<!-- page 1 -->
# SERVICES AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2019-04-01 |
| Parties | Idan Maimon ("Maimon"); Intellisense Solutions Inc. ("Company") |
| Source | CUAD v1 / SCOUTCAMINC_05_12_2020-EX-10.22-SERVICES AGREEMENT |

Exhibit 10.22 SERVICES AGREEMENT SERVICES AGREEMENT, dated as of April 1, 2019 (the "Agreement"),
between Idan Maimon ("Maimon") and Intellisense Solutions, Inc., a Nevada corporation (the
"Company"). WHEREAS, the Company desires to engage Maimon as the Company's Chief Executive Officer
("CEO"), to provide services to the Company that are ordinarily and customarily performed by a CEO,
and Maimon is willing to serve as the CEO and member of the board of directors of the Company, on
the terms and conditions set forth below; and WHEREAS, the Company desires Maimon to serve on the
Company's Board of Directors. NOW, THEREFORE, in consideration of the mutual covenants and
agreements contained herein, the receipt and sufficiency of which are hereby acknowledged, the
Company and Maimon agree as follows: 1. Services. The Company hereby retains Maimon, and Maimon
hereby agrees to make himself available as the Company's CEO, upon the terms and subject to the
conditions contained herein. 2. Duties. During the Service Term (as hereinafter defined), the
parties agree that Maimon shall serve as the Company's CEO, and shall perform all the duties that
are ordinarily and customarily performed by a CEO. 3. Term. Subject to the provisions for
termination hereinafter provided, the term of this Agreement shall commence on the date hereof (the
"Effective Date") and shall continue for a minimum period of 12 months (the "Minimum Period") and
thereafter upon the mutual agreement of the Company and Maimon (the "Service Term"). 4.
Compensation. In consideration of the services to be rendered by Maimon hereunder and for Maimon's
service as a director on the Board of Directors of the Company, the Company will pay Maimon a
monthly fee of $1,000 during the Minimum Period, beginning on the Effective Date. 5. Termination. If
Maimon should become unable to serve as CEO, or should fail to perform any of the obligations
hereunder for any cause including death or disability, always in the sole judgment and decision of
the Company, then the Company shall have the right to terminate this agreement on five days prior
written notice. Maimon shall have the right to resign at any time upon 30 days prior written notice.
The Company may in its discretion and at its option terminate this Agreement at any time after the
Minimum Period upon five days prior written notice to Maimon. 6. Reimbursement. The Company will
reimburse Maimon for all reasonable pre- approved out-of-pocket expenses incurred in connection with
this Agreement. 1
<!-- page 2 -->
7. Confidential Information. Maimon recognizes and acknowledges that by reason of his retention by
and service to the Company, Maimon will have access to certain confidential and proprietary
information relating to the Company's business, which may include, but is not limited to, trade
secrets, trade "know-how," product development techniques and plans, formulas, customer lists and
addresses, financing services, funding programs, cost and pricing information, marketing and sales
techniques, strategy and programs, computer programs and software and financial information
(collectively referred to as "Confidential Information"). Maimon acknowledges that such Confidential
Information is a valuable and unique asset of the Company and covenants that he will not, unless
expressly authorized in writing by the Company, at any time use any Confidential Information or
divulge or disclose any Confidential Information to any person, firm or corporation except in
connection with the performance of his duties for the Company and in a manner consistent with the
Company's policies regarding Confidential Information. Maimon also covenants that at any time after
the termination of this Agreement, directly or indirectly, he will not use any Confidential
Information or divulge or disclose any Confidential Information to any person, firm or corporation,
unless such information is in the public domain through no fault of his or except when required to
do so by applicable law. All written Confidential Information (including, without limitation, in any
computer or other electronic format) which comes into Maimon's possession during the Service Term
shall remain the property of the Company. Except as required in the performance of Maimon's duties
for the Company, or unless expressly authorized in writing by the Company, Maimon shall not remove
any written Confidential Information from the Company's premises, except in connection with the
performance of his duties for the Company and in a manner consistent with the Company's policies
regarding Confidential Information. Upon termination of this Agreement, Maimon agrees to return
immediately to the Company all written Confidential Information (including, without limitation, in
any computer or other electronic format) in his possession. 8. Conflicts of Interest,
Non-Competition, Non-Solicitation. Maimon agrees during the term of this Agreement not to accept
work or enter into a contract or accept an obligation inconsistent or incompatible with Maimon's
obligations under this Agreement or with the scope of services to be rendered for the Company.
Maimon warrants that to the best of Maimon's knowledge, there is no other contract or duty on
Maimon's part now in existence inconsistent with this Agreement. During the term of this Agreement
and for a period of two (2) years after expiration or termination for any reason of this Agreement,
Maimon agrees not to: (a) compete with the business of the Company, whether individually or through
any entity, or to use (or permit the use of) any Confidential Information, directly or indirectly,
for the purpose of competing with the business of the Company; or (b) suggest to, induce or persuade
any customer, client, vendor, supplier, employee, consultant or agent of the Company to terminate or
diminish its relationship with the Company.. 9. Waiver of Breach. The waiver by any party hereto of
a breach of any provision of this Agreement shall not operate nor be construed as a waiver of any
subsequent breach. 10. Binding Effect; Benefits. Neither of the parties hereto may assign its or his
rights hereunder without the prior written consent of the other party hereto, and any such attempted
assignment without such consent shall be null and void and without effect. This Agreement shall
inure to the benefit of, and shall be binding upon, the parties hereto and their respective
successors, permitted assigns, heirs and legal representatives. 2
<!-- page 3 -->
11. Entire Agreement; Amendments. This Agreement contains the entire agreement and supersedes all
prior agreements and understandings, oral or written, between the parties hereto with respect to the
subject matter hereof. This Agreement may not be changed orally, but only by an agreement in writing
signed by the party against whom any waiver, change, amendment, modification or discharge is sought.
12. Severability. The invalidity of all or any part of any provision of this Agreement shall not
render invalid the remainder of this Agreement or the remainder of such provision. If any provision
of this Agreement is so broad as to be unenforceable, such provision shall be interpreted to be only
so broad as is enforceable. 13. Governing Law; Consent to Jurisdiction. This Agreement shall be
governed by and construed in accordance with the law of the State of New York without giving effect
to the principles of conflicts of law thereof. The parties hereto each hereby submits herself or
itself for the sole purpose of this Agreement and any controversy arising hereunder to the exclusive
jurisdiction of the state courts in the State of New York. 14. Headings. The headings herein are
inserted only as a matter of convenience and reference, and in no way define, limit or describe the
scope of this Agreement or the intent of the provisions thereof. 15. Counterparts. This Agreement
may be executed in one or more counterparts, each of which shall be deemed an original and all of
which together shall constitute one and the same instrument. Signatures evidenced by facsimile
transmission will be accepted as original signatures. IN WITNESS WHEREOF, the parties have caused
this Agreement to be duly executed as of the date first above written. /s/ Oded Gilboa INTELLISENSE
SOLUTIONS, INC. Oded Gilboa, CFO 3
