<!-- page 1 -->
# COLLABORATIVE RESEARCH, DEVELOPMENT AND COMMERCIALIZATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2018-06-08 |
| Parties | Revolution Medicines, Inc. ("Revmed"); Aventis, Inc. ("Sanofi")("Party" and collectively as the "Parties") |
| Source | CUAD v1 / RevolutionMedicinesInc_20200117_S-1_EX-10.1_11948417_EX-10.1_Development Agreement |

Exhibit 10.1

[***] Certain information in this document has been excluded pursuant to Regulation S-K, Item
601(b)(10). Such excluded information is not material and would likely cause competitive harm to the
registrant if publicly disclosed.

Execution Copy

COLLABORATIVE RESEARCH, DEVELOPMENT AND COMMERCIALIZATION AGREEMENT

This COLLABORATIVE RESEARCH, DEVELOPMENT AND COMMERCIALIZATION AGREEMENT (this "Agreement") is
entered into as of June 8, 2018 (the "Execution Date"), by and between Revolution Medicines, Inc., a
corporation organized and existing under the laws of Delaware, having its principal place of
business at 700 Saginaw Dr. Redwood City, CA 94063, USA ("RevMed"), and Aventis, Inc., a corporation
organized and existing under the laws of Pennsylvania, having offices at 55 Corporate Drive,
Bridgewater, NJ 08807 ("Sanofi"). Sanofi and RevMed are referred to in this Agreement individually
as a "Party" and collectively as the "Parties."

RECITALS

WHEREAS, RevMed has developed expertise in cancer biology and related drug discovery and precision
medicine capabilities enabling RevMed to design and optimize drug candidates that inhibit the
activity of the cancer target known as Src homology region 2-containing protein tyrosine phosphatase
2;

WHEREAS, Sanofi is a pharmaceutical company working to develop and commercialize novel therapies;

WHEREAS, RevMed and Sanofi desire to establish a collaboration for the research, development and
potential commercialization of such drug candidates and biologic compounds that inhibit the activity
of such cancer target for the treatment of cancer, and potentially other indications; and

WHEREAS, Sanofi desires to acquire from RevMed, and RevMed desires to grant to Sanofi, certain
licenses with regard to SHP2 Inhibitors and Products (as defined below), as further described
herein.

NOW, THEREFORE, in consideration of the foregoing premises and the mutual covenants contained
herein, the receipt and sufficiency of which are hereby acknowledged, RevMed and Sanofi hereby
agree:

Article I.

DEFINITIONS

The terms in this Agreement with initial letters capitalized shall have the meanings set forth
below, or the meaning as designated in the indicated places throughout this Agreement.

1.1 "Accounting Standards" means, with respect to a Party or its Affiliate or Sublicensee, IFRS or
GAAP, as such Person uses for its financial reporting obligations, consistently applied.

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 2 -->
1.2 "Acquired Party Family" means in the case of a Change of Control of a Party or its Affiliate,
such Party or such Affiliate existing immediately prior to the Change of Control transaction and any
subsidiaries thereof (then existing or thereafter created).

1.3 "Acquiror Family" means in the case of a Change of Control of a Party or any of its Affiliates,
the Acquiror and its Affiliates existing immediately prior to the closing of the Change of Control
transaction together with any future Affiliates other than the Acquired Party Family.

1.4 "Act" means the United States Federal Food, Drug, and Cosmetic Act, as amended, and the rules,
regulations, guidance, guidelines and requirements promulgated thereunder (including all additions,
supplements, extensions and modifications) in effect from time to time.

1.5 "Affiliate" means, with respect to a Party or other Person, any corporation or other business
entity that, directly or indirectly, through one or more intermediaries, controls, is controlled by,
or is under common control with that Party or other Person for so long as such Party or other Person
controls, is controlled by or is under common control with such corporation or other business
entity. For the purpose of this definition only, "control" (including, with correlative meaning, the
terms "controlled by" and "under the common control") means the actual power, either directly or
indirectly through one or more intermediaries, to direct or cause the direction of the management
and policies of such Party or other Person, whether by the ownership of 50% or more of the voting
equity of such Party or other Person, by contract or otherwise. Notwithstanding the foregoing,
solely with respect to Sections 1.61 (Major Biopharmaceutical Company), and 3.1 (Licenses to
Sanofi), "Affiliates" will not include (a) with respect to an entity, its bona fide venture capital
or private equity investors, (b) with respect to an entity, its bona fide institutional investors,
provided that such institutional investors routinely make venture capital investments for the
potential financial return on such investments and for so long as such institutional investors do
not (x) obtain any rights (including options, rights to negotiate, rights of first refusal or other
contingent rights) to acquire control of such entity or its assets or (y) enter into or agree to
enter into any research, development, commercial, license or other strategic transaction with such
entity (each investor in clause (a) and (b), an "Excluded Investor"), or (c) Affiliates of such
venture capital, private equity or institutional investors that do not otherwise qualify as
Affiliates of such entity under this Section 1.5 (i.e., for a reason other than by virtue of their
status as Affiliates of such investors).

1.6 "Ancillary Agreement" means the Co-Promotion Agreement, the Pharmacovigilance Agreement, the
Profit/Loss Share Agreement, any Supply Agreement, any Quality Agreement and any other agreement
entered into between the Parties (or their respective Affiliates) pursuant to this Agreement.

1.7 "Antitrust Law" means the Hart-Scott-Rodino Antitrust Improvements Act of 1976 and the rules and
regulations promulgated thereunder (the "HSR Act"), the Sherman Act, as amended, the Clayton Act, as
amended, the Federal Trade Commission Act, as amended, and any other Applicable Laws related to
merger control or designed to prohibit, restrict or regulate actions having the purpose or effect of
monopolization or restraint of trade. 2

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 3 -->
1.8 "Applicable Law" means (a) any federal, state, local, foreign or multinational law, statute,
standard, ordinance, code, rule, regulation, resolution or promulgation (including written
governmental interpretations thereof, the guidance related thereto), (b) any judicial, governmental
or administrative order, judgment, decree or ruling by any Governmental Authority, or (c) any
license, franchise, permit or similar right granted under any of the foregoing, or any similar
provision having the force or effect of law, in each case (a), (b) and (c) that may be in effect
from time to time and as applicable to the subject matter and the Persons at issue.

1.9 "Business Day" means a day other than a Saturday or Sunday or a day on which banking
institutions in San Francisco, California or in Paris, France are permitted or required to be
closed.

1.10 "Calendar Quarter" means each successive period of three calendar months commencing on January
1, April 1, July 1 and October 1, except that the first Calendar Quarter of the Term shall commence
on the Effective Date and end on the day immediately prior to the first to occur of January 1, April
1, July 1 or October 1 after the Effective Date, and the last Calendar Quarter shall end on the last
day of the Term.

1.11 "Calendar Year" means each successive period of 12 calendar months commencing on January 1 and
ending on December 31, except that the first Calendar Year of the Term shall commence on the
Effective Date and end on December 31 of the year in which the Effective Date occurs and the last
Calendar Year of the Term shall commence on January 1 of the year in which the Term ends and end on
the last day of the Term.

1.12 "Change of Control" means with respect to a Party (a) any sale, exchange, transfer, or issuance
to or acquisition in one transaction or a series of related transactions by one or more Third
Parties of units and/or shares of equity (as applicable) representing 50% or more of the aggregate
ordinary voting power entitled to vote for the election of directors or managers represented by the
issued and outstanding units of equity of such Party (or any Affiliate that directly or indirectly
controls such Party (such Affiliate, the "Parent")), whether such sale, exchange, transfer, issuance
or acquisition is made directly or indirectly, by merger or otherwise, or beneficially or of record
(collectively, a "Stock Sale"); (b) a merger or consolidation under Applicable Law of such Party or
a Parent with a Third Party, other than a merger or consolidation in which the units and/or shares
of equity of such Party or Parent outstanding immediately prior to such merger or consolidation
continue to represent, or are converted into or are exchanged for units and/or shares of equity
which represent, immediately following such merger or consolidation, 50% or more of the aggregate
ordinary voting power of such units and/or shares of equity of the surviving or resulting entity or
a parent entity of such surviving or resulting entity, whether direct or indirect (collectively, a
"Merger"); (c) a sale, lease, transfer, exclusive license or other disposition of all or
substantially all of the assets of such Party or a Parent to one or more Third Parties in one
transaction or a series of related transactions (collectively, the "Asset Transfer").
Notwithstanding the foregoing, a purchase of shares in a Stock Sale by one or more Third Parties in
a bona fide financing transaction the primary purpose of which is to raise working capital for
RevMed or to acquire assets from a Third Party (in either case including one or more public
offerings) shall not constitute a Change of Control even if such Third Parties collectively
negotiate or receive their rights as security holders in such financing transaction(s), except that
such exemption shall not apply with respect to any Change of Control that would result in any Major
Biopharmaceutical Company having more than 50% of the aggregate ordinary voting power in RevMed or
its Parent. The Parent of a Party for purposes of this Section 1.12 shall not include any 3

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 4 -->
Excluded Investor, provided that the applicable Stock Sale, Merger or Asset Transfer does not result
in any Major Biopharmaceutical Company having more than 50% of the aggregate ordinary voting power
in, or control over all or substantially all of the assets of, RevMed or its Parent or any surviving
or resulting entity or a parent entity of such surviving or resulting entity.

1.13 "Clinical Trial" means any clinical investigation conducted on human subjects, as that term is
defined in FDA regulations at 21 C.F.R. § 312.3. Without limiting the foregoing, Clinical Trial
includes any Phase 1 Clinical Trial, Phase 2 Clinical Trial, Phase 3 Clinical Trial, Phase 4 Study
or variations of the foregoing.

1.14 "Collaboration" means the collaboration of the Parties with respect to the Research,
Development, Manufacture and Commercialization of Products in the Field, as and to the extent set
forth in this Agreement and the Ancillary Agreements.

1.15 "Combination Product" means any pharmaceutical preparation in final form containing a SHP2
Inhibitor in combination with one or more additional active ingredients, for sale by prescription or
any other method either as a fixed dose or unit or as separate doses or units in a single package.

1.16 "Commercialization" means the marketing, promotion, sale or distribution of Products (or
Companion Diagnostics for Products in accordance with this Agreement) in the Field, including: (a)
commercial activities conducted in preparation for commercial launch of a Product; (b) strategic
marketing, sale force detailing, advertising, medical education and liaison; (c) any Phase 4
Studies, except Required Phase 4 Studies; and (d) all customer support, product distribution,
invoicing and other sales activities. "Commercialize" and "Commercializing" have a correlative
meaning.

1.17 "Commercially Reasonable Efforts" means: (a) with respect to Sanofi, [***], consistent with
[***] that [***], taking into account [***], including [***] and (b) with respect to RevMed, [***],
consistent with [***] that [***], taking into account [***], including [***].

1.18 "Committee" means the JSC, JRDC, JCC, JPC or any subcommittee established under Article II, as
applicable.

1.19 "Companion Diagnostic" means, with respect to a Product, (a) a companion diagnostic approved by
the applicable Regulatory Authority that provides information essential to the safe and effective
use of such Product or is otherwise necessary for the Regulatory Approval of such Product, or (b) a
complementary diagnostic that provides information helpful to the safe and effective use of such
Product but is not a companion diagnostic referred to in the foregoing clause (a).

1.20 "Competing Product" means, other than a Product, any pharmaceutical preparation [***] that
satisfies the criteria [***], alone or in combination with one or more additional active
ingredients, for sale by prescription or any other method. 4

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 5 -->
1.21 "Confidential Information" of a Party means all proprietary Know-How, unpublished patent
applications and other non-public information and data of a financial, commercial, business,
operational or technical nature of such Party that is disclosed by or on behalf of such Party, its
Affiliates or its or their Sublicensees, or otherwise made available to the other Party, its
Affiliates or its or their Sublicensees, prior to, on or after the Effective Date, whether made
available orally, in writing or in electronic form in connection with this Agreement or any
Ancillary Agreement, including the terms of this Agreement and any Ancillary Agreements, information
comprising or relating to concepts, discoveries, inventions, data, designs or formulae in connection
with this Agreement or any Ancillary Agreement. All (a) RevMed Licensed Know-How to the extent
relating to SHP2 Inhibitors or Products, (b) Joint Program Know-How, and (c) the terms of this
Agreement and any Ancillary Agreements, shall be deemed to be the Confidential Information of both
Parties (and both Parties shall be deemed to be the Receiving Party and the Disclosing Party with
respect thereto). All RevMed Licensed Know-How to the extent relating to RevMed's products and
product candidates (other than SHP2 Inhibitors or Products) shall not be deemed Confidential
Information of both Parties.

1.22 "Control" or "Controlled" means, with respect to any item of Know-How, Patent Right, other
intellectual property right or Regulatory Material, a Party has the ability (whether by sole, joint
or other ownership interest, license, sublicense or otherwise, and including any such abilities
which are contingent) (other than by operation of the licenses granted in this Agreement) to grant a
license, sublicense, access or right to use (as applicable) under such item of Know-How, Patent
Right, other intellectual property right or Regulatory Material to the other Party on the terms and
conditions set forth herein at the time of such grant, in each case without breaching the terms of
any agreement with a Third Party.

1.23 "Correspondence" means that certain letter between Sanofi and RevMed dated as of the Execution
Date.

1.24 "Decision-Making Committee" means each Committee (other than the JPC and JMC).

1.25 "Designated Senior Officer" means: (a) with respect to RevMed, [***] and, (b) with respect to
Sanofi, [***].

1.26 "Detail" means, with respect to a Co-Promotion Product in the Co-Promotion Territory, a
face-to-face contact between a sales representative and a physician or other medical professional
licensed or authorized to prescribe drugs, during which a primary position detail or a secondary
position detail is made to such person, in each case as measured by each Party's internal recording
of such activity in accordance with the Co-Promotion Agreement; provided that such meeting is
consistent with and in accordance with the requirements of Applicable Law, this Agreement and the
Co- Promotion Agreement. For the avoidance of doubt, the following activities will not constitute
Details: e-details; sample drops; reminder details; activities conducted at conventions, exhibit
booths, speaker meetings or similar gatherings; and activities performed by market development
specialists, managed care account directors and other personnel not performing face-to-face sales
calls or not specifically trained with respect to a Co-Promotion Product. The definition of "Detail"
may be further refined in the Co-Promotion Agreement. When used as a verb, "Detail" means to engage
in a Detail. 5

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 6 -->
1.27 "Development" means all development activities for any Product (or a Companion Diagnostic for
such Product in accordance with this Agreement) that are directed to obtaining Regulatory
Approval(s) of such Product, including: all non-clinical, preclinical and clinical activities
conducted in support of Regulatory Approval (including any Required Phase 4 Studies); testing and
studies of such Product (including IND-enabling studies and translational research); toxicology,
pharmacokinetic and pharmacological studies; manufacture and distribution of such Product for use in
Clinical Trials (including comparators, process development and scale up, and Combination
Therapies); statistical analyses; assay development; instrument design and development; protocol
design and development; quality assurance and control; report writing; the preparation, filing and
prosecution of any MAA for such Product; development activities directed to label expansion or
obtaining Regulatory Approval for one or more additional indications following initial Regulatory
Approval; health economic studies relating to the indication for which the applicable Product is
being developed conducted prior to Regulatory Approval; and all regulatory affairs related to any of
the foregoing. "Develop" and "Developing" have a correlative meaning.

1.28 "Dollars" means the U.S. dollar, and "$" shall be interpreted accordingly.

1.29 "Drug Treatment Regimen" means either (a) SHP2 Inhibitor monotherapy, or (b) SHP2 Inhibitor
Combination Therapy.

1.30 "EMA" means the European Medicines Agency or any successor entity thereto.

1.31 "EU" or the "European Union" means the economic, scientific and political organization of
European Union member states as it may be constituted from time to time, which as of the Effective
Date consists of: Austria, Belgium, Bulgaria, Croatia, Cyprus, Czech Republic, Denmark, Estonia,
Finland, France, Germany, Greece, Hungary, Ireland, Italy, Latvia, Lithuania, Luxemburg, Malta,
Netherlands, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden and the United Kingdom, as
well as Norway and Iceland. For purposes of this Agreement, the "EU" shall continue to include each
foregoing territory whether or not such territory is a participating member state as of the
applicable time.

1.32 "Excluded List" means any of the United States Department of Health and Human Service's List of
Excluded Individuals/Entities or the United States General Services Administration's Lists of
Parties Excluded from Federal Procurement and Non-Procurement Programs.

1.33 "FCPA" means the U.S. Foreign Corrupt Practices Act of 1977, as amended, including the rules
and regulations thereunder. A summary of the FCPA and related information can be found at
http://www.justice.gov/criminal/fraud/fcpa.

1.34 "FDA" means the United States Food and Drug Administration or any successor entity thereto.

1.35 "FFDCA" means the United States Federal Food, Drug, and Cosmetic Act, 21 U.S.C. 301, et. seq.,
as it may be amended from time to time, and the rules, regulations, guidance, guidelines, and
requirements promulgated or issued thereunder.

1.36 "Field" means any and all uses. 6

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 7 -->
1.37 "First Commercial Sale" means, with respect to any Product in any country or jurisdiction, the
first sale for monetary value of such Product to a Third Party for distribution, use or consumption
in such country or jurisdiction after Marketing Approval has been obtained for such Product in such
country or jurisdiction. Sales prior to receipt of Marketing Approval for such Product, such as
so-called "treatment IND sales," "named patient sales," and "compassionate use sales," shall not be
construed as a First Commercial Sale.

1.38 "FTE" means a full time equivalent person year (consisting of [***] hours per year) of work as
an employee or contractor [***] hereunder as tracked by each Party using its respective standard
practice and methodologies. For clarity, [***] will not constitute FTEs. Notwithstanding the
foregoing, the time of a single individual will not account for more than one FTE for a given
Calendar Year (or applicable pro-rata portion of an FTE during any Calendar Quarter or other period
of less than a Calendar Year).

1.39 "FTE Costs" means, with respect to a Party for any period, the applicable FTE Rate multiplied
by the applicable number of FTEs of such Party performing the applicable activity described
hereunder during such period.

1.40 "FTE Rate" means the applicable rate set forth in Exhibit A of the Correspondence or in any
Ancillary Agreement or exhibit thereto, which rate shall be adjusted annually, with each annual
adjustment effective as of January 1 of each Calendar Year, with the first such annual adjustment to
be made as of January 1, 2019, to correspond with respect to Research, Development, Manufacturing or
Commercialization activities under the Collaboration by or on behalf of a Party, [***] preceding
each such January 1.

1.41 "GAAP" means the U.S. generally accepted accounting principles.

1.42 "Generic Product" means, with respect to a Product, any pharmaceutical or biological product
(a) that is sold by a Person other than a Party or its Affiliates or Sublicensees, which Person did
not purchase such product in a chain of distribution that included such Party or its Affiliate or
Sublicensee as intentional participants, (b) contains, for a pharmaceutical product, the same or a
bioequivalent SHP2 Inhibitor or, for a biologic product, a biosimilar or interchangeable SHP2
Inhibitor, to such Product[***].

1.43 "Genotype" means one or more [***]. In the cases where such [***].

1.44 "Good Clinical Practice" or "GCP" means the then-current standards for Clinical Trials for
pharmaceuticals, as set forth in the Act or other Applicable Law, and such standards of good
clinical practice as are required by the Regulatory Authorities of the European Union and other
organizations and Governmental Authorities in countries for which the SHP2 Inhibitor or Product is
intended to be Developed, to the extent such standards are not less stringent than United States
GCP.

1.45 "Good Laboratory Practice" or "GLP" means the then-current standards for laboratory activities
for pharmaceuticals, as set forth in the Act or other Applicable Law, and such standards of good
laboratory practice as are required by the Regulatory Authorities of the European Union and other
organizations and Governmental Authorities in countries for which the applicable SHP2 Inhibitor or
Product is intended to be Developed, to the extent such standards are not less stringent than United
States GLP. 7

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 8 -->
1.46 "Good Manufacturing Practice" or "GMP" means the current good manufacturing practices
applicable from time to time to the manufacturing of a SHP2 Inhibitor, Product or any intermediate
thereof pursuant to Applicable Law.

1.47 "Governmental Authority" means any multi-national, federal, national, state, provincial, local,
municipal or other government authority of any nature (including any governmental division,
subdivision, commission, department, bureau, prefecture, agency, branch, office, governmental
arbitrator or arbitral body, council, court or other tribunal entitled to exercise any
administrative, executive, judicial, legislative, police, regulatory or taxing authority or power).

1.48 "IFRS" means the International Financial Reporting Standards.

1.49 "Immuno-Oncology Agent" means any treatment [***]. For clarity, Immuno-Oncology Agent shall
include any treatment that primarily targets [***].

1.50 "IND" means (a) in the United States, an Investigational New Drug Application, as defined in
the Act, that is required to be filed with the FDA before conducting a Clinical Trial (including all
supplements and amendments that may be filed with respect to the foregoing); and (b) any foreign
counterpart of the foregoing filed with a Regulatory Authority in conformance with the requirements
of such Regulatory Authority.

1.51 "Indication" means a type of cancer for which Regulatory Approval for a Product is being sought
that (i) is distinct from other types of cancer by [***].

1.52 "Initial R&D Term" means the first [***] of the Term.

1.53 "Initiation" means, with respect to a Clinical Trial of a Product, [***] subject for such
Clinical Trial.

1.54 "Joint Program Patents" means any Patent Right covering or claiming the Joint Program Know-How.

1.55 "Joint Program Technology" means Joint Program Know-How and Joint Program Patents.

1.56 "Knowledge" means, with respect to a Party, the actual knowledge of such Party, or what such
Party should have known after due inquiry.

1.57 "Know-How" means any information and materials, including but not limited to discoveries,
inventory, information, regulatory filings, processes, formulae, data, databases, protocols,
inventions (whether patentable or not), improvements (whether patentable or not), invention
disclosures, developments, skills, experience, know-how and trade secrets (whether patentable or
not), including without limitation, all chemical, pharmaceutical, toxicological, biochemical, and
biological, technical and non-technical data, and information relating to the results of tests,
assays, methods, techniques, and processes, and specifications or other documents containing
information and related data, and any preclinical, clinical, assay control, manufacturing,
regulatory and any other data or information, but excluding any Patent Rights. 8

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 9 -->
1.58 "Licensed Territory" means all countries and territories of the world.

1.59 "Line of Therapy" means the treatment with a Product [***].

1.60 "Losses" means any and all liability, loss, damage, injury, costs or expenses (including
reasonable attorneys' fees and expenses of litigation) of any kind.

1.61 "MAA" or "Marketing Authorization Application" means an application to the appropriate
Regulatory Authority for Marketing Approval (but excluding pricing approval) in the Field in any
particular jurisdiction (including, without limitation, a New Drug Application in the U.S.) and all
amendments and supplements thereto.

1.62 "Major Biopharmaceutical Company" means (a) any entity that develops or commercializes
healthcare products for human consumption that has a fully diluted market capitalization of at least
$[***] as measured at the closing price on the last day of the preceding Calendar Quarter during
which the measurement is taken or any Affiliate of such entity or (b) any entity that has [***].

1.63 "Major Market Countries" means the [***].

1.64 "Manufacture" and "Manufacturing" mean activities directed to manufacturing, processing,
filling, finishing, packaging, labeling, quality assurance testing and release, storing and
transporting any Product, SHP2 Inhibitors or any intermediate or component thereof, including
manufacturing and analytical development, process and formulation development, process
qualification, process validation, scale-up, pre-clinical, clinical and commercial manufacture and
analytic development, product characterization, stability testing, quality assurance and quality
control, and chemistry, manufacturing and controls.

1.65 "Manufacturing Costs" means, with respect to a Product, the costs incurred by a Party or its
Affiliate or Sublicensee in connection with Manufacturing or purchasing from a Third Party, as
applicable, each Product that is either (a) supplied by a Third Party, or (b) manufactured directly
by a Party or an Affiliate or Sublicensee of such Party, determined as follows and in accordance
with Accounting Standards:

In the case of clause (a) above, Manufacturing Costs means [***]. To the extent any non-refundable
or non-creditable value added or similar tax is due with respect to amounts paid to such Third Party
for Manufacture of any portion of a Product, such amounts shall be considered Manufacturing Costs
under this clause (a).

In the case of clause (b) above, Manufacturing Costs means: (i) [***] and a reasonable allocation of
[***], which allocation is made [***]; (ii) [***]; and (iii) a reasonable allocation of [***]. All
components of Manufacturing Costs shall be allocated [***].

Such Party may elect, in its sole discretion, to [***] the above Manufacturing Cost definition. 9

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 10 -->
Third Party payments shall be included on a pass-through basis for purposes of clause (a) or clause
(b) above.

1.66 "Marketing Approval" means all Regulatory Approvals necessary for the commercial sale of a
Product in the Field in a given country or regulatory jurisdiction, including pricing and
reimbursement approval.

1.67 "Material Adverse Event" means any event, occurrence, condition, change, circumstance,
development, effect or state of facts that has had or would reasonably be expected to have,
individually or in the aggregate, materially adverse to [***]; provided, however, that "Material
Adverse Effect" shall not include the effect of any event, occurrence, condition, change,
circumstance, development, effect or state of facts arising out of or attributable to any of the
following, either alone or in combination: [***], in each case of clauses (i), (ii) or (iv) only to
the extent such event, occurrence, condition, change, circumstance, development, effect or state of
facts has a disproportionate effect on a Party or its Affiliates as compared to other participants
operating in the biopharmaceutical industry in the same markets in which such Party or its
Affiliates conduct their businesses.

1.68 "NDA" means (a) in the United States, a New Drug Application or Biologics License Application
that is submitted to the FDA for Regulatory Approval for a Product, and (b) any foreign counterpart
of either of the foregoing filed with a Regulatory Authority in conformance with the requirements of
such Regulatory Authority.

1.69 "Net Sales" means, with respect to a Product for any period, the gross amount billed or
invoiced by Sanofi, its Affiliates or its or their Sublicensees for the sale of a Product to Third
Parties (including Distributors) commencing with the First Commercial Sale of such Product less the
following deductions determined in accordance with Accounting Standards from such gross amounts
which are actually incurred, allowed, accrued or specifically allocated: (a) [***] (b) [***] (c)
[***] (d) [***] (e) [***] (f) [***] (g) [***] (h) [***] (i) [***] and (j) [***]. 10

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 11 -->
Any of the deductions listed above that involves a payment by such Party, its Affiliates or its or
their Sublicensees shall be taken as a deduction in the Calendar Quarter in which the payment is
accrued by such entity. For purposes of determining Net Sales, a Product shall be deemed to be sold
when [***]. Net Sales shall not include [***]. Such Party's, its Affiliates' or its or their
Sublicensees' transfer of any Product to an Affiliate or Sublicensee shall not result in any Net
Sales unless the transferee is an end user.

In the event that a Product is sold in any country in the form of a Combination Product, Net Sales
of such Combination Product shall be adjusted by [***]; provided that the invoice price [***]. If
either such Product that contains the SHP2 Inhibitor(s) as its sole active ingredient or any such
product that contains active ingredient(s) other than the SHP2 Inhibitor(s) is not sold separately
in a particular country, then the adjustment to Net Sales shall be [***].

In the case of pharmacy incentive programs, hospital performance incentive programs, chargebacks,
disease management programs, similar programs or discounts on portfolio product offerings, [***];
provided that [***] shall be done in accordance with Applicable Law, including any price reporting
laws, rules and regulations.

Subject to the above, Net Sales shall be calculated [***].

1.70 "Non-SHP2 Collaboration Product" means for any Drug Treatment Regimen under the Collaboration
that is [***].

1.71 "Non-SHP2 Same Class Product" means, with respect to a Non-SHP2 Collaboration Product, any
[***].

1.72 "Other SHP2 Inhibitor" means any small molecule or biologic compound that (a) satisfies the
criteria specified in the SHP2 Inhibitor Criteria and (b) is not a SHP2 Inhibitor that is Controlled
by RevMed or its Affiliates.

1.73 "Patent Rights" means any and all national, regional and international (a) issued patents and
pending patent applications (including provisional patent applications), (b) patent applications
filed either from the foregoing or from an application claiming priority to the foregoing, including
all provisional applications, converted provisionals, substitutions, continuations,
continuations-in-part, divisions, renewals and continued prosecution applications, and all patents
granted thereon, (c) patents-of-addition, revalidations, reissues, reexaminations and extensions or
restorations by existing or future extension or restoration mechanisms, including patent term
adjustments, patent term extensions, supplementary protection certificates or the equivalent
thereof, (d) inventor's certificates, utility models, petty patents, innovation patents and design
patents, (e) other forms of government-issued rights substantially similar to any of the foregoing,
including so-called pipeline protection or any importation, revalidation, confirmation or
introduction patent or registration patent or patent of additions to any of such foregoing and (f)
United States and foreign counterparts of any of the foregoing.

1.74 "Permitted Contractors or Researchers" means (a) any Third Party independent contractor that
RevMed has entered into a written agreement with prior to the Effective Date and which Person is
listed on Exhibit B of the Correspondence, (b) any other Third Party to which Sanofi consents in
writing as a subcontractor of RevMed pursuant to Section 3.4, and (c) any named Third Party set
forth in the Research Plan or Development Plan. 11

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 12 -->
1.75 "Person" means any individual, partnership, limited liability company, firm, corporation,
association, trust, unincorporated organization or other entity.

1.76 "Phase 1 Clinical Trial" means a Clinical Trial of a Product that generally provides for the
first introduction into humans of such Product, with the primary purpose of determining metabolism
and pharmacokinetic properties and side effects of such product, in a manner that is generally
consistent with 21 C.F.R. § 312.21(a), as amended (or its successor regulation), excluding, for
clarity, any investigator-initiated Clinical Trials unless agreed to by the JRDC.

1.77 "Phase 2 Clinical Trial" means a Clinical Trial of a Product conducted on a sufficient number
of subjects for evaluating (and the principal purpose of which is to evaluate) the effectiveness of
a pharmaceutical product for its particular intended use and obtaining (and to obtain) information
about side effects and other risks associated with the drug, in a manner that is generally
consistent with 21 C.F.R. § 312.21(b), as amended (or its successor regulation), or a similar
clinical study prescribed by the Regulatory Authorities in a country or jurisdiction outside the
United States, to permit the design of further Clinical Trials of such Product, excluding, for
clarity, any investigator-initiated Clinical Trials unless agreed to by the JRDC.

1.78 "Phase 3 Clinical Trial" means a pivotal Clinical Trial of a Product with a defined dose or a
set of defined doses of such Product and conducted on a sufficient number of subjects for
ascertaining (and that is designed to ascertain) the overall risk-benefit relationship of the
Product for its intended use and determining (and to determine) warnings, precautions, and adverse
reactions that are associated with such Product in the dosage range to be prescribed, in a manner
that is generally consistent with 21 C.F.R. § 312.21(c), as amended (or its successor regulation),
or a similar clinical study prescribed by the Regulatory Authorities in a country or jurisdiction
outside the United States, which trial is necessary to support Regulatory Approval of such Product,
excluding, for clarity, any investigator-initiated Clinical Trials unless agreed to by the JRDC.

1.79 "Phase 4 Study" means a Clinical Trial or data collection effort with respect to any Product
that is commenced after the receipt of Regulatory Approval in the country where such trial is
conducted.

1.80 "PMDA" means Japan's Pharmaceuticals and Medical Devices Agency and any successor thereto.

1.81 "Pre-Registrational Meeting" means the meeting with the FDA or the equivalent meeting with the
EMA or PMDA or other Regulatory Authority (as applicable) to be conducted to discuss the
requirements of the FDA, EMA, or PMDA or other Regulatory Authority (as applicable) for a
Registration Program for a given Product to support Marketing Approval, e.g., end-of-Phase 2 or
pre-Phase 3 meetings.

1.82 "Product" means any pharmaceutical preparation in final form containing a SHP2 Inhibitor, alone
or in the form of a Combination Product. 12

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 13 -->
1.83 "Program Inventions" means any Know-How conceived, reduced to practice, developed, made or
otherwise generated by or on behalf of a Party or its Affiliates or Sublicensees in connection with
the Research, Development, Manufacture or Commercialization of SHP2 Inhibitors or Products under
this Agreement or any Ancillary Agreement, including all rights, title and interest in and to the
intellectual property rights therein.

1.84 "Publication" means any release of information, including any presentation, which information
(a) has not been disclosed pursuant to Section 11.3 or (b) has not previously been publicly
disclosed.

1.85 "Registrational Clinical Trial" means a Clinical Trial of a Product designed to be adequate to
achieve Regulatory Approval of such Product and that would satisfy the requirements of 21 C.F.R
312.21(c), as amended, or corresponding foreign regulations, regardless of whether such trial is
referred to as a "phase 2b clinical trial", "phase 2b/3 clinical trial" or "phase 3 clinical trial",
but excluding, for clarity, any investigator-initiated Clinical Trials.

1.86 "Regulatory Approval" means, with respect to a country or jurisdiction, any and all approvals
(including Marketing Approvals), licenses, registrations or authorizations of any Regulatory
Authority necessary to commercially distribute, sell or market a Product in such country or
jurisdiction, including, where applicable, (a) pricing or reimbursement approval in such country or
jurisdiction, (b) pre- and post-approval marketing authorizations (including any prerequisite
Manufacturing approval or authorization related thereto) and (c) labeling approval.

1.87 "Regulatory Authority" means any applicable Governmental Authority involved in the granting
Regulatory Approvals for the Products or otherwise exercising authority with respect to
biopharmaceutical products in the applicable country or jurisdiction, including the FDA, the EMA,
the PMDA and any corresponding national or regional regulatory authorities.

1.88 "Regulatory Exclusivity" means any rights or protections which are recognized, afforded or
granted by the FDA or any other Regulatory Authority in any country or region of the Territory
pursuant to Applicable Laws of such country or region, in association with the marketing
authorization of the Product, providing the Product[***] a period of marketing exclusivity, during
which a Regulatory Authority recognizing, affording or granting such marketing exclusivity will
refrain from either reviewing or approving a marketing authorization application or similar
regulatory submission, submitted by a Third Party seeking to market a Generic Product of such
Product[***].

1.89 "Regulatory Materials" all (a) applications (including all INDs), registrations, licenses,
authorizations and approvals (including MAAs and Regulatory Approvals), (b) correspondence and
reports submitted to or received from Regulatory Authorities (including minutes and official contact
reports relating to any communications with any Regulatory Authority) and all supporting documents
with respect thereto, including all adverse event files and complaint files, (c) clinical and other
data contained, referenced or otherwise relied upon in any of the foregoing, and (d) for clarity,
any drug master file.

1.90 "Required Phase 4 Studies" means any Phase 4 Studies that are required by the applicable
Regulatory Authority to be conducted as a condition for Regulatory Approval, including Regulatory
Approval for a label expansion, whether or not also required for pricing or reimbursement approval.
13

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 14 -->
1.91 "Research" means all research activities conducted by or on behalf of either Party or the
Parties jointly pursuant to the Research Plan.

1.92 "Research and Development Costs" means all RevMed R&D Costs and Sanofi R&D Costs.

1.93 "Residual Knowledge" means intangible Know-How (but, for the avoidance of doubt, not Patents)
relating to the Collaboration or otherwise to this Agreement or any Ancillary Agreement that has
been retained in the unaided memories of any employees of a Party.

1.94 "RevMed Background Know-How" means, subject to Section 3.1(b), all Know-How that is (a)
Controlled by RevMed or its Affiliates as of the Effective Date or during the Term, excluding the
RevMed Sole Program Know-How and Joint Program Know-How; and (b) necessary or useful for the
Research, Development, Manufacture, Commercialization or other exploitation of any Product in the
Field.

1.95 "RevMed Background Patents" means, subject to Section 3.1(b), any Patent Right (a) (i) that is
Controlled by RevMed or its Affiliates as of the Effective Date; or (ii) that comes into the Control
of RevMed or its Affiliates during the Term, excluding the RevMed Sole Program Patents and Joint
Program Patents; and [***].

1.96 "RevMed Background Technology" means RevMed Background Patents and RevMed Background Know-How.

1.97 "RevMed Licensed Know-How" means RevMed Background Know-How and RevMed Sole Program Know-How.

1.98 "RevMed Licensed Patent" means RevMed Background Patents and RevMed Sole Program Patents.

1.99 "RevMed Licensed Technology" means RevMed Background Technology, RevMed Sole Program Technology
and RevMed's undivided one- half ownership of the full right, title and interest in and to the Joint
Program Technology.

1.100 "RevMed R&D Costs" means RevMed R&D FTE Costs and RevMed R&D Out-Of-Pocket Costs.

1.101 "RevMed R&D FTE Costs" means FTE Costs incurred by or on behalf of RevMed or its Affiliates in
the Research or Development of Product in the Field in accordance with the Research Plan or
Development Plan for such Product, as applicable.

1.102 "RevMed R&D Out-Of-Pocket Costs" means amounts paid by RevMed in cash to Third Parties for
goods and services required in order for RevMed to conduct Research or Development of Product in the
Field in accordance with the Research Plan or Development Plan for such Product, as applicable. 14

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 15 -->
1.103 "RevMed Sole Program Know-How" means all Program Inventions owned solely by RevMed pursuant to
Section 10.1(a).

1.104 "RevMed Sole Program Patents" means any Patent Right covering or claiming the RevMed Sole
Program Know-How.

1.105 "RevMed Sole Program Technology" means RevMed Sole Program Patents and RevMed Sole Program
Know-How.

1.106 "Sanofi R&D Costs" means Sanofi R&D FTE Costs and Sanofi R&D Out-Of-Pocket Costs.

1.107 "Sanofi R&D FTE Costs" means FTE Costs incurred by or on behalf of Sanofi or its Affiliates in
the Research or Development of Product in the Field in accordance with the Research Plan or
Development Plan for such Product, as applicable.

1.108 "Sanofi R&D Out-Of-Pocket Costs" means amount paid by Sanofi in cash to Third Parties for good
and services required in order for Sanofi to conduct Research or Development of Product in the Field
in accordance with the Research Plan or Development Plan for such Product, as applicable.

1.109 "Sanofi Sole Program Know-How" means all Program Inventions owned solely by Sanofi pursuant to
Section 10.1(a).

1.110 "Sanofi Sole Program Patents" means any Patent Right covering or claiming the Sanofi Sole
Program Know-How.

1.111 "SHP1" means [***].

1.112 "SHP1 Inhibitor" means [***].

1.113 "SHP1 Inhibitor Criteria" means [***], as set forth in Exhibit C of the Correspondence.

1.114 "SHP1-SHP2 Dual Inhibitor" means [***].

1.115 "SHP1-SHP2 Dual Inhibitor Product" means any pharmaceutical preparation in final form
containing a SHP1-SHP2 Dual Inhibitor, alone or in combination with one or more additional active
ingredients, for sale by prescription, over-the-counter or any other method.

1.116 "SHP1-SHP2 Dual Inhibitor Criteria" means [***], as set forth in Exhibit D of the
Correspondence.

1.117 "SHP2" means [***].

1.118 "SHP2 Inhibitor Combination Therapy" means [***].

1.119 "SHP2 Inhibitor" means [***]. 15

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 16 -->
1.120 "SHP2 Inhibitor Criteria" means [***], as set forth in Exhibit E of the Correspondence.

1.121 "Study Report" means a written report that contains information required by ICH guidelines
after the Clinical Trial in question is closed but before database lock for such Clinical Trial.

1.122 "Sublicensees" means a Person, other than an Affiliate or a Distributor, that is granted a
sublicense by a Party or its Affiliate under the license grants in this Agreement.

1.123 "Subsidiary" means, with respect to a Party, any corporation or other business entity that,
directly or indirectly, through one or more intermediaries, is controlled by that Party for so long
as such Party controls such corporation or other business entity. For the purpose of this definition
only, "control" (including, with correlative meaning, the terms "controlled by" and "under the
common control") means the actual power of such Party, either directly or indirectly through one or
more intermediaries, to direct or cause the direction of the management and policies of such
corporation or other business entity, whether by the ownership of 50% or more of the voting equity
of such corporation or other business entity, by contract or otherwise.

1.124 "Targeted Anti-Cancer Agent" means, other than an Immuno-Oncology Agent, any molecularly
targeted therapy that blocks the growth of cancer [***]. For clarity, Targeted Anti-Cancer Agent
includes [***].

1.125 "Third Party" means any Person other than a Party or an Affiliate of a Party.

1.126 "Third Party Claims" means all Third Party demands, claims, actions, investigations and
proceedings (whether criminal or civil, in contract, tort or otherwise).

1.127 "Trademark" means any word, name, symbol, color, shape, designation or any combination
thereof, including any trademark, service mark, trade name, brand name, sub-brand name, trade dress,
product configuration, program name, delivery form name, certification mark, collective mark, logo,
tagline, slogan, design or business symbol, that functions as an identifier of source or origin,
whether or not registered and all statutory and common law rights therein and all registrations and
applications therefor, together with all goodwill associated with, or symbolized by, any of the
foregoing.

1.128 "Tumor Type" means a cancer that differs from another type of cancer in [***].

1.129 "United States" or "U.S." means the United States of America, including its territories and
possessions.

1.130 "Valid Claim" means [***]. 16

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 17 -->
1.131 In addition to the foregoing definitions, the following table identifies the location of the
following definitions set forth in various other Sections of, or Exhibits to, the Agreement: Defined
Term Section Acquiror Section 15.2(a) Agreement Preamble Alliance Manager Section 2.1 Applicable
Reduction Percentage Section 9.3(c)(ii) Asset Transfer Section 1.12 Base Net Sales Section
9.3(c)(ii) Closing Conditions Section 13.6 Co-Promotion Agreement Section 8.7(c) Co-Promotion Option
Section 8.7(a) Co-Promotion Product Section 8.7(a) Co-Promotion Territory Section 8.7(a) Combination
Therapy Section 5.3(a) Commercialization Plan Section 8.2 Confidentiality Agreement Section 15.9
CREATE Act Section 10.3 Data Package Section 5.2(c) Development Candidate Section 4.3 Development
Budget Section 5.2(a) Development Plan Section 5.2(a) [***] Section 5.2(b) Disclosing Party Section
11.1(a) Dispute Section 15.6(a) Distributor Section 8.3 Effective Date Section 3.8 Execution Date
Preamble Force Majeure Section 15.1 Indemnification Claim Notice Section 14.3(a) Indemnified Party
Section 14.3(a) Indemnifying Party Section 14.3(a) Indemnitee Section 14.3(a) Initial Know-How
Section 3.7(a) Joint Commercialization Committee or JCC Section 2.4 Joint Research and Development
Committee or JRDC Section 2.3 Joint Steering Committee or JSC Section 2.2 Joint Program Know-How
Section 10.1(a) Know-How Index Section 3.7(a) Launch Quarter Section 9.3(c)(ii) Merger Section 1.12
Milestone Event Section 9.2 Milestone Payment Section 9.2 Non-SHP2 Termination Product Section
12.3(c)(ii)(A) Parent Section 1.12 Party or Parties Preamble Pharmacovigilance Agreement Section 6.5
17

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 18 -->
Defined Term Section Product Infringement Section 10.4(a) Product Marks Section 10.5(a) Profit/Loss
Share Agreement Section 9.4 Quality Agreement Section 7.3 Receiving Party Section 11.1(a) Remainder
Section 10.4(f) Remedial Action Section 6.7 Research Budget Section 4.2(a) Research Plan Section 4.1
[***] Section 4.2(b) RevMed Preamble RevMed Commercialization Costs Section 8.2 RevMed Indemnitee
Section 14.2 RevMed Program Invention Section 12.3(c)(ii) RevMed Study Section 5.6(b) Royalty Floor
Section 9.3(c)(iii) Royalty Term Section 9.3(b) Sanofi Preamble Sanofi Indemnitee Section 14.1
Sanofi Program Invention Section 12.3(c)(ii) Sanofi Prosecuted Patents Section 10.2(a) [***] Section
12.3(c)(ii) [***] Section 12.3(c)(ii) [***] Section 12.3(c)(ii) SHP1-SHP2 Dual Inhibitor License
Rights Section 3.5(a) SHP1-SHP2 Dual Inhibitor Licensing Decision Section 3.5(a) SHP1-SHP2 Dual
Inhibitor Licensing Negotiation Period Section 3.5(a) Stock Sale Section 1.12 Supply Agreement
Section 7.3 Term Section 12.1 Third Party Right Section 10.7(a) Termination Product Section
12.3(c)(ii)(D) Third Party Right Notification Section 10.7(a) VAT Section 9.7(b)

1.132 Interpretation. In this Agreement, unless otherwise specified:

(a) The words "include", "includes" and "including" shall be deemed to be followed by the phrase
"without limitation";

(b) the words "will" and "shall" have the same meaning; 18

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 19 -->
(c) the word "or" shall be interpreted to mean "and/or" unless the context requires otherwise;

(d) words denoting the singular shall include the plural and vice versa and words denoting any
gender shall include all genders;

(e) words such as "herein", "hereof", and "hereunder" refer to this Agreement as a whole and not
merely to the particular provision in which such words appear; and

(f) the Exhibits and other attachments to this Agreement and the Correspondence form part of the
operative provision of this Agreement and references to "this Agreement" shall include references to
such Exhibits and attachments.

Article II.

GOVERNANCE

2.1 Alliance Managers. Each Party hereby appoints the person listed on Exhibit F of the
Correspondence to act as its alliance manager under this Agreement as of the Effective Date (the
"Alliance Manager"). Each Party's Alliance Manager shall: (a) serve as the primary contact point
between the Parties for the purpose of providing the other Party with information on the progress of
such Party's activities under this Agreement; (b) be primarily responsible for facilitating the flow
of information and otherwise promoting communication, coordination and collaboration between the
Parties; and (c) have the right to attend all Committee meetings, all as non-voting members. Without
limiting the foregoing, the Alliance Managers (or their designees) shall be responsible for (i)
scheduling meetings of each Decision-Making Committee; (ii) setting agendas for meetings of each
Decision-Making Committee with solicited input from members of the respective Committee, and (iii)
preparing the draft minutes of such meetings (with such responsibility alternating between the
Alliance Managers), which minutes shall provide a description in reasonable detail of the discussion
held at the meeting and a list of any actions, decisions or determinations approved by the
respective Committee. Each Party may replace its Alliance Manager at any time upon written notice to
the other Party.

2.2 Joint Steering Committee. The Parties hereby establish an executive steering committee (the
"Joint Steering Committee" or the "JSC").

(a) Composition. The JSC shall consist of three senior executives of each Party, with at least one
such senior executive from each such Party holding the position of vice president or above.

(b) Function and Powers. The JSC shall manage the overall Collaboration, and shall in particular:

(i) coordinate the activities of the Parties under this Agreement, including facilitating
communications between the Parties with respect to the Research, Development, Manufacture and
Commercialization of the SHP2 Inhibitors and Products; 19

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 20 -->
(ii) provide a forum for discussion of matters relating to the Research, Development, Manufacture
and Commercialization of the SHP2 Inhibitors and Products presented to the JSC by the other
Committees;

(iii) direct and oversee the operation of the JRDC, JCC, JPC and any other joint subcommittee
established by JSC, including resolving any disputed matter of the JRDC, JCC, JPC and other
subcommittees in accordance with Section 2.10, and promote effective member participation in each
such Committee's or subcommittee's operations;

(iv) approve each Research Plan and Development Plan prepared by the JRDC, and the Research Budget
and Development Budget therein, respectively, and amendments to the foregoing in accordance with
Section 5.2(d);

(v) establish additional subcommittees as appropriate;

(vi) [***]; and

(vii) perform such other duties as are expressly assigned to the JSC in this Agreement, and perform
such other functions as appropriate to further the purposes of this Agreement as may be allocated to
it by the Parties' written agreement, except where in conflict with any provision of this Agreement.

2.3 Joint Research and Development Committee. The Parties hereby establish a joint research
committee (the "Joint Research and Development Committee" or the "JRDC").

(a) Composition. The JRDC shall consist of three representatives of each Party that have knowledge
and expertise in the Research and Development of pharmaceutical or biologic products in the Field.

(b) Function and Powers. The JRDC shall have the following responsibilities:

(i) prepare each Research Plan and Development Plan, and the Research Budget and Development Budget
therein, respectively, and amendments to the foregoing in accordance with Section 5.2(d);

(ii) oversee the implementation of each Research Plan and Development Plan;

(iii) monitor, coordinate and evaluate the activities and performance of the Parties under each
Research Plan and Development Plan[***];

(iv) following completion of early Development activities for a Product, determine whether to
further develop such Product for Regulatory Approval;

(v) if the JRDC determines to further Develop a Product for Regulatory Approval, develop the Data
Package for such Product in accordance with Section 5.2(c);

(vi) provide a forum for and facilitate communications between the Parties with respect to the
Research and Development of the SHP2 Inhibitors and Products; 20

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 21 -->
(vii) review and approve a format for the expense reports to be provided by RevMed to Sanofi
pursuant to Section 4.5 and Section 5.5;

(viii) monitor and coordinate all regulatory actions, communications and submissions for the SHP2
Inhibitors and Products allocated to each Party under the Development Plans;

(ix) oversee and coordinate the Manufacturing of the SHP2 Inhibitors and Products for clinical
supply in accordance with Article VII, unless the JSC designates a manufacturing committee or
subcommittee to perform such activities;

(x) establish other subcommittees, as appropriate, to carry out its functions; and

(xi) perform such other functions as determined by the JSC to further the purposes of this Agreement
with respect to the Research and Development of SHP2 Inhibitors and Products, except where in
conflict with any provision of this Agreement.

(c) Decision-Making. Notwithstanding anything to the contrary in Section 2.10(a), if the JRDC is
unable to reach unanimous agreement on the following matters then such matters shall not be
submitted for resolution to the JSC and shall instead be subject to Sanofi's final decision-making
power: [***].

2.4 Joint Commercialization Committee. The Parties shall establish a joint commercialization
committee (the "Joint Commercialization Committee" or "JCC") no later than the date that is [***]
prior to the anticipated submission of the first NDA for the first Product.

(a) Composition. The JCC shall consist of three representatives of each Party that have knowledge
and expertise in the commercialization of pharmaceutical or biologic products in the Field.

(b) Function and Powers. The JCC shall monitor and oversee the Commercialization activities (and
certain Manufacturing activities as provided hereunder) of the SHP2 Inhibitors and Products and in
particular have the following responsibilities:

(i) coordinate the messaging and branding strategy for Products in the United States;

(ii) coordinate the activities of the Parties under the Commercialization Plan and oversee the
implementation of the Commercialization Plan;

(iii) if the Co-Promotion Option has been exercised, coordinate the activities of the Parties under
the applicable Co-Promotion Agreement and oversee the implementation of such Co-Promotion Agreement;

(iv) review and discuss the Commercialization Plans and amendments thereto in accordance with
Section 8.2; 21

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 22 -->
(v) provide a forum for and facilitate communications between the Parties with respect to the
Commercialization of the Products in the United States;

(vi) oversee and coordinate the Manufacturing of the SHP2 Inhibitors and Products for commercial
supply in the United States in accordance with Article VII, unless the JSC designates a
manufacturing committee or subcommittee to perform such activities;

(vii) establish subcommittees, as appropriate, to carry out its functions; and

(viii) perform such other functions as determined by the JSC to further the purposes of this
Agreement with respect to the Commercialization of the Products, except where in conflict with any
provision of this Agreement.

2.5 Joint Patent Committee. The Parties shall establish a joint patent committee ("Joint Patent
Committee" or "JPC").

(a) Composition. The JPC shall be composed of one patent counsel representing Sanofi, one patent
counsel representing RevMed, (who may be internal or outside counsel to RevMed), and up to two
additional representatives of each Party that have knowledge and expertise in patent prosecution of
pharmaceutical or biologic products.

(b) No Power or Authority; Function. The JPC shall not have any power or authority (including
decision making) with respect to Collaboration matters. Rather, the JPC shall serve as an
information-sharing forum for the Parties with respect to the following:

(i) the filing, prosecution, and maintenance of the RevMed Licensed Patents and Joint Program
Patents, including deadlines for responses to patent authorities and Sanofi's proposed timelines for
submission of comments to patent authorities;

(ii) any periodic reports or updates for Collaboration-related intellectual property matters as may
be requested by the JRDC;

(iii) strategy for patent term extensions to extend exclusivity in the Licensed Territory and for
listings in the FDA's Approved Drug Products with Therapeutic Equivalence Evaluations (known as the
"Orange Book") and its foreign counterparts;

(iv) confer regarding any related information to ensure the Parties' compliance with the 37 C.F.R.
1.56 duty of disclosure as it relates to SHP2 Inhibitors or SHP2 inhibition; and

(v) such other intellectual property-related matters as determined by the JSC to further the
purposes of this Agreement, except where in conflict with any provision of this Agreement.

2.6 Joint Manufacturing Committee. The Parties shall establish a joint manufacturing committee
("Joint Manufacturing Committee" or "JMC"). 22

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 23 -->
(a) Composition. The JMC shall consist of three representatives of each Party that have knowledge
and expertise in the manufacture or supply management of pharmaceutical or biologic products in the
Field.

(b) No Power or Authority; Function. The JMC shall not have any power or authority (including
decision making) with respect to Collaboration matters. Rather, the JMC shall serve as an
information-sharing forum for the Parties with respect to the following:

(i) transfer of the Manufacturing Know-How in accordance with Section 7.2 hereof;

(ii) periodic reports or updates for Collaboration-related Manufacturing matters as may be requested
by the JSC;

(iii) logistical strategies, capacity planning and inventory levels for each Product for consistency
with the then-current Development Plans and Commercialization Plans for such Product;

(iv) results of regulatory inspections related to Products and steps taken by the concerned Party to
address any Manufacturing deficiencies noted;

(v) such other functions as may be agreed upon by the Parties to further the purposes of this
Agreement, except where in conflict with any provision of this Agreement.

2.7 Limitation of Committee Authority. Each Committee shall only have the powers expressly assigned
to it in this Article II and elsewhere in this Agreement and shall not have the authority to: (a)
modify or amend the terms and conditions of this Agreement; (b) waive either Party's compliance with
the terms and conditions of this Agreement; or (c) determine any issue in a manner that would
conflict with the express terms and conditions of this Agreement.

2.8 Committee Membership and Meetings.

(a) Committee Members. The initial members of each Party on each Committee (other than the JCC) as
of the Effective Date are set forth in Exhibit F of the Correspondence. Each Party may replace its
representatives on any Committee by written notice to the other Party. Each Committee representative
shall have appropriate knowledge and expertise and sufficient seniority within the applicable Party
to make decisions arising within the scope of the applicable Committee's responsibilities. A
particular individual may serve as a Party's representative on more than one Committee, provided
that such individual satisfies the requirements of the preceding sentence for each applicable
Committee. Each Party shall appoint one of its representatives on each Committee to act as a
co-chairperson of such Committee. The Alliance Managers shall be responsible for calling any
regularly scheduled meetings for each Decision-Making Committee on no less than [***] notice and
shall also jointly prepare and circulate agendas for each Decision-Making Committee meeting no less
than [***] prior to such meeting. In addition, members of each Decision-Making Committee may request
that the Alliance Managers schedule and facilitate ad hoc meetings. The Alliance Managers shall
jointly prepare and circulate reasonably detailed minutes for each Decision-Making Committee meeting
within [***] of such meeting. For the avoidance of doubt, meetings of the JPC shall not require any
formal agenda or preparation or circulation of any minutes unless otherwise agreed by the Parties.
23

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 24 -->
(b) Meetings.

(i) Decision-Making Committees. Each Decision-Making Committee shall meet in accordance with a
schedule established by mutual written agreement of both Parties, but no less frequently than [***].
Meetings of any Decision-Making Committee will be held in person, at locations to be alternately
selected by each Party, with [***] deciding the location for the first such meeting of each
Decision-Making Committee. Alternatively, each Decision-Making Committee may meet by means of
teleconference, videoconference, or other similar communications equipment; provided, however, to
the extent practicable at least [***] meetings of each Decision-Making Committee per [***] should be
conducted in-person. A meeting shall be deemed to be "in-person" as long as one representative of
each Party is participating in person; for clarity, other representatives of such Party may
participate remotely during an "in person" meeting as provided under this subsection. Each Party
shall be responsible for all of its own expenses of participating in any Decision-Making Committee.
No action taken at any meeting of a Decision-Making Committee shall be effective unless at least one
representative of each Party is participating.

(ii) JPC and JMC. The JPC and JMC shall hold meetings as agreed upon by both Parties but in no event
less frequently than [***]. Meetings of the JPC and JMC will be held by telephone, video conference
or similar means in which each participant can hear what is said by, and be heard by, the other
participants, unless the Parties agree to meet in person.

(c) Non-Member Attendance. Each Party may from time to time invite a reasonable number of
participants, in addition to its representatives, to attend the Committee meetings in a non-voting
capacity; provided that if either Party intends to have any Third Party (including any consultant)
attend such a meeting, such Party shall provide prior written notice to the other Party and shall
ensure that such Third Party is bound by confidentiality and non-use obligations consistent with the
terms of this Agreement.

2.9 Continuity of Representation. Notwithstanding the Parties' respective rights to replace its
Alliance Manager and members of Committees by written notification to the other Party, each Party
shall strive to maintain continuity in the representation of such Alliance Manager and Committee
members.

2.10 Decision-Making.

(a) All decisions of each Decision-Making Committee shall be made by unanimous vote, with each
Party's representatives collectively having one vote (such vote to be cast by the Party's co-chair
to the extent such Party's representatives do not unanimously agree on a decision). If after
reasonable discussion and good faith consideration of each Party's view on a particular matter
before a Decision-Making Committee, the representatives of the Parties cannot reach an agreement as
to such matter within [***] after such matter was brought to such Decision-Making 24

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 25 -->
Committee for resolution or after such matter has been referred to such Decision-Making Committee,
such disagreement shall, upon the written request of either Party, be referred to the JSC (in the
case of disagreement of the JRDC, JCC or subcommittees of the JSC), or the Designated Senior
Officers (in the case of disagreement of the JSC) for resolution, in each case, to discuss such
matter in good faith for resolution. If the Designated Senior Officers cannot resolve any matter
referred to them by the JSC within [***] after such matter has been referred to them, then such
matters shall be finally and definitively resolved as set forth in Section 2.10(b) or otherwise by
consensus. The Parties may by mutual written agreement determine to shorten the timeframes specified
above in this Section 2.10. If any decision-making authority assigned to any Committee necessarily
extends beyond the term of such Committee as set forth in Section 2.11, then such decision making
authority shall be automatically transferred to Sanofi.

(b) For any matters submitted for resolution by the Designated Senior Officers, the Designated
Senior Officer of Sanofi shall have final decision- making power with respect to such matter;
provided that the Designated Senior Officer of Sanofi shall not have the right to exercise its final
decision- making authority without RevMed's consent to:

(i) [***]

(ii) [***]

(iii) [***] or

(iv) [***]. Notwithstanding anything to the contrary in this Agreement, except as expressly set
forth in Section 4.2(a)(i)(A) and, if applicable, Section 4.2(a)(i)(B), [***]:

A. Sanofi cannot without cause exercise such final decision-making authority to [***] from one of
its assigned activities under the applicable Research Plan or Development Plan and [***] similar
activity;

B. for any proposal to [***], the JRDC shall first use good faith efforts to [***], a pending
amendment thereto or as otherwise determined by the JRDC, that [***]; and

C. if [***] does not occur and if Sanofi [***] by [***] without RevMed's consent, then [***] for a
period of [***] in which such [***], provided that RevMed shall use good faith efforts to [***]
during [***], and provided further that Sanofi shall not be required to make any such [***] during
[***]. Without limiting the foregoing, Sanofi shall be deemed to have cause to [***], for example,
in the case of [***].

2.11 Discontinuation of Committees. The activities to be performed by each Committee shall solely
relate to governance under this Agreement, and are not intended to be or involve the delivery of
services. Each Committee shall continue to exist until the Parties mutually agree to disband such
Committee, or if RevMed provides Sanofi with written notification of its decision to discontinue its
participation in such Committee; provided that (a) the JPC shall disband upon [***], (b) the JCC
shall disband if [***]; (c) the JRDC shall disband upon [***]; and (d) the JMC shall disband upon
[***]. If a Committee is so disbanded, such Committee shall have no further obligations under this
Agreement and, thereafter, the Alliance Managers shall be the contact persons for the exchange of
information under this Agreement and decisions of such 25

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 26 -->
Committee shall be decisions of Sanofi. Upon disbandment of the JRDC, JCC, JPC or JMC or at any time
in the JSC's discretion, the JSC may assume from the JRDC, JCC, JPC or JMC any and all of such
Committees' respective responsibilities. Notwithstanding anything to the contrary in Section
2.8(b)(i), following substantial completion of RevMed's activities under the Research Plan and
Development Plan, the JRDC shall meet no less frequently than [***], provided that there are bona
fide agenda items for such meetings. If RevMed undergoes a Change of Control following substantial
completion of RevMed's activities under the Research Plan and Development Plan, [***] may, in its
sole discretion, [***]. The JSC shall disband if all other Committees have disbanded.

Article III.

LICENSE

3.1 Licenses and Option to Sanofi.

Licenses. Subject to the terms and conditions of this Agreement, RevMed hereby grants to Sanofi an
exclusive (even as to RevMed and its Affiliates), royalty-bearing license (which shall be
sub-licensable solely as provided in Section 3.4) under the RevMed Licensed Technology, to Research,
Develop, Manufacture, use, sell, offer for sale, import and otherwise Commercialize and exploit
Products (including, for clarity, any Companion Diagnostics with respect to such Products) in the
Field in the Licensed Territory.

(a) Option.

(i) Option. Subject to the terms and conditions of this Agreement, RevMed hereby grants to Sanofi an
exclusive option, under the Patent Rights and Know-How claiming or embodied in the [***].

(ii) Exercise. Sanofi may exercise its Option at any time during the Term by providing RevMed with
written notice of such exercise. During the Term prior to the Option exercise by Sanofi, RevMed
shall provide to Sanofi any additional information Controlled by RevMed that is reasonably requested
by Sanofi in order to assist Sanofi in determining whether to exercise its Option. If Sanofi so
exercises its Option pursuant to this Section 3.1(b)(ii), [***]. Upon Sanofi's exercise of the
Option, [***] accordingly subject to the license granted to Sanofi under Section 3.1(a) and the
payment obligations therefor pursuant to this Agreement.

3.2 License to RevMed. Subject to the terms and conditions of this Agreement, Sanofi hereby grants
to RevMed a non-exclusive, royalty-free sublicense (which shall only be further sub-licensable (a)
to RevMed's Subsidiaries, (b) to the Permitted Contractors or Researchers, and (c) solely with
Sanofi's prior written consent, such consent not to be unreasonably withheld, delayed or
conditioned, to Third Parties who are not Permitted Contractors or Researchers) under the rights
exclusively licensed to Sanofi pursuant to Section 3.1, solely to the extent necessary for RevMed to
perform its obligations under this Agreement and the Ancillary Agreements.

3.3 Retained Rights; Residuals. RevMed hereby retains subject to Section 3.5(b), all rights in and
to the RevMed Licensed Technology other than the rights expressly licensed to Sanofi thereunder
pursuant to Section 3.1. Notwithstanding the foregoing, each Party shall have the right to use
[***]. Notwithstanding anything to the contrary in this Agreement, nothing shall [***]. 26

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 27 -->
3.4 Sublicense and Subcontracting Rights. Subject to the terms and conditions of this Agreement:

(a) Subject to Section 3.4(c) below, Sanofi may exercise its rights and perform its obligations
under this Agreement by itself or through the engagement of any of its Affiliates without RevMed's
consent. For the avoidance of doubt, RevMed shall not have any responsibility for any taxes relating
to or arising out of the engagement of Sanofi's Affiliates or Sanofi's use of subcontractors, except
for any taxes to the extent that RevMed would have incurred such taxes even in the absence of such
engagement of Sanofi's Affiliates or Sanofi's use of subcontractors.

(b) Sanofi shall have the right to grant sublicenses (through multiple tiers) under the rights
granted to it under Section 3.1 to one or more Third Parties (i) outside of the United States, and
(ii) in the United States; provided that for purposes of subsection (ii), Sanofi shall not
sublicense substantially all of the rights granted to it under Section 3.1 in the United States to
Third Parties without RevMed's prior written consent, such consent not to be unreasonably withheld,
delayed or conditioned.

(c) Subject to the remainder of this Section 3.4(c), (i) Sanofi may subcontract to Third Parties the
performance of Sanofi's tasks and obligations with respect to the Research, Development, Manufacture
and Commercialization of any Product as Sanofi deems appropriate (ii) RevMed may subcontract to the
Permitted Contractors or Researchers listed on Exhibit B of the Correspondence as of the Effective
Date the performance of RevMed's tasks and obligations with respect to the Research, Development,
Manufacture and Commercialization of any Product, and (iii) RevMed shall not, without the prior
written approval of Sanofi, otherwise subcontract to Third Parties the performance of RevMed's tasks
and obligations with respect to the Research, Development, Manufacture and Commercialization of any
Product. If Sanofi approves a Third Party subcontractor of RevMed following the Effective Date, or
such Third Party is named in the Research Plan or the Development Plan, then RevMed, unless
otherwise explicitly waived by the Sanofi Alliance Manager, shall enter into a written agreement
with such Third Party substantially in a form approved by Sanofi and such Third Party shall be
deemed a Permitted Subcontractor or Researcher under this Agreement. Each Party shall remain liable
for any action or failure to act by its Affiliates, Sublicensees or subcontractors to whom such
Party's obligations under this Agreement have been delegated, subcontracted or sublicensed and which
action or failure to act would constitute a breach of this Agreement if such action or failure to
act were committed by such Party. Such Party shall require that such Affiliates, Sublicensees and
subcontractors agree in writing to comply with the applicable terms and conditions of this
Agreement. Without limiting the foregoing, if a Party first engages a subcontractor after the
Effective Date to perform any activities assigned to it under this Agreement, such Party shall
require that such subcontractor be bound by written obligations of confidentiality and non-use
consistent with this Agreement and shall have agreed to assign to the Party engaging such
subcontractor (or, if an assignment cannot be made, grant an irrevocable, perpetual, fully-paid,
exclusive, royalty-free, worldwide license to such Party, with the right to sublicense through
multiple tiers, to Research, Develop, Manufacture, Commercialize and otherwise exploit SHP2
Inhibitors and Products) under all Program Inventions made by such subcontractor in the course of
performing such subcontracted work that relate to any Products or their use, manufacture or sale. 27

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 28 -->
3.5 SHP1-SHP2 Dual Inhibitors.

(a) Except pursuant to or as expressly permitted by this Agreement, RevMed shall not, shall cause
its Affiliates not to, conduct or agree to conduct, outside of the Collaboration, on its own or
together with one or more Third Parties, the Research, Development or Commercialization of any
product that contains a SHP2 Inhibitor, including any SHP1-SHP2 Dual Inhibitor that [***]. For
purposes of this Section, [***].

(b) If [***] (such determination, the "SHP1-SHP2 Dual Inhibitor Licensing Decision" and such Third
Party's rights, the "SHP1-SHP2 Dual Inhibitor License Rights"), then prior to commencing any
negotiations with any Third Party with regard to any SHP1-SHP2 Dual Inhibitor License Rights, RevMed
shall promptly notify Sanofi in writing of such SHP1-SHP2 Dual Inhibitor Licensing Decision and
provide to Sanofi a detailed summary of the data then in RevMed's Control regarding the relevant
SHP1-SHP2 Dual Inhibitor. Sanofi shall notify RevMed in writing (a "Notice of Interest"), within
[***] after Sanofi's receipt of such notice, if Sanofi desires to enter into negotiations with
RevMed of the terms under which Sanofi would obtain SHP1-SHP2 Dual Inhibitor License Rights. If
Sanofi provides a Notice of Interest to RevMed within [***], then (i) RevMed shall, upon request of
Sanofi, provide Sanofi with reasonable access to all other then-existing Know-How in RevMed's
Control that exists in either paper or electronic form and pertains to the relevant SHP1-SHP2 Dual
Inhibitor and (ii) the Parties shall negotiate exclusively in good faith and on a commercially
reasonable basis the terms of a definitive agreement under which Sanofi would be granted SHP1-SHP2
Dual Inhibitor License Rights for [***] after RevMed receives such Notice of Interest (such period,
the "SHP1-SHP2 Dual Inhibitor Licensing Negotiation Period"). If Sanofi provides such Notice of
Interest during [***], then RevMed shall not negotiate with any Third Party the terms under which
such Third Party would obtain any development or commercialization rights with respect to a
SHP1-SHP2 Dual Inhibitor during the SHP1-SHP2 Dual Inhibitor Licensing Negotiation Period. If (x)
Sanofi does not provide a Notice of Interest within [***] or (y) Sanofi does provide a Notice of
Interest within [***] but Parties have not entered into an agreement under which Sanofi is granted
SHP1-SHP2 Dual Inhibitor License Rights prior to the expiration of the SHP1-SHP2 Dual Inhibitor
Licensing Negotiation Period, then RevMed shall have no further obligations to Sanofi with respect
to such SHP1-SHP2 Dual Inhibitor Products, and RevMed shall have the right to enter into
negotiations and execute an agreement with a Third Party under which such Third Party is granted the
SHP1-SHP2 Dual Inhibitor License Rights [***]. For clarity, the Parties' rights and obligations
under this Section 3.5(b) shall apply one time only, upon the occurrence of the first SHP1-SHP2 Dual
Inhibitor Licensing Decision.

3.6 No Implied Licenses. Except as expressly set forth herein, neither Party shall acquire any
license or other intellectual property interest, by implication or otherwise, under or to any
trademarks, Patents, Know-How, or other intellectual property rights Controlled by the other Party.
For clarity, any exclusive license granted to each Party under any particular Patent Rights or
Know-How Controlled by the other Party shall confer exclusivity to the Party obtaining such license
only to the extent the Party granting such license Controls the exclusive rights to such Patent
Rights or Know-How. 28

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 29 -->
3.7 Technology Transfers.

(a) Initial. As of the Effective Date RevMed shall have included in the electronic dataroom for this
Agreement: (i) all Know-How in its Control that is necessary or useful to the Research, Development,
Manufacture, Commercialization or other exploitation of the Development Candidate on Exhibit I of
the Correspondence that currently exists in either paper or electronic form (the "Initial Know-How")
and (ii) a complete, accurate and detailed index of all other SHP2 Inhibitors which RevMed, as of
the Effective Date, has made or had made and all related Know-How in RevMed's Control, which
consists of the data regarding the structure and biochemical and other characteristics of such SHP2
Inhibitors that currently exists in RevMed's database(s) (the "Index").

(b) Ongoing. Following the Effective Date, RevMed shall disclose to the JRDC on a [***] basis all
RevMed Licensed Know-How created, generated, invented or developed by or on behalf of RevMed under
the Collaboration. In addition, upon Sanofi's reasonable written request, RevMed shall deliver to
Sanofi updates to the Index, and related RevMed Licensed Know-How, including the data regarding the
structure and biochemical and other characteristics of such SHP2 Inhibitors that then exists in
RevMed's database(s).

(c) Breach of Section 3.7(a) or 3.7(b) by RevMed. Notwithstanding anything to the contrary in
Section 12.2(b), in the event Sanofi believes RevMed has materially breached Section 3.7(a) or
3.7(b), Sanofi shall so notify RevMed in writing. RevMed may, within [***] following receipt of such
notice from Sanofi, request that [***].

3.8 Government Approvals.

(a) Efforts. Each of RevMed and Sanofi will use its commercially reasonable good faith efforts to
remove promptly any and all impediments to consummation of the transaction contemplated by this
Agreement, including obtaining government antitrust clearance, cooperating in good faith with any
Governmental Authority investigation, promptly producing any documents and information and providing
witness testimony if requested by a Governmental Authority. Notwithstanding anything to the contrary
in this Agreement, this Section 3.8 and the term "commercially reasonable good faith efforts" do not
require that either Party (i) offer, negotiate, commit to or effect, by consent decree, hold
separate order, trust or otherwise, the sale, divestiture, license or other disposition of any
capital stock, assets, rights, products or businesses of RevMed or Sanofi or its Affiliates, (ii)
agree to any restrictions on the businesses of RevMed or Sanofi or its Affiliates, or (iii) pay any
amount or take any other action to prevent, effect the dissolution of, vacate, or lift any decree,
order, judgment, injunction, temporary restraining order, or other order in any suit or proceeding
that would otherwise have the effect of preventing or delaying the transaction contemplated by this
Agreement (collectively, an "Antitrust Remedy"), where such Antitrust Remedy would represent a
Material Adverse Event for RevMed or Sanofi.

(b) HSR/Antitrust Filings. Each of RevMed and Sanofi will, within [***] after the execution of the
Agreement (or such later time as may be agreed to in writing by the Parties) file with the U.S.
Federal Trade Commission ("FTC") and the Antitrust Division of the U.S. Department of Justice
("DOJ") any HSR/Antitrust Filing required of it under the HSR Act and, as soon as practicable, file
with the appropriate Governmental Authority any other 29

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 30 -->
HSR/Antitrust Filing required of it under any other Antitrust Law as determined in the reasonable
opinion of either Party with respect to the transactions contemplated by the Agreement and Ancillary
Agreements. The Parties shall cooperate with one another to the extent necessary in the preparation
of any such HSR/Antitrust Filing. Each Party shall be responsible for its own costs, expenses, and
filing fees associated with any HSR/Antitrust Filing; provided, however, that Sanofi shall bear
solely all fees (other than penalties that may be incurred as a result of actions or omissions on
the part of a Party, which penalties shall be the sole financial responsibility of such Party),
required to be paid to any Governmental Authority in connection with making any such HSR/Antitrust
Filing. In the event that the Parties make an HSR/Antitrust Filing under this Section 3.8, this
Agreement shall terminate (i) at the election of either Party, immediately upon notice to the other
Party, in the event that the FTC, DOJ or other Governmental Authority obtains a preliminary
injunction or final order under Antitrust Law enjoining the transactions contemplated by the
Agreement, or (ii) at the election of either Party, immediately upon notice to the other Party, in
the event that the Antitrust Clearance Date shall not have occurred on or prior to [***] after the
date upon which a HSR/Antitrust Filing has been submitted by each Party to a Governmental Authority
in relation to the Agreement. Notwithstanding anything to the contrary contained herein, except for
the terms and conditions of this Section 3.8, none of the terms and conditions contained in this
Agreement shall be effective until the "Effective Date," which is agreed and understood to mean,
subject to the Closing Conditions having been fulfilled or waived in accordance with Section 13.6,
the later of (A) if a determination is made pursuant to this Section 3.8 that an HSR/Antitrust
Filing is not required to be made under any Antitrust Law for this Agreement, the date of such
determination, or (B) if a determination is made pursuant to this Section 3.8 that an HSR/Antitrust
Filing is required to be made under any Antitrust Law for this Agreement, the Antitrust Clearance
Date. As used herein: (1) "Antitrust Clearance Date" means the earliest date on which the Parties
have actual knowledge that all applicable waiting periods under the HSR Act and any comparable
waiting periods as required under any other Antitrust Law, in each case with respect to the
transaction contemplated by this Agreement have expired or have been terminated; and (2)
"HSR/Antitrust Filing" means (x) a filing by RevMed and a filing by Sanofi with the FTC and the DOJ
of a Notification and Report Form for Certain Mergers and Acquisitions (as that term is defined in
the HSR Act), together with all required documentary attachments thereto or (y) any comparable
filing by RevMed or Sanofi required under any other Antitrust Law, in each case ((x) and (y)) with
respect to the transaction contemplated by this Agreement.

(c) Information Exchange. Each of RevMed and Sanofi will, in connection with any HSR/Antitrust
Filing, (i) reasonably cooperate with each other in connection with any communication, filing or
submission and in connection with any investigation or other inquiry, including any proceeding
initiated by a private party; (ii) keep the other Party and/or its counsel informed of any
communication received by such Party from, or given by such Party to, the FTC, the DOJ or any other
U.S. or other Governmental Authority and of any communication received or given in connection with
any proceeding by a private party, in each case regarding the transaction contemplated by this
Agreement; (iii) consult with each other in advance of any meeting or conference with the FTC, the
DOJ or any other Governmental Authority or, in connection with any proceeding by a private party,
with any other Person, and to the extent permitted by the FTC, the DOJ or such other Governmental
Authority or other Person, give the Parties and/or their counsel the opportunity to attend and
participate in such meetings and conferences; and (iv) to the extent practicable, permit the other
Party and/or its counsel to review in advance any submission, filing or communication (and documents
submitted therewith) 30

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 31 -->
intended to be given by it to the FTC, the DOJ or any other Governmental Authority; provided, that
materials may be redacted to remove references concerning the valuation of the business of the
disclosing Party or other sensitive information in the judgment of such disclosing Party. RevMed and
Sanofi, as each deems advisable and necessary, may reasonably designate any competitively sensitive
material to be provided to the other under this Section 3.8 as "Antitrust Counsel Only Material."
Such materials and the information contained therein shall be given only to the outside antitrust
counsel of the recipient and will not be disclosed by such outside counsel to employees, officers or
directors of the recipient unless express permission is obtained in advance from the source of the
materials (RevMed or Sanofi, as the case may be) or its legal counsel.

Article IV.

RESEARCH

4.1 General. Subject to the terms and conditions of this Agreement, the Parties will conduct a
research program for the identification, validation and optimization of SHP2 Inhibitors (including
without limitation back-up compound chemistry and characterization, pre-clinical studies, and
translation and biomarker studies) pursuant to a research plan (such plan, the "Research Plan").

4.2 Research Plan.

(a) Research Plan and Budget.

(i) Initial. As of the Effective Date, the Parties have agreed on an initial Research Plan and
Research Budget for Calendar Years 2018, 2019 and 2020, which is set forth in Exhibit H of the
Correspondence.

A. Calendar Year 2018. The initial Research Plan and Research Budget for Calendar Year 2018 are
final and may only be amended or modified by mutual agreement of the Parties (i.e., Sanofi shall not
have the unilateral right, either directly or through its participation in the JRDC or the JSC,
including by exercising its final decision-making power under Section 2.10(b), [***]).

B. Calendar Years 2019 and 2020. The initial Research Budget for Calendar Years 2019 and 2020
included in Exhibit H of the Correspondence represents, as of the Effective Date, what the Parties
believe to be a reasonable estimate of the Research Budget for Calendar Years 2019 and 2020 and
shall become final only if the Parties mutually agree in writing with respect to the detailed
Research activities and timelines to be set forth in the Research Plan for Calendar Years 2019 and
2020. Upon any such mutual agreement, such Research Plan and Research Budget may only be amended or
modified by mutual agreement of the Parties (i.e., Sanofi shall not have the right to exercise its
final decision-making power under Section 2.10(b), [***]. If the Parties do not reach such mutual
agreement and Sanofi exercises its final decision-making power under Section 2.10(b) [***]. For
clarity, if the Parties mutually agree upon activities under the Research Plan for a Research Budget
equal to or greater than that set forth in Exhibit H of the Correspondence then Section 4.5(b) shall
apply and Sanofi shall be responsible for 80% of the Research and Development Costs and RevMed shall
be responsible for 20% of the Research and Development Costs, provided that Sanofi shall be
responsible for [***]% of the Research and Development Costs associated with [***]. 31

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 32 -->
C. Calendar Year 2021 and Beyond. The Research Plan and Research Budget for Calendar Year 2021 and
any Calendar Year after 2021 shall be subject in all respects to the governance set forth in Article
II (including Sanofi's final decision-making power under Section 2.10(b) and the procedure for
amendments set forth in Section 4.2(a)(ii)).

(ii) Amendments. From time to time after the Effective Date, the JRDC may propose any amendment to
the Research Plan, which shall be made in good faith, based on scientific and regulatory judgment.
The Research Plan shall set forth: (a) the Research activities to be conducted by either Party; (b)
the estimated timelines for such Research activities; and (c) a detailed budget setting forth the
estimated RevMed R&D Costs to be incurred in connection with such activities (the "Research
Budget"). If the terms of the Research Plan contradict, or create inconsistencies or ambiguities
with, the terms of this Agreement, then the terms of this Agreement shall govern.

(b) Conduct of Research. Each Party shall perform all Research activities under this Agreement in
compliance with all Applicable Law (including GMP, GLP and GCP). In furtherance and not in
limitation of the foregoing, RevMed shall use diligent efforts to conduct its activities under each
Research Plan in accordance with the terms of such Research Plan (including timelines), as the same
may be amended from time to time (and which basis for comparison shall be tolled until any
then-contemplated or pending amendments are completed or for the duration of any bona fide dispute
between the Parties with respect to a Research Plan or amendment thereto), and this Agreement. If
Sanofi believes RevMed has materially breached its obligation in the foregoing sentences with
respect to any Product, Sanofi shall so notify RevMed in writing. If either RevMed agrees or it is
determined in accordance with [***], that RevMed has committed a material breach of its obligations
under this Section 4.2(b) with respect to such Product, the JRDC shall, within [***] after such
agreement on or determination of material breach, meet in person or by teleconference to discuss
such material breach and specify reasonable actions that RevMed should take to cure such material
breach. If RevMed fails to commence within [***] after such discussion occurs such actions
recommended by the JRDC, or fails to cure any such material breach within [***] after the JRDC meets
(or such longer timeframe as the JRDC decides is necessary to complete the actions specified by the
JRDC), then Sanofi shall have the right, without prejudice to any other rights or remedies Sanofi
may have under this Agreement or otherwise at law or in equity, [***]. In such case, RevMed shall,
[***], (i) make available [***], (ii) provide [***], and (iii) otherwise provide [***].

4.3 Designation of Development Candidates As of the Effective Date, the Parties agree that the SHP2
Inhibitor set forth on Exhibit I of the Correspondence is deemed a Development Candidate (defined
below) under this Agreement. From time to time, either Party may nominate one or more additional
SHP2 Inhibitors to the JRDC for consideration as a candidate for Development under a Development
Plan (the "Development Candidate"). Such nomination (and approval thereof by the JRDC) shall be made
prior to the initiation of the IND-enabling studies for such SHP2 Inhibitor(s), unless otherwise
permitted by the JRDC. Promptly after such nomination, each Party shall present to the JRDC the data
and results it has obtained with respect to such SHP2 Inhibitor(s) as well as, if requested by the
other Party, written records maintained 32

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 33 -->
by or on behalf of such Party or its Affiliates with respect to the discovery or development history
of such SHP2 Inhibitor. The JRDC shall determine whether such SHP2 Inhibitor(s) shall be approved as
a Development Candidate under this Agreement. The JRDC may also request that further Research
activities be conducted with respect to such SHP2 Inhibitor(s) (under an amended Research Plan),
after which activities such SHP2 Inhibitor(s) may be reconsidered for nomination as a Development
Candidate. If the JRDC (or Designated Senior Officers, as applicable) approve a particular SHP2
Inhibitor as a Development Candidate, then the Parties shall proceed to conduct further Development
of such SHP2 Inhibitor (including IND-enabling studies, other pre-clinical and non-clinical studies,
and clinical studies) pursuant to a Development Plan (as further described in Section 5.2) and under
the oversight of the JRDC. In addition, at any time after a SHP2 Inhibitor is designated as a
Development Candidate, if requested by Sanofi, RevMed shall make available written records (such as
lab notebooks) maintained by or on behalf of RevMed or its Affiliates with respect to the discovery
and/or development history of such SHP2 Inhibitor or any Product under Development that contains
such SHP2 Inhibitor, provided that such request shall not be made more than once for each SHP2
Inhibitor or each Product, as applicable, except for cause.

4.4 Research Records and Reports. Each Party shall maintain complete, current and accurate records
of all Research activities conducted by it hereunder, and all data and other information resulting
from such activities. Such records shall fully and properly reflect all work done and results
achieved in the performance of the Research activities in good scientific manner appropriate for
regulatory and patent purposes. Each Party shall keep the other Party reasonably informed as to its
progress in the conduct of the Research activities through meetings of the JRDC. Upon written
request from the JRDC, each Party shall submit to the JRDC a written summary (in slide format unless
otherwise agreed by the Parties) of its Research activities since its prior report.

4.5 Research Costs.

(a) Calendar Years 2018, 2021 and All Calendar Years After 2021. Sanofi shall be responsible for
100% of the Research and Development Costs for Calendar Years 2018, 2021 and all Calendar Years
after 2021. Sanofi will reimburse RevMed for any RevMed R&D Costs incurred by or on behalf of RevMed
after the Execution Date in the performance of its activities under the Research Plan, provided that
such RevMed R&D Costs are incurred per the Research Budget for such activities as approved by the
JSC and [***] set forth in the Research Budget for the particular Calendar Quarter. Promptly
following the end of each Calendar Quarter during which RevMed is responsible for activities under
the Research Plan, but in no event later than [***] following the end of such Calendar Quarter,
RevMed will provide to Sanofi a detailed expense report in form approved by the JRDC with respect to
the RevMed R&D Costs incurred by or on behalf of RevMed during such Calendar Quarter consistent with
the previous sentence (including, if requested by Sanofi in writing, copies of receipts or invoices
from Third Parties for all RevMed R&D Out-of-Pocket Costs) together with an invoice for the same,
provided that[***]. Sanofi will reimburse RevMed in Dollars all undisputed amounts within such
expense reports under this Section 4.5 within [***] following receipt of the invoice therefor.
RevMed shall invoice Sanofi for costs under this Section 4.5 on an accrual basis. 33

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 34 -->
(b) Calendar Years 2019 and 2020. Subject to Section 4.2(a)(i)(B), Sanofi shall be responsible for
80% of the Research and Development Costs for Calendar Years 2019 and 2020 and RevMed shall be
responsible for 20% of the Research and Development Costs for Calendar Years 2019 and 2020 (provided
that such Research and Development Costs are incurred per the Research Budget for such activities as
approved by the JSC and [***] set forth in the Research Budget for the particular Calendar Quarter).
Research and Development Costs shall initially be borne by the Party incurring the cost or expense.
Promptly following the end of each Calendar Quarter during Calendar Years 2019 and 2020, but in no
event later than [***] following the end of such Calendar Quarter, each Party will provide to the
JRDC a detailed expense report in form approved by the JRDC with respect to the Research and
Development Costs incurred by or on behalf of such Party during such Calendar Quarter consistent
with the previous sentence (including, if requested by Sanofi in writing, copies of receipts or
invoices from Third Parties for all RevMed R&D Out-of-Pocket Costs). The Party that incurs more than
its share of the total Research and Development Costs during any such Calendar Quarter shall deliver
an invoice to the other Party for an amount of cash sufficient to reconcile to the invoicing Party's
agreed percentage of Research and Development Costs. Such other Party will reimburse the invoicing
Party in Dollars all undisputed amounts within such expense reports under this Section 4.5 in
accordance with Section 9.5 mutatis mutandis.

Article V.

DEVELOPMENT

5.1 General. Subject to the terms and conditions of this Agreement, the Parties will collaborate on
the Development of the Products in the Field for Regulatory Approval under the direction of the JRDC
and pursuant to the Development Plan, as set forth in more detail below.

5.2 Development.

(a) Development Plan and Budget. As of the Effective Date, the Parties have agreed on an initial
Development Plan and Development Budget (each as defined below), which is set forth in Exhibit J of
the Correspondence. After the Effective Date, for the Development Candidate listed in Exhibit J of
the Correspondence, and at the time any other SHP2 Inhibitor is designated as a Development
Candidate by the JRDC, the JRDC shall prepare and approve a Development plan for Products containing
such SHP2 Inhibitor through Regulatory Approval of the Product from the FDA, EMA, or PMDA, as
applicable, that includes the items described below (the "Development Plan"). The Development Plan
for each Product shall set forth the timeline and details of: (i) all clinical Development
activities to be conducted by the Parties that are designed to generate data sufficient to present
to the FDA, EMA, and PMDA or other Regulatory Authority at the Pre-Registrational Meetings; (ii) the
protocol synopsis for each Clinical Trial included in such Development Plan; (iii) a Manufacturing
plan for the Manufacturing of the Product for such Clinical Trials; (iv) all additional clinical
Development activities to be conducted by the Parties that are designed to generate data sufficient
to seek Regulatory Approval of the Product from the FDA, EMA, or PMDA, as applicable, for the
indication(s) to be pursued; (v) any other Development activities to be performed in order to obtain
Regulatory Approval by the FDA, EMA, PMDA or the Regulatory Authority of any other jurisdiction;
(vi) a detailed budget setting forth the estimated RevMed R&D Costs to be incurred in connection
with such activities (the "Development Budget"); and (vi) the Party responsible for conducting each
Development activity under such Development Plan. 34

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 35 -->
(b) Conduct of Development. Each Party shall perform all Development activities under this Agreement
in compliance with all Applicable Law (including GMP, GLP and GCP). In furtherance and not in
limitation of the foregoing, RevMed shall use diligent efforts to conduct its activities under each
Development Plan in accordance with the terms of such Development Plan (including timelines), as the
same may be amended from time to time (and which basis for comparison shall be tolled until any
then-contemplated or pending amendments are completed or for the duration of any bona fide dispute
between the Parties with respect to a Development Plan or amendment thereto), and this Agreement. If
either RevMed agrees or it is determined in accordance with [***] that RevMed has committed a
material breach of its obligations under this Section 5.2(b) with respect to any Clinical Trial of a
Product, the JSC shall, within [***] after such agreement on or determination of material breach,
meet in person or by teleconference to discuss such material breach and specify reasonable actions
that RevMed should take to cure such material breach. If RevMed fails to commence within [***] after
such discussion occurs such actions recommended by the JSC, or fails to cure any such material
breach within [***] after the JSC meets (or such longer timeframe as the JSC decides is necessary to
complete the actions specified by the JSC), then Sanofi shall have the right, without prejudice to
any other rights or remedies Sanofi may have under this Agreement or otherwise at law or in
equity[***]. In such case, RevMed shall, [***], (i) make available [***], (ii) provide [***], (iii)
provide [***], and (iv) otherwise provide [***].

(c) Pre-Registrational Meeting. After obtaining early Development data and results under the
Development Plan for a particular Product, in the event the JRDC determines to further Develop such
Product for Marketing Approval, the JRDC shall develop a package setting forth such data and
results, a planned regulatory strategy for the Development of such Product for a defined indication
in the Field, the protocol synopses for each Registrational Clinical Trial included in the
applicable Registration Program, any other Development activities to be conducted in support of such
regulatory strategy, any other materials as may be required by the FDA, EMA, or PMDA or other
Regulatory Authority for the Pre-Registrational Meetings for the applicable Products, and the Party
responsible for conducting each Development activity under such package (the "Data Package"). After
developing such Data Package, the Parties shall conduct the Pre-Registrational Meetings as set forth
in Section 6.3(a).

(d) Development Plan Amendments. From time to time during the Term, the JRDC shall prepare
amendments, as appropriate, to the then-current Development Plan. Subject to the foregoing, the JRDC
shall have the right to approve amendments to the Development Plan, with final decision-making
authority as provided in Section 2.10. Once approved by the JRDC, such amended Development Plan
shall replace the prior Development Plan.

5.3 Combination Therapies.

(a) The JRDC shall discuss whether to include in the Development Plan for a Product the Development
of such Product for use with other products to the extent not already provided for in the
Development Plan (each, a "Combination Therapy"), including products developed or sold by a Third
Party or that are in the public domain. Subject to this Section 5.3, each Party shall have the right
to propose to the JRDC studies for co-development of Products with other products under the
applicable Development Plan. 35

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 36 -->
(b) The Development Plan shall address the conduct of any Clinical Trial for a Combination Therapy
and shall (i) specify which Party will be responsible for each activity for the Development of such
Combination Therapy and (ii) specify which Party will be responsible for obtaining supplies of the
Product or other product in such Combination Therapy as necessary. The JRDC shall review and approve
the terms of any agreement with a Third Party in connection with any supply or other aspect of
Development of such Combination Therapy.

5.4 Conflicts. If the terms of a Development Plan contradict, or create inconsistencies or
ambiguities with, the terms of this Agreement, then the terms of this Agreement shall govern.

5.5 Development Costs.

(a) Sanofi will reimburse RevMed for RevMed R&D Costs incurred by or on behalf of RevMed after the
Execution Date in the performance of its activities under the Development Plan, as applicable,
provided that such RevMed R&D Costs are incurred per the Development Budget, as applicable, for such
activities as approved by the JSC and do not exceed [***]% of the applicable amounts set forth in
the Development Budget for the particular Calendar Quarter. Promptly following the end of each
Calendar Quarter during which RevMed is responsible for activities under any Development Plan, but
in no event later than [***] following the end of such Calendar Quarter, RevMed will provide to
Sanofi a detailed expense report in form approved by the JRDC with respect to the RevMed R&D Costs
incurred by or on behalf of RevMed during such Calendar Quarter consistent with the previous
sentence (including, if requested by Sanofi in writing, copies of receipts or invoices from Third
Parties for all RevMed Out-of-Pocket Costs) together with an invoice for the same, provided that
[***]. Sanofi will reimburse RevMed in Dollars all undisputed amounts within such expense reports
under this Section 5.5 within [***] following receipt of the invoice therefor. RevMed shall invoice
Sanofi for costs under this Section 5.5 on an accrual basis.

5.6 RevMed Studies.

(a) RevMed or its Affiliates may propose to the JRDC that the Parties conduct a Clinical Trial of a
Product in the Field that is not included in the Development Plan for such Product, in which case
RevMed shall present the proposed design and projected costs of such Clinical Trial to the JRDC. If
Sanofi agrees to include such Clinical Trial and related costs in the Development Plan and
Development Budget for such Product, the Parties shall prepare an updated Development Plan and
Development Budget and such Clinical Trial shall become part of the Collaboration and subject to
this Agreement.

(b) In the event Sanofi, through the JRDC, decides not to pursue a Clinical Trial that RevMed
presents in accordance with Section 5.6(a), then (i) the matter will be escalated pursuant to
Section 2.10 and (ii) notwithstanding anything to the contrary in Section 2.10(b), if such matter
remains unresolved after the matter is escalated to Designated Senior Officers, then RevMed, subject
to this Section 5.6(b), may elect to conduct such study, on its own and at its own expense, provided
that if such study [***], RevMed shall not have the right to conduct such study unless Sanofi agrees
in writing that RevMed may conduct such study (any such study so conducted, a "RevMed Study"). For
purposes of determining whether subsections (x), (y) or (z) apply, RevMed shall, prior to commencing
a RevMed Study, submit to the JRDC for comment and review 36

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 37 -->
the protocol for such RevMed Study. Any disagreement among the JRDC members as to whether
subsections (x), (y) or (z) apply shall be submitted for resolution to the Designated Senior
Officers, provided that if the Designated Senior Officers do not agree on such matter, then RevMed
shall not conduct such study. Provided that RevMed is permitted to conduct a RevMed Study, RevMed
shall report to the JRDC on an ongoing basis any and all data arising from a RevMed Study (the
"RevMed Study Data") and provide the JRDC with updates and any other information pertaining to any
RevMed Study as may be requested by the JRDC.

A. Sanofi shall have rights to use, at no additional cost, any RevMed Study Data in its performance
of its obligations and exercise of its rights under the Collaboration except in connection with
filing of MAAs for the Indication and Product Treatment Regimen that were the subject of such RevMed
Study.

B. If Sanofi wishes to use, or actually uses, RevMed Study Data in support of filing a MAA for the
Indication and Product Treatment Regimen that were the subject of such RevMed Study, it shall notify
RevMed in writing and shall make a buy-in payment to RevMed in Dollars equal to [***] within [***]
after the date that Sanofi receives a detailed invoice from RevMed setting forth [***]. In such case
the RevMed Study shall be deemed a Clinical Trial under the Collaboration for all purposes,
including that all Know-How conceived, reduced to practice, developed, made or otherwise generated
by or on behalf of RevMed or its Affiliates in the course of the RevMed Study activities shall be
deemed Program Inventions hereunder.

C. Each Party shall have rights to use RevMed Study Data for internal research and development
outside the scope of the Collaboration.

5.7 Diligence. Consistent with [***] or as otherwise agreed by the Parties, Sanofi shall use
Commercially Reasonable Efforts [***] to file and seek approval for an MAA for at least one Product
in all of such countries or, in the case of the Major Market Countries in the European Union,
through the centralized European Union approval process. If Sanofi materially breaches its
obligation set forth in this Section 5.7, [***].

5.8 Development Records. Each Party shall maintain complete, current and accurate records of all
Development activities conducted by it hereunder, and all data and other information resulting from
such activities, for at least [***] after the expiration or termination of this Agreement in its
entirety or for such longer period as may be required by Applicable Law. Such records shall fully
and properly reflect all work done and results achieved in the performance of the Development
activities in good scientific manner appropriate for regulatory and patent purposes. Each Party
shall document all non-clinical studies and Clinical Trials for Products in formal written study
reports in accordance with Applicable Law and national and international guidelines (e.g., GCP, GLP,
and GMP). Each Party shall have the right to review and copy such records maintained by the other
Party at reasonable times and to obtain access to the original to the extent necessary for
regulatory and patent purposes or for other legal proceedings.

5.9 Data Exchange and Development Reports. In addition to adverse event and safety data reporting
obligations pursuant to Section 6.5, each Party shall promptly provide the other Party with copies
of all data and results generated by or on behalf of such Party in the course of performing the
Development activities hereunder, including, in each case of data arising from 37

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 38 -->
Clinical Trials for Products, or in such form as the JRDC may agree from time to time. Each Party
shall provide the JRDC with regular reports detailing its Development activities for the Products,
and the results of such activities at each regularly scheduled JRDC meeting. The Parties shall
discuss the status, progress and results of each Party's Development activities at such JRDC
meetings.

5.10 Clinical Samples. The Party who sponsors the applicable Clinical Trial of SHP2 Inhibitors shall
retain and archive all clinical samples obtained by such Party in the course of such Clinical Trial,
and shall provide the other Party reasonable access to such retained clinical samples.

Article VI.

REGULATORY

6.1 Regulatory Responsibilities. Subject to the Parties' cooperation as set forth in Section 6.3,
and except as otherwise set forth in a Development Plan or this Article VI, Sanofi shall have the
sole right and responsibility to perform all regulatory activities under the Collaboration
(including conducting all correspondence and communications with Regulatory Authorities and filing
all Marketing Authorization Applications and other filings with Regulatory Authorities). The
Development Plan shall set forth the regulatory strategy for seeking Regulatory Approval for the
Products in the Field by the FDA, EMA and other Regulatory Authorities in the Major Market
Countries.

6.2 Regulatory Materials and Database. All INDs in existence as of the Effective Date related to a
Product shall be solely owned and held in the name of RevMed or its Affiliate for so long as
necessary for RevMed to conduct any Clinical Trial for such Product it is responsible for under the
Development Plan for such Product. Following the Effective Date, each Party shall file and hold the
IND and NDA for all Products in Clinical Trials conducted by it. Once RevMed has completed
conducting all Clinical Trials for a Product assigned to it under the Development Plan for such
Product, RevMed agrees to assign, and hereby does assign, to Sanofi all of its rights, title and
interests in and to all Regulatory Approvals (including INDs and NDAs) for such Product.

6.3 Cooperation. For each Product, each Party shall cooperate reasonably with the other Party with
respect to all regulatory activities under the Research Plan or Development Plans relating to the
Products. Without limiting the foregoing, for such activities, each Party:

(a) shall meet and discuss with the other Party through the JRDC the timing, strategy and
presentation of the Pre-Registrational Meeting with the goal of developing the Registration Program
and setting the regulatory path to obtain Regulatory Approval for the Product from the FDA, EMA, and
PMDA;

(b) shall consult with each other with respect to the preparation of the Data Package;

(c) shall consult with the other Party through the JRDC regarding material regulatory matters
pertaining to all Regulatory Materials of the Products in the United States, European Union and the
Major Market Countries outside the European Union, including plans, strategies, filings, reports,
updates and supplements in connection therewith and perform its responsibilities in connection with
the preparation of the portion of such Regulatory Materials allocated to such Party for preparation
in the Development Plan; 38

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 39 -->
(d) shall provide the other Party with drafts of any Regulatory Materials for the Products to be
submitted by such Party to any Regulatory Authority in the United States, European Union and the
Major Market Countries outside the European Union within a reasonable time (but in no event less
than [***], unless impractical) prior to submission for review and comment, and shall consider in
good faith any comments received from the other Party;

(e) shall provide the other Party with copies in electronic format (e.g., eCTD format) of any
Regulatory Materials submitted to and any correspondence received from any Regulatory Authority in
the United States, European Union and the Major Market Countries outside the European Union
pertaining to the Products promptly after its submission or receipt by such Party; and

(f) shall provide the other Party written minutes or other records of any material oral discussions
with any Regulatory Authority in the European Union and the Major Market Countries outside the
European Union pertaining to the Products promptly after any such discussion.

If any Regulatory Material to be provided under this Section 6.3 was originally created in a
language other than the English language, if requested by the receiving Party, the providing Party
shall provide an English translation along with the original document to the receiving Party at the
receiving Party's cost if such translation would not normally be made by the providing Party in
accordance with its standard operating procedures.

6.4 Meetings with Regulatory Authorities. The Development Plan shall set forth which Party shall
lead and present at each meeting or teleconference with Regulatory Authorities for the applicable
Product, provided that, notwithstanding the foregoing, RevMed shall lead and present at such
meetings or teleconferences with respect to any RevMed Studies and for Clinical Trials conducted
under RevMed's IND while RevMed remains the holder of such IND. The Party leading such regulatory
interactions shall provide the other Party with advance notification of any in-person meeting or
teleconference with the Regulatory Authorities that relates to the Development of any Product as
promptly as possible after such meeting has been scheduled, but in no event less than [***] before
the meeting is scheduled to occur. The Party leading such regulatory interactions shall, as
applicable, seek permission from the Regulatory Authority for representatives of the other Party to
attend any such meeting or teleconference, and such other Party shall have the right, but not the
obligation, to have its representatives attend (but, unless otherwise requested by the Party
responsible for such meeting, not participate in) such meetings.

6.5 Adverse Events Reporting. Following the Effective Date, but in any case prior to the Initiation
of the first Clinical Trial for a Product or earlier upon the written request of either Party, the
Parties shall enter into a pharmacovigilance agreement setting forth the worldwide pharmacovigilance
procedures for the Parties with respect to the Products, such as safety data sharing, adverse events
reporting and safety profile monitoring (the "Pharmacovigilance Agreement"). Such procedures shall
be in accordance with, and enable the Parties to fulfill, local and national regulatory reporting
obligations under Applicable Law. Each Party shall be responsible for reporting quality complaints,
adverse events and safety data related to the Products 39

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 40 -->
to the applicable Regulatory Authorities in its territory, as well as responding to safety issues
and to all requests of Regulatory Authorities related to the Products in its territory, in each case
at its own cost. The initial global safety database shall be established by RevMed using its
Permitted Contractors or Researchers, and RevMed shall, at RevMed's sole cost and expense, transfer
such global safety database to Sanofi upon Sanofi's written request reasonably in advance of the
desired transfer date, which transfer date shall be no later than [***] prior to the initiation of
Sanofi's first Clinical Trial for a Product and in the form requested by Sanofi. Prior to such
transfer RevMed shall provide to Sanofi all safety information obtained by RevMed for the Products
prior to Sanofi's assumption of the global safety database. Each Party agrees to comply with its
respective obligations under the Pharmacovigilance Agreement and to cause its Affiliates, and
Sublicensees to comply with such obligations.

6.6 Notification of Threatened Action. Each Party shall immediately notify the other Party of any
information it receives regarding any threatened or pending action, inspection or communication by
any Regulatory Authority, which may affect the safety or efficacy claims of any Product or the
continued marketing of any Product. Upon receipt of such information, the Parties shall promptly
consult with each other in an effort to arrive at a mutually acceptable procedure for taking
appropriate action.

6.7 Remedial Actions. Each Party shall notify the other immediately, and promptly confirm such
notice in writing, if it obtains information indicating that any Product may be subject to any
recall, corrective action, market withdrawal or other similar regulatory action with respect to the
Product taken by virtue of Applicable Law (a "Remedial Action"). The Parties shall fully assist each
other in gathering and evaluating such information as is necessary to determine the necessity of
conducting a Remedial Action. Each Party shall, and shall ensure that its Affiliates, Sublicensees,
(sub)contractors and Distributors shall, maintain adequate records to permit the Parties to trace
the Manufacture, distribution and use of the Products, as required by Applicable Law. Sanofi shall
have sole discretion with respect to any matters relating to any Remedial Action in the Licensed
Territory, including the decision to commence such Remedial Action and the control over such
Remedial Action, at its sole cost and expense; provided that to the extent such Remedial Action
results from (a) the breach of RevMed's obligations hereunder or under any Ancillary Agreement or
(b) the negligence, recklessness or willful misconduct of RevMed or its Affiliate, in each case,
RevMed shall bear the costs and expenses of such Remedial Action.

6.8 Compassionate Use. Promptly after the Pre-Registrational Meeting with the FDA, EMA, and PMDA for
a particular Product (or in the case in which a Product is only being developed for the US or the
EU, but not both, after the applicable FDA, EMA or PMDA Pre-Registrational Meeting) or at a time
otherwise agreed by the Parties, the JRDC shall decide on a procedure for managing Product requests
for compassionate use.

6.9 Audit Vendors & Contractors. Each Party shall have in place standard operating procedures for
their vendor management processes (including with respect to compliance). Each Party shall notify
the other Party of any inspections of such Party or any of its Affiliates or subcontractors
conducted by any Regulatory Authority or other government entity and any related findings to the
extent that such inspections relate to the activities conducted hereunder. In addition, Sanofi shall
have the right to conduct customary reviews and audits of RevMed and its Affiliates and
subcontractors (provided that, with respect to Permitted Contractors or Researchers that 40

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 41 -->
RevMed entered into a written agreements with prior to the Effective Date, such right of Sanofi
shall be to the extent RevMed has the right to permit Sanofi to do so under such written agreements,
and provided further, that RevMed shall use Commercially Reasonable Efforts to secure such right for
Sanofi where one does not exist).

Article VII.

MANUFACTURING AND SUPPLY

7.1 General. The Manufacture of the SHP2 Inhibitors and Products, including all process and
formulation development in connection therewith, including Chemistry, Manufacturing and Controls
(CMC) activities, shall be overseen and coordinated by (a) RevMed for clinical supply related to
Phase 1 Clinical Trials, and Phase 2 Clinical Trials that are not Registrational Clinical Trials,
and (b) Sanofi for supply of all Clinical Trials other than those set forth in clause (a) and all
supply associated with Commercialization. If requested by the JMC, each Party shall provide reports
summarizing its Manufacturing activities and the results of such activities.

7.2 Transfer of Manufacturing Know-How. Upon Sanofi's request, RevMed shall transfer to Sanofi or
its designee Know-How Controlled by RevMed that is necessary or useful to enable the Manufacture of
each SHP2 Inhibitor that is nominated or designated as a Development Candidate pursuant to Section
4.3, Development Candidate and Product, including regulatory starting materials and key starting
materials, as set forth in this Section 7.2. Sanofi may also request such Know-How for backup SHP2
Inhibitors that Sanofi is considering for nomination or designation as a Development Candidate, and
RevMed shall transfer such Know-How to Sanofi (to the extent any exists). RevMed shall (a) at [***]
cost, provide copies or samples of relevant documentation (including, but not limited to,
documentation listed in Exhibit K of the Correspondence), materials and other embodiments of such
Know-How, (b) at [***] cost (calculated on [***]), make available RevMed's qualified technical
employees, and use Commercially Reasonable Efforts to make available the qualified technical
personnel of RevMed's independent manufacturing contractors, in each case, on a reasonable basis to
consult with Sanofi or its designee with respect to such Know-How, and (c) if requested by Sanofi,
at [***] cost, use Commercially Reasonable Efforts to support Sanofi in the establishment of its own
supply agreements with Third Party suppliers of RevMed.

7.3 Supply Agreement. In each case where one Party shall Manufacture Product for the other Party for
clinical use or commercial use, (with the cost and expense of the commercial supply of Product for
the U.S. being subject to Section 9.4), the Parties shall negotiate in good faith to enter into a
supply agreement (a "Supply Agreement") and a quality agreement (a "Quality Agreement") for such
Manufacture on commercially reasonable terms. Such Supply Agreement shall cover the documentation
and other quality requirements for the acceptance of previously manufactured supply of Product for
use by the other Party. The price charged by the manufacturing Party under any Supply Agreement
shall be equal to [***] unless otherwise agreed by the Parties. 41

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 42 -->
Article VIII.

COMMERCIALIZATION

8.1 General. Subject to Section 8.7 and unless otherwise delegated to RevMed by the JCC, Sanofi
shall have the sole right and responsibility, at its own expense, for all aspects of the
Commercialization of the Products in the Field in the Licensed Territory including: (a) developing
and executing a commercial launch and pre-launch plan, (b) negotiating with applicable Governmental
Authorities regarding the pricing and reimbursement status of the Products; (c) marketing and
promotion (including promotional materials); (d) booking sales and distribution and performance of
related services; (e) handling all aspects of order processing, invoicing and collection, inventory
and receivables; (f) providing customer support, including handling medical queries, and performing
other related functions; and (g) conforming its practices and procedures to Applicable Law relating
to the marketing, detailing and promotion of the Products.

8.2 Commercialization Plan. Promptly after the formation of the JCC, Sanofi shall prepare and
provide to the JCC for review and discussion a written plan for the Commercialization of such
Product in the Licensed Territory (the "Commercialization Plan"). Each Commercialization Plan shall
include a reasonably detailed description of (a) [***]; (e) non-binding sales and marketing
forecasts in the U.S.; (f) non-binding net sales projections in the U.S.; (g) [***]; (h) non-binding
sales and marketing forecasts and non-binding net sales projections, in each case, outside of the
U.S. (i) [***], and in such case the Parties shall amend the Profit/Loss Share Agreement
accordingly. Sanofi shall periodically (at least [***]) prepare updates and amendments to its
Commercialization Plan to reflect changes in its plans, including in response to changes in the
marketplace, relative success of the Products and other relevant factors influencing such plans and
activities. Sanofi shall submit all updates and amendments to each Commercialization Plan to the JCC
for review and discussion before adopting such updates and amendments.

8.3 Distributorships. Sanofi shall have the right, in its sole discretion, to appoint its
Affiliates, and Sanofi and its Affiliates shall have the right, in its sole discretion, to appoint
any other Persons, in the Licensed Territory to distribute, market, and sell the Products (with or
without packaging rights), in circumstances where the Person purchases its requirements of Products
from Sanofi or its Affiliates but does not otherwise make any royalty or other payment to Sanofi or
its Affiliates with respect to its intellectual property or other proprietary rights. Where Sanofi
or its Affiliates appoints such a Person and such Person is not an Affiliate of Sanofi, that Person
shall be a "Distributor" for purposes of this Agreement. The term "packaging rights" in this Section
means the right for the Distributor to package Products supplied in unpackaged bulk form into
individual ready-for-sale packs.

8.4 Pricing Approvals. Sanofi shall control all pricing and reimbursement approvals for Products in
the Licensed Territory. RevMed shall provide Sanofi with reasonable assistance and cooperation with
respect to obtaining pricing and reimbursement approvals for the Products, at Sanofi's request and
expense. 42

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 43 -->
8.5 Patent Marking. Each Party shall mark all Products in accordance with the applicable patent
marking laws, and shall require all of its Affiliates, Sublicensees and Distributors to do the same.

8.6 Reports. Each Party shall update the JCC at each regularly scheduled JCC meeting regarding its
Commercialization activities with respect to the Products. Each such update shall be in a form to be
agreed by the JCC by mutual agreement of its representatives (without application of any final
decision-making right of either Party) and shall summarize such Party's (either by itself or through
its Affiliates and its Sublicensees) Commercialization activities with respect to the Products.

8.7 Co-Promotion of Products in the United States.

(a) RevMed shall have the one-time exclusive right to elect to assume up to [***]% (but not less
than [***]%) of the Detailing effort for all Products in the United States (such geography, the
"Co-Promotion Territory"; such right, the "Co-Promotion Option"; such Products that are co- promoted
by the Parties, the "Co-Promotion Product"); provided that (i) [***] and (ii) RevMed shall provide
to Sanofi, at the time of RevMed's exercise of the Co-Promotion Option pursuant to Section 8.7(b), a
plan demonstrating to Sanofi's reasonable satisfaction that RevMed has, or will have on a timely
basis, the necessary resources in place sufficient to Detail the applicable Co-Promotion Products in
a manner consistent with and within the timelines required under the applicable Commercialization
Plan. RevMed shall be obligated to perform the activities set forth in such plan within the
timelines provided therein.

(b) Sanofi shall notify RevMed of the anticipated launch date for the first Product in the
Co-Promotion Territory at least [***] in advance thereof. If RevMed wishes to exercise its one-time
Co-Promotion Option, it shall so notify Sanofi in writing at least [***] prior to the anticipated
launch of such Product in the Co-Promotion Territory. If (i) RevMed does not provide the above
election notice in compliance with the requirements of this Section 8.7(b), or (ii) RevMed provides
notice to Sanofi that it does not intend to exercise its one-time Co-Promotion Option, then RevMed
shall be deemed to have waived such one-time right to co-promote any and all Products in the
Co-Promotion Territory. For clarity, once RevMed has exercised its Co- Promotion Option pursuant to
this Section 8.7(b), RevMed's right to co-promote Products shall apply to all other existing and
subsequent Products in the Co-Promotion Territory.

(c) If RevMed exercises the Co-Promotion Option for the Co-Promotion Territory, the Parties shall
negotiate in good faith terms and conditions of a co-promotion agreement pursuant to which they will
co-promote Products in the Co-Promotion Territory (the "Co-Promotion Agreement"). The Co- Promotion
Agreement will contain the terms and conditions set forth in Exhibit L of the Correspondence and
other terms and conditions as are reasonable and customary for the co-promotion of similar products
in the Co-Promotion Territory. The Parties shall use Commercially Reasonable Efforts to enter into
the Co-Promotion Agreement no later than [***] following the date upon which RevMed exercises the
Co-Promotion Option, or such later date as the Parties may agree in writing. 43

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 44 -->
Article IX.

FINANCIAL PROVISIONS

9.1 Upfront Payment. Sanofi shall pay to RevMed a one-time, non-refundable, non-creditable upfront
payment of $50,000,000 within [***] Business Days after the Effective Date.

9.2 Milestone Payments. Upon first achievement of a milestone event described below in this Section
9.2 (a "Milestone Event") by Sanofi or any of its Affiliates or Sublicensees, Sanofi shall notify
RevMed of such achievement and RevMed will issue an invoice to Sanofi for the corresponding one-
time, non-refundable and non-creditable milestone payment (a "Milestone Payment"). RevMed will also
have the right to notify Sanofi in writing if RevMed believes a Milestone Event has been achieved
even if Sanofi has not provided such notice to RevMed, and unless Sanofi notifies RevMed within
[***] Business Days after receipt of such notice from RevMed that such Milestone Event has not been
achieved, RevMed may issue an invoice to Sanofi for the corresponding Milestone Payment. Subject to
the terms and conditions of this Agreement, Sanofi will pay to RevMed the following Milestone
Payments within [***] after receipt of such invoice therefor as follows:

Milestone Event Milestone Payment (a) [***] [***] (b) [***] [***] (c) [***] [***] (d) [***] [***]
(e) [***] [***] (f) [***] [***] (g) [***] [***] (h) [***] [***] (i) [***] [***] (j) [***] [***] (k)
[***] [***] (l) [***] [***] 44

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 45 -->
Milestone Event Milestone Payment (m) [***] [***] (n) [***] [***] (o) [***] [***] (p) [***] [***] In
no event shall the total Milestone Payments under this Agreement exceed: $520,000,000

Each Milestone Payment is due only once and will be payable only upon the first Product to achieve
the corresponding Milestone Event for the first time.

*For purposes of determining whether a Milestone Event has occurred with respect to the EMA, a
Marketing Approval must be obtained [***].

The Milestone Payments shall be payable with respect to Initiation of any RevMed Study only if
[***].

9.3 Royalty Payments for Products.

(a) Royalty Rates for Royalties Payable by Sanofi on Net Sales outside the United States. Subject to
the other terms of this Section 9.3, during the Royalty Term, Sanofi shall make quarterly royalty
payments to RevMed on aggregate Net Sales of each Product sold outside the United States during a
Calendar Year at the applicable royalty rates as set forth below. For clarity, royalties shall only
be payable once on any sale of Product under this Agreement.

Aggregate Net Sales of each Product outside the United States during a Calendar Year Royalty Rate
Portion of aggregate Net Sales of each Product outside the United States during a Calendar Year less
than or equal to $[***] [***]% Portion of aggregate Net Sales of each Product outside the United
States during a Calendar Year greater than $[***] and less than or equal to $[***] [***]% Portion of
aggregate Net Sales of each Product outside the United States during a Calendar Year greater than
$[***] and less than $[***] [***]% Portion of aggregate Net Sales of each Product outside the United
States during a Calendar Year greater than $[***] [***]% 45

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 46 -->
(b) Royalty Term. Sanofi's royalty payment obligations under this Section 9.3 with respect to a
particular Product and country shall commence upon the First Commercial Sale of such Product in such
country (by Sanofi or its Affiliates or Sublicensees) and shall continue, on a Product-by-Product
and country-by-country basis, until the latest of (i) the date on which there is no Valid Claim that
would be infringed by the sale of such Product in such country; (ii) the expiration of any
Regulatory Exclusivity granted with respect to such Product in such country[***] (the "Royalty Term"
for such Product and country).

(c) Royalty Reductions.

(i) In any country in which there is no Valid Claim and no Regulatory Exclusivity for such Product,
at the time of sale of such Product in such country during the applicable Royalty Term, Sanofi's
obligation to pay royalties under Section 9.3(a) on Net Sales of such Product in such country shall
be reduced to [***]% of the rates otherwise payable under such section.

(ii) If during the Royalty Term for a Product in a country, one or more Generic Products of such
Product are sold in such country, and during any Calendar Quarter following the Calendar Quarter in
which such Generic Product(s) are first sold in such country (the "Launch Quarter") Net Sales of
such Product in such country during any Calendar Quarter following the Launch Quarter are less than
the Designated Percentage (as defined below) of average Net Sales occurring during the [***]
immediately preceding the Launch Quarter (such average Net Sales during such Calendar Quarters, the
"Base Net Sales"), then the royalty rates provided in Section 9.3(a) for such Product shall be
reduced in such country by the "Applicable Reduction Percentage" set forth below for such Calendar
Quarter and for all future Calendar Quarters, unless and until the Generic Product is no longer sold
or the Net Sales increase above the Base Net Sales in a Calendar Quarter. If Net Sales of the
applicable Product in a country in a Calendar Quarter following the Launch Quarter for such country
are:

A. lower than or equal to [***]%, but more than [***]%, of Base Net Sales of the applicable Product
in such country, then the Applicable Reduction Percentage shall be [***]%; or

B. lower than or equal to [***]% of Base Net Sales of the applicable Product in such country, then
the Applicable Reduction Percentage shall be [***]%.

(iii) If Sanofi enters into an agreement with a Third Party in order to obtain a license or other
right to a Third Party Right that is reasonably necessary to manufacture, use or sell a Product (or
the SHP2 Inhibitor contained therein) in a country pursuant to Section 10.7, Sanofi shall be
entitled to deduct from the royalties payable under Section 9.3(a) with respect to such Product in
such country in a particular Calendar Quarter [***] paid by Sanofi to such Third Party in respect of
such agreement for such Calendar Quarter, in each case to the extent reasonably allocable to such
Third Party Right and such Product and country; provided that in no event shall the royalties
payable for such Product and country in any Calendar Quarter be reduced to less than [***]% of the
amount otherwise due under Section 9.3(a) (the "Royalty Floor"). If any of such amounts cannot be
offset against royalties due with respect to a Product for any Calendar Quarter because they would
result in royalties payable to RevMed being lower than the Royalty Floor, Sanofi shall have 46

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 47 -->
the right to carry forward and offset such excess amount against royalties or any other payments
otherwise due to RevMed in subsequent Calendar Quarters up to a maximum reduction for each Quarter
of [***]% of the amounts owed in respect of such subsequent Calendar Quarter. Upon RevMed's written
request Sanofi shall provide a summary to RevMed with respect to the scope of the licensed rights
and payments due pursuant to such Third Party license, provided that RevMed may only make such a
request one time for each Third Party license.

(d) Royalty Reports and Payment.

(i) Within [***] after each Calendar Quarter, commencing with the Calendar Quarter during which the
First Commercial Sale of the first Product is made anywhere in the Licensed Territory, Sanofi shall
provide RevMed with a report that contains the following information for the applicable Calendar
Quarter: (i) on a country-by-country and Product-by-Product basis, the amount of Net Sales of the
Products (which may be provided in Dollars or Euros), (ii) on a country-by-country basis and on a
Product-by-Product basis, a calculation of the royalty payment due on such sales, and (iii) the
exchange rate for such country. Within [***] following delivery of the applicable quarterly report,
Sanofi shall pay in Dollars all royalties due to RevMed with respect to Net Sales by Sanofi, its
Affiliates and their respective Sublicensees for such Calendar Quarter.

(ii) Within [***] after each Calendar Year, commencing with the Calendar Year during which the First
Commercial Sale of the first Product is made anywhere in the Licensed Territory, Sanofi shall
provide RevMed with [***].

(e) Clarifications. For the purpose of calculating the aggregate Net Sales of a particular Product
for an applicable country to determine the applicable royalty rate under Section 9.3, all Products
containing the same SHP2 Inhibitor shall be deemed a single Product, regardless of form,
formulation, dosage, packaging, other active ingredient or component, label or intended patient
population. All royalty payments under this Section 9.3 are non-refundable and non-creditable.

9.4 U.S. Profit/Loss Share. No later than the Initiation of the first Registrational Clinical Trial
for the first Product, Sanofi and RevMed shall enter into a profit/loss share agreement (the
"Profit/Loss Share Agreement") pursuant to which the Parties shall equally share the Net Profit and
Net Loss (as defined in Exhibit M of the Correspondence) applicable with respect to
Commercialization of Products (but, for clarity, not any costs of Development) of Products in the
U.S. The Profit/Loss Share Agreement for a Product in the U.S. shall continue in effect until the
expiration of the Royalty Term for such Product in the U.S. and shall contain the terms and
conditions set forth in Exhibit M of the Correspondence and other terms and conditions as are
reasonable and customary for the sharing of profits and losses with respect to similar products in
the United States (including that each Party shall bear its own income taxes, that each Party is
entitled to withhold any tax on behalf of the other Party on payments made to the other Party as
required by Applicable Law (taking into account any legally available reduction or elimination of
such tax pursuant to an applicable tax treaty or otherwise), and each Party shall indemnify the
other Party with respect to any withholding taxes asserted or assessed by any taxing authority on
amounts received directly by, or deemed allocable to, such other Party. 47

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 48 -->
9.5 Payment Terms; Exchange Rate. Notwithstanding any term to the contrary of this Agreement, RevMed
shall deliver an invoice to Sanofi for all payments owed by Sanofi to RevMed under this Agreement.
Sanofi will make all payments owed to RevMed within [***] after the date on which Sanofi receives an
undisputed invoice for such owed amount, except where a different timeframe is expressly provided in
another Section of this Agreement (e.g., for the reimbursement of RevMed R&D Costs pursuant to
Sections 4.5 and 5.5; the payment of the buy-in payment pursuant to Section 5.6(b)B; the upfront
payment set forth in Section 9.1; the royalties payable pursuant to Section 9.3, the payment of VAT
pursuant to Section 9.7(b); and the payment of unpaid or overpaid amounts pursuant to Section
9.9(b)). All payments to be made by a Party to the other Party under this Agreement shall be made in
Dollars by bank wire transfer in immediately available funds to a bank account designated by written
notice from the Party that receives the payment. Conversion of Net Sales or reimbursable costs
incurred hereunder that are recorded in local currencies to Dollars by a Party, its Affiliates or
its or their Sublicensees shall be performed in a manner consistent with its normal practices used
to prepare its audited financial statements for internal and external reporting purposes.

9.6 Late Payments. If a Party does not receive payment of any undisputed sum due to it on or before
the due date therefor, then it shall notify the paying Party. The paying Party shall pay interest on
any undisputed late payments (before and after any judgment) at an annual rate (but with interest
accruing on a daily basis) of the lesser of (a) [***] percent above the London Interbank Offered
Rate for deposits in Dollars having a maturity of one month published by the British Bankers'
Association, as adjusted from time to time on the [***] of each month, such interest to run from the
date on which payment of such sum became due until payment thereof in full together with such
interest or (b) the maximum rate permitted by Applicable Law.

9.7 Taxes.

(a) General. Each Party shall be solely responsible for the payment of all income taxes imposed on
its share of income arising directly or indirectly from the activities of the Parties under this
Agreement. In the event that Sanofi is required, under Applicable Law, to withhold any deduction or
tax from any payment due to RevMed under this Agreement (taking into account any legally available
reduction or elimination of such tax pursuant to an applicable tax treaty or otherwise), such amount
will be deducted from the payment to be made by Sanofi, paid to the proper taxing authority, and
Sanofi will notify RevMed and upon RevMed's request promptly provide RevMed with copies of any tax
certificate or other documentation evidencing such withholding, provided, however, that in the event
that any such withholding tax arises as a result of Sanofi's re-domiciliation, assignment of its
rights or obligations hereunder to an Affiliate, or use of any Third Party subcontractor, payments
to RevMed hereunder shall be made on a grossed-up basis to ensure that RevMed receives the same
amount it would have in the absence of such withholding. Each Party agrees to cooperate with the
other Party in claiming exemptions from such deductions or withholdings under any agreement or
treaty from time to time in effect.

(b) Value Added Tax. Notwithstanding anything contained in Section 9.7(a), this Section 9.7(b) will
apply with respect to value added tax (or sales, use or indirect tax) ("VAT"). All payments to be
made by Sanofi hereunder are exclusive of VAT. If any VAT is chargeable in respect of any such
payments, Sanofi will notify RevMed and pay VAT at the applicable rate in respect of any such
payments following the receipt of a VAT invoice in the appropriate form issued by RevMed in respect
of those payments or Sanofi shall self-assess and pay such VAT, such VAT to be payable on the later
of the due date of the payment to which such VAT relates and [***] after the receipt by Sanofi of
the applicable invoice relating to that VAT payment. 48

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 49 -->
9.8 Records. Each Party shall, and shall cause its Affiliates and its and their Sublicensees to,
maintain complete and accurate financial books and records in sufficient detail to permit the other
Party to confirm the accuracy of the amount of amounts payable under this Agreement. Each Party
shall, and shall cause its Affiliates and its and their Sublicensees to, retain such books and
records until the later of (a) [***] after the end of the period to which such books and records
pertain and (b) the expiration of the applicable tax statute of limitations (or any extensions
thereof) or for such longer period as may be required by Applicable Law.

9.9 Audit Procedures.

(a) Upon reasonable prior notice of the other Party, but in any event at least [***] prior notice,
each Party shall and shall cause its Affiliates and its and their Sublicensees to permit an
independent auditor of international prominence, selected by the auditing Party and reasonably
acceptable to the audited Party, to audit the books and records maintained pursuant to Section 9.8
for the sole purpose of verifying for the auditing Party the accuracy of the financial reports
furnished by the audited Party pursuant to this Agreement or of any payments made, or required to be
made, by or to the audited Party pursuant to this Agreement or any Ancillary Agreement. Such audit
shall not occur more than [***] in a given Calendar Year, unless for cause, and shall not concern
books and records relating to a period more than [***] preceding the current Calendar Year. Any
failure by a Party to exercise its rights under this Section 9.9 with respect to a Calendar Year
within such [***] period shall constitute a waiver by such Party of its right to later object to any
payments made by the other Party under this Agreement during such Calendar Year.

(b) Upon completion of the audit, the auditor shall provide a report to both Parties, which report
shall be limited to a description of any failure to comply with the terms of this Agreement and the
amount of the financial discrepancy. Such auditor shall not disclose the audited Party's
Confidential Information to the auditing Party, except to the extent such disclosure is necessary to
verify the accuracy of the financial reports furnished by the audited Party or the amount of
payments to or by the audited Party under this Agreement. Any amounts shown to be owed but unpaid,
or overpaid and in need of reimbursement, shall be paid or refunded (as the case may be) within
[***] after the auditor's report, plus interest (as set forth in Section 9.6) from the original due
date (unless challenged in good faith by the audited Party in which case any dispute with respect
thereto shall be resolved in accordance with Section 15.6).

(c) The auditing Party shall bear the full cost of such audit unless such audit reveals an
underpayment by the audited Party that resulted from a discrepancy in the financial report provided
by the audited Party for the audited period, which underpayment was more than [***] percent of the
amount set forth in such report, in which case the audited Party shall reimburse the auditing Party
for the costs for such audit.

(d) The auditing Party shall treat all information subject to review under this Section 9.9 in
accordance with the confidentiality provisions of Article XI and the Parties shall cause the auditor
to enter into a reasonably acceptable confidentiality agreement with the audited Party obligating
such auditor to retain all such financial information in confidence pursuant to such confidentiality
agreement. 49

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 50 -->
Article X.

INTELLECTUAL PROPERTY RIGHTS

10.1 Ownership.

(a) [***] Each Party shall ensure that every Third Party performing activities on behalf of such
Party in connection with the Collaboration executes a binding and enforceable invention assignment
agreement assigning all of such Third Party's right, title and interest in and to Program Inventions
to such Party, provided that [***], provided that for those Permitted Contractors or Researchers for
whom [***], [***], or [***], provided that [***].

(b) Subject to the other terms and conditions of this Agreement (including the licenses and other
rights granted under this Agreement or any Ancillary Agreement), each Party shall have the right to
exploit, including license, the Joint Program Technology, without a duty of accounting or any
obligation to seek consent from the other Party to exploit such Joint Program Technology. To the
extent necessary to effect the foregoing in a country other than the United States, each Party
grants to the other Party a nonexclusive, irrevocable, perpetual, fully-paid, worldwide license,
with the right to grant sublicenses, under the granting Party's interest in Joint Program
Technology, for any and all purposes, provided that RevMed's interest therein shall be subject to
the other terms and conditions of this Agreement, including the exclusive licenses granted herein
(during the Term) and all payment obligations.

(c) Each Party shall promptly disclose to the other Party in writing and shall cause its Affiliates,
and its and their Sublicensees to so disclose, any Joint Program Know-How and any other Program
Inventions. Each Party shall also respond promptly to reasonable requests from the other Party for
additional information relating to such Joint Program Know-How and other Program Inventions as
reasonably necessary to exercise such Party's rights and perform its obligations, hereunder and
under any Ancillary Agreement, with respect thereto.

10.2 Patent Prosecution.

(a) Sanofi Prosecuted Patents. Sanofi shall have the sole and exclusive right [***] to file,
prosecute and maintain the RevMed Licensed Patents and [***] (the "Sanofi Prosecuted Patents"),
[***]. Such right shall be subject to [***], provided that [***]. RevMed shall transfer the
applicable prosecution files for the RevMed Licensed Patents to Sanofi within [***] after the
Effective Date. Sanofi shall, through the JPC, consult with RevMed and keep RevMed reasonably
informed of the status of the Sanofi Prosecuted Patents and shall promptly provide RevMed with all
correspondence received from any patent authorities in connection therewith, including with respect
to Sanofi's proposed timelines for submission of comments to patent authorities (to the extent not
shared via the JPC). In addition, Sanofi shall promptly provide RevMed, through the JPC, with drafts
of all proposed material filings and correspondence to any patent authorities with respect to the
Sanofi Prosecuted Patents for RevMed's review and comment reasonably in advance of the intended
submission of such proposed filings and correspondence. Sanofi shall, through the 50

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 51 -->
JPC, confer with RevMed and take into consideration RevMed's comments prior to submitting such
proposed filings and correspondence. If RevMed does not provide such comments at least [***] prior
to the proposed submission date, then RevMed shall be deemed to have no comment to such proposed
filings or correspondence. In case of disagreement between the Parties with respect to the filing,
prosecution and maintenance of such Sanofi Prosecuted Patents, the final decision shall be made
pursuant to Section 2.10.

(b) Collaboration. RevMed shall provide Sanofi all reasonable assistance and cooperation in the
patent prosecution and maintenance efforts under this Section 10.2, including providing any
necessary powers of attorney and executing any other required documents or instruments for such
prosecution or maintenance.

(c) Patent Listings. As between the Parties, [***].

10.3 CREATE Act. Notwithstanding anything to the contrary in this Article X, each Party shall have
the right to invoke the Cooperative Research and Technology Enhancement Act of 2005, 35 U.S.C.
§102(c) (the "CREATE Act") when exercising its rights under this Article X without the prior written
consent of the other Party. Where such Party intends to invoke the CREATE Act, as permitted by the
preceding sentence, it shall notify the other Party and the other Party shall cooperate and
coordinate its activities with the Party invoking the CREATE Act with respect to any submissions,
filings or other activities in support thereof. The Parties acknowledge and agree that this
Agreement is a "joint research agreement" as defined in 35 U.S.C. § 100(h).

10.4 Patent Enforcement and Defense.

(a) Each Party shall promptly notify the other Party (but in any case no later than [***] after
becoming aware) of any alleged or threatened infringement by a Third Party of any of the RevMed
Licensed Patents or Joint Program Patents, and RevMed shall promptly notify Sanofi (but in any case
no later than [***] after becoming aware) of any alleged or threatened infringement by a Third Party
of any of the Sanofi Sole Program Patents, in each case including (i) any such alleged or threatened
infringement on account of a Third Party's manufacture, use or sale of a Product in the Field or
(ii) any "patent certification" filed in the United States under 21 U.S.C. §355(b)(2) or 21 U.S.C.
§355(j)(2) or similar provisions in other jurisdictions in connection with an ANDA (an Abbreviated
New Drug Application in the United States or a comparable application for Regulatory Approval under
Applicable Law in any country other than the United States) or other MAA for a Product in the Field
and (iii) any declaratory judgment action filed by a Third Party that is developing, manufacturing
or commercializing a Product in the Field alleging the invalidity, unenforceability or
non-infringement of any of the RevMed Licensed Patents, Joint Program Patents or Sanofi Sole Program
Patents ((i)-(iii), collectively, "Product Infringement").

(b) Sanofi, at its sole cost and expense, shall have the sole and exclusive right, but not the
obligation, to bring (or defend) and control any legal action in connection with any Product
Infringement at its own expense, as it reasonably determines appropriate.

(c) RevMed, at its sole cost and expense, shall have the sole and exclusive right to enforce the
RevMed Licensed Patents for any infringement that is not a Product Infringement at its own expense
as it reasonably determines appropriate. Each Party shall have the right to enforce the Joint
Program Patents for any infringement that is not a Product Infringement at its own expense as it
reasonably determines appropriate. Sanofi shall have the sole and exclusive right to enforce the
Sanofi Sole Program Patents at its sole cost and expense. 51

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 52 -->
(d) [***]

(e) At the request of Sanofi, RevMed shall provide reasonable assistance in connection with any such
suit or action, including by executing reasonably appropriate documents, cooperating in discovery
and joining as a party to the action if required (at Sanofi's expense). In connection with a
proceeding with respect to a Product Infringement covered by this Section 10.4, Sanofi shall not
enter into any settlement admitting the invalidity of, or otherwise impairing RevMed's rights in,
the RevMed Licensed Patents or Joint Program Patents without the prior written consent of RevMed.

(f) Any recoveries resulting from an enforcement action relating to a claim of Product Infringement
shall be first applied against payment of each Party's costs and expenses in connection therewith.
Any such recoveries in excess of such costs and expenses (the "Remainder") shall be shared by the
Parties as follows. The Remainder shall, [***].

10.5 Trademarks.

(a) Product Marks. Sanofi shall have the right to Commercialize the Products in the Licensed
Territory, in accordance with Applicable Law, using (i) the corporate Trademarks of Sanofi and its
Affiliates, Sublicensees and Distributors and (ii) subject to Section 11.5(a)(ii), any other
Trademarks it determines appropriate for such Products in such countries (such Trademarks in clause
(ii), the "Product Marks"), which may vary by country or within a country, provided that the Parties
shall coordinate in good faith a global branding strategy with respect to the Products through the
JCC pursuant to Section 2.4(a). Sanofi shall own all rights in the Product Marks and shall have the
sole right to register, prosecute and maintain the Product Marks using counsel of its own choice in
the countries and regions in the Licensed Territory that it determines reasonably necessary, at
Sanofi's cost and expense.

(b) Trademark Infringement. RevMed shall provide to Sanofi prompt written notice of any actual or
threatened infringement of the Product Marks and of any actual or threatened claim that the use of
such Product Marks violates the rights of any Third Party, in each case, of which RevMed becomes
aware. Sanofi shall have the sole right to take such action as Sanofi deems necessary against a
Third Party based on any alleged, threatened or actual infringement, dilution, misappropriation or
other violation of or unfair trade practices or any other like offense relating to, the Product
Trademarks by a Third Party at its sole cost and expense, subject to Section 9.4, and using counsel
of its own choice. Sanofi shall retain any damages or other amounts collected in connection
therewith.

(c) Domain Names. Sanofi shall have the sole right to register and shall own and control any domain
names for the Product Marks that it registers in any generic Top Level Domain (e.g., .com, .info,
.net or .org) or in any country code Top Level Domain for any country in the Licensed Territory
(e.g., .us for the United States and .ca for Canada). 52

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 53 -->
10.6 Patent Extensions.

(a) The Parties shall cooperate in obtaining patent term restoration (under but not limited to the
U.S. Drug Price Competition and Patent Term Restoration Act and its foreign equivalents),
supplemental protection certificates or their equivalents, and patent term extensions with respect
to the RevMed Licensed Patents and Joint Program Patents in any country or region where applicable.

(b) Sanofi shall determine the RevMed Licensed Patents and Joint Program Patents for which it shall
apply to extend in any country and notify RevMed of such determination and any such extensions that
are granted. Each Party shall provide all reasonable assistance to the other Party in connection
with such filings and each Party shall bear its own costs with respect to such assistance.

10.7 Third Party Rights.

(a) If either Party reasonably determines, in consultation with the JRDC, that (i) the Research,
Development, Manufacture, or Commercialization of [***] infringes or misappropriates any Patent
Right or other intellectual property right of a Third Party, such that such Party or its respective
Affiliates or Sublicensees cannot [***] without infringing or misappropriating the Patent Right or
other intellectual property right of such Third Party (a "Third Party Right") or (ii) [***], such
Party shall notify the other Party (such notification, the "Third Party Right Notification"), and
promptly thereafter the Parties shall discuss obtaining a license to the applicable intellectual
property right.

(b) Sanofi shall have the first right, but not the obligation, through counsel of its choosing, to
negotiate and obtain a license with respect to such Third Party intellectual property right and
shall provide RevMed with a copy of such license if it obtains such a license (to the extent
permitted by the terms of such license, provided that Sanofi shall use Commercially Reasonable
Efforts to obtain such permission to provide such copy). If Sanofi elects not to obtain such
license, or fails to obtain such license within [***] after the Third Party Right Notification, then
RevMed shall have the right to obtain such license, with the right to grant the corresponding
sublicense to Sanofi pursuant to Section 10.7(c). The Party negotiating a license shall keep the
other Party reasonably informed of the material terms for such prospective license applicable to the
Products and shall consider in good faith the comments of such other Party with respect to such
Third Party license.

(c) If RevMed obtains such license, then notwithstanding anything to the contrary in this Agreement,
the Patent Rights and Know-How licensed thereunder will be included in the RevMed Background
Technology only if Sanofi provides RevMed with written notice within [***] following its receipt
from RevMed of the substantive terms of the license agreement, in which [***]. Sanofi shall [***] no
later than [***] before the applicable due date therefor. 53

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 54 -->
Article XI.

CONFIDENTIALITY; PUBLICATION

11.1 Duty of Confidence. At all times during the Term and for a period of [***] thereafter, subject
to the other provisions of this Article XI:

(a) all Confidential Information of a Party (the "Disclosing Party") shall be maintained in
confidence and otherwise safeguarded by the other Party (the "Receiving Party") and its Affiliates,
using commercially reasonable efforts, but in any event no less than in the same manner and the same
protections with which the Receiving Party maintains its own confidential information; and

(b) the Receiving Party may only use any such Confidential Information for the purposes of
performing its obligations or exercising its rights under this Agreement or any Ancillary Agreement.

11.2 Exceptions. The foregoing obligations shall not apply to the extent that the Receiving Party
can demonstrate that any information:

(a) is known by the Receiving Party at the time of its receipt without an obligation of
confidentiality with respect to such information, and not through a prior disclosure by the
Disclosing Party;

(b) is in the public domain before its receipt from the Disclosing Party, or thereafter enters the
public domain through no fault of the Receiving Party;

(c) is subsequently disclosed to the Receiving Party by a Third Party who may lawfully do so and is
not under an obligation of confidentiality to the Disclosing Party with respect to such information;
or

(d) is developed by the Receiving Party independently and without use of or reference to any
Confidential Information received from the Disclosing Party.

Any combination of features or disclosures shall not be deemed to fall within the foregoing
exclusions merely because individual features are published or available to the general public or in
the rightful possession of the Receiving Party unless the combination itself and principle of
operation are published or available to the general public or in the rightful possession of the
Receiving Party.

11.3 Authorized Disclosures. Notwithstanding the obligations set forth in Sections 11.1 and 11.5, a
Party may disclose the other Party's Confidential Information (including this Agreement and the
terms herein) to the extent:

(a) such disclosure: (i) is reasonably necessary for the filing or prosecuting Patent Rights as
contemplated by Article X; (ii) is reasonably necessary in connection with regulatory filings for
the Products in the Field consistent with this Agreement; or (iii) is made to any Third Party bound
by written obligations of confidentiality and non-use similar to those set forth under this Article
XI, to the extent otherwise necessary or appropriate in connection with the exercise of its rights
or the performance of its obligations hereunder or under any Ancillary Agreement;

(b) such disclosure is reasonably necessary: (i) to its and its Affiliates', Sublicensees' and
Distributors' employees and subcontractors in connection with the exercise of its rights or the
performance of its obligations hereunder or under any Ancillary Agreement; (ii) to such Party's
directors, attorneys, independent accountants or financial advisors for the sole purpose of enabling
54

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 55 -->
such directors, attorneys, independent accountants or financial advisors to provide advice to such
Party relating to this Agreement; or (iii) to actual or potential investors or Acquirers of such
Party solely for the purpose of evaluating or carrying out a bona fide investment in or acquisition
of such Party; provided that in each case, (i), (ii) and (iii), such party(ies) to whom disclosure
is made under this Section 11.3(b) shall be bound by confidentiality and non-use obligations
substantially consistent with those contained in the Agreement; or

(c) such disclosure is required by Applicable Law, rules of a securities exchange or judicial or
administrative process or is reasonably necessary for prosecuting or defending litigation under
Article X or Article XIV; provided that in such event such Party (to the extent legally permissible)
shall promptly inform the other Party of such required disclosure and use reasonable efforts to
provide the other Party an opportunity to challenge or limit the disclosure obligations; provided,
further that Confidential Information disclosed shall be limited to that information which is
required under the relevant Applicable Law, rule, judicial or administrative process or court or
governmental order. Confidential Information that is so disclosed shall remain otherwise subject to
the confidentiality and non-use provisions of this Article XI, provided that the Party disclosing
Confidential Information in such situation shall use reasonable efforts, including seeking
confidential treatment or a protective order, to seek and obtain continued confidential treatment of
such Confidential Information.

11.4 Publications. The JRDC shall, directly or through a subcommittee (a) discuss and approve a
publication strategy and plan with respect to Development activities hereunder (including details of
the Parties' participation in appropriate conferences and scientific or medical publications
relating to Products and processes for review of proposed Publications by each Party) and (b) review
and comment on and approve any Publication relating to the scientific or medical aspects of the
Products in accordance with such strategy, and if applicable coordinate such review and comment
process with the JCC. The Parties acknowledge RevMed's interest in publishing the results of the
Research and Development activities under this Agreement in order to obtain recognition within the
scientific, medical or other applicable community, to advance the state of knowledge in the field,
and RevMed's need to fulfill its obligations to principal investigators and researchers with respect
to publications under its relevant agreements; the need to protect Confidential Information; and the
Parties' mutual interest in obtaining valid patent protection and protecting reasonable business
interests and trade secret information. Consequently, each Party and their Affiliates, employee(s)
and consultant(s) shall deliver to the JRDC or the applicable subcommittee, and if applicable to the
JCC, for review and comment a copy of any proposed Publication that pertains to SHP2 inhibition or
any SHP2 Inhibitor or Product using Commercially Reasonable Efforts to provide such copy at least
[***] (but in no event less than [***] unless otherwise agreed by the Parties) prior to its intended
submission or publication, and in accordance with the applicable strategy determined by the JRDC and
the ICMJE guidelines or other similar guidelines. The non-publishing Party shall have the right to
require reasonable modifications of the Publication: (a) to protect the non-publishing Party's
Confidential Information or trade secrets; or (b) to delay such submission for a reasonable time
period (not to exceed [***]) as may be reasonably necessary to seek patent protection for the
information disclosed in such proposed submission to the extent consistent with Article X. 55

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 56 -->
11.5 Publicity; Use of Names.

(a) The Parties have agreed to issue a joint press release or separate press releases announcing
this Agreement, subject to mutual agreement by the Parties with respect to the content thereof and
issued at a mutually agreed date and time. Subject to Sections 11.3 and 11.4 above and the remainder
of this Section 11.5, (i) no other disclosure of the existence or the terms of this Agreement or
otherwise relating to this Agreement or the activities hereunder may be made by either Party or its
Affiliates, and (ii) no Party shall use the name, trademark, trade name or logo of the other Party,
its Affiliates or their respective employees in any publicity, promotion, news release or disclosure
relating to this Agreement or its subject matter, except in each case (i) and (ii) as provided in
this Section 11.5 or as otherwise provided in this Agreement or any Ancillary Agreement or with the
prior express written permission of the other Party, except as may be required by Applicable Law.

(b) If a Party is required by Applicable Law, rule or regulation to make a securities filing
relating to the signing or effectiveness of this Agreement, or to the terms of this Agreement, with
the appropriate Governmental Authorities (including the U.S. Securities and Exchange Commission, and
any securities exchange on which securities of such Party are listed), then the Party under such
requirement will prepare a draft of such securities filing for review and comment by the other
Party. If such securities filing includes the disclosure of this Agreement and its terms, the Party
under such disclosure obligation will submit a confidential treatment request and a proposed
redacted version of this Agreement as part of such draft. Such draft securities filing will, where
possible, be provided to the other Party reasonably in advance of the deadline for such securities
filing, and the other Party agrees to promptly (and in any event, no less than [***] (or such
shorter time to meet any filing deadline where it was not possible to provide the other Party with
[***] notice) after receipt of such confidential treatment request and proposed redactions) give its
input in a reasonable manner in order to allow the Party seeking disclosure to file its request
within the timelines proscribed by the regulations of applicable Governmental Authorities or
securities exchange. The Party seeking such disclosure will use reasonable efforts to obtain
confidential treatment of this Agreement from the applicable Governmental Authority or securities
exchange as represented by the redacted version reviewed by the other Party, provided that the Party
seeking such disclosure shall, notwithstanding the foregoing, at all times have the right to submit
such disclosure in accordance with such requirement prior to or on the relevant deadline therefor.

(c) At any time after the release of the initial press release(s) described in Section 11.5(a), each
Party shall notify the other Party if it desires to disclose publicly (including on its website) any
of the following: [***]. For clarity, this Section 11.5 does not apply to scientific or medical
Publications, which are governed by Section 11.4. If the other Party also desires to make such a
public disclosure, the Parties will coordinate and agree upon the form, content and timing of such
disclosure. If the other Party does not desire to make such a public disclosure, the requesting
Party may nonetheless make such disclosure so long as it provides the other Party with a draft of
such disclosure at least [***] prior to its intended release for such other Party's review and
comment. The non-disclosing Party shall have the right to require reasonable modifications of the
disclosure: (a) to protect the non- publishing Party's Confidential Information or trade secrets; or
(b) to delay such disclosure for a reasonable time period (not to exceed [***]) as may be reasonably
necessary to seek patent protection for the information disclosed in such proposed submission to the
extent consistent with Article X. If either Party requests to make any other disclosure with respect
to this Agreement or the Collaboration (including any public statement or press release) that is not
otherwise permitted under this Agreement, the other Party shall reasonably consider such request. 56

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 57 -->
11.6 Return of Confidential Information. Upon the effective date of the termination of this
Agreement for any reason in its entirety, or with respect to a Product, either Party may request in
writing and the non-requesting Party shall (at the non-requesting Party's election), with respect to
Confidential Information to which such non-requesting Party does not retain rights under the
surviving provisions of this Agreement (if applicable, with respect to the terminated Region or
terminated Product) promptly destroy all copies of such Confidential Information in the possession
or control of the non-requesting Party and confirm such destruction in writing to the requesting
Party. Notwithstanding the foregoing, the non-requesting Party shall be permitted to retain such
Confidential Information (i) to the extent necessary or useful for purposes of performing any
continuing obligations or exercising any ongoing rights hereunder and, in any event, a single copy
of such Confidential Information for archival purposes and (ii) any computer records or files
containing such Confidential Information that have been created solely by such non-requesting
Party's automatic archiving and back-up procedures, to the extent created and retained in a manner
consistent with such non-requesting Party's standard archiving and back-up procedures, but not for
any other uses or purposes. All Confidential Information shall continue to be subject to the terms
of this Agreement for the period set forth in Section 11.1.

11.7 Attorney-Client Privilege. As to any Third Party, neither Party is waiving, nor shall be deemed
to have waived or diminished, any attorney work product protection or attorney-client privilege as a
result of disclosing information pursuant to this Agreement, or any Confidential Information
(including Confidential Information related to pending or threatened litigation) to the Receiving
Party, regardless of whether the Disclosing Party has asserted, or is or may be entitled to assert,
such privileges and protections. The Parties: (a) share a common legal and commercial interest in
such information to the extent available under Applicable Law that is subject to such privileges and
protections; (b) are or may become joint defendants in proceedings to which the information covered
by such protections and privileges relates; (c) intend that such privileges and protections remain
intact should either Party become subject to any actual or threatened proceeding initiated by or
against a Third Party to which the Disclosing Party's Confidential Information covered by such
protections and privileges relates; and (d) intend that after the Effective Date both the Receiving
Party and the Disclosing Party shall have the right to assert such protections and privileges as
against a Third Party to the extent available under Applicable Law. In the event of any litigation
(or potential litigation) with a Third Party related to this Agreement or the subject matter hereof,
the Parties shall, upon either Party's request, enter into a reasonable and customary joint defense
agreement. Each Party shall consult in a timely manner with the other Party before producing
information or documents in connection with litigation or other proceedings brought by or initiated
against a Third Party that would likely implicate privileges maintained by the other Party.
Notwithstanding anything contained in this Section 11.7, nothing in this Agreement shall prejudice a
Party's ability to take discovery of the other Party in disputes between them relating to the
Agreement and no information otherwise admissible or discoverable by a Party shall become
inadmissible or immune from discovery, including without limitation based on an assertion of
attorney work product protection or attorney-client privilege, solely by this Section 11.7. 57

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 58 -->
11.8 Permitted Disclosure for CREATE Act. In order for a Party to exercise its rights under Section
10.3, such Party shall be allowed to disclose in a patent application it prepares and files pursuant
to this Agreement the names of the Parties to this Agreement, or amends a pending application it is
prosecuting pursuant to this Agreement to state the names of the Parties to this Agreement.

Article XII.

TERM AND TERMINATION

12.1 Term. The term of this Agreement shall commence upon the Effective Date and, unless earlier
terminated pursuant to this Article XII, shall continue in full force and effect until the
expiration of Sanofi's payment obligations under Article IX or the Profit/Loss Share Agreement,
whichever is later (the "Term").

12.2 Termination.

(a) Terminations by Sanofi.

(i) Termination by Sanofi for Convenience. Sanofi may terminate this Agreement (A) in its entirety
by providing [***] written notice of termination to RevMed or (B) on a country-by-country or
Product-by-Product basis by providing [***] written notice of termination to RevMed; provided that
if Sanofi desires to terminate this Agreement under this Section 12.2(a)(i)B only with respect to
the U.S. (for all Products or one or more Products), Sanofi shall provide [***] written notice of
termination to RevMed.

(ii) For a Change of Control of RevMed. RevMed will notify Sanofi in writing as soon as possible
after RevMed announces publicly any information regarding any proposed Change of Control of RevMed
(or if the Change of Control will not be publicly announced, then no later than [***] after the
signing of the Change of Control). Sanofi will have the option to either (A) terminate this
Agreement in its entirety upon written notice to RevMed provided to RevMed within [***] of the
effective date of such Change of Control; or (B) [***].

(iii) For Safety. Sanofi will have the right to terminate this Agreement in its entirety or on a
country-by-country or Product-by-Product basis, upon [***] prior written notice to RevMed, due to
safety concerns raised by a Regulatory Authority, an Institutional Review Board for a Clinical Trial
or by Sanofi's internal regulatory decision makers acting in accordance with Sanofi's standard
internal policies (any such entity or group, a "Safety Reviewer"), where such Safety Reviewer
recommends cessation of Development or Commercialization of such SHP2 Inhibitor or Product with
respect to any SHP2 Inhibitor or Product (and a summary of such concerns will be stated in the
notice of termination). During such [***] notice period, each Party will continue to perform all of
its obligations under this Agreement then in effect. 58

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 59 -->
(b) Termination for Material Breach. If either Party believes that the other is in material breach
of this Agreement, then the non-breaching Party may deliver notice of such breach to the other
Party. For all material breaches other than a failure to make a payment as set forth in this
Agreement, the allegedly breaching Party shall have [***] from such notice to dispute or cure such
breach. For any material breach arising from a failure to make a payment set forth in this
Agreement, the allegedly breaching Party shall have [***] from the receipt of the notice to dispute
or cure such breach. If the Party receiving notice of material breach under this Agreement fails to
cure, or fails to dispute, such breach within the applicable time period set forth above, then the
Party originally delivering the notice of material breach may terminate this Agreement effective on
written notice of termination to the other Party. If the allegedly breaching Party in good faith
disputes such material breach or disputes the failure to cure or remedy such material breach and
provides written notice of that dispute to the other Party within the applicable period set forth
above, the matter shall be addressed under the dispute resolution provisions in Section 15.6. During
the pendency of any such dispute, all of the terms and conditions of this Agreement will remain in
effect and the Parties will continue to perform all of their respective obligations hereunder.

(c) Termination for Insolvency. In the event that either Party (i) files for protection under
bankruptcy or insolvency laws, (ii) makes an assignment for the benefit of creditors, (iii) appoints
or suffers appointment of a receiver or trustee over substantially all of its property that is not
discharged within [***] after such filing, (iv) proposes a written agreement of composition or
extension of its debts, (v) proposes or is a party to any dissolution or liquidation, (vi) files a
petition under any bankruptcy or insolvency act or has any such petition filed against it that is
not charged within [***] of the filing thereof or (vii) admits in writing its inability generally to
meet its obligations as they fall due in the general course, then the other Party may terminate this
Agreement in its entirety effective immediately upon writing notice to such Party.

(d) Termination for Competing Product of Sanofi. If after [***]: (i) Sanofi or its Affiliates, alone
or with or through a Third Party, develop, manufacture or commercialize a Competing Product and (ii)
Sanofi or its Affiliates have not commenced a Registrational Clinical Trial for a Product prior to
commencing the activities in Section 12.2(d)(i), RevMed may terminate this Agreement effective [***]
after it delivers written notice to Sanofi that it is exercising its rights under this Section
12.2(d) unless Sanofi elects in writing within such [***] period to [***].

(e) Termination for Sanofi's Decision to Cease [***] of Product.

(i) If at any time during the period commencing on the Effective Date, there is a consecutive [***]
period during which Sanofi [***] and such [***] is not (A) by written agreement of the Parties, (B)
a result of [***], (C) as a result of [***], (D) a result of [***], or (E) a direct result, in whole
or in part, of [***], then RevMed shall promptly notify Sanofi in writing upon becoming aware of
such [***]. Alternatively, RevMed, no more often than [***], may request for Sanofi to notify RevMed
whether there has been any [***] and Sanofi shall respond to such request within [***], providing
reasonable support for any assertion that [***]. Within another [***] following either receipt of
notice from RevMed or receipt of any such response from Sanofi confirming [***], as applicable, the
Parties shall meet (which may be by teleconference) to discuss the nature and circumstances
surrounding such [***]. Sanofi shall have [***] from such meeting date to cure such [***]. If Sanofi
fails to cure such [***] within such [***] period, RevMed may terminate this Agreement upon written
notice to Sanofi. 59

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 60 -->
(ii) If RevMed reasonably believes a [***] is likely to occur but it has not yet been [***], RevMed
may, no more than [***] per Calendar Year, request for the Parties to discuss such potential [***]
and Sanofi's intended plans with respect to [***], provided that, for clarity, such discussion shall
not be deemed to accelerate the timeframes specified above in Section 12.2(a).

12.3 Effects of Expiration or Termination.

(a) General. Upon termination or expiration of this Agreement with respect to any particular Product
or country, all rights and obligations of the Parties under this Agreement with respect to such
Product or country shall cease except as otherwise set forth in this Section 12.3 or elsewhere in
this Agreement, but, for clarity, such termination or expiration shall not affect the Parties'
rights and obligations under this Agreement with respect to the other Products or countries.

(b) Effect of Expiration. Upon expiration of this Agreement, the licenses granted to Sanofi under
Section 3.1 will become fully paid up, royalty free, perpetual and irrevocable.

(c) Effect of Termination by Sanofi for Convenience, Change of Control or Termination by RevMed for
Sanofi's Material Breach, Insolvency, Competing Product, or Cessation of [***]. Upon the termination
of this Agreement by Sanofi pursuant to Section 12.2(a)(i) (Termination by Sanofi for Convenience)
or Section 12.2(a)(ii)A (Termination by Sanofi for Change of Control of RevMed) or by RevMed
pursuant to Section 12.2(b) (Termination for Material Breach), 12.2(c) (Termination for Insolvency),
12.2(d) (Termination for Competing Product of Sanofi) or 12.2(e) (Termination for Sanofi's Decision
to Cease [***] of Product), the following provisions shall apply:

(i) License to Sanofi. All licenses and other rights granted to Sanofi under the RevMed Licensed
Technology shall terminate (except as necessary to permit Sanofi to perform its surviving
obligations under this Article XII) and all rights thereunder shall revert to RevMed.

(ii) Licenses.

A. License Grants.

1. RevMed License to SHP2 Inhibitors. Sanofi shall, effective upon any such termination of this
Agreement, and hereby does, grant to RevMed [***], under all [***], and [***], to [***].
Notwithstanding the foregoing, [***] shall not include [***], and [***] shall include [***] (to the
extent [***]).

2. RevMed License to Practice Certain Combinations. Sanofi shall, effective upon any such
termination of this Agreement, and hereby does, grant to RevMed [***], under [***], and [***] (but
excluding [***]). For the avoidance of doubt, [***] licensed under this Section 12.3(c)(ii)(A)(2) do
not [***]. 60

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 61 -->
3. Sanofi License to Practice Certain Combinations. [***] RevMed shall, effective upon any such
termination of this Agreement, and hereby does, grant to Sanofi [***], under [***], and [***]. For
the avoidance of doubt, [***] licensed under this Section 12.3(c)(ii)(A)(3) do not [***]. If Sanofi
[***], Sanofi shall so notify RevMed in writing, and [***].

B. Third Party Restrictions. If the rights licensed to RevMed pursuant to subsection A are
sublicensed to RevMed under an agreement between Sanofi and a Third Party, then Sanofi shall so
notify RevMed within [***] after the effective date of termination of this Agreement, and the
foregoing licenses shall be subject to the applicable provisions of such Third Party agreement
(including any applicable payment obligations to the extent arising from the exercise of RevMed's
practice of its license under subsection A). RevMed shall have the right to terminate all or any
portion of the rights granted to it under subsection A, upon written notice to Sanofi.

C. Royalties. If this Agreement is terminated in its entirety or with respect to one or more
Products, other than by RevMed pursuant to Section 12.2(b) (Termination for Material Breach) or
12.2(c) (Termination for Insolvency), RevMed shall pay to Sanofi on a Product-by-Product basis
royalties on sales of terminated Products (such Products, which for the purpose of clarity shall not
include any Non-SHP2 Product, hereinafter referred to as "Termination Products"), calculated based
on worldwide Net Sales (as such term is applied mutatis mutandis to RevMed and including sales in
the U.S.) by RevMed and its Affiliates and Sublicensees of such Termination Products as follows:
[***]. RevMed shall pay Sanofi such royalties until the earlier of (x) expiration of the
Post-Termination Royalty Term therefor and (y) a Change of Control of Sanofi. Upon any termination
of this Agreement, RevMed shall pay to Sanofi any amounts owed to Third Parties under license
agreements to which Sanofi is a party that grant Sanofi a license under such Third Party's Patent
Rights or Know-How that is sublicensed to RevMed pursuant to Section 12.3(c)(ii)A, unless RevMed
declines in writing to obtain such sublicense. "Post-Termination Royalty Term" means: (I) with
respect to a particular country and a particular Termination Product that is the subject of the
royalty obligations under Section 12.3(c)(ii)B(1), the period of time commencing upon the First
Commercial Sale of such Termination Product in such country (by RevMed or its Affiliates or
sublicensees) and ending upon the latest of (a) the date on which there is no Valid Claim (as such
term is applied mutatis mutandis to Sanofi Sole Program Patents) of a Sanofi Sole Program Patent
that would be infringed by the sale of such Termination Product in such country; (b) the expiration
of any Regulatory Exclusivity granted with respect to such Termination Product in such country[***]
and (II) with respect to a particular country and a particular Termination Product that is subject
of the royalty obligations under Section 12.3(c)(ii)B(2) or Section 12.3(c)(ii)B(3), the period of
time commencing upon the First Commercial Sale of such Termination Product in such country (by
RevMed or its Affiliates or sublicensees) and ending upon the latest of (a) the expiration of any
Regulatory Exclusivity granted with respect to such Termination Product in such country; and (b)
[***]. 61

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 62 -->
(iii) Inventory Sell-Off Period. In the case of a termination of this Agreement, Sanofi (with
respect to the Termination Products in the Licensed Territory), shall be entitled, for a period of
[***] after termination, to (i) complete Manufacture of work-in-progress, and (ii) continue
conducting Commercialization activities being conducted by Sanofi hereunder as of such termination
(if applicable, with respect to the terminated country(ies)), to the extent related to such
Termination Product in Sanofi's inventory as of such termination (or added to such inventory as a
result of the completion described in clause (i)), provided that Sanofi fulfills its payment
obligations under this Agreement in connection with such inventory sell-off, provided further that
the sharing of Net Profits and Net Losses under the Profit/Loss Share Agreement shall continue to
apply during the sell-off period. For clarity, from and after the expiration of such [***] period
all rights and licenses granted to Sanofi hereunder (if applicable, with respect to the terminated
country(ies)) shall terminate (except as necessary to permit Sanofi to perform its obligations under
this Article XII).

(iv) Regulatory Materials; Data. Within [***] after the effective date of such termination for
Termination Products for which Regulatory Approval has been obtained prior to the effective date of
such termination or [***] for other Termination Products (or as promptly as practical thereafter, if
such period is not practical under Applicable Law), Sanofi shall transfer and assign to RevMed all
Regulatory Approvals relating to such Termination Products, and, to the extent not previously
provided to RevMed, transfer other Regulatory Materials including data from preclinical,
non-clinical and clinical studies conducted by or on behalf of Sanofi, its Affiliates or
Sublicensees on such Termination Products and all pharmacovigilance data (including all adverse
event databases) on such Termination Products. In addition, subject to any applicable provisions of
any Third Party contract manufacturing agreement, Sanofi shall, or cause its Affiliate or Third
Party contract manufacturer to, grant RevMed and any of its Affiliates and Third Party contract
manufacturer the right to reference any and all drug master files pertaining to Termination Products
within the foregoing time period for the relevant Termination Products. At RevMed's reasonable
request, for a period not to exceed [***] following the effective date of termination, Sanofi shall
provide RevMed with assistance up to a total of [***] with any inquiries and correspondence with
Regulatory Authorities relating to any such Termination Product. [***] The foregoing shall not apply
to the extent containing proprietary information or technology of any Third Party relating to
proprietary active ingredients contained in Combination Products or any Non-SHP2 Products, provided
that Sanofi shall, for any Combination Products, upon written request by RevMed and to the extent
permitted by the terms of its Third Party agreements, provide reasonable assistance to RevMed to
enable RevMed to access such information or technology by, for example, facilitating introductions
to and discussions with the relevant Third Party with respect to such information or technology,
provided that such assistance shall count toward the [***] total set forth in the preceding
sentence.

(v) Trademarks. Sanofi shall transfer and assign, and shall ensure that its Affiliates transfer and
assign, to RevMed, at no cost to RevMed, all Product Marks exclusively relating to any Termination
Product, provided that such Product Marks do not contain the business entity names of Sanofi or its
Affiliates or variations thereof, except as may otherwise be required by Applicable Law during a
transition period to avoid any interruptions in supply of Termination Product to patients. In such
case if requested by Sanofi, RevMed shall sign a non-royalty bearing trademark license agreement in
the form mutually agreed by the Parties, as requested by Sanofi. 62

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 63 -->
(vi) Transition Assistance. With regard to Termination Products in countries for which the licenses
to Sanofi are terminating, Sanofi shall provide the following transitional assistance, with costs
allocated as set forth below:

A. Each Party shall comply with Section 11.6 with regard to each Party's Confidential Information.

B. To the extent Sanofi has the right to do so, Sanofi shall promptly provide RevMed with a copy
(which may be redacted in Sanofi's discretion if required to protect confidential information of
Sanofi or a Third Party) of each license agreement, collaboration agreement or vendor agreement then
effective between Sanofi (or its Affiliates) and a Third Party that exclusively relates to any
Termination Product, or the Development, Manufacture and Commercialization thereof, and, upon
RevMed's request, to the extent Sanofi has the right to do so, Sanofi shall assign or sublicense,
and shall ensure that its Affiliates assign or sublicense, to RevMed any such agreement(s). If
Sanofi does not have the right to do so, Sanofi will provide RevMed with contact information for
such Third Party so that RevMed may pursue an agreement directly with such licensor, collaborator or
vendor with respect to Termination Products.

C. Sanofi shall, at RevMed's request, for a period not to exceed [***] following the effective date
of termination, provide reasonable technical assistance up to a total of [***] and, to the extent
not already provided to RevMed, transfer copies of (including when available, in electronic format)
all Sanofi Sole Program Know-How to RevMed or its designee, including without limitation: [***], in
each case to the extent such materials are exclusively related to the Termination Product. All such
Know-How so provided to RevMed shall be deemed Confidential Information of Sanofi. Furthermore,
Sanofi shall within [***] after the effective date of such termination, transfer to RevMed all files
and documents relating to the prosecution, defense or enforcement of the RevMed Licensed Patents or
Joint Program Patents and provide reasonable assistance for a period not to exceed [***] following
the effective date of termination, up to a total of [***], in the transfer of the prosecution,
defense and enforcement responsibilities to RevMed, including by executing any documents reasonable
necessary therefor.

D. At the end of the sell-off period set forth in Section 12.3(c)(iii), Sanofi shall transfer to
RevMed any and all inventory of SHP2 Inhibitors and Termination Products (including all research
materials, final product, bulk drug substance, intermediates, work-in-process, formulation
materials, reference standards, drug product clinical reserve samples, packaged retention samples,
and the like) then in the possession of Sanofi, its Affiliates or Sublicensees, and continue or have
continued any ongoing stability studies pertaining to any materials so transferred to RevMed for a
reasonable period of time until RevMed can assume responsibility for such activities.
Notwithstanding the allocation of costs described below, all such inventory shall be purchased by
RevMed at a price equal to [***].

E. If at the time of such termination, RevMed or its Affiliates are not Manufacturing a particular
Termination Product, then, at RevMed's request, Sanofi shall: (1) [***], provided that Sanofi shall
in no case be obligated to [***], and provided further that such [***]; and (2) if it has the right
to do so, assign or transfer to RevMed any Manufacturing agreement between Sanofi and a Third Party
contract manufacturer with respect to such Termination Product; or (3) conduct a technology transfer
analogous to that described in Section 7.2. 63

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 64 -->
F. If at the time of such termination, Sanofi or its Affiliates are conducting any Clinical Trials
(including Registrational Clinical Trials) of a Termination Product, then, at RevMed's election on a
trial-by-trial basis, Sanofi shall cooperate, and shall ensure that its Affiliates cooperate, with
RevMed to transfer the conduct of all such Clinical Trials to RevMed within [***] after the
effective date of such transfer (to the extent practical in light of applicable regulatory and
patient safety concerns) and RevMed shall assume any and all liability, and is liable, for such
Clinical Trials conducted after the effective date of such termination (except to the extent Sanofi
has an obligation of indemnification under Article XIV existing for a claim that arose prior to the
effective date of such termination).

G. If at the time of such termination, Sanofi or its Affiliates are Commercializing a particular
Termination Product, then, at RevMed's request, the Parties shall negotiate in good faith a
transition services agreement to cover detailing and promotion of such Termination Product (in the
same manner and no more extensive than the then-current detailing and promotional efforts of Sanofi)
by Sanofi or its Affiliate or contract sales force pursuant to a transition plan agreed by the
Parties for a period not to exceed [***], and RevMed shall pay Sanofi a commercially reasonable
amount to conduct such activities (which amount would include a commercially reasonable per-detail
rate).

H. In addition to the foregoing, Sanofi shall use reasonable efforts with respect to those
activities for which it is responsible hereunder to cooperate with RevMed to achieve an orderly
transition of the Development, Manufacturing and Commercialization of Termination Products from
Sanofi or its applicable Affiliate to RevMed.

I. Except as provided in Sections 12.3(c)(vi)D-E, Sanofi's activities under this Section 12.3(c)(vi)
shall be conducted [***].

(d) Effect of Termination by Sanofi for Safety or for RevMed's Material Breach or Insolvency. Upon
termination of this Agreement by Sanofi pursuant to Section 12.2(a)(iii) (Termination by Sanofi for
Safety), Section 12.2(b) (Termination for Material Breach) or 12.2(c) (Termination for Insolvency),
the following provisions shall apply:

(i) License to Sanofi. All licenses and other rights granted to Sanofi under the RevMed Licensed
Technology under this Agreement shall terminate (except as necessary to permit Sanofi to perform its
surviving obligations under this Article XII) and all rights thereunder shall revert to RevMed;
provided, however, RevMed shall, effective upon any such termination of this Agreement, and hereby
does, grant to Sanofi a non- exclusive, worldwide license, with the right to grant sublicenses to
contractors and otherwise only with RevMed's prior written consent, under each (1) RevMed Program
Invention and (2) [***]. For the avoidance of doubt, the Patent Rights licensed under this Section
12.3(d)(i) do not include any [***]. 64

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 65 -->
(ii) Inventory Sell-Off Period. In the case of a termination of this Agreement, Sanofi (with respect
to the Termination Products in the Licensed Territory), shall be entitled, for a period of [***]
after termination, to (i) complete Manufacture of work-in-progress, and (ii) continue conducting
Commercialization activities being conducted by Sanofi hereunder as of such termination (if
applicable, with respect to the terminated country(ies)), to the extent related to Termination
Product in Sanofi's inventory as of such termination (or added to such inventory as a result of the
completion described in clause (i)), provided that Sanofi fulfills its payment obligations under
this Agreement in connection with such inventory sell-off, provided further that the payment of
royalties to RevMed and the sharing of Net Profits and Net Losses under the Profit/Loss Share
Agreement shall continue to apply during the sell-off period. For clarity, from and after the
expiration of such [***] period all rights and licenses granted to Sanofi hereunder (if applicable,
with respect to the terminated country(ies)) shall terminate (except as necessary to permit Sanofi
to perform its obligations under this Article XII).

(iii) Regulatory Materials; Data. Within [***] of the effective date of such termination (or as
promptly as practical thereafter, if such period is not practical under Applicable Law), [***],
Sanofi shall transfer and assign to RevMed all Regulatory Approvals relating to Termination
Products, and, to the extent not previously provided to RevMed, transfer other Regulatory Materials
including data from preclinical, non-clinical and clinical studies conducted by or on behalf of
Sanofi, its Affiliates or Sublicensees on any Termination Products and all pharmacovigilance data
(including all adverse event databases) on any Termination Products.

(iv) Trademarks. [***], Sanofi shall transfer and assign, and shall ensure that its Affiliates
transfer and assign, to RevMed, [***], all Product Marks exclusively relating to any Termination
Product, provided that such Product Marks do not contain the business entity names of Sanofi or its
Affiliates or variations thereof.

(e) Effect of Termination by Sanofi of [***] for Change of Control of RevMed. Upon termination of
[***] by Sanofi pursuant to Section 12.2(a)(ii)B (Termination by Sanofi for Change of Control) in
the case of an Acquiror of RevMed that is a Major Biopharmaceutical Company, RevMed, [***], will (1)
make available to Sanofi copies of [***], (2) provide Sanofi with copies of [***], (3) provide
Sanofi with all [***], and (4) otherwise provide Sanofi all reasonable assistance in [***].
Furthermore, in such case, except for [***], all Committees shall [***].

12.4 Survival. The following Sections and Articles shall survive the termination or expiration of
this Agreement: Articles I (Definitions) (to the extent necessary to give effect to the other
Sections and Articles that survive under this Section 12.4) and XV (General Provisions) and Sections
5.8 (Development Records) (for the period stated therein), 9.8 (Records) (for the period stated
therein), 11.1 (Duty of Confidence), 11.2 (Exceptions), 11.3 (Authorized Disclosures), 11.5(a) and
11.5(b) (Publicity; Use of Names), 11.6 (Return of Confidential Information), 11.7 (Attorney-Client
Privilege), 11.8 (Permitted Disclosures for CREATE Act), 12.3 (Effects of Expiration or
Termination), 12.4 (Survival), 12.5 (Accrued Rights and Obligations), 12.6 (Termination Not Sole
Remedy), 14.1 (Indemnification by RevMed) (as to activities conducted during the Term), 14.2
(Indemnification by Sanofi) (as to activities conducted during the Term), 14.3 (Indemnification
Procedure), 14.4 (Mitigation of Loss), and 14.5 (Limitation of Liability). 65

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 66 -->
12.5 Accrued Rights and Obligations. Expiration or termination of this Agreement shall not diminish
either Party's rights, or relieve either Party of any of its obligations, in each case that have
been accrued prior to the effective date of such expiration or termination.

12.6 Termination Not Sole Remedy. Except as set forth in Section 5.7, termination is not the sole
remedy under this Agreement and, whether or not termination is effected and notwithstanding anything
contained in this Agreement to the contrary, all other remedies shall remain available except as
agreed to otherwise herein.

Article XIII.

REPRESENTATIONS, WARRANTIES AND COVENANTS; CLOSING CONDITIONS

13.1 Representations and Warranties of Each Party. Each Party hereby represents and warrants, as of
the Execution, and covenants (as applicable) to the other Party as follows:

(a) It is a company or corporation duly organized, validly existing, and in good standing under the
laws of the jurisdiction in which it is incorporated, and has the full right, power and authority to
enter into this Agreement, to perform its obligations hereunder.

(b) (i) This Agreement has been duly executed by it and is legally binding upon it, enforceable in
accordance with its terms, (ii) it has taken all necessary corporate action on its part required to
authorize the execution and delivery of this Agreement and, (iii) this Agreement, and the
performance of its obligations hereunder, do not conflict with any agreement, instrument or
understanding, oral or written, to which it is a party or by which it may be bound, nor violate any
material law or regulation of any court, governmental body or administrative or other agency having
jurisdiction over it.

(c) (i) It is familiar with the provisions and restrictions contained in the FCPA and has adopted
and maintains an FCPA policy; (ii) it shall comply with the FCPA in connection with its activities
under this Agreement; (iii) it shall not, in the course of its activities under this Agreement,
offer, promise, give, demand, seek or accept, directly or indirectly, any gift or payment,
consideration or benefit in kind that would or could be construed as an illegal or corrupt practice;
and (iv) it is not a government official (as the term is defined in the FCPA) or affiliated with any
government official.

(d) (i) Neither it nor any of its Affiliates has been debarred or is subject to debarment pursuant
to Section 306 of the FFDCA or analogous provisions of Applicable Law outside the United States or
listed on any Excluded List and (ii) neither it nor any of its Affiliates has, to its knowledge,
used in any capacity, in connection with the activities to be performed under this Agreement, any
individual or entity that has been debarred pursuant to Section 306 of the FFDCA or analogous
provisions of Applicable Law outside the United States, or that is the subject of a conviction
described in such Section or analogous provisions of Applicable Law outside the United States, or
listed on any Excluded List.

(e) It will maintain throughout the Term all permits, licenses, registrations and other forms of
authorizations and approvals from any Governmental Authority, necessary or required to be obtained
or maintained by such Party in order for such Party to execute and deliver this Agreement and to
perform its obligations hereunder in a manner which complies with all Applicable Law. 66

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 67 -->
13.2 Representations and Warranties by RevMed. Except as disclosed in the Disclosure Schedule to
this Agreement in Exhibit N of the Correspondence, RevMed represents and warrants to Sanofi as of
the Execution Date that:

(a) RevMed has not had any Affiliates prior to the Execution Date and does not have any Affiliates
as of the Execution Date;

(b) RevMed is the sole and exclusive owner of all of the RevMed Background Technology, free and
clear or all liens and encumbrances, and no Third Party owns or possesses any right, title or
interest in or to any of the RevMed Licensed Technology existing as of the Execution Date;

(c) RevMed has not previously agreed to or otherwise committed to assign, transfer or convey or
otherwise encumber its rights, title and interests in and to RevMed Licensed Technology existing as
of the Execution Date;

(d) To the Knowledge of RevMed, all Patent Rights owned or Controlled by RevMed, existing as of the
Execution Date, and reasonably necessary or useful for conducting the Collaboration or otherwise
necessary or useful for Researching, Developing, Manufacturing, Commercializing or otherwise
exploiting Product in the Field, including the Development or Manufacture of the Products as
contemplated in the initial Research Plan and Development Plan attached to this Agreement as of the
Execution Date and Commercialization of the Products, as provided hereunder are listed in Exhibit O
of the Correspondence;

(e) RevMed has the right to grant the licenses and other rights expressly granted herein to Sanofi,
and it has not granted any license, right or interest in, to or under the RevMed Licensed Technology
to any Third Party (or agreed to make any such grant) to exploit SHP2 Inhibitors or Products in the
Field;

(f) To RevMed's Knowledge, the research and development of the Development Candidate and use of
RevMed Background Know-How in connection therewith does not infringe the claims of any issued Patent
or published patent application of any Third Party;

(g) The research and development of the SHP2 Inhibitors and use of RevMed Background Know-How in
connection therewith does not misappropriate the Know-How of any Third Party;

(h) The research and development of SHP2 Inhibitors (including pursuant to the activities set forth
in the initial Research Plan and initial Development Plan) does not breach any obligation of
confidentiality or non-use owed by RevMed to a Third Party;

(i) To RevMed's Knowledge, no Third Parties are misappropriating the RevMed Background Know-How and
there are no activities by Third Parties that are infringing the RevMed Background Patents; 67

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 68 -->
(j) There are no judgments or settlements against or owed by RevMed, and to RevMed's Knowledge,
there are no pending claims or litigation or written threats of possible claims or litigation, in
each case relating to the SHP2 Inhibitors or otherwise to RevMed Background Technology;

(k) The issued RevMed Background Patents are valid, enforceable and subsisting, and the pending
applications included in the RevMed Background Patents are being prosecuted in accordance with
Applicable Law in all material respects, and RevMed has presented all relevant references, documents
and information of which it and the inventors are aware to the relevant patent examiners and patent
offices that are required to be so submitted under Applicable Law;

(l) The RevMed Background Patents have been filed and maintained properly and correctly and all
applicable fees have been paid on or before the due date for payment in all material respects;

(m) RevMed has not received any written notice alleging that the RevMed Background Patents, existing
as of the Execution Date, are or would be invalid or unenforceable or that the applications included
in such RevMed Background Patents will not proceed to grant;

(n) There (i) are no actual, pending or, to RevMed's Knowledge, alleged or threatened, adverse
actions, suits, claims, interferences, re-examinations, oppositions, inventorship challenges or
formal governmental investigations involving the RevMed Background Technology that are in or before
any Governmental Authority, and (ii) are no actual, pending or, to RevMed's Knowledge, alleged or
threatened, adverse actions, suits, claims, interferences, re-examinations, oppositions,
inventorship challenges or formal governmental investigations involving the RevMed Licensed
Technology;

(o) The inventions claimed or covered by the RevMed Licensed Technology (i) were not conceived,
discovered, developed or otherwise made in connection with any research activities funded, in whole
or in part, by the federal government of the United States or any agency thereof, (ii) are not a
"subject invention" as that term is described in 35 U.S.C. § 201(e), (iii) are not otherwise subject
to the provisions of the Patent and Trademark Law Amendments Act of 1980, as amended, codified at 35
U.S.C. §§ 200-212, as amended, as well as any regulations promulgated pursuant thereto, including in
37 C.F.R. part 401, and (iv) are not the subject of any licenses, options or other rights of any
other Governmental Authority, within or outside the United States, due to such Governmental
Authority's funding of research and development or otherwise (other than the right to receive
payments or any law of general application that applies to personal property generally, e.g.,
takings laws);

(p) None of the RevMed Background Patents are licensed to RevMed from a Third Party;

(q) There are no exclusivity provisions or any other restrictions in any agreement between RevMed or
its Affiliates, on the one hand, and any Third Party, on the other hand, of any SHP2 Inhibitor or
Product, that would limit Sanofi's ability to exercise its rights under this Agreement; 68

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 69 -->
(r) All current and former officers, employees, and consultants of RevMed who are inventors of or
have otherwise contributed in a material manner to the creation or development of any RevMed
Background Technology have executed and delivered to RevMed an assignment or other agreement
regarding the protection of proprietary information and the assignment to RevMed of inventions or
work product created or generated in the course of employment by or providing services for RevMed,
the current forms of which has been made available for review by Sanofi;

(s) The portions of RevMed Background Know-How that are proprietary to RevMed and unpublished as of
the Execution Date and material to Research, Development, Manufacture or Commercialization of SHP2
Inhibitors or Products in the Field have been kept confidential by RevMed and have only been
disclosed to Third Parties under obligations of confidentiality, and to the Knowledge of RevMed, no
such Third Party has breached any such confidentiality obligation to RevMed;

(t) RevMed has included in the electronic dataroom for this Agreement all information in its
possession that is material to the Research, Development, Manufacture or Commercialization of the
Development Candidate as of the Execution Date, and such information does not contain any untrue
statement(s) of fact, or omit to state any fact(s), in either case that are collectively material to
the Research, Development, Manufacture or Commercialization of the Development Candidate; and

(u) To RevMed's Knowledge, RevMed and its contractors and consultants have conducted all research
and development of the SHP2 Inhibitors and Products in material compliance with all Applicable Laws.

13.3 Covenants by RevMed. RevMed covenants to Sanofi that:

(a) RevMed will not, and will cause its Affiliates not to, grant a lien on the RevMed Licensed
Technology to any Third Party or knowingly permit a lien to be imposed on the RevMed Licensed
Technology other than those disclosed to Sanofi by RevMed and that do not conflict with the rights
granted Sanofi hereunder.

(b) RevMed will not, and will cause its Affiliates and (sub)contractors not to, use any government
or not-for-profit organization funding that would encumber the RevMed Licensed Technology without
the prior written consent of Sanofi, which consent may be withheld in Sanofi's sole discretion. For
clarity, this Section 13.3(b) does not apply to Permitted Contractors and Researchers.

(c) At any time upon written request from Sanofi, if the Parties mutually agree that an agreement
between RevMed and a Permitted Contractor or Researcher should be amended to optimize language
regarding assignment of inventions or intellectual property to ensure conformance with the
principles relating thereto set forth in this Agreement, RevMed will use Commercially Reasonable
Efforts to cause such Permitted Contractors or Researchers to sign written agreements substantially
in the form agreed upon by the Parties. 69

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 70 -->
(d) With respect to the sponsored research agreements of RevMed in effect as of the Effective Date,
if after the Effective Date, there is a material amendment or modification to any such sponsored
research agreement or work plan thereunder, and if Sanofi in good faith desires to assume and
perform the subject research in-house and if Sanofi reasonably possesses the relevant expertise,
capacity and applicable materials necessary for such research at such time (the "Capabilities"),
then Sanofi shall notify RevMed and if RevMed does not give notice to terminate such sponsored
research agreement to the applicable Third Party under such agreement within [***] after Sanofi
reasonably demonstrates that it has the Capabilities for such research activities, then RevMed shall
obtain a license to the intellectual property rights in any inventions arising out of such sponsored
research such that they are "Controlled" by RevMed for purposes of this Agreement and RevMed shall
[***].

13.4 Mutual Covenants.

(a) No Debarment. In the course of the Research, Development, Manufacture and Commercialization of
the Products, neither Party nor its Affiliates shall use any employee or consultant who has been
debarred by any Regulatory Authority or, to such Party's or its Affiliates' Knowledge, is the
subject of debarment proceedings by a Regulatory Authority. Each Party shall notify the other Party
promptly upon becoming aware (in the case of Sanofi, by its compliance department) that any of its
or its Affiliates' employees or consultants has been debarred or is the subject of debarment
proceedings by any Regulatory Authority.

(b) Compliance. Each Party and its Affiliates shall comply in all material respects with all
Applicable Law (including all anti-bribery laws and laws applicable to the manufacture of human
pharmaceuticals) in the Research, Development, Manufacture and Commercialization of the Products and
performance of its obligations under this Agreement and the Ancillary Agreements.

(c) Information. In addition to the requirements of Section 6.5, each Party will provide the other
Party with all information in its control reasonably necessary or desirable for such other Party to
comply with its pharmacovigilance responsibilities in all countries in the Territory, including, as
applicable, any adverse drug experiences (including those events or experiences that are required to
be reported to the FDA under 21 C.F.R. §§ 312.32 or 314.80 or to foreign Regulatory Authorities
under corresponding Applicable Law outside the United States of America) from pre-clinical or
clinical laboratory, animal toxicology, pharmacology studies and clinical studies, in each case in
the form reasonably requested by such other Party.

13.5 No Other Warranties. EXCEPT AS EXPRESSLY STATED IN THIS ARTICLE XIII, (A) NO REPRESENTATION,
CONDITION OR WARRANTY WHATSOEVER IS MADE OR GIVEN BY OR ON BEHALF OF SANOFI OR REVMED; AND (B) ALL
OTHER CONDITIONS AND WARRANTIES WHETHER WRITTEN OR ORAL OR EXPRESS OR IMPLIED ARE HEREBY EXPRESSLY
EXCLUDED, INCLUDING ANY CONDITIONS AND WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE OR NON-INFRINGEMENT. 70

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 71 -->
13.6 Closing Conditions. The obligations of each Party to consummate the transactions contemplated
by this Agreement and the Ancillary Agreements (the "Contemplated Transactions") is subject to the
fulfillment, or, to the extent permitted by Applicable Law, waiver by such Party, of each of the
following conditions (collectively, the "Closing Conditions"):

(a) The representations and warranties of the other Party contained in this Agreement (i) that are
not qualified by materiality, material adverse effect, substantial compliance or similar materiality
qualifier will be true and correct in all material respects both when made and at the closing with
the same force and effect as if made on the Effective Date and (ii) that are qualified by
materiality, material adverse effect, substantial compliance or similar materiality qualifier will
be true and correct in all respects both when made and at the closing with the same force and effect
as if made on the Effective Date, except, in each of (i) and (ii) as would not reasonably be
expected, individually or in the aggregate, to have a material impact on the transaction
contemplated by this Agreement.

(b) All actions by (including any authorization, consent or approval) in respect of (including
notice to), or filings with, any Governmental Authority or other Person that are required to be
obtained pursuant to Section 3.8 to consummate the Contemplated Transactions (including any
HSR/Antitrust Filing) will have been obtained or made, in a manner reasonably satisfactory in form
and substance to such Party, and no such authorization, consent or approval will have been revoked.

(c) No Material Adverse Event shall have occurred or arisen since the Execution Date.

Article XIV.

INDEMNIFICATION; LIABILITY; INSURANCE

14.1 Indemnification by RevMed. RevMed shall indemnify, defend and hold harmless Sanofi, its
Affiliates and their respective officers, directors, agents and employees ("Sanofi Indemnitees")
from and against any Third Party Claims and Losses arising therefrom under or related to this
Agreement against any of them to the extent arising or resulting from:

(a) the negligence, recklessness or willful misconduct of any of the RevMed Indemnitees; or

(b) the material breach of any of the warranties or representations made by RevMed to Sanofi under
this Agreement or any Ancillary Agreement; or

(c) the material breach by RevMed of any of its obligations pursuant to this Agreement or any
Ancillary Agreement;

except in each case ((a) through (c)), to the extent the applicable Third Party Claim and Losses
arising therefrom arise or result from (i) the negligence, recklessness or willful misconduct of any
Sanofi Indemnitee; (ii) the breach of any of the warranties or representations made by Sanofi to
RevMed under this Agreement or any Ancillary Agreement; or (iii) any breach by Sanofi of its
obligations pursuant to this Agreement or any Ancillary Agreement.

14.2 Indemnification by Sanofi. Sanofi shall indemnify, defend and hold harmless RevMed, its
Affiliates, and their respective officers, directors, agents and employees ("RevMed Indemnitees")
from and against any Third Party Claims and Losses arising therefrom under or related to this
Agreement against any of them to the extent arising or resulting from:

(a) (i) the Research, Development or Manufacture of any Products by or on behalf of Sanofi or any of
its Affiliates, Sublicensees or contractors (other than by RevMed or its Affiliates), or (ii) the
Commercialization of Products by or on behalf of Sanofi; or 71

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 72 -->
(b) the negligence, recklessness or willful misconduct of any of the Sanofi Indemnitees; or

(c) the material breach of any of the warranties or representations made by Sanofi to RevMed under
this Agreement or any Ancillary Agreement; or

(d) the material breach by Sanofi of any of its obligations pursuant to this Agreement or any
Ancillary Agreement;

except in each case ((a) through (d)), to the extent the applicable Third Party Claim and Losses
arising therefrom arise or result from (i) the negligence, recklessness or willful misconduct of any
RevMed Indemnitee; (ii) the breach of any of the warranties or representations made by RevMed to
Sanofi under this Agreement or any Ancillary Agreement; or (iii) any breach by RevMed of its
obligations pursuant to this Agreement or any Ancillary Agreement.

14.3 Indemnification Procedure.

(a) Notice of Claim. All indemnification claims in respect of any Sanofi Indemnitee or RevMed
Indemnitee seeking indemnity under Section 14.1 or Section 14.2 (collectively, the "Indemnitees" and
each an "Indemnitee") will be made solely by the corresponding Party (the "Indemnified Party"). The
Indemnified Party will give the indemnifying Party (the "Indemnifying Party") prompt written notice
(an "Indemnification Claim Notice") of any Losses or discovery of fact upon which such Indemnified
Party intends to base a request for indemnification under Section 14.1 or Section 14.2, but failure
to provide prompt notice will not relieve the Indemnifying Party from its obligation to indemnify
the Indemnitee hereunder except to the extent any Losses result from such delay in providing such
notice. Each Indemnification Claim Notice must contain a description of the claim and the nature and
amount of such Loss (to the extent that the nature and amount of such Loss are known at such time).
Together with the Indemnification Claim Notice, the Indemnified Party will furnish promptly to the
Indemnifying Party copies of all notices and documents (including court papers) received by any
Indemnitee in connection with the Third Party Claim.

(b) Control of Defense. At its option, the Indemnifying Party may assume the defense of any Third
Party Claim subject to indemnification as provided for in Section 14.1 or Section 14.2 by giving
written notice to the Indemnified Party within [***] after the Indemnifying Party's receipt of an
Indemnification Claim Notice. Upon assuming the defense of a Third Party Claim, the Indemnifying
Party may select and appoint the lead legal counsel for the defense of the Third Party Claim. Should
the Indemnifying Party assume the defense of a Third Party Claim, the Indemnifying Party will not be
liable to the Indemnified Party or any other Indemnitee for any legal expenses subsequently incurred
by such Indemnified Party or other Indemnitee in connection with the analysis, defense or settlement
of the Third Party Claim. 72

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 73 -->
(c) Right to Participate in Defense. Without limiting Section 14.3(b), any Indemnitee will be
entitled to participate in, but not control, the defense of such Third Party Claim and to employ
counsel of its choice for such purpose; provided, however, that such employment will be at the
Indemnitee's own expense unless (a) the employment thereof has been specifically authorized by the
Indemnifying Party in writing, or (b) the Indemnifying Party has failed to assume the defense and
employ counsel in accordance with Section 14.3(b) (in which case the Indemnified Party will control
the defense).

(d) Settlement. With respect to any Losses relating solely to the payment of money damages in
connection with a Third Party Claim and that will not result in the Indemnitee's becoming subject to
injunctive or other relief or otherwise adversely affect the business of the Indemnitee in any
manner, and as to which the Indemnifying Party has acknowledged in writing the obligation to
indemnify the Indemnitee hereunder, the Indemnifying Party will have the sole right to consent to
the entry of any judgment, enter into any settlement or otherwise dispose of such Loss, on such
terms as the Indemnifying Party, in its sole discretion, will deem appropriate. The Indemnifying
Party will pay all amounts on behalf of the Indemnified Party at or prior to the time of the entry
of judgment. With respect to all other Losses in connection with Third Party Claims, where the
Indemnifying Party has assumed the defense of the Third Party Claim in accordance with Section
14.3(b), the Indemnifying Party will have authority to consent to the entry of any judgment, enter
into any settlement or otherwise dispose of such Loss provided it obtains the prior written consent
of the Indemnified Party (which consent will be at the Indemnified Party's sole and absolute
discretion). The Indemnifying Party that has assumed the defense of the Third Party Claim in
accordance with Section 14.3(b) will not be liable for any settlement or other disposition of a Loss
by an Indemnitee that is reached without the written consent of such Indemnifying Party. Regardless
of whether the Indemnifying Party chooses to defend any Third Party Claim, no Indemnitee will admit
any liability with respect to, or settle, compromise or discharge, any Third Party Claim without
first offering to the Indemnifying Party the opportunity to assume the defense of the Third Party
Claim in accordance with Section 14.3(b).

(e) Cooperation. If the Indemnifying Party chooses to defend any Third Party Claim, the Indemnified
Party will, and will cause each other Indemnitee to, cooperate in the defense thereof and will
furnish such records, information and testimony, provide such witnesses and attend such conferences,
discovery proceedings, hearings, trials and appeals as may be reasonably requested in connection
with the defense of such Third Party Claim. Such cooperation will include access during normal
business hours afforded to the Indemnifying Party to, and reasonable retention by the Indemnified
Party of, records and information that are reasonably relevant to such Third Party Claim, and making
Indemnitees and other employees and agents available on a mutually convenient basis to provide
additional information and explanation of any material provided hereunder. The Indemnifying Party
will reimburse the Indemnified Party for all its reasonable out-of-pocket costs in connection with
such cooperation.

(f) Expenses. Except as provided above, the reasonable and verifiable costs and expenses, including
fees and disbursements of counsel, incurred by the Indemnified Party in connection with any claim
will be reimbursed on a [***] by the Indemnifying Party, without prejudice to the Indemnifying
Party's right to contest the Indemnified Party's right to indemnification and subject to refund in
the event the Indemnifying Party is ultimately held not to be obligated to indemnify the Indemnified
Party. 73

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 74 -->
14.4 Mitigation of Loss. Each Indemnified Party shall take and shall procure that its Affiliates
take all such reasonable steps and action as are reasonably necessary or as the Indemnifying Party
may reasonably require in order to mitigate any Third Party Claims (or potential losses or damages)
under this Article XIV. Nothing in this Agreement shall or shall be deemed to relieve any Party of
any common law or other duty to mitigate any losses incurred by it.

14.5 Limitation of Liability. NEITHER PARTY SHALL BE LIABLE TO THE OTHER FOR ANY SPECIAL,
CONSEQUENTIAL, INCIDENTAL, PUNITIVE, OR INDIRECT DAMAGES OR LOST PROFITS ARISING FROM OR RELATING TO
ANY BREACH OF THIS AGREEMENT, REGARDLESS OF ANY NOTICE OF THE POSSIBILITY OF SUCH DAMAGES.
NOTWITHSTANDING THE FOREGOING, NOTHING IN THIS SECTION 14.5 IS INTENDED TO OR SHALL LIMIT OR
RESTRICT THE INDEMNIFICATION RIGHTS OR OBLIGATIONS OF ANY PARTY UNDER SECTION 14.1 OR SECTION 14.2,
OR DAMAGES AVAILABLE FOR A PARTY'S BREACH OF ITS OBLIGATIONS RELATING TO CONFIDENTIALITY UNDER
ARTICLE XI OR INTELLECTUAL PROPERTY UNDER ARTICLE X.

14.6 Insurance. Each Party shall procure and maintain insurance, including product liability
insurance, with respect to its activities hereunder and under the Ancillary Agreements and which is
consistent with normal business practices of companies similarly situated at all times during which
any SHP2 Inhibitors or Product is being clinically tested in human subjects or commercially
distributed or sold. Sanofi may fulfill such obligation through self- insurance. Each Party shall
provide the other Party with evidence of such insurance upon request and, in the case of RevMed,
shall provide Sanofi with written notice at least [***] prior to the cancellation, non-renewal or
material changes in such insurance. It is understood that such insurance shall not be construed to
create a limit of either Party's liability with respect to its indemnification obligations under
this Article XIV.

Article XV.

GENERAL PROVISIONS

15.1 Force Majeure. Neither Party shall be held liable to the other Party nor be deemed to have
defaulted under or breached this Agreement for failure or delay in performing any obligation under
this Agreement to the extent such failure or delay is caused by or results from causes beyond the
reasonable control of the affected Party, including embargoes, war, acts of war (whether war be
declared or not), acts of terrorism, insurrections, riots, civil commotions, strikes, lockouts or
other labor disturbances (whether involving the workforce of the nonperforming Party or of any other
Person), fire, floods, earthquakes or other acts of God, or acts, generally applicable action or
inaction by any governmental authority (but excluding any government action or inaction that is
specific to such Party, its Affiliates or Sublicensees, such as revocation or non-renewal of such
Party's license to conduct business), or omissions or delays in acting by the other Party, or
unavailability of materials related to the Manufacture of the Products (each cause, an event of
"Force Majeure"). The affected Party shall give notice to the other Party in writing as soon as
reasonably practical but no later than [***] after the occurrence of the event of Force Majeure,
specifying the nature and extent of the event of Force Majeure, its anticipated duration and any 74

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 75 -->
action being taken to avoid or minimize its effect. The suspension of performance allowed hereunder
shall be of no greater scope and no longer duration than is reasonably required, and the affected
Party shall promptly undertake and continue diligently all reasonable efforts necessary to cure such
force majeure circumstances or to perform its obligations in spite of the ongoing circumstances. In
the event that RevMed is the non-performing Party and the Force Majeure continues for more than
[***] (which period, in its entirety or a portion thereof, is prior to the commencement of the
Registration Program for a Product, which Development thereof is impacted by such Force Majeure),
Sanofi's payment obligations under Article IX shall be suspended until notification by RevMed to
Sanofi of the termination of such Force Majeure Event (and any related triggers and deadlines shall
be similarly suspended).

15.2 Assignment; Change of Control.

(a) Neither Party may assign this Agreement or any of its rights or obligations hereunder, except as
expressly permitted hereunder, or delegate any of its obligations under this Agreement, whether by
operation of law or otherwise, in whole or in part, without the consent of the other Party, except
as follows:

(i) Sanofi may, without consent of RevMed, assign this Agreement or its rights and obligations
hereunder in whole or in part to any Affiliate of Sanofi, and RevMed may, with the consent of Sanofi
(not to be unreasonably withheld, delayed or conditioned), assign this Agreement or its rights and
obligations hereunder in whole or in part to any Affiliate of RevMed; and

(ii) Either Party may, without consent of the other Party, assign this Agreement in whole to (i) in
the case of RevMed, its successor in interest or assignee or purchaser, as applicable, in the case
of a Change of Control or (ii) in the case of Sanofi, its successor in interest or assignee or
purchaser, as applicable, in connection with the sale of all or substantially all of its assets to
which this Agreement relates, or in connection with a merger, acquisition or similar transaction. In
the case of Sanofi the intellectual property owned or controlled by any such successor in interest
or assignee or purchaser (such successor in interest or assignee or purchaser, as applicable, an
"Acquiror") or its Acquiror Family prior to the applicable Change of Control or other similar
transaction immediately prior to such acquisition (other than as a result of a license from the
acquired Party) or thereafter developed outside the scope of this Agreement in accordance with this
Agreement shall be excluded from [***] and the Acquiror Family shall be excluded from "Affiliate"
solely for purposes of the applicable components of the intellectual property definitions set forth
herein. In the case of RevMed, the intellectual property owned or controlled by any such Acquiror or
its Acquiror Family prior to the applicable Change of Control or other similar transaction
immediately prior to such acquisition (other than as a result of a license from the acquired Party)
or is thereafter developed outside the scope of this Agreement in accordance with this Agreement
shall be excluded from the RevMed Licensed Technology, in each case only for so long as the
remainder of the conditions of this Section 15.2 are met, and the Acquiror Family shall be excluded
from "Affiliate" solely for purposes of the applicable components of the intellectual property
definitions set forth herein, in all such cases if and only if: (A) the acquired Party remains a
wholly-owned subsidiary of the Acquiror; (B) all intellectual property of the Acquired Party Family
and 75

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 76 -->
all research and development assets and operations of the Acquired Party Family, in each case
relating to SHP2 Inhibitors and Products, remain with the Acquired Party Family and are not licensed
or otherwise transferred to the Acquiror Party Family for any purpose; (C) the scientific and
Development activities with respect to SHP2 Inhibitors and Products of the Acquired Party Family and
Competing Products of the Acquiror Family (if any) are maintained separate and distinct, and (D)
there is no exchange of Know-How relating to SHP2 Inhibitors and Products between the Acquired Party
Family and the Acquiror Family. Any attempted assignment not in accordance with this Section 15.2
shall be null and void and of no legal effect. Any permitted assignee shall assume all assigned
obligations of its assignor under this Agreement. The terms and conditions of this Agreement shall
be binding upon, and shall inure to the benefit of, the Parties and their respected successors and
permitted assigns. For clarity, any assignment by Sanofi shall be subject to Section 9.7(a).

(b) Except as part of a transaction permitted under this Section 15.2, in no event shall RevMed
assign or transfer, or agree to assign or transfer to any Third Party, any or all of the RevMed
Licensed Patents without the consent of Sanofi, not be unreasonably withheld or conditioned.

15.3 Severability. If any provision of this Agreement is held to be illegal, invalid or
unenforceable under any present or future law and if the rights or obligations of either Party under
this Agreement will not be materially and adversely affected thereby, (i) such provision shall be
fully severable, (ii) this Agreement shall be construed and enforced as if such illegal, invalid or
unenforceable provision had never comprised a part hereof, (iii) the remaining provisions of this
Agreement shall remain in full force and effect and shall not be affected by the illegal, invalid or
unenforceable provision or by its severance here from and (iv) in lieu of such illegal, invalid or
unenforceable provision, there shall be added automatically as a part of this Agreement a legal,
valid and enforceable provision as similar in terms to such illegal, invalid or unenforceable
provision as may be possible and reasonably acceptable to the Parties. To the fullest extent
permitted by Applicable Law, each Party hereby waives any provision of law that would render any
provision hereof illegal, invalid or unenforceable in any respect.

15.4 Notices. All notices which are required or permitted hereunder shall be in writing and
sufficient if delivered personally, sent by e-mail (and promptly confirmed by personal delivery,
registered or certified mail or overnight courier), sent by an internationally-recognized overnight
courier or sent by registered or certified mail, postage prepaid, return receipt requested,
addressed as follows:

If to RevMed:

Revolution Medicines, Inc. 700 Saginaw Dr. Redwood City, CA 94063 USA Attn: General Counsel Email:
[***] 76

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 77 -->
With a copy to:

[***] Latham & Watkins LLP 140 Scott Drive Menlo Park, CA 94025 Fax: [***]

If to Sanofi:

Sanofi 50 Binney Street Cambridge, MA 02142 Attn: [***]

With a copy to:

Sanofi 50 Binney Street Cambridge, MA 02142 Attn: [***]

or to such other address(es) as the Party to whom notice is to be given may have furnished to the
other Party in writing in accordance herewith. Any such notice shall be deemed to have been given:
(a) when delivered if personally delivered or sent by facsimile on a Business Day (or if delivered
or sent on a non-Business Day, then on the next Business Day); (b) on the second (2nd) Business Day
after dispatch if sent by an internationally- recognized overnight courier; or (c) on the tenth
(10th) Business Day following the date of mailing, if sent by mail.

15.5 Governing Law. This Agreement shall be governed by and construed in accordance with the laws of
the State of New York without reference to any rules of conflict of laws.

15.6 Dispute Resolution.

(a) Except for matters within the JSC's authority that are resolved under Section 2.10, including
through a Party's exercise of its final decision making authority in accordance therewith, and
matters resolved pursuant to Section 5.6, any dispute, claim or controversy arising out of or
relating to this Agreement, or the breach, termination, enforcement, interpretation or validity
thereof, including the determination of the scope or applicability of this Agreement to arbitrate (a
"Dispute") that is not resolved within [***] after written notice of the Dispute by one Party to the
other shall be determined by arbitration in [***] before [***] arbitrators, unless the Parties
mutually agree in writing otherwise. The arbitration shall be administered by JAMS pursuant to its
Comprehensive Arbitration Rules and Procedures then in effect and the Expedited Procedures contained
therein, as modified in this paragraph, except (i) to the extent such rules are inconsistent with
this Section 15.6(a), in which case, this Section 15.6(a) shall control (including with regard to
any limitations of liability or forms of relief), and (ii) [***] discovery depositions may be 77

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 78 -->
conducted per side. The JAMS Expedited Procedures shall be modified to [***] of such procedures as
in effect on the Effective Date, and the [***] shall be modified to provide that [***]. The language
of the arbitration shall be English. The proceedings and decisions of the arbitrator shall be final
and binding on the Parties, and judgment on the award may be entered in any court having
jurisdiction.

(b) The Parties shall maintain the confidential nature of the arbitration proceeding and the award,
including the hearing, except as may be necessary to prepare for or conduct the arbitration hearing
on the merits, or except as may be necessary in connection with a court application for a
preliminary remedy, a judicial challenge to an award or its enforcement, or unless otherwise
required by law or judicial decision. All arbitration proceedings and decisions of the arbitrators
under this Section 15.6(b) shall be deemed Confidential Information of both Parties under Article
XI.

(c) Within [***] after the commencement of arbitration, each Party shall select [***] within [***]
of the commencement of the arbitration. If the arbitrator selected by the Parties are unable or fail
to agree upon [***] within the allotted time, [***] shall be appointed by JAMS in accordance with
its rules. All arbitrators shall serve as a neutral, independent and impartial arbitrators. Each
arbitrator shall have not less than [***] years of experience in biotechnology or pharmaceutical
industry disputes.

(d) The award shall be rendered within [***] of the constitution of the arbitral tribunal, unless
the arbitrators determine that the interest of justice requires that such limit be extended.

(e) The arbitrators may award to the prevailing Party, if any, as determined by the arbitrators, the
costs and attorneys' fees reasonably incurred by the prevailing Party in connection with the
arbitration. If the arbitrators determine a Party to be the prevailing Party under circumstances
where the prevailing Party won some but not all of the claims and counterclaims, the arbitrators may
award the prevailing Party an appropriate percentage of the costs and attorneys' fees reasonably
incurred by the prevailing Party in connection with the arbitration.

(f) The arbitrators are not empowered to award punitive or exemplary damages, and the Parties waive
any right to recover any such damages.

(g) Unless the Parties otherwise agree in writing, during the period of time that any arbitration
proceeding is pending under this Agreement, (i) the Parties shall continue to comply with all those
terms and provisions of this Agreement that are not the subject of the pending arbitration
proceeding; and (ii) in the event that the subject of the dispute relates to the exercise by a Party
of a termination right hereunder, including in the case of a material breach of this Agreement, the
effectiveness of such termination shall be stayed until the conclusion of the proceedings under this
Section 15.6.

(h) Notwithstanding the foregoing, any dispute, controversy or claim relating to the scope,
validity, enforceability or infringement of any Patent Rights or Trademark covering the manufacture,
use, importation, offer for sale or sale of Products shall be submitted to a court of competent
jurisdiction in the country in which such Patent Rights or Trademark were granted or arose. 78

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 79 -->
(i) Notwithstanding anything to the contrary in Section 15.6(c), any dispute relating to the
ownership of any Program Invention shall be finally adjudicated, according to U.S. patent law, by an
independent U.S. patent counsel with appropriate expertise that is jointly appointed by Sanofi and
RevMed. Some adjudication shall be completed within [***] after such counsel is appointed, and such
counsel must be appointed within [***] after submission of the issue for resolution.

(j) Nothing in this Section 15.6 will preclude either Party from seeking equitable relief or interim
or provisional relief from a court of competent jurisdiction, including a temporary restraining
order, preliminary injunction or other interim equitable relief, either prior to or during any
arbitration.

15.7 Rights in Bankruptcy. All rights and licenses granted under or pursuant to this Agreement by
Sanofi or RevMed are and shall otherwise be deemed to be, for purposes of Section 365(n) of the U.S.
Bankruptcy Code or any analogous provisions in any other country or jurisdiction, licenses of right
to "intellectual property" as defined under Section 101 of the U.S. Bankruptcy Code. The Parties
agree that the Parties, as licensees of such rights under this Agreement, shall retain and may fully
exercise all of their rights and elections under the U.S. Bankruptcy Code or any analogous
provisions in any other country or jurisdiction. The Parties further agree that, in the event of the
commencement of a bankruptcy proceeding by or against either Party under the U.S. Bankruptcy Code or
any analogous provisions in any other country or jurisdiction, the Party hereto that is not a Party
to such proceeding shall be entitled to a complete duplicate of (or complete access to, as
appropriate) any such intellectual property and all embodiments of such intellectual property,
which, if not already in the non-subject Party's possession, shall be promptly delivered to it (i)
upon any such commencement of a bankruptcy proceeding upon the non-subject Party's written request
therefor, unless the Party subject to such proceeding elects to continue to perform all of its
obligations under this Agreement or (ii) if not delivered under clause (i) above, following the
rejection of this Agreement by or on behalf of the Party subject to such proceeding upon written
request therefor by the non-subject Party. The Parties acknowledge and agree that payments made
under Section 9.1 and Section 9.2 or pursuant to the Co-Promotion Agreement shall not (x) constitute
royalties within the meaning of Section 365(n) of the U.S. Bankruptcy Code or any analogous
provisions in any other country or jurisdiction or (y) relate to licenses of intellectual property
hereunder.

15.8 No Action. In no event shall either Party be obligated under the Agreement to take any action
or omit to take any action that such Party believes, in good faith, would cause it to be in
violation of any Applicable Law.

15.9 Entire Agreement; Amendments. This Agreement, together with the Correspondence and the Exhibits
hereto and thereto, contains the entire understanding of the Parties with respect to the
collaboration and the licenses granted hereunder. Any other express or implied agreements and
understandings, negotiations, writings and commitments, either oral or written, in respect to the
collaboration and the licenses granted hereunder are superseded by the terms of this Agreement. The
Exhibits to this Agreement and the Correspondence are incorporated herein by reference and shall be
deemed a part of this Agreement. This Agreement may be amended, or any term hereof modified, only by
a written instrument duly executed by authorized representatives of both Parties hereto. The Parties
agree that, effective as of the Effective Date, 79

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 80 -->
that certain Confidentiality Agreement between an Affiliate of Sanofi and RevMed dated as of June
21, 2017, as amended ("Confidentiality Agreement") shall be superseded by this Agreement, and that
disclosures made prior to the Effective Date pursuant to the Confidentiality Agreement shall be
subject to Article XI.

15.10 Exhibits/Ancillary Agreements. In the event there is a conflict or inconsistency between or
among the terms of this Agreement, the terms of the Correspondence, the terms of any Exhibit hereto
or thereto, or the terms of any Ancillary Agreement, the order of precedence for resolution of such
conflict or inconsistency in descending order shall be as follows: (i) this Agreement, (ii) the
Correspondence, (iii) any Exhibit or Schedule of this Agreement or the Correspondence; (iii) any
Ancillary Agreement; and (iv) any exhibit or schedule of any Ancillary Agreement.

15.11 Headings. The captions to the several Articles, Sections, subsections and Exhibits hereof are
not a part of this Agreement, but are merely for convenience to assist in locating and reading the
several Articles, Sections, subsections and Exhibits hereof.

15.12 Independent Contractors. It is expressly agreed that RevMed and Sanofi shall be independent
contractors and that the relationship between the two Parties shall not constitute a partnership,
joint venture or agency. Neither RevMed nor Sanofi shall have the authority to make any statements,
representations or commitments of any kind, or to take any action, which shall be binding on the
other Party, without the prior written consent of the other Party.

15.13 Waiver. The waiver by either Party hereto of any right hereunder, or of any failure of the
other Party to perform, or of any breach by the other Party, shall not be deemed a waiver of any
other right hereunder or of any other breach by or failure of such other Party whether of a similar
nature or otherwise.

15.14 Cumulative Remedies. No remedy referred to in this Agreement is intended to be exclusive, but
each shall be cumulative and in addition to any other remedy referred to in this Agreement or
otherwise available under law.

15.15 Waiver of Rule of Construction. Each Party has had the opportunity to consult with counsel in
connection with the review, drafting and negotiation of this Agreement. Accordingly, the rule of
construction that any ambiguity in this Agreement shall be construed against the drafting Party
shall not apply.

15.16 Business Day Requirements. In the event that any notice or other action or omission is
required to be taken by a Party under this Agreement on a day that is not a Business Day then such
notice or other action or omission shall be deemed to be required to be taken on the next occurring
Business Day.

15.17 Translations. This Agreement is in the English language only, which language shall be
controlling in all respects, and all versions hereof in any other language shall be for
accommodation only and shall not be binding upon the Parties. All communications and notices to be
made or given pursuant to this Agreement, and any dispute proceeding related to or arising
hereunder, shall be in the English language. If there is a discrepancy between any translation of
this Agreement and this Agreement, this Agreement shall prevail. 80

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 81 -->
15.18 Further Actions. Each Party agrees to execute, acknowledge and deliver such further
instruments, and to do all such other acts, as necessary or appropriate in order to carry out the
purposes and intent of this Agreement.

15.19 Counterparts. This Agreement may be executed in two or more counterparts by original
signature, facsimile or PDF files, each of which shall be deemed an original, but all of which
together shall constitute one and the same instrument.

[REMAINDER OF PAGE INTENTIONALLY LEFT BLANK] 81

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 82 -->
IN WITNESS WHEREOF, the Parties intending to be bound have caused this Collaborative Research,
Development and Commercialization Agreement to be executed by their duly authorized representatives
as of the Effective Date. Revolution Medicines, Inc. Aventis, Inc.

By: /s/ Mark A. Goldsmith, M.D., Ph.D. By: /s/ Douglas J. McCormack Name: Mark A. Goldsmith, M.D.,
Ph.D. Name: Douglas J. McCormack Title: President & Chief Executive Officer Title: Vice President

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 83 -->
Aventis, Inc. c/o Sanofi 50 Binney Street Cambridge, MA 02142

August 24, 2018

Revolution Medicines, Inc. 700 Saginaw Dr. Redwood City, CA 94063 Attention: General Counsel

Re: Amendment to Collaborative Research, Development and Commercialization Agreement

Dear Revolution Medicines, Inc.:

Reference is hereby made to that certain Collaborative Research, Development and Commercialization
Agreement (the "Collaboration Agreement"), dated as of June 8, 2018, by and between Revolution
Medicines, Inc. ("RevMed") and Aventis, Inc. ("Sanofi"). Capitalized terms used but not defined in
this letter agreement (this "Letter") shall have the meanings assigned to them in the Collaboration
Agreement.

Each of RevMed and Sanofi acknowledges and agrees as follows:

1. Amendment to Section 6.5 of the Collaboration Agreement. The first sentence of Section 6.5 of the
Collaboration Agreement is hereby amended and restated in its entirety as follows:

"Following the Effective Date, but in any case prior to the Initiation of the first Clinical Trial
sponsored by Sanofi for a Product, the Parties shall enter into a pharmacovigilance agreement
setting forth the worldwide pharmacovigilance procedures for the Parties with respect to the
Products, such as safety data sharing, adverse events reporting and safety profile monitoring (the
"Pharmacovigilance Agreement")."

2. No Other Amendments. This Letter shall be deemed to be a part of and incorporated into the
Collaboration Agreement. In the event of a conflict between this Letter and the Collaboration
Agreement, this Letter shall control. Except as expressly set forth in this Letter, all of the terms
and conditions of the Collaboration Agreement shall remain unchanged and are ratified and confirmed
in all respects and remain in full force and effect.

3. Entire Agreement. This Letter, together with the Collaboration Agreement and any exhibits or
attachments thereto (including, without limitation, the Correspondence and the Exhibits thereto),
constitutes the entire agreement between the Parties regarding the subject matter hereof, and any
reference to the Collaboration Agreement shall refer to the Collaboration Agreement, as amended by
this Letter.

4. Counterparts. This Letter may be executed in one (1) or more counterparts, each of which will be
deemed an original, but all of which together will constitute one and the same instrument.

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 84 -->
5. Governing Law. This Letter shall be governed by and construed in accordance with the laws of the
State of New York without reference to any rules of conflict of laws.

[Remainder of Page Intentionally Left Blank]

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
<!-- page 85 -->
Please indicate your agreement by countersigning in the space provided below and returning a copy to
my attention.

Sincerely,

Aventis, Inc. By: /s/ Douglas J. McCormack Name: Douglas J. McCormack Title: Vice President

Acknowledged and Agreed:

Revolution Medicines, Inc. By: /s/ Mark A. Goldsmith Name: Mark A. Goldsmith Title: Chief Executive
Officer

[Signature Page to Letter Agreement]

Source: REVOLUTION MEDICINES, INC., S-1, 1/17/2020
