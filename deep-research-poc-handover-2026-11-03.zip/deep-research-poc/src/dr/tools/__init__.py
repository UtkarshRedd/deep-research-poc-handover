"""Framework-agnostic tools. Each module exposes a plain function taking a Workspace and
returning a pydantic model. `registry.py` adapts them for LangChain (and others).

Small-model rules (see CLAUDE.md): <= 6 tools exposed per agent, flat argument schemas,
counts not booleans, every result capped.
"""
