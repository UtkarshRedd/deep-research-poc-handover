<!-- page 1 -->
# AGENCY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Agency Agreement |
| Agreement Date | 2016-05-25 |
| Parties | Bluerock Residential Growth REIT, Inc. (“Company”); Bluerock Residential Holdings, L.P. (“Operating Partnership”) (collectively, Company, and Bluerock Residential Growth REIT, Inc. are referred to as the “Transaction Entities”); BRG Manager, LLC (“Manager”); Compass Point Research & Trading, LLC (“Agent”) |
| Source | CUAD v1 / BLUEROCKRESIDENTIALGROWTHREIT,INC_06_01_2016-EX-1.1-AGENCY AGREEMENT |

Exhibit 1.1 400,000 Shares BLUEROCK RESIDENTIAL GROWTH REIT, INC. 8.250% Series A Cumulative
Redeemable Preferred Stock AGENCY AGREEMENT May 25, 2016 Compass Point Research & Trading, LLC 1055
Thomas Jefferson Street N.W. Suite 303 Washington, DC 20007 As Sales Agent Dear Ladies and
Gentlemen: Bluerock Residential Growth REIT, Inc., a Maryland corporation (the "Company"), together
with Bluerock Residential Holdings, L.P., a Delaware limited partnership for which the Company is
the sole general partner (the "Operating Partnership" and together with the Company, the
"Transaction Entities") and BRG Manager, LLC, a Delaware limited liability company (the "Manager"),
agrees that it may issue and sell through Compass Point Research & Trading, LLC, acting as agent
(the "Agent"), up to a total of 400,000 shares (the "Offered Shares") of its 8.250% Series A
Cumulative Redeemable Preferred Stock, par value $0.01 per share (the "Series A Preferred Stock") as
set forth below. Notwithstanding anything to the contrary contained herein, the parties hereto agree
that compliance with the limitation set forth in this paragraph on the number of Offered Shares
issued and sold under this Agreement shall be the sole responsibility of the Company, and the Agent
shall have no obligation in connection with such compliance. Pursuant to the Second Amended and
Restated Agreement of Limited Partnership of the Operating Partnership (the "OP Agreement"), as
amended by that First Amendment to the Second Amended and Restated Agreement of Limited Partnership
of the Operating Partnership, as further amended by that Second Amendment to the Second Amended and
Restated Agreement of Limited Partnership of the Operating Partnership, as further amended by that
Third Amendment to the Second Amended and Restated Agreement of Limited Partnership of the Operating
Partnership and as further amended by the Fourth Amendment to the Second Amended and Restated
Agreement of Limited Partnership of the Operating Partnership, upon receipt of the net proceeds of
the sale of the Offered Shares on the Settlement Date (as defined below), the Company, through its
wholly-owned subsidiary, Bluerock REIT Holdings, LLC, a Delaware limited liability company
("Holdings LLC"), will contribute such net proceeds to the Operating Partnership in exchange for a
number of 8.250% Series A Cumulative Redeemable Preferred Units of partnership interest in the
Operating Partnership (the "Series A Preferred OP Units") that is equivalent to the number of
Offered Shares to be sold (the "Company Preferred OP Units").
<!-- page 2 -->
1. Representations and Warranties of the Transaction Entities. (a) Representations and Warranties.
The Transaction Entities, jointly and severally, represent and warrant to, and agree with, the Agent
that: (i) Filing and Effectiveness of Registration Statement; Certain Defined Terms. The Company has
filed with the Commission a registration statement on Form S-3 (No. 333-208956) covering the
registration of the Offered Shares under the Act, including a base prospectus (the "Base
Prospectus"). Such registration statement, as amended, including the financial statements, exhibits
and schedules thereto, in the form in which it became effective under the Act, including all
documents incorporated or deemed to be incorporated by reference therein and any information deemed
to be a part thereof at the time of effectiveness pursuant to Rule 430B under the Act, shall be
referred to as the "Registration Statement." Any registration statement filed by the Company
pursuant to Rule 462(b) under the Act in connection with the offer and sale of the Offered Shares is
called the "Rule 462(b) Registration Statement," and from and after the date and time of filing of
any such Rule 462(b) Registration Statement the term "Registration Statement" shall include the Rule
462(b) Registration Statement. As used herein, the term "Prospectus" shall mean the final prospectus
supplement to the Base Prospectus dated the date hereof that describes the Offered Shares and the
offering thereof (the "Final Prospectus Supplement"), together with the Base Prospectus, in the form
first used by the Agent to meet requests of purchasers pursuant to Rule 173 under the Act.
References herein to the Prospectus shall refer to both the prospectus supplement and the Base
Prospectus components of such prospectus, including all documents incorporated or deemed to be
incorporated by reference therein. The Registration Statement has been declared effective under the
Act. The Offered Shares all have been duly registered under the Act pursuant to the Registration
Statement. The Company has complied, to the Commission's satisfaction, with all requests of the
Commission for additional or supplemental information, if any. No stop order suspending the
effectiveness of or use of the Registration Statement has been issued under the Act, and no order
preventing or suspending the use of the Prospectus has been issued and no proceedings for any such
purposes have been instituted and are pending or, to the knowledge of the Company, are contemplated
by the Commission, and any request on the part of the Commission for additional information from the
Company in connection with the Registration Statement has been complied with. The Company meets the
requirements for use of Form S-3 under the Act. The documents incorporated or deemed to be
incorporated by reference in the Registration Statement, the General Disclosure Package (as defined
below) and the Prospectus, at the time they were or hereafter are filed with the Commission, or
became effective under the Exchange Act, as the case may be, complied and will comply (as
applicable) in all material respects with the requirements of the Exchange Act.

2
<!-- page 3 -->
For purposes of this Agreement: "430B Information," with respect to any registration statement,
means information included in a prospectus and retroactively deemed to be a part of such
registration statement pursuant to Rule 430B(b). "Act" means the Securities Act of 1933, as amended.
"Applicable Time" means of the time of the sale of the Offered Shares pursuant to this Agreement.
"Settlement Date" has the meaning defined in Section 3 hereof. "Commission" means the Securities and
Exchange Commission. "Effective Time" with respect to the Registration Statement, means the date and
time as of which such Registration Statement was declared effective by the Commission.
"Environmental Law" means any federal, state or local law, statute, ordinance, rule, regulation,
order, decree, judgment, injunction, permit, license, authorization or other binding requirement, or
common law, relating to health, safety or the protection, cleanup or restoration of the environment
or natural resources, including those relating to the distribution, processing, generation,
treatment, storage, disposal, transportation, other handling or release or threatened release of
Hazardous Materials. "Exchange Act" means the Securities Exchange Act of 1934, as amended. "General
Disclosure Package" means the Prospectus, together with the information and free writing
prospectuses, if any, identified in Schedule A hereto. "General Use Issuer Free Writing Prospectus"
means any Issuer Free Writing Prospectus that is intended for general distribution to prospective
investors (other than a "bona fide electronic road show", defined in Rule 433 (the "Bona Fide
Electronic Road Show")), as evidenced by its being so specified in Schedule A to this Agreement.
"Hazardous Materials " means any material (including, without limitation, pollutants, contaminants,
hazardous or toxic substances or wastes), the presence of which in the environment is prohibited,
regulated or serves as the basis of liability as defined, listed or regulated by any Environmental
Law.

3
<!-- page 4 -->
"Issuer Free Writing Prospectus" means any "issuer free writing prospectus," as defined in Rule 433,
relating to the Offered Shares, including, without limitation, any "free writing prospectus" (as
defined in Rule 405) relating to the Offered Shares that is (i) required to be filed with the
Commission by the Company, (ii) a road show that is a written communication within the meaning of
Rule 433(d)(8)(i), whether or not required to be filed with the Commission, or (iii) exempt from
filing with the Commission pursuant to Rule 433(d)(5)(i) because it contains a description of the
Offered Shares or of the offering of the Offered Shares that does not reflect the final terms, in
each case in the form filed or required to be filed with the Commission or, if not required to be
filed, in the form retained in the Company's records pursuant to Rule 433(g). "Limited Use Issuer
Free Writing Prospectus" means any Issuer Free Writing Prospectus that is not a General Use Issuer
Free Writing Prospectus. A "Registration Statement" without reference to a time means such
Registration Statement as of its Effective Time. For purposes of the foregoing definitions, 430B
Information with respect to a Registration Statement shall be considered to be included in such
Registration Statement as of the time specified in Rule 430B. "LTIP Units" means the special units
of partnership interest of the Operating Partnership having the rights, preferences and other
privileges designated in Section 4.04 and elsewhere in the OP Agreement. "Rules and Regulations"
means the rules and regulations of the Commission. "Securities Laws" means, collectively, the
Sarbanes-Oxley Act of 2002 ("Sarbanes-Oxley"), the Act, the Exchange Act, the Rules and Regulations,
the auditing principles, rules, standards and practices applicable to auditors of "issuers" (as
defined in Sarbanes-Oxley) promulgated or approved by the Public Company Accounting Oversight Board
and, as applicable, the rules of the NYSE MKT, LLC (the "NYSE MKT") ("Exchange Rules"). "Statutory
Prospectus" means the Base Prospectus, as amended and supplemented immediately prior to the
Applicable Time, including any document incorporated by reference therein and any prospectus
supplement deemed to be a part thereof. For purposes of this definition, Rule 430B Information
contained in a form of prospectus that is deemed retroactively to be a part of the Registration
Statement shall be considered to be included in the Statutory Prospectus as of the actual time that
such form of prospectus is filed with the Commission pursuant to Rule 424(b) under the Act.

4
<!-- page 5 -->
"Subsidiary" or "Subsidiaries" means each of the entities listed on Schedule A, which i) comprise
all of the subsidiaries of the Transaction Entities, including the entities in which the Operating
Partnership owns, directly or indirectly, all of the membership interests; ii) hold assets and iii)
such omitted entities are considered in the aggregate as a single subsidiary, would not constitute a
"significant subsidiary" within the meaning of Rule 1-02(w) of Regulation S-X. Unless otherwise
specified, a reference to a "rule" or "Rule" is to the indicated rule under the Act. (ii) Compliance
with Securities Act Requirements. (A) (1) At the Effective Time, (2) on the date of this Agreement
and (3) on the Settlement Date, the Registration Statement or any post-effective amendment thereto
complied and will comply in all respects to the requirements of the Act and the Rules and
Regulations thereunder, and did not, does not and will not include any untrue statement of a
material fact or omitted, omits or will omit to state any material fact required to be stated
therein or necessary to make the statements therein, in the light of the circumstances under which
they were made, not misleading; and (B) the Prospectus and each amendment or supplement thereto, as
of their respective issue dates, complied and will comply in all material respects with the Act and
the Rules and Regulations thereunder, and neither the Prospectus nor any amendment or supplement
thereto (including any prospectus wrapper), as of its issue date, at the time of any filing with the
Commission pursuant to Rule 424(b) and at the Settlement Date, included, includes or will include an
untrue statement of a material fact or omitted, omits or will omit to state a material fact
necessary in order to make the statements therein, in light of the circumstances under which they
were made, not misleading. The representations and warranties contained herein do not apply to
statements in or omissions from any document discussed herein based upon written information
furnished to the Company by the Agent specifically for use therein, it being understood and agreed
that such information is only that described as such in Section 8(b) hereof (collectively, the
"Agent Information"). (iii) General Disclosure Package. As of the Applicable Time and on the
Settlement Date, none of (A) the General Disclosure Package, (B) any individual Limited Use Issuer
Free Writing Prospectus, when considered together with the General Disclosure Package and/or (C)
each road show, if any, when considered together with, and as may be corrected by, the General
Disclosure Package, included, includes or will include any untrue statement of a material fact or
omitted, omits or will omit to state any material fact necessary in order to make the statements
therein, in the light of the circumstances under which they were made, not misleading. The preceding
sentence does not apply to statements in or omissions from any Statutory Prospectus, Issuer Free
Writing Prospectus or road show made in reliance upon and in conformity with the Agent Information.

5
<!-- page 6 -->
(iv) Issuer Free Writing Prospectuses. Each Issuer Free Writing Prospectus, as of its issue date
and, to the extent not superseded or modified, at all subsequent times through the completion of the
offer and sale of the Offered Shares did not, does not and will not include any information that
conflicted, conflicts or will conflict with the information then contained in the Registration
Statement or the Prospectus. Each Issuer Free Writing Prospectus conformed, conforms or will conform
in all respects to the requirements of the Act and the Rules and Regulations thereunder. The Company
has not made any offer relating to the Offered Shares that would constitute an Issuer Free Writing
Prospectus without the prior written consent of the Agent; provided that such consent is deemed to
have been given with respect to each Issuer Free Writing Prospectus identified on Schedule A to this
Agreement. The Company (A) has filed or will file each Issuer Free Writing Prospectus required to be
filed with the Commission pursuant to the Act and the Rules and Regulations thereunder in accordance
therewith and/or (B) has retained or will retain in accordance with the Act and the Rules and
Regulations thereunder all Issuer Free Writing Prospectuses that were not required to be filed
pursuant to the Act and the Rules and Regulations thereunder. The Company has made any Bona Fide
Electronic Road Show in compliance with Rule 433(d)(8)(i) such that no filing of any road show (as
defined in Rule 433(h)) is required in connection with the offering of the Series A Preferred Stock.
(v) Ineligible Issuer Status. As of the determination date referenced in Rule 164(h) under the Act,
the Company was not, is not or will not be (as applicable) an "ineligible issuer" in connection with
the offering of the Offered Shares pursuant to Rules 164, 405 and 433, including (x) the Company or
its subsidiaries in the preceding three years not having been convicted of a felony or misdemeanor
or having been made the subject of a judicial or administrative decree or order as described in Rule
405 and (y) the Company or its subsidiaries in the preceding three years not having been the subject
of a bankruptcy petition or insolvency or similar proceeding, not having had a registration
statement be the subject of a proceeding or examination under Section 8 of the Act and not being the
subject of a pending proceeding under Section 8A of the Act in connection with an offering, all as
described in Rule 405. (vi) Good Standing of the Transaction Entities. The Company has been duly
incorporated and is validly existing as a corporation under the laws of the State of Maryland and is
in good standing with the State Department of Assessments and Taxation of Maryland, with the full
corporate power and authority to own its properties and conduct its business as described in the
Registration Statement, the General Disclosure Package and the Prospectus and to enter into and
perform its obligations under this Agreement to which it is a party; and the Company is duly
qualified to do business as a foreign corporation in good standing in all other jurisdictions in
which its ownership or lease of property or the conduct of its business requires such qualification,
except where the failure to be so qualified would not, individually or in the aggregate, result in a
material adverse effect on the condition (financial or otherwise), results of operations, earnings,
business, properties or prospects of the Transaction Entities and each of their respective
Subsidiaries, taken as a whole (a "Material Adverse Effect"). The Operating Partnership has been
duly formed and is validly existing as a limited partnership in good standing under the laws of the
State of Delaware, with power and authority to own its properties and conduct its business as
described in the Registration Statement, the General Disclosure Package and the Prospectus and to
enter into and perform its obligations under this Agreement to which it is a party; and the
Operating Partnership is duly qualified to do business as a foreign organization in good standing in
all other jurisdictions in which its ownership or lease of property or the conduct of its business
requires such qualification, except where the failure to be so qualified would not, individually or
in the aggregate, result in a Material Adverse Effect.

6
<!-- page 7 -->
(vii) Subsidiaries. Each Subsidiary (including, without limitation, Holdings LLC) has been duly
incorporated or organized and is validly existing and in good standing under the laws of the
jurisdiction of its incorporation or organization, with power and authority (corporate or other) to
own its properties and conduct its business as described in the Registration Statement, the General
Disclosure Package and the Prospectus; and each Subsidiary is duly qualified to do business as a
foreign corporation or organization in good standing in all other jurisdictions in which its
ownership or lease of property or the conduct of its business requires such qualification, except
where the failure to be so qualified would not, individually or in the aggregate, result in a
Material Adverse Effect; all of the issued and outstanding capital stock, partnership interests or
membership interests of each Subsidiary, including the outstanding LTIP Units of the Operating
Partnership, has been duly authorized and validly issued and is fully paid and nonassessable (except
with respect to future contributions as provided in the operating agreement or limited partnership
agreement (or similar organizational document) of the applicable Subsidiary made subsequent to the
date hereof); and the capital stock, membership interest, limited partnership interest or other
equity interest of each Subsidiary held by the Transaction Entities or a Subsidiary, as applicable,
is held as set forth on Schedule C hereto. The Transaction Entities, directly or indirectly through
their respective Subsidiaries, hold good and marketable title to their equity interests in their
respective Subsidiaries, in each case free and clear of any lien, encumbrance or security interest,
except as described in the Registration Statement, the General Disclosure Package and the
Prospectus, subject only to restrictions on transfer imposed under applicable U.S. federal and state
securities laws and the limited liability company agreement, limited partnership agreement or other
organizational document of each Subsidiary; and have not conveyed, transferred, assigned, pledged or
hypothecated any of their respective equity interests in their Subsidiaries, in whole or in part, or
granted any rights, options or rights of first refusal or first offer to purchase any of such
interests or any portion thereof.

7
<!-- page 8 -->
(viii) Subsidiaries of Transaction Entities. The Transaction Entities do not own or control,
directly or indirectly, any corporation, association or other entity other than (i) the subsidiaries
listed in Exhibit 21 to the Registration Statement, (ii) the subsidiaries not listed on Exhibit 21
but listed on Schedule A hereto, and (ii) such other entities omitted from Exhibit 21 which, when
such omitted entities are considered in the aggregate as a single subsidiary, would not constitute a
"significant subsidiary" within the meaning of Rule 1-02(w) of Regulation S-X. (ix) Authorization of
the Agreement. This Agreement has been duly authorized, executed and delivered by each of the
Transaction Entities and is enforceable against each Transaction Entity in accordance with the
applicable terms contained herein. (x) Shares. The Offered Shares and all outstanding shares of
capital stock of the Company have been duly authorized; the authorized equity capitalization of the
Company is as set forth in the Registration Statement, the General Disclosure Package and the
Prospectus under the caption "Capitalization", all outstanding shares of capital stock of the
Company are, and when the Offered Shares have been delivered and paid for in accordance with this
Agreement on the Settlement Date as set forth in the Registration Statement, the General Disclosure
Package and the Prospectus, such Offered Shares will be, validly issued, fully paid and
nonassessable, will conform to the information in the Registration Statement, the General Disclosure
Package and the Prospectus and to the description of such Offered Shares contained therein; the
stockholders of the Company have no preemptive rights with respect to the Offered Shares; none of
the outstanding shares of capital stock have been issued in violation of any preemptive or similar
rights of any security holder; any forms of certificates used to represent the Offered Shares comply
in all material respects with all applicable statutory requirements and with any applicable
requirements of the Organizational Documents of the Company, and with any requirements of the NYSE
MKT. Except as disclosed in the Registration Statement, the General Disclosure Package and the
Prospectus, there are no outstanding (a) securities of the Company reserved for any purpose (other
than certain outstanding common units of partnership interest in the Operating Partnership (the "OP
Units") and LTIP Units disclosed in the General Disclosure Package and the Prospectus), (b)
securities or obligations of the Company convertible into or exchangeable for any shares of common
stock, $0.01 par value per share, of the Company (the "Common Stock"), Series A Preferred Stock or
shares of Series B Redeemable Preferred Stock outstanding, par value $0.01 per share (the "Series B
Preferred Stock"), (c) warrants, rights or options to subscribe for or purchase from the Company any
such shares of Common Stock, Series A Preferred Stock or Series B Preferred Stock or any such
convertible or exchangeable securities or obligations or (d) obligations of the Company to issue or
sell any shares of Common Stock, Series A Preferred Stock or Series B Preferred Stock, any such
convertible or exchangeable securities or obligations, or any such warrants, rights or options. At
the Settlement Date, should the maximum number of Offered Shares be sold, there will be 19,565,106
shares of Common Stock outstanding, 5,721,460 shares of Series A Preferred Stock outstanding,
1,169,881 LTIP Units outstanding, 5,721,460 Series A Preferred OP Units outstanding, warrants to
purchase approximately 25,720 shares of Common Stock outstanding, approximately 1,286 shares of
Series B Preferred Stock, approximately 1,286 Series B Preferred Units of partnership interest in
the Operating Partnership (the "Series B Preferred OP Units") and 19,870,674 OP Units outstanding,
and each such class of securities conforms to the description set out in the Registration Statement,
the General Disclosure Package and the Prospectus.

8
<!-- page 9 -->
(xi) No Equity Awards. Except for grants (including those subject to issuance under the Management
Agreement) disclosed in the Registration Statement, the General Disclosure Package and the
Prospectus, the Company has not granted, to any person or entity a stock option or other
equity-based award of or to purchase Common Stock, Series A Preferred Stock or Series B Preferred
Stock pursuant to an equity-based compensation plan or otherwise. (xii) OP Units and Preferred OP
Units. (1) OP Units. All outstanding OP Units have been duly authorized; all outstanding OP Units
are validly issued and will conform to the information in the Registration Statement, the General
Disclosure Package and the Prospectus and to the description of such OP Units contained therein; the
holders of the outstanding OP Units have no preemptive rights with respect to the outstanding OP
Units; none of the outstanding OP Units have been issued in violation of any preemptive or similar
rights of any security holder; all outstanding OP Units have been issued and sold in compliance with
all applicable federal and state securities laws. Except as disclosed in the Registration Statement,
the General Disclosure Package and the Prospectus, there are no outstanding (a) securities of the
Operating Partnership reserved for any purpose, (b) securities or obligations of the Operating
Partnership convertible into or exchangeable or redeemable for any partnership interests of the
Operating Partnership, (c) warrants, rights or options to subscribe for or purchase from the
Operating Partnership any such partnership interests or any such convertible or exchangeable
securities or obligations or (d) obligations of the Operating Partnership to issue or sell any
partnership interests, any such convertible or exchangeable securities or obligations, or any such
warrants, rights or options. There are 19,870,674 OP Units outstanding, of which the Company owns,
directly or indirectly, 19,565,106 OP Units.

9
<!-- page 10 -->
(2) Series A Preferred OP Units. All outstanding Series A Preferred OP Units have been duly
authorized; all outstanding Series A Preferred OP Units are validly issued and will conform to the
information in the Registration Statement, the General Disclosure Package and the Prospectus and to
the description of such Series A Preferred OP Units contained therein; the holders of the
outstanding OP Units have no preemptive rights with respect to the outstanding Series A Preferred OP
Units; none of the outstanding Series A Preferred OP Units have been issued in violation of any
preemptive or similar rights of any security holder; all outstanding Series A Preferred OP Units
have been issued and sold in compliance with all applicable federal and state securities laws. The
Company Preferred OP Units have been duly authorized; when the Company Preferred OP Units have been
delivered and paid for in accordance with the OP Agreement, the Company Preferred OP Units will be
validly issued and will conform to the information in the Registration Statement, the General
Disclosure Package and the Prospectus and to the description of such Company Preferred OP Units
contained therein; there are no outstanding preemptive rights with respect to the Company Preferred
OP Units; none of the outstanding Company Preferred OP Units have been issued in violation of any
preemptive or similar rights of any security holder; all Company Preferred OP Units have been and
will be, issued and sold in compliance with all applicable federal and state securities laws. There
are 5,321,460 Series A Preferred OP Units outstanding, and at the Settlement Date, should all
Offered Shares be sold pursuant to this Agreement, there will be 5,721,460 Series A Preferred OP
Units outstanding, of which the Company will own, directly or indirectly, 100% of such Series A
Preferred OP Units. (3) Series B Preferred OP Units. All outstanding Series B Preferred OP Units
have been duly authorized; all outstanding Series B Preferred OP Units are validly issued and will
conform to the information in the Registration Statement, the General Disclosure Package and the
Prospectus and to the description of such Series B Preferred OP Units contained therein; the holders
of the outstanding OP Units have no preemptive rights with respect to the outstanding Series B
Preferred OP Units; none of the outstanding Series B Preferred OP Units have been issued in
violation of any preemptive or similar rights of any security holder; all outstanding Series B
Preferred OP Units have been issued and sold in compliance with all applicable federal and state
securities laws. Except as disclosed in the Registration Statement, the General Disclosure Package
and the Prospectus, there are no outstanding (a) securities of the Operating Partnership reserved
for any purpose, (b) securities or obligations of the Operating Partnership convertible into or
exchangeable or redeemable for any partnership interests of the Operating Partnership, (c) warrants,
rights or options to subscribe for or purchase from the Operating Partnership any such partnership
interests or any such convertible or exchangeable securities or obligations or (d) obligations of
the Operating Partnership to issue or sell any partnership interests, any such convertible or
exchangeable securities or obligations, or any such warrants, rights or options. As of the
Settlement Date there are approximately 1,286 Series B Preferred OP Units outstanding, of which the
Company owns, directly or indirectly, 100% of Series B Preferred OP Units.

10
<!-- page 11 -->
(xiii) No Finder's Fee. Except for the Agent's discounts and commissions payable by the Company to
the Agent in connection with the Offered Shares contemplated herein or as otherwise disclosed in the
Registration Statement, the General Disclosure Package and the Prospectus, there are no contracts,
agreements or understandings that would give rise to a valid claim against the Company or the Agent
for a brokerage commission, finder's fee or other like payment in connection with this offering.
(xiv) Registration Rights. Except as described in the Registration Statement, General Disclosure
Package and the Prospectus, there are no contracts, agreements or understandings by either of the
Transaction Entities or their respective Subsidiaries, on the one hand, and any person, on the other
hand, granting such person the right to require either of the Transaction Entities or such
Subsidiaries to file a registration statement under the Act with respect to any securities of either
of the Transaction Entities or their respective Subsidiaries owned or to be owned by such person or
to require either of the Transaction Entities or such Subsidiaries to include such securities in the
securities registered pursuant to a Registration Statement or in any securities being registered
pursuant to any other registration statement filed by either of the Transaction Entities or such
Subsidiaries under the Act (collectively, "Registration Rights"). (xv) Articles Supplementary. The
articles supplementary of the Company designating the rights and preferences of the Offered Shares
(the "Articles Supplementary"), comply with all applicable requirements under the Maryland General
Corporation Law (the "MGCL").

11
<!-- page 12 -->
(xvi) Listing. The Offered Shares are registered under Section 12(b) of the Exchange Act, which
registration will be maintained pursuant to Section 12(b) of the Exchange Act as of the Settlement
Date; and the Company has applied for approval for the listing of the Offered Shares on the NYSE MKT
and will receive such approval prior to the Settlement Date. (xvii) Absence of Further Requirements.
No consent, approval, authorization, or order of, or filing or registration with, any governmental
agency or body or any court is required for the consummation of the transactions contemplated by
this Agreement, the OP Agreement or any other agreements in connection with the offering, issuance
and sale of the Offered Shares by the Company or the issuance and sale of the Company Preferred OP
Units by the Operating Partnership or the performance of obligations hereunder or pursuant to the
terms of the Offered Shares, except the filing of the Prospectus under the Act and a Form 8-K under
the Exchange Act and except such as have been already obtained or as may be required under state
securities laws, FINRA or the NYSE MKT. (xviii) Title to Property. (1) The Transaction Entities
hold, directly or indirectly through their respective Subsidiaries, good and marketable fee simple
title to all of the real property described in the Registration Statement, the General Disclosure
Package and the Prospectus and the improvements (exclusive of improvements owned by tenants, if
applicable) located thereon (individually, a "Property" and collectively, the "Properties"), in each
case, free and clear of all liens, encumbrances, claims, security interests, restrictions and
defects, except such as are disclosed in the Registration Statement, the General Disclosure Package
and the Prospectus, or do not materially affect the value of such Properties as a whole and do not
materially interfere with the use made and proposed to be made of such Properties as a whole by the
Company; (2) except as set forth in the Registration Statement, the General Disclosure Package and
the Prospectus, none of the Transaction Entities or any of their respective Subsidiaries owns any
real property other than the Properties; (3) except as set forth in the Registration Statement, the
General Disclosure Package and the Prospectus, the mortgages or deeds of trust that encumber certain
of the Properties are not convertible into debt or equity securities of the Transaction Entities and
their respective Subsidiaries and such mortgages and deeds of trust are not cross-defaulted with any
loan not made to, or cross-collateralized to any property not owned directly or indirectly by, the
Transaction Entities or their respective Subsidiaries; (4) each of the Properties complies with all
applicable codes, laws and regulations (including without limitation, building and zoning codes,
laws and regulations and laws relating to access to the Properties), except as would not
individually or in the aggregate materially affect the value of the Properties or interfere in any
material respect with the use made and proposed to be made of the Properties by the Transaction
Entities; (5) except as set forth in the Registration Statement, the General Disclosure Package and
the Prospectus, neither of the Transaction Entities nor their respective Subsidiaries has received
from any governmental authority any written notice of any condemnation of or zoning change affecting
the Properties or any part thereof which if consummated would reasonably be expected to have a
Material Adverse Effect on the Transaction Entities and their respective Subsidiaries, taken as a
whole, and none of the Transaction Entities and their respective Subsidiaries know of any such
condemnation or zoning change which is threatened and, in each case, which if consummated would
reasonably be expected to have a Material Adverse Effect on the Transaction Entities and their
respective Subsidiaries, taken as a whole, whether or not arising from transactions in the ordinary
course of business; (6) no third party has an option or a right of first refusal to purchase any
Property or any portion thereof or direct interest therein, except as such is set forth in the
Registration Statement, the General Disclosure Package and the Prospectus; and (7) each of the
Transaction Entities or one of its respective Subsidiaries has obtained an owner's title insurance
policy, from a title insurance company licensed to issue such policy, on each Property that insures
the Transaction Entities', the respective Subsidiary's fee interest in such Property.

12
<!-- page 13 -->
(xix) Leases. (1) Each of the Transaction Entities or one of its Subsidiaries holds the lessor's
interest under the applicable leases with any tenants occupying each Property (collectively, the
"Leases"); (2) other than the Leases, none of the Transaction Entities or their respective
Subsidiaries has entered into any agreements that would materially affect the value of the
Properties as a whole or would materially interfere with the use made and proposed to be made of
such Properties as a whole by the Transaction Entities; (3) none of the Transaction Entities, their
respective Subsidiaries, or, to the Transaction Entities' knowledge, any other party to any Lease,
is or, upon consummation of the transaction contemplated by this Agreement, will be in breach or
default of any such Lease, except as to any such breach or default as would not have a Material
Adverse Effect on the Transaction Entities and their respective Subsidiaries, taken as a whole; (4)
no event has occurred or, to the Transaction Entities' knowledge, has been threatened in writing,
which with or without the passage of time or the giving of notice, or both, would, individually or
together with all such other events, constitute a default under any Lease, or would, permit
termination, modification or acceleration under such Lease, except as to any such default as would
not have a Material Adverse Effect on the Transaction Entities and their respective Subsidiaries,
taken as a whole; (5) each of the Leases is valid and binding and in full force and effect, subject
to applicable bankruptcy, insolvency, moratorium or other similar laws relating to creditors' rights
and general principles of equity, except as would not have a Material Adverse Effect on the
Transaction Entities or their respective Subsidiaries; and (6) none of the Transaction Entities,
their respective Subsidiaries, or, to the Transaction Entities' knowledge, any other party to any
Lease, is a party to any ground lease, sublease or operating sublease relating to any of their
Properties.

13
<!-- page 14 -->
(xx) Utilities. To the knowledge of the Transaction Entities and their respective Subsidiaries,
water, stormwater, sanitary sewer, electricity and telephone service are all available at the
property lines of each Property over duly dedicated streets or perpetual easements of record
benefiting the applicable Property. (xxi) Absence of Defaults and Conflicts Resulting from
Transaction. The execution, delivery and performance of this Agreement, and the issuance and sale of
the Offered Shares by the Company (including the issuance of the Conversion Shares (as defined
below)) and the issuance and sale of the Company Preferred OP Units by the Operating Partnership,
and the use of net proceeds therefrom as contemplated by the Registration Statement, the General
Disclosure Package and the Prospectus, will not result in a breach or violation of any of the terms
or provisions of, or constitute a default or, to the extent applicable, a Debt Repayment Triggering
Event (as defined below) under or result in the imposition of any lien, charge or encumbrance upon
any property or assets of the Transaction Entities or any of their respective Subsidiaries pursuant
to (A) the Organizational Documents (as defined below) of the Transaction Entities or any of their
respective Subsidiaries, (B) any statute, rule, regulation or order of any governmental agency or
body or any court, domestic or foreign, having jurisdiction over the Transaction Entities or any of
their respective Subsidiaries or any of their Properties, or (C) any agreement, lease, contract,
indenture or other agreement or instrument to which the Transaction Entities or any of their
respective Subsidiaries is a party or by which the Transaction Entities or any of their respective
Subsidiaries is bound or to which any of the Properties of the Transaction Entities or any of their
respective Subsidiaries is subject, and except in case of clause (B) only, for such defaults,
violations, liens, charges or encumbrances that would not, individually or in the aggregate, result
in a Material Adverse Effect. A "Debt Repayment Triggering Event" means any event or condition that
gives, or with the giving of notice or lapse of time would give, the holder of any guarantee, note,
debenture or other evidence of indebtedness (or any person acting on such holder's behalf) the right
to require the satisfaction, repurchase, redemption or repayment of all or a portion of such
indebtedness by the Transaction Entities or any of their respective Subsidiaries. The term
"Organizational Documents" as used herein means (a) in the case of a trust, its declaration of trust
and bylaws; (b) in the case of a corporation, its charter and bylaws; (c) in the case of a limited
or general partnership, its partnership certificate, certificate of formation or similar
organizational documents and its partnership agreement; (d) in the case of a limited liability
company, its articles of organization, certificate of formation or similar organizational documents
and its operating agreement, limited liability company agreement, membership agreement or other
similar agreement; and (e) in the case of any other entity, the organizational and governing
documents of such entity.

14
<!-- page 15 -->
(xxii) Absence of Existing Defaults and Conflicts. Neither of the Transaction Entities nor any of
their respective Subsidiaries is (A) in violation of its respective Organizational Documents; (B) in
default (or with the giving of notice or lapse of time would be in default) under any existing
obligation, agreement, covenant or condition contained in any indenture, loan, contract, note,
agreement, mortgage, lease or other agreement or instrument to which any of them is a party or by
which any of them is bound or to which any of the properties of any of them is subject; or (C) in
violation of any law or statute or any judgment, order, rule or regulation of any court or
arbitrator or governmental or regulatory authority, except in the case of clauses (B) and (C) above,
for any such default or violation that would not, individually or in the aggregate, have a Material
Adverse Effect. (xxiii) Absence of Dividend Restriction. Except as set forth in the Registration
Statement, the General Disclosure Package and the Prospectus, (i) neither of the Transaction
Entities nor any of their respective Subsidiaries is currently prohibited, restricted or limited in
its respective ability to pay, directly or indirectly, distributions or dividends to its equity
holders, limited partners, general partners or members, as applicable, (ii) no Subsidiary is
prohibited, directly or indirectly, from repaying to the Transaction Entities any loans or advances
to such Subsidiary from the Transaction Entities or from transferring any of such Subsidiary's
property or assets to the Transaction Entities or any other Subsidiary and (iii) the Operating
Partnership is not prohibited, directly or indirectly, from repaying to the Company any loans or
advances to the Operating Partnership from the Company or from transferring any of the Operating
Partnership's property or assets to the Company. (xxiv) Possession of Licenses and Permits. The
Transaction Entities and each of their respective Subsidiaries possess, and are in compliance with
the terms of, all adequate certificates, authorizations, franchises, licenses and permits
("Licenses") necessary or material to the conduct of the business now conducted or proposed in the
Registration Statement, the General Disclosure Package and the Prospectus to be conducted by them
and have not received any notice of proceedings relating to the revocation or modification of any
Licenses that, if determined adversely to the Transaction Entities or any of their respective
Subsidiaries, would, individually or in the aggregate, have a Material Adverse Effect.

15
<!-- page 16 -->
(xxv) Absence of Labor Dispute. No labor dispute with the employees of the Transaction Entities or
their respective Subsidiaries exists, except as described in the Registration Statement, General
Disclosure Package or Prospectus, or, to the knowledge of the Transaction Entities, is imminent,
which, in any such case, would, singly or in the aggregate, result in a Material Adverse Effect.
(xxvi) Possession of Intellectual Property. The Transaction Entities and their respective
Subsidiaries have access to, adequate patents, patent rights, licenses, inventions, copyrights, know
how (including trade secrets and other unpatented and/or unpatentable proprietary or confidential
information, systems or procedures), trademarks, service marks, trade names or other intellectual
property necessary to conduct the business now operated by them; and neither the Transaction
Entities nor their respective Subsidiaries have received any notice of infringement of or conflict
with asserted rights of others with respect to any of the foregoing which, singly or in the
aggregate, if the subject of an unfavorable decision, ruling or finding, would have a Material
Adverse Effect on the Transaction Entities and their respective Subsidiaries, taken as a whole.
(xxvii) Environmental Laws. Except as described in the Registration Statement, General Disclosure
Package and the Prospectus and except as would not reasonably be expected to result, singly or in
the aggregate, in a Material Adverse Effect, neither of the Transaction Entities nor any of their
respective Subsidiaries (and, to the knowledge of the Transaction Entities, no tenant or subtenant
of any Property or portion thereof owned or leased by the Transaction Entities or their respective
Subsidiaries) is in violation of any Environmental Law, including relating to the release of
Hazardous Materials, and there are no pending or, to the knowledge of the Transaction Entities,
threatened administrative, regulatory or judicial actions, suits, demands, claims, liens, notices of
noncompliance, investigations or proceedings relating to any such violation or alleged violation.
There are no past or present events, conditions, circumstances, activities, practices, actions,
omissions or plans that could reasonably be expected to give rise to any costs or liabilities to the
Transaction Entities or any of their respective Subsidiaries under, or to interfere with or prevent
compliance by the Transaction Entities or any of their respective Subsidiaries with, Environmental
Laws, except as such would not have a Material Adverse Effect and would not have a material adverse
effect on a Property or a prospective acquisition property described in the Prospectus, or any of
their respective operations, financial results or value. There are no costs or liabilities
associated with Environmental Laws (including, without limitation, any capital or operating
expenditures required for clean-up, closure of properties or compliance with Environmental Laws or
any permit, license or approval, any related constraints on operating activities and any potential
liabilities to third parties) that would, singly or in the aggregate, have a Material Adverse
Effect.

16
<!-- page 17 -->
(xxviii) Accurate Disclosure. The statements in the Registration Statement, the General Disclosure
Package and the Prospectus under the captions "Prospectus Supplement Summary, "Additional Material
Federal Income Tax Considerations," "Bluerock Residential Growth REIT, Inc.," "Description of the
Securities We May Offer," "Description of Capital Stock," "Description of Depositary Shares,"
"Description of Debt Securities," "Description of Warrants," "Description of Units," "Book Entry
Procedures and Settlement," "Important Provisions of Maryland Corporate Law and Our Charter and
Bylaws," "Material Federal Income Tax Considerations," and "Plan of Distribution," insofar as such
statements summarize legal matters, agreements, documents or proceedings discussed therein, are
accurate and fair summaries of such legal matters, agreements, documents or proceedings and present
the information required to be shown. (xxix) Absence of Manipulation. None of the Transaction
Entities, any of their respective Subsidiaries or any affiliates of the Transaction Entities, has
taken, directly or indirectly, any action that is designed to or that has constituted or that would
cause or result in the stabilization or manipulation of the price of any security of the Company to
facilitate the sale or resale of the Offered Shares. (xxx) Statistical and Market-Related Data. Any
third-party statistical and market-related data included in the Registration Statement, the General
Disclosure Package and the Prospectus are based on or derived from sources that the Transaction
Entities believe to be reliable and accurate and, to the extent required, they have obtained written
consent to use such data from such sources. (xxxi) Compliance with the Sarbanes-Oxley Act. There is
and has been no failure on the part of the Company or any of the Company's directors or officers, in
their capacities as such, to comply in all material respects with any applicable provision of the
Sarbanes-Oxley Act and the rules and regulations promulgated in connection therewith, including
Section 402 related to loans and Sections 302 and 906 related to certifications. (xxxii) Internal
Controls. The Transaction Entities and each of their respective subsidiaries maintain (A) effective
internal controls over financial reporting (as defined under Rule 13a-15 and Rule 15d-15 under the
Exchange Act) and (B) a system of internal accounting controls sufficient to provide reasonable
assurance that (i) transactions are executed in accordance with management's general or specific
authorizations; (ii) transactions are recorded as necessary to permit preparation of financial
statements in conformity with U.S. generally accepted accounting principles ("GAAP") and to maintain
asset accountability; (iii) access to assets is permitted only in accordance with management's
general or specific authorization; and (iv) the recorded accountability for assets is compared with
the existing assets at reasonable intervals and appropriate action is taken with respect to any
differences. Except as described in the Registration Statement, the General Disclosure Package and
the Prospectus, since the end of the Company's most recent audited fiscal year, there has been (i)
no material weakness in the Company's internal control over financial reporting (whether or not
remediated) and (ii) no change in the Company's internal control over financial reporting that has
materially affected, or is reasonably likely to materially affect, the Company's internal control
over financial reporting. Other than as set forth in the Registration Statement, the General
Disclosure Package and the Prospectus, since the date of the most recent balance sheet of the
Company reviewed or audited by the Company's accountants, (i) the Audit Committee of the Board of
Directors of the Company (the "Board") has not been advised of (A) any significant deficiencies in
the design or operation of internal controls that could adversely affect the ability of the Company
to record, process, summarize and report financial data, or any material weaknesses in internal
controls and (B) any fraud, whether or not material, that involves management or other employees who
have a significant role in the internal controls of the Company, and (ii) there have been no
significant changes in internal controls over financial reporting that has materially affected the
Company's internal controls over financial reporting, including any corrective actions with regard
to significant deficiencies and material weaknesses.

17
<!-- page 18 -->
(xxxiii) Disclosure Controls. The Company and its subsidiaries maintain an effective system of
"disclosure controls and procedures" (as defined in Rule 13a-15(e) and Rule 15d-15 under the
Exchange Act) that complies with the requirements of the Exchange Act and that has been designed to
provide reasonable assurances that information required to be disclosed by the Company in reports
that it files or submits under the Exchange Act is recorded, processed, summarized and reported
within the time periods specified in the Commission's rules and forms, including controls and
procedures designed to ensure that such information is accumulated and communicated to the Company's
management as appropriate to allow timely decisions regarding required disclosure, and such
disclosure controls and procedures are effective in all material respects to perform the functions
for which they were established. (xxxiv) XBRL. The interactive data in extensible Business Reporting
Language included in the Registration Statement fairly presents the information called for in all
material respects and has been prepared in accordance with the Commission's rules and guidelines
applicable thereto.

18
<!-- page 19 -->
(xxxv) Litigation. Other than as described in the Registration Statement, General Disclosure Package
and Prospectus, there are no pending actions, suits or proceedings (including any inquiries or
investigations by any court or governmental agency or body, domestic or foreign) against or
affecting the Transaction Entities or any of their respective Subsidiaries or Properties that, if
determined adversely to the Transaction Entities or any of their respective Subsidiaries or
Properties, would materially and adversely affect the ability of the Transaction Entities to perform
their respective obligations under this Agreement, or which are otherwise material in the context of
the sale of the Offered Shares; and no such actions, suits or proceedings (including any inquiries
or investigations by any court or governmental agency or body, domestic or foreign) are threatened
or, to the Transaction Entities' knowledge, contemplated against their respective Subsidiaries or
the Properties. (xxxvi) Financial Statements; Non-GAAP Financial Measures. The financial statements
of the Company and its consolidated subsidiaries included in the Registration Statement, the General
Disclosure Package and the Prospectus, together with the related schedules and notes, present fairly
in all material respects the financial position of the Company and its consolidated subsidiaries as
of the dates indicated, and the balance sheet, statements of operations, changes in members' equity
and cash flows of the Company and its consolidated subsidiaries for the periods specified; said
financial statements have been prepared in conformity with GAAP applied on a consistent basis
throughout the periods involved and comply with the Commission's rules and guidelines with respect
thereto. The supporting schedules included in the Registration Statement, the General Disclosure
Package and the Prospectus relating to the Company and its consolidated subsidiaries present fairly
in accordance with GAAP the information required to be stated therein. The combined statements of
revenue and certain expenses included in the Registration Statement, the General Disclosure Package
and the Prospectus, together with the related notes, comply with Rule 8-06 of Regulation S-X and
present fairly in all material respects the revenue and certain expenses of the applicable Property
for the periods specified; said financial statements have been prepared in conformity with GAAP
applied on a consistent basis throughout the periods involved and comply with the Commission's rules
and guidelines with respect thereto. The selected financial data and the summary financial
information included in the Registration Statement, the General Disclosure Package and the
Prospectus present fairly the information shown therein and have been compiled on a basis consistent
with that of the audited, or unaudited as applicable, financial statements of the Company and its
consolidated Subsidiaries included therein and comply with the Commission's rules and guidelines
with respect thereto. The pro forma financial statements, if any, and the related notes thereto
included in the Registration Statement, the General Disclosure Package and the Prospectus present
fairly in all material respects the information shown therein, comply with the Commission's rules
and guidelines with respect to pro forma financial statements and have been properly compiled on the
bases described therein, and the assumptions used in the preparation thereof are reasonable and the
adjustments used therein are appropriate to give effect to the transactions and circumstances
referred to therein. Except as included therein, no historical or pro forma financial statements or
supporting schedules are required to be included in the Registration Statement, the General
Disclosure Package or the Prospectus under the Act or Rules and Regulations thereunder. All
disclosures contained in the Registration Statement, the General Disclosure Package or the
Prospectus regarding "non- GAAP financial measures" (as such term is defined by the Rules and
Regulations ) comply with Regulation G of the Exchange Act and Item 10 of Regulation S-K of the Act
to the extent applicable.

19
<!-- page 20 -->
(xxxvii) No Material Adverse Change in Business. Except as disclosed in the Registration Statement,
the General Disclosure Package and the Prospectus, since the end of the period covered by the latest
audited financial statements included therein (A) there has been no change, nor any development or
event involving a prospective change, in the condition (financial or otherwise), results of
operations, business, earnings, properties or prospects of the Transaction Entities and their
respective subsidiaries, taken as a whole, that is material and adverse, (B) there has been no
dividend or distribution of any kind declared, paid or made by the Transaction Entities and the
Subsidiaries, on any class of the capital stock, membership interest or other equity interest, as
applicable, except as would not have been required to be disclosed pursuant to the Exchange Act or
the Exchange Act Regulations, (C) there has been no material change in the capital shares of stock,
short-term indebtedness, long-term indebtedness, net current assets or net assets of the Transaction
Entities or any of their respective Subsidiaries, (D) there has not been any material transaction
entered into or any material transaction that is probable of being entered into by the Transaction
Entities and their respective Subsidiaries, other than transactions in the ordinary course of
business and changes and transactions disclosed or described in the Registration Statement, the
General Disclosure Package and the Prospectus, (E) there has not been any obligation, direct or
contingent, which is material to the Transaction Entities and their respective Subsidiaries, taken
as a whole, incurred by the Transaction Entities and their respective Subsidiaries, except
obligations incurred in the ordinary course of business and changes and transactions disclosed or
described in the Registration Statement, the General Disclosure Package and the Prospectus, and (F)
none of the Transaction Entities or any of their subsidiaries has sustained any loss or interference
with its business from fire, explosion, flood or other calamity, whether or not covered by
insurance, or from any labor disturbance or dispute or any action, order or decree of any court or
arbitrator or governmental or regulatory authority that would, singly or in the aggregate, have a
Material Adverse Effect.

20
<!-- page 21 -->
(xxxviii) Investment Company Act. Neither of the Transaction Entities are, nor after giving effect
to the offering and sale of the Offered Shares and the application of the proceeds thereof as
described in the Registration Statement, the General Disclosure Package and the Prospectus, will be
required to register as an "investment company" as defined in the Investment Company Act of 1940, as
amended (the "Investment Company Act"). (xxxix) Indebtedness. Neither the Transaction Entities nor
any of their respective Subsidiaries has any indebtedness as of the date of this Agreement, and
neither the Transaction Entities nor any of their respective Subsidiaries will have any indebtedness
immediately prior to the sale of the Offered Shares on the Settlement Date, in each case except as
disclosed in the Registration Statement, the General Disclosure Package and the Prospectus. (xl)
Insurance. The Transaction Entities and each of their respective Subsidiaries are insured by
insurers with appropriately rated claims paying abilities against such losses and risks and in such
amounts as are prudent and customary for the businesses in which they are engaged; all policies of
insurance and fidelity or surety bonds insuring the Transaction Entities, their respective
Subsidiaries or their respective businesses, assets, employees, officers and directors are in full
force and effect; neither of the Transaction Entities nor any of their respective Subsidiaries has
been refused any insurance coverage sought or applied for; neither of the Transaction Entities nor
any of their respective Subsidiaries has any reason to believe that it will not be able to renew its
existing insurance coverage as and when such coverage expires or to obtain similar coverage from
similar insurers as may be necessary to continue its business at a similar cost as currently paid,
except as set forth in or contemplated in the Registration Statement, the General Disclosure Package
and the Prospectus; and the Company has obtained or will obtain directors' and officers' insurance
in such amounts as is customary for companies engaged in the type of business conducted by the
Company. (xli) Tax Law Compliance. Each of the Transaction Entities and the Subsidiaries has timely
filed all federal, state and local tax returns that are required to be filed or has timely requested
extensions thereof ("Returns"), except for any failures to file that, individually or collectively,
would not result in a Material Adverse Effect, and has paid all taxes required to be paid by it and
any other assessment, fine or penalty levied against it, to the extent that any of the foregoing is
due and payable, except for any such assessments, fines or penalties that are currently being
contested in good faith or that, individually or collectively, would not result in a Material
Adverse Effect. No audits or other administrative proceedings or court proceedings are presently
pending against any of the Transaction Entities or the Subsidiaries with regard to any Returns, and
no taxing authority has notified any of the Transaction Entities or the Subsidiaries that it intends
to investigate its tax affairs, except for any such audits or investigations that, individually or
collectively, would not result in the assessment of material taxes.

21
<!-- page 22 -->
(xlii) Real Estate Investment Trust. The Company has been organized and has operated in conformity
with the requirements for qualification and taxation as a real estate investment trust (a "REIT")
under the Internal Revenue Code of 1986, as amended (the "Code"), for its taxable years ended
December 31, 2010 through December 31, 2015, and the Company's organization and method of operation
(as described in the Registration Statement, the General Disclosure Package and the Prospectus) will
enable the Company to continue to meet the requirements for qualification and taxation as a REIT
under the Code for its taxable year ending December 31, 2016 and thereafter. All statements
regarding the Company's qualification and taxation as a REIT set forth in the Registration
Statement, the General Disclosure Package and the Prospectus are correct in all material respects.
(xliii) Accuracy of Exhibits. There are no contracts or other documents that are required to be
described in the Registration Statement, the General Disclosure Package or the Prospectus or to be
filed as exhibits to the Registration Statement that are not described or filed as required by Item
601 of Regulation S-K or otherwise under the Rules and Regulations. (xliv) No Restriction on
Subsidiaries. No Subsidiary of the Company is currently prohibited, directly or indirectly, under
any agreement or other instrument to which it is a party or is subject, from paying any dividends to
the Company, from making any other distribution on such Subsidiary's capital stock or membership
interest, from repaying to the Company any loans or advances to such Subsidiary from the Company or
from transferring any of such Subsidiary's properties or assets to the Company or any other
Subsidiary of the Company, except as disclosed in the Registration Statement, the General Disclosure
Package and the Prospectus. (xlv) No Unlawful Payments. None of the Transaction Entities, any of
their respective Subsidiaries, any director or officer or, to the knowledge of the Transaction
Entities, any agent, employee or other person associated with or acting on behalf of the Transaction
Entities or any of their respective Subsidiaries, has (i) used any corporate funds for any unlawful
contribution, gift, entertainment or other unlawful expense relating to political activity; (ii)
made any direct or indirect unlawful payment to any foreign or domestic government official or
employee from corporate funds; (iii) violated or is in violation of any provision of the Foreign
Corrupt Practices Act of 1977, as amended, and the rules and regulations thereunder; or (iv) made
any bribe, rebate, payoff, influence payment, kickback or other unlawful payment.

22
<!-- page 23 -->
(xlvi) Compliance with Anti-Money Laundering Laws. The operations of the Transaction Entities and
their respective Subsidiaries are and have been conducted at all times in compliance with applicable
financial recordkeeping and reporting requirements of the Currency and Foreign Transactions
Reporting Act of 1970, as amended, the applicable anti-money laundering statutes of all
jurisdictions in which the Transaction Entities and their respective Subsidiaries conduct business
or whose Anti-Money Laundering Laws (as defined below) apply to the Transaction Entities, the rules
and regulations thereunder and any related or similar rules, regulations or guidelines, issued,
administered or enforced by any governmental agency (collectively, the "Anti-Money Laundering Laws")
and no action, suit or proceeding by or before any court or governmental agency, authority or body
or any arbitrator involving the Transaction Entities or any of their respective Subsidiaries with
respect to the Anti-Money Laundering Laws is pending or, to the knowledge of the Transaction
Entities, threatened. (xlvii) Compliance with OFAC. None of the Transaction Entities, any of their
respective subsidiaries or, to the knowledge of either of the Transaction Entities, any director,
officer, agent, employee or affiliate thereof is currently subject to any U.S. sanctions
administered by the Office of Foreign Assets Control of the U.S. Department of the Treasury
("OFAC"); and the Company will not, directly or indirectly, use the proceeds of the offering of the
Series A Preferred Stock hereunder, or lend, contribute or otherwise make available such proceeds to
any subsidiary, joint venture partner or other person or entity, for the purpose of financing the
activities of any person currently subject to any U.S. sanctions administered or enforced by OFAC.
(xlviii) Prior Sales of Series A Preferred Stock, Series B Preferred Stock, Series A Preferred OP
Units, Series B Preferred OP Units, Series A OP Units or LTIP Units. Except as disclosed in the
Registration Statement, the General Disclosure Package and the Prospectus, the Company has not sold,
issued or distributed any Series A Preferred Stock and Series B Preferred Stock, and the Operating
Partnership has not issued, sold or distributed any Series A Preferred OP Units, Series B Preferred
OP Units, Series A OP Units or LTIP Units during the six-month period preceding the date hereof.
(xlix) Fourth Amendment to the OP Agreement. The terms of the Fourth Amendment to the OP Agreement
provide for a sufficient number of Series A Preferred OP Units, the terms of which are substantially
similar to the terms of the Series A Preferred Stock.

23
<!-- page 24 -->
(l) Compliance with Laws. Each of the OP Agreement, the First Amendment to the OP Agreement, the
Second Amendment to the OP Agreement, the Third Amendment and the Fourth Amendment to the OP
Agreement comply with all applicable laws and each of the aforementioned amendments to the OP
Agreement have been adopted in accordance with the OP Agreement. (li) Independent Accountants. BDO
USA, LLP and Plante & Moran, PLLC, who have certified the financial statements and supporting
schedules included in the Registration Statement, the General Disclosure Package and the Prospectus
are independent public accountants as required by the Act, the Rules and Regulations and the Public
Company Accounting Oversight Board. (lii) ERISA Matters. The Transaction Entities and each of their
Subsidiaries is in compliance in all material respects with all presently applicable provisions of
the Employee Retirement Income Security Act of 1974, as amended, including the regulations and
published interpretations thereunder ("ERISA"); no "reportable event" (as defined in ERISA) has
occurred with respect to any "pension plan" (as defined in ERISA) for which the Transaction Entities
and each Subsidiary would have any liability; the Transaction Entities and each Subsidiary has not
incurred and does not expect to incur liability under (i) Title IV of ERISA with respect to
termination of, or withdrawal from, any "pension plan" or (ii) Sections 412, 403, 431, 432 or 4971
of the Code; and each "pension plan" for which the Transaction Entities or any Subsidiary would have
any liability that is intended to be qualified under Section 401(a) of the Code is so qualified in
all material respects and nothing has occurred, whether by action or by failure to act, which would
cause the loss of such qualification. (liii) Enforceability of Management Agreement. The Management
Agreement by and among the Transaction Entities and the Manager (the "Management Agreement"), has
been duly authorized by the Transaction Entities and constitutes a valid and binding agreement of
the Transaction Entities enforceable in accordance with its terms, except to the extent limited by
applicable bankruptcy, insolvency, fraudulent conveyance, reorganization, moratorium and similar
laws relating to or affecting creditors' rights and remedies generally, and subject, as to
enforceability, to general principles of equity and, with respect to equitable relief, the
discretion of the court before which any proceeding therefor may be brought (regardless of whether
enforcement is sought in a proceeding at law or in equity). (liv) Subsidiary Partnership Tax
Classification. Each of the Operating Partnership and each Subsidiary that is a partnership or a
limited liability company under state law has been at all relevant times properly classified as a
partnership or a disregarded entity, and not as a corporation or an association taxable as a
corporation, for federal income tax purposes.

24
<!-- page 25 -->
(lv) Related-Party Transactions. There are no relationships, whether direct or indirect, or
related-party transactions involving the Transaction Entities or any of their respective
Subsidiaries or any other person required to be described in the Registration Statement, the General
Disclosure Package or the Prospectus that have not been described as required by the Act. (b)
Certificates of Officers. Any certificate signed by any officer of either Transaction Entity, as
applicable, and delivered to the Agent or its counsel in connection with the offering of the Offered
Shares shall be deemed a representation and warranty by each Transaction Entity, as applicable, as
to matters covered thereby, to the Agent. 2. Representations and Warranties Regarding the Manager.
(a) Representations and Warranties. The Manager represents and warrants to the Agent and agrees with
the Agent that: (i) Good Standing of the Manager. The Manager has been duly organized and is validly
existing as a limited liability company in good standing under the laws of the State of Delaware and
has full power and authority to own, lease and operate its properties and to conduct its business as
described in the Registration Statement, the General Disclosure Package and the Prospectus and to
enter into and perform its obligations under this Agreement; and the Manager and each of its
subsidiaries is duly qualified as a foreign entity to transact business and is in good standing in
each other jurisdiction in which such qualification is required, whether by reason of the ownership
or leasing of property or the conduct of business, except where the failure so to qualify or to be
in good standing would not result in a Material Adverse Effect. (ii) Authorization of Agreement.
This Agreement has been duly authorized, executed and delivered by the Manager. (iii) Absence of
Further Requirements. No consent, approval, authorization, or order of, or filing or registration
with, any court or governmental authority or agency is necessary or required for the performance by
the Manager of its obligations under this Agreement and the Management Agreement, except such as
have been already obtained or as may be required under the Act, Exchange Act Regulations, state
securities laws, FINRA or the NYSE MKT. (iv) Absence of Defaults and Conflicts. The Manager is not
in violation of its organizational documents or in default in the performance or observance of any
obligation, agreement, covenant or condition contained in any contract, indenture, mortgage, deed of
trust, loan or credit agreement, note, lease or other agreement or instrument to which the Manager
is a party or will be a party in connection with this Agreement (including the Management Agreement)
or by which it may be bound, or to which any of the property or assets of the Manager is subject
(collectively, "Manager's Agreements and Instruments"), except for such violations or defaults that
would not result in a Material Adverse Effect; and the execution, delivery and performance of this
Agreement do not and will not, and in the case of the performance of the Management Agreement, will
not, whether with or without the giving of notice or passage of time or both, conflict with or
constitute a breach of, or default or repayment event under, or result in the creation or imposition
of any lien, charge or encumbrance upon any property or assets of the Manager pursuant to, the
Manager's Agreements and Instruments (except for such conflicts, breaches, defaults or repayment
events or liens, charges or encumbrances that would not result in a Material Adverse Effect), nor
will such action result in any violation of (A) the provisions of the Organizational Documents of
the Manager or (B) any statute, law, rule, regulation, or order of any government agency or body or
any court, domestic or foreign, having jurisdiction over the Manager or any of its assets,
properties or operations, except in the case of clause (B) only, for any such violation that would
not result in a Material Adverse Effect.

25
<!-- page 26 -->
(v) Possession of Licenses and Permits. The Manager possesses, and is in compliance with the terms
of, all Licenses necessary or material to the conduct of the business of the Manager now conducted
or proposed in the Registration Statement, the General Disclosure Package and the Prospectus to be
conducted by the Manager, except where the failure to possess such Licenses would not, singly or in
the aggregate, result in a Material Adverse Effect, and has not received any notice of proceedings
relating to the revocation or modification of any Licenses that, if determined adversely to the
Manager would, individually or in the aggregate, have a Material Adverse Effect. (vi) Employment;
Noncompetition; Nondisclosure. The Manager has not been notified that any of its executive officers
or key employees named in the Registration Statement, the General Disclosure Package and the
Prospectus (each, a "Company-Focused Professional") plans to terminate his or her employment with
the Manager. Neither the Manager nor, to the knowledge of the Manager, any Company-Focused
Professional is subject to any noncompete, nondisclosure, confidentiality, employment, consulting or
similar agreement that would be violated by the present or proposed business activities of the
Company or the Manager as described in the Registration Statement, the General Disclosure Package
and the Prospectus. (vii) Accurate Disclosure. The statements regarding the Manager in the
Registration Statement, the General Disclosure Package and the Prospectus under the captions
"Prospectus Supplement Summary," "Risk Factors," "Description of Capital Stock—Distributions" and
"Bluerock Residential Growth REIT, Inc.," are true and correct in all material respects.

26
<!-- page 27 -->
(viii) Absence of Manipulation. The Manager has not taken, and will not take, directly or
indirectly, any action that is designed to or that has constituted or that would be expected to
cause or result in stabilization or manipulation of the price of any security of the Company to
facilitate the sale or resale of the Offered Shares. (ix) Absence of Proceedings. There are no
actions, suits or proceedings (including any inquiries or investigations by any court or
governmental agency or body, domestic or foreign) now pending, or, to the knowledge of the Manager,
threatened against or affecting the Manager that, if determined adversely to the Manager, would,
individually or in the aggregate, have a Material Adverse Effect. (x) Investment Advisers Act. The
Manager is not prohibited by the Investment Advisers Act of 1940, as amended, or the rules and
regulations thereunder, from performing its obligations under the Management Agreement as described
in the Registration Statement, the General Disclosure Package and the Prospectus. (xi)
Enforceability of Management Agreement. The Management Agreement has been duly authorized by all
necessary action and constitutes a valid and binding agreement of the Manager enforceable in
accordance with its terms, except to the extent limited by applicable bankruptcy, insolvency,
fraudulent conveyance, reorganization, moratorium and similar laws relating to or affecting
creditors' rights and remedies generally, and subject, as to enforceability, to general principles
of equity and, with respect to equitable relief, the discretion of the court before which any
proceeding therefor may be brought (regardless of whether enforcement is sought in a proceeding at
law or in equity). (xii) Internal Controls. The Manager operates under the Company's system of
internal accounting controls in order to provide reasonable assurances that (A) transactions
effectuated by it on behalf of the Company pursuant to its duties set forth in the Management
Agreement are executed in accordance with management's general or specific authorization; and (B)
access to the Company's assets is permitted only in accordance with management's general or specific
authorization. (xiii) Resources. The Manager has the financial and other resources available to it
necessary for the performance of its services and obligations as contemplated hereby and in the
Management Agreement, the Registration Statement, the General Disclosure Package and the Prospectus.

27
<!-- page 28 -->
(b) Certificates of Officers. Any certificate signed by any officer of the Manager and delivered to
the Agent or its counsel shall be deemed a representation and warranty by the Manager as to matters
covered thereby, to the Agent. 3. Sale and Delivery of Offered Shares. On the basis of the
representations, warranties and agreements and subject to the terms and conditions set forth herein,
the Agent will use commercially reasonable efforts on behalf of the Company in connection with the
Agent's services hereunder. No offers or sales of the Offered Shares shall be made to any person
without the prior approval of such person by the Company, such approval to be at the reasonable
discretion of the Company. The Agent's aggregate fee for its services hereunder will be an amount
equal to 3.15% of the gross proceeds from the sale of the Offered Shares sold to Purchasers that are
not affiliates of the Agent (such fee payable by the Company at and subject to the consummation of
Settlement). The Company, upon consultation with the Agent, may establish in the Company's sole
discretion an aggregate amount of Shares to be sold in the offering contemplated hereby, which
aggregate amount shall be reflected in the Prospectus. The Company acknowledges and agrees that (i)
there can be no assurance that the Agent will be successful in selling the Offered Shares, and (ii)
the Agent will incur no liability or obligation to the Company or any other person or entity if it
does not sell the Offered Shares for any reason other than a failure by the Agent to use its
commercially reasonable efforts consistent with its normal trading and sales practices to sell such
Offered Shares as required herein. The Company will deliver the Offered Shares to or as directed by
the Agent in a form reasonably acceptable to the Agent at or before 11:30 A.M., New York time, on
May 26, 2016, or at such other time not later than seven (7) full business days thereafter as the
Agent and the Company mutually determine, in the sole discretion of each, such time being herein
referred to as the "Settlement Date". Immediately and only upon receipt of funds equal to the gross
offering price of the Offered Shares, the Agent will then facilitate payment of the proceeds net of
the Agent's fees specified herein, to the Company in Federal (same day) funds by wire transfer to an
account at a bank acceptable to the Agent drawn to the order of the Company at the office of Bass,
Berry & Sims PLC ("BBS"), no later than 5:30 P.M., New York time, on May 26, 2016. If, as of 5 P.M.,
New York time, on the Settlement Date, the settlement of the Offered Shares has not been fully
consummated, including without limitation, receipt of the net offering proceeds by the Company, then
Agent shall use its best efforts to promptly deliver any of the Offered Shares that have been
transferred by the Company to the credit of the Agent's or its designee's account to the Company's
designated account through coordination with the Company and its transfer agent. For purposes of
Rule 15c6-1 under the Exchange Act, the Settlement Date (if later than the otherwise applicable
settlement date) shall be the settlement date for payment of funds and delivery of securities for
all the Offered Shares sold pursuant to the offering. The Offered Shares so to be delivered or
evidence of their issuance will be made available for review at the above office of BBS at least 24
hours prior to the Settlement Date.

28
<!-- page 29 -->
4. Reserved. 5. Certain Agreements of the Transaction Entities and the Manager. (a) The Transaction
Entities agree with the Agent that: (i) Additional Filings. Unless filed pursuant to Rule 462(b) as
part of the Rule 462(b) Registration Statement in accordance with the last sentence, the Company
will file the Prospectus, in a form approved by the Agent, with the Commission pursuant to and in
accordance with Rule 424(b) and Rule 430B and during the time period specified by Rule 424(b) and
Rule 430B. The Company will advise the Agent promptly of any such filing pursuant to Rule 424(b) and
provide satisfactory evidence to the Agent of such timely filing. (ii) Filing of Amendments;
Response to Commission Requests. The Company, subject to Section 5(a)(iii) hereof, will comply with
the requirements of Rule 430B and will promptly advise the Agent of any proposal to amend or
supplement at any time the Registration Statement or any Statutory Prospectus and will not affect
such amendment or supplementation without the Agent's consent; and the Company will also advise the
Agent promptly of (A) any amendment or supplementation of a Registration Statement or any Statutory
Prospectus, (B) any request by the Commission or its staff for any amendment to any Registration
Statement, for any supplement to any Statutory Prospectus or for any additional information, (C) the
institution by the Commission of any stop order proceedings in respect of a Registration Statement
or, to the Company's knowledge, the threatening of any proceeding for that purpose, and (D) the
receipt by the Company of any notification with respect to the suspension of the qualification of
the Offered Shares in any jurisdiction or the institution or, to the Company's knowledge, the
threatening of any proceedings for such purpose. The Company will use its best efforts to prevent
the issuance of any such stop order or the suspension of any such qualification and, if issued, to
obtain as soon as possible the withdrawal thereof. (iii) Reserved.

29
<!-- page 30 -->
(iv) Continued Compliance with Securities Laws. To comply with the Act and the Rules and Regulations
thereunder so as to permit the completion of the distribution of the Offered Shares as contemplated
in this Agreement and in the General Disclosure Package and the Prospectus. If, during such period
after the first date of the placement of the Offered Shares as in the opinion of counsel for the
Agent the Prospectus (or in lieu thereof the notice referred to in Rule 173(a)) is (or, but for the
exception afforded by Rule 172, would be) required by law to be delivered in connection with sales
by an Agent or dealer, any event shall occur or condition exist as a result of which it is
necessary, in the opinion of counsel for the Agent or for the Company, to (i) amend the Registration
Statement in order that the Registration Statement will not include an untrue statement of a
material fact or omit to state a material fact required to be stated therein or necessary to make
the statements therein not misleading, (ii) amend or supplement the General Disclosure Package or
the Prospectus in order that the General Disclosure Package or the Prospectus, as the case may be,
will not include any untrue statement of a material fact or omit to state a material fact necessary
in order to make the statements therein not misleading in the light of the circumstances existing at
the time it is delivered to a purchaser or (iii) amend the Registration Statement or amend or
supplement the General Disclosure Package or the Prospectus, as the case may be, in order to comply
with the requirements of the Act or the Rules and Regulations thereunder, the Company will promptly
(A) notify the Agent of such event, (B) prepare any amendment or supplement as may be necessary to
correct such statement or omission or to make the Registration Statement, the General Disclosure
Package or the Prospectus comply with such requirements and, a reasonable amount of time prior to
any proposed filing or use, furnish the Agent with copies of any such amendment or supplement and
(C) file with the Commission any such amendment or supplement; provided, that the Company shall not
file or use any such amendment or supplement to which the Agent or its counsel shall reasonably
object. The Company will give the Agent notice of its intention to make any filings pursuant to the
Exchange Act or Rules and Regulations thereunder from the date of this Agreement to the Settlement
Date and will furnish the Agent with copies of any such documents a reasonable amount of time prior
to such proposed filing, as the case may be, and will not file or use any such document to which the
Agent or its counsel shall reasonably object, other than such filings as are required to be made
pursuant to the Exchange Act or the Rules and Regulations thereunder. (v) Rule 158. The Company will
timely file such reports pursuant to the Exchange Act as are necessary in order to make generally
available to its stockholders as soon as practicable an earnings statement for the purposes of, and
to provide to the Agent the benefits contemplated by, the last paragraph of Section 11(a) of the
Act. (vi) Furnishing of Registration Statements and Prospectuses. The Company will furnish to the
Agent signed copies of each Registration Statement (including all exhibits thereto), each related
Statutory Prospectus, and, so long as a prospectus relating to the Offered Shares is (or but for the
exemption in Rule 172 would be) required to be delivered under the Act, the Prospectus and all
amendments and supplements to such documents, in each case in such quantities as the Agent requests.
The Prospectus shall be so furnished on or prior to 9:00 A.M., New York time, on the business day
following the execution and delivery of this Agreement, or at such time as otherwise agreed to by
the Agent. All other documents shall be so furnished as soon as available. The Company will pay the
expenses of printing and distributing to the Agent all such documents.

30
<!-- page 31 -->
(vii) Blue Sky Qualifications. The Company will arrange for the qualification of the Offered Shares
for sale under the laws of such jurisdictions as the Agent designate and will continue such
qualifications in effect so long as required for the distribution but in no event longer than one
year. (viii) Reporting Requirements. The Company, during the period when a prospectus relating to
the Offered Shares is (or, but for the exception afforded by Rule 172, would be) required to be
delivered under the Act, will file all documents required to be filed with the Commission pursuant
to the Exchange Act within the time periods required by the Exchange Act and Rules and Regulations
related thereto. (ix) Payment of Expenses. The Transaction Entities will pay all expenses incident
to the performance of their obligations under this Agreement and all the costs and expenses in
connection with the offering of the Offered Shares including but not limited to (A) any filing fees
and other expenses incurred in connection with qualification of the Offered Shares for sale under
the laws of such jurisdictions as the Agent designate and the preparation and printing of blue sky
surveys or legal investment surveys relating thereto, (B) costs and expenses related to the review
by the Financial Industry Regulatory Authority, Inc. ("FINRA") of the Offered Shares (including
filing fees and the fees and expenses of counsel for the Agent relating to such review), (C) costs
and expenses of legal counsel for the Agent incurred in connection with this Agreement and the
offering of the Offered Shares not to exceed $35,000, (D) costs and expenses of the Company relating
to investor presentations and any road show in connection with the offering and sale of the Offered
Shares, if any, including, without limitation, (1) any travel expenses of the Company's officers and
employees and (2) any other expenses of the Company, including all actually and reasonably incurred
costs and expenses of the Agent advanced on behalf of the Company relating to the investor
presentations and any roadshow in connection with the offering and sale of the Offered Shares, (E)
the fees and expenses incident to listing the Offered Shares and Conversion Shares on the NYSE MKT,
(F) expenses incurred in distributing the Prospectus (including any amendments and supplements
thereto) to the Agent, (G) expenses incurred for preparing, printing and distributing any Issuer
Free Writing Prospectuses to investors or prospective investors, (H) stamp duties, similar taxes or
duties or other similar fees or charges, if any, incurred by the Agent in connection with the
offering and sale of the Offered Shares; provided, however that the Transaction Entities shall have
no obligation to pay any costs and expenses of the Agent relating to the investor presentations and
any roadshow in connection with the offering and sale of the Offered Shares, other than costs and
expenses advanced on behalf of the Company in accordance with (D) above.

31
<!-- page 32 -->
(x) Use of Proceeds. The Company will use the net proceeds received in connection with the offering
and sale of the Offered Shares and will cause the Operating Partnership to use the net proceeds
received in connection with the issuance and sale of the Company Preferred OP Units in the manner
described in the "Use of Proceeds" section of the Registration Statement, the General Disclosure
Package and the Prospectus, and, except as disclosed in the Registration Statement, the General
Disclosure Package and the Prospectus, the Company does not intend to use any of the proceeds from
the sale of the Offered Shares hereunder to repay any outstanding debt owed to any affiliate of the
Agent. (xi) Absence of Manipulation. The Transaction Entities will not, and will cause each of its
subsidiaries and controlled affiliates not to, take, directly or indirectly, any action designed to
or that would constitute or that might cause or result in, stabilization or manipulation of the
price of any securities of the Company to facilitate the sale or resale of the Offered Shares. (xii)
Listing. The Company will maintain the registration of the Offered Shares pursuant to Section 12(b)
of the Exchange Act as of the Settlement Date; and the Company will cause the Offered Shares to be
listed on the NYSE MKT on or prior to the Settlement Date. (xiii) Maryland Law. The Company will use
its best efforts to comply with all applicable requirements under the MGCL with respect to the
Offered Shares. (xiv) Sarbanes-Oxley Act. The Company will use its reasonable best efforts to comply
with all applicable provisions of the Sarbanes-Oxley Act. (xv) Reserved. (xvi) Qualification and
Taxation as a REIT. The Company will use its best efforts to qualify for taxation as a REIT under
the Code for its taxable year ending December 31, 2016 and thereafter, unless the Board determines
that it is no longer in the best interests of the Company to continue to qualify as REIT. (xvii)
Market Value. The aggregate market value of the Company's outstanding voting and nonvoting common
equity computed pursuant to General Instruction I.B.1 of Form S-3 equaled or exceeded $75 million as
of a date within 60 days prior to the date of filing of the Registration Statement. (xviii)
Conversion Shares. (i) Following issuance and delivery of the Series A Preferred Stock in accordance
with this Agreement, the Series A Preferred Stock will be redeemable at the option of holders of the
Series A Preferred Stock beginning October 21, 2022 as provided in Articles Supplementary, and any
such redemption by a holder may be settled at the option of the Company in cash, shares of Common
Stock (the "Conversion Shares"), or a combination of cash and shares of Common Stock in accordance
with the Articles Supplementary; upon approval of the issuance of the Conversion Shares by the
Board, the Conversion Shares will be duly authorized and reserved for issuance upon such conversion
by all necessary corporate action and such Conversion Shares, when issued upon such redemption in
accordance with the Articles Supplementary, will be validly issued and will be fully paid and
non-assessable, and will conform to the description of the Common Stock contained in the General
Disclosure Package and the Prospectus; (ii) no holder of the Conversion Shares will be subject to
personal liability by reason of being such a holder; (iii) the issuance of such Conversion Shares
upon such redemption will not be subject to the preemptive or other similar rights of any security
holder of the Company; (iv) the Board will make any and all determinations concerning the future
issuance of the Conversion Shares; (v) the Company will not issue Conversion Shares unless the
issuance thereof will comply with all applicable laws and rules and regulations of the NYSE MKT or
any exchange on which the Common Stock or Series A Preferred Stock of the Company is listed; (vi)
the Company will not issue Conversion Shares, unless upon such issuance the Conversion Shares will
be free of transfer restrictions under applicable law and freely tradable by non-affiliates; and
(vii) the Conversion Shares will be listed, pursuant to a supplemental listing application or
otherwise, on the market or exchange where the Common Stock is then registered.

32
<!-- page 33 -->
(xix) Amendment of Company Organizational Documents. To the extent necessary for the holders of
Series A Preferred Stock to exercise their voting rights as described in the Articles Supplementary,
the Company will make all necessary amendments to its Bylaws in order to effectuate such voting
rights. (xx) Investment Company. The Company will not, and the Operating Partnership will not, be or
become, at any time prior to the expiration of three years after the date of this Agreement, an
"investment company," as such term is defined in the Investment Company Act; provided, however, that
this provision shall not be applicable and shall have no legal force or effect in the event that the
Company becomes deemed an "investment company" solely as a result of the Commission amending,
revising, rescinding or otherwise modifying the Investment Company Act, the rules and regulations
promulgated thereunder or the Commission's interpretations and guidance relating thereto after the
Settlement Date. (b) The Manager agrees with the Agent that: (i) Reporting of Material Events. The
Manager agrees that, during the period when the Prospectus is required to be delivered under the Act
or the Exchange Act, it shall notify the Agent and the Transaction Entities of the occurrence of any
material events respecting its activities or condition, financial or otherwise, and the Manager will
forthwith supply such information to the Transaction Entities as shall be necessary in the opinion
of counsel to the Transaction Entities and the Agent for the Transaction Entities to prepare any
necessary amendment or supplement to the Prospectus so that, as so amended or supplemented, the
Prospectus will not contain an untrue statement of a material fact or omit to state a material fact
necessary in order to make the statements therein, in the light of the circumstances existing at the
time it is delivered to a purchaser, not misleading.

33
<!-- page 34 -->
(ii) No Stabilization or Manipulation. Not to take, directly or indirectly, any action designed to
or that could reasonably be expected to cause or result in any stabilization or manipulation of the
price of any securities of the Company to facilitate the sale or resale of the Offered Shares. (iii)
Investment Adviser. The Manager will not be or become, at any time prior to the expiration of three
years after the date of this Agreement, an "investment adviser," as such term is defined in the
Investment Advisers Act of 1940, as amended (the "Investment Advisers Act"). 6. Free Writing
Prospectuses. The Company represents and agrees that, unless it obtains the prior consent of the
Agent, and the Agent represents and agrees that, unless it obtains the prior consent of the Company,
it has not made and will not make any offer relating to the Offered Shares that would constitute an
Issuer Free Writing Prospectus, or that would otherwise constitute a "free writing prospectus," as
defined in Rule 405, required to be filed with the Commission; provided, that such consent is deemed
to have been given with respect to each Issuer Free Writing Prospectus identified on Schedule A
hereto and any "road show that is a written communication" within the meaning of Rule 433(d)(8)(i)
that has been reviewed and approved by the Agent. Any such free writing prospectus consented to by
the Company and the Agent is hereinafter referred to as a "Permitted Free Writing Prospectus." The
Company represents that it has treated and agrees that it will treat each Permitted Free Writing
Prospectus as an "issuer free writing prospectus," as defined in Rule 433, and has complied and will
comply with the requirements of Rules 164 and 433 applicable to any Permitted Free Writing
Prospectus, including timely Commission filing where required, legending and record keeping. The
Company represents that it has satisfied and agrees that it will satisfy the conditions in Rule 433
to avoid a requirement to file with the Commission any Bona Fide Electronic Road Show. If at any
time following the issuance of a Permitted Free Writing Prospectus there occurred or occurs an event
or development as a result of which such Permitted Free Writing Prospectus conflicted or would
conflict with the information contained in the Registration Statement, the General Disclosure
Package or the Prospectus, or included or would include an untrue statement of a material fact or
omitted or would omit to state a material fact necessary in order to make the statements therein, in
the light of the circumstances existing at that subsequent time, not misleading, the Company will
promptly notify the Agent and will promptly amend or supplement, at its own expense, such Permitted
Free Writing Prospectus to eliminate or correct such conflict, untrue statement or omission

34
<!-- page 35 -->
7. Conditions of the Obligations of the Agent. The obligations of the Agent with respect to the
consummation of the transactions contemplated hereby will be subject to the accuracy of the
representations and warranties of the Transaction Entities and the Manager herein (as though made on
the Settlement Date), to the accuracy of the statements of the Transaction Entities and the Manager
made pursuant to the provisions hereof, to the performance by the Transaction Entities and the
Manager of their obligations hereunder, to all contingencies and conditions described in this
Agreement having been met and to the following additional conditions precedent: (a) Accountants'
Comfort Letters and CAO Certificates. (i) The Agent shall have received letters, dated,
respectively, the date hereof and the Settlement Date, of BDO USA, LLP in a form approved by the
Agent and/or Bass, Berry & Sims PLC, confirming that they are a registered public accounting firm
and independent public accountants within the meaning of the Securities Laws and in form and
substance satisfactory to the Agent, containing statements and information of the type ordinarily
included in accountants' "comfort letters" with respect to financial statements and certain
financial information of the Company contained in the Registration Statement, the General Disclosure
Package and the Prospectus (except that, in any letter dated the Settlement Date, the specified date
referred to in the letter shall be a date no more than three (3) days prior to the Settlement Date).
(ii) Should the Agent deem appropriate, the Agent shall have received a certificate, dated the date
hereof, of Christopher J. Vohs, in his capacity as the Chief Accounting Officer and Principal
Financial Officer of the Company, substantially in the form of Annex I-A hereto. (b) Effectiveness
of Registration Statement. If the Effective Time of an additional Registration Statement (if any) is
not prior to the execution and delivery of this Agreement, such Effective Time shall have occurred
not later than 5:00 P.M., New York time, on the date of this Agreement or, if earlier, the time the
Prospectus is finalized and distributed to the Agent, or shall have occurred at such later time as
shall have been consented to by the Agent. The Prospectus shall have been filed with the Commission
in accordance with Rule 424(b) under the Act and Section 5(a) hereof. Prior to the Settlement Date,
no stop order suspending the effectiveness of a Registration Statement, Statutory Prospectus or the
Prospectus shall have been issued and no proceedings for that purpose shall have been instituted or,
to the knowledge of the Company or the Agent, shall be contemplated by the Commission.

35
<!-- page 36 -->
(c) No Material Adverse Change. Subsequent to the execution and delivery of this Agreement, there
shall not have occurred (i) any change, or any development or event involving a prospective change,
in the condition (financial or otherwise), results of operations, business, earnings, properties or
prospects of the Transaction Entities and their respective Subsidiaries, taken as a whole, that, in
the sole judgment of the Agent, is material and adverse and makes it impractical or inadvisable to
market the Offered Shares; (ii) any change in either U.S. or international financial, political or
economic conditions or currency exchange rates or exchange controls the effect of which is such as
to make it, in the judgment of the Agent, impractical to market or to enforce contracts for the sale
of the Offered Shares, whether in the primary market or in respect of dealings in the secondary
market; (iii) any suspension or material limitation of trading in securities generally on the NYSE
MKT, or any setting of minimum or maximum prices for trading on such exchange; (iv) or any
suspension of trading of any securities of the Company on any national securities exchange or in the
over-the-counter market; (v) any banking moratorium declared by any U.S. federal or New York
authorities; (vi) any major disruption of settlements of securities, payment, or clearance services
in the United States or any other country where such securities are listed; or (vii) any attack on,
outbreak or escalation of hostilities or act of terrorism involving the United States, any
declaration of war by Congress or any other national or international calamity or emergency if, in
the judgment of the Agent, the effect of any such attack, outbreak, escalation, act, declaration,
calamity or emergency is such as to make it impractical or inadvisable to market the Offered Shares
or to enforce contracts for the sale of the Offered Shares. (d) Opinion of Counsel for the
Transaction Entities. The Agent shall have received an opinion, dated the Settlement Date, of
Kaplan, Voekler, Cunningham & Frank, PLC, counsel for the Transaction Entities, substantially in the
form attached hereto as Annex III-A and a letter substantially in the form attached hereto as Annex
III-B. (e) Opinion of Maryland Counsel for Company. The Agent shall have received an opinion, dated
the Settlement Date, of Venable LLP, Maryland counsel for the Company, substantially in the form
attached hereto as Annex IV. (f) Tax Opinion. The Agent shall have received a tax opinion, dated the
Settlement Date, of Vinson & Elkins, LLP, counsel for the Company, substantially in the form
attached hereto as Annex V. (g) Opinion of Counsel for Agent. The Agent shall have received from
Bass, Berry & Sims PLC, counsel for the Agent, such opinion or opinions, dated the Settlement Date,
with respect to such matters as the Agent may require. In rendering such opinion, Bass, Berry & Sims
PLC, may (i) rely as to matters of fact (but not as to legal conclusions), to the extent they deem
proper, on certificates of responsible officers of the Transaction Entities, their respective
Subsidiaries, the Manager and of public officials and (ii) rely as to matters involving the
application of the laws of the state of Maryland upon the opinion of Venable LLP.

36
<!-- page 37 -->
(h) Company Officers' Certificate. The Agent shall have received a certificate, dated the Settlement
Date, of the Chief Executive Officer of the Company and the Chief Accounting Officer of the Company,
in his capacity as the Principal Financial Officer of the Company, in which such officers shall
state that: the representations and warranties of the Transaction Entities in this Agreement are
true and correct as of such date; each of the Transaction Entities has complied with all agreements
and satisfied all conditions on its part to be performed or satisfied hereunder at or prior to the
Settlement Date; no stop order suspending the effectiveness of any Registration Statement has been
issued and no proceedings for that purpose have been instituted or, to the best of their knowledge
and after reasonable investigation, are contemplated by the Commission; the 462(b) Registration
Statement (if any) satisfying the requirements of subparagraphs (1) and (3) of Rule 462(b) was
timely filed pursuant to Rule 462(b), including payment of the applicable filing fee in accordance
with the applicable Rules and Regulations; and, subsequent to the date of the most recent financial
statements in the Registration Statement, the General Disclosure Package and the Prospectus, there
has been no change, nor any development or event involving a prospective change, in the condition
(financial or otherwise), results of operations, earnings, business, properties or prospects of the
Transaction Entities and their respective Subsidiaries, taken as a whole, that is material and
adverse, except as set forth in the Registration Statement, the General Disclosure Package and the
Prospectus or as described in such certificate. (i) Manager Officer's Certificate. The Agent shall
have received a certificate, dated the Settlement Date, of the Chief Executive Officer of the
Manager in which such officer shall state that: the representations and warranties of the Manager in
this Agreement are true and correct as of such date and that the Manager has complied with all
agreements and satisfied all conditions on its part to be performed or satisfied hereunder at or
prior to the Settlement Date. (j) Reserved. (k) Rule 462(b) Registration Statement. In the event
that a Rule 462(b) Registration Statement is filed in connection with the offering contemplated by
this Agreement, such Rule 462(b) Registration Statement shall have been filed with the Commission
and shall have become effective automatically upon such filing. (l) Company Good Standing. The Agent
shall have received a certificate of good standing of the Company certified by the Maryland State
Department of Assessments and Taxation as of a date within five (5) business days of the Settlement
Date. (m) Operating Partnership Good Standing. The Agent shall have received a certificate of good
standing of the Operating Partnership certified by the Secretary of State of the State of Delaware
as of a date within five (5) business days of the Settlement Date.

37
<!-- page 38 -->
(n) Manager Good Standing. The Agent shall have received a certificate of good standing of the
Manager certified by the Secretary of State of the State of Delaware as of a date within five (5)
business days of the Settlement Date. (o) Subsidiary Good Standings. The Agent shall have received a
certificate of good standing certified by the Secretary of State (or equivalent governmental
authority) of the state of incorporation or formation as of a date no earlier than April 15, 2016,
for each entity listed on Schedule B hereto. (p) Secretary's Certificate of the Company. The Agent
shall have received a certificate of the secretary of the Company certifying resolutions of the
board of directors of the Company approving the Agreement and the transactions contemplated thereby.
(q) Secretary's Certificate of the Manager. The Agent shall have received a certificate of the
secretary of the Manager certifying resolutions of the Manager's managing member approving the
Agreement and the transactions contemplated thereby. (r) General Partner Certificate of the
Operating Partnership. The Agent shall have received a certificate of the general partner of the
Operating Partnership certifying resolutions of the Operating Partnership approving the Agreement
and the transactions contemplated thereby. (s) FINRA Approval. The Agent shall have received any
required clearance letter from the Corporate Finance Department of FINRA with respect to the
offering. (t) Listing. An application for the listing of the Offered Shares shall have been approved
for listing to the NYSE MKT prior to the Settlement Date. (u) Amendment to OP Agreement. The Fourth
Amendment to the OP Agreement shall be in full force and effect as of the Settlement Date. The
Transaction Entities will furnish the Agent with such conformed copies of such opinions,
certificates, letters and documents as the Agent reasonably request. The Agent may in its sole
discretion waive compliance with any conditions to the obligations of the Agent hereunder.

38
<!-- page 39 -->
8. Indemnification and Contribution. (a) Indemnification of Agent by the Transaction Entities. Each
of the Transaction Entities will, jointly and severally, indemnify and hold harmless the Agent, its
partners, members, directors, officers, employees, agents, affiliates and each person, if any, who
controls the Agent within the meaning of Section 15 of the Act or Section 20 of the Exchange Act
(each, an "Indemnified Party"), against any and all losses, claims, damages or liabilities, joint or
several, to which such Indemnified Party may become subject, under the Act, the Exchange Act, other
Federal or state statutory law or regulation or otherwise, insofar as such losses, claims, damages
or liabilities (or actions in respect thereof) arise out of or are based upon any untrue statement
or alleged untrue statement of any material fact contained in any part of any Registration Statement
at any time, any Statutory Prospectus as of any time, the Prospectus or any Issuer Free Writing
Prospectus, or arise out of or are based upon the omission or alleged omission of a material fact
required to be stated therein or necessary to make the statements therein not misleading, and will
reimburse each Indemnified Party for any legal or other expenses reasonably incurred by such
Indemnified Party in connection with investigating or defending against any loss, claim, damage,
liability, action, litigation, investigation or proceeding whatsoever (whether or not such
Indemnified Party is a party thereto), whether threatened or commenced, and in connection with the
enforcement of this provision with respect to any of the above as such expenses are incurred;
provided, however, that neither of the Transaction Entities will be liable in any such case to the
extent that any such loss, claim, damage or liability arises out of or is based upon an untrue
statement or alleged untrue statement in or omission or alleged omission from any of such documents
in reliance upon and in conformity with written information furnished to the Company by the Agent
specifically for use therein, it being understood and agreed that such information furnished by the
Agent consists only of the information described as such in Section 8(b) below. (b) Indemnification
of Company, Directors and Officers. The Agent will indemnify and hold harmless each of the
Transaction Entities, their directors and each of their officers who signs a Registration Statement
and each person, if any, who controls either of the Transaction Entities within the meaning of
Section 15 of the Act or Section 20 of the Exchange Act (each, an "Agent Indemnified Party"),
against any losses, claims, damages or liabilities to which such Agent Indemnified Party may become
subject, under the Act, the Exchange Act, other Federal or state statutory law or regulation or
otherwise, insofar as such losses, claims, damages or liabilities (or actions in respect thereof)
arise out of or are based upon any untrue statement or alleged untrue statement of any material fact
contained in any part of any Registration Statement at any time, any Statutory Prospectus as of any
time, the Prospectus or any Issuer Free Writing Prospectus, or arise out of or are based upon the
omission or the alleged omission of a material fact required to be stated therein or necessary to
make the statements therein not misleading, in each case to the extent, but only to the extent, that
such untrue statement or alleged untrue statement or omission or alleged omission was made in
reliance upon and in conformity with written information furnished to either of the Transaction
Entities by the Agent specifically for use therein, and will reimburse any legal or other expenses
reasonably incurred by such Agent Indemnified Party in connection with investigating or defending
against any such loss, claim, damage, liability, action, litigation, investigation or proceeding
whatsoever (whether or not such Agent Indemnified Party is a party thereto), whether threatened or
commenced, based upon any such untrue statement or omission, or any such alleged untrue statement or
omission as such expenses are incurred, it being understood and agreed that the only such
information furnished by the Agent consists of the following information in the Prospectus furnished
on behalf of the Agent: the thirteenth full paragraph under the caption "Plan of Distribution" in
the Final Prospectus Supplement and under the caption "Other Relationships," in each case, only to
the extent that such statements relate only to the Agent.

39
<!-- page 40 -->
(c) Actions against Parties; Notification. Promptly after receipt by an indemnified party of notice
of the commencement of any action against such indemnified party, such indemnified party will, if a
claim in respect thereof is to be made against the indemnifying party under subsections (a), (b) or
(c) above, notify the indemnifying party of the commencement thereof; but the failure to notify the
indemnifying party shall not relieve it from any liability that it may have under subsections (a),
(b) or (c) above except to the extent that it has been materially prejudiced (through the forfeiture
of substantive rights or defenses) by such failure; and provided further that the failure to notify
the indemnifying party shall not relieve it from any liability that it may have to an indemnified
party otherwise than under subsections (a), (b) or (c) above. In case any such action is brought
against any indemnified party and it notifies the indemnifying party of the commencement thereof,
the indemnifying party will be entitled to participate therein and, to the extent that it may wish,
jointly with any other indemnifying party similarly notified, to assume the defense thereof, with
counsel satisfactory to such indemnified party (who shall not, except with the consent of the
indemnified party, be counsel to the indemnifying party), and after notice from the indemnifying
party to such indemnified party of its election so to assume the defense thereof, the indemnifying
party will not be liable to such indemnified party under this Section 8(c) for any legal or other
expenses subsequently incurred by such indemnified party in connection with the defense thereof
other than reasonable costs of investigation. In any such proceeding, any indemnified party shall
have the right to retain its own counsel, but the fees and expenses of such counsel shall be at the
expense of such indemnified party unless (i) the indemnifying party and the indemnified party shall
have mutually agreed to the contrary; (ii) the indemnifying party has failed within a reasonable
time to retain counsel reasonably satisfactory to the indemnified party; (iii) the indemnified party
shall have reasonably concluded that there may be legal defenses available to it that are different
from or in addition to those available to the indemnifying party; or (iv) the named parties in any
such proceeding (including any impleaded parties) include both the indemnifying party and the
indemnified party and representation of both parties by the same counsel would be inappropriate due
to actual or potential differing interest between them. No indemnifying party shall, without the
prior written consent of the indemnified party, effect any settlement of any pending or threatened
action in respect of which any indemnified party is or could have been a party and indemnity could
have been sought hereunder by such indemnified party unless such settlement (i) includes an
unconditional release of such indemnified party from all liability on any claims that are the
subject matter of such action and (ii) does not include a statement as to, or an admission of,
fault, culpability or a failure to act by or on behalf of an indemnified party. (d) Contribution. If
the indemnification provided for in this Section 8 is unavailable or insufficient to hold harmless
an indemnified party under subsections (a), (b) or (c) above, then each indemnifying party shall
contribute to the amount paid or payable by such indemnified party as a result of the losses,
claims, damages or liabilities referred to in subsections (a), (b) or (c) above (i) in such
proportion as is appropriate to reflect the relative benefits received by the Transaction Entities
on the one hand and by the Agent on the other hand from the offering of the Offered Shares or (ii)
if the allocation provided by clause (i) above is not permitted by applicable law, in such
proportion as is appropriate to reflect not only the relative benefits referred to in clause (i)
above but also the relative fault of the Company, on the one hand, and the Agent, on the other, in
connection with the statements or omissions which resulted in such losses, claims, damages or
liabilities as well as any other relevant equitable considerations. The relative benefits received
by the Transaction Entities on the one hand and by the Agent on the other hand shall be deemed to be
in the same proportion as the total net proceeds from the offering (before deducting expenses)
received by the Company bear to the total underwriting discounts and commissions received by the
Agent. The relative fault shall be determined by reference to, among other things, whether the
untrue or alleged untrue statement of a material fact or the omission or alleged omission to state a
material fact relates to information supplied by the Company or the Agent and the parties' relative
intent, knowledge, access to information and opportunity to correct or prevent such untrue statement
or omission. The amount paid by an indemnified party as a result of the losses, claims, damages or
liabilities referred to in the first sentence of this Section 8(d) shall be deemed to include any
legal or other expenses reasonably incurred by such indemnified party in connection with
investigating or defending any action or claim which is the subject of this Section 8(d).
Notwithstanding the provisions of this Section 8(d), the Agent shall not be required to contribute
any amount in excess of the amount by which the total price at which the Series A Preferred Stock
sold pursuant to this Agreement exceeds the amount of any damages which the Agent has otherwise been
required to pay by reason of such untrue or alleged untrue statement or omission or alleged
omission. No person guilty of fraudulent misrepresentation (within the meaning of Section 11(f) of
the Act) shall be entitled to contribution from any person who was not guilty of such fraudulent
misrepresentation.

40
<!-- page 41 -->
9. Termination of Agency. If the Offered Shares are not sold by May 26, 2016, this Agreement will
terminate without liability on the part of the Company and the Agent, except as provided in Section
10 hereof. As used in this Agreement, the term "Agent" includes any person substituted for the Agent
under this Section 9. 10. Survival of Certain Representations and Obligations. The respective
indemnities, agreements, representations, warranties and other statements of the Transaction
Entities, the Manager or their respective officers and of the Agent set forth in or made pursuant to
this Agreement will remain in full force and effect, regardless of any investigation, or statement
as to the results thereof, made by or on behalf of the Agent, the Transaction Entities, the Manager
or any of their respective representatives, officers or directors or any controlling person, and
will survive delivery of and payment for the Offered Shares. If the settlement of the Offered Shares
by the Agent is not consummated for any reason other than solely because of the termination of this
Agreement pursuant to Section 9 hereof, the Company will reimburse the Agent for all out-of-pocket
expenses (including fees and disbursements of counsel) reasonably incurred by them in connection
with the placement of the Offered Shares, and the respective obligations of the Transaction Entities
and the Manager, on the one hand, and the Agent, on the other hand, pursuant to Section 8 hereof
shall remain in effect. In addition, if the Offered Shares have been settled pursuant to the terms
of the Agreement, the representations and warranties in Sections 2 through 3 and all obligations
under Section 5 shall also remain in effect.

41
<!-- page 42 -->
11. Notices. All communications hereunder will be in writing and, if sent to the Agent, will be
mailed or delivered and confirmed to the Agent, with a copy to Bass, Berry & Sims PLC, 150 Third
Avenue South, Suite 2800, Nashville, TN 37201, Attention: Lori B. Morgan, or, if sent to the
Transaction Entities or the Manager, will be mailed or delivered and confirmed to it at c/o Bluerock
Residential Growth REIT, Inc., 712 Fifth Avenue, 9th Floor, New York, NY 10019, Attention: Michael
L. Konig, with a copy to Kaplan, Voekler, Cunningham & Frank, PLC, 1401 East Cary Street, Richmond,
Virginia 23239, Attention: Richard P. Cunningham, Jr. 12. Successors. This Agreement will inure to
the benefit of and be binding upon the parties hereto and their respective successors and the
officers, directors and controlling persons referred to in Section 9, and no other person will have
any right or obligation hereunder. 13. Counterparts. This Agreement may be executed in any number of
counterparts, each of which shall be deemed to be an original, but all such counterparts shall
together constitute one and the same Agreement. 14. Headings. The headings herein are inserted for
convenience of reference only and are not intended to be part of, or to affect the meaning or
interpretation of, this Agreement. 15. Entire Agreement. This Agreement represents the entire
agreement between the Transaction Entities and the Manager, on the one hand, and the Agent, on the
other, with respect to the preparation of any Registration Statement, the General Disclosure
Package, the Prospectus, the conduct of the offering, and the placement and sale of the Offered
Shares. 16. Absence of Fiduciary Relationship. The Transaction Entities and the Manager each
acknowledge and agree that: (a) No Other Relationship. The Agent has been retained solely to act as
a placement agent in connection with the sale of Offered Shares and that no fiduciary, advisory or
agency relationship between the Transaction Entities and the Manager on the one hand, and the Agent
on the other has been created in respect of any of the transactions contemplated by this Agreement
or the Prospectus, irrespective of whether the Agent has advised or is advising either of the
Transaction Entities or the Manager on other matters; (b) Arms' Length Negotiations. The price of
the Offered Shares set forth in this Agreement was established by the Company following discussions
and arms' length negotiations with the Agent, and the Transaction Entities and Manager are capable
of evaluating and understanding and understands and accepts the terms, risks and conditions of the
transactions contemplated by this Agreement;

42
<!-- page 43 -->
(c) Absence of Obligation to Disclose. The Transaction Entities and the Manager have been advised
that the Agent and its affiliates are engaged in a broad range of transactions which may involve
interests that differ from those of the Transaction Entities and the Manager, and that the Agent has
no obligation to disclose such interests and transactions to Transaction Entities and the Manager by
virtue of any fiduciary, advisory or agency relationship; and (d) Waiver. Each of the Transaction
Entities and the Manager waives, to the fullest extent permitted by law, any claims they may have
against the Agent for breach of fiduciary duty or alleged breach of fiduciary duty and agree that
the Agent shall have no liability (whether direct or indirect) to either of the Transaction Entities
or the Manager in respect of such a fiduciary duty claim or to any person asserting a fiduciary duty
claim on behalf of or in right of the Transaction Entities or the Manager, including stockholders,
holders of membership interests, employees or creditors of the Transaction Entities or the Manager.
17. Trial by Jury. Each of the Transaction Entities and the Manager (on its behalf and, to the
extent permitted by applicable law, on behalf of its stockholders and affiliates) and the Agent
hereby irrevocably waives, to the fullest extent permitted by applicable law, any and all right to
trial by jury in any legal proceeding arising out of or relating to this Agreement or the
transactions contemplated hereby. 18. Applicable Law. This Agreement shall be governed by, and
construed in accordance with, the laws of the State of New York. 19. Jurisdiction. Each of the
Transaction Entities and the Manager hereby submits to the non-exclusive jurisdiction of the Federal
and state courts in the Borough of Manhattan in The City of New York in any suit or proceeding
arising out of or relating to this Agreement or the transactions contemplated hereby. Each of the
Transaction Entities and the Manager irrevocably and unconditionally waives any objection to the
laying of venue of any suit or proceeding arising out of or relating to this Agreement or the
transactions contemplated hereby in Federal and state courts in the Borough of Manhattan in The City
of New York and irrevocably and unconditionally waives and agrees not to plead or claim in any such
court that any such suit or proceeding in any such court has been brought in an inconvenient forum.
20. Termination. Until the Settlement Date, this Agreement may be terminated by the Agent by giving
notice (in the manner prescribed by Section 9 hereof) to the Company, if (i) the Company shall have
failed, refused or been unable, at or prior to the Settlement Date, to perform any agreement on its
part to be performed hereunder unless the failure to perform any agreement is due to the default or
omission by the Agent; (ii) any other condition of the obligations of the Agent hereunder is not
fulfilled; (iii) trading in securities generally on the NYSE, NYSE MKT, or Nasdaq shall have been
suspended or minimum or maximum prices shall have been established on either of such exchanges or
such market by the Commission or by such exchange or other regulatory body or governmental authority
having jurisdiction; (iv) trading or quotation in any of the Company's securities shall have been
suspended or materially limited by the Commission or by the NYSE MKT, NYSE or Nasdaq or other
regulatory body of governmental authority having jurisdiction; (v) a general banking moratorium has
been declared by Federal or New York authorities; (vi) a material disruption in securities
settlement, payment or clearance services in the United States shall have occurred; (vii) there
shall have been any material adverse change in general economic, political or financial conditions
in the United States or in international conditions on the financial markets in the United States,
in each case, the effect of which is such as to make it, in the Agent's reasonable judgment,
inadvisable to proceed with the delivery of the Securities; or (viii) any attack on, outbreak or
escalation of hostilities, declaration of war or act of terrorism involving the United States or any
other national or international calamity or emergency has occurred if, in the Agent's reasonable
judgment, the effect of any such attack, outbreak, escalation, declaration, act, calamity or
emergency makes it impractical or inadvisable to proceed with the completion of the placement or the
delivery of the Securities. Any termination of this Agreement pursuant to this Section 21 shall be
without liability on the part of the Company or the Agent, except as otherwise provided in Sections
5(a), 7, 8 and 9 hereof.

43
<!-- page 44 -->
If the foregoing is in accordance with the Agent's understanding of our agreement, kindly sign and
return to the Company one of the counterparts hereof, whereupon it will become a binding agreement
among the Transaction Entities, the Manager and the Agent in accordance with its terms. [Signature
Page Follows]

44
<!-- page 45 -->
Very truly yours, BLUEROCK RESIDENTIAL GROWTH REIT, INC. By: /s/ R. Ramin Kamfar Name: R. Ramin
Kamfar Title: Chief Executive Officer BLUEROCK RESIDENTIAL HOLDINGS, L.P. By: Bluerock Residential
Growth REIT, Inc. Its: General Partner By: /s/ R. Ramin Kamfar Name: R. Ramin Kamfar Title: Chief
Executive Officer BRG MANAGER, LLC By: Bluerock Real Estate, L.L.C. Its: Sole Member By: /s/ R.
Ramin Kamfar Name: R. Ramin Kamfar Title: Chief Executive Officer [Signature Page to Agreement]

45
<!-- page 46 -->
The foregoing Agreement is hereby confirmed and accepted as of the date first above written. Acting
on behalf of itself as the Agent COMPASS POINT RESEARCH & TRADING, LLC By: /s/ Christopher A. Nealon
Name: Christopher A. NealonTitle: President and Chief Operating Officer [Signature Page to
Agreement]

46
<!-- page 47 -->
SCHEDULE A None
