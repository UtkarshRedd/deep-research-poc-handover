<!-- page 1 -->
# Master Services Agreement
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2020-02-05 |
| Parties | Kubient Inc. ("Kubient"); The Associated Press (the "Customer")(individually as a "Party" and collectively as the "Parties") |
| Source | CUAD v1 / KUBIENT,INC_07_02_2020-EX-10.14-MASTER SERVICES AGREEMENT_Part1 |

Exhibit 10.14 MASTER SERVICES AGREEMENT This Master Services Agreement (the "Agreement"), dated as
of the 5th day of February, 2020 (the "Effective Date"), is by and between Kubient Inc., with
offices located at 330 7th Avenue, 10th Floor, New York, NY 10001 ("Kubient") and The Associated
Press, a New York not-for-profit corporation with principal place of business located at 200 Liberty
Street, New York, NY 10281 (the "Customer"). Each of Customer and Kubient may be referred to herein
individually as a "Party" and collectively as the "Parties". WHEREAS, Customer wishes to increase
the revenue derived from its traffic, content, websites, applications, podcasts, audience and
database, and would like to retain Kubient to support and assist in that process as described
herein; For good and valuable consideration, the receipt of which is acknowledged by each Party, the
Parties agree as follows: 1. Kubient Services. The services provided by Kubient pursuant to each
specific engagement by Customer (the "Service" or "Services") shall be set forth and detailed in
individual exhibits attached hereto (each an "Exhibit"), which shall be subject to the terms and
conditions hereof and be incorporated as part of this Agreement. Kubient shall use reasonable
efforts to provide to Customer the Services. Customer agrees to provide all reasonable and necessary
access, support and cooperation for Kubient to provide the Services in a timely and effective
manner. Nothing herein is intended nor shall be construed as creating an exclusive arrangement
between Customer and Kubient. This Agreement will not restrict Customer offering Inventory via other
agents or otherwise selling Inventory to any third parties. 2. Kubient License. In the event
Customer shall utilize Kubient's ad serving technology as part of the Services, Kubient hereby
grants to Customer a limited, royalty-free, non-exclusive, non-transferable, non-assignable, without
right of sublicense, revocable license to access, participate in and use to the full extent the
Auction Platform as hosted by Kubient, for the purpose of serving Inventory at Target Demand (" ").
The Auction Platform will place Creative from the Target Demand with the Winning Bid Price on Google
Ad Manager for such Creative to be placed on Customer's websites. 3. Kubient License Definitions.
Certain capitalized terms used in this Agreement shall have meanings set forth below. (a) "Auction"
means a real-time auction through the Auction Platform for the placement of Creatives on Customer's
websites and applications. (b) "Auction Platform" means that technology licensed or created by
Kubient on which a Registered Bidder may Bid for Inventory. (c) "Bid" means a price for which a
Registered Bidder is willing to pay for Impressions in an Auction via the Auction Platform. (d)
"Creative" means, as applicable: (i) any Digital ad, or Companion ad as defined in the IAB's
Portfolio and Guidelines. (e) "Impression(s)" means the number of times a Creative is served to, and
received by, a visitor viewing the Inventory as measured by Kubient. (f) "Registered Bidder" means a
person or entity that executed an agreement with Kubient in order to use the Auction Platform to
participate in Auction and to deliver Impressions in Inventory. (g) "Request(s)" means the data sent
from Customer to Kubient that is used in the auction to determine a Bid. (h) "Target Demand" means
the Registered Bidder that has placed a Bid for Impressions to be delivered in Inventory. (i)
"Inventory" means advertising space on, within or associated with premium content on web site(s) or
app(s) offered through the Auction Platform by Customer. (j) "Winning Bid Price" means the price at
which the Auction Platform awards Impressions to a bidding party which shall be no less than the
minimum price that Customer has agreed to accept. 4. Term and Termination. (a) The initial term of
this Agreement shall be one (1) year from the Effective Date (the "Initial Term"). This Agreement
will automatically renew for additional 1-year terms unless earlier terminated pursuant to this
Agreement's express provisions (together with the Initial Term, such additional periods the "Term").
Neither Party may terminate this Agreement during the Initial Term except as set forth in paragraph
4(b) or any Exhibit. Either Party may terminate this Agreement for any reason following the Initial
Term upon ninety (90) days written notice to the other Party. Except for termination for material
breach as detailed in paragraph 4(b), Kubient shall be entitled to all fees generated during the
termination period regardless of which Party terminates the Agreement, (b) Either Party may
terminate this Agreement if the other Party commits a material breach of the Agreement and upon
thirty (30) days written notice to the other Party, such other Party hasn't cured the breach within
such thirty (30) days. Either Party may terminate the Agreement immediately if the other party (i)
becomes insolvent or makes a general assignment for the benefit of creditors; (ii) suffers or
permits the appointment of a conservator or receiver for its business or assets or any similar
action by a governmental entity for the purpose of assuming operation or control of the Party due to
the financial condition of the Party; (iii) becomes subject to any proceeding under any bankruptcy
or insolvency law whether domestic or foreign and such proceeding or action has not been dismissed
within a sixty (60) period; or (iv) has wound up or liquidated its business, voluntarily or
otherwise.
<!-- page 2 -->
(c) Upon termination of the Agreement: (i) Kubient will cease providing the Services; (ii) the
license granted under section 3 shall be revoked, (iii) Customer will promptly cease use of the
Services and the Auction Platform; (iv) and each Party will return or destroy any of the other
Party's Confidential Information then in its possession. 5. Fees and Payment. The Parties agree to
share any revenue generated as a result of this Agreement, or Customer's use of the Services or the
Auction Platform, as set forth and detailed in each applicable Exhibit. Unless specified otherwise
in an Exhibit, Kubient shall be responsible for contracting with all advertisers, agencies, media
buyers, and/or sponsors (collectively "Advertisers") on Customer's behalf, including Advertisers
with whom Customer has existing relationships. Pursuant to the doctrine of sequential liability,
payment from Kubient to Customer shall be made within seven (7) days from Kubient's receipt of
payment, regardless of when Customer submits an invoice. Customer acknowledges and agrees that
Kubient shall proceed with recovery of the amounts due on a best effort basis but will not initiate
any legal action against a delinquent party without the express written consent and support of
Customer. Except of taxes associated with Kubient's income, Customer shall be responsible for paying
all applicable sales, use or other taxes, duties, or tariffs applicable to its use of the Services.
6. Use of Service. (a) Customer will comply with all international, federal, state and local laws,
rules, and regulations of any governmental or regulating authority ("Law") that are applicable to
its business and use of the Service. Customer agrees that it will not transfer or (unless expressly
and specifically approved by Kubient in advance and in writing) allow third-party access to the
Service. Customer will not modify, translate, alter, tamper with, repair, or otherwise create
derivative works of any software included in any Service; reverse engineer, disassemble, or
decompile any software or Service or apply any other process or procedure to derive source code of
any software included in any Service; or resell, transfer, assign, or use as a service bureau any
Service. Customer will ensure that its stories, articles, polls, videos, pictures, photographs,
images, broadcasts, and any other type of content (collectively the "Content"), and each of its
websites, devices, applications, podcasts, ads, emails, databases or any other types of mediums for
which the Service is engaged (collectively the "Properties") contains or is linked to a privacy
policy in accordance with applicable Law. Customer shall be responsible and solely liable for all
the Content (including without limitation all intellectual property rights therein) and the
Properties. 7. Limitation of Liability. (a) EXCEPT WITH RESPECT TO THE PARTIES' LIABILITY FOR
INDEMNIFICATION, OR LIABILITY FOR BREACH OF CONFIDENTIALITY, NEITHER PARTY SHALL BE LIABLE FOR ANY
CONSEQUENTIAL, INCIDENTAL, INDIRECT, PUNITIVE, SPECIAL OR OTHER SIMILAR DAMAGES, WHETHER OR NOT
CAUSED BY THE OTHER PARTY'S EMPLOYEES OR REPRESENTATIVES„ WHETHER UNDER TORT (INCLUDING NEGLIGENCE),
CONTRACT OR OTHER THEORIES OF RECOVERY, EVEN IF THE OTHER PARTY WAS OR SHOULD HAVE BEEN AWARE OR WAS
ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 8. Arbitration. Each Party agrees and does waive trial
by jury in any action, proceeding or counterclaim brought against the other Party for any matter
whatsoever arising out of or in any way connected with this Agreement. No action, suit or proceeding
shall be brought against a Party more than one year after the date of termination this Agreement.
Any controversy or claim arising out of or relating to this Agreement, or the breach thereof, shall
be settled by arbitration administered by the American Arbitration Association under its Commercial
Arbitration Rules, and judgment on the award rendered by the arbitrator(s) may be entered in any
court having jurisdiction thereof
<!-- page 3 -->
9. Representations, Warranties, and Covenants. (a) Each Party represents, warrants and covenants to
the other that (i) it has the full right, power, and authority to enter into this Agreement; (ii)
the execution of this Agreement and performance of its obligations under this Agreement do not and
will not violate any other agreement to which it is a party; and (iii) this Agreement constitutes a
legal, valid and binding obligation when agreed to. (b) Kubient represents, warrants and covenants
that: (i) the Service and any deliverables provided hereunder by Kubient do not and shall not
infringe, misappropriate or violate any patent, copyright, trademark, trade secret, publicity,
privacy or other rights of any third party; (ii) the Service will perform in all material respects
to industry standards; (iii) the collection, maintenance, management and storage of visitor
information (data), to the extent collected, directed by, maintained or stored by Kubient, as well
as the performance of the Auction Platform, is and shall be in a secure manner using best practices
of security technology and best practices to protect against loss, misuse or alteration of data and
Kubient shall use measures in accordance with industry standards to ensure that all databases shall
be accessible only by certain authorized personnel of Kubient or Customer; (iv) it will ensure that
the product and service provided by Kubient shall be free of any viruses, Trojan Horses, worms, time
bombs, trap doors, back doors, Easter eggs, cancelbots, or other computer programming routines that
will damage, detrimentally interfere with, surreptitiously intercept or expropriate any system, data
or information; (v) the execution and delivery of the Agreement and the performance of its
obligations hereunder do not conflict with or violate applicable Laws or regulations; (vi) any
services provided by it shall comply with the terms of this Agreement and shall be free from errors
that materially affect their utility; (vii) it owns or controls the rights granted or licensed to
Customer herein; (viii) it is the rightful owner or licensee of all intellectual property rights to
the Service, the Auction Platform and products delivered hereunder; (ix) it is now and throughout
the Term shall comply with all applicable Laws in connection with the operation of its business and
the performance of its obligations hereunder or the provision of the Service, except to the extent
that such failure would not, in the aggregate, reasonably be expected to have a material adverse
effect on Customer's business, (x) it shall not place advertising for guns, tobacco products,
pornography, illegal products and any products identified by the IAB as excluded categories for
advertising and (xi) it will ensure that all Target Bidders have agreed to provide representations
and warranties with respect to the Creative in accordance with industry standards, including,
without limitation, that all Creative is supported by competent and reliable prior substantiation in
accordance with Law and complies with applicable Law and is not defamatory, libelous, slanderous or
otherwise unlawful. (c) Customer represents and warrants that: (i) it is the sole and rightful owner
of all the Content and Properties, or has the necessary rights to the Content and Properties to meet
its obligations hereunder; (ii) the Content and Properties do not and shall not infringe,
misappropriate or violate any patent, copyright, trademark, trade secret, publicity, privacy or
other intellectual property or other rights of any third party; (iii) the collection, maintenance,
management and storage of visitor information (data), to the extent collected, maintained or stored
by Customer or a third-party on Customer's behalf, is in a secure manner using best practices of
security technology and best practices to protect against loss, misuse or alteration of data and
Customer shall use measures in accordance with industry standards to ensure that all databases shall
be accessible only by certain authorized personnel of Kubient or Customer in accordance with
Customer's privacy policy and applicable Law; and (iv) the execution and delivery of the Agreement
and the performance of its obligations hereunder do not and will not violate any applicable Law. 10.
Indemnification. (a) Kubient agrees to indemnify, defend, and hold harmless Customer and its
officers, directors, managers, members, agents, and employees from all third-party allegations,
claims, actions, losses, expenses, damages, costs (including, without limitation, reasonable
attorneys' fees) or liabilities ("Claims") arising out of or in connection with: (i) the Services;
(ii) the Auction Platform; (iii) to the best of its knowledge the Creative placed onto Customer's
platforms or websites by the Auction Platform; (iv) Kubient's breach of any representation or
warranty under this Agreement or (v) the acts or omissions of Kubient or a third party hired by,
employed, retained or under Kubient control with respect to Kubient's obligations hereunder. (b)
Customer agrees to indemnify, defend, and hold harmless Kubient and its owners, shareholders,
officers, directors, managers, agents, and employees from all third-party Claims arising out of or
in connection with (i) Customer's unauthorized or inappropriate use of the Services, (ii) Customer's
unauthorized or inappropriate use of the Auction Platform, (iii) Customer's breach of any
representation or warranty under this Agreement, or (iv) the Content or Properties, including any
allegation or claim that the Content or Properties violate or infringe on an y third party rig hts,
or (v) the acts or omissions of Customer or a third party hired by, employed, retained or under
Customer's control. 11. Indemnification Procedures. Any claim for indemnification hereunder shall be
subject to the following provisions: (i) the party seeking indemnification shall provide prompt
written notice of the claim to the indemnifying party, provided that any delay in providing notice
shall not relieve the indemnifying party of its indemnity obligations ; (ii) the indemnifying party
shall have the right to control the defense and all negotiations relative to the settlement of any
such claim, provided that no settlement admitting liability on the part of the indemnified party may
be made without the express written consent of the indemnified party; and (iii) the indemnified
party shall reasonably cooperate with the indemnifying party and its counsel at the indemnifying
party's cost and expense. 12. Confidentiality. "Confidential Information" means any tangible and
intangible non-public information in any form (including written information, oral statements and
electronically stored data) which a party discloses (the "Discloser") to the other party (the
"Recipient") including, without limitation, information relating to trade secrets, systems,
know-how, products, processes (including manufacturing processes), inventions, computer software
programs, marketing or sales techniques, financial condition, costs, business interests,
initiatives, objectives, plans, strategies, customers, suppliers, lenders, underwriters, or
employees, that is marked as confidential or identified at the time of disclosure as being
confidential or is otherwise disclosed under circumstances that would lead a reasonable person to
conclude that such information is confidential, excluding information that: (a) was in Recipient's
possession before receipt from the Discloser pursuant this Agreement; (b) is in or enters the public
domain without a breach of this Agreement; (c) is rightfully received by Recipient from a third
party who was not known by Recipient to be legally or contractually restricted from disclosing such
information; or (d) is independently developed by Recipient without use of or reference to the
Discloser's Confidential Information. Recipient will protect the Confidential Information, for one
(1) year from the date of disclosure, by using at least the same degree of care as it uses to
protect its own Confidential Information, but no less than a reasonable degree of care, to prevent
unauthorized use, disclosure or publication. Notwithstanding the foregoing, if Recipient is required
by applicable Law or a valid legal order to disclose any Confidential Information, Recipient shall,
before such disclosure, notify Discloser of such requirements, if legally permissible and reasonably
practicable, so that Discloser may seek a protective order or other remedy, and Recipient shall
reasonably assist Discloser therewith (at Discloser's cost). If Recipient remains legally compelled
to make such disclosure, it shall only disclose that portion of the Confidential Information
Recipient is required to disclose. Without limiting the foregoing, Recipient: (x) will not use,
disclose, make available or reproduce the Confidential Information (or permit others to do so)
except as expressly authorized in this Agreement; (y) will not disclose any such Confidential
Information to anyone except employees and directors of Recipient to whom disclosure is necessary
for the performance of the Agreement; and (z) will appropriately notify such employees and directors
that the disclosure is made in confidence and will be kept in confidence in accordance with this
Agreement. If Recipient becomes aware of any loss or unauthorized disclosure of Confidential
Information, Recipient will promptly notify Discloser of such and use reasonable efforts to retrieve
such Confidential Information.
<!-- page 4 -->
13. Disclaimer. Except as expressly set forth herein, the Services are provided on an "as is,"
"where is," and "as available" basis, and, to the maximum extent permitted by Law, Kubient
disclaims, and Customer hereby waives, all representations and warranties, express or implied,
arising by operation of Law or otherwise, except for the representations and warranties set forth in
this Agreement, including but not limited to the implied warranties of merchantability, fitness for
a particular purpose, as well as any warranties arising from a course of dealing, usage or trade
practice. Kubient makes no representation or warranty and expressly disclaims, and Customer
understands and acknowledges, that there is no guarantee that any minimum level of revenue or profit
will be generated by either Party as a result of the Services or this Agreement. 14. General
Provisions. (a) This Agreement is governed in all respects by the laws of the State of Delaware
without giving effect to its conflict of laws principles. Each Party hereby irrevocably submits for
all disputes to the exclusive jurisdiction and venue of the state and federal courts located in New
York, New York. (b) Each Party's names, trademarks and logos are the exclusive property of said
respective Party, and neither Party will acquire any proprietary rights therein by reason of this
Agreement or any other agreement. Neither Party may issue any publicity release or marketing
materials identifying the other Party without the prior express written approval of such other
Party, provided however, the Parties agree to issue a joint press release within ninety (90) days of
the Effective Dave announcing the Agreement. (c) The relationship of the Parties is that of
independent contractors, and nothing herein is intended, nor should be construed, to create a
partnership, agency, joint venture or employment relationship. No act or statement of either Party
will operate to bind the other and neither Party will hold itself out or have any authority as an
agent of the other for any purposes whatsoever. (d) If any legal action, including, without
limitation, an action for arbitration or injunctive relief, is brought relating to the Agreement or
in breach hereof, the prevailing party in any final judgment or arbitration award shall be entitled
to recover its reasonable expenses, including all court costs, arbitration fees and reasonable
attorney's fees. (e) All notices provided pursuant to this Agreement will be in writing and will be
deemed given (i) if by personal delivery, upon receipt thereof; (ii) if mailed five 5 days after
deposit in the US mail, postage prepaid, certified mail return receipt requested; or (iii) if sent
via overnight courier, upon receipt. All notices will be sent to the person who has signed this
Agreement (at the address set forth above) or to such other person or address as either party may
specify in writing. (f) If any provision of this Agreement is unenforceable, illegal or invalid
under any applicable Law or court of competent jurisdiction, then such unenforceability or
invalidity will not render the Agreement unenforceable or invalid. In such event, such provision
will be deemed restated in accordance with applicable Law to reflect as nearly as possible the
original intentions of the parties, and the remainder of the Agreement will remain in full force and
effect. Provisions that should reasonably be considered to survive termination of the Agreement will
survive and be enforceable after such termination or expiration, including without limitation
provisions relating to confidentiality, proprietary rights, indemnification, limitations of
liability, effects of termination, and governing Law. The delay or failure of either Party to
exercise any right or power provided in this Agreement or to require performance by the other Party
of any provision of this Agreement will not impair such right or power, or be deemed a waiver
thereof. A waiver by either Party of any covenants to be performed by the other or any breach
thereof will not be taken or held to be a waiver of any succeeding breach thereof or of any other
covenant contained in this Agreement or under any agreement. (g) Neither Party will be liable under
this Agreement by reason of any damages, failure or delays in the performance of its obligations
under such Agreement (except for the payment of money) on account of any cause beyond the reasonable
control of such Party, such as fire, explosion, power failures, pest damage, lightning or power
surges, strikes or labor disputes, water, war, civil disturbances, terrorism, acts of civil or
military authorities, inability to secure raw materials, transportation facilities, fuel or energy
shortages, performance or availability of communications services or networks and network facilities
failures of any suppliers or service providers, or other causes beyond the Party's reasonable
control. (h) Neither Party may assign (voluntarily, by operation of law, or otherwise) this
Agreement or any rights or obligations under this Agreement without the other Party's prior written
consent, which shall not be unreasonably withheld, provided however, that either Party may assign
this Agreement without approval or consent to any affiliate or purchaser of all or substantially all
of said Party's assets related to the subject matter of this Agreement or to any successor by way of
merger, stock sale, consolidation or similar transaction. Any attempted assignment other than in
accordance herewith will be void. Subject to the foregoing, the Agreement will bind and inure to the
benefit of the Parties and their respective successors and permitted assigns. The Agreement
completely and exclusively states the agreement of the Parties regarding its subject matter. This
Agreement supersedes, and its terms govern, all prior proposals, agreements, or other communications
between the parties, oral or written, regarding its subject matter. (i) This Agreement is intended
for the sole and exclusive benefit of the Parties hereto, is not intended to confer any rights or
benefits on any third party, and only the Parties may enforce such Agreement. This Agreement shall
be binding on both Parties when signed on behalf of each Party, and may be signed in one or more
counterparts, each of which shall be deemed to be an original and both of which when taken together
will constitute one and the same agreement. Fax or electronically scanned copies of such executed
documents may be used in lieu of the originals for any purpose.
<!-- page 5 -->
IN WITNESS WHEREOF, the Parties hereto have caused this Agreement to be executed by their duly
authorized representatives as of the dates written below. Kubient Signature: /s/ Paul Roberts By:
Paul Roberts Its: CFO Date: 2-6-2020 Customer Signature: /s/ Paul Caluori By: Paul Caluori Its: VP,
Global Products Date: 02-05-2020
