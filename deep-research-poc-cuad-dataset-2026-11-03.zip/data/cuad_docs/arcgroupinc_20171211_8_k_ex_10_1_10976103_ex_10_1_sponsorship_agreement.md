<!-- page 1 -->
# JACKSONVILLE JAGUARS SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 2017-11-27 |
| Parties | Jacksonville Jaguars, LLC ("Club"); The ARC Group, Inc. ("Sponser") |
| Source | CUAD v1 / ArcGroupInc_20171211_8-K_EX-10.1_10976103_EX-10.1_Sponsorship Agreement |

Exhibit 10.1 JACKSONVILLE JAGUARS SPONSORSHIP AGREEMENT This Sponsorship Agreement (this
"Agreement") is entered into as of November 27, 2017 (the "Execution Date") by and between
Jacksonville Jaguars, LLC, a Delaware limited liability company ("Club"), and The ARC Group, Inc., a
Florida corporation (owner and operator of Dick's Wings and Grill) ("Sponsor"). This Agreement
consists of this Sponsorship Agreement and Exhibits A and B hereto, each of which is incorporated
into and forms a part of this Agreement by this reference. RECITALS A. Club owns and operates the
National Football League ("NFL") team known as the Jacksonville Jaguars (the "Team") and has the
right to grant sponsorship rights and to exploit certain commercial, advertising and related
opportunities with respect to the Team, including at the football- based stadium in Jacksonville,
Florida currently named EverBank Field (the "Stadium"). B. Sponsor wishes to obtain certain
sponsorship rights, benefits and opportunities with respect to the Team in connection with the
advertising and promotion of the Sponsor Business (as defined below). In consideration of the mutual
covenants contained herein, the parties agree as follows: 1. Term of Agreement. This Agreement shall
be binding on the parties hereto as of the Execution Date. The term of this Agreement (the "Term")
shall commence as of April 1, 2018 (the "Effective Date") and shall expire upon the later of: (a)
the conclusion of the 2022/23 NFL season and (b) the last day in February, 2023 (such expiration
date, the "Scheduled Expiration Date"), unless sooner terminated pursuant to the terms of this
Agreement. 2. Sponsor Rights and Benefits. Subject to the terms and conditions of this Agreement, as
part of the consideration of the full and timely payment of the Sponsor Fees, Club hereby grants to
Sponsor, and Sponsor hereby accepts, solely in the Territory, and during the Term: (i) the right to
use the Benefits set forth on Exhibit A and the license and right to use the Team Marks solely in
connection with the advertisement and promotion of Sponsor's Dick's Wings and Grill branded
restaurants (the "Sponsor Business") in accordance with this Agreement; and (ii) the right to use
the designation "Official Wings of the Jacksonville Jaguars" and such other designations as Club and
Sponsor may agree to in a writing from time to time (collectively, the "Official Designations"),
solely in connection with the Sponsor Business. No license or right is granted for the use of any
other Club intellectual property for any other purpose, in any geographic area outside the
Territory, for any medium of distribution that cannot be reasonably limited to the Territory, or
during any period before or after the Term. The rights granted to Sponsor pursuant to this Section 2
may not be used to promote or advertise any products or services of Sponsor other than the Sponsor
Business, or any other person or entity, whether directly or by affiliation, cooperation,
co-sponsorship, or any joint programs or promotions. 3. Annual Fees; Playoff Payment. (a) In
consideration for the Benefits, during each Contract Year of the Term, Sponsor shall pay Club, in
accordance with this Section 3(a) and Section 2(d) of the Terms and Conditions, the amount set forth
next to the applicable Contract Year below (the "Annual Fee"). First Contract Year (2018/19): $
200,000 Second Contract Year (2019/20): $ 204,000 Third Contract Year (2020/21): $ 208,080 Fourth
Contract Year (2021/22): $ 212,240 Fifth Contract Year (2022/23): $ 216,490 Sponsor shall pay Club
the Annual Fee for each Contract Year of this Agreement in six (6) equal installments, each due on
or prior to the 1st of each month between June and November of the applicable Contract Year. (b) In
addition to the Annual Fees identified in Section 3(a) above, Sponsor shall provide Club with food,
beverage and serving products from Sponsor's Dicks' Wings restaurant with values equal to the
following (each, an "Annual Trade Value"): First Contract Year (2018/19): $ 35,000 Second Contract
Year (2019/20): $ 35,700 Third Contract Year (2020/21): $ 36,410 Fourth Contract Year (2021/22): $
37,140 Fifth Contract Year (2022/23): $ 37,890 As part of the Annual Trade Value, Sponsor shall
provide Club with a designated liaison who will coordinate the menu and quantities to be provided by
Sponsor. Sponsor shall deliver the food (the cost of which is included in the Annual Trade Value) to
the Stadium at the time and location specified by Club. If any portion of the Annual Trade Value is
not used in any given Contract Year, such unused amount shall carry forward to the subsequent
Contract Year. If any portion of the Annual Trade Value is not used at the end of the Term, Club
shall be permitted to use such unused amount within twelve (12) months following expiration of this
Agreement. The parties acknowledge that the Annual Trade Value is inclusive of any taxes, surcharges
or related fees applicable to the orders placed by Club during the Term.

Source: ARC GROUP, INC., 8-K, 12/11/2017
<!-- page 2 -->
(c) If, during the Term, the Team plays in the Hall of Fame game, or any post-season playoff game,
including any wild card, divisional playoff, conference championship, or Super Bowl (each, a
"Playoff Game"), to the extent Club has the necessary rights to grant the Benefits identified on
Exhibit A for such Playoff Game, Sponsor shall pay Club an additional amount per Playoff Game equal
to a pro-rated portion of the Annual Fee applicable during the then-current Contract Year. The
pro-rated portion shall be determined by Club using Club's internal line item accounting values as
set forth in Club's standard rate card for such Benefits during each Playoff Game; provided that the
cost of the Playoff Game tickets shall be based upon the generally applicable price for such tickets
(the "Playoff Payments"). Sponsor shall pay the Playoff Payments in accordance with Section 2(d) of
the Terms and Conditions not later than 30 days following Sponsor's receipt of an invoice requesting
payment for such Playoff Games; provided that Club's failure to deliver such an invoice shall not,
and not be construed to, relieve Sponsor of any obligation to pay any amount owed to Club. 4.
Definitions. Capitalized terms used but not otherwise defined herein have the respective meanings
given to them on Exhibit B (as it may be amended or otherwise modified from time to time, the "Terms
and Conditions"). 5. Standard Terms and Conditions. Except as expressly set forth in this
Sponsorship Agreement or Exhibit A, all Benefits granted by Club to Sponsor hereunder shall be
subject to, and Sponsor shall at times comply with, the terms and conditions set forth in the Terms
and Conditions. 6. Notices. Any notice or other communication under this Agreement shall be in
writing and shall be considered given when delivered personally or by electronic mail (confirmed by
one of the other permissible methods of giving notice hereunder), one business day after being sent
by a nationally recognized overnight courier, or three business days after being mailed by
registered or certified mail, postage prepaid and return receipt requested, to the parties at the
following addresses (or at such other address as a party may specify by notice to the other): To
Sponsor: The ARC Group, Inc. To Club: Jacksonville Jaguars, LLC 6327-4 Argyle Forest Blvd. 1
EverBank Field Drive Jacksonville, Florida 32244 Jacksonville, Florida 32202 Attn: Rick Akam Attn:
Scott Massey Title: CEO Senior Vice President, Corporate Partnerships Email: rick@dickswings.com
masseys@nfl.jaguars.com With a copy to: _________________________ With a copy to: Jacksonville
Jaguars, LLC _________________________ 1 EverBank Field Drive _________________________
Jacksonville, Florida 32202 Attn: ____________________ Attn: Megha Parekh Title:
____________________ Senior Vice President, Chief Legal Officer Email: ____________________
parekhm@nfl.jaguars.com Notwithstanding the foregoing, delivery of an invoice via solely electronic
mail shall constitute sufficient delivery under this Agreement. 7. Integration; Amendment. This
Agreement contains the complete understanding between the parties hereto and supersedes all prior
and contemporaneous written or verbal agreements or understandings (including but not limited to all
negotiations, term sheets, letters of intent, presentations, and prior drafts of this Agreement)
relating to the subject matter hereof. This Agreement may not be amended or otherwise modified
except in a writing specifically referring to this Agreement and signed by authorized
representatives of Sponsor and Club. 8. Counterparts. This Agreement may be executed in any number
of counterparts, each of which will be deemed an original, but all of which taken together shall
constitute one single agreement. Delivery of an executed counterpart by electronic transmission
shall have the same effect as delivery of an original ink counterpart. IN WITNESS WHEREOF, each
party has caused this Agreement to be executed in Jacksonville, Florida, by its duly authorized
representative with the intent that it be binding as of the Execution Date. CLUB: SPONSOR:
JACKSONVILLE JAGUARS, LLC The ARC Group, Inc. By: /s/ Scott Massey By: /s/ Richard W. Akam Scott
Massey Rick Akam SVP, Corporate Partnerships CEO

Page 2 of 4

Source: ARC GROUP, INC., 8-K, 12/11/2017
<!-- page 3 -->
EXHIBIT A Sponsorship Benefits For purposes of clarity, the Benefits set forth on this Exhibit A are
subject to the terms and conditions of this Agreement, including the Club Approval Rights under
Section 5 of the Terms and Conditions. 1. STADIUM SIGNAGE a. Carousel Messaging: Sponsor shall
receive three (3) minutes of real time (and not game clock time) of display of a Sponsor Mark on LED
carousel Signage on one (1) of the main video boards above the north or south end zone during each
quarter of each preseason and regular season Jaguars Home Game. During each three (3) minute
segment, Sponsor may include up to thirty seconds (:30) of animated messaging. Sponsor shall be
solely responsible for any costs related to the animated messaging. a. Ribbon LED Signage: Sponsor
shall receive display of a Sponsor Mark on the LED ribbon boards located on the fascia on the east
and west sides of the Stadium for thirty seconds (:30) of real time (and not game clock time) during
each quarter of each preseason and regular season Jaguars Home Game. The exact timing of each
display shall be determined by Club. b. Concourse Signage: Sponsor shall receive display of a
Sponsor Mark or Advertisement on five (5) back-illuminated advertising panels at certain locations
on the Stadium concourses to be displayed during each preseason and regular season Jaguars Home
Game. The exact size and location of each panel shall be determined by Club. 2. RADIO a. Radio
Spots: Sponsor shall receive the following radio spots in Club radio programming broadcasted by
Club's primary radio partner. The exact timing of each spot shall be determined by Club or Club's
primary radio partner: i. Jaguars Thursday: A total of twenty-three (23) thirty second (:30) spots
for broadcast of an advertisement of the Sponsor Business during certain initial broadcasts of
Jaguars Thursday. ii.Pre-Game Show: One (1) thirty second (:30) spot for broadcast of an
advertisement of the Sponsor Business during each initial broadcast of the Pre-Game Show (for a
total of twenty (20) spots during each Contract Year). iii.In-Game: One (1) thirty second (:30) spot
for broadcast of an advertisement of the Sponsor Business during the initial broadcast of each
preseason and regular season Team Game radio broadcast (for a total of twenty (20) spots during each
Contract Year). 3. DIGITAL a. Banner Ad: During each Contract Year, Sponsor shall receive display of
a Sponsor Mark on one (1) banner advertisement in respect of the Sponsor Business that rotates
throughout www.jaguars.com (approximately 300x250 pixels) and that links to Sponsor's official
website. The exact placement of the banner shall be determined by Club in its sole discretion. b.
Gameday Magazine: During each Contract Year, Sponsor shall receive space to display one (1) full
page advertisement in respect of the Sponsor Business and display of a Sponsor Mark in each digital
(or printed, as determined by Club) issue of the Gameday Magazine distributed to Club's season
ticket members prior to each Jaguars Home Game. The exact size and placement of the advertisement
and timing of each distribution of the Gameday Magazine shall be determined by Club in its sole
discretion. c. Social Media Feature: During each Contract Year, Sponsor shall be the presenting
sponsor of a video feature that highlights a top rushing play by a Team player during each preseason
and regular season Team Game (the "Feature"). The top rushing play shall be determined by Club in
its sole discretion. Such presenting sponsorship shall consist of the following: i. A Sponsor Mark
displayed in the Feature, which shall be published by Club to Club's official Facebook, Twitter,
Instagram or Snapchat account. The post will tag Sponsor's official corresponding social media
account. The content, timing and frequency of such social media posts and the social media platforms
shall be determined by Club. 4. HOSPITALITY a. Season Tickets: Sponsor shall receive tickets (in
Section 150, Row X, Seats 5-8, or a substantially similar location) to each preseason and regular
season Jaguars Home Game.

Page 3 of 4

Source: ARC GROUP, INC., 8-K, 12/11/2017
<!-- page 4 -->
5. CONCESSIONS a. Branded Concession Stands: During each preseason and regular season Jaguars Home
Game and Other Events as requested by Club or the Stadium concessionaire ("Concessionaire"), Sponsor
shall have the right to display Sponsor branding on (i) one (1) fixed concession stand in the
Stadium located in the Bud Light Party Zone; and (ii) the fixed concession stand identified as
Concession Stand 118 on the Stadium concourse (collectively, the "Stands"). The exact size and
location of the Stands shall be determined by Club. The exact design of the Stands shall be mutually
agreed upon between Sponsor and Club. Sponsor may display Signage displaying a Sponsor Mark in
and/or on the Stand. Sponsor shall be responsible for all costs associated with the branding and
Advertising in respect of the Stand. b. Vending: Subject to the Concessions Agreement (as defined
herein), Sponsor shall have the right to have its food products sold or otherwise distributed from
the Stands and/or certain general concessions areas at the Stadium determined by Club or the
Concessionaire. For purposes of clarity, nothing in this Agreement grants Sponsor the right to
operate the Stand or otherwise sell or distribute food products from or within the Stand. Sponsor
shall enter into an agreement with the Concessionaire to memorialize any such rights regarding the
sale or distribution of Sponsor's products at the Stadium during each Jaguars Home Game and Other
Events (the "Concessions Agreement"). The exact products to be sold and distributed shall be subject
to Club's final approval. For purposes of clarity, Club reserves the right to sell other products at
the Stadium competitive to the Sponsor Business. Sponsor acknowledges that such rights do not
automatically extend to Other Events at the Stadium. Sponsor acknowledges that Sponsor shall
cooperate with the Concessionaire regarding logistics and management of the Sponsor's food products,
and appropriate storage and dispensation of the food products. In the event of any recall with
respect to Sponsor's products provided to the Concessionaire pursuant to this Agreement or the
Concessions Agreement, Sponsor shall notify both Club and the Concessionaire immediately upon
issuance of such recall, and Club may, at its sole discretion and without penalty, suspend the
Benefits for a duration as reasonably determined by Club. Any costs or expenses incurred by Club or
the Concessionaire with respect to any such recall shall be the sole responsibility of Sponsor.
Sponsor shall be responsible for the management and control over the services provided by its staff
members operating the Stands ("Sponsor Staff") and Sponsor shall be solely responsible for
determining the terms of employment for Sponsor Staff. Sponsor shall train Sponsor Staff or require
Sponsor Staff to undergo training provided by Concessionaire. The staffing levels at each Stand
shall be subject to Club's approval.

Page 4 of 4

Source: ARC GROUP, INC., 8-K, 12/11/2017
