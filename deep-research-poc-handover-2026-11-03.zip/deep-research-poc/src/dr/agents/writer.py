"""Outline-first, fact-bound writer (PLAN Phase 3). Model role: writer (no tools).

Protocol (WebWeaver + ClaimWriter + ScaffoldAgent, adapted for small models):
  1. outline_from_question(question)              -> sections (sees NO evidence)
  2. revise_and_assign(outline, bank)              -> one pass of Expansion / Contraction / Revision
                                                     ops AND each evidence id assigned to <= 1 section
                                                     (code enforces: ids must exist, no id twice,
                                                     unassigned ids placed by keyword overlap)
  3. draft_section per section, in parallel, from ONLY that section's evidence. Every factual
     sentence carries {{CITE:e<n>}} before the period; missing facts become "[GAP] ..." lines.
     A section with no evidence is a gap line and costs no model call.
  4. claims = sentence-level Claim list (deterministic); the markdown is RENDERED FROM CLAIMS,
     never from free text, so verify/report.py can drop or flag individual sentences.

Deadline: when less than half the WRITE budget remains, the revision call is skipped and the
heuristic assignment is used; the report is marked partial. A research stage that ended without
a submission also marks the report partial. Nothing here reads the chat transcript: the bank is
the only input (CLAUDE.md invariant 3).
"""
from __future__ import annotations

import re
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from langchain_core.messages import HumanMessage
from pydantic import BaseModel, Field

from ..config import DEFAULT, Config
from ..evidence import EvidenceBank
from ..models import Claim, EvidenceItem, Finding, OutlineSection, Report, VerifyResult
from ..prompts import load
from ..structured import ModelCaller
from ..trace import Trace

CITE_RE = re.compile(r"\{\{CITE:([^}]+)\}\}")
_WORD_RE = re.compile(r"[a-z0-9]{3,}")
_STOP = {"the", "and", "for", "that", "with", "this", "from", "under", "what", "which", "does", "are",
         "was", "were", "has", "have", "into", "over", "between", "about", "each", "every", "all"}


class OutlinePlan(BaseModel):
    sections: list[OutlineSection] = Field(min_length=1)


# --------------------------------------------------------------------------- outline


def outline_from_question(question: str, caller: ModelCaller, config: Config = DEFAULT) -> list[OutlineSection]:
    """Outline from the question alone (ClaimWriter): the writer has not seen evidence yet."""
    plan = caller.json(
        [HumanMessage(content=load("outline", question=question, max_sections=config.agents.OUTLINE_MAX_SECTIONS))],
        OutlinePlan,
    )
    if plan is None:
        return [OutlineSection(section_id="s1", title="Answer", intent=f"Answer the question: {question}")]
    return _normalize(plan.sections, config)


def revise_and_assign(
    question: str, sections: list[OutlineSection], bank: EvidenceBank, caller: ModelCaller,
    config: Config = DEFAULT, max_sections: int | None = None,
) -> list[OutlineSection]:
    """One revision pass (expand / contract / revise) that also assigns evidence ids to sections.
    Falls back to the keyword heuristic when the model's JSON cannot be repaired."""
    cap = max_sections or config.agents.OUTLINE_MAX_SECTIONS
    outline_txt = "\n".join(f"- {s.section_id}: {s.title} — {s.intent}" for s in sections)
    plan = caller.json(
        [HumanMessage(content=load("outline_revise", question=question, outline=outline_txt,
                                   evidence=bank.render_for_writer(), max_sections=cap))],
        OutlinePlan,
    )
    if plan is None:
        return assign_heuristic(sections, bank)
    # the cap is advice to the model; sections it still returns empty are collapsed into visible
    # gaps by the caller rather than silently truncated here
    return _enforce_assignment(_normalize(plan.sections, config), bank)


def outline_from_findings(findings: list[Finding], bank: EvidenceBank) -> list[OutlineSection]:
    """Breadth questions: one section per fan-out finding (its sub-question is the intent, its
    evidence ids are the section's evidence), no model call. Leftover usable evidence is placed by
    keyword overlap so nothing the researchers saved is hidden from the writer."""
    secs: list[OutlineSection] = []
    used: set[str] = set()
    for i, f in enumerate(findings, start=1):
        ids = [e for e in f.evidence_ids if bank.get(e) is not None and e not in used]
        used.update(ids)
        title = f.sub_question.strip().rstrip("?")
        secs.append(OutlineSection(section_id=f"s{i}", title=title if len(title) <= 90 else title[:87] + "...",
                                   intent=f.sub_question.strip(), evidence_ids=ids))
    for it in _usable(bank):
        if it.id not in used:
            secs[_best_section(it, secs)].evidence_ids.append(it.id)
            used.add(it.id)
    return secs


def sections_cap(n_evidence: int, config: Config = DEFAULT) -> int:
    """Structural bound: an outline cannot have more sections than the evidence can fill.
    Two quotes never justify four headings; the model may still choose fewer."""
    return max(1, min(config.agents.OUTLINE_MAX_SECTIONS, (n_evidence + 1) // 2 + 1))


def collapse_empty_sections(sections: list[OutlineSection]) -> tuple[list[OutlineSection], list[OutlineSection]]:
    """Sections with no evidence become one trailing gaps section (their intents are kept as
    [GAP] lines, so coverage gaps stay visible). Returns (sections, collapsed)."""
    filled = [s for s in sections if s.evidence_ids]
    empty = [s for s in sections if not s.evidence_ids]
    if not filled or not empty:
        return sections, []
    gaps = OutlineSection(section_id="gaps", title="Not established by the evidence",
                          intent=" | ".join(s.intent for s in empty))
    return filled + [gaps], empty


def assign_heuristic(sections: list[OutlineSection], bank: EvidenceBank) -> list[OutlineSection]:
    """Model-free assignment: each usable evidence item goes to the section whose title+intent
    shares the most content words with the quote+note; ties and no-overlap go to the first section."""
    secs = [s.model_copy(update={"evidence_ids": []}) for s in sections]
    for it in _usable(bank):
        secs[_best_section(it, secs)].evidence_ids.append(it.id)
    return secs


def _enforce_assignment(sections: list[OutlineSection], bank: EvidenceBank) -> list[OutlineSection]:
    usable = {it.id: it for it in _usable(bank)}
    seen: set[str] = set()
    for s in sections:
        kept = []
        for eid in s.evidence_ids:
            if eid in usable and eid not in seen:
                kept.append(eid)
                seen.add(eid)
        s.evidence_ids = kept
    for eid, it in usable.items():          # the model forgot some ids: place them by overlap
        if eid not in seen:
            sections[_best_section(it, sections)].evidence_ids.append(eid)
    return sections


def _usable(bank: EvidenceBank) -> list[EvidenceItem]:
    return [it for it in bank.all() if it.tier1_status != "drop"]


def _words(text: str) -> set[str]:
    return {w for w in _WORD_RE.findall(text.lower()) if w not in _STOP}


def _best_section(it: EvidenceItem, sections: list[OutlineSection]) -> int:
    ev = _words(it.quote + " " + it.note)
    scores = [len(ev & _words(s.title + " " + s.intent)) for s in sections]
    best = max(scores) if scores else 0
    return scores.index(best) if best > 0 else 0


def _normalize(sections: list[OutlineSection], config: Config, cap: int | None = None) -> list[OutlineSection]:
    out: list[OutlineSection] = []
    for i, s in enumerate(sections[: cap or config.agents.OUTLINE_MAX_SECTIONS], start=1):
        out.append(OutlineSection(section_id=f"s{i}", title=s.title.strip() or f"Section {i}",
                                  intent=s.intent.strip() or s.title.strip(), evidence_ids=list(s.evidence_ids)))
    return out


# --------------------------------------------------------------------------- drafting


def draft_section(section: OutlineSection, evidence_text: str, question: str, caller: ModelCaller) -> str:
    """prompts/writer_section.md; returns prose with {{CITE:e<n>}} markers (or a [GAP] line on failure)."""
    text = caller.text([HumanMessage(content=load(
        "writer_section", title=section.title, question=question, intent=section.intent, evidence=evidence_text
    ))])
    if not text or not text.strip():
        return f"[GAP] The writer produced nothing for: {section.intent}"
    return text.strip()


def extract_claims(section: OutlineSection, draft: str) -> list[Claim]:
    """Split a drafted section into sentence-level claims with their evidence ids. Deterministic.
    A marker written after the period is moved before it so the sentence split stays correct."""
    draft = re.sub(r"\.\s*(\{\{CITE:[^}]+\}\})", r" \1.", draft)
    claims: list[Claim] = []
    for i, sent in enumerate(_sentences(draft)):
        ids: list[str] = []
        for m in CITE_RE.finditer(sent):
            ids += [x.strip() for x in m.group(1).split(",") if x.strip()]
        text = CITE_RE.sub("", sent).strip()
        text = re.sub(r"\s+([.,;:])", r"\1", text)
        if not text or re.fullmatch(r"\[GAP\][\s:.-]*", text):   # an empty gap line says nothing
            continue
        is_gap = text.startswith("[GAP]") or not ids
        claims.append(Claim(claim_id=f"{section.section_id}.{i + 1}", section_id=section.section_id,
                            text=text, evidence_ids=ids, is_gap=is_gap))
    return claims


def _sentences(text: str) -> list[str]:
    parts: list[str] = []
    for para in re.split(r"\n+", text):
        para = para.strip()
        if not para:
            continue
        if para.startswith("[GAP]"):
            parts.append(para)
            continue
        parts += [p.strip() for p in re.split(r"(?<=[.!?])\s+(?=[A-Z\[\-\*\"'(])", para) if p.strip()]
    return parts


# --------------------------------------------------------------------------- report


def write_report(
    question: str,
    bank: EvidenceBank,
    config: Config = DEFAULT,
    llm: Any | None = None,
    trace: Trace | None = None,
    deadline_ts: float | None = None,
    research_partial: bool = False,
    findings: list[Finding] | None = None,
) -> Report:
    """Evidence bank -> Report (markdown rendered from claims, not yet verified). With two or more
    fan-out `findings`, the outline is one section per finding instead of a model-made outline."""
    if llm is None:
        from ..llm import get_llm

        llm = get_llm("writer")
    caller = ModelCaller(llm, trace, "write", "writer", deadline_ts=deadline_ts)
    t0 = time.time()
    budget = config.stages.WRITE
    notes: list[str] = []
    if trace:
        trace.stage("write", "start", n_evidence=len(bank), model=caller.model_name)

    usable = _usable(bank)
    remaining = (deadline_ts - time.time()) if deadline_ts else budget
    partial = research_partial
    if findings and len(findings) >= 2 and usable:
        sections = outline_from_findings(findings, bank)
        notes.append(f"outline from {len(findings)} fan-out findings (no outline call)")
    else:
        sections = outline_from_question(question, caller, config)
    if findings and len(findings) >= 2 and usable:
        pass   # assignment came with the findings
    elif not usable:
        sections = [s.model_copy(update={"evidence_ids": []}) for s in sections]
        notes.append("no evidence in the bank; every section is a gap")
        partial = True
    elif remaining < budget / 2:
        sections = assign_heuristic(sections, bank)
        notes.append(f"outline revision skipped: {remaining:.0f} s left")
        partial = True
    else:
        sections = revise_and_assign(question, sections, bank, caller, config, max_sections=sections_cap(len(usable), config))
    sections, collapsed = collapse_empty_sections(sections)
    if collapsed:
        notes.append(f"{len(collapsed)} empty section(s) collapsed into gaps: " + "; ".join(s.title for s in collapsed))
    empty_intents = [s.intent for s in collapsed]

    def _draft(sec: OutlineSection) -> str:
        if sec.section_id == "gaps":
            return "\n".join(f"[GAP] No evidence was found for: {intent}" for intent in empty_intents)
        if not sec.evidence_ids:
            return f"[GAP] No evidence was found for: {sec.intent}"
        return draft_section(sec, bank.render_for_writer(sec.evidence_ids, max_quote_chars=1200), question, caller)

    with ThreadPoolExecutor(max_workers=max(1, min(config.agents.WRITE_SECTION_CONCURRENCY, len(sections)))) as ex:
        drafts = list(ex.map(_draft, sections))

    claims: list[Claim] = []
    for sec, draft in zip(sections, drafts):
        sec.draft = draft
        claims += extract_claims(sec, draft)
    gaps = [c.text for c in claims if c.is_gap]
    notes += caller.errors
    report = Report(question=question, title=_title(question), sections=sections, claims=claims,
                    partial=partial, gaps=gaps, notes=notes)
    report.markdown = render_report(report, bank)
    if trace:
        trace.stage("write", "end", n_sections=len(sections), n_claims=len(claims), n_gaps=len(gaps),
                    partial=partial, elapsed_ms=int((time.time() - t0) * 1000))
    return report


def render_report(report: Report, bank: EvidenceBank, results: dict[str, VerifyResult] | None = None) -> str:
    """Markdown from claims. With tier-1 `results`, dropped claims are replaced by an explicit
    marker and partially supported ones are flagged (never silently kept)."""
    out = [f"# {report.title}", "", f"*Question:* {report.question}", ""]
    if report.partial:
        out += ["> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.", ""]
    by_section: dict[str, list[Claim]] = {}
    for c in report.claims:
        by_section.setdefault(c.section_id, []).append(c)
    for sec in report.sections:
        out += [f"## {sec.title}", ""]
        para: list[str] = []
        for c in by_section.get(sec.section_id, []):
            r = results.get(c.claim_id) if results else None
            if c.text.startswith("[GAP]"):
                if para:
                    out += [" ".join(para), ""]
                    para = []
                out += [c.text, ""]
                continue
            if r is not None and r.tier1 == "drop":
                para.append(f"[DROPPED: claim {c.claim_id} could not be verified against its cited source.]")
                continue
            cites = " ".join(bank.citation_for(e) for e in c.evidence_ids if bank.get(e))
            if not cites and not c.is_gap:
                cites = "[citation missing]"
            flag = " [partially supported]" if r is not None and r.tier1 == "truncate" else ""
            if r is not None and r.tier2 == "unsupported":
                flag += " [unsupported by review]"
            elif r is not None and r.tier2 == "partially":
                flag += " [partially supported by review]"
            gap = " [uncited]" if c.is_gap else ""
            para.append(f"{c.text}{gap}{flag} {cites}".strip())
        if para:
            out += [" ".join(para), ""]
    return "\n".join(out).rstrip() + "\n"


def resolve_citations(markdown: str, bank: EvidenceBank) -> str:
    """Resolve raw {{CITE:...}} markers in free text (kept for notebooks / ad-hoc drafts)."""

    def _sub(m: re.Match) -> str:
        ids = [x.strip() for x in m.group(1).split(",") if x.strip()]
        cites = [bank.citation_for(e) for e in ids if bank.get(e)]
        return " " + " ".join(cites) if cites else " [citation missing]"

    return CITE_RE.sub(_sub, markdown)


def _title(question: str) -> str:
    q = question.strip().rstrip("?.")
    return q if len(q) <= 90 else q[:87] + "..."
