"""Derive '<!-- page N -->' markers from the raw PDFs when the parsed markdown lacks them.

Approach (Phase 0): for each PDF page, take its text (pymupdf), pick 2–3 distinctive anchor
lines, locate them in the markdown, and insert a marker before the first anchor of each page.
Falls back to proportional splitting by character count when anchors are not found (mark those
docs `pages_approximate=true` in metadata).

Matching is done on a *normalized stream*: both texts are NFKC-folded, lower-cased and reduced
to their alphanumeric characters, so differences in whitespace, line wrapping, hyphenation at
line ends, curly quotes and ligatures do not matter. Every stream position maps back to a char
offset in the original markdown, so page starts are exact offsets, then snapped to line starts.

Pure Python + pymupdf; no model calls.

    from dr.ingest.pages import add_page_markers, add_page_markers_batch
    text, approximate = add_page_markers(markdown, Path("contract.pdf"))
"""
from __future__ import annotations

import bisect
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

_MARKER_RE = re.compile(r"^<!--\s*page\s+(\d+)\s*-->\s*\n?", re.MULTILINE)
_ALNUM_RE = re.compile(r"[^\W_]", re.UNICODE)

ANCHORS_PER_PAGE = 3          # anchors we try to locate per page (the first located one places the marker)
CANDIDATES_PER_PAGE = 12      # PDF lines inspected per page before giving up
MIN_ANCHOR_CHARS = 20         # normalized chars; shorter runs are too common to be distinctive
MAX_ANCHOR_CHARS = 80         # anchors are prefixes of PDF lines; longer is brittle, not safer
EMPTY_PAGE_CHARS = 40         # PDF pages with fewer normalized chars are treated as blank (no anchor needed)


@dataclass
class PageAlignment:
    """Where each PDF page starts in the text. `starts[i]` is the char offset of page i+1 (starts[0] == 0)."""

    n_pages: int
    starts: list[int]
    located: list[bool] = field(default_factory=list)   # page start found through an anchor
    blank: list[bool] = field(default_factory=list)     # PDF page has (almost) no text
    approximate: bool = False                           # some non-blank page had to be interpolated

    @property
    def n_located(self) -> int:
        return sum(self.located)

    def page_of_offset(self, offset: int) -> int:
        """1-based page containing char `offset` of the text."""
        return bisect.bisect_right(self.starts, offset)

    def pages_of_span(self, start: int, end: int) -> list[int]:
        """1-based pages touched by text[start:end] (end exclusive; empty spans use `start`)."""
        last = max(start, end - 1)
        return list(range(self.page_of_offset(start), self.page_of_offset(last) + 1))


# --------------------------------------------------------------------------- normalization


def normalize_stream(text: str) -> tuple[str, list[int]]:
    """Return (stream, index): `stream` is the lower-cased alphanumeric skeleton of `text` after NFKC
    folding, `index[i]` the char offset in `text` of stream char i."""
    chars: list[str] = []
    index: list[int] = []
    # NFKC per character keeps offsets aligned with the original text (a ligature may expand to
    # several stream chars, all mapped to the same original offset).
    for m in _ALNUM_RE.finditer(text):
        c = m.group(0)
        folded = unicodedata.normalize("NFKC", c).lower()
        for fc in folded:
            if _ALNUM_RE.fullmatch(fc):
                chars.append(fc)
                index.append(m.start())
    return "".join(chars), index


def _norm_key(s: str) -> str:
    return "".join(ch for ch in unicodedata.normalize("NFKC", s).lower() if _ALNUM_RE.fullmatch(ch))


# --------------------------------------------------------------------------- pdf


def pdf_page_texts(pdf_path: Path) -> list[str]:
    """Plain text of every page (pymupdf). Raises ImportError with a hint if pymupdf is missing."""
    try:
        import pymupdf  # type: ignore
    except ImportError as e:  # pragma: no cover - environment dependent
        raise ImportError("pymupdf is required for page alignment: pip install 'deep-research-poc[ingest]'") from e
    with pymupdf.open(pdf_path) as doc:
        return [page.get_text("text") for page in doc]


# --------------------------------------------------------------------------- alignment


def _candidates(page_text: str) -> list[str]:
    """Normalized anchor candidates from the first lines of a PDF page, in page order.

    A candidate is one line, or a run of consecutive short lines joined (signature blocks, tables
    of contents and cover pages rarely have a single long line), cut to MAX_ANCHOR_CHARS."""
    keys = [k for k in (_norm_key(raw) for raw in page_text.splitlines()) if k]
    out: list[str] = []
    for i, key in enumerate(keys):
        if key.isdigit():
            continue
        cand = key
        j = i + 1
        while len(cand) < MIN_ANCHOR_CHARS and j < len(keys) and j < i + 4:
            cand += keys[j]
            j += 1
        if len(cand) < MIN_ANCHOR_CHARS:
            continue
        cand = cand[:MAX_ANCHOR_CHARS]
        if cand not in out:
            out.append(cand)
        if len(out) >= CANDIDATES_PER_PAGE:
            break
    return out


def _nth_occurrence(hay: str, needle: str, n: int, start: int = 0) -> int:
    """Position of the n-th (0-based) occurrence of `needle` in `hay` at or after `start`, or -1."""
    pos = start - 1
    for _ in range(n + 1):
        pos = hay.find(needle, pos + 1)
        if pos < 0:
            return -1
    return pos


def locate_page_starts(text: str, page_texts: list[str]) -> PageAlignment:
    """Align the pages of a PDF (their texts) to `text`. Page 1 always starts at 0.

    For every later page, the first ANCHORS_PER_PAGE candidate lines that are unique within the PDF
    (so running headers/footers are skipped) are searched for in the normalized text after the
    previous page's start; the earliest hit becomes the page start. Pages with no hit are placed
    proportionally (by PDF character count) between their nearest located neighbours and the
    alignment is flagged `approximate` unless the page is blank.
    """
    n = len(page_texts)
    if n == 0:
        return PageAlignment(n_pages=0, starts=[], located=[], blank=[], approximate=False)
    stream, index = normalize_stream(text)
    page_keys = [_norm_key(p) for p in page_texts]
    pdf_stream = "".join(page_keys)
    blank = [len(k) < EMPTY_PAGE_CHARS for k in page_keys]

    starts: list[int | None] = [0] + [None] * (n - 1)
    located = [True] + [False] * (n - 1)
    page_stream_offsets = [0]
    for k in page_keys:
        page_stream_offsets.append(page_stream_offsets[-1] + len(k))
    prev_stream_pos = 0
    for i in range(1, n):
        if blank[i]:
            continue
        hits: list[int] = []        # unique in the PDF and in the text: trustworthy
        fallback: list[int] = []    # repeated somewhere: matched by occurrence rank, lower trust
        tried = 0
        for cand in _candidates(page_texts[i]):
            tried += 1
            n_pdf = pdf_stream.count(cand)
            if n_pdf == 1:
                pos = stream.find(cand, prev_stream_pos)
                if pos >= 0:
                    (hits if stream.find(cand, pos + 1) < 0 else fallback).append(pos)
            elif n_pdf > 1:
                # repeated line (running header, TOC entry vs heading): take the occurrence in the
                # text that has the same rank as this page's occurrence in the PDF
                rank = pdf_stream.count(cand, 0, page_stream_offsets[i] + len(cand) - 1)
                pos = _nth_occurrence(stream, cand, rank)
                if pos >= prev_stream_pos:
                    fallback.append(pos)
            if len(hits) >= ANCHORS_PER_PAGE or tried >= CANDIDATES_PER_PAGE:
                break
        chosen = min(hits) if hits else (min(fallback) if fallback else None)
        if chosen is not None:
            starts[i] = index[chosen]
            located[i] = True
            prev_stream_pos = chosen

    # interpolate the gaps proportionally to the PDF text length of the missing pages
    approximate = False
    i = 1
    while i < n:
        if starts[i] is not None:
            i += 1
            continue
        j = i
        while j < n and starts[j] is None:
            j += 1
        lo = starts[i - 1]
        hi = starts[j] if j < n else len(text)
        assert lo is not None
        weights = [len(page_keys[k]) for k in range(i - 1, j)]  # pages i-1 .. j-1 share [lo, hi)
        total = sum(weights) or 1
        acc = 0
        for k in range(i, j):
            acc += weights[k - i]
            starts[k] = lo + int((hi - lo) * acc / total)
            if not blank[k]:
                approximate = True
        i = j
    fixed: list[int] = []
    for s in starts:
        assert s is not None
        fixed.append(max(s, fixed[-1]) if fixed else s)  # monotonic
    return PageAlignment(n_pages=n, starts=fixed, located=located, blank=blank, approximate=approximate)


def snap_to_line_starts(text: str, starts: list[int]) -> list[int]:
    """Move every page start back to the beginning of its line (markers go on their own line)."""
    out: list[int] = []
    for s in starts:
        s = min(max(s, 0), len(text))
        s = text.rfind("\n", 0, s) + 1
        out.append(max(s, out[-1]) if out else s)
    return out


def strip_page_markers(markdown: str) -> str:
    return _MARKER_RE.sub("", markdown)


def insert_markers(text: str, starts: list[int]) -> str:
    """Insert '<!-- page N -->' on its own line at each (line-start) offset; page 1 goes first."""
    starts = snap_to_line_starts(text, starts)
    pieces: list[str] = []
    for n, s in enumerate(starts, start=1):
        e = starts[n] if n < len(starts) else len(text)
        chunk = text[s:e]
        pieces.append(f"<!-- page {n} -->\n")
        if chunk:
            pieces.append(chunk if chunk.endswith("\n") else chunk + "\n")
    return "".join(pieces)


def align_markdown(markdown: str, pdf_path: Path) -> tuple[str, PageAlignment]:
    """Markdown with markers (existing ones removed first) plus the full alignment record."""
    body = strip_page_markers(markdown)
    alignment = locate_page_starts(body, pdf_page_texts(pdf_path))
    if alignment.n_pages == 0:
        return "<!-- page 1 -->\n" + body, PageAlignment(n_pages=1, starts=[0], located=[True], blank=[False])
    return insert_markers(body, alignment.starts), alignment


def add_page_markers(markdown: str, pdf_path: Path) -> tuple[str, bool]:
    """Return (markdown_with_markers, approximate). See module docstring."""
    text, alignment = align_markdown(markdown, pdf_path)
    return text, alignment.approximate


def add_page_markers_batch(pairs: Iterable[tuple[Path, Path]], out_dir: Path | None = None,
                           skip_existing: bool = False) -> list[dict]:
    """Batch helper: for every (markdown_path, pdf_path) write `<stem>.md` with markers into `out_dir`
    (default: in place) and return one stats row per document:
    {stem, n_pages, n_located, approximate, out}. Documents whose markdown already carries markers
    are skipped when `skip_existing` is set."""
    rows: list[dict] = []
    for md_path, pdf_path in pairs:
        md_path, pdf_path = Path(md_path), Path(pdf_path)
        markdown = md_path.read_text(encoding="utf-8", errors="replace")
        if skip_existing and _MARKER_RE.search(markdown):
            rows.append({"stem": md_path.stem, "skipped": True, "out": str(md_path)})
            continue
        text, alignment = align_markdown(markdown, pdf_path)
        out = (Path(out_dir) / md_path.name) if out_dir else md_path
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8", newline="\n")
        rows.append({"stem": md_path.stem, "n_pages": alignment.n_pages, "n_located": alignment.n_located,
                     "approximate": alignment.approximate, "out": str(out)})
    return rows
