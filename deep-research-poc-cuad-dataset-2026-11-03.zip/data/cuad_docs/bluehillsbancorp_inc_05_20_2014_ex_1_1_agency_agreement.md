<!-- page 1 -->
# AGENCY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Agency Agreement |
| Agreement Date | 2014-05-14 |
| Parties | Blue Hills Bancorp, Inc. (“Holding Company”); Hyde Park Bancorp, MHC (“MHC”); Hyde Park Bancorp, Inc. (“Mid­Tier”); Blue Hills Bank (“Bank”); Bruyette & Woods, Inc. (“Agent”) |
| Source | CUAD v1 / BLUEHILLSBANCORP,INC_05_20_2014-EX-1.1-AGENCY AGREEMENT |

Exhibit 1.1

Blue Hills Bancorp, Inc. up to 24,150,000 Shares (subject to increase up to 27,772,500 shares)

SHARES ($0.01 Par Value)

Subscription Price $10.00 Per Share

AGENCY AGREEMENT

May 14, 2014

Keefe, Bruyette & Woods, Inc. 10 South Wacker Drive Investment Banking, Suite 3400 Chicago, Illinois
60606

Ladies and Gentlemen:

Blue Hills Bancorp, Inc. (the "Holding Company"), a newly formed Maryland corporation, Hyde Park
Bancorp, MHC, a Massachusetts­ chartered mutual holding company (the "MHC"), Hyde Park Bancorp,
Inc., a Massachusetts corporation (the "Mid­Tier"), and Blue Hills Bank, a Massachusetts­chartered
stock savings bank (the "Bank" and together with the Holding Company, the MHC and the Mid­Tier, the
"Blue Hills Parties"), hereby confirm their agreement with Keefe, Bruyette & Woods, Inc. (the
"Agent") as follows:

Section 1. The Offering. The MHC, in accordance with the plan of conversion as adopted by the Boards
of Directors of each of the Blue Hills Parties (the "Plan"), intends to convert from the current
mutual holding company form of organization to a stock holding company form of organization (the
"Conversion"). Pursuant to the Plan, the Holding Company will offer and sell up to 24,150,000 shares
(subject to increase up to 27,772,500 shares) of its common stock, $0.01 par value per share (the
"Shares"), in a subscription offering (the "Subscription Offering") to (1) depositors of the Bank
with Qualifying Deposits (as defined in the Plan) as of February 28, 2013 ("Eligible Account
Holders"), (2) the Bank's tax­ qualified employee benefit plans, including the employee stock
ownership plan established by the Bank (the "ESOP"), and (3) employees, officers, directors,
trustees and corporators of the Bank, the Mid-Tier and the MHC who do not have a higher priority to
purchase stock. Subject to the prior subscription rights of the above­listed parties, the Holding
Company may offer for sale in a direct community offering (the "Community Offering" and when
referred to together with or subsequent to the Subscription Offering, the "Subscription and
Community Offering") the Shares not subscribed for or ordered in the Subscription Offering to
members of the general public to whom a copy of the Prospectus (as hereinafter defined) is delivered
with a preference given first to natural persons and trusts of natural persons residing in the local
community as defined in the Plan, and thereafter to cover orders of other members of the general
public. It is anticipated that Shares not subscribed for in the Subscription and Community Offering
may be offered to certain members of the general public on a best efforts basis through a selected
dealers agreement (the "Syndicated Community Offering") or to certain members of the general public
in a firm commitment underwritten offering (the "Underwritten Offering") with the Agent acting as
sole book­running manager (the Underwritten Offering, Subscription Offering, Community Offering and
Syndicated Community Offering are collectively referred to as the "Offering"). It is acknowledged
that the purchase of Shares in the Offering is subject to the maximum and minimum purchase
limitations as described in the Plan and that the Holding Company may reject, in whole or in part,
any order received in the Community Offering or Syndicated Community Offering.
<!-- page 2 -->
The Holding Company has filed with the Securities and Exchange Commission (the "Commission") a
registration statement on Form S-1 (File No. 333­194486) (the "Registration Statement"), containing
a prospectus relating to the Subscription and Community Offering, for the registration of the Shares
under the Securities Act of 1933 (the "1933 Act"), and has filed such amendments thereof and such
amended prospectuses as may have been required to the date hereof. The term "Registration Statement"
shall include all financial schedules and exhibits thereto, as amended, including post-effective
amendments. The prospectus, as amended, on file with the Commission at the time the Registration
Statement initially became effective is hereinafter called the "Prospectus," except that if any
prospectus is filed by the Holding Company pursuant to Rule 424(b) or (c) of the rules and
regulations of the Commission under the 1933 Act (the "1933 Act Regulations") differing from the
prospectus on file at the time the Registration Statement initially became effective, the term
"Prospectus" shall refer to the prospectus filed pursuant to Rule 424(b) or (c) from and after the
time said prospectus is filed with the Commission.

In accordance with the Massachusetts General Laws and the rules and regulations governing the
conversion of Massachusetts mutual holding companies to stock holding companies (including, without
limitation, Chapter 167H of the Massachusetts General Laws and Chapter 33, Subpart D of the Code of
Massachusetts Regulations), as from time to time amended or supplemented (the "Massachusetts
Regulations"), the MHC has filed the Plan with the Massachusetts Division of Banks (the "Division")
and has filed such amendments thereto and supplementary materials as may have been required to the
date hereof (such application, as amended to date, if applicable, and as subsequently amended, if
applicable, is hereinafter referred to as the "Massachusetts Conversion Application"), including
copies of the MHC's Notice and Information Statement for a Special Meeting of its Corporators
relating to the Conversion (the "Information Statement"), the Appraisal, and the Prospectus.

In addition, the Holding Company has filed with the Board of Governors of the Federal Reserve System
(the "FRB") an Application to Become a Bank Holding Company and/or Acquire an Additional Bank or
Bank Holding Company on Form FR Y­3 (the "Holding Company Application") to become a bank holding
company under Section 3 of the Bank Holding Company Act of 1956, as amended (the "BHCA"), as in
effect at the time and the FRB has approved the Holding Company Application. The Massachusetts
Conversion Application and the Holding Company Application are collectively referred to herein as
the "Applications".

Section 2. Retention of Agent; Compensation; Sale and Delivery of the Shares. Subject to the terms
and conditions herein set forth, the Blue Hills Parties hereby appoint the Agent as their exclusive
financial advisor and conversion agent (i) to utilize its best efforts to solicit subscriptions for
Shares and to advise and assist the Holding Company and the Bank with respect to the sale of the
Shares in the Offering and (ii) to participate in the Offering in the areas of market making and in
syndicate formation or to act as sole book-running manager in the Underwritten Offering (if
necessary).

On the basis of the representations, warranties, and agreements herein contained, but subject to the
terms and conditions herein set forth, the Agent accepts such appointment and agrees to consult with
and advise the Blue Hills Parties as to the matters set forth in the letter agreements, dated
October 7, 2013, among the MHC, the Mid-Tier, the Bank and the Agent (a copy of each of which is
attached hereto as Exhibit A and Exhibit B). It is acknowledged by the Blue Hills Parties that the
Agent shall not be required to purchase any Shares in the Subscription Offering, Community Offering,
and Syndicated Community Offering or be obligated to take any action which is inconsistent with all
applicable laws, regulations, decisions or orders.

2
<!-- page 3 -->
The obligations of the Agent pursuant to this Agreement shall terminate upon termination of the
Offering, but in no event later than 45 days after the completion of the Subscription Offering,
unless extended (the "End Date"). All fees or expenses due to the Agent but unpaid will be payable
to the Agent in next day funds at the earlier of the Closing Date (as hereinafter defined) or the
End Date. In the event the Offering is extended beyond the End Date, the Blue Hills Parties and the
Agent may agree to renew this Agreement under mutually acceptable terms.

In the event the Holding Company is unable to sell a minimum of 17,850,000 Shares within the period
herein provided, this Agreement shall terminate and the Holding Company shall refund to any persons
who have subscribed for any of the Shares the full amount which it may have received from them plus
accrued interest, as set forth in the Prospectus; and none of the parties to this Agreement shall
have any obligation to the other parties hereunder, except as set forth in this Section 2 and in
Sections 7, 9 and 10 hereof. In the event the Offering is terminated for any reason not attributable
to the action or inaction of the Agent, the Agent shall be paid the fees due to the date of such
termination pursuant to subparagraphs (a) and (e) below.

The Agent shall receive the following compensation for its services hereunder:

(a) A management fee of $50,000 payable in four installments of $12,500 on the first day of October
2013, December 2013, March 2014 and June 2014. Such fees shall be deemed to have been earned when
due. Should the Offering be terminated for any reason not attributable to the action or inaction of
Agent, Agent shall have earned and be entitled to be paid fees accruing through the stage at which
point the termination occurred.

(b) A Success Fee of 0.85% shall be paid based on the aggregate purchase price of the Shares sold in
the Subscription Offering and the Community Offering excluding shares purchased by the Blue Hills
Parties' officers, directors, trustees or employees (or members of their immediate family) plus any
ESOP, tax-qualified or stock based compensation plans or similar plan created by the Blue Hills
Parties for some or all of their directors or employees or by the foundation (or any shares
contributed to the foundation). The Management Fee described in Section 2(a) above will be credited
against the Success Fee paid pursuant to this paragraph.

(c) If any of the Shares remain available after the Subscription Offering and Community Offering, at
the request of the Holding Company, Agent will seek to form a syndicate of registered broker-dealers
to assist in the sale of Shares on a best efforts basis, subject to the terms and conditions set
forth in a selected dealers agreement to be entered into between the Holding Company and Agent.
Agent will endeavor to distribute the Shares among dealers in a fashion which best meets the
distribution objectives of the Holding Company and the Plan. Agent will be paid a fee not to exceed
5.25% of the aggregate Purchase Price of the Shares sold in the Syndicated Community Offering. From
this fee, Agent will pass onto selected broker-dealers, who assist in the Syndicated Community
Offering, an amount competitive with gross underwriting discounts charged at such time for
comparable amounts of stock sold at a comparable price per share in a similar market environment.
Fees with respect to purchases affected with the assistance of a broker/dealer other than Agent
shall be transmitted by Agent to such broker/dealer. The decision to utilize selected broker-dealers
will be made by Agent upon consultation with the Holding Company.

(d) The Holding Company may engage Agent to offer the Shares to certain members of the general
public in the Underwritten Offering with Agent acting as sole book-running manager. In the event
that Agent sells Shares in the Underwritten Offering, the underwriting discount will equal 5.25% of
the aggregate Purchase Price of the Shares sold in the Underwritten Offering to Agent and to any
other broker-dealer participating as an underwriter in the Underwritten Offering.

3
<!-- page 4 -->
(e) If, as a result of any resolicitation of subscribers undertaken by the Holding Company, the
Agent reasonably determines that it is required or requested to provide significant services, the
Agent will be entitled to additional compensation for such services, which additional compensation
will not exceed $50,000.

(f) The Holding Company shall reimburse the Agent for its reasonable out-of-pocket expenses,
including costs of travel, meals and lodging, photocopying, telephone, facsimile and couriers, etc.
not to exceed $25,000. In addition, the Holding Company will reimburse the Agent for fees and
expenses of its counsel not to exceed $100,000. In the event of unusual circumstances or delays or a
re-solicitation in connection with the Offering, including in the event of a material delay in the
Offering that would require an update of the financial information in tabular form to reflect a
period later than that set forth in the original filing of the Registration Statement, the Agent
shall be reimbursed for its additional expenses up to a maximum of $10,000 in the case of additional
out-of-pocket expenses of the Agent, and up to an additional $25,000 in the case of additional fees
and expenses of the Agent's counsel. The Holding Company will bear the expenses of the Offering
customarily borne by issuers including, without limitation, regulatory filing fees, SEC, Blue Sky
and Financial Institution Regulatory Authority ("FINRA") filing and registration fees; the fees of
the Holding Company's accountants, attorneys, appraiser, transfer agent and registrar, printing,
mailing and marketing and syndicate expenses associated with the Conversion and Offering; and the
fees set forth under this Section 2.

Conversion Agent Services. The Agent shall also receive a fee of $50,000 for certain conversion
agent services set forth in the letter agreement, dated October 7, 2013, among the MHC, the
Mid-Tier, the Bank and the Agent (a copy of which is attached hereto as Exhibit B), $10,000 of which
has already been paid to the Agent and is nonrefundable and the balance of which shall be payable to
the Agent upon completion of the Offering. The Holding Company will reimburse the Agent, upon
request made from time to time, for its reasonable out-of-pocket expenses incurred in connection
with its conversion agent services not to exceed $25,000 without the consent of the Blue Hills
Parties. However, in the event of unusual circumstances, delays or a re-solicitation in connection
with the offering, the total fees paid to the Agent may be increased by an additional amount not to
exceed $10,000.

Section 3. Sale and Delivery of Shares. If all conditions precedent to the consummation of the
Conversion, including without limitation, the sale of all Shares required by the Plan to be sold,
are satisfied, the Holding Company agrees to issue, or have issued, the Shares sold in the Offering
and to release for delivery certificates for such Shares on the Closing Date against payment to the
Holding Company by any means authorized by the Plan; provided, however, that no funds shall be
released to the Holding Company until the conditions specified in Section 8 hereof shall have been
complied with to the reasonable satisfaction of the Agent or its counsel. The release of Shares
against payment therefor shall be made on a date and at a place acceptable to the Blue Hills Parties
and the Agent as set forth in Section 14. Certificates for shares shall be delivered directly to the
purchasers in accordance with their directions as provided by the Holding Company to the Holding
Company's registrar and transfer agent. The date upon which the Holding Company shall release or
deliver the Shares sold in the Offering, in accordance with the terms herein, is called the "Closing
Date."

Section 4. Representations and Warranties of the Blue Hills Parties. The Blue Hills Parties, jointly
and severally, represent and warrant to and agree with the Agent as follows:

(a) The Registration Statement, which was prepared by the Blue Hills Parties and filed with the
Commission, has been declared effective by the Commission, no stop order has been issued with
respect thereto and no proceedings therefor have been initiated or, to the knowledge of the Blue
Hills Parties, threatened by the Commission. At the time the Registration Statement, including the
Prospectus contained therein (including any amendment or supplement), became effective, at the
Applicable Time

4
<!-- page 5 -->
(as defined in Section 4(c) hereof) and at the Closing Date, the Registration Statement complied and
will comply in all material respects with the requirements of the 1933 Act and the 1933 Act
Regulations and the Registration Statement, including the Prospectus contained therein (including
any amendment or supplement thereto), and any information regarding the Blue Hills Parties contained
in Sales Information (as such term is defined in Section 9 hereof) authorized by the Blue Hills
Parties for use in connection with the Offering, did not contain an untrue statement of a material
fact or omit to state a material fact required to be stated therein or necessary to make the
statements therein, in light of the circumstances under which they were made, not misleading, and at
the time any Rule 424(b) or (c) Prospectus is filed with the Commission and at the Closing Date
referred to in Section 3 hereof, the Prospectus (including any amendment or supplement thereto) and
any information regarding the Holding Company contained in Sales Information (as such term is
defined in Section 9 hereof) authorized by the Holding Company for use in connection with the
Offering contains all statements that are required to be stated therein in accordance with the 1933
Act and the 1933 Act Regulations and does not contain an untrue statement of a material fact or omit
to state a material fact necessary in order to make the statements therein, in light of the
circumstances under which they were made, not misleading; provided, however, that the
representations and warranties in this Section 4(a) shall not apply to statements or omissions made
in reliance upon and in conformity with written information furnished to the Holding Company by the
Agent or its counsel expressly regarding the Agent for use in the Prospectus (the "Agent
Information," which the Blue Hills Parties acknowledge appears only in the first sentence of the
second paragraph under the caption "The Conversion; Plan of Distribution—Marketing and Distribution;
Compensation" in the Prospectus).

(b) None of the Blue Hills Parties has directly or indirectly distributed or otherwise used and will
not directly or indirectly distribute or otherwise use any prospectus, any "free writing prospectus"
(as defined in Rule 405 of the 1933 Act Regulations) or other offering material (including, without
limitation, content on the Holding Company's website that may be deemed to be a prospectus, free
writing prospectus or other offering material) in connection with the offering and sale of the
Shares other than any Permitted Free Writing Prospectus or the Prospectus or other materials
permitted by the 1933 Act and the 1933 Act Regulations distributed by the Holding Company and
reviewed and approved in advance for distribution by the Agent. The Holding Company has not,
directly or indirectly, prepared or used and will not directly or indirectly, prepare or use, any
Permitted Free Writing Prospectus except in compliance with the filing and other requirements of
Rules 164 and 433 of the 1933 Act Regulations; assuming that such Permitted Free Writing Prospectus
is so sent or given after the Registration Statement was filed with the Commission (and after such
Permitted Free Writing Prospectus was, if required pursuant to Rule 433(d) under the Act, filed with
the Commission), the sending or giving, by the Agent, of any Permitted Free Writing Prospectus will
satisfy the provisions of Rules 164 and 433 (without reliance on subsections (b), (c) and (d) for
Rule 164); and the Holding Company is not an "ineligible issuer" (as defined in Rule 405 of the 1933
Act Regulations) as of the eligibility determination date for purposes of Rules 164 and 433 of the
1933 Act Regulations with respect to the offering of the Shares or otherwise precluded under Rule
164 from using free writing prospectuses in connection with the offering of the Shares.

(c) As of the Applicable Time (as defined below), neither (i) the Issuer-Represented General Free
Writing Prospectus(es) issued at or prior to the Applicable Time and the Statutory Prospectus, all
considered together (collectively, the "General Disclosure Package"), nor (ii) any individual
Issuer-Represented Limited-Use Free Writing Prospectus, when considered together with the General
Disclosure Package, included any untrue statement of a material fact or omitted to state any
material fact necessary in order to make the statements therein, in the light of the circumstances
under which they were made, not misleading. The preceding sentence does not apply to statements in
or omissions from any Prospectus included in the Registration Statement relating to the offered
Shares or any Issuer-Represented Free Writing Prospectus based upon and in conformity with written
information furnished to the Holding Company by the Agent specifically for use therein. As used in
this paragraph and elsewhere in this Agreement:

1. "Applicable Time" means each and every date when a potential purchaser submitted a subscription
or otherwise committed to purchase Shares.

5
<!-- page 6 -->
2. "Statutory Prospectus," as of any time, means the Prospectus relating to the offered Shares that
is included in the Registration Statement relating to the offered Shares immediately prior to the
Applicable Time, including any document incorporated by reference therein.

3. "Issuer­Represented Free Writing Prospectus" means any "issuer free writing prospectus," as
defined in Rule 433(h) of the 1933 Act Regulations, relating to the offered Shares in the form filed
or required to be filed or, if not required to be filed, in the form retained in the Holding
Company's records pursuant to Rule 433(g) under the 1933 Act Regulations. The term does not include
any writing exempted from the definition of prospectus pursuant to clause (a) of Section 2(a)(10) of
the 1933 Act, without regard to Rule 172 or Rule 173 of the 1933 Act Regulations.

4. "Issuer­Represented General Free Writing Prospectus" means any Issuer­Represented Free Writing
Prospectus that is intended for general distribution to prospective investors.

5. "Issuer­Represented Limited­Use Free Writing Prospectus" means any Issuer­Represented Free
Writing Prospectus that is not an Issuer-Represented General Free Writing Prospectus. The term
Issuer-Represented Limited-Use Free Writing Prospectus also includes any "bona fide electronic road
show," as defined in Rule 433 of the 1933 Act Regulations, that is made available without
restriction pursuant to Rule 433(d)(8)(ii) of the 1933 Act Regulations or otherwise, even though not
required to be filed with the Commission.

6. "Permitted Free Writing Prospectus" means any free writing prospectus as defined in Rule 405 of
the 1933 Act Regulations that is consented to by the Holding Company, the Bank and the Agent.

(d) Each Issuer-Represented Free Writing Prospectus, as of its date of first use and at all
subsequent times through the completion of the Offering and sale of the offered Shares or until any
earlier date that the Holding Company notified or notifies the Agent (as described in the next
sentence), did not, does not and will not include any information that conflicted, conflicts or will
conflict with the information contained in the Registration Statement. If at any time following the
date of first use of an Issuer-Represented Free Writing Prospectus there occurred or occurs an event
or development as a result of which such Issuer-Represented Free Writing Prospectus conflicted or
would conflict with the information contained in the Registration Statement relating to the offered
Shares or included or would include an untrue statement of a material fact or omitted or would omit
to state a material fact necessary in order to make the statements therein, in the light of the
circumstances prevailing at that subsequent time, not misleading, the Holding Company has notified
or will notify promptly the Agent so that any use of such Issuer-Represented Free-Writing Prospectus
may cease until it is amended or supplemented and the Holding Company has promptly amended or will
promptly amend or supplement such Issuer-Represented Free Writing Prospectus to eliminate or correct
such conflict, untrue statement or omission. The foregoing two sentences do not apply to statements
in or omissions from any Issuer-Represented Free Writing Prospectus based upon and in conformity
with written information furnished to the Holding Company by the Agent specifically for use therein.

6
<!-- page 7 -->
(e) The Holding Company has filed the Holding Company Application with the FRB and has published
notice of such filing and the Holding Company Application is accurate and complete in all material
respects. The Holding Company has received written notice from the FRB of its approval of the
acquisition of the Bank, such approval remains in full force and effect and no order has been issued
by the FRB suspending or revoking such approval and no proceedings therefor have been initiated or,
to the knowledge of the Blue Hills Parties, threatened by the FRB or any other applicable regulator.
At the date of such approval, the Holding Company Application complied in all material respects with
the applicable provisions of the BHCA and the regulations promulgated thereunder, except as the FRB
or any other applicable regulator has expressly waived such regulations in writing.

(f) The MHC has filed the Massachusetts Conversion Application with the Division and the
Massachusetts Conversion Application is accurate and complete in all material respects. The MHC has
received written notice from the Division of its approval of the Prospectus, order form and
marketing materials for use in the Offering, such approval remains in full force and effect and no
order has been issued by the Division suspending or revoking such approval and no proceedings
therefor have been initiated or, to the knowledge of the Blue Hills Parties, threatened by the
Division. On the Closing Date, the MHC will have received written notice from the Division of its
approval of the Conversion, and no order will have been issued by the Division suspending or
revoking such approval and no proceedings therefor will have been initiated or, to the knowledge of
the Blue Hills Parties, threatened by the Division. At the date of the applicable approval, the
Prospectus, order form and marketing materials for use in the Offering and the Massachusetts
Conversion Application complied in all material respects with the applicable provisions of the
Massachusetts Regulations, except as the Division or any other applicable regulator has expressly
waived such Massachusetts Regulations in writing.

(g) The Blue Hills Parties have filed the Prospectus and any supplemental sales literature with the
Commission, the FRB, the Division and any other applicable regulator. The Prospectus, the
Information Statement and all supplemental sales literature, as of the date the Registration
Statement became effective and on the Closing Date referred to in Section 3, complied and will
comply in all material respects with the applicable requirements of the 1933 Act Regulations, the
Massachusetts Regulations and, at or prior to the time of their first use, will have received all
required authorizations of the Division and the Commission and any other applicable regulator for
use in final form. No approval of any other regulatory or supervisory or other public authority is
required in connection with the distribution of the Prospectus, the Information Statement and any
supplemental sales literature that has not been obtained and a copy of which has been delivered to
the Agent. The Holding Company and the Bank have not distributed any offering material in connection
with the Offering except for the Prospectus, the Information Statement and any supplemental sales
material that has been filed with the Registration Statement and the Applications and authorized for
use by the Commission, the FRB and the Division, or any other applicable regulator. The information
contained in the supplemental sales material filed as an exhibit to both the Registration Statement
and the Applications does not conflict in any material respects with information contained in the
Registration Statement and the Prospectus.

(h) The Plan has been adopted by the Boards of Directors of the Blue Hills Parties, and the offer
and sale of the Shares will have been conducted in all material respects in accordance with the
Plan, the Massachusetts Regulations (except to the extent waived or otherwise approved by the
Division) and all other applicable laws, regulations, decisions and orders, including all terms,
conditions, requirements and provisions precedent to the Offering imposed upon the Blue Hills
Parties by the Division, the Commission, or any other regulatory authority and in the manner
described in the Prospectus. To the best knowledge of the Blue Hills Parties, no person has sought
to obtain review of the final action of the Division or any other applicable regulator in approving
the Conversion.

7
<!-- page 8 -->
(i) The Bank has been duly organized and validly existing as a Massachusetts-chartered stock savings
bank and upon completion of the Conversion will continue to be a duly organized and validly existing
Massachusetts-chartered savings bank in stock form, in both instances duly authorized to conduct its
business and own its property as described in the Registration Statement and the Prospectus; the
Bank has obtained all licenses, permits and other governmental authorizations currently required for
the conduct of its business, except those that individually or in the aggregate would not have a
material adverse effect on the conduct of the business, financial condition, results of operations,
affairs or prospects of the Blue Hills Parties, taken as a whole (a "Material Adverse Effect"); all
such licenses, permits and governmental authorizations are in full force and effect, and the Bank is
in compliance with all laws, rules, regulations and orders applicable to the operation of its
business, except where failure to be in compliance would not have a Material Adverse Effect; the
Bank is duly qualified as a foreign corporation to transact business and is in good standing in each
jurisdiction in which its ownership of property or leasing of property or the conduct of its
business requires such qualification, unless the failure to be so qualified in one or more of such
jurisdictions would not have a Material Adverse Effect. The Bank does not own equity securities or
any equity interest in any other business enterprise except as described in the Prospectus or as
would not be material to the operations of the Blue Hills Parties, taken as a whole. Following
completion of the Conversion and the Offering, the authorized capital stock of the Bank will consist
of 10,000 shares of common stock, par value $1.00 per share (the "Bank Common Stock"), of which
5,000 shares of Bank Common Stock are issued and outstanding as of the date hereof; the issued and
outstanding shares of Bank Common Stock have been duly authorized and validly issued and are fully
paid and non-assessable and following completion of the Conversion, will be owned directly by the
Holding Company free and clear of any security interest, mortgage, pledge, lien, encumbrances or
legal or equitable claim; the terms and provisions of the Bank Common Stock conform to all
statements thereto contained in the Prospectus. The Conversion will be effected in all material
respects in accordance with all applicable statutes, regulations, decisions and orders; and, except
with respect to the filing of certain post-sale, post- Conversion reports, and documents in
compliance with the 1933 Act, the Massachusetts Regulations or letters of approval, at the Closing
Date, all terms, conditions, requirements and provisions with respect to the Conversion imposed by
the Commission, the FRB and the Division or any other applicable regulator, if any, will have been
complied with by the Blue Hills Parties in all material respects or appropriate waivers will have
been obtained and all applicable notice and waiting periods will have been satisfied, waived or
elapsed.

(j) The Holding Company is duly organized, validly existing and in good standing as a corporation
under the laws of the State of Maryland with full corporate power and authority to own, lease and
operate its properties and to conduct its business as described in the Registration Statement and
the Prospectus, and the Holding Company is, and at the Closing Date will be, qualified to do
business as a foreign corporation in each jurisdiction in which the conduct of its business requires
such qualification, except where the failure to so qualify would not have a Material Adverse Effect.
The Holding Company has obtained all licenses, permits and other governmental authorizations
currently required for the conduct of its business except those that individually or in the
aggregate would not have a Material Adverse Effect; all such licenses, permits and governmental
authorizations are in full force and effect, and the Holding Company is in all material respects
complying therewith and with all laws, rules, regulations and orders applicable to the operation of
its business. There are no outstanding warrants or options to purchase any securities of the Holding
Company.

(k) The MHC is duly organized, validly existing and in good standing as a mutual holding company
organized under the laws of the Commonwealth of Massachusetts with full corporate power and
authority to own and operate its properties and to conduct its business as described in the

8
<!-- page 9 -->
Registration Statement and the Prospectus and, at the Closing Date, the corporate existence of the
MHC will cease to exist. The MHC has obtained all licenses, permits and other governmental
authorizations currently required for the conduct of its business except those that individually or
in the aggregate would not have a Material Adverse Effect; all such licenses, permits and
governmental authorizations are in full force and effect, and the MHC is in all material respects
complying therewith and with all laws, rules, regulations and orders applicable to the operations of
its business.

(l) The MHC has no capital stock.

(m) The Mid-Tier is duly organized, validly existing and in good standing as a corporation organized
under the laws of the Commonwealth of Massachusetts with full corporate power and authority to own
and operate its properties and to conduct its business as described in the Registration Statement
and the Prospectus and, at the Closing Date, the corporate existence of the Mid-Tier will cease to
exist. The Mid-Tier has obtained all licenses, permits and other governmental authorizations
currently required for the conduct of its business except those that individually or in the
aggregate would not have a Material Adverse Effect; all such licenses, permits and governmental
authorizations are in full force and effect, and the Mid-Tier is in all material respects complying
therewith and with all laws, rules, regulations and orders applicable to the operations of its
business. Immediately prior to the completion of the Conversion and the Offerings, the authorized
capital stock of the Mid-Tier will consist solely of 275,000 shares of common stock, no par value,
of which 1,000 shares will be issued and outstanding and held by the MHC, and 50,000 shares of
preferred stock, no par value. As of the date hereof, 18,724 shares of Senior Non-Cumulative
Perpetual Preferred Stock, Series A are issued and outstanding and held by The Secretary of the
Treasury and no other shares of preferred stock will be issued or outstanding immediately prior to
the completion of the Conversion and the Offerings.

(n) Except as described in the Prospectus there are no contractual encumbrances or restrictions or
requirements or legal restrictions or requirements required to be described therein, on the ability
of any of the Blue Hills Parties, (A) to pay dividends or make any other distributions on its
capital stock or to pay any indebtedness owed to another party, (B) to make any loans or advances
to, or investments in, another party or (C) to transfer any of its property or assets to another
party. Except as described in the Prospectus, there are no restrictions, encumbrances or
requirements affecting the payment of dividends or the making of any other distributions on any of
the capital stock of the Holding Company.

(o) The Bank has properly administered all accounts for which it acts as a fiduciary, including but
not limited to accounts for which it serves as a trustee, agent, custodian, personal representative,
guardian, conservator or investment advisor, in accordance with the terms of the governing documents
and applicable state and federal law and regulation, except where the failure to do so would not
have a Material Adverse Effect. Neither the Bank, nor any of its respective directors, officers or
employees has committed any material breach of trust with respect to any such fiduciary account, and
the accountings for each such fiduciary account are true and correct in all material respects and
accurately reflect the assets of such fiduciary account in all material respects.

(p) The Bank is a member in good standing of the Federal Home Loan Bank of Boston ("FHLBB"). The
deposit accounts of the Bank are insured by the FDIC up to the applicable limits, and upon
consummation of the Conversion, the liquidation accounts for the benefit of Eligible Account Holders
will be duly established in accordance with the requirements of the Massachusetts Regulations. No
proceedings for the termination or revocation of such insurance are pending or, to the best
knowledge of the Blue Hills Parties, threatened.

9
<!-- page 10 -->
(q) The Blue Hills Parties have good and marketable title to all real property and good title to all
other assets material to the business of the Blue Hills Parties, taken as a whole, and to those
properties and assets described in the Registration Statement and Prospectus as owned by them, free
and clear of all liens, charges, encumbrances or restrictions, except such as are described in the
Registration Statement and Prospectus or as are not material to the business of the Blue Hills
Parties, taken as a whole; and all of the leases and subleases material to the business of the Blue
Hills Parties, taken as a whole, under which the Blue Hills Parties hold properties, including those
described in the Registration Statement and Prospectus, are in full force and effect.

(r) The Holding Company has received an opinion of its special counsel, Luse Gorman Pomerenk &
Schick, P.C. ("Luse Gorman"), with respect to the legality of the Shares to be issued and the
federal income tax consequences of the Conversion and the opinion of Wolf & Co., P.C., with respect
to the Massachusetts state income tax consequences of the Conversion, copies of which are filed as
exhibits to the Registration Statement; all material aspects of such opinions are accurately
summarized in the Registration Statement and the Prospectus. The facts upon which such opinions are
based are truthful, accurate and complete in all material respects. None of Blue Hills Parties has
taken or will take any action inconsistent therewith.

(s) Each of the Blue Hills Parties has all such power, authority, authorizations, approvals and
orders as may be required to enter into this Agreement, to carry out the provisions and conditions
hereof and to issue and sell the Shares to be sold by the Holding Company as provided herein and as
described in the Prospectus, subject to approval or confirmation by the Division or any other
applicable regulator of the final Appraisal. The execution, delivery and performance of this
Agreement and the consummation of the transactions herein contemplated have been duly and validly
authorized by all necessary corporate action on the part of each of the Blue Hills Parties. This
Agreement has been validly executed and delivered by each of the Blue Hills Parties and, assuming
due execution and delivery by the Agent, is the valid, legal and binding agreement of each of the
Blue Hills Parties enforceable in accordance with its terms (except as the enforceability thereof
may be limited by bankruptcy, insolvency, moratorium, reorganization or similar laws relating to or
affecting the enforcement of creditors' rights generally or the rights of creditors of bank holding
companies, the accounts of whose subsidiaries are insured by the FDIC, or by general equity
principles, regardless of whether such enforceability is considered in a proceeding in equity or at
law, and except to the extent, if any, that the provisions of Sections 9 and 10 hereof may be
unenforceable as against public policy or pursuant to applicable Federal law and the rules and
regulations of the FRB).

(t) None of the Blue Hills Parties is in violation of any directive received from the FRB, the
Division or the FDIC to make any material change in the method of conducting its business so as to
comply in all material respects with all applicable statutes and regulations (including, without
limitation, regulations, decisions, directives and orders of the FRB, the Division or the FDIC) and,
except as may be set forth in the Registration Statement, the General Disclosure Package and the
Prospectus, there is no suit or proceeding or charge or action before or by any court, regulatory
authority or governmental agency or body, pending or, to the knowledge of any of the Blue Hills
Parties, threatened, which might materially and adversely affect the Offering, or which might result
in any Material Adverse Effect.

(u) The consolidated financial statements, schedules and notes related thereto which are included in
the General Disclosure Package and the Prospectus fairly present the balance sheet, income
statement, statement of changes in equity capital and statement of cash flows of the MHC on a
consolidated basis at the respective dates indicated and for the respective periods covered thereby
and comply as to form in all material respects with the applicable accounting requirements of the
1933 Act Regulations and Title 12 of the Code of Federal Regulations. Such consolidated financial
statements,

10
<!-- page 11 -->
schedules and notes related thereto have been prepared in accordance with accounting principles
generally accepted in the United States of America ("GAAP") consistently applied through the periods
involved, present fairly in all material respects the information required to be stated therein and
are consistent with the most recent financial statements and other reports filed by the Blue Hills
Parties with the Division, the FDIC and the FRB, except that accounting principles employed in such
regulatory filings conform to the requirements of the Division, the FDIC and the FRB and not
necessarily to GAAP. The other financial, statistical and pro forma information and related notes
included in the Prospectus present fairly the information shown therein on a basis consistent with
the audited and unaudited consolidated financial statements of the Blue Hills Parties included in
the Prospectus, and as to the pro forma adjustments, the adjustments made therein have been properly
applied on the basis described therein.

(v) The Blue Hills Parties carry, or are covered by, insurance in such amounts and covering such
risks as is adequate for the conduct of their respective businesses and the value of their
respective properties as is customary for companies engaged in a similar industry.

(w) Since the respective dates as of which information is given in the Registration Statement
including the Prospectus and except as disclosed in the General Disclosure Package and the
Prospectus: (i) there has not been any material adverse change, financial or otherwise, in the
condition of the Blue Hills Parties and their subsidiaries, considered as one enterprise, or in the
earnings, capital, properties, business or prospects of the Blue Hills Parties and their
subsidiaries considered as one enterprise, whether or not arising in the ordinary course of
business; (ii) there has not been any material increase in the long­term debt of any of the Blue
Hills Parties or in the principal amount of the Blue Hills Parties' consolidated assets which are
classified by any of such entities as impaired, substandard, doubtful or loss or in loans past due
90 days or more or real estate acquired by foreclosure, by deed-in-lieu of foreclosure or deemed
in-substance foreclosure or any material decrease in equity capital or total assets of any of the
Blue Hills Parties; nor has any of the Blue Hills Parties issued any securities (other than in
connection with the incorporation of the Holding Company) or incurred any liability or obligation
for borrowing other than in the ordinary course of business; (iii) there have not been any material
transactions entered into by the Blue Hills Parties; (iv) there has been no material adverse change
in any of the Blue Hills Parties' relationship with its insurance carriers, including, without
limitation, cancellation or other termination of any of the Blue Hills Parties' fidelity bond or any
other type of insurance coverage; (v) there has been no material change in management of any of the
Blue Hills Parties; (vi) none of the Blue Hills Parties has sustained any material loss or
interference with its respective business or properties from fire, flood, windstorm, earthquake,
accident or other calamity, whether or not covered by insurance; (vii) none of the Blue Hills
Parties has defaulted in the payment of principal or interest on any outstanding debt obligations;
(viii) the capitalization, liabilities, assets, properties and business of the Blue Hills Parties
conform in all material respects to the descriptions thereof contained in the General Disclosure
Package and the Prospectus; and (ix) none of the Blue Hills Parties has any material liabilities,
contingent or otherwise, except as set forth in the Prospectus.

(x) None of the Blue Hills Parties is (i) in violation of their respective articles, charters,
organizational certificates or bylaws (and none of the Blue Hills Parties will be in violation of
its articles of incorporation, charters, organizational certificates or bylaws upon completion of
the Conversion), or (ii) in default (nor has any event occurred which, with notice or lapse of time
or both, would constitute a defect) in the performance or observance of any obligation, agreement,
covenant, or condition contained in any contract, lease, loan agreement, indenture, mortgage, or
other instrument to which it is a party or by which it or any of its property may be bound, or to
which any of the property or assets of the Blue Hills Parties is subject, except for defaults that
would not, individually or in the aggregate, have a Material Adverse Effect, and there are no
contracts or documents of the Blue Hills Parties that are required to be filed as exhibits to the
Registration Statement or the Applications that have

11
<!-- page 12 -->
not been so filed. The execution and delivery of this Agreement and the consummation of the
transactions herein contemplated will not: (i) conflict with or constitute a breach of, or default
under, or result in the creation of any lien, charge or encumbrance upon any of the assets of any of
the Blue Hills Parties pursuant to the respective articles of incorporation, charters or bylaws of
the Blue Hills Parties or any contract, lease or other instrument in which the Blue Hills Parties
has a beneficial interest, or any applicable law, rule, regulation or order; (ii) violate any
authorization, approval, judgment, decree, order, statute, rule or regulation applicable to any of
the Blue Hills Parties; or (iii) result in the creation of any material lien, charge or encumbrance
upon any property of the Blue Hills Parties.

(y) All documents made available or delivered by, or to be made available to or delivered by the
Blue Hills Parties or their representatives in connection with the issuance and sale of the Shares,
including records of account holders and depositors of the Bank, or in connection with the Agent's
exercise of due diligence, except for those documents which were prepared by parties other than the
Blue Hills Parties or their representatives, were on the dates on which they were delivered, or will
be on the dates on which they are to be delivered, true, complete and correct in all material
respects.

(z) Upon consummation of the Conversion, the authorized, issued and outstanding equity capital of
the Holding Company will be within the range set forth in the General Disclosure Package and the
Prospectus under the caption "Capitalization," and no Shares have been or will be issued and
outstanding prior to the Closing Date; the Shares will have been duly and validly authorized for
issuance and, when issued and delivered by the Holding Company pursuant to the Plan against payment
of the consideration calculated as set forth in the Plan and in the Prospectus, will be duly and
validly issued, fully paid and non-assessable, except for shares purchased by the ESOP with funds
borrowed from the Holding Company to the extent payment therefor in cash has not been received by
the Holding Company; except to the extent that subscription rights and priorities pursuant thereto
exist pursuant to the Plan, no preemptive rights exist with respect to the Shares; and the terms and
provisions of the Shares will conform in all material respects to the description thereof contained
in the Registration Statement and the Prospectus. On the Closing Date, the Shares will have been
approved for listing on the Nasdaq Global Stock Market, subject to issuance. Upon the issuance of
the Shares, good title to the Shares will be transferred from the Holding Company to the purchasers
thereof against payment therefor, subject to such claims as may be asserted against the purchasers
thereof by third-party claimants.

(aa) No default exists, and no event has occurred which, with notice or lapse of time or both, would
constitute a default on the part of any of the Blue Hills Parties in the due performance and
observance of any term, covenant, agreement, obligation, representation, warranty or condition of
any indenture, mortgage, deed of trust, note, bank loan or credit agreement, lease, license, permit
or any other instrument or agreement to which the Blue Hills Parties is a party or by which any of
them or any of their respective property is bound or affected which, in any such case, could have,
individually or in the aggregate with other breaches, violations or defaults, a Material Adverse
Effect; each of such agreements is in full force and effect and is the legal, valid and binding
agreement of the applicable party and the other parties thereto, enforceable in accordance with its
terms, except as the enforcement thereof may be limited by bankruptcy, insolvency, reorganization or
similar laws affecting the rights of creditors generally and subject to general principles of equity
and no other party to any such agreement has instituted or, to the knowledge of the Blue Hills
Parties, threatened any action or proceeding wherein any of the Blue Hills Parties or any subsidiary
thereof would or might be alleged to be in default thereunder where such action or proceeding, if
determined adversely to the Blue Hills Parties, would have a Material Adverse Effect. There are no
contracts or documents that are required to be filed as exhibits to the Registration Statement or
described in the Registration Statement, the Prospectus, or any Permitted Free Writing Prospectus
which are not so filed or described as required, and such contracts and documents as are summarized
in the Registration Statement, the Prospectus, and any Permitted Free Writing Prospectus are fairly
summarized in all material respects. No party has sent or received any notice indicating the

12
<!-- page 13 -->
termination of or intention to terminate any of the contracts or agreements referred to or described
in the Registration Statement, the Prospectus, or any Permitted Free Writing Prospectus, or filed as
an exhibit to the Registration Statement, and, to the knowledge of the Blue Hills Parties, no such
termination has been threatened by any party to any such contract or agreement.

(bb) Subsequent to the date the Registration Statement is declared effective by the Commission and
prior to the Closing Date, except as otherwise may be indicated or contemplated in the Registration
Statement, none of the Blue Hills Parties has or will have issued any securities or incurred any
liability or obligation, direct or contingent, for borrowed money, except borrowings from the same
or similar sources indicated in the Prospectus in the ordinary course of its business.

(cc) Except for the Savings Banks Employees Retirement Association Pension Plan and those plans set
forth on Schedule 4(cc), none of the Blue Hills Parties maintains any "pension plan," as defined in
the Employee Retirement Income Security Act of 1974, as amended ("ERISA"). In addition, (A) the
employee benefit plans, including employee welfare benefit plans, of the Blue Hills Parties (the
"Employee Plans") have been operated in compliance with the applicable provisions of ERISA, the
Internal Revenue Code of 1986, as amended (the "Code"), all regulations, rulings and announcements
promulgated or issued thereunder and all other applicable laws and governmental regulations, (B) no
reportable event under Section 4043(c) of ERISA has occurred with respect to any Employee Plan of
the Blue Hills Parties for which the reporting requirements have not been waived by the Pension
Benefit Guaranty Corporation, (C) no prohibited transaction under Section 406 of ERISA, for which an
exemption does not apply, has occurred with respect to any Employee Plan of the Blue Hills Parties
and (D) all Employee Plans that are group health plans have been operated in compliance with the
group health plan continuation coverage requirements of Section 4980B of the Code, except to the
extent such noncompliance, reportable event or prohibited transaction would not have, individually
or in the aggregate, a Material Adverse Effect. There are no pending or, to the knowledge of the
Blue Hills Parties, threatened, claims by or on behalf of any Employee Plan, by any employee or
beneficiary covered under any such Employee Plan or by any governmental authority, or otherwise
involving such Employee Plans or any of their respective fiduciaries (other than for routine claims
for benefits).

(dd) No approval of any regulatory or supervisory or other public authority is required in
connection with the execution and delivery of this Agreement or the issuance of the Shares, except
for action by the Commission declaring the Registration Statement effective, and approval by the
FRB, the Division and any necessary qualification, notification, registration or exemption under the
securities or blue sky laws of the various states in which the Shares are to be offered, and except
as may be required under the rules and regulations of the FINRA.

(ee) Wolf & Co., P.C., which has certified the audited consolidated financial statements of the MHC
included in the Prospectus, has advised the Blue Hills Parties in writing that they are, with
respect to the Blue Hills Parties, independent registered public accountants within the applicable
rules of the Public Company Accounting Oversight Board (United States).

(ff) RP Financial LC, which has prepared the Appraisal, has advised the Blue Hills Parties in
writing that it is independent of the Blue Hills Parties within the meaning of the Massachusetts
Regulations and is believed by the Blue Hills Parties to be experienced and expert in the valuation
and the appraisal of business entities, including savings banks, and the Blue Hills Parties believe
that RP Financial LC has prepared the pricing information set forth in the Prospectus in accordance
with the requirements of the Massachusetts Regulations.

(gg) The Blue Hills Parties have timely filed or extended all required federal, state and local
income and franchise tax returns required to be filed; the Blue Hills Parties have timely paid all

13
<!-- page 14 -->
taxes that have become due and payable in respect of such returns and no deficiency has been
asserted with respect thereto by any taxing authority. The Blue Hills Parties have no knowledge of
any tax deficiency which has been or might be assessed against them which, if subject to an
unfavorable decision, ruling or finding, could have, individually or in the aggregate with other tax
deficiencies, a Material Adverse Effect. All material tax liabilities have been adequately provided
for in the financial statements of the Blue Hills Parties in accordance with GAAP. There are no
transfer taxes or other similar fees or charges under Federal law or the laws of any state, or any
political subdivision thereof, required to be paid in connection with the execution and delivery of
this Agreement by the Holding Company or with the issuance or sale by the Holding Company of the
Shares.

(hh) Each of the Blue Hills Parties is in compliance in all material respects with the applicable
financial record-keeping and reporting requirements of the Currency and Foreign Transactions
Reporting Act of 1970, as amended, and the regulations and rules thereunder. The Bank has
established compliance programs and is in compliance in all material respects with the requirements
of the USA PATRIOT Act and all applicable regulations promulgated thereunder, and, except as
disclosed in the Prospectus, there is no charge, investigation, action, suit or proceeding before
any court, regulatory authority or governmental entity or body pending or, to the knowledge of the
Blue Hills Parties, threatened regarding the Bank's compliance with the USA PATRIOT Act or any
regulations promulgated thereunder.

(ii) All Sales Information (as defined in Section 9(a)) used by the Holding Company in connection
with the Conversion that is required by the Division to be filed has been filed with and approved by
the Division or any other applicable regulator.

(jj) Except for the loan to the ESOP by the Holding Company or a subsidiary of the Holding Company,
to the knowledge of the Blue Hills Parties, none of the Blue Hills Parties or the employees of the
Blue Hills Parties has made any payment of funds as a loan for the purchase of the Shares or made
any other payment of funds prohibited by law, and no funds have been set aside to be used for any
payment prohibited by law.

(kk) None of the Blue Hills Parties has: (i) issued any securities within the last 18 months (except
for notes to evidence bank loans and reverse repurchase agreements or other liabilities in the
ordinary course of business or as described in the Prospectus); (ii) had any material dealings
within the 12 months prior to the date hereof with any member of the FINRA, or any person related to
or associated with such member, other than discussions and meetings relating to the proposed
Offering and routine purchases and sales of United States government and agency and other securities
in the ordinary course of business; (iii) entered into a financial or management consulting
agreement except as contemplated hereunder; and (iv) engaged any intermediary between the Agent and
the Holding Company or the Bank in connection with the offering of the Shares, and no person is
being compensated in any manner for such service.

(ll) The Blue Hills Parties have not relied upon the Agent or its legal counsel for any legal, tax
or accounting advice in connection with the Conversion.

(mm) The records used by the Blue Hills Parties to determine the identities of Eligible Account
Holders and employees, officers, directors, trustees and corporators of the Bank, the Mid-Tier and
the MHC are accurate and complete in all material respects.

(nn) None of the Blue Hills Parties is or intends to conduct business in a manner which would cause
it to become an "investment company," an entity "controlled" by an "investment company" or an
"investment adviser" within the meaning of the Investment Company Act of 1940, as amended, or the
Investment Advisers Act of 1940, as amended.

14
<!-- page 15 -->
(oo) None of the Blue Hills Parties or any properties owned or operated by any of the Blue Hills
Parties, is in violation of or liable under any Environmental Law (as defined below), except for
such violations or liabilities that, individually or in the aggregate, would not have a Material
Adverse Effect. There are no actions, suits or proceedings, or demands, claims, notices or
investigations (including, without limitation, notices, demand letters or requests for information
from any environmental agency) instituted or pending or, to the knowledge of the Blue Hills Parties,
threatened relating to the liability of any property owned or operated by the Blue Hills Parties
under any Environmental Law. To the knowledge of the Blue Hills Parties, there are no events or
circumstances that could form the basis of an order for clean-up or remediation, or an action, suit
or proceeding by any private party or governmental body or agency, against or affecting the Blue
Hills Parties relating to any Environmental Law. For purposes of this subsection, the term
"Environmental Law" means any federal, state, local or foreign law, statute, ordinance, rule,
regulation, code, license, permit, authorization, approval, consent, order, judgment, decree,
injunction or agreement with any regulatory authority relating to (i) the protection, preservation
or restoration of the environment (including, without limitation, air, water, vapor, surface water,
groundwater, drinking water supply, surface soil, subsurface soil, plant and animal life or any
other natural resource), and/or (ii) the use, storage, recycling, treatment, generation,
transportation, processing, handling, labeling, production, release or disposal of any substance
presently listed, defined, designated or classified as hazardous, toxic, radioactive or dangerous,
or otherwise regulated, whether by type or by quantity, including any material containing any such
substance as a component.

(pp) The Blue Hills Parties maintain a system of internal accounting controls sufficient to provide
reasonable assurance that (A) transactions are executed in accordance with management's general or
specific authorizations, (B) transactions are recorded as necessary to permit preparation of
financial statements in conformity with generally accepted accounting principles and to maintain
accountability for assets, (C) access to assets is permitted only in accordance with management's
general or specific authorization, and (D) the recorded accounts or assets are compared with the
existing assets at reasonable intervals and appropriate action is taken with respect to any
difference. The books, records and accounts and systems of internal accounting control of the Blue
Hills Parties and its subsidiaries comply in all material respects with the requirements of Section
13(b)(2) of the Securities Exchange Act of 1934, as amended (the "1934 Act"). The Blue Hills Parties
have established and maintain "disclosure controls and procedures" (as defined in Rule 13a­15(e)
under the 1934 Act) that are effective in ensuring that the information the Holding Company will be
required to disclose in the reports it files or submits under the 1934 Act is accumulated and
communicated to the Holding Company's management (including its chief executive officer and chief
financial officer) in a timely manner and recorded, processed, summarized and reported within the
periods specified in the Commission's rules and forms. To the knowledge of the Blue Hills Parties,
Wolf & Co., P.C. and the Audit Committee of the Board of Directors have been advised of: (A) any
significant deficiency or material weakness in the design or operation of internal control over
financial reporting which could adversely affect the Blue Hills Parties' ability to record, process,
summarize, and report financial data; and (B) any fraud, whether or not material, that involves
management or other employees who have a significant role in the Blue Hills Parties' internal
accounting controls.

(qq) All of the loans represented as assets of the Bank in the Prospectus meet or are exempt from
all requirements of federal, state and local law pertaining to lending, including, without
limitation, truth in lending (including the requirements of Regulation Z and 12 C.F.R. Part 226),
real estate settlement procedures, consumer credit protection, equal credit opportunity and all
disclosure laws applicable to such loans, except for violations which, if asserted, would not have a
Material Adverse Effect.

15
<!-- page 16 -->
(rr) To the knowledge of the Blue Hills Parties, there are not and have not been any affiliations or
associations (as such terms are defined by the FINRA) between any member of the FINRA and any of the
Blue Hills Parties' officers, directors or 5% or greater security holders, except as set forth in
the Registration Statement, filings with FINRA or the Prospectus.

(ss) The Holding Company has taken all actions necessary to obtain at the Closing Date a blue sky
memorandum from Luse Gorman.

(tt) Any certificates signed by an officer of any of the Blue Hills Parties pursuant to the
conditions of this Agreement and delivered to the Agent or their counsel that refers to this
Agreement shall be deemed to be a representation and warranty by such Blue Hills Party to the Agent
as to the matters covered thereby with the same effect as if such representation and warranty were
set forth herein.

(uu) The statistical and market related data contained in any Permitted Free Writing Prospectus, the
Prospectus and the Registration Statement are based on or derived from sources which the Blue Hills
Parties believe were reliable and accurate at the time they were filed with the Commission. No
forward-looking statement (within the meaning of Section 27A of the 1933 Act and Section 21E of the
1934 Act) contained in the Registration Statement, the Prospectus, or any Permitted Free Writing
Prospectus has been made or reaffirmed without a reasonable basis or has been disclosed other than
in good faith.

(vv) At or prior to the Closing, the Holding Company will have filed a Form 8-A with the Commission
registering the Shares under Section 12(b) of the Exchange Act.

Section 5. Representations and Warranties of the Agent. The Agent represents and warrants to the
Blue Hills Parties as follows:

(a) The Agent is a corporation and is validly existing in good standing under the laws of the State
of New York with full power and authority to provide the services to be furnished to the Blue Hills
Parties hereunder.

(b) The execution and delivery of this Agreement and the consummation of the transactions
contemplated hereby have been duly and validly authorized by all necessary action on the part of the
Agent, and this Agreement has been duly and validly executed and delivered by the Agent and is a
legal, valid and binding agreement of the Agent, enforceable in accordance with its terms, except as
the legality, validity, binding nature and enforceability thereof may be limited by (i) bankruptcy,
insolvency, moratorium, reorganization, conservatorship, receivership or other similar laws relating
to or affecting the enforcement of creditors' rights generally, and (ii) general equity principles
regardless of whether such enforceability is considered in a proceeding in equity or at law.

(c) Each of the Agent and its employees, agents and representatives who shall perform any of the
services hereunder shall be duly authorized and empowered, and shall have all licenses, approvals
and permits necessary to perform such services; and the Agent is a registered selling agent in each
of the jurisdictions in which the Shares are to be offered by the Holding Company in reliance upon
the Agent as a registered selling agent as set forth in the blue sky memorandum prepared with
respect to the Offering.

(d) The execution and delivery of this Agreement by the Agent, the consummation of the transactions
contemplated hereby and compliance with the terms and provisions hereof will not conflict with, or
result in a breach of, any of the terms, provisions or conditions of, or constitute a default (or an
event which with notice or lapse of time or both would constitute a default) under, the articles of
incorporation or bylaws of the Agent or any material agreement, indenture or other instrument to
which the Agent is a party or by which it or its property is bound.

16
<!-- page 17 -->
(e) No approval of any regulatory or supervisory or other public authority is required in connection
with the Agent's execution and delivery of this Agreement, except as may have been received.

(f) There is no suit or proceeding or charge or action before or by any court, regulatory authority
or government agency or body or, to the knowledge of the Agent, pending or threatened, which might
materially adversely affect the Agent's performance under this Agreement.

Section 6. Covenants of the Blue Hills Parties. The Blue Hills Parties hereby jointly and severally
covenant and agree with the Agent as follows:

(a) The Holding Company will not, at any time prior to or after the date the Registration Statement
is declared effective, file any amendment or supplement to the Registration Statement without
providing the Agent and its counsel an opportunity to review such amendment or supplement or file
any amendment or supplement to which amendment or supplement the Agent and its counsel shall
reasonably object.

(b) If at any time following issuance of an Issuer-Represented Free Writing Prospectus there
occurred or occurs an event or development as a result of which such Issuer Represented Free Writing
Prospectus conflicted or would conflict with the information contained in the Registration Statement
or included or would include an untrue statement of a material fact or omitted or would omit to
state a material fact necessary in order to make the statements therein, in light of the
circumstances prevailing at the subsequent time, not misleading, the Holding Company has notified or
will notify promptly the Agent so that any use of such Issuer-Represented Free Writing Prospectus
may cease until it is amended or supplemented and the Holding Company has promptly amended or will
promptly amend or supplement such Issuer-Represented Free Writing Prospectus to eliminate or correct
such conflict, untrue statement or omission; provided, however, that this covenant shall not apply
to any statement or omission made in reliance upon and in conformity with information furnished in
writing to the Holding Company by the Agent expressly for use therein.

(c) Each of the Blue Hills Parties represents and agrees that, unless it obtains the prior consent
of the Agent, and the Agent represents and agrees that, unless it obtains the prior consent of the
Blue Hills Parties, it has not made and will not make any offer relating to the offered Shares that
would constitute an "issuer free writing prospectus" as defined in Rule 433 of the 1933 Act
Regulations, or that would constitute a "free writing prospectus," as defined in Rule 405 of the
1933 Act Regulations, required to be filed with the Commission. The Holding Company represents that
it has treated or agrees that it will treat each Permitted Free Writing Prospectus as an "issuer
free writing prospectus," as defined in Rule 433 of the 1933 Act Regulations, and has complied and
will comply in all material respects with the requirements of Rule 433 of the 1933 Act Regulations
applicable to any Permitted Free Writing Prospectus, including timely Commission filing where
required, legending and record keeping. The Blue Hills Parties need not treat any communication as a
free writing prospectus if it is exempt from the definition of prospectus pursuant to clause (a) of
Section 2(a)(10) of the 1933 Act without regard to Rule 172 or 173 of the 1933 Act Regulations.

(d) The Holding Company will not, at any time prior to or after the Holding Company Application is
approved by the FRB and any other applicable regulator, file any amendment or supplement to such
Holding Company Application without providing the Agent and its counsel an opportunity to review
such amendment or supplement or file any amendment or supplement to which amendment or supplement
the Agent and its counsel shall reasonably object.

17
<!-- page 18 -->
(e) The Blue Hills Parties will not, at any time prior to or after the Massachusetts Conversion
Application is approved by the Division, file any amendment or supplement to such Massachusetts
Conversion Application without providing the Agent and its counsel an opportunity to review such
amendment or supplement or file any amendment or supplement to which amendment or supplement the
Agent and its counsel shall reasonably object.

(f) The Blue Hills Parties will use their best efforts to cause any post-effective amendment to the
Registration Statement to be declared effective by the Commission and any post-approval amendment to
the Applications to be approved by the FRB, the Division or any other applicable regulator and will
immediately upon receipt of any information concerning the events listed below notify the Agent: (i)
when the Registration Statement, as amended, has become effective; (ii) when the Applications, as
amended, have been approved by the FRB or the Division; (iii) of any comments from the Commission,
the FRB, the Division or any other governmental entity with respect to the Conversion contemplated
by this Agreement; (iv) of the request by the Commission, the FRB, the Division or any other
governmental entity for any amendment or supplement to the Registration Statement, the Applications
or for additional information; (v) of the issuance by the Commission, the FRB, the Division or any
other governmental entity of any order or other action suspending the Conversion or the use of the
Registration Statement or the Prospectus or any other filing of the Holding Company or the Bank
under the BHCA, the Massachusetts Regulations or other applicable law, or the threat of any such
action; (vi) of the issuance by the Commission, the FRB, the Division or any authority of any stop
order suspending the effectiveness of the Registration Statement or of the initiation or threat of
initiation or threat of any proceedings for that purpose; or (vii) of the occurrence of any event
mentioned in paragraph (j) below. The Blue Hills Parties will make every reasonable effort (i) to
prevent the issuance by the Commission, the FRB, the Division or any other federal or state
authority of any such order and, (ii) if any such order shall at any time be issued, to obtain the
lifting thereof at the earliest possible time.

(g) The Blue Hills Parties will deliver to the Agent and to its counsel as many conformed copies of
the Registration Statement or the Applications, as originally filed and of each amendment or
supplement thereto, including all exhibits, as the Agent may reasonably request.

(h) The Blue Hills Parties will furnish to the Agent, from time to time during the period when the
Prospectus (or any later prospectus related to this offering) is required to be delivered under the
1933 Act or the 1934 Act, such number of copies of such Prospectus (as amended or supplemented) as
the Agent may reasonably request for the purposes contemplated by the 1933 Act, the 1933 Act
Regulations, the 1934 Act or the rules and regulations promulgated under the 1934 Act (the "1934 Act
Regulations"). The Holding Company authorizes the Agent to use the Prospectus (as amended or
supplemented, if amended or supplemented) in any lawful manner contemplated by the Plan in
connection with the sale of the Shares by the Agent.

(i) The Blue Hills Parties will comply with any and all terms, conditions, requirements and
provisions with respect to the Offering imposed by the Commission, the Division or any other
applicable regulator or the Massachusetts Regulations and by the 1933 Act, the 1933 Act Regulations,
the 1934 Act and the 1934 Act Regulations to be complied with prior to or subsequent to the Closing
Date and when the Prospectus is required to be delivered, and during such time period the Blue Hills
Parties will comply, at their own expense, with all requirements imposed upon them by the
Commission, the Division or any other applicable regulator or the Massachusetts Regulations, and by
the 1933 Act, the 1933 Act Regulations, the 1934 Act and the 1934 Act Regulations, including,
without limitation, Rule 10b-5 under the 1934 Act, in each case as from time to time in force, so
far as necessary

18
<!-- page 19 -->
to permit the continuance of sales or dealing in the Shares during such period in accordance with
the provisions hereof and the Prospectus. The Holding Company will comply with all undertakings
contained in the Registration Statement.

(j) If, at any time during the period when the Prospectus is required to be delivered, any event
relating to or affecting any of the Blue Hills Parties shall occur, as a result of which it is
necessary or appropriate, in the opinion of counsel for the Holding Company and in the reasonable
opinion of the Agent's counsel, to amend or supplement the Registration Statement or Prospectus in
order to make the Registration Statement or Prospectus not misleading in light of the circumstances
existing at the time the Prospectus is delivered to a purchaser, the Holding Company will
immediately so inform the Agent and prepare and file, at its own expense, with the Commission, the
FRB and the Division or any other applicable regulator, and furnish to the Agent a reasonable number
of copies, of an amendment or amendments of, or a supplement or supplements to, the Registration
Statement or Prospectus (in form and substance reasonably satisfactory to the Agent and its counsel
after a reasonable time for review) which will amend or supplement the Registration Statement or
Prospectus so that as amended or supplemented it will not contain an untrue statement of a material
fact or omit to state a material fact necessary in order to make the statements therein, in light of
the circumstances existing at the time the Prospectus is delivered to a purchaser, not misleading.
For the purpose of this Agreement, the Holding Company will timely furnish to the Agent such
information with respect to the Blue Hills Parties as the Agent may from time to time reasonably
request.

(k) The Blue Hills Parties will take all necessary actions in cooperating with the Agent and furnish
to whomever the Agent may direct such information as may be required to qualify or register the
Shares for offering and sale by the Holding Company or to exempt such Shares from registration, or
to exempt the Holding Company as a broker-dealer and its officers, directors and employees as
broker-dealers or agents under the applicable securities or blue sky laws of such jurisdictions in
which the Shares are required under the Massachusetts Regulations to be sold or as the Agent and the
Holding Company may reasonably agree upon; provided, however, that the Holding Company shall not be
obligated to file any general consent to service of process, to qualify to do business in any
jurisdiction in which it is not so qualified, or to register its directors or officers as brokers,
dealers, salesmen or agents in any jurisdiction. In each jurisdiction where any of the Shares shall
have been qualified or registered as above provided, the Holding Company will make and file such
statements and reports in each fiscal period as are or may be required by the laws of such
jurisdiction.

(l) The liquidation account for the benefit of Eligible Account Holders will be duly established and
maintained in accordance with the requirements of the Plan, the Massachusetts Regulations, and such
Eligible Account Holders who continue to maintain their savings accounts in the Bank will have an
inchoate interest in their pro rata portion of the liquidation account, which shall have a priority
superior to that of the holders of the Common Stock in the event of a complete liquidation of the
Bank.

(m) The Holding Company will not sell or issue, contract to sell or otherwise dispose of, for a
period of 90 days after the Closing Date, without the Agent's prior written consent, any of its
shares of common stock, other than the Shares or other than in connection with any plan or
arrangement described in the Prospectus.

(n) The Holding Company will register its common stock under Section 12(b) of the 1934 Act. The
Holding Company shall maintain the effectiveness of such registration for not less than three years
from the time of effectiveness or such shorter period as may be required by the Division or any
other applicable regulator.

19
<!-- page 20 -->
(o) During the period during which the Shares are registered under the 1934 Act or for three years
from the date hereof, whichever period is greater, the Holding Company will furnish to its
shareholders as soon as practicable after the end of each fiscal year an annual report of the
Holding Company (including a consolidated balance sheet and statements of consolidated income,
shareholders' equity and cash flows of the Holding Company and its subsidiaries as at the end of and
for such year, certified by independent registered public accountants in accordance with Regulation
S-X under the 1933 Act and the 1934 Act) and make available as soon as practicable after the end of
each of the first three quarters of each fiscal year (beginning with the first fiscal quarter ending
after the effective time of the Registration Statement) financial information of the Holding Company
and its subsidiaries for such quarter in reasonable detail.

(p) During the period of three years from the date hereof, the Holding Company will furnish to the
Agent: (i) as soon as practicable after such information is publicly available, a copy of each
report of the Holding Company furnished to or filed with the Commission under the 1934 Act or any
national securities exchange or system on which any class of securities of the Holding Company is
listed or quoted (including, but not limited to, reports on Forms 10-K, 10-Q and 8-K and all proxy
statements and annual reports to stockholders), provided that the filing of such documents through
the Commission's EDGAR system shall be deemed to satisfy this obligation; (ii) a copy of each other
non­confidential report of the Holding Company mailed to its shareholders or filed with the
Commission, the FRB, the Division or any other supervisory or regulatory authority or any national
securities exchange or system on which any class of securities of the Holding Company is listed or
quoted, each press release and material news items and additional documents and information with
respect to the Holding Company or the Bank as the Agent may reasonably request; and (iii) from time
to time, such other nonconfidential information concerning the Holding Company or the Bank as the
Agent may reasonably request.

(q) The Holding Company and the Bank will use the net proceeds from the sale of the Shares in the
manner set forth in the Prospectus under the caption "How We Intend to Use the Proceeds From the
Offering."

(r) The Holding Company will make generally available to its security holders as soon as
practicable, but not later than 60 days after the close of the period covered thereby, an earnings
statement (in form complying with the provisions of Rule 158 of the 1933 Act Regulations) covering a
twelve­month period beginning not later than the first day of the Holding Company's fiscal quarter
next following the effective date (as defined in such Rule 158) of the Registration Statement.

(s) The Holding Company will use its best efforts to cooperate with the Agent to affect the trading
of the Shares on the Nasdaq Global Market on or prior to the Closing Date.

(t) The Holding Company will maintain appropriate arrangements for depositing all funds received
from persons mailing or delivering subscriptions for or orders to purchase Shares in the Offering
with the Bank, on an interest-bearing basis at the rate described in the Prospectus until the
Closing Date and satisfaction of all conditions precedent to the release of Shares in the Offering
in accordance with the Plan and as described in the Prospectus or until refunds of such funds have
been made to the persons entitled thereto or withdrawal authorizations canceled in accordance with
the Plan and as described in the Prospectus. The Holding Company will maintain such records of all
funds received to permit the funds of each subscriber to be separately insured by the FDIC (to the
maximum extent allowable) and to enable the Holding Company to make the appropriate refunds of such
funds in the event that such refunds are required to be made in accordance with the Plan and as
described in the Prospectus.

20
<!-- page 21 -->
(u) The Holding Company will report the use of proceeds of the Offering on its first periodic report
filed pursuant to Sections 13(a) and 15(d) of the 1934 Act and on any subsequent periodic report as
may be required pursuant to Rule 463 of the 1933 Act Regulations.

(v) The Holding Company will promptly take all necessary action to register as a bank holding
company under Section 3 of the BHCA.

(w) The Holding Company and the Bank will take such actions and furnish such information as are
reasonably requested by the Agent in order for the Agent to ensure compliance with FINRA Rule 5130.

(x) None of the Blue Hills Parties will amend the Plan without the consent of the Agent, which
consent shall not be unreasonably withheld.

(y) The Holding Company shall assist the Agent, if necessary, in connection with the allocation of
the Shares in the event of an oversubscription and shall provide the Agent with any information
necessary to assist the Holding Company in allocating the Shares in such event and such information
shall be accurate and reliable in all material respects.

(z) Prior to the Closing Date, the Holding Company will inform the Agent of any event or
circumstances of which it is aware as a result of which the Registration Statement and/or
Prospectus, as then amended or supplemented, would contain an untrue statement of a material fact or
omit to state a material fact necessary in order to make the statements therein not misleading.

(aa) The Holding Company will not deliver the Shares until the Blue Hills Parties have satisfied or
caused to be satisfied each condition set forth in Section 8 hereof, unless such condition is waived
in writing by the Agent.

(bb) Subsequent to the date the Registration Statement is declared effective by the Commission and
prior to the Closing Date, except as otherwise may be indicated or contemplated therein or set forth
in an amendment or supplement thereto, none of the Blue Hills Parties will have: (i) issued any
securities or incurred any liability or obligation, direct or contingent, for borrowed money, except
borrowings from the same or similar sources indicated in the Prospectus in the ordinary course of
its business, or (ii) entered into any transaction which is material in light of the business and
properties of the Blue Hills Parties, taken as a whole.

(cc) Until the Closing Date, the Blue Hills Parties will conduct their businesses in compliance in
all material respects with all applicable federal and state laws, rules, regulations, decisions,
directives and orders, including all decisions, directives and orders of the Commission, the FDIC,
the FRB and the Division.

(dd) The facts and representations provided to Luse Gorman and Nutter, McClennen & Fish, LLP
("Nutter") by the Blue Hills Parties and upon which each of Luse Gorman and Nutter will base their
opinions under Sections 8(c) and (d), respectively, are and will be truthful, accurate and complete.

(ee) The Blue Hills Parties will not distribute any offering material in connection with the
Offering except for the Prospectus and any supplemental sales material that has been filed with the
Registration Statement and the Applications and authorized for use by the Commission, the FRB and
the Division or any other applicable regulator. The information contained in any supplemental sales
material (in addition to the supplemental sales material filed as an exhibit to the Registration
Statement and the Applications) shall not conflict with the information contained in the
Registration Statement and the Prospectus.

21
<!-- page 22 -->
(ff) The Holding Company will comply with all applicable provisions of the Sarbanes-Oxley Act of
2002 and the Dodd-Frank Wall Street Reform and Consumer Protection Act and all applicable rules,
regulations, guidelines and interpretations promulgated thereunder by the Commission.

(gg) The Blue Hills Parties will not, prior to the Closing Time, incur any liability or obligation,
direct or contingent, or enter into any material transaction, other than in the ordinary course of
business consistent with past practice, except as contemplated by the Prospectus.

(hh) The Blue Hills Parties will use all reasonable efforts to comply with, or cause to be complied
with, the conditions precedent to the several obligations of the Agent specified in Section 8.

Section 7. Payment of Expenses. Whether or not the Conversion is completed or the sale of the Shares
by the Holding Company is consummated, the Blue Hills Parties jointly and severally agree to pay or
reimburse the Agent for: (a) all filing fees in connection with all filings related to the
Conversion with the FINRA; (b) any stock issue or transfer taxes which may be payable with respect
to the sale of the Shares; (c) subject to Section 2(f), all expenses of the Conversion, including
but not limited to the Agent's attorneys' fees and expenses, blue sky fees, transfer agent,
registrar and other agent charges, fees relating to auditing and accounting or other advisors and
costs of printing all documents necessary in connection with the Offering. In the event the Holding
Company is unable to sell the minimum number of shares necessary to complete the Conversion or the
Conversion is terminated or otherwise abandoned, the Blue Hills Parties shall promptly reimburse the
Agent in accordance with Section 2(f) hereof.

Section 8. Conditions to the Agent's Obligations. The obligations of the Agent hereunder, as to the
Shares to be delivered at the Closing Date, are subject, to the extent not waived in writing by the
Agent, to the condition that all representations and warranties of the Blue Hills Parties herein
are, at and as of the commencement of the Offering and at and as of the Closing Date, true and
correct in all material respects, the condition that the Blue Hills Parties shall have performed all
of its obligations hereunder to be performed on or before such dates, and to the following further
conditions:

(a) At the Closing Date, the Blue Hills Parties shall have conducted the Conversion in all material
respects in accordance with the Plan, the BHCA, the Massachusetts Regulations (except to the extent
waived or otherwise approved by the FRB, the Division and any other applicable regulator), and all
other applicable laws, regulations, decisions and orders, including all terms, conditions,
requirements and provisions precedent to the Conversion imposed upon them by the FRB, the Division
or any other applicable regulator.

(b) The Registration Statement shall have been declared effective by the Commission and the
Applications shall have been approved by the FRB and the Division not later than 5:30 p.m. on the
date of this Agreement, or with the Agent's consent at a later time and date; and at the Closing
Date, no stop order suspending the effectiveness of the Registration Statement shall have been
issued under the 1933 Act or proceedings therefore initiated or, to the knowledge of the Blue Hills
Parties, threatened by the Commission or any state authority, and no order or other action
suspending the authorization of the Prospectus or the consummation of the Conversion shall have been
issued or proceedings therefore initiated or, to the Blue Hills Parties' knowledge, threatened by
the Commission, the FRB, the Division, or any other regulatory authority.

22
<!-- page 23 -->
(c) At the Closing Date, the Agent shall have received the favorable opinion, dated as of the
Closing Date and addressed to the Agent and for its benefit, of Luse Gorman, special counsel for the
Blue Hills Parties, in form and substance as attached hereto as Exhibit C.

(d) At the Closing Date, the Agent shall have received the favorable opinion, dated as of the
Closing Date and addressed to the Agent and for its benefit, of Nutter, special counsel for the
Agent, in form and substance as attached hereto as Exhibit D.

(e) Prior to the mailing of the Prospectus, a blue sky memorandum from Luse Gorman relating to the
Offering, including Agent's participation therein, shall have been furnished to the Holding Company
with a copy thereof addressed to Agent or upon which Luse Gorman shall state the Agent may rely. The
blue sky memorandum will relate to the necessity of obtaining or confirming exemptions,
qualifications or the registration of the Shares under applicable state securities law.

(f) At the Closing Date, the Agent shall receive a certificate of the Chief Executive Officer and
the Chief Financial Officer of each of the Blue Hills Parties in form and substance reasonably
satisfactory to the Agent's Counsel, dated as of such Closing Date, to the effect that: (i) they
have carefully examined the Prospectus and, in their opinion, at the time the Prospectus became
authorized for final use, the Prospectus did not contain any untrue statement of a material fact or
omit to state a material fact necessary in order to make the statements therein, in light of the
circumstances under which they were made, not misleading; (ii) since the date the Prospectus became
authorized for final use, no event has occurred which should have been set forth in an amendment or
supplement to the Prospectus which has not been so set forth, including specifically, but without
limitation, any material adverse change in the condition, financial or otherwise, or in the
earnings, capital, properties or business of the Blue Hills Parties and the conditions set forth in
this Section 8 have been satisfied; (iii) since the respective dates as of which information is
given in the Registration Statement, the General Disclosure Package and the Prospectus, there has
been no material adverse change in the condition, financial or otherwise, or in the earnings,
capital, properties or business of the Blue Hills Parties independently, or of the Blue Hills
Parties considered as one enterprise, whether or not arising in the ordinary course of business;
(iv) the representations and warranties in Section 4 are true and correct with the same force and
effect as though expressly made at and as of the Closing Date; (v) the Blue Hills Parties complied
in all material respects with all agreements and satisfied all conditions on their part to be
performed or satisfied at or prior to the Closing Date and will comply in all material respects with
all obligations to be satisfied by them after the Closing Date; (vi) no stop order suspending the
effectiveness of the Registration Statement has been initiated or, to the knowledge of the Blue
Hills Parties, threatened by the Commission or any state authority; (vii) no order suspending the
Conversion, the Offering or the use of the Prospectus has been issued and no proceedings for that
purpose are pending or, to the knowledge of the Blue Hills Parties, threatened by the FRB, the
Division, or any other regulatory authority; and (viii) to the best knowledge of the Blue Hills
Parties, no person has sought to obtain review of the final action of the FRB, the Division or any
other applicable regulator approving the Conversion.

(g) None of the Blue Hills Parties shall have sustained, since the date of the latest financial
statements included in the Registration Statement, the General Disclosure Package and Prospectus,
any material loss or interference with its business from fire, explosion, flood or other calamity,
whether or not covered by insurance, or from any labor dispute or court or governmental action,
order or decree, otherwise than as set forth in the Registration Statement and the Prospectus, and
since the respective dates as of which information is given in the Registration Statement and the
Prospectus, there shall not have been any Material Adverse Effect that is in the Agent's reasonable
judgment sufficiently material and adverse as to make it impracticable or inadvisable to proceed
with the Offering or the delivery of the Shares on the terms and in the manner contemplated in the
Prospectus.

23
<!-- page 24 -->
(h) Prior to and at the Closing Date: (i) in the reasonable opinion of the Agent, there shall have
been no material adverse change in the financial condition, results of operations or business of the
Blue Hills Parties considered as one enterprise, from that as of the latest dates as of which such
condition is set forth in the Prospectus, other than transactions referred to or contemplated
therein; (ii) none of the Blue Hills Parties shall have received from the FRB, the Division or the
FDIC any direction (oral or written) to make any material change in the method of conducting their
business with which it has not complied (which direction, if any, shall have been disclosed to the
Agent) or which materially and adversely would affect the financial condition, results of operations
or business of the Blue Hills Parties taken as a whole; (iii) none of the Blue Hills Parties shall
have been in default (nor shall an event have occurred which, with notice or lapse of time or both,
would constitute a default) under any provision of any agreement or instrument relating to any
outstanding indebtedness; (iv) no action, suit or proceeding, at law or in equity or before or by
any federal or state commission, board or other administrative agency, not disclosed in the
Prospectus, shall be pending or, to the knowledge of the Blue Hills Parties, threatened against the
any of the Blue Hills Parties or affecting any of their properties wherein an unfavorable decision,
ruling or finding would materially and adversely affect the financial condition, results of
operations or business of the Blue Hills Parties taken as a whole; and (v) the Shares shall have
been qualified or registered for offering and sale or exempted therefrom under the securities or
blue sky laws of the jurisdictions as the Agent shall have reasonably requested and as agreed to by
the Blue Hills Parties.

(i) Concurrently with the execution of this Agreement, the Agent shall receive a letter from Wolf &
Co., P.C., dated as of the date hereof and addressed to the Agent: (i) confirming that Wolf & Co.,
P.C. is a firm of independent registered public accountants within the applicable rules of the
Public Company Accounting Oversight Board (United States) and stating in effect that in its opinion
the consolidated financial statements and related notes of the MHC as of December 31, 2013 and 2012,
and covered by their opinion included in the Prospectus, and any other more recent unaudited
financial statements included in the Prospectus, comply as to form in all material respects with the
applicable accounting requirements and related published rules and regulations of the FRB and any
other applicable regulator and the 1933 Act; (ii) stating in effect that, on the basis of certain
agreed upon procedures (but not an audit in accordance with standards of the Public Company
Accounting Oversight Board (United States)) consisting of a reading of the latest available
consolidated financial statements of the MHC prepared by the MHC, a reading of the minutes of the
meetings of the Boards of Directors of each of the Blue Hills Parties and consultations with
officers of the MHC responsible for financial and accounting matters, nothing came to their
attention which caused them to believe that: (A) the audited consolidated financial statements and
any unaudited interim financial statements included in the Prospectus are not in conformity with the
1933 Act, applicable accounting requirements of the FRB, the Division and the FDIC and GAAP applied
on a basis substantially consistent with that of the audited consolidated financial statements
included in the Prospectus; or (B) during the period from the date of the latest consolidated
financial statements included in the Prospectus to a specified date not more than three business
days prior to the date of the Prospectus, except as has been described in the Prospectus, there was
any increase in long-term debt of the MHC, other than normal deposit fluctuations for the Bank; or
(C) there was any decrease in the total consolidated assets, total loans, the allowance for loan
losses, total deposits or total equity of the MHC at the date of such letter as compared with
amounts shown in the latest balance sheet included in the Prospectus, except as has been described
in the Prospectus; and (iii) stating that, in addition to the audit referred to in their opinion
included in the Prospectus and the performance of the procedures referred to in clause (ii) of this
subsection (i), they have compared with the general accounting records of the MHC, which are subject
to the internal controls of the MHC, the accounting system and other data prepared by the MHC,
directly from such accounting records, to the extent specified in such letter, such amounts and/or
percentages set forth in the Prospectus as the Agent may reasonably request; and they have found
such amounts and percentages to be in agreement therewith (subject to rounding).

24
<!-- page 25 -->
(j) At the Closing Date, the Agent shall receive a letter dated the Closing Date, addressed to the
Agent, confirming the statements made by Wolf & Co., P.C. in the letter delivered by it pursuant to
subsection (i) of this Section 8, the "specified date" referred to in clause (ii) of subsection (i)
to be a date specified in the letter required by this subsection (j) which for purposes of such
letter shall not be more than three business days prior to the Closing Date.

(k) At the Closing Date, the Holding Company shall receive a letter from RP Financial LC., dated the
Closing Date (i) confirming that said firm is independent of the Blue Hills Parties and is
experienced and expert in the area of corporate appraisals within the meaning of the Massachusetts
Conversion Regulations, (ii) stating in effect that the Appraisal prepared by such firm complies in
all material respects with 209 CMR 33.08(3)(a), and (iii) further stating that its opinion of the
aggregate pro forma market value of the Holding Company including the Bank, as most recently
updated, remains in effect.

(l) At or prior to the Closing Date, the Agent shall receive: (i) a copy of the letter from the FRB
approving the Holding Company Application; (ii) a copy of a letter from the Division approving the
Massachusetts Conversion Application; (iii) confirmation that the Commission declared the
Registration Statement effective; (iv) certificates from the Secretary of State of the Commonwealth
of Massachusetts evidencing the valid existence and good standing of the MHC and the Mid-Tier; (v) a
certificate from the Division evidencing the good standing of the Bank; (vi) a certificate from the
FDIC evidencing the Bank's insurance of accounts; (vii) a certificate from the FHLBB evidencing the
Bank's membership therein; (viii) a certificate from the Maryland Department of Assessments &
Taxation evidencing the good standing of the Holding Company and (ix) such other documents and
certificates as the Agent may reasonably request.

(m) Subsequent to the date hereof, there shall not have occurred any of the following; (i) a
suspension or limitation in trading in securities generally on the New York Stock Exchange (the
"NYSE") or in the over­the­counter market, or quotations halted generally on the Nasdaq Stock
Market, or minimum or maximum prices for trading have been fixed, or maximum ranges for prices for
securities have been required by either of such exchanges or the Nasdaq Stock Market or by order of
the Commission or any other governmental authority; (ii) a general moratorium on the operations of
federal or state chartered depository institutions or a general moratorium on the withdrawal of
deposits from federal or state chartered depository institutions declared by federal or state
authorities; (iii) the engagement by the United States in hostilities which have resulted in the
declaration, on or after the date hereof, of a national emergency or war or a material decline in
the price of equity or debt securities, if the effect of such declaration or decline, in the Agent's
reasonable judgment, makes it impracticable or inadvisable to proceed with the Offering or the
delivery of the Shares on the terms and in the manner contemplated in the Registration Statement and
the Prospectus.

(n) At or prior to the Closing Date, counsel to the Agent shall have been furnished with such
documents and opinions as they may reasonably require for the purpose of enabling them to pass upon
the sale of the Shares as herein contemplated and related proceedings or in order to evidence the
occurrence or completeness of any of the representations or warranties, or the fulfillment of any of
the conditions, herein contained; and all proceedings taken by the Blue Hills Parties in connection
with the sale of the Shares as herein contemplated shall be satisfactory in form and substance to
the Agent or its counsel.

(o) All such opinions, certificates, letters and documents will be in compliance with the provisions
hereof only if they are reasonably satisfactory in form and substance to the Agent or to counsel for
the Agent. Any certificate signed by an officer of any of the Blue Hills Parties and delivered to
the Agent or to counsel for the Agent shall be deemed a representation and warranty by such Blue
Hills Party to the Agent as to the statements made therein.

25
<!-- page 26 -->
Section 9. Indemnification.

(a) Each of the Blue Hills Parties jointly and severally agrees to indemnify and hold harmless the
Agent, its officers and directors, employees and agents, and each person, if any, who controls the
Agent within the meaning of Section 15 of the 1933 Act or Section 20(a) of the 1934 Act, against any
and all loss, liability, claim, damage or expense whatsoever (including, but not limited to,
settlement expenses), joint or several, that the Agent or any of them may suffer or to which the
Agent and any such persons may become subject under all applicable federal or state laws or
otherwise, and to promptly reimburse the Agent and any such persons upon written demand for any
reasonable expense (including all reasonable fees and disbursements of counsel) incurred by the
Agent or any of them in connection with investigating, preparing or defending any actions,
proceedings or claims (whether commenced or threatened) to the extent such losses, claims, damages,
liabilities or actions: (i) arise out of or are based upon any untrue statement or alleged untrue
statement of a material fact contained in the Registration Statement (or any amendment or supplement
thereto), the General Disclosure Package, any Issuer-Represented Limited-Use Free Writing
Prospectus, any Issuer-Represented General Free Writing Prospectus, preliminary or final Prospectus
(or any amendment or supplement thereto), the Applications (or any amendment or supplement thereto),
or any instrument or document executed by the Blue Hills Parties or based upon written information
supplied by the Holding Company filed in any state or jurisdiction to register or qualify any or all
of the Shares or to claim an exemption therefrom or provided to any state or jurisdiction to exempt
the Blue Hills Parties as a broker-dealer or its officers, directors and employees as broker-dealers
or agents, under the securities laws thereof (collectively, the "Blue Sky Application"), or any
document, advertisement, oral statement or communication ("Sales Information") prepared, made or
executed by or on behalf of the Blue Hills Parties with its consent and based upon written or oral
information furnished by or on behalf of the Blue Hills Parties, whether or not filed in any
jurisdiction, in order to qualify or register the Shares or to claim an exemption therefrom under
the securities laws thereof; (ii) arise out of or are based upon the omission or alleged omission to
state in any of the foregoing documents or information a material fact required to be stated therein
or necessary to make the statements therein, in light of the circumstances under which they were
made, not misleading; or (iii) arise from any theory of liability whatsoever relating to or arising
from or based upon the Registration Statement (or any amendment or supplement thereto), preliminary
or final Prospectus (or any amendment or supplement thereto), the General Disclosure Package, any
Issuer­Represented Limited­Use Free Writing Prospectus, any Issuer-Represented General Free Writing
Prospectus, the Applications (or any amendment or supplement thereto), any Blue Sky Application or
Sales Information or other documentation distributed in connection with the Conversion; provided,
however, that no indemnification is required under this paragraph (a) to the extent such losses,
claims, damages, liabilities or actions arise out of or are based upon any untrue material statement
or alleged untrue material statement in, or material omission or alleged material omission from, the
Registration Statement (or any amendment or supplement thereto), preliminary or final Prospectus (or
any amendment or supplement thereto), the General Disclosure Package, any Issuer-Represented
Limited-Use Free Writing Prospectus, any Issuer-Represented General Free Writing Prospectus, the
Applications, any Blue Sky Application or Sales Information made in reliance upon and in conformity
with information furnished in writing to the Holding Company, by the Agent or its counsel regarding
the Agent, and provided, that it is agreed and understood that the only information furnished in
writing to the Holding Company, by the Agent regarding the Agent is set forth in the Prospectus in
the first sentence of the second paragraph under the caption "The Conversion; Plan of
Distribution—Marketing and Distribution; Compensation"; and, provided further, that such
indemnification shall be limited to the extent prohibited by the Commission, the FDIC, the Division
and the FRB.

26
<!-- page 27 -->
(b) The Agent agrees to indemnify and hold harmless the Blue Hills Parties, their directors and
officers and each person, if any, who controls the Holding Company or the Bank within the meaning of
Section 15 of the 1933 Act or Section 20(a) of the 1934 Act against any and all loss, liability,
claim, damage or expense whatsoever (including but not limited to settlement expenses), joint or
several, which they, or any of them, may suffer or to which they, or any of them may become subject
under all applicable federal and state laws or otherwise, and to promptly reimburse the Blue Hills
Parties, and any such persons upon written demand for any expenses (including reasonable fees and
disbursements of counsel) incurred by them, or any of them, in connection with investigating,
preparing or defending any actions, proceedings or claims (whether commenced or threatened) to the
extent such losses, claims, damages, liabilities or actions: (i) arise out of or are based upon any
untrue statement or alleged untrue statement of a material fact contained in the Registration
Statement (or any amendment or supplement thereto), the Applications (or any amendment or supplement
thereto), the preliminary or final Prospectus (or any amendment or supplement thereto), any Blue Sky
Application or Sales Information, (ii) are based upon the omission or alleged omission to state in
any of the foregoing documents a material fact required to be stated therein or necessary to make
the statements therein, in the light of the circumstances under which they were made, not
misleading, or (iii) arise from any theory of liability whatsoever relating to or arising from or
based upon the Registration Statement (or any amendment or supplement thereto), preliminary or final
Prospectus (or any amendment or supplement thereto), the Applications (or any amendment or
supplement thereto), or any Blue Sky Application or Sales Information or other documentation
distributed in connection with the Offering; provided, however, that the Agent's obligations under
this Section 9(b) shall exist only if and only to the extent that such untrue statement or alleged
untrue statement was made in, or such material fact or alleged material fact was omitted from, the
Registration Statement (or any amendment or supplement thereto), the preliminary or final Prospectus
(or any amendment or supplement thereto), the Applications (or any amendment or supplement thereto),
any Blue Sky Application or Sales Information in reliance upon and in conformity with information
furnished in writing to the Holding Company or the Bank, by the Agent or its counsel regarding the
Agent, and provided, that it is agreed and understood that the only information furnished in writing
to the Holding Company or the Bank, by the Agent regarding the Agent is set forth in the Prospectus
in the first sentence of the second paragraph under the caption "The Conversion; Plan of
Distribution­Marketing and Distribution; Compensation."

(c) Each indemnified party shall give prompt written notice to each indemnifying party of any
action, proceeding, claim (whether commenced or threatened), or suit instituted against it in
respect of which indemnity may be sought hereunder, but failure to so notify an indemnifying party
shall not relieve it from any liability which it may have on account of this Section 9 or otherwise.
An indemnifying party may participate at its own expense in the defense of such action. In addition,
if it so elects within a reasonable time after receipt of such notice, an indemnifying party,
jointly with any other indemnifying parties receiving such notice, may assume defense of such action
with counsel chosen by it and approved by the indemnified parties that are defendants in such
action, unless such indemnified parties reasonably object to such assumption on the ground that
there may be legal defenses available to them that are different from or in addition to those
available to such indemnifying party. If an indemnifying party assumes the defense of such action,
the indemnifying parties shall not be liable for any fees and expenses of counsel for the
indemnified parties incurred thereafter in connection with such action, proceeding or claim, other
than reasonable costs of investigation. In no event shall the indemnifying parties be liable for the
fees and expenses of more than one separate firm of attorneys (and any local counsel that said firm
may retain) for each indemnified party in connection with any one action, proceeding or claim or
separate but similar or related actions, proceedings or claims in the same jurisdiction arising out
of the same general allegations or circumstances.

Section 10. Contribution. In order to provide for just and equitable contribution in circumstances
in which the indemnification provided for in Section 9 is due in accordance with its terms

27
<!-- page 28 -->
but is for any reason held by a court to be unavailable from the Blue Hills Parties or the Agent,
the Blue Hills Parties and the Agent shall contribute to the aggregate losses, claims, damages and
liabilities (including any investigation, legal and other expenses incurred in connection with, and
any amount paid in settlement of, any action, suit or proceeding, but after deducting any
contribution received by the Blue Hills Parties or the Agent from persons other than the other
parties thereto, who may also be liable for contribution) in such proportion so that the Agent is
responsible for that portion represented by the percentage that the fees paid to the Agent pursuant
to Section 2 of this Agreement (not including expenses) bears to the gross proceeds received by the
Holding Company from the sale of the Shares in the Offering, and the Blue Hills Parties shall be
responsible for the balance. If, however, the allocation provided above is not permitted by
applicable law, then each indemnifying party shall contribute to such amount paid or payable by such
indemnified party in such proportion as is appropriate to reflect not only such relative fault of
the Blue Hills Parties on the one hand and the Agent on the other in connection with the statements
or omissions which resulted in such losses, claims, damages or liabilities (or actions, proceedings
or claims in respect thereto), but also the relative benefits received by the Blue Hills Parties on
the one hand and the Agent on the other from the Offering (before deducting expenses). The relative
fault shall be determined by reference to, among other things, whether the untrue or alleged untrue
statement of a material fact or the omission or alleged omission to state a material fact relates to
information supplied by the Blue Hills Parties on the one hand or the Agent on the other and the
parties' relative intent, good faith, knowledge, access to information and opportunity to correct or
prevent such statement or omission. The Blue Hills Parties and the Agent agree that it would not be
just and equitable if contribution pursuant to this Section 10 were determined by pro-rata
allocation or by any other method of allocation which does not take into account the equitable
considerations referred to above in this Section 10. The amount paid or payable by an indemnified
party as a result of the losses, claims, damages or liabilities (or actions, proceedings or claims
in respect thereof) referred to above in this Section 10 shall be deemed to include any legal or
other expenses reasonably incurred by such indemnified party in connection with investigating or
defending any such action, proceeding or claim. It is expressly agreed that the Agent shall not be
liable for any loss, liability, claim, damage or expense or be required to contribute any amount
pursuant to Section 9(b) or this Section 10 which in the aggregate exceeds the amount paid
(excluding reimbursable expenses) to the Agent under this Agreement. It is understood that the above
stated limitation on the Agent's liability is essential to the Agent and that the Agent would not
have entered into this Agreement if such limitation had not been agreed to by the parties to this
Agreement. No person found guilty of any fraudulent misrepresentation (within the meaning of Section
11(f) of the 1933 Act) shall be entitled to contribution from any person who was not found guilty of
such fraudulent misrepresentation. The obligations of the Blue Hills Parties under this Section 10
and under Section 9 shall be in addition to any liability which the Holding Company and the Agent
may otherwise have. For purposes of this Section 10, each of the Agent's and the Blue Hills Parties'
officers and directors and each person, if any, who controls the Agent or any of the Blue Hills
Parties within the meaning of the 1933 Act and the 1934 Act shall have the same rights to
contribution as the Agent on the one hand, or, the Blue Hills Parties on the other hand. Any party
entitled to contribution, promptly after receipt of notice of commencement of any action, suit,
claim or proceeding against such party in respect of which a claim for contribution may be made
against another party under this Section 10, will notify such party from whom contribution may be
sought, but the omission to so notify such party shall not relieve the party from whom contribution
may be sought from any other obligation it may have hereunder or otherwise than under this Section
10 unless and to the extent the party has been materially prejudiced through the forfeiture by the
other party of substantial rights and defenses.

Section 11. Termination. The Agent may terminate this Agreement by giving the notice indicated below
in Section 12 at any time after this Agreement becomes effective as follows:

(a) If any domestic or international event or act or occurrence has materially disrupted the United
States securities markets such as to make it, in the Agent's reasonable opinion,

28
<!-- page 29 -->
impracticable to proceed with the offering of the Shares; or if trading on the NYSE shall have
suspended (except that this shall not apply to the imposition of NYSE trading collars imposed on
program trading); or if the United States shall have become involved in a war or major hostilities
or escalation thereof; or if a general banking moratorium has been declared by a state or federal
authority which has a material effect on the Blue Hills Parties on a consolidated basis; or if a
moratorium in foreign exchange trading by major international banks or persons has been declared; or
if there shall have been a material adverse change in the financial condition, results of operations
or business of any of the Blue Hills Parties, or if any of the Blue Hills Parties shall have
sustained a material or substantial loss by fire, flood, accident, hurricane, earthquake, theft,
sabotage or other calamity or malicious act, whether or not said loss shall have been insured; or,
if there shall have been a material adverse change in the financial condition, results of operations
or business of the Blue Hills Parties taken as a whole.

(b) In the event the Holding Company fails to sell the required minimum number of the Shares by the
date when such sales must be completed, in accordance with the provisions of the Plan or as required
by the Massachusetts Regulations and applicable law, this Agreement shall terminate upon refund by
the Holding Company to each person who has subscribed for or ordered any of the Shares the full
amount which it may have received from such person, together with interest as provided in the
Prospectus, and no party to this Agreement shall have any obligation to the other hereunder, except
as set forth in Sections 2(a), 2(e), 7, 9 and 10 hereof.

(c) If any of the conditions specified in Section 8 shall not have been fulfilled when and as
required by this Agreement, unless waived in writing, or by the Closing Date, this Agreement and all
of the Agent's obligations hereunder may be cancelled by the Agent by notifying the Holding Company
of such cancellation in writing or by electronic mail at any time at or prior to the Closing Date,
and any such cancellation shall be without liability of any party to any other party except as
otherwise provided in Sections 2(a), 2(e), 7, 9 and 10 hereof.

(d) If the Agent elects to terminate this Agreement as provided in this Section, the Blue Hills
Parties shall be notified promptly by telephone or electronic mail, confirmed by letter.

Any of the Blue Hills Parties may terminate this Agreement in the event the Agent is in material
breach of the representations and warranties or covenants contained in Sections 5 or 6(c) and such
breach has not been cured within a reasonable time period after the Blue Hills Party has provided
the Agent with notice of such breach.

This Agreement may also be terminated by mutual written consent of the parties hereto.

Section 12. Notices. All communications hereunder, except as herein otherwise specifically provided,
shall be mailed in writing and if sent to the Agent shall be mailed, delivered or telegraphed and
confirmed to Keefe, Bruyette & Woods, Inc., 10 South Wacker Drive, Investment Banking Suite 3400,
Chicago, Illinois 60606, Attention: Pat McJoynt (with a copy to Nutter, McClennen & Fish LLP,
Attention: Michael Krebs) and, if sent to the Blue Hills Parties, shall be mailed, delivered or
telegraphed and confirmed to the Bank at Blue Hills Bank, 320 Norwood Park South, Norwood, MA 02062,
Attention: William Parent (with a copy to Luse Gorman Pomerenk & Schick, P.C., Attention: Larry
Spaccasi).

Section 13. Parties. The Blue Hills Parties shall be entitled to act and rely on any request,
notice, consent, waiver or agreement purportedly given on behalf of the Agent when the same shall
have been given by the undersigned. The Agent shall be entitled to act and rely on any request,
notice, consent, waiver or agreement purportedly given on behalf of the Blue Hills Parties, when the
same shall have been given by the undersigned or any other officer of any of the Blue Hills Parties.
This Agreement

29
<!-- page 30 -->
shall inure solely to the benefit of, and shall be binding upon, the Agent, the Blue Hills Parties
and their respective successors and assigns, and no other person shall have or be construed to have
any legal or equitable right, remedy or claim under or in respect of or by virtue of this Agreement
or any provision herein contained.

Section 14. Closing. The closing for the sale of the Shares (the "Closing") shall take place on the
Closing Date at such location as mutually agreed upon by the Agent and the Holding Company and the
Bank. At the Closing, the Blue Hills Parties shall deliver to the Agent in next day funds the
commissions, fees and expenses due and owing to the Agent as set forth in Sections 2 and 7 hereof
and the opinions and certificates required hereby and other documents deemed reasonably necessary by
the Agent shall be executed and delivered to effect the sale of the Shares as contemplated hereby
and pursuant to the terms of the Prospectus.

Section 15. Partial Invalidity. In the event that any term, provision or covenant herein or the
application thereof to any circumstance or situation shall be invalid or unenforceable, in whole or
in part, the remainder hereof and the application of said term, provision or covenant to any other
circumstances or situation shall not be affected thereby, and each term, provision or covenant
herein shall be valid and enforceable to the full extent permitted by law.

Section 16. Governing Law and Construction. This Agreement shall be governed by and construed in
accordance with the laws of the State of New York without regard to principles of conflicts of law.

Section 17. Counterparts; Facsimile Delivery. This Agreement may be executed in separate
counterparts and by facsimile or electronic signatures, each of which so executed and delivered
shall be an original, but all of which together shall constitute but one and the same instrument.
The exchange of copies of this Agreement and of signature pages by facsimile transmission or in pdf
format shall constitute effective execution and delivery of this Agreement as to the parties and may
be used in lieu of the original Agreement for all purposes. Signatures of the parties transmitted by
facsimile or in pdf format shall be deemed to be their original signatures for all purposes.

Section 18. Entire Agreement. This Agreement, including schedules and exhibits hereto, which are
integral parts hereof and incorporated as though set forth in full, constitutes the entire agreement
between the parties pertaining to the subject matter hereof superseding any and all prior or
contemporaneous oral or prior written agreements, proposals, letters of intent and understandings,
and cannot be modified, changed, waived or terminated except by a writing which expressly states
that it is an amendment, modification or waiver, refers to this Agreement and is signed by the party
to be charged. No course of conduct or dealing shall be construed to modify, amend or otherwise
affect any of the provisions hereof.

Section 19. Survival. The respective indemnities, agreements, representations, warranties and other
statements of the Blue Hills Parties and the Agent, as set forth in this Agreement, shall remain in
full force and effect, regardless of any termination or cancellation of this Agreement or any
investigation (or any statement as to the results thereof) made by or on behalf of the Agent or any
of the Agent's officers or directors or any person controlling the Agent, or the Blue Hills Parties,
or any of their respective officers or directors or any person controlling the Blue Hills Parties,
and shall survive termination of this Agreement and receipt or delivery of any payment for the
Shares.

Section 20. Waiver of Trial by Jury. Each of the Agent and the Blue Hills Parties waives all right
to trial by jury in any action, proceeding, claim or counterclaim (whether based on contract, tort
or otherwise) related to or arising out of this Agreement.

30
<!-- page 31 -->
This agreement is made solely for the benefit of and will be binding upon the parties hereto and
their respective successors and the directors, officer and controlling persons and no other person
will have any right or obligation hereunder.

[Remainder of page intentionally blank]

31
<!-- page 32 -->
If the foregoing correctly sets forth the arrangement among the Blue Hills Parties and the Agent,
please indicate acceptance thereof in the space provided below for that purpose, whereupon this
letter and the Agent's acceptance shall constitute a binding agreement.

Very truly yours,

Blue Hills Bank Blue Hills Bancorp, Inc.

By Its Authorized Representative: By Its Authorized Representative:

/s/ William M. Parent /s/ William M. Parent William M. Parent William M. Parent President and Chief
Executive Officer President and Chief Executive Officer

Hyde Park Bancorp, MHC Hyde Park Bancorp, Inc.

By Its Authorized Representative: By Its Authorized Representative:

/s/ William M. Parent /s/ William M. Parent William M. Parent William M. Parent President and Chief
Executive Officer President and Chief Executive Officer

Accepted as of the date first above written

KEEFE, BRUYETTE & WOODS, INC.

By its Authorized Representative

/s/ Pat McJoynt Pat McJoynt Managing Director
