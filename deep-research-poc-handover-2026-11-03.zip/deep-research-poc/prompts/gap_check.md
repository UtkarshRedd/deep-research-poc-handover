Research on the question below was split into parts. Review what the parts established and list what
is still MISSING to answer the whole question: a part that was not covered, an item the question asks
for that no finding addresses, or a conflict between findings that must be resolved. Do not list
things already answered. Return at most {max_gaps} items, each as a narrow, self-contained question.
Return an empty list if nothing is missing.

Question: {question}

Findings so far:
{findings}

Reply with ONLY a JSON object, no prose, no code fence:
{{"gaps": ["narrow question 1", "narrow question 2"]}}
