<!-- page 1 -->
# CONSULTING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Consulting Agreement |
| Agreement Date | 2017-03-27 |
| Parties | Immunotolerance, Inc. ("Company"); Alan Crane ("Consultant") |
| Source | CUAD v1 / PANDIONTHERAPEUTICSHOLDCOLLC_05_22_2020-EX-10.17-CONSULTING AGREEMENT |

Exhibit 10.17

IMMUNOTOLERANCE, INC.

CONSULTING AGREEMENT

This Consulting Agreement (the "Agreement"), made this 27t h day of March, 2017 is entered into by
Immunotolerance, Inc., a Delaware corporation (the "Company"), and Alan Crane, an individual (the
"Consultant").

WHEREAS, the Company and the Consultant desire to establish the terms and conditions under which the
Consultant will provide services to the Company.

NOW, THEREFORE, in consideration of the mutual covenants and promises contained herein and other
good and valuable consideration, the receipt and sufficiency of which is hereby acknowledged by the
parties hereto, the parties agree as follows:

1. Services. The Consultant agrees to perform such consulting, advisory and related services to and
for the Company as may be reasonably requested from time to time by the Company, including, but not
limited to, the services specified on Schedule A to this Agreement. The Consultant also agrees to
provide the Company with related services that may be requested from time to time by the Company.
During the Consultation Period (as defined below) and for a period of one year thereafter, except in
connection with his performance of the Services, the Consultant shall not engage in any activity in
the field described on Schedule A to this Agreement, and he shall not assist any other person or
organization that engages in any such activity.

2. Term. This Agreement shall commence on the Effective Date and shall continue until the four-year
anniversary of the Effective Date (such period, as it may be extended, either by the mutual written
agreement of the parties or automatically, or earlier terminated being referred to as the
"Consultation Period"), unless sooner terminated in accordance with the provisions of Section 4, and
shall automatically renew for successive one-year periods, unless the Company provides 90 days'
notice of termination before any such successive period.

3. Compensation.

3.1 Shares. In connection with the execution of this Agreement, Consultant and Company shall enter
into a Restricted Stock Agreement. Subject to approval of the Board of Directors of the Company, the
Company shall issue and sell to the Consultant, and the Consultant shall purchase from the Company,
subject to the terms and conditions set forth in this Agreement and the Restricted Stock Agreement,
1,990,000 shares (the "Shares") of common stock, $0.0001 par value, of the Company ("Common Stock"),
at a purchase price of $0.0001 per share, for an aggregate purchase price of $190. Such Shares are
in addition to the 10,000 shares of Common Stock held by the Consultant as of the date hereof. The
Consultant agrees that the Shares shall be subject to the terms of the Restricted Stock Agreement.

3.2 Expenses. The Company shall reimburse the Consultant for all reasonable and necessary documented
out of pocket expenses incurred or paid by the Consultant in connection with, or related to, the
performance of Consultant's services under this Agreement.
<!-- page 2 -->
The Consultant shall submit to the Company itemized monthly statements, in a form satisfactory to
the Company, of such expenses incurred in the previous month. The Company shall pay to the
Consultant amounts shown on each such statement within thirty (30) days after receipt thereof.

3.3 Benefits. The Consultant shall not be entitled to any benefits, coverages or privileges,
including, without limitation, health insurance, social security, unemployment, medical or pension
payments, made available to employees of the Company.

4. Termination. The Company may terminate the Consultation Period at any time for Cause (as defined
below). In the event of such termination, the Consultant shall be entitled to payment hereunder and
for expenses paid or incurred prior to the effective date of termination. Such payments shall
constitute full settlement of any and all claims of the Consultant of every description against the
Company. Notwithstanding the foregoing, the Company may terminate the Consultation Period effective
immediately upon receipt of written notice by the Consultant, if the Consultant breaches or
threatens to breach any provision of Section 6. For purposes of this Section 4, "Cause" shall exist
in the event of (i) a good faith finding by the Board of Directors of the Company (A) of repeated
and willful failure of the Consultant after written notice to perform his reasonable Services for
the Company, or (B) that the Consultant has engaged in dishonesty, gross negligence or misconduct;
or (ii) the conviction of the Consultant of, or the entry of a pleading of guilty or nolo contendere
by the Consultant to, any crime involving moral turpitude or any felony. The Consultant may
terminate the Consultation Period at any time upon thirty (30) days' written notice.

5. Cooperation. The Consultant shall use Consultant's best efforts in the performance of
Consultant's obligations under this Agreement. The Company shall provide such access to its
information and property as may be reasonably required in order to permit the Consultant to perform
Consultant's obligations hereunder. The Consultant shall cooperate with the Company's personnel,
shall not interfere with the conduct of the Company's business and shall observe all rules,
regulations and security requirements of the Company concerning the safety of persons and property.

6. Proprietary Information and Inventions.

6.1 Proprietary Information.

(a) The Consultant acknowledges that Consultant's relationship with the Company is one of high trust
and confidence and that in the course of Consultant's service to the Company, Consultant will have
access to and contact with Proprietary Information. The Consultant will not disclose any Proprietary
Information to any person or entity other than employees of the Company or use the same for any
purposes (other than in the performance of the services) without written approval by an officer of
the Company, either during or after the Consultation Period, unless and until such Proprietary
Information has become public knowledge without fault by the Consultant. - 2 -
<!-- page 3 -->
(b) For purposes of this Agreement, Proprietary Information shall mean, by way of illustration and
not limitation, all information, whether or not in writing, whether or not patentable and whether or
not copyrightable, of a private, secret or confidential nature, owned, possessed or used by the
Company, concerning the Company's business, business relationships or financial affairs, including,
without limitation, any Invention, formula, vendor information, customer information, apparatus,
equipment, trade secret, process, research, report, technical or research data, clinical data,
know-how, computer program, software, software documentation, hardware design, technology, product,
processes, methods, techniques, formulas, compounds, projects, developments, marketing or business
plan, forecast, unpublished financial statement, budget, license, price, cost, customer, supplier or
personnel information or employee list that is communicated to, learned of, developed or otherwise
acquired by the Consultant in the course of Consultant's service as a consultant to the Company.

(c) The Consultant's obligations under this Section 6.1 shall not apply to any information that (i)
is or becomes known to the general public under circumstances involving no breach by the Consultant
or others of the terms of this Section 6.1, (ii) is generally disclosed to third parties by the
Company without restriction on such third parties, or (iii) is approved for release by written
authorization of an officer of the Company.

(d) The Consultant agrees that all files, documents, letters, memoranda, reports, records, data,
sketches, drawings, models, laboratory notebooks, program listings, computer equipment or devices,
computer programs or other written, photographic, or other tangible material containing Proprietary
Information, whether created by the Consultant or others, which shall come into Consultant's custody
or possession, shall be and are the exclusive property of the Company to be used by the Consultant
only in the performance of Consultant's duties for the Company and shall not be copied or removed
from the Company premises except in the pursuit of the business of the Company. All such materials
or copies thereof and all tangible property of the Company in the custody or possession of the
Consultant shall be delivered to the Company, upon the earlier of (i) a request by the Company or
(ii) the termination of this Agreement. After such delivery, the Consultant shall not retain any
such materials or copies thereof or any such tangible property.

(e) The Consultant agrees that Consultant's obligation not to disclose or to use information and
materials of the types set forth in paragraphs (b) and (d) above, and Consultant's obligation to
return materials and tangible property set forth in paragraph (d) above extends to such types of
information, materials and tangible property of customers of the Company or suppliers to the Company
or other third parties who may have disclosed or entrusted the same to the Company or to the
Consultant.

(f) The Consultant acknowledges that the Company from time to time may have agreements with other
persons or with the United States Government, or agencies thereof, that impose obligations or
restrictions on the Company regarding inventions made during the course of work under such
agreements or regarding the confidential nature of such work. The Consultant agrees to be bound by
all such obligations and restrictions that are known to Consultant and to take all action necessary
to discharge the obligations of the Company under such agreements. - 3 -
<!-- page 4 -->
6.2 Inventions.

(a) All inventions, ideas, creations, discoveries, computer programs, works of authorship, data,
developments, technology, designs, innovations and improvements (whether or not patentable and
whether or not copyrightable) which are made, conceived, reduced to practice, created, written,
designed or developed by the Consultant, solely or jointly with others or under Consultant's
direction and whether during normal business hours or otherwise, (i) during the Consultation Period
if related to the business of the Company or (ii) during or after the Consultation Period if
resulting or directly derived from Proprietary Information (as defined above) (collectively under
clauses (i) and (ii), "Inventions"), shall be the sole property of the Company. The Consultant
hereby assigns to the Company all Inventions and any and all related patents, copyrights,
trademarks, trade names, and other industrial and intellectual property rights and applications
therefor, in the United States and elsewhere and appoints any officer of the Company as Consultant's
duly authorized attorney to execute, file, prosecute and protect the same before any government
agency, court or authority. However, this paragraph shall not apply to Inventions which do not
relate to the business or research and development conducted or planned to be conducted by the
Company at the time such Invention is created, made, conceived or reduced to practice and which are
made and conceived by the Consultant not during normal working hours, not on the Company's premises
and not using the Company's tools, devices, equipment or Proprietary Information. The Consultant
further acknowledges that each original work of authorship which is made by the Consultant (solely
or jointly with others) within the scope of this Agreement and which is protectable by copyright is
a "work made for hire," as that term is defined in the United States Copyright Act.

(b) The Consultant agrees that if, in the course of performing the Services, the Consultant
incorporates into any Invention developed under this Agreement any preexisting invention,
improvement, development, concept, discovery or other proprietary information owned by the
Consultant or in which the Consultant has an interest ("Prior Inventions"), (i) the Consultant will
inform the Company, in writing before incorporating such Prior Inventions into any Invention, and
(ii) the Company is hereby granted a nonexclusive, royalty-free, perpetual, irrevocable,
transferable worldwide license with the right to grant and authorize sublicenses, to make, have
made, modify, use, import, offer for sale, sell, reproduce, distribute, modify, adapt, prepare
derivative works of, display, perform, and otherwise exploit such Prior Inventions, without
restriction, including, without limitation, as part of or in connection with such Invention, and to
practice any method related thereto. The Consultant will not incorporate any invention, improvement,
development, concept, discovery or other proprietary information owned by any third party into any
Invention without the Company's prior written permission.

(c) Upon the request of the Company and at the Company's expense, the Consultant shall execute such
further assignments, documents and other instruments as may be necessary or desirable to fully and
completely assign all Inventions to the Company and to assist the Company in applying for, obtaining
and enforcing patents or copyrights or other rights in the United States and in any foreign country
with respect to any Invention. The Consultant also hereby waives all claims to moral rights in any
Inventions.

(d) The Consultant shall promptly disclose to the Company all Inventions and will maintain adequate
and current written records (in the form of notes, sketches, drawings and as may be specified by the
Company) to document the conception and/or first actual reduction to practice of any Invention. Such
written records shall be available to and remain the sole property of the Company at all times. - 4
-
<!-- page 5 -->
7. Non-Solicitation. During the Consultation Period and for a period of one year thereafter, the
Consultant shall not, either alone or in association with others, (i) solicit, or permit any
organization directly or indirectly controlled by the Consultant to solicit, any employee of the
Company to leave the employ of the Company; or (ii) solicit for employment, hire or engage as an
independent contractor, or permit any organization directly or indirectly controlled by the
Consultant to solicit for employment, hire or engage as an independent contractor, any person who is
employed or engaged by the Company; provided, that this clause (ii) shall not apply to any
individual whose employment with the Company has been terminated for a period of six months or
longer.

8. Other Agreements; Warranty.

8.1 The Consultant hereby represents that, except as the Consultant has disclosed in writing to the
Company, the Consultant is not bound by the terms of any agreement with any third party to refrain
from using or disclosing any trade secret or confidential or proprietary information in the course
of Consultant's consultancy with the Company, to refrain from competing, directly or indirectly,
with the business of such third party or to refrain from soliciting employees, customers or
suppliers of such third party. The Consultant further represents that Consultant's performance of
all the terms of this Agreement and the performance of the services as a consultant of the Company
do not and will not breach any agreement with any third party to which the Consultant is a party
(including, without limitation, any nondisclosure or non-competition agreement), and that the
Consultant will not disclose to the Company or induce the Company to use any confidential or
proprietary information or material belonging to any current or previous employer or others.

8.2 The Consultant hereby represents, warrants and covenants that Consultant has the skills and
experience necessary to perform the services, that Consultant will perform said services in a
professional, competent and timely manner, that Consultant has the power to enter into this
Agreement and that Consultant's performance hereunder will not infringe upon or violate the rights
of any third party or violate any federal, state or municipal laws.

9. Independent Contractor Status.

9.1 The Consultant shall perform all services under this Agreement as an "independent contractor"
and not as an employee or agent of the Company. The Consultant is not authorized to assume or create
any obligation or responsibility, express or implied, on behalf of, or in the name of, the Company
or to bind the Company in any manner.

9.2 The Consultant shall have the right to control and determine the time, place, methods, manner
and means of performing the services. In performing the services, the amount of time devoted by the
Consultant on any given day will be entirely within the Consultant's control, and the Company will
rely on the Consultant to put in the amount of time necessary to fulfill the requirements of this
Agreement. The Consultant will provide all equipment and supplies required to perform the services.
The Consultant is not required to attend regular meetings at the Company. However, upon reasonable
notice, the Consultant shall meet with representatives of the Company at a location to be designated
by the parties to this Agreement. - 5 -
<!-- page 6 -->
9.3 In the performance of the services, the Consultant has the authority to control and direct the
performance of the details of the services, the Company being interested only in the results
obtained. However, the services contemplated by the Agreement must meet the Company's standards and
approval and shall be subject to the Company's general right of inspection and supervision to secure
their satisfactory completion.

9.4 The Consultant shall not use the Company's trade names, trademarks, service names or service
marks without the prior approval of the Company.

9.5 The Consultant shall be solely responsible for all state and federal income taxes, unemployment
insurance and social security taxes in connection with this Agreement and for maintaining adequate
workers' compensation insurance coverage.

10. Remedies. The Consultant acknowledges that any breach of the provisions of Section 1, 6 or 7 of
this Agreement shall result in serious and irreparable injury to the Company for which the Company
cannot be adequately compensated by monetary damages alone. The Consultant agrees, therefore, that,
in addition to any other remedy the Company may have, the Company shall be entitled to enforce the
specific performance of this Agreement by the Consultant and to seek both temporary and permanent
injunctive relief (to the extent permitted by law) without the necessity of proving actual damages
or posting a bond.

11. Notices. All notices required or permitted under this Agreement shall be in writing and shall be
deemed effective upon personal delivery or upon deposit in the United States Post Office, by
registered or certified mail, postage prepaid, addressed to the other party at the address shown
above, or at such other address or addresses as either party shall designate to the other in
accordance with this Section 11.

12. Pronouns. Whenever the context may require, any pronouns used in this Agreement shall include
the corresponding masculine, feminine or neuter forms, and the singular forms of nouns and pronouns
shall include the plural, and vice versa.

13. Entire Agreement. This Agreement constitutes the entire agreement between the parties and
supersedes all prior agreements and understandings, whether written or oral, relating to the subject
matter of this Agreement.

14. Amendment. This Agreement may be amended or modified only by a written instrument executed by
both the Company and the Consultant.

15. Non-Assignability of Contract. This Agreement is personal to the Consultant and the Consultant
shall not have the right to assign any of Consultant's rights or delegate any of Consultant's duties
without the express written consent of the Company. Any non-consented-to assignment or delegation,
whether express or implied or by operation of law, shall be void and shall constitute a breach and a
default by the Consultant. - 6 -
<!-- page 7 -->
16. Governing Law. This Agreement shall be governed by and construed in accordance with the laws of
the Commonwealth of Massachusetts without giving effect to any choice or conflict of law provision
or rule that would cause the application of laws of any other jurisdiction.

17. Successors and Assigns. This Agreement shall be binding upon, and inure to the benefit of, both
parties and their respective successors and assigns, including any corporation with which, or into
which, the Company may be merged or which may succeed to its assets or business, provided, however,
that the obligations of the Consultant are personal and shall not be assigned by Consultant.

18. Interpretation. If any restriction set forth in Section 1, 6 or 7 is found by any court of
competent jurisdiction to be unenforceable because it extends for too long a period of time or over
too great a range of activities or in too broad a geographic area, it shall be interpreted to extend
only over the maximum period of time, range of activities or geographic area as to which it may be
enforceable.

19. Survival. The last sentence of Section 1 and Sections 4 through 20 shall survive the expiration
or termination of this Agreement.

20. Miscellaneous.

20.1 No delay or omission by the Company in exercising any right under this Agreement shall operate
as a waiver of that or any other right. A waiver or consent given by the Company on any one occasion
shall be effective only in that instance and shall not be construed as a bar or waiver of any right
on any other occasion.

20.2 The captions of the sections of this Agreement are for convenience of reference only and in no
way define, limit or affect the scope or substance of any section of this Agreement.

20.3 In the event that any provision of this Agreement shall be invalid, illegal or otherwise
unenforceable, the validity, legality and enforceability of the remaining provisions shall in no way
be affected or impaired thereby.

[Remainder of Page Intentionally Left Blank] - 7 -
<!-- page 8 -->
IN WITNESS WHEREOF, the parties hereto have executed this Consulting Agreement as of the date and
year first above written. COMPANY:

IMMUNOTOLERANCE, INC.

By: /s/ Dan Matloff Name: Dan Matloff Title: CFO

CONSULTANT:

/s/ Alan Crane Name: Alan Crane

SIGNATURE PAGE TO CONSULTING AGREEMENT
<!-- page 9 -->
SCHEDULE A

Consultant will provide advice and services to the Company as requested by the Board of Directors
from time to time. The field for purposes of Section 1 is defined as drugs and cell-based therapies
designed for tissue-specific immunosuppression.
