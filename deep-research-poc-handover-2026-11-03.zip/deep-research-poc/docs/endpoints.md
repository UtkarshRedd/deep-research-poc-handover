# Endpoint capability probe

Last run: 2026-11-01 21:01. One row per model; rows persist across runs.

| role | model | tools | parallel_tools | json | p50_s_2k_in | parallel8_max_s | parallel8_failures | base_url |
|---|---|---|---|---|---|---|---|---|
| extractor/verifier | nvidia/nemotron-nano-3-30b-a3b | error: OpenAIModelNotFoundError: Error code: 404 | error: OpenAIModelNotFoundError: Error code: 404 | error: OpenAIModelNotFoundError: Error code: 404 | nan | nan | 8 | https://integrate.api.nvidia.com/v1 |
| judge/writer | google/gemma-3-12b-it | error: OpenAIModelNotFoundError: Error code: 404 | error: OpenAIModelNotFoundError: Error code: 404 | error: OpenAIModelNotFoundError: Error code: 404 | nan | nan | 8 | https://integrate.api.nvidia.com/v1 |
| planner/researcher/router | openai/gpt-oss-20b | True | 1 | True | 71.53 | 165.84 | 0 | https://integrate.api.nvidia.com/v1 |
| researcher | nvidia/nemotron-3.5-super-vl-120b-a12b | True | 2 | True | 18.59 | 0.55 | 0 | https://integrate.api.nvidia.com/v1 |
| extractor | nvidia/nemotron-3.5-lightning-30b-a3b | True | 1 | True | 17.57 | 8.47 | 0 | https://integrate.api.nvidia.com/v1 |

## Notes (2026-11-01, NVIDIA Build free tier, ~40 req/min)

- `nvidia/nemotron-3.5-super-vl-120b-a12b` (planner/router/researcher): tools, **parallel tool calls (2 in one turn)**, JSON all OK; one-word calls < 1 s even 8-way parallel. The 18.6 s p50 is the 2K-in summarization task (reasoning model, thinking uncapped).
- `nvidia/nemotron-3.5-lightning-30b-a3b` (extractor/verifier): tools and JSON OK; emitted one tool call when asked for two; 8-way parallel max 8.5 s.
- `openai/gpt-oss-20b`: works (tools, JSON) but one tool call per turn and 50-70 s per call on this tier; kept as a documented fallback only.
- `nvidia/nemotron-nano-3-30b-a3b`, `google/gemma-3-12b-it`: listed by /v1/models but 404 on chat completions. `google/gemma-4-31b-it`: one 120 s timeout; configured for writer/judge, unverified (no code yet).
- Model ids live in `.env` (gitignored) / `.env.example`; CLAUDE.md still names the intended production families.
- Live end-to-end run (q001, sample corpus, 2026-11-01): research 11.8 s / 6 calls, write 130 s (4 writer calls on nemotron-3.5-super, ~40 s each with uncapped reasoning), verify 2 ms; 6 claims, 5 keep + 1 gap, 0 dropped. The write stage exceeds its 45 s budget: cap writer reasoning/max_tokens or use nemotron-3.5-lightning for drafts (Phase 8 tuning).
- Live A1_deep_list run (q011 temporal, 31-doc synthetic corpus, 2026-11-01): first move 28.5 s (7 model clues, 31 candidates, gold doc at rank 2, candidate recall 1.0), route 6.8 s (single, correct reasoning about the not-yet-effective amendment), research 36 s (submitted; gold page cited), write 188 s (one 90 s timeout -> empty section), verify 3 ms; total 260 s. Writer latency is the bottleneck.
- Writer fix (2026-11-01): `DR_THINKING_WRITER=0` (chat_template_kwargs.enable_thinking=false). Same A1 question: total 260 s -> 48 s (lightning) / 76 s (super); write 188 s -> 4.7 s / 3.9 s. Super no-thinking cites every sentence (6/6 keep); lightning no-thinking stacked citations and left sentences uncited. Writer/judge = super, no thinking.
- After clue expansion + outline bound (2026-11-01): q011 temporal 61 s (first move 24 s, 7/7 clues expanded, recall 1.0; 8 keep / 2 gap, no empty sections); q004 governing law 43 s (3 keep / 1 gap, correct: California). CUAD corpus: 510 docs load 0.2 s, materialize 0.5 s, BM25 build 3.0 s / 15,155 chunks.
- CUAD slice eval (2026-11-01, 6 questions, 510 docs): A1 3/6 and A2 3/6 judge-correct; details in eval/README.md. Planner thinking 66-68 s on long questions; one researcher call thought 110 s (timeout); a transient connection error killed an A2 run (loop now retries once).
- Thinking A/B (2026-11-01, 6 CUAD questions, A1): on=3/6; planner off=3/6; researcher off=5/6; both off=5/6 with tokens/correct 212k (best) -> .env sets DR_THINKING_{PLANNER,ROUTER,RESEARCHER}=0. Extractor/verifier untested (no code yet).
- Phase 5 breadth (cq077, 2026-11-01): A3_fanout v4 111 s / 436k tokens / 88 calls (8 units + gap); A3_grid_only over 40 docs 28 s / 104k. Extractor + verifier thinking off. See eval/README.md.
- Phase 7 (2026-11-01): verifier = lightning, no thinking (`DR_THINKING_VERIFIER=0`). Seeded tier-2 check: 10/10 planted errors flagged, 0 false flags, 2 skipped; 4 grouped calls took 156 s while an eval shared the rate budget.
- 429 probe (2026-11-02 04:56 UTC, no other load): three isolated one-word calls to `nemotron-3.5-super-vl-120b-a12b` -> 429, OK, 429 (body `{'status': 429, 'title': 'Too Many Requests'}`, no retry-after header, 0.5 s each); three to `lightning-30b-a3b` -> OK, OK, OK but 11 s / 0.8 s / 17 s (queueing). The super endpoint sheds load per request; it is not our request rate (pacer at 30 RPM, ~5 req/min actual). Long 20/40 s backoffs are the wrong response to this: a rejected call usually succeeds seconds later.
- Single-stream probe (2026-11-02 05:10 UTC, no other load, 1 s gap): super 7/10 OK (3 x 429, 0.2-0.7 s when accepted); lightning 6/6 OK (one 11 s queue). Candidate substitutes: `llama-3.1-nemotron-51b/70b/ultra-253b`, `nemotron-3-super-120b-a12b`, embed models -> 404 on chat; `nemotron-3-nano-omni-30b-a3b-reasoning` OK at ~10 s per one-word call; `llama-3.1-nemotron-safety-guard-8b-v3` OK (not a chat model for our roles). Decision: keep super, run evals at concurrency 1, retries 2/4/8/16/30 s.
