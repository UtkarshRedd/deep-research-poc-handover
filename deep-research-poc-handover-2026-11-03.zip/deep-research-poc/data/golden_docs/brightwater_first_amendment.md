<!-- page 1 -->
# First Amendment to Credit Agreement — Brightwater Renewables
| Field | Value |
|---|---|
| Document Type | Amendment |
| Effective Date | 2025-05-12 |
| Parties | Brightwater Renewables plc; Meridian Trust Bank, N.A. |
| Facility ID | FAC-2024-0311 |
| Version | First Amendment |

THIS FIRST AMENDMENT TO CREDIT AGREEMENT (this "Amendment") is entered into as of 2025-05-12 (the "First Amendment Effective Date") among Brightwater Renewables plc (the "Borrower"), the Lenders party hereto and Meridian Trust Bank, N.A., as Administrative Agent.

## Recitals
WHEREAS, the Borrower, the Lenders and the Administrative Agent are parties to that certain Credit Agreement dated as of 2024-09-30 (the "Credit Agreement"; facility FAC-2024-0311);
WHEREAS, the Borrower has requested a reduction of the minimum Interest Coverage Ratio following the commissioning delay at the Firth Array;
NOW, THEREFORE, the parties agree as follows.
<!-- page 2 -->
## Section 1 — Amendments to the Credit Agreement
Effective as of the First Amendment Effective Date, the Credit Agreement is amended as follows:
1.1 Section 7.2 is amended by replacing "2.50 to 1.00" with "2.25 to 1.00", so that the Borrower shall not permit the Interest Coverage Ratio to be less than 2.25 to 1.00.

## Section 2 — Conditions to Effectiveness
This Amendment becomes effective on the date the Administrative Agent receives counterparts hereof executed by the Borrower and the Required Lenders, together with an amendment fee for the account of each consenting Lender equal to 0.125% of such Lender's Commitment.
<!-- page 3 -->
## Section 3 — Representations; Reaffirmation
The Borrower represents that no Default has occurred and is continuing and that the representations in Article V of the Credit Agreement are true and correct in all material respects on the date hereof.
Each Guarantor, by its acknowledgment below, reaffirms its obligations under the Guarantee and the Security Agreement after giving effect to this Amendment.
## Section 4 — Effect; Governing Law
Except as expressly amended hereby, the Credit Agreement and the other Loan Documents remain in full force and effect and are hereby ratified and confirmed. This Amendment is a Loan Document.
This Amendment shall be governed by the laws of the State of New York. Notices hereunder shall be given in the manner set forth in Section 10.1 of the Credit Agreement.
Brightwater Renewables plc, as Borrower — By: /s/ Authorized Signatory
Meridian Trust Bank, N.A., as Administrative Agent — By: /s/ Authorized Signatory
