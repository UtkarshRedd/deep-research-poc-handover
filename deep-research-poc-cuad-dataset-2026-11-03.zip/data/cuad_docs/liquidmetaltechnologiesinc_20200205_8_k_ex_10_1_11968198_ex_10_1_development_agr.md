<!-- page 1 -->
# BUSINESS DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| SEC Filing Date | 2020-02-05 |
| Parties | LIQUIDMETAL TECHNOLOGIES, INC. ("Liquidmetal"); EUTECTIX, LLC ("Eutectix") |
| Source | CUAD v1 / LiquidmetalTechnologiesInc_20200205_8-K_EX-10.1_11968198_EX-10.1_Development Agreement |

Exhibit 10.1 BUSINESS DEVELOPMENT AGREEMENT THIS BUSINESS DEVELOPMENT AGREEMENT (the "Agreement") is
effective as of , 2020 (the "Effective Date"), by and between LIQUIDMETAL TECHNOLOGIES, INC., a
Delaware corporation having its principal place of business at 20321 Valencia Circle, Lake Forest,
California 92630 ("Liquidmetal"), and EUTECTIX, LLC, a Delaware limited liability company having an
address of 323 Main Street, Chatham, New Jersey 07928 ("Eutectix"). Liquidmetal and Eutectix are
sometimes referred to herein individually as a "Party" or collectively as the "Parties." RECITALS
WHEREAS, Liquidmetal is a global leader in the development and pursuit of applications for amorphous
alloys and has developed relationships with various prominent corporations with respect to the
development of parts and products made from amorphous alloys; WHEREAS, Eutectix is a global leader
in the development and production of amorphous alloys and other high-quality technical alloys, and
possesses certain intellectual property in connection therewith which is not provided for under this
Agreement; WHEREAS, Liquidmetal and DongGuan Eontec Co., Ltd. ("Eontec") are parties to a Parallel
License Agreement dated March 10, 2016 (the "Affiliate License Agreement"), pursuant to which
Liquidmetal and Eontec license to each other certain technology and intellectual property relating
to bulk metallic glasses as further described therein, a copy of which has been provided to
Eutectix; WHEREAS, Liquidmetal desires to utilize Eutectix's capabilities with respect to amorphous
alloy development and the manufacture of amorphous alloy parts, which Liquidmetal develops with, and
intends to sell to, Liquidmetal's customers, and Eutectix is interested in providing such product
development and manufacturing services to Liquidmetal; WHEREAS, Liquidmetal and Eutectix desire to
further collaborate with respect to the advancement and commercialization of amorphous alloy
materials and technologies; WHEREAS, Eutectix desires to utilize Liquidmetal processing equipment
and methodologies to independently develop new metallic glass technologies, including, but not
limited to, new metallic glass alloys and related products for sale, as further described herein;
and WHEREAS, the Parties perceive an opportunity for shared growth in worldwide sales of products
made from bulk metallic glasses. NOW THEREFORE, in consideration of the premises and the mutual
covenants and agreements set forth herein and other good and valuable consideration, the receipt and
sufficiency are hereby acknowledged, the Parties hereto hereby agree as follows:

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 2 -->
AGREEMENT 1. TERM. The initial term of this Agreement shall commence on the Effective Date and shall
continue until the fifth (5t h) anniversary of the Effective Date (the "Term"), unless the Agreement
is sooner terminated in accordance with the terms of this Agreement. Upon the expiration of the
Term, the Term shall automatically extend for successive 12-month periods until one Party terminates
the Agreement by providing at least 180 days prior written notice to the other Party prior to the
expiration of the then-current term or unless sooner terminated in accordance with the terms of this
Agreement. 2. EQUIPMENT AND ALLOY. 2.1 Equipment License. Upon and subject to the terms and
conditions stated in this Agreement, on the Effective Date, for the consideration described in this
Agreement and Eutectix's performance of its other obligations under this Agreement, Liquidmetal
grants to Eutectix the right and license to use the following equipment owned by Liquidmetal (the
"Licensed Equipment") (i) solely for use on Liquidmetal's behalf, (ii) for Eutectix's own limited
use in the production of Liquidmetal Products (as defined below) or Licensed Products (as defined
below), (iii) for the continued development of applications utilizing bulk metallic glasses in
cooperation between Liquidmetal and Eutectix, and (iv) independently by Eutectix pursuant to the
terms of this Agreement: (a) Two (2) Engel e-motion 310/120 injection molding machines, and
associated equipment; (b) Two (2) Eontec 300-C Die Casting Machines, and associated equipment; (c)
One (1) Flow M21313B Waterjet Machine; (d) Two (2) DMG Mori Milltap 700 CNC machines, and associated
consumables and fixtures; (e) Equipment for cut, mount, and polish analysis operations, including:
i. One (1) Struers Accutom-10 cut-off machine ii. One (1) Struers Secotom-50 precision cutting
machine iii. One (1) Struers Tegramin-30 tabletop grinding machine iv. One (1) Keyence VH X-S550E
microscope (f) Equipment required for vibratory deburring operations, including: i. One (1) Rosler R
125 EC-KF rotary vibrator ii. One (1) Rosler R 125 EC rotary vibrator 2

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 3 -->
(g) Equipment required for passivation operations, including: i. One (1) ESMA, Inc. E782C ultrasonic
cleaning system (h) One (1) Dry Cooler D455 chill water system; (i) One (1) MTS 810 MTS mechanical
testing frame; and (j) Molds and fixtures needed for production of sample parts. 2.2 Alloys
Purchase. Upon and subject to the terms and conditions of this Agreement, on the Effective Date, for
such consideration as described in this Agreement and Eutectix's performance of its other
obligations pursuant to this Agreement, Liquidmetal hereby sells, assigns, conveys, transfers, and
delivers to Eutectix, and Eutectix hereby acquires from Liquidmetal, free and clear of all liens
(other than and to the extent that liens may be imposed by or arise by operation of law), all of
Liquidmetal's right, title, and interest in and to the following alloys (the "Transferred Alloy"),
subject to Liquidmetal's right to use said Transferred Alloy or the corresponding replacement
thereof as specified in this Agreement: (a) Approximately three thousand kilograms (3,000 kg) of
"virgin" LM105 Alloy (b) Approximately one thousand kilograms (1,000 kg) of "virgin" 106C Alloy (c)
Approximately two thousand kilograms (2,000 kg) of LM 105 Alloy revert 2.3 Shipment and Delivery.
Licensed Equipment and Transferred Alloy shall be delivered to Eutectix Ex Works Lake Forest (as
defined by Incoterms 2010). Title to the Transferred Alloy shall vest to Eutectix at the point of
delivery. Eutectix will bear all delivery and shipping expenses with respect to the Licensed
Equipment and Transferred Alloy from Liquidmetal's facility. THE LICENSED EQUIPMENT AND TRANSFERRED
ALLOY ARE BEING PROVIDED "AS IS" AND "WITH ALL FAULTS" AND WITH NO WARRANTIES OF ANY KIND, INCLUDING
WITHOUT LIMITATION WARRANTIES OF FITNESS FOR A PARTICULAR PURPOSE. 2.4 License. Liquidmetal grants
to Eutectix during the Term of this Agreement and subject to the Field of Use Restrictions (as
defined below), a royalty-bearing, worldwide, non-transferrable, non-exclusive license (or
sublicense as the case may be) to the Licensed Patents (as defined below) and the Licensed Technical
Information (as defined below) to make and have made, assemble and have assembled, use, sell, offer
to sell, import and offer to import, export and offer to export, distribute and offer to distribute,
repair, reconstruct, practice, and maintain Licensed Products in the Field (as defined below). The
foregoing Licensed Patents and Licensed Technical Information shall not include the right to
sublicense the Licensed Patents and Licensed Technical Information without the prior written consent
of Liquidmetal. For purposes hereof, the following definitions and provisions shall apply: (a)
"Field" shall mean all fields of use except as described in the Field of Use Restrictions. (b)
"Field of Use Restrictions" shall mean the exclusions, conditions, limitations, and restrictions
described on Schedule 1 to this Agreement. 3

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 4 -->
(c) "Licensed Patents" shall mean any and all Patents of Liquidmetal or any Affiliate of Liquidmetal
in existence at any time during the term of this Agreement. (d) "Liquidmetal Product" shall mean any
product or component made with one or more amorphous alloys or bulk metallic glasses (or composite
materials containing amorphous alloys or bulk metallic glasses) (i) pursuant to an Order (as defined
below) for and on behalf of Liquidmetal by Eutectix in connection with the Licensed Equipment; (ii)
purchased by Liquidmetal from third party manufacturers other than Eutectix, and (iii) manufactured
by Liquidmetal directly. (e) "Licensed Product" shall mean any metallic glass product produced by
Eutectix for its customers (i) the manufacture, use, offer for sale, sale or importation of which by
Eutectix or its permitted sublicensees would, but for this Agreement, infringe a valid claim of a
Licensed Patent in a jurisdiction where such valid claim exists, (ii) that incorporates or uses any
element of the Licensed Technical Information in its design or manufacture, or (iii) that is
manufactured or processed in any respect, in whole or in part, with any part of the Licensed
Equipment listed in Sections 2.1(a) and (b). (f) "Licensed Technical Information" shall mean all
information as documented in Schedule 3 hereto, as may be amended from time to time, including but
not limited to, unpublished research and development information, unpatented inventions, know-how,
trade secrets, and technical data, of which Eutectix has no prior knowledge (where prior knowledge
cannot be proven or documented) and is not generally available in the public domain, which such
Licensed Technical Information is in the possession of Liquidmetal and is reasonably necessary or
useful for using the Licensed Patents to produce Licensed Products within the Field, provided
Liquidmetal has the right to disclose such items to Eutectix. Liquidmetal shall deliver all
available Licensed Technical Information to Eutectix within ten (10) days of the Effective Date. (g)
"Patents" shall mean any and all letters patents (including, but not limited to, patents of
implementation, improvement, or addition, utility model and appearance design patents, and inventors
certificates, as well as all divisionals, reissues, reexaminations, continuations,
continuations-in-part, renewals, extensions, substitutions, foreign equivalents and counterparts,
and any other forms of patent protection directed to the inventions covered by any of the
foregoing), applications for letters patent (including, but not limited to, all foreign counterpart
patent applications, and letters patent that may issue on such applications, all as of the Effective
Date as documented in Schedule 3 hereto and any subsequent revisions to Schedule 3 by Liquidmetal
during the Term of this Agreement. (h) Enforcement. Liquidmetal and its Affiliates shall have the
sole right and discretion to prevent, abate, or seek legal recourse for any actual or threatened
misappropriation or infringement and attempt to resolve any claims relating to Liquidmetal's
Intellectual Property (as defined herein), including the Licensed Patents and Licensed Technical
Information. 4

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 5 -->
2.5 Bailment of Equipment. Eutectix will provide facility space for the Licensed Equipment in a
Eutectix-owned or leased secure and protected property that is restricted from unauthorized access
or viewing (the "Eutectix Property"). Eutectix shall maintain the Licensed Equipment only in such
designated Eutectix Property and shall not relocate the Licensed Equipment from such Eutectix
Property without the prior written consent of Liquidmetal. Once Eutectix receives the Licensed
Equipment, Eutectix will acknowledge in writing the receipt thereof. Eutectix's acknowledgement of
receipt of the Licensed Equipment will constitute an acknowledgement that Eutectix has received and
accepted and possesses the Licensed Equipment on bailment for the benefit of Liquidmetal and that
such receipt of the Licensed Equipment is not subject to the terms and conditions of any applicable
laws pertaining to sales and/or secured transactions. The Licensed Equipment: (a) is and shall
remain the sole property of Liquidmetal, (b) shall be made available for reasonable inspection upon
at least three (3) weeks prior written request by Liquidmetal, such inspection not to occur more
than once per year during the Term, to be conducted with minimal business disruption to Eutectix and
to be conducted at Liquidmetal's sole cost and expense and Eutectix shall, at its own expense: (c)
keep the Licensed Equipment in a suitable place, safe from loss or damage; (d) subscribe to an
insurance policy from an insurance company reasonably acceptable to Eutectix covering the Licensed
Equipment at full replacement value against fire, theft and such other normal business risks, with a
waiver of subrogation in favor of Liquidmetal and with Liquidmetal to be named as an additional
insured and loss payee, and provide, upon receipt of a written request from Liquidmetal, a
certificate evidencing such insurance, and comply with all requirements associated with such
insurance policy; (e) keep the Licensed Equipment in good working order and condition, excepting
normal wear and tear, and perform all regular and routine maintenance and repairs on the Equipment;
(f) perform no act or omission inconsistent with Liquidmetal's sole ownership of the Licensed
Equipment, nor attempt to sell, assign, loan, donate, mortgage, pledge or in any other manner permit
the Licensed Equipment to be encumbered; (g) comply with all reasonable directions given by
Liquidmetal regarding (A) the inspection of the Licensed Equipment, including upon termination or
expiration of the Agreement and in connection with any non-ordinary or non-routine revisions or
alterations to the Licensed Equipment, (B) the removal and shipment of the Licensed Equipment,
including upon termination or expiration of the Agreement, and (C) protecting or perfecting
Liquidmetal's interest in the Licensed Equipment, including by executing and permitting Liquidmetal
to file financing statements and other documents with respect thereto, at Liquidmetal's expense; and
(h) shall be liable for all loss or damage to Licensed Equipment, except for normal wear and tear of
the Licensed Equipment. 5

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 6 -->
Eutectix may, with prior written consent of Liquidmetal (such consent not to be unreasonably
withheld, conditioned or delayed), (i) transfer or move any Licensed Equipment, (j) make or cause to
be made any non-ordinary or non-routine revisions or alterations to the Licensed Equipment. 2.6
Alloy Availability. During the initial three (3) years of the Term of this Agreement, Eutectix shall
make available alloy raw materials equal in kind and quantity to the Transferred Alloy without cost,
for use in Orders (as defined in Section 3.1 below) placed by Liquidmetal. 2.7 Royalty. In
consideration of the license of Liquidmetal Technical Information and the Licensed Equipment granted
by Liquidmetal, Eutectix agrees to pay Liquidmetal a cash royalty based on a percentage of the
invoice price of any Licensed Products (but not including Liquidmetal Products) sold by Eutectix or
its permitted sublicensees and for which payment was actually received by Eutectix. The cash royalty
shall be an amount equal to six percent (6.0%) of the Net Sales Price of the invoice price of any
Licensed Products and for which payment was actually received by Eutectix (the "Liquidmetal
Royalty"). "Net Sales Price" is defined as the gross invoice price actually received by Eutectix or
its permitted sublicensees on the sale of Licensed Products, less returns or refunds, but before
deduction of cash discounts. The Net Sales Price shall be commercially reasonable, and in no case
shall the Net Sales Price be less than the cost of material consumed in a single manufacturing
cycle, divided by the number of Licensed Products produced by such single cycle. The Liquidmetal
Royalty shall be paid in U.S. dollars within 30 days after the end of each calendar quarter, based
on payments received for sales of Licensed Products made during a given quarter. Liquidmetal hereby
waives the payment of any Liquidmetal Royalty otherwise due and payable pursuant to this Agreement
until the one (1) year anniversary of the Effective Date. 2.8 Royalties for Transactions Not at
Arm's Length. Eutectix agrees that in the event any Licensed Products shall be sold (1) to any
Affiliate (as defined herein), or (2) to a corporation, firm, or association with which, or
individual with whom Eutectix or its stockholders or Affiliates shall have any agreement,
understanding, or arrangement (such as, among other things, an option to purchase stock, or an
arrangement involving a division of profits or special rebates or allowances) without which
agreement, understanding, or arrangement, prices paid by such a corporation, firm, association or
individual for the Licensed Products would be higher than the Net Sales Price reported by Eutectix,
or if such agreement, understanding, or arrangement results in extending to such corporation, firm,
association, or individual lower prices for Licensed Products than those charged to outside concerns
buying similar products in similar amounts and under similar conditions, then, and in any such
events, the royalties to be paid hereunder in respect of such Licensed Products shall be computed
based on an assumed or deemed Net Sales Price equal to those charged to such outside concerns. 2.9
Commission. From time to time, Liquidmetal may encounter, develop, and refer to Eutectix customer
accounts for direct sales by Eutectix. Provided that such referred customer is not already a
Eutectix customer, Eutectix may accept such customer referral, and in that case hereby agrees to pay
Liquidmetal a cash commission based on a percentage of the invoice price of Licensed Products sold
by Eutectix or its permitted sublicensees and for which payment was actually received by Eutectix,
in addition to the Liquidmetal Royalty. The cash commission shall be an amount equal to six percent
(6.0%) of the Net Sales Price of the invoice price of Licensed Products sold by Eutectix or its
permitted sublicensees and for which payment was actually received by Eutectix (the "Liquidmetal
Commission"). The Liquidmetal Commission shall be paid in U.S. dollars within 30 days after the end
of each calendar quarter, based on payments received for sales of Licensed Products made during a
given quarter. Liquidmetal hereby waives the payment of any Liquidmetal Commission otherwise due and
payable pursuant to this Agreement until the one (1) year anniversary of the Effective Date. For the
purposes of this Section, product development teams within a single corporation or group of
corporations under common control are not the "same customer" as any other product development team
unless they (i) are organized within the same legal entity and under the same product division, and
(ii) operate within the same geographic territory. 6

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 7 -->
2.10 Report. Eutectix shall provide a report to Liquidmetal accompanying the Liquidmetal Royalty and
Liquidmetal Commission stating whether the sales were to an Affiliate, the Net Sales Price actually
received and the amount of Liquidmetal Royalty and Liquidmetal Commission due and owing. 3. ORDERS:
PRICING, PAYMENT TERMS, AND CAPACITY. 3.1 Pricing. During the Term of this Agreement, Liquidmetal
may from time to time purchase from Eutectix such "Liquidmetal Products" as specifically described
in a purchase order issued by Liquidmetal (an "Order") to Eutectix at the prices set forth in the
Order (the "Prices"). The Parties shall negotiate the Prices in good faith on a project-by-project
basis, taking into consideration strategic value, competitiveness, profitability, design issues,
cost-drivers including input material costs, export licensing of the Liquidmetal Products and
payment of broker's fees, duties, tariffs and other similar charges, taxes, tariffs, or charges
imposed by any taxing authority upon the sale, shipment, storage, "value add" or use of the
Liquidmetal Products, set-up, tooling, non-recurring engineering activities, and any other relevant
factors. Prices (a) are in U.S. Dollars, (b) include Eutectix's standard packaging, and (c) are
based on the configuration set forth in the specifications provided to Eutectix by Liquidmetal (the
"Specifications"). Consistent with Section 2.6 above, from the Effective Date, the Prices shall
include zero U.S. dollars ($0.00) input materials cost factor for all Orders requiring LM 105 Alloy
and 106C Alloy input materials until the earlier of the third anniversary of the Effective Date, or
the date upon which Liquidmetal has consumed alloy, including revert (assuming the Transferred Alloy
revert is suitable for use in such Orders), equivalent to the respective quantities listed in
Section 2.2 above. 3.2 Payment Terms. Eutectix may issue an invoice for Liquidmetal Products any
time after the shipment thereof to Liquidmetal. Payment terms are net 30 days after the date of the
invoice, or the date of receipt by Liquidmetal of the invoice if the invoice is received more than
10 days after the date of the invoice. Unless otherwise stated in the applicable Order or as
otherwise agreed in writing by the Parties, payment shall be made in U.S. Dollars. 3.3 Cost
Reduction. Eutectix will work diligently with Liquidmetal in an effort to reduce waste, enhance
productivity, and decrease Prices through reductions in the cost of producing Liquidmetal Products,
all without adversely impacting quality or delivery times. Throughout the term of this Agreement,
Eutectix and Liquidmetal will work cooperatively and take advantage of cost saving technologies and
other cost reduction opportunities to assist in maintaining a competitive cost position. The Parties
shall meet on a quarterly basis to discuss specific cost reduction and productivity enhancement
activities (collectively, the "Activities"). In support of these efforts, Liquidmetal shall provide
to Eutectix its own estimates of direct sales costs, including commissions, inspections,
modifications, inventory, repackaging, shipping/receiving, duties & tariffs, warranty services, and
current overhead rates. Notwithstanding any such estimates Liquidmetal may provide, Eutectix shall
set Prices in accordance with its known costs and margins. 7

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 8 -->
3.4 Forecasts; Manufacturing Capacity. In connection with any Order, Liquidmetal may concurrent with
such Order or subsequent thereto from time to time provide Eutectix with a six (6) month rolling
forecast (each, a "Forecast") of its projected additional purchases of Liquidmetal Products covered
by an Order ("Additional Product"). Forecasts will be prepared in good faith. Eutectix agrees to
reserve sufficient manufacturing capacity to satisfy the supply of Additional Product in accordance
with the applicable Forecast, provided that Eutectix shall not be required to reserve in excess of
ten percent (10%) of its manufacturing capacity pursuant to this Section 3.4. 3.5 Quotation.
Liquidmetal may from time to time request a price quote for certain Liquidmetal Products (each such
request, a "RFQ"). Eutectix agrees to provide a timely response to Liquidmetal's RFQ either
providing Liquidmetal with such requested quote (each, a "Quote"), or informing Liquidmetal of
Eutectix's intent not to provide such requested quote. 3.6 Purchase Orders. Eutectix agrees to
manufacture and deliver Liquidmetal Products pursuant to Orders (or any changes thereto timely and
reasonably requested by Liquidmetal in writing and agreed to by Eutectix). Each Order shall be in
the form of a written or electronic communication. Liquidmetal and Eutectix shall agree to the
required Acceptance (as defined below) criteria before Eutectix accepts an Order. The Parties shall
negotiate in good faith to resolve any disputed matter(s). 3.7 Shipments. Eutectix will make
Liquidmetal Product shipments from Eutectix's facility of manufacture directly to Liquidmetal or, if
directed by Liquidmetal in writing, to Liquidmetal's customers ("Customers") on behalf of
Liquidmetal. In the event that Liquidmetal so directs, Eutectix will use packaging provided by
Liquidmetal at Liquidmetal's cost indicating Liquidmetal as the seller of the Product. 3.8 Delivery.
Unless otherwise agreed in writing or in the applicable Order, all Liquidmetal Product shipments
shall be Ex Works (Incoterms 2010) Eutectix's facility of manufacture in Tolleson, Arizona. Title to
and risk of loss or damage to the Liquidmetal Product shall pass to Liquidmetal upon Eutectix's
tender of the Liquidmetal Product to the common carrier. 3.9 Acceptance. Acceptance of the
Liquidmetal Product shall be based on characteristics that are measurable by a quality system and
designed to demonstrate compliance with the Specifications. Unless Liquidmetal notifies Eutectix
that the Liquidmetal Product does not meet the Specifications within thirty (30) calendar days after
receipt of the Liquidmetal Product, then the Liquidmetal Product shall be deemed Accepted. 3.10
Changes. Liquidmetal may upon sufficient timely and reasonable written notice make changes within
the general scope of an Order, if agreed to by Eutectix. Such changes may include, but are not
limited to changes in (1) drawings, plans, designs, procedures, Specifications or test
specifications, (2) methods of packaging and shipment, (3) quantities of Liquidmetal Products to be
furnished, or (4) delivery schedule. If appropriate, Liquidmetal will prepare an Engineering Change
Order ("ECO"), and Eutectix will communicate to Liquidmetal any change in Prices and/or delivery
schedule. Each ECO shall be mutually agreed upon. Eutectix shall not make any changes to the design,
material, or process of manufacturing the Liquidmetal Products or any changes to the Specifications,
expect as may be agreed in writing by Liquidmetal in each instance. 8

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 9 -->
3.11 Supply. For avoidance of doubt, Liquidmetal may purchase Liquidmetal Products from third
parties other than Eutectix, and/or manufacture Liquidmetal Products itself. Liquidmetal makes no
commitment that it will purchase any particular volume of any Liquidmetal Products from Eutectix.
3.12 Quality Specifications. Eutectix shall comply with the quality specifications set forth by
Liquidmetal and/or the Customer and agreed to in an Order. Eutectix shall comply with the standards
set forth in ISO 9001. 3.13 Eutectix Warranty. Eutectix warrants that the Product (i) will conform
to the Specifications, (ii) will be free from manufacturing defects (including all defects in
workmanship and any defects in materials that were not specified by Liquidmetal or Customer), ) will
be free and clear of all liens, encumbrances, charges, claims, or adverse interests of any kind,
(iii) will comply with, in all stages of manufacture and distribution to Liquidmetal or Customer,
the terms of Section 10. The foregoing representations and warranties shall survive delivery,
inspection and payment and shall run in favor of Liquidmetal and its Affiliates, and their
respective successors, assigns and customers, both direct and indirect. 3.14 Return Process.
Liquidmetal and Eutectix shall concur in advance on all Liquidmetal Products to be returned for
repair or rework. All returns shall state the specific reason for such return, and will be processed
in accordance with the return policies and processes agreed to in writing by Eutectix and
Liquidmetal. Eutectix shall pay all transportation costs for valid returns of Liquidmetal Products
to Eutectix and for the shipment of repaired or replacement Liquidmetal Products to Customers, and
Eutectix shall bear all risk of loss or damage to such Liquidmetal Products while in transit. 3.15
Exclusions from Warranty. This warranty does not include remedy for defects in Liquidmetal Products
resulting from (a) Customer's design of Liquidmetal Products, (b) Eutectix's compliance with
Liquidmetal's Specifications, or (c) accident, disaster, neglect, abuse, misuse or improper handling
by Customer or Liquidmetal. 3.16 Organization and Qualification. Eutectix is an entity duly
incorporated or otherwise organized, validly existing and in good standing under the laws of the
jurisdiction of its incorporation or organization, with the requisite power and authority to own and
use its properties and assets and to carry on its business as currently conducted. Eutectix is not
in violation nor default of any of the provisions of its respective certificate or articles of
incorporation, bylaws or other organizational or charter documents. Eutectix is duly qualified to
conduct business and is in good standing as a foreign corporation or other entity in each
jurisdiction in which the nature of the business conducted or property owned by it makes such
qualification necessary, except where the failure to be so qualified or in good standing, as the
case may be, could not have or reasonably be expected to result in: (i) a material adverse effect on
the legality, validity or enforceability of any this Agreement, (ii) a material adverse effect on
the results of operations, assets, business, prospects or condition (financial or otherwise) of
Eutectix, or (iii) a material adverse effect on Eutectix's ability to perform in any material
respect on a timely basis its obligations under this Agreement (any of (i), (ii) or (iii), a
"Material Adverse Effect") and no proceeding has been instituted in any such jurisdiction revoking,
limiting or curtailing or seeking to revoke, limit or curtail such power and authority or
qualification. 9

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 10 -->
3.17 Solvency. Eutectix does not intend to incur debts beyond its ability to pay such debts as they
mature (taking into account the timing and amounts of cash to be payable on or in respect of its
debt). Eutectix has no knowledge of any facts or circumstances which lead it to believe that it will
file for reorganization or liquidation under the bankruptcy or reorganization laws of any
jurisdiction within one year from the Effective Date. 3.18 Remedy. THE WARRANTIES SET FORTH IN THIS
ARTICLE 3 ARE THE SOLE WARRANTIES GIVEN BY EUTECTIX AND ARE IN LIEU OF ANY OTHER WARRANTIES EITHER
EXPRESS OR IMPLIED. EUTECTIX DOES NOT MAKE ANY WARRANTIES REGARDING MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE. Eutectix agrees to indemnify, defend and hold the Liquidmetal Indemnified
Parties (as defined in Section 12.1) harmless from and against any and all claims, demands
liabilities, losses, costs and expenses (including without limitation, costs of investigation and
reasonable attorney's fees) irrespective of the theory upon which based, which Liquidmetal or any
other Liquidmetal Indemnified Party may suffer or incur as a result of any breach of the
representations or warranties of Eutectix set forth in this Article 3. 4. LIQUIDMETAL'S
REPRESENTATIONS AND WARRANTIES. 4.1 Liquidmetal represents and warrants that it owns all right,
title and interest in and to the Licensed Equipment, except for that equipment listed in Section
2.1(b). Liquidmetal represents and warrants that it has all necessary right and authority to deliver
and provide to Eutectix the Licensed Equipment for Eutectix's sole retention, possession and use as
permitted herein. Liquidmetal represents and warrants that it will perform no act or omission that
is inconsistent with Eutectix's retention, possession and use of the Licensed Equipment during the
Term. 4.2 Liquidmetal represents and warrants that there are no outstanding liens, security
interests, mortgages, claims, pledges, obligations or other encumbrances of any kind against the
Licensed Equipment and that Liquidmetal will not and will not permit any third party to place any
liens, security interests, mortgages, claims, pledges, obligations or other encumbrances of any kind
against the Licensed Equipment during the Term. 4.3 Liquidmetal represents and warrants that as
delivered to Eutectix, Liquidmetal is not aware of any claim or assertion by any third party that
the Licensed Equipment misappropriates or infringes upon any third party's Intellectual Property
rights. 4.4 Liquidmetal represents and warrants that as of the delivery date to Eutectix of the
Licensed Equipment, the Licensed Equipment was functional, operable, and usable. 4.5 Liquidmetal
represents and warrants that Liquidmetal Products do not misappropriate or infringe upon any third
party's Intellectual Property rights. Liquidmetal represents and warrants that it is not aware of
any claim or assertion by any third party that the Liquidmetal Products misappropriates or infringes
upon any third party's Intellectual Property rights. 4.6 Liquidmetal represents and warrants that it
will maintain the Affiliate License Agreement in full force and effect during the Term and will
perform no act or omission that would jeopardize the ongoing effectiveness of the Affiliate License
Agreement during the Term. 10

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 11 -->
4.7 Organization and Qualification. Liquidmetal is an entity duly incorporated or otherwise
organized, validly existing and in good standing under the laws of the jurisdiction of its
incorporation or organization, with the requisite power and authority to own and use its properties
and assets and to carry on its business as currently conducted. Liquidmetal is not in violation nor
default of any of the provisions of its respective certificate or articles of incorporation, bylaws
or other organizational or charter documents. Liquidmetal is duly qualified to conduct business and
is in good standing as a foreign corporation or other entity in each jurisdiction in which the
nature of the business conducted or property owned by it makes such qualification necessary, except
where the failure to be so qualified or in good standing, as the case may be, could not have or
reasonably be expected to result in: (i) a material adverse effect on the legality, validity or
enforceability of any this Agreement, (ii) a material adverse effect on the results of operations,
assets, business, prospects or condition (financial or otherwise) of Liquidmetal, or (iii) a
material adverse effect on Liquidmetal's ability to perform in any material respect on a timely
basis its obligations under this Agreement (any of (i), (ii) or (iii), a "Material Adverse Effect")
and no proceeding has been instituted in any such jurisdiction revoking, limiting or curtailing or
seeking to revoke, limit or curtail such power and authority or qualification. 4.8 Solvency.
Liquidmetal does not intend to incur debts beyond its ability to pay such debts as they mature
(taking into account the timing and amounts of cash to be payable on or in respect of its debt).
Liquidmetal has no knowledge of any facts or circumstances which lead it to believe that it will
file for reorganization or liquidation under the bankruptcy or reorganization laws of any
jurisdiction within one year from the Effective Date. 4.9 THE WARRANTIES SET FORTH IN THIS ARTICLE 4
ARE THE SOLE WARRANTIES GIVEN BY LIQUIDMETAL AND ARE IN LIEU OF ANY OTHER WARRANTIES EITHER EXPRESS
OR IMPLIED. LIQUIDMETAL DOES NOT MAKE ANY WARRANTIES REGARDING MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE. Liquidmetal agrees to indemnify, defend and hold the Eutectix Indemnified
Parties (as defined in Section 12.2) harmless from and against any and all claims, demands
liabilities, losses, costs and expenses (including without limitation, costs of investigation and
reasonable attorney's fees) irrespective of the theory upon which based, which Eutectix or any other
Eutectix Indemnified Party may suffer or incur as a result of any breach of the representations and
warranties of Liquidmetal set forth in this Article 4. 5. AGREEMENT TERMINATION. 5.1 Termination for
Cause. Either Party may terminate this Agreement hereunder for default if the other Party materially
breaches this Agreement; provided, however, no termination right shall accrue until thirty (30) days
after the defaulting Party is notified in writing of the material breach and has failed to cure
within the thirty (30) day period after notice of a material breach. 5.2 Termination for
Convenience. Either Party may terminate this Agreement for any reason upon providing 180 days prior
written notice to the other Party prior to the expiration of the then-current term or unless sooner
terminated in accordance with the terms of this Agreement. 11

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 12 -->
5.3 Termination by Operation of Law. This Agreement shall immediately and automatically terminate
should either Party (a) become insolvent; (b) enter into or file a petition, arraignment or
proceeding seeking an order for relief under bankruptcy laws of its respective jurisdiction; (c)
enter into receivership of any of its assets; or (d) enter into a dissolution or liquidation of its
assets or an assignment for the benefit of its creditors. 5.4 Consequences of Termination. In the
event this Agreement expires or is terminated for any reason other than a breach by Eutectix,
Liquidmetal shall purchase from Eutectix existing raw material inventory at the purchase price
(including delivery charges) paid by Eutectix to its suppliers in connection with the Orders
accepted by Eutectix hereunder. Upon expiration or termination of this Agreement: (a) Liquidmetal
shall i. Pay Eutectix any amounts rightfully owing under each outstanding Order in accordance with
the payment terms set forth in this Agreement; ii. Subject to Eutectix's right to finish
manufacturing work in process as set forth below, have the unconditional right to possess or
repossess the Licensed Equipment (as defined in Section 2.1) and take all actions it deems
appropriate to effect such possession or repossession at its own cost; and (b) Eutectix shall
immediately i. cease all activities under this Agreement (including exercising its rights under the
licenses granted hereunder), unless and to the extent otherwise agreed or requested in writing by
Liquidmetal; ii. Notwithstanding the foregoing, with regard to orders received and accepted by
Eutectix before expiration or notice of termination, Eutectix may finish making any products in
process, may conclude any orders in process, including finishing manufacturing of such products and
shipping such products to the customer for up to 6 months after termination or expiration of this
Agreement; iii. Comply with Section 9.2 and iv. transfer title and deliver to Liquidmetal, in the
manner and to the extent requested in writing by Liquidmetal, such completed or partially completed
Liquidmetal Products, drawings and other information Eutectix has produced or acquired in connection
with this Agreement. Liquidmetal shall not be responsible to Eutectix for any compensation,
reimbursement, profits, expenses, losses or damages whatsoever as a result of any expiration or
termination of the Agreement. Any such expiration or termination shall be without prejudice to any
other rights and remedies that Liquidmetal may be entitled to at law or in equity. 12

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 13 -->
5.5 Right to Purchase. Upon expiration or termination of this Agreement for any reason, Eutectix
shall have the option to purchase some or all of the Licensed Equipment at fair market value, less
any amounts owed to Eutectix by Liquidmetal, except the equipment listed under Section 2.1(b) above.
The following additional terms shall apply to Eutectix's exercise of this option: (a) Eutectix's
option hereunder shall be exercisable by providing Liquidmetal with written notice of its intention
to exercise its chosen option no later than the effective date of termination. Such notice shall
include a description of the assets Eutectix will purchase (the "Optioned Assets"). (b) In the event
that Eutectix and Liquidmetal cannot agree to a fair market value for the Optioned Assets, then the
fair market value shall be determined by an independent third-party appraisal. Eutectix and
Liquidmetal shall each select one independent, qualified appraiser, and the two so selected shall
select a third appraiser, all three to independently from one another determine the fair market
value of the Optioned Assets. The purchase price shall be the mean of the fair market values as
determined by the three appraisers. (c) The closing for the purchase of the Optioned Assets will
take place no later than sixty (60) days after the termination, unless the Parties cannot agree on
the price, in which case, closing will take place no later than sixty (60) days after the three
independent appraisals have been received. Eutectix will pay the purchase price in full at the
closing. Liquidmetal must sign all documents of assignment and transfer as are reasonably necessary
for purchase of the Optioned Assets by Liquidmetal. (d) In the event that Eutectix does not exercise
its right to purchase the Optioned Assets as set forth above, Liquidmetal will be free to keep or to
sell, after such termination to any third party, all of the Optioned Assets and shall be responsible
for timely removing equipment not purchased by Eutectix at Liquidmetal's own expense. In the event
Liquidmetal fails to timely remove such Optioned Assets, in light of the periods for continued
operation in Section 5.4(b)(ii) and closing in Section 5.5(c), Eutectix may dispose of them, at
Liquidmetal's cost, with no liability to Eutectix. 5.6 Survival. The terms of this Agreement that by
their nature or their express terms are intended to survive its expiration or termination (including
without limitation, indemnification, warranty, insurance, bailment, and confidentiality provisions),
and any and all rights, remedies and obligations that arose or are incurred prior to expiration or
termination, shall survive expiration or termination of this Agreement. 6. TRAINING AND OTHER
SERVICES. 6.1 Training and Technical Assistance. At any time within one (1) year of the Effective
Date, upon request by Eutectix, Liquidmetal shall remotely supply such of its then-existing
engineering, facilities, or manufacturing experts to Eutectix, as shall be reasonably necessary to
assist in the safe and effective installation, operation, troubleshooting, and maintenance of the
Licensed Equipment. In the same period, upon request by Eutectix, and subject to availability,
Liquidmetal shall provide on-site support of the same kind. Eutectix shall pay to Liquidmetal the
reasonable documented travel and accommodation expenses associated with such on-site service. 6.2
DFM. Upon request by Eutectix, Liquidmetal, at its own cost, shall provide engineering support for
the design of Liquidmetal Products and equipment molds for optimal manufacturability (that is,
engineering the design of the Product in such a way that the Product is easy to manufacture). 13

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 14 -->
6.3 Research, Development, and Collaboration. Eutectix will meet with Liquidmetal on at least an
annual basis to discuss ways in which Eutectix and Liquidmetal can collaborate on advancements and
improvements to the composition, processing, and application of bulk metallic glasses and composites
and derivatives thereof, and Eutectix will make available to Liquidmetal any information regarding
processing technologies, bulk metallic glasses, amorphous alloys, and derivatives and compositions
and improvements thereto used by Eutectix in the manufacture of Liquidmetal Products. The
information exchanged at such meetings will be owned in accordance with Article 8. 7. FORCE MAJEURE.
7.1 Force Majeure Event. For purposes of this Agreement, a "Force Majeure Event" shall mean the
occurrence of unforeseen circumstances beyond a Party's control and without such Party's negligence
or intentional misconduct, including, but not limited to, any act by any governmental authority, act
of war, natural disaster, strike, boycott, embargo, shortage, riot, lockout, labor dispute, and
civil commotion. 7.2 Notice of Force Majeure Event. Neither Party shall be responsible for any
failure to perform due to a Force Majeure Event provided that such Party gives notice to the other
Party of the Force Majeure Event as soon as reasonably practicable, but not later than fifteen (15)
days after the date on which such Party knew of the commencement of the Force Majeure Event,
specifying the nature and particulars thereof and the expected duration thereof. 7.3 Termination of
Force Majeure Event. The Party claiming a Force Majeure Event shall use reasonable efforts to
mitigate the effect of any such Force Majeure Event and to cooperate to develop and implement a plan
of remedial and reasonable alternative measure to remove the Force Majeure Event. Upon the cessation
of the Force Majeure Event, the Party affected thereby shall immediately notify the other Party of
such fact, and use its best efforts to resume normal performance of its obligations under the
Agreement as soon as possible. 7.4 Limitations. Notwithstanding that a Force Majeure Event otherwise
exists; the provisions of this Article shall not excuse (i) any obligation of either Party that
arose before the occurrence of the Force Majeure Event causing the suspension of performance; or
(ii) any late delivery of Product caused solely by negligent acts or omissions on the part of such
Party. 7.5 Termination for Convenience. In the event a Party fails to perform any of its obligations
for any reasons defined in this Article 7 for a cumulative period of ninety (90) days or more from
the date of such Party's notification to the other Party, then the other Party at its option may
extend the corresponding delivery period for the length of the delay, or terminate this upon written
notice. 14

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 15 -->
8. OWNERSHIP OF INTELLECTUAL PROPERTY. 8.1 Definitions. 8.1.1 For purposes of this Agreement,
"Amorphous Alloy" means any one or more amorphous alloys or bulk metallic glasses (or composite
materials containing amorphous alloys or bulk metallic glasses) limited to the Liquidmetal Products,
amorphous alloys marketed or sold under the Liquidmetal® brand, and Licensed Products. 8.1.2
"Intellectual Property" means any and all inventions (whether or not protected or protectable under
patent laws), works of authorship, information fixed in any tangible medium of expression (whether
or not protected or protectable under copyright laws), moral rights, trade secrets, developments,
designs, applications, processes, know-how, discoveries, ideas (whether or not protected or
protectable under trade secret laws), and all other subject matter protected or protectable under
Patent, copyright, moral right, trademark, trade secret, or other laws, including, without
limitation, all new or useful art, combinations, formulae, manufacturing techniques, technical
developments, applications, data and research results. 8.1.3 "New Amorphous Alloy Technology" means,
to the extent developed or acquired after the Effective Date by a Party, alone, with the other Party
or with a third party, in connection with Orders under this Agreement, the Licensed Patents, or the
Licensed Technical Information, all Amorphous Alloys and/or all Intellectual Property relating to
the composition, processing, properties, or applications of Amorphous Alloys, and all patents
therefor, including, but not limited to, improvements to patents. (a) "New Alloy Technology" means a
New Amorphous Alloy Technology that concerns only the composition, properties, or raw material
processing of Amorphous Alloys. (b) "New Process Technology" means a New Amorphous Alloy Technology
that concerns only the process of converting Amorphous Alloy raw material into usable or saleable
parts or components, or equipment related thereto. (c) "New Application Technology" means a New
Amorphous Alloy Technology that concerns only customer end-uses for parts and components
manufactured of Amorphous Alloys. 8.2 New Technology Ownership. Ownership over New Amorphous Alloy
Technologies shall be determined as follows: 8.2.1 New Alloy Technology. New Alloy Technologies that
have been developed by a Party alone or with a third party shall be solely owned by the developing
Party. New Alloy Technologies that have been developed by cooperation of the Parties shall be
jointly and equally owned by the Parties, and any royalties for the use thereof by third parties
shall be shared equitably between the Parties. The Parties shall work cooperatively toward the
appropriate patent or other legal protection of such jointly and equally owned Intellectual
Property. 15

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 16 -->
8.2.2 New Process Technology. New Process Technologies that have been developed by Liquidmetal,
alone or with a third party, shall be solely owned by Liquidmetal. New Process Technologies that
have been developed by Eutectix, alone or with a third party, shall be solely owned by Eutectix,
and, if permitted, Eutectix shall grant Liquidmetal a license to such New Process Technologies as
set forth in Section 8.3 below. New Process Technologies that have been developed by cooperation of
the Parties shall be jointly and equally owned by the Parties, and any royalties for the use thereof
by third parties shall be shared equitably between the Parties. The Parties shall work cooperatively
toward the appropriate patent or other legal protection of such jointly and equally owned
Intellectual Property. 8.2.3 New Application Technology. New Application Technologies that have been
developed by Liquidmetal, alone or with a third party, shall be solely owned by Liquidmetal. New
Application Technologies that have been developed by Eutectix shall be solely owned by Eutectix, and
Eutectix shall negotiate with Liquidmetal a license to such New Application Technologies as set
forth Section 8.4 below. New Application Technologies that have been developed by Eutectix with a
third party shall be owned by Eutectix and the third party, and, if permitted by such third party,
Eutectix shall negotiate with Liquidmetal a license to such New Application Technology as set forth
in Section 8.4 below in the case that (i) Eutectix retains the authority to grant a such license,
and (ii) the New Application Technology is derived in whole or in part from Liquidmetal Intellectual
Property. New Application Technologies that have been developed by cooperation of the Parties shall
be jointly and equally owned by the Parties, and any royalties for the use thereof by third parties
shall be shared equitably between the Parties. The Parties shall work cooperatively toward the
appropriate patent or other legal protection of such jointly and equally owned Intellectual
Property. 8.3 New Process Technology License. Eutectix hereby grants to Liquidmetal a fully-paid up,
royalty-free, perpetual, world-wide, non-exclusive license to any New Process Technologies in which
Eutectix acquires licensing rights pursuant to Section 8.2 above. 8.4 New Application Technology
License Negotiation. The Parties shall negotiate in good faith a royalty-bearing, perpetual,
world-wide, non-exclusive license to any New Application Technology in which they acquire rights as
set forth in Section 8.2.3 above. Royalties and other terms shall be commercially reasonable and
negotiated by the Parties in good faith. 8.5 Assignment & Cooperation. To the extent that the
Parties have jointly developed any New Amorphous Alloy Technology and they have agreed that such New
Amorphous Alloy Technology will be jointly owned, as set forth in Section 8.2 above, each Party
hereby assigns to the other, and will cause its employees, contractors, representatives, successors,
assigns, Affiliates, parents, subsidiaries, officers and directors to assign to the other, a
co-equal right, title and interest in and to any such jointly developed New Amorphous Alloy
Technology. The parties agree to cooperate and cause their employees and contractors to cooperate in
the preparation and prosecution of patent applications relating to any joint development work
concerning New Process Technology or New Application Technology. 16

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 17 -->
9. CONFIDENTIALITY. 9.1 Certain Definitions. For purposes hereof, "Confidential Information" shall
mean any and all commercial, technical, financial, proprietary, and other information relating to a
Discloser, its Affiliates, and their respective business operations, including, but not limited to,
samples, data, technical information, know-how, formulas, ideas, inventions, discoveries, patents,
patent applications, Intellectual Property, product development plans, demonstrations, business and
financial information, applications and designs, and all manifestations or embodiments relating to
the foregoing and all improvements made thereto, in whatever form provided, whether oral, written,
visual, machine-readable, electronic, or otherwise. "Confidential Information" also includes any
information described above which a Discloser obtains from a third party and which the Discloser
treats as proprietary or designates as confidential, whether or not owned or developed by the
Discloser. "Discloser" shall mean the Party that is disclosing Confidential Information under this
Agreement, regardless of whether such Confidential Information is being provided directly by such
Party, by a Representative of the Party, or by any other person that has an obligation of
confidentiality with respect to the Confidential Information being disclosed. "Recipient" shall mean
the Party receiving Confidential Information that is protected under this Agreement.
"Representatives" shall mean the respective directors, officers, employees, financial advisors,
accountants, attorneys, agents, and consultants of a Party. 9.2 Restrictions and Covenants. Except
as otherwise provided herein, each Party agrees that, in its capacity as the Recipient of
Confidential Information, it will (i) hold the Discloser's Confidential Information in strict
confidence, use a high degree of care in safeguarding the Discloser's Confidential Information, and
take all precautions necessary to protect the Discloser's Confidential Information including, at a
minimum, all precautions the Recipient normally employs with respect to its own Confidential
Information, (ii) not divulge any of the Discloser's Confidential Information or any information
derived therefrom to any other person (except as set forth in Section 9.3 hereof), (iii) not make
any use whatsoever at any time of the Discloser's Confidential Information except as is necessary in
the performance of Recipient's specific duties under this Agreement, (iv) not copy, reverse
engineer, alter, modify, break down, melt down, disassemble or transmit any of the Discloser's
Confidential Information, (v) not, within the meaning of United States or other export control laws
or regulations, export or re-export, directly or indirectly, including but not limited to export on
the Internet or other network service, any of the Discloser's Confidential Information, (vi) notify
the Discloser in writing immediately upon discovery by the Recipient or its Representatives of any
unauthorized use or disclosure of the Discloser's Confidential Information, and (vii) upon the
termination or expiration of this Agreement, immediately return to the Discloser or destroy (at the
option of the Recipient) all such Confidential Information, including all originals and copies. 9.3
Disclosure to Representatives. The Recipient may only disseminate the Discloser's Confidential
Information to its Representatives who have been informed of the Recipient's obligations under this
Agreement and are bound by an obligation of confidentiality and non-use with respect to the
Discloser's Confidential Information at least as broad in scope as the Recipient's obligations under
this Agreement. The Recipient agrees to reasonably restrict disclosure of the Discloser's
Confidential Information to the smallest number of the Recipient's Representatives which have a need
to know the Confidential Information. The Recipient shall be responsible for enforcing this
Agreement as the Recipient's Representatives and shall take such action (legal or otherwise) to the
extent necessary to cause them to comply with this agreement. 9.4 Enforcement. The Recipient
acknowledges and agrees that due to the unique nature of the Licensed Technical Information and
other Confidential Information of the Discloser, there can be no adequate remedy at law for any
breach of its obligations hereunder, which breach may result in irreparable harm to the Discloser,
and therefore, that upon any such breach or any threat thereof, the Discloser shall be entitled to
appropriate equitable relief, including injunction, without the requirement of posting a bond, in
addition to whatever remedies it might have at law. 17

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 18 -->
9.5 Exceptions. The restrictions of the Recipient's disclosure and use of the Discloser's
Confidential Information under this Article 9 will not apply to the extent of any Confidential
Information: (a) that becomes publicly known without breach of the Recipient's or its
Representatives' obligations under this Agreement; (b) that is rightfully acquired by Recipient from
a third party which is not subject to any restriction or obligation (whether contractual, fiduciary,
or otherwise) on disclosure or use of such Confidential Information; (c) that is independently
developed by employees of the Recipient without knowledge of or reference to such Confidential
Information, as evidenced by written documentation or other tangible evidence of Recipient; (d) that
is required to be disclosed by law or by court order or government order, provided that the
Recipient (a) promptly notifies the Discloser of any such disclosure requirement so that the
Discloser may seek an appropriate protective order (or other appropriate protections) and (b)
provides reasonable assistance (at no cost to the Recipient) in obtaining such protective order or
other form of protection; or (e) as to which and to the extent to which the Recipient has received
express written consent from an authorized officer of the Discloser to disclose or use. 10.
COMPLIANCE. 10.1 Laws. Eutectix and its operations, facilities and business shall at all times
comply with all applicable federal, national, state, provincial and local laws (including common
law), statutes, ordinances, orders, rules, codes, standards and regulations of the U.S.A., the
country(ies) in which Eutectix or its operations or facilities are located, customs and export
controls, and all other relevant jurisdictions (each individually a "Law" and collectively "Laws"),
including without limitation Environmental Laws as defined below. 10.2 Customs. Eutectix shall
provide Liquidmetal with all information, certificates and records relating to the Liquidmetal
Products (including Certificates of Origin) as necessary for Liquidmetal to: (a) fulfill any customs
obligations, origin marking or labeling requirements, and certification or local content reporting
requirements; (b) claim preferential duty treatment under applicable trade preference regimes; and
(c) participate in any duty deferral or free trade zone programs of the country of import.
Liquidmetal shall obtain all pre-delivery export licenses and authorizations and pay all
pre-delivery export taxes, duties, and fees. 10.3 Environmental Laws. Eutectix shall promptly
furnish to Liquidmetal upon request from time to time all information evidencing Eutectix's
compliance with Laws, including Environmental Laws. "Environmental Laws" are Laws pertaining to the
environment and its protection, and the toxic or hazardous nature of products or their constituents,
and any other environmental, toxic or hazardous product compliance Laws and obligations. Eutectix
represents and warrants that the Liquidmetal Products do not and shall not contain asbestos, and do
not and shall not contain mercury or other chemicals, metals, or minerals in excess of amounts (if
any) permitted by Laws. If Eutectix supplies Liquidmetal or its Customers with Liquidmetal Products
containing hazardous materials as defined by Environmental Laws, including the provisions
promulgated by the U.S. Department of Transportation, Eutectix shall warn, label, and ship such
hazardous materials in accordance with Environmental Laws. Upon shipment and on an ongoing basis,
Eutectix shall provide Liquidmetal with current Safety Data Sheets and all other information needed
to comply with all Environmental Laws. Eutectix shall have no liability to or on behalf of
Liquidmetal for any failure by Liquidmetal to comply with any Environmental Law. 18

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 19 -->
10.4 Product Corrective Actions. Each Party shall immediately notify the other Party, in writing, if
it becomes aware of any circumstances indicating that a stop sale, Liquidmetal Product recall,
corrective action, Liquidmetal Product or quality control action or retrofit, or regulatory action
involving any Liquidmetal Products sold by Eutectix to Liquidmetal or its dealers or customers
(each, a "Product Corrective Action") may be necessary under Laws or otherwise appropriate.
Liquidmetal shall, to the extent practicable, provide to Eutectix for review any relevant data and
comment upon any potential Product Corrective Action, and Liquidmetal and Eutectix will mutually
decide when to conduct a Product Corrective Action and the scope of any such Product Corrective
Action. 10.5 Anti-Bribery; Anti-Corruption. In addition to its other obligations under this
Agreement, Eutectix will strictly comply with both the letter and the spirit of all Laws concerning
corrupt practices, "anti-bribery", or which in any manner prohibit the giving of anything of value
to any official, agent or employee of any government, political party or public international
organization, including without limitation the U.S. Foreign Corrupt Practices Act, the UK Bribery
Act and similar Laws of other countries. Eutectix represents and warrants to Liquidmetal that: (a)
neither Eutectix nor any of its officers, directors, employees, representatives or agents will
offer, promise, or give anything of value to a government official or an employee of a state-owned
or controlled enterprise, or authorize the foregoing, directly or indirectly, in order to influence
such a person to act or refrain from acting in the exercise of his/her official duties with respect
to this Agreement; (b) Eutectix and its officers, directors, employees, representatives and agents
will use only ethical, legitimate and legal business practices in commercial operations and in
promoting the position of Liquidmetal on issues before governmental authorities (it being understood
that Eutectix shall not promote any position of Liquidmetal before any such authorities unless
Liquidmetal has specifically directed Eutectix in writing to do so); and that it and its officers,
directors, employees, representatives and agents will comply with all applicable anti-corruption
Laws; (c) Eutectix and its officers, directors, employees, representatives and agents will never
bribe any employees of Liquidmetal by any means, including but not limited to providing or promising
to provide an off-the-book rebate in secret, entertainment allowance, employment arrangement, travel
home, present, discount for shopping, or any other material benefits for the employees of
Liquidmetal or their relatives; Eutectix will also refuse any improper interests in any form
required or requested by any of the employees of Liquidmetal and will provide relevant evidence to
assist Liquidmetal to investigate and take action with respect to any such activities; and (d)
Eutectix shall keep its books and records in such a fashion that its compliance with this Article
may be readily audited. 19

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 20 -->
10.6 Components Disclosure; Special Warnings. If requested by Liquidmetal from time to time,
Eutectix shall promptly furnish Liquidmetal in such form and detail as Liquidmetal may direct: (a) a
bill of materials for or list of all ingredients, components or constituents in the Liquidmetal
Products purchased hereunder, (b) the amount of one or more of such ingredients, components or
constituents, and (c) information concerning any changes in or additions to any such ingredients,
components or constituents. 11. AUDIT RIGHTS. Upon reasonable prior notice to Eutectix and at
Liquidmetal's expense, no more than once per year, during the Term of this Agreement and for one (1)
year following the expiration or termination of this Agreement, Liquidmetal or its designee shall
have the right from time to time to confirm and validate: (a) that Eutectix has complied with the
pricing provisions of this Agreement; (b) Eutectix's financial condition, successorship planning,
and ability to continue operations; (c) that Eutectix's performance is consistent with the
Agreement; (d) that Eutectix has complied with Article 10 (Compliance) of this Agreement. Upon
reasonable and prior notice to Eutectix, Eutectix will also provide Liquidmetal or its designee from
time to time with reasonable access to Eutectix's facility and the facilities of its sub-suppliers
and other subcontractors to permit Liquidmetal to inspect the production, handling, and storage of
Liquidmetal Products and the Licensed Equipment and inventories of raw materials and components.
Eutectix shall maintain an orderly storage bookkeeping so that the respective inventory of the
Licensed Equipment, Liquidmetal Products and property of Liquidmetal can be immediately recognized;
and (e) such confirmation and validation to be conducted with minimal disruption to Eutectix's
business operations and all information disclosed during such exercise to be deemed to be
Confidential Information. 12. INSURANCE AND INDEMNIFICATION. 12.1 Indemnification by Eutectix.
Eutectix shall indemnify, defend, and hold harmless Liquidmetal and its Affiliates, and its and
their respective directors, officers, employees, agents, insurers, Customers (both direct and
indirect), successors and assigns (collectively, the "Liquidmetal Indemnified Parties"), from and
against any and all claims, losses, liabilities, damages and expenses (including without limitation
attorneys' fees and legal costs and all costs associated with Product Corrective Actions that are a
result or consequence of any negligent or willful misconduct of Eutectix) that they, or any of them,
may sustain or incur as a result of (a) any actual or alleged breach of any representation, warranty
or covenant made by Eutectix in this Agreement (including its Schedules); or (b) any actual or
alleged injury to or death of any person, or any actual or alleged damage to or loss of any
property, arising out of (i) any Liquidmetal Products or Licensed Products sold by Eutectix under
the Agreement or that are in the possession or under the control of Eutectix, its employees, agents,
sub-suppliers or other subcontractors, except to the extent of Liquidmetal's negligence or willful
misconduct, or (ii) any services performed by Eutectix, its employees, agents, sub-suppliers or
other subcontractors; or (c) the negligent acts or omissions, intentional misconduct, or breach of
contract of or by Eutectix, its employees, agents, sub-suppliers or other subcontractors; or (d) any
infringement by Eutectix's Intellectual Property on the Intellectual Property rights of a third
party. 20

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 21 -->
12.2 Indemnification by Liquidmetal. Liquidmetal shall indemnify, defend, and hold harmless Eutectix
and its Affiliates, and its and their respective directors, officers, employees, agents, insurers,
Customers (both direct and indirect), successors and assigns (collectively, the "Eutectix
Indemnified Parties"), from and against any and all claims, losses, liabilities, damages and
expenses (including without limitation attorneys' fees and legal costs and all costs associated with
Product Corrective Actions that are a result or consequence of any negligent or willful misconduct
of Liquidmetal) that they, or any of them, may sustain or incur as a result of (a) any actual or
alleged breach of any representation, warranty or covenant made by Liquidmetal in this Agreement
(including its Schedules); or (b) any actual or alleged injury to or death of any person, or any
actual or alleged damage to or loss of any property, arising out of (i) any Liquidmetal Products
designed by Liquidmetal or that are in the possession or under the control of Liquidmetal, its
employees, agents, sub-suppliers or other subcontractors, except to the extent of Eutectix's
negligence or willful misconduct, or (ii) any services performed by Liquidmetal, its employees,
agents, sub-suppliers or other subcontractors; or (c) the negligent acts or omissions, intentional
misconduct, or breach of contract of or by Liquidmetal, its employees, agents, sub-suppliers or
other subcontractors; or (d) any infringement by Liquidmetal's Intellectual Property on the
Intellectual Property rights of a third party. 12.3 Insurance. Eutectix shall obtain, pay for, and
maintain insurance meeting or exceeding the minimum insurance requirements set forth on Schedule 2
attached hereto, with policy terms satisfactory to Liquidmetal. 13. LIMITATION OF LIABILITY. NEITHER
PARTY SHALL BE LIABLE TO OTHER PARTY FOR ANY LOST PROFITS, LOST REVENUES, OR ANY OTHER INCIDENTAL,
INDIRECT, PUNITIVE, SPECIAL OR CONSEQUENTIAL DAMAGES WHATSOEVER ARISING OUT OF THIS AGREEMENT OR ANY
ORDER, OR OUT OF THE PERFORMANCE OR BREACH OF THIS AGREEMENT OR ANY ORDER, EVEN IF THE PARTY HAS
BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 14. MISCELLANEOUS. 14.1 Entire Agreement. This
Agreement, including its Schedules, which are attached hereto and incorporated herein, constitutes
the entire understanding and agreement of the Parties with respect to the subject matter hereof, and
supersedes all prior and contemporaneous agreements, understandings, inducements or conditions,
expressed or implied, written or oral, between the Parties relating to the subject matter hereof. No
additional or different terms contained in any sales order, Quotes, acknowledgement, invoice or
other communications. This Agreement shall not be changed or modified except by written agreement
signed by Liquidmetal and Eutectix. 21

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 22 -->
14.2 Orders of Precedence. All Quotes, Orders, acknowledgements and invoices issued pursuant to this
Agreement are issued for convenience of the Parties only and shall be subject to, and governed by,
the provisions of this Agreement. 14.3 Assignment. Neither this Agreement nor any rights or
obligations hereunder shall be transferred or assigned by either Party without the written consent
of the other Party, which consent shall not be unreasonably withheld; provided, however, that
Liquidmetal shall have the right, without the prior written consent of Eutectix, to assign its
warranty rights and other rights hereunder with respect to specific Liquidmetal Products to the
Customers of such Liquidmetal Products. 14.4 Severability. If any provision of this Agreement, or
the application thereof, shall for any reason and to any extent be invalid or unenforceable, the
remainder of this Agreement and application of such provision to other persons or circumstances
shall be interpreted so as best to reasonably effect the intent of the Parties hereto. The Parties
further agree to replace such void or unenforceable provision with a provision which will achieve,
to the extent possible, the economic, business and other purposes of the void or unenforceable
provision. 14.5 Notices. Wherever one Party is required or permitted or required to give written
notice to the other under this Agreement, such notice will be given by hand, by certified U.S. mail,
return receipt requested, by overnight courier, or by fax and addressed as follows: If to
Liquidmetal: Liquidmetal Technologies, Inc. Attn: CEO and/or President 20321 Valencia Cir Lake
Forest, CA 92630 Facsimile: (949) 635-2188 If to Eutectix: Eutectix, LLC 323 Main St. Chatham, NJ
07928 Attention: Fax: Email: 14.6 Definition of "Affiliate". For purposes of this Agreement, the
term "Affiliate" means, with respect to any specified person or entity, any corporation, limited
liability company or other legal entity which directly or indirectly controls, is controlled by, or
is under common control with specified person or entity or its successors or assigns. For the
purposes of this Agreement, "control" shall mean the direct or indirect ownership of more than fifty
percent (50%) of the outstanding shares on a fully diluted basis or other voting rights of the
specified entity to elect directors or managers, or the right to direct or cause the direction of
the management and policies of the specified entity whether by contract or otherwise; and the terms
"controlling" and "controlled" have meaning correlative to the foregoing. 14.7 Further Assurances.
Each Party agrees to cooperate fully with the other and to execute such further instruments,
documents and agreements and to give such further written assurances, as may be reasonably requested
by another Party to better evidence and reflect the transactions described herein and contemplated
hereby, and to carry into effect the intents and purposes of this Agreement. 22

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 23 -->
14.8 Disputes. The parties irrevocably agree that any legal actions or proceedings brought by or
against them with respect to this Agreement shall be brought exclusively in the courts in and for
Maricopa County, Arizona, and the United States District Court for the District of Arizona, and by
execution and delivery hereof, the parties irrevocably submit to such jurisdiction and hereby
irrevocably waive any and all objections which they may have with respect to venue in any of the
above courts. Notwithstanding the foregoing, this paragraph shall not preclude or limit either
Party's rights to pursue actions in the International Trade Commission, or for either Party to
pursue an action with respect to a Licensed Patent before a foreign court or governmental agency if
neither the federal courts nor the state courts have subject matter jurisdiction over the action.
This Agreement, the legal relations between the parties, and any action, whether contractual or
non-contractual, instituted by any party with respect to matters arising under or growing out of or
in connection with or in respect of this Agreement shall be governed by and construed in accordance
with the internal laws of the State of Arizona (U.S.A.), excluding any choice of law rules that may
direct the application of the laws of another jurisdiction, and except that questions affecting the
construction and effect of any Patent shall be determined by the law of the country in which the
Patent has been granted. The parties agree that the United Nations Convention on Contracts for the
International Sale of Goods (1980) is specifically excluded from application to this Agreement. THE
PARTIES HEREBY EXPRESSLY WAIVE ANY AND ALL RIGHT TO A TRIAL BY JURY WITH RESPECT TO ANY ACTION,
PROCEEDING OR OTHER LITIGATION RESULTING FROM OR INVOLVING THE ENFORCEMENT OF THIS AGREEMENT. IN
WITNESS WHEREOF, the Parties hereto have caused this Agreement to be executed as of the Effective
Date, by their officers, duly authorized. EUTECTIX, LLC LIQUIDMETAL TECHNOLOGIES, INC. By: /s/ Barry
D. Russell By: /s/ Isaac Bresnick Name: Barry D. Russell Name: Isaac Bresnick Title: Chief Executive
Officer Title: Executive Administrator 23

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 24 -->
Schedule 1 Field of Use Restrictions The licenses granted under this Agreement shall be subject to
the following exclusions, conditions, restrictions, and limitations: 1. The "Field" shall exclude
the following products and fields of use: a. Any Consumer Electronic Products (as defined below) or
any components or sub-components suitable for use with any Consumer Electronic Products. For this
purpose, "Consumer Electronic Products" means personal computers (portable and desktop); tablet or
slate style computing devices; handheld electronic and/or communication devices (e.g., smartphones,
digital music players, multi-function devices, etc.); any device whose function includes the
creation, storage or consumption of digital media; any component or sub-component in any Consumer
Electronic Product; and any accessory that is the same or similar (in the sole discretion of Apple,
Inc.) to an accessory made or sold by or on behalf of Apple (regardless of when Apple sold or
started to sell such accessory, including after date of the closing of the Proposed Transaction)
that is suitable for use with any Consumer Electronic Product. b. Any watches or components for
watches. c. Finished or semi-finished Jewelry, and also any other products that are sold under the
name of a Luxury Brand or incorporated into products that are sold under the name of a Luxury Brand,
including without limitation (a) buckles for belts, briefcases, handbags, and clothing; and (b)
cigarette lighters and cigar cutters. For purposes hereof, the term "Jewelry" means rings,
necklaces, pins, cufflinks, and other objects that are ornamental in nature and used for adornment
of the human body. "Luxury Brands" shall not include brands owned or used by Nokia, Motorola,
Samsung, LG, Sony-Ericsson, Apple, RIM, HTC or similar companies that supply mobile phones and
accessories to the mass-market. Otherwise, "Luxury Brands" consist of the following brands and any
other similar, renowned luxury brand which is used as the sole or primary brand on a competitive
product sold at similar price point: LVMH Moet Hennessey Rolex Chanel Bentley Motors Chopard
Compagnie Financiere Richemont Gucci Group Hermes IWC Jaeger LeCoultre Mercedes Benz Porsche ST
DuPont The Swatch Group 24

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 25 -->
Tiffany & Co. IWC Cartier Montblanc TAG Heuer Louis Vuitton Bvlgari CHANEL Prada Dunhill Aspreys
Porsche Ferrari Sellita Group Safilo Group Luxottica Group Ventura Ellicot 2. The licenses to
Eutectix shall exclude any patents, technical information, know-how, or other Intellectual Property
that Liquidmetal licenses from a third party (other than a third party that is an Affiliate of
Liquidmetal) if and to the extent that the terms of the third- party license would prohibit the
sublicensing of such Intellectual Property hereunder. 3. The Field shall exclude any products or
services that are intended for use in, or likely to be used in, military or weapons/munitions
applications, other than with the prior written consent of Liquidmetal. Such written consent shall
not be unreasonably withheld, conditioned or delayed. 4. The licenses granted to Eutectix hereunder
shall be subject to and limited by (and shall contain any exclusions required by) any applicable
state or federal legal or regulatory requirements of any state or federal governmental or regulatory
body. Specifically, the licenses granted hereunder, and the Field shall exclude, any Intellectual
Property that would require an export license under the United States Export Administration
Regulations (EAR) (15 CFR §§ 734.2(b)(2)(ii) and 734.2(b)(4)) or that would require any other
consent or authorization of any United States federal or state governmental or regulatory body,
unless and until the required export license or other governmental or regulatory consent or
authorization is obtained, to the extent that the licenses concern the equipment listed under
Section 2.1(b) of this Agreement. 5. Licensed Products may not be sold to any customer in, or to any
customer for distribution into, the following countries, without Liquidmetal's prior written
consent, which consent shall not be unreasonably withheld, conditioned or delayed: Brunei, Cambodia,
China (P.R.C and R.O.C.), East Timor, Indonesia, Japan, Laos, Malaysia, Myanmar, North Korea,
Philippines, Singapore, South Korea, Thailand and Vietnam. 25

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 26 -->
Schedule 2 Minimum Insurance Requirements Eutectix shall obtain, pay for, and maintain in full force
and effect throughout the term of this Agreement insurance as follows: (a) Workers' Compensation and
Employers' Liability insurance with limits to conform with the greater of the amount required by
applicable law or one million dollars ($1,000,000) each accident, including occupational disease
coverage and an endorsement to the Workers' Compensation and Employers' Liability insurance policy,
in form acceptable to Liquidmetal, containing a waiver of subrogation by the insurance carrier with
respect to Liquidmetal and its parent, subsidiaries, divisions and Affiliates, and all of their
respective directors, officers, shareholders, employees and representatives; (b) Commercial General
Liability insurance with limits of not less than five million dollars ($5,000,000) combined single
limit for bodily injury, death, and property damage, including personal injury, contractual
liability, independent contractors, broad- form property damage, and products and completed
operations coverage; and, (c) Commercial Automobile Liability insurance with limits of not less than
one million dollars ($1,000,000) each occurrence combined single limit of liability for bodily
injury, death, and property damage, including owned and non-owned and hired automobile coverages, as
applicable. As evidence of insurance coverage, Eutectix shall deliver to Liquidmetal on the
Effective Date and no less than annually thereafter (a) certificates of insurance issued by
Eutectix's insurance carrier showing each of these policies in force during the term of this
Agreement, and (b) an endorsement to each required policy, in form acceptable to Liquidmetal, naming
Liquidmetal and its parent, subsidiaries, divisions and Affiliates, and all of their respective
directors, officers, shareholders, employees and representatives as additional insureds (except
under the Workers' Compensation policies). To the extent any insurance coverage required under this
Agreement is purchased on a "claims-made" basis, such insurance shall cover all prior acts of
Eutectix during the term of this Agreement, and such insurance shall be continuously maintained
until at least two (2) years beyond the expiration or termination of the term of this Agreement, or
Eutectix shall purchase "tail" coverage, effective upon termination of any such policy or upon
termination or expiration of the term of this Agreement, to provide coverage for at least two (2)
years from the occurrence of either such event. Eutectix shall give thirty (30) days' prior written
notice to Liquidmetal of cancellation, non-renewal, or material change in coverage, scope, or amount
of any of the required policies. Eutectix's liability under the Agreement shall not be limited or
modified in any way by the amount or terms of any insurance it is required to maintain hereunder. 26

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
<!-- page 27 -->
Schedule 3 Licensed Technical Information and Patents Included in the Agreement 27

Source: LIQUIDMETAL TECHNOLOGIES INC, 8-K, 2/5/2020
