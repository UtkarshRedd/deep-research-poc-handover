<!-- page 1 -->
# JOINT FILING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| Agreement Date | 2020-07-06 |
| Parties | ATHENE ANNUITY AND LIFE COMPANY; ATHENE ANNUITY & LIFE ASSURANCE COMPANY; ATHENE USA CORPORATION; ATHENE LIFE RE LTD.; ATHENE HOLDING LTD.; APOLLO INSURANCE SOLUTIONS GROUP LP; AISG GP LTD.; APOLLO LIFE ASSET, L.P.; APOLLO LIFE ASSET GP, LLC.; APOLLO CAPITAL MANAGEMENT, L.P.; APOLLO CAPITAL MANAGEMENT GP, LLC; APOLLO MANAGEMENT HOLDINGS, L.P.; APOLLO MANAGEMENT HOLDINGS GP, LLC; OMAHA EQUITY AGGREGATOR, L.P.; AP OMAHA ADVISORS, LLC; APOLLO HYBRID VALUE ADVISORS, L.P.; APOLLO HYBRID VALUE CAPITAL MANAGEMENT, LLC; APH HOLDINGS, L.P.; APOLLO PRINCIPAL HOLDINGS III GP, LTD. |
| Source | CUAD v1 / MFAFINANCIAL,INC_07_06_2020-EX-99.D-JOINT FILING AGREEMENT |

EXHIBIT D JOINT FILING AGREEMENT MFA FINANCIAL, INC. In accordance with Rule 13d-1(k) under the
Securities Exchange Act of 1934, as amended, the undersigned hereby confirm the agreement by and
among them to the joint filing on behalf of them of the Statement on Schedule 13D and any and all
further amendments thereto, with respect to the securities of the above referenced issuer, and that
this Agreement be included as an Exhibit to such filing. This Agreement may be executed in any
number of counterparts each of which shall be deemed to be an original and all of which together
shall be deemed to constitute one and the same Agreement. IN WITNESS WHEREOF, the undersigned hereby
execute this Agreement as of July 6, 2020. ATHENE ANNUITY AND LIFE COMPANY By: Apollo Insurance
Solutions Group LP, its investment adviser By: AISG GP Ltd., its general partner By: /s/ Matthew S.
O'Mara Matthew S. O'Mara Authorized Signatory ATHENE ANNUITY & LIFE ASSURANCE COMPANY By: Apollo
Insurance Solutions Group LP, its investment adviser By: AISG GP Ltd., its general partner By: /s/
Matthew S. O'Mara Matthew S. O'Mara Authorized Signatory ATHENE USA CORPORATION By: Apollo Insurance
Solutions Group LP, its investment adviser By: AISG GP Ltd., its general partner By: /s/ Matthew S.
O'Mara Matthew S. O'Mara Authorized Signatory
<!-- page 2 -->
ATHENE LIFE RE LTD. By: Apollo Insurance Solutions Group LP, its investment adviser By: AISG GP
Ltd., its general partner By: /s/ Matthew S. O'Mara Matthew S. O'Mara Authorized Signatory ATHENE
HOLDING LTD. By: Apollo Insurance Solutions Group LP, its investment adviser By: AISG GP Ltd., its
general partner By: /s/ Matthew S. O'Mara Matthew S. O'Mara Authorized Signatory APOLLO INSURANCE
SOLUTIONS GROUP LP By: AISG GP Ltd., its general partner By: /s/ Matthew S. O'Mara Matthew S. O'Mara
Authorized Signatory AISG GP LTD. By: /s/ Matthew S. O'Mara Matthew S. O'Mara Authorized Signatory
APOLLO LIFE ASSET, L.P. By: Apollo Life Asset GP, LLC, its general partner By: /s/ William B. Kuesel
William B. Kuesel Vice President
<!-- page 3 -->
APOLLO LIFE ASSET GP, LLC By: /s/ William B. Kuesel William B. Kuesel Vice President APOLLO CAPITAL
MANAGEMENT, L.P. By: Apollo Capital Management GP, LLC, its general partner By: /s/ William B.
Kuesel William B. Kuesel Vice President APOLLO CAPITAL MANAGEMENT GP, LLC By: /s/ William B. Kuesel
William B. Kuesel Vice President APOLLO MANAGEMENT HOLDINGS, L.P. By: Apollo Management Holdings GP,
LLC, its general partner By: /s/ William B. Kuesel William B. Kuesel Vice President APOLLO
MANAGEMENT HOLDINGS GP, LLC By: /s/ William B. Kuesel William B. Kuesel Vice President OMAHA EQUITY
AGGREGATOR, L.P. By: AP Omaha Advisors, LLC, its general partner By: Apollo Hybrid Value Advisors,
L.P., its sole member By: Apollo Hybrid Value Capital Management, LLC, its general partner By: /s/
Joseph D. Glatt Joseph D. Glatt Vice President
<!-- page 4 -->
AP OMAHA ADVISORS, LLC By: Apollo Hybrid Value Advisors, L.P., its sole member By: Apollo Hybrid
Value Capital Management, LLC, its general partner By: /s/ Joseph D. Glatt Joseph D. Glatt Vice
President APOLLO HYBRID VALUE ADVISORS, L.P. By: Apollo Hybrid Value Capital Management, LLC, its
general partner By: /s/ Joseph D. Glatt Joseph D. Glatt Vice President APOLLO HYBRID VALUE CAPITAL
MANAGEMENT, LLC By: /s/ Joseph D. Glatt Joseph D. Glatt Vice President APH HOLDINGS, L.P. By: Apollo
Principal Holdings III GP, Ltd., its general partner By: /s/ William B. Kuesel William B. Kuesel
Vice President APOLLO PRINCIPAL HOLDINGS III GP, LTD. By: /s/ William B. Kuesel William B. Kuesel
Vice President
