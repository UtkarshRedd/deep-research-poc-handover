# Which jurisdiction's law governs the Endorsement Agreement between Teardrop Putter Corp...

*Question:* Which jurisdiction's law governs the Endorsement Agreement between Teardrop Putter Corporation and Consolidated Artists Inc. (dated 1996-01-01)?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Identify governing law clause

[GAP] The writer produced nothing for: Establish whether the Endorsement Agreement contains an express choice-of-law provision and which jurisdiction it designates.

## Verification appendix

Claims: 1 · supported: 0 · partially: 0 · dropped: 0 · gaps: 1

Notes: OpenAIRateLimitError: Error code: 429

| claim | section | tier 1 | score | tier 2 | clusters | sources | note |
|---|---|---|---|---|---|---|---|
| s1.1 | s1 | gap |  | skipped |  |  |  |

### Evidence

