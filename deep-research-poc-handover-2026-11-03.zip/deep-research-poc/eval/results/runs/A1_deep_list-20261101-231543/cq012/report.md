# Which jurisdiction's law governs the Business Development Agreement between LIQUIDMETAL...

*Question:* Which jurisdiction's law governs the Business Development Agreement between LIQUIDMETAL TECHNOLOGIES, INC. and EUTECTIX, LLC (filed 2020-02-05)?

## Identify governing law clause

The Business Development Agreement between LIQUIDMETAL TECHNOLOGIES, INC. and EUTECTIX, LLC is governed by the internal laws of the State of Arizona (U.S.A.). [e110b7fe3046dec8 p.23] The governing law clause states: "This Agreement, the legal relations between the parties, and any action, whether contractual or non-contractual, instituted by any party with respect to matters arising under or growing out of or in connection with or in respect of this Agreement shall be governed by and construed in accordance with the internal laws of the State of Arizona (U.S.A.), excluding any choice of law rules that may direct the application of the laws of another jurisdiction". [e110b7fe3046dec8 p.23]

## Verify document filing date

The document is titled "BUSINESS DEVELOPMENT AGREEMENT". [e110b7fe3046dec8 p.1] The parties are LIQUIDMETAL TECHNOLOGIES, INC. [uncited] ("Liquidmetal") and EUTECTIX, LLC ("Eutectix"). [e110b7fe3046dec8 p.1] The SEC Filing Date is 2020-02-05. [e110b7fe3046dec8 p.1]

## Verification appendix

Claims: 6 · supported: 5 · partially: 0 · dropped: 0 · gaps: 1 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e2→[e110b7fe3046dec8 p.23] |  |
| s1.2 | s1 | keep | 1.00 | e2→[e110b7fe3046dec8 p.23] |  |
| s2.1 | s2 | keep | 1.00 | e1→[e110b7fe3046dec8 p.1] |  |
| s2.2 | s2 | gap |  |  | no evidence cited |
| s2.3 | s2 | keep | 1.00 | e1→[e110b7fe3046dec8 p.1] |  |
| s2.4 | s2 | keep | 1.00 | e1→[e110b7fe3046dec8 p.1] |  |

### Evidence

- e1 [e110b7fe3046dec8 p.1 L2-8] keep (1.0): "# BUSINESS DEVELOPMENT AGREEMENT | Field | Value | |---|---| | Document Type | Development Agreement | | SEC Filing Date | 2020-02-05 | | Parties | LIQUIDMETAL TECHNOLOGIES, INC. ("Liquidmetal"); EUTECTIX, LLC ("Eutectix")"
- e2 [e110b7fe3046dec8 p.23 L845-852] keep (1.0): "This Agreement, the legal relations between the parties, and any action, whether contractual or non-contractual, instituted by any party with respect to matters arising under or growing out of or in connection with or in respect of this Agr…"
