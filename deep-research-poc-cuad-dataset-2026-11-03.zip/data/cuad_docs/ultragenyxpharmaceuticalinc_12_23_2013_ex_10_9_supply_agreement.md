<!-- page 1 -->
# SUPPLY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Supply Agreement |
| Agreement Date | 2012-11-19 |
| Parties | Cremer Oleo GmbH & Co KG ("Cremer"); Ultragenyx Pharmaceutical Inc. ("Ultragenyx") |
| Source | CUAD v1 / ULTRAGENYXPHARMACEUTICALINC_12_23_2013-EX-10.9-SUPPLY AGREEMENT |

Exhibit 10.9

SUPPLY AGREEMENT

between

CREMER OLEO GmbH & Co KG, Glockengiesserwall 3, 20095 Hamburg,

Germany

— hereinafter referred to as Cremer —

and

Ultragenyx Pharmaceutical Inc, 60 Leveroni Court, Suite 200, Novato, California 94949, United States
of America

— hereinafter referred to as Ultragenyx —

­ each party also referred to as a "Party" and jointly as the "Parties" -

Preamble

Whereas, Cremer is a producer of oleo chemical products;

Whereas, Ultragenyx is a biotechnology company committed to bringing life-enhancing therapeutics for
patients with rare and ultra-rare genetic diseases, also known as orphan diseases, to market;

Whereas, the Parties desire that Cremer supplies to Ultragenyx the product Triheptanoin (hereinafter
also referred to as the "Product") in bulk form pursuant to the terms and conditions of this
Agreement;

Whereas, Ultragenyx intends to process the Product into a pharmaceutical product in the meaning of
Sec. 2 German Pharmaceuticals Act (Arzneimittelgesetz—AMG) and to market the processed Product in
the Field (as defined below) (hereinafter referred to as the "Purpose"); and

Whereas, Ultragenyx intends to obtain regulatory approval for the processed Product as a
pharmaceutical product in the meaning of Sec. 2 AMG.

Now therefore, the Parties hereto agree as follows:

Article 1 Supply of Product

1) Subject to the terms and conditions set forth in this Agreement Cremer shall supply Ultragenyx
with the Product free from defect and meeting the product specification attached to this Agreement
as Annex A (the "Product Specifications").

2) Cremer shall supply Ultragenyx exclusively with the Product worldwide. The aforesaid exclusivity
is limited to [***] (collectively, the "Field"). Cremer may supply the Product to other customers
outside of the Field.

3) Ultragenyx shall purchase the Product exclusively from Cremer.

[***] Certain information in this document has been omitted and filed separately with the Securities
and Exchange Commission. Confidential treatment has been requested with respect to the omitted
portions.

1
<!-- page 2 -->
Article 2 Orders and Delivery

1) The Product will be ordered by Ultragenyx through purchase orders. Purchase orders shall be
submitted in any written or electronic form or by facsimile, setting out the quantity of Product
required and the date for delivery. Cremer shall give its order confirmation in writing stating the
quantity and Price (as defined below). Cremer shall not be obliged to deliver the Product in the
absence of a written order confirmation given to Ultragenyx.

2) Delivery of the Product in bulk form by Cremer shall be EXW (Incoterms 2010), unless otherwise
agreed in writing by the Parties.

3) Within [***] days of execution of this Agreement, Cremer shall deliver to Ultragenyx the Master
Batch Record for the Product for Ultragenyx to review.

4) All Product shall be delivered with the applicable certificate of analysis and batch records for
the Product delivered and an invoice for the quantity of Product delivered.

5) If Ultragenyx obtains regulatory approval for the processed Product, the Parties shall enter into
a separate commercial supply agreement for the Product that sets forth the forecasting and ordering
mechanism for commercial supply of the Product, enablement of the manufacturing process in the event
of a failure to supply, the term of such commercial supply agreement and other customary terms and
conditions.

Article 3 Prices and payment

1) The prices payable by Ultragenyx to Cremer for the Product (the "Price") shall be agreed [***]
every contract year; provided, that the Price may not increase more than the [***] for such period
or [***]%, whichever is higher. At the date of signing the Parties agree on a Price of €[***] per
kilogram for the Product.

2) If the parties cannot agree on a price for the Product by the beginning of a following contract
year, Cremer may refuse to deliver the Product to Ultragenyx until the Parties agreed on a
respective price.

3) Payments shall be made by Ultragenyx in Euro and within [***] days after receipt of a proper
invoice.

4) Transfer of title with respect to any Product shall be subject to full payment and settlement of
all claims Cremer may have against Ultragenyx in connection with the execution of this Agreement.

Article 4 Specification; Warranties; Cremer's Liability; Indemnification

1) The Parties assume that the Product constitutes an active pharmaceutical ingredient in the
meaning of Sec. 4 para. 19 AMG. Ultragenyx shall process the Product into a pharmaceutical product
in the meaning of Sec. 2 AMG and market the processed Product as a pharmaceutical product in the
meaning of Sec 2 AMG and to perform clinical trials. Cremer does not participate in the processing,
manufacturing and marketing of the respective pharmaceutical product or in the clinical trials.

[***] Certain information in this document has been omitted and filed separately with the Securities
and Exchange Commission. Confidential treatment has been requested with respect to the omitted
portions.

2
<!-- page 3 -->
2) Upon execution of this Agreement and any purchase order, Cremer shall provide Ultragenyx with
following documentation regarding the Product: Certificate of Analysis and the applicants' part of
the Drug Master File once compiled.

3) Cremer represents and warrants that all quantities of Product delivered under the Agreement were
manufactured in accordance with GMP. The Product shall be free from defects if it is within the
specifications according to Annex A.

4) Cremer represents and warrants that it has not received any written notice from a third party
alleging that the manufacture, use or sale of the Product infringes intellectual property rights of
a third party.

5) Ultragenyx will perform final release of the Product. Ultragenyx may rely on the documentation
provided by Cremer and Ultragenyx will not need to independently test the Product unless Ultragenyx
determines such independent testing is necessary. In the event that the Product fails to conform to
the Product Specifications, and/or GMP, Ultragenyx may reject the Product by giving written notice
to Cremer within [***] days after receipt of the Product and all documentation (except such [***]
day period will not apply for any latent defect). Within [***] days following receipt of the
rejected and returned Product from Ultragenyx, Cremer will, at Ultragenyx's choice, replace such
quantity of Product with Product conforming to the Product Specifications, and GMP or refund
Ultragenyx the Price paid for such Product.

6) Cremer does not warrant or represent that the Product is effective in a pharmaceutical way within
the meaning of Sec. 4 para. 19 AMG. Cremer does not warrant or represent that the Product is safe in
a pharmaceutical and pharmacological way. Cremer does not warrant or represent that the Product is
suitable for the intended Purpose by Ultragenyx. Cremer is not a pharmaceutical manufacturer within
the meaning of Sec. 4 para. 18 AMG. Cremer's liability in connection with the Purpose and the
processing and marketing of a pharmaceutical product is excluded. No. 9 below applies.

7) Except for a claim arising out of Cremer's intentional misconduct or gross negligence under this
Agreement, in the event of legal proceedings being instituted against Cremer by a third party
arising out of Ultragenyx's development, processing and commercialization of the Product, Ultragenyx
shall indemnify and keep indemnified Cremer in full against all damages, losses, injuries, costs and
expenses in connection with such legal proceedings. Cremer will inform Ultragenyx about any legal
proceedings being instituted against Cremer without delay. Ultragenyx shall control the respective
legal proceedings but shall not settle any claim that admits fault on behalf of Cremer without
Cremer's consent (not be unreasonably withheld).

[***] Certain information in this document has been omitted and filed separately with the Securities
and Exchange Commission. Confidential treatment has been requested with respect to the omitted
portions.

3
<!-- page 4 -->
8) In the event of legal proceedings being instituted against Ultragenyx by a third party arising
out of Cremer's intentional misconduct or gross negligence under this Agreement, Cremer shall
indemnify and keep indemnified Ultragenyx in full against all damages, losses, injuries, costs and
expenses in connection with such legal proceedings. Ultragenyx will inform Cremer about any legal
proceedings being instituted against Ultragenyx without delay. Cremer shall control the respective
legal proceedings but shall not settle any claim without Ultragenyx's consent (not be unreasonably
withheld).

9) Cremer's liability arising from this Agreement is limited to intentional misconduct or gross
negligence. This limitation of liability does not apply to the injury of the life, body or health of
a person, to claims according to the Product Liability Act (Produkthaftungsgesetz) or any other
coercive legal liability claims.

10) NEITHER PARTY MAY CLAIM AND NEITHER PARTY IS LIABLE FOR CLAIMS FOR INDIRECT DAMAGES AND LOSSES,
SUCH AS SPECIAL OR CONSEQUENTIAL LOSS OR DAMAGE, ANY LOSS OF ACTUAL OR ANTICIPATED PROFIT, OR
REVENUE, ANTICIPATED SAVINGS OR BUSINESS OR DAMAGE TO GOODWILL OR BRAND EQUITY, ARE EXCLUDED.

Article 5 Term and Termination

1) This Agreement shall become effective on the date of its execution and shall remain in force for
three years (the "Initial Term"). Thereafter, the Agreement shall be automatically renewed for
additional two year periods (each a "Renewal Term", the Initial Term and all Renewal Terms, the
"Term") unless either Party notifies the other Party of its intention not to renew in writing at
least three calendar months before the expiration of the then current Term.

2) If a Party materially breaches an obligation under this Agreement and does not cure such breach
within sixty (60) days of receiving notice of such breach from the non-breaching Party, the
non-breaching Party may terminate this Agreement immediately upon written notice to the breaching
Party.

3) Every termination has to be in writing.

Article 6 General Terms and Conditions

The application of General Terms and Conditions of any Party is excluded.

Article 7 Product Development

At the request and expense of Ultragenyx, Cremer shall perform development work for Ultragenyx to
develop new formulations of the Product. All such work shall be performed pursuant to a statement of
work (including a budget) to be agreed upon by the Parties and attached as an annex to this
Agreement (each, a "Statement of Work"). In the event that in the course of performing a Statement
of Work new Product know­how and intellectual property rights may result, can be created or have
been created the Parties will enter into a separate Agreement in order to define the rights and
duties regarding the aforesaid know how and intellectual property rights.

[***] Certain information in this document has been omitted and filed separately with the Securities
and Exchange Commission. Confidential treatment has been requested with respect to the omitted
portions.

4
<!-- page 5 -->
Article 8 Invalidity

In the event that any individual clauses of these terms and conditions are, or shall become,
invalid, this shall not affect the validity of the remaining clauses. An invalid condition shall be
deemed to have been replaced by such provision which is legally valid and corresponds nearest to the
economic purpose of the clause originally deemed invalid.

Article 9 Applicable Law; Modifications; Annexes; Miscellaneous

1) The laws of the Federal Republic of Germany shall apply to the Agreement and any legal relations
thereof, especially any purchase order, between Cremer and Ultragenyx shall be governed by that law.
The law of the United Nations Conventions of the formation of Agreements for the international sale
of goods (CISG) is excluded. Exclusive place of Jurisdiction is Hamburg, Germany.

2) No addition or modification to this Agreement shall be valid unless made in writing and signed by
the Parties.

3) The Annex attached to this Agreement form an integral part of the Agreement.

4) This Agreement, including the Annexes and any Statement of Work, constitutes the entire agreement
between the Parties concerning the subject matter hereof and supersedes all written or oral prior
agreements or understandings with respect thereto except the Confidentiality Agreement between the
parties dated September 26t h, 2012. This Agreement shall be binding upon and shall inure to the
benefit of the Parties hereto, their successors and assigns.

5) All waivers must be in writing and signed by the Party to be charged. Any waiver or failure to
enforce any provision of this Agreement on one occasion will not be deemed a waiver of any other
provision or of such provision on any other occasion.

6) Each Party must deliver all notices, consents, and approvals required or permitted under this
Agreement in writing to the other Party at the address specified above, by personal delivery, by
certified or registered mail (postage prepaid and return receipt requested), by a nationally-
recognized overnight carrier, or by facsimile transmission with electronic confirmation of
transmission. Notice will be effective upon receipt or refusal of delivery. Each Party may change
its address for receipt of notice by giving notice of such change to the other Party.

7) This Agreement may be executed in counterparts by original signature, facsimile or PDF files,
each of which shall be deemed an original, but all of which together shall constitute one and the
same instrument.

5
<!-- page 6 -->
Hamburg, November 19t h, 2012

/s/ Thomas Kassberg /s/ Dr. R. Stephan Ultragenyx Pharmaceutical Inc

CREMER OLEO GmbH & Co KG

CREMER OLEO GmbH & Co. KG Postfach 10 11 20, D-20007 Hamburg Tel: 040/320 11-0, Telefax 320 11-400

6
<!-- page 7 -->
Annex A — Specification of the Product Trihepatanoin (Heptansäuretriglycerid)

No Test EP method Limits

1 [***] [***], [***] 2 [***] [***] [***] 3 [***] [***] [***] 4 [***] [***] [***] 5 [***] [***] [***]
6 [***] [***] [***] 7 [***] [***] [***] 8 [***] [***] [***] 9 [***] [***] [***] 10 [***] [***] [***]
11 [***] [***] [***] 12 [***] [***] 13 [***] [***] [***] 18 [***] [***] [***]

[***] Certain information in this document has been omitted and filed separately with the Securities
and Exchange Commission. Confidential treatment has been requested with respect to the omitted
portions.

7
