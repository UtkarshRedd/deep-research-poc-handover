<!-- page 1 -->
# Cooperation Agreement
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2014-12-12 |
| Parties | VA Partners I, LLC, ValueAct Capital Master Fund, L.P., ValueAct Capital Management, L.P., ValueAct Capital Management, LLC, ValueAct Holdings, L.P. (collectively, the “ValueAct Group”, and individually a “member” of the ValueAct Group); Allison Transmission Holdings, Inc. (the “Company”); Gregory P. Spivy (the “ValueAct Designee”) |
| Source | CUAD v1 / ALLISONTRANSMISSIONHOLDINGSINC_12_15_2014-EX-99.1-COOPERATION AGREEMENT |

Exhibit 99.1

COOPERATION AGREEMENT

This Cooperation Agreement (this "Agreement") dated December 12, 2014, is by and among the persons
and entities listed on Schedule A (collectively, the "ValueAct Group", and individually a "member"
of the ValueAct Group), Allison Transmission Holdings, Inc. (the "Company") and Gregory P. Spivy, in
his individual capacity and as a member of the ValueAct Group (the "ValueAct Designee").

WHEREAS, the ValueAct Group currently beneficially owns 19,125,204 shares of the common stock, par
value $0.01 per share, of the Company (the "Common Stock"), which represents approximately 10.77% of
the issued and outstanding shares of Common Stock.

WHEREAS, the Nominating and Governance Committee of the Board (the "Nominating Committee") and the
Company's Board of Directors (the "Board") have considered the qualifications of the ValueAct
Designee and conducted such review as they have deemed appropriate.

WHEREAS, the Board has determined that it is in the best interests of the Company to appoint the
ValueAct Designee on the terms set forth in this Agreement.

NOW, THEREFORE, In consideration of and reliance upon the mutual covenants and agreements contained
herein, and for other good and valuable consideration, the receipt and sufficiency of which is
hereby acknowledged, the parties hereto agree as follows:

1. Board Nomination.

(a) Subject to the satisfactory completion of the Company's customary background check, the Board
shall appoint the ValueAct Designee to serve as a director beginning within ten (10) calendar days
following receipt of the ValueAct Group's written request to the Company to have the ValueAct
Designee appointed to the Board; provided that, at such time, the Board does not conclude in good
faith and based on the written opinion of outside legal counsel that such appointment would
constitute a breach of the directors' fiduciary duties. If the ValueAct Designee is appointed to the
Board pursuant to this Section 1(a), the Company shall include the ValueAct Designee as a Class I
Director, which term expires at the Company's 2016 annual meeting of stockholders.

(b) As a condition to the ValueAct Designee's appointment to the Board, the ValueAct Group,
including the ValueAct Designee, agrees to provide to the Company information required to be or
customarily disclosed for directors, candidates for directors, and their affiliates and
representatives in a proxy statement or other filings under applicable law or stock exchange rules
or listing standards, information in connection with assessing eligibility, independence and other
criteria applicable to directors or satisfying compliance and legal obligations, and such other
information as reasonably requested by the Company from time to time with respect to the ValueAct
Group and the ValueAct Designee.

(c) The ValueAct Designee agrees that, at all times while serving as a member of the Board, he will
(i) meet all director independence and other standards of the Company, the New York Stock Exchange
and the Securities and Exchange Commission ("SEC") and applicable provisions of the Securities
Exchange Act of 1934, as amended (the "Exchange Act"), and the rules and regulations promulgated
thereunder, including Rule 10A- 3; and (ii) be qualified to serve as a director under the Delaware
General Corporation Law (the "DGCL") (clauses (i) and (ii), the "Conditions"). The ValueAct Designee
will promptly advise the Nominating Committee if he ceases to satisfy any of the Conditions.

(d) At all times while serving as a member of the Board, the ValueAct Designee shall comply with all
policies, procedures, processes, codes, rules, standards and guidelines applicable to Board members,
including the Company's Code of Business Conduct, Insider Trading Policy, Executive Stock Ownership
Policy as in effect on the date hereof, and Corporate Governance Guidelines, and (except as
permitted by the Confidentiality Agreement (as defined in Section 7 below)) preserve the
confidentiality of Company business and information, including discussions or matters considered in
meetings of the Board or Board committees to the extent not disclosed publicly by the Company. 1
<!-- page 2 -->
(e) So long as the ValueAct Group collectively beneficially owns, in the aggregate, at least 7.5% of
the outstanding Common Stock, if, during the Covered Period, a vacancy on the Board is created as a
result of the ValueAct Designee's death, resignation, disqualification or removal, then the ValueAct
Group and the Company (acting through the Board) shall work together in good faith to fill such
vacancy or replace such nominee with an individual who (A) meets the Conditions, (B) meets the
historical standards and criteria applied by the Company in nominating and appointing directors, and
(C) is otherwise mutually acceptable (in each of their sole discretion) to the ValueAct Group and
the Company, and thereafter such individual shall serve and/or be nominated as the "ValueAct
Designee" under this Agreement.

(f) The Company's obligations hereunder shall terminate immediately, and the ValueAct Designee shall
promptly offer to resign from the Board, and any committee of the Board on which he then sits (and,
if requested by the Company, promptly deliver his written resignation to the Board (which shall
provide for his immediate resignation) it being understood that it shall be in the Board's sole
discretion whether to accept or reject such resignation) if: (i) members of the ValueAct Group,
collectively, cease to beneficially own at least 7.5% of the Company's outstanding Common Stock;
(ii) the ValueAct Designee ceases to satisfy the conditions set forth in clauses (c)-(d) above;
(iii) a member of the ValueAct Group, including the ValueAct Designee, otherwise ceases to comply or
breaches any of the terms of this Agreement or the Confidentiality Agreement; or (iv) the employment
of the ValueAct Designee with the ValueAct Group is terminated for any reason. The ValueAct Group
agrees to cause the ValueAct Designee to resign from the Board if the ValueAct Designee fails to
resign if and when requested pursuant to this Section 1(f). Notwithstanding the foregoing, in the
event of the occurrence of an event set forth in subsection (ii) or (iv) above, the provisions of
Section 1(e) must be complied with before the Company's obligations hereunder may terminate.

(g) The percentage thresholds set forth in clauses (e) and (f) above shall not be deemed unsatisfied
to the extent a failure to maintain the specified ownership thresholds is the result of share
issuances or similar Company actions that increase the number of outstanding shares of Common Stock.

2. Standstill.

(a) Each member of the ValueAct Group agrees that, during the Covered Period, (unless specifically
requested in writing by the Company, acting through a resolution of a majority of the Company's
directors not including the ValueAct Designee), it shall not, and shall cause each of its Affiliates
or Associates (as such terms are defined in Rule 12b-2 promulgated by the SEC under the Exchange
Act) (collectively and individually, the "ValueAct Affiliates," provided that no portfolio company
of the ValueAct Group shall be deemed a "ValueAct Affiliate" so long as such portfolio company (A)
has not discussed any of the actions set forth in this subsection (a) with the ValueAct Group or the
ValueAct Designee, (B) has not received from the ValueAct Group or the ValueAct Designee information
concerning the Company or its business, and (C) is not acting at the request of, in coordination
with or on behalf of the ValueAct Group or the ValueAct Designee), not to, directly or indirectly,
in any manner, alone or in concert with others:

(i) make, engage in, or in any way participate in, directly or indirectly, any "solicitation" of
proxies (as such terms are used in the proxy rules of the SEC but without regard to the exclusion
set forth in Rule 14a-1(l)(2)(iv) of the Exchange Act) or consents to vote, or seek to advise,
encourage or influence any person with respect to the voting of any securities of the Company or any
securities convertible or exchangeable into or exercisable for any such securities (collectively,
"securities of the Company") for the election of individuals to the Board or to approve stockholder
proposals, or become a "participant" in any contested "solicitation" for the election of directors
with respect to the Company (as such terms are defined or used under the Exchange Act) (other than a
"solicitation" or acting as a "participant" in support of all of the nominees of the Board at any
stockholder meeting) or make or be the proponent of any stockholder proposal (pursuant to Rule 14a-8
under the Exchange Act or otherwise);

(ii) form, join, encourage, influence, advise or in any way participate in any Group (as such term
is defined in Section 13(d)(3) of the Exchange Act) with any persons who are not ValueAct Affiliates
2
<!-- page 3 -->
with respect to any securities of the Company or otherwise in any manner agree, attempt, seek or
propose to deposit any securities of the Company in any voting trust or similar arrangement, or
subject any securities of the Company to any arrangement or agreement with respect to the voting
thereof, except as expressly set forth in this Agreement;

(iii) acquire, offer or propose to acquire, or agree to acquire, directly or indirectly, whether by
purchase, tender or exchange offer, through the acquisition of control of another person, by joining
a partnership, limited partnership, syndicate or other group (including any group of persons that
would be treated as a single "person" under Section 13(d) of the Exchange Act), through swap or
hedging transactions or otherwise, any securities of the Company or any rights decoupled from the
underlying securities of the Company that would result in the ValueAct Group (together with the
ValueAct Affiliates) owning, controlling or otherwise having any beneficial or other ownership
interest in more than 12% in the aggregate of the shares of Common Stock outstanding at such time;
provided, that, nothing herein will require Common Stock to be sold to the extent the ValueAct Group
and the ValueAct Affiliates, collectively, exceed the ownership limit under this paragraph as the
result of a share repurchase or similar Company actions that reduces the number of outstanding
shares of Common Stock;

(iv) sell, offer or agree to sell directly or indirectly, through swap or hedging transactions or
otherwise, the securities of the Company or any rights decoupled from the underlying securities of
the Company held by the ValueAct Group or any ValueAct Affiliate to any person or entity not a (A)
party to this Agreement, (B) member of the Board, (C) officer of the Company or (D) ValueAct
Affiliate (any person or entity not set forth in clauses (A)-(D) shall be referred to as a "Third
Party"), that would knowingly result in such Third Party, together with its affiliates and
associates, owning, controlling or otherwise having any beneficial or other ownership interest in
the aggregate of more than 4.9% of the shares of Common Stock outstanding at such time, except in a
transaction approved by the Board;

(v) effect or seek to effect, offer or propose to effect, cause or participate in, or in any way
assist or facilitate any other person to effect or seek, offer or propose to effect or participate
in, any tender or exchange offer, merger, consolidation, acquisition, scheme, arrangement, business
combination, recapitalization, reorganization, sale or acquisition of material assets, liquidation,
dissolution or other extraordinary transaction involving the Company or any of its subsidiaries or
joint ventures or any of their respective securities (each, an "Extraordinary Transaction"), or make
any public statement with respect to an Extraordinary Transaction; provided, however, that this
clause shall not preclude the tender by the ValueAct Group or a ValueAct Affiliate of any securities
of the Company into any tender or exchange offer or vote by the ValueAct Group or a ValueAct
Affiliate of any securities of the Company with respect to any Extraordinary Transaction;

(vi) engage in any short sale or any purchase, sale or grant of any option, warrant, convertible
security, stock appreciation right, or other similar right (including, without limitation, any put
or call option or "swap" transaction) with respect to any security (other than a broad- based market
basket or index) that includes, relates to or derives any significant part of its value from a
decline in the market price or value of the securities of the Company;

(vii) (A) call or seek to call any meeting of stockholders, including by written consent, (B) seek
representation, on or nominate any candidate to, the Board, except as set forth herein, (C) seek the
removal of any member of the Board, (D) solicit consents from stockholders or otherwise act or seek
to act by written consent, (E) conduct a referendum of stockholders, or (F) make a request for any
stockholder list or other Company books and records, whether pursuant to Section 220 of the DGCL or
otherwise;

(viii) take any action in support of or make any proposal or request that constitutes: (A) advising,
controlling, changing or influencing the Board or management of the Company, including any plans or
proposals to change the number or term of directors or to fill any vacancies on the Board; (B) any
material change in the capitalization, stock repurchase programs and practices or dividend policy of
the Company; (C) any other material change in the Company's management, business or corporate
structure; (D) seeking to have the Company waive or make amendments or modifications to the
Company's Certificate of Incorporation or Bylaws, or other actions that may impede or facilitate the
acquisition of control of the Company by any person; (E) causing a class of securities of the
Company to be delisted from, or to cease to be authorized to be quoted on, any securities exchange;
or (F) causing a class of securities of the Company to become eligible for termination of
registration pursuant to Section 12(g)(4) of the Exchange Act; 3
<!-- page 4 -->
(ix) disparage or cause to be disparaged the Company or Affiliates thereof, any of its current or
former officers, or directors;

(x) make any public disclosure, announcement or statement regarding any intent, purpose, plan or
proposal with respect to the Board, the Company, its management, policies or affairs, any of its
securities or assets or this Agreement that is inconsistent with the provisions of this Agreement;

(xi) enter into any substantive discussions, negotiations, agreements, or understandings with any
Third Party with respect to any of the foregoing, or advise, assist, knowingly encourage or seek to
persuade any Third Party to take any action or make any statement with respect to any of the
foregoing, or otherwise take or cause any action or make any statement inconsistent with any of the
foregoing; or

(xii) request, directly or indirectly, any amendment or waiver of the foregoing.

The foregoing provisions of this Section 2(a) shall not be deemed to prohibit the ValueAct Group or
its directors, officers, partners, employees, members or agents (acting in such capacity)
("Representatives") from communicating privately with the Company's directors, officers or advisors
so long as such communications are not intended to, and would not reasonably be expected to, require
any public disclosure of such communications.

(b) Each member of the ValueAct Group shall cause all shares of Common Stock beneficially owned,
directly or indirectly, by it, or by any ValueAct Affiliate, to be present for quorum purposes and
to be voted, at the Company's annual and special stockholder meetings and at any adjournments or
postponements thereof, and further agrees that at the 2015 annual stockholder meeting they shall
vote in favor of (i) all directors nominated by the Board for election at such meeting and (ii) in
accordance with the Board's recommendation with respect to any proposals for the election of
directors that may be the subject of stockholder action at such meeting.

(c) The ValueAct Group acknowledges that the ValueAct Designee shall have all of the rights and
obligations, including fiduciary duties to the Company and its stockholders, of a director under
applicable law and the Company's organizational documents while the ValueAct Designee is serving on
the Board. Notwithstanding the foregoing, nothing in this Section 2 shall limit any actions that may
be taken by the ValueAct Designee acting solely as a director of the Company consistent with his
fiduciary duties as a director of the Company (it being understood and agreed that the ValueAct
Group and the ValueAct Affiliates shall not seek to do indirectly through the ValueAct Designee
anything that would be prohibited if done by the ValueAct Group or the ValueAct Affiliates).

For purposes of this Agreement the terms "person" or "persons" shall mean any individual,
corporation (including not-for-profit), general or limited partnership, limited liability or
unlimited liability company, joint venture, estate, trust, association, organization or other entity
of any kind or nature.

3. Representations of the Company. The Company represents and warrants as follows: (a) the Company
has the power and authority to execute, deliver and carry out the terms and provisions of this
Agreement and to consummate the transactions contemplated hereby; and (b) this Agreement has been
duly and validly authorized, executed and delivered by the Company, constitutes a valid and binding
obligation and agreement of the Company and is enforceable against the Company in accordance with
its terms.

4. Representations of the ValueAct Group. The ValueAct Group, jointly and severally, represent and
warrant as follows: (a) the ValueAct Group has the power and authority to execute, deliver and carry
out the terms and provisions of this Agreement and to consummate the transactions contemplated
hereby; (b) this Agreement has been duly and validly authorized, executed and delivered by the
ValueAct Group, constitutes a valid and binding obligation and agreement of the ValueAct Group and
is enforceable against the ValueAct Group in accordance with its terms; and (c) the ValueAct Group,
together with the ValueAct Affiliates, beneficially owns, directly or indirectly, an aggregate of
19,125,204 shares of Common Stock and such shares of Common Stock constitute all of the Common Stock
beneficially owned by the ValueAct Group and the ValueAct Affiliates or in which the ValueAct Group
or the ValueAct Affiliates have any interest or right to acquire, whether through derivative
securities, voting agreements or otherwise; and (d) as of the date of this Agreement, the ValueAct
Designee satisfies all of the Conditions. 4
<!-- page 5 -->
5. Termination.

(a) This Agreement is effective as of the date hereof and shall remain in full force and effect for
the period (the "Covered Period") commencing on the date hereof and ending on the date that is the
earliest of: (i) the Company's failure to appoint the ValueAct Designee to the Board following the
ValueAct Group's written request to the Company to have the ValueAct Designee appointed to the Board
pursuant to Section 1(a) of this Agreement; (ii) the failure of the Company to comply in good faith
with Section 1(e) of this Agreement; or (iii) the date which is the 60t h day prior to the Company's
2016 annual meeting of stockholders.

(b) The provisions of Section 1(d) this Section 5, Section 7 through Section 16 (and, for the
avoidance of doubt, the Confidentiality Agreement) shall survive the termination of this Agreement.
No termination pursuant to Section 5(a) shall relieve any party hereto from liability for any breach
of this Agreement prior to such termination.

6. Public Announcement and SEC Filing.

(a) The Company shall file promptly a Form 8-K reporting entry into this Agreement (the "Form 8-K")
and appending or incorporating by reference this Agreement as an exhibit thereto.

(b) The ValueAct Group shall promptly, but in no case prior to the date of filing of the Form 8-K by
the Company pursuant to Section 6(a) hereof, file an amendment to its Schedule 13D with respect to
the Company filed with the SEC on November 13, 2013 (the "ValueAct Schedule 13D"), reporting the
entry into this Agreement and amending applicable items to conform to its obligations hereunder.
None of the ValueAct Group, the ValueAct Affiliates or the ValueAct Designee shall (i) issue a press
release in connection with this Agreement or the actions contemplated hereby or (ii) otherwise make
any public statement, disclosure or announcement with respect to this Agreement or the actions
contemplated hereby, other than as mutually agreed to by the Company and the ValueAct Group.

(c) The Company shall promptly issue a press release in connection with this Agreement and in the
form attached hereto as Exhibit A (the "Press Release"), which is expressly agreed to by the
ValueAct Group.

7. Confidentiality Agreement. The Company hereby agrees that, notwithstanding any other provision of
this Agreement to the contrary, the ValueAct Group may be provided confidential information in
accordance with and subject to the terms of a Confidentiality Agreement in the form attached hereto
as Exhibit B (the "Confidentiality Agreement"), after the Confidentiality Agreement has been
mutually executed and delivered concurrently with the appointment of the ValueAct Designee to the
Board pursuant to the terms of this Agreement.

8. Compensation. The ValueAct Designee shall participate in all director compensation and benefit
programs in which the Company's other non-employee directors participate. The Company acknowledges
that pursuant to the ValueAct Group's policies, cash, equity awards and other property received by
the ValueAct Designee are held by such person for the benefit of certain members of the ValueAct
Group. The Company agrees that it will seek board or appropriate committee approval of all
stock-based awards made to the ValueAct Designee so that the grant of such awards shall be exempt
from Section 16(b) of the Exchange Act by virtue of Rule 16b-3 thereunder. Without limiting the
foregoing, the Company also acknowledges that as a result of the ValueAct Designee's service on the
Board, members of the ValueAct Group may be considered directors of the Company by deputization
under applicable interpretations of Section 16 of the Exchange Act. The Company agrees that it will
seek board or appropriate committee approval for purposes of Rule 16b-3 for all transactions in
classes of Company securities subject to Section 16 and involving the ValueAct Designee or any
member of the ValueAct Group who may be considered a "director by deputization" or who may be deemed
to have an indirect interest in the transaction in question.

9. Miscellaneous. The parties agree that irreparable damage would occur in the event any of the
provisions of this Agreement were not performed in accordance with the terms hereof and that such
damage would not be adequately compensable in monetary damages. Accordingly, the parties hereto
shall be entitled to an injunction or injunctions to prevent breaches of this Agreement, to enforce
specifically the terms and provisions of this Agreement exclusively in the Court of Chancery or
other federal or state courts of the State of Delaware and to 5
<!-- page 6 -->
require the resignation of the ValueAct Designee from the Board commencing on the date that is 10
days following the date that the ValueAct Designee and/or the ValueAct Group materially breaches its
obligations under this Agreement, provided, that, such breach has not been cured prior to the
expiration of such 10-day period, in addition to any other remedies at law or in equity, and each
party agrees it will not take any action, directly or indirectly, in opposition to another party
seeking relief. Each of the parties hereto agrees to waive any bonding requirement under any
applicable law, in the case any other party seeks to enforce the terms by way of equitable relief.
Furthermore, each of the parties hereto (a) consents to submit itself to the personal jurisdiction
of the Court of Chancery or other federal or state courts of the State of Delaware in the event any
dispute arises out of this Agreement or the transactions contemplated by this Agreement, (b) agrees
that it shall not attempt to deny or defeat such personal jurisdiction by motion or other request
for leave from any such court, (c) agrees that it shall not bring any action relating to this
Agreement or the transactions contemplated by this Agreement in any court other than the Court of
Chancery or other federal or state courts of the State of Delaware, and each of the parties
irrevocably waives the right to trial by jury, and (d) each of the parties irrevocably consents to
service of process by a reputable overnight mail delivery service, signature requested, to the
address set forth in Section 11 of this Agreement or as otherwise provided by applicable law. THIS
AGREEMENT SHALL BE GOVERNED IN ALL RESPECTS, INCLUDING WITHOUT LIMITATION VALIDITY, INTERPRETATION
AND EFFECT, BY THE LAWS OF THE STATE OF DELAWARE APPLICABLE TO CONTRACTS EXECUTED AND TO BE
PERFORMED WHOLLY WITHIN SUCH STATE WITHOUT GIVING EFFECT TO THE CHOICE OF LAW PRINCIPLES OF SUCH
STATE.

10. Expenses. All attorneys' fees, costs and expenses incurred in connection with this Agreement and
all matters related hereto will be paid by the party incurring such fees, costs or expenses.

11. Entire Agreement; Amendment. This Agreement and the Confidentiality Agreement contain the entire
agreement and understanding of the parties with respect to the subject matter hereof and supersede
any and all prior and contemporaneous agreements, memoranda, arrangements and understandings, both
written and oral, between the parties, or any of them, with respect to the subject matter hereof.
This Agreement may be amended only by an agreement in writing executed by the parties hereto, and no
waiver of compliance with any provision or condition of this Agreement and no consent provided for
in this Agreement shall be effective unless evidenced by a written instrument executed by the party
against whom such waiver or consent is to be effective. No failure or delay by a party in exercising
any right, power or privilege hereunder shall operate as a waiver thereof, nor shall any single or
partial exercise thereof preclude any other or further exercise thereof or the exercise of any
right, power or privilege hereunder.

12. Notices. All notices, consents, requests, instructions, approvals and other communications
provided for herein and all legal process in regard hereto shall be in writing and shall be deemed
validly given, made or served, when delivered in person or sent by overnight courier, when actually
received during normal business hours at the address specified in this subsection: If to the
Company: Allison Transmission Holdings, Inc. Mail Code L-25 One Allison Way Indianapolis, IN
46222-3271 Attention: General Counsel

If to the ValueAct Group: ValueAct Capital Management, L.P. One Letterman Drive Building D, 4t h
Floor San Francisco, CA 94129 Attention: General Counsel

13. Severability. If at any time subsequent to the date hereof, any provision of this Agreement
shall be held by any court of competent jurisdiction to be illegal, void or unenforceable, such
provision shall be of no force and effect, but the illegality or unenforceability of such provision
shall have no effect upon the legality or enforceability of any other provision of this Agreement. 6
<!-- page 7 -->
14. Counterparts. This Agreement may be executed in two or more counterparts either manually or by
electronic or digital signature (including by facsimile or electronic mail transmission), each of
which shall be deemed to be an original and all of which together shall constitute a single binding
agreement on the parties, notwithstanding that not all parties are signatories to the same
counterpart.

15. No Third Party Beneficiaries; Assignment. This Agreement is solely for the benefit of the
parties hereto and is not binding upon or enforceable by any other persons. No party to this
Agreement may assign its rights or delegate its obligations under this Agreement, whether by
operation of law or otherwise, and any assignment in contravention hereof shall be null and void.
Nothing in this Agreement, whether express or implied, is intended to or shall confer any rights,
benefits or remedies under or by reason of this Agreement on any persons other than the parties
hereto, nor is anything in this Agreement intended to relieve or discharge the obligation or
liability of any third persons to any party.

16. Interpretation and Construction. When a reference is made in this Agreement to a Section, such
reference shall be to a Section of this Agreement, unless otherwise indicated. The headings
contained in this Agreement are for reference purposes only and shall not affect in any way the
meaning or interpretation of this Agreement. Whenever the words "include," "includes" and
"including" are used in this Agreement, they shall be deemed to be followed by the words "without
limitation." The words "hereof, "herein" and "hereunder" and words of similar import when used in
this Agreement shall refer to this Agreement as a whole and not to any particular provision of this
Agreement. The word "will" shall be construed to have the same meaning as the word "shall." The
words "dates hereof" will refer to the date of this Agreement. The word "or" is not exclusive. The
definitions contained in this Agreement are applicable to the singular as well as the plural forms
of such terms. Any agreement, instrument, law, rule or statute defined or referred to herein means,
unless otherwise indicated, such agreement, instrument, law, rule or statute as from time to time
amended, modified or supplemented. Each of the parties hereto acknowledges that it has been
represented by counsel of its choice throughout all negotiations that have preceded the execution of
this Agreement, and that it has executed the same with the advice of said independent counsel. Each
party cooperated and participated in the drafting and preparation of this Agreement and the
documents referred to herein, and any and all drafts relating thereto exchanged among the parties
shall be deemed the work product of all of the parties and may not be construed against any party by
reason of its drafting or preparation. Accordingly, any rule of law or any legal decision that would
require interpretation of any ambiguities in this Agreement against any party that drafted or
prepared it is of no application and is hereby expressly waived by each of the parties hereto, and
any controversy over interpretations of this Agreement shall be decided without regards to events of
drafting or preparation.

[Signature Pages Follow] 7

IN WITNESS WHEREOF, each of the parties hereto has executed this COOPERATION AGREEMENT or caused the
same to be executed by its duly authorized representative as of the date first above written.
Allison Transmission Holdings, Inc.
<!-- page 8 -->
By: /s/ Eric C. Scroggins Name: Eric C. Scroggins Title: Vice President, General Counsel & Secretary
[Signature Page to Cooperation Agreement]

IN WITNESS WHEREOF, each of the parties hereto has executed this COOPERATION AGREEMENT or caused the
same to be executed by its duly authorized representative as of the date first above written.
<!-- page 9 -->
VA Partners I, LLC By: /s/ George F. Hamel, Jr. Name: George F. Hamel, Jr. Title: Chief Operating
Officer

ValueAct Capital Master Fund, L.P. By: /s/ George F. Hamel, Jr. Name: George F. Hamel, Jr. Title:
Chief Operating Officer

ValueAct Capital Management, L.P. By: /s/ George F. Hamel, Jr. Name: George F. Hamel, Jr. Title:
Chief Operating Officer

ValueAct Capital Management, LLC By: /s/ George F. Hamel, Jr. Name: George F. Hamel, Jr. Title:
Chief Operating Officer

ValueAct Holdings, L.P. By: /s/ George F. Hamel, Jr. Name: George F. Hamel, Jr. Title: Chief
Operating Officer

ValueAct Holdings GP, LLC By: /s/ George F. Hamel, Jr. Name: George F. Hamel, Jr. Title: Chief
Operating Officer /s/ Gregory P. Spivy Gregory P. Spivy [Signature Page to Cooperation Agreement]
<!-- page 10 -->
Schedule A

Members of ValueAct Group

VA Partners I, LLC

ValueAct Capital Master Fund, L.P.

ValueAct Capital Management, L.P.

ValueAct Capital Management, LLC

ValueAct Holdings, L.P.

ValueAct Holdings GP, LLC

Gregory P. Spivy
