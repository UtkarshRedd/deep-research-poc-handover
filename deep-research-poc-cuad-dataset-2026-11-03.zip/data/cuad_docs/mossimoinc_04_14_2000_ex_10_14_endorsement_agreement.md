<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2000-01-01 |
| Parties | MOSSIMO, INC. ("Company"); DAVID DUVAL ENTERPRISES, INC ("Licensor") |
| Source | CUAD v1 / MOSSIMOINC_04_14_2000-EX-10.14-ENDORSEMENT AGREEMENT |

ENDORSEMENT AGREEMENT

THIS AGREEMENT, made and entered into as of this 1st day of January, 2000, by and between MOSSIMO,
INC., 2450 White Road, 2nd Floor, Irvine, California 92614 ("Company"), and DAVID DUVAL ENTERPRISES,
INC. c/o International Management, Inc., IMG Center, 1360 East 9th Street, Suite 100, Cleveland,
Ohio 44114 ("Licensor"):

WITNESSETH:

WHEREAS, David Duval ("Duval") is recognized as a highly skilled professional golfer.

WHEREAS, Company desires to obtain the rights to use the name, fame, image and athletic renown of
Duval in connection with the advertisement and promotion of its products as provided herein;

WHEREAS, Duval has licensed all such rights to Licensor, along with the right to sublicense such
rights to third parties.

NOW, THEREFORE, the parties agree as follows:

1. DEFINITIONS. As used herein, the following terms shall be defined as set forth below:

(a) "Contract Period" shall mean that period of time commencing on January 1, 2000 and concluding
December 31, 2003, unless terminated sooner as provided herein.

(b) "Contract Year" shall mean the consecutive 12-month period beginning on any January 1st during
the Contract Period.

(c) "Products" shall mean casual apparel consisting of men's pants, shirts, sweaters, windshirts and
raingear.

(d) "Duval Identification" means the right to use, subject to the provisions hereof, Duval's name,
fame, nickname, initials, autograph, voice, video or film portrayals, facsimile signature,
photograph, likeness and image or facsimile image, and any other means of endorsement by Duval used
in connection with the advertisement and promotion of Company's Products.

(e) "Contract Territory" shall mean worldwide.

(f) "Outerwear" shall mean the golf shirts, sweaters, windshirts and raingear worn by Duval when he
plays professional golf.

-1-

(g) "Exempt Status" shall mean Duval has earned full playing privileges on the PGA Tour each year of
the contract term.

2. GRANT OF RIGHTS. In consideration of the remuneration to be paid to Licensor pursuant hereto,
Licensor grants to Company the right and license during the Contract Period to use the Duval
Identification solely in connection with the advertisement and promotion of Company's Products
within the Contract Territory as set forth herein. Licensor agrees not to grant the right to use the
Duval Identification to anyone other than Company in connection with the advertisement and promotion
of Products. It is understood that Company may not use the Duval Identification in connection with
any items for sale or resale, other than Company Products as specified herein.

3. PRIOR APPROVAL. Company agrees that no use of the Duval Identification nor any item used in
connection with the Duval Identification will be made hereunder unless and until the same has been
approved by Licensor. Licensor agrees that any material, advertising or otherwise, submitted for
approval as provided&sbsp;herein may be deemed by Company to have been approved hereunder if the
same is not disapproved in writing within ten (10) business days after receipt thereof. Licensor
agrees that any material submitted hereunder will not be unreasonably disapproved and, if it is
disapproved, that Company will be advised of the specific grounds therefor. If Company desires
immediate approval of advertising material hereunder, Company shall have the right to directly
contact Licensor's authorized agent to obtain such approval. Company agrees to protect, indemnify
and save harmless Licensor, Duval and their authorized agent, or any of them, from and against any
and all expenses, damages, claims, suits, actions, judgments and costs whatsoever, arising out of,
or in any way connected with, any advertising material furnished by, or on behalf of, Company.

4. REMUNERATION. (a) In consideration of the rights herein granted hereunder, Company shall pay to
Licensor the annual fee set forth in the schedule below (the "Annual Fee").

Year Annual Fee ---- ----------
<!-- page 2 -->
2000 $850,000 2001 $850,000 plus amounts paid under Section 5 in 2000 2002 $850,000 plus amounts
paid under Section 5 in 2000 and 2001 2003 $850,000 plus amounts paid under Section 5 in 2000-2002

One-half of the Annual Fee will be due on or before January 1 and July 1 of each Contract Year.

(b) As additional remuneration hereunder, Company agrees to pay Licensor an Additional License Fee
of One Million Five Hundred Thousand Dollars ($1,500,000) to be paid

-2-

in quarterly installments on or before January 1, April 1, July 1 and October 1 of the first
Contract Year.

(c) Licensor agrees that Duval must achieve and maintain Exempt Status on the PGA Tour throughout
each Contract Year and must participate as a player in a minimum of fifteen (15) official PGA Tour
events each Contract Year (Minimum Annual Performance Requirements). Licensor also agrees that the
Additional License Fee set forth in Section 4 (b), is an advance payment earned at a rate of
$375,000 on each annual anniversary date beginning December 31, 2000. In the event Duval does not
meet the Minimum Annual Performance Requirements for a Contract Year, $375,000 of the Additional
License Fee will be deemed to be unearned. Any unearned Additional License Fee is fully &bbsp;
refundable and due Company no later then January 31st of the following year. In the event the
Company terminates the Agreement in accordance with Section 16, any unearned Additional License Fee
will be fully refundable and due the Company as set forth in Section 16.

5. ADDITIONAL REMUNERATION. It is agreed that should Duval achieve any of the accomplishments set
forth in the following schedule during the Contract Period, then Company will pay Licensor the
additional remuneration set forth below for each such accomplishment due to the increased value in
the Duval Identification.

Accomplishment Additional Remuneration -------------- -----------------------

PGA Tour Win $25,000 PGA Tour 2-5 place finish $10,000

World Championship Event Win $40,000 World Championship Event 2-5 place finish $15,000

Major Win (Masters, U.S. Open, British Open, PGA Championship) $100,000 Major 2-5 place finish
$25,000

Named to Ryder Cup or President's Cup Team $15,000

Player of the Year $40,000

All additional remuneration will be due within thirty (30) days of each such accomplishment. Company
agrees that all additional remuneration earned by Licensor during each Contract Year will be added
to the Annual Fee for each remaining Contract Year during the Contract Period.

6. PAYMENTS. Licensor may elect to have payments made by check, wire transfer, or bank transfer.
Unless such election has been made in writing, all payments shall be made by check drawn to the
order of "David Duval Enterprises, Inc." and delivered to c/o IMG Center,

-3-

1360 East 9th Street, Cleveland, Ohio 44114, Attention: Treasurer. Past due payments hereunder shall
bear interest at the rate of (a) one and one-half percent (1-1/2%) per month, or (b) the maximum
interest rate permissible under law, whichever is less. All amounts herein are in United States
Dollars.

7. MARKETING COMMITMENT. Company agrees that it will aggressively promote Duval and his association
with Company and Company Products each Contract Year during the Contract Period.

8. SERVICES OF DUVAL. (a) If Company desires to utilize the services of Duval as a model in
connection with Company advertising to promote its products or for personal appearances to promote
Company, Licensor agrees, at the request of Company to provide the services of Duval upon a
reasonable number&bbsp;of days as mutually agreed upon and at places reasonably convenient to his
schedule. Company agrees that it will reimburse Licensor for all reasonable travel, lodging and meal
expenses incurred by Licensor or Duval in connection with such
<!-- page 3 -->
services. Company further understands that failure to utilize services of Duval pursuant to this
section shall not result in any reduction in payments to Licensor hereunder nor may the obligation
to provide services be carried forward or backward to any Contract Year. The obligations of Licensor
to provide services of Duval hereunder are subject to the condition that payments to Licensor are
current and up to date.

(b) Should Company use Duval in television advertising to promote Company's Products, Company will
make all applicable required union scale and pension and welfare payments. Company and Licensor will
mutually agree on the portion of the Annual Fee that shall be allocated for such broadcast services.

(c) Licensor agrees to cause Duval to wear Company's Products sold by Company when playing
professional golf, and while participating in golf exhibitions and outings, upon the condition that
Company supply Duval with such amounts of properly fitting Products, in fabrics and styles approved
by Duval and Company, as Duval may reasonably request which are suitable for his use in tournament
competition. Company agrees to pay all charges in connection with the delivery of such Products to
Duval, including shipping charges, air freight charges and customs charges. Company agrees to
reimburse Licensor's authorized agent for all such expenses incurred by it in connection with the
transfer of such Products to Duval.

(d) Licensor agrees that Duval will consult with Company as reasonably requested regarding the
development of a Company golf line of Products or a Duval Signature Line of Products as mutually
agreed upon. Company agrees that Licensor will receive additional remuneration in connection with
such golf line or signature line, whether as a royalty or otherwise, as mutually agreed upon.

9. COMPANY IDENTIFICATION. (a) It is agreed that the logo or name of Company (or Company's
subsidiaries as mutually agreed upon) (the "Company Logo") shall be affixed to mutually agreed upon
locations of Duval's Outerwear, excluding the right sleeve which is reserved for one of Licensor's
other sponsors, which he wears when he plays professional golf.

-4-

Company agrees that it will be responsible for, and the cost of, affixing the Company Logo on all
such Outerwear. Furthermore, Company understands that if Duval participates in a special team event
where there is an official uniform, then Duval is permitted to wear such uniform during such event
(e.g. Ryder Cup, President's Cup, etc.).

(b) Company shall provide and maintain, at its own expense, commercial general liability insurance
and advertising injury coverage, with limits of not less than One Million Dollars ($1,000,000.00),
and shall cause such policy to be endorsed to state that Duval is an additional named insured
thereunder. A certificate of insurance evidencing such coverage shall be furnished to Duval within
thirty (30) days of the full execution of this Agreement. Such insurance policy shall provide that
the insurer shall not terminate or materially modify such policy or remove Duval as an additional
named insured without prior written notice to Duval at least twenty (20) days in advance thereof.

10. AUTHORIZED AGENT. Licensor hereby designates International Management, Inc., IMG Center, 1360
East 9th Street, Suite 100, Cleveland, Ohio 44114, Attention: Charley Moore as its authorized agent
for all purposes hereunder. All notices or submissions to be made or delivered by Company to
Licensor pursuant to this Agreement shall be delivered to said address free of all charges such as,
for example, shipping charges and customs charges. In the event that any such charges are paid by
Licensor or by its authorized agent, Company agrees to make prompt reimbursement.

11. DEFAULT. (a) If either party at any time during the Contract Period shall (i) fail to make any
payment of any sum of money herein specified to be made, or (ii) fail to observe or&bbsp;perform any
of the covenants, agreements or obligations hereunder (other than the payment of money), the
nondefaulting party may terminate this Agreement as follows: as to (i) if such payment is not made
within ten (10) days after the defaulting party shall have received written notice of such failure
to make payment, or as to (ii) if such default is not cured within thirty (30) days after the
defaulting party shall have received written notice specifying in reasonable detail the nature of
such default. In order to be a sufficient notice hereunder, any such written notice shall specify in
detail each item of default and shall specify the provision of this Agreement which applies to each
item of default, and shall specify in detail the action the defaulting party is required to take in
order to cure each item of default. The termination rights set forth in this section shall not
constitute the exclusive remedy of the nondefaulting party hereunder, however, and if default is
made by either party hereunder, the other may resort to such other remedies as said party would have
been entitled to if this section had been omitted from this Agreement, subject to the terms of this
Agreement. Termination under the provisions of this section shall be without prejudice to any rights
or claims which the terminating party may otherwise have against the defaulting party, and if
Company is the defaulting party, Company shall be responsible for any and all payments due under the
terms of this Agreement in addition to other liabilities set forth above.

(b) If Company shall become bankrupt or insolvent, or if Company's business shall be placed in the
hands of a receiver, assignee or trustee, whether by voluntary act of Company or otherwise, the
Contract Period shall, at the election of Licensor, immediately terminate.

-5-
<!-- page 4 -->
12. USE OF DUVAL IDENTIFICATION AFTER TERMINATION. From and after the termination of the Contract
Period all of the rights of Company to the use of the Duval Identification shall cease absolutely
and Company shall not thereafter use or refer to the Duval Identification in advertising or
promotion in any manner whatsoever. It is further agreed that following termination of the Contract
Period, Company shall not advertise, promote, distribute or sell any item whatsoever in connection
with the use of any name, figure, design, logo, trademark or trade name similar to or suggestive of
the Duval Identification.

13. TRADEMARKS. Company agrees that it will not file, during the Contract Period or thereafter, any
application for trademark registration or otherwise obtain or attempt to obtain ownership of any
trademark or trade name within the Contract Territory or in any other country of the world which
consists of the Duval Identification or any mark, design or logo intended to make reference to Duval
or to identify products endorsed by Duval. In the event that, prior to commencement of the Contract
Period, Company has filed one or more applications for registration of any such trademark, or
otherwise has obtained any rights to such trademark, Company agrees to cause such applications
and/or trademarks to be assigned and transferred to Licensor forthwith.

14. RESERVATION OF RIGHTS. All rights not herein specifically granted to Company shall remain the
property of Licensor to be used in any manner Licensor deems appropriate. Company understands that
Licensor has reserved the right to authorize others to use Duval Identification within the Contract
Territory and during the Contract Period in connection with all tangible and intangible items and
services other than Products themselves.

15. INDEMNITY. Company agrees to protect, indemnify and save harmless Licensor, Duval and their
authorized agent, or any of them, from and against any and all expenses, damages, claims, suits,
actions, judgments and costs whatsoever, including reasonable attorneys' fees, arising out of, or in
any way connected with, actions or omissions of Company, any advertising material furnished by, or
on behalf of, Company or any claim or action for personal injury, death or other cause of action
involving alleged defects in Company's Products or services. Company agrees to provide and maintain,
at its own expense, general commercial and product liability insurance with limits no less than
Three Million Dollars ($3,000,000) and naming Licensor and Duval as additional named insureds.
Within thirty (30) days from the date hereof, Company will submit to Licensor evidence of such
policy, requiring that the insurer shall not terminate or materially modify such without written
notice to Licensor at least twenty (20) days in advance thereof.

16. SPECIAL RIGHT OF TERMINATION. Company shall have the right to terminate this Agreement upon
written notice to Licensor if the commercial value of the Duval Identification is substantially
reduced because Duval (i) has engaged in illegal or immoral conduct resulting in a felony
conviction; or (ii) fails an officially sanctioned drug test or is criminally convicted of any drug
related offense. Any termination pursuant to this paragraph shall become effective on the 30th day
next following the date of receipt by Licensor of Company's written notice to so terminate.

-6-

17. LIMITED LIABILITY. Notwithstanding anything to the contrary herein, in the event Company incurs
any expenses, damages or other liabilities (including, without limitation, reasonable attorneys'
fees) in connection with the performance or non-performance of any term or provision hereof,
Licensor's liability to Company shall not exceed the remuneration, excluding reimbursement of
expenses, actually paid to Licensor by Company. In no event will Licensor be liable for any
indirect, incidental, reliance, special or consequential damages arising out of the performance or
non-performance of this Agreement, whether or not Licensor had been advised of the possibility of
such damages. It is understood that Duval is not a party hereto and has no liability hereunder but
is an intended specific third party creditor beneficiary hereof.

18. WAIVER. The failure of either party at any time or times to demand strict performance by the
other of any of the terms, covenants or conditions set forth herein shall not be construed as a
continuing waiver or relinquishment thereof and each may at any time demand strict and complete
performance by the other of said terms, covenants and conditions. Any waiver of such rights must be
set forth in writing.

19. SEVERABILITY. If any provision of this Agreement shall be declared illegal, invalid, void or
unenforceable by any judicial or administrative authority, the validity of any other provision and
of the entire Agreement shall not be affected thereby.

20. ASSIGNMENT. This Agreement shall bind and inure to the benefit of Licensor, and the successors
and assigns of Licensor. The rights granted Company hereunder are personal to it, shall be used only
by it or its affiliate and shall not without the prior written consent of Licensor be transferred or
assigned to any other party. In the event of the merger or consolidation of Company with any other
entity, Licensor shall have the right to terminate the Contract Period by so notifying Company in
writing within sixty (60) days following Licensor's receipt of notice of such merger or
consolidation.

21. ARBITRATION/GOVERNING LAW. This agreement shall be governed by, and its provisions enforced in
accordance with, the laws of the State of Ohio, without regard to its principals of conflicts of
laws. In the event a dispute arises under this agreement which cannot be resolved, such dispute
shall be submitted to arbitration and resolved by a single arbitrator (who shall be a lawyer not
employed by or associated with either party to this agreement) in accordance with the Commercial
Arbitration Rules of the American Arbitration Association then in effect. All such arbitration shall
take place at the office
<!-- page 5 -->
of the American Arbitration Association located in Cleveland, Ohio. Each party is entitled to depose
one (1) fact witness and any expert witness retained by the other party, and to conduct such other
discovery as the arbitrator deems appropriate. The award or decision rendered by the arbitrator
shall be final, binding and conclusive and judgment may be entered upon such award by any court.

22. SIGNIFICANCE OF HEADINGS. Section headings contained herein are solely for the purpose
of&bbsp;aiding in speedy location of subject matter and are not in any sense to be given weight in
the construction of this Agreement. Accordingly, in case of any question with respect to the

-7-

construction of this Agreement, it is to be construed as though such section headings had been
omitted.

23. NO JOINT VENTURE. This Agreement does not constitute and shall not be construed as constituting
an association, partnership, joint venture or relationship of principal and agent or employer and
employee between Licensor and Company. Neither party shall have any right to obligate or bind the
other party in any manner whatsoever, and, except as expressly set forth herein, nothing herein
contained shall give, or is intended to give, any rights of any kind to any third person.

24. ENTIRE AGREEMENT. This writing constitutes the entire agreement between the parties hereto and
may not be changed or modified except by a writing signed by the party or parties to be charged
thereby.

25. EXECUTION AND DELIVERY. This instrument shall not be considered to be an agreement or contract
nor shall it create any obligation whatsoever on the part of Licensor and Company, or either of
them, unless and until it has been personally signed by a representative of Licensor and by a
representative of Company and delivery has been made of a fully signed original. Acceptance of the
offer made herein is expressly limited to the terms of the offer.

IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be executed as of the date
first above written.

MOSSIMO, INC. DAVID DUVAL ENTERPRISES, INC.

By: /s/ Edwin Lewis By: /s/ David Duval -------------------------------
------------------------------ Name: Edwin Lewis Name: David Duval Title: President and CEO

-8-
