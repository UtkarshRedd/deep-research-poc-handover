"""offload: keep oversized tool results out of model context (CLAUDE.md invariant 1).

A rendered tool result above `OFFLOAD_TOKENS` (estimated as chars / 4) is written to
`<workspace>/tool_out/<n>_<tool>.txt` and replaced by a pointer plus the first
`OFFLOAD_PREVIEW_LINES` lines. With the caps in `ToolCaps` this rarely triggers; it is the
safety net for pathological calls (e.g. `grep '.'` with context on a large scope). The agent
cannot open tool_out files without the optional bash tool, so the pointer text tells it to
narrow the call instead.
"""
from __future__ import annotations

import itertools
import threading
from pathlib import Path

from ..config import DEFAULT, Config
from ..workspace import Workspace

_counter = itertools.count(1)
_lock = threading.Lock()


def estimate_tokens(text: str) -> int:
    """Cheap, model-agnostic estimate (~4 chars per token for English prose and code)."""
    return max(1, len(text) // 4)


def maybe_offload(ws: Workspace, tool: str, text: str, config: Config = DEFAULT) -> tuple[str, Path | None]:
    """Return (text_for_model, offloaded_path). The text is unchanged when under the cap."""
    caps = config.tools
    n_tokens = estimate_tokens(text)
    if n_tokens <= caps.OFFLOAD_TOKENS:
        return text, None
    with _lock:
        n = next(_counter)
    path = ws.offload_dir() / f"{n:03d}_{tool}.txt"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    lines = text.splitlines()
    k = min(caps.OFFLOAD_PREVIEW_LINES, len(lines))
    head = (
        f"(result too large for context: ~{n_tokens} tokens, {len(lines)} lines; full text saved to "
        f"{path.relative_to(ws.root).as_posix()}. Showing the first {k} lines; narrow the pattern or "
        "scope doc_ids to see the rest.)"
    )
    return head + "\n" + "\n".join(lines[:k]), path
