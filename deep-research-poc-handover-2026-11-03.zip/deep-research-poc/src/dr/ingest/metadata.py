"""Metadata from the first ~2 pages of the parsed markdown.

Two strategies, in order:
  1. `parse_metadata_block` — deterministic: YAML front matter, or 'Key: Value' lines, or a
     markdown table in the first pages. Zero cost. Adapt the KEY_ALIASES to your extractor's output.
  2. `extract_metadata_llm` — Nemotron Nano over the first two pages -> structured JSON
     (prompts/metadata_extract.md). One call per doc, one-time; use when (1) yields < 2 fields.

Recommendation (PLAN Phase 0 decision): persist the result as a `<name>.meta.json` sidecar
and leave the body untouched so line numbers stay stable for citations.
"""
from __future__ import annotations

import re

KEY_ALIASES: dict[str, str] = {
    "title": "title", "document title": "title", "name": "title",
    "type": "doc_type", "document type": "doc_type", "doc type": "doc_type", "category": "doc_type",
    "date": "date", "effective date": "date", "agreement date": "date", "as of": "date",
    "parties": "parties", "party": "parties", "counterparty": "parties", "borrower": "parties", "lender": "parties",
    "client": "client", "account": "account", "version": "version", "amendment": "version",
}

_FRONT_MATTER_RE = re.compile(r"\A---\s*\n(.*?)\n---\s*\n", re.DOTALL)
_KV_RE = re.compile(r"^\s*\**([A-Za-z][A-Za-z /_-]{1,40}?)\**\s*[:|]\s*\**(.+?)\**\s*$")
_TABLE_ROW_RE = re.compile(r"^\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*$")


def first_pages(text: str, max_pages: int = 2, marker_re: str = r"^<!--\s*page\s+(\d+)\s*-->\s*$") -> str:
    rx = re.compile(marker_re)
    out, pages_seen = [], 0
    for ln in text.split("\n"):
        if rx.match(ln):
            pages_seen += 1
            if pages_seen > max_pages:
                break
        out.append(ln)
    return "\n".join(out)


def parse_metadata_block(text: str, max_pages: int = 2) -> dict[str, str]:
    head = first_pages(text, max_pages)
    meta: dict[str, str] = {}
    fm = _FRONT_MATTER_RE.match(head)
    if fm:
        for ln in fm.group(1).split("\n"):
            if ":" in ln:
                k, v = ln.split(":", 1)
                _put(meta, k, v)
        head = head[fm.end():]
    for ln in head.split("\n"):
        m = _TABLE_ROW_RE.match(ln) or _KV_RE.match(ln)
        if m:
            _put(meta, m.group(1), m.group(2))
    if "title" not in meta:
        for ln in head.split("\n"):
            if ln.startswith("# "):
                meta["title"] = ln[2:].strip()
                break
    return meta


def _put(meta: dict[str, str], k: str, v: str) -> None:
    key = KEY_ALIASES.get(k.strip().lower())
    val = v.strip().strip("*").strip()
    if not key or not val or val in {"-", "—", "N/A"}:
        return
    if key == "parties" and key in meta:
        meta[key] = meta[key] + "; " + val
    else:
        meta.setdefault(key, val)


def extract_metadata_llm(text: str, max_pages: int = 2) -> dict[str, str]:
    """TODO(Phase 0): get_llm('extractor') + prompts/metadata_extract.md -> structured dict."""
    raise NotImplementedError
