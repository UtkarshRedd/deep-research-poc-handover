<!-- page 1 -->
# Distributor Agreement
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| SEC Filing Date | 2011-04-15 |
| Parties | Lucid Inc.; [*] ("Distributor") |
| Source | CUAD v1 / LUCIDINC_04_15_2011-EX-10.9-DISTRIBUTOR AGREEMENT |

EXHIBIT 10.9 DISTRIBUTOR AGREEMENT This Distributor Agreement (the 'Agreement') dated [*] is between
Lucid Inc., a New York corporation, having a principal place of business at 2320 Brighton Henrietta
T/L Road, Rochester NY 14623 And [*] ('Distributor') For good and valuable consideration, the
parties hereby agree: 1. Appointment A) Lucid appoints the Distributor and the Distributor accepts
appointment as an exclusive authorized Lucid Distributor. The Distributor will be entitled to
purchase certain Lucid products and resell them to End User customers within the following market
segments:- hospital and medical research centres, including but not limited to dermatology,
pathology, plastic surgery and mohs surgery departments, clinical research centres, small animal
research facilities, cosmetic and cosmeceutical companies. B) The relationship of the parties under
this Agreement is that of independent contractors and nothing contained herein shall be construed as
creating any partnership, joint venture or agency relationship between the Distributor and Lucid.
Under no circumstances shall any employees of one party be deemed the employees of the other for any
purpose. The Distributor shall not have the authority to assume or create any obligation, or make
any representation of any kind on behalf of Lucid. 2. Term A) The initial term of this Agreement
shall be three (3) calendar years from the Agreement date. After the initial term, unless
terminated, this Agreement will automatically renew for periods of one (1) calendar year each. 3.
Products A) Lucid agrees to sell the following products to the Distributor: - VivaScope in-vivo
Confocal Microscope Model VS1500 VivaScope ex-vivo Confocal Microscope Model VS2500 VivaSCOPE
in-vivo Confocal Microscope Model VS3000 B) Further products manufactured by Lucid will be discussed
with the Distributor and by agreement will be added to this Agreement.
<!-- page 2 -->
4. Territory A) The Distributor is appointed as an exclusive Distributor within the following
territories: [*]. B) The Distributor agrees to act as a Distributor for Lucid within the above
Territories and not to solicit any sales of the Product(s) outside the above Territories. 5. Duties
of The Distributor A) The Distributor will use his best efforts to actively promote and sell the
Product to all relevant End Users within all relevant market segments within the Territory. B) The
Distributor agrees to undertake detailed sales demonstrations of the Product(s) to potential End
Users within all relevant market segments within the Territory. C) The Distributor agrees to allow
the End User to undertake sales evaluations (trials) of the product(s), using the Distributor's own
Demonstration Equipment as necessary. D) The Distributor agrees to promote the Product(s) at all
relevant trade shows, seminars and exhibitions held within the Territory. Lucid may, at it's
discretion, and in co-ordination with the Distributor when Lucid deems it necessary, at its own
expense and in its own name, engage in advertising activities of or hold or participate in
exhibitions of the Product in the Territory. E) The Distributors will not develop, manufacture or
sell any equipment or service, which in any way can be considered to be competitive to the equipment
or service offered by Lucid to the Distributor as Product. Lucid reserves the right to inform the
Distributor from time to time of specific products and companies that Lucid considers to be
competitive. A competitive product includes, but is not limited to, any product that would infringe
any claim of any Lucid owned or licensed patent issued or pending worldwide, whether or not
corresponding patent claims are in force in the Distributors territory or the sale of which would
restrict sale of Lucid product. F) The Distributor will provide to the End User, full installation
and customer training of the Product(s).
<!-- page 3 -->
6. Personnel A) The Distributor will employ as a minimum one full-time Lucid dedicated Product
Manager sales professional, giving one hundred per cent of their time to the promotion and sale of
Lucid products. 7. Demonstration Equipment A) The Distributor agrees to purchase demonstration
products as new products are released subject to special pricing. The Distributor agrees to use the
demonstration equipment for the duties as noted in 5 A, B, C, D as above and not to re-sell this
demonstration equipment to End Users. 8. Training A) The Distributor agrees to have all sales
professionals employed on Lucid products undergo sales training at an agreed location and to a level
approved by Lucid. B) The Distributor agrees to allow Lucid to accompany the Distributor sales
professionals during sales calls within the Territory as required. C) The Distributor agrees to
allow Lucid to participate in sales meetings for training purposes, held within the Distributor's
facility. 9. Information A) The Distributor will supply to Lucid, on a monthly basis, a detailed
listing of all sales prospects within the Territory. A sales prospect is considered by Lucid to be
any End User who has expressed an interest in purchasing Lucid products. B) The Distributor agrees
to supply to Lucid on a monthly basis a detailed sales forecast, highlighting potential order dates
of product. C) The Distributor agrees to supply to Lucid, from time to time, with any competitive
data emanating from the Territory. D) The Distributor agrees to supply Lucid, on an annual basis,
with a detailed sales plan for the Product(s), broken down by sales for each individual country
within the Territory. Any country or part of the territory that does not meet the sales expectations
as forecasted by the Distributor will be subject to review by Lucid and may subsequently be removed
from the Territory. The first sales plan will be presented to Lucid within three (3) months of the
signing of this agreement and annual sales plans will be due on November 30 each year.
<!-- page 4 -->
E) The distributor agrees to keep Lucid informed of details of forthcoming and installed units
together with customer details including customer name, address and email details at a level
sufficient to fulfil all requirements of US Government Export Administration Regulations and Lucid
quality audits. 10. Sub-Distribution The Distributor shall not be entitled to engage
sub-distributors or any other third party as his sub-agent for sales of the Product, without having
obtained Lucid's prior written approval. Such approval shall not be unreasonably withheld. 11.
Intellectual Property A) Lucid is the sole owner of all trademark symbols and logos under which the
products will be sold. Lucid agrees that the Distributor may use the appropriate trademarks to
promote the sale of products in the Territory. Such use is only with Lucid's permission and must be
related to the sale of Lucid products. The Distributor acquires no rights to Lucid trademarks by
selling Lucid products. The Distributor may not use Lucid trademarks, symbols or logos as part of
its business or corporate names. B) The Distributor will assist Lucid in protecting Lucid's patents,
copyright, trademarks and logos. The Distributor will inform Lucid of any known or suspected
violations of Lucid's patents, copyright, trademarks, symbols and logos. If Lucid requests, the
Distributor will assist in protecting such intellectual property from infringement. 12. Duties of
Lucid A) Lucid will supply to the Distributor, free of any charge, reasonable quantities of Product
datasheets. B) Lucid will supply to the Distributor, free of charge, images of skin in vivo. Lucid
will make every reasonable effort to supply images of skin to the Distributor, which are required by
the Distributor for a particular End User application. C) Lucid will make available free of charge
to the Distributor the services of at least one suitable sales professional. D) Lucid will make
available free of charge to the Distributor the services of at least one Clinical Research Engineer.
This person will normally reside at Lucid's USA Headquarters but may from time to time assist the
Distributor within the Territory.
<!-- page 5 -->
E) Lucid will make its facility in the USA available, from time to time, to the Distributor and the
Distributor's sales force for sales training purposes. Lucid will also offer this service to the
Distributor for the introduction of potential End Users from the Territory. 13. Prices, Terms &
Conditions of Sale A) The Distributor may purchase Products from Lucid at the price published by
Lucid, from time to time, in the International Distributor price list (attached). Lucid agrees to
allow the Distributor a discount of thirty (30) per cent against the published International
Distributor price list. B) All orders from the Distributor to Lucid will be subject to Lucid's
standard terms and conditions of sale. C) All prices are quoted by Lucid in US Dollars and are sold
Ex Works, becoming the Distributor's property when despatched from the Lucid facility. 14. Minimum
Purchase Obligation The Distributor agrees to purchase from Lucid minimum agreed quantity of product
in the first, second and third years of the Agreement, excluding demonstration product. These
quantities to be agreed by both parties in the initial detailed sales plan noted in clause 9D and
amended with further agreement in subsequent annual sales plans 15. PAYMENT TERMS The Distributor
agrees to abide by Lucid's standard payment terms, which are as follows; One Hundred (100) per cent
of order value by sixty ( 90 ) day irrevocable letter of credit when order is placed on Lucid. 16.
TERMINATION A) Either party may terminate this agreement by giving written Notice to the other party
if: i) The other party fails to perform or satisfy any of the conditions, covenants or obligations
of this Agreement. ii) The other party files or has filed against it, a petition seeking relief
under any bankruptcy, insolvency, reorganisation, moratorium, liquidation or similar law affecting
creditors' rights B) In addition, Lucid may terminate this agreement by giving the Distributor
Written Notice if there is any change of control, ownership or management of the Distributor.
<!-- page 6 -->
C) Either party may terminate this agreement by providing Ninety days Written Notice. 17. EFFECT OF
TERMINATION A) Upon the termination of this Agreement: 1. The Distributor shall terminate any
registration it has made as a Lucid Distributor. 2. Distributor will immediately return any samples,
sales literature, promotional materials and other documents supplied to the Distributor free of
charge from Lucid. 3. Any right to use Lucid patents, copyrights, trademarks, symbols and logos
shall immediately cease. B) If this Agreement is terminated Lucid shall not be liable for any
incidental, indirect; special punitive of consequential damages of any kind, including any perceived
or real market development costs. 18. Incident and Traceability Reporting A) DISTRIBUTOR will
IMMEDIATELY report via telephone communication to Lucid any incidents that involve the use of
PRODUCTS sold by the DISTRIBUTOR to end users that affect patient safety or well-being (an
"INCIDENT"). Such oral incident reporting will be followed immediately by a written incident report
that documents the detailed conditions that resulted in the INCIDENT and Distributor shall
thereafter co-operate with Lucid in the investigation of any and all conditions that led to, or
resulted from the INCIDENT. B) DISTRIBUTOR will routinely, but not less than annually, report in
writing to Lucid, documenting the end users to which PRODUCTS have been sold, including the address,
telephone number and name of a person who is the primary emergency contact. Lucid will use this
information in the event of Lucid issuing a product recall of the PRODUCT for safety or other
reasons. If such an event occurs, and upon Lucid's request, the DISTRIBUTOR will immediately provide
Lucid with the names, addresses, telephone numbers and emergency contact personnel of any end user
sites not previously reported to Lucid. 19. LIMITATION OF LIABILITY A) Lucid does not guarantee
delivery of Product by any particular date. If Lucid accepts Distributor's order and fails to
deliver ordered products, Distributors sole remedy will be limited to refund of money paid to Lucid
for any undelivered products. B) Lucid will not have any liability or responsibility to Distributor
or any other person or entity for any consequential, indirect, special, punitive or incidental
damages or lost profits, whether foreseeable or unforeseeable, based on
<!-- page 7 -->
claims of Distributor or Distributor's customers (including but not limited to, claims for loss of
data, goodwill, profits, use of money or use of product, interruption in use or availability of data
stoppage or other work or impairment or assets) arising out of breach or failure of express or
implied warranty, breach of contract, misrepresentation, negligence, strict liability in tort or
otherwise, except only in the case of death or personal injury where and to the extent that
applicable law requires such liability. In no event will the aggregate liability incurred by Lucid
in any action or proceeding exceed the total amount actually paid to Lucid by Distributor for the
purchase of the products that actually caused the damage or loss. 20. Governing Law A) This
Agreement shall be governed by and interpreted in accordance with the laws of the State of New York,
USA without regard to conflict of laws principles. 21. NOTICE A) All notices required herein
("NOTICE") shall be given in English language. Notices must be sent postage pre-paid, and (a)
delivered personally against written receipt (b) transmitted via facsimile or (c) sent by nationally
recognised overnight courier service, or (d) sent via first class certified mail, return receipt
requested, to the address listed above. Any change of addresser fax number must be designated in
writing and served in accordance with this Section. Notice shall be effective (a) upon receipt if
personally delivered (b) upon confirmation of transmission if sent via facsimile and (c) two (2)
business days after deposit with the courier or an official depository of the US Post Office, if
sent via recognised overnight courier of via Certified Mail, as the case may be. 22 ENTIRE
AGREEMENT: A) This Agreement, including the Price List attached hereto, as amended from time to
time, constitutes the entire understanding between the parties with respect to the subject matter of
this Agreement and supersedes and replaces all previous proposals, both oral and written,
negotiations, representations, commitments, writings, contracts, agreements and all other
communications between the two parties. Signatures on the next page
<!-- page 8 -->
IN WITNESS WHEREOF, the parties have duly executed this Agreement on the date first above written.

LUCID Inc. [*] By By Marcy K. Davis-McHugh [*] TITLE TITLE: Corporate Vice President

DATE [*] DATE: [*]

SIGNATURE SIGNATURE
