"""Approach 1: first move + ephemeral BM25 deep list (PLAN Phase 4).

Question's Gambit, adapted for small models and no index:
  1. ONE planner call decomposes the question into 3–10 Clues (entities, identifiers, dates,
     phrasings), each with 1–3 grep patterns and a BM25 query (prompts/first_move.md). If the
     model's JSON cannot be repaired, `fallback_clues` derives clues from the question text.
  2. The HARNESS runs every clue in parallel: grep counts per document + BM25 search to depth
     FIRST_MOVE_K_PER_CLUE. This never depends on the model's multi-tool-call support.
  3. Union; documents ranked by (#clues that hit, BM25 score + log grep counts); optional local
     rerank of the top chunks (dr/tools/rerank.py, no-op unless enabled).
  4. FirstMoveResult: an opening observation (per-clue counts, top candidate documents, top
     line-cited hits) that becomes part of the researcher's system prompt, plus the deep ranking
     for the question cached in the index so `page_results` can page it.

Measured upstream: +5.5–10.9 pts, candidate recall -> 98%, ~28 s median (frontier models).
Budget here: stages.FIRST_MOVE (30 s): the planner call is bounded by that deadline.
"""
from __future__ import annotations

import math
import re
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from langchain_core.messages import HumanMessage
from pydantic import BaseModel, Field

from ..config import DEFAULT, Config
from ..models import Clue, FirstMoveResult, SearchHit
from ..prompts import load
from ..structured import ModelCaller
from ..tools import grep as _grep
from ..tools import manifest as _manifest
from ..tools.bm25 import BM25Index
from ..tools.rerank import rerank
from ..trace import Trace
from ..workspace import Workspace

_QUOTED_RE = re.compile(r"[\"“']([^\"”']{3,60})[\"”']")
_IDENT_RE = re.compile(r"\b[A-Z]{2,}-?\d[\w-]*\b|\b\d{1,3}(?:,\d{3})+(?:\.\d+)?\b|\b\d+(?:\.\d+)?\s?%")
_CAPS_RE = re.compile(r"\b(?:[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){0,3})\b")
_STOP = {"what", "which", "when", "where", "how", "does", "did", "the", "under", "between", "and", "for",
         "with", "that", "this", "must", "is", "are", "was", "were", "list", "every", "all", "of", "to",
         "in", "on", "by", "as", "at", "from", "do", "any", "an", "a", "it", "its", "their", "there"}


class CluePlan(BaseModel):
    clues: list[Clue] = Field(min_length=1)


# --------------------------------------------------------------------------- decomposition


def decompose(question: str, ws: Workspace, caller: ModelCaller | None, config: Config = DEFAULT) -> tuple[list[Clue], str]:
    """Planner call -> clues; returns (clues, 'model' | 'fallback')."""
    if caller is not None:
        rows, total = _manifest.list_docs(ws, config=config)
        plan = caller.json([HumanMessage(content=load(
            "first_move", n_docs=len(ws.manifest), max_clues=config.tools.FIRST_MOVE_CLUES_MAX,
            manifest_preview=_manifest.render(rows, total), question=question,
        ))], CluePlan)
        if plan is not None:
            clues = [_sanitize(c) for c in plan.clues[: config.tools.FIRST_MOVE_CLUES_MAX]]
            clues = [c for c in clues if c.grep_patterns or c.bm25_query]
            if clues:
                return clues, "model"
    return fallback_clues(question, config), "fallback"


def fallback_clues(question: str, config: Config = DEFAULT) -> list[Clue]:
    """Model-free clues: quoted strings, identifiers/amounts, capitalised terms, plus the question itself."""
    clues: list[Clue] = []
    seen: set[str] = set()

    def add(text: str, patterns: list[str], query: str | None) -> None:
        key = text.lower()
        if key in seen or not text:
            return
        seen.add(key)
        clues.append(Clue(text=text, grep_patterns=patterns, bm25_query=query))

    for m in _QUOTED_RE.finditer(question):
        add(m.group(1), [re.escape(m.group(1))], m.group(1))
    for m in _IDENT_RE.finditer(question):
        add(m.group(0), [re.escape(m.group(0))], m.group(0))
    for m in _CAPS_RE.finditer(question):
        term = m.group(0)
        words = [w for w in term.split() if w.lower() not in _STOP]
        if words and not (len(words) == 1 and question.startswith(term)):
            t = " ".join(words)
            add(t, [re.escape(t)], t)
    content_words = [w for w in re.findall(r"[A-Za-z][A-Za-z-]{2,}", question) if w.lower() not in _STOP]
    add("question keywords", [], " ".join(content_words[:8]) or question)
    return clues[: config.tools.FIRST_MOVE_CLUES_MAX]


def _sanitize(c: Clue) -> Clue:
    pats = []
    for p in c.grep_patterns[:3]:
        p = p.strip()
        if not p:
            continue
        try:
            re.compile(p)
            pats.append(p)
        except re.error:
            pats.append(re.escape(p))
    q = (c.bm25_query or "").strip() or None
    return Clue(text=c.text.strip()[:120], grep_patterns=pats, bm25_query=q)


# --------------------------------------------------------------------------- harness fan-out


def first_move(
    ws: Workspace, question: str, clues: list[Clue], bm25: BM25Index, config: Config = DEFAULT,
    trace: Trace | None = None, decomposed_by: str = "model",
) -> FirstMoveResult:
    t0 = time.perf_counter()
    caps = config.tools
    tasks: list[tuple[str, int, str]] = []
    for i, c in enumerate(clues):
        tasks += [("grep", i, p) for p in c.grep_patterns]
        if c.bm25_query:
            tasks.append(("bm25", i, c.bm25_query))
    expanded: dict[int, str] = {}

    def run(task: tuple[str, int, str]):
        kind, i, arg = task
        if kind == "grep":
            return task, _grep.grep(ws, arg, config=config)
        hits = bm25.ranking(arg)[: caps.FIRST_MOVE_K_PER_CLUE]
        # pseudo-relevance feedback: a second ranking with the documents' own vocabulary
        q2 = bm25.expand_query(arg, caps.FIRST_MOVE_FEEDBACK_DOCS, caps.FIRST_MOVE_EXPANSION_TERMS)
        if q2 != arg:
            expanded[i] = q2
            seen = {(h.doc_id, h.start_line) for h in hits}
            hits = hits + [h for h in bm25.ranking(q2)[: caps.FIRST_MOVE_K_PER_CLUE] if (h.doc_id, h.start_line) not in seen]
        return task, hits

    with ThreadPoolExecutor(max_workers=min(8, max(1, len(tasks)))) as ex:
        results = list(ex.map(run, tasks))

    clue_hits: dict[str, set[int]] = {}
    grep_counts: dict[str, int] = {}
    bm25_best: dict[str, float] = {}
    clue_lines: list[str] = []
    top_hits: list[SearchHit] = []
    per_clue_summary: dict[int, list[str]] = {i: [] for i in range(len(clues))}
    for (kind, i, arg), res in results:
        if kind == "grep":
            for doc_id, n in res.per_doc_counts:
                clue_hits.setdefault(doc_id, set()).add(i)
                grep_counts[doc_id] = grep_counts.get(doc_id, 0) + n
            tops = ", ".join(f"{d}:{n}" for d, n in res.per_doc_counts[:3])
            per_clue_summary[i].append(f"grep /{arg}/: {res.total_matches} matches in {res.docs_with_matches} docs" + (f" (top {tops})" if tops else ""))
            for m in res.matches[:2]:
                top_hits.append(SearchHit(rank=0, doc_id=m.doc_id, start_line=m.line, end_line=m.line, page=m.page,
                                          score=0.0, snippet=m.text.strip()))
        else:
            if res:
                mx = res[0].score or 1.0
                for h in res:
                    clue_hits.setdefault(h.doc_id, set()).add(i)
                    bm25_best[h.doc_id] = max(bm25_best.get(h.doc_id, 0.0), h.score / mx)
                label = f"bm25 /{arg}/" + (f" (+ expanded: {expanded[i][len(arg):].strip()})" if i in expanded else "")
                per_clue_summary[i].append(f"{label}: {len(res)} chunks; top docs " + ", ".join(dict.fromkeys(h.doc_id for h in res[:3])))
                top_hits += res[:3]
            else:
                per_clue_summary[i].append(f"bm25 /{arg}/: no hits")

    ranked = sorted(clue_hits, key=lambda d: (len(clue_hits[d]), bm25_best.get(d, 0.0) + math.log1p(grep_counts.get(d, 0))), reverse=True)
    # the question itself is the deep ranking the agent can page through
    deep = rerank(question, bm25.ranking(question), config)
    seen: set[tuple[str, int]] = set()
    hits: list[SearchHit] = []
    for h in (deep[:5] + top_hits):
        key = (h.doc_id, h.start_line)
        if key in seen:
            continue
        seen.add(key)
        hits.append(h)
        if len(hits) >= caps.FIRST_MOVE_TOP_HITS:
            break

    for i, c in enumerate(clues):
        clue_lines.append(f"- {c.text}: " + ("; ".join(per_clue_summary[i]) or "no patterns"))
    lines = [f"## Opening observation (first move: {len(clues)} clues, {len(ranked)} candidate documents of {len(ws.manifest)})"]
    lines += clue_lines
    lines.append(f"Top candidate documents (clues hit / {len(clues)}):")
    for d in ranked[: caps.FIRST_MOVE_TOP_DOCS]:
        me = ws.manifest[d]
        meta = ", ".join(x for x in (me.doc_type, me.date) if x)
        lines.append(f"  {d} — {me.title[:70]}" + (f" ({meta})" if meta else "") + f" — {len(clue_hits[d])}")
    lines.append("Top hits (read around these lines):")
    for h in hits:
        pg = f" p.{h.page}" if h.page else ""
        lines.append(f"  [{h.doc_id}:{h.start_line}{pg}] {h.snippet[:160]}")
    lines.append(f"The full question ranking has {len(deep)} chunks: page_results(\"{question[:80]}\", page=2) pages it.")
    est_tokens = sum(bm25.doc_token_estimate(d) for d in ranked)
    fm = FirstMoveResult(clues=clues, opening_observation="\n".join(lines), candidate_doc_ids=ranked,
                         clues_hit={d: len(s) for d, s in clue_hits.items()}, estimated_candidate_tokens=est_tokens,
                         decomposed_by=decomposed_by, elapsed_ms=int((time.perf_counter() - t0) * 1000))
    if trace:
        trace.stage("first_move", "end", n_clues=len(clues), n_tasks=len(tasks), n_candidates=len(ranked),
                    n_expanded=len(expanded), deep_ranking=len(deep), est_tokens=est_tokens,
                    decomposed_by=decomposed_by, ms=fm.elapsed_ms)
    return fm


def run_first_move(ws: Workspace, question: str, bm25: BM25Index, config: Config = DEFAULT, llm: Any | None = None,
                   trace: Trace | None = None, deadline_ts: float | None = None) -> FirstMoveResult:
    """Decompose (model, bounded by the deadline) + harness fan-out. `llm` is the planner."""
    if llm is None:
        from ..llm import get_llm

        llm = get_llm("planner")
    caller = ModelCaller(llm, trace, "first_move", "planner", deadline_ts=deadline_ts)
    clues, how = decompose(question, ws, caller, config)
    return first_move(ws, question, clues, bm25, config, trace, decomposed_by=how)
