<!-- page 1 -->
# TRANSPORTATION CONTRACT GENERAL CONDITIONS
| Field | Value |
|---|---|
| Document Type | Transportation Agreement |
| Agreement Date | 2012-01-30 |
| Parties | SOLANA PETROLEUM EXPLORATION COLOMBIA LIMITED ("SENDER"); ECOPETROL S.A.("ECOPETROL") ("SHIPPER") |
| Source | CUAD v1 / GRANTIERRAENERGYINC_05_07_2012-EX-10.6-TRANSPORTATION CONTRACT |

EXHIBIT 10.6 TRANSPORTATION CONTRACT SPECIFIC CONDITIONS

PURPOSE

ECONOMIC CONDITIONS

CONTRACTED CAPACITY

POINTS OF ENTRANCE AND EXIT MANSOYÁ - TUMACO

Date Bogota D.C. January 30, 2012

Contract No. VIT-005-2012

SENDER SOLANA PETROLEUM EXPLORATION COLOMBIA LIMITED

TAX ID 830.051.027-8

SHIPPER ECOPETROL S.A. TAX ID 899.999.068-1

T Y P E O F CRUDE OWN PRODUCTION x PROPERTY

Transportation Service of liquid hydrocarbons through the "Trasandino" Pipeline(OTA) and
Mansoyá-Orito (OMO) pipeline.

Estimated Value of the Contract Six millions seven hundred forty five thousand dollars of The United
States of America (USD$6.745.000). Rate "Mansoyá-Orito" Pipeline (OMO) Cero point five one nine two
dollars of The Untied States of America (USD$0,5192) per Barrel Rate "Trasandino" Pipeline (OTA)
Three dollars eleven forty three cents of dollars of The Untied States of America (USD$3,1143) per
Barrel.

PRODUCT Daily Average (Barrels/calendar day) Monthly average (Barrels/month) Crude 10.000 300.000

TERM OF EXECUTION From January 30, 2012 until July 29, 2012

Point # Type of Point Name of Point Distance (km)

1 Point of Entrance Entrance bridle to the srapers tramp in the PK 35+400 of OMO 377,3 2 Point of
Exit Exit bridle to the main tanks of Tumaco Plant.
<!-- page 2 -->
SPECIFICATIONS OF PRODUCTS TO BE SHIPPED PRODUCT CHARACTERISTICS

Quality Specifications of Crude: Bases on the operating conditions of the "Trasandino" Pipeline,
ECOPETROL shall only receive daily crude oil from the SENDER up to a maximum equivalent to 12% of
the total light crude received in the day at the Orito Plant. The indicated Quality Specifications
correspond to those which the final mix of crude delivered by the SENDER shall have. In the event in
which the Crude delivered by the SENDER fails to meet the Quality Specification and if the buying of
dissolvent is required to make mixes, the SENDER shall request approval from ECOPETROL before its
delivery for transportation by ECOPETROL. It is the SENDER's responsibility to ensure its
possession, control and entitlement to deliver or make deliver on its behalf the crude received by
ECOPETROL at the Entrance Point. The SENDER shall hold ECOPETROL harmless against any claim, action
or damages which may result from suits, claims or administrative, judicial or extrajudicial actions
from any third persons alleging ownership or possession on the crude to be shipped. BONDS

In witness whereof, and accepting the General Conditions and the Specific Conditions this Contract
is subscribed in two (2) duplicates of the same content in the city of Bogotá on the thirtieth
(30th) day of the month of January, 2012.

Characteristics Lower Limit Upper Limit Temperature 120°F Viscosity 300 cSt 30ºC. Water and
sediments (BSW) 0,5 % in volume Salt 20 PTB Steam pressure Eleven (11) psi at 100°F Gravity in API
degrees 18 degrees 50 degrees

TYPE OF BOND AMOUNT Performance Insurance Policy Four thousand forty seven millions of Colombian
pesos ($4.047.000.000)

1
<!-- page 3 -->
All notifications and communications to be delivered to the Parties as a result of the execution of
the Contract hereof shall be made to the addresses indicated as follows: ECOPETROL

THE SENDER

BY THE SENDER: BY ECOPETROL S.A.: Signature "/s/ Duncan Nightingale" Signature "/s/ Rafael Espinosa
Rozo" Name: DUNCAN NIGHTINGALE Name: RAFAEL ESPINOSA ROZO Title: Legal Representative Pasaporte No.
BA386341 Title: Pipelines Manager C.C. No. 79.432.773 de Bogotá D.C. Signature "/s/ Hugo Rodriguez"
Name: HUGO RODRIGUEZ Title: Legal Representative C.C. No. 3.093.980

ADDRESS 5.1 Carrera 7 No. 37 - 69 Piso 9 Edificio Teusacá TELEPHONE 5.2 2343491 FAX 5.3 2343532 CITY
5.4 Bogotá D.C.

ADDRESS 5.5 Calle 113 No. 7 - 80 Piso 17 TELEPHONE 5.6 6585757 FAX 5.7 2139327 CITY 5.8 Bogotá D.C.

2
<!-- page 4 -->
TRANSPORTATION CONTRACT GENERAL CONDITIONS The Contract hereof executed between ECOPETROL and the
SENDER shall be comprised by these General Clauses and by the Specific Conditions subscribed by the
Parties. All current legal provisions shall apply thereto and therefore the Parties are obliged to
fulfill them regardless of whether or not they are stated in this document or in the Specific
Conditions. PARTIES: The Parties of the Contract shall be: ECOPETROL S A, hereinafter ECOPETROL, a
company of mixed economy, authorized by law 1118 of 2006, attached to the Ministry of Mines and
Energy, acting pursuant to its by-laws with its main domicile in Bogotá D C with Tax ID 899.999.068-
1, represented by whoever subscribes the Specific Conditions of the Contract and the SENDER,
identified as indicated in the Specific Conditions, who is obliged subject to the conditions and
terms set forth herein. ECOPETROL and the SENDER may also be called in this Shipment Contract or
"Contract", individually as the "Party" or jointly as the "Parties". RECITALS:

By virtue of the above the parties agree: CLAUSE FIRST PURPOSE

1. ECOPETROL is the owner of the pipelines of private use indicated in the Specific Conditions
(hereinafter, the "Pipelines"). 2. Currently the Pipelines have Available Capacity for the shipment
of crudes from third parties. 3. The SENDER has crude oils of its own/production that wishes to ship
through the Pipelines under the conditions established in this Contract and its annexes, with the
quality specifications set forth by ECOPETROL for its shipment through the Pipelines. 4. The Parties
have agreed to enter into this Contract under the "Spot" shipping contract modality, by virtue of
which, the SENDER shall be obliged to pay the shipping fee applicable for the barrels effectively
shipped through the Pipelines during the Month of Operation and subject to the existence of
Available Capacity. 5. The SENDER knows and accepts in all its terms the Manual of the Shipper of
the Pipelines, which is an integral part of the Contract hereof as Annex 1.

1.1 ECOPETROL is obliged within the terms and conditions set out in this Contract, its annexes and
in the applicable regulations, to ship through the Pipeline, from the Entrance Points agreed and
detailed in the Specific Conditions to the Exit Points agreed and detailed in Specific Conditions,
crudes owned/produced by the SENDER and delivered in the Entrance Points pursuant to the
instructions and procedures set out by ECOPETROL (hereinafter, the "Service").

1
<!-- page 5 -->
CLAUSE SECOND DEFINITIONS 2.1 All capitalized terms shall have the meaning as defined in the Clauses
of this Contract and/or in Clause 2 of the Manual of the Shipper of ECOPETROL. CLAUSE THIRD TERM 3.1
The Contract shall be in force during the period indicated in the Specific Conditions. 3.2 The term
of execution of the Service for the Contracted Capacity being the purpose of the Contract hereof may
be extended by common agreement between the Parties by a document subscribed prior to the date of
termination of the Contract, subject to the existence of Available Capacity in the Pipeline during
the month of Operation in which the Service is to be provided. 3.3 the obligation of the monthly
payment borne by the SENDER for the Service shall be made during the totality of the term of
execution of the Contract. CLAUSE FOURTH AMOUNT OF THE CONTRACT 4.1 The initial estimated amount of
the Contract hereof is as indicated in the Specific Conditions. The final amount of the Contract
shall correspond to the total of the actual invoicing by ECOPETROL and shall be established upon
termination and final liquidation of the same.

1.2 By virtue of this Contract and as indicated in the Specific Conditions, the SENDER shall have a
limited capacity for shipment by the Pipeline of crudes of its own/production, subject to the
existence of Available Capacity during the month of operation of the Service (hereinafter, the
"Contracted Capacity"). 1.3 The scope of the obligations of ECOPETROL is limited to the reception,
custody, shipment, decanting, and indispensable storage for the transportation and shipment of Crude
to the SENDER. 1.4 The Contract hereof does not include the provision of the unloading service in
unloading areas, the treatment of crudes, the storage in export terminals, or any terminal services.
It is the responsibility of the SENDER to execute or contract these services whenever it may be
necessary. The SENDER shall wave and hold ECOPETROL harmless for any damage or prejudice suffered by
ECOPETROL as a result of failing to receive the Crude in the Exit Point, either by lack of the
services before mentioned or by failing to provide the appropriate facilities for such purpose.

2
<!-- page 6 -->
CLAUSE FIFTH FEES 5.1 The Contract is agreed under the "Spot" modality, understanding that the
SENDER shall pay for the Barrels effectively transported through the Pipeline subject to the
existence of Available Capacity in the Pipeline during the Month of Operation in which the Service
is to be provided. 5.2 The SENDER is obliged irrevocably and unconditionally by subscription of this
Contract to the payment of the fee indicated in the Specific Conditions for each Barrel effectively
transported making use of its Contracted Capacity (hereinafter, the "Fee"). CLAUSE SIXTH
READJUSTMENTS 6.1 The Monthly Fee agreed in this Contract shall be adjusted each year pursuant to
the formula established by the Ministry of Mines and Energy in Resolution 124 386 of July 15th, 2010
or any provisions the amend, add or supersede it. CLAUSE SEVENTH TERMS OF PAYMENT

7.1 The SENDER undertakes the obligation to pay irrevocably and unconditionally the Service for the
Contracted Capacity, twenty (20) calendar days at the latest, after ECOPETROL files in the offices
of the SENDER the invoice for the provision of the Service. 7.2 ECOPETROL shall deliver to the
SENDER on the twentieth (20) day of each month at the latest a preliminary account (invoice) with
the amount that the SENDER must pay (corresponding to the current month) based on the Nomination
made by the SENDER for the current month. 7.3 Considering that the charging for the Service is made
on the Nomination of the current month, ECOPETROL in order to make the corresponding adjustment to
the nominated volume and the volume of Crude actually shipped, shall generate the corresponding
debit and credit vouchers and shall deliver said debit or credit vouchers together with the
invoice(s) of the nominated month to be charged. The due date of the debit and credit vouchers shall
be the same as for the invoice (with the nominated volume) of the current month in order to
facilitate the SENDER the making of only one net payment for both items. 7.4 Payments shall be made
in Colombian pesos using the arithmetic average of the representative market exchange rate certified
by the Superintendence of Finance or the entity replacing it, of the days of the month corresponding
to the Service invoiced. 7.5 The SENDER shall make the payment by means of making a deposit in any
of the bank accounts as indicated by ECOPETROL. In case ECOPETROL requires any changes in the bank
account, it shall be informed in writing to the SENDER. 7.6 The SENDER is obliged to receive the
invoice once ECOPETROL has filed it. Any objections to the invoicing will not interrupt the term for
the payment respect to the sums that are not objected by the SENDER, pursuant to the term
established in this clause. ECOPETROL shall issue the note credit or equivalent document respect to
the sums objected by the SENDER, in order to rectify the inaccuracy.

3
<!-- page 7 -->
CLAUSE EIGHTH BONDS 8.1 The SENDER may pay in advance the Service for the Contracted Capacity, in
which case the corresponding invoice shall be adjusted pursuant to the provisions in the Clause of
Terms of Payment as it may apply. 8.2 Otherwise, In order to guarantee compliance with all and each
of the obligations of the SENDER under the Contract hereof, including but without being limited to
the payment of the Fee, the SENDER is obliged to constitute in favor of ECOPETROL and to deliver
within ten (10) business days after the subscription of the Contract hereof for the amount indicated
in the Specific Conditions (hereinafter, the "Bond"): a) A performance policy for the payment of
Services issued by an insurance policy legally established in the country, governed by the General
Clauses of ECOPETROL indicated in Annex 3; or b) An irrevocable stand-by letter of credit at first
requirement, issued by (i) a banking establishment authorized to operate in Colombia with AAA credit
rating for its long-term debt in pesos, o (ii) a foreign financial entity with representation or a
confirming and payment bank in Colombia, with risk credit of long term debt in dollars no less than
the rating for the foreign sovereign debt of Colombia issued pursuant to the International Standby
Practices (ISP98) of the International Chamber of Commerce, for which, it may be used the form
contained in Annex 4 of the Contract hereof. 8.3 The Bond shall be valid during all the term of
execution of the Contract plus one hundred twenty (120) calendar days.

7.7 ECOPETROL, in order to facilitate and expedite the verification of the invoices by the SENDER
shall deliver via e-mail the same day of its preparation and in PDF format, to the account of
institutional e-mail registered by the SENDER, a copy of the invoices and corresponding debit and
credit vouchers. 7.8 The SENDER shall pay late interests on any unpaid amounts pursuant to the
provisions set out by ECOPETROL in the Guidelines for Administration of Service Receivables
ECP-UTE-G-008 or a document that modifies or supersedes it, which is an integral part of the
Contract hereto as Annex 2. 7.9 The shipment tax shall be invoiced in Colombian pesos upon obtaining
the corresponding liquidation from the Ministry of Mines and Energy and shall be paid to ECOPETROL
by the SENDER, within the fifteen (15) calendar days after ECOPETROL files in the offices of the
SENDER the corresponding bills or invoices. 7.10 The amounts deposited by the SENDER in any of the
bank accounts of ECOPETROL must come from the accounts owned by the SENDER, who by means of written
communication before the subscription of the Contract will certify the origin of funds. This in
accordance with the Policy for the Prevention and Control of Asset Laundering of ECOPETROL.

4
<!-- page 8 -->
8.4 In the case of local financial institutions, the bond shall expressly state that the issuer
waves the benefit of excussio stipulated in article 2383 of the Colombian Civil Code. 8.5 The
issuance and validity of the Bond shall be an indispensable condition for the provision of the
Service. As a consequence, ECOPETROL may suspend the provision of the Service or terminate the
Contract in advance, when the Bond is not in force, without this waiving the SENDER from its payment
obligations and all other obligations derived from the Contract hereof. CLAUSE NINTH OBLIGATIONS OF
THE SHIPPER 9.1 In addition to the obligations set forth in the Manual of the Shipper and those
established in the law, ECOPETROL is obliged in a special manner to:

CLAUSE TENTH OBLIGATIONS OF THE SENDER 10.1 In addition to the obligations set out in the Manual of
the Shipper and those in the law, the SENDER is obliged particularly to:

a) Receive in the Entrance Point agreed in the Pipeline, the Crude owned by the SENDER up to the
volume corresponding to the Contracted Capacity, subject to the Available Capacity of the Pipeline
in the Month of Operation in which the Service is to be provided. b) Maintain in custody the Crude
delivered from the Point of Entrance until the time of delivery to the SENDER in the Exit Point.
Notwithstanding the foregoing, in the event in which the SENDER does not receive the Crude in the
Point of Exit pursuant to the agreement, the responsibility by the ECOPETROL to maintain the Crude
in custody shall cease. c) Shipping and decanting through the Pipeline the Crude delivered by the
SENDER from the Point of Entrance until the Exit Point. d) Store the Crude from its reception in the
Point of Entrance until delivered to the SENDER in the Point of Exit, exclusively to facilitate its
shipment under the Contract hereof, not including the storage for export or the segregate storage of
Crude. e) Deliver the Crudes shipped to the SENDER or whoever is designated as receiver of the same
in the Point of Exit, in accordance with the instructions received by the SENDER and with the
conditions of the Manual of the Shipper. f) ECOPETROL shall not be obliged to receive Crude: (a)
when the same fails to fulfill the Specifications of Quality agreed in the Contract hereof; (b) when
the SENDER does not have an accepted nomination in the Shipment Schedule of the Pipeline, or (c)
when there are not valid agreements of the SENDER that allow the delivery of Crude in the Point of
Exit. g) Execute all other obligations derived from the nature of the Contract.

5
<!-- page 9 -->
CLAUSE ELEVENTH RISKS AND RESPONSIBILITY 11.1 Each Party shall be responsible for any damage caused
to the other Party as a result of failing to fulfill its obligations under the Contract hereof, in
the terms set out in the clause hereof. 11.2 Responsibility of ECOPETROL:

a) Undertake the nomination of the Crudes to be shipped, pursuant to the procedure established in
the Manual of the Shipper. b) Deliver at the Point of Entrance the Crudes of its own/production
included in the Shipment Schedule as a result of the nomination process. c) Receive in the Point of
Exit the Crudes transported as established in the Manual of the Shipper and the procedures set forth
by ECOPETROL, or if a receiver different than the SENDER has been designated, this shall take al
necessary measures so that the Crude is received in accordance with the stipulations in the Manual
of the Shipper and the procedures set out by ECOPETROL, the SENDER is any case responsible for the
reception of the Crude. In case the Crude is not received at the Point of Exit, the provisions
established in the Manual of the Shipper shall be applied. d) Enter into the contracts with other
shippers or terminal operators required to ensure the delivery of crudes at the Point of Exit
without affecting the operation of the Pipeline. e) Make the Fee payment and all other items as they
may apply in the terms and conditions established in the Contract hereof. f) Execute the bond in
favor of ECOPETROL. g) Make the payment of the shipping tax under the conditions set out in this
Contract and the law. h) Execute all other obligations derived from the nature of the Contract.

a) In addition to the provisions in the Manual of the Shipper, ECOPETROL shall not be responsible
for any faults in the Service, or the loses, damage or deterioration the Crude may suffer, if the
fault in the Service, the loss, damage or deterioration of the Crude are due to (i) events of force
majeure or acts of nature, (ii) Acts from third parties, (iii) vice inherent to the Crude, or (iv)
fault attributable to the Sender (hereinafter, the "Excusable Events"). b) ECOPETROL shall only be
responsible for the faults in the Service or loses, damage or deterioration the Crude may suffer to
the extent it does not demonstrate that (i) no Excusable Event has occurred, and also, (ii)
ECOPETROL failed to adopt the reasonable measures any shipper would have taken according to the
requirements of operation of a pipeline with similar characteristics to the Pipeline, to avoid the
damage or its aggravation. c) In all other events, different than those in connection with the
provision of the Service, ECOPETROL shall be liable to the extent in incurs in gross negligence. d)
Save the event of gross negligence or willful misconduct, pursuant to the provisions in this numeral
11.2, the responsibility of ECOPETROL under the Contract hereof under no circumstance shall exceed
seventy five per cent (75%) of the value of the Crude lost or damaged by causes attributable to
ECOPETROL.

6
<!-- page 10 -->
11.3 Crude Assessment: In order to determine the value of the Crude for liability purposes based on
the previous numeral, ECOPETROL shall establish the following rules: a) For those Pipelines using
the mechanism of Volumetric Compensation for Quality and pursuant to the indications in the Manual
of the Shipper, the value of the Crude shall be determined based on the result generated by the
application of said mechanism defined for the Pipeline for the month in which the loss or damage of
Crude occurs. b) For intermediate Pipelines and/or ending in Sea Terminals and not using the
mechanism of Volumetric Compensation for Quality, the assessment of the Crude shall be made taking
the price of reference of export of Crude in the respective Sea Terminal, reported for the month in
which the loss or damage of Crude occurs, based on the commercial balance of ECOPETROL for the
export mix of which the Crude was part, discounting the applicable monthly fee for the Services, and
including but not limited to, the handling services in plant, storage, terminal services, etc., up
to the Point of Entrance of the Pipeline in which the loss or damage of the Crude has occurred. 11.4
Responsibility of the SENDER:

11.5 In those events in which the SENDER may be involved, the technical procedures defined for these
occasions by ECOPETROL shall be followed: 11.6 Procedure under an Excusable Event: In the event of
occurrence of an Excusable Event:

e) Save the event of gross negligence or willful misconduct, if any claims arise by the SENDER such
as the loss of profit, this shall not exceed twenty five percent (25%) of the value that ECOPETROL
is obliged to indemnify the SENDER under this numeral 11.2(d) of the Contract hereof.

a) The SENDER shall be liable for any damage caused to ECOPETROL for the default of its obligations
under the Contract hereof and shall be responsible for any damage derived from or as a consequence
of the actions or omissions of the SENDER, its workers, subordinates, contractors and
subcontractors, except in cases of (i) gross negligence or willful misconduct by ECOPETROL, or (ii)
a force majeure or unforeseen circumstances. b) The SENDER shall not be waved from its
responsibility to pay the Fee agreed in this Contract, save the Service is not provided by causes
exclusively attributable to ECOPETROL as indicated in numeral 11.2 b).

a) ECOPETROL shall notify the SENDER within twenty four hours (24) following the moment of
occurrence, making the commitment to submit all details within the following five (5) business days.

7
<!-- page 11 -->
11.7 The fulfillment of all legal obligations corresponding to each of the Parties, among them and
including, those in connection with its personnel, compliance with environmental standards, those
related with the legality of intellectual property rights, tax provisions or any other similar
obligation, shall be borne and will be the exclusive responsibility of the Party to whom said
obligation corresponds and its failure to perform it shall only affect said Party. 11.8 The fact
that any of the Parties fails to enforce to the other Party any of the stipulations hereof at any
time, shall not be considered a waiver for the performance of said stipulation, unless the other
Party notifies it in writing. No waiver to allege a violation of this Contract shall be considered
as a waiver to allege any other violation. 11.9 The Parties state to be aware of the public order
and security conditions of the areas in which the purpose of the Contract shall be developed, and
each Party assumes its own and exclusive responsibility for the risks derived from such conditions,
and therefore, shall not take any claim or action against the other Party due to any damage or
injuries suffered by said Party on its property, personnel, its agents, contractors or
subcontractors (including its employees or subordinates) resulting from public order or security
conditions. 11.10 Each Party shall be exclusively responsible for any damage caused to third parties
as a result of its proved and exclusive fault. In particular, each Party shall be responsible for
all loss or damage to the property of third parties or injury, illness or death of all third parties
as a result of its acts or omission or those from its personnel. CLAUSE TWELFTH PENAL PECUNIARY
CLAUSE 12.1 In case of failing to fulfill the obligations of the SENDER as a result of any actions
or illegal omissions or deviations from the Contract, the SENDER agrees to pay ECOPETROL as a
penalty, an amount equivalent to ten percent (10%) of the final value of the Contract. 12.2 Said sum
shall be charged to the amount of damage suffered by ECOPETROL, and its value may be taken directly
from the balance in favor of the SENDER if there is any, or else from the Bond. If this is not
possible, the penal pecuniary clause shall be collected by means of execution for which the Contract
shall be a writ of execution. 12.3 The application of the penal pecuniary clause does not include
the indemnification for any damages borne by the SENDER if the amounts of these are higher, under
the criteria of ECOPETROL, to the amount of the penal pecuniary clause agreed hereof, nor it
releases the SENDER from its payment obligation of the totality of the value of the Contract
pursuant to the conditions agreed.

b) ECOPETROL shall carry out all reasonable procedures as required to resume as soon as possible the
performance of the obligations of the Contract. Likewise, it shall make efforts to minimize or
mitigate any delay or additional costs that may be generated.

8
<!-- page 12 -->
CLAUSE THIRTEENTH SUSPENSION DUE TO NON-PERFORMANCE OF THE SENDER 13.1 ECOPETROL shall be entitled
to suspend the Service in case of any events that may represent a serious default on any of the
obligations of the SENDER. For this purpose, a communication from ECOPETROL addressed to the SENDER
shall be sufficient, notifying the serious default. ECOPETROL may, based on the seriousness and the
effects of the default, grant the SENDER a reasonable term to fix the default (the "Grace Period"),
which under no circumstance may be granted if the default is due to the non-payment of the Fee in
the terms set out in the Contract hereof. If, upon expiration of the Grace Period the SENDER has not
resolved the default, ECOPETROL may suspend the Service and the SENDER shall not be entitled to any
indemnification under no circumstance. The reestablishment of the provision of Services shall be
subject to previous approval in writing by ECOPETROL. 13.2 The suspension of the Contract is not a
waiver or a release for the SENDER on its responsibility to pay the Fee and all other concepts that
may be applicable under the Contract hereof. CLAUSE FOURTEENTH TERMINATION OF THE CONTRACT 14.1 The
Contract hereof shall terminate upon expiration of the term of validity agreed. 14.2 The Parties
agree that ECOPETROL may declare the termination in advance of the Contract at any time, without any
indemnity in favor of the SENDER in the following events:

a) Serious default of the obligations of the SENDER without solving them within the Grace Period,
when it may apply. b) The dissolution of the SENDER as a legal person. c) The unauthorized
assignment of the Contract by the SENDER. d) Due to changes in regulations making more costly the
fulfillment of obligations undertaken by ECOPETROL. e) As a consequence of any of the following
causes: (i) fraud of the SENDER; or (ii) the SENDER incurs in acts or conducts that may endanger the
operational and/or technical stability of the Pipelines. f) The procedure to be followed by
ECOPETROL to terminate the Contract is: notify in writing with at least thirty (30) calendar days in
advance to the SENDER its intention to terminate the Contract, indicating the causes for such
decision and the effective date of termination. Upon fulfillment of this procedure the SENDER shall
not: (i) request any justifications or extensions to the motives explained by ECOPETROL, or (ii)
request or demand any kind of compensation or damages derived from the decision to terminate the
Contract. g) The termination shall not release the Parties from its corresponding obligations and
responsibilities attributable to periods before the date of termination of the Contract.

9
<!-- page 13 -->
14.3 It shall not be necessary any previous private or judicial requirement for purposes of
enforcement of this clause. CLAUSE FIFTEENTH TAXES 15.1 All taxes, contributions, rates, surcharges
and any other national, departmental, district or municipal taxes caused by the entering into,
execution and liquidation of the Contract hereof, shall be borne by the Party that has to assume
said payment pursuant to the law. 15.2 The collection and payment of the shipment tax shall be
assumed by ECOPETROL before the Ministry of Mines and Energy, and therefore the SENDER shall pay the
same to ECOPETROL pursuant to the provisions hereto. CLAUSE SIXTEENTH LIQUIDATION OF THE CONTRACT
16.1 Upon expiration of the Term of Validity, the Parties shall subscribe the minutes of termination
of the execution. 16.2 The Parties shall make the liquidation of the Contract by mutual agreement
within three (3) months following the expiration of the date of termination of the Contract. 16.3 In
case the SENDER fails to appear to the liquidation, or if there is not an agreement of the same
within the term previously mentioned, the SENDER expressly authorizes ECOPETROL to proceed with the
liquidation in one (1) month term. 16.4 The following shall be expressly stated in the minutes of
liquidation:

16.5 Upon liquidation of the Contract, the SENDER shall pay ECOPETROL any Fees or any amount of
money owed or resulting from the final liquidation of the same, after making any deduction that may
be applicable.

h) The termination in advance of this Contract shall not release the SENDER from the obligations
that survive the termination of the Contract, especially that related with the payment of the Fee
pending of payment and the payment of the penal clause. In the event of termination in advance of
the Contract, the SENDER shall have a sixty (60) day term following the issuance of the
corresponding invoice by ECOPETROL to pay the amount of any overdue fees.

a) The statement regarding the performance of the obligation undertaken by each of the Parties (or
from ECOPETROL if the liquidation is unilateral) derived from the execution of the Contract; and b)
Any agreements, settlements and transactions reached by the Parties to settle any differences that
may have arisen and to obtain the good standing and release of any obligations.

10
<!-- page 14 -->
CLAUSE SEVENTEENTH AUTHORIZED REPRESENTATIVES FROM THE PARTIES 17.1 Each of the Parties shall notify
to the other in writing, before the commencement of the execution of this Contract the name,
position, addresses, institutional electronic mails and telephone numbers of the person(s)
authorized to represent it. Likewise, any change of these representatives shall be notified in
writing. 17.2 Any instruction or notification addressed to the representative designated in the
manner previously established shall be considered as addressed to the respective Party. CLAUSE
EIGHTEENTH AMENDMENTS 18.1 Any amendment, clarification or addition to the conditions stipulated in
the Contract hereof, shall be in writing, in documents subscribed by the authorized representatives
by the Parties. CLAUSE NINETEENTH ASSIGNMENT 19.1 The SENDER shall not assign totally or partially
the Contract hereof, without the previous written consent by ECOPETROL. 19.2 The assignee shall
assume all rights and obligations in the same terms established hereto. 19.3 The assignment may be
authorized by ECOPETROL, when the SENDER sufficiently demonstrates to ECOPETROL that:

a) The assignee is a legal person duly organized and the duration of the same shall not be less that
the term of the Contract and three (3) more years. b) The assignee has an adequate financial
capacity to meet the obligations derived from the Contract assigned. c) The assignee has Crude of
its own/production. d) The assignee provides and adequate and acceptable Bond payment to ECOPETROL
for the fulfillment of the obligations derived from the Contract.

19.4 ECOPETROL may assign the Contract without the authorization from the SENDER.

CLAUSE TWENTIETH LICENSES, PERMITS AND AUTHORIZATIONS 20.1 The Parties are obliged to have or obtain
all required licenses, permits and authorizations for the execution of the purpose of the Contract.
Each Party shall be individually liable for all those risks, fines, sanctions or damage caused as a
result of the absence of any license, permit or authorization that is obliged to obtain and
therefore shall defend and hold the other Party harmless before any authorities, judges and third
parties.

11
<!-- page 15 -->
CLAUSE TWENTY-FIRST EXCLUSION OF THE LABOR RELATION 21.1 The Parties do not assume any labor
relationship with personnel that, by virtue of the Contract, are assigned to the other Party for the
appropriate execution of the same. All future or present obligations resulting from the relations of
the Parties with its personnel shall be exclusively borne by the Party involved, and therefore, each
Party assumes full responsibility concerning compliance with labor regulations and social security
and shall hold the other Party harmless against any claim in connection with any violation to the
mentioned regulations. CLAUSE TWENTY-SECOND INDEMNITY 22.1 ECOPETROL is obliged to protect,
indemnify and hold the SENDER harmless against any loss, cost or damage to be caused or derived
from, or related with the breaching of the Contract by ECOPETROL, save the same are caused by
Excusable Events. 22.2 The SENDER is obliged to protect, indemnify and hold ECOPETROL harmless and
its parent, affiliates and subsidiaries, and the directors, employees, agents and representatives of
ECOPETROL, and of its affiliates and subsidiaries against any loss, cost or damage to be caused or
derived from or related with the execution of the Contract, except (i) by causes exclusively
attributable to ECOPETROL or (ii) force majeure or unforeseen circumstances and acts of third
parties. CLAUSE TWENTY-THIRD CONFIDENTIALITY 23.1 The Parties make the commitment to keep strict
confidentiality and not to disclose to any person any information considered as confidential (the
"Information"), which has been provided through the development of the Contract hereof, and through
the development of the activities inherent to ECOPETROL and/or the SENDER. 23.2 Without prejudice of
the foregoing, only in the following cases information may be disclosed:

23.3 For any information to be disclosed, that must be or wished to be disclosed as established in
previous numerals, only the disclosure in question shall proceed after consulting, if the period
granted by law or the authority ordaining the disclosure of the information allows it, with the
Party that has provided the information.

a) When the disclosure of information is mandatory by law; b) When the disclosure of information is
ordered by a competent authority; c) When the information in question is of public domain, without
any action or omission from the Parties; or d) When the entity providing the information authorizes
it, in each case, previously and in writing;

12
<!-- page 16 -->
23.4 Furthermore, it shall be understood that the Information may be disclosed to employees,
advisors and officers of the Parties, as well as employees, advisors, officers, auditors and
insurance companies of the shareholders of ECOPETROL or the SENDER (including parents, affiliates
and subordinates). 23.5 In any case, the Parties shall ensure that persons to whom the Information
is disclosed hold, in turn, said Information as confidential and refrain from disclosing it. The
Parties shall be responsible for any disclosure of Information to any of its employees, advisors and
officers. If the Parties become aware of any unauthorized disclosure of confidential Information, it
shall be notified immediately to the other Party and jointly shall take all measures necessary
and/or convenient to prevent other disclosures of Information in the future. 23.6 The SENDER shall
solely use or permit the use of the Confidential Information disclosed under the execution of this
Contract to perform it. The disclosure of Confidential Information under this Contract shall not
grant any other right. 23.7 The SENDER shall be responsible for ensuring that all persons to whom
the Confidential Information is revealed under the execution of this Contract maintain said
Information as Confidential and without disclosing it to any unauthorized persons. The SENDER shall
be liable for any damage caused to ECOPETROL in case of breaching the Contract hereto, or if through
negligent actions or omissions, discloses or makes public any Confidential Information outside the
terms set out herein in accordance with law. 23.8 ECOPETROL may request the return of the
Information at any time after notifying in writing to the other Party. Within thirty (30) days
following the reception of said notification, the SENDER shall return all original Information and
destroy or make to be destroyed all copies and reproductions (in any manner, including but without
being limited to electronic means) in its possession and in possession of persons to whom it was
disclosed pursuant with the Contract hereof. In any case, upon expiration of the term of execution
of the Contract, the SENDER shall return all original Information and destroy or make to be
destroyed all copies and reproductions (in any manner, including but without being limited to
electronic means) in its possession and in possession of persons to whom it was disclosed pursuant
with the Contract hereof. 23.9 During the term of execution of the Contract, ECOPETROL is obliged to
keep in reserve and not to disclose the information expressly identified and in writing by the
SENDER that is protected by copyrights or industrial secret pursuant to the regulations in force,
that is directly delivered by the SENDER as a result of the execution of the Contract, and makes the
commitment not to deliver said information to any third parties, except as ordered by the judicial
or administrative authorities or in events required by the legal provisions in force. 23.10 This
confidentiality clause shall keep its validity, inclusively after the date of termination of the
Contract hereto, until the date in which all obligations set out in this clause are fulfilled.

13
<!-- page 17 -->
CLAUSE TWENTY-FOURTH SOCIAL CORPORATE RESPONSIBILITY 24.1 The SENDER undertakes the commitment to:
a) Respect and obey the Good Governance Code and Policies of Integral Responsibility and Social
Corporate Responsibility of ECOPETROL. b) Make the best efforts to establish and maintain, as best
as possible, good relations with the institutions (authorities) and communities settled in the
region and in the area where the Contract shall be executed. c) Report to ECOPETROL or whoever
replaces it, any incidents or new actions that may affect its image and/or the image of ECOPETROL,
within three (3) business days after the occurrence of said incidents, in order to have consensus in
the handling of said incidents. CLAUSE TWENTY-FIFTH COMMITMENT WITH TRANSPARENCY 25.1 The SENDER
undertakes the obligation to:

25.2 The SENDER states to be aware of and accepts the Code of Ethics of ECOPETROL found in the
following website: www.ecopetrol.com.co, and the provisions on conflict of interest existing in the
by-laws of ECOPETROL found in the same website. In case ECOPETROL determines that the SENDER has
incurred in conducts that violate the clause hereof, ECOPETROL may terminate the Contract.

a) Maintain conducts and appropriate controls to ensure an ethical conduct and in accordance with
regulations in force. b) Refrain from making (directly or indirectly, or through employees,
representatives, affiliates or contractors) payments, loans, gifts, gratifications, commissions, to
employees, managers, administrators, contractors or suppliers of ECOPETROL, public officials,
members of corporations of popular election or political parties, in order to induce such persons to
conduct any action or make any decision or use their influence in order to contribute to obtain or
retain businesses in connection with the Contract. c) Refrain from originating records or inaccurate
information, or publish information that affects the image of the other Party when based on
assumptions that have not been demonstrated. d) Avoid any situation which may generate a conflict of
interest. e) Communicate mutually and reciprocally any deviation from the line of conduct indicated
in this clause.

14
<!-- page 18 -->
CLAUSE TWENTY-SIXTH INTEGRITY 26.1 The Contract hereof constitutes a sole and integral agreement
regarding the purpose of the same and replaces any previous agreement that has not been written in
this Contract. 26.2 The following documents are an integral part of the Contract:

26.3 Likewise, all regulations and procedures that ECOPETROL has established for the development of
the activities being the purpose hereto are an integral part of this Contract. CLAUSE TWENTY-SEVENTH
LEGAL REGIME 27.1 The relation established in the Contract hereof is of commercial nature and
therefore is governed by the regulations of Colombian private law. CLAUSE TWENTY-EIGHTH
NOTIFICATIONS 28.1 All communications and invoices between the SENDER and ECOPETROL delivered as a
result of this Contract shall require for its validity to be in writing, and depending on the will
of the Party issuing it, they will have to be:

28.2 All communications shall deemed as served and valid:

ANNEX 1 MANUAL OF THE SHIPPER OF THE ECOPETROL S A PIPELINE

ANNEX 2 GUIDELINES FOR THE ADMINISTRATION OF RECEIVABLE SERVICES OF ECOPETROL

ANNEX 3 GENERAL CLAUSES OF ECOPETROL FOR PERFORMANCE POLICIES

ANNEX 4 STAND-BY LETTER OF CREDIT FORM

a) delivered personally; or b) transmitted by facsimile, electronic mail or any other means through
which it may be proved its delivery and reception (with proved reception and confirmation by mail).

a) On the reception date if delivered personally, or b) Twenty four (24) hours after the
transmission date, if transmitted by facsimile, electronic mail or any other means through which its
delivery and reception may be proved; provided however, confirmation is received within the
following three (3) days; whatever occurs first.

15
<!-- page 19 -->
28.3 Each Party may change the address for these purposes, with previous written communication to
the other Party with fifteen (15) calendar days in before the expected date for such change. 28.4
All notifications and communications to be made to the Parties as a result of the execution of this
Contract shall be delivered to the addresses indicated in the Specific Conditions. CLAUSE
TWENTY-NINTH MISCELLANEOUS 29.1 Severability: the voidance, nullity or inefficacy of any provision
of this Contract shall not affect the validity, efficacy and enforceability of all other provisions
of the same. In these events the Parties are obliged to negotiate in good faith a clause resulting
legally valid, and enforceable, whose purpose is the same of the provision or provisions having
vices of nullity, invalidity or non-enforceability, as the case may be. 29.2 Administration and
Inspection: ECOPETROL shall designate an administrator and inspector of the Contract, whose
functions shall be established in the Manual of Administration and Inspection of ECOPETROL. 29.3
Survival: The termination of this Contract shall not relieve the Parties from any obligation towards
the other Party pursuant to this Contract, or any other loss, cost, damage, expense or
responsibility which may occur under this Contract before or as a result of said termination. CLAUSE
THIRTEENTH PERFECTION AND EXECUTION 30.1 The Contract hereof is perfected with the subscription of
the same. For its execution the approval of the bond assumed by the SENDER is required.

16
<!-- page 20 -->
ANNEX 1 MANUAL FOR THE TRANSPORTER OF PIPELINES ECOPETROL S A
<!-- page 21 -->
Operation and Transport Regulations Version 1 MANUAL FOR THE TRANSPORTER OF PIPELINES ECOPETROL S A
TABLE OF CONTENTS

CLAUSE 1. PURPOSE 3 CLAUSE 2 DEFINITIONS 3 CLAUSE 3 GENERAL DESCRIPTION OF THE PIPELINE 10 CLAUSE 4
OBLIGATIONS OF THE PARTIES 10 CLAUSE 5 FEES 13 CLAUSE 6 SPECIAL SERVICES 14 CLAUSE 7 ADJUSTMENT OF
THE EFFECTIVE CAPACITY OF THE SYSTEM DUE TO VARIATIONS IN THE SPECIFICATIONS OF HYDROCARBONS 14

CLAUSE 8 PROJECTIONS, NOMINATION AND TRANSPORTATION SCHEDULE OF THE PIPELINE 15 CLAUSE 9 BALANCE IN
EXCESS OR DEFECT 18 CLAUSE 10 PRIORITIES IN THE NOMINATION PROCESS 19 CLAUSE 11 REJECTION OF A
TRANSPORTATION REQUEST 20 CLAUSE 12 QUALITY REQUIREMENTS 21 CLAUSE 13 DETERMINATION OF QUANTITIES
AND QUALITY 22 CLAUSE 14 VOLUMETRIC COMPENSATION FOR QUALITY 25 CLAUSE 15 BULLETIN OF TRANSORTATION
BY THE PIPELINE - BTO 26 CLAUSE 16 SPECIAL TRANSPORTATION CONDITIONS 28 CLAUSE 17 REGULATIONS FOR
THE TRANSPORTATION OF SEGREGATED HYDROCARBON 29 CLAUSE 18 RISKS AND RESPONSIBILITY 29 CLAUSE 19
FILLING THE PIPELINE OR FILLING THE LINE 31 CLAUSE 20 HANDLING LOSSES IN THE PIPELINE 31 CLAUSE 21
CLAIMS 33

1
<!-- page 22 -->
Operation and Transport Regulations Version 1

CLAUSE 22 SANCTIONS TO OPERATING AGENTS FOR NON-PERFORMANCE OF THE TRANSPORTATION SCHEDULE 33 CLAUSE
23 HYDROCARBON AFFECTED BY LITIGATION 34 CLAUSE 24 INVESTMENTS IN THE PIPELINE 35 CLAUSE 25 SOLE
RISK PROPOSALS 36 CLAUSE 26 PROCEDURES FOR COORDINATION OF OPERATIONS, COMMUNICATIONS AND EMERGENCY
ASSISTANCE 38 CLAUSE 27 SETTLEMENT OF CONTROVERSIES 39 CLAUSE 28 VALIDITY 39 CLAUSE 29 ADDITIONS AND
MODIFICATION 39 CLAUSE 30 APPLICABLE LEGISLATION 39 ANNEX 1: MECHANISMS OF QUALITY COMPENSATION FOR
THE MIXTURE OF CRUDE OIL 40 ANNEX 2: DEFINITION OF STANDARD BARRELS PER SYSTEM 48 ANNEX 3:
DESCRIPTION OF THE SYSTEMS 49 ANNEX 4: MINIMUM SPECIFICATIONS OF QUALITY PER SYSTEM 50

2
<!-- page 23 -->
Operation and Transport Regulations Version 1 CLAUSE 1. PURPOSE

CLAUSE 2 DEFINITIONS 2.1 All terms listed hereunder shall have the meaning assigned in this Manual
without any difference when the term is used either in singular or plural, upper or lower case
letters. 2.1.1. Transportation Agreement or Transportation Contract: means the agreement between the
Transporter and a Sender whose purpose is the Transportation of Crude Oil through the Pipeline.
2.1.2. Operating agent or agent: means any natural or legal person, public or private person
involved the technical and/or commercial relations for the provision of Transportation services of
Crude Oil through Pipelines. 2.1.3. Water and sediment: means any material coexisting with Crude Oil
without being part of the same. 2.1.4. Fiscal Year: means the period of time starting at 00:01 hours
of January 1st of a year and ending at 24:00 hours of 31 December of the same year. Always being
referred to Colombian time 2.1.5. API: means the American Petroleum Institute. Also it will have the
meaning corresponding to the measuring unit for density (API 141.5/GE-131.5; where GE is defined as
specific gravity), known internationally as one of the sale properties of Hydrocarbons depending on
the context used. 2.1.6. ASTM: American Society for Testing Materials. 2.1.7. Provisional Notice:
means the notification that the Transporter will deliver to the Sender regarding any damage or
additional costs incurred, or about its intention to withdraw and use the Sender's Crude to pay
monies in favor of the Transporter or the owner, borne by the Sender and/or to avoid any Operational
affectations in the Pipeline.

1.1 The Pipeline is for private use considering its nature and in accordance to the provisions in
the Colombian Code of Crude Oils.

1.2 The purpose of this Manual of the Transporter of the Pipeline (hereinafter the "Transporter's
Manual) is to establish the general conditions for the Transportation of Hydrocarbons of the Owners
through the Pipeline.

1.3 Likewise, conditions for the access of Third Parties to the Pipeline are established in those
events in which there is Available Capacity in the Pipeline.

3
<!-- page 24 -->
Operation and Transport Regulations Version 1 2.1.8. Balance for the Sender: means the volumetric
balance for each of the Senders using the Pipeline. 2.1.9. Volumetric Balance: means the balance of
Operations conducted by the Transporter at the end of each month of Operation, in order to establish
the amounts of Crude handled in the Pipeline and to make the determination and distribution of Crude
losses. 2.1.10. Barrel: means a volume equal to 42 United States of America gallons. Each gallon is
equal to three liters and seven thousand eight hundred and fifty three ten thousands of liters
(3.7853). 2.1.11. Standard Barrel: means the volume of Hydrocarbons including dissolved water,
suspended water and suspended sediment but excluding free water and bottom sediments, calculated at
standard conditions (60F and 14.7 lbf/in, or 15C and 1.01325 bares). 2.1.13. Net Standard Barrel:
means the volume of Hydrocarbon excluding total water and total sediment, calculated at standard
conditions (60F and 14.7 lbf/in, or 15C and 1.01325 bars). 2.1.14 Barrels per Calendar Day (bpdc):
means the measuring unit of flow volume referring to the average value of a specific period. 2.1.15
Barrels per Operational Day (bpdo): means the measuring unit of flow volume referring to the average
value of days effectively operated. 2.1.16 Bulletin of Transportation by Pipeline: means the website
in which the Transporter makes available to agents and all other interested parties, the information
indicated in resolutions No 18-1258 and 12-4386 of 2010, issued by the Ministry of Mines and Energy,
which regulates Transportation through Pipelines and the methodology to set out the rates, as
amended or superseded. 2.1.17 Quality of a Hydrocarbon: means a set of characteristics contained in
a volume of Hydrocarbon. These characteristics are referred, among others, to viscosity, API
gravity, specific gravity, percentage in weight of sulfur, Point of fluidity, acidity, steam
pressure, percentage in volume of water, percentage in weight of sediments and salt content. 2.1.18
Contracted Capacity: means the Capacity of the Pipeline committed through Transportation Contracts.
2.1.19 Designed Capacity or Transportation Capacity: means the Transportation Capacity for Crude Oil
established for the Pipeline, based on the Crude properties and specifications of the equipment and
tubing for the calculation and design of the Pipeline. If the design of the Pipeline is modified to
increase said Capacity, then this will be the new design Capacity.

4
<!-- page 25 -->
Operation and Transport Regulations Version 1 2.1.20 Owners Capacity: means the Transportation
Capacity of the Pipeline necessary in a period of time for the Transportation Crude Oil owned by its
owners, its parent companies or subsidiaries. 2.1.21 Available Capacity: means, for a specific
period of time, the difference between the effective Capacity and the sum of: i) the owner's
Capacity, ii) the Contracted Capacity and iii) the preferred rights, which shall be available for
the Transportation of Third Party's Crude under the conditions set out in the Manual hereof. 2.1.22
Effective Capacity or Transportation Effective Capacity: means the maximum average Capacity of
Transportation, which may be used for Crude Transportation in a specific period of time. This is
calculated as the product of the nominal Capacity by the service factor. 2.1.23 Nominated Capacity:
this means the Crude volume that, according to a letter from the Sender or Third-Party delivered to
the Transporter in the respective month of nomination, and in accordance with the procedures
established in this Manual, they require it to be transported through the Pipeline. 2.1.24 Nominal
Capacity: means the maximum Transportation Capacity between a pumping station and a Pipeline
terminal, or between two pumping stations, calculated considering the installed equipment in the
system and the expected quality of Crude for a specific period of time. It is expressed in BOPD for
a Hydrocarbon of standard barrel characteristics in terms of viscosity in cstks at 30 C and API at
60 F according to the design Capacity of the Pipeline. 2.1.25 Programmed Capacity: this means the
portion of the effective Capacity of Transportation of the Pipeline assigned to each Sender or Third
Party requesting the Transportation service in accordance with the provisions in this Manual. 2.1.26
Volumetric Compensation for Quality or CVC: this means the procedure by which Senders are
compensated for the gain or loss in the discounts of Crude as determined by the difference between
the Crude delivered by the Sender at the Point of Entrance compared to the Crude withdrawn at the
Point of Exit. 2.1.27 Monetary Conditions: means the tables or formulas to calculate any extra
charge and bonuses for Crude quality and commercial discounts applied on the Rate for the Line.

5
<!-- page 26 -->
Operation and Transport Regulations Version 1 2.1.28 Connection: this means the installation that
allows delivery of Crude to the Pipeline and/or withdrawal of Crude from the Pipeline. 2.1.29 Ship
or Pay Transportation Contract: this means the agreement between the Transporter and a Sender that
regulates the provision of the Transportation service of Hydrocarbons for a specific Contracted
Capacity in firm, understanding that the Sender has a permanent right for the Transportation of a
specific volume of Hydrocarbons, and that the Payment of the rate is agreed in firm, regardless of
the volume effectively transported or even if no volume is transported. 2.1.30 Spot Transportation
Contract: this means the agreement between the Transporter and a Sender that regulates the provision
of the Transportation service of Hydrocarbons for a specific Contracted Capacity in a month of
Operations, subject to the available Capacity of the Pipeline in the process of nomination. 2.1.31
Coordination of Operations: means the set of activities conducted by the Transporter to control the
development of the Transportation program and procure its fulfillment. 2.1.32 Crude Oil or
Hydrocarbon: means the natural mix of Hydrocarbons in accordance with the definition through the
article 1 of the Petroleum Code, which exists in underground deposits and remains liquid at
atmospheric pressure after going through the separation facilities on surface, as well as the
products necessary to make viable its Transportation such as diluents. 2.1.33 Crude for
Transportation: means the inspected Crude Oil delivered to the Pipeline for Crude Transportation.
This category includes inspected Crude Oils both segregated or separated from others as well as
those mixed between them, when they may be mixed, in both cases, with any other substance for
Transportation purposes. 2.1.34 Inspected Crude: means the Crude Oil treated, dehydrated,
degasified, drained, settled, stabilized and measured at the inspection facilities. 2.1.35 Mixed
Crude or Mix: means the combination of different Crude before and/or after delivered to the Pipeline
to be transported. 2.1.36 Segregated Crude: means Crude Oil that by agreement between the
Transporter and a Sender is decided to be transported through the Pipeline without being mixed with
other Crude. 2.1.37 Preferred Right: means the power that the National Government has through the
National Agency of Hydrocarbons (ANH) or whoever replaces it, on the Design Capacity of the Pipeline
for the Transportation of royalty Crude. This preference is limited to Crude Oil coming from
royalties corresponding to production served through the Pipeline. The preferred right shall be up
to 20% of the design Capacity.

6
<!-- page 27 -->
Operation and Transport Regulations Version 1 2.1.38 Day: means the period of twenty four (24) hours
starting at 00:01 of one day and ends at 24:00 of the same day, always referring to Colombian time.
2.1.39 Diluent: means the natural or refined product mixed with heavy Oil to facilitate
Transportation through the Pipeline. 2.1.40 Delivery: means the action by which the custody of the
volume of the Sender's Crude is transferred to the Transporter to be shaped through the Pipeline.
2.1.41 Reasonable Effort: means the effort that a prudent person makes in handling his own business
while protecting his interests. 2.1.42 Initial Pumping Station: means the initial station of the
Pipeline. 2.1.43 Final Station: means the final Station on the Pipeline. 2.1.44 Justified Event:
means any event or circumstance beyond the Transporter's control such as, including but not limited
to, strange cause, force majeure, acts of nature, acts of a Third-Party or the victim, labor
disputes or actions of any kind arising from organized labor, outside war (whether or not declared),
civil war, sabotage, revolution, insurrection, riots, civil unrest, terrorism, illegal actions from
Third parties, epidemics, cyclones, tsunamis, landslides, lightning, earthquakes, floods,
rainstorms, fire, adverse atmospheric conditions, expropriation, nationalization, laws, regulations
or orders for any competent authority, distortions, damage or accidents in machinery, equipment,
Pipelines, power transmission lines or other facilities, attachments, impossibility or delays in
obtaining equipment or materials, inherent vices of crude oil, among others. 2.1.45 Service Factor:
means that percentage effectively uses of the nominal Capacity due to temporary operating and
maintenance restrictions of the Pipeline and its complementary facilities, calculated for a specific
period of time in which the effects of unavailability of mechanical equipment, maintenance programs
of the line and the number of days of the period considered must be taken into account. 2.1.46 Line
Fill or Pipeline Fill: means the volume of Crude necessary to fill in the lines of the Pipeline
between the initial pumping station under final station, the bottom of the storage tanks that cannot
be pumped o that serve the Pipeline, and all installations, lines, pumping and measuring equipment.

7
<!-- page 28 -->
Operation and Transport Regulations Version 1 2.1.47 Calendar Month: means the period of time
starting at 00:01 hours of the first day of the Gregorian month and ends at 24:00 hours of the last
day of the same Gregorian month. 2.1.48 Nomination Month: means the calendar month immediately
before a month of Operations. 2.1.49 Operation Month: means the calendar month during which the
Transporter executes the Transportation program. 2.1.50 Entrance Node: means the set of facilities
located in a determined geographical area where the Sender delivers the Crude and in which a
distance is started. 2.1.51 Exit Node: means the set of facilities located in a determined
geographical area where the Sender withdraws the Crude and in which a distance ends. 2.1.52
Nomination: means that transportation service request formalized by each Sender or Third-Party for
the month of Operation, specifying the required Transportation volume, the Point of Entrance, the
Point of Exit and the quality of Crude and the characteristics of Crude required to be transported.
2.1.53 Pipeline: means all the necessary physical facilities for the Transportation of Crude Oil
from the nodes of Entrance to the nodes of Exit including, among others, pipes, pumping units,
measuring units, control systems and tanks used for the Operation of the Pipeline. 2.1.54 Operator:
means the Transporter or the natural or legal person that performs the Operation tasks of the
Pipeline. 2.1.55 Party: means the Transporter and/or Sender, or there assignees as the case may be.
2.1.56 Identifiable Losses: means the losses of Crude that may be located in a specific Point of the
Pipeline and attributable to specific events such as breakages, spills, attacks, theft, force
majeure or acts for nature. 2.1.57 Non-identifiable Losses: means the normal losses inherent to the
Operation of Transportation in the Pipeline corresponding, among others, to what volumetric
contractions as a result of the mix, leakages in the equipment, drainages, evaporation and other
reasons originated in the handling of the Pipeline. 2.1.58 Transportation Plan: means the projection
of the volumes to be transported through the Pipeline and the available Capacity in the medium and
long term.

8
<!-- page 29 -->
Operation and Transport Regulations Version 1 2.1.59 Transportation Program or Program: means
program of Operations of the Pipeline for a month of Operations prepared by the Transporter, days on
the cycle of nomination of Transportation. It specifies the use of the effective Capacity, the
volumes of Crude entering at the Points of Entrance and volumes of Crude coming out from the
Pipeline at the Points of Exit. 2.1.60 Owner: means Capacity S.A. as an exporter company and/or
refiner of Crude Oil and its parent and/or branches, holders of the goods and Pipeline's facilities.
2.1.61 Point of Entrance: means the exact Point of the Pipeline, in which the Transporter assumes
custody of the Crude delivered by the Sender at the node of Entrance. This must be specified in the
Transportation agreement. 2.1.62 Point of Fluidity: means the temperature at which a Crude Oil
ceases to flow. 2.1.63 Point of Exit: means the exact of the Pipeline in which the Sender takes the
Crude Oil delivered by the Transporter that the node of Exit and the ceases custody of the Crude by
the Transporter. This must be specified in the Transportation contract. 2.1.64 Sender: means the
natural or legal person to whom the Transporter provides Transportation service of Hydrocarbons
through the Pipeline. It shall be understood that the Sender acts as the owner of the Crude to be
transported unless specified otherwise. Among the Senders are the ANH and the owner. Any Third
parties and the ANH acquire the Capacity of Senders when enter into a Transportation contract with
the Transporter. 2.1.65 Withdrawal: means the act by which he Transporter returns to the Sender or
whoever is designated, at the Point of Exit, a volume of Hydrocarbons ceasing its custody. 2.1.66
Withdrawal by Defect: means the volume of Crude that is Sender is not withdrawn according to the
Transportation program. 2.1.67 Withdrawal by Excess: means the volume of Crude that has been
withdrawn from a Sender above the limits in the Transportation program. 2.1.68 Transportation Rate
or Rate: means the monetary value per barrel charged by the Transporter to the Senders for the
Transportation service. Surcharges, bonuses and discounts shall be applied to this rate as specified
in the monetary conditions. 2.1.69 Third Party: means the person that has the ownership title or
holding of the Crude Oil and requires from the Transporter the provision of the Transportation
service through the Pipeline, conditioned to the existence of available Capacity.

9
<!-- page 30 -->
Operation and Transport Regulations Version 1 2.1.70 Transporter: means Capacity S A owner of the
Pipeline, or the person appointed as a representative or assignee, whose activity is the provision
of the Transportation service. 2.1.71 Distance: means the portion of the Pipeline from a node of
Entrance and a node of Exit, which must have a rate. 2.1.72 Volume to Transport: means the Gross
Standard Barrels delivered by the Sender to the Transporter at the Point of Entrance. CLAUSE 3
GENERAL DESCRIPTION OF THE PIPELINE The descriptions of the systems to which this Transporter Manual
applies are published in Annex 3, description of the systems. CLAUSE 4 OBLIGATIONS OF THE PARTIES
4.1 Obligations of the Senders: The following are obligations of the Sender: 4.1.1 Enter into
Transportation Contracts with the Transporter. 4.1.2 Report to the Office of Hydrocarbons of the
Ministry of Mines and Energy by communication delivered within ten (10) days following the
contracting of the service its Transportation through the Pipeline and the Distance to be used, the
origin (regions, municipalities and fields) of the Crude Oil to be transported and the term of the
Transportation contract. 4.1.3 Provide the Transporter in on a timely basis and in accordance with
the time schedule set out for said purpose, the necessary information for preparation of the
Transportation Plan. 4.1.4 Timely present the nomination to the Transporter pursuant to the
conditions, specifications, and based on the procedure set out in this Manual. 4.1.5 Comply with and
implement the commercial, Operational and administrative procedures of the Manual hereof. 4.1.6
Comply with the Transportation program defined for the month of Operation for the delivery of Crude
to the Pipeline at the Point of Entrance and implement whatever may be necessary for its reception
at the Point of Exit in accordance with the procedures defined in this Manual. 4.1.7 Deliver and
withdraw the Crude Oil within the limits of quality, volume, opportunity and all other conditions
set out in this Manual.

10
<!-- page 31 -->
Operation and Transport Regulations Version 1 4.1.8 Accountable for the consequences derived for its
failure to comply with the obligations agreed in the Transportation contract. 4.1.9 Refrain from
conducting restrictive commercial practices or those considered as unfair competition as set forth
in laws 155 of 1959, 256 of 1996, Decree 2153 of 1992, Law 1340 of 2009 and all other regulations as
amended and superseded. 4.1.10 Comply with the regulations set out by the competent authority on
environmental protection and preservation. 4.1.11 Comply with the regulations and procedures set out
in this Manual for the connection of the Pipeline, as it may be applicable under the Transporter's
judgment. 4.1.12 Pay the rates established for the distances being the purpose of the Transportation
service. 4.1.13 Pay to the Transporter, acting as a collector, the Transportation tax established by
the legislation for Crude Oil Transportation through Pipelines. 4.1.14 Provide the information as
required by the Office of Hydrocarbons of the Ministry of Mines and Energy in order to exercise
adequate control of the activity. 4.1.15 Refrain from conducting any actions that may affect the
normal Operation of the Pipeline and may cause damage to the Transporter or other Senders. 4.1.16
Contribute and maintain in the Pipeline the quantity of Crude Oil as may be necessary to fill in the
line according to the instructions provided by the Transporter. 4.1.17 Indemnify the Transporter and
the owner for any damage which may be caused by, or as a consequence of failing to fulfill its
obligations. 4.1.18 all those derived from the Transportation contract of this Manual and any
applicable regulations. 4.2 Obligations of the Transporter: The following are obligations of the
Transporter: 4.2.1 Maintain the Pipeline in adequate operating conditions. 4.2.2 Allow access to the
Pipeline of any Third parties requesting it in those cases in which there is available Capacity,
provided they fulfill the requirements established in this Manual.

11
<!-- page 32 -->
Operation and Transport Regulations Version 1 4.2.3 Enter into Transportation Contracts with Senders
and Third parties which comply with the requirements of this Manual. 4.2.4 Prepare, publish and keep
the BTO updated. 4.2.5 Submit the Manual to the Office of Hydrocarbons of the Ministry of Mines and
Energy, keep it updated and publish it in the BTO. 4.2.6 Report to the Office of Hydrocarbons of the
Ministry of Mines and Energy, the Transportation Contracts subscribed with the Senders within ten
(10) days after its execution. 4.2.7 Pursuant to Article 47 of the Petroleum Code of Colombia give
notice to the Office of Hydrocarbons of the Ministry of Mines and Energy on the Transportation
requests made by Third parties to use the available Capacity within (30) days following reception of
the applications, indicating the Contracting Party or applicant, the distance and the volumes to be
transported. 4.2.8 Conduct its Transportation activity separately from other activities and giving
an objective treatment to all agents in connection with the Pipeline. 4.2.9 Refrain from conducting
restrictive commercial practices or those considered as unfair competition as set forth in laws 155
of 1959, 256 of 1996, Decree 2153 of 1992, Law 1340 of 2009 and all other regulations as amended and
superseded. 4.2.10 Provide suitable facilities to receive the Crude Oil according to their
specifications set out in this Manual, control volumes and the quality of the same and carry out the
Transportation according to the industry's specifications. 4.2.11 Attend the Transportation
requirements from Third parties and Senders, and implement the nomination process under the terms
set out in this Manual and the applicable regulations. 4.2.12 Provide the Senders the information on
volumes at the Point of Entrance, volume withdrawn at the Point of Exit and the inventory of Crude
in the Pipeline. 4.2.13 Establish control and inspection mechanisms to maintain the integrity of the
Pipeline, and based on this, schedule maintenance and required repairs. 4.2.14 Calibrate the
measurement and quality control instruments of Crude Oil, according to the procedures and timing
required by the producers, the technical regulations and provisions established for this purpose in
this Manual, inviting the Senders or their representatives to provide support if considered
necessary. 4.2.15 Charge the corresponding rates for Transportation services.

12
<!-- page 33 -->
Operation and Transport Regulations Version 1 4.2.16 collect and Pay the Transportation tax pursuant
to article 26 of Law 141 of 1994 or any other regulations as amended or superseded. 4.2.17 Publish
the Transportation rates in the BTO. 4.2.18 Comply with all regulations set out for the protection
and preservation of the environment foreseeing all procedures for closing and abandonment of the
Pipeline. 4.2.19 Submit to the Office of Hydrocarbons of the Ministry of Mines and Energy before
March 1 of each year, the special annual report referred to in article 204 of the Petroleum Code or
any other regulations as amended or superseded. 4.2.20 Use the available Capacity if there is any,
for the Transportation of Third Party's Crude, upon request, and with the previous subscription of
the respective Transportation contract. 4.2.21 Maintain rules and procedures to attend expansion
requests, when the available Capacity is not sufficient to cope with the Transportation requests of
Crude from Third parties 4.2.22 allow preferred Transportation of Crude Oil to refineries in order
to satisfy the country's needs and avoid a national shortage pursuant to article 58 of the petroleum
code. 4.2.23 Permit that, in the event there is available Capacity, the Sender or Third Party
conduct additional investments as required, to provide access and Capacity to use that means of
Transportation pursuant to the regulations on access and investments indicated in this Manual and
other applicable regulations. 4.2.24 Submit to the Office of Hydrocarbons of the Ministry of Mines
and Energy the information on cost, rates on volumes and all other information as required. 4.2.25
All those derived from the Transportation contract of this Manual and other applicable regulations.
CLAUSE 5 FEES 5.1 The Pipeline fee shall correspond to the rate established according to the
methodology to set out rates pursuant to resolution 124386 of 2010 from the Ministry of Mines and
Energy as amended or superseded. 5.2 Without prejudice of the foregoing, the Transporter may agree
with the Senders the monetary conditions for the Pipeline fee considering the commercial and
technical items listed hereunder, including but without being limited to: 5.2.1 Commercial
Conditions

13
<!-- page 34 -->
Operation and Transport Regulations Version 1 5.2.2 Contracted Capacity 5.2.3 Contracted Term 5.2.4
Contracted Type 5.2.5 Payment Terms 5.2.6 Crude Oil Quality 5.2.7 About Utilization 5.3 The
corresponding Party shall assume any taxes as indicated by law. The Transportation Tax is the
responsibility of the Sender and is not included in the fee. CLAUSE 6 SPECIAL SERVICES 6.1 Increases
in the Transportation Capacity. 6.1.1 In the event in which the Pipeline falls short in the
effective Capacity of Transportation for the Shipment of Hydrocarbons of any of the Senders and if
there is the technical possibility to increase it through the use of any friction reduction agents
or other Operational adjustments, the Transporter may technically assess and approve this option, in
which case the Sender may use this alternative under the agreements and commercial conditions
established by the parties. The Sender understands and accepts that any costs resulting from the
implementation of this alternative are additional to the rate agreed, shall be borne by the Sender
and shall not be considered as an additional rate for the Transportation service. 6.2 Transportation
of Segregated Hydrocarbon 6.2.1In the event in which any Sender requires to transport Hydrocarbons
in a segregated manner, the Transporter may agree with this option if it is technically and
commercially viable, in which case the Sender may use that alternative under the agreements and
technical and commercial conditions established with the Transporter. The Sender understands and
accepts that any costs and damage resulting from the implementation of this alternative are
additional to the rate agreed, shall be assumed by the Sender and under no circumstance constitute
an additional rate for the Transportation service. CLAUSE 7 ADJUSTMENT OF THE EFFECTIVE CAPACITY OF
THE SYSTEM DUE TO VARIATIONS IN THE SPECIFICATIONS OF HYDROCARBONS 7.1 The effective Transportation
Capacity may vary as a function of the Hydrocarbon specifications pumped in the Pipeline. The
specifications of the Hydrocarbon delivered by the Senders may vary from this standard, obtaining as
a result a variation in the effective Transportation Capacity in the Pipeline.

14
<!-- page 35 -->
Operation and Transport Regulations Version 1 7.2 In case there is an increase in the effective
Transportation Capacity by using a Hydrocarbon of different specifications to those agreed in the
Transportation contract, this Capacity in excess shall be assigned according to the order of
priorities established in this Manual. 7.3 If a Sender with a Ship or Pay contract nominates a
Hydrocarbon of lower specifications to those agreed in the Transportation contract and this
generates a decrease in the Transportation effective Capacity, the Transporter may accept the
delivery of the Hydrocarbon, in which case the Sender understands and accepts that it will transport
a lower equivalent quantity dude to the change in the specification and the economic conditions of
the Ship or Pay contract shall not be modified. 7.4 The Transporter shall be in charge of defining
the increases or decreases of Capacity generated by a variation in the specifications of the
Hydrocarbon. This process shall be conducted once a month as part of the nomination process. CLAUSE
8 PROJECTIONS, NOMINATION AND TRANSPORTATION SCHEDULE OF THE PIPELINE 8.1 Projections. 8.1.1 In the
month of October of each year, the Transporter shall prepare the Transportation plan for the
following five (5) fiscal years, expressed in barrels per calendar day (bpdc in Spanish). For the
first year volumes per month shall be provided and for subsequent years there will be volumes per
year. As a result of the preparation of this Transportation plan, the estimation of the available
Capacity the Transportation of Third Party's Crude shall be available in compliance with the
provisions in article 47 of the petroleum code as amended or superseded. These information and
Transportation Capacity shall be available for consultation in the BTO. 8.1.2 The procedure to be
followed shall be as follows: 8.1.2.1 The first day of each September or before, all Senders shall
submit to the Transporter the information on the projections of the volumes to be nominated for the
five subsequent fiscal years and for the following fiscal year this information shall be specified
monthly. Such information shall include the following: 8.1.2.1.1 The best estimate of the Sender,
the volume to be transported in bpdc, assuming uniform flow rates expressed separately for each
Hydrocarbon to be delivered; 8.1.2.1.2 The quality characteristics of each Hydrocarbon;

15
<!-- page 36 -->
Operation and Transport Regulations Version 1 8.1.2.1.3 The Points of Entrance, expressed separately
for each Hydrocarbon, with the delivery program for each of them; and 8.1.2.1.4 The Points of Exit,
expressed separately for each Hydrocarbon, with the withdrawal program for each of them. 8.1.2.2
Within the first 15 days of the Third calendar month of each quarter, the Sender shall deliver to
the Transporter the update of the volume projections to be nominated in average per day for the
remaining calendar months of the current fiscal year and the average per day for the following two
fiscal years. 8.2 Nomination Scheme and Transportation Schedules 8.2.1 Nominations are accepted and
scheduled independently from the incoming restrictions to other systems, upon which there is no
responsibility from the Transporter to make these schedules or to contract Transportation quotas in
other Transportation systems. 8.2.2 The following process is established in order to comply with and
enforce Transportation schedules: 8.3 Nomination of the ANH, Owners and Senders with Ship or Pay
Contract. 8.3.1 At the latest on the Third calendar day of the month of nomination, the ANH or
whoever is designated shall carry out the nomination of the royalties of Crude Oil coming from the
fields served by the Pipeline. In this same term, the owners shall nominate the Crude Oils possessed
and all other Senders with Ship or Pay contract shall carry out the nomination of their
Transportation requirements for the following month of Operation. Additionally, the Senders
previously mentioned shall deliver their tentative Transportation needs for the following five
calendar months. The Sender shall specify: name of the Hydrocarbon, the requested volume to be
transported, quality, regime of deliveries during the month of Operation, Point of Entrance and
Point of Exit, as well as any other specific information as required or requested by the
Transporter. 8.3.2 If the nomination of royalties is higher than the preferred right, the nomination
shall be adjusted to that value. Royalty Crude Oils are considered those directly nominated by the
ANH in its Capacity as Sender or whoever is designated, except when these are sold to another Sender
or to a Third Party. If the owners buy Crude from royalties, the Transporter shall account for them
within the preferred right without affecting the Capacity of the owner. 8.4 Acceptance and rejection
of Nominations and disclosure of Available Capacity.

16
<!-- page 37 -->
Operation and Transport Regulations Version 1 8.4.1At the latest on the seventh calendar day of the
month of nomination, the Transporter shall communicate to the ANH, the owners and all other Senders
with Ship or Pay Contracts its acceptance or rejection of the nominations and the final volume
accepted, taking into account the priorities, the overutilization and the generation of additional
Capacity due to change in specifications of the Hydrocarbon. Senders with Ship or Pay contract shall
be assigned volumes to be transported up to the volume of their Contracted Capacity. Based on the
accepted nominations, the Transporter shall calculate the available Capacity, which shall be
published in the BTO as previous requirement to any additiona nominations of Senders and of Third
parties having any interest and contracting the Transportation service. 8.5 Additional Nominations
of Senders and nominations from Third Parties 8.5.1At the latest on the ninth calendar day of the
month of nomination, any Third Party may carry out the nominations of their Transportation
requirements under the modality of Spot Contracts for the month of Operation. All Senders may
nominate additional volumes at this stage. Additionally, all Third parties and Senders with
additional nominations to their Contracted Capacity shall deliver the tentative Transportation needs
for the following five (5) calendar months. Third parties and Senders shall specify: name of the
Hydrocarbon, request for the volume to be transported, delivery schedules during the month of
Operation, Point of Entrance and Point of Exit, as well as any other information as required by the
Transporter. 8.5.2 if nominations exceed the available Capacity of the Pipeline, the assignment of
the volumes to be transported shall be at a prorate of the requests received and up to the available
Capacity. 8.6 Closing the Nomination Process 8.6.1At the latest on the twelfth calendar day of the
month of nomination the Transporter shall conduct the closing of the nomination process and shall
publish the nominations approved for all Senders and Third parties as well as the Programmed
Capacity of the Pipeline. Likewise, it will carry out the publication of any available Capacity if
such is the case. 8.7 Final Scheduled of Transportation 8.7.1 The Transporter shall prepare the
final scheduled Transportation for the month of Operation and an estimate for the following five (5)
calendar months and shall submit it to the Senders and Third parties with assigned Capacity at the
latest on the twelfth calendar day of each month of nomination. 8.7.2 This schedule may be modified
by the Transporter, among other reasons: 8.7.2.1 Due to justified events that affect the
Transportation Capacity

17
<!-- page 38 -->
Operation and Transport Regulations Version 1 8.7.2.2 By request of the Transporter, accepted by the
Senders or by request of a Sender accepted by the other Senders and the Transporter. 8.7.2.3 Derived
from any other circumstances beyond the control of the Transporter. 8.7.3 Priority criteria for
assignment of capacities en case of the aforementioned modifications shall be those established in
clause 10 of this Manual. 8.7.4 The Sender shall notify the Transporter as soon as possible, if it
is found that: (i) its deliveries during a month of Operation at a Point of Entrance will be less
than 95% of the Scheduled Capacity or (ii) its withdrawals at any Point of Exit shall be less than
95% of the Scheduled Capacity. With the reception of the information, the Transporter shall analyze
the impact of the acquired commitments for Transportation and will make decisions at its Sole
discretion to mitigate the impact. 8.8 Extemporary Nominations 8.8.1 If any Third Party or the
Sender fails to meet the terms set out to nominate in accordance with the procedures contained
herein, the Transporter shall not be obliged to accept such nominations. The Transporter shall only
accept extemporary nominations as long as the Pipeline has available Capacity. If the nomination is
accepted, the Third Party or Sender shall Pay to the Transporter as a penalty, two (2%) of the
applicable rate to the volumes in barrels delivered in the Pipeline in the respective month. 8.9
Final Report of Operation 8.9.1 At the end of each month of Operation, the Transporter shall prepare
a report which shall be delivered to the Senders at the latest on the tenth (10) working day of the
following calendar month of the month of Operation indicating the volumes in Gross Standard Barrels
and Net Standard Barrels delivered and withdrawn and the average qualities at each Point of Entrance
and Point of Exit. CLAUSE 9 BALANCE IN EXCESS OR DEFECT 9.1 The following procedure for the balance
of each Sender is established as follows: 9.1.1 Each Sender shall schedule its withdrawals according
to its delivery schedules. 9.1.2 In case that a Sender fails to fulfill or is not meeting its
delivery schedule during the month of Operation, the Transporter may adjust the withdrawal schedule
of the Sender in question, to comply at all times with numeral 9.1.1 of this clause. In any case, if
the Sender fails to meet its delivery or withdrawal schedule, the Sender shall Pay the Transporter
the full amount of costs associated to such breaching, including but without being limited to those
referred to storage or disposal of the Hydrocarbon, which shall be reported through a provisional
notice.

18
<!-- page 39 -->
Operation and Transport Regulations Version 1 9.1.3 In case of withdrawals in excess and in defect
it is establish that if a Sender withdraws in excess or fails to withdraw its Hydrocarbon at the
Points of Exit, pursuant to the current schedule, the Transporter may at its Sole judgment start the
following procedure: 9.1.3.1 The Transporter shall offer the withdrawal in defect or a portion of it
to other Senders in proportion to the assignment of Capacity in the nomination process in the month
of Operation. Each Sender to whom this volume has been offered shall be respond to this offer in the
following forty eight (48) hours. 9.1.3.2 As a result of the responses received, according to the
offer of numeral 9.1.3.1, the Transporter may make new offerings or assign the withdrawal in defect.
9.1.3.3 Based on the implementation of the procedure, the Senders who will withdraw the volumes in
defect shall be determined. 9.1.3.4 The balance of the withdrawals in excess shall be reflected in
the volumetric compensation by quality. 9.1.3.5 In no case the Transporter shall be responsible for
the Hydrocarbon that a Sender has not withdrawn and as a result of that, the Pipeline had to be
evacuated. The Sender that has not withdrawn shall have the exclusive responsibility for all damages
and costs caused in the procedures for evacuation that the Transporter has to implement, which shall
be informed through provisional notices. 9.1.4 The Transporter shall prepare a monthly balance
showing for each Sender, the situation of deliveries and withdrawals in excess or withdrawals in
defect. This balance shall be the result of the process of volumetric compensation for quality (CVC)
CLAUSE 10 PRIORITIES IN THE NOMINATION PROCESS 10.1 For purposes of the nomination process the
priorities indicated in this clause shall be followed. In the event in which the sum of the volumes
requested by the Senders exceeds the effective Transportation Capacity, o when due to the events
mentioned in numeral 8.7.2 the effective Transportation Capacity is reduced below the sum of the
volumes assigned to the Senders, the Transporter shall calculate the volumes assigned in the
Transportation schedule to each Sender according to the following priorities:

19
<!-- page 40 -->
Operation and Transport Regulations Version 1 10.1.1 First: Crude of royalties of the State coming
from the fields served by the Pipeline. This priority makes reference to a preferred right that
Crude Oils from royalties shall have in the nomination process for the preparation of the
Transportation schedules. For purposes of this first priority, Crude Oil sold by the State to a
Third Party or Sender non-owner, shall not be considered as Crude of royalties of the State. 10.1.2
Second: Nominations of the owners, its parent and subsidiaries. 10.1.3 Third: Nominations of Senders
non-owners with Ship or Pay Transportation Contracts. 10.1.4 Fourth: Nominations of Third Parties.
10.2 For Transportation Contracts different than Ship or Pay Contracts in force prior to the
enforcement of this Manual, a transitory priority between Third and fourth priority shall be
applied. 10.3 Within the Third and fourth priority, the assignment of volumes or the reduction of
volumes assigned shall be made at prorate of the capacities of each Sender and the nomination of
each Third Party respectively. CLAUSE 11 REJECTION OF A TRANSPORTATION REQUEST 11.1 The Transporter
reserves the right to reject any Transportation request in addition to the reasons mentioned during
the nomination process and the Transportation schedule, those coming from a Sender who has breached
a Transportation contract, this Manual or any applicable regulations, including but without being
limited to: 11.1.1 Delivery of Hydrocarbons without the minimum quality specifications indicated in
this Manual. 11.1.2 Failing to deliver sufficient Hydrocarbons to fill in the line in the proportion
that corresponds, 11.1.3 Late Payment or no Payment of the rate, 11.1.4 Failing to comply with the
Transportation schedule either in deliveries and/or withdrawals. 11.2 The rejection of a request due
to any justified event by the Transporter shall not be considered as a breaching of the obligations
of the same and this shall be made without prejudice of other actions the Transporter or the owner
may have to make effective the any damages that a Sender or a Third Party may have caused.

20
<!-- page 41 -->
Operation and Transport Regulations Version 1 CLAUSE 12 QUALITY REQUIREMENTS 12.1 The minimum values
of quality that the Crude delivered by the Senders must have to be accepted for Transportation in
the Pipeline are:

For specific systems the Transporter defines minimum parameters for quality which are listed in
Annex 4 Minimum Quality Specifications by System. 12.2 Quality Certification. 12.2.1 The Sender
shall always provide the Transporter a certificate evidencing the characteristics and quality
specifications of the Hydrocarbon, which shall be delivered to the Transporter. The certificate
referred to in this numeral shall be issued by a company specialized in this matter and independent
from the Sender. If the Sender fails to provide the corresponding certificate, the Transporter shall
not have the obligation to accept or transport the Hydrocarbon through the Pipeline. 12.2.2 The
minimum characteristics of the Hydrocarbon which must be included in the certificate are: Viscosity
cST and SSU at 86°F, 100°F and 140°F, gravity API at 60°F, sulfur content, salt content, BSW,
Acidity and Point of fluidity. 12.3 Extra costs 12.3.1 The Transporter and the Sender may agree on
the delivery of Hydrocarbons with lower characteristics than the minimum required, in which case the
Sender shall pay all costs and expenses to improve the Hydrocarbon and to bring it to acceptable
Transportation specifications for the Transporter. 12.3.2 The agreement to make this scheme
Operational shall be recorded in writing.

TEST PARAMETER VALUE OF THE PARAMETER TEST STANDARD Sediment and water or particles Not to exceed
0.5% in volume Sediments -ASTM D473 Water - Karl Fisher API at 60 °F Higher than 18 degrees API but
less than 50 degrees API D 1298 V i s c o s i t y @ t e m p e r a t u r e o f reference Not to
exceed 300 cSt at 30 °C ASTM D445 or D446

Vapor pressure Not to exceed 11 lb/square inch Reid Vapour Pressure ASTM D323

Temperature of reception Not to exceed 120 °F Salt content 20 PTB ASTM D 3230 Point of fluidity Not
higher than 12 °C ASTM D 93

21
<!-- page 42 -->
Operation and Transport Regulations Version 1 CLAUSE 13 DETERMINATION OF QUANTITIES AND QUALITY 13.1
Measuring equipment and applicable regulations. 13.1.1 Quantity and quality measurements and
Hydrocarbon samples delivered or withdrawn shall be conducted by the Transporter or whoever is
designated through the measurement systems installed at the node of Entrance and node of Exit; each
measuring system installed may include among other things: 13.1.1.1 Calibration unit (Prover)
installed and calibrated according to the method "water-draw" (for water distillation) as specified
in the Manual API MPMS-4 "Petroleum Measurement Standards", Chapter 4 "Proving Systems" in the most
recent edition. 13.1.1.2 Turbine meters of positive displacement or Coriolis type installed in
accordance with Manual API MPM-6 MPMS-4 "Petroleum Measurement Standards", Chapter 6 "Metering
Assemblies Standards" in its last edition. The meters factors shall be derived by calibration using
the same standards, taking into account correction by temperature and pressure. 13.1.1.3 A device
for continuous sampling as specified in Manual API MPMS "Petroleum Measurement Standards", Chapter 8
"Sampling" in its last edition. The methods to be used to determine the characteristics of the
samples are the following: - Water (by distillation) ASTM D 4006 - Water by Karl Fisher ASTM D 4377
- Salt content ASTM D 3230 - Sediments (by extraction) ASTM D 473 - Density API 1298 - Sulfur ASTM D
4294 13.1.1.4 A BS&W measuring equipment may also be available by the centrifuge method, following
in that case, the proving method ASTM D 4007. The density of samples shall be determined in the
event of damage of the density meter or to validate or calibrate the density meter measurements.
13.1.1.5 A density meter for permanent measurement of density. 13.1.1.6 An electronic system for the
measurement of flow adjusted to API MPMS, Chapter 21.2 requirements in the last edition. 13.1.1.7
The volumetric correction factor to be applied shall be the one appearing in the last edition of
tables 23 and 24 of the ASTM 1250 method.

22
<!-- page 43 -->
Operation and Transport Regulations Version 1 13.1.1.8 The calculation of the dynamic and static
measurements shall be made in accordance with the current API, Chapter 12 or 4 regulations as it may
correspond. 13.1.2 The Transporter shall return to the Sender, measured in those nodes of Exit
specified by the Sender, a volume of Crude equivalent to the volume delivered by the Sender and
measured at the nodes of Entrance with the following adjustments: 13.1.2.1 Deductions for
Identifiable Losses and Non-identifiable losses. The Identifiable Losses and Non-identifiable losses
shall be distributed among the Senders according to the provisions in the Procedure for Adjustments
for Volumetric Compensation for Quality. 13.1.2.2 Increases or reductions necessary to be made as a
result of making adjustments for Volumetric Compensation. 13.2 Accounting for losses 13.2.1 The
volume of all Crude Oil losses produced in the system shall be calculated by the Transporter using
its best Operational and engineering judgment. 13.3 Process to determine quantities and qualities at
the Points of Entrance and Points of Exit. 13.3.1 Quantity measurements and quality sampling of
deliveries and withdrawals (including calibration of instruments) shall be the Transporter's
responsibility and shall be made according to the standards and accepted prevailing practices by the
API and the ASTM. The installed equipment to conduct measurements and sampling shall be determined
by the Transporter. 13.3.2 The Transporter shall ensure to set out adequate measuring and
calibration procedures at the nodes of Entrance and nodes of Exit. Calibration of the measuring
systems shall be made as required by operating circumstances under the Transporter's criteria. The
calibration factor of the meters shall be effective only after the date of the latest calibration
except in case of manifest error in which case the last factor of valid calibration shall be
applied. 13.3.3 The Transporter has the responsibility to take two samples of representative Crude
Oil according to the API standards and with the adequate volume for each delivery and withdrawal
made. The frequency of such sampling shall be determined occasionally by the Transporter based on
the continuity of the Crude's quality among other factors. Samples shall be used for the following
purposes:

23
<!-- page 44 -->
Operation and Transport Regulations Version 1 13.3.3.1 To determine the quality. 13.3.3.2 The
Transporter shall retain a sample for each delivery and withdrawal, which shall be used as a
counter-sample. The Transporter shall preserve said sample for a period no longer than 15 calendar
days in case there are any claims regarding a specific delivery or withdrawal. After this lapse of
time it will not be possible to make any claims in this sense. 13.3.4 Crude volumes that the
Transporter shall be committed to transport shall be determined using the measurement systems of the
Pipeline following the API and ASTM standards. The Transporter shall ensure the filling in of all
official forms for each kind of measurement, which shall contain as a minimum the following
information: the date, the readings of the meters or the measures of the storage tank or tanks
before starting and upon completion of the deliveries or withdrawals, the API gravity, densities,
temperatures, pressures, sediment and water percentages and any other necessary characteristic for
its identification. The forms above mentioned constitute documents, which shall be used to make
calculations for the Transportation value and the adjustment for volumetric compensation and shall
serve as proving documents for any other purpose. 13.3.5 At any time before starting any delivery or
withdrawal and in intervals with a frequency not higher than two (2) times per month, the Sender may
inspect, through an independent inspector, with previous approval from the Transporter, the accuracy
of the results of the measurements and the samples taken to determine the quantity and quality of
the Hydrocarbon. The Sender shall bear the cost of said inspection. For this purpose the respective
Sender shall notify the Transporter the name and title of the independent inspector at least five
business days before the measurement of the corresponding Crude. 13.3.6 The calibration of the
measurement equipment shall be made as required by the Operational circumstances or by written
request received from a Sender in particular under the Transporter's judgment. The meters factors
shall be updated every time this procedure is conducted. Prior to the calibration of the meters, the
Transporter shall notify the Senders the dates in which said calibration shall be carried out so
that they if deemed necessary, may be present in the calibration. The meters calibration factor
shall be effective only after the date of the last calibration and the parties participating in the
calibration shall issue a certificate; otherwise this shall be documented in a letter from the
Transporter to the Senders. 13.3.7 Pursuant to API recommendations, testers shall be re-calibrated
at least once every five years (from the date of the last calibration) o immediately after any
alteration in the measuring section.

24
<!-- page 45 -->
Operation and Transport Regulations Version 1 13.3.8 The Hydrocarbon volumes that the Transporter
accepts and schedules for its Transportation shall be determined by meters installed in the nodes of
Entrance and/or Exit. Notwithstanding the foregoing, the Transporter may use alternate methods
included in the API standards. If the static measurement of tanks is used, these must have their
measurement approved by the Ministry of Mines and Energy or the competent entity. The tank
measurement shall be determined following the current existing standards for such purpose. CLAUSE 14
VOLUMETRIC COMPENSATION FOR QUALITY 14.1 The Regulations of Volumetric Compensation for Quality is
an integral part of this Manual as annex 1 (MECHANISMS OF COMPENSATION OF QUALITY FOR THE MIX OF
CRUDE OILS). 14.2 Each of the Senders shall deliver to the Transporter at a Point of Entrance a
Hydrocarbon volume which, and only for purposes of Volumetric Compensation for Quality (CVC), shall
be valued according to the procedure defined for the Pipeline and in accordance with its particular
quality. This quality shall be determined by an independent quantity and quality inspector accepted
and recognized both by the Transporter and the Sender. 14.3 Considering that as a result of the
Transportation the Hydrocarbons delivered in the Pipeline are mixed without distinction, each Sender
shall withdraw at the Point of Exit a volume of Hydrocarbons with a different quality than its
Hydrocarbon delivered, except when it has been requested and has been accepted the Transportation of
Hydrocarbons in a segregated manner. The quality of this segregated Hydrocarbon shall also be
determined by an independent quantity and quality inspector accepted and recognized both by the
Transporter and the Senders. This Hydrocarbon shall be assessed only for purposes of Volumetric
Compensation for Quality and shall take into account the compensation for quality due to the
interfaces occurring when transported with other Crude Oils. 14.4 The Transporter shall apply the
mechanism of Volumetric Compensation for Quality defined by the same for the Pipeline which shall
have the following main characteristics: 14.4.1 The Senders who have delivered to the Transporter
Hydrocarbons with a better quality than the mixed Hydrocarbon withdrawn at the Point of Exit of the
Pipeline shall be entitled to compensation in volume, equivalent to the volumes that Senders who
have delivered Hydrocarbons of lower quality than the ones withdrawn at the Point of Exit will have
to assume. For such purpose, individual qualities of all volumes delivered and withdrawn shall be
taken into account as well as the final inventories of the preceding month of Operation and the last
month of Operation, with its respective qualities.

25
<!-- page 46 -->
Operation and Transport Regulations Version 1 14.4.2 The Volumetric Compensation for Quality shall
be internal between the Senders in such a way that the final volumetric balances equal cero and the
Transporter shall neither charge nor Pay any volume for this purpose and shall only serve as a
mediator, regulator, liquidator and responsible for the volumetric distribution of the
compensations. 14.4.3 The Volumetric Compensation for Quality is not part of the Rate and therefore
shall not be compensated or will have any variation as a result of this. 14.5 In each month of
Operation the Transporter shall make a balance of the existing volumes and qualities at the
beginning of the month delivered to the Pipeline, lost, withdrawn and existing at the end of the
month, both for the total of Hydrocarbons as well as for individual Hydrocarbons of each Sender.
14.6 The Sender shall hold the Transporter and owner harmless against any cost, action, claim,
intended procedures by any Third parties, losses and all damage and obligations incurred and
inherent to the mix of Hydrocarbons in the Transportation process and the Volumetric Compensation
for Quality. 14.7 In any case the Transporter may modify the mechanism of Volumetric Compensation
for Quality contained herein, in the respective annexes and all other documents in connection with
the CVC. 14.8 Senders of a specific Hydrocarbon may agree with the Transporter not to apply the
Volumetric Compensation for Quality to said Hydrocarbon. The foregoing shall be applicable as long
as the Hydrocarbon of other Senders is not affected negatively. 14.9 By agreement between the
totality of Senders and the Transporter, it may be decided not to implement the Volumetric
Compensation for Quality (CVC) for Crude Oils transported through the system. In this case the
Transporter may implement any other mechanism validated with the Senders to carry out the volumetric
balances. CLAUSE 15 BULLETIN OF TRANSORTATION BY THE PIPELINE - BTO 15.1 The Transporter shall
implement the Bulletin of Transportation by the Pipeline - BTO - which shall contain as a minimum
the following information: 15.2 Information of public access: 15.2.1 General description of the
Pipeline 15.2.2 Current rates for each Distance 15.2.3 Value tables or current calculation formulas
of Monetary Conditions 15.2.4 Design Capacity of the Pipeline and Nominal Capacity

26
<!-- page 47 -->
Operation and Transport Regulations Version 1 15.2.5 Monthly available Capacity of the Pipeline
estimated for the next (6) months and annual for the next five (5) years. 15.2.6 Excerpts of this
Manual corresponding to connection requests, nomination process and minimum quality requirements of
Crude Oil 15.3 Information of exclusive access for Senders and Third parties: 15.3.1 This valid
Manual. 15.3.2 Discussion on modifications to the Manual 15.3.3 General information on the
programmed maintenance schedule of the Pipeline and other programed activities affecting the
effective Capacity during the next six (6) months. 15.3.4 Listing of expansion projects and changes
in the Pipeline's infrastructure 15.3.5 Effective Capacity confirmed for each month of Operation and
estimated for the following five (5) months and the corresponding available Capacity for each
Distance. 15.3.6 Transportation program for the month of Operation and tentative for the following
(5) months for each Distance 15.3.7 Description of the mechanism established by the Transporter and
foreseen in the nomination process to assign the available Capacity equitably 15.3.8 Last volumetric
balance prepared for the Pipeline. 15.3.9 Daily statistics for the last month of Operation and
monthly statistics since the enforcement of Resolution 181258 of 2010 from the Ministry of Mines and
Energy on the information on Effective Capacity and Volumetric Balances. 15.3.10 The annual rates
and the Monetary Conditions for each Distance from the date of enforcement of Resolution 181258 of
2010 from the Ministry of Mines and Energy. 15.4 The Transporter is no obliged to publish any
information of reserved character. 15.5 The Transporter shall provide to Senders and any Third
parties interested in transporting Hydrocarbons through the Pipeline as requested, within the
following ten (10) calendar days after the request and with previous verification from the
Transporter of their Capacity as Sender or Third Party an access password to the information of
exclusive character referred to in numeral 15.3 of this clause. The access with a password shall be
active while the requestor maintains its Capacity as Sender or Third Party.

27
<!-- page 48 -->
Operation and Transport Regulations Version 1 15.6 The Transporter shall communicate any updates,
amendments or additions of relevant information in the BTO by means of electronic mail or direct
communication to the Office of Hydrocarbons of the Ministry of Mines and Energy and to all those
with active access to the information of exclusive character pursuant to the previous numeral.
CLAUSE 16 SPECIAL TRANSPORTATION CONDITIONS 16.1 The Transportation of Hydrocarbons shall be subject
to the following conditions: 16.1.1 The Hydrocarbon shall be delivered by the Sender at a Point of
Entrance and withdrawn at a Point of Exit. 16.1.2 The Transportation of Hydrocarbon shall be subject
to performance of the conditions foreseen in the Transportation Contract, the Manual hereof, its
modifications, additions or updates, including its annexes and the applicable regulations. 16.1.3
The Transporter reserves the right to receive or reject a Hydrocarbon that fails to meet the minimum
specified values; in case of reception, the Sender shall Pay the Transporter any costs incurred in
the analysis and eventual treatment of this Hydrocarbon to place it within the required
specifications or to implement the scheme required for its Transportation. 16.1.4 The Transporter
reserves the right to require, reject or approve the injection at any other Point in the Pipeline of
products such as corrosion inhibitors, depressors of Point of fluidity, friction reducers or any
other additive in the Hydrocarbon to be transported. The Sender shall Pay the Transporter all costs
incurred in the analysis and eventual treatment of this Hydrocarbon to place it within the required
specifications or to implement the scheme required for its Transportation. 16.1.5 The Transporter
reserves the right to transport Hydrocarbons delivered by Senders that exceed the limits determined
by Transporter for organic chloride, sand, dust, dirtiness, glues, impurities, other objectionable
substances or any other compounds with physical or chemical characteristics that, under the
exclusive determination of the Transporter may cause that the Hydrocarbon would not be easily
transported, may damage the Pipeline or may interfere with the Transportation and the withdrawals.
The Sender shall Pay the Transporter all costs incurred in the analysis and eventual treatment of
this Hydrocarbon to place it within the required specifications or to implement the scheme required
for its Transportation. 16.1.6 The Transporter shall be entitled, with a previous provisional
notice, to remove and sell the Crude of any Sender that fails to comply with any of the
specifications at its Sole discretion. If the Transporter exercises its right of sale pursuant to
this clause, the Transporter shall deduct from the proceeds of such sale all costs incurred by the
Transporter with respect to the storage, removal and sale of such Crude Oil. The Transporter shall
pay the balance to the Sender.

28
<!-- page 49 -->
Operation and Transport Regulations Version 1 16.1.7 The Transporter shall not accept Crude Oil
delivered by any Sender if this may cause impairment to the Pipeline of the Crudes or mixtures
transported (without consideration of whether or not the Crude Oil meets the minimum quality
specifications). 16.1.8 The Transporter acting reasonably and in good faith, shall be entitled to
make any changes to the minimum quality specifications of Crude Oil in accordance with operating
practices, which may be necessary or pertinent, including but without being limited to, prevent
material damage or the material degradation of the effective Capacity of the Pipeline in order to
prevent any personal injuries or damage to the property or the environment. CLAUSE 17 REGULATIONS
FOR THE TRANSPORTATION OF SEGREGATED HYDROCARBON 17.1 With a previous request from the Sender or
Third Party, the Transporter may accept the Transportation of segregated Hydrocarbon to the extent
that this is a technical and economically viable alternative. The Transportation of segregated
Hydrocarbon cannot change the scheme set out in clause 10 and shall be conducted pursuant to the
provisions in this Manual. 17.2 As a consequence of the foregoing, the Transporter shall inform the
Sender its disposition to start the Transportation of segregated Hydrocarbon. The Transportation of
segregated Hydrocarbon shall be subject to the nomination process set forth in this Manual. 17.3 Any
additional charges for Transportation of segregated Hydrocarbon shall be borne by the Sender or
Third Party requesting the service, and it will be taken into account, including but without being
limited, any costs and damage caused to the Transporter, owner or other Senders. CLAUSE 18 RISKS AND
RESPONSIBILITY 18.1 The Transporter shall exercise custody on the Hydrocarbon from the time the
Sender or whoever the Sender designates, delivers it at the Point of Entrance and until the Point of
Exit. 18.2 Neither the Transporter nor the owner shall be responsible for the consequences of
failing to comply with the deliveries and withdrawals generated by the Sender in the Transportation
program, commitments of operators and/or Transporters of Transportation systems connected to the
Pipeline.

29
<!-- page 50 -->
Operation and Transport Regulations Version 1 18.3 The Transporter shall not be responsible for any
damage or deterioration that a Hydrocarbon delivered by a Sender may suffer, such as contamination
with strange materials, contamination by contact of different types of Hydrocarbons if the damage or
deterioration is due to Justified Events. In the event any of the cases previously mentioned occurs,
and one or more Senders are involved, all the Hydrocarbons affected shall be prorated between the
Senders in proportion to the ownership of each of the Hydrocarbons involved, without prejudice of
any indemnities afterwards which may be applicable between the Senders affected. The Transporter
shall prepare the information corresponding to the volume of Hydrocarbon affected and the proportion
corresponding to each Sender. 18.4 The Transporter shall be responsible for the Transportation
service, for any losses, damage or deterioration that the Hydrocarbon may suffer. The Transporter
shall be released from any responsibility in the Justified Events and the Transporter is not
incurring in any gross negligence. 18.5 Any damage or prejudice caused to the Transporter by virtue
of failing to comply with the regulations contained in this Manual by any Sender shall be the
responsibility of the Sender who shall indemnify the Transporter for such damage or prejudice. 18.6
Hydrocarbons delivered by each Sender and transported through the Pipeline may vary in their quality
as a result of the mix with other Hydrocarbons. Except for events in which segregated Hydrocarbons
are transported, the Transporter shall not have any obligation to return at the Point of Exit a
Hydrocarbon of the same quality as the Hydrocarbon delivered for its Transportation at the Point of
Entrance. The adjustments of Volumetric Compensation for Quality shall be applied to the transported
mixed Hydrocarbons. 18.7 In the Transportation of Hydrocarbon mix and Hydrocarbon segregated through
the Pipeline, contamination fronts are generated. All Senders of the Pipeline shall accept as
withdrawn volume, a portion of the contamination fronts generated in the Transportation through the
Pipeline. If the Sender requires some special conditions for the Transportation of a Hydrocarbon,
these shall be agreed with the Transporter who reserves the right to accept them and require the
Sender to bear all costs associated to such conditions. 18.8 The following shall be considered in
the Transportation of Hydrocarbon mix and Hydrocarbon segregated through the Pipeline: 18.8.1 The
Hydrocarbon of higher quality with respect to the Hydrocarbon of lower quality shall always be
degraded in the contamination fronts.

30
<!-- page 51 -->
Operation and Transport Regulations Version 1 18.8.2 The Transporter shall estimate a maximum volume
corresponding to the contamination fronts and shall be responsible to comply with this value. 18.9
The Transporter is obliged to return the Sender and the latter to withdraw at a Point of Exit, the
volume of equivalent Hydrocarbon upon application of the mechanism of Volumetric Compensation for
Quality. 18.10 The Senders and Third parties shall indemnify and hold the Transporter and the owner
harmless against any costs, claims, litigations, judicial or extra-judicial action, and decisions of
any kind, which may be brought against the Transporter or owner, and in general by any procedure
intended by any Third parties. CLAUSE 19 FILLING THE PIPELINE OR FILLING THE LINE 19.1 It is the
necessary volume to fill the Pipeline between the initial pumping station and the final station, the
non-pumping bottom of the storage tanks of the Pipeline, and all installations, tubes, equipment,
pumping and measuring accessories. 19.2 For the Pipeline Operation, the Transporter may request to
each Sender, including the ANH, to deliver to the Transporter the necessary quantity of Hydrocarbon
to fill in the line of the Pipeline. The participation of each Sender in filling in the line shall
be determined by the Transporter based on criteria such as: Ownership of the Pipeline and Contracted
Capacity. 19.3 The Transporter shall determine at its judgment the Day in which each Sender shall
deliver its proportional participation in filling the line of the Pipeline, and shall communicate
the corresponding volume indicating the date of delivery. 19.4 The Hydrocarbon delivered by the
Senders to fill in the line of the Pipeline shall not be withdrawn from the Pipeline without the
previous authorization from the Transporter. Without prejudice of the foregoing, the Sender shall
not lose the ownership of the Hydrocarbon remaining in the Pipeline. 19.5 When segregated
Hydrocarbon is transported, it shall be understood that the ownership of the filling of the line of
the Pipeline varies according to the volumes of segregated Hydrocarbon present in the Pipeline at a
given time. Without prejudice of the foregoing, the Sender shall not lose the ownership of the
segregated Hydrocarbon remaining in the Pipeline. CLAUSE 20 HANDLING LOSSES IN THE PIPELINE 20.1 The
identification and handling of losses in the Pipeline shall be carried out as follows:

31
<!-- page 52 -->
Operation and Transport Regulations Version 1 20.1.1 All identifiable losses of mix or segregated
Hydrocarbon not attributable to the Transporter as per numeral 18.4 shall be assumed by the Senders
of the mix or segregated Hydrocarbon according to the calculation made by the Transporter based on
the Operational parameters and formalized in the CVC. In this sense, the Senders accept the
liquidation made by the Transporter. 20.1.2 The report prepared by the Transporter shall be
considered as the basis to calculate the identifiable losses, indicating the Operation conditions of
that day, time, place, causes, deliveries, dispatches, withdrawals, mix or segregated Hydrocarbon,
recovered and lost and determined after the filling of the line and the restarting of the pumping.
20.1.3 Non-identifiable loses are understood only those losses during Transportation to which its
cause cannot be determined with precision throughout the process, from the Points of Entrance to the
Points of Exit, including but without being limited to the following:

20.1.4 The Transporter shall calculate these losses each semester in such a manner that the semester
calculation reflects the real losses occurring during each semester. The average semester of all
losses shall be up to cero Point five percent (0.5%) of the deliveries of the period. This
calculation shall be made by means of balances that the Transporter shall carry out at the beginning
of each calendar month with respect to the previous calendar month, which shall reflect the
deliveries and withdrawals, the inventory movement and the identifiable losses, if there are any, to
be calculated each semester. 20.1.5 In the case of mix Hydrocarbon, the Non-identifiable Losses of
the semester shall be assumed by each of the Senders at prorate of the deliveries of the period.

· Stops/ starts of the Pipeline · Illegal extractions non-detected · Faults in the meter factors ·
Volumetric contractions · Leakages/passes in the valves · Evaporation · Escapes · Inherent
uncertainties on the measurement systems and associated instrumentation · Inherent uncertainties of
laboratory analysis associated to the calculation of volumes · Propagation of inherent uncertainties
of the procedures set out at the international level for the calculation of volumes by static and
dynamic measurement. · Handling loses inherent to the Pipeline

32
<!-- page 53 -->
Operation and Transport Regulations Version 1 20.1.6 In the case of segregated Hydrocarbon, the
Sender of the segregated Hydrocarbon shall assume the Non-identifiable losses of the semester.
20.1.7 In the event that Non-identifiable losses exceed cero Point five percent (0.5%) of the
deliveries, calculated each semester, the Transporter shall inquire on the possible causes in order
to take the corrective actions immediately. 20.1.8 The calculation procedure of losses in the
Pipeline shall be governed by the provisions in this clause and the current Compensation Mechanism
for Quality for the Mix of Crude Oil. 20.1.9 Non-identifiable losses equal or less than 0.5% monthly
shall be distributed according to the value in US dollars of the deliveries by each Sender of the
calendar month in which they were detected or the calendar month in which they are reported. 20.1.10
Identifiable losses are distributed according to the value in US dollars of the deliveries by each
Sender on the calendar month in which they were detected CLAUSE 21 CLAIMS 21.1 Any claim by a Sender
or Third Party in connection with the Transportation service of Hydrocarbons shall be resolved
pursuant to the internal procedures of the Transporter and the applicable regulations. These claims
shall be delivered to the Transporter's Operational area and they shall conduct the respective
internal procedure and shall communicate the result to the Sender. 21.2 For claims regarding the
quantity or quality of Hydrocarbons, these shall be presented in writing at the latest within
fifteen (15) calendar days after the date of delivery or withdrawal of the Hydrocarbon or the date
in which the report for the Volumetric Compensation for Quality is issued. The claim shall be
justified within the following thirty calendar days after being presented. 21.3 If the Sender does
not present its claim, or if made extemporaneously, or if it is not duly and timely justified, it
shall mean the acceptance by the Sender of the Hydrocarbon delivered or withdrawn or the Volumetric
Compensation by Quality, as the case may be. CLAUSE 22 SANCTIONS TO OPERATING AGENTS FOR
NON-PERFORMANCE OF THE TRANSPORTATION SCHEDULE 22.1 Each of the nominations made by Senders and
Third parties shall constitute their commitment to comply with the delivery and withdrawal schedule
with quantities and flow rates previously agreed between the parties.

33
<!-- page 54 -->
Operation and Transport Regulations Version 1 22.2 For the Operation of the Pipeline the following
particular provisions shall be taken into account to apply the following sanctions depending on the
type of Sender: 22.2.1 Sender with Contracted Capacity in Firm: 22.2.1 If by any reason the delivery
is less than 95% or more than 105% of their Scheduled Capacity, the Sender shall Pay: 22.2.1.1.1 The
Transportation fee for volumes delivered when they are higher than the Contracted Capacity in firm.
When they are equal or less the Sender shall Pay Transportation fee on the Contracted Capacity in
firm. 22.2.1.1.2 The Transporter may decide to charge the Sender a sanction equivalent to 5% of the
Transportation Fee of the Scheduled Capacity.

22.2.1.2 If by any reason, delivery is between 95% and up to 105% of its scheduled Capacity, the
Transporter shall charge the Transportation fee for volumes delivered when these are above the
Contracted Capacity in firm. When they are equal or less the Sender shall pay the Transportation fee
on the Contracted Capacity in firm. In this case there shall not be any sanction, without prejudice
of the application of other types of sanctions. 22.2.2 Sender without Contracted Capacity in firm:
22.2.2.1 If by any reason, the delivery is less than 95% or more than 105% of its scheduled
Capacity, the Sender shall Pay: 22.2.2.1.1 The Transportation fee for volumes delivered 22.2.2.1.1
The Transporter may decide to charge the Sender a sanction equivalent to 5% of the Transportation
Fee of the Scheduled Capacity. 22.2.2.2 If by any reason, delivery is between 95% and up to 105% of
its scheduled Capacity, the Transporter shall charge the Transportation fee for volumes delivered.
In this case there shall not be any sanction, without prejudice of the application of other types of
sanctions. 22.3 For the second and all faults thereafter occurring in a twelve month period counted
from the date of occurrence of the last fault, sanctions shall be 10%, without prejudice of other
types of sanctions as the may be applicable. CLAUSE 23 HYDROCARBON AFFECTED BY LITIGATION 23.1 Any
Sender or Third Party is in the obligation to notify in writing before delivery to the Transporter,
if the Hydrocarbon being the purpose of the Transportation request is being affected by any
encumbrance, claim or litigation both judicial and extra-judicial. 34
<!-- page 55 -->
Operation and Transport Regulations Version 1 23.2 The Transporter reserves the right to either
accept or reject any Hydrocarbon being affected under the terms abovementioned. Without prejudice or
the power mentioned, the Transporter shall coordinate with the Sender possible action plans in order
to ensure the rights acquired by the Senders regarding the Owner's Capacity and/or Contracted
Capacity in firm. 23.3 In case of accepting its Transportation, the Transporter may request to the
Sender the presentation of a bond at satisfaction of the Transporter to cover any damage which may
be caused to the Transporter, the owner, to other Senders and Third parties as a result of the
Transportation. 23.4 Likewise, the Sender shall indemnify and hold the transported and the owner
harmless under the terms set out in the clause of Risks and responsibility. CLAUSE 24 INVESTMENTS IN
THE PIPELINE 24.1 Regarding any requests made to the Transporter to carry out any works and
additional investments to those made in the Pipeline by the Transporter or the owner, the following
provisions shall be considered: 24.1.1 Whoever is interested or needs the execution of works for the
construction, adaptation, expansion, connection and/or addition of assets and facilities required,
as a result of the Transportation of Crude Oil through the Pipeline, shall request it (hereinafter
the "Proposal") to the Transporter with due justification and indicating the needs and
specifications of the works to be carried out. The Transporter shall indicate whether or not the
Proposal meets and/or is in accordance with the safety, and environmental requirements as well as
the technical, commercial, legal and engineering aspects in connection with the Pipeline and the
common practices of the industry in general in Colombia. 24.1.2 The Proposal submitted to the
Transporter under the previous terms shall: Include all relevant details, including but without
being limited to, a(1) the necessary additional infrastructure and the modifications to be made on
the existing infrastructure, (2) the estimated costs, (3) the time schedule for construction of the
works and start-up of the services associated to these works, (4) all estimated operating and
maintenance costs considered during the service associated to these works and (5) basic engineering;
The Proposal shall be addressed to the Transporter through the legal representative of the person
interested, for consideration and analysis of the Transporter during a lapse not to exceed 60
calendar days counted after the following day of submission of the Proposal with all the information
required.

35
<!-- page 56 -->
Operation and Transport Regulations Version 1 24.1.3 As a result of the analysis conducted, the
Transporter shall determine whether or not the Proposal is accepted, or if conditioned totally or
partially, if executed directly, or through a person designated by said Transporter, as well as the
scope of the investment and all other aspects relevant to the Proposal. 24.1.4 If the new
infrastructure modifies the Effective Capacity, the Senders or Third parties participating in the
Proposal may enter into a Ship or Pay Transportation Contract to contract a portion of the new
Capacity. In the case of the Capacity corresponding to the Transporter or Owner given the scope of
the Proposal, this shall be considered as Owner's Capacity. 24.1.5 No one may carry out any
constructions, connections or adaptations in the Pipeline without the previous written agreement
duly signed by the Transporter's representative. CLAUSE 25 SOLE RISK PROPOSALS 25.1 Proposals made
to be carried out at the Sole and exclusive Risk or Senders or Third parties (hereinafter, "Sole
Risk Proposal") shall only be executed upon completion of the process indicated in clause 24 with
the decision that the Transporter will not participate initially in the Proposal. 25.2 The Sole Risk
Proposal shall cover the same aspects as the Proposal presented in accordance with clause 24. In any
case, all Sole Risk Proposals shall meet the technical specifications in terms of measurement, the
applicable determinations of quality and safety and the regulations of this Manual, and shall have
the respective licenses, and required permits by the competent authorities as well as compliance
with the provisions that regulate the acquisition of lands and any other applicable regulations.
25.3 For this purpose the following shall be taken into account: 25.3.1 Presentation of the Sole
Risk Proposal: The interested Party shall request authorization for the Sole Risk Proposal
submitting all the necessary documentation for its study. The Transporter shall verify compliance
with the regulations on these matters and may request any clarifications or details regarding the
information. The response accepting or rejecting the request for the Sole Risk Proposal shall not
exceed a term of three (3) months from its reception, without including in this term the time
necessary to submit and respond any clarifications or details requested by the Transporter. 25.3.2
Participation of the Transporter: At any time during the approval, design, construction and start-up
of a Sole Risk Proposal, the Transporter may express its intention to participate in it. The
proportion and conditions in which the Transporter shall participate shall be determined by common
agreement between the parties. If no agreement is reached between the parties, the mechanisms set
out in clause 27 (Settlement of Controversies) shall be applied.

36
<!-- page 57 -->
Operation and Transport Regulations Version 1 25.3.3 Conditions for the Execution: The Transporter
may deny the authorization for the implementation of the Sole Risk Proposal duly justified,
including but without being limited to, safety, technical, Operational or Capacity reasons, alleging
they may affect the integrity of the Pipeline or the Operation of other Senders or by disposition of
the competent authority. The Transporter shall not be in the obligation to provide the
Transportation service until the execution of the Sole Risk Proposal fulfills the requirements
established in the Manual, the applicable engineering standards, the Transporter's provisions and
requirements and any other applicable regulations. In the case of associated systems to the
Pipeline, the Sender shall not modify the facilities or its way of Operation without the
Transporter's authorization. The Transporter reserves the right to carry out the construction,
administration, Operation and maintenance totally or partially of the Sole Risk Proposals and shall
define the scope of its participation. The costs implied thereto shall be borne by the Sender or
Third Party presenting the Sole Risk Proposal. The Sender and the Transporter may freely agree on
the means for financing and Payment. 25.3.4 Indemnity: Any Sender or Third Party participating in
the execution of the Sole Risk Proposal shall indemnify and hold the Transporter and owner harmless
under the terms set forth in the Risks and Responsibilities clause. 25.3.5 Bonds and Insurance: the
Transporter and the interested Senders in the Sole Risk Proposal shall obtain the necessary bonds
and insurance to cover any Risk derived from the Sole Risk Proposal under terms reasonably
acceptable for the Transporter, without prejudice of obtaining all other bonds and insurance
requested by the Transporter. 25.3.6 Property, financing and Operation of the Sole Risk Proposal:
For those investments that somehow change the existing infrastructure of the Pipeline and if the
Operation affects the functioning of the same, the ownership shall belong to the Transporter or the
owner. In this case the Transporter and the Sender or Third Party executing the Sole Risk Proposal,
shall agree on the mechanism for amortization. All funds required to undertake the execution of the
Sole Risk Proposal shall be procured, obtained and guaranteed by the Senders or Third parties
participating in the Sole Risk Proposal, and under no circumstances neither the Transporter nor the
owners or any other Sender shall be affected by the financing instruments that the Senders or Third
parties participating in the Proposal adopted by, or as a result therefrom. 25.3.6.1 If the new
infrastructure modifies the effective Capacity, the Senders or Third parties participating in the
Sole Risk Proposal may enter into a Ship or Pay Transportation contract to contract a portion of the
new Capacity. In the case of the Capacity corresponding to the Transporter or owner given the scope
of the Sole Risk Proposal, it shall be considered as an owner's Capacity.

37
<!-- page 58 -->
Operation and Transport Regulations Version 1 25.3.6.2 The Transporter shall facilitate to the
Senders or Third parties that will execute or have executed the Sole Risk Proposal the access to
their own infrastructure. Without prejudice of the foregoing, the Senders or Third parties that have
executed a Sole Risk Proposal shall ensure to the Transporter or owner that the Transportation
Capacity of the latter shall not be affected by the execution of the Sole Risk Proposals. In any
case, if the Capacity of the owner or Senders is affected as a result of the execution of the Sole
Risk Proposal, the Sender(s) and Third parties that have executed it shall be liable and indemnify
the owner and all other Senders. 25.3.7 Information: The Senders and Third parties participating in
the Sole Risk Proposal shall provide the Transporter all the information arising from the design,
construction, implementation, adaptation, expansion, connection, addition of assets and facilities,
and the start-up of services associated to the Sole Risk Proposal. CLAUSE 26 PROCEDURES FOR
COORDINATION OF OPERATIONS, COMMUNICATIONS AND EMERGENCY ASSISTANCE 26.1 Communications and all
other aspects associated to the coordination of the activities related to the Manual hereof, shall
be attended by the operating area of the Transporter. These communications may be directed through
field representatives of the Transporter or processed directly by personnel of the operating
coordination in the Transporter's Offices. 26.2 Meetings shall be held, depending on the
requirements from the parties, in which the Transporters and the Senders shall participate in order
to review compliance with the Transportation schedule under execution and review the Transportation
plan. In these meetings aspects impacting the Transporter's Operation shall be reviewed and aspects
or interest for the Senders shall be disclosed. 26.3 With a monthly frequency, in the Third week of
the calendar month after the month of Operation the exercise of volumetric compensation for quality
shall be conducted. 26.4 The Transporter has available a Contingency Plan that compiles the
structure and required procedures to assist in any type of emergencies which may affect the
integrity of people, the environment or the infrastructure. To provide assistance with emergencies
the Transporter applies a System Model Command of Incidents, which contemplates different flows of
horizontal and vertical communication required to ensure an effective notification and response
preparation to the event.

38
<!-- page 59 -->
Operation and Transport Regulations Version 1 26.5 In the assistance of emergencies, the
Transporter's Operations and maintenance personnel participates, as well as personnel from corporate
support to contribute in the handling of communications and the required logistics support by the
assistance group. 26.6 Likewise, the Transporter has agreements with different authorities and
emergency assistance bodies at the local, regional and national level as complement to its internal
assistance equipment. This is complemented with agreements established with companies from the
sector to provide support and mutual assistance before any event, in order to mitigate any emergency
impact. CLAUSE 27 SETTLEMENT OF CONTROVERSIES 27.1 In the event of occurrence of any conflict or
disagreement in connection with the Manual hereof or the Transportation service, it shall be
initially resolved by a representative duly authorized from each of the parties within thirty (30)
days following the notification issued by the Party who considers the existence of a disagreement
and effectively received by the other Party. 27.2 If, after the thirty (30) days abovementioned, the
disagreement continues totally or partially, the parties shall rely on any alternative mechanism to
settle conflicts contained in the Colombian legislation. CLAUSE 28 VALIDITY 28.1 The validity of
this Manual is the date of its disclosure which shall be made through a publication in the
Transporter's website. CLAUSE 29 ADDITIONS AND MODIFICATION 29.1 The Transporter may carry out
additions or modifications to this Manual, pursuant to the provisions in Resolution 18-1258 of July
14, 2010 from the Ministry of Mines and Energy as substituted or amended. CLAUSE 30 APPLICABLE
LEGISLATION 30.1 This Manual is governed in all its parts by the applicable regulations of the
Republic of Colombia.

39
<!-- page 60 -->
Operation and Transport Regulations Version 1 ANNEX 1: MECHANISMS OF QUALITY COMPENSATION FOR THE
MIXTURE OF CRUDE OIL ADJUSTMENT PROCEDURES OR VOLUMETRIC BALANCES The Transporter shall conduct the
volumetric balance with a monthly frequency in order to establish the volumes injected by each
Sender to the Pipeline, the identifiable losses, the Non-identifiable losses, consumptions,
inventory variations, and any adjustments for quality if the latter is applicable.

For purposes of the procedure hereof, the provisions set out in the Manual of the Transporter for
handling Losses in the Pipeline and in the annex hereof shall be applied.

The Transporter assumes the totality of costs for consumption of Crude Oil.

In order to make equitable adjustments between the Senders of the Pipeline by the differences in
value resulting for differences in quality of Crude Oils delivered I the Pipeline, a procedure of
volumetric compensation for quality shall be established ("CVC" in Spanish). The purpose of the CVC
is to establish a system to compensate Senders for the degradation or improvement of the Crude Oil
withdrawn compared with the Crude delivered. The Sender withdrawing a Crude o lower quality than the
Crude delivered shall be compensated with a higher volume. The Sender withdrawing a Crude with
higher quality than the Crude delivered shall compensate others Senders of better quality accepting
a lower volume. At any rate, the sum of debits and credits by CVC for all Senders shall be cero.

1. LOSSES

2. CRUDE OIL CONSUMPTION

3. VOLUMETRIC COMPENSATION FOR QUALITY - CVC

3.1 When Crude Oils are delivered to the Pipeline of different quality and from different Senders,
the result shall be a Crude Oil with different characteristics of quality and market value than the
Crude Oil delivered to the Pipeline by each of the Senders. Due to different qualities of Crude Oil
delivered to the Pipeline, some Senders shall withdraw Crude of higher value than the Oil delivered
while others shall withdraw Crude Oil with less value than the Oil delivered to the Pipeline.

40
<!-- page 61 -->
Operation and Transport Regulations Version 1 At any node of Entrance of the Pipeline where two or
more Crude Oil flows merge in order to be transported, a volumetric compensation for quality shall
be established on the resulting mix.

For purposes of the procedure hereof, the provisions in the Manual of the Transporter shall be
applied for measurements in the Pipeline.

The Transporter set out detailed procedures for the CVC following the guidelines established hereto.

For any month of Operation the corresponding quantity of Crude of each Sender shall be:

3.2 SAMPLING AND SYSTEM MEASUREMENT

3.3 CVC PROCEDURES

3.3.1 The Transporter shall administer the CVC process and the Senders may audit the process or
request reviews thereto as long as the Transporter is timely informed and a working plan is
coordinated between the parties.

3.3.2 The Transporter shall establish monthly the coefficients for adjustments of quality and sulfur
pursuant to the criteria established herein.

3.3.3 The CVC shall be settled in kind.

3.3.4 The Transporter shall make monthly adjustments to the corresponding volume of Crude to each
Sender, based on the coefficients of adjustment for quality.

(a) Reduced if such Sender of the Pipeline delivers Crude of lower quality than the average quality
of the mix,

(b) Increased if said Sender of the Pipeline delivers Crude of ah higher quality than the average
quality of the mix.

3.3.5 At the latest on the 15th day of the calendar month following the Operation, Senders shall
report to the Transporter the export prices, the API gravity and the sulfur content of its Crude for
the Month of Operation.

41
<!-- page 62 -->
Operation and Transport Regulations Version 1

The parties may jointly review:

The API gravity and the sulfur content on the data base of the Crude quality are representative of
the current qualities of Crude which is being delivered. The variability of the API gravity and
sulfur is within an allowed tolerance to be determined by the parties. Analyses of sulfur content
shall be conducted based on a schedule agreed by the parties after the beginning of the Fiscal Year.

By means of using the Crude Oil basket of reference the variation of price shall be determined
regarding the API grade and sulfur content for Crude Oil delivered. The method is based on the use
of the linear regression of prices of a Crude Oil basket of reference delivered in the coast of the
Gulf of The United States of America with API gravity and sulfur content.

3.3.6 Each month of Operation the Transporter shall measure the volumes delivered by the Senders and
shall determine the weighted average for the quality parameters of Crude Oils delivered.

3.3.7 The Transporter shall calculate the adjustments to the volume for each Sender and shall
determine the Crude volume that corresponds. No adjustment in the volume as a consequence of the CVC
shall affect the Transportation fee that a Sender shall Pay to the Transporter.

3.3.8 Senders acknowledge that adjustments to their Crude volumes to be withdrawn as a result of
these principles and procedures of the CVC may affect the volume of Crude Oil for a withdrawal
afterwards.

3.3.9 Senders are entitled to review the Transporter's calculations regarding the adjustments by CVC
and the due application of this procedure.

(a) The appropriateness of the Crude Oil reference basket regarding their terms of quality.

(b) The information on prices available to the public.

(c) The calculations of the coefficients and the volumes adjusted.

3.3.10 A data base for the API gravity shall be developed and sulfur content for Crude delivered
from reliable samples of laboratory of Crude Oil flows. The quality data of Crude Oil must comply
with the following criteria:

3.4 METHODOLOGY FOR CRUDE OIL VALUATION

42
<!-- page 63 -->
Operation and Transport Regulations Version 1

The basket of Crude Oil to be used shall always include a minimum of ten (10) Crude Oils. The basket
of reference for Crude Oil with prices and qualities historically recognized shall be used to
determine the coefficients of adjustment for API grade and sulfur content. The price information of
the basket shall be continuously available from sources open to the public for each Crude Oil of
reference. Prices reported used in the basket of Crude Oil of reference shall be obtained from
independent price information services recognized by the industry and shall come from real
Operations. This basket provides a range of qualities to develop the coefficients for the
regressions and therefore cover the flows that may be injected to the Pipeline. The initial basket
of Crude Oils to be used is the one established in table I of this procedure which may be reviewed
by common agreement between the Transporter and the Senders.

All price quotes of Crude Oil for a common location in the Coast of the Gulf of The United States of
America shall be adjusted. All prices of Crude Oil of reference shall be adjusted with respect to
the location and based on the availability of price information according to the following list:

Tables II to IV of this procedure show examples for calculation of basket Crude prices delivered in
the Gulf Coast.

To determine API gravity and sulfur coefficients linear regressions shall be run using the minimum
square method.

3.4.1 BASKET OF REFERENCE FOR CRUDE OIL

3.4.2 CALCULATION OF CRUDE OIL PRICES FOR THE BASKET IN THE COAST OF THE GULF

1. FOB quotation

- Transportation to the Coast of the Gulf of The United States of America is added using the
appropriate vessel size.

- Customs Tariffs, Oil pollution Liability Insurance, "Superfund" taxes are included and others as
appropriate.

2. CIF quotation

- Customs Tariffs, Oil pollution Liability Insurance, "Superfund" taxes are included and others as
appropriate.

3. Crude Oil delivered by the Pipeline

- Any Pipeline fee is added if necessary

- "Superfund" is included and other fees/tariffs as appropriate.

3.4.3 LINEAR REGRESSION FOR PRICES, GRAVITY AND SULFUR

43
<!-- page 64 -->
Operation and Transport Regulations Version 1 First the arithmetic average is calculated for prices
of the basket of Crude Oils of reference delivered in the Gulf coast for three months. The
cumulative average for three months shall be calculated at the closing of the settling month using
the prices for the settling month and the two (2) previous months prior to the settling month (See 1
in table V). To determine the API gravity coefficient, a linear regression analysis shall be
performed using the three months average of Crude prices from the basket calculated in the paragraph
above as the dependent variable. Likewise, the API gravity and sulfur content is used for each Crude
Oil of reference as the independent variables. The formula to be used makes a regression of the
price as a function of API gravity and sulfur simultaneously (See 2 in table V). To determine the
sulfur content a linear regression analysis shall be conducted using the three month average of
Crude prices from the basket calculated in the previous paragraph as the dependent variable.
Likewise, the API gravity and sulfur content is used for each Crude Oil of reference as the
independent variables. The formula to be used makes a regression of the price as a function of API
gravity and sulfur simultaneously (See 3 in table V). The results of the determination of the linear
relation between the price delivered and the API gravity and sulfur content may be stated in the
following lineal equation: Y = A1* X1+ B* X2 + b Pr = A1* APIR+ B*SR + b (1) Where: PR = Crude price
in $/Bbl A1 = API gravity coefficient determined through linear regression in $ by grade API-Bbl
APIR = Independent variable of API gravity B = Sulfur coefficient determined through linear
regression in $/%S-Bbl (negative number) SR = Independent variable of sulfur content b = Y
interception determined from the linear regression in $/Bbl.

After obtaining the API and sulfur coefficients, a volumetric adjustment shall be calculated to
conciliate differences between the quality of each Sender and the mix transported. The quantity to
be adjusted for each Sender is determined as is follows:

3.4.3 ADJSUTMENT OF VOLUMES FOR SENDERS (TABLE VI)

44
<!-- page 65 -->
Operation and Transport Regulations Version 1 The relative value of Crude Oil for each Sender shall
be calculated at the Point of Entrance. To obtain this, the API gravity of Crude from each Sender is
multiplied by the API coefficient obtained in the regression and then adding to this result, the
multiplication of the sulfur percentage of Crude from each Sender by the sulfur coefficient obtained
in the regression. See table VI in the column - Relative value of Crude $/BBL The relative value of
the mix transported is calculated with the data of the relative value of each Crude Oil from all
Senders. This value is obtained calculating the weighted average of the relative values of each
Crude Oil multiplied by the volume delivered by the Sender. (See (1) table VI After this, the
average export price of the mix must be obtained with the data from exports of all Senders in the
month in which the adjustments are made. (See (2) in table VI To obtain the calculated price, the
difference between the relative value of each Crude Oil and the relative value calculated for mix
(1) must be obtained, and add this difference to the average export price of the mix. Then, the
quantity delivered by the Sender is multiplied by its calculated price and this product is divided
between the average export price of the mix, obtaining as a result the total adjusted volume by
Sender. The volume to be adjusted shall be the difference between the total adjusted volume by
Sender and the volume delivered by a Sender to the Pipeline. The sum of volumes to be adjusted from
all Senders must be cero. The Transporter shall run the linear regression using a spreadsheet such
as Excel. The Transporter shall document the statistical results of the linear regression so that
the information can be provided to any Sender upon request.

45
<!-- page 66 -->
Operation and Transport Regulations Version 1 Table I Reference Crude Basket

Table II Illegible Information Table III Illegible Information Table IV Illegible Information

Degree Origin API, ° Sulfur% Source for Pricing BBL/MT

Arab Light Saudi Arabia 33.2 1.9 Argus, Formula 7.34 Arab Medium Saudi Arabia 30.5 2.4 Argus,
Formula 7.22 Arab Heavy Saudi Arabia 27.6 2.8 Argus, Formula 7.09 Castilla Colombia 18.8 2.0 Platts
6.70 LLS US Gulf Coast 36.2 0.3 Argus 7.47 Mars US Gulf Coast 28.0 2.1 Argus 7.15 Maya Mexico 21.1
3.5 Argus 6.80 Napo Ecuador 18.0 2.3 Platts 6.66 East Ecuador 24.0 1.2 Platts 6.93 Vasconia Colombia
26.5 0.9 Platts 7.04

46
<!-- page 67 -->
Operation and Transport Regulations Version 1 Table V Linear regression of prices, API gravity and
sulfur - August 2010 Closing Example

Table VI Adjustments of volumes for senders - August 2010 example

API Sulfur JUN-2010 JUL-2010 AUG-2010 Average of 3 previous months (1) Arab Light 33.2 1.9 77.60
76.26 76.29 76.72 Arab Medium 30.5 2.4 75.84 74.59 74.62 75.02 Arab Heavy 27.6 2.8 74.34 73.32 73.25
73.64 Castilla 18.8 2.0 69.84 69.20 69.20 69.41 LLS 36.2 0.3 78.94 78.84 79.79 79.19 Mars 28.9 2.1
74.63 74.18 74.35 74.39 Maya 21.1 3.5 66.27 67.47 68.65 67.46 Napo 18.0 2.3 69.56 69.02 69.08 69.22
East 24.0 1.2 72.12 71.93 72.15 72.07 Vasconia 26.5 0.9 74.93 75.89 75.29 75.37

(2) API, $/API-BBL Coefficient 0,495 (3) Sulfur, $%S-BBL (1,191)

Bank of Quality Coefficients API Coefficient (0.50) Sulfur Coefficient (1.19)

Sender Volume injected by sender MBBL/mo

API in the injection point

Sulfur in the injection point

Relative value of the crude S$/BBL

Calculated Price $/BBL

Total Volume adjusted by sender MBBL/mo

Volume to adjust MBBL/mo

Sender A 900 31 0.5 14.75 77.97 935 36 Sender B 1,200 26 1.0 11.69 74.90 1,195 (2) Sender C 600 20
2.0 7.53 70.74 566 (34) Total 2,700 2,700 -

(1) Relative value calculated for mix 11.79 (2) Average price of exportation of mix, August 2012
75.00

47
<!-- page 68 -->
Operation and Transport Regulations Version 1 ANNEX 2: DEFINITION OF STANDARD BARRELS PER SYSTEM

48
<!-- page 69 -->
Operation and Transport Regulations Version 1 ANNEX 3: DESCRIPTION OF THE SYSTEMS See File Annex 3
attached. Description of the Systems.

49
<!-- page 70 -->
Operation and Transport Regulations Version 1 ANNEX 4: MINIMUM SPECIFICATIONS OF QUALITY PER SYSTEM

50
<!-- page 71 -->
Operation and Transport Regulations Version 1

*, **, *** : for Crude

51
<!-- page 72 -->
ANNEX 2 ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008
<!-- page 73 -->
TABLE OF CONTENTS

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

1. OBJECTIVE 2. GLOSSARY 3. GENERAL CONDITIONS 3.1Commercial Principles for Credit and Receivables
Management 3.2Analysis of Credit Quality of the Client 3.3Internal Rating by ECOPETROL 3.3.1
Guidelines for the Analysis of the Client 3.3.2 Modalities in which Payments can be Made 3.3.3
Clients with Acceptable Guarantee Created for Purchase 3.3.4 Clients of Leasing 3.4Process for
Approval of a Line of Credit by ECOPETROL 3.4.1 Credit application 3.4.2 Determination of the Credit
Quality of the Client 3.4.3 Officers Authorized for the Analysis and Consideration of Lines of
Credit 3.4.4 Amounts above the Ceiling Approved in Lines of Credit 3.5Acceptable Guarantees
3.6Follow-up 3.7Managing the Relation with the Client that Buys on Credit 3.7.1 Sale Prices and
Terms 3.7.2 Claims and Discrepancies in Invoicing 3.8Collection of Receivables 3.9Guarantees
Delivery and Custody 3.10Late Interests 3.11Collections Management 3.11.1 Starting Legal Actions to
Collect Overdue Balances 3.11.2 Modifications in the Long Term 3.12Restructuring by General
Agreements 3.13Provision for Accounts Receivables 3.14Receivables Write-offs

1
<!-- page 74 -->
To define uniform guidelines for the management of service Receivables from ECOPETROL in order to
mitigate the inherent risks in the sale of said services.

Credit Lines: This is a debt facility granted by ECOPETROL to a specific client. Approval of a
credit line is an autonomous decision by ECOPETROL based on objective criteria such as the credit
history of the client, its historical behavior on payments or the type of client according to the
Internal Classification Chart. ECOPETROL at its sole judgment may suspend any credit line at any
time without any legal or formal requirement to be fulfilled before the client. Acceptable
Guarantees: Payment mechanisms that provide collateral for payment issued by financial entities
(financial guarantees), securities or instruments providing immediate liquidity for their
realization. See Guidelines for the Management of Acceptable Guarantees ECP-UTE-G-006. Other
Services: includes all those provided to third parties such as provision of electricity, water,
information network, leasing of tangible and intangible assets, machinery and tools among others.
Receivables Risk: Associated to the risk of credit1, the Receivables risk concerning this document
is defined as the potential inability to pay from clients requesting any type of services from
ECOPETROL. Services: Provision or execution that satisfies some necessity with a specific purpose.
ECOPETROL provides industrial, technical, technological, research and transportation services among
others. Research Services: Research services applied to projects generally internal, with the
Business Units. Transportation Services: transportation services different from those defined by the
Vice-presidency of supply and marketing (VSM) referred to transportation services of products
delivered by pipeline. Industrial Services: provision offering solutions given the infrastructure
facilities of ECOPETROL, part of industrial services are the following: Unloading Services: Services
provided to exploration companies which must transport the oil produced in truck- by land from the
production wells to a point in the pipeline system.

1 The risk of credit is the possible loss assumed by an economic agent as a result of default in
contractual obligations regarding the counterparties involved.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

1. OBJECTIVE

2. GLOSSARY

2
<!-- page 75 -->
Filling Services: Services provided to client companies who, in order to take the refined products
purchased at the plant, need to be connected to the product loading infrastructure in truck-tankers,
identified as filling in. Storage Services: services provided to client companies for storage of
products owed by third parties in tanks owed by ECOPETROL. Port Services: Use services of sea
terminal facilities and necessary operations for a ship to carry out its task of product loading and
unloading. Technical Services: laboratory studies or tests, sample analyses, industrial laboratory,
technical assistance and gas compression (agreements with gas transportation companies to provide
gas compression services to gas going through the gas pipeline). Technological Services: design and
development of equipment, machinery and specialized products.

This document applies to those cases in which ECOPETROL acts as a seller or service provider and as
a supplement to those contracts already signed and the regulations in force, notwithstanding
anything to the contrary. This does not include anything in connection with transportation services
associated to the commercialization of products derived from oil, propane gas and crude oils whose
policy is defined by the Vice- presidency of supply and marketing in the reference documents for
credit to clients.

Throughout all stages referred to the analyses, consideration of terms and commercial conditions,
approval of credit facilities and client's follow-up, good faith, ethics, transparency, economy,
responsibility, equity, planning, and customer service criteria shall prevail as described hereunder
(those terms not defined in this numeral shall be given a meaning according to the law, otherwise
they will have their natural and obvious meaning). Ethics: all officers from ECOPETROL shall avoid
any conflict between their personal interests and the interests from ECOPETROL when dealing with
purchasers or any other person - natural or legal, national or foreign - who is making, or intends
to do Business with ECOPETROL order with companies in which ECOPETROL has an interest directly or
indirectly. In case of any conflict of interests, inabilities for incompatibilities, the officer
from ECOPETROL shall refrain from participating in any manner in the respective act.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

3. GENERAL CONDITIONS.

3.1 Commercial Principles for Credit and Receivables Management.

3
<!-- page 76 -->
Transparency: decisions shall be made, based on objective criteria and clear and known rules.
Equity: all necessary measures to keep a healthy balance with the client, regarding terms and
conditions of commercial, technical, economic and financial character shall be adopted in all
transactions. Planning: all commercial and credit procedures shall correspond to a careful planning
to contribute in an efficient manner to fulfill the mission and achievement of ECOPETROL's
objectives. Economy: all resources used in the process of approving and managing Businesses shall be
administered with a healthy criterion of austerity in means, time and expenses. Customer Service:
the rules set out in this document shall be applied by officers as a vehicle to expedite decisions
and to conduct all commercial and credit procedures with efficiency and efficacy.

Considering the risks ECOPETROL is exposed to, ECOPETROL shall only negotiate with natural or legal
persons of whom ECOPETROL has knowledge about their history in the market and their condition as
users of services, consumers or traders of products in the oil sector. The basic client's
information shall provide answers to the questions asked hereunder and it is the responsibility of
the Business Unit providing the service, which handles the relation with the client, to have clarity
on the answers to the following questions:

3.3.1 Guidelines for the Analysis of the Client For an appropriate decision-making it is required to
have knowledge of the client and its activities.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

3.2 Analysis of Credit Quality of the Client

· Who is the client? · What reputation does it have in the market? · What has been its history with
ECOPETROL? · What type of Business does it make? · Does it have capacity to meet its commitments?

3.3 Internal Rating by ECOPETROL

4
<!-- page 77 -->
In addition, it is mandatory to comply with the Prevention Manual for assets laundering. In the
client interested in buying to ECOPETROL any service, shall conduct through the Business Unit
providing this service the registration process in the client's master database of ECOPETROL. The
respective manager and/or director of the Business Unit must record the validation indicating that
validation has been made in the restrictive listings on the client

3.3.2 Modalities in which payments can be made Payment commitments with ECOPETROL can be based on:

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

· Any client applying for a line of credit must be subject to a preapproval from the Business Unit
providing the service or the division of ECOPETROL in charge of conducting the credit analysis. ·
The risk rating does not guarantee the approval of credit of confidence; ECOPETROL reserves the
right of whether or not to approve such type of credit. · All guarantees presented must be adjusted
in their content to the stipulations of ECOPETROL, and must be issued by an entity equally accepted
by the company. · All documents in connection with the credit application must remain in ECOPETROL
's files, and as the case may be, those documents were the line of credit is awarded. · In case of
default by a client of any of the obligations undertaken with ECOPETROL, the Company reserves the
right to whether or not accept a restructuring of the debt or to start a legal proceeding. ·
Annually, or with less frequency depending on market conditions, an officer appointed by the
Business Unit providing the service must conduct a follow-up, both to the credit quality as well as
the line of credit assigned to each client, updating the risk rate before a Risk Rating Agency or by
an Agency of Research Service, Collection and Processing of Credit and Company Information approved
and accepted by ECOPETROL.

· Payments in advance · Through credits of confidence · By means of financial instruments of payment
such as banking acceptance or commercial letter of credit.

5
<!-- page 78 -->
The determination of the type of client is the responsibility of the Business Unit providing the
service considering objective criteria such as its payment behavior and the current relation with
ECOPETROL, in addition to the financial assessment conducted by a Risk Rating Agency. Payments in
Advance: ECOPETROL may accept payments in advance from clients having liquidity and/or who would
like to benefit from discounts that ECOPETROL may offer for the purchasing of specific services.
Notwithstanding, each management office shall set out the discount policy for its line of services.
Payment in advance shall be requested to those who cannot offer any payment support through
financial entities or offer collateral at satisfaction. Credits of Confidence: These are credits
granted by ECOPETROL to clients with well recognized commercial and/or industrial history, or to
clients that, even though they are new have proved financial strength in the oil sector and its
derivatives, biofuels and energy products with an impeccable payment history, are classified in
category 1 of internal rating Table 1 of these guidelines and execute promissory notes with letter
or instructions in favor of ECOPETROL . Impeccable payment history is understood as the client who
has timely paid its obligations with ECOPETROL, or with any other agent with whom it as obligations
within the payment terms set out in the bills, has acknowledged and paid all late interests
resulting from any possible delays in payments, and no payment instrument has been made effective
from any agent with whom it has obligations to support for its purchases. A client shall lose access
to credits of confidence when there is a default in a period of one calendar year in the payment of
its commitments with ECOPETROL under the terms set out in the previous paragraph or when its rating
falls below the Superior category. Default shall be understood as the act of enforcing the guarantee
or promissory note supporting the obligations undertaken with ECOPETROL, or when in a calendar year
a notice has been delivered to the insurance company or banking entity for the execution of the
guarantee, even if the client is in good standing on the date before making the policy effective.
Without prejudice of the foregoing, ECOPETROL reserves the right to whether or not approve a credit
of confidence to a client, even if said client has obtained the highest rating based on Table 1 of
these guidelines.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

6
<!-- page 79 -->
Likewise, a client of confidence may use, in addition to the credit of confidence, other financial
instruments for payment and/or payment in cash. Payment by financial instruments: These are
instruments for payment in cash or through credit in favor of ECOPETROL, issued by a financial
entity on behalf of the client and limited to a particular transaction as indicated in the
Guidelines for the Administration of Acceptable Guarantees ECP-UTE-G-006. 3.3.3 Clients with
Acceptable Guarantee Created for the Purchase of Products. For clients with a current line of credit
with ECOPETROL for the purchase of products, the Business Unit providing the service shall request
to the corresponding commercialization management to review with the legal department whether or not
the guarantee provided covers the provision of the service, and if so, generate a memorandum to the
Coordination of Receivables indicating the distribution of the line of credit for the sale of
product and the sale of services. In any case, the arithmetic sum of the line of credit for the
product and the line of service shall not exceed the total value of the guarantee provided by the
client. 3.3.4 Clients of Leasing For the clients of leasing, the leasing contract entered into is
writ of execution, the Head of the Unit for Real Estate Management must request through a memorandum
the line of credit to the Coordination of Receivables and Collections indicating the contract
number, starting date, termination date, the amount of the leasing installment, and the value of the
line of credit applied for, said memorandum shall indicate that the contract has approval from the
legal area or attach approval from the legal office advising the Business Unit. 3.4 Process for
Approval of a Line of Credit by ECOPETROL The process for approving a line of credit by ECOPETROL is
explained as follows: 3.4.1 Credit Application Any client interested in purchasing through credit
any product or service of ECOPETROL, shall carry out with the Business Unit providing the service an
application for a line of credit and the client will be informed of the result of the Decision. If
the decision is not approved, the client shall be informed of the reasons by which the same was not
approved. Decisions in this sense shall be adopted based on objective criteria regarding terms and
conditions of commercial, technical, economic and financial character and within the frame of
current legal regulations.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

7
<!-- page 80 -->
3.4.2 Determination of the Credit Quality of the Client The officer appointed by the Business Unit
providing the service shall examine the content of the application form and request to the client or
to a Risk Rating Agency or an Agency of Research Services, Collection and Processing of Credit and
Company information, the Rating Certificate2 in order to have the rating given by such Agencies.
This Rating Certificate shall be attached to the application form if it is a new client or to the
client's file in the central archives of ECOPETROL if it is a client already registered wishing to
have a direct credit with ECOPETROL . Based on the information described above, you'll consider
appointed by the Business Unit providing the service shall examine and classify the client in the
Table of Internal Rating for Clients of Services from ECOPETROL Table 1, taking as a basis (when
there is more than one rating) the lowest rating given by a Risk Rating Agency or by Agencies
Specialized in Credit. If the rating of obtained classifies the client as a superior client, at the
latest 10 days after having the complete information from the client the officer appointed by the
Business Unit providing the service shall fill out the application form for a line of credit for the
approval of his/her Manager and or respective Director3 in accordance with the template that appears
in form ECP-UTE-005 Application Line of Credit Services. With the purpose to classify ECOPETROL 's
clients who wish to buy through credit after this document is in force, such clients shall be
classified through the application of an internal general risk rating according to the methodology
presented hereunder. Such classification shall be conducted and reviewed by each of the officers
appointed by the Business Unit providing the service annually or from time to time but at least once
a year or when the economic or market conditions or the financial situation of the company requires
so. The position of a client within the internal rating table shall be in accordance to table 1,
whose categories have their equivalence with the risk rating given by rating agencies or by agencies
specialized in credit analysis. The foregoing shall not apply to: (i) bodies and state entities at
different levels (central and decentralized) with whom ECOPETROL subscribes contracts for the sale
of products and/or services provided there is a risk assessment of Receivables for the respective
entity duly authorized and/or (ii) companies associated with ECOPETROL in oil production fields,
associated through collaboration, participation, strategic alliances and joint venture contracts,
these companies shall subscribe a promissory note with a letter of instructions to ensure their
payment obligations, however, in this case the Manager and/or Director of the Business Unit
providing the service shall assess the pertinence of requesting an acceptable guarantee (policy,
bank collateral, etc.) to ensure the payment obligations in lieu of the promissory note with letter
of instructions.

2 Risk Rating Agency or by Agencies of Research Services, Collection and Processing of Credit and
Company Information approved by the Vice- presidency of corporate finance of ECOPETROL . 3 Managers
and Directors shall have 10 calendar days to make a decision. Reviews of lines of credit shall be
approved for up to 12 months.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

8
<!-- page 81 -->
Table 1 INTERNAL RISK RATING FOR CLIENTS OF SERVICES OF ECOPETROL 4

4 Comments and considerations included by the risk rating agency in its report about a company are
understood as already included in the rating given by the risk rating agency, in that sense the same
shall not affect again either in a positive or negative manner the rating issued and shall not be
taken into account in the analysis conducted by Management at the time of considering, approving or
rejecting credit applications. 5 New clients with rating risks equivalent to superior level (1) and
without purchasing records with ECOPETROL may be considered as clients of confidence with previous
approval from the vice president of the Business Unit providing the service and the line of credit
shall be established by said officer.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

Rating Definition Description Equivalence (Credit Risk in the Short Term 1 Superior Wide and strong
capacity to meet commitments. Minimum risk. May be defined as a client of trust. Sufficient
requesting a promissory note with letter of instructions5. For larger lines of credit the respective
manager and/ or director may increase the lines up to 100% of the lines approved with previous
authorization from the corresponding vice-president of the Business Unit providing the service. The
line of credit conservative and liberal recommended by risk rating agencies shall be understood as
an indication and does not oblige ECOPETROL with the client, or the respective manager to use this
as a ceiling for the approval of the line of credit at the time of defining a line of credit for a
client of confidence.

Duff / Phelps (D&P): DP to DP1 BRC Investors Services (BRC): BRC 1 to BRC 1 Byington: 1 to 2 BPR
Asociados (BPR): A (1.00-1.50) Bureau Veritas: 1

2 Average Superior Sufficient capacity to fulfill commitments. Low risk. D&P: DP1- BRC: BRC 2
Byington: 2.1 to 2.9 BPR: B(1.51-2.00) Bureau Veritas:2

9
<!-- page 82 -->
Clients whose internal rating is level 1 (superior) according to the table above, in order to have a
line of credit shall not offer acceptable guarantees issued by third parties in favor of ECOPETROL
as indicated in Table 1. Instead, they shall subscribe a promissory note with a letter of
instructions as support for their payment obligations. In any case, it is understood that clients of
confidence shall only be limited to a number of recognized companies.

6 Byington (N) corresponds to companies recently created.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

3 Average Acceptable capacity to fulfill commitments. Medium risk. D&P: DP2 BRC: BRC 2 Byington: 3
to 3.4 Byington (N)6: 3 to 3.4 BPR: C(2.01-2.50) Bureau Veritas:3 4 Average Inferior Capacity to
fulfill commitments; uncertain performance. High risk. D&P: DP3 BRC: BRC 3 Byington: 3.5 to 4.0
Byington (N): 2.1 to 3.0 BPR: D(2.51-2.75) Bureau Veritas:4 5 Low Quality Uncertainty or inability
to fulfill commitments. High risk. D&P: DP4 or below BRC: BRC 4 or below Byington: 4.1 to 5.0
Byington (N): 3.1 to 4.5 BPR: D(2.76-3.00) Bureau Veritas:5

10
<!-- page 83 -->
Those clients offering acceptable guarantees to support their purchases, shall not require a risk
rating from any risk rating agency acknowledged and accept it by ECOPETROL because the risk is
assumed by the guarantor. The contents and the type of guarantee shall be fully adjusted to the
minimum characteristics required by ECOPETROL, and the same shall be issued by entities accepted by
the company through the listing of acceptable companies for such purpose issued by the
vice-presidency of corporate finance. Clients classified in level 5 shall be those without a rating
or analysis by specialized agencies in credit analysis. Those clients shall require acceptable
guarantees contained in the guidelines for administration of acceptable guarantees ECP-UTE-G-006.
ECOPETROL reserves the right not to sell through credit to any client, regardless of whether or not
it is in capacity to provide guarantees or securities, and therefore the amount of the purchases
shall be a cash or in advance. A client classified as Superior may make purchases in cash and/or
complement the line of credit awarded with acceptable guarantees in favor of ECOPETROL. For
guarantees in US dollars, in case the guarantee is made effective, the payment shall be at the
representative market exchange rate (TRM) valid on the day of payment of the guarantee. 3.4.3
Officers Authorized for the Analysis and Consideration of Lines of Credit. The officer appointed by
the Business Unit providing the service shall be in contact and permanent interaction with the
client, shall determine the credit quality of the same through the report from the risk rating
company, shall process the application and review from time to time the lines of credit, and shall
provide support to the vice-presidency of corporate finance in the handling of Receivables. Upon
classification of the client in the internal rating table of ECOPETROL, and if and any station of
the maximum they were a specific client. is no information that prevents the processing of the
application or that would imply any risk in the performance of the obligations that the client may
undertake with ECOPETROL, the approval of the client shall be established by filling out the form,
Application for a Line of Credit contained in Form ECP-UTE-F-005 Application for a Line of Credit
for Services. Each manager and/or director shall have the responsibility to consider, approve or
reject in a justified manner, all credit applications filled out by the clients, which should be
recorded in the forms defined for such purpose, or otherwise in the electronic mails which shall be
equally valid as the other forms and shall be printed and delivered to the central archives of
ECOPETROL to the file opened for each client.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

11
<!-- page 84 -->
The lines of credit recommended by the risk rating company and/or approved are strictly of internal
character and an indication of the maximum debt of a specific client. 3.4.4 Amounts above the
Ceilings Approved in Lines of Credit When a client has reached the maximum debt approved, within the
term of the validity of the lines of credit and temporality requires7 from additional services not
exceeding beyond 100% the amount of the line of credit, the respective manager and/or director may
approve at his sole discretion this higher debt, provided however, that the same are covered with an
extension of acceptable guarantees originally issued to have access to the credit facility.

7 For a maximum period of three months, renewable with previous approval from the vice president of
the corresponding Business area 8 Enforced and executed at the latest 30 days after default, and
only in the event of a pledge on CDs.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

3.5 Acceptable Guarantees.

· ECOPETROL shall not make any sales on credit to clients not providing acceptable guarantees except
for those clients with internal rating Superior (clients of confidence) or who have been considered
in numeral 3.4.2 of this guideline.

· For the provision of services only guarantees offering endorsement of payment by financial
entities will (financial guarantees) shall only be accepted, or those representing securities or
instruments that guarantee immediate liquidity when realized.8

· The coverage of the guarantees or the amount of financial instruments for payment must be
sufficient to cover eventual increases in the price of services.

· Guarantees in foreign currencies may be accepted (dollars of the United States of America or any
other currency) pursuant to the current foreign exchange regulations. If guarantees are in a foreign
currency are made effective, they shall be registered in the central bank in order to convert them
in the equivalent of the market representative exchange rate from peso with respect to the dollar on
the day of payment of the guarantee. Guarantees in currencies different than the US dollar, in order
to be accepted, shall require approval from the vice presidency of corporate finance.

· Only guarantees established in the guide for administration of acceptable guarantees ECP-UTE-G-006
shall be acceptable.

· Guarantees received by the respective management offices shall be previously reviewed and approved
by the legal office advising on the same. The standardization and updating of the respective forms
shall be under the responsibility of the legal vice presidency.

12
<!-- page 85 -->
To the extent that the updating of the rating provided by the risk rating agencies or by agencies
specialized in credit implies a higher risk for ECOPETROL , or if default in the payments by clients
occur, the conditions of the relation with the clients shall be reviewed, in particular, those
having to do with the requirement or improvement of the specific guarantees. The same exercise shall
be conducted through the vice presidency of corporate finance with financial entities guaranteeing
obligations in favor of ECOPETROL . Particular attention is given to those clients classified in
categories of the internal rating table not requiring any specific guarantee and the superior
clients. Those clients shall be monitored through the updating of the ratings given by specialized
agencies in credit or risk rating agencies. The period for obtaining such reports shall be a least
annually. Based on the results of the updated information, the vice presidency of corporate finance
shall adjust the internal rating of the client and shall review the payment conditions originally
approved. The updating of the ratings for clients shall not be conducted before the month of March
each year because the financial statements of the previous year have not yet been disclosed before
the respective entities of vigilance and control, and from which official data for studies are
taken. Therefore, if the study mentioned falls during the first three months of the year, the
current rating shall be applied until the last day of the month of March of the current year.
Notwithstanding the foregoing, if the promissory note and that was the letter of instructions has
completed one year, said documents must be updated for this period and the subsequent ratification
or denial of the credit granted by ECOPETROL.

In the commercialization of services, ECOPETROL must observe the norms, mercantile and credit
customs, collect Receivables in a timely manner, assess any Receivables in default from time to
time, and record in its financial statements any provisions and write-offs as they may apply,
pursuant to the provisions in the document hereof.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

· Acceptance of any other type of guarantee established in the Contracting Manual shall require
approval from the respective manager and/or director with previous approval from the legal vice
presidency.

3.6 Follow-up.

3.7 Managing the Relation with the Client that Buys on Credit.

13
<!-- page 86 -->
Each sale of services, depending on each specific case, must be instrumented in writing either
through a buy-sell contract, a supply contract, or commercial offer, or registered in an invoice or
an equivalent in document. Each invoice shall detail the value of services and taxes, pursuant to
the law and applicable regulations. Invoicing prices are those current prices on the date of sale or
provision of services and may change without previous is notice. Commercial invoices shall be issued
in two original counterparts of the same content with writ of execution9. One of them for the client
and the other duly signed by the client in signal of acceptance destined to ECOPETROL. This copy
shall remain with the appropriate custody in the files of ECOPETROL for collection and eventual
discount of the instrument in the secondary market.

These correspond to the policies already designed for each Business Unit providing the service
regarding sale prices and terms, which must be in accordance with those set out by the presidency of
the company and the manual of delegations - MAD.

In those cases in which there may be claims by clients due to differences in price and/or terms duly
justified, under the judgment of the Business Units in charge of handling the client it must be the
determined the viability of the claim and adopt the pertinent decision in a reasonable period of
time in accordance with the complexity of the discrepancy. To resolve any discrepancies, each of the
parties shall deliver to the other, a copy of the documents supporting the invoice and the claim.
The review process of any claims shall be in accordance with the provisions in each contract for the
provision of services entered into between the parties. Any disagreement regarding any invoice does
not exempt the buyer from its obligations to pay the non-disputed portion of said invoice or any
other invoice. If the claim is resolved favor of ECOPETROL, having the client omitted payments on
services rendered and invoiced by ECOPETROL, the buyer is obliged to pay a sanction for default on
the amounts not paid within the term established, at the highest late interest rate established by
the Superintendence of Finance of Colombia or whoever replaces it. If the buyer has made payments in
excess, ECOPETROL shall credit the same to the next due date or make the corresponding reimbursement
after clarification of the amount under discrepancy.

9 A carbon copy being valid

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

3.7.1 Sale Prices and Terms

3.7.2 Claims and Discrepancies in Invoicing

14
<!-- page 87 -->
The Business Unit providing the service with the support of the Coordination for Receivables and
Collections, shall control any payments for Receivables as well as the actions are collections
derived from the sale or provision of services and will be responsible for collecting any late
interests (as they may apply) and any verification of accounts with the client.

With previous approval from the legal area and after the guarantees have been reviewed and accepted
by the commercialization areas, they shall be delivered for custody to the Coordination of
Receivables. The custody and collection of guarantees is responsibility of the ordination of
Receivables and collections, and all security measures shall be taken to keep guarantees in a safe
place. Before a guarantee is received for custody, the Coordination of Receivables shalt make sure
that it has the approval from the legal area and the dates of validity. In addition, the
Coordination for Receivables shall be responsible for the integrity of the documents and shall adopt
measures to prevent access to places established for custody to non-authorized personnel. In the
event that a client fails to perform the requirements from Receivables, the collection of the
guarantee shall be made within the terms established for such purpose and each of the reported to
the respective Business Unit providing the service to discontinue the provision of such services. In
those cases in which it applies, the guarantees once they have been reviewed and approved by the
legal area assigned to the Business Units providing the service and accepted by the respective
management office, they shall be delivered for custody to each of the managers and/or directors
through a memorandum, to the Coordination of Receivables and collections from the Treasury Unit
responsible for the corresponding record in SAP and of its collection if necessary. ECOPETROL
through the Business Unit providing the service shall immunity suspend any credit or cash sales, to
clients to whom the execution of guarantees has started until a certificate of good standing is
received from the Coordination are Receivables and a new guarantee acceptable to ECOPETROL is
presented. The Coordination of Receivables and collections shall adopt all security measures to keep
the guarantees in a safe place. The Coordination of Receivables and collections of the Treasury Unit
shall update and activate in an individual manner in SAP each guarantee for the corresponding area
of credit control; indicating "the limit authorized" which becomes a rotatory limit in pesos
authorized for the provision of services and establishing that period of time in which the limit of
credit shall be covered with the guarantee, taking into account the term of the credit given to the
client for the provision of the service (5, 15 or 30 days).

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

3.8 Collection of Receivables

3.9 Guarantees Delivery and Custody

15
<!-- page 88 -->
The payment of Receivables by clients after the due date generates a late interest as a sanction.
Late interests are a applicable without exception to all kinds are Receivables handled by ECOPETROL.
Late interests shall be calculated on any overdue balances and in proportion to the time lapsed from
the date in which the payment should have been made until that date in which it is actually made.
The record of these interests shall be under the responsibility of the Coordination of Receivables
and collections; control and collection activities shall be the responsibility of the Business Unit
providing the service, which may check these charges through consultations to the account statement
of the client in the SAP integrated information system. Any payment made by a client in accordance
with the provisions in the Colombian Civil Code in its article 1653, except as otherwise agreed,
when principal and interests are owed, payment shall apply first to interests and then to principal.
Late interests are not forgivable, the General Controller of the country has issued several opinions
denying this prerogative based on the constitutional principle by which public servants can only do
whatever the law and the Constitution allows. Currently there is no regulation that allows
cancellation of interests by public entities such as ECOPETROL. ECOPETROL in each of its invoices
shall indicate that the interest rate to be charged as late interest for the payment is the highest
monthly rate allowed by the Superintendence of Finance or whoever replaces it (the Treasury Unit
shall communicate the late interest rate to be applied for each period). For invoices or bills
issued in US dollars an interest rate in dollars in equivalent to the Prime rate +2 percentage
points shall be applied (Prime +2%). The resulting amounts shall be converted into pesos at the
market representative exchange rate (TRM) valid on the date of payment. If the due date of the
invoice falls on Saturday, Sunday or in a holiday, the payment may be made on the following Business
day and said payment shall not generate any late interest. If a client pays after the first Business
day, the calculation for late interest shall be made from the due date of the invoice The charging
of interests shall be made through a bill addressed to the client, which shall contain a Receivables
statement on which interests are calculated.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

3.10 Late Interests

16
<!-- page 89 -->
When an invoice or bill is not collected within the due dates or payment has been made partially,
the collection action shall start immediately by the Business Units providing the service and the
Coordination of Receivables and collections. The Coordination of Receivables and collections shall
proceed to make effective the sources of payment and guarantees, in case of clients covered by
financial collateral who have not made full or partial payments of all their obligations represented
in the sale invoices within the due dates in accordance with the terms established in said invoices,
with the support of their respective Business Unit and legal counsel. For such purposes, the loss
shall be reported to the insurance company (in case there is a policy covering the default), the
documentation required shall be presented before the banking entities (bank guarantees, bank
acceptances or letters of credit), the client shall be contacted in the case of a promissory note
and in the case of guarantees, they shall be made effective before the corresponding entity in order
to collect any overdue amounts together with late interests.

If a client fails to make a payment within the normal process of collection and all instances have
been used before going to court without any positive results, in a peremptory term of 90 days, the
Business Units providing the service must request to the respective legal advising Unit to carry out
collection actions pursuant to the provisions in the applicable regulations. For such purpose, the
respective Business must prepare and deliver the following documentation to the legal area:

In the event that under special circumstances a client is late in meeting its obligations with
ECOPETROL and does not have immediate payment capacity, upon request, the Business Units providing
the service may request to the Head of the Treasury Unit of ECOPETROL, attaching the commercial and
legal analysis of the client, an authorization for the extension of the term of the credit, and this
financing shall not cause an impairment of the guarantee in the force in favor of ECOPETROL.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

3.11 Collections Management

3.11.1 Starting Legal Actions to Collect Overdue Balances

- A request memorandum indicating actions undertaken by the Business Unit providing the service and
the Coordination of Receivables and collections to obtain recovery of money owed.

- Documents supporting the credit in favor of ECOPETROL (invoices or promissory notes).

- Copies of all correspondence held with the client.

- Copy of the contract or certificate for the provision of services.

3.11.2 Modifications in the Long Term.

17
<!-- page 90 -->
Without prejudice of the foregoing, ECOPETROL reserves the right to request an acceptable guarantee
that allows covering a higher risk for the extension of the term for the payment. The interest rate
for the refinancing term shall be in accordance with the conditions of the financial market. Clients
under legal proceedings to recover any amounts in favor of the company may be eligible for
refinancing when lacking any property or liquid guarantees executable in favor of ECOPETROL. In the
case of individual agreements, the interest rate for the refinancing period must be associated with
the opportunity cost of ECOPETROL as indicated by the Treasury Unit of the vice presidency of
corporate finance. The amortization of the debt in default shall be applied first, to sanctions and
late interests, second, to current interests and third, to the principal. The mentioned option for
refinancing if adopted by ECOPETROL, must offer better expected results than those continuing under
the legal proceeding or execution of guarantees. Any refinancing must be subject to the approval of
the Head of the Treasury Unit with the previous commercial, financial and legal analysis.

ECOPETROL may participate in payment agreements of clients with their creditors, under modalities
aimed to ensure the maximum collection of their Receivables in terms of present value as indicated
hereunder: Restructuring Agreement under Law 550 or reorganization agreements under Law 1116 of 2006
(company insolvency). Regarding the guarantees in the proceedings to prevent bankruptcy, creditors
still governed under Law 550/1999 (that is, territorial entities, decentralized entities and state
universities at the national or territorial level) have the power to inform the promoter within the
following ten (10) days after starting the negotiation, if the decision is only to make the
guarantee effective without waving their right to obtain from the debtor the payment of the
obligation under default pursuant to the paragraph of article 14 of said Law. In those cases,
ECOPETROL through the vice presidency of corporate finance and the respective manager and/or
director shall inform the Promoter if the guarantee will be made effective. Furthermore, Law 1116 of
2006 did not include the provision of the foregoing paragraph, instead, in article 43 the Law
regulated the issue of real estate guarantees within the process of insolvency, and therefore the
power to make them effective was suspended, save by authorization of all creditors to wave said
limitation. Said decision shall be made with an absolute majority and included within the Agreement.
Thus, the creditor may present in the proceedings, together with its debt, the guarantee covering it
and a request to make it effective, or else wait the development of the proceeding, and if
terminated by breaching, the enforceability will be then "reactivated".

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

3.12 Restructuring by General Agreements.

18
<!-- page 91 -->
Provision of services to clients with whom global payment agreements have been executed or under Law
550/99 or Law 1116/06 shall only be made under the modality of payment in advance. Interests in
favor of ECOPETROL derived from individual refinancing processes or restructurings cannot be
cancelled. Presently there are no regulations that allow the cancellation of interests by public
entities such as ECOPETROL. All refinancing shall be subject to approval by the respective manager
and/or director with previous approval from the vice presidency of corporate finance and after a
commercial, financial and legal analysis; and evidence of economic support.

The calculation for the provision shall correspond to a technical evaluation (individual study based
on the factors previously described) that will allow to determine the contingency of loss or risk
for non-collecting the right. Based on this the recording of an individual provision shall be made.
Accounting Provision: The Coordination of Receivables and collections together with the officers
responsible for the management the Business Units providing this service shall conduct an individual
analysis of Receivables in default to determine which accounts are considered un- collectible, and
based on that, make the recording of an individual provision. To do this, the manager and/or
director of the Business Unit of providing the service must submit a memorandum requesting the
recording of the corresponding provision. Fiscal Provision: For purposes of this provision,
Receivables are classified by seniority and are calculated according to the percentages set out by
tax regulations. Any of the two methods indicated hereunder may be applied as a deduction for the
provision:

10 Defined according to the contingency of loss of the rights to be collected as a result of the
degree of seniority, default, prescription, and collection action through legal means; the provision
includes the amount estimated as uncollectable.

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

3.13 Provision for Accounts Receivable10

· Individual: four debts between 12 and 24 months (33%), between 24 and 36 months (66%) and over 36
months (99%). · General: the corresponding percentages are applied depending on the seniority of
their Receivables. (5% 3-6 months; 10% 6-12 months; 15% over 12 months).

19
<!-- page 92 -->
Accounts Receivable classified as lost or uncollectible, and upon which all procedures for
collection have been conducted and with a provision of 100% are subject to a request for a write-off
pursuant to the provisions in the MAD. Accounts Receivable classified as lost or uncollectible,
whose value does not exceed 150 (SMLMV) (current monthly minimum legal wage) and upon which all
procedures for collection have been conducted and with a provision of 100% are subject to a request
for a write-off by the Coordinator of Records and Analysis of Accounts Payable if their value is
between 1 and 70 monthly minimum legal wages, and by the Head of the Unit of Accounting and Tax
Information if their value is between 71 and 150 monthly minimum legal wages upon exhaustion of all
legal and other instances by the Business Unit generating it and the legal vice presidency. When
Accounts Receivables classified as lost or uncollectible exceed 180 monthly minimum wages, its write
off must be authorized by the Board of Directors upon exhaustion of instances such as: current
collection, execution of guarantees and previous legal collection. It is understood as debt that is
lost and without any value, all that debt whose collection is not possible to make it effective due
to insolvency of debtors and guarantors as a result of lack of property guarantees or by any other
cause that allows them to be considered as currently lost according to commercial practices. This
definition includes those accounts receivable of less value whose collection procedures is
significantly more onerous than the write-off of said debt. Version: 01 Date: 10/09/2010 Reviewed
by: Jose David Roldan Professional Receivables and Collections Approved by: Elkin Leonardo Suarez
Coordinator Receivables and Collections

ECOPETROL MANAGEMENT GUIDELINES FOR RECEIVABLES SERVICES ECP-UTE-G-008

3.14 Receivables Write-offs

20
<!-- page 93 -->
ANNEX 3 INSURANCE ONLY POLICY OF PERFORMANCE FOR STATE CONTRACTS IN FAVOR OF ECOPETROL S A
<!-- page 94 -->
INSURANCE ONLY POLICY OF PERFORMANCE FOR STATE CONTRACTS IN FAVOR OF ECOPETROL S A Front Page

ANY DEFAULT IN PAYMENT OF THE POLICY PREMIUM, THE CERTIFICATES OR ANNEXES ISSUED BASED ON SAID
POLICY, SHALL NOT GENERATE THE AUTOMATIC TERMINATION OF THE CONTRACT, WITHOUT PREJUDICE OF THE RIGHT
UNDER THE NAME OF THE INSURER TO REQUEST PAYMENT OF THE PREMIUM AND ANY EXPENSES CAUSED AS A RESULT
OF THE ISSUANCE OF THE CONTRACT, ALL THESE PURSUANT TO THE PROVISIONS IN THE FINAL PARAGRAPH OF
NUMERAL 19 OF ARTICLE 25 OF LAW 80, 1993.

1. CITY AND DATE OF ISSUANCE

2. POLICY NUMBER

3. INTERMEDIARY

4. INSURER

a) name

b) tax ID

5. POLICYHOLDER

a) name

b) tax ID

c) address

6. ENTITY INSURED (ECOPETROL S A)

a) name

b) tax ID

c) address

7. BENEFICIARY ENTITY (ECOPETROL S A)

8. COVERAGE GRANTED

9. INSURED LIMITS GRANTED FOR EACH COVERAGE

10. VALIDITY FOR EACH OF THE COVERAGE GRANTED

a) From at 00:00 hours

b) Until at 00:00 hours

c) Days

11. IDENTIFICATION AND PURPOSE OF THE CONTRACT GUARANTEED BY THE INSURANCE

12. PARTICULAR CONDITIONS OF THE INSURANCE

13. PREMIUM FOR EACH OF THE COVERAGE GRANTED

14. TOTAL PREMIUM FOR ALL COVERAGE CONTRACTED

15. VALUE ADDED TAX

16. FINAL PREMIUM TO BE PAID BY THE BONDED POLICYHOLDER AND DATE OF PAYMENT

17. ADDRESS FOR NOTIFICATION AND COLLECTIONS

18. CITY

19. ANNEXES

20. AUTHORIZED SIGNATURE

2
<!-- page 95 -->
INSURANCE ONLY POLICY OF PERFORMANCE FOR STATE CONTRACTS IN FAVOR OF ECOPETROL S A INDEX SECTION I:
COVERAGE

SECTION II: EXCLUSIONS

SECTION III: GENERAL CONDITIONS

1. COVERAGE FOR SERIOUSNESS OF THE BID

2. COVERAGE FOR ADVANCEMENT

3. COVERAGE FOR PREPAYMENT

4. COVERAGE FOR PERFORMANCE OF THE CONTRACT

5. COVERAGE FOR THE PAYMENT OF SALARIES, FRINGE BENEFITS AND INDEMNIFICATION

6. COVERAGE FOR STABILITY OF WORKS

7. COVERAGE FOR QUALITY OF EQUIPMENT PROVIDED

8. COVERAGE FOR PROPER OPERATION OF EQUIPMENT

9. COVERAGE FOR QUALITY OF SERVICE

10. COVERAGE FOR THE PROVISION OF SPARE PARTS AND ACCESSORIES

11. OTHER COVERAGE

1. FORCE MAJEURE OR ACTS OF NATURE

2. AMENDMENTS TO THE ORIGINAL CONTRACT

3. INJURIES TO PERSONS OR DAMAGE TO PROPERTY

4. IMPAIRMENT BY THE PASSING OF TIME

1. TERM

2. LOSS CLAIM

2.1 IN THE EVENT OF EXPIRATION

2.2 TO MAKE EFFECTIVE THE PAYMENT OF PENALTY OR THE PENALTY CLAUSE

2.3 IN ALL OTHER EVENTS

3. PROVING THE AMOUNT TO BE INDEMNIFIED

4. PAYMENT OF THE LOSS

5. AMOUNT INSURED

6. COMPENSATION OF OBLIGATIONS

7. SUBROGATION

8. ASSIGNMENT OF THE CONTRACT

9. COEXISTING INSURANCE

10. NO EXPIRATION BY FAILURE OF PAYMENT OF THE PREMIUM AND IRREVOCABILITY

11. CONDUCT OF THE POLICYHOLDER

12. NOTIFICATION AND RECOURSES

13. AMENDMENTS

14. GUARANTEE CALL

15. VIGILANCE

16. CO-INSURANCE
<!-- page 96 -->
17. BANKRUPTCY PROCEEDINGS

18. TIME BAR

19. INCOMPATIBLE CLAUSES

20. SETTLEMENT OF CONFLICTS

21. DOMICILE

3
<!-- page 97 -->
INSURANCE ONLY POLICY OF PERFORMANCE FOR STATE CONTRACTS IN FAVOR OF ECOPETROL S A
_____________________, A COMPANY LEGALLY ESTABLISHED IN COLOMBIA AND DULY AUTHORIZED BY
SUPERINTENDENCE OF FINANCE OF COLOMBIA TO OPERATE IN THE COUNTRY, WHICH, HEREINAFTER SHALL BE CALLED
THE INSURER, GRANTS IN FAVOR OF ECOPETROL S A, HEREINAFTER CALLED ECOPETROL, THE INSURED AND
BENEFICIARY ENTITY, THE COVERAGE SPECIFIED IN THE FRONT PAGE OF THIS POLICY SUBJECT IN ITS SCOPE AND
CONTENT TO THE GENERAL AND PARTICULAR CONDITIONS THERETO WITHOUT EXCEEDING THE CORRESPONDING INSURED
AMOUNT, PURSUANT TO THE PROVISIONS IN ARTICLE 1079 OF THE COLOMBIAN CODE OF COMMERCE ACCORDING TO
THE DEFINITIONS AND SCOPE OF THE RESPECTIVE COVERAGE DESCRIBED HEREUNDER: SECTION I: COVERAGE

BY MEANS OF THIS COVERAGE ECOPETROL IS PROTECTED AGAINST ANY EQUITY DAMAGE CAUSED BY THE BIDDER AS
THE RESULT OF ANY BREACHING ONCE THE CONTRACT HAS BEEN AWARDED AND FROM ANY OF THE OBLIGATIONS AND
NECESSARY REQUIREMENTS FOR THE EXECUTION, PERFECTION AND A COMMENCEMENT OF THE SAME, AND MORE
SPECIFICALLY AS A RESULT OF ANY DEFAULT ON THE OBLIGATIONS TO ENTERED INTO AND TO PERFECT THE
CONTRACT UNDER THE TERMS IN WHICH THE BID HAS BEEN PRESENTED AND PROVIDE IN THE APPROPRIATE MANNER
ANY PERFORMANCE POLICY OR BANK COLLATERAL REQUIRED TO COMPLY WITH THE SAME. ALL OF THIS, PURSUANT TO
THE PARAMETERS SET FORTH IN THE SELECTION PROCESS AND ALL OTHER CONDITIONS REQUIRED BY ECOPETROL.
THE AMOUNT INSURED ESTABLISHED FOR THE COVERAGE OF SERIOUSNESS OF THE BID HAS PUNITIVE OR PENALTY
IMPLICATIONS AND CONSTITUTES AN ADVANCE ASSESSMENT OF DAMAGES.

THIS COVERAGE GUARANTEES THE REIMBURSEMENT TO ECOPETROL OF THE FUNDS AND GOODS GIVEN TO THE
CONTRACTOR AS AN ADVANCE FOR THE EXECUTION OF THE CONTRACT IF SAID CONTRACTOR HAS MADE INAPPROPRIATE
USE OF SAID FUNDS. IT SHALL BE UNDERSTOOD THAT THERE HAS BEEN INAPPROPRIATE USE OF THE FUNDS OR
GOODS GIVEN IN ADVANCE, IN THE EVENT THAT SUCH FUNDS OR GOODS HAVE NOT BEEN USED FOR THE PURPOSE FOR
WHICH THEY WERE GIVEN AT THE BEGINNING OR DURING THE DEVELOPMENT OF THE EXECUTION OF THE CONTRACT
WHICH INCLUDES NO-REIMBURSEMENT, AS IT MAY APPLY. THIS COVERAGE DOES NOT EXTEND TO THE USE OF FUNDS
GIVEN AT PREPAYMENT TO THE CONTRACTOR. THIS RISK SHALL ALSO BE COVERED IN THE EVENTS AS THEY MAY
APPLY AS DEFINED HEREUNDER.

1. COVERAGE FOR SERIOUSNESS OF THE BID

2. COVERAGE FOR ADVANCEMENT

4

INSURANCE ONLY POLICY OF PERFORMANCE FOR STATE CONTRACTS IN FAVOR OF ECOPETROL S A
<!-- page 98 -->
THIS COVERAGE GUARANTEES THE REIMBURSEMENT TO ECOPETROL BY THE CONTRACTOR OF ANY BALANCE
CORRESPONDING TO THE DIFFERENCE BETWEEN THE TOTAL AMOUNT RECEIVED BY THE CONTRACTOR AS PREPAYMENT
AND ANY AMOUNT CORRESPONDING TO THE PORTION PERFORMED OF THE CONTRACT. THEREFORE, IF THE CONTRACT IS
PARTIALLY PERFORMED, ANY REIMBURSEMENT AS IT MAY APPLY SHALL BE CALCULATED DEDUCTING FROM THE FULL
AMOUNT GIVEN BY ECOPETROL TO THE CONTRACTOR AS THE PREPAYMENT, THE AMOUNT CORRESPONDING TO THE
REMUNERATION OR PAYMENT OF THE PERFORMED PORTION OF THE CONTRACT.

THIS COVERAGE PROTECTS ECOPETROL AGAINST ANY EQUITY DAMAGE SUCH AS GENERAL DAMAGE AND LOSS OF
PROFITS RESULTING FROM ANY BREACHING ATTRIBUTABLE TO THE CONTRACTOR ON ANY OF THE OBLIGATIONS
ARISING FROM THE GUARANTEED CONTRACT. THIS COVERAGE COMPRISES ANY FINES AND THE AMOUNT OF THE
PENALTY CLAUSE IF ENFORCED. THE TOTAL INDEMNITY SHALL NOT EXCEED IN ANY CASE THE AMOUNT INSURED SET
FORTH FOR SAID PURPOSE.

AS PROVIDED IN ARTICLE 34 OF THE COLOMBIAN CODE OF LABOR, THIS COVERAGE PROTECTS ECOPETROL AGAINST
THE RISK OF DEFAULT BY THE CONTRACTOR ON ANY LABOR OBLIGATIONS ACQUIRED BY SAID CONTRACTOR WITH
PERSONNEL USED IN THE EXECUTION OF THE CONTRACT BEING THE PURPOSE OF COVERAGE UNDER THIS POLICY. THE
INSURANCE COMPANY SHALL MAKE THE PAYMENTS TO THE EXTENT THAT EACH OF THE WORKERS DEMONSTRATES THEIR
RIGHTS AND THE AMOUNT INSURED SHALL BE DECREASING TO THE EXTENT THAT PAYMENTS ARE BEING MADE UNTIL
COMPLETION, IF SUCH IS THE CASE.

THIS COVERAGE PROTECTS ECOPETROL AGAINST ANY EQUITY DAMAGE INCLUDING LOSS OF PROFITS RESULTING FROM
ANY IMPAIRMENT THAT, UNDER NORMAL CONDITIONS OF USE, SUFFERS ANY OF THE GOODS BUILT OR MANUFACTURED
BEING THE PURPOSE OF THIS CONTRACT, FOR THE ACTIONS OR OMISSIONS ATTRIBUTABLE TO THE CONTRACTOR
DERIVED FROM DEFICIENCIES IN THE EXECUTION AND COMPLIANCE WITH CONTRACT AND DETECTED AFTER THE
TERMINATION AND DELIVERY OF THE SAME. THIS COVERAGE SHALL START TO BE IN FORCE AFTER THE ISSUANCE OF
THE MINUTES OF THE DELIVERY OF WORKS DULY COMPLETED WITH THE RESPECTIVE RECORD OF RECEPTION AT
SATISFACTION BY ECOPETROL.

3. COVERAGE FOR PREPAYMENT

4. COVERAGE FOR PERFORMANCE OF THE CONTRACT

5. COVERAGE FOR THE PAYMENT OF SALARIES, FRINGE BENEFITS AND INDEMNIFICATION

6. COVERAGE FOR STABILITY OF WORKS

5

INSURANCE ONLY POLICY OF PERFORMANCE FOR STATE CONTRACTS IN FAVOR OF ECOPETROL S A
<!-- page 99 -->
THIS COVERAGE PROTECTS ECOPETROL AGAINST ANY EQUITY DAMAGE INCLUDING LOSS OF PROFITS RESULTING FROM
ANY IMPAIRMENT THAT, UNDER NORMAL CONDITIONS OF USE, SUFFERS ANY OF THE GOODS BEING THE PURPOSE OF
THIS CONTRACT, FOR THE ACTIONS OR OMISSIONS ATTRIBUTABLE TO THE CONTRACTOR DERIVED FROM THE
DEFICIENT QUALITY OF THE GOODS OR EQUIPMENT PROVIDED IN ACCORDANCE WITH THE TECHNICAL SPECIFICATIONS
AGREED IN THE CONTRACT AND DETECTED AFTER THE TERMINATION AND DELIVERY OF THE SAME. THIS COVERAGE
SHALL START TO BE IN FORCE AFTER THE ISSUANCE OF THE MINUTES OF THE DELIVERY OF THE EQUIPMENT
PROVIDED DULY COMPLETED WITH THE RESPECTIVE RECORD OF RECEPTION AT SATISFACTION BY ECOPETROL.

THIS COVERAGE PROTECTS ECOPETROL AGAINST ANY EQUITY DAMAGE INCLUDING LOSS OF PROFITS RESULTING FROM
ANY DEFICIENCIES IN THE OPERATION THAT, UNDER NORMAL CONDITIONS OF USE, SUFFERS ANY OF THE EQUIPMENT
PROVIDED TO INSTALLED IN THE DEVELOPMENT OF THE CONTRACT, FOR THE ACTIONS OR OMISSIONS ATTRIBUTABLE
TO THE CONTRACTOR DERIVED FROM THE DEFICIENT QUANTITY OR IMPROPER INSTALLATION OF THE SAME IN
ACCORDANCE WITH THE TECHNICAL SPECIFICATIONS AGREED IN THE CONTRACT AND DETECTED AFTER THE
TERMINATION AND DELIVERY OF THE SAME. THIS COVERAGE SHALL START TO BE IN FORCE AFTER THE ISSUANCE OF
THE MINUTES OF THE DELIVERY OR INSTALLATION OF THE EQUIPMENT PROVIDED WITH THE RESPECTIVE RECORD OF
RECEPTION AT SATISFACTION BY ECOPETROL.

THIS COVERAGE PROTECTS ECOPETROL AGAINST ANY EQUITY DAMAGE INCLUDING LOSS OF PROFITS ATTRIBUTABLE TO
THE CONTRACTOR RESULTING FROM NONCOMPLIANCE OR DEFICIENT NON-COMPLIANCE WITH THE SPECIFICATIONS AND
REQUIREMENTS OF THE SERVICE CONTRACTED BY ECOPETROL PURSUANT TO THE TERMS AND CONDITIONS DEFINED IN
THE CONTRACT GUARANTEED AND IDENTIFIED IN THE PARTICULAR CONDITIONS OF THIS POLICY. THIS COVERAGE
SHALL START TO BE IN FORCE AFTER THE ISSUANCE OF THE MINUTES OF THE DELIVERY OF THE SERVICE
CONTRACTED WITH THE RESPECTIVE RECORD OF RECEPTION AT SATISFACTION BY ECOPETROL.

THIS COVERAGE PROTECTS ECOPETROL AGAINST ANY EQUITY DAMAGE INCLUDING LOSS OF PROFITS ATTRIBUTABLE TO
THE CONTRACTOR RESULTING FROM NONCOMPLIANCE WITH THE PROVISION OF SPARE PARTS AND ACCESSORIES
PURSUANT TO THE STIPULATIONS IN THE CONTRACT. THIS COVERAGE SHALL START TO BE IN FORCE AFTER THE
ISSUANCE OF THE MINUTES OF TERMINATION OF THE CONTRACT WITH THE RESPECTIVE RECORD OF RECEPTION AT
SATISFACTION BY ECOPETROL.

7. COVERAGE FOR QUALITY OF EQUIPMENT PROVIDED

8. COVERAGE FOR PROPER OPERATION OF EQUIPMENT

9. COVERAGE FOR QUALITY OF SERVICE

10. COVERAGE FOR THE PROVISION OF SPARE PARTS AND ACCESSORIES

6

INSURANCE ONLY POLICY OF PERFORMANCE FOR STATE CONTRACTS IN FAVOR OF ECOPETROL S A
<!-- page 100 -->
THE INSURANCE COMPANY SHALL PROVIDE TO ECOPETROL ALL OTHER COVERAGE AS DETERMINED IN THE FRONT PAGE
OR IN THE ANNEXES ISSUED TO THE POLICY HEREOF. PARAGRAPH; THE LISTED COVERAGE IS INDEPENDENT FROM
ONE ANOTHER REGARDING THE COVERAGE PROVIDED AND THE AMOUNT INSURED. THEREFORE, THEY ARE MUTUALLY
EXCLUSIVE AND NON-CUMULATIVE. SECTION II: EXCLUSIONS COVERAGE PROVIDED IN THE POLICY HEREOF SHALL
NOT APPLY IN THE FOLLOWING CASES:

IN THE EVENT OF FORCE MAJEURE, ACTS OF NATURE OR ANY OTHER LEGAL CAUSE OF EXEMPTION OF
RESPONSIBILITY BY THE CONTRACTOR.

ANY EQUITY DAMAGE GENERATED BY OR FROM BREACHING ATTRIBUTABLE TO THE CONTRACTOR AND RESULTING IN
AMENDMENTS TO THE ORIGINAL CONTRACT, SAVE THERE HAS BEEN ACCEPTANCE OF THE SAME BY THE INSURANCE
COMPANY WITH A WRITTEN RECORD.

ANY INJURY CAUSED BY THE CONTRACTOR OR BY ITS WORKERS TO ECOPETROL'S PERSONNEL OR ANY THIRD PARTIES,
OR ANY DAMAGE CAUSED TO ECOPETROL'S PROPERTY OR ANY THIRD PARTIES, OCCURRING DURING THE EXECUTION OF
THE CONTRACT, OR THOSE DERIVED IN GENERAL FROM THE EXTRA-CONTRACTUAL CIVIL LIABILITY OF THE
CONTRACTOR.

THE IMPAIRMENT OR NORMAL DETERIORATION SUFFERED BY THE GOODS, PROPERTY OR WORKS CARRIED OUT AND
COVERED BY THE POLICY, AS A CONSEQUENCE OF THE MERE PASSING OF TIME. SECTION III: GENERAL CONDITIONS

The term of the coverage included in the policy hereof shall be recorded in the front page of the
same or through annexes according to the nature of each of them. The term for the performance
coverage under no circumstances shall be less than that term of execution and liquidation of the
contract. The term may be extended by request from ECOPETROL or the contractor, if so stated. If the
insurance company accepts the extension, it will issue the certificates and annexes recording said
amendment subject to the payment of the corresponding premium.

11. OTHER COVERAGE

1. FORCE MAJEURE OR ACTS OF NATURE

2. AMENDMENTS TO THE ORIGINAL CONTRACT

3. INJURIES TO PERSONS OR DAMAGE TO PROPERTY

4. IMPAIRMENT BY THE PASSING OF TIME

1. TERM

7

INSURANCE ONLY POLICY OF PERFORMANCE FOR STATE CONTRACTS IN FAVOR OF ECOPETROL S A
<!-- page 101 -->
Pursuant to the provisions in article 1077 of the Colombian code of commerce, ECOPETROL shall
demonstrate both the occurrence of the incident as well as the amount of the loss and shall
correspond to the insurance company to demonstrate the facts or circumstances waving its
responsibility. The occurrence of the loss may be accredited as follows:

By means of an administrative action duly executed stating the expiration of the contract, which
shall be notified both to the insurance company as well as the contractor, pursuant to the
provisions of article 44 of the Colombian administrative code.

By delivery to the insurance company of the decision made ordering the payment of a fine or the
penalty clause in accordance with the terms and conditions of the respective contract being the
purpose of the coverage.

For all contracts entered into by ECOPETROL in all other events in which there is claim under this
policy, by delivering to the insurance company all documents or evidence accrediting the occurrence
of the loss and the amount of the damage being the purpose of the claim, pursuant to the provisions
in article 1077 of the code of commerce.

The amount of the loss may be proved, depending on the case: with the minutes of liquidation of the
contract; with the administrative action in firm of the unilateral liquidation of the contract; with
the decision duly justified claiming the payment of a fine or a penalty clause accompanied by the
text of the contract stipulating the enforcement of the same, or by any other means that allows to
prove the amount of the loss suffered as provided in article 1077 of the code of commerce.

Pursuant to the provision in article 1110 of the code of commerce, the indemnity may be paid in
cash, or by replacement, repair or reconstruction of the goods insured at the option of the
insurance company. If the option is to indemnify with an amount in cash, pursuant to the indications
in Article 1080 of the code commerce, this payment shall be made as follows: In the case of numeral
2.1 the payment shall be made within the following month after a written communication delivered by
ECOPETROL to the insurance company, accompanied with the corresponding administrative act, duly
executed declaring the expiration of the contract and the minutes of liquidation of the same or a
resolution executed adopting its unilateral liquidation.

2. LOSS CLAIM

2.1 IN THE EVENT OF EXPIRATION

2.2 TO MAKE EFFECTIVE THE PAYMENT OF PENALTY OR THE PENALTY CLAUSE

2.3 IN ALL OTHER EVENTS

3. PROVING THE AMOUNT TO BE INDEMNIFIED

4. PAYMENT OF THE LOSS

8
<!-- page 102 -->
INSURANCE ONLY POLICY OF PERFORMANCE FOR STATE CONTRACTS IN FAVOR OF ECOPETROL S A In the cases of
numerals 2.2 and 2.3 payment shall be made within the following month after delivery of the written
communication by ECOPETROL to the insurance company accompanied by the documents proving the
occurrence of the loss and the amount of any damage.

The insurance company's liability in connection with each coverage is limited to the value
established as insured amount in the from page or the annexes issued based on the policy, and shall
not exceed in any case said amount, pursuant to the provisions in article 1079 of the code of
commerce. The amount of the insured value may be reestablished with the express previous acceptance
from the insurance company when there is a formal request by ECOPETROL or the contractor, thus
generating an additional premium charge which shall be previously paid by the policyholder.

If ECOPETROL owes any money to the contractor by virtue of the contract guaranteed at the time of
filing the judicial or extrajudicial claim of the loss, ECOPETROL shall compensate the amounts owed
pursuant to the provisions in articles 1714 and the following, of the Colombian civil code, thus
decreasing the amount of indemnity to be paid by the insurance company to ECOPETROL.

By virtue of the indemnity payment pursuant to article 1096 of the code of commerce and according to
article 203 of Decree 663 of 1993 (EOSF) Code of the Financial System, the insurance company
subrogates up to the amount paid by said company on the rights ECOPETROL may be entitled against the
contractor resulting from the occurrence of the loss.

If by any breaching from the contractor, the insurance company resolves to continue with the
execution of the contract and if ECOPETROL is in agreement, the contractor accepts hereafter the
assignment of the contract in favor of the insurance company.

Pursuant to the provisions in the code of commerce, in case of existence, at the time of the
incident or loss, of any other insurance for the same coverage in connection with the contract
thereto, the amount of the indemnity as it may apply shall be distributed between the insurers in
proportion to the amounts of their respective insurance contracts without exceeding the amount
insured as set forth in the contract.

5. AMOUNT INSURED

6. COMPENSATION OF OBLIGATIONS

7. SUBROGATION

8. ASSIGNMENT OF THE CONTRACT

9. COEXISTING INSURANCE

9

INSURANCE ONLY POLICY OF PERFORMANCE FOR STATE CONTRACTS IN FAVOR OF ECOPETROL S A
<!-- page 103 -->
The policy hereof shall not expire by failure of payment of the premium and said premium shall not
be revocable in a unilateral manner neither by the insurance company nor by the contractor.

It is stated for the record that ECOPETROL shall not accept any objections from the insurance
company regarding the exceptions or defense resulting from the conduct of the policyholder, in
particular those derived from any inaccuracy or reticence incurred by the contactor in the
contracting of insurance or its omission regarding the duty to report the seriousness of a risk
situation, or in general any other exceptions the insurance company may have against the contractor.

ECOPETROL shall timely notify the insurance company on any administrative action issued in
connection with the guaranteed contract, in particular those on expiration and unilateral
termination of the contract, being the insurance company entitled to file any pertinent legal action
against said administrative actions pursuant to the provisions in the Administrative Code.

In those cases in which the amount of the contract or the term of the same are increased or
decreased, or in general when the stipulations of the original contract are somehow amended
according to the law by the parties, the respective amendment to the insurance as it may apply, must
be previously accepted by the insurance company in order to make it effective.

When the discussion regarding any breaching of the contract occurs in an arbitration process between
ECOPETROL and the contractor, the insurance company is committed in advance to accept the guarantee
call made inside said process.

The insurance company is entitled to conduct vigilance on the contractor regarding the execution of
the contract, and ECOPETROL shall provide the necessary cooperation. In those cases in which the
contract has as a purpose any issues in connection with public order and the national security,
ECOPETROL shall forbid or limit this power to the insurance company. ECOPETROL makes the commitment
to carry out strict control on the development of the contract and the handling of the corresponding
funds and goods within the legal provisions that said control confers.

If there is any co-insurance as referred to in article 1095 of the code of commerce, the amount of
the indemnity, as it may apply, shall be distributed between the insurers at a pro rate of the
amounts of their respective insurance, without solidarity between participating insurers and without
exceeding the amount insured under the insurance contract.

10. NO EXPIRATION BY FAILURE OF PAYMENT OF THE PREMIUM AND IRREVOCABILITY

11. CONDUCT OF THE POLICYHOLDER

12. NOTIFICATION AND RECOURSES

13. AMENDMENTS

14. GUARANTEE CALL

15. VIGILANCE

16. CO-INSURANCE

10

INSURANCE ONLY POLICY OF PERFORMANCE FOR STATE CONTRACTS IN FAVOR OF ECOPETROL S A
<!-- page 104 -->
ECOPETROL is obliged to protect its rights in any bankruptcy proceedings as set out in the Colombian
legislation in which the contractor may be admitted, as it may do it if there was no guarantee as
provided by the policy hereof, its application certificates and its coverage, giving notice to the
insurance company of said conduct. Any failure to comply with this obligation would cause to
ECOPETROL the consequences stipulated in article 1078 of the code of commerce.

The time bar for the actions derived from the contract hereof shall be governed pursuant to article
1081 of the code of commerce as added or amended or any other special applicable law to the case.

In case of any incongruity or differences between the general and particular conditions of the
policy, the latter shall prevail.

In case of any disputes or conflicts in connection with the interpretation, execution and
enforcement of the policy hereof, the parties shall make their best effort to use the alternative
settlement mechanisms as stated in Law 80 of 1993.

Without prejudice of any proceedings stipulations, for all purposes regarding the contract hereof,
the parties establish as a domicile the city of Bogota D C.

17. BANKRUPTCY PROCEEDINGS

18. TIME BAR

19. INCOMPATIBLE CLAUSES

20. SETTLEMENT OF CONFLICTS

21. DOMICILE

11

ANNEX 4 SAMPLE STAND-BY LETTER OF CREDIT
<!-- page 105 -->
<!-- page 106 -->
SAMPLE STAND-BY LETTER OF CREDIT Letter of Credit No [________] Place and date of issuance:
[_____________] Nominal Value: US$ [______________] Issuing Bank: [____________________]
Beneficiary: Ecopetrol S A Applicant: [_______________________] By means of this document we are
informing to you, Ecopetrol S A (the "Beneficiary") that, by request from [________________________]
(the "Applicant"), a company created pursuant to the laws of [_______________________], through its
branch duly established in Colombia, the Bank [_________________] (the "Bank") that we have issued
in favor of Ecopetrol S A, a company incorporated pursuant to the laws of the Republic of Colombia
and with tax ID [______] (the "Beneficiary"), this Stand-by Letter of Credit irrevocable at first
request (the "Letter of Credit") to ensure payments of up to the nominal value as indicated above
(The "Secured Obligations"). This Letter of Credit shall be valid from [______] of 20 [ ] until the
date of occurrence [ ][ ] calendar days after [ ] of [ ]. It is understood that the Bank's
responsibility derived from the Letter of Credit hereof is limited only and exclusively to the
amounts and the terms indicated in the heading of the Letter of Credit. In case of default by the
Applicant of all or any of the Secured Obligations, the Beneficiary shall report said default to the
Bank in its offices located at [_____________________], within the term of the Letter of Credit
hereof. On the same date of reception of the referred communication by the Bank, the Bank shall
directly proceed to pay in an unconditional manner to the Beneficiary the amounts indicated in the
document reporting the default to the Beneficiary, without exceeding at any time the total secured
value drawn on this Letter of Credit in (i) pesos, the legal currency of the Republic of Colombia,
or (ii) dollars of the United States of America. If the communication of default previously
mentioned is not received within the term of the Letter of Credit hereof, the Bank's responsibility
derived therefrom shall cease. The communication informing the Bank regarding the default of the
Secured Obligations shall consist of a document duly signed by the legal representative of the
Beneficiary or whoever replaces him, stating the default by the Applicant of the Secured Obligations
and thus requesting the payment of the guarantee hereof. Said communication shall indicate the
number of this Letter of Credit, and the amount drawn thereto. In case the Beneficiary decides to
use the Letter of Credit in pesos, the legal currency in the Republic of Colombia, the amount of the
nominal value of the Letter of Credit shall be converted at the market representative exchange rate
certified by the Superintendence of Finance of Colombia on the date in which the communication is
submitted to the Bank. This document shall be governed by the International Standby Practices
(ISP98) from the International Chamber of Commerce. 1
