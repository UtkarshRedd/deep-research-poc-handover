<!-- page 1 -->
# SUPPLIER/SUBCONTRACTOR CONTRACT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| SEC Filing Date | 2009-02-20 |
| Parties | Playboy.com, Inc. ("Purchaser"); Supplier |
| Source | CUAD v1 / PlayboyEnterprisesInc_20090220_10-QA_EX-10.2_4091580_EX-10.2_Content License Agreement_ Marketing Agreement_ Sales-Purchase Agreement2 |

Exhibit 8 SUPPLIER/SUBCONTRACTOR CONTRACT

1. By execution of this Supplier/Subcontractor Contract ("Contract"), _______________ ("Supplier")
agrees and acknowledges that: (i) all images and/or trademarks, including, but not limited to
PLAYBOY, (the "Playboy Properties") applied at the request of _______________ ("Purchaser") to
merchandise covered by this Contract are owned by Playboy Enterprises International, Inc.
("Playboy"), and when used upon merchandise means that such merchandise is sponsored, approved,
recommended or sold by Playboy or its licensees; (ii) Supplier will not sell, ship or otherwise
dispose of any such merchandise except upon the order of Purchaser or Playboy; (iii) Supplier will
never make, cause others to make or assist others in making, any claim whatsoever to any or all of
the Playboy Properties or any trademark, copyright, designation, name, phrase, design or symbol
similar thereto in connection with the manufacture, advertising, promotion, sale or distribution of
merchandise; and (iv) Supplier will defend, indemnify and hold harmless Purchaser and Playboy and
the distributors and dealers and the officers and employees of each of the foregoing against all
liability whatsoever which may be incurred by them or any of them as a result of any alleged defects
in material or workmanship in the merchandise covered by this Contract.

2. Supplier agrees that no production or manufacture of any merchandise covered by this Contract
will commence until this Contract has been signed, dated and returned by Supplier to Purchaser.
Supplier further agrees that it will not produce, cause to be produced or assist in the production
of more units than are specified by Purchaser nor will Supplier produce, cause to be produced or
assist in the production of any product or item not specifically requested by Purchaser using any or
all of the Playboy Properties or any trademark, copyright, designations, names, phrases, designs or
symbols similar to any or all of the Playboy Properties during or at any time after the completion
of merchandise requested by this Contract.

3. Supplier will, upon request from Purchaser or Playboy, deliver to Purchaser or will destroy in
the presence of Purchaser or its representative(s), all molds, designs or any other elements used in
reproducing any or all of the Playboy Properties.

4. Playboy is an intended third-party beneficiary of this Contract.

5. This Contract, when attached to a purchase order, shall consist of the entire agreement between
the parties and shall supersede any conflicting or contrary terms and conditions of any purchase
order or other order form whether supplied by Purchaser or Supplier.

6. This Contract may not be modified or terminated except in writing, and no claimed modification,
termination or waiver shall be binding unless also signed by an authorized representative of
Playboy.

40

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 2 -->
7. VIOLATION OF THIS AGREEMENT BY SUPPLIER MAY RESULT IN PROSECUTION FOR PLAYBOY PROPERTIES
INFRINGEMENT, UNFAIR COMPETITION AND OTHER CAUSES OF ACTION AND THE IMPOSITION OF FINES AND/OR
CRIMINAL PENALTIES.

SUPPLIER PURCHASER (Name of Company - Please Print) By: By: Title: Title: Date: Date: SUPPLIER
INFORMATION PLAYBOY Name: Name: PLAYBOY.COM, INC. Address: Address: 730 Fifth Avenue New York, NY
10019 Contact: Contact: Telephone: Telephone: 212-261-5000 Facsimile: Facsimile: 212-957-2950

41

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
