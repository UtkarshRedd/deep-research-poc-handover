# Which jurisdiction's law governs the Licensing and Web Site Hosting Agreement between M...

*Question:* Which jurisdiction's law governs the Licensing and Web Site Hosting Agreement between Mortgage Logic.com, Inc. and TrueLink, Inc. (dated 1999-02-26)?

## Identify agreement and parties

The document is titled "LICENSING AND WEB SITE HOSTING AGREEMENT". [642f3505d982f946 p.1] The agreement date is 1999-02-26. [642f3505d982f946 p.1] The parties are Mortgage Logic.com, Inc. [uncited] ("Client") and TrueLink, Inc. [uncited] ("TrueLink"). [642f3505d982f946 p.1] The body text confirms the agreement is entered into on February 26, 1999, by and between Mortgage Logic.com, Inc. [uncited] ("Client") and TrueLink, Inc. [uncited] ("TrueLink"). [642f3505d982f946 p.1]

## Identify governing law clause

The Licensing and Web Site Hosting Agreement between Mortgage Logic.com, Inc. and TrueLink, Inc. dated 1999-02-26 contains an explicit choice-of-law provision. [642f3505d982f946 p.6] Section 26, titled "APPLICABLE LAW," states: "26. [uncited] APPLICABLE LAW. [uncited] This Agreement shall be governed, construed and interpreted in accordance with the laws of the State of California (without respect to principles of conflicts of law)." [642f3505d982f946 p.6]

## Verification appendix

Claims: 12 · supported: 6 · partially: 0 · dropped: 0 · gaps: 6 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[642f3505d982f946 p.1] |  |
| s1.2 | s1 | keep | 1.00 | e1→[642f3505d982f946 p.1] |  |
| s1.3 | s1 | gap |  |  | no evidence cited |
| s1.4 | s1 | gap |  |  | no evidence cited |
| s1.5 | s1 | keep | 1.00 | e1→[642f3505d982f946 p.1] |  |
| s1.6 | s1 | gap |  |  | no evidence cited |
| s1.7 | s1 | gap |  |  | no evidence cited |
| s1.8 | s1 | keep | 1.00 | e2→[642f3505d982f946 p.1] |  |
| s2.1 | s2 | keep | 1.00 | e3→[642f3505d982f946 p.6] |  |
| s2.2 | s2 | gap |  |  | no evidence cited |
| s2.3 | s2 | gap |  |  | no evidence cited |
| s2.4 | s2 | keep | 1.00 | e3→[642f3505d982f946 p.6] |  |

### Evidence

- e1 [642f3505d982f946 p.1 L2-8] keep (1.0): "# LICENSING AND WEB SITE HOSTING AGREEMENT | Field | Value | |---|---| | Document Type | Hosting Agreement | | Agreement Date | 1999-02-26 | | Parties | Mortgage Logic.com, Inc. ("Client"); TrueLink, Inc. ("TrueLink") |"
- e2 [642f3505d982f946 p.1 L16-19] keep (1.0): "This Agreement is entered into on February 26, 1999, (the "Effective Date") by and between Mortgage Logic.com, Inc. ("Client"), with an address at Two Venture Plaza, 2 Venture, Irvine, California 92618 and TrueLink, Inc. ("TrueLink"), with …"
- e3 [642f3505d982f946 p.6 L434-436] keep (1.0): "26. APPLICABLE LAW. This Agreement shall be governed, construed and interpreted in accordance with the laws of the State of California (without respect to principles of conflicts of law)."
