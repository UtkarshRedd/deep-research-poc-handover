<!-- page 1 -->
# Mutual Non-Disclosure Agreement — Corvallis Foods Group LLC and Willamette Valley Produce, Inc.
| Field | Value |
|---|---|
| Document Type | Non-Disclosure Agreement |
| Effective Date | 2025-06-02 |
| Parties | Corvallis Foods Group LLC; Willamette Valley Produce, Inc. |

This Mutual Non-Disclosure Agreement (this "NDA") is entered into as of 2025-06-02 between Corvallis Foods Group LLC and Willamette Valley Produce, Inc. in connection with a potential acquisition (the "Transaction").
<!-- page 2 -->
## 1. Confidential Information
"Confidential Information" means all non-public information disclosed by a party in connection with the Transaction, including financial projections, customer lists and the terms of any financing arrangements.
## 2. Obligations
Each party shall hold the other party's Confidential Information in strict confidence for a period of three (3) years from the date of disclosure.
<!-- page 3 -->
## 3. Exclusions; Remedies
The obligations do not apply to information that is or becomes public through no fault of the receiving party. Each party acknowledges that breach may cause irreparable harm for which injunctive relief is appropriate.
## 4. Governing Law
This NDA is governed by the laws of the State of Oregon.
