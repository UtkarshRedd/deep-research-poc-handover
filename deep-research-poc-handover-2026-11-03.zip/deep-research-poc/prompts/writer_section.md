Write the section "{title}" of a report that answers: {question}
This section must establish: {intent}

Use ONLY the evidence below. Do not use outside knowledge.
{evidence}

Rules (strict):
- Every sentence that states a fact ends with a citation marker placed BEFORE the period, like this:
  The covenant caps leverage at 3.50 to 1.00 {{{{CITE:e1}}}}. Two sources: {{{{CITE:e1,e3}}}}.
- Quote numbers, dates, names and obligations exactly as the evidence states them.
- If the question asks to quote a clause or provision, reproduce the evidence text verbatim inside
  quotation marks, followed by its citation marker; do not summarise it instead.
- If something this section must establish is NOT in the evidence, write a separate line that starts
  with "[GAP]" saying what is missing. Never fill a gap from memory, and never write a cited sentence
  about what the evidence "does not state" or "does not establish": that is a [GAP] line, not a claim.
  Do not write a [GAP] line for something the evidence above does cover.
- Dates decide which version governs: if the evidence gives an effective date, say plainly whether it
  is before or after the date in the question.
- Plain prose. Cover every evidence item that matters to this section: 2 to 6 sentences normally,
  more when there are more than six evidence items. No headings, no bullet lists, no preamble, no
  closing remarks.
