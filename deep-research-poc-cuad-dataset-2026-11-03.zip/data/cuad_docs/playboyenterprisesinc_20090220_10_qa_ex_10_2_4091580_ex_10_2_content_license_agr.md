<!-- page 1 -->
# CONTENT LICENSE, MARKETING AND SALES AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2008-01-15 |
| Parties | eFashion Solutions LLC ("EFS"); Playboy.com, Inc. ("Client", which shall include affiliates controlling, controlled by or under common control with Playboy.com, Inc.) |
| Source | CUAD v1 / PlayboyEnterprisesInc_20090220_10-QA_EX-10.2_4091580_EX-10.2_Content License Agreement_ Marketing Agreement_ Sales-Purchase Agreement1 |

Exhibit 10.2 Portions of this Exhibit have been omitted pursuant to a request for confidential
treatment filed with the Securities and Exchange Commission. The omissions have been indicated by
asterisks ("*****"), and the omitted text has been filed separately with the Securities and Exchange
Commission. CONTENT LICENSE, MARKETING AND SALES AGREEMENT This CONTENT LICENSE, MARKETING AND SALES
AGREEMENT (the "Agreement") is entered into and effective as of January 15, 2008, (the "Effective
Date") by and between eFashion Solutions, LLC, a New Jersey limited liability company having its
principal place of business at 80 Enterprise Avenue South, Secaucus, NJ 07094 ("EFS") and
Playboy.com, Inc., a Delaware corporation with offices at 680 North Lake Shore Drive, Chicago, IL
60611 ("Client," which shall include affiliates controlling, controlled by or under common control
with Playboy.com, Inc.). WHEREAS, Client is in the business of, inter alia, developing, marketing,
promoting, distributing and selling branded and unbranded merchandise via physical media, worldwide,
via mail order catalogs (the "Catalogs") where orders are taken via multiple order channels
including online, phone, fax and mail and via the Internet through its PLAYBOY-branded and BUNNY
SHOP-branded e-commerce websites as designated on Exhibit 1 (the "Websites") (the Catalogs and
Websites shall be collectively referred to as the "Playboy Commerce Business"). WHEREAS, the parties
intend that EFS will operate under license from Client the Playboy Commerce Business, including, but
not limited to, the marketing, promotion and distribution of branded, unbranded and co-branded soft
and hard goods which include but are not limited to men's and women's apparel, home, lingerie, men's
and women's accessories, jewelry, books and DVD's and related products (collectively, "Merchandise")
via the Catalogs and the Websites (including other Micro- Sites (as defined in Section
1.1(d)(vii))). NOW THEREFORE, in consideration of the promises contained herein, the receipt and
sufficiency of which are hereby acknowledged, the parties hereto each intending to be legally bound,
agree as follows: 1. Operation of the Playboy Commerce Business 1.1. Obligations of EFS. (a)
Operations. EFS, at its sole cost and expense, shall be solely responsible for (i) developing,
designing, operating, maintaining and distributing the Catalogs; (ii) developing, designing,
operating, maintaining and hosting the Websites; (iii) except as otherwise set forth in this
Agreement, the creation (except for that provided by Client) and use of all content to be displayed
in the Catalogs and on the Websites; and (iv) marketing and promotion of the Playboy Commerce
Business. EFS shall be permitted to display on the bottom of each page of the Websites "Powered by
eFashionSolutions" which shall appear substantially as set forth in Exhibit 2, attached hereto and
hereby incorporated by reference.

1

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 2 -->
(b) Fulfillment Services. EFS, at its sole cost and expense or (with respect to pass-through
expenses such as shipping, gift wrapping, etc.) at the consumer's expense, shall be solely
responsible for conducting all business activities related to the Playboy Commerce Business,
including, but not limited to the following activities: (i) setting the price consumers will pay for
Merchandise offered through the Catalogs and Websites and for shipping thereof; (ii) processing all
Catalog and Website orders placed by consumers, including, but not limited to, all picking, packing,
billing, shipping, gift wrapping and other value-added services necessary to process orders from
order placement to delivery, which shall be performed substantially as set forth in Exhibit 3,
attached hereto and hereby incorporated by reference (collectively, "Fulfillment Services"); (iii)
providing pricing, billing and financial clearinghouse services in connection with the Playboy
Commerce Business; (iv) handling all customer service matters (provided, however, that Client and
EFS shall agree upon a "hot transfer" process whereby non-e-commerce-related customer calls will be
rerouted); (v) handling all financial transactions related to the Playboy Commerce Business,
including, but not limited to, establishing merchant accounts with a banking institution to be
approved by Client; (vi) handling all aspects of procuring Merchandise to be made available for sale
through the Playboy Commerce Business, including, without limitation, all warehouse and inventory
maintenance and control; and (vii) except as otherwise set forth in this Agreement, handling all
advertising, promotion and marketing relating to the Playboy Commerce Business. Client acknowledges
that the efficient and cost effective fulfillment of orders on the Websites will require that third
parties that provide Merchandise to EFS under a Playboy license adhere to certain shipping and
packaging guidelines provided by EFS, and which comply with Client's packaging guidelines as set
forth in Exhibit 3. Client agrees to provide reasonable assistance to EFS to enable EFS to have such
third parties agree to abide by the EFS guidelines. (c) Client Approval. All aspects of the Websites
and the Catalogs, including, but not limited to, their "look and feel" (including as set forth in
Section 1.1(d)(iii) below), use of the Playboy Marks (as defined in Section 7.2), functionality,
models to be used and all Merchandise sold therein, shall be subject to Client's prior written
approval, which shall not be unreasonably withheld. Further, EFS acknowledges that Client reserves
the right to change the names of the PlayboyStore and ShopTheBunny/BunnyShop Catalog and Websites to
new Client brands and/or to add names to be used provided that Client provides EFS with no less than
six (6) months prior written notice. In the event that names are changed, except to the extent that
there is an extenuating reason for such name change, EFS shall be permitted to continue to use
domain names then in use for purposes of Micro Sites and/or forwarding domains (i.e., driving
traffic to the new names). (d) Websites (i) Unless otherwise agreed by the parties and provided that
this Agreement is executed not later than January 15, 2008, EFS agrees that no later than March 1,
2008, both Websites shall launch and be fully operational, with the exception of the gift wrapping
which EFS shall make available as set forth in the time and action calendar (attached hereto as
Exhibit 12 and hereby incorporated by reference) and local billing (pursuant to Section 3.1, below),
and EFS shall be ready to perform all aspects of administration of the Website business, including,
but not limited to, all Fulfillment Services. In furtherance of this launch

2

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 3 -->
date, EFS and Client shall perform all activities and deliver all deliverables in accordance with
the time and action calendar. Client acknowledges that if it is unable to perform any obligations
within the time period agreed to in the time and action calendar that the launch of the Websites may
be delayed accordingly. (ii) Client and EFS acknowledge that design and functionality of the
Websites consistent with best practices for e-commerce is critical to ensure the maximum sales
performance of the Websites and to maintain the goodwill of Client's customers. EFS will utilize
best industry practices to maintain the shopping areas of the Websites in order to ensure that such
areas feature functionality that is deemed best practice in the e-commerce industry and is updated
with all content and brand imagery necessary to keep the shopping areas of the Websites up-to-date
and fresh, in all instances maintaining the high level of brand integrity of the PLAYBOY brand while
focusing on customer experience. From time to time, Client will provide updated photo and brand
elements for purposes of utilization by EFS in Website design. (iii) In addition to any guidelines
provided by Client, EFS shall use and comply with any style guides provided by Client to ensure
consistency among retail channels (e.g., graphics, patterns, colors, logos, etc.), visual brand
displays and seasonal color palettes. EFS shall maintain the shopping areas of the Websites
consistent with the style guides (as modified for e-commerce) to maximize sales, brand appearance
and marketability. Client will provide new brand and content assets from time- to-time along with
updated style guides in both digital and hard copies, and EFS will update the Websites and future
Catalogs accordingly within a commercially reasonable time following receipt. As of the Effective
Date hereof, updated style guides are provided twice per year. EFS will have not less than six (6)
months advance notice of upcoming new style guides. (iv) EFS will host all content displayed on the
Websites on an EFS-hosted server provided by EFS at its sole cost and expense. EFS may at its
election use a reputable third party hosting service to host the Websites; provided, however, that
EFS shall nevertheless be responsible for ensuring the availability of the Websites as set forth in
this Agreement. EFS shall provide as required all updates of content on the Websites, including
enhancements, modifications and additions thereto. (v) EFS agrees to at all times during the Term
use its best efforts to market the Websites no less diligently than it does other online properties
managed by EFS on behalf of third parties (including without limitation, maintaining best practice
functionality, search engine optimization tactics, utilizing customer acquisition and retention
campaigns, etc.). (vi) EFS shall take all reasonable measures to ensure the performance of each of
the Websites, including, at a minimum, availability at least ninety-nine and one-half percent
(99.5%) of the time per month as averaged over any one (1) month period, excepting scheduled
maintenance or a Force Majeure Event (as defined in Section 14.7). (vii) Subject to the prior,
written approval of Client, which shall not be unreasonably withheld, EFS shall have the right at
its sole cost and expense to design and launch as many micro- and sub-domain websites as EFS deems
appropriate in order to take full

3

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 4 -->
advantage of online marketing channels (collectively, "Micro Sites"); provided, however, that all
such Micro Sites shall be designed and maintained consistent with the terms of this Agreement. At a
minimum, EFS agrees to launch a version of the PlayboyStore.com Website, which does not contain
products or content containing nudity, marital aid or massager Merchandise, within forty-five (45)
days following launch of the PlayboyStore.com Website. (viii) Front-End Platform. In the event that
EFS chooses to use the Demandware, Inc. ("Demandware") front-end platform software and services for
the Websites, EFS shall enter into a separate agreement directly with Demandware; provided, however,
that the terms of any such agreement must be approved by Client in advance in writing. (e) Catalogs
(i) EFS agrees that (A) the first issue of each of the Catalogs shall be sent to consumers by March
15, 2008; and (B) no later than March 1, 2008, EFS shall be ready to perform all aspects of
administration of the Catalog business, including, but not limited to, all Fulfillment Services.
(ii) EFS shall provide a copy of each Catalog to Client for review and approval not less than five
(5) business days prior to printing. EFS shall promptly make any changes to the Catalog as may be
reasonably requested by Client. No Catalog shall be sent to printing without the written approval of
Client, which shall not be unreasonably withheld. (f) Models and Photography. EFS agrees that all
female models depicted in or in connection with the Playboy Commerce Business shall be approved by
Client and shall be Playmates (or other Playboy models, including, but not limited The Girls Next
Door) as requested by the Client unless otherwise mutually agreed in advance in writing by the
parties. In addition, EFS agrees to shoot major photography in connection with the Playboy Commerce
Business in Los Angeles and in coordination with Client, as requested by Client and in line with
current and past practices (taking into account changes in Client's Catalog- related strategy) with
respect to process, cost and frequency. EFS shall be responsible for all costs and expenses in
connection with such photography, including, but not limited to, payments to models and
photographers, based upon an estimated schedule of costs attached as Exhibit 4. EFS shall secure
model and photographer releases in a form provided by Client and shall provide all content created
under this Section 1.1(f) to Client within thirty (30) days of creation. All such photographs shall
be deemed Playboy Content for purposes of this Agreement, for which EFS shall have a license to use
during the Term solely in connection with the Playboy Commerce Business and as is necessary to
promote the Websites. During the Term, Client shall not be permitted to sell or otherwise provide
such photographs to third party retailers (except for those retailers operating under the PLAYBOY
brand) or Licensees (as defined in Section 2.4), without the prior written approval of EFS. (i)
Client shall own all content produced pursuant to Section 1.1(f) (whether or not actually used), and
EFS hereby assigns to Client all right, title and interest, including all rights in copyright, in
and to the photographs and materials, and agrees to cooperate with all reasonable requests by
Client, and take all reasonable actions, to effect or perfect such assignment. EFS hereby provides
Client with an irrevocable power of attorney appointing Client as its irrevocable attorney-in-fact
coupled with an interest to execute all such assignments on

4

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 5 -->
behalf of EFS in the event that EFS fails to do so within thirty (30) days following written request
by Client. Client hereby grants to EFS a limited and perpetual right and license to use such
photographs and materials for research and forecasting purposes, including, but not limited to,
combining the same with reports and analytics concerning the performance of the Websites, providing
information to strategic partners to better define consumer purchasing habits, and for trend
forecasting and planning purposes. In addition, during the Term, EFS may use such photographs and
materials to provide information to Client Licensees to better define consumer purchasing habits,
refine the design and performance of the Websites and EFS Portals on which the Merchandise is sold
in connection with any EFS Analysis (as defined below), and for marketing and planning purposes. For
the avoidance of doubt, no information provided to third parties under this Section 1.1(i) shall:
(i) specifically or by inference identify or in any way reference Client; (ii) disclose any
proprietary information of Client; or (iii) disclose any personally identifiable information of or
otherwise identify any consumer of the Websites or the Catalogs. (g) Compliance with Guidelines. EFS
shall at all times comply with the provisions and limitations set forth in Client's editorial and
advertising guidelines, which are attached hereto as Exhibit 5 and hereby incorporated by reference,
as the same may be amended from time to time at Client's sole discretion, effective upon fifteen
(15) business days prior written notice to EFS (the "Guidelines"). (h) Compliance with Laws.
Throughout the Term, EFS shall be solely responsible for knowledge of and compliance with all
applicable international, federal, state and local laws, rules, regulations, ordinances, industry
guidelines and similar restrictions (collectively, "Laws") in connection with operation of the
Playboy Commerce Business. EFS shall be responsible for monitoring such Laws and taking any actions
necessary to keep compliant all aspects of the Playboy Commerce Business, including, but not limited
to, the Privacy Policy (as defined in Section 5.1(a)), as well as best practices relating to Direct
Marketing Association ("DMA") Guidelines (as they relate to the DMA Privacy Promise, pander files,
etc.). (i) Product Placement. At no additional cost to Client, EFS will provide preferential
placement in the Catalogs and/or on the Websites, as requested by Client, for certain Merchandise
from time-to-time, e.g. apparel, magazines, books, DVD's, etc. or marketing campaigns that tie to
events and initiatives of Client and its affiliates, consistent with Client's past practices in the
prior placement of such items in the Catalogs and/or on the Websites. (j) Staffing/Retention of
Client Employees. EFS agrees to staff the Playboy Commerce Business sufficiently to operate and grow
the Playboy Commerce Business. An initial organizational chart approved by both parties is attached
as Exhibit 6, attached hereto and hereby incorporated by reference. EFS agrees to employ certain
individuals who are currently employed by the Client (names, titles and current salaries are listed
in Exhibit 6), the hiring of whom shall be complete no later than March 1, 2008. Client shall
coordinate with EFS regarding the termination of these employees and their subsequent hire by EFS.
Each of the hired employees shall be required to comply with all policies and procedures of EFS
which are generally applicable to its employees; provided however that levels of seniority and
tenure of hired employees (as they relate to vacation time, etc.) will carry over to EFS. Client
shall have

5

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 6 -->
input and approval rights regarding the hiring of key positions in connection with the Playboy
Commerce Business, including replacement personnel, which approval shall not be unreasonably
withheld. EFS agrees that ***** primary responsibilities will continue to be the Playboy Commerce
Business. (k) Keywords. EFS may use Playboy Marks as keyword-targeted advertising on any portal,
search engine or other website; provided, however that such use is directly related to the
Merchandise available on the Playboy Commerce Business or the promotion of the Websites. Any use of
Playboy Marks as keywords not directly related to Merchandise shall be subject to Client's prior
written approval. (l) Service Model Option. Client shall have the right upon not less than six (6)
months prior written notice to request that, at any time as of the third anniversary of the
Effective Date, EFS provide its services to Client via a "service model," in which case, upon
effective date of transition to a service model, EFS will no longer be a licensee but rather a
vendor. In such transition to a service model, the parties will work in good faith to establish a
reasonably equivalent economic benefit for EFS (adjusting for operational responsibilities and
economic risk being transferred to Client). The parties agree that Client will not be charged a
higher fee than what is being made available by EFS to its other Clients for similar services. The
terms of such arrangement will allow for Client to recognize the top-line revenues from the Playboy
Commerce Business as well as assume responsibility for various operations of the business as
determined by Client, with the remaining services to be provided by EFS. In such event, EFS shall
provide Client with all best practice services and tools that are provided to EFS' largest clients.
The parties further agree that in the event Client elects to receive services hereunder via the
"service model," during the transition to the service model, the operation of the Websites will
remain on the EFS core technology platform. (m) Insurance. EFS shall maintain at all times during
the Term of this Agreement insurance as provided below and shall name Client, its parent company,
subsidiaries and affiliated entities and their respective officers, directors, shareholders, agents
and employees as additional insureds to the extent of indemnity provided herein under its liability
policies as follows: (i) Commercial general liability insurance including premises/operations, broad
form property damage, independent contractors, and contractual liability covering EFS' obligations
hereunder for bodily injury and property damage, with a combined single limit of not less than
$1,000,000 each occurrence and $6,000,000 umbrella coverage; (ii) Workers' compensation insurance in
statutory amounts covering EFS and its employees; and (iii) Errors and omissions insurance, and
employer's liability insurance in an amount not less than $1,000,000 per accident/disease. (iv) All
insurance required above shall be carried with insurance companies licensed to do business in the
state(s) where operations are maintained with a rating

6

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 7 -->
of no less than A-. EFS shall deliver to Client, upon execution of the Agreement, certificates of
insurance as evidence of the required coverages. EFS agrees that these policies shall not be
canceled or materially changed without at least thirty (30) days' prior written notice to Client.
Such notice shall include written confirmation and details of replacement insurance coverages and
other material revisions to the policies, which shall be effective immediately upon any cancellation
or material change in EFS' policies in order that no gap in coverage results. 1.2. Obligations of
Client. (a) Client will provide instructions and specifications for linking to the Licensed Domain
Names (as defined in Section 7.3) from the EFS-hosted server. (b) Client will provide image and
descriptive content, the selection of which shall be at Client' discretion, related to the Client
Inventory (as defined in Section 2.2) as may be in Client's possession, subject to rights
availability and the license grant contained in Section 7.1 (collectively, the "Playboy Content"),
for use by EFS in connection with the Playboy Commerce Business. Client shall use commercially
reasonable efforts to ensure that all digital images provided to EFS conform to the file format and
size requirements specified by EFS. Client will use commercially reasonable efforts to provide EFS
with at least six (6) months notice prior to providing any new brand imagery, brand elements or
style guides, and EFS will prepare a time and action calendar for the updating of respective
sections of the Websites and/or Catalogs. (c) Client shall be solely responsible for the design and
maintenance of www.playboy.com (the "Playboy Site"). Client agrees to place a persistent shopping
button on the main navigation bar of the Playboy Site (with "Shop Playboy" or such other wording as
may be mutually agreed upon by the parties), and Client further agrees that the shopping button will
be located on the main navigation bar of all sub pages. Client will also promote the Playboy
Commerce Business with calls to action in its rotation of house ads throughout the Playboy Site (the
placement of which to be determined by Client in its sole reasonable discretion, taking into account
conversion rates and click-through success), with creative to be provided by EFS and approved by
Client. EFS acknowledges that the Playboy Site is currently undergoing a redesign. The parties will
work together in good faith to provide additional promotion on the Playboy Site of the Playboy
Commerce Business, which shall fit within context of the new design of the Playboy Site.
Notwithstanding the foregoing, Client agrees that the shopping button directing customers to the
Websites will continue to be located on the main navigation bar appearing above the fold on the
Playboy Site and all sub pages. Client and EFS will work together in good faith to provide
additional promotion of the Websites licensed by EFS. 2. Merchandise. 2.1. Merchandise Assortment.
(a) The Merchandise mix shall be determined by EFS in its reasonable discretion in operating the
business with input and collaboration from Client, provided that EFS agrees it will merchandise
individual items as directed by Client based on factors such as alignment with Client's retail
stores (for Bunny Shop only) or for new Client media initiatives (e.g., a new book, special edition
of PLAYBOY Magazine, etc.) with unit decisions made by

7

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 8 -->
EFS in its reasonable discretion. The parties agree that there will be regular merchandising
meetings between the parties to discuss sales performance, fashion, brand and retail trends, and
initiatives. It is contemplated that such meetings shall take place no less than once per month
during the first year of the Term and then no less than quarterly thereafter. (b) The parties agree
that the Merchandise mix as of the Effective Date for each of the Websites and Catalogs is an
approved baseline of categories and the general mix of Merchandise and that there will be no
material deviations from such mix without the mutual agreement of Client and EFS, provided however
that (i) EFS shall use commercially reasonable efforts to work with Client to align the
merchandising of the Bunny Shop with that of Client's retail stores and (ii) EFS shall collaborate
with Client to reduce the amount of unbranded (i.e., non-Playboy branded) apparel from its current
levels (currently ***** of all apparel and ***** of the total Merchandise mix), which shall in no
event comprise more than ***** of EFS' total Merchandise mix. For the avoidance of doubt,
Merchandise shall not include ticket sales to Client-sponsored or other events. For purposes of this
Agreement, the term "branded Merchandise" shall refer to Merchandise which contains or references
any of the Playboy Marks or is otherwise branded or labeled with a Playboy Mark, and the term
"unbranded Merchandise" shall refer to Merchandise which does not contain or make reference to any
of the Playboy Marks. (c) Notwithstanding the provisions of this Section 2.1, if Client determines
in its sole discretion that certain Merchandise must be removed or altered for legal reasons, EFS
shall promptly take such action required by Client. If Client requests that EFS change or
discontinue any Merchandise for reasons other than legal, Client will provide EFS with sufficient
notice and a reasonable sell-off period to minimize any disruption to the Playboy Commerce Business
and EFS shall comply. In the event that the Merchandise required to be removed is a current item
being sold and such removal results in an actual material impact on revenues or Merchandise Gross
Margin as demonstrated by EFS, EFS and Client will work together to agree on an equitable adjustment
to the Minimum Royalty. 2.2. Purchase and Use of Existing Inventory. EFS will purchase from Client
all existing product inventory of Merchandise held by or on behalf of Client in connection with the
Playboy Commerce Business, including, but not limited to, back issues of PLAYBOY Magazine held by
Client as of forty-five (45) days after as of the Effective Date hereof, as determined by Client
(collectively, the "Client Inventory"), as set forth in Section 6.6. During the Term, Client
Inventory supplied to EFS shall be sold by EFS solely through the Playboy Commerce Business. 2.3.
Transition Period. In addition, prior to launch of the Websites, Client (in collaboration with EFS)
shall purchase new and replenishment Merchandise on behalf of EFS for March 1, 2008 orders, with
such Merchandise to be shipped to EFS directly. For such orders, EFS shall pay the vendor in full,
with such payments to be made directly to each vendor in accordance with such vendor's payment
terms, and therefore, the Merchandise purchased in connection with March 1, 2008 orders shall not be
subject to the discount for Client Inventory set forth in Section 6.6. 2.4. Licensees. Client shall
notify each of its Licensees (as defined below) of the provisions of this Agreement relating to the
sale and provision of Merchandise to EFS. EFS

8

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 9 -->
shall be permitted to deal directly with and purchase Merchandise directly from those third parties
licensed by Client to produce products under the PLAYBOY brand ("Licensees"). EFS shall be free to
negotiate directly with Licensees, and Client will use commercially reasonable efforts to assist EFS
in securing favorable terms on pricing and service levels. EFS acknowledges, however, that Client
cannot guarantee that EFS will secure such favorable terms. EFS shall enter into separate agreements
with all Licensees and any such agreements shall supersede any agreement between Client and such
Licensee solely with respect to EFS' relationship with such Licensee, as approved by Client. 2.5.
International Sales. For a period of one (1) year after launch of the Websites, EFS shall be
permitted to fulfill orders placed by customers in the UK and Australia *****; provided, however
that: (a) EFS is solely responsible for the collection and remittance of all regulations, tariffs,
VAT and any other taxes or charges; and (b) during this period, EFS may not sell or otherwise ship
EFS Produced Merchandise apparel. During the foregoing one (1) year period (the "US Shipping
Period"), EFS shall be permitted to initiate negotiations for the terms of purchase of Merchandise
from local Licensees in the territories. In the event that EFS has not entered into meaningful
negotiations with any Licensee within three (3) months following the end of the US Shipping Period,
or if negotiations do not result in an actual agreement within six (6) months following the end of
the US Shipping Period, then Client may remove such market(s) from the Territory (as defined in
Section 3.4) in its sole discretion. 2.6. Manufacture of Merchandise. (a) Subject to provisions in
existing agreements as disclosed herein on Exhibit 7, which shall be updated from time-to-time,
Client's prior written consent and the Licensees' right of first refusal as set forth below, EFS
shall be permitted to design and manufacture, or arrange for third parties (which have been approved
by Client in advance in writing, said approval not to be unreasonably withheld) to manufacture on
its behalf, products branded with the Playboy Marks to be sold on the Websites and/or through the
Catalogs ("EFS Produced Merchandise"). EFS agrees that it shall approach Licensees regarding any
planned EFS Produced Merchandise and give such Licensees a seven (7) day right of first refusal with
respect to the design and manufacture thereof, whereby EFS may set forth commercially reasonable
requirements with respect to pricing, delivery and product specifications. If such Licensee is
unwilling or unable to comply with EFS' request, EFS shall be free to proceed with the manufacturing
of EFS Produced Merchandise as set forth in this Section 2.6. ***** (b) In EFS' discretion, EFS
Produced Merchandise may be created in any product categories where there is no exclusivity conflict
with a Client Licensee, as set forth in Exhibit 7. (c) Subject to Sections 2.6(a) and (b), EFS may
subcontract the manufacture of EFS Produced Merchandise, provided: (i) EFS notifies Client in
advance of any intended supplier/subcontractor and obtains Client's prior written approval of such
supplier/subcontractor, which shall not be unreasonably withheld; (ii) EFS obtains from each such
supplier/subcontractor an executed written agreement in the form substantially identical to that
attached hereto and made a part hereof as Exhibit 8; and (iii) furnishes a copy of each such
executed agreement to Client. EFS shall abide by, and shall ensure that any third-party

9

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 10 -->
supplier/subcontractor it uses to design and/or manufacture any EFS Produced Merchandise abides by
any design, manufacturing and other guidelines of Client. At the end of each Year of the Term hereof
and at any other time so requested by Client during the Term, EFS shall provide Client with an
updated list of the names and addresses of all manufacturing sources, subcontractors, suppliers and
others which have been engaged in the design and/or manufacture of EFS Produced Merchandise. (d) EFS
understands and agrees that any and all EFS Produced Merchandise and any other items bearing the
Playboy Marks or intended for use in connection with the EFS Produced Merchandise must be approved
in accordance with the approval process as set forth in Exhibit 9, attached hereto and hereby
incorporated by reference. In the event Client fails to provide its approval or disapproval of any
or all things submitted to Client pursuant to this Section 2.6(d) within fourteen (14) days of
Client's receipt thereof, EFS may send written notice to Client advising no response was received.
If Client does not respond within five (5) days of Client's receipt thereof, then Client shall be
deemed to have given disapproval. 2.7. Co-branding. EFS shall have the right to co-brand or
co-market certain Merchandise, combining a Playboy Mark with other current EFS clients, subject to
Client's approval at Client's sole discretion as to the co-brand partner, the Merchandise that will
be co-branded and the appearance of the branding on the Merchandise. Any co-branding with non-EFS
clients will be subject to prior written approval by Client on a case by case basis. The parties
agree that the co-branding or co-marketing of any Merchandise shall be subject to a separate
agreement to be negotiated between the parties, including provisions regarding the royalties to be
paid to Client for such Merchandise and any approval process to be followed. 2.8. Shopping Portal.
EFS shall be permitted to sell Merchandise on EFS owned and operated shopping portal websites ("EFS
Portals") subject in all respects to the standards, approvals and requirements applicable to the
sale of Merchandise on the Websites and provided that integration with third party brands and
products is acceptable to Client, approval not to be unreasonably withheld. EFS agrees that it will
use the merchandising presence on the EFS Portals to also market the Websites in order to drive
additional customer acquisition. 2.9. Mass-Customized Merchandise. Client agrees that
mass-customized Merchandise (i.e., Merchandise allowing consumers to choose customizable options,
including, but not limited to, color) shall be available for sale on the Websites and/or through the
Catalogs, such that customers may select and order pre-configured semi-customized Merchandise based
upon specifications that shall be agreed upon in advance by Client and EFS. EFS shall be responsible
for fulfilling orders of all semi- customized Merchandise, including fulfilling any build-to-order
or special features requested by the customer, as permitted during the order process. 2.10.
Exclusive Merchandise. Subject to Client's prior written approval in each case, EFS shall have the
right to work with Client's manufacturers for the production of Merchandise that will be designed
and offered for sale exclusively via the Playboy Commerce Business. 2.11. Merchandise. All EFS
Produced Merchandise, co-branded Merchandise, mass-customized Merchandise, exclusive Merchandise and
Client Inventory shall be deemed "Merchandise" for purposes of the calculation of Royalties (defined
below) to be paid by EFS.

10

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 11 -->
2.12. Merchandise Supplied to Client and Employees. EFS agrees to make Merchandise available to
Client for Client's own use, such as for events, photo shoots, gifts, etc. ***** when at least two
(2) weeks' notice is provided, and ***** when less than two (2) weeks' notice is provided. In
addition, employees of Client and EFS shall be permitted to purchase Merchandise through the Playboy
Commerce Business and shall receive a ***** discount on posted prices. Further, EFS acknowledges
that Client may offer discounts of up to ***** to Client's premium customers at Client's discretion
as part of a loyalty program or other promotional incentive, and EFS shall honor such discounts.
2.13. Product Quality. EFS hereby warrants and agrees that: (a) the Merchandise designed,
manufactured, advertised, promoted, sold or distributed under this Agreement shall meet the high
standards of quality, workmanship, material, design, size, color and style established by Client
from time to time and in accordance with the terms and conditions of this Agreement, provided that
EFS can rely on the approvals granted by Client pursuant to Section 2.6; (b) EFS will not knowingly
or negligently cause or authorize any or all of the Merchandise not conforming to this Agreement to
be sold or distributed, as doing so may adversely affect Client's goodwill in the Playboy Marks; and
(c) any such non-conforming Merchandise shall be destroyed at EFS' expense. All of the Merchandise
shall conform to and comply with, in all respects, all Laws governing the design, quality, labeling
and safety of such Merchandise and shall not violate the rights of any third parties. EFS shall not
cause, condone or authorize: (x) the use of any substandard or offensive materials in or in
connection with any of the Merchandise; (y) any violation of any Law, including, but not limited to,
provisions thereof imposing advertising standards or requiring trade or content description of the
Merchandise; or (z) the use of any Playboy Mark or any other word, device or symbol associated in
any way with any or all of Client and its subsidiaries and affiliates in connection with any product
or activity that is not the subject of this Agreement. 3. Territory. 3.1. International Sales. Upon
the launch of Websites, the exclusive territory for the Websites will include the USA, Canada, UK
and Australia (collectively, the "Website Territory"). For any market that is included in the
initial Website Territory or is added later, EFS agrees to (a) actively market, including, but not
limited to, via SEO (optimizing the Websites and creating custom pages to maximize search engine
optimization in local markets), search engine marketing and affiliate marketing, (b) provide local
billing and customized Websites for local audiences, vis a vis language and targeted merchandising,
and (c) provide competitive and timely fulfillment. Client agrees to register and maintain the
applicable domain name extensions in each such market, including .ca, .au, .com, and .uk for the
Websites; provided that such domain names are available. Client acknowledges that the functionality
for local billing will not be deployed by March 1, 2008, but will be deployed for the UK and
Australia not later than ninety (90) days following launch of the Websites. 3.2. Pilot Program.
Client agrees that within six (6) months of the launch of the Websites, Client and EFS will use
commercially reasonable efforts to collaborate on a strategy for an international expansion of the
customer base for the Websites beyond the established Website Territory and to identify up to two
(2) markets for a pilot test to actively market. If the test is successful as determined by Client
in its reasonable discretion, these markets will be added

11

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 12 -->
to the Territory under the terms of the Agreement. 3.3. Continuation of Current Online Business.
Client agrees that, barring cultural sensitivities, or regulatory or legal circumstances, EFS shall
be permitted to continue operating the Websites to fulfill international online business as is
currently being conducted. 3.4. Catalog Territory. Upon the launch of the Catalogs, the exclusive
territory for the Catalog will include the USA and Canada ("Catalog Territory"). The Website
Territory and the Catalog Territory shall be collectively referred to as the "Territory." The
parties agree that the Catalog Territory is the initial territory for the Catalogs and, within a
reasonable time period after the launch of the Websites, to discuss and agree upon the strategy for
the distribution of the Catalogs throughout the Website Territory. In the event that if within one
(1) year of launch of the Websites, EFS has not begun distribution of the Catalogs in the UK or
Australia, Client may, in its sole discretion: (a) rescind EFS' right to pursue such distribution;
and (b) either by itself or through third parties, effect Catalog distribution in those countries;
provided that in either case, EFS shall perform all order fulfillment in connection therewith in
accordance with the terms and conditions of this Agreement and provided the parties can reach
agreement on the financial terms associated with such services. 3.5. Pre-Existing Domestic and
International Partners. EFS understands that Client has pre-existing agreements internationally and
domestically (e.g., product Licensees, retail store partners, location-based entertainment venues
and media partners). EFS agrees that it will work in good faith with such Client partners to
identify areas of cross promotion and other synergies. 3.6. International Products. EFS understands
that certain markets will have their own product Licensees, and EFS will comply fully with all
restrictions (including, but not limited to, with respect to regulatory and brand issues) and
exclusive arrangements for all markets. Given that there may be different product margins in such
territories, the associated Royalty will be computed separately for international markets (pursuant
to Section 6.1(c)), as necessary. 4. Advertising Commitments. 4.1. Catalog Budget. EFS will commit
to an annual Catalog budget equal to or greater than *****, which represents ***** of the actual
amount spent by Client on the Catalogs for 2007. In addition, EFS shall use commercially reasonable
efforts to achieve a target in 2008 of not less than ***** of 2007 Catalog circulated pages. It is
EFS' intent to maximize both Website and Catalog sales, and the parties agree that they will
collaborate during the Term to define the budget and sales matrix to maximize sales in both channels
to bring the greatest overall sales growth. EFS shall have the right to decrease the Catalog budget
below the ***** minimum only if EFS can demonstrate that online marketing activities yield a higher
return-on-investment and provided all such reduced dollars are then reinvested in online marketing
spend over and above the minimum online marketing commitment described in Section 4.2, below.

12

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 13 -->
4.2. Online Marketing Budget. EFS understands and acknowledges that agreement to an online marketing
plan is critical to the success of the Playboy Commerce Business. Accordingly, EFS agrees it will
spend annually a minimum of ***** of Net Website Sales (as defined below) on online marketing
("Online Marketing Budget"). "Net Website Sales" shall mean total Merchandise sales derived through
the Websites via any order channel less applicable, actual Merchandise returns, if any, during the
applicable period. In the event such online marketing yields a ***** return or more on spend at an
average gross margin return on advertising of *****, then EFS will increase the Online Marketing
Budget as it deems appropriate to maximize sales of Merchandise. The Online Marketing Budget will be
used by the EFS marketing team to promote the PLAYBOY and BUNNY SHOP brands online, drive traffic to
and sales on the Websites, purchase search engine placement, drive affiliate sales and to
participate in other online marketing initiatives. In addition, EFS commits to continuous SEO
efforts during the Term to maximize discovery of, and algorithmic search results for, the Websites.
4.3. Corporate Marketing Commitments. Client agrees that the following marketing activities shall be
performed: (a) Client and EFS shall jointly issue a press release following the execution of this
Agreement announcing Client's selection of EFS as its end-to-end ecommerce services and platform
provider for the Websites; which release shall be subject to Client's final approval not to be
unreasonably withheld; (b) Subject to confidentiality obligations hereunder, EFS may prepare and
distribute a case study upon launching the Websites with respect to the business arrangement between
EFS and Client, subject to Client's prior written approval not to be unreasonably withheld; (c)
Subject to confidentiality obligations hereunder, EFS may to prepare and distribute a second case
study within three (3) to six (6) months of the launch of the Websites detailing the return on
investment resulting from the business relationship between Client and EFS, subject to Client's
prior written approval not to be unreasonably withheld; (d) Client shall provide a reasonable and
appropriate reference on behalf of EFS to EFS customers and potential customers contingent upon EFS'
successful implementation of services hereunder; (e) Client shall provide reasonable press and
investment analyst (in the event that EFS becomes a publicly traded company) support for articles,
interviews, and other public relations activities relating to the relationship between EFS and
Client. (f) EFS may not issue any press release or make any public statement concerning the subject
matter of this Agreement or the parties' relationship without Client's prior review and written
approval, which shall not be unreasonably withheld. EFS agrees to promptly make any changes
reasonably requested by Client to any public announcement, statement or use of Client's name and/or
intellectual property prior to any public release.

13

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 14 -->
4.4. Third Party Advertising. Client grants EFS the right to: (a) sell and place on the Websites
promotional banner advertisements (the frequency, placement and volume of which to be mutually
agreed upon by the parties) that advertise and market third party products and services that do not
compete with Client's products or services and comply with Client's advertising guidelines
("Advertisements"), provided that such advertising efforts are mutual (i.e., equivalent promotion of
Client and its affiliates on third party websites) and are executed in a manner that minimizes
adverse impact on sales; and (b) send emails containing Advertisements to customers who specifically
opt in to receive email notifications from EFS and Client. All Advertisements on the Websites and
emails to Playboy Commerce Business customers will require the prior written consent of Client
(which will not be unreasonably withheld or delayed). EFS shall provide quarterly reports detailing
page exits, abandonment rates and overall Website conversion rates. If Client determines based upon
such reports that any such advertising is adversely impacting Website conversions, EFS will, at
Client's direction, cease placing Advertisements on the Websites and/or sending third party
Advertisement emails. Client shall be entitled to receive an Advertising Fee in connection with the
sale of Advertisements as set forth in Section 6.4. (a) EFS shall be responsible for maintaining the
Advertisements on the Websites. EFS shall ensure that the Advertisements do not violate any Law or
right of any third party or otherwise contain content reasonably likely to diminish the value of
Client's brand or detract from the goodwill of the Client. Upon written request of Client, EFS shall
discontinue or modify any Advertisement that in the reasonable opinion of Client is not appropriate
for the Client brand or is competitive with Client business. 4.5. Promotion of Client Partners. At
no additional cost to Client, EFS will continuously and prominently promote Client's related
businesses on the Websites and in emails to customers confirming orders, including without
limitation PLAYBOY- branded online, publishing and television properties, or such other businesses
as Client may request from time to time; provided, however, that in the event any such promotional
activities interfere with or diminish sales on a Website, as demonstrated by EFS to Client's
reasonable satisfaction, EFS shall be permitted to reduce or restructure such promotions as
reasonably necessary to improve sales on the applicable Website. EFS shall be responsible for
determining the timing, frequency and scope of all such promotional activities with input from
Client. Creative shall be provided by Client at Client's expense. Where there is traceable resulting
commerce from the above activities, EFS will be entitled to Client's then current standard bounties
or affiliate fees. 4.6. Catalog Inserts & Packaging Onserts. At Client's cost for materials (but
excluding costs for labor or other EFS charges), EFS agrees to include up to two (2) inserts per
month in each of the Catalogs and up to two (2) onserts per month in all outgoing Merchandise
packaging, promoting Client products and services and/or those of Client's affiliates, Licensees or
sponsors. Client shall be responsible for all creative and printing costs associated with such
inserts and onserts. EFS may include onserts in product packaging but only with the prior written
approval of Client, not to be unreasonably withheld. 5. User Agreements and Data.

14

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 15 -->
5.1. Terms of Use & Privacy Policy. (a) EFS shall prominently display, as is customary in the
industry, and implement a terms of use policy ("TOU") on the Websites, which shall comply with all
applicable Laws and which at a minimum prohibits orders from any customer under eighteen (18) years
of age (or the applicable age of majority in the jurisdiction in which the customer resides) and
explains EFS' purchasing and return policies. EFS shall implement a privacy policy ("Privacy
Policy") applicable to users of the Websites and the Catalogs that is no less protective of user
privacy than is required under the Laws of or otherwise applicable to the Territory. Such Privacy
Policy shall be prominently displayed, as is customary in the industry, within the Websites and the
Catalogs and be easily accessible to users. EFS shall not take any action, and shall not operate the
Websites or the Catalogs, in contravention of such Privacy Policy or of any applicable Law,
including, but not limited to, data protection provisions imposed by the United Sates, the European
Union or the other countries of the Territory and other applicable Laws. (b) Client shall have the
right to review the TOU and Privacy Policy, to require reasonable changes thereto (subject to
applicable Laws), and to request certification from EFS that it is complying with this Section 5.1.
All such requests shall be promptly met. 5.2. Information on Usage and Users. EFS shall be solely
responsible for and shall ensure the security of all customer data collected in connection with the
Playboy Commerce Business, including, but not limited to, personally identifiable information and
transaction information (collectively, the "User Data"). Client and EFS shall jointly own and have
rights to all User Data collected hereunder provided, however, that EFS shall only use the User Data
in strict accordance with the Privacy Policy and, subject to the remainder of this Section 5, solely
in connection with the Playboy Commerce Business. EFS shall gather, retain in its records, and take
all necessary measures (which may include disclosure in the Privacy Policy and/or an opt-in
mechanism) in order to provide such User Data to Client, as well as information on usage and viewing
of the Websites and such additional information as Client may reasonably request. EFS warrants that
it has implemented and will maintain during the Term of this Agreement an information security
program that is reasonably designed to: (a) ensure the security, integrity and confidentiality of
User Data collected hereunder; (b) protect against anticipated threats or hazards to the security or
integrity of User Data; and (c) protect against unauthorized access to or use of User Data. EFS
agrees that included in EFS' information security program are policies and administrative and
technical measures specifically prohibiting and preventing the placement of User Data in or on any
form of mobile media (e.g., CD's or flash drives and other external storage media). EFS shall notify
Client immediately in the event EFS believes that User Data collected hereunder has been or
potentially could have been accessed by an unauthorized individual and shall cooperate with Client
and indemnify Client regarding any investigation or response to a security breach, including any
claims, notifications or protection of Client's employees related therewith. 5.3. Existing User
Data. Client holds certain customer data relating to the Playboy Commerce Business ("Existing
Customer Data") and hereby grants to EFS a non-exclusive, limited, non-sublicensable,
non-transferable, revocable license to store and use such Existing Customer Data solely for purposes
of the operation and promotion of the Playboy Commerce

15

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 16 -->
Business. To the extent that EFS makes available to Client any customer data previously collected by
EFS and permitted to be disclosed to Client ("EFS Customer Data"), EFS shall retain ownership of
such EFS Customer Data and Client shall have the right to use such user data solely in connection
with the Websites. Existing Customer Data shall be deemed User Data for purposes of this Agreement;
provided, however, that notwithstanding anything to the contrary in Section 5.2, Existing Customer
Data shall be owned solely by Client. 5.4. Reporting and Use of User Data. Upon request from Client,
EFS agrees to provide to Client any and all User Data generated hereunder and such reports as
reasonably requested by Client from time to time relating to User Data. EFS shall use User Data
solely for purposes of the operation and promotion of the Playboy Commerce Business, and except as
specifically approved in advance in writing by Client, shall not use such User Data to market any
other EFS or third-party products or services to users or otherwise use, transfer or sell any User
Data collected hereunder. Notwithstanding the foregoing, EFS may use and exchange User Data in
accordance with standard DMA practices for purposes of customer prospecting solely in order to grow
the Playboy Commerce Business. EFS shall not cross-market between the PLAYBOY-branded Catalog and
Website and the BUNNY SHOP-branded Catalog and Website. Client may use User Data free of charge and
in any manner (including, to the extent permitted by applicable Laws, sharing such data with its
affiliates and partners). Client reserves the right to periodically audit EFS' customer lists to
ensure compliance with this Section 5.4 provided, however, that any such audit shall be performed at
the offices of EFS (or at such other location(s) as EFS' customer lists may be held) and conducted
in such a manner so as to preserve EFS' customer lists as a trade secret. In no event shall Client
be permitted to copy, possess, or use EFS' confidential customer data other than to ensure
compliance with this Section 5.4. 5.5. Opt-In List. EFS shall be permitted to offer customers who
visit the Websites the option to receive emails from EFS concerning the Merchandise as well as
offers by EFS or third-parties with which EFS has an established relationship and which have been
approved in advance in writing by Client. Any customers who do not specifically opt-in to receiving
email communications from EFS shall be excluded from such communications. 5.6. Demographic Data. EFS
shall be permitted to collect demographic data from customers that visit the Websites, which shall
include: IP address, geographic information regarding the location of the customer (i.e., zip code,
area code, city, state and country), age, and gender ("Demographic Data"). Client and EFS shall
jointly own and have rights to all Demographic Data collected hereunder. 5.7. Analysis of User Data
and Demographic Data. EFS shall have the right to analyze the User Data and Demographic Data for a
variety of purposes including, but not limited to, performing market studies, trend reporting, sales
performance, demographic studies and comparison/analysis with third party market data and consumer
purchasing information ("EFS Analysis"). EFS shall be permitted to combine the EFS Analyses with
other EFS studies and, further, to share the EFS Analyses with third parties provided that no
proprietary information of Client or personally identifiable information of consumers is disclosed
to such third parties. 6. Payments and Fees.

16

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 17 -->
6.1. Royalties. EFS shall pay a royalty ("Royalty") to Client to be calculated and paid as follows:
(a) the Royalty shall be determined based upon the percentage applicable to the Merchandise Gross
Margin (pursuant to the chart in Exhibit 10, attached hereto and hereby incorporated by reference);
(b) multiplied by the Net Merchandise Sales (as defined below) as applicable in each case for the
applicable Calendar Quarter or Year (each as defined below). The Royalty calculation period shall
begin upon the first order received by EFS via any order channel (e.g., on a Website, via mail, fax
or telephone) and shall be paid to Client within fifteen (15) days following the conclusion of each
calendar quarter ("Calendar Quarter") based on the calendar year ("Year"), as calculated on the
actual Merchandise Gross Margin and Net Merchandise Sales (each as defined below) for such Calendar
Quarter. (a) For purposes of this Agreement, "Merchandise Gross Margin" shall be defined as the Net
Merchandise Sales through the Playboy Commerce Business during the applicable Calendar Quarter or
Year, less (i) the actual unit cost of goods sold paid by EFS for the manufacture of such goods,
which shall not include expenses relating to overhead or allocations, (ii) reductions for markdowns,
discounts and allowances, and (iii) actual Merchandise inventory shrinkage during the same period,
which shall in no event exceed *****. The Merchandise Gross Margin scale for purposes of calculating
the Royalty shall be determined from Exhibit 10 based upon the Minimum Royalty (as defined in
Section 6.2) set forth in Exhibit 10. (b) For purpose of this Agreement, "Net Merchandise Sales"
shall be defined as total Merchandise sales derived through the Playboy Commerce Business via any
order channel less applicable, actual Merchandise returns, if any, during the applicable Calendar
Quarter. (c) Pursuant to Section 3.6, EFS shall pay a quarterly Royalty to Client calculated as set
forth in Section 6.1 using separate Royalty percentages on a country-by-country basis based on
product margins for each such country, as agreed upon by the parties. 6.2. Minimum Royalty.
Notwithstanding revenue actually generated by EFS in connection with the Playboy Commerce Business
hereunder, it is understood and agreed that the Royalty paid to Client in each Year of the Term
shall not be less than the amounts set forth in Exhibit 10 (the "Minimum Royalty"). In the event the
Minimum Royalty is not achieved in any Year based on the Royalty payments made in such Year, EFS
shall pay the shortfall between the Royalty earned and the applicable Minimum Royalty due, if any,
within sixty (60) days of the end of such Year. (a) In the event that the Minimum Royalty is met in
any applicable Year, (i) EFS shall not be permitted to carry over any overages into the next Year
and (ii) EFS will not be eligible for any refund from any Minimum Royalty or Royalty previously owed
or paid to Client. In the event EFS does not meet the full amount of the Minimum Royalty during the
applicable Year in which such Minimum Royalty was owed to Client, EFS will not be permitted to
offset the shortfall with any overages from any previous or subsequent Year, and a new Minimum
Royalty will be due as set forth in this Section 6.2. For the avoidance of doubt, the Minimum
Royalty is a minimum net sum from which no taxes or charges of any sort may be deducted.

17

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 18 -->
(b) In the event that this Agreement is terminated prior to the end of the Initial Term, any portion
of the Year 1 Minimum Royalty that has been spread across Years 2 through 5 of the Term pursuant to
Exhibit 10 and which has not yet been paid to Client, shall immediately become due and owing. 6.3.
Royalty on Shipping Charges. In addition, Client shall be entitled to receive a royalty payment on
the shipping and handling charges paid by customers during the applicable Calendar Quarter
("Shipping Royalty") equal to the Royalty percentage multiplied by the shipping profit. For purposes
of this Section 6.3, the shipping profit shall be calculated as the gross charges for shipping less
shipping materials, cost of freight and dunnage. The Shipping Royalties paid to Client shall be
counted towards the Minimum Royalty for the applicable Year. If there is no shipping profit, Client
shall not be owed any Shipping Royalty, nor will Client be impacted by any shipping losses. 6.4.
Advertising Revenues. Client shall be entitled to receive an advertising fee of ***** of the Net
Advertising Revenue derived by EFS from Advertisements pursuant to Section 4.4 ("Advertising Fee").
"Net Advertising Revenue" shall be defined as the gross revenue derived from the sale of
Advertisements less: (a) all direct costs (i.e., commissions and ad-server related fees) incurred by
EFS and third party fees paid out by EFS for the execution, maintenance and ongoing facilitation of
Advertisements on the Websites and (b) ***** of gross revenue derived from the sale of
Advertisements, which shall be reinvested by EFS for online promotions and advertising ("Advertising
Marketing Allocation"). Neither Net Advertising Revenue nor the Advertising Fee shall be counted
toward the Minimum Royalty obligation of EFS. 6.5. Payment of Royalties; Reports. Except as
otherwise specifically set forth, all fees due to Client shall be due and

payable on or before the fifteenth (15t h) day following the applicable Calendar Quarter. EFS shall
use commercially reasonable efforts to provide within three (3) days, but in no event later than
five (5) days, following such Calendar Quarter, regardless of whether any payment is due, a report
that includes at a minimum: (a) gross sales broken down by each Website, Catalog and product, gross
shipping charges and gross advertising revenue generated during such Calendar Quarter; (b) a
detailed calculation of Merchandise Gross Margin, Net Merchandise Sales, shipping profit and Net
Advertising Revenue; (c) a detailed calculation of the Royalty, Shipping Royalty and Advertising Fee
payable to Client for such Calendar Quarter; (d) Client's aggregate Royalty, Shipping Royalty and
Advertising Fee earned and paid to date; and (e) such other information as may be requested by
Client from time to time. In addition, EFS shall provide to Client interim monthly reports. 6.6.
Purchase of Product Inventory. Pursuant to Section 2.2, EFS shall pay Client a non-refundable
purchase price of ***** of the wholesale price (i.e., the Client's original cost) as determined as
of forty-five (45) days after the Effective Date for all Client Inventory. Such amount shall be paid
Net ninety (90) days following entry of such Client Inventory into EFS' system; provided, however,
that EFS shall enter all such Client Inventory upon receipt or shall promptly notify Client in the
event it is unable to do so due to missing information (i.e. barcodes) or because any product is
incomplete or otherwise in a condition not fit for immediate resale.

18

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 19 -->
6.7. Method of Payment. All payments required to be made by EFS hereunder shall be made by
electronic transfer of immediately available funds in United States Dollars through a bank
designated by Client. In the event that EFS receives orders through the Playboy Commerce Business or
otherwise hereunder involving foreign currency, in order to determine the proper rate of exchange to
be applied to the payments due hereunder, it is agreed that EFS shall calculate such payments on a
Calendar Quarter basis in local currency (with each such quarter considered to be a separate
accounting period for the purpose of computing the payments) and that EFS shall compute a conversion
of each such Calendar Quarter total into United States Dollars utilizing the selling rate of
exchange in effect on the last day of each relevant Calendar Quarter as quoted by Reuters in the
Wall Street Journal. 6.8. Costs and Expenses. Unless expressly stated otherwise in this Agreement or
otherwise agreed in writing, each party shall be responsible for any costs or expenses incurred by
it in connection with its obligations under this Agreement. 6.9. Taxes. As between the parties, EFS
shall be responsible for, without limitation, any tax, duty, levy, income, royalty, withholding tax
or charge required by any Law now in effect or hereafter enacted (other than Client's direct net
income taxes) including, without limitation, sales, use, value-added, property, royalty and excise
or other similar taxes, licenses, import permits, state, county, city or other taxes arising out of
or relating to this Agreement. EFS will be responsible for the timely notification, remittance,
filing and reporting of all such taxes to the proper tax authorities at the rates required by Law.
6.10. Accounting Reports. EFS shall provide, at its sole expense: (a) Client acknowledges that EFS
is not currently able to provide a SAS 70 Type II Report. EFS will endeavor to become SAS 70
compliant and once compliant, shall provide a SAS 70 Type II Report to Client or its affiliates.
Until EFS becomes compliant EFS may provide an alternative report acceptable to Client or its
affiliates. Reports pursuant to this Section 6.10(a) shall be provided for the one-year period
ending September 30th of each year by December 31st of each year of the Term; and (b) A copy of EFS'
Independent Auditors' Report and audited balance sheet for each Year of the Term within thirty (30)
days of the close of such audit. 6.11. Verification of Information; Audit Right Generally. During
the Term of this Agreement and for two (2) years thereafter, (a) EFS shall maintain complete and
accurate books and records relating to revenue generated under this Agreement; and (b) Client and/or
its authorized representative(s) shall have the right to examine, review, copy and audit EFS' books
and records relating to revenue generated under this Agreement to verify the accuracy of the
payments and associated information provided by EFS and to verify EFS' compliance with the terms and
conditions of this Agreement. If the result of the audit reveals deviations that indicate that
Client was underpaid, EFS shall immediately pay the sum of such underpayment plus interest at a rate
of ***** from the date such payment was first due. If the result of the audit reveals deviations by
***** or more for any one year of the Term, EFS shall pay the sum due plus interest as set out above
and shall further bear the reasonable costs and expenses associated with audit.

19

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 20 -->
7. License Grants 7.1. Playboy Content. During the Term and subject to the terms, conditions, and
limitations set forth in this Agreement, Client grants EFS a limited, non-exclusive,
non-transferable, non-assignable (without any right to sublicense), world-wide license to use,
modify, create derivative works of, publish, reproduce, broadcast, exhibit and display the Playboy
Content solely in connection with the design, publication, distribution, operation and promotion of
the Playboy Commerce Business. (a) In the event that EFS creates any modifications, alterations or
other derivative works of any Playboy Content ("Derivative Works"), EFS hereby irrevocably assigns
to Client all right, title and interest in and to all of those Derivative Works, including the
copyrights and other proprietary rights therein. EFS further agrees to cooperate with Client's
reasonable requests to effect or perfect such assignment and hereby provides Client with an
irrevocable power of attorney appointing Client as EFS' irrevocable attorney-in-fact coupled with an
interest to execute all such assignments on behalf of EFS. All Derivative Works are hereby licensed
back to EFS subject to the limitations that are applicable hereunder to the Playboy Content. EFS
shall deliver to Client all original versions of Derivative Works upon the request of Client. 7.2.
Client Trademarks. During the Term and subject to the terms, conditions, and limitations set forth
in this Agreement, Client grants EFS a limited, non-exclusive, non-transferable, non-assignable
(without any right to sublicense), world-wide license to use the Client trademarks and/or service
marks as set forth on Part A of Exhibit 1 (the "Playboy Marks") solely in connection with the
design, publication, distribution, operation and promotion of the Playboy Commerce Business. Except
in connection with marketing obligations hereunder or as otherwise expressly permitted by Client in
writing, EFS shall not use any Playboy Mark on or in connection with, or to permit or facilitate any
presentation or promotion of, any Internet website(s) other than the Websites or any other catalog
other than the Catalogs. (a) Use of Playboy Marks. EFS recognizes and acknowledges that the Playboy
Marks are internationally well- known by the general public and are associated in the public mind
with Client's affiliate, Playboy Enterprises International, Inc. ("PEII"), and are marks in which
PEII has acquired considerable and valuable goodwill. EFS acknowledges that Client and PEII have an
interest in maintaining the worldwide goodwill, recognition and standards of the Playboy Marks.
Consequently, with respect to uses of the Playboy Marks in the normal course of business (i.e., for
marketing and promotional purposes), EFS shall submit representative samples of such uses to Client
as soon as practicable for purposes of post-use audit. If as a result of any post use audit, Client
determines in its reasonable discretion that the use of a Playboy Mark is improper or inappropriate,
Client will notify EFS, and EFS shall correct the problem as soon as reasonably practicable. Any
uses not in the ordinary course must be approved in advance in writing by Client, and Client shall
have the right to require EFS to make any changes and/or corrections with regard to the Playboy
Marks as Client may reasonably deem necessary to maintain the quality standards and the goodwill
associated with the Playboy Marks. EFS agrees to make and incorporate such changes or corrections
promptly upon notice from Client and at EFS' sole cost and expense.

20

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 21 -->
(b) Modifications of Playboy Marks. EFS may modify or alter the Playboy Marks or combine the Playboy
Marks with any other words or symbols only if, and to the extent that, Client shall have authorized
such modification or alteration or combination specifically in advance in writing. Any such
permitted modification/alteration and/or combination shall be referred to herein as an "Authorized
Modification." No such authorization by Client shall constitute a representation or warranty that
use of the Authorized Modification(s) by EFS or by anyone else will not violate the rights of others
in any jurisdiction or that such Authorized Modification will constitute an enforceable trademark in
any jurisdiction. (c) Assignment of Authorized Modifications. EFS hereby irrevocably assigns, and
Client hereby accepts, all right, title and interest in and to each and every Authorized
Modification, and EFS agrees to cooperate with all reasonable requests by Client to effect or
perfect such assignment. All Authorized Modifications (if any) are hereby licensed back to EFS
subject to the limitations applicable to the Playboy Marks hereunder. (d) Goodwill. EFS will not
obtain any right, title or interest in the Playboy Marks by virtue of their use of the Playboy Marks
under this Agreement and any additional goodwill associated with the Playboy Marks that is created
through use of the Playboy Marks shall inure solely to the benefit of PEII. (e) Variations. During
and after the Term, EFS will not apply for or use any domain names, trademarks or service marks that
include or are confusingly similar to any of the Licensed Domain Names (as defined in Section 7.3,
below), Playboy Marks or any other similar marks or variations thereto. (f) Notices. EFS must
display on the Websites and Catalogs such trademark and copyright notices as requested by Client
and/or as required by applicable Law. Except as expressly approved in writing by Client, neither the
Playboy Marks nor any notices associated therewith may be changed, manipulated or modified in
appearance. 7.3. Domain Names. During the Term and subject to the terms, conditions and limitations
of this Agreement, Client hereby grants EFS, a limited, non-transferable, non-assignable (without
any right to sublicense) world-wide license to use the Internet location or resource designators
(URLs, domain names, etc.) set forth in Part B of Exhibit 1 hereto, and/or to the extent approved in
advance in writing by Client, as the case may be, modifications thereof (the "Licensed Domain
Names"), as the domain name(s) and Internet locators/designators for the Websites during the Term.
The Licensed Domain Names shall at all times be owned by PEII as registrant. Client agrees that the
registration for the Licensed Domain Names and for any successor URL's shall be maintained and that
EFS shall remain the technical contact for the duration of the Agreement. If EFS desires to use any
other domain names or Internet locators/designators in connection with the Websites, Micro Sites or
otherwise utilizing PLAYBOY- or PLAYBOY-related marks, EFS shall so notify Client, which may at its
sole discretion, choose to register the same at its expense. Any such additional domain names or
Internet locators/designators shall be owned by PEII as registrant, and EFS shall receive a limited
license to use the same as Licensed Domain Names hereunder, solely in connection with the Websites
and/or Micro Sites during the Term. Unless otherwise agreed by the parties in

21

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 22 -->
writing, the Licensed Domain Names shall at all times remain on PEII servers and will be redirected
to the Websites. 7.4. Client Take-Down Rights. Despite conformity to the Guidelines and/or the terms
and conditions of this Agreement and/or the prior written approval by Client, Client shall be
entitled to review all uses of the Playboy Marks and all utilizations of the Playboy Content at any
time and in its sole discretion. Client shall be entitled to require alteration or termination of
any specific use if it determines in its reasonable and good faith discretion that such action is
necessary or appropriate and EFS shall promptly comply with any such demand. Nothing in this Section
7.4 shall create any obligation on the part of Client to identify or prevent improper uses of
material or inclusion of improper material in connection with the Playboy Commerce Business, nor
shall Client or its affiliates have any liability for nonfeasance, negligence, or other conduct in
such reviews or for failing to conduct any such reviews. 7.5. Exclusions. Nothing in this Agreement
shall restrict Client (or its affiliates) from the following commerce activities in the Territory:
any DVD commerce (rental or sales), sales by product Licensees via third-party commerce websites or
mail order sales or similar activities. In addition, EFS agrees that Client's location-based
entertainment partners, as listed in Exhibit 11, attached hereto and hereby incorporated by
reference, which may be updated from time to time, may engage in limited e- commerce activities
primarily, but not limited to, for co-branded products (e.g., Playboy at the Palms co-branded
merchandise). 8. Confidentiality. 8.1. Confidential Information. EFS and Client each acknowledge
that during the Term of this Agreement each party may have access to the proprietary or trade secret
information of the other concerning the other's business affairs, property, methods of operation,
processing system or other information provided by the disclosing party to the receiving party that
is identified as, or should reasonably be understood to be (given its content or the circumstance of
its disclosure), proprietary (collectively, the "Confidential Information"). Information shall not
be considered Confidential Information under this Agreement that the recipient can document: (a) is
publicly known prior to or after disclosure hereunder other than through acts or omissions
attributable to the recipient or its employees or representatives; (b) is already known to the
recipient at the time of disclosure hereunder without reference to the disclosing party's
Confidential Information; (c) is disclosed in good faith to the recipient by a third party having a
lawful right to do so; (d) is the subject of written consent of the party which supplied such
information authorizing disclosure; or (e) is independently developed by the receiving party without
reference to Confidential Information of the disclosing party. 8.2. Obligations. EFS and Client each
agree to use the Confidential Information of the other party solely to the extent necessary to
fulfill its obligations or exercise its rights hereunder, and not for any other purpose. Each party
agrees (a) that it will not disclose to any third party or use any Confidential Information
disclosed to it by the other except as expressly permitted in this Agreement and (b) that it will
take all reasonable measures to maintain the confidentiality of all Confidential Information of the
other party using at least the degree of care and security as each uses to maintain the
confidentiality of its own Confidential Information. Notwithstanding the foregoing, each party may
disclose Confidential Information (x) to their officers, directors,

22

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 23 -->
employees, agents, attorneys and consultants who need to know such information and who are bound by
restrictions regarding disclosure and use of such information comparable to and no less restrictive
than those set forth herein, (y) as required by applicable Law, provided that in the case of any
filing with a governmental authority that would result in public disclosure of the terms hereof, the
parties shall mutually cooperate to limit the scope of public disclosure to the greatest extent
possible; and (z) to the extent required by a court of competent jurisdiction or other governmental
authority or otherwise as required by Law, provided that the receiving party uses reasonable efforts
to provide the disclosing party with prior notice of such obligation in order to permit the
disclosing party a reasonable opportunity to take legal action to prevent or limit the scope of such
disclosure. 9. Ownership. 9.1. In General. Each party hereby reserves for itself all rights not
specifically granted to the other party in this Agreement. Each party will use good faith efforts to
cooperate with the other party in the protection of their intellectual property rights. 9.2. EFS. As
between the parties, EFS retains ownership of, and all right, title and interest in and to any
intellectual property including trademark, trade name, patent, copyright, technology, trade secret,
software, source code or know-how created for or relating to the Playboy Commerce Business that was
affixed to, used with or incorporated into the Playboy Commerce Business by EFS, but specifically
excluding the Client Property, as defined below (collectively, the "EFS Property"). Nothing
contained in this Agreement shall be deemed to transfer or convey to Client any ownership rights
whatsoever in or to the EFS Property or grant any license to the EFS Property other than in
connection with the Playboy Commerce Business. To the extent that Client is deemed to obtain any
interest or ownership rights in the EFS Property, Client hereby assigns, transfers and conveys to
EFS, to the maximum extent permitted by applicable Law, all of Client's right, title and interest
therein used by Client under or in connection with this Agreement so that EFS will be the sole owner
of all rights therein and further agrees to cooperate with EFS during and after the Term to effect
and perfect all assignments. 9.3. Client. As between the parties, Client retains ownership of, and
all right, title and interest in and to any and all Playboy Marks, Playboy Content, Derivative
Works, Licensed Domain Names, User Data and any other materials provided by or on behalf of Client
to EFS hereunder, which are incorporated in or are otherwise related to the Playboy Commerce
Business (collectively, the "Client Property"). Nothing contained in this Agreement shall be deemed
to transfer or convey to EFS any ownership rights whatsoever in or to the Client Property. To the
extent that EFS is deemed to obtain any interest or ownership rights in the Client Property, EFS
hereby assigns, transfers and conveys to Client, to the maximum extent permitted by applicable Law,
all of EFS' right, title and interest therein used or created by EFS under or in connection with
this Agreement so that Client will be the sole owner of all rights therein and further agrees to
cooperate with Client during and after the Term to effect and perfect all assignments. 10. Term and
Termination.

23

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 24 -->
10.1. Term. This Agreement shall commence as of the Effective Date and, unless earlier terminated as
provided under this Agreement, shall terminate five (5) years following the date of launch of the
first Website, but in no event later than February 28, 2013 (the "Initial Term"). This Agreement
shall automatically renew for an additional period of three (3) years (such renewal and each
subsequent renewal shall be defined as a "Renewal Term") provided that EFS achieves Net Merchandise
Sales of at least ***** during the fourth year following launch of the first Website. In such event,
the annual Minimum Royalty during the Renewal Term, if any, shall be equal to the greater of: (a)
***** of the actual Royalty paid to Client in Year 5; and (b) *****. The Initial Term and any and
all Renewal Terms shall be collectively referred to as the "Term." 10.2. Termination for Breach.
Each party shall have the right to terminate this Agreement, in whole or in part, if the other party
materially breaches this Agreement and such breach is not cured within thirty (30) days' written
notice from the non- breaching party. 10.3. Termination for Bankruptcy. Each party shall have the
right to immediately terminate this Agreement if the other party (a) is involuntarily made subject
to any bankruptcy or insolvency proceedings and such proceedings are not dismissed within sixty (60)
days of the filing of such proceedings or (b) voluntarily institutes any bankruptcy or insolvency
proceedings, corporate reorganization, liquidation, assignment for the benefit of creditors, or
appointment of a receiver or trustee. 10.4. Effects of Termination. Upon and after the termination
of this Agreement (the "Termination Date"): (a) All accrued and unpaid amounts shall become
immediately due and payable, including the pro rata amount of the annual Minimum Royalty for the
applicable Year based upon the Termination Date; (b) All licenses granted pursuant to this Agreement
shall immediately terminate; (c) EFS shall cease the display and use of the Playboy Content,
Derivative Works, Playboy Marks, Authorized Modifications, Licensed Domain Names in any manner; (d)
EFS shall return any and all Playboy Content and Derivative Works to Client within five (5) business
days of the Termination Date; (e) Each party will promptly, at the direction of the other party,
return or destroy any and all Confidential Information of the other party in any medium and all
copies thereof; (f) EFS shall discontinue the use of any User Data collected hereunder, and subject
to applicable Laws, shall promptly deliver and assign all User Data to Client per Client's
instructions; and

24

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 25 -->
(g) If so requested by Client in connection with a planned or potential continuation of the
business, EFS shall cooperate with Client and its affiliates in order to transfer any remaining
operations to them or any other entity that Client may so designate without interruption of the
Playboy Commerce Business' availability. 10.5. Outstanding Orders. As of the Termination Date, EFS
shall not process any new orders placed through the Playboy Commerce Business. Notwithstanding the
foregoing, EFS may fulfill any outstanding orders placed through the Playboy Commerce Business prior
to the Termination Date and may continue collection activities related thereto, which shall be
subject to Section 6 hereof. 10.6. Survival. Sections 6.11, 7.5, 8, 9, 10.4, 10.5, 10.6, 11.4, and
12 through 14 shall survive any expiration or termination of this Agreement. In addition, Sections
6.1 through 6.10 shall survive any termination of this Agreement until all amounts due in connection
with activities during the Term are paid and all reports provided. 11. Warranties and Disclaimers.
11.1. By Both Parties. Each party represents and warrants that (a) it has the full right and
authority to enter into this Agreement, perform its obligations and grant the rights and licenses
granted hereunder; and (b) its execution, delivery and performance of this Agreement will not result
in a breach of any material agreement or understanding to which it is a party or by which it or any
of its material properties may be bound. 11.2. By EFS. EFS further represents and warrants that (a)
the Websites and the Catalogs and all content contained therein (but specifically excluding the
Playboy Marks and Playboy Content) do not and will not infringe any intellectual property right of
any third party; (b) it has all necessary intellectual property rights in and to the Merchandise to
be offered for sale through the Playboy Commerce Business; (c) it will at all times abide by and
comply with the Privacy Policy and all other Laws applicable to operation of the Playboy Commerce
Business, including, but not limited to the CANSPAM Act of 2003 and those related to privacy; (d) it
(i) shall use its best efforts to ensure that all performers featured in any content and/or
Merchandise offered for sale through the Catalogs and/or the Websites were at least eighteen (18)
years of age at the time of production and (ii) shall comply with all record keeping, labeling and
other requirements pursuant to Section 2257, as the same may be amended from time to time; (e) it
will at all times take commercially reasonable steps to ensure the accuracy of all information
contained on the Websites and in the Catalogs; and (f) the Playboy Commerce Business, including,
without limitation, the Catalogs and Websites and all aspects thereof, will be operated in a
workmanlike, timely and professional manner consistent with industry standards and EFS' operation of
other third-party branded commerce offerings. 11.3. By Client. Client further represents and
warrants that it has the full right and authority to grant the rights and licenses to the Playboy
Marks, the Licensed Domain Names and Playboy Content set forth herein.

25

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 26 -->
11.4. Disclaimer. Except as expressly set forth in this Agreement, and to the extent permitted by
Law, each party expressly disclaims all warranties and representations, whether express, implied or
statutory, including any implied warranty of merchantability, non-infringement or fitness for a
particular purpose. Client does not warrant that the Playboy Content will be error-free or will meet
EFS' specific needs. Client makes no warranty whatsoever regarding the accuracy of the information
contained in the Playboy Content. 12. Indemnification. 12.1. By EFS. EFS shall indemnify, defend and
hold Client, its parent, subsidiaries and affiliates and the directors, officers, shareholders,
employees and agents of each harmless against any claims, suits, losses, liabilities, injuries or
damages (including, without limitation, reasonable attorneys' fees and litigation expenses) arising
out of any third party claim relating to (a) the Playboy Commerce Business, including, the marketing
and operation thereof; (b) the Privacy Policy; (c) EFS' use of any Client Property not permitted by
or inconsistent with this Agreement; (d) any claims brought by users, service providers or others in
connection with this Agreement; (e) the User Data, including the collection, storage and/or use
thereof; (f) any alleged action or failure to act whatsoever in regard to EFS' performance of its
obligations and duties under this Agreement; (g) the EFS Sites, including, but not limited to, the
operation of the EFS Sites and content contained thereon; (h) any breach by EFS of any of its
representations and warranties set forth above; (i) the sale or availability through the Catalogs
and/or Websites of any content and/or Merchandise, which includes any performer who was less than
eighteen (18) years of age at the time of production; (j) any EFS Produced Merchandise; (k) any
alleged non-conformity to or non-compliance with any Law, including, but not limited to, pertaining
to the content, design or quality of any portion of the Playboy Commerce Business; or (l) any claim
or allegation by a third party claiming rights (including, but not limited to, any copyright,
trademark or patent rights) in or to EFS Property, the Derivative Works (to the extent caused by
EFS), the Merchandise available for sale via the Playboy Commerce Business or the operation of the
Playboy Commerce Business. 12.2. By Client. Client will indemnify, defend and hold EFS, its parent,
subsidiaries and affiliates and the directors, officers, shareholders, employees and agents of each
harmless against any claims, suits, losses, liabilities, injuries or damages (including, without
limitation, reasonable attorneys' fees and litigation expenses) arising out of any third party claim
relating to (a) the authorized use by EFS in compliance with this Agreement of the Client Property
in connection with Playboy Commerce Business; (b) any alleged action or failure to act whatsoever in
regard to Client's performance of its obligations and duties under this Agreement; (c) any breach by
Client of any of its representations and warranties set forth above; (d) any alleged non- conformity
to or non-compliance with any Law, including, but not limited to, pertaining to the content, design
or quality of any portion of the Client Property; or (e) any claim or allegation by a third party
claiming rights in or to Client Property. 12.3. Procedure. If a claim is made against an indemnified
party, such party will promptly notify the indemnifying party of such claim. Failure to so notify
the indemnifying party will not relieve the indemnifying party of any liability which the
indemnifying party might have, except to the extent that such failure materially prejudices the
indemnifying party's legal

26

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 27 -->
rights. The indemnified party shall cooperate with the indemnifying party in the defense and/or
settlement of the claims at the expense of the indemnifying party; provided however, the
indemnifying party shall assume control of the defense of such claim. The indemnified party may
participate in the defense of the claim at its own cost. Notwithstanding anything contained herein,
(a) the indemnified party shall not enter into any settlement or compromise that provides for any
remedy of the claim without the prior written approval of the indemnifying party, which approval
will not be unreasonably withheld; and (b) EFS may not enter into any settlement or compromise that
involves or affects any Playboy Mark, Licensed Domain Name, Playboy Content, Derivative Work or
Authorized Modification without Client's prior written approval. 13. Limitation of Liability. EXCEPT
IN THE EVENT OF A BREACH OF SECTION 8 (CONFIDENTIALITY) OR LIABILITY ARISING UNDER A PARTY'S
INDEMNIFICATION OBLIGATIONS UNDER SECTION 12, IN NO EVENT SHALL EITHER PARTY BE LIABLE FOR ANY
INDIRECT, SPECIAL, INCIDENTAL, PUNITIVE OR CONSEQUENTIAL DAMAGES ARISING OUT OF OR IN ANY WAY
CONNECTED WITH THIS AGREEMENT OR ANY MATTER RELATED HERETO, INCLUDING WITHOUT LIMITATION, LOST
BUSINESS OR LOST PROFITS, EVEN IF SUCH PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
14. Miscellaneous. 14.1. Independent Contractors. The rights and powers herein granted to EFS are
those rights and powers of an independent contractor only, and this Agreement shall not, and is not
intended to, create any other relationship nor make, constitute or appoint EFS an agent or employee
of Client. It is expressly understood and agreed that Client shall not under any circumstances be
liable to EFS for all or any part of any losses EFS may sustain. EFS shall have no power to obligate
or bind Client in any manner whatsoever. 14.2. Severability. Each provision of this Agreement shall
be severable. If, for any reason, any provision herein is finally determined to be invalid and
contrary to, or in conflict with, any existing or future law or regulation by a court or agency
having valid jurisdiction, such determination shall not impair the operation or affect the remaining
provisions of this Agreement, and such remaining provisions will continue to be given full force and
effect and bind the parties hereto. Each invalid provision shall be curtailed only to the extent
necessary to bring it within the requirements of such law or regulation. 14.3. Assignment. This
Agreement shall be binding upon and inure to the benefit of the parties named herein and their
respective heirs, legal representatives, successors and permitted assigns. Notwithstanding the
foregoing, this Agreement and all rights and duties hereunder shall not, without the prior written
consent of Client, in any manner be assigned, mortgaged, licensed, or otherwise transferred or
encumbered by EFS or by operation of law; provided, however, that EFS may assign this Agreement to
an acquirer of all or substantially all of its assets without Client's consent, but only in the
event that in Client's reasonable determination (a) key EFS management (as defined by Client at the
time of acquisition) will remain indefinitely with EFS or replacement management is reasonably
acceptable to Client and no less experienced than those in place as of the Effective Date hereof;
(b) the acquirer can demonstrate to Client's reasonable satisfaction the availability of financial
resources, and the ability and intention, to

27

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 28 -->
adequately invest in growing the Playboy Commerce Business (by way of example, the acquirer shall
have a minimum net worth equal to or above that of EFS as of the Effective Date hereof); (c) such
assignment will not have a detrimental impact on the Playboy Commerce Business or Client's other
businesses; and (d) the acquirer is otherwise able to honor all financial terms and assume all
obligations of EFS hereunder. In addition, EFS may not assign this Agreement without Client's
consent to a competitor of Client or any of Client's businesses. Client's consent to any proposed
assignment hereunder shall not be unreasonably withheld or delayed. Any purported transaction not
specifically permitted under this Section 14.3 shall be null and void ab initio. 14.4. Entire
Agreement; Counterparts. This Agreement constitutes the entire agreement between the parties and
supersedes any prior understandings, agreements or representations by or among the parties, written
or oral, to the extent they relate to the subject matter hereof. This Agreement may be executed in
any number of counterparts, each of which shall be deemed an original, but all of which together
shall constitute one and the same instrument. 14.5. No Waiver; No Third Party Beneficiary. None of
the terms of this Agreement may be waived or modified except by an express agreement in writing
signed by the parties. There are no representations, promises, warranties, covenants or undertakings
other than those contained in this Agreement. No custom or practice of the parties hereto at
variance with the terms hereof shall constitute a waiver of either party's right to demand exact
compliance with any of the terms herein at any time. The failure of either party hereto to enforce,
or the delay by either party hereto in enforcing, any or all of its rights under this Agreement
shall not be deemed as constituting a waiver or a modification thereof, and either party hereto may,
within the time provided by applicable Law, commence appropriate proceedings to enforce any or all
of such rights. Except as expressly provided in this Agreement, no individual or entity other than
EFS and Client shall be deemed to have acquired any rights by reason of anything contained in this
Agreement. 14.6. Headings. The headings used herein are for convenience only and shall not be deemed
to define, limit or construe the contents of any provision of this Agreement. The wording of this
Agreement will be deemed to be the wording chosen by the parties hereto to express their mutual
intent, and no rule of strict construction will be applied against any such party. Time is the
essence of this Agreement. 14.7. Force Majeure. Neither party to this Agreement shall be liable for
its failure to perform any of its obligations hereunder during any period in which such performance
is delayed by circumstances beyond its reasonable control (each a "Force Majeure Event"), including
but not limited to: fire, act of nature, embargo, riot, or the intervention of any government
authority; provided, however, that as soon as reasonably practicable prior to any such circumstance,
and in any event promptly thereafter, the affected party (a) has so notified the other in writing;
(b) takes reasonable measures to avoid or limit the effect or duration of such circumstances; and
(c) cooperates with the other party to reasonably alter its obligations hereunder and/or resume
performance under this Agreement as soon as reasonably practicable. If any such circumstance
persists for longer than ninety (90) days, Client may terminate this Agreement immediately upon
written notice without penalty.

28

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 29 -->
14.8. Notices. All notices, demands, claims, requests, undertakings, consents and other
communications which may or are required to be given hereunder shall be in writing and shall be
deemed to be properly given when personally delivered to the party entitled to receive the notice or
when sent via confirmed email or facsimile, or by United States or International mail, postage
prepaid, properly addressed to the respective parties as follows: If to Client: Playboy.com, Inc.
730 Fifth Avenue New York, NY 10019 Attn: Executive Vice President, Business Development With a copy
to: Playboy Enterprises International, Inc. 680 North Lake Shore Drive Chicago, IL 60611 Attn:
General Counsel If to EFS: eFashion Solutions, LLC 80 Enterprise Avenue South Secaucus, NJ 07094
Attn: Edward Foy, Jr., CEO With a copy to: OlenderFeldman, LLP 2840 Morris Avenue Union, NJ 07083
Attn: Kurt D. Olender, Esq. 14.9. Governing Law and Jurisdiction. This Agreement shall be governed
by and construed in accordance with the laws of the Illinois without giving effect to its conflict
of laws principles.

29

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 30 -->
IN WITNESS WHEREOF, the parties hereto, intending this Agreement to be effective as of the Effective
Date, have caused this Agreement to be executed by a duly authorized representative of each.

PLAYBOY.COM, INC. EFASHION SOLUTIONS, LLC By: /s/ Jeremy S. Westin By: /s/ Edward Foy Name: Jeremy
S. Westin Name: Edward Foy Title: EVP, Business Development Title: CEO

30

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 31 -->
Exhibit 1 Playboy Marks & Licensed Domain Names

* THE GIRLS NEXT DOOR & RABBIT HEAD DESIGN mark may be used in advertising Merchandise bearing the
mark only. It should not be used to advertise other goods, such as PLAYBOY goods. If a cast member
of "The Girls Next Door" models PLAYBOY clothing for the Playboy Commerce Business or wears PLAYBOY
clothing on the show, an informational reference to that may be made, but THE GIRLS NEXT DOOR &
RABBIT HEAD DESIGN mark should not be used in connection with such informational reference. Examples
of acceptable informational references include "As seen on The Girls Next Door" and "Modeled by the
stars of The Girls Next Door."

A. Playboy Marks: · PLAYBOY · PLAYBOY.COM · PLAYBOY STORE · SHOPTHEBUNNY.COM · BUNNY · BUNNY SHOP ·
BUNNY(RABBIT HEAD DESIGN)SHOP · BUNNY(SILHOUETTE)SHOP · BUNNY COSTUME · RABBIT HEAD DESIGN · THE
GIRLS NEXT DOOR * · THE GIRLS NEXT DOOR & RABBIT HEAD DESIGN * · FEMLIN · FEMLIN DESIGN · CYBER GIRL
· CYBER CLUB · CENTERFOLD · PLAYBOY CENTERFOLD · CLASSIC CENTERFOLD · PLAYMATE · PLAYMATE OF THE
MONTH · PLAYMATE OF THE YEAR · PMOY · INNER VIXEN · HMH · HUGH M. HEFNER · MISS (MONTH)

B. Licensed Domain Names: · www.playboystore.com · www.playboycatalog.com · www.shopthebunny.com ·
www.bunnyshopcatalog.com · www.bunnyshopcatalog.net · www.bunnyshopstore.com · Other URLs as may be
approved in advance by Client in writing on a case by case basis, including mutually agreed upon
Micro Sites

31

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 32 -->
Exhibit 2 "Powered by eFashionSolutions" Creative

32

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009

33
<!-- page 33 -->
Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 34 -->
Exhibit 3 Fulfillment Services Fulfillment Services shall be handled by EFS as follows: (a)
Substantially all Catalog and Website orders, including, without limitation, regular phone, mail
direct and online orders, received by the end of a Business Day will be processed, picked, packed
and shipped on the same day received, and in no event later than the end of the next Business Day.
Saturday and Sunday orders will be processed with Monday orders. For purposes of this Exhibit,
"Business Day" shall mean any day other than a Saturday, Sunday or other day on which commercial
banks in the State of New Jersey for the USA or the applicable country of the Territory are
authorized or required by law or executive order to close and shall begin at 9:00 AM and end at 6:00
PM (Eastern Time). (b) Substantially all expedited (next day and 2-day delivery) orders, regardless
of channel, received in time for the Monday through Friday 2:00 PM ET cutoff will be picked, packed
and shipped that same day. Exceptions: Credit card irregularities, which cannot be resolved same
day, will ship the following Business Day with notification to the customer. In the event of system
problems that prevent turnover to shipper by last pickup, customers will be notified and packages
will be shipped expedited the next Business Day. (c) Substantially all customer returns will be
processed within two (2) Business Days of dock receipt. (d) Websites order confirmations or back
order or cancellation notices to customers will be provided within one (1) Business Day of receipt.
Direct order letters will be produced the next Business Day and substantially all will be mailed
that same day. (e) Exact Merchandise ordered at the price(s) specified will be shipped unless the
customer approves a substitution. (f) Orders will be packed in professional packaging material
including appropriate filler to prevent damage while in transit. Customer Service shall consist of
the following: (a) Telephone-based order processing Monday through Friday, 7:00am to 9:00pm,
Saturday and Sunday, 9:00am to 5:00pm (Eastern Time). (b) Telephonic and online (e-mail) customer
service Monday through Friday, 8:00am to 7:00pm, Saturday, 9:00am to 5:00pm (Eastern Time). (c)
Customer service shall address inquiries and complaints with respect to any Merchandise, gift
certificates, Catalog orders, Website orders, etc.

34

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 35 -->
(d) All costs in connection with postage, printing and stationary expenses incurred by EFS in
furtherance of its customer service obligations hereunder shall be borne solely by EFS. Order
Processing shall consist of the following: • Mail order processing and data entry • Phone order
processing and data entry • Fax order processing and data entry • Check verification processing •
Gift certificate processing and support • Deposit preparation • Held order processing for fraud
review/AVS • Customer Service

35

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 36 -->
Exhibit 4 Photography Costs * Costs per day for a typical photo shoot (based on a 7-day shoot):
Photographer & Assistants: ***** Equipment & Rentals: ***** Set Design: ***** Styling: ***** Make Up
Artist: ***** Playmates/Models: ***** Travel & Hotel: ***** Catering: ***** Estimate: *****

* The information set forth in this Exhibit 4 is provided only as an example and estimate of costs
associated a typical photo shoot. Nothing herein shall be deemed or interpreted as a guarantee of
costs or expenses that may be encountered by EFS.

36

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 37 -->
Exhibit 5 Guidelines A. PURPOSE OF GUIDELINES GENERALLY The purpose of these Guidelines is to help
ensure, among other things, that: 1) The Playboy Commerce Business meets the standards of excellence
in content, graphic appeal and other qualities that Client and its affiliates seek to maintain; 2)
The Playboy Marks are associated only with material of the type and quality generally associated
therewith; 3) The validity and effectiveness of the Playboy Marks and the Playboy Commerce Business
and the rights and value therein are fully protected; and 4) EFS and its affiliates conduct their
activities, both relating to the Playboy Commerce Business and otherwise, in a way that does not
jeopardize the Playboy Marks or the reputation and image of any Playboy entity or activity. B.
CONTENT GUIDELINES ***** C. LANGUAGE ***** D. PROHIBITED ADVERTISING CONTENT *****

37

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 38 -->
Exhibit 6 Staffing

A. Organizational Chart *****

B. Client Employees to be Hired by EFS *****

38

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 39 -->
Exhibit 7 Licensee Exclusives Restricting EFS Produced Merchandise *****

39

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 40 -->
Exhibit 9 EFS Produced Merchandise Approval Process

1. EFS understands and agrees that any and all EFS Produced Merchandise and any other items bearing
the Playboy Marks or intended for use in connection with the Merchandise (hereinafter collectively
referred to as the "Materials") must be approved in advance in writing by Client through Client's
online approval submission system. The Materials include, but are not limited to, photography,
cartons, containers, labels, wrappers, packaging and other inner and outer packaging materials,
fixtures, displays, artwork and printing, advertising, sales, marketing and promotional materials.
EFS shall, at its own expense, submit to Client or its designee for written approval, samples of any
EFS Produced Merchandise and the Materials at each stage of development thereof, which shall
include, but not be limited to: (i) an initial sketch or photograph prior to any manufacture
thereof; (ii) a sample prototype or equivalent acceptable to Client; and (iii) two final
production-quality samples of that which will be mass produced or manufactured. EFS must obtain
Client's written approval of each stage of development before proceeding to the next stage, and in
no event shall EFS commence or permit the mass manufacture, advertising, promotion, sale or
distribution of any EFS Produced Merchandise or Materials unless and until EFS has received Client's
written approval of the samples provided pursuant to (iii) of this Section 1. In the event Client
fails to provide its approval or disapproval of any or all things submitted to Client pursuant to
this Section 1 within ***** of Client's receipt thereof, EFS may send written notice to Client
advising no response was received. If Client does not respond within ***** of Client's receipt
thereof, then Client shall be deemed to have given disapproval. 2. To ensure that EFS Produced
Merchandise and the Materials are constantly maintained in conformance with the previously approved
samples pursuant to Section 1 of this Exhibit 9 above, EFS shall, within ten (10) days of receipt of
a request from Client, send or cause to be sent to Client at EFS' expense: (i) such actual samples
requested by Client of the EFS Produced Merchandise and the Materials EFS is using, manufacturing,
selling, distributing or otherwise disposing of; and (ii) a listing or revised listing of each
location where any of the EFS Produced Merchandise and the Materials or either thereof are designed,
manufactured, stored or otherwise dealt with, except to the extent such listing or revised listing
duplicates currently accurate information previously provided. Client and its nominees, employees,
agents and representatives shall have the right to enter upon and inspect, at all reasonable hours
of the day, any and all such location(s) and to take, without payment, individual samples of any of
the EFS Produced Merchandise and the Materials as Client reasonably requires for the purposes of
such inspection. 3. If any of the EFS Produced Merchandise or Materials sent or taken pursuant to
Section 2 of this Exhibit 9 above or that otherwise come to the attention of Client does or do not
conform in Client's sole opinion to the previously approved samples, Client shall so notify EFS, in
writing, specifying in what respect such of the EFS Produced Merchandise or Materials is or are
unacceptable. Immediately upon receipt of such notice, EFS shall suspend all manufacture, sale and
distribution of all such EFS Produced Merchandise and Materials and shall not resume the
manufacture, sale or distribution thereof unless and until EFS has made

42

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 41 -->
all necessary changes to the satisfaction of Client and has received Client's written re-approval of
each of such EFS Produced Merchandise and Materials. 4. Except as otherwise specifically provided in
this Agreement, all EFS Produced Merchandise and/or Materials that are not approved by Client or
that are determined by Client to be non-conforming or unacceptable shall not be sold, distributed or
otherwise dealt with by EFS. All such EFS Produced Merchandise and Materials shall be destroyed by
EFS with, if Client so requests, an appropriate certificate of destruction furnished to Client. 5.
Any and all sales, distribution or use by EFS of unapproved, non-conforming or unacceptable EFS
Produced Merchandise or Materials shall not only constitute an incurable default under the terms of
this Agreement, but such EFS Produced Merchandise or Materials also shall be considered unlicensed
and an infringement of Client's proprietary rights, and Client shall have the right to bring legal
action against EFS for any and all remedies available to Client in addition to the remedies
available under this Agreement. EFS acknowledges and agrees that to the extent EFS has followed the
approval process as outlined in this Exhibit 9 with respect to EFS Produced Merchandise, EFS shall
have had notice of any non-approval, non- conformance and/or unacceptability thereof. 6. Client
shall have final approval with respect to the following elements of the Products: (i) selection of
Client's images for use on such Merchandise; (ii) manipulation and adaptation of the Playboy Marks
for reproduction on such Merchandise; (iii) approval of "strike offs" or other pre-production
samples as the parties may agree; and (iv) approval of actual materials to be used for manufacture
of such Merchandise. 7. It is specifically agreed by EFS that there shall be no approval by default.
No product may be manufactured unless there is a written approval by Client.

43

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 42 -->
Exhibit 10 Payments and Fees *****

44

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 43 -->
Exhibit 11 Location-Based Entertainment Partners Playboy Club at the Palms Casino Resort Playboy
Mansion at Macao Studio City

45

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
<!-- page 44 -->
Exhibit 12 Time & Action Calendar

EFS Transition Key Dates Date Contract Signing 1/15/2008 Shipping & Receiving IRI to Prepare
Inventory for Shipment Week of 1/21/2008 3 Stages 60 Days + Week of 1/28/2008 Majority of Inventory
Week of 2/11/2008 Final Shipment Week of 3/1/2008 EFS to Receive Inventory

Customer Service Transfer of 800 numbers 2/15/2008 Test Orders 2/18/2008-2/23/2008 Create Live Chat
2/15/2008 Turn on phone Lines 3/1/2008 IRI terminates taking returns 6/1/2008 Turn off IRI CS Lines
6/1/2008

Site Development Recreation of current store design 1/1/2008-2/15/2008 Site Testing 2/23/2008 Change
DNS from current Host 2/1/2008 Point DNS to new EFS IP 2/27/2008 Go Live 3/1/2008

Other IT Abacus/Epsilon Integration 1/1/2008-2/15/2008

PLAYBOY/BUNNY SHOP Summer Catalog 2008 START END PRODUCTION SCHEDULE Style Out 11/27/2007
Merchandiser Samples due Final 12/5/2007 Photography 12/10/2007 12/14/2007 Complete tabletop pre pro
12/7/2007 TableTop Photography 12/10/2007 12/17/2007 Creative Page Building 12/12/2007 12/25/2007
Creative Selects Review 1/3/2008 Mktng/Merch/Crtve Proof One 1/7/2008 1/11/2008 Mktng/Merch Proof
one Revisions 1/14/2008 1/16/2008 Creative Proof Two 1/16/2008 1/23/2008 Mktng/Merch Final Proof
1/28/2008 2/1/2008 Mktng/Merch Release Pages 2/4/2008 2/8/2008 Separator

46

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009

47
<!-- page 45 -->
Proof Separations 2/11/2008 2/15/2008 Creative/Separator Files DUE to Printer 2/21/2008 Separator
Printer Proofs DUE 2/22/2008 Printer Correction Due to Printer 2/22/2008 Creative ON PRESS 2/25/2008
Printer PRINTING SCHEDULES Paper DUE (40 Days Prior) 2/20/2008 Creative Print Order/Distrib. info
Due 2/17/2008 Creative/Mktng Process Tapes DUE 2/21/2008 Marketing Postal DUE 3/6/2008 Marketing
Order Form DUE 2/19/2008 Creative Begin Bindery 2/26/2006 3/2/2006 Printer DROP 1-IN HOME 3/19/2008
3/21/2008 Printer DROP 2-IN HOME 4/23/2008 4/25/2008 Printer DROP 3-IN HOME 5/21/2008 5/23/2008

Source: PLAYBOY ENTERPRISES INC, 10-Q/A, 2/20/2009
