<!-- page 1 -->
# TURN - KEY MANUFACTURING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Manufacturing Agreement |
| Agreement Date | 2011-04-01 |
| Parties | INVASIX LTD. ("Customer"); FLEXTRONICS ISRAEL LTD. ("Contractor"); |
| Source | CUAD v1 / InmodeLtd_20190729_F-1A_EX-10.9_11743243_EX-10.9_Manufacturing Agreement |

Exhibit 10.9 TURN - KEY MANUFACTURING AGREEMENT This Turn - Key Manufacturing Agreement (the
"Agreement") is effective as of the 1.4.2011 (the "Effective Date") by and between: INVASIX LTD.,
with a principal place of business at Tavor Building, Shaar Yokneam, POB 533, Yokneam 20692, Israel.
Hereinafter referred to as "Customer" And FLEXTRONICS ISRAEL LTD. with a principal place of business
at Industrial Zone Migdal Haemek 23108 P.O.B. 867, Israel. Hereinafter referred to as "Contractor."
Whereas Customer designs, manufactures and sells the Products as defined in Exhibit A attached
hereto, which includes subassemblies components and know- how, that is confidential and proprietary
property of Customer; Whereas Customer desires to buy manufacturing services; Whereas Contractor is
in the business of Turn - Key projects; Whereas Customer acknowledges that Contractor's expertise is
manufacturing and that Contractor's responsibility related to the Customer's Products is limited to
this extent; Whereas Contractor declares that it has all the capabilities to supply manufacturing
services for Customer's Products; and Whereas Contractor desires to sell and deliver its
manufacturing services in accordance with Customer specifications all subject to the terms and
conditions contained herein. Now therefore, the parties hereto have agreed and do hereby agree as
follows: 1. Precedence 1.1 The terms and conditions and appendices herein shall govern all services
performed by Contractor pertaining to the subject matter. 1.2 It is the intent of the parties that
this Agreement and its appendices represent the entire agreement and prevail over the terms and
conditions of any purchase order, acknowledgment form or order instruction. 2. Term This Agreement
shall commence on the Effective Date and shall continue for an initial term of year as of the
Effective Date. This Agreement shall automatically be renewed for successive one (1) year increments
unless either party request in writing, at least ninety (90) days prior to the anniversary date,
that this Agreement not to be renewed. 3. Scope Of Work Contractor will, pursuant to the written
specifications given by Customer and pre approved by Contractor ("Specifications"), perform
manufacturing services on behalf of Customer. These manufacturing services shall include, but not be
limited to, labor, materials, testing, packaging and delivery to Customer, all subject to the terms
and conditions contained in this Agreement.

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 2 -->
4. Contractor's Obligations 4.1 Contractor shall provide Customer with the following services: -
Material planning - Material procurement - Incoming Inspection - Assembly of printed circuit boards
& cables - Final assembly & integration of the Product - In Circuit test - Functional test -
Packaging and delivery 4.2 Customer's production facilities Contractor will be obliged to allocate
to Customer, production and storage space as well as trained production and testing personnel as an
integral part of this Agreement. Contractor shall apply for and receive the ISO13488 standard for
the production facility, by no later than . During the term of this Agreement, the manufacturing
services provided by the Contractor hereto shall confirm in all material respects with the ISOl3488
standard. 5. Customer's obligations Customer will provide the following: - Technical specifications
- Standard Operation Procedures - Drawings - Bill of Materials - Approved Vendors list - Gerber
data, CAD files - Quality requirements - Technical support, as required - Any additional information
reasonably requested by Contractor or otherwise required hereunder. 6. Material Procurement The
material procurement undertaking, pursuant to this Agreement, will be carried-out by the Contractor.
6.1 Contractor is authorized to purchase materials using standard purchasing practices including,
but not limited to acquisition of materials recognizing Economic Order Quantity, ABC buy policy and
long lead time components management, in order to meet the requirements of Customer's orders and
forecasts.

2

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 3 -->
6.2 Economic Order Quantity ("EOQ") for items which are un-returnable to vendor or unusable for
other clients of the Contractor must be pre- approved by Customer. For such pre-approved EOQ's,
Customer shall advance to the Contractor sums on account of future deliveries equal to the cost
attributed to the quantity ordered exceeding the 3 months forecast. 6.3 Long Lead Items In order to
manage demand fluctuations Contractor shall suggest from time to time a list of LLI's to be approved
by the Customer. Contractor shall maintain in inventory certain quantities of LLI. "LLI" shall mean
Long Lead Item materials required in order to complete manufacture and supply of Products. For the
avoidance of doubt Customer shall have no additional liability with respect to the holding of LLI
other than the liability provided herein below. The usage of LLI by Contractor for the manufacture
of Items shall be by a written order by Customer in accordance with this Agreement, stipulating the
quantity Customer wishes Contractor to use. If Contractor holds LLIs based on any written
requirement for more than three (3) months, Customer shall be required to purchase such LLIs at
their direct costs plus a handling fee of 2% of Product price. The purchase terms of such LLI's, set
forth in Section 8.2 hereof. 6.4 Contractor is responsible for monitoring supplier's quality,
according to the Specifications provided by Customer for all purchased materials. 6.5 In the event
of termination of this Agreement or a cancellation of a Purchase Order, and/or discontinuance of a
Product, or excess materials created by an Engineering Change, Customer agrees to compensate
Contractor for unused material inventory which are affected by such termination, cancellation or
discontinuance, as follows: (i) The cost of material inventory, whether in raw form or work in
process, which are not returnable to the vendor without charge (unless the charge was approved by
Customer, or usable for other Contractor's customers, including EOQ of unique parts. (ii) The cost
of materials on order which cannot be cancelled without charge (unless the charge was approved by
Customer. (iii) To the above applicable compensation, the Contractor shall be entitled to a handling
fee of 2% of the compensation due. The compensation under this Sub-section shall be the sole
compensation due to Contractor with respect to handling the Products/materials. (v) Payment shall be
made to Contractor against delivery of the compensated materials to Customer. The compensation for
finished Products is as set out in Section 7.3 below. 6.6 Contractor shall use its commercially
reasonable efforts to cancel all applicable materials purchase orders and reduce materials inventory
through return for credit programs or allocate materials for alternate programs, if applicable.
Without derogating from the aforesaid, Customer shall pay in advance the same amount it is obligated
to pay under this Section 6, on account of such inventory. Such advance shall be non refundable
except to the extent such inventory was consumed by Contractor in order to manufacturing Customer's
Products under this Agreement.

3

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 4 -->
7. Forecasts and Purchase Orders 7.1 Customer shall issue to Contractor, on a monthly basis, a six
(6) month rolling forecast setting forth projected demand for the Products (the "Forecast").
Contractor shall use all reasonable commercial efforts, including expediting materials and
allocating capacity, in order to support Customer's request for increased production. 7.2 Contractor
will supply all orders that do not exceed the forecast at the delivery times set forth in each
Purchase Order. In the event Contractor anticipates at any time that it will not deliver Products
within the prescribed timetable as set forth in the applicable Purchase Order, Contractor shall
promptly so inform Customer by written notice of such delay. Contractor shall submit proposed
revisions to the timetable that reflect Contractor's best estimates of what can realistically be
achieved and shall use its best commercial efforts to achieve such timeline, unless otherwise
directed by Customer and confirmed by Contractor. 7.3 Purchase Orders. Customer will issue written
purchase orders, which specify all Products to be delivered within a minimum three (3) months period
commencing on the date of acceptance of the purchase order by Contractor ("Purchase Order").
Contractor shall accept or reject (in writing summarizing the rejection causes) each Purchase Order
according to its terms (including the delivery date) within five (5) working days of receipt of such
order, if an order has not been confirmed within such period it shall be deemed rejected. 7.4
Finished Goods Inventory 7.4.1 In order to manage demand fluctuations, Contractor shall maintain an
amount of additional units of each Product as FGI, in a minimum level of two (2) weeks of supply and
a maximum of four (4) weeks of supply of each Product set forth in the most recent Customer's
Forecast. "FGI" shall mean rolling finished goods inventory that Contractor shall be obligated to
hold in inventory for Customer in addition to any Purchase Order amounts. The actual quantity of FGI
required to be held by Contractor will be specified on a monthly basis in a formal document provided
by Customer to Contractor for this purpose. For the avoidance of doubt Customer shall have no
additional liability with respect to the holding of FGI other than the liability provided in Section
7.4.3 below. 7.4.2 When Customer draws from the FGI, Contractor shall replenish the FGI no later
than sixty (60) days from such date that Customer draws from FGI, provided the drawing of FGI shall
be by the issuance of a written order by Customer in accordance with this Agreement, stipulating the
quantity Customer wishes to withdraw from the FGI. 7.4.3 If Contractor holds any FGI based on any
forecast for more than three (3) months from the original delivery date specified in the applicable
purchase order, Customer shall be required to purchase any and all such goods from Contractor for
100% of Contract Price of such goods and Section 8.3 below shall not apply.

4

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 5 -->
7.5 Customer tooling, etc. All Customers' materials, tooling and equipment furnished to Contractor
or paid for by Customer in connection with this Agreement and all paid for Products shall be clearly
marked and remain the Customer's property. Contractor will maintain the tooling as provided in
Exhibit B. 8. Customer Liability for Forecasts 8.1 Customer's liability with respect to any and all
demand signals provided by Customer, including but not limited to "purchase orders," "forecasts,"
"schedules," "pick lists," with respect to any Products manufactured, produced, procured, stored or
delivered by Contractor, including, but not limited to, any direct or indirect costs related thereto
or related to components, work in progress and/or raw materials shall be limited to the amounts set
forth in this Section 8 with respect to finished Products and in Section 6 concerning components,
work in progress and/or raw materials. 8.2 In the event that Customer has either cancelled or
delayed delivery of a Purchase Order and Customer has not taken delivery of the Products ordered
under that Purchase Order within three (3) months from the original delivery date, then; (i)
Contractor shall submit a claim for reimbursement for such cancelled or delayed Products within
thirty (30) days from the end of such three (3) month period; (ii) Customer shall be liable to pay
Contractor 100% of the Contract Price of such cancelled or delayed Products and (iii) Contractor
shall hold the cancelled or delayed Products in its inventory and make them available to Customer
(upon Customer's request) for a period of six (6) months from receipt of payment for such Products
free of charge. 30 days before the lapse of the 6 month period, the Contractor shall notify the
Customer of the upcoming lapse of the term. In the event that Customer, at its sole discretion,
decides to repurchase any (or all) of the Products in said Period, and subject to the fulfillment of
all Customer's obligations in this Sections 8.2 (i.e. 100% of the Contract Price has been paid to
Contractor), then the price for such repurchase shall be 0% of the Contract Price. Thereafter, the
Customer shall pay Contractor all direct costs in connection therewith. Provided Customer hereby
authorizes Contractor to transfer such Products to a warehouse operated by Contractor or a third
party as instructed by Customer. 8.3 In the event that for any reason whatsoever, Customer has not
ordered any Products for a period of three (3) months, then: (i) Contractor shall submit a claim for
reimbursement for Products that were forecasted for the upcoming three months in the last Forecast
sent three (3) months ago (the "Last Forecast"); (ii) Customer shall be liable to pay Contractor:
100% of the Contract Price of the Product s forecasted for days 0-30 in the Last Forecast which were
not delivered to Customer; and (iii) Contractor shall hold the Forecasted Products in its inventory
and make them available to Customer (upon Customer's request) for a period of six (6) months of
receipt of payment for such Products free of charge. 30 days before the lapse of the 6 month period,
the Contractor shall notify the Customer of the upcoming lapse of the term. In the event that
Customer at its sole discretion decides to repurchase any (or all) of the Forecasted Products in
said Period and subject to the fulfillment of all Customer's obligations in this Section 8.3 (i.e.
100% of the Contract Price has been paid to Contractor), then the price for such repurchase shall be
0% of the Contract Price. Thereafter, the Customer shall pay Contractor all direct costs in
connection therewith. Provided Customer hereby authorizes Contractor to transfer such Products to a
warehouse operated by Contractor or a third party as instructed by Customer.

5

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 6 -->
9. Quality 9.1 Contractor shall permit Customer to audit its quality procedures, upon three (3)
business day advance written notice to Contractor and shall provide all assistance which is
reasonably necessary for Customer to evaluate the quality of the Products. 9.2 Contractor shall
maintain quality assurance standards in accordance with ISO 13488, Seller's Quality Assurance,
Control and Inspection shall be in compliance with all material ISO 13488 standards during the Terms
of this Agreement. 9.3 If a Product did not pass Customer's Automatic Test Process then Contractor
will perform two rounds of repairs on the Product, if after such two rounds the Product still did
not pass the ATP then Contractor will send the Product with a qualified personnel to Customer for
repair. If after Customer tried to repair the Product and failed Customer will be obligated to pay
for such defected product (if the reason is other than workmanship). 10. Express Limited Warranty
For the purpose of this Agreement, "Warranty Period" shall mean twelve (12) months as of the date of
delivery to Customer. Contractor represents and warrants that, for the Warranty Period, the Products
(i) will be free from defects in workmanship, material (only to the same extent as the original
manufacturer of the material warrants the Contractor), and manufacture; (ii) will comply the
Specifications IPC610.B standard (in all material respects and unless otherwise was instructed by
Customer). Contractor further represents and warrants that the Product will consist of new
materials. The warranty provided in this Section shall not apply to (1) Customer's materials,
tooling and equipment (2) Products modified by Customer or any third party without Contractor's
prior written consent, (2) Products installed or operated by Customer or any third party in a manner
inconsistent with the Specifications or the terms and conditions of this Agreement, or (3) Products
damaged, abused, altered or misused by Customer or any third party, or as the result of fire,
casualty, or other external cause (4) defects resulting directly or indirectly, wholly or partially,
from Customer's Specifications or the design of the Products, (5) First articles, prototypes,
pre-production units, test units or other similar Products. Upon any failure of a Product to comply
with the above warranty, Contractor's sole obligation, and Customer's sole remedy, is for
Contractor, at its option, to promptly repair or replace such Product and return it to Customer
freight prepaid. Customer shall return Products covered by the warranty freight prepaid after
completing a failure report and obtaining a return material authorization number from Contractor to
be displayed on the shipping container. Customer shall bear all risks, costs and expenses,
associated with Products that have been returned to Contractor for which there is no defect found
and/or with Products not covered under the warranty above.

6

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 7 -->
Customer will not pass through to end users or other third parties the warranties made by Contractor
under this Agreement. Furthermore, Customer will not make any representations to end users or other
third parties on behalf of Contractor, and Customer will expressly indicate that the end users and
third parties must look solely to Customer in connection with any problems, warranty claim or other
matters concerning the Product. EXCEPT AS SPECIFICALLY SET FORTH HEREIN, CONTRACTOR MAKES NO OTHER
WARRANTIES OR CONDITIONS ON THE PRODUCTS, EXPRESS, IMPLIED, STATUTORY, OR IN ANY OTHER PROVISION OF
THIS AGREEMENT OR COMMUNICATION WITH CUSTOMER, AND CONTRACTOR SPECIFICALLY DISCLAIMS ANY IMPLIED
WARRANTY OR CONDITION OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. 11. Engineering
Changes 11.1 Customer may, upon advance written notice to Contractor, submit engineering changes for
incorporation into the Products. Contractor will review the engineering change and report to
Customer within two (2) working days of any implications of the proposed changes. The report should
include all possible implications on materials, delivery schedule, manufacturing process, quality
and product cost and shall also quote the Contractors costs for implementing the changes. Customer
and Contractor will agree on all aspects of implications and shall accordingly make revisions in
outstanding Purchase Orders - if requested by Customer and subject to Contractor's consent in
writing. 11.2 Contractor shall assure quick implementation of engineering changes. 12. Delivery and
Inspection, Title and shipping 12.1 Contractor undertakes to report to Customer once (1) a week, or
per Customer request, the quantity of Products ready for delivery 12.2 Customer will notify
Contractor, from time to time, quantities of Products and destinations to which to ship the
Products. 12.3 If the delivery destination is within Israel, excluding port/airport ("Limited
Delivery Territory") than the delivery shall be made by Contractor at no additional cost and to such
destination of delivery Contractor shall incur insurance transport costs. Upon delivery or the
placement of an invoice by Contractor, whichever is earlier, Risk of loss and title will pass to
Customer. 12.4 The price for Deliveries to other destinations outside the Limited Delivery
Territory, including for export will be agreed by the parties. All risk of loss, responsibility and
cost shall be borne by the Customer Ex-Factory. 12.5 To each delivery, Contractor shall include all
required documentation (e.g. bill of lading, QA/QC certificate). Upon delivery to Customer, Customer
will sign the bill of lading. Such signature shall only be deemed as acknowledgement of receipt of
the delivery and not confirmation as to the delivered Products' condition and quality.

7

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 8 -->
12.6 Subject to the above limitations, the Contractor will ship and deliver the Products according
to Customer's instructions in the best and safest means of transportation, to the extent
commercially reasonable. 13. Price and Price Reviews 13.1 Pricing conditions for manufacturing
services supplied under this Agreement are defined in Appendix C. All prices will be quoted in US
Dollars. 13.2 Price Review. Contractor and Customer will meet every three (3) months, during the
term of this Agreement to review pricing and determine the actions required by both sides in order
to achieve cost reduction. The new prices that will be agreed to and the said new prices will come
into effect, will be reflected in the Purchase Orders submitted after such review. 13.3 It is agreed
that, for the sake of facilitating uninterrupted manufacturing, Contractor may purchase materials
for Customer's Products at prices higher than those agreed to with the following limitations: 13.3.1
For price change which has a cost impact less than US $200, based on one (1) quarter consumption
will not require prior authorization from Customer. Contractor will be obliged to submit
comprehensive written report to Customer, subsequent to such event. 13.3.2 For price change which
has cost impact greater than US $200, based on one (1) quarter consumption will require prior
written authorization from Customer. 13.3.3 Customer shall answer urgent requests for approvals for
price change, within three (3) working days. 13.3.4 Maintain Credit Line. Customer agrees to provide
all necessary financial information required by Contractor from time to time and as available to
Customer in order to make a proper assessment of the creditworthiness of Customer. That includes
full annually audited financials statements and, subjected the credit limit analysis request,
Quarterly financial statements (P&L, BS and Cash Flow statements). Contractor will, in good faith,
review Customer's creditworthiness periodically and may provide more favorable terms once it feels
it is prudent to do so. 13.3.5 Upon Contractor's request at any time during the term of this
Agreement, Customer shall obtain and maintain appropriate securities, such as letter of credit,
escrow account, bank guarantees and /or pre-payments in an amount equal to the total value of all
risks associated with the performance of any of the services under this Agreement, on an aggregate
basis. 14. Terms of Payments 14.1 Contractor will invoice Customer per each delivery or as provided
in Sections 6 and 8 hereinabove. The invoice shall include all purchase order details. The invoice
will be quoted in US Dollars. 14.2 Contractor and Customer agree to terms of payments of current
plus thirty (30) days from the date of invoice. Payment shall be affected in US Dollars.

8

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 9 -->
15. Termination 15.1 Termination for cause If either party fails to meet anyone or more of the terms
and conditions as stated in either this Agreement or the Appendices, Contractor and Customer agree
to negotiate in good faith to resolve such default. If the defaulting party fails to cure such
default or submit an acceptable written plan to resolve such default within thirty (30) days
following notice of default, the non-defaulting party shall have the right to terminate this
Agreement by furnishing the defaulting party with sixty (60) days written notice of termination.
15.2 Termination without cause Notwithstanding anything to the contrary stated in this Agreement,
either party may terminate this Agreement at any time without cause by giving to the other party,
not less than four (4) months written notice. 15.3 A Party may immediately terminate this Agreement
should the other party: (i) become insolvent; (ii) enter into or filing a petition, arraignment or
proceeding seeking an order for relief under the bankruptcy/insolvency laws of its respective
jurisdiction; (iii) enter into a receivership of any of its assets; or (iv) enter into a dissolution
of liquidation of its assets or an assignment for the benefit of its creditors. 16. Effect of
Termination 16.1 in the case of termination, unless otherwise stipulated and subject to Customer
fulfillments of all its payments obligations under this Agreement, Contractor will deliver all
Products, materials to Customer and Customer will pay all amounts due under this Agreement, for all
Products, materials mentioned on a Purchase Order or Change Order accepted by Contractor before
expiration or termination date. 16.2 Except where the termination is a result of Contractor's
material default Customer agrees to compensate Contractor for Products and materials as stipulated
in Sections 6 and 8 of this Agreement. 16.3 Each party will promptly return to the other party, all.
technical documentation (e.g. drawings, work instructions, data and design sheets) and/or
Confidential Documents related to the present Agreement 16.4 Subject to Customer fulfillments of all
its obligations under this Agreement, Contractor will return to customer all consigned materials,
equipment and tooling stipulated in section 7.5 of this Agreement. 17. Dispute Resolutions 17.1 In
the spirit of continued cooperation, the parties intend to and hereby establish the following
dispute resolution procedure to be utilized in the unlikely event any controversy should arise out
of or concerning the performance of this Agreement. 17.2 It is the intent of the parties that any
dispute be resolved informally and promptly through good faith negotiations between Contractor and
Customer. Either party may initiate negotiation proceedings by written notice to the other party
setting forth the particulars of the dispute. The parties agree to meet in good faith to jointly
define the scope and method to remedy the dispute. If these proceedings are not productive of a
resolution, then senior management of Contractor and Customer are authorized to and will meet
personally to confer in a bona fide attempt to resolve the matter.

9

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 10 -->
17.3 Should the foregoing procedure not bring a mutually satisfactory solution within 30 days, each
party will be free to proceed according to applicable law. 18. Limitation of Liability 18.1 Customer
shall defend, indemnify and hold harmless Contractor from all claims, liabilities, costs, damages,
judgments and attorney's fees resulting from or arising out of any alleged and/or actual
infringement or other violation of any patents, patent rights, trademarks, trademark rights, trade
names, trade name rights, copyrights, trade secrets, proprietary rights and processes or other such
rights elated to the Product or claims relating to Customer's instructions, tooling, specifications
and designs ("Claims") provided that: (i) Contractor will provide the Customer with prompt written
notice of any Claim no later than three (3) business days following receipt of notice by Contractor;
(ii) Contractor will grant Customer sole control of the defense and settlement of Claims, taking
into account any reasonable request of Contractor; and (iii) Contractor will provide Customer with
reasonable assistance, at Customer's sole expense. Customer assumes no liability for any Claims made
by any third party to the extent that such Claims result from the use of specifications other than
the Specification, unaltered by Contractor or anyone on its behalf. If such Claim is brought, or
Customer in good faith determines a Claim is likely to be made, Customer shall notify Contractor and
either: (1) procure for Contractor the right to continue to perform this Agreement; (2) modify the
Specification so that there will no longer be an infringement or misappropriation or (3) terminate
this Agreement and pay Contractor the consideration due under this Agreement for all services
performed until the date of termination, including all payments set forth in Sections 6 and 8. 18.2
Contractor shall defend, indemnify and hold harmless Customer from all claims, liabilities, costs,
damages, judgments and attorney's fees resulting from or arising out of any alleged and/or actual
infringement or other violation of any patents, patent rights, trademarks, trademark rights, trade
names, trade name rights, copyrights, trade secrets, proprietary rights and processes or other such
rights as a result of the manufacturing methods employed by Contractor but excluding Claims as
defined above) ("Manufacturing Claims") provided that: (i) Customer will provide Contractor with
prompt written notice of any Manufacturing Claim no later than three (3) business days following
receipt of notice by Customer; (ii) Customer will grant Contractor sole control of the defense and
settlement of Manufacturing Claims, taking into account any reasonable request of Customer; and
(iii) Customer will provide Contractor with reasonable assistance, at Contractor sole expense. If a
Manufacturing Claim is brought, or Contractor in good faith determines a Manufacturing Claim is
likely to be made, Contractor shall notify Customer and either: (1) procure for Customer the right
to continue to perform this Agreement; (2) modify its manufacturing methods so that there will no
longer be an infringement or misappropriation or (3) terminate this Agreement.

10

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 11 -->
18.3 THE FOREGOING STATES THE ENTIRE LIABILITY OF THE PARTIES TO EACH OTHER CONCERNING INFRINGEMENT
OF PATENT, COPYRIGHT, TRADE SECRET OR OTHER INTELLECTUAL PROPERTY RIGHTS. 18.4 No Other Liability.
IN NO EVENT SHALL EITHER PARTY BE LIABLE TO THE OTHER FOR ANY INCIDENTAL, CONSEQUENTIAL, SPECIAL OR
PUNITIVE DAMAGES OF ANY KIND OR NATURE ARISING OUT OF THIS AGREEMENT OR THE SALE OF PRODUCTS,
WHETHER SUCH LIABILITY IS ASSERTED ON THE BASIS OF CONTRACT, TORT (INCLUDING THE POSSIBILITY OF
NEGLIGENCE OR STRICT LIABILITY), OR OTHERWISE, EVEN IF THE PARTY HAS BEEN WARNED OF THE POSSIBILITY
OF ANY SUCH LOSS OR DAMAGE. AND EVEN IF ANY OF THE LIMITED REMEDIES IN THIS AGREEMENT FAIL OF THEIR
ESSENTIAL PURPOSE. IN ADDITION, NOTWITHSTANDING ANYTHING TO THE CONTRARY HEREIN OR OTHERWISE, THE
PARTIES ACKNOWLEDGE THAT AS AN ELECTRONIC MANUFACTURING SERVICES PROVIDER WORKING ON A COST PLUS
BASIS SUPPLIER MUST LIMIT ITS LIABILITY IN CONNECTION HEREWITH AND THEREFORE, CONTRACTOR'S LIABILITY
IS FURTHER LIMITED IN ANY EVENT, UNDER ANY LAW, RULE OR REGULATION, TO ANY AMOUNT IT ACTUALLY
RECEIVED IN CONSIDERATION OF THE MANUFACTURING SUBJECT MATTER OF THE RESPECTIVE CLAIM OR DEMAND BY
CUSTOMER OR ANY THIRD PARTY. 19. Confidentiality Customer's product and designs contain certain
elements that are proprietary to Customer. Furthermore, in the course of this agreement, technical
and commercial information of the Customer may be revealed or become known to the Contractor.
Contractor shall keep in confidence all information relating to the foregoing, shall not use any
part of it for any purpose except the performance of this Agreement or in connection therewith, and
shall not enable any third party to use ft without the prior written consent of Customer or unless
such information becomes public domain. Contractor shall ensure that all employees who directly
participate in any of the services performed under this Agreement and may accordingly receive
certain confidential information of the Customer are subject to similar non-disclosure and non-use
undertakings and are made aware of the proprietary and confidential nature of the information. The
provisions of this Section 19 shall survive termination or expiration of the Agreement. 20.
Non-Competition 20.1 The Contractor and the Customer will not be allowed to employ employees of the
other party, directly or indirectly, for one (1) year from the date the employee has ceased to be
employed by the other party. The above mentioned restriction may be waived by either party provided
that it is done by a written and specific consent.

11

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 12 -->
20.2 During the Term, of this Agreement and for an additional period of two (2) years from the date
of termination of this Agreement, the Contractor undertakes not to develop on its own account any
Product. 21. General 21.1 Force Majeur. Neither party shall be liable for any failure or delay in
its performance under this Agreement due to acts of God, acts of civil or military authority, fires,
floods, earthquakes, riots, wars, sabotage, labor disputes, material unavailability due to
unwarranted production stoppage by supplier or any other cause beyond the reasonable control of the
delayed party provided that the delayed party, (i) gives the other party written notice of such
cause, and (ii) uses its reasonable efforts to remedy such delay in its performance. 22.2
Severability. If any provision of this Agreement is held by a court of competent jurisdiction to be
unenforceable, such provision shall be deemed null and void, and the remainder of the Agreement
shall continue to be in full force and effect, while the parties shall negotiate in good faith to
replace the provision with another enforceable one reflecting as closely as possible the parties
initial intention. 22.3 Relationship of the Parties. Each of the parties shall at all times during
the term of this Agreement act as, and shall represent itself to be, an independent contractor.
Neither Party shall have any right or authority to assume or create any obligations or to make any
representations or warranties on behalf of the other parry whether express or implied, or to bind
the other party in a respect whatsoever. 22.4 Governing Law. The construction, interpretation and
performance of this Agreement and all transactions under it shall be governed by the law of the
State of Israel, without giving effect to choice of law rules, and both Parties consent to
jurisdiction by the courts of the City of Haifa. 22.5 Choice of Language. The original of this
Agreement has been written in English. Any notices provided by any party as required by this
Agreement shall be written in the English language. 22.6 Notifications. Any and all notices and
other communications whatsoever under this Agreement shall be in writing, sent by registered mail or
by, email or facsimile to the address set forth above. Notices sent via registered mail shall be
deemed to have been delivered within 3 business days after the date posted. With regards to the
normal course of business, notices sent via email or facsimile shall be deemed to have been received
1 business day following the date of transmission. 22.7 Entire Agreement. No amendment of this
Agreement will be valid unless made in writing signed by a duly authorized representative of both
parties. No provision of this Agreement will be deemed waived and breach or default excused unless
the waiver or excuse is in writing and signed by the party issuing it. The terms and conditions
contained in this Agreement terminate and supersede all prior oral or written understanding between
the parties and shall constitute the entire agreement between them concerning the subject matter of
this Agreement. 22.8 This Agreement may be executed in one or more counterparts, each of which will
be deemed the original, but all of which will constitute but one and the same document.

12

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 13 -->
The parties agree that this Agreement and its appendices may not be modified except in writing,
signed by both parties. 22.9 Set-off. Amounts due hereunder may not be set off except with mutual
prior written consent. 22.10 Insurance. Customer specifically agrees to maintain insurance coverage
for any finished Products or materials which passes to Customer pursuant to this Agreement and which
is stored on the premises of Contractor. 22.11 Successors, Assignment. This Agreement shall be
binding upon and inure to the benefit of the Parties hereto and their respective permitted
successors, permitted assigns and legal representatives. Neither Party shall have the right to
assign or otherwise transfer its rights or obligations under this Agreement except with the prior
written consent of the other Party, not to be unreasonably withheld or delayed. Notwithstanding the
foregoing, Contractor shall be entitled to assign its rights to be paid hereunder to banks or first
tier financial institutions. In Witness whereof, the Parties have caused this Agreement to be duly
executed for and on behalf of: Flextronics (Israel) Ltd. INVASIX LTD 514073618 Contractor Customer
Date: Date: Name: Name: MOSHE MIZRAHY Title: Title: CEO

Signature: Signature: /s/ Moshe Mizrahy

13

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 14 -->
Exhibit A Product's Description Customer Flow Meter Assy PS Shelf Assy Pump Assy Heat Exchanger Assy
Pump with Pneomatics Assy Controller to Speaker Harness DLP Controller Card Assy Distribution Card
Assy Laser Driver Assy Folding Wheels Arms Assy DLP Controller Card + Compulab RF Connector Assy
Touch Screen Assy Touch Panel Adaptor Assy EMERSON Kit Assy HP Fractora Firm Harness Harness for
Dermablation Univer.HP Termistor PCB Card A InMode RF HPS Set InMode Laser Driver Card Assem Display
Assy InMode IPL Card Reworked FootSwitch Preliminary Pack.Assy. Fractora Kit Pack. Fractora Plus
Applicator Fractora Firm-Forma Firm-Forma Fractora 5pcs Box Set 24 Coat Fractora 5pcs box set 126
pin RF Card Assy 75W 2Temp Sensors LCD Adaptor Card AC Filter Card Assy

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 15 -->
Fractora 5 Tips 60 Pin Pack. BodyTite II Controller Card As Fan Rework Assy Fractora 5 Tips 20 Pin
Pack. Fractora Cabinet Front Cover A BodyTite II Cabinet Front Cov BodyTite - Shell Sample Fractora
5pcs Box Set 24 Pin DermAblate Electrode Connectio Body Tite Fractora-BodyFX Blue BodyTite RFAL Grey
Platform BodyTite II Controller Card As T6 HP LED Card BodyTite System Packging Assy InMode System 2
Platform Only 24V PSU Card Assy. Gear Pump Assy. Heat Exchanger Assy Flow Meter Assy BodyTite II Top
Assy InModeRF Color 1 Votiva InModeRF Color 2 BodyTite InModeRF Color 3 Contura BodyTite Color3
FRACTORA InMode System 2 Color1 Optimas InModeRF Color 5 BodyTite PRO InMode System 2 Color 2 Triton
Fract.InitialTipsKit

Source: INMODE LTD., F-1/A, 7/29/2019
<!-- page 16 -->
Exhibit B Description HP HI-POT tester Blue wave-50(UV) RF tester Leakage current TOS3200 EARTH
Continuity tester TOS6210 Tester controler.Programmer memory plag. Power Suply (For Leptop) Komputer
(LEPTOP-DELL) Display MAG tos5052(Hi-POT) Load RF Load Burn-in Test Barcode reader(Argox) TITE FX
Testing Adaptor Fractora-electrical test(five tips) Jig for clening FRACTORA TIPS Thermistor
tester(FRACTORA FIRM,FRACTORA PLUS) Thermistor mounting Tool(FRACTORA FIRM) Tite FX Programmer Tite
FX TESTER Hi-POT CLIP Thermistor mounting Tool(FRACTORA PLUS) Fen HL2010E.(Digital display). Lecroy
wave ACE232 LCRY2101c02774(SCOPE) TEK P5000100(PROB_) PP016 ADAPTOR Cable Lable Applicatot J I G -In
Mode(water system check) Jig screen assy Jig-Laser DUMMY Heat Exchanger washing Jig Diolaze-Testor
CASE LAZER FootSwith Simulator TORC-GEDORE In Mode TESTER Laboratory DC POWER SUPPLY Model: LE3303
Tray For 3 Pcs Laser Printing BURNING(ברוצ) Tool for assembly of Cradle Stem Screw BODY TITE
(AS601206A) BODY TITE (AS601206A) BODY TITE (AG600007A) InMode Main Connector Pin-Checker JIG
InMode2 Pump Burn-in JIG Screen LOGO Placement Jig Side Label Placement Jig Front Label Placement
Jig

Source: INMODE LTD., F-1/A, 7/29/2019
