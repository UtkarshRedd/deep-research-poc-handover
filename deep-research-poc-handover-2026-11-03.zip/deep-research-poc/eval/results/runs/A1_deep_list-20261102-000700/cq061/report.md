# Which agreement in the corpus was entered into between Holiday RV Superstores, Inc. and...

*Question:* Which agreement in the corpus was entered into between Holiday RV Superstores, Inc. and Affinity Group, Inc.? Give its title and date.

## Identify agreement between Holiday RV Superstores, Inc. and Affinity Group, Inc.

The document listing both parties is titled "ENDORSEMENT AGREEMENT". [dac76ece63f3755d p.1] It was entered into as of the 20th day of March 2002. [dac76ece63f3755d p.1] The parties are Holiday RV Superstores, Inc., d/b/a Recreation USA, and Affinity Group, Inc.. [dac76ece63f3755d p.1]

## Verification appendix

Claims: 3 · supported: 3 · partially: 0 · dropped: 0 · gaps: 0 · tier-1 support rate: 1.00 · tier 2 checked: 2 (unsupported 0, partially 0)

| claim | section | tier 1 | score | tier 2 | clusters | sources | note |
|---|---|---|---|---|---|---|---|
| s1.1 | s1 | keep | 0.96 | skipped | 1 | e2→[dac76ece63f3755d p.1] |  |
| s1.2 | s1 | keep | 1.00 | supported | 1 | e1→[dac76ece63f3755d p.1] |  |
| s1.3 | s1 | keep | 1.00 | supported | 1 | e1→[dac76ece63f3755d p.1] |  |

### Evidence

- e1 [dac76ece63f3755d p.1 L12-18] keep (1.0): "ENDORSEMENT AGREEMENT

This Agreement is made as of the 20th day of March 2002, by and between Holiday RV Superstores,
Inc., d/b/a Recreation USA (the "Company"), a Delaware corporation having its principal office at
200 East Broward Boulev…"
- e2 [dac76ece63f3755d p.1 L1-9] keep (0.957): "<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2002-03-20 |
| Parties | Holiday RV Superstores, Inc. d/b/a Recreation USA ("Company"); Affinity Group, Inc. ("…"
