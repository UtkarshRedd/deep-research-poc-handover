"""Approach 3 pieces with scripted models: extract grid, fan-out contract, gap round, graph variants."""
import json
import uuid
from dataclasses import replace
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage, SystemMessage

from dr.agents.fanout import FanoutUnit, gap_check, plan_units, run_breadth, run_units
from dr.config import DEFAULT
from dr.evidence import EvidenceBank
from dr.graph import Pipeline
from dr.ingest.load import load_dir
from dr.llm import get_scripted_llm
from dr.models import Clue, FirstMoveResult, RouteDecision, RouteMode
from dr.structured import ModelCaller
from dr.tools.bm25 import BM25Index
from dr.tools.extract import document_context, extract_grid
from dr.trace import Trace
from dr.workspace import Workspace

SAMPLE = Path(__file__).resolve().parents[1] / "data" / "sample_docs"
QUOTE = "Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00."
AMEND = "Section 3 is amended to read: Borrower shall maintain a Leverage Ratio not exceeding 4.00 to 1.00."


@pytest.fixture()
def docs():
    return load_dir(SAMPLE)


@pytest.fixture()
def ws(tmp_path, docs):
    return Workspace.materialize(docs, tmp_path / "ws")


@pytest.fixture()
def ids(ws):
    by_title = {m.title: d for d, m in ws.manifest.items()}
    return {"a": by_title["Credit Agreement — Acme Industrial LLC"],
            "c": next(d for t, d in by_title.items() if "conformed" in t),
            "m": next(d for t, d in by_title.items() if t.startswith("First Amendment"))}


def tc(name, args):
    return {"name": name, "args": args, "id": f"call_{uuid.uuid4().hex[:8]}", "type": "tool_call"}


def ai(*calls, content=""):
    return AIMessage(content=content, tool_calls=list(calls))


def serial(**agents):
    """Width 1 so scripted replies are consumed in a deterministic order."""
    base = {"FANOUT_WIDTH": 1, "EXTRACT_CONCURRENCY": 1, "FANOUT_MIN_CALLS": 1}
    base.update(agents)
    return replace(DEFAULT, agents=replace(DEFAULT.agents, **base))


# --------------------------------------------------------------------------- extract grid

def test_document_context_is_numbered_and_bounded(ws, ids):
    ix = BM25Index(ws)
    text = document_context(ws, ids["a"], "leverage ratio covenant", ix)
    lines = text.splitlines()
    assert lines[0].startswith("1| ") and any(ln.startswith("17| ") and "3.50 to 1.00" in ln for ln in lines)
    tiny = replace(DEFAULT, agents=replace(DEFAULT.agents, EXTRACT_DOC_MAX_TOKENS=20))
    assert len(document_context(ws, ids["a"], "leverage", ix, tiny)) <= 20 * 4 + 40
    assert document_context(ws, ids["a"], "q", None).count("\n") >= 10        # no index: head + body


def test_extract_grid_saves_verified_quotes_and_rejects_bad_ones(ws, ids, tmp_path):
    a, c, m = ids["a"], ids["c"], ids["m"]
    script = [
        AIMessage(content=json.dumps({"found": True, "answer": "cap 3.50", "quote": QUOTE, "start_line": 17, "end_line": 17})),
        AIMessage(content=json.dumps({"found": True, "answer": "cap 3.50", "quote": "a paraphrase that is not there", "start_line": 15, "end_line": 15})),
        AIMessage(content=json.dumps({"found": False, "answer": "", "quote": ""})),
    ]
    bank = EvidenceBank(ws)
    res = extract_grid(ws, bank, "What is the maximum leverage ratio?", [a, c, m], llm=get_scripted_llm(script),
                       bm25=BM25Index(ws), config=serial(), trace=Trace(tmp_path / "t.jsonl", "t"))
    by = {r.doc_id: r for r in res.rows}
    assert by[a].evidence_id == "e1" and by[a].page == 2 and bank.get("e1").created_by == "extract"
    assert by[c].found and by[c].evidence_id is None and by[c].error.startswith("rejected")
    assert not by[m].found and res.n_added == 1 and res.n_rejected == 1 and res.n_found == 2
    assert "1 with a verified quote" in res.summary() and f"- {a} p.2 [e1]" in res.summary()


# --------------------------------------------------------------------------- fan-out units

def test_run_units_enforces_contract_and_retries_once(ws, ids, tmp_path):
    a, m = ids["a"], ids["m"]
    units = [FanoutUnit(index=1, sub_question="original cap", doc_ids=[a]),
             FanoutUnit(index=2, sub_question="amended cap", doc_ids=[a, m])]
    long_answer = "x" * (DEFAULT.agents.FANOUT_FINDING_MAX_TOKENS * 4 + 50)
    script = [
        # unit 1: grep, then add + submit with an over-long answer and one unknown id
        ai(tc("grep", {"pattern": "Leverage Ratio"})),
        ai(tc("add_evidence", {"doc_id": a, "start_line": 17, "end_line": 17, "quote": QUOTE, "note": "cap"}),
           tc("submit", {"sub_question": "original cap", "answer": long_answer + " [e1]", "evidence_ids": ["e1"]})),
        # unit 2, attempt 1: reads outside scope are rejected; submits with no evidence and no abstention -> contract violation
        ai(tc("read", {"doc_id": ids["c"], "start_line": 1, "n_lines": 5})),
        ai(tc("submit", {"sub_question": "amended cap", "answer": "4.00", "evidence_ids": []})),
        # unit 2, attempt 2: proper
        ai(tc("grep", {"pattern": "4.00 to 1.00"})),
        ai(tc("add_evidence", {"doc_id": m, "start_line": 9, "end_line": 9, "quote": AMEND, "note": "amended"}),
           tc("submit", {"sub_question": "amended cap", "answer": "4.00 [e2]", "evidence_ids": ["e2"]})),
    ]
    bank = EvidenceBank(ws)
    tr = Trace(tmp_path / "t.jsonl", "t")
    findings, failed = run_units(units, "What caps apply?", ws, bank, serial(), llm=get_scripted_llm(script), trace=tr)
    assert failed == [] and [f.sub_question for f in findings] == ["original cap", "amended cap"]
    assert findings[0].evidence_ids == ["e1"] and findings[0].answer.endswith("…[truncated by the harness]")
    assert findings[1].evidence_ids == ["e2"] and bank.get("e2").created_by == "fanout:2"
    events = [json.loads(ln) for ln in (tmp_path / "t.jsonl").read_text().splitlines()]
    units_ev = [e for e in events if e["kind"] == "fanout_unit"]
    # unit 2's empty submit is refused by the registry inside the loop, so the unit finishes on attempt 1
    assert [(e["unit"], e["attempt"]) for e in units_ev] == [(1, 1), (2, 1)]
    assert units_ev[0]["problems"] == ["answer over the token cap (truncated)"]
    # unknown ids cannot pass `submit` (the registry rejects them); the contract still guards a forced hand-off
    from dr.agents.fanout import _contract
    from dr.models import Finding
    f, problems = _contract(Finding(sub_question="s", answer="a", evidence_ids=["e1", "e9"]), bank, DEFAULT)
    assert f.evidence_ids == ["e1"] and problems == ["unknown evidence ids dropped: ['e9']"]
    f, problems = _contract(Finding(sub_question="s", answer="a", evidence_ids=[]), bank, DEFAULT)
    assert problems == ["no evidence and not marked not_in_corpus"]


def test_unit_without_submission_is_a_failed_handoff(ws, ids, tmp_path):
    unit = FanoutUnit(index=1, sub_question="q", doc_ids=[ids["a"]])
    script = [AIMessage(content="no tools"), AIMessage(content="still none"), AIMessage(content="ignoring force"),
              AIMessage(content="no tools"), AIMessage(content="still none"), AIMessage(content="ignoring force")]
    findings, failed = run_units([unit], "q", ws, EvidenceBank(ws), serial(), llm=get_scripted_llm(script))
    assert findings == [] and len(failed) == 1 and "no_tool_calls" in failed[0]


def test_plan_units_and_gap_check(ws, ids):
    fm = FirstMoveResult(clues=[Clue(text="x")], opening_observation="o", candidate_doc_ids=[ids["a"], ids["m"]])
    d = RouteDecision(mode=RouteMode.breadth, rationale="r", sub_questions=["s1", "s2"])
    units = plan_units(d, fm, ws)
    assert [u.sub_question for u in units] == ["s1", "s2"] and units[0].doc_ids == [ids["a"], ids["m"]]
    assert plan_units(d, None, ws)[0].doc_ids == ws.doc_ids()
    from dr.models import Finding
    fs = [Finding(sub_question="s1", answer="a [e1]", evidence_ids=["e1"])]
    caller = ModelCaller(get_scripted_llm([AIMessage(content='{"gaps": ["Does the amendment change the margin?", " "]}')]), None, "g", "planner")
    assert gap_check("q", fs, caller) == ["Does the amendment change the margin?"]
    assert gap_check("q", [], caller) == []


# --------------------------------------------------------------------------- breadth branch + graph

def researcher_script(a, m):
    return [
        ai(tc("grep", {"pattern": "3.50"})),
        ai(tc("add_evidence", {"doc_id": a, "start_line": 17, "end_line": 17, "quote": QUOTE, "note": "cap"}),
           tc("submit", {"sub_question": "original cap", "answer": "3.50 [e1]", "evidence_ids": ["e1"]})),
        ai(tc("grep", {"pattern": "4.00"})),
        ai(tc("add_evidence", {"doc_id": m, "start_line": 9, "end_line": 9, "quote": AMEND, "note": "amended"}),
           tc("submit", {"sub_question": "amended cap", "answer": "4.00 [e2]", "evidence_ids": ["e2"]})),
        # gap unit
        ai(tc("grep", {"pattern": "Applicable Margin"})),
        ai(tc("submit", {"sub_question": "margin", "answer": "not asked", "evidence_ids": [], "not_in_corpus": True})),
    ]


def test_run_breadth_with_sub_questions_and_gap_round(ws, ids, tmp_path):
    a, m = ids["a"], ids["m"]
    fm = FirstMoveResult(clues=[Clue(text="x")], opening_observation="o", candidate_doc_ids=[a, m])
    d = RouteDecision(mode=RouteMode.breadth, rationale="r", sub_questions=["original cap", "amended cap"])
    planner = get_scripted_llm([AIMessage(content='{"gaps": ["Did the margin change?"]}')])
    bank = EvidenceBank(ws)
    res = run_breadth("What caps apply?", d, fm, ws, bank, serial(), llms={"researcher": get_scripted_llm(researcher_script(a, m)), "planner": planner},
                      trace=Trace(tmp_path / "t.jsonl", "t"))
    assert [f.sub_question for f in res.findings] == ["original cap", "amended cap", "margin"]
    assert res.gaps == ["Did the margin change?"] and res.failed_units == [] and len(bank) == 2
    merged = res.merged_answer()
    assert "- original cap: 3.50 [e1]" in merged and "margin (not in its documents)" in merged


def test_run_breadth_grid_only(ws, ids, tmp_path):
    a, c, m = ids["a"], ids["c"], ids["m"]
    fm = FirstMoveResult(clues=[Clue(text="x")], opening_observation="o", candidate_doc_ids=[a, c, m])
    d = RouteDecision(mode=RouteMode.single, rationale="r")
    extractor = get_scripted_llm([
        AIMessage(content=json.dumps({"found": True, "answer": "3.50", "quote": QUOTE, "start_line": 17, "end_line": 17})),
        AIMessage(content=json.dumps({"found": False})),
        AIMessage(content=json.dumps({"found": True, "answer": "4.00", "quote": AMEND, "start_line": 9, "end_line": 9})),
    ])
    res = run_breadth("leverage cap", d, fm, ws, EvidenceBank(ws), serial(), llms={"extractor": extractor},
                      bm25=BM25Index(ws), grid_only=True)
    assert res.grid is not None and res.grid.n_added == 2 and res.findings == [] and res.gaps == []


def test_pipeline_a3_fanout_end_to_end(docs, ids, tmp_path):
    a, m = ids["a"], ids["m"]
    planner = get_scripted_llm([
        AIMessage(content=json.dumps({"clues": [{"text": "cap", "grep_patterns": ["Leverage Ratio"], "bm25_query": "leverage ratio"}]})),
        AIMessage(content='{"gaps": []}'),
    ])
    router = get_scripted_llm([AIMessage(content='{"mode": "breadth", "rationale": "each document", "sub_questions": ["original cap", "amended cap"]}')])
    drafts = {"original cap": "The original cap is 3.50 to 1.00 {{CITE:e1}}.", "amended cap": "The amendment raises it to 4.00 to 1.00 {{CITE:e2}}."}

    def by_title(messages):
        prompt = messages[-1].content
        for t, d in drafts.items():
            if f'Write the section "{t}"' in prompt:
                return AIMessage(content=d)
        raise AssertionError(prompt[:200])

    writer = get_scripted_llm([by_title, by_title])      # one draft per fan-out finding, no outline call
    p = Pipeline(serial(), llms={"planner": planner, "router": router, "researcher": get_scripted_llm(researcher_script(a, m)[:4]), "writer": writer})
    state = p.run("What leverage caps apply across the Acme documents?", docs, variant="A3_fanout", root=tmp_path / "run")
    assert state["route"]["mode"] == "breadth" and "breadth" in state["stage_ms"] and "research" not in state["stage_ms"]
    assert state["research_done"] == "submitted" and not state["partial"] and state["errors"] == []
    assert len(state["findings"]) == 3 and state["findings"][0]["evidence_ids"] == ["e1", "e2"]
    assert [v["tier1"] for v in state["verify"]] == ["keep", "keep"] and f"[{m} p.1]" in state["report_md"]
    assert "## original cap" in state["report_md"] and "## amended cap" in state["report_md"] and len(writer.script) == 0


def test_pipeline_a3_grid_only_variant(docs, ids, tmp_path):
    planner = get_scripted_llm([AIMessage(content=json.dumps({"clues": [{"text": "cap", "grep_patterns": ["Leverage Ratio"], "bm25_query": "leverage ratio"}]}))])
    router = get_scripted_llm([AIMessage(content='{"mode": "single", "rationale": "one answer"}')])
    extractor = get_scripted_llm([AIMessage(content=json.dumps({"found": True, "answer": "cap", "quote": QUOTE, "start_line": 17, "end_line": 17}))] * 1
                                 + [AIMessage(content=json.dumps({"found": False}))] * 2)
    writer = get_scripted_llm([
        AIMessage(content=json.dumps({"sections": [{"section_id": "s1", "title": "Cap", "intent": "cap"}]})),
        AIMessage(content=json.dumps({"sections": [{"section_id": "s1", "title": "Cap", "intent": "cap", "evidence_ids": ["e1"]}]})),
        AIMessage(content="The cap is 3.50 to 1.00 {{CITE:e1}}."),
    ])
    p = Pipeline(serial(), llms={"planner": planner, "router": router, "extractor": extractor, "writer": writer})
    state = p.run("What is the leverage cap?", docs, variant="A3_grid_only", root=tmp_path / "run")
    assert state["route"]["mode"] == "single" and "breadth" in state["stage_ms"]       # grid_only ignores the router
    assert state["research_done"] == "submitted" and state["findings"][0]["evidence_ids"] == ["e1"]
    assert [v["tier1"] for v in state["verify"]] == ["keep"]


# --------------------------------------------------------------------------- fixes from the first live breadth run

def test_extract_json_tolerates_string_line_numbers():
    from dr.tools.extract import ExtractJSON
    j = ExtractJSON.model_validate({"found": True, "quote": "q", "start_line": "L12", "end_line": "12-13"})
    assert (j.start_line, j.end_line) == (12, 12)
    assert ExtractJSON.model_validate({"found": False, "start_line": "none"}).start_line is None


def test_outline_from_findings_one_section_per_unit(ws, ids):
    from dr.agents.writer import outline_from_findings, write_report
    from dr.models import Finding
    a, m = ids["a"], ids["m"]
    bank = EvidenceBank(ws)
    bank.add(a, 17, 17, QUOTE, "cap", created_by="fanout:1")
    bank.add(m, 9, 9, AMEND, "amended", created_by="fanout:2")
    bank.add(a, 11, 11, '"Applicable Margin" means 2.25% per annum for Term SOFR Loans.', "margin", created_by="fanout:3")
    fs = [Finding(sub_question="Does the Credit Agreement cap leverage?", answer="yes [e1]", evidence_ids=["e1"]),
          Finding(sub_question="Does the First Amendment change the cap?", answer="yes [e2]", evidence_ids=["e2", "e77"]),
          Finding(sub_question="margin", answer="not asked", evidence_ids=[], not_in_corpus=True)]
    secs = outline_from_findings(fs, bank)
    assert [s.section_id for s in secs] == ["s1", "s2", "s3"] and secs[0].evidence_ids == ["e1"] and secs[1].evidence_ids == ["e2"]
    assert "e3" in secs[0].evidence_ids + secs[1].evidence_ids + secs[2].evidence_ids      # leftover placed, never hidden
    assert secs[0].title == "Does the Credit Agreement cap leverage"
    drafts = {"Does the Credit Agreement cap leverage": "Yes: \"" + QUOTE + "\" {{CITE:e1}}.",
              "Does the First Amendment change the cap": "Yes {{CITE:e2}}.", "margin": "[GAP] not asked"}
    def by_title(messages):
        prompt = messages[-1].content
        for t, d in drafts.items():
            if f'Write the section "{t}"' in prompt:
                return AIMessage(content=d)
        raise AssertionError(prompt[:200])
    llm = get_scripted_llm([by_title] * 3)          # no outline or revision call: only the three drafts
    report = write_report("What caps apply?", bank, llm=llm, findings=fs)
    assert any("outline from 3 fan-out findings" in n for n in report.notes) and len(llm.script) == 0
    assert report.markdown.count("## ") == 3 and QUOTE in report.markdown


def test_docs_named_in_scopes_units_to_the_named_agreement(ws, ids):
    from dr.agents.fanout import docs_named_in
    assert docs_named_in("Does the First Amendment to the Credit Agreement for Acme Industrial change the cap?", ws)[0] == ids["m"]
    acme = docs_named_in("What does Acme Industrial owe First National?", ws)
    assert set(acme) == {ids["a"], ids["c"], ids["m"]}          # all three name the same parties: tie, all in scope
    assert docs_named_in("What is the weather like?", ws) == []
    fm = FirstMoveResult(clues=[Clue(text="x")], opening_observation="o", candidate_doc_ids=[ids["a"], ids["c"], ids["m"]])
    d = RouteDecision(mode=RouteMode.breadth, rationale="r",
                      sub_questions=["Does the First Amendment to the Credit Agreement change the leverage cap?", "What is the margin?"])
    units = plan_units(d, fm, ws)
    assert units[0].doc_ids[0] == ids["m"] and set(units[0].doc_ids) <= {ids["a"], ids["c"], ids["m"]}
    assert units[1].doc_ids == [ids["a"], ids["c"], ids["m"]]            # nothing named: the first-move candidates


def test_grid_scope_keeps_every_named_agreement_and_units_get_outlines(ws, ids, tmp_path):
    from dr.agents.fanout import docs_named_in
    q = "Among the Credit Agreement for Acme Industrial and the First Amendment, which cap leverage?"
    assert set(docs_named_in(q, ws, near_ties=False)) == {ids["a"], ids["c"], ids["m"]}
    unit = FanoutUnit(index=1, sub_question="Does the First Amendment change the cap?", doc_ids=[ids["m"]])
    script = [ai(tc("add_evidence", {"doc_id": ids["m"], "start_line": 9, "end_line": 9, "quote": AMEND, "note": "n"}),
                 tc("submit", {"sub_question": "s", "answer": "4.00 [e1]", "evidence_ids": ["e1"]}))]
    llm = get_scripted_llm(script)
    findings, failed = run_units([unit], "q", ws, EvidenceBank(ws), serial(), llm=llm)
    system = next(m for m in llm.seen[0] if isinstance(m, SystemMessage)).content
    assert "outline " + ids["m"] in system and "1. Amendments" in system        # the unit's briefing carries the TOC
    assert findings[0].evidence_ids == ["e1"] and failed == []


def test_forced_submit_without_evidence_is_low_confidence_not_a_failure(ws, ids, tmp_path):
    from dr.agents.researcher import ResearchContext, ResearchLoop
    from dr.tools.read import ReadTracker
    cfg = replace(DEFAULT, agents=replace(DEFAULT.agents, RESEARCH_MIN_CALLS=1, RESEARCH_MAX_CALLS=1))
    script = [ai(tc("grep", {"pattern": "nothing here"})),
              ai(tc("submit", {"sub_question": "s", "answer": "Could not locate the clause.", "evidence_ids": []}))]
    ctx = ResearchContext(ws=ws, bank=EvidenceBank(ws), tracker=ReadTracker(), config=cfg, llm=get_scripted_llm(script))
    run = ResearchLoop(ctx).run("q")
    assert run.done == "forced_submit" and run.finding.confidence == "low" and run.finding.evidence_ids == []
    assert run.finding.answer.startswith("[No evidence could be saved")


def test_model_caller_timeout_capped_by_client_timeout():
    import time as _t

    from langchain_core.messages import HumanMessage

    from dr.structured import ModelCaller
    llm = get_scripted_llm([AIMessage(content="x")])
    llm.timeout = 30                                                        # pretend to be a client with a 30 s timeout
    caller = ModelCaller(llm, None, "s", "r", deadline_ts=_t.time() + 300)
    assert caller.text([HumanMessage(content="q")]) == "x" and llm.last_kwargs["timeout"] == 30
