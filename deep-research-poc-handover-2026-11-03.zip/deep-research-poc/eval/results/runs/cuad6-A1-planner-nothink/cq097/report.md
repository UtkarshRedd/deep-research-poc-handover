# What non-compete clause does the Exclusive Distributor Agreement between WATER NOW, INC...

*Question:* What non-compete clause does the Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc. (dated 2019-11-12) contain? Quote the clause and cite its page.

## Identify the Exclusive Distributor Agreement

The Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc. dated 2019-11-12 is present on page 1. [c3ea62bed0707060 p.1] The document identifies the parties as WATER NOW, INC. [uncited] ("Water Now"), Hydraspin USA, Inc. [uncited] ("Subsidiary"), and BESTEV MANAGEMENT, LLC ("Distributor"). [c3ea62bed0707060 p.1]

[GAP] The non-compete clause is not present in the provided evidence.

## Locate the non-compete clause

The Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc., dated 2019-11-12, does not contain a provision explicitly labeled as a non-compete clause. [c3ea62bed0707060 p.3] [c3ea62bed0707060 p.4] The closest provision to a non-compete is Section 2.3 Noncircumvention, located on page 4. [c3ea62bed0707060 p.4] This section states: "2.3 Noncircumvention. [uncited] Hydraspin certifies, stipulates, and agrees that the Hydraspin will deal exclusively with and through the Distributor in relation to the distribution of the Products in the Territory. [uncited] Hydraspin will not in any way or in any capacity, either directly or indirectly (including without limitation acting by, with or through one or more Persons in which the Hydraspin has an interest and/or with whom Hydraspin has a relationship): except pursuant to an agreement with the Distributor, (a) contact, approach or negotiate with any Customer outside of the Distributor, or (b) contact,…". [c3ea62bed0707060 p.4]

[GAP] The exact page number where a non-compete clause appears is missing because no such clause is present in the provided evidence.

## Not established by the evidence

[GAP] No evidence was found for: Establish the verbatim text of the non-compete clause as it appears in the agreement.

## Verification appendix

Claims: 12 · supported: 5 · partially: 0 · dropped: 0 · gaps: 7 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Quote the non-compete clause

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e3→[c3ea62bed0707060 p.1] |  |
| s1.2 | s1 | gap |  |  | no evidence cited |
| s1.3 | s1 | gap |  |  | no evidence cited |
| s1.4 | s1 | keep | 1.00 | e3→[c3ea62bed0707060 p.1] |  |
| s1.5 | s1 | gap |  |  |  |
| s2.1 | s2 | keep | 1.00 | e1→[c3ea62bed0707060 p.3] e2→[c3ea62bed0707060 p.4] |  |
| s2.2 | s2 | keep | 1.00 | e2→[c3ea62bed0707060 p.4] |  |
| s2.3 | s2 | gap |  |  | no evidence cited |
| s2.4 | s2 | gap |  |  | no evidence cited |
| s2.5 | s2 | keep | 1.00 | e2→[c3ea62bed0707060 p.4] |  |
| s2.6 | s2 | gap |  |  |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [c3ea62bed0707060 p.3 L107-121] keep (1.0): "ARTICLE II. APPOINTMENT 2.1 Exclusivity and Territory. Hydraspin hereby appoints Distributor, and Distributor hereby accepts appointment, as Hydraspin's exclusive distributor of the Products in the Territory during the term of this Agreemen…"
- e2 [c3ea62bed0707060 p.4 L129-141] keep (1.0): "2.3 Noncircumvention. Hydraspin certifies, stipulates, and agrees that the Hydraspin will deal exclusively with and through the Distributor in relation to the distribution of the Products in the Territory. Hydraspin will not in any way or i…"
- e3 [c3ea62bed0707060 p.1 L1-15] keep (1.0): "# EXCLUSIVE DISTRIBUTOR AGREEMENT | Field | Value | |---|---| | Document Type | Distributor Agreement | | Agreement Date | 2019-11-12 | | Parties | WATER NOW, INC.; ("Water Now"); Hydraspin USA, Inc. ("Subsidiary", collectively with Water N…"
