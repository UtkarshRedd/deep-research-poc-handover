<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2017-10-30 |
| Parties | National Football League Alumni - Northern America Chapter ("NFLA-NC"); National Football League Alumni, Inc ("NFLA"); Food For Athletes, Inc./Gridiron BioNutrients™ (collectively the "Company") |
| Source | CUAD v1 / GridironBionutrientsInc_20171206_8-K_EX-10.1_10972555_EX-10.1_Endorsement Agreement |

EXHIBIT 10.1 ENDORSEMENT AGREEMENT This Endorsement Agreement ("Agreement") made October 30, 2017,
between National Football League Alumni - Northern California Chapter ("NFLA-NC"), a charitable
corporation organized under the laws of California, having its principal office at 1311 Madison
Avenue, Redwood CA 94061; National Football League Alumni, Inc. ("NFLA"), a charitable corporation
organized under the laws of Florida, having its principal office at 8000 Midlantic Drive, 130 S.,
Mount Laurel, NJ. 08054 and Food For Athletes, Inc. a corporation organized under the laws of
California / Gridiron BioNutrients™, a corporation organized under the laws of Nevada having their
principal office(s) at 1119 West 1st Ave., STE G, Spokane, WA 99201 (collectively the "Company").
RECITALS A. Whereas, NFLA is a nationwide group of former National Football League players, coaches,
and other employees whose mission is to serve, assist and inform players and their families. The
association offers a variety of medical, financial and social programs to help members lead healthy,
productive and connected lives. B. Whereas, NFLA-NC is a local Chapter of the NFLA and supports the
organizations "Caring for Kids" initiative through fundraising for youth-related charities. C. The
Company desires to obtain the rights to use the Pro Football Legends Logo of the NFLA in connection
with the advertisement and promotion of certain of its products. An image of the Pro Football
Legends Logo is depicted in Exhibit A. D. The NFLA agrees to license such rights to the Company. In
consideration of the matters described above, and of the mutual benefits and obligations set forth
in this Agreement, the parties agree as follows: SECTION ONE. DEFINITIONS As used in this Agreement,
the following terms shall be defined as follows: A. "Contract Period" shall mean that period of time
of three (3) years commencing on November 1st, 2017 and concluding November 2nd, 2020, unless
terminated sooner or extended as provided in this Agreement. B. "Contract Territory" shall mean
worldwide. C. "Contract Year" shall mean each of the consecutive 12-month periods beginning on the
effective date of the Agreement of the Contract Period. 1

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
<!-- page 2 -->
D. "Gross Sales" shall mean total revenues, under generally accepted accounting principles, from
sales of the Licensed Products, but does not include any revenue from sales, use or other
transaction taxes, duties, handling, graphics, embroidery or shipping. E. "Net Sales" shall mean
Gross Sales less Product returns, trade discounts, samples, allowances, value added services,
markdowns, customer charge backs and liquidation sales (substantially discounted and out of ordinary
distribution channel) of Licensed Products. F. "Licensed Products" shall mean BlackMP Living Water,
BlackMP Concentrate, Zezel Probiotic Water, Zayin Sports Water, Gridiron MVP™ and Gridiron MVP™
Concentrate using the Pro Football Legends Logo on the Licensed Products' affixed labels, hang-tags
or packaging. Other products of the Company may be added to the list of Licensed Products during the
Contract Period by written amendment to this Agreement. All amendments to this Agreement must be
signed by all parties to this Agreement. G. "Products" shall mean goods manufactured, distributed or
otherwise sold by the Company. H. "Licensed Marks" shall mean in connection with the rights and
benefits granted to Company hereunder as set forth in General Terms. Company may utilize only the
logo and other trademarks listed on Exhibit A (the "Licensed Marks") during the Term and within the
Territory solely in connection with advertising and promotional materials that identify Company as a
sponsor of the Pro Football Legends, provided that NFLA first approves all such uses in writing. Any
use of the Licensed Marks will bear the trademark and/or copyright notices required by NFLA to
facilitate its trademark protection program and will be a "work made for hire" for NFLA. All of
Company's uses of the Licensed Marks shall inure to the benefit of the NFLA. After the expiration or
termination of this Agreement, Company will refrain from further use of the Licensed Marks used
pursuant to this Agreement. Company will not sublicense pass-through or otherwise grant to any third
parties the rights granted to Company hereunder without the NFLA prior written consent, including
but not limited to the right to use the Licensed Marks. Company acknowledges that this Agreement
does not grant Company any rights with respect to any other NFLA Marks (defined below), the name,
likeness, signature, or other attributes of any NFLA member or other individual, or any audio or
video of any NFLA event. Company agrees that the quality of all services offered by Company under
the Licensed Marks will conform to Licensor's written quality control standards and that Company
will annually provide to NFLA samples of any advertising and marketing materials that use the
Licensed Marks. I. "Trademark Protection" for the purposes of this agreement, "NFLA MARKS" means the
names, symbols, emblems, designs, and colors of the NFLA, including but not limited to the Licensed
Marks. Company acknowledges and agrees that all right, title and interest in and to the NFLA marks
belongs to the NFLA. Company agrees that NFLA marks possesses a special, unique and extraordinary
character that makes difficult assessment of the monetary damages that would be sustained by their
unauthorized use. Company recognizes that irreparable injury would be caused by unauthorized use of
any of the NFLA marks, and agrees that injunctive and other equitable relief would be appropriate in
the event of such unauthorized use, and that such remedy would not be exclusive of other legal
remedies available to NFLA. Company recognizes that great value and goodwill associated with NFLA
marks belongs to the NFLA and that the NFLA marks have secondary meaning. 2

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
<!-- page 3 -->
J. "NFLA Identification" means the right to use, subject to the provisions of this Agreement, the
NFLA name, and Pro Football Legends Logo and any other means of endorsement by the NFLA used in
connection with the advertisement and promotion of the Company and the Licensed Products. K. "One
(1) Unit" shall represent $0.05 (1 Unit = $0.05USD) for purposes of defining the monetary donation
allocation of the Company's sold products to the NFLA-NC, specific to the terms of this Agreement. A
Licensed Product in no circumstance shall be valued at less than one (1) full Unit and under no
circumstance shall a Unit be fractionalized (if required rounded up to the nearest whole number).
SECTION TWO. GRANT OF RIGHTS In consideration of the remuneration to be paid to the NFLA-NC pursuant
to this Agreement, the NFLA grants to Company and to its authorized distributors and sublicenses the
right and license during the Contract Period to use the NFLA Identification solely in connection
with the advertisement, marketing and promotion of the Products within the Contract Territory as set
forth in this Agreement. NFLA agrees not to grant the right to use the NFLAs Identification to
anyone other than Company in connection with the advertisement and promotion of Products. It is
understood that Company, its authorized distributors and sublicenses may not use the name of the
NFLA in connection with any items for sale or resale, other than the Products as specified in this
Agreement. The foregoing rights to use the name of the NFLA is limited to television, radio and
print advertising, advertising published over the Internet (provided that such material is limited
to advertising or Product promotion only), public relations and marketing materials, point-of-sale
displays, free standing inserts, videos shown to customers and consumers, catalogs for customers and
consumers, direct mail (including e-mail) and billboards. Company shall ensure that all uses of the
name of the NFLA comply with applicable law. SECTION THREE. PRIOR APPROVAL Company agrees that no
use of the name of the NFLA Identification nor any item used in connection with the name of NFLA
Identification (including any Licensed Product) will be made under this Agreement unless and until
the same is approved by the NFLA. The NFLA agrees that any material, advertising or otherwise,
submitted for approval as provided in this section may be deemed by Company to have been approved
under this section if the same is not disapproved in writing within ten (10) business days after
receipt of the material. The NFLA agrees that it will reasonably cooperate with Company and that any
material submitted under this section will not be unreasonably disapproved and, if it is
disapproved, that Company will be advised of the specific grounds for disapproval. If Company
desires immediate approval of advertising material, Company shall have the right to directly contact
the NFLA's authorized agent to obtain such approval. Company agrees to protect, indemnify and hold
harmless the NFLA and their authorized agents, or any of them, from and against any and all
expenses, damages, claims, suits, actions, judgments and costs whatsoever, arising out of, or in any
way connected with any advertising material furnished by, or on behalf of Company, except with
respect to any inaccurate information furnished by them expressly for use in such advertising. 3

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
<!-- page 4 -->
SECTION FOUR. REMUNERATION In consideration of the endorsement rights granted under this Agreement,
Company shall provide the following remuneration: A. An initial one-time license fee of
$35,000.00USD (Thirty-Five Thousand Dollars) payable to the NFLA-NC; B. A one-time $10,000USD (Ten
Thousand Dollars) promotional fee payable to NFLA. The $10,000 promotional fee shall be payable in
four (4) quarterly payments beginning in 2018: Q1 ($2500); Q2 ($2500); Q3 ($2500); Q4 ($2500). Each
payment shall be delivered by no later than the 10t h day of the first month of each quarter. C. A
*donation of $0.05 per Unit sold of Licensed Products within the Contract Territory payable to the
**NFL Alumni Northern California Chapter. Donated amounts will be allocated and dispersed to the
Northern California Chapter beginning on the first full quarter [three (3) month period] of the
Agreement and continue on a quarterly basis thereafter for the term of this Agreement. Where the
following per Unit conversion shall apply for the term of this Agreement:

a. (1) Bottle of BlackMP LivingWater = 1 Unit

b. (1 ) 4oz bo t t l e o f BlackMPConcentrate = 30 Units

c. (1) Bottle of Zezel ProbioticWater = 1 Unit

d. (1) Bottle of Zayin Sports Water = 1 Unit e. (1) Bottle Gridiron MVP™ Water= 1 Unit

f. (1) 4oz bottle of Gridiron MVP™Concentrate = 30 Units

_____________ * The NFLA-NC will donate 15% of the above described proceeds to the NFLA.

** The Company will provide to the NFLA-NC upon request the most recent quarterly sales report of
the Company'sLicensed Products. D. Product Commitment. Up to Two-thousand (2,000) 4oz bottles of
BlackMP Living Water Concentrate to be used as a "value appeal" for annual membership renewal (up to
a $220,000 value) a l located to the NFLA and provide a combination/assortment of bottle water to
NFLA-NC for display and use though out the term of the Agreement at the NFLA-NC facilities. The
Company agrees to pay for all shipping costs of the Products under the Product Commitment to the
fulfillment center, currently Sharp Marketing, located in Fort Lauderdale, FL and to any subsequent
fulfillment center that is contracted by the NFLA to provide distribution to existing and new NFLA
members. E. Affiliated Partnership Commitment. Company agrees to facilitate and provide in
good-faith their affiliated partnership discount program benefits and access to applicable health
and wellness research, information and protocols to NFLA members (Current partnership benefit
includes providing NFLA members with a 15% discount on all Kraski's Nutrition Real Products For Real
People); and F. Marketing Commitment. Company agrees that it will continue in good-faith to produce
and market Licensed Products in the same manner that it is currently producing and marketing such
items as of September 2017, unless Company and the NFLA/NFLA-NC believe it is not commercially
reasonable to continue to produce and market the Licensed Products. 4

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
<!-- page 5 -->
SECTION FIVE. SERVICES OF COMPANY A. Resource Call Center. For the term of this Agreement Company
shall provide a call in center whereby NFLA members can call for information, ask questions, and
consult with Company's staff on details and specifics of the Company's Products and replenishment
program. SECTION SIX. SERVICES OF NFLA-NC A. If Company desires to use the services of the NFLA-NC
and/or any of its officers and members as a model in connection with Company advertising to promote
its Products or as a part of a special promotional appearance for the Company, the NFLA-NC agrees,
at the request of Company, to provide a good faith effort services of the officers or members of the
NFLA for a reasonable amount of time as mutually agreed upon by all parties and at places reasonably
convenient to each parties schedule. Each day shall not exceed a reasonable number of hours unless
otherwise mutually agreed upon. The Company agrees that it will reimburse the NFLA-NC and if
applicable the NFLA or its officers/members for all reasonable travel, lodging and meal expenses
incurred by the NFLA / NFLA-NC or its officers/members in connection with such services. The Company
understands that failure to use services of a member of the NFLA / NFLA-NC pursuant to this section
shall not result in any reduction in payments to NFLA-NC under this Agreement. The obligations of
the NFLA / NFLA-NC to provide services of its officers/members under this Agreement are subject to
the condition that payments to NFLA-NC are current and up to date. B. Should Company use any member
of the NFLA-NC in television advertising to promote Company's Products, Company will make all
applicable required union scale and pension and welfare payments. C. During the Contract Period,
NFLA-NC shall make a good faith effort to assure that its members shall wear Company Products at all
professional and promotional events and at all media appearances where appropriate, and when not in
conflict with its members existing agreements. It is agreed that the logo or name of Company (the
"Company Logo") shall be affixed to an appropriate location (i.e. shoulder-sleeve and/or back] of
all Company Products that members of the NFLA-NC wear. Company agrees that it will be responsible
for, and the cost of, affixing the Company Logo on all such Company Products. Company acknowledges
that other locations on the NFLA-NC Products are reserved for NFLA-NC's other sponsors. Furthermore,
Company understands that if the NFLA-NC or its Officers/members participate in a special team event
where there is an official uniform, then representatives of the NFLA-NC are permitted to wear such
uniform during such event. D. The NFLA shall list the Company as a sponsor on all of its promotional
materials, websites or other electronic media. The NFLA shall allow the Company to participate in
local and national NFLA functions (i.e. Super Bowl Parties, Award Ceremonies, Banquets, etc…) at the
Company's own expense. E. The NFLA shall promote Company and Company's products to NFLA database and
audience by deliverables listed in Exhibit B. 5

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
<!-- page 6 -->
SECTION SEVEN. PAYMENTS All payments shall be made by wire transfer drawn to the account of NFLA-NC
no later than ten (10) business days after the end of each quarter as follows: $0.05 per Unit as
described herein of Company's Products sold in the Contract Territory payable to NFLA-NC. Donated
amounts will be allocated and dispersed to the NFLA-NC beginning on the first full quarter (three
month period) of the Agreement and continue on a quarterly basis thereafter for the term of this
Agreement. Past due payments under this Agreement shall bear interest at the rate of: (a) 1% per
month; or (b) the maximum interest rate permissible under law, whichever is less. All amounts in
this section are in United States dollars. SECTION EIGHT. AUTHORIZED AGENT Each party shall
designate its authorized agent for all purposes under this Agreement. All notices or submissions to
be made or delivered by the Company, the NFLA or the NFLA-NC pursuant to this Agreement shall be
delivered to the agent's address below, free of all charges (for example, shipping charges and
customs charges). If any such shipping charges are paid by another party or by its authorized agent,
the corresponding party agrees to make prompt reimbursement. All notices or submissions to be made
or delivered to Company pursuant to this Agreement shall be delivered to: The Company Food For
Athletes/Gridiron BioNutrients™ Attention: Darren Long 1147 N Roseburg Ct STE A, Visalia CA, 93291
NFLA-NC National Football League Alumni - Northern California Chapter Attention: Russell Isaacson -
Comptroller 1311 Madison Avenue Redwood CA 94061 NFLA National Football League Alumni, Inc.
Attention: Elvis Gooden 8000 Midlantic Drive, 130 S. Mount Laurel, NJ. 08054 6

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
<!-- page 7 -->
SECTION NINE. DEFAULT A. If either party at any time during the Contract Period shall: (i) fail to
make any payment of any sum of money specified in this Agreement to be made; or (ii) fail to observe
or perform any of the covenants, agreements or obligations under this Agreement (other than the
payment of money), the non-defaulting party may terminate this Agreement as follows: As to a default
under clause (i) above, if such payment is not made within 10 business days after the defaulting
party shall have received written notice of such failure to make payment; or, as to a default under
clause (ii) above, if such other default is not cured within 30 days after the defaulting party
shall have received written notice specifying in reasonable detail the nature of such default. In
order to be a sufficient notice under this section, any such written notice shall specify in detail
each item of default and shall specify the provision of this Agreement which applies to each item of
default, and shall specify in detail the action the defaulting party is required to take in order to
cure each item of default. The termination rights set forth in this section shall not constitute the
exclusive remedy of the non-defaulting party under this Agreement, however, and if default is made
by either party under this Agreement, the other party may resort to such other remedies as such
party would have been entitled to if this section had been omitted from this Agreement, subject to
the terms of this Agreement. Termination under the provisions of this section shall be without
prejudice to any rights or claims which the terminating party may otherwise have against the
defaulting party, and if Company is the defaulting party, Company shall be responsible for any and
all payments due under the terms of this Agreement in addition to other liabilities set forth above.
B. If Company shall become bankrupt or insolvent, or if Company's business shall be placed in the
hands of a receiver, assignee or trustee, whether by voluntary act of Company or otherwise, the
Contract Period, at the election of NFLA, shall immediately terminate. SECTION TEN. USE OF THE
NFLA/NFLA-NC's IDENTIFICATION AFTER TERMINATION A. Except as provided in paragraph B of this SECTION
TEN, from and after the termination of the Contract Period, all of the rights of Company to the use
of the name of the NFLA shall cease absolutely and Company subsequently shall not use or refer to
the NFLA in advertising or promotion in any manner whatsoever. Except as provided in paragraph B
below, it is further agreed that following termination of the Contract Period, Company shall not
advertise, promote, distribute or sell any item whatsoever in connection with the use of any name,
figure, design, logo, trademark or trade name similar to or suggestive of the NFLA. 1. Company may
liquidate and sell its inventory of Licensed Products (including any inventory then in production)
for a period of ninety (90) days after the termination date of the Contract Period, subject to the
Company's continued obligation to pay the Fee as provided above, and will deliver the Sales Report
with respect to such liquidation sales within 30 days following the end of the first reached full
quarter following termination. 2. If Company has not disposed of all Licensed Products as provided
in subparagraph 1 above by the end of the 90 day period, Company, at its option, may either: (a)
remove or obliterate entirely from such Licensed Products (and any labels, tags, riders and the
like) all references to any NFLA Identification, and then sell the same; or (b) destroy all such
remaining Licensed Products. 7

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
<!-- page 8 -->
SECTION ELEVEN. TRADEMARKS Company agrees that it will not file, during the Contract Period or
afterward, any application for trademark registration or otherwise obtain or attempt to obtain
ownership of any trademark or trade name within the Contract Territory or in any other country of
the world which consists of the NFLA Identification or any mark, design or logo intended to obtain
any rights to the name of the NFLA or to identify products as being endorsed b the NFLA. SECTION
TWELVE. RESERVATION OF RIGHTS All rights not specifically granted in this Agreement to Company shall
remain the property of the NFLA to be used in any manner the NFLA deems appropriate. Company
understands that the NFLA has reserved the right to authorize others to use the name of the NFLA
within the Contract Territory and during the Contract Period in connection with all tangible and
intangible items and services other than Products themselves. NFLA is not aware of any such rights
that would conflict with the nature or image of Company Products. SECTION THIRTEEN. INDEMNITY
Company agrees to protect, indemnify and hold harmless the NFLA / NFLA-NC and their authorized
agents, or any of them, from and against any and all expenses, damages, claims, suits, actions,
judgments and costs whatsoever, including reasonable attorney's fees, arising out of, or in any way
connected with, actions or omissions of Company, any advertising material furnished by, or an behalf
of, Company, or any claim or action for personal injury, death or other cause of action involving
alleged defects in Company's Products or services. Company agrees to provide and maintain, at its
own expense, general commercial and product liability insurance. SECTION FOURTEEN. SPECIAL RIGHT OF
TERMINATION Company shall have the right to terminate this Agreement, upon written notice to the
NFLA / NFLA-NC, if the commercial value of the NFLA's endorsement is substantially reduced because
an officer of the NFLA / NFLA-NC: (i) has been charged with illegal or immoral conduct which could
result in a felony conviction and such charges have not been dismissed or terminated within 90 days.
Any termination pursuant to this section shall become effective on the business day next following
the date of receipt by NFLA of Company's written notice to so terminate. SECTION FIFTEEN. CONTRACT
EXTENSION Due to long product development lead times, Company and NFLA-NC agree to begin discussions
for the renewal of this Agreement by no later than June 1st, 2020. All terms of this Agreement will
automatically commence on November 1st, 2017, and expire on November 2nd, 2020. 8

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
<!-- page 9 -->
SECTION SIXTEEN. LIMITED LIABILITY Notwithstanding anything to the contrary in this Agreement, if
Company incurs any expenses, damages or other liabilities (including but not limited to reasonable
attorney's fees) in connection with the performance or nonperformance of any term or provision of
this Agreement, NFLA's liability to Company shall not exceed the remuneration, excluding
reimbursement of expenses, actually paid to NFLA by Company. In no event will NFLA be liable for any
indirect, incidental, reliance, special or consequential damages arising out of the performance or
nonperformance of this Agreement, whether or not NFLA had been advised of the possibility of such
damages. SECTION SEVENTEEN. WAIVER The failure of either party at any time or times to demand strict
performance by the other party of any of the terms, covenants or conditions set forth in this
Agreement shall not be construed as a continuing waiver or relinquishment of the same and each party
may at any time demand strict and complete performance by the other party of such terms, covenants
and conditions. Any waiver of such rights must be set forth in writing. SECTION EIGHTEEN.
SEVERABILITY If any provision of this Agreement shall be declared illegal, invalid, void or
unenforceable by any judicial or administrative authority, the validity of any other provision and
of the entire Agreement shall not be affected by such declaration. SECTION NINETEEN. ASSIGNMENT This
Agreement shall bind and inure to the benefit of Company and NFLA and their respective successors
and assigns. SECTION TWENTY. GOVERNING LAW; ARBITRATION This Agreement shall be governed by, and its
provisions enforced in accordance with, the laws of California without regard to its principles of
conflicts of laws. If a dispute arises under this Agreement which cannot be resolved, such dispute
shall be submitted to arbitration and resolved by a single arbitrator (who shall be a lawyer not
employed by or associated with either party to this Agreement) in accordance with the Commercial
Arbitration Rules of the American Arbitration Association then in effect. All such arbitration shall
take place at the office of the American Arbitration Association located within 225 miles of
Hayward, California. Each party is entitled to depose one fact witness and all expert witnesses
retained by the other party, and to conduct such other discovery as the arbitrator deems
appropriate. The award or decision rendered by the arbitrator shall be final, binding and conclusive
and judgment may be entered upon such award by any court. SECTION TWENTY-ONE. HEADINGS Section
headings contained in this Agreement are solely for the purpose of aiding in speedy location of
subject matter and are not in any sense to be given weight in the construction of this Agreement.
Accordingly, in case of any question with respect to the construction of this Agreement, it is to be
construed as though such section headings had been omitted. 9

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
<!-- page 10 -->
SECTION TWENTY-TWO. NO JOINT VENTURE This Agreement does not constitute and shall not be construed
as constituting an association, partnership, joint venture or relationship of principal and agent,
or employer and employee, between NFLA and Company. Neither party shall have any right to obligate
or bind the other party in any manner whatsoever except as expressly set forth in this Agreement,
nothing contained in this Agreement shall give, or is intended to give, any rights of any kind to
any person. SECTION TWENTY-THREE. ENTIRE AGREEMENT This writing constitutes the entire agreement
between the parties to this Agreement and may not be changed or modified except by a writing signed
by the party or parties to be charged by such change or modification. The parties have executed this
Agreement on October 30, 2017. Food For Athletes, Inc. / Gridiron BioNutrients™ By: /s/ Darren Long
Darren Long - CEO The National Football League Alumni, Inc. By: /s/ Elvis Gooden Elvis Gooden -
President NFL Alumni - Northern California Chapter By: /s/ Eric Price Eric Price - President 10

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
<!-- page 11 -->
EXHIBIT A PRO FOOTBALL LEGENDS LOGO

11

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
<!-- page 12 -->
EXHIBIT B NFLA agrees to promote Company and Company's products to NFLA database by: 1. E-blasts:
NFLA to send a minimum of two (2) dedicated e-blasts per year to NFLA database. All e-blast
communications must be approved in writing by Company; 2. Newsletter: NFLA to feature Company in
Weekly Newsletter "Partner Spotlight" a minimum of four (4) times per year. All newsletter
communications must be approved in writing by Company; and 3. Social Media: NFLA to feature Company
on all social media channels a minimum of four (4) times per year. All newsletter communications
must be approved in writing by Company. 12

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
