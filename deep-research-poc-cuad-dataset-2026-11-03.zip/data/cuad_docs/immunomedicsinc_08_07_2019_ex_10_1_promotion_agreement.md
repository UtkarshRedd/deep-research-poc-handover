<!-- page 1 -->
# PROMOTION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Promotion Agreement |
| Agreement Date | 2019-04-05 |
| Parties | Janssen Biotech, Inc. ("Janssen”); Immunomedics, Inc. ("Company") |
| Source | CUAD v1 / IMMUNOMEDICSINC_08_07_2019-EX-10.1-PROMOTION AGREEMENT |

CERTAIN IDENTIFIED INFORMATION HAS BEEN EXCLUDED FROM THIS EXHIBIT BECAUSE IT IS NOT MATERIAL AND
WOULD LIKELY CAUSE COMPETITIVE HARM TO THE REGISTRANT IF PUBLICLY DISCLOSED. [***] INDICATES THAT
INFORMATION HAS BEEN REDACTED.

PROMOTION AGREEMENT

by and between

JANSSEN BIOTECH, INC.

and

IMMUNOMEDICS, INC.

Dated as of: April 5, 2019
<!-- page 2 -->
TABLE OF CONTENTS

ARTICLE 1 DEFINITIONS 1

ARTICLE II BRAND PLAN 10 2.1 Brand Plan Generally 10 2.2 Contents of Brand Plan 10

ARTICLE III PROMOTION 12 3.1 Scope 12 3.2 Detailing Requirements 13 3.3 Sales Representatives 14 3.4
Promotional Materials 15 3.5 Product Sales 16 3.6 Product Recall 16 3.7 Product Return 17

ARTICLE IV GOVERNANCE 17 4.1 Authority 17 4.2 Joint Commercial Team 17 4.3 BALVERSA Sales Advisory
Team 18

ARTICLE V COMPENSATION 18 5.1 Definitions 18 5.2 Service Fees 18 5.3 Milestones 19 5.4 Costs 20 5.5
Reports and Payments 20

ARTICLE VI REGULATORY MATTERS 21 6.1 Regulatory Approvals 21 6.2 Pharmacovigilance Procedures 22 6.3
Product Complaints 22 6.4 Post-Marketing Surveillance 22 6.5 Product Medical Inquiries 22 6.6
Companion Diagnostic Inquiries 22 6.7 Access, Affordability and Patient Support Inquiries 23

ARTICLE VII BOOKS, RECORDS AND AUDIT RIGHTS 23 7.1 Books and Records 23 7.2 Books and Records Audits
23

ARTICLE VIII TERM AND TERMINATION 24 8.1 Term; Termination 24 8.2 Effect of Termination or
Expiration 26 8.3 Suspension of Product Promotion 28
<!-- page 3 -->
ARTICLE IX CONFIDENTIALITY; RESTRICTIVE COVENANTS 28 9.1 Confidentiality 28 9.2 Exclusivity 31 9.3
Restrictions on Promotions 31 9.4 Limitation on Soliciting Employees 31

ARTICLE X INTELLECTUAL PROPERTY 32 10.1 Use of Trademarks 32 10.2 Ownership of Intellectual Property
Rights 32 10.3 Prosecution and Maintenance 33 10.4 Enforcement against Infringement 33 10.5 Third
Party Infringement Claims 33

ARTICLE XI REPRESENTATIONS AND WARRANTIES; CERTAIN COVENANTS 33 11.1 Representations of Authority 33
11.2 Consents 33 11.3 No Conflict 33 11.4 Enforceability 33 11.5 Sales Representatives and Other
Company Employees 34 11.6 Other Compliance Matters 34 11.7 Infringement of Third Party Intellectual
Property; Clinical Trial Data 36 11.8 Disclaimer 36

ARTICLE XII INDEMNIFICATION; LIMITS ON LIABILITY 37 12.1 Scope of Indemnification 37 12.2 Notice and
Control of Actions 38 12.3 Limitations on Liability 39

ARTICLE XIII DISPUTE RESOLUTION 39 13.1 Disputes 39 13.2 Negotiation 39 13.3 Mediation 40 13.4
Arbitration 40 13.5 Confidentiality 42

ARTICLE XIV MISCELLANEOUS 42 14.1 Press Announcements 42 14.2 Force Majeure Event 42 14.3
Independent Contractors 43 14.4 Performance by Affiliates 43 14.5 Notices 43 14.6 Entire Agreement
44 14.7 Amendments; Assignment 44
<!-- page 4 -->
14.8 Non-Waiver of Rights 14.9 Further Assurances and Cooperation 14.1 Severability 14.11 Binding
Effect 14.12 Counterparts; Facsimile Signatures 14.13 Third Party Beneficiaries 14.14 Governing Law
14.15 Construction

Schedule 1.16 Janssen Universal Calendar

Schedule 6.2 Pharmacovigilance Provisions

Exhibit A Brand Plan

Exhibit B Detailing Requirements

Exhibit C Records and Information Management Requirements

Exhibit D Health Care Compliance Provisions
<!-- page 5 -->
PROMOTION AGREEMENT

This PROMOTION AGREEMENT (this "Agreement") dated as of April 5, 2019 (the "Effective Date"), is
entered into by and between Janssen Biotech, Inc., a corporation organized under the laws of
Pennsylvania ("Janssen") and Immunomedics, Inc., a corporation organized under the laws of Delaware
("Company").

WHEREAS, before the Effective Date, Janssen submitted an application for approval to market and/or
sell the Product (defined below) for the Initial Indication (defined below) in the Territory
(defined below); and

WHEREAS, Janssen now wishes to engage Company to Promote (defined below) the Product for the Initial
Indication in the Territory and Company wishes to be so engaged, subject to and upon the terms and
conditions set forth in this Agreement;

NOW, THEREFORE, in consideration of the mutual representations, warranties, covenants and
undertakings contained in this Agreement, and for other good and valuable consideration, the receipt
and sufficiency of which are hereby acknowledged, the Parties, intending to be legally bound, agree
as follows:

ARTICLE I DEFINITIONS

Unless otherwise defined herein, capitalized terms used in this Agreement have the meanings set
forth in this Article I.

1.1 "Acquirer" has the meaning set forth in Section 9.2.

1.2 "Acquisition" has the meaning set forth in Section 9.2.

1.3 "Action" means any claim, action, cause of action or suit (whether in contract or tort or
otherwise), litigation (whether at law or in equity, whether civil or criminal), assessment,
arbitration, investigation, hearing, charge, complaint, demand, notice or proceeding from, by or
before any Governmental Authority.

1.4 "Affiliate" means with respect to a Party, any Person that is directly or indirectly
controlling, controlled by or under common control with such Party at the time that the
determination of affiliation is made. For the purposes of this definition, "control" of a Person
means (a) beneficial ownership of at least fifty percent (50%) of the voting securities or other
comparable equity interests of such Person (whether directly or pursuant to any option, warrant or
other similar arrangement) or (b) the possession, directly or indirectly, of the power to direct the
management and policies of such Person, whether through the ownership of voting securities, by
contract, declaration of trust or otherwise, and the terms "controlling" and "controlled" shall have
meanings correlative to the foregoing.

1.5 "Agreement" has the meaning set forth in the preamble to this Agreement.

1.6 "Approval Date" means the date upon which Marketing Approval is received for

the Product for the Initial Indication.
<!-- page 6 -->
1.7 "Audit Report" has the meaning set forth in Section 7.2.2.

1.8 "Audited Party" has the meaning set forth in Section 7.2.1.

1.9 "Auditing Party" has the meaning set forth in Section 7.2.2.

1.10 "Balversa-only Target" has the meaning set forth in Exhibit B.

1.11 "Baseline" has the meaning set forth in Section 5.1.1.

1.12 "Books and Records" has the meaning set forth in Section 7.1.

1.13 "Brand Plan" has the meaning set forth in Section 2.1.

1.14 "BSAT" has the meaning set forth in Section 4.3.1.

1.15 "Business Day" means any day other than a Saturday or a Sunday or other day on which commercial
banks are authorized or required to be closed in New York, New York.

1.16 "Calendar Quarter" means a calendar quarter based on that certain universal calendar system
used by Janssen and each of its Affiliates for internal business purposes (a copy of which calendar
for 2019 and 2020 is attached hereto as Schedule 1.16), such that each Calendar Quarter ends on the
last date of the calendar quarter indicated on Schedule 1.16 (the "Quarter End Date") and begins on
the date following the Quarter End Date of the preceding Calendar Quarter.

1.17 "Calendar Year" means a calendar year based on that certain universal calendar system used by
Janssen and each of its Affiliates for internal business purposes (a copy of which calendar for 2019
and 2020 is attached hereto as Schedule 1.16), such that each Calendar Year ends on the fourth
Quarter End Date for such year and begins on the date following the fourth Quarter End Date of the
preceding Calendar Year.

1.18 "Call" means an in-person visit by an adequately trained sales representative to the office of
a health care professional in the Territory for the purpose of promoting or presenting one or more
pharmaceutical products.

1.19 "Call Plan" has the meaning set forth in Section 2.2.3.

1.20 "CPR Mediation Procedure" has the meaning set forth in Section 13.3.1.

1.21 "CPR Rules" has the meaning set forth in Section 13.4.

1.22 "Companion Diagnostic" means the diagnostic test approved by FDA concurrently with the Product
for use in conjunction with the Product.
<!-- page 7 -->
1.23 "Company" has the meaning set forth in the preamble to this Agreement.

1.24 "Company Indemnified Parties" has the meaning set forth in Section 12.1.1.

1.25 "Company Internal Detail Reporting System" means the data and records collected by Company and
its Affiliates, in accordance with its standard business practice, to monitor Details made by Sales
Representatives, which, with respect to the Product, include the date a Detail was made, the name of
the Target to whom the Detail was made, the indication(s) for which the Product was presented, and
the identity of the Sales Representative who delivered the Detail.

1.26 "Company Product" means the drug that is being developed by Company on the Effective Date,
known as "IMMU- 132" or sacituzumab govitecan.

1.27 "Company Product Approval Date" means the date upon which Marketing Approval is first received
in the Territory for the Company Product.

1.28 "Company Trademark" means any Trademark owned by Company or any of its Affiliates.

1.29 "Competing Product" means any pharmaceutical product that is (a) approved specifically for use,
in the treatment of urothelial cancer in any patient population in the Territory or (b) a fibroblast
growth factor receptor inhibitor. If the Parties agree to extend the Term beyond the Expiration
Date, Competing Product shall not include Company Product after the Expiration Date.

1.30 "Confidential Information" of a Party means (a) all non-public or proprietary information and
data (including clinical data, technology, trade secrets, design specifications, dossiers,
manufacturing formulae, manufacturing procedures and instructions, methods and processes, formats,
designs, applications and programs, raw material supply arrangements, projections, prescriber and
target data, pharmacy data, sales data, analyses, rebate agreements, promotion plans, detailing
information, financial statements, customer and target lists, marketing plans, budgets, Third Party
contracts, market research data, pricing, reimbursement and costs relating to the Product) that is
disclosed by or on behalf of such Party or any of its Affiliates to the other Party, any of its
Affiliates or any of their respective employees, agents or contractors pursuant to or in connection
with this Agreement and (b) any other non- public or proprietary information and data that is
expressly deemed in this Agreement to be Confidential Information of such Party, whether or not
disclosed by or on behalf of such Party to the other Party, any of its Affiliates or any of their
respective employees, agents or contractors, in each case ((a) and (b)) without regard to whether
any of the foregoing is marked "confidential" or "proprietary," or in oral, written, graphic or
electronic form.

1.31 "Cumulative Net Sales" has the meaning set forth in Section 5.1.1.

1.32 "Cure Period" has the meaning set forth in Section 8.1.4.
<!-- page 8 -->
1.33 "Detail" means an in-person presentation of the Product and its uses for the Initial Indication
made by an adequately trained sales representative during a Call to one or more Health Care
Professionals in the Territory during which the sales representative describes the Product and such
use(s) in a fair and balanced manner consistent with (a) the Product Label and Insert and any
Promotional Materials approved in accordance with this Agreement, and (b) the other requirements of
this Agreement, the Promotion Rules and applicable Laws, but shall not include reminder details or
e-details, as such terms are generally understood in the pharmaceutical industry in the Territory,
or any presentations made at conventions, consulting programs or similar gatherings, other than a
pre-arranged or scheduled meeting at such gathering between the sales representative and a Health
Care Professional. When used as a verb, "Detail" means to deliver the presentation described in this
definition. "Detailing" shall have a corresponding meaning.

1.34 "Detailing Period" means each of the following periods: (a) the period beginning on the Start
Date and ending on September 30, 2019; (b) October 1, 2019 through December 31, 2019; and (c)
January 1, 2020 through March 31, 2020.

1.35 "Diligent Efforts" means, with respect to an activity to be undertaken by a Party pursuant to
this Agreement, the level of efforts and resources normally used by such Party with respect to a
pharmaceutical product owned or controlled by such Party, or to which such Party has similar rights,
which product is of similar market potential and strategic value and is at a similar stage in its
development or life as is the Product, taking into account all relevant factors, including issues of
safety, efficacy, product profile, the competitiveness of the marketplace, the proprietary position
of the Product, regulatory matters, profitability of the Product and other relevant commercial
factors.

1.36 "Disclosing Party" has the meaning set forth in Section 9.1.3.

1.37 "Disputes" has the meaning set forth in Section 13.1.

1.38 "Dual Target" has the meaning set forth in Exhibit B.

1.39 "Effective Date" has the meaning set forth in the preamble to this Agreement.

1.40 "Expiration Date" means March 31, 2020.

1.41 "FDA" means the United States Food and Drug Administration or any successor agency thereto.

1.42 "Fee Notice" has the meaning set forth in Section 5.5.1.

1.43 "First Position Detail" means, with respect to any product, a detail or presentation that is
dedicated solely to such product and constitutes at least 70% of the total presentation time for all
products presented during a Call in which such product is the first product presented to the health
care professional.
<!-- page 9 -->
1.44 "Force Majeure" has the meaning set forth in Section 14.2.

1.45 "GAAP" means United States generally accepted accounting principles applied on a consistent
basis. Unless otherwise defined or stated, financial terms shall be calculated by the accrual method
under GAAP.

1.46 "Governmental Authority" means any government (including any national, federal, state or local
government), or political subdivision thereof, or any multinational or other organization,
authority, agency or commission entitled to exercise any administrative, executive, judicial,
legislative, police, regulatory or taxing authority or power, any court or tribunal, or any
governmental arbitrator or arbitral body (or any department, bureau or division of any of the
foregoing).

1.47 "Health Care Professional" means a health care professional with prescribing authority who
treats urothelial cancer.

1.48 "Indemnified Party" has the meaning set forth in Section 12.2.1.

1.49 "Indemnifying Party" has the meaning set forth in Section 12.2.1.

1.50 "Initial Indication" means the first indication for which the Product receives Marketing
Approval in the Territory, which the Parties expect to be treatment of adult patients with locally
advanced or metastatic urothelial carcinoma which has (a) susceptible FGFR 3 or 2 genetic
alterations and (b) progressed during or following at least one line of prior platinum-containing
chemotherapy including within 12 months of neoadjuvant or adjuvant platinum-containing chemotherapy,
where patients are selected for therapy based on an FDA-approved companion diagnostic for the
Product; provided, however, that, with respect to any such indication for which the Product receives
Marketing Approval from the FDA, "Initial Indication" shall be defined by the exact wording used in
the Product Label and Insert as so approved.

1.51 "Janssen" has the meaning set forth in the preamble to this Agreement.

1.52 "Janssen Brand Usage Guidelines" means Janssen's group guidelines on the Janssen brand visual
and verbal identity as they apply to the Trademarks of Janssen and its Affiliates and the use of
other companies' names and logos, as notified to Company by Janssen from time to time.

1.53 "Janssen Indemnified Parties" has the meaning set forth in Section 12.1.2.

1.54 "Joint Commercial Team" has the meaning set forth in Section 4.2.1.

1.55 "Launch Date" means the date of the commercial launch of the Product in the Territory selected
by Janssen. As of the Effective Date, the Parties expect that the Launch Date shall be on or about
May 1, 2019.
<!-- page 10 -->
1.56 "Laws" means all laws, statutes, rules, regulations, ordinances and other pronouncements having
the effect of law in any country, state, province, county, city or other political subdivision, and
includes any rule or regulation of any Governmental Authority that may be in effect from time to
time in the Territory.

1.57 "License Agreement" means that certain Collaboration and License Agreement between Janssen
Pharmaceutica N.V. and Astex Therapeutics Limited executed in June 2008, as amended, pursuant to
which Janssen was granted a license under one or more patents covering the Product.

1.58 "Losses" has the meaning set forth in Section 12.1.1.

1.59 "Marketing Approval" means, with respect to any product, approval by the FDA of an NDA for such
product. 1.60 "Milestone Event" has the meaning set forth in Section 5.3.

1.61 "Milestone Payment" has the meaning set forth in Section 5.3.

1.62 "Minimum Number of Details Requirement" has the meaning set forth in Exhibit B.

1.63 "Minimum PDE Requirement" has the meaning set forth in Exhibit B.

1.64 "Minimum Reach Requirement" has the meaning set forth in Exhibit B.

1.65 "Minimum Top Target Requirement" has the meaning set forth in Exhibit B.

1.66 "NDA" means, with respect to any product, a New Drug Application for such product and all
supplements to such New Drug Application filed pursuant to the requirements of the FDA.

1.67 "Net Sales" means [***].

1.68 "Other Company Employees" has the meaning set forth in Section 2.2.2(a).

1.69 "Party" means each of Janssen and Company, which together are referred to as the "Parties".

1.70 "Passing Score" has the meaning set forth in Section 2.2.2(c).

1.71 "Payee Party" means, with regards to a payment pursuant to this Agreement, the Party that
receives such payment from the other Party under this Agreement.

1.72 "Paying Party" means, with regards to a payment pursuant to this Agreement, the Party that
makes such payment to the other Party under this Agreement.
<!-- page 11 -->
1.73 "PDE" shall mean, with respect to any product, a primary detail equivalent, which consists of
either a First Position Detail of such product or two Second Position Details of such product, such
that a First Position Detail shall count as [***] PDE and a Second Position Detail shall count as
[***] PDE. 1.74 "Performance Failure Notice" has the meaning set forth in Section 3.2.4(b). 1.75
"Person" means, as applicable, an individual, sole proprietorship, partnership, limited partnership,
limited liability partnership, corporation, limited liability company, business trust, joint stock
company, trust, incorporated association, joint venture or similar entity or organization, including
a Governmental Authority.

1.76 "PMS" has the meaning set forth in Section 6.4.

1.77 "Product" means any or each of the tablets containing erdafitinib as its sole active ingredient
in a dosage amount of 3 mg, 4 mg or 5 mg and that is currently expected to be approved by the FDA
for the Initial Indication, as currently manufactured by or on behalf of Janssen or its Affiliate
and planned to be marketed under the trademark BALVERSA™.

1.78 "Product Complaint" means an oral, written or electronic communication from any Person that
implies dissatisfaction regarding the identity, purity, quality or stability of the Product.

1.79 "Product Label and Insert" means (a) all labels and other written, printed or graphic material
affixed to any container, packaging or wrapper utilized with the Product; and (b) any written
material physically accompanying the Product, including the Product package inserts.

1.80 "Product-Specific Training" means training with respect to (a) sales and scientific materials
regarding the disease state information on urothelial cancer, (b) currently available clinical data
supporting use of the Product for the treatment of urothelial cancer, and (c) clinical data for
products that compete with the Product.

1.81 "Product Trademarks" means any Trademarks as may be selected by Janssen and its Affiliate, in
their sole discretion, for use in connection with the Product in the Territory, including any
Trademark owned or controlled by Janssen or its Affiliates that includes the name "BALVERSA". For
purposes of clarity, the term "Product Trademark" shall not include the corporate names and logos of
either Party.

1.82 "Promotion" means the (a) Detailing of the Product in the Territory for the Initial Indication
and (b) performance of the other promotional activities for the Product set forth in the Brand Plan.
"Promote" and "Promoting," when used as a verb, means to engage in such Promotion.

1.83 "Promotion Rules" means: (a) the PhRMA Code on Interactions with Health Care Professionals; and
(b) upon reasonable notice by Janssen to Company, any other similar rules,
<!-- page 12 -->
policies or procedures with respect to the promotion of pharmaceutical products in the Territory
that Janssen deems necessary or advisable to follow (including Janssen's compliance policies).

1.84 "Promotional Materials" has the meaning set forth in Section 3.4.2.

1.85 "Quarter End Date" has the meaning set forth in Section 1.16.

1.86 "Receiving Party" has the meaning set forth in Section 9.1.3.

1.87 "Regulatory Approval" means all technical, medical and scientific licenses, registrations,
authorizations and approvals (including Marketing Approvals and labeling approvals) of all
applicable Regulatory Authorities necessary for the commercial distribution, marketing, promotion,
offer for sale, use, import and sale of a pharmaceutical product in a regulatory jurisdiction.

1.88 "Regulatory Authority" means any authority, agency, commission, official or other
instrumentality inside or outside the Territory, including the FDA, having jurisdiction over the
manufacture of Product for sale in the Territory, or over the commercial distribution, marketing,
promotion, offer for sale, use, import or sale of the Product in the Territory.

1.89 "Remediation Plan" has the meaning set forth in Section 3.2.4(b).

1.90 "Sales Force" has the meaning set forth in Section 3.3.2(a).

1.91 "Sales Representative" means a sales representative used by Company to perform Details of the
Product for the Initial Indication to Health Care Professionals in the Territory. Sales
Representative shall not include any key account manager, medical science liaison or regional sales
manager.

1.92 "Second Position Detail" means, with respect to any product, a detail or presentation that is
dedicated solely to such product and constitutes at least 30% of the total presentation time for all
products presented during a Call in which such product is the second product presented to the health
care professional.

1.93 "Service Fee" has the meaning set forth in Section 5.1.

1.94 "Start Date" means the first date upon which Sales Representatives are able to Detail the
Product in accordance with this Agreement and as approved by Janssen, which may be before, on or
after the Launch Date.

1.95 "Supplementary Training" means supplemental training relating to a Product, including refresher
training, training regarding any emerging Product safety information, or new Promotional Materials
or Product messaging.

1.96 "Target" means a Health Care Professional who treats patients for locally advanced
<!-- page 13 -->
or metastatic urothelial cancer and is included in the Target List in accordance with this
Agreement.

1.97 "Target List" has the meaning set forth in Section 2.2.1.

1.98 "Tax" or "Taxes" means any present or future taxes, levies, imposts, duties, charges,
assessments or fees of any nature (including interest, penalties and additions thereon or thereto)
that are imposed upon a Party by a Governmental Authority or other taxing authority under any
applicable Laws.

1.99 "Term" has the meaning set forth in Section 8.1.1.

1.100 "Territory" means the United States of America, including its territories and possessions.

1.101 "Third Party" means any Person other than a party to this Agreement or any of its Affiliates.

1.102 "Trademark" means any trademark, trade dress, trade name, brand name, logo, corporate name or
service mark, used in connection with any product or service.

1.103 "Training Activities Plan" has the meaning set forth in Section 2.2.2(a). ARTICLE II BRAND
PLAN 2.1 Brand Plan Generally. A written plan for the marketing and promotion of the Product for the
Initial Indication in the Territory pursuant to this Agreement for Calendar Year 2019 is attached to
this Agreement as Exhibit A (the "Brand Plan"). If the Launch Date is delayed beyond May 1, 2019,
Janssen shall update the Brand Plan to adjust the Parties' obligations appropriately to reflect such
delay. Janssen shall have the sole authority and responsibility for updating the Brand Plan for
Calendar Year 2020. Janssen shall use reasonable efforts to deliver the Brand Plan for Calendar Year
2020 to the Joint Commercial Team by no later than November 30, 2019.

2.2 Contents of Brand Plan. The Brand Plan shall include: (a) a description of the Target List; (b)
the Training Activities Plan; (c) a description of the Call Plan; and (d) a description of the sales
and promotional materials (including Health Care Provider and patient education sales materials and,
where applicable, non-personal promotional materials) to be used during the relevant year in
connection with the Product. The Brand Plan shall also include plans for other non-Detailing
activities, if any, to be conducted in relation to the Product during the period covered by the
Brand Plan, such as attendance at medical conferences and Janssen sales meetings, marketing plans
for advisory boards and publication plans.
<!-- page 14 -->
2.2.1 Target List. Prior to the Launch Date, Janssen shall provide to Company, in electronic form, a
list that sets forth: (x) the name of each Target to which the Sales Representatives will perform
Details; and (y) the priority classification of each such Target (high, medium or low). Such list,
as amended from time to time by Janssen, shall be the "Target List". Janssen shall furnish with or
as part of the Target List the claims data upon which the Target priority classification was based
if (a) Janssen is able to obtain an agreement with the relevant Third Party to provide such data to
Company and (b) the Parties agree on which Party will bear the costs of providing such data to
Company.

2.2.2 Training Activities Plan.

(a) Training Activities Plan. The Brand Plan includes a plan that sets forth all of the training
that Janssen deems necessary or advisable for the Sales Representatives and any other employees of
Company conducting activities under this Agreement (such other employees, the "Other Company
Employees") to complete prior to conducting activities under this Agreement (the "Training
Activities Plan"). The Training Activities Plan shall indicate which Party is responsible for
providing such training, when such training will be provided and how such training will be provided
(e.g., in person or remotely, which may include live audio/video conference calls, or electronically
such as via learning management systems). The initial Training Activities Plan includes a plan for
conducting and completing the Product-Specific Training and (as applicable) state Law compliance
training of the Sales Representatives before the Launch Date. The initial Training Activities Plan
also includes a plan for conducting and completing before the Launch Date compliance training of the
Sales Representatives and the Other Company Employees in a manner consistent with all applicable
pharmaceutical industry standards. Janssen may update the Training Activities Plan from time to time
to include any additional training that Janssen deems necessary or advisable to refresh or update
the knowledge of the Sales Representatives and the Other Company Employees.

(b) Training Responsibilities. Janssen shall conduct all Product-Specific Training to the Sales
Representatives and Other Company Employees. Company shall at all times ensure that each Sales
Representative and Other Company Employee (including Sales Representatives and Other Company
Employee that are engaged after Launch Date) has received the Product- Specific Training and any
other training set forth in the Training Activities Plan.

(c) Examination. Janssen shall administer to each Sales Representative an examination of the
Product- Specific Training topics and any other training topics that Janssen deems necessary or
advisable. The first such examination of the Sales Representatives shall occur no later than the
Launch Date. Janssen shall determine the minimum score that is considered a minimum passing score
for each examination (the "Passing Score"). Company shall ensure that, before conducting any
Detailing of the Product pursuant to this Agreement, each Sales Representative has completed the
Product-Specific Training and other training described in the Training Activities Plan and has
achieved a Passing Score on such examination. Upon Company's request, Janssen shall provide, as soon
as reasonably practicable, additional remedial training and re-testing of Sales Representatives who
fail to achieve a Passing Score. Any Sales Representative
<!-- page 15 -->
who does not obtain a Passing Score on such an examination shall not be permitted by Company to
perform in-person presentations of the Product unless and until such Sales Representative is
re-tested and achieves a Passing Score.

2.2.3 Call Plan. Janssen shall develop and provide to Company an annual plan that describes the
amount, frequency and reach of Detailing to be performed by the Sales Representatives to the Targets
on the Target List (the "Call Plan").

ARTICLE III PROMOTION

3.1 Scope.

3.1.1 Engagement; Obligations.

(a) Janssen hereby engages Company on a non-exclusive basis to Promote the Product for the Initial
Indication in the Territory on the terms, and subject to the conditions, set forth in this
Agreement, and Company hereby accepts such engagement. Company shall not Promote the Product for any
indication other than the Initial Indication. Company shall not conduct any promotion or marketing
activities with respect to the Product that are not set forth in the Brand Plan without the prior
written consent of Janssen. Janssen and its Affiliates retain the right to Detail and otherwise
promote the Product in the Territory.

(b) Each Party shall perform the obligations and activities assigned to it in, and comply with the
applicable provisions of, the Brand Plan and this Agreement.

3.1.2 Retained Rights. Any rights of Janssen or any of its Affiliates related to the Product that
are not expressly granted to Company hereunder shall be retained by Janssen or such Affiliate,
including all decision-making and other authority relating to Product development, regulatory
matters, medical affairs, distribution, manufacturing and supply, Product strategy, marketing,
sales, pricing, discounting, reimbursement, life cycle management, positioning, marketing messages
and other commercialization matters. Janssen shall book sales of the Product in the Territory and
shall have the sole right and responsibility to manufacture the Product and to distribute the
Product in the Territory. Company shall not distribute or sell the Product in the Territory, and
nothing herein shall be construed to provide Company with any rights to develop, manufacture,
supply, distribute or sell the Product in the Territory.

3.1.3 Compliance with Laws. Company shall ensure that all of its personnel involved in the
activities set forth under this Agreement comply with all applicable Laws and the Promotion Rules.
Company shall ensure that the Sales Representatives and Other Company Employees Promote the Product
at all times in accordance with applicable Laws and the Promotional Materials provided and approved
by Janssen, refrain from making any false or misleading statements about the Product and refrain
from discussing any unapproved uses of the Product.

3.2 Detailing Requirements.
<!-- page 16 -->
3.2.1 General. Subject to Janssen fulfilling its obligations under Section 2.2.2(b) to provide the
initial training and under Section 3.4 to deliver the Promotional Materials, Company shall begin
promoting and Detailing the Product for the Initial Indication to the Targets on the Start Date.
Company shall perform Detailing during the Term in accordance with this Section 3.2, the Call Plan
and the Detailing requirements set forth on Exhibit B. For reference, the term "Detail" is defined
in Section 1.33.

3.2.2 Minimum Detailing Requirements. At a minimum, Company shall cause its Sales Force to satisfy
the Minimum Number of Details Requirement, the Minimum Reach Requirement and, if applicable, the
Minimum PDE Requirement and the Minimum Top Target Requirement set forth in Exhibit B in each
Detailing Period. Company shall ensure that the Sales Force satisfies the Positioning Requirements
set forth on Exhibit B. Details that do not satisfy the Positioning Requirements set forth on
Exhibit B will not be counted for purposes of determining whether the Minimum Number of Details
Requirement, the Minimum Reach Requirement, the Minimum PDE Requirement or the Minimum Top Target
Requirement has been satisfied.

3.2.3 Effects of Failure to Meet Minimum Detailing Requirements. If Company fails to achieve the
Minimum Number of Details Requirement, the Minimum Reach Requirement or, if applicable, the Minimum
PDE Requirement or the Minimum Top Target Requirement in any Detailing Period, Janssen shall have
the right to terminate this Agreement by giving thirty (30) days' notice, unless:

(a) Company complied with and performed its Detailing activities in accordance with any Remediation
Plans developed by Company and approved by Janssen during such Detailing Period; or

(b) if (i) neither Party provided a Performance Failure Notice under Section 3.2.4 during such
Detailing Period and (ii) Company performs additional Details in the first month after such
Detailing Period such that, if such Details had been performed during such Detailing Period, they
would have been sufficient to cure the failure to achieve the Minimum Number of Details Requirement,
the Minimum Reach Requirement, the Minimum PDE Requirement or the Minimum Top Target Requirement, as
applicable. To avoid double-counting, such additional Details will not be taken into account when
determining whether Company satisfies the Minimum Number of Details Requirement, Minimum Reach
Requirement or, if applicable, the Minimum PDE Requirement or the Minimum Top Target Requirement in
the then-current Detailing Period.

For clarity, (i) Company must achieve all of the applicable foregoing minimum requirements in order
to avoid giving rise to Janssen's rights and remedies under this Section 3.2.3, and (ii) such rights
shall be in addition to any other rights and remedies that may be available to Janssen under
applicable Laws in the event of any such failure on the part of Company.

3.2.4 Monthly Detailing Reports.
<!-- page 17 -->
(a) No later than [***] ([***]) Business Days following the end of each month during the Term,
Company shall report to Janssen the number of Details performed (and any other information necessary
to determine whether the requirements set forth in Section 3.2.2 and Exhibit B have been satisfied)
during such month by the Sales Representatives in accordance with this Agreement and the Call Plan,
as reported by the Company Internal Detail Reporting System. The Joint Commercial Team shall review
and discuss Company's performance of its Detailing obligations on a monthly basis.

(b) In the event that either Party believes, based on such reports, review or discussion, that
Company will fail to achieve the Minimum Number of Details Requirement, the Minimum Reach
Requirement or, if applicable, the Minimum PDE Requirement or the Minimum Top Target Requirement
under Section 3.2.2 for the then-current Detailing Period, such Party will promptly notify the other
Party in writing (a "Performance Failure Notice") and Company shall develop a plan to avoid such a
failure within fifteen (15) Business Days after the end of the applicable month, which plan will be
subject to Janssen's approval, not to be unreasonably withheld or delayed (as so approved, a
"Remediation Plan").

(c) For clarity, the Joint Commercial Team shall have no authority to extend the time for
performance or reduce the Minimum Number of Details Requirement, the Minimum Reach Requirement or,
if applicable, the Minimum PDE Requirement or the Minimum Top Target Requirement without an
amendment to this Agreement.

3.2.5 Ride-Alongs. Members of Janssen's team shall have the right to conduct ride-alongs with the
Sales Representatives for purposes of monitoring the Details delivered by the Sales Representatives
upon Janssen's request. Janssen will give reasonable notice to Company sales management of each
request.

3.3 Sales Representatives.

3.3.1 Qualifications. Company shall ensure that each Sales Representative: (i) is a full-time
employee of Company and a full-time member of its sales force; (ii) possesses skills, training and
experience that are consistent with industry standards applicable to the promotion of an oncological
pharmaceutical product; (iii) has completed the Product-Specific Training and other sales training
described in this Agreement and the Brand Plan and achieved a Passing Score on an examination in
accordance with Section 2.2.2(c); and (iv) has become adequately equipped and knowledgeable with
respect to the Product, as determined in accordance with Company's then-current standards for sales
personnel selling pharmaceutical products in the Territory. No sales representative or other
individual may be used by Company to perform in-person presentations of
<!-- page 18 -->
the Product in the Territory unless and until such individual satisfies the conditions described in
clauses (i) - (iv) above.

3.3.2 Size of Sales Force.

(a) At all times during the Term, Company shall use reasonable efforts to deploy and maintain a
sales force (the "Sales Force") of at least [***] ([***]) Sales Representatives who satisfy the
conditions described in Section 3.3.1.

(b) Company shall notify Janssen (i) at least [***] ([***]) days in advance of any planned reduction
by Company in the size of the Sales Force to less than [***] ([***]) Sales Representatives and (ii)
promptly if the number of Sales Representatives on the Sales Force decreases to less than [***]
([***]). In either event, Company shall provide Janssen with a plan to continue meeting the Minimum
Number of Details Requirements, Minimum Reach Requirements, Minimum PDE Requirements and, if
applicable, Minimum Top Target Requirements under Section 3.2.2.

(c) If the average number of Sales Representatives on the Sales Force is less than twenty-five (25)
over any forty-five (45)-day period, Janssen will have the right to terminate this Agreement by
giving thirty (30) days' notice.

3.3.3 Subcontracting. Company may not subcontract with or otherwise use any Affiliate or Third Party
to perform any Detailing or any of its other obligations under this Agreement without the prior
written consent of Janssen.

3.3.4 Compensation of Sales Force. In the event Company elects to provide incentives to Sales
Representatives, such incentives will be appropriate, in accordance with the applicable Laws, and,
in the aggregate, competitive in the marketplace with respect to the products promoted by the Sales
Representatives. Janssen shall not have any responsibility for or authority over the hiring,
supervision, termination or compensation of the Sales Representatives or any other Company employees
or for any employee benefits of such employees.

3.3.5 Additional Obligations. Company shall ensure that the Sales Representatives do not identify or
represent themselves as employees or agents of Janssen or any Affiliate of Janssen.

3.4 Promotional Materials.

3.4.1 Positioning and Messages. Janssen shall develop and, as deemed advisable or necessary by
Janssen from time to time, update product positioning and core selling messages for the Promotion of
the Product. Janssen agrees to consider in good faith Company's feedback in the development of any
such updates to such messaging.

3.4.2 Promotional Materials Development and Approval. Janssen shall be solely responsible for
developing and providing to Company (at Janssen's cost) all promotional materials
<!-- page 19 -->
for use in connection with the Promotion of the Product (the "Promotional Materials") and agrees to
provide Company with sufficient quantities of the materials based on market demand and expected
levels of Detailing efforts. Janssen agrees to consider in good faith Company's feedback in the
development of any new promotional materials during the Term. Such Promotional Materials shall
comply with all applicable Laws and may include written sales and advertising materials, detail
aids, brochures, hand-outs, reprints, booth panels and any other promotional support items. Company
shall use only the Promotional Materials provided by Janssen and the Product Label and Insert in its
Promotion of the Product in the Territory. Company shall not add any Company Trademark to the
Promotional Materials or otherwise alter the Promotional Materials in any way. Company shall not
develop or use any other promotional materials in its Promotion of the Product.

3.4.3 Janssen Right to Use Promotional Materials. Nothing in this Agreement shall restrict Janssen's
right to use any Promotional Materials for the purposes of promoting the Product in the Territory.

3.4.4 Revisions. Janssen may revise, update or develop additional Promotional Materials from time to
time during the Term, as deemed necessary and appropriate by Janssen, including based on: (i)
changes in the Product Label and Insert; (ii) requirements or mandates of the FDA or other
Regulatory Authorities or any Laws; or (iii) changes in the Promotion Rules.

3.4.5 Revocation of Approval. If, at any time, Janssen notifies Company in writing that it no longer
approves the use of specified Promotional Materials, Company shall immediately take action to remove
the Promotional Materials from use by Sales Representatives and either (i) destroy such materials or
(ii) return them to Janssen. The cost of such return shall be borne by Janssen.

3.5 Product Sales. Janssen shall have sole authority and responsibility for sale and distribution of
the Product in the Territory. Company shall not, and shall not permit the Sales Representatives or
Other Company Employees to, solicit or accept orders for the Product or otherwise engage in any
distribution, sale or offer for sale of the Product, any Product samples or any other product
containing erdafitinib, but rather shall promptly direct any orders that it receives for Product or
Product samples, and cause the Sales Representatives and Other Company Employees to direct promptly
any such orders they may receive, to Janssen or any Third Party designated by Janssen.

3.6 Product Recall. Janssen shall have sole authority and responsibility for any recall or
withdrawal of the Product in the Territory. Following a decision by Janssen to conduct any such
recall or withdrawal of the Product: (a) Janssen shall immediately notify Company of such decision,
(b) Company shall immediately cease Detailing and all other promotion of the Product and (c) as soon
as reasonably practicable, Janssen provide Company with a prepared statement for use in response to
any inquiries regarding such recall or withdrawal. Company shall use such prepared statement to
respond to any inquiries received with regard to the recall or withdrawal and shall not make any
other statement regarding such recall or withdrawal except as required by
<!-- page 20 -->
applicable Law. In the event of a recall or withdrawal, the obligations of the Parties under this
Agreement (other than Janssen's obligation to pay Service Fees or Milestone Payments to Company)
will be suspended solely to the extent and for so long as necessary until the circumstances that
were the reasons for the recall or withdrawal have been resolved.

3.7 Product Return. Janssen shall have the sole authority, right and responsibility to accept and
handle, either directly or indirectly, any request to return Product in the Territory. Company shall
not solicit the return of any Product and shall promptly direct any attempted returns and cause the
Sales Representatives and Other Company Employees to direct promptly any attempted returns to
Janssen or any Third Party designated by Janssen.

ARTICLE IV GOVERNANCE

4.1 Authority. Janssen shall have sole decision-making authority with respect to all matters
relating to the promotion and Detailing of the Product in the Territory under this Agreement
(including making changes to the Brand Plan), but Janssen may not exercise such decision-making
authority with respect to a change to the Brand Plan that would materially increase Company's
Detailing obligations or materially increase Company's non-Detailing obligations.

4.2 Joint Commercial Team.

4.2.1 Formation; Purpose. Simultaneously with the execution of this Agreement the Parties shall
establish a joint commercial team (the "Joint Commercial Team") solely as a forum for the Parties'
representatives to discuss Company's execution of the Brand Plan, potential changes to the Brand
Plan and the promotion and Detailing of the Product to the Targets in the Territory. The Joint
Commercial Team will have no decision-making authority. During the meetings of the Joint Commercial
Team, the Parties may make recommendations to one another with respect to Company's execution of the
Brand Plan, potential changes to the Brand Plan and the promotion and Detailing of the Product to
the Targets in the Territory.

4.2.2 Membership. The Joint Commercial Team shall consist of at least three (3) representatives of
each Party, appointed by such Party from among its (or its Affiliates') employees that have a level
of experience customary for a committee of this type. Either Party may remove and replace any member
that it appointed, with or without cause, at any time by prior notice to the other Party. The Joint
Commercial Team shall at all times be chaired by a representative of Janssen. The chairperson shall
be responsible for calling meetings, preparing and circulating an agenda in advance of each meeting,
and preparing and issuing minutes of each meeting within thirty (30) days thereafter or within a
timeframe agreed by the Parties.

4.2.3 Meetings. The Joint Commercial Team shall meet monthly. Meetings of the Joint Commercial Team
may be held in person or by audio or video teleconference with the consent of each Party. Each Party
shall bear its own costs associated with the attendance of its appointees at such meetings. Each
Party shall ensure that at least two (2) of its appointed members
<!-- page 21 -->
(or their alternates) attend each meeting. Other employee representatives of each Party may attend
meetings of the Joint Commercial Team.

4.3 BALVERSA Sales Advisory Team.

4.3.1 Formation; Purpose. Upon request by Janssen, the Parties shall establish a BALVERSA Sales
Advisory Team (the "BSAT"). The BSAT will serve solely as an advisory forum and will have no
decision-making authority.

4.3.2 Membership. The BSAT shall consist of at least one Sales Representative per region, at least
two (2) regional managers of Company and at least one representative of Janssen's BALVERSA marketing
team. Either Party may remove and replace any member that it appointed, with or without cause, at
any time by prior notice to the other Party. The BSAT shall at all times be chaired by a
representative of Janssen. The chairperson shall be responsible for calling meetings.

4.3.3 Meetings. The BSAT shall meet every other week during the first sixty (60) days after the
Launch Date and monthly for the rest of the Term, with each meeting not to exceed ninety (90)
minutes in duration. Meetings of the BSAT shall be held by audio or video teleconference and the
parties agree to make reasonable efforts to ensure the meetings do not interfere with territory
detailing time. Each Party shall bear its own costs associated with the attendance of its appointees
at such meetings. Other employee representatives of each Party may attend meetings of the BSAT.

ARTICLE V COMPENSATION

5.1 Definitions.

5.1.1 "Baseline" means (i) with respect to Calendar Year 2019, [***] Dollars ($[***]); and (ii) with
respect to Calendar Year 2020, [***]Dollars ($[***]).

5.1.2 "Cumulative Net Sales" means, with respect to any Calendar Quarter, the aggregate amount of
Net Sales that were made during such Calendar Quarter and any prior Calendar Quarter(s) during the
same Calendar Year.

5.2 Service Fee. In partial consideration of Company's Promotion of the Product in accordance with
the terms of this Agreement, and subject to the terms and conditions of this Agreement, with respect
to each Calendar Quarter during Calendar Year 2019 and Calendar Year 2020, Janssen shall pay Company
a service fee (the "Service Fee"), as follows:

(a) with respect to each Calendar Quarter during Calendar Year 2019, an amount equal to (i) [***]
percent ([***]%) of that portion of Cumulative Net Sales that is greater than the Baseline for
Calendar Year 2019, less (ii) the total Service Fees that have been invoiced by Company to Janssen
for all preceding Calendar Quarters of Calendar Year 2019; and
<!-- page 22 -->
(b) with respect to each Calendar Quarter during Calendar Year 2020, an amount equal to (i) [***]
percent ([***]%) of that portion of Cumulative Net Sales that is greater than the Baseline for
Calendar Year 2020, less (ii) the total Service Fees that have been invoiced by Company to Janssen
for all preceding Calendar Quarters of Calendar Year 2020.

Unless and until the Cumulative Net Sales exceed the Baseline for a particular Calendar Year, the
Service Fee shall be zero. The foregoing calculation method is intended to ensure that each Service
Fee for a Calendar Quarter includes a true-up amount of all Service Fees earned year-to-date in the
same Calendar Year.

5.3 Milestones.

5.3.1 In partial consideration of Company's Promotion of the Product in accordance with the terms of
this Agreement, and subject to the terms and conditions of this Agreement, Janssen shall pay Company
milestone payments in accordance with this Section 5.3. Janssen shall notify Company in the
applicable Fee Notice the first time the Cumulative Net Sales in the applicable Calendar Year exceed
the amounts set forth in the following table (each, a "Milestone Event"). Janssen shall pay to
Company the applicable milestone payments set forth in the table below (each, a "Milestone Payment")
within [***] ([***]) days after receipt of an invoice from Company with respect to achievement of
each Milestone Event. Each Milestone Payment shall be non-refundable and non-creditable.

Milestone Event Milestone Payment Upon the first occasion that Cumulative Net Sales in Calendar Year
2019 exceed US$[***] US$[***] Upon the first occasion that Cumulative Net Sales in Calendar Year
2019 exceed US$[***] US$[***] Upon the first occasion that Cumulative Net Sales in Calendar Year
2019 exceed US$[***] US$[***] Upon the first occasion that Cumulative Net Sales in Calendar Year
2020 exceed US$[***] US$[***]

5.3.2 Each Milestone Payment shall be payable only once upon the first occurrence of the relevant
Milestone Event, even if the Milestone Event occurs multiple times.

In the event Regulatory Approval of the Product for the Initial Indication in the Territory is
delayed beyond May 18, 2019, or in the event commercial availability of the Product is delayed
beyond June 1, 2019, Janssen agrees to make proportional adjustments to the Milestone Events in
2019, Milestone Payments in 2019 and the Baseline for 2019
<!-- page 23 -->
consistent with the period of delay in Regulatory Approval or commercial availability, whichever is
greater, as shown in the following sample calculation.

Sample Calculation:

Example: Regulatory Approval date is June 18, 2019 - 30 days delayed approval

New Baseline for Calendar Year 2019: $[***] - ($[***] X [***] days / [***] days) = $[***]

New Milestone Event and Payment for First 2019 Milestone: Cumulative Net Sales: $[***] - ($[***]X
[***] days / [***] days) = $[***] Payment: $[***] - ($[***] X [***] days / [***] days) = $[***]

5.4 Costs. Unless otherwise expressly stated in this Agreement, each Party shall bear and be
responsible for all internal and out-of-pocket costs and expenses incurred by such Party in the
performance of this Agreement.

5.5 Reports and Payments.

5.5.1 After the end of each Calendar Quarter of Calendar Year 2019 and 2020, Janssen shall calculate
in good faith, based on Janssen's Books and Records and in accordance with Janssen's customary and
consistently-applied accounting practices, the Net Sales in such Calendar Quarter and for such
Calendar Year in the aggregate, as well as the Cumulative Net Sales and the Service Fee for such
Calendar Quarter. Janssen shall deliver to Company, within thirty (30) days following the last day
of such Calendar Quarter, a report setting forth the Cumulative Net Sales, the Service Fee and, if
applicable, the Milestone Payment for such Calendar Quarter (the "Fee Notice").

5.5.2 Following receipt of a Fee Notice from Janssen pursuant to Section 5.5.1, Company shall
invoice Janssen for the amount of the Service Fee payable with respect thereto, if any.

5.5.3 Subject to Janssen obtaining appropriate consents from its Third Party specialty pharmacy
partner, and the Parties reaching mutual agreement on the allocation between them of the associated
costs, if any, Janssen shall provide prescriber level unit sales data generated from the specialty
pharmacy partner on a weekly basis for the Company to track business trends, direct resources,
measure sales force effectiveness, detailing sensitivity, and to design an effective sales incentive
program.

5.5.4 If a Party incurs any costs that are the responsibility of the other Party under this
Agreement, such Party shall invoice the other Party for such costs promptly following the
<!-- page 24 -->
Calendar Quarter during which such costs were incurred. Such invoice shall include reasonable
documentation of the costs for which the invoicing Party is seeking reimbursement.

5.5.5 All invoices delivered in accordance with Section 5.5.2 or 5.5.4 shall be paid by the Paying
Party within [***] ([***]) days after receipt of such invoice.

5.5.6 All payments hereunder will be paid in U.S. Dollars and made available by bank wire transfer,
in immediately available funds, to the account designated in writing by the Payee Party from time to
time. Any changes to such account designation shall be made at least thirty (30) Business Days
before the due date of the applicable payment.

5.6 Tax Matters. The Paying Party shall make all payments to the Payee Party under this Agreement
without deduction or withholding for any Taxes except to the extent that any such deduction or
withholding is required by any Law in effect at the time of payment. Each Party shall otherwise be
responsible for its own income taxes and corporate taxes and any other Taxes payable by such Party
arising under or in connection with this Agreement and shall pay all such Taxes and file any
applicable tax returns on a timely basis. Any Tax required to be withheld on amounts payable under
this Agreement shall timely and promptly be paid by the Paying Party on behalf of the Payee Party to
the appropriate Governmental Authority, and the Paying Party shall furnish the Payee Party with
proof of payment of such Tax. Any such Tax required to be withheld shall be an expense of and borne
by the Payee Party. If any such Tax is assessed against and paid by the Paying Party, then the
amount of such Tax withheld shall be treated as paid by the Paying Party to the Payee Party and the
Payee Party shall indemnify and hold harmless the Paying Party from and against such Tax. Both
Parties will cooperate with respect to all documentation required by any taxing authority or
reasonably requested by the Paying Party to secure a reduction in the rate of applicable withholding
Taxes.

ARTICLE VI REGULATORY MATTERS

6.1 Regulatory Approvals.

6.1.1 Obligations of Janssen. Janssen, either itself or through one of its Affiliates, shall use
Diligent Efforts to obtain Regulatory Approval of the Product for the Initial Indication in the
Territory and to maintain the validity of such Regulatory Approval throughout the Term, including
the submission of any additional information requested by any Regulatory Authority in connection
with such Regulatory Approval. Janssen shall have no obligation to file any application for
Regulatory Approval for the Product in respect of any indication other than the Initial Indication.

6.1.2 Rights of Janssen. Janssen shall be the holder of any and all Regulatory Approvals for the
Product in the Territory and shall retain sole authority over all regulatory matters relating to the
Product in the Territory.
<!-- page 25 -->
6.1.3 Communications with Regulatory Authorities. As between Janssen and Company, Janssen shall have
the sole authority and responsibility for communicating with any Regulatory Authority regarding any
Regulatory Approval of the Product in the Territory or any application or filing therefor, or
regarding any other obligation to any Regulatory Authority in relation to the Product. Except as
expressly set forth herein or as required by applicable Law or as approved in advance by Janssen in
writing, Company shall not communicate directly with any Regulatory Authority regarding the Product
or otherwise take any action concerning any application, registration, authorization or approval
under which the Product is manufactured, imported, maintained, marketed, reimbursed or sold in the
Territory.

6.2 Pharmacovigilance Procedures. The Parties shall comply, and Company shall cause the Sales
Representatives and Other Company Employees to comply, with the provisions set forth on Schedule
6.2, which govern the reporting of adverse events/adverse drug reactions associated with the
Product, Product quality complaints associated with adverse events and other information concerning
the safety of the Product within the Territory.

6.3 Product Complaints. Janssen shall have the sole right and responsibility to accept and handle
any Product Complaint associated with the use of the Product. Company shall, and shall cause each of
its Sales Representatives and Other Company Employees to, notify Janssen as soon as possible, but no
later than 24 hours after the time he or she becomes aware of any Product Complaint associated with
the Product, which notice shall include the name of the person making such Product Complaint, the
Target that prescribed the Product (if any), and the date the relevant Sales Representative or Other
Company Employee received such Product Complaint. Details regarding the process for notifying
Janssen of any such Product Complaints shall be as set forth in "product complaints standard
operating procedures", a copy of which Janssen will provide to Company promptly following the
Effective Date.

6.4 Post-Marketing Surveillance. Janssen shall have the sole right to conduct any post marketing
surveillance with respect to the Product ("PMS"), whether such PMS is elected by Janssen or required
by applicable Law.

6.5 Product Medical Inquiries. Janssen shall handle all medical questions from members of the
medical profession regarding the Product in the Territory. Company shall refer all medical inquiries
regarding the Product to Janssen through the established process outlined by Janssen for reporting
of medical information requests, a copy of which Janssen will provide to Company promptly following
the Effective Date.

6.6 Companion Diagnostic Inquiries. Company shall direct all inquiries relating to the Companion
Diagnostic in accordance with the procedures established by Janssen, a copy of which Janssen will
provide to Company promptly following the Approval Date.

6.7 Access, Affordability and Patient Support Inquiries. Company shall direct all inquiries relating
to access, affordability, or patient support for the Product to the dedicated specialty pharmacy
responsible for addressing such questions, in accordance with the procedures
<!-- page 26 -->
established by Janssen, a copy of which Janssen will provide to Company promptly following the
Effective Date.

ARTICLE VII BOOKS, RECORDS AND AUDIT RIGHTS

7.1 Books and Records. Janssen and Company shall each maintain true and complete books and records
with respect to the performance of its obligations hereunder, including the Company Internal Detail
Reporting System and items underlying all payment obligations and invoices related to this Agreement
(the "Books and Records"). Company shall maintain and manage its Books and Records in accordance
with the records and information management requirements set forth on Exhibit C.

7.2 Books and Records Audits.

7.2.1 Right to Audit. Upon [***] ([***]) days prior notice from a Party (the "Auditing Party"), the
other Party (the "Audited Party") will permit an independent certified public accounting firm of
internationally recognized standing selected by the Auditing Party and reasonably acceptable to the
Audited Party, to examine the relevant Books and Records of the Audited Party, as may be reasonably
necessary to verify the accuracy of the reports provided by the Audited Party pursuant to Section
3.2.4 or Section 5.5.1, as applicable, and the payments made or invoiced under this Agreement. An
examination by each Auditing Party under this Section shall occur not more than once with respect to
the Term and will be limited to the pertinent Books and Records for Calendar Year 2019 and Calendar
Year 2020.

7.2.2 Scope of Audit. The independent certified public accounting firm will be provided access to
the Books and Records of the Audited Party, and such examination will be conducted during the
Audited Party's normal business hours. The Audited Party may require the accounting firm to sign a
standard non-disclosure agreement before providing the accounting firm access to the Audited Party's
facilities or Books and Records. The draft report of the accounting firm will be provided to the
Audited Party so that justifying remarks can be included in the final report to be shared with the
Auditing Party. Upon completion of the audit, the accounting firm will provide both Parties a final
copy of the written report disclosing any discrepancies in the reports submitted by the Audited
Party or the payments made or owed by the Audited Party, if any, and shall not include any
confidential information (or additional information that is ordinarily not included in the Fee
Notice or Detailing reports, as applicable) disclosed to the auditor during the course of the audit
(such report, an "Audit Report").

7.2.3 Results of Audit. If an Audit Report shows that the Audited Party underpaid or failed to pay
any amount due to the Auditing Party, then the Audited Party will pay to the Auditing Party the
amount of such underpayment or non-payment. Such payment shall be made within [***] ([***]) days
after the Audited Party's receipt of the Audit Report. If an Audit Report shows that Company
overstated or otherwise misreported any information relating to Calls and Details, then Janssen
shall be entitled to exercise any rights and seek any remedies it would have
<!-- page 27 -->
had if such information had been accurately reported. If the Audited Party disagrees with the
findings of the Audit Report, the Parties will first seek to resolve the matter between themselves,
and in the event they fail to reach agreement the dispute resolution provisions outlined in Article
XIII shall be followed to resolve the dispute. Any unpaid Service Fees or Milestone Payments finally
determined by such resolution to be payable shall be paid within [***] ([***]) days after such final
resolution. If an Audit Report shows any overpayment by either Party, such Party will be entitled to
receive, at its option, either a refund of such overpayment or a credit equal to such overpayment
against the amounts otherwise payable by such Party to the other Party under this Agreement.

7.2.4 Costs of Audit. If an Audit Report shows unpaid Service Fees or Milestones that exceeds [***]
percent ([***]%) of the total amount owed by the Audited Party for the period being audited, then
the reasonable and documented fees and expenses of such independent public accountant performing the
examination shall be paid by the Audited Party, subject to reasonable substantiation thereof.
Otherwise, the costs of the examination shall be solely borne by the Auditing Party.

7.3 Compliance Audits. Janssen or an authorized representative of Janssen, and any governmental
agency that regulates a Party, may, at reasonable times during the Term and upon reasonable notice
to Company, inspect and audit the Books and Records of Company with respect to Company's obligations
under this Agreement for the sole purpose of evaluating Company's compliance with Sections 3.1.3,
3.4.2, 11.5 and 11.6 of this Agreement, applicable Laws and the Promotion Rules. The costs of any
such audit shall be borne by Janssen, unless such audit reveals noncompliance by Company due to a
failure by Company that is not excused by Janssen under this Agreement, in which case Company shall
reimburse Janssen for any out-of-pocket costs reasonably incurred in connection with the audit.

ARTICLE VIII TERM AND TERMINATION

8.1 Term; Termination.

8.1.1 Term. This Agreement shall commence on the Effective Date and, unless earlier terminated,
shall expire on the Expiration Date (the "Term"). For the avoidance of doubt, the Parties agree that
Janssen's obligations under Section 5.2 (subject to Section 8.2.5) and Section 5.3 (subject to
Section 8.2.5) shall remain in effect beyond the Expiration Date.

8.1.2 Failure or Delay in Obtaining Regulatory Approval. This Agreement may be terminated by either
Party, before the date that Marketing Approval has been obtained for the Product for the Initial
Indication in the Territory, in the event that Janssen withdraws its application for Marketing
Approval for the Product for the Initial Indication in the Territory or is notified by FDA that
Janssen's application for such Marketing Approval in the Territory has been or will be denied.
Further, this Agreement may be terminated by either Party in the event that Marketing Approval for
the Product in the Territory is not obtained before June 30, 2019. Any such
<!-- page 28 -->
termination pursuant to this Section 8.1.2 shall be effective thirty (30) days following written
notice of such termination being given to the non-terminating Party.

8.1.3 Termination Scenarios Following Regulatory Approval. Without limiting either Party's rights
under Section 8.3, this Agreement may be terminated by either Party with thirty (30) days' prior
written notice to the other, in the event that (a) a Governmental Authority requires Janssen to
withdraw permanently the Product from the market in the Territory for the Initial Indication or
Regulatory Approval for the Product for the Initial Indication is otherwise withdrawn, (b) Janssen
permanently withdraws the Product from the market in the Territory for the Initial Indication for
safety reasons or (c) promotion and sale of the Product in the Territory for the Initial Indication
has been suspended for more than three (3) months or is permanently suspended, in either case, as a
consequence of and pursuant to Section 8.3. To the extent practicable, each Party will consult with
the other Party before terminating this Agreement pursuant to this Section and will consider the
other Party's input in good faith; provided, however, that the decision to withdraw the Product
pursuant to clause (b) above will be made by Janssen in its sole discretion, acting in good faith.

8.1.4 Material Breach. This Agreement may be terminated by either Party in the event that the other
Party commits a material breach of this Agreement and (a) such breach shall not have been cured
within thirty (30) days after the giving of notice of such material breach, unless (i) the specific
provision to which such breach relates expressly provides for a different period, or (ii) the
Parties mutually agree in writing to an extension of such period (the "Cure Period"); or (b) such
breach, by its nature, is not curable. Unless such breach in clause (a) is cured during the Cure
Period, such termination will be effective immediately upon the expiration of the Cure Period
without any further action or notice by the non-breaching Party. In the case of a breach in clause
(b), such termination will be effective thirty (30) days following written notice of such breach
being given to the breaching Party.

8.1.5 Performance Failure. This Agreement may be terminated by Janssen in accordance with Section
3.2.3 or 3.3.2(c).

8.1.6 Competing Products. In the event that Company commits a breach of Section 9.2 or Section 9.3,
then Janssen shall have the right to terminate this Agreement in its entirety at any time
immediately upon written notice to Company.

8.1.7 Insolvency Proceeding. This Agreement may be terminated by either Party, immediately and
without notice, if the other Party at any time (a) commences a voluntary case or other proceeding
seeking liquidation, reorganization or other relief with respect to itself or its debts under any
bankruptcy, insolvency or other similar Law or seeking the appointment of a trustee, receiver,
liquidator, custodian or similar official of it or of any substantial part of its property, or
consents to any such relief or to the appointment of or taking possession by any such official in an
involuntary case or other proceeding commenced against it, or makes a general assignment for the
benefit of creditors, or takes any corporate action to authorize any of the foregoing, (b) has an
involuntary case or other proceeding commenced against it seeking liquidation, reorganization or
<!-- page 29 -->
other relief with respect to it or its debts under any bankruptcy, insolvency or other similar Law
or seeking the appointment of a trustee, receiver, liquidator, custodian or other similar official
of it or any substantial part of its property, and such involuntary case or other proceeding remains
undismissed and unstayed for a period of ninety (90) days; or an order for relief is entered against
such Party under applicable bankruptcy Laws, or (c) is insolvent or is generally unable to pay its
debts as they become due.

8.1.8 Force Majeure. This Agreement may be terminated by either Party in accordance with Section
14.2.

8.1.9 Health Care Compliance. This Agreement may be terminated by Janssen in accordance with Section
2(d) of Exhibit D.

8.1.10 Third Party Agreement. This Agreement may be terminated by Janssen with effect on December
31, 2019 or January 31, 2020, in either case with fifteen (15) days' advance written notice, and
only in the event that Janssen has entered into an agreement with a Third Party that provides for
(a) a license, sublicense, assignment, divestiture or other transfer or disposition of substantial
rights or assets relating to the Product in the Territory, or (b) a collaboration involving the
development and/or commercialization in the Territory of the Product or any other pharmaceutical
product that contains erdafitinib. If Janssen terminates this Agreement pursuant to this Section
8.1.10, then Janssen shall, within [***] ([***]) days following the effective date of such
termination, pay Company an amount equal to $[***] and, if the Milestone Event listed in the first
line of the table in Section 5.3.1 has occurred, Janssen shall pay to Company an additional amount
of $[***] (which shall be in addition to the Milestone Payment earned in respect of such Milestone
Event).

8.1.11 Company Product Additional Indication. This Agreement may be terminated by Janssen with
thirty (30) days' prior written notice in the event that the Company Product is approved by the FDA
for use in the treatment of urothelial cancer in any patient population in the Territory.

8.2 Effect of Termination or Expiration.

8.2.1 Materials. Upon the effective date of termination or expiration of this Agreement, Company
shall immediately (a) cease, and cause the Sales Representatives and Other Company Employees to
cease, all Promotion of the Product, (b) discontinue the use of any Promotional Materials, and (c)
discontinue the use of any Janssen sales data, Target List and other documents and data related to
the Product provided to Company by Janssen hereunder. As requested by Janssen, Company shall either
maintain (subject to the provisions of Section 9.1 and Exhibit C) or promptly destroy (and certify
to Janssen the destruction) or return to Janssen all Promotional Materials, all training materials
and all other materials related to the Product provided by Janssen pursuant to this Agreement or the
Brand Plan. With respect to any information, data, or reports provided by Janssen to Company under
this Agreement, including Janssen sales data, that Janssen requests Company to destroy or return,
Company shall upon the effective date of
<!-- page 30 -->
termination or expiration of this Agreement remove such information from its internal systems and
certify to Janssen to such removal; provided, however, that such information shall not be required
to be removed from inactive back-up computer files created pursuant to standard, automated archiving
procedures.

8.2.2 Confidential Information. Following the effective date of termination or expiration of this
Agreement, without prejudice to Section 8.2.1, each Party shall use reasonable efforts to return,
destroy or maintain (subject to the provisions of Section 9.1 and Exhibit C), at the Disclosing
Party's election, all Confidential Information of the other Party (provided that the Receiving Party
may keep one copy of such Confidential Information subject to an ongoing obligation of
confidentiality for archival purposes only).

8.2.3 Transition Plan. The Parties shall reasonably cooperate in good faith to effect the transition
to Janssen of all Product promotional activities to minimize disruptions to customers and patients.
In furtherance of the foregoing, and at the request of either Party, the Joint Commercial Team,
reasonably in advance of the expected end of the Term shall develop and approve a transition plan
that contains, among other things, a plan for notifying Targets and other customers or health care
providers of such termination or expiration and transition, and, if applicable, provides for the
completion of any events set forth in a Brand Plan which are already scheduled but will take place
after the effective date of termination or expiration.

8.2.4 Non-Exclusive Remedies. The consequences set forth in this Section 8.2 are not intended to be
the exclusive remedies of the Parties in connection with the breach of or termination of this
Agreement.

8.2.5 Compensation in Certain Termination Events. If this Agreement is terminated pursuant to any of
the following Sections, Janssen shall not be obligated to pay to Company (a) any Service Fees with
respect to any period after the effective date of termination of this Agreement or (b) any Milestone
Payments with respect to any Milestone Events that are achieved after the effective date of
termination of this Agreement: Section 8.1.4 (if terminated by Janssen for breach by Company),
8.1.5, 8.1.6, 8.1.7 (if terminated by Janssen for the insolvency of Company), 8.1.8 (if terminated
by Janssen for Force Majeure applicable to Company), 8.1.9, 8.1.10 (except that this Section 8.2.5
shall not affect Janssen's obligation to pay the amounts set forth in Section 8.1.10 as being
payable in accordance with and subject to the conditions set forth in such Section 8.1.10) or
8.1.11.

8.2.6 Survival. Termination or expiration of this Agreement shall not relieve a Party of any
liability for any breach that occurred, or of any obligation to make payment that accrued, before or
on the effective date of such termination or expiration, nor prejudice either Party's right to
obtain performance of any obligation provided for in this Agreement that survives termination or
expiration. All provisions of this Agreement which, in accordance with their terms, are intended to
have effect after the expiration or termination of this Agreement shall survive such termination or
expiration, including: Sections 3.1.2, 3.2.4(a) (with respect to the last month of the Term), 5.2
(subject to Section 8.2.5), 5.3 (subject to Section 8.2.5), 5.5.1, 5.5.2, 5.5.5, 5.5.6, 5.6,
<!-- page 31 -->
7.1, 7.2, 8.1.1 (last sentence only), 8.1.10 (only if the Agreement is terminated pursuant to
Section 8.1.10), 8.2, 9.1, 10.2, 11.8, and Articles XII, XIII and XIV.

8.3 Suspension of Product Promotion

8.3.1 Right to Suspend. Janssen shall have the right to require that both Parties suspend the
promotion of the Product in the Territory for the Initial Indication if Janssen decides, in its sole
discretion, acting in good faith, that it is necessary to do so due to safety reasons, or to comply
with applicable Law or a request or mandate of a Regulatory Authority, or because of any Third
Party's claim or potential claim of intellectual property infringement in relation to the Product.
In any such event, Company shall cease promoting the Product in the Territory immediately upon
Company's receipt of notice from Janssen directing it to do so, and Janssen shall have the right to
cease the sale and/or distribution of the Product for so long as promotion thereof is suspended.
Janssen shall discuss its decision with Company as soon as it is practicable to do so and consider
Company's input in good faith; provided, however, that all decisions regarding such matters shall be
made by Janssen in its sole discretion. If Janssen decides to end any such suspension of the
promotion, sale or distribution of the Product in the Territory, Janssen shall immediately notify
Company of its decision.

8.3.2 Adjustments Due to Suspension. In the event Janssen suspends the promotion and/or sale of the
Product in the Territory for the Initial Indication pursuant to Section 8.3.1, and such suspension
results in any restriction or prohibition on Detailing activities by Company for a period of one
week or more, then the Parties will discuss and attempt to agree upon an appropriate adjustment to
Company's Detailing obligations under the Brand Plan and/or the Baselines.

ARTICLE IX CONFIDENTIALITY; RESTRICTIVE COVENANTS

9.1 Confidentiality.

9.1.1 Non-Disclosure and Non-Use. Except to the extent expressly authorized by this Agreement or
otherwise agreed in writing, each of Janssen and Company agrees that, during the Term and until the
conclusion of the [***] ([***]) year period beginning upon the expiration or earlier termination of
this Agreement, such Party shall: (a) maintain in confidence the Confidential Information of the
other Party using not less than the efforts such Party uses to maintain in confidence its own
confidential or proprietary information of similar kind and value (but not less than reasonable
efforts); (b) not disclose the Confidential Information of the other Party to any Third Party; and
(c) not use the Confidential Information of the other Party for any purpose other than as provided
for in this Agreement.

9.1.2 Certain Information. The Brand Plan (including the Training Activities Plan and Call Plan),
the Target List and all information and data contained within such documents is deemed to be the
Confidential Information of Janssen. The reports of Details provided by Company pursuant to Section
3.2.4 and all data in the Company Internal Detailing System relating
<!-- page 32 -->
to the Product are deemed to be (a) the Confidential Information of both Parties during the Term and
(b) the Confidential Information of Janssen after the Term.

9.1.3 Exceptions. The obligations of Section 9.1.1 do not apply to any portion of the Confidential
Information of a Party (the "Disclosing Party") that the other Party (the "Receiving Party") can
show by competent written evidence:

(a) is already known to the Receiving Party before the time of disclosure by the Disclosing Party,
as evidenced by the Receiving Party's written records made or obtained before the date of
disclosure; provided, however, that this clause (a) shall not apply to the reports and data
described in the second sentence of Section 9.1.2;

(b) is disclosed to the Receiving Party on a non-confidential basis by a Third Party who, to the
knowledge of the Receiving Party, is under no obligation to the Disclosing Party (or any of its
Affiliates) with respect to confidentiality, secrecy or restriction on the use of such information
or data;

(c) is now, or hereafter becomes, through no act or failure of the Receiving Party or any of its
Affiliates in violation of this Agreement, generally known or available to the public;

(d) is independently discovered or developed by or on behalf of the Receiving Party or any of its
Affiliates (i) not pursuant to or in connection with this Agreement and (ii) without the use of or
reference to the Confidential Information of the Disclosing Party as evidenced by the Receiving
Party's written records; or

(e) is publicly disclosed by the Disclosing Party, either before or after it is disclosed to the
Receiving Party under this Agreement.

9.1.4 Permitted Disclosure. The Receiving Party may disclose the Disclosing Party's Confidential
Information only to the extent such disclosure is reasonably necessary in the following instances,
or to the extent permitted under the other applicable provisions of this Agreement:

(a) to those of the Receiving Party's Affiliates and its and their respective officers, directors,
employees, agents, advisors and consultants who (a) are bound in writing (or, with respect to
counsel to the Receiving Party, by professional or ethical obligations) by obligations of
confidentiality and non-use substantially similar to and consistent with those of this Section 9.1,
(b) need to receive the Confidential Information in order for the Receiving Party to exercise its
rights, conduct the activities required by or fulfill its other obligations under this Agreement and
(c) are made aware of the confidential nature of the information, and then only to the extent
required for the Receiving Party to exercise its rights under, conduct the activities required by or
fulfill its other obligations under this Agreement; provided that the Receiving Party shall be
responsible and liable for any breach of the provisions of this Section 9.1 by any Person who
receives Confidential Information pursuant to this Section 9.1.4(a);
<!-- page 33 -->
(b) with respect to Janssen as the Receiving Party, to the FDA or other applicable Regulatory
Authority where such disclosure is required in connection with any filing, application, or request
for any Regulatory Approval of the Product in the Territory;

(c) to the extent that such disclosure is necessary to prosecute litigation for the protection,
preservation, or return of Confidential Information or to enforce its rights under this Agreement;

(d) to comply with applicable Law or the rules of any stock exchange on which such Party's
securities (or the securities of a Party's Affiliate) are traded, subject to the terms of Section
9.1.5;

(e) with respect to Janssen as the Receiving Party, to counterparties under the License Agreement to
the extent such disclosure is required under the License Agreement or is advisable for the purpose
of carrying out more fully Janssen's obligations under this Agreement or otherwise increasing Net
Sales of the Product in the Territory; or

(f) to comply with court orders or administrative orders pursuant to Law.

In the case of disclosure pursuant to Section 9.1.4(c), 9.1.4(d) or 9.1.4(f), the Receiving Party
(i) shall, to the extent reasonably practicable under the circumstances, give reasonable advance
notice of the disclosure requirement to the Disclosing Party, so as to provide the Disclosing Party
with the opportunity to secure, to the extent available, a protective order (or similar remedy) or
other assurance of confidential treatment of the Confidential Information to be disclosed, and (ii)
shall reasonably cooperate with the Disclosing Party, at its expense and request, in seeking such
protective orders or other relief.

Any permitted use of the Disclosing Party's Confidential Information by the Receiving Party for
purposes of its performance hereunder will not be deemed a license or other right of the Receiving
Party to use any such Confidential Information for any other purpose. The Receiving Party shall not
acquire any right, title, or interest in or to any Confidential Information (including copies and
summaries thereof and extracts therefrom, whether tangible or in electronic or other form) of the
Disclosing Party by virtue of its disclosure hereunder.

9.1.5 Terms of this Agreement. The terms of this Agreement are deemed to be, and shall be treated by
each Party as, Confidential Information of each Party. Either Party may disclose the terms of this
Agreement and other information relating to this Agreement or the transactions contemplated by this
Agreement to the extent required, in the reasonable opinion of such Party's counsel, to comply with
the rules and regulations promulgated by the United States Securities and Exchange Commission, New
York Stock Exchange, Nasdaq Stock Market or similar security regulatory authorities or stock market
in other countries. If a Party intends to disclose this Agreement or any of its terms or other
Confidential Information of the other Party pursuant to this Section 9.1.5, such Party will, except
where impracticable or not legally permitted, give reasonable advance notice to the other Party of
such disclosure and seek confidential treatment
<!-- page 34 -->
of portions of this Agreement or such terms or information, as may be reasonably requested by the
other Party in a timely manner.

9.1.6 Prior Non-Disclosure Agreement. As of the Effective Date, the terms of this Section 9.1
supersede any prior non-disclosure, secrecy or confidentiality agreement between the Parties (or
their Affiliates) relating to the subject matter of this Agreement, including the Mutual
Confidentiality Agreement between the Parties dated February 1, 2019. Any information disclosed
pursuant to any such prior agreement shall be deemed Confidential Information under this Agreement.

9.2 Exclusivity. During the Term, neither Company nor any of its Affiliates (including, for the
avoidance of doubt, any Third Party that becomes an Affiliate of Company after the Effective Date)
shall, alone or in collaboration with any Third Party, market, promote, sell, distribute or
otherwise commercialize in the Territory any Competing Product without the prior written consent of
Janssen. In the event that, after the Effective Date, a Third Party (an "Acquirer") either (a)
merges with Company, (b) acquires "control" (as defined in Section 1.4) of Company or (c) acquires
substantially all the assets of the Company (each of (a), (b) and (c), an "Acquisition"), and such
Acquirer or any of its Affiliates immediately prior to such Acquisition is commercializing a
Competing Product in the Territory, then either Party shall have the right to terminate this
Agreement on [***] ([***]) days written notice delivered within [***] ([***]) days of the closing of
such Acquisition, and Company shall not be deemed to be marketing, promoting, selling, distributing
or commercializing a Competing Product in breach of this Section for so long as it is conducting
such activities solely through personnel who are not involved in any activities under this Agreement
and do not have access to Janssen's Confidential Information hereunder.

9.3 Restrictions on Promotion. During the Term, Company and its Affiliates (including, for the
avoidance of doubt, any Third Party which becomes an Affiliate of Company after the Effective Date)
(a) will not, whether alone or in collaboration with any Third Party or for itself or any Third
Party, during the promotion of any product, compare such product (other than the Product) with the
Product in any aspect nor disparage the Product in any manner, and (b) with respect to any such
product that is a product of Company or its Affiliates and that Company or its Affiliates promotes,
sells, distributes, or otherwise commercializes using or through a Third Party, will (i) cause any
such Third Party, during the promotion of such product, not to compare such product with the Product
in any aspect nor disparage the Product in any manner and (ii) not authorize any Third Party to make
any such comparison or disparagement.

9.4 Limitation on Soliciting Employees. During the Term, Janssen shall not directly or indirectly
solicit for employment any Sales Representative who is an employee of Company, and Company shall not
directly or indirectly solicit for employment any employee of Janssen with whom Company has had
contact in the course of the evaluation or negotiation of this Agreement or with whom Company
interacts during the Term; provided, however, that the foregoing provision will not prohibit either
Party from (a) conducting general solicitations of employment in publications (including but not
limited to websites, newspapers and/or journals) available to the public, or solicitations through
the use of search firms, and which, in any case, are not directed
<!-- page 35 -->
specifically toward such employees of the other Party or (b) any contact with any such employee of
the other Party (i) that was initiated by such employee without any solicitation prior thereto by
the contacting Party (other than solicitation permitted by clause (a) of this sentence) or (ii) with
whom the contacting Party is already in employment discussions as of the Effective Date, or (iii) by
any person other than (A) one who was introduced to, or became aware of, the relevant employee of
the other Party solely in connection with this Agreement, and (B) one who is acting at the direction
or suggestion of a person described in (A).

ARTICLE X INTELLECTUAL PROPERTY

10.1 Use of Trademarks. Janssen and its Affiliates shall retain all right, title and interest in and
to its and their respective Trademarks. Company shall Promote pursuant to this Agreement only under
the Product name and other Product Trademarks used by Janssen in the Territory. Janssen hereby
grants to Company, during the Term, a non-exclusive, royalty free right to use such Product name and
Product Trademarks, and Janssen corporate names and logos, solely to the extent they are included on
the Promotional Materials and solely for the purpose of using the Promotional Materials to Promote
in the Territory under this Agreement. Company shall not, without the express, prior written consent
of Janssen, alter or modify in any manner any Product Trademark or any other Trademark of Janssen.
Company agrees to comply with such Janssen standard guidelines regarding the use of the Product
Trademarks and any other Trademarks of Janssen, and any amendments thereto, as Janssen provides to
Company from time to time after the Effective Date (including the Janssen Brand Usage Guidelines).

10.2 Ownership of Intellectual Property Rights. Company acknowledges and agrees that Janssen or one
of its Affiliates (a) is the sole and exclusive owner of all rights in and to the Product Trademarks
and any other Trademarks of Janssen, including any form or embodiment thereof, and the goodwill now
or hereafter associated therewith, (b) shall own the copyrights to all Promotional Materials and the
Product Label and Insert, and (c) has the sole right to assert or control any action to enforce its
rights in or to any of the Product Trademarks, any other Trademarks of Janssen or such copyrights
and to receive the proceeds of any such action. Company further acknowledges and agrees that it does
not, by virtue of this Agreement or its activities hereunder, obtain or acquire any right or
interest in the Product Trademarks, any other Trademarks of Janssen, such copyrights, or any other
intellectual property right of Janssen or its Affiliates. To the extent that Company, by operation
of Law or otherwise, acquires any right (other than pursuant to this Agreement) to any of the
Product Trademarks, any other Trademarks of Janssen, such copyrights or such other intellectual
property rights, Company shall assign to Janssen all such rights at Janssen's cost and will not
claim ownership. Company agrees that it shall not seek to register or obtain ownership rights in any
of Janssen's corporate names, logos, or Product Trademarks (or any confusingly similar trademark).

10.3 Prosecution and Maintenance. Janssen will have the right (and not the obligation) to prepare,
file, prosecute and maintain any intellectual property right of Janssen or its Affiliates claiming
or covering the Product or its use in its sole discretion and at its own cost.
<!-- page 36 -->
10.4 Enforcement against Infringement. Janssen and Company will each promptly notify the other in
writing of any alleged or threatened infringement by a Third Party in the Territory of any
intellectual property right of Janssen or its Affiliates claiming or covering the Product or its use
in treating urothelial cancer, or any alleged or threatened assertion by a Third Party of invalidity
of any of the intellectual property rights of Janssen or its Affiliates claiming or covering the
Product or its use in treating urothelial cancer in the Territory, of which such Party becomes
aware. Janssen and its Affiliates shall have the sole right (but not the obligation) to prosecute
any such infringement in its sole discretion and at its sole cost.

10.5 Third Party Infringement Claims. In the event that Janssen or its Affiliate(s) decides to
obtain a license to intellectual property from a Third Party in the Territory in order to
commercialize the Product, whether or not due to a Third Party claim, notice, or suit or other inter
partes proceeding against Janssen, Company and/or their Affiliates alleging that the
commercialization of the Product in the Territory infringes or misappropriates any intellectual
property rights of such Third Party, Janssen and its Affiliate(s) shall be solely responsible for
the costs associated with such license and Company shall provide reasonable cooperation to Janssen
or its applicable Affiliate(s) in procuring and complying with such license.

ARTICLE XI REPRESENTATIONS AND WARRANTIES; CERTAIN COVENANTS

11.1 Representations of Authority. Janssen and Company each represents and warrants to the other
Party that, as of the Effective Date, it has full right, power and authority to enter into this
Agreement and to perform its respective obligations under this Agreement and that it has the right
to grant to the other Party the rights granted pursuant to this Agreement as set forth herein.

11.2 Consents. Janssen and Company each represents and warrants to the other Party that all
necessary consents, approvals, and authorizations of all Government Authorities and other Persons
required to be obtained by it as of the Effective Date in connection with the execution, delivery,
and performance of this Agreement have been obtained by the Effective Date.

11.3 No Conflict. Janssen and Company each represents and warrants to the other Party that the
execution and delivery of this Agreement by it and the performance of its obligations hereunder (a)
do not conflict with or violate any Laws existing as of the Effective Date as applicable to such
Party and (b) do not conflict with, violate, breach, or constitute a default under any of its
material contractual obligations existing as of the Effective Date.

11.4 Enforceability. Janssen and Company each represents and warrants to the other Party that, as of
the Effective Date, this Agreement is a legal and valid obligation binding upon it and is
enforceable against it in accordance with its terms, subject to the laws of bankruptcy, insolvency,
and creditors' rights.

11.5 Sales Representatives and Other Company Employees.
<!-- page 37 -->
11.5.1 Company covenants to Janssen that:

(a) with respect to the Product, the Sales Representatives and Other Company Employees in the
Territory shall make no statements, claims, or undertakings to any health care provider with whom
they discuss or promote the Product that are not consistent with, nor provide nor use any labeling,
literature, or other materials other than, the Product Label and Insert and those Promotional
Materials provided and approved for use pursuant to this Agreement; and

(b) it shall ensure that all statements, comments and claims made by the Sales Representatives and
Other Company Employees (i) about the Product, including as to efficacy and safety, are truthful and
accurate and are consistent with and in strict compliance with the Product Label and Insert and all
applicable Laws, and (ii) about Janssen in relation to the Product are truthful, accurate, and in
strict compliance with all applicable Laws.

Any statement, claim or comment that is contained in the Promotional Materials or the Product Label
and Insert, in each case, as in effect when such statement, claim or comment is made, shall be
deemed not to violate this Section 11.5.1.

11.5.2 Company shall perform all Detailing and other promotional activities with respect to the
Product in compliance with applicable Laws and the Promotion Rules.

11.6 Other Compliance Matters.

11.6.1 Company represents and warrants that it has established, and covenants that it will maintain
during the Term, a compliance program consistent with the Compliance Program Guidance for
Pharmaceutical Manufacturers published by the Office of Inspector General, U.S. Department of Health
and Human Services.

11.6.2 Company represents and warrants that it has implemented, and covenants that it will maintain
during the Term, adequate systems, policies, and procedures governing (1) interactions with health
care professionals, (2) material that can be distributed or discussed with health care
professionals, (3) the manner in which personnel should handle unsolicited requests for off- label
information, and (4) the review and approval of all marketing, promotion, and sales materials, call
plans, and incentive compensation structures. Company represents and warrants that such policies and
procedures are and will be consistent with applicable Law and with this Agreement. 11.6.3 Company
represents and warrants that neither Company, nor any of its employees, officers, directors, or
agents, has been debarred by the FDA, is the subject of a conviction described in 21 U.S.C. 335a, or
is subject to any similar sanction. Company represents and warrants that it has not, and covenants
that it will not engage, in any capacity in connection with this Agreement, any person who has been
debarred by FDA, is the subject of a conviction
<!-- page 38 -->
described in 21 U.S.C. 335a, or is subject to any similar sanction. Company shall promptly inform
Janssen in writing if it or any person performing services under this Agreement is debarred or is
the subject of a conviction described in 21 U.S.C. 335a, or if any action, suit, claim,
investigation, or legal or administrative proceeding is pending or threatened relating to the
debarment or such conviction of Company or any such person performing services in connection with
this Agreement. Upon written request from Janssen, Company shall, within ten (10) days, provide
written confirmation that it has complied with the foregoing obligation.

11.6.4 Company represents and warrants that it is in compliance, and covenants that it will continue
to comply during the Term, with all applicable Laws, rules and regulations, including the federal
anti-kickback statute (42 U.S.C. § 1320a-7b), the related safe harbor regulations, and the
Limitation on Certain Physician Referrals, also referred to as the "Stark Law" (42 U.S.C. § 1395nn).

11.6.5 Company shall conduct activities in accordance with applicable state and federal Laws and any
applicable regulations regarding Medicare, Medicaid, and other third party-payer programs, if any.
Company represents and warrants that (1) it is not excluded from, and has not been convicted of any
crime or engaged in any conduct that could result in exclusion from, participation in any state or
federal healthcare program, as defined in 42 U.S.C. §1320a-7b(f), for the provision of items or
services for which payment may be made by a federal healthcare program; (2) it has not contracted,
and will not contract, with any employee, contractor, agent, or vendor to perform work under the
Agreement who is excluded from participation in any state or federal healthcare program; and (3) it
is not subject to a final adverse action, as defined in 42 U.S.C.§ 1320a-7a(e) and 42 U.S.C. §
1320a- 7a(g), and has no adverse action pending or threatened against it. Company shall notify
Janssen of any final adverse action, discovery of contract with an excluded entity or individual, or
exclusion within thirty (30) days of such action.

11.6.6 Company will comply with Exhibit D.

11.6.7 Janssen represents and warrants that neither Janssen, nor any of its employees, officers,
directors, or agents, has been debarred by the FDA, is the subject of a conviction described in 21
U.S.C. 335a, or is subject to any similar sanction. Janssen represents and warrants that it has not,
and covenants that it will not engage, in any capacity in connection with this Agreement, any person
who has been debarred by FDA, is the subject of a conviction described in 21 U.S.C. 335a or is
subject to any similar sanction. Janssen shall promptly inform Company in writing if it or any
person performing services under this Agreement is debarred or is the subject of a conviction
described in 21 U.S.C. 335a, or if any action, suit, claim, investigation, or legal or
administrative proceeding is pending or threatened relating to the debarment or such conviction of
Janssen or any such person performing services in connection with this Agreement.
<!-- page 39 -->
11.6.8 Janssen represents and warrants that it has established, and covenants that it will maintain
during the Term, Promotional Materials which are truthful, accurate, and in strict compliance with
all applicable Laws.

11.6.9 Janssen represents and warrants that it is in compliance, and covenants that it will continue
to comply during the Term, with all applicable Laws, rules and regulations, including the federal
anti-kickback statute (42 U.S.C. § 1320a-7b), the related safe harbor regulations, and the
Limitation on Certain Physician Referrals, also referred to as the "Stark Law" (42 U.S.C. § 1395nn).

11.6.10 Janssen shall conduct all activities hereunder in accordance with applicable state and
federal Laws, including any applicable regulations regarding Medicare, Medicaid, and other third
party-payer programs, if any. Janssen represents and warrants that (1) it is not excluded from, and
has not been convicted of any crime or engaged in any conduct that could result in exclusion from,
participation in any state or federal healthcare program, as defined in 42 U.S.C. §1320a-7b(f), for
the provision of items or services for which payment may be made by a federal healthcare program;
(2) it has not contracted, and will not contract, with any employee, contractor, agent, or vendor to
perform work under the Agreement who is excluded from participation in any state or federal
healthcare program; and (3) it is not subject to a final adverse action, as defined in 42 U.S.C.§
1320a-7a(e) and 42 U.S.C. § 1320a-7a(g), and has no adverse action pending or threatened against it.

11.7 Infringement of Third Party Intellectual Property; Clinical Trial Data. Janssen represents and
warrants to Company that, to its knowledge, as of the Effective Date, the manufacture, use, import,
or sale of the Product in the Territory for the Initial Indication does not, and will not during the
Term, infringe or misappropriate any intellectual property rights of any Third Party. Janssen
represents and warrants to Company that, as of the Effective Date, [***].

11.8 Disclaimer. EXCEPT AS OTHERWISE EXPRESSLY SET FORTH IN THIS ARTICLE XI, NEITHER JANSSEN NOR
COMPANY, NOR ANY OF THEIR AFFILIATES, MAKES ANY REPRESENTATION OR EXTENDS ANY WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, TO THE OTHER PARTY IN CONNECTION WITH THE PRODUCT, AND HEREBY DISCLAIMS
ALL IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
WITH RESPECT TO THE PRODUCT. EACH PARTY HEREBY DISCLAIMS ANY REPRESENTATION OR WARRANTY THAT THE
EXPLOITATION OF THE PRODUCT PURSUANT TO THIS AGREEMENT WILL BE SUCCESSFUL OR THAT ANY PARTICULAR
SALES LEVEL WITH RESPECT TO THE PRODUCT WILL BE ACHIEVED.

ARTICLE XII INDEMNIFICATION; LIMITS ON LIABILITY

12.1 Scope of Indemnification.
<!-- page 40 -->
12.1.1 Janssen shall indemnify and hold harmless Company, its Affiliates and its and their
respective directors, officers, employees, and agents (collectively, the "Company Indemnified
Parties"), from, against, and in respect of any and all liabilities, costs, fines, penalties, orders
of any Governmental Authorities, Taxes, expenses, or amounts paid as damages or in settlement (in
each case, including reasonable attorneys' and experts fees and expenses), involving an Action
asserted by a Third Party (collectively, "Losses"), incurred or suffered by the Company Indemnified
Parties or any of them and arising out of or resulting from:

(a) any breach by Janssen or any of the other Janssen Indemnified Parties of any representation,
warranty or covenant under this Agreement;

(b) the negligence or willful misconduct of Janssen or any of the other Janssen Indemnified Parties
in connection with Janssen's performance under this Agreement;

(c) any claim of death or bodily injury resulting from the use of the Product sold in the Territory;
or

(d) any recall, withdrawal, product return or suspension of product promotion under Section 3.6, 3.7
or 8.3.

except, in each case ((a), (b) (c), and (d)), to the extent caused by the negligence or willful
misconduct of Company or any of the other Company Indemnified Parties or the breach by Company of
any of its representations, warranties or covenants set forth herein.

12.1.2 Company shall indemnify and hold harmless Janssen, its Affiliates, and its and their
respective directors, officers, employees, and agents (collectively, the "Janssen Indemnified
Parties"), from, against and in respect of any and all Losses incurred or suffered by the Janssen
Indemnified Parties or any of them and arising out of or resulting from:

(a) any breach by Company or any of the other Company Indemnified Parties of any representation,
warranty or covenant under this Agreement; or

(b) the negligence or willful misconduct of Company or any of the other Company Indemnified Parties
in connection with Company's performance under this Agreement;

except in each case ((a) and (b)), to the extent caused by the negligence or willful misconduct of
Janssen or any of the other Janssen Indemnified Parties or the breach by Janssen of any of its
representations, warranties or covenants set forth herein.

12.2 Notice and Control of Actions.
<!-- page 41 -->
12.2.1 A Person entitled to indemnification under this Article XII (an "Indemnified Party") shall
give prompt written notification to the Person from whom indemnification is sought (the
"Indemnifying Party") of the assertion of any Action by a Third Party for which indemnification may
be sought (it being understood and agreed, however, that the failure by an Indemnified Party to give
such notice of a Third Party Action as provided in this Section 12.2.1 shall not relieve the
Indemnifying Party of its indemnification obligation under this Agreement except and only to the
extent that such Indemnifying Party is actually prejudiced as a result of such failure to give
notice).

12.2.2 Within thirty (30) days after delivery of such notification, the Indemnifying Party may, upon
written notice thereof to the Indemnified Party, assume control of the defense of such Action with
counsel reasonably satisfactory to the Indemnified Party; provided, however, that the Indemnifying
Party shall not have the right to control the defense of any Action against any Indemnified Party
involving criminal charges or tax matters. If the Indemnifying Party does not assume control of the
defense of an Action, the Indemnified Party shall control such defense.

12.2.3 The Party not controlling such defense shall reasonably cooperate with the other Party at
such other Party's request and expense, and may participate therein at its own expense; provided,
however, that if the Indemnifying Party assumes control of such defense and the Indemnified Party
reasonably concludes, based on advice from counsel, that the Indemnifying Party and the Indemnified
Party have conflicting interests with respect to such Action, the Indemnifying Party shall be
responsible for the reasonable fees and expenses of counsel to the Indemnified Party solely in
connection with such Action; provided further, however, that in no event shall the Indemnifying
Party be responsible for the fees and expenses of more than one counsel for all Indemnified Parties.

12.2.4 The Party controlling such defense shall keep the other Party advised of the status of such
Action and the defense thereof and shall consider recommendations made by the other Party with
respect thereto.

12.2.5 The Indemnified Party shall not agree to any settlement of such Action, consent to any
judgment in respect thereof or admit any liability with respect thereto, without the prior written
consent of the Indemnifying Party, which shall not be unreasonably withheld or delayed.

12.2.6 The Indemnifying Party shall not agree to any settlement of such Action or consent to any
judgment in respect thereof without the prior written consent of the Indemnified Party, which shall
not be unreasonably withheld or delayed; provided, however, that no such consent shall be required
with respect to any such settlement, compromise or consent to judgment that (a) involves solely the
payment of money damages as to which the Indemnifying Party has acknowledged its obligation to
indemnify hereunder, (b) does not involve any claim for injunctive
<!-- page 42 -->
or other equitable relief, and (c) effects a full and unconditional release of the Indemnified Party
with respect to all claims related to the Action.

12.3 Limitations on Liability. SUBJECT TO AND WITHOUT LIMITING THE INDEMNIFICATION OBLIGATIONS OF
EACH PARTY WITH RESPECT TO THIRD PARTY ACTIONS UNDER SECTIONS 12.1 AND 12.2, AND EXCEPT WITH RESPECT
TO LIABILITY ARISING FROM BREACH OF SECTION 9.1 BY A PARTY, NO PARTY OR ANY OF ITS AFFILIATES WILL
BE LIABLE TO THE OTHER PARTY OR ITS AFFILIATES UNDER ANY CONTRACT, WARRANTY, NEGLIGENCE, TORT,
STRICT LIABILITY OR OTHER LEGAL OR EQUITABLE THEORY FOR ANY SPECIAL, INDIRECT, INCIDENTAL, PUNITIVE,
MULTIPLIED OR CONSEQUENTIAL DAMAGES, OR OTHER DAMAGES FOR LOSS OF PROFIT, SALES OR FEES, ARISING OUT
OF OR IN CONNECTION WITH THIS AGREEMENT OR ITS SUBJECT MATTER. FURTHER, SUBJECT TO AND WITHOUT
LIMITING THE INDEMNIFICATION OBLIGATIONS OF EACH PARTY WITH RESPECT TO THIRD PARTY ACTIONS UNDER
SECTIONS 12.1 AND 12.2, AND EXCEPT WITH RESPECT TO LIABILITY ARISING FROM BREACH OF SECTION 9.1 BY A
PARTY OR ARISING FROM THE GROSS NEGLIGENCE OR WILLFUL MISCONDUCT OF A PARTY, EACH PARTY'S AGGREGATE
LIABILITY TO THE OTHER PARTY FOR ALL CASES AND CONTROVERSIES ARISING OUT OF THE SUBJECT MATTER OF
THIS AGREEMENT, REGARDLESS OF THE CAUSE OF ACTION AND WHETHER BROUGHT IN CONTRACT, TORT (INCLUDING
NEGLIGENCE), STRICT LIABILITY OR OTHERWISE, WILL BE LIMITED TO $[***]. THE AMOUNT OF SERVICE FEES
AND MILESTONE PAYMENTS PAID OR DUE TO COMPANY UNDER THIS AGREEMENT WILL NOT BE INCLUDED IN THE
CALCULATION OF SUCH AGGREGATE LIABILITY AMOUNT.

12.4 Insurance. Company agrees to comply with Exhibit E attached hereto, which is incorporated
herein by this reference.

ARTICLE XIII DISPUTE RESOLUTION

13.1 Disputes. All disputes, claims or controversies (other than matters that are expressly stated
herein to require the consent of either or both Parties) arising from or related to this Agreement,
or to the interpretation, application, breach, termination or validity of this Agreement, whether
based on contract, tort, statute, or other theory of liability ("Disputes"), shall be resolved in
accordance with this Article XIII. It is the intent of the Parties that all Disputes relating in any
way to this Agreement should be resolved in accordance with this Article, including Disputes that
may involve the parent companies, subsidiaries, and other Affiliates of any Party.

13.2 Negotiation. Before any Dispute may be submitted to mediation or arbitration as provided below,
the Dispute shall be referred to the President of Janssen and the Chief Executive Officer of Company
for discussion and attempted resolution. No statements made by either Party during such discussions
will be used by the other Party or admissible in arbitration or any other
<!-- page 43 -->
subsequent proceeding for resolving the dispute. If such executives do not resolve the Dispute
within thirty (30) days of such referral by either Party, then either Party may, upon written notice
to the other Party, submit the Dispute to mediation pursuant to Section 13.3 and binding arbitration
pursuant to Section 13.4.

13.3 Mediation.

13.3.1 The Parties shall first attempt in good faith to resolve any Dispute that is not resolved
pursuant to Section 13.2 by confidential mediation in accordance with the then current Mediation
Procedure of the International Institute for Conflict Prevention and Resolution ("CPR Mediation
Procedure") (http://www.cpradr.org) before initiating arbitration. The CPR Mediation Procedure shall
control, except where the CPR Mediation Procedure conflicts with these provisions, in which case
these provisions control. The mediator shall be chosen pursuant to the CPR Mediation Procedure. The
mediation shall be conducted in English in New York, New York. At the request of either Party (and
at the shared expense of the Parties), the mediation shall have simultaneous translation from and
into English.

13.3.2 Either Party may initiate mediation with respect to any Dispute that is not resolved pursuant
to Section 13.2 by written notice to the other Party. The Parties agree to select the mediator
within twenty (20) days of the notice and the mediation will begin promptly after the selection. The
mediation will continue until the mediator or either Party, declares in writing, no sooner than
after the conclusion of one full day of a substantive mediation conference attended on behalf of
each Party by a senior business person with authority to resolve the Dispute, that the Dispute
cannot be resolved by mediation. In no event, however, shall mediation continue more than sixty (60)
days from the initial notice by a Party to initiate meditation unless the Parties agree in writing
to extend that period.

13.3.3 Any period of limitations that would otherwise expire between the initiation of mediation and
its conclusion shall be extended until twenty (20) days after the conclusion of the mediation.

13.4 Arbitration. If the Parties fail to resolve a Dispute by mediation under Section 13.3 and
either Party desires to pursue resolution of the Dispute, the Dispute shall be submitted by either
Party for resolution in arbitration pursuant to the then current CPR Rules for Non-Administered
Arbitration of International Disputes ("CPR Rules") (http://www.cpradr.org), except where they
conflict with these provisions, in which case these provisions control. CPR is designated as the
Neutral Organization for all purposes.

13.4.1 Language/Location. The arbitration shall be conducted in English in New York, New York.

13.4.2 Selection of Arbitrators.

(a) The arbitrators will be chosen from the CPR Panels of Distinguished Neutrals, unless a candidate
not on the CPR Panels of Distinguished Neutrals is approved by both
<!-- page 44 -->
Parties. Each arbitrator shall be a lawyer with at least fifteen (15) years' experience with a law
firm or corporate law department of over twenty-five (25) lawyers or who was a judge of a court of
general jurisdiction. To the extent that the Dispute requires special expertise, the Parties will so
inform CPR prior to the beginning of the selection process.

(b) The arbitration tribunal shall consist of three (3) arbitrators, chosen in accordance with Rules
5.3 and 6 of the CPR Rules. If, however, the aggregate award sought by the Parties is less than five
million United States dollars (USD $5,000,000) and equitable relief is not sought, a single
arbitrator shall be chosen in accordance with Rules 5.3 and 6 of the CPR Rules.

(c) Candidates for the arbitrator position(s) may be interviewed by representatives of the Parties
in advance of their selection, provided that all Parties are represented.

(d) The Parties agree to select the arbitrator(s) within forty-five (45) days of initiation of the
arbitration.

13.4.3 Conduct of Proceedings.

(a) The hearing will be concluded within nine (9) months after selection of the arbitrator(s) and
the award will be rendered within 60 days of the conclusion of the hearing, or of any post hearing
briefing, which briefing will be completed by both sides within 45 days after the conclusion of the
hearing. In the event the Parties cannot agree upon a schedule, then the arbitrator(s) shall set the
schedule following the time limits set forth above as closely as practical.

(b) The arbitrator(s) shall be guided, but not bound, by the IBA Rules on the Taking of Evidence in
International Commercial Arbitration (www.ibanet.org).

(c) The hearing will be concluded in ten hearing days or less. Multiple hearing days will be
scheduled consecutively to the greatest extent possible. A transcript of the testimony adduced at
the hearing shall be made and shall be made available to either Party.

13.4.4 Applicable Law. The arbitrator(s) shall decide the merits of any Dispute in accordance with
the law governing this Agreement, without application of any principle of conflict of laws that
would result in reference to a different law. The arbitrator(s) may not apply principles such as
"amiable compositeur" or "natural justice and equity."

13.4.5 Award.

(a) The arbitrator(s) shall render a written opinion stating the reasons upon which the award is
based. The arbitrator(s) may award the costs and expenses of the arbitration as provided in the CPR
Rules, but each Party shall bear its own attorney fees.

(b) The award may be entered and enforced in any court of competent jurisdiction. If a court is
called upon to enforce an award in a court proceeding, the Parties consent
<!-- page 45 -->
to the court's requiring the Party resisting enforcement to pay the reasonable attorneys' fees and
costs incurred in that proceeding by the Party seeking enforcement.

13.4.6 Provisional Relief. Any Party may seek emergency, interim, or provisional relief prior to the
appointment of the arbitrator(s) from any court of competent jurisdiction, without waiver of the
agreements to mediate and arbitrate. After appointment of the arbitrator(s), any request for
emergency, interim, or provisional relief shall either be addressed to the arbitrator(s), which
shall have the power to enter an interim award granting relief using the standards provided by
applicable law, or to a court, but only with the permission of the arbitrator(s). Any interim award
of the arbitrator(s) may be enforced in any court of competent jurisdiction.

13.4.7 WAIVER. EACH PARTY HERETO WAIVES: (A) ITS RIGHT TO TRIAL OF ANY ISSUE BY JURY, (B) WITH THE
EXCEPTION OF RELIEF MANDATED BY STATUTE, ANY CLAIM FOR THE TYPES OF DAMAGES EXCLUDED BY SECTION 12.3
(SUBJECT TO THE EXCEPTIONS SPECIFIED IN SUCH SECTION), AND (C) ANY CLAIM FOR ATTORNEY FEES, COSTS
AND PREJUDGMENT INTEREST.

13.5 Confidentiality. All proceedings and decisions of the mediator(s) and/or arbitrator(s) shall be
deemed Confidential Information of each of the Parties and shall be subject to Section 9.1.

ARTICLE XIV MISCELLANEOUS

14.1 Press Announcements. Neither Party, nor any of its Affiliates, shall issue any press release or
make any other public statement relating to the terms and conditions of this Agreement or the
relationship contemplated hereunder without the prior written consent of the other Party.
Notwithstanding the foregoing, each Party (or its applicable Affiliate) may make any disclosure
relating to the Product or the terms and conditions of this Agreement that such Party (or
Affiliate), in the opinion of its counsel, is obligated to make pursuant to Laws applicable to
publicly-traded companies, including, inter alia, regulations of the Securities and Exchange
Commission, the New York Stock Exchange or the Nasdaq Stock Market. In such event, the announcement
shall be brief and factual (to the extent consistent with applicable Laws), and the Party required
to make such disclosure shall, to the extent practicable, notify the other Party of the method and
content of such disclosure a reasonable period of time (at least five (5) Business Days if possible)
in advance thereof, so as to allow such other Party to review it for the use of its name and
disclosure of Confidential Information.

14.2 Force Majeure Event. All incidents of force majeure, being circumstances beyond the reasonable
control of either Party and which have, or may have, a material effect on the ability of such Party
to perform under this Agreement, including, failure of power or other utility or sanitary supplies;
fire; flood; earthquake; other natural disaster; explosion; riot; strike or lock-out of such Party's
workforce; civil insurrection or unrest; terrorist activity; war (whether declared or not); and
regulations of any Governmental Authority, in each case, to the extent beyond the
<!-- page 46 -->
reasonable control of such Party ("Force Majeure"), shall, for the duration and to the extent of the
effects caused thereby, release such Party from the performance of its contractual obligations
hereunder. The Party who has suffered the Force Majeure shall notify the other Party without delay
of any such incident(s) occurring, and the Parties shall discuss the effects and extent of such
incident(s) on this Agreement and the measures to be taken. Each Party shall use Diligent Efforts to
avoid or restrict Force Majeure and to mitigate any loss therefrom. In the event of an incident or
incidents of Force Majeure, the Party whose performance has been affected thereby shall as soon as
reasonably possible resume performance of its obligations hereunder. If any Force Majeure
substantially prevents, hinders, or delays performance by a Party in a manner and to an extent that
would, but for this Section, constitute a material breach or give rise to a right of termination
hereunder, and the performance is not materially restored within one hundred eighty (180) days, the
other Party may terminate this Agreement upon written notice to such Party.

14.3 Independent Contractors. Nothing in this Agreement shall create or imply an association,
partnership, or joint venture between the Parties, it being agreed and understood that the Parties
are independent contractors; and neither Party, with respect to a Third Party, shall have the power
or authority to bind or obligate the other Party in any way. Neither Party shall have any
responsibility for the hiring, termination or compensation of the other Party's employees or for any
employee benefits of such employee. No employee or representative of a Party shall have any
authority to bind or obligate the other Party to this Agreement for any sum or in any manner
whatsoever, or to create or impose any contractual or other liability on the other Party without
said Party's approval.

14.4 Performance by Affiliates. To the extent that this Agreement purports to impose obligations on
the Affiliates of a Party, such Party agrees to cause its Affiliates to perform such obligations.
Company shall not use an Affiliate to exercise any of its rights or perform any of its obligations
or duties hereunder without Janssen's prior written consent. Janssen may use an Affiliate to
exercise its rights or perform its obligations and duties hereunder with prior written notice to
Company. If either Janssen or Company uses an Affiliate to exercise any of its rights or perform any
of its obligations or duties hereunder, as the case may be, such Party shall remain liable hereunder
for the prompt payment and performance of all of its obligations hereunder.

14.5 Notices.

14.5.1 All notices, statements, requests or other documents that either Party shall be required or
shall desire to give to the other hereunder shall be in writing and shall be given by the Parties
only as follows: (a) by personal delivery; (b) by facsimile, receipt confirmed; (c) by addressing it
as indicated below, and by depositing it certified mail, postage prepaid, in the mail, first class
(airmail if the address is outside of the country in which such notice is deposited); or (d) by
addressing it as indicated below, and by delivering it toll prepaid to a recognized courier service
(e.g., Federal Express or DHL).

14.5.2 If so delivered, transmitted by facsimile, mailed, or couriered, each such notice, statement,
request or other document shall, except as herein expressly provided, be
<!-- page 47 -->
conclusively deemed to have been given when personally delivered or faxed during a Business Day, or
on the fifth (5th) Business Day after the date of mailing, or on the second (2nd) Business Day after
delivery to a courier service, as the case may be. The address of a Party shall be the address of
which the other Party actually receives written notice pursuant to this Section 14.5 and until
further notice such addresses are:

If to Janssen, to:

Janssen Biotech, Inc. 800 Ridgeview Dr. Horsham, PA 19044 Attention: President, Oncology Facsimile:
[***]

With a copy (which shall not constitute notice) to:

Office of the General Counsel Johnson & Johnson One Johnson & Johnson Plaza New Brunswick, NJ 08933
Attn: General Counsel, Pharmaceuticals Fax No.: [***]

If to Company, to:

Immunomedics, Inc. 300 The American Road Morris Plains, NJ 07950 Attn: General Counsel

14.6 Entire Agreement. This Agreement, including the exhibits and schedules attached hereto (which
are hereby incorporated by reference), sets forth the entire agreement and understanding between the
Parties as to the subject matter hereof and supersedes all agreements or understandings, oral or
written, made between the Parties before the Effective Date with respect to the subject matter
hereof. 14.7 Amendments; Assignment. This Agreement may not be revised, amended, supplemented, or
varied except by an instrument in writing signed by Janssen and Company. Neither this Agreement nor
any rights or obligations of a Party may be assigned, delegated or otherwise transferred by such
Party without the prior written consent of the other Party; provided, however, that Janssen may,
without such consent but with prior written notice to Company, assign, delegate and transfer this
Agreement or all or any of its rights and obligations under this Agreement to (a) any Third Party
that acquires substantially all Janssen's assets relating to the Product in the
<!-- page 48 -->
Territory or (b) any Affiliate of Janssen. Any attempted assignment, transfer or delegation not in
accordance with this Section shall be void.

14.8 Non-Waiver of Rights. Failure of a Party to enforce any of the provisions of or any rights with
respect to this Agreement shall in no way be considered a waiver of such provisions or rights or in
any way affect the validity of this Agreement. The failure of either Party to enforce any of such
provisions or rights shall not preclude or prejudice such Party from later enforcing or exercising
the same or any other provisions or rights which it may have under this Agreement. The waiver of any
provision, right or obligation under this Agreement shall be effective only if in a written
instrument signed by the Party to be bound thereby.

14.9 Further Assurances and Cooperation. Each Party agrees that after the Effective Date it will
execute and deliver, or cause its Affiliates to execute and deliver, such further documents and
instruments as may be reasonably necessary or proper to fully effectuate this Agreement and the
transactions contemplated hereby.

14.10 Severability. This Agreement is intended to be valid and effective under any Laws and, to the
extent permissible under Law, shall be construed in a manner to avoid violation of or invalidity
under any Laws. Should any provisions of this Agreement be or become invalid, illegal, or
unenforceable under any Laws, the other provisions of this Agreement shall not be affected and shall
remain in full force and effect, and, to the extent permissible under the Laws, any such invalid,
illegal, or unenforceable provision shall be deemed amended lawfully to conform with the intent of
the Parties.

14.11 Binding Effect. This Agreement shall be binding upon and inure to the benefit of the Parties
hereto and their respective successors and permitted assigns.

14.12 Counterparts; Facsimile Signatures. This Agreement may be executed in counterparts, each of
which counterparts, when so executed and delivered, will be deemed to be an original, and all of
which counterparts, taken together, will constitute one and the same instrument even if all parties
have not executed the same counterpart. Signatures provided by any photocopy and transmitted by
facsimile or other electronic means will be deemed to be original signatures.

14.13 Third Party Beneficiaries. The provisions of this Agreement are not intended legally to
benefit or be enforceable by any Person who is not a party to this Agreement, and no such Person
shall obtain any right under any such provisions or shall by reason of such provisions make any
claim against a party to this Agreement.

14.14 Governing Law. The interpretation, construction and performance of this Agreement, and the
rights granted and obligations arising hereunder, shall be governed in accordance with the
substantive laws of the State of New York, without regard to its conflicts of law rules.
<!-- page 49 -->
14.15 Construction. Except where expressly stated otherwise in this Agreement, the following rules
of interpretation apply to this Agreement: (a) "include", "includes", and "including" are not
limiting and mean include, includes, and including, without limitation; (b) definitions contained in
this Agreement are applicable to the singular as well as the plural forms of such terms; (c)
references to an agreement, statute, regulation, or instrument mean such agreement, statute,
regulation, or instrument as from time to time amended, modified, or supplemented; (d) references to
a Person are also to its successors and permitted assigns; (e) references to an "Article",
"Section", "Exhibit", or "Schedule" refer to an Article or Section of, or any Exhibit or Schedule
to, this Agreement unless otherwise indicated; (f) the word "will" shall be construed to have the
same meaning and effect as the word "shall"; (g) the use of any gender shall be applicable to all
genders; and (i) the words "hereof" and "hereunder", and words of similar import, shall be construed
to refer to this Agreement as an entirety and not to any particular provision. The captions of this
Agreement are for convenience of reference only and in no way define, describe, extend, or limit the
scope or intent of this Agreement or the intent of any provision contained in this Agreement. Any
reference in this Agreement to a matter or action being subject to the "mutual agreement" or "mutual
consultation" of the Parties, or words of similar import, shall not be construed as an agreement
that the Parties shall agree to such matter or action. The language of this Agreement shall be
deemed to be the language mutually chosen by the Parties and no rule of strict construction shall be
applied against either Party on the basis that such Party drafted this Agreement or any portion
hereof.

[The remainder of this page is intentionally left blank.]
<!-- page 50 -->
IN WITNESS WHEREOF, the Parties have executed this Agreement as of the Effective Date.

JANSSEN BIOTECH, INC. By: /s/Reshema Keups-Polanco Name: Reshema Keups-Polanco Title: VP, Sales and
Marketing, Solid Tumor

IMMUNOMEDICS, INC. By: /s/Jared Freedberg Name: Jared Freedberg Title: General Counsel

Schedule 1.16

Janssen Universal Calendar
<!-- page 51 -->
Schedule 6.2

Pharmacovigilance Provisions
<!-- page 52 -->
<!-- page 53 -->
1 Definitions

1.1 "Adverse Event" (AE) means any untoward medical occurrence in a patient or a clinical-trial
subject administered a medicinal product and which does not necessarily have to have a causal
relationship with this treatment. An adverse event can therefore be any unfavourable and unintended
sign (for example, an abnormal laboratory finding), symptom, or disease temporally associated with
the use of a medicinal product, whether or not considered related to this medicinal product.

1.2 "Agreement" means the Promotion Agreement to which this Schedule is attached.

1.3 "Applicable Law" means the applicable laws, rules, regulations, including any guidelines or
other requirements of any Regulatory Authority in the relevant country of the Territory, and
industry guidelines or codes of conduct that may apply to the review and analysis of safety
information, the reporting of safety information to Regulatory Authorities and the maintenance of
records thereof.

1.4 "Company Employee" means any employee of Immunomedics, Inc. or any of its Affiliates conducting
activities under the Agreement.

1.5 "Date of First Receipt" means the date of receipt or coming into possession or control of safety
information, which contains at a minimum a suspect medicinal product and a suspect event i.e. an
incomplete case. Unless otherwise indicated in the Applicable Law the Regulatory Clock Start Date or
Day Zero for regulatory reporting, is the date the minimum criteria for reporting as defined by the
Applicable Law becomes available (i.e., an identifiable subject/ patient, identifiable reporter,
suspect product, and event).

1.6 "Incomplete Case" means a case that does not contain minimum criteria for reporting (as defined
by the Applicable Law) to a Regulatory Authority (i.e., an identifiable subject/ patient,
identifiable reporter, suspect medicinal product, and event), but at a minimum contains a suspect
medicinal product and a suspect event. Such reports are entered on the safety database maintained by
Janssen as potential cases of value for signal detection purposes.
<!-- page 54 -->
1.7 "Personal Data" means any information relating to an identified or identifiable natural person.

1.8 "Product" has the meaning set forth in Section 1.77 of the Agreement.

1.9 "Product Quality Complaint" (PQC) Any written, electronic or oral communication that alleges
deficiencies related to the identity, quality, durability, reliability, safety, effectiveness or
performance of a product after it is released for distribution.

1.10 "Regulatory Authority" means any applicable federal, national, regional, state, provincial or
local regulatory agencies, departments, bureaus, commissions, councils or other government entities
regulating or otherwise exercising authority with respect to the Product in the relevant Territory.

1.11 "Special Situation" Occurrences or reports that may not contain an adverse event, which must
still be collected and reported in order to meet regulatory safety reporting requirements and
Janssen policies:

• Overdose of Product, • Pregnancy exposure (maternal and paternal), • Exposure to the Product from
breastfeeding, • Suspected abuse/misuse of the Product, • Inadvertent or accidental exposure to the
Product (including occupational exposure), • Any failure of expected pharmacological action (i.e.
lack of effect) of the Product, • Unexpected therapeutic or clinical benefit from use of the
Product, • Medication error (includes potential, intercepted or actual) involving the Product with
or without patient/consumer exposure to the Product, (e.g. name confusion) OR that caused an
unintended effect or could cause an intended effect (e.g. adult medicine given to a young child), •
Suspected transmission of an infectious agent via Product, • Expired drug use and falsified
medicine,
<!-- page 55 -->
• Off-label use - situations where the Product is intentionally used for a medical purpose not in
accordance with the authorized product information.

Off-label use without an associated AE, Special Situation, UE or AEPQC should be collected only when
it is specifically and voluntarily brought to the attention of a Company Employee in an unsolicited
manner by a reporter e.g., Health Care Professional or data obtained from databases where off-label
use may be systematically collected (e.g., reimbursement database in US), and in accordance with
local procedure in compliance with local laws and regulations. Follow-up of off-label use is not
required.

1.12 "Territory" means the United States of America, including its territories and possessions.

1.13 "Undesirable Effect" (UE) shall mean an adverse reaction for human health attributable to the
normal or reasonably foreseeable use of a cosmetic product.

Note: All capitalized terms used but not defined in this Schedule shall have the meanings ascribed
to them (if any) in the Agreement.

2 Reporting Requirements

2.1 If any Company Employee receives or otherwise comes into possession or control of any
information about the Product, regardless of source, relating to an Adverse Event (AE), Special
Situation, AE associated with a Product Quality Complaint (AEPQC), Undesirable Effect (UE) or an
Incomplete Case, such Company Employee shall provide such information immediately, but in no case
later than twenty-four (24) hours from the Date of First Receipt by the Company Employee, to Janssen
by using the Janssen Online Complaint Form available at Janssensafety.com. For the avoidance of
doubt, all information regarding Incomplete Cases should also be provided immediately, but in no
case later than twenty-four (24) hours from the date the Company Employee receives such information.

3 Training

4.1 Company shall ensure that all Company Employees are trained in the reporting of AEs, Special
Situations, AEPQC or UEs, prior to the start of performing services under the Agreement and at least
annually thereafter if such services remain in effect, to ensure
<!-- page 56 -->
compliance with this Schedule and the Applicable Law. This includes, but is not limited to,
monitoring applicable AE, Special Situation, AEPQC and UE training, and maintaining documentation of
such training. Such training shall be conducted in the manner set forth in the Agreement using
materials to be provided by Janssen. Janssen may require Company Employees to complete additional
training provided by Janssen when there is a change in the governing contracts and/or processes or
changes in Company's personnel.

5 [Intentionally Omitted.]

5 Retention Policy

5.1 Company shall maintain and archive records of all source documentation generated by the activity
(records, questionnaires, reports), personnel training records and other relevant information
relating to its obligations under this Schedule for a period consistent with Section 7.1 of the
Agreement (including Exhibit C thereto) and Applicable Law. Company must have appropriate storage
capabilities (e.g., preventing accidental damage of physical records and appropriate back up of
electronic storage systems) if storing original AE, Special Situations, AEPQC and UE documentation.
Notwithstanding the above, before Company destroys any safety records it will notify Janssen of its
intention to do so, affording Janssen the opportunity to retain such records if it so wishes.

6 Audit

6.1 Without prejudice to Section 7.5 of the Agreement, Janssen or its designee shall have the right
to audit Company to verify Company's compliance with this Schedule and the Applicable Law, provided
that Janssen provides Company with at least [***] ([***]) calendar days prior written notice. The
Parties shall agree upon the scope of the audit with a written audit plan to be submitted by Janssen
[***] ([***]) calendar days prior to the audit. Company will allow such access to its facilities,
systems, personnel and records, in whatever form and in any location (including locations owned or
operated by a third party) as may reasonably be necessary to enable Janssen or its designee to
evaluate and ensure compliance with this Schedule and the Applicable Law. Janssen shall communicate
audit findings in a written audit report in a timely manner. The Parties undertake to cooperate with
each other to diligently investigate and resolve any such audit findings.

7 Data Privacy
<!-- page 57 -->
7.1 In the performance of the above safety activities, both Parties will comply with all Applicable
Laws in respect of data privacy in order to protect Personal Data.

7.2 Each Party shall collect, use and disclose any Personal Data obtained in the course of
performing the safety activities under this Schedule solely for the purposes of complying with the
regulatory obligations as described in this Schedule, or as otherwise required by Applicable Law or
by a court order. Both Parties will use electronic, physical and any other safeguards appropriate to
the nature of the information to prevent any use or disclosure of Personal Data other than as
provided for above. Both Parties will also take reasonable precautions to protect the Personal Data
from accidental, unauthorised, or unlawful alteration or destruction.

7.3 Each Party shall notify the other Party promptly of any accidental, unauthorised, unlawful
destruction, loss, alteration, or disclosure of, or access to the Personal Data, and take immediate
steps to rectify any such security breach.

8 Follow Up

8.1 Janssen will be responsible to diligently follow up on safety information.

9 Miscellaneous

9.1 Notwithstanding the above, in the event any Company Employee is informed of AE, Special
Situations, AEPQC or UE related to the use of any other products of Janssen or its Affiliates that
such Company Employee is aware of, such Company Employee shall report these to Janssen (in the same
manner as any such report relating to the Products) within twenty-four (24) hours of the Date of
First Receipt of such information by such Company Employee.
<!-- page 58 -->
CONTACT DETAILS

For Janssen Name: Company: Telephone: Fax: Email:

For Company Name: Company: Telephone: Fax: Email:

EXHIBIT A
<!-- page 59 -->
Brand Plan

[***]
<!-- page 60 -->
EXHIBIT B

Detailing Requirements

[***]
<!-- page 61 -->
EXHIBIT C

Records and Information Management ("RIM") Requirements

1. Maintenance. Company shall maintain and manage all paper and electronic records, files,
documents, work papers and other information in any form provided by Janssen or generated pursuant
to this Agreement (the "Files and Work Papers"): (a) in accordance with Janssen's records management
policies (which may be changed by JBI from time to time and communicated to Company), including as
set forth in "RIM Requirements" below, (b) separately from files generated, managed or maintained by
Company under agreements with other customers, (c) as required by applicable statutes and
regulations, and (d) as set out in any preservation request issued to Company by Janssen.

2. Preservation. Company shall comply promptly and fully with any request from Janssen, for any
reason, to preserve Files and Work Papers or to promptly deliver such materials to Janssen. Steps to
comply include, when requested by Janssen, periodic meetings to identify and implement documented
procedures to preserve or deliver such data. Files and Work Papers created or modified by Company in
electronic format must be delivered to Janssen in the same electronic format or as otherwise
directed by Janssen.

3. Third Party Requests. Upon receipt from Third Parties of any request, demand, notice, subpoena,
order, or other legal information- request for any Files and Work Papers, Company shall take all
reasonable steps to protect Janssen's legal rights in any response to such request and, to the
extent that Company legally may do so, shall immediately notify Janssen, shall provide Janssen with
a copy of such request, and shall meet and cooperate with Janssen in the implementation of
procedures to comply with the request.

4. RIM Requirements. This section specifies RIM requirements applicable to Files and Work Papers
that Company personnel create, maintain, manage or manipulate on behalf of Janssen. Company is
responsible for understanding and complying with Janssen's RIM requirements.

a. Records and Information Management requirements shall be applied consistently and regularly.

b. Company's Files and Work Papers:

i) shall be created, stored and managed throughout their lifecycle using proper protection;

ii) shall be protected and access controlled according to their value as described in the Johnson &
Johnson Supplier Information Security Requirements;

iii) shall be retained in accordance with the Johnson & Johnson
<!-- page 62 -->
Enterprise Retention Schedule, which defines retention requirements for business, legal, regulatory
and privacy purposes; and

iv) relevant to litigation or an investigation and subject to a legal hold shall be retained and
preserved, regardless of the retention requirement set forth in the Johnson & Johnson Enterprise
Retention Schedule.

c. Company shall ensure that the Files and Work Papers are retained upon the departure of personnel
employed by Company.

d. Janssen or the applicable Janssen Affiliate shall provide written approval prior to the
disposition (disposal or deletion) of any Files and Work Papers.

e. Company personnel with access to Janssen's network shall annually complete Records and
Information Management training as specified by Janssen.

EXHIBIT D

Health Care Compliance Provisions
<!-- page 63 -->
1. "HCP" is defined as (i) any person who is licensed by a state to provide health care services
directly or indirectly to patients, such as a physician, a nurse, a technician, a psychologist, or a
lab specialist and/or (ii) any person or organization to whom a Party markets its products and
services that is in a position to influence the selection of the products furnished or purchased,
including but not limited to hospitals and health systems, administrators, procurement personnel,
group purchasing organizations, pharmacy benefit managers, and business people.

2. Company shall, with respect to each HCP engaged under this Agreement:

a. Ensure that the HCP's services are provided in compliance with all applicable laws and
regulations, including but not limited to laws and regulations pertaining to the promotion of
products regulated by the United States Food and Drug Administration (FDA); laws, regulations and
guidance pertaining to federal and state anti-kickback and submission of false claims to
governmental or private health care payors (collectively, "Health Care Compliance" or "HCC"); state
and federal laws and regulations relating to the protection of individual and patient privacy; and
any other laws and regulations applicable to such services.

b. Ensure that HCP's services are provided in compliance with Janssen's written policies and
procedures of which Company is provided notice, including, but not limited to, policies and
procedures related to FDA and Health Care Compliance and the protection of individual and patient
privacy (collectively, "Janssen Policies"). The requirements of this Agreement and any additional
policies attached to this Agreement shall constitute Janssen Policies of which Janssen provides
notice to Company.

c. Comply with professional and/or employment rules (such as conflicts of interest or ethics
policies) established by Company or a professional organization or institution with which HCP is
affiliated when the provision of services by an HCP is subject to such rules, including, as
applicable, obtaining any required approval(s) prior to providing services and making any required
reports.

3. Company shall provide notice to each HCP of the following:

The Physician Payments Transparency Requirements of the Patient Protection and Affordable Care Act
of 2010 (codified at 42 U.S.C. 1320a-7h) and implementing regulations, require certain
pharmaceutical, medical device, and other companies to annually report to the Centers for Medicare
and Medicaid Services (CMS) certain information about payments and transfers of value provided
directly or indirectly to U.S. physicians and teaching hospitals, which CMS will make publicly
available. This includes any payments or transfers of value that Janssen provides indirectly through
Company to U.S. physicians and teaching hospitals. As required by law, Janssen will report to CMS
information about payments and transfers of value that Company
<!-- page 64 -->
provides to U.S. physicians and teaching hospitals pursuant to this Agreement. This includes any
portion of any payment or transfer of value that Janssen furnishes to Company which Company then
provides directly or indirectly to U.S. physicians or teaching hospitals, including its employees,
agents, or contractors. Information that Janssen must report includes the identity and business
address of each relevant U.S. physician or teaching hospital, the value and purpose of any payments
or transfers of value that are furnished, and any other information as may be required by law. To
enable Janssen to comply with its legal obligations, Company shall track, maintain, and provide
Janssen information and data related to any payments or transfers of value that Company provides to
U.S. physicians and teaching hospitals under this Agreement. Company shall provide such information
and data in the form and manner that Janssen requests in a timely manner. Janssen may also report
information about compensation, payments or transfers of value that Company provides to U.S.
physicians and teaching hospitals as otherwise required by law and Janssen reserves the right to
post on a website accessible to the public such information, whether or not required by law.

4. In accordance with Janssen's request, Company shall, within thirty (30) days thereafter, provide
or upload to Janssen's health care compliance data system (the "Totality Third Party Company
Portal") or any similar system, all compliance documents and data templates related to services.
Data requirements regarding Totality Third Party Company Portal can be found at
https://totalitygateway.jnj.com. Compliance documents and data templates include the following:

a. Copies of written agreements including compensation terms, with each HCP providing services.

b. Documentation indicating that each HCP providing services is not excluded or debarred and, for
any health care practitioner, duly licensed under state law, as set forth above. Company shall
obtain such documentation prior to engaging such HCP to provide services.

c. Documentation of services provided by such HCP (e.g., a written report, comments collected at a
meeting, presentation materials, etc.).

d. HCP data templates capturing details on HCP value exchange. Value exchanges shall include,
without limitation, any gifts, meals, compensation, travel reimbursement and patient-related
materials provided to HCPs in connection with this Agreement.

e. Documentation that shows that Company provided notice to each HCP that information provided
pursuant to this Agreement may be made publicly available at any time at the sole discretion of
Janssen.

f. Electronic report of overall expenses paid to or on behalf of each HCP and electronic copies of
all original receipts documenting such expenses; and
<!-- page 65 -->
g. Written evidence of any required ethics or other authorizations allowing HCPs employed by
federal, state or local government agencies, including but not limited to pharmacy and therapeutics
committees, to provide services under this Agreement.

5. In the event that Janssen is charged any fee or penalty because Company failed to comply with the
requirements set forth in this Exhibit, Company agrees to reimburse Janssen for such fees or
penalties. Janssen reserves the right to reduce or not pay any invoice in the event that Company
fails to comply with the requirements set forth in this Exhibit.

6. Company shall produce and send to Janssen electronic reports each month in which payments were
made or gifts or meals were provided to HCPs by Company on behalf of Janssen, listing the following:

a. value of any gifts, meals, compensation paid, and/or entertainment provided to HCPs, whether
their services were obtained through a written agreement or not;

b. nature, purpose and date of payments or other items of value provided; and

c. names, addresses, and federal Tax I.D. number of HCPs who were paid remuneration for services
relating to Janssen.

7. Company shall report any violations of the compliance obligations set forth in this Agreement to
Janssen at the name and address listed in Section 14.5 (Notices) or through the Vendor & Distributor
Hotline at 1-800-556-2496.

8. Company, at its expense, shall ensure that all personnel and subcontractors involved in providing
services attend and participate in training and educational programs reasonably scheduled by
Janssen. Company, at its expense, agrees to train and periodically provide refresher training to all
its new and current personnel and subcontracted personnel providing services regarding the
compliance obligations set forth in this Agreement, including any Janssen Policies applicable to
services. Company shall, upon request, provide Janssen with a record of the training provided and
the dates training was attended by any Company personnel and subcontractors.
<!-- page 66 -->
EXHIBIT E

Insurance Requirements

[***]
