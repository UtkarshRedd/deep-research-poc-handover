# Eval results

Runner: `python -m dr.eval.run --variant <v> --golden <questions.jsonl> --docs <dir> [--limit N --types ... --no-judge]`.
Rows land in `eval/results/<variant>-<ts>.jsonl`, the per-slice table in `<variant>-<ts>.summary.md`,
run folders (report, verification, trace, evidence) under `eval/results/runs/`. Metrics are defined in
`src/dr/eval/metrics.py`; the judge prompt is `prompts/judge.md`.

Models (NVIDIA Build free tier): planner/router/researcher/writer/judge = Nemotron 3.5 Super, extractor/verifier =
Nemotron 3.5 Lightning. Thinking was ON for planner/router/researcher only in the first table below; the thinking A/B
and every later run had thinking OFF for every role (`.env`). Tokens stand in for cost. Caveats found in review
(2026-11-02, HANDOVER.md §5.3): candidate recall is saturated on CUAD (candidate sets of 277-427 of 510 docs);
`item_recall` counts gold items that appear in the question text, so CUAD coverage item recall is inflated; the
judge reads only the first 12,000 characters of a report.

## 2026-11-01 — CUAD slice, one question per type (6 questions, 510 real contracts)

| variant | judge pass | cand recall | opened/cited | gold page | support | gate fail | abstain ok | wall s p50 | calls p50 | tokens p50 |
|---|---|---|---|---|---|---|---|---|---|---|
| A1_deep_list | 3/6 | 1.00 | 0.96 | 0.88 | 0.94 | 1/6 | 5/6 | 64.8 | 10 | 96k |
| A2_fs_agent | 3/6 | — | 0.80 | 0.72 | 0.93 | 1/6 | 5/6 | 32.6 | 11.5 | 111k |

Per question (judge verdict, A1 / A2):

| qid | type | A1 | A2 | what happened |
|---|---|---|---|---|
| cq001 | single (governing law) | correct, 50 s | model_error, 11 s | A2's first model call hit a transient connection error and the loop gave up (fixed: a failed call now costs a turn, not the run) |
| cq037 | temporal (expiry) | correct, 59 s | correct, 45 s | both quote the term clause and cite the page |
| cq061 | identifier (which agreement) | correct, 55 s | correct, 20 s | both correct; one over-reaching claim dropped by tier 1 in each (gate fail, answer unaffected) |
| cq077 | coverage (8 agreements, non-compete) | incorrect, 177 s | incorrect, 81 s | both exhausted the 25-call budget on grep/read and listed 2 of 5; the router chose `single`. This is the Phase 5 fan-out case |
| cq089 | multihop (governing law) | incorrect, 71 s | incorrect, 16 s | both found Pennsylvania but cited a sibling agreement with overlapping parties (localization between near-identical documents) |
| cq097 | not_in_corpus (non-compete absent) | incorrect, 204 s | correct, 54 s | A1 presented a noncircumvention clause as the answer after a 110 s thinking spike and a forced submit; A2 said the clause is absent but set `not_in_corpus=false` (flag discipline) |

### Thinking A/B on the same six questions (A1_deep_list)

| setting | judge pass | opened/cited | gold page | support | gate fail | wall s p50 | calls p50 | tokens p50 | tok/correct |
|---|---|---|---|---|---|---|---|---|---|
| thinking on (planner, researcher) | 3/6 | 0.96 | 0.88 | 0.94 | 1/6 | 64.8 | 10 | 96k | 297k |
| planner off (+ abstention prompt) | 3/6 | 0.96 | 0.88 | 0.96 | 1/6 | 50.2 | 11.5 | 98k | 288k |
| researcher off | 5/6 | 0.96 | 0.80 | 1.00 | 0/6 | 49.7 | 16.5 | 243k | 294k |
| **both off (adopted)** | **5/6** | **1.00** | **0.96** | **1.00** | **0/6** | 52.9 | 13 | 164k | **212k** |

The abstention and "confirm the document" prompt rules were added between the first and second
rows and apply to all later rows. Files: `cuad6-A1-planner-nothink.*`, `cuad6-A1-researcher-nothink.*`,
`cuad6-A1-both-nothink.*`.

### Breadth question cq077 (8 named agreements, "which contain a non-compete clause; quote it") — Approach 3

Single-agent variants exhausted 25 calls and listed 1–2 of the 5 gold agreements. Fan-out iterations:

| attempt | change | judge | claims (support) | failed units | wall s | tokens |
|---|---|---|---|---|---|---|
| A1/A2 (reference) | single agent | incorrect, 1–2 of 5 | 10 (1.0) | — | 81–177 | 224–334k |
| A3 v1 | router gives 8 sub-questions, 8 units over 418 candidates | incorrect: writer compressed 8 findings into 2 sections, wrote gaps for evidence it had | 10 (1.0) | 0 | 68 | 778k |
| A3 v2 | outline = one section per finding; quote-when-asked rule | incorrect: 2/3 rubric; Touchstar unit never submitted | 37 (1.0) | 1 | 82 | 887k |
| A3 v3 | units scoped to the agreement they name (1 doc each) | incorrect: Touchstar unit still out of calls on one long doc; Sponsorship judged "no" | 31 (1.0) | 1 | 177 | 655k |
| A3 v4 | TOC in the unit briefing; forced submit without evidence = low-confidence finding; timeout cap | incorrect: Reseller "not established", Sponsorship excluded, one dropped claim | 33 (0.95) | 0 | 111 | 436k |
| A3_grid_only v1 | grid over 320 candidates | no findings: extractor timeouts, deadline skips | — | — | 197 | 119k |
| A3_grid_only v4 | grid over the 40 named docs, extractor thinking off | incorrect: 1 verified quote | 10 (1.0) | — | 28 | 104k |

What the iterations fixed is structural: routing to breadth, one section per unit, unit scoping, hand-off
contract. What remains is model-level: inside one long contract a clause worded "shall not sell competing
products" is not found by a 12-call unit that greps for "non-compete", and the extractor sees only the
chunks BM25 picks for the question's words. Next lever is vocabulary expansion inside units and the grid
(the grid now borrows the first move's expanded terms; untested live), then the larger CUAD coverage slice.

Reading: retrieval is not the limiter on this slice (A1 candidate recall 1.0; the gold page was cited
in 88 % of cases). The misses are breadth (needs fan-out), near-duplicate localization (needs the
provenance gate and a sharper "which agreement" check) and abstention discipline (prompt). Timing:
the planner spent 66–68 s thinking on the two long questions and one researcher call thought for
110 s; both are candidates for the no-thinking switch (A/B pending).

Caveat: n = 1 per slice; this is a smoke test of the harness, not a result.

## 2026-11-01 — Phase 7 (tier 2 + provenance) and the CUAD smoke set

Seeded tier-2 check (`dr.verify.tier2.seeded_check`: 10 true claims + 10 planted errors on the synthetic
corpus, verifier = nemotron-3.5-lightning without thinking, groups of 8):

| attempt | perturbation | planted flagged | false flags | skipped | wall |
|---|---|---|---|---|---|
| 1 | first number in the quote (hit "Section 7.1" labels) | 1/10 | - | - | - |
| 2 | substantive value: ratio, %, $ amount, date, day count | **10/10** | 0 | 2 | 156 s (4 calls, rate budget shared with an eval) |

Provenance gate calibration (synthetic corpus, MinHash 64 perms over word 5-grams): conformed copies >= 0.97,
template-built agreements for different borrowers 0.92-0.94, amendments < 0.2. Thresholds: 0.95 for any pair,
0.8 when both documents list the same parties. The 3-document sample corpus is too small to calibrate (0.5).

Smoke set: `data/golden/cuad_smoke.jsonl`, 12 CUAD questions, 2 per type (cq001 cq002 single; cq037 cq038
temporal; cq061 cq062 identifier; cq077 cq078 breadth; cq089 cq090 multi-hop; cq097 cq098 abstention).

```
python -m dr.eval.run --variant A1_deep_list --golden data/golden/cuad_smoke.jsonl --docs data/cuad_docs --concurrency 2
```

First smoke attempt (A1, 23:47, results `A1_deep_list-20261101-234746.jsonl`): stopped after 4 questions.
The super endpoint rejected about half of all calls with HTTP 429 regardless of our pace (confirmed with
isolated probe calls, see docs/endpoints.md); the 20 s / 40 s backoffs then pushed every question to the
240 s deadline: cq001 correct in 110 s, cq002 model_error, cq037 deadline, cq038 incorrect at 243 s.
Not a measurement of the system; rerun after switching to short retries.

Second attempt (A1, concurrency 1, short retries, results `A1_deep_list-20261102-000700.jsonl`): stopped
after 7 of 12 questions on the user's call. Rejection chains had deepened to 4-5 consecutive 429s per call
(about 70 % of requests refused), 11-26 retries and 100-190 s of waiting per question even with one request
in flight. Retrieval was clean on every question (candidate recall 1.0; gold page cited wherever the write
stage completed); the losses are rejected model calls.

| qid | type | wall | outcome | judge | note |
|---|---|---|---|---|---|
| cq001 | single | 58 s | submitted | correct | Delaware, p.9 cited |
| cq002 | single | 91 s | submitted | correct | Virginia, p.6 cited |
| cq037 | temporal | 207 s | model_error | correct | right date; research ended on a 429 after all retries |
| cq038 | temporal | 226 s | submitted | incorrect | 192 s waiting; report said the date could not be determined |
| cq061 | identifier | 112 s | submitted | unknown | report written; the judge call itself was rejected |
| cq062 | identifier | 153 s | model_error | incorrect | no successful call after turn 1; zero evidence |
| cq077 | coverage | 103 s | forced_submit | incorrect | zero evidence |

Rerun the smoke set when the free endpoint is quieter, or on a paid/self-hosted endpoint for the 120B
model; keep `--concurrency 1` on the free tier.
