# Which jurisdiction's law governs the Cooperation Agreement between e.l.f. Beauty, Inc. ...

*Question:* Which jurisdiction's law governs the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01)?

## Identify agreement and governing law clause

[GAP] The writer produced nothing for: Establish the identity, date, parties of the Cooperation Agreement and its explicit choice-of-law provision

## Verification appendix

Claims: 1 · supported: 0 · partially: 0 · dropped: 0 · gaps: 1

Notes: OpenAIRateLimitError: Error code: 429

| claim | section | tier 1 | score | tier 2 | clusters | sources | note |
|---|---|---|---|---|---|---|---|
| s1.1 | s1 | gap |  | skipped |  |  |  |

### Evidence

