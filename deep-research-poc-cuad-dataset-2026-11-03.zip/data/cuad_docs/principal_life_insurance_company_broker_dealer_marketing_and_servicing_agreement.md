<!-- page 1 -->
# Broker Dealer Marketing and Servicing Agreement for Variable Annuity Contracts
| Field | Value |
|---|---|
| Document Type | Marketing Agreement |
| Parties | Principal Life Insurance Company ("Issuer", individually referred to as a “Party” and collectively with Distributor and Broker Dealer as the “Parties”); Princor Financial Services Corporation ("Distributor", individually referred to as a “Party” and collectively with Issuer and Broker Dealer as the “Parties”); ABC Company and its duly licensed insurance affiliates indicated on the signature page of this Agreement (collectively “Broker Dealer”, individually referred to as a “Party” and collectively with Issuer and Distributor as the “Parties”) |
| Source | CUAD v1 / Principal Life Insurance Company - Broker Dealer Marketing and Servicing Agreement |

BROKER DEALER MARKETING AND SERVICING AGREEMENT FOR VARIABLE ANNUITY CONTRACTS This Broker Dealer
Marketing and Servicing Agreement for Variable Annuity Contracts (the "Agreement") is effective this
______ day of ________________, 2013, by and among Principal Life Insurance Company ("Issuer") and
Princor Financial Services Corporation ("Distributor"), on the one hand, and _______________________
and its duly licensed insurance affiliates indicated on the signature page of this Agreement, if
any, (collectively "Broker Dealer"), on the other hand. Distributor, Issuer and Broker Dealer are
individually referred to as a "Party" and collectively as the "Parties" RECITALS A. Issuer offers
certain individual variable annuity contracts listed in the exhibit(s) attached to this Agreement

B. Distributor is a broker dealer registered with the Securities and Exchange Commission (the "SEC")
under

C. Broker Dealer is engaged in the sale of securities and other investment products, including
variable annuity

D. The Parties enter into this Agreement for the purpose of authorizing Broker Dealer to solicit
sales of and

NOW THEREFORE, in consideration of the mutual promises and covenants contained in this Agreement,
the receipt and sufficiency of which the Parties acknowledge, the Parties agree as follows:
REPRESENTATIONS 1. Issuer represents that the Annuity Contracts shall comply with the registration
and other applicable requirements of the Securities Act of 1933 (the "1933 Act") and the Investment
Company Act of 1940 (the "40 Act") and the rules and regulations thereunder, including the terms of
any order of the SEC with respect thereto. Issuer further represents that the Annuity Contract
prospectuses included in Issuer's registration statement, post-effective amendments, and any
supplements thereto, as filed or to be filed with the SEC, as of their respective effective dates,
contain or will contain all statements and information required to be stated therein by the 1933 Act
and in all respects conform or will conform to the requirements thereof, and no prospectus, nor any
supplement thereof, includes or will include any untrue statement of a material fact, or omits or
will omit to state any material fact required to be stated therein or necessary to make the
statements therein not misleading; provided, however, that the foregoing representations shall not
apply to information contained in or omitted from any prospectus or supplement in reliance upon and
in conformity with written information furnished to Issuer by Broker Dealer specifically for use in
preparation thereof. The foregoing representations also shall not apply to information contained in
or omitted from any prospectus or supplement of any underlying mutual fund.

("Annuity Contracts"). The exhibit(s) attached to this Agreement are incorporated herein by
reference and made a part hereof ("Exhibits").

the Securities and Exchange Act of 1934, as amended, (the "1934 Act") and a member in good standing
of the Financial Industry Regulatory Authority, Inc. ("FINRA"). Distributor is the principal
underwriter of the Annuity Contracts.

contracts. Broker Dealer either is licensed in certain states as an insurance agent or agency or has
entered into an insurance networking agreement with the undersigned duly licensed insurance
affiliates to act on its behalf in the capacity of a licensed insurance agent or agency.

service Annuity Contracts, subjects to the terms and conditions set forth in this Agreement and the
Exhibits.
<!-- page 2 -->
2 . Broker Dealer represents and warrants that it is a broker dealer registered with the SEC under
the 1934 Act, a member in good standing of FINRA, and is registered as a broker dealer under state
law to the extent required in order for it or those persons who are registered with it and licensed
as insurance producers ("Registered Representatives") to provide the services described in this
Agreement. Broker Dealer agrees to abide by all rules and regulations of FINRA, including its
Conduct Rules, and to comply with all applicable state and federal laws and the rules and
regulations of authorized regulatory agencies affecting the sale and servicing of Annuity Contracts.
MARKETING/SERVICING 3 . Issuer and Distributor appoint Registered Representatives to solicit and
procure applications for the sale of and service of Annuity Contracts. This appointment is not
exclusive and only extends to those jurisdictions in which the Annuity Contracts have been approved
for sale and in which Broker Dealer and Registered Representatives are properly registered, licensed
and appointed. 4 . Broker Dealer will itself be, or will select persons associated with it who are,
trained and qualified to solicit applications for purchase and service of Annuity Contracts in
conformance with applicable state and federal laws. Any such persons shall be registered
representatives of Broker Dealer in accordance with the rules of FINRA and any applicable state
laws, be licensed to offer the Annuity Contracts in accordance with the insurance laws of any
jurisdiction in which such person solicits applications and be licensed with and appointed by Issuer
to solicit applications for and service Annuity Contracts. 5 . Broker Dealer will use commercially
reasonable efforts to train and instruct its Registered Representatives not to make recommendations
to an applicant to purchase an Annuity Contract in the absence of reasonable grounds to believe that
the purchase is suitable for such applicant, in accordance with the suitability and disclosure
requirements of the 1934 Act, FINRA Conduct Rule 2310, and any state insurance law or regulation
governing the offer and sale of Annuity Contracts, including any state law or regulation governing
sales to the public in general (e.g. consumer protection laws or regulations, unfair trade
practices, annuity disclosure regulations, etc.) or to senior citizens, as the same may be amended
or interpreted from time to time. Broker Dealer will use commercially reasonable efforts to
determine that each transaction is completed with a Registered Representative's report indicating
suitability, including any required and necessary customer information, and is subjected to a review
process in compliance with FINRA Conduct Rule 3010, as the same may be amended or interpreted from
time to time. Each application shall be approved by one of Broker Dealer's registered principals, in
accordance with all applicable FINRA rules. 6 . The activities of all Registered Representatives,
employees and agents ("producers") will be under the direct supervision and control of Broker
Dealer. The right of Registered Representatives to solicit applications for the purchase and service
of Annuity Contracts is subject to their continued compliance with the rules and procedures that may
be established by Broker Dealer, or Issuer, including, but not limited to, those set forth in this
Agreement. 7 . Broker Dealer shall ensure that applications for the purchase of Annuity Contracts
are solicited only in the states where Annuity Contracts are qualified for sale, and only in
accordance with the terms and conditions of the then current prospectus applicable to Annuity
Contracts and will make no representations not included in the prospectus, Statement of Additional
Information, or in any authorized supplemental material supplied by Distributor. With regard to
Annuity Contracts, Broker Dealer shall not use or permit its producers to use any sales promotion
materials or any form of advertising other than that supplied or approved by Distributor. Issuer and
Distributor shall provide only approved supplemental material, advertising and sales materials,
including illustrations, for Broker Dealer's use.
<!-- page 3 -->
8 . Broker Dealer will promptly forward to the appropriate office of Distributor, or its authorized
designee, all Annuity Contract applications along with other documents, if any, and any payments
received with such applications and will have no rights of set off for any reason. Any Annuity
Contract application that is rejected, together with any payment made and other documents submitted,
shall be returned to Broker Dealer or the source of the payments. 9 . Broker Dealer shall ensure
that the prospectus delivery requirements under the 1933 Act and all other applicable securities and
insurance laws, rules and regulations are met and that delivery of any prospectus for Annuity
Contracts will be accompanied by delivery of the prospectus for the underlying mutual funds, and,
where required by state law, the Statement of Additional Information for the underlying mutual
funds. Issuer or Distributor shall inform Broker Dealer of those states that require delivery of a
Statement of Additional Information with the prospectus on initial sale. Broker Dealer is
responsible for prospectus delivery requirements only on initial sale. Issuer and Distributor will
be responsible for prospectus delivery annually after the original sale. 10 . Broker Dealer agrees
to maintain all books and records relating to the servicing and sale of Annuity Contracts or
interests therein required under the 1934 Act, and any applicable rules promulgated thereunder, and
applicable securities or insurance laws of any states. 11 . Broker Dealer understands and agrees
that in performing the services covered by this Agreement, it is acting in the capacity of an
independent contractor and not as an agent or employee of Distributor or Issuer and is not
authorized to act for, or make any representation on behalf of, Distributor or Issuer except as
specified herein. Broker Dealer understands and agrees that Issuer shall execute telephone
transactions only in accordance with the terms and conditions of the then current prospectus
applicable to Annuity Contracts and agrees that in consideration for Broker Dealer's right to
exercise the telephone transaction services neither Distributor nor Issuer will be liable for any
loss, injury or damage incurred as a result of acting upon, nor will they be held responsible for
the authenticity of any telephone instructions containing unauthorized, incorrect or incomplete
information. Broker Dealer agrees to indemnify and hold harmless Distributor and Issuer against any
loss, injury or damage resulting from any telephone transactions instruction containing
unauthorized, incorrect or incomplete information received from Broker Dealer or any of its
Registered Representatives. (Telephone instructions are recorded on tape.) 12 . Broker Dealer has no
authority to: incur any liability or debt on behalf of Issuer or Distributor; accept risks or
contracts of any kind; make, alter, authorize or discharge any contract; fail to transmit promptly
any contributions collected to Issuer or Distributor; or bind Issuer or Distributor in any way. 13 .
Broker Dealer agrees to notify Distributor promptly of any change, termination, or suspension of its
status as a broker dealer or FINRA member. Broker Dealer shall immediately notify Distributor with
respect to i) the initiation and disposition of any form of disciplinary action by the FINRA or any
other agency or instrumentality having jurisdiction with respect to the subject matter hereof
against Broker Dealer or any Registered Representative; ii) the issuance of any form of deficiency
notice made part of the public record by FINRA or any such agency regarding Broker Dealer's
training, supervision or sales practices; and/or iii) the effectuation of any consensual order with
respect thereto. 14. Broker Dealer agrees to notify Distributor and Issuer immediately of any
customer complaints or legal or regulatory inquiries (including, but not limited to, subpoenas)
regarding any Annuity Contracts offered or sold pursuant to the Agreement. Broker Dealer shall
provide full, prompt cooperation and assistance to Distributor and Issuer in responding to and
resolving any such complaints or inquiries. 15. Anti-Money Laundering and Know Your Customer
Compliance: The Parties acknowledge that they are financial institutions subject to the USA Patriot
Act of 2001 and the Bank Secrecy Act (collectively, the "AML Acts"), which require, among other
things, that financial institutions adopt compliance programs
<!-- page 4 -->
to guard against money laundering. Each Party represents and warrants that it is in compliance and
will continue to comply with the AML Acts and the applicable rules and regulations of the SEC,
FINRA, and any other self-regulatory organizations, as they now exist and as they may be amended in
the future. Broker Dealer represents and warrants that it has adopted a customer identification
program and will verify the identity of customers who purchase Annuity Contracts. Periodically,
Issuer or Distributor may ask Broker Dealer to, and Broker Dealer agrees to, certify that it is
compliance with the requirements, representations and warranties in this paragraph. The Parties
further acknowledge that they have a current 314(b) notice on file with FinCEN in accordance with
section 314(b) of the USA Patriot Act and agree to refile such notice annually (or as otherwise
required to remain current in accordance with applicable rules and regulations) during the term of
this Agreement. COMPENSATION 16. Unless otherwise provided, Issuer, on behalf of Distributor, shall
pay compensation to Broker Dealer as set out in this Agreement and the Exhibits. Compensation shall
only be paid to Broker Dealer of record on premiums paid to and retained by Issuer while this
Agreement is in force. Broker Dealer agrees to pay a commission to Registered Representatives in
connection with the sales or servicing of Annuity Contracts under this Agreement. 17. In those
states where Broker Dealer has not obtained an insurance license, Broker Dealer represents and
warrants that: it has entered into an insurance networking agreement with the undersigned duly
licensed insurance affiliate(s) to act on its behalf in the capacity of a licensed insurance agent
or agency ("Affiliated Agency"). Broker Dealer authorizes Issuer to pay any compensation owed to
Broker Dealer from the sales or servicing of Annuity Contracts to such Affiliated Agency. Broker
Dealer remains fully responsible for recordkeeping and supervision of the solicitation, sale and/or
servicing of Annuity Contracts. All compensation received by Affiliated Agency in accordance with
this section will be distributed by Affiliated Agency only to duly licensed and registered
representatives who have been appointed by Issuer to solicit applications for Annuity Contracts. 18.
Issuer and Distributor may change the compensation schedules set forth in the attached Exhibits at
any time and will notify Broker Dealer of the revised compensation schedules electronically or by
other writing in advance of the effective date of the change. Any change to the compensation
schedules will affect only commissions payable on Annuity Contracts with an effective date on or
after the effective date of the change, unless otherwise provided or required by law. Issuer or
Distributor may discontinue the issuance of any form of Annuity Contract and fix the amount of
compensation on Annuity Contracts issued in exchange for previously issued Annuity Contracts. 19.
Broker Dealer agrees to return promptly to Issuer all compensation received for any Annuity Contract
returned within the "free look" period as specified in the Annuity Contract. Issuer expressly
reserves the right to change the broker dealer of record or Registered Representative in the event
an Annuity Contract owner so requests. 20. Any indebtedness or obligation of Broker Dealer to
Distributor or Issuer, whether arising hereunder or otherwise, shall be set off against any
compensation payable under this Agreement or any other agreement between or among the Parties or
their affiliates. Indebtedness or obligations include but are not limited to any debt, liability, or
debit balance resulting from Issuer's reversal of compensation under this Agreement or any other
agreement between or among the Parties or their affiliates. It also includes any amount paid by
Issuer or Distributor, including reasonable attorney fees and costs, to settle a complaint or
satisfy any judgment entered by any court, administrative agency or arbitrator related to any
Annuity Contract sold by Broker Dealer, or its producers or breach of Broker Dealer's duties and
responsibilities contained in this or any prior Agreement, whether or not the liability for
settlement or satisfaction of judgment arose after the termination of this Agreement. Issuer or
Distributor reserves the right to use any remedies under the law to collect any indebtedness Broker
Dealer owes Issuer or
<!-- page 5 -->
Distributor and Broker Dealer agrees to pay any reasonable attorney's fees and actual costs of
collection incurred as a result of such action. CONFIDENTIALITY 21. a. Confidentiality. Each Party
acknowledges that, in the course of performing its duties under this Agreement or otherwise, it may
receive or learn information about individuals who have applied for or purchased financial products
or financial services from the other Party, including, but not limited to, personal, financial
and/or health information ("Confidential Information"). Each Party agrees that it will not use or
disclose to any affiliate or third party, orally or in writing, any Confidential Information of the
other Party for any purpose other than the purpose for which the Confidential Information was
provided to that Party. Without limiting any of the foregoing, each Party agrees to take all
precautions that are reasonably necessary to protect the security of the other Party's Confidential
Information. Each Party agrees to restrict access to the other Party's Confidential Information to
those employees who need to know that information to perform their duties under this Agreement. Each
Party further agrees that, upon request of the other Party, it will return to the Party making such
request all tangible items containing any Confidential Information of the other Party, including all
copies, abstractions and compilations thereof, without retaining any copies of the items required to
be returned. The obligations of this paragraph extend to the employees, agents, affiliates and
contractors of each Party and each Party shall inform such persons of their obligations hereunder.
21. b. Notification obligation. Each Party shall, upon learning of any unauthorized disclosure or
use of any of the other Party's Confidential Information, notify the other Party promptly and
cooperate fully with such Party to protect such Confidential Information. 21. c. Disclosure required
by law. If Broker Dealer believes it is required by law or by a subpoena or court order to disclose
any Confidential Information, Broker Dealer, prior to any disclosure, shall promptly notify Issuer
in writing attaching a copy of the subpoena, court order or other demand and shall make all
reasonable efforts to allow Issuer an opportunity to seek a protective order or other judicial
relief. 21. d. Non-restricted information. Except as stated in the final sentence of this paragraph,
nothing in this Agreement shall be construed to restrict disclosure or use of information that: (a)
was in the possession of or rightfully known by the recipient, without an obligation to maintain its
confidentiality, prior to receipt from the other Party; (b) is or becomes generally known to the
public without violation of this Agreement; (c) is obtained by the recipient in good faith from a
third party having the right to disclose it without an obligation of confidentiality; (d) is
independently developed by the receiving Party without the participation of individuals who have had
access to the other Party's confidential or proprietary information. The Parties acknowledge that
certain laws governing Confidential Information about individuals are more restrictive than the
foregoing statements and they agree to comply in all respects with such laws. 21. e. Compliance with
law. Each Party agrees, in connection with its performance under this Agreement, to comply with all
applicable laws, including but not limited to laws protecting the privacy of non- public personal
information about individuals. 21. f. Survival. The provisions of this Agreement relating to
confidentiality shall survive termination or expiration of this Agreement. INDEMNIFICATION 22. In
connection with the offer, sale or servicing of Annuity Contracts, Broker Dealer agrees to indemnify
<!-- page 6 -->
and hold harmless Distributor and Issuer from any damage or expense, including reasonable attorneys'
fees, as a result of (a) the negligence, misconduct or wrongful act of Broker Dealer or producers;
(b) any violation of any securities or insurance laws, regulations or orders or (c) any actual
obligation of the Affiliated Agency under terms of the agreement between Broker Dealer and the
Affiliated Agency, including claims by one or more of Registered Representatives for compensation
due or to become due on account of such Registered Representatives' sale or servicing of Annuity
Contracts and any claims or controversy between Broker Dealer and Affiliated Agency as to rights to
compensation. Notwithstanding the foregoing, Broker Dealer shall not indemnify and hold harmless
Distributor and Issuer from any damage or expense on account of the negligence, misconduct or
wrongful act of Broker Dealer or producer if such negligence, misconduct or wrongful act arises out
of or is based upon any untrue statement or alleged untrue statement of material fact, or the
omission or alleged omission of a material fact in: (i) any registration statement, including any
prospectus or any post-effective amendment thereto; or (ii) any material prepared and/or supplied by
Distributor or Issuer for use in conjunction with the offer or sale of Annuity Contracts, or (iii)
any state registration or other document filed in any state or jurisdiction in order to qualify any
Annuity Contracts under the securities laws of such state or jurisdiction. The terms of this
provision shall not be impaired by termination of this Agreement 23. In connection with the
solicitation of applications for the purchase of Annuity Contracts, Distributor and Issuer agree to
indemnify and hold harmless Broker Dealer from any damage or expense, including reasonable
attorneys' fees, as a result of the negligence, misconduct or wrongful act of Distributor or Issuer
or any employee, representative or agent of Distributor or Issuer, including but not limited to, any
damage or expense which arises out of or is based upon any untrue statement or alleged untrue
statement of material fact, or the omission or alleged omission of a material fact in: (i) any
registration statement, including any prospectus or any post-effective amendment thereto; or (ii)
any material prepared and/or supplied by Distributor or Issuer for use in conjunction with the offer
or sale of Annuity Contracts; or (iii) any state registration or other document filed in any state
or other jurisdiction in order to qualify any Annuity Contract under the securities laws of such
state or jurisdiction and/or any actual or alleged violation of any securities or insurance laws,
regulations or orders. The terms of this provision shall not be impaired by termination of this
Agreement. GENERAL PROVISIONS 24. Issuer or Distributor may modify this Agreement at any time by
written notice to Broke Dealer. Any notice shall be deemed to have been given on the date upon which
it was either delivered personally or by fax or e-mail transmission to the other Party, or mailed
post prepaid to his or its address as shown herein. 25. Any Party hereto may terminate this
Agreement at any time upon prior written notice. This Agreement shall automatically terminate if
Broker Dealer voluntarily or involuntarily ceases to be or is suspended from being, a member in good
standing of FINRA. In addition, Distributor and Issuer reserve the right to terminate this Agreement
in the event that any producer of Broker Dealer is suspended, disciplined or found to be in
violation of governing insurance or securities laws, rules or regulations. Failure of any Party to
terminate this Agreement for any of the causes set forth in this Agreement shall not constitute a
waiver of the right to terminate this Agreement at a later time for any such causes. 26. This
Agreement may not be assigned by Broker Dealer without the prior written consent of Issuer and
Distributor, which shall not be unreasonably withheld. 27. This Agreement shall be governed by and
construed in accordance with the laws of the State of Iowa. 28. No failure or delay to exercise, nor
any single or partial exercise of, any right, power, or privilege given or arising under this
Agreement will operate as a waiver of future rights to exercise any such right,
<!-- page 7 -->
power, or privilege. 29. This Agreement may be signed in any number of counterparts, each of which
will be considered an original, but all of those counterparts will together constitute only one
Agreement. 30. The determination that any provision of this Agreement is not enforceable in a
particular jurisdiction will not affect the validity or enforceability of the remaining provisions
generally, or in any other jurisdiction or as to any other entities not involved in that judgment.
Such unenforceable provisions will be stricken or deemed modified in accordance with such
determination and this Agreement, as so modified, will continue to be in force and effect. IN
WITNESS WHEREOF, the Parties hereto have caused this Agreement to be executed on the date first
above written. ABC Company, Broker Dealer By: ____________________________
_______________________________ Please type or print name _______________________________ Please
type or print Title Date: __________________________ Princor Financial Services Corporation By:
_______________________________________ Marty Richardson Operations Officer Date:
____________________________________ Principal Life Insurance Company By:
_______________________________________ Angela Ellis Assistant Vice President - Marketer Services
Date: ____________________________________ Affiliated Agencies of Broker Dealer By:
_______________________________________ __________________________________________ Please type or
print name
<!-- page 8 -->
__________________________________________ Please type or print Title Date:
____________________________________
<!-- page 9 -->
EXHIBIT A COMPENSATION SCHEDULE FOR PRINCIPAL VARIABLE ANNUITY CONTRACTS Products may not be
available in all states and state variations may apply. Trail commissions are calculated as a
percentage of account value. Commissions for variable annuities are based on the age of the oldest
owner or annuitant. The trail commission is paid to the current servicing agent of record provided
the Annuity Contract is still in effect. Servicing agent means the broker dealer or Registered
Representative appointed by us and accepted by the contract owner as the servicing agent. If the
contract owner requests a change in the servicing agent or if we decide that a change would be in
the best interests of the contract owner, trail commissions will be paid to the new servicing agent
or his/her broker dealer where appropriate. No trail commissions are paid after termination of this
Agreement.

A. Option Elections The Broker Dealer will be paid compensation on sales of Principal Variable
Annuity/Principal Investment Plus Variable Annuitysm Contracts in accordance with the Compensation
Options elected herein and which its Registered Representative shall elect, using the election
procedures established by the Issuer, upon submission of the product application to the Issuer and
for which good payment has been received. Compensation paid will be based on Option A unless, upon
submission of the contract application, the Registered Representative elects another Option made
available to it by Broker Dealer's election below. Check the options available to your Registered
Representatives. _X_ Option A - Full front end compensation with no trail ___Option B - Slightly
lower front-end commission with a .10% annual trail commission paid quarterly starting at the end of
the fifth quarter ___Option C - Lower front-end commission with a .30% annual trail commission paid
quarterly starting at the end of the fifth quarter ___Option D - Low or no up front-end commission
based upon issue age with a 1.0% annual trail commission paid quarterly starting at the end of the
fifth quarter
<!-- page 10 -->
<!-- page 11 -->
<!-- page 12 -->
<!-- page 13 -->
Principal Variable Annuity (FVA)*/Principal Investment Plus Variable Annuity (IPVA)**
