## grep
- `grep(pattern, doc_ids?)` — regex across the documents. Returns per-document MATCH COUNTS and the
  first matching lines with line numbers and pages. Use counts to decide which documents to open.
  Use alternations for synonyms and spellings: `terminat(e|ion)|cancel`, `3\.50|3\.5 ?to ?1`.
## read
- `read(doc_id, start_line, n_lines)` — a line-numbered window of one document. Start at a line you
  got from a search, grep or outline hit. Windows you already read come back as "already read".
## outline
- `outline(doc_id)` — headings with line numbers and pages; use it to jump to a section.
## list_docs
- `list_docs(filters)` — document metadata (type, date, parties). Use dates to pick the governing version.
## search
- `search(query, k?)` — keyword (BM25) search over ~300-token chunks of every document. Returns ranked
  hits with doc_id, line range, page and a snippet, plus how deep the ranking goes. Use several
  distinct short queries (defined terms, amounts, section words), then `read` around the best hits.
## page_results
- `page_results(query, page)` — the next page of 10 hits from an earlier `search` ranking, down to
  its full depth. Use it when the first page did not contain what you need, instead of re-running
  the same query.
## add_evidence
- `add_evidence(doc_id, start_line, end_line, quote, note)` — save a VERBATIM quote. Copy the text
  exactly from a `read` window; paraphrases are rejected. Save evidence as soon as you find it.
## submit
- `submit(sub_question, answer, evidence_ids, confidence, not_in_corpus)` — finish. Every factual
  statement in `answer` must cite saved evidence ids like [e3]. If the documents do not contain what
  was asked, say so and set not_in_corpus=true, even when you found a related or similar provision:
  a different kind of clause is not the answer. You may cite the nearest provision as evidence of
  what the document does contain, but do not present it as the asked-for item.
