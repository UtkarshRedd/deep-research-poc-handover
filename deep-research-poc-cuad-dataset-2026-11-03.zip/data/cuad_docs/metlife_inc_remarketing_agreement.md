<!-- page 1 -->
# Remarketing Agreement
| Field | Value |
|---|---|
| Document Type | Marketing Agreement |
| Agreement Date | 2014-08-26 |
| Parties | MetLife, Inc. ("Company"); Deutsche Bank Securities Inc. ("Deutsche Bank”, "Remarketing Agents"); Deutsche Bank Trust Company America ("Stock Purchase Contract Agent") |
| Source | CUAD v1 / MetLife, Inc. - Remarketing Agreement |

Exhibit 99.1

EXECUTION VERSION

METLIFE, INC.

Series E Senior Component Debentures, Tranche 1, due 2018 Series E Senior Component Debentures,
Tranche 2, due 2045

REMARKETING AGREEMENT

August 26, 2014

Deutsche Bank Securities Inc. 60 Wall Street New York, New York 10005

Ladies and Gentlemen:

This Remarketing Agreement is dated as of August 26, 2014 (this "Remarketing Agreement"), among
MetLife, Inc., a Delaware corporation (the "Company"), and Deutsche Bank Securities Inc. ("Deutsche
Bank") (the "Remarketing Agents," which expression shall include any institution appointed as a
Remarketing Agent in accordance with Section 8 hereof), and Deutsche Bank Trust Company Americas,
not individually but solely as Stock Purchase Contract Agent (as defined below) and as
attorney-in-fact of the holders of Stock Purchase Contracts (as defined below). The Company and the
Remarketing Agents will enter into a Pricing Agreement, to be dated the Remarketing Date (as defined
below) (the "Pricing Agreement"), which will set forth, inter alia, the final terms of the
Remarketed Securities (as defined below) and the Remarketing Fee (as defined below). The Remarketing
Agents are undertaking to remarket Series E Senior Component Debentures, Tranche 1, due 2018
(principal amount $1,000 per Series E Senior Component Debenture) (the "First Tranche Series E Debt
Securities") and Series E Senior Component Debentures, Tranche 2, due 2045 (principal amount $1,000
per Series E Senior Component Debenture) (the "Second Tranche Series E Debt Securities"), whose
terms will each be modified in the event of a Successful Remarketing (as defined below), as provided
in the notice of remarketing from the Company, dated August 26, 2014 (the "Notice") pursuant to
Section 3.3(a) of the Twenty-Second Supplemental Indenture (as defined below) and Section 5.2(a)(iv)
of the Stock Purchase Contract Agreement (as defined below) (such securities, as so modified from
and after a Successful Remarketing (whether or not such securities were remarketed by the
Remarketing Agents), the "Securities"). Upon a Successful Remarketing, the Stated Maturity (as
defined in the Indenture (as defined below)) of the First Tranche Series E Debt Securities will,
effective October 8, 2014, automatically be adjusted to December 15, 2017 and the Stated Maturity of
the Second Tranche Series E Debt Securities will, effective October 8, 2014, automatically be
adjusted to December 15, 2044.
<!-- page 2 -->
The First Tranche Series E Debt Securities and Second Tranche Series E Debt Securities will be
component securities of the Series E Senior Debentures due 2045 ("Series E Debt Securities") issued
by the Company, pursuant to an Indenture, dated as of November 9, 2001 (the "Base Indenture"),
between the Company and The Bank of New York Mellon Trust Company, N.A. (as successor in interest to
J.P. Morgan Trust Company, National Association (as successor to Bank One Trust Company, N.A.)), as
trustee (the "Trustee"), as supplemented by the Twenty- Second Supplemental Indenture, dated as of
November 1, 2010 (the "Twenty-Second Supplemental Indenture" and, together with the Base Indenture,
the "Indenture"), between the Company and the Trustee. Effective on September 15, 2014, the Series E
Debt Securities will automatically convert, without any act of any holder, into units consisting of
two tranches, with each $2,000 principal amount of Series E Debt Securities thereafter consisting of
$1,000 principal amount of First Tranche Series E Debt Securities and $1,000 principal amount of
Second Tranche Series E Debt Securities.

A 1/40t h or 2.50% undivided beneficial ownership interest in each Series E Debt Security having a
principal amount of $1,000 is part of a common equity unit (each, a "Unit"), which currently
includes one stock purchase contract (the "Stock Purchase Contract") which was issued pursuant to
the Stock Purchase Contract Agreement, dated as of November 1, 2010, as amended and supplemented by
Supplemental Agreement No. 1, dated June 26, 2013, between the Company and the Stock Purchase
Contract Agent (as so amended and supplemented, the "Stock Purchase Contract Agreement"), between
the Company and Deutsche Bank Trust Company Americas, as stock purchase contract agent (the "Stock
Purchase Contract Agent"), and under which the holder of the Unit is obligated to purchase from the
Company on the Third Stock Purchase Date (as defined in the Stock Purchase Contract Agreement), for
$25.00 per Stock Purchase Contract, a number of shares of common stock, par value $0.01 per share,
of the Company (the "Common Stock"), equal to the applicable Settlement Rate as set forth in the
Stock Purchase Contract Agreement. The ownership interests in the Series E Debt Securities or, if
the holder has stripped such Unit, designated zero-coupon U.S. Treasury Securities, have been
pledged to secure the obligations to purchase Common Stock on the Third Stock Purchase Date (as
defined in the Stock Purchase Contract Agreement) pursuant to the Stock Purchase Contract. The terms
and conditions of such pledge are set forth in the Pledge Agreement, dated as of November 1, 2010
(the "Pledge Agreement"), among the Company, Deutsche Bank Trust Company Americas, as collateral
agent (the "Collateral Agent"), custodial agent (the "Custodial Agent") and securities intermediary
(the "Securities Intermediary"), and the Stock Purchase Contract Agent.

The Units were initially issued in a private placement to AM Holdings LLC (f/k/a ALICO Holdings
LLC), a Delaware limited liability company (the "Selling Securityholder"), as part of the
consideration paid by the Company to the Selling Securityholder in connection with the Company's
acquisition of American Life Insurance Company and Delaware American Life Insurance Company from the
Selling 2
<!-- page 3 -->
Securityholder and American International Group, Inc. (the "Acquisition"). The Acquisition was
completed on November 1, 2010. The Units were offered and sold by the Selling Securityholder in a
registered public offering completed on March 8, 2011.

Capitalized terms used and not defined in this Remarketing Agreement shall have the meanings set
forth in the Stock Purchase Contract Agreement, the Pledge Agreement or the Indenture, as the case
may be.

The Remarketing (as defined below) of the First Tranche Series E Debt Securities and Second Tranche
Series E Debt Securities is provided for in Article III of the Twenty-Second Supplemental Indenture.
As used in this Remarketing Agreement, "Transaction Documents" shall mean, collectively, the Stock
Purchase Contract Agreement, the Indenture, the Pledge Agreement, this Remarketing Agreement and the
Pricing Agreement; the term "Remarketed Securities" means the First Tranche Series E Debt Securities
and Second Tranche Series E Debt Securities subject to the Remarketing as notified to the
Remarketing Agents by the Collateral Agent and the Custodial Agent, on or prior to the Remarketing
Date; the term "Remarketing Procedures" means the procedures in connection with the Remarketing,
described in the Stock Purchase Contract Agreement, the Pledge Agreement and the Twenty-Second
Supplemental Indenture, as the case may be; the term "Remarketing" means the remarketing, offering,
sale and delivery of the Remarketed Securities pursuant to the Remarketing Procedures; the term
"Remarketing Date" means the date on which the Remarketing Agents price the Remarketed Securities in
connection with the Remarketing, such date to occur on a Business Day (as defined below) during the
period that begins on, and includes, September 25, 2014 and ends on, and includes, October 7, 2014;
the term "Remarketing Settlement Date" means the date on which the purchase and sale of the
Remarketed Securities closes and the delivery of such Remarketed Securities is made against payment
therefor, such date to occur on a Business Day during the period that begins on, and includes,
October 1, 2014 and ends on, and includes, October 8, 2014; and the term "Successful Remarketing"
means a Remarketing that (i) was conducted in accordance with Article III of the Twenty-Second
Supplemental Indenture; and (ii) results in (a) the sale of each Remarketed Security that is subject
to such Remarketing by the Remarketing Agents by no later than 4:00 P.M., New York City time, on the
Remarketing Settlement Date of such Remarketing; (b) the delivery of the aggregate cash gross
proceeds from such sale to such Remarketing Agents no later than 4:00 P.M., New York City time, on
such Remarketing Settlement Date; and (c) aggregate cash gross proceeds of not less than the
Remarketing Price (as defined below) for such Remarketing.

As used herein, "Business Day" means any day other than a Saturday, Sunday or other day on which
banking institutions in New York, New York are authorized or required by law or executive order to
remain closed.

1. Appointment and Obligations of the Remarketing Agents. (a) The Company hereby appoints Deutsche
Bank as the initial Remarketing Agent, and Deutsche 3
<!-- page 4 -->
Bank hereby accepts appointment as Remarketing Agent, for the purpose of (i) Remarketing the
Remarketed Securities on behalf of the holders thereof, (ii) establishing the Reset Rates (as
defined below) for the Securities in connection with the Remarketing and (iii) performing such other
duties as are assigned to the Remarketing Agents in the Remarketing Procedures, all in accordance
with and pursuant to the Remarketing Procedures.

(b) The Remarketing Agents agree (i) to use commercially reasonable efforts to remarket the
Remarketed Securities tendered or deemed tendered to the Remarketing Agents in the Remarketing, (ii)
to establish the Reset Rates in accordance with the Remarketing Procedures and to notify the
Company, the Trustee and the Stock Purchase Contract Agent promptly of the Reset Rates and (iii) to
carry out such other duties as are assigned to the Remarketing Agents in the Remarketing Procedures,
all in accordance with the provisions of the Remarketing Procedures.

(c) On the Remarketing Date, the Remarketing Agents shall use their commercially reasonable efforts
to remarket the Remarketed Securities tendered or deemed tendered for purchase, at a price which
results in cash proceeds equal to at least the sum of (i) the remarketing fee to be paid to the
Remarketing Agents in connection with the Remarketing in an amount to be specified in the Pricing
Agreement (such fee, the "Remarketing Fee"), (ii) 100% of the aggregate principal amount of such
Remarketed Securities, (iii) the accrued and unpaid interest to, but not including, the Initial
Scheduled Third Stock Purchase Date on such Remarketed Securities and (iv) the product of five basis
points (0.05%) and the aggregate principal amount of such Remarketed Securities (such sum, the
"Remarketing Price").

(d) On the Remarketing Date, the Remarketing Agents shall determine the rate per annum, rounded to
the nearest one-thousandth of one percent (0.001%), that each tranche of Securities should bear
(which rate will apply to all Securities of the applicable tranche whether or not such Securities
were included in the Remarketing) (the "Reset Rate") in order for each tranche of the Remarketed
Securities to generate cash proceeds from the Remarketing equal to at least the Remarketing Price
allocable to that tranche and that in the sole reasonable discretion of the Remarketing Agents will
enable them to remarket all Remarketed Securities of such tranche tendered or deemed tendered for
purchase in such Remarketing at no less than the Remarketing Price allocable to that tranche;
provided, that, each such Reset Rate need not, but may, be the same for each tranche of Securities;
provided, however, that, unless such requirement has been validly waived by the Company, the Reset
Rate may not exceed the prevailing market yield, as determined by the Remarketing Agents, of the
benchmark U.S. treasury security having a remaining maturity that most closely corresponds to the
period from the Remarketing Settlement Date until the Stated Maturity of the applicable tranche of
the Securities (after giving effect to the change in the Stated Maturity of each tranche of the
Securities on the Remarketing Settlement Date pursuant to the Indenture), plus 750 basis points per
annum; provided, further, that neither Reset Rate may be less than 0% per annum. 4
<!-- page 5 -->
(e) In the event of a Remarketing that is not a Successful Remarketing, the Remarketing Agents shall
promptly remit (i) to the Custodial Agent the Remarketed Securities, if any, that are no longer a
component of the Units ("Separate Securities"), and (ii) to the Collateral Agent the balance of the
Remarketed Securities.

(f) By no later than 4:30 P.M., New York City time, on the Remarketing Settlement Date, provided
that there has been a Successful Remarketing, the Remarketing Agents shall advise, by telephone, the
Company, the Stock Purchase Contract Agent and the Trustee that the Remarketing was a Successful
Remarketing and of the Reset Rates determined in the Remarketing and the aggregate principal amount
of Remarketed Securities sold in the Remarketing.

(g) In accordance with The Depository Trust Company's (the "Depositary") normal procedures, on the
Remarketing Settlement Date, the transactions described above with respect to each Remarketed
Security tendered for purchase and sold in the Remarketing shall be executed through the Depositary,
and the accounts of the respective Depositary participants shall be debited and credited and such
Remarketed Securities delivered by book-entry as necessary to effect purchases and sales of such
Remarketed Securities.

(h) On the Remarketing Settlement Date, the tender and settlement procedures set forth in this
Section 1, including provisions for payment by purchasers of the Remarketed Securities in the
Remarketing, shall be subject to modification to the extent required by the Depositary or, if the
book- entry system is no longer available for the Remarketed Securities at the time of the
Remarketing, to facilitate the tendering and remarketing of the Remarketed Securities in
certificated form. In addition, the Remarketing Agents may modify the settlement procedures set
forth herein in order to facilitate the settlement process.

(i) On the Remarketing Settlement Date, the Remarketing Agents shall deduct the Remarketing Fee from
the gross proceeds of the Remarketing and shall remit any proceeds remaining after such deduction as
follows: (i) to the extent such net proceeds relate to Remarketed Securities that form part of any
Normal Common Equity Unit (as defined in the Stock Purchase Contract Agreement), to the Securities
Intermediary and (ii) to the extent such net proceeds relate to the Separate Securities that were
included in the Remarketing as Remarketed Securities to, or at the direction of, the Custodial Agent
for payment to the holders of such Separate Securities. Holders whose First Tranche Series E Debt
Securities and Second Tranche Series E Debt Securities are remarketed pursuant to this Remarketing
Agreement will not otherwise be responsible for the payment of any Remarketing Fee in connection
therewith. 5
<!-- page 6 -->
(j) If fewer than all of the Remarketed Securities are remarketed in accordance with the terms
hereof, the Remarketing shall be deemed to have failed as to all Remarketed Securities.

(k) If at any time during the term of this Remarketing Agreement, any Event of Default (as defined
in the Indenture) or event that with the passage of time or the giving of notice or both would
become such an Event of Default has occurred and is continuing under the Indenture, then the
obligations and duties of the Remarketing Agents under this Remarketing Agreement shall be suspended
until such default or event has been cured. The Company will promptly cause the Trustee, the Stock
Purchase Contract Agent and the Collateral Agent to give the Remarketing Agents notice of all such
defaults and events of which such trustee or agent is aware.

2. Representations and Warranties of the Company. The Company hereby represents and warrants that,
unless otherwise specified (i) on and as of the Applicable Time (as defined below) (to the extent
such representations and warranties are applicable as of such date), (ii) on and as of the
Remarketing Date and (iii) on and as of the Remarketing Settlement Date that:

(a) The Company has filed with the Securities and Exchange Commission (the "Commission") a
registration statement on Form S-3 (No. 333-192366) under the Securities Act of 1933, as amended
(the "Act"), which has become effective covering, inter alia, the Remarketing of the Remarketed
Securities. The Company meets the requirements for use of Form S-3 under the Act. The Company
proposes to file with the Commission pursuant to Rule 424 under the Act a supplement or supplements
to the form of prospectus included in such registration statement relating to the Remarketed
Securities and the plan of distribution thereof. Such registration statement, including the exhibits
thereto, as amended at the Remarketing Date, is hereinafter called the "Registration Statement"; the
Registration Statement at the time it originally became effective is herein called the "Original
Registration Statement"; such prospectus in the form in which it appears in the Original
Registration Statement is hereinafter called the "Base Prospectus"; and such supplemented form of
prospectus, in the form in which it shall first be filed with the Commission pursuant to Rule 424
(including the Base Prospectus as so supplemented), is hereinafter called the "Final Prospectus."
Any preliminary form of the Final Prospectus in the form in which it shall first be filed with the
Commission pursuant to Rule 424 is hereinafter called a "Preliminary Prospectus." Any reference
herein to the Registration Statement, the Base Prospectus, any Preliminary Prospectus, the Pricing
Prospectus (as defined below) or the Final Prospectus shall be deemed to refer to and include the
documents incorporated by reference therein pursuant to Item 12 of Form S-3 which were filed under
the Securities Exchange Act of 1934, as amended (the "Exchange Act"), on or before the Remarketing
Date, or the issue date of the Base 6
<!-- page 7 -->
Prospectus, any Preliminary Prospectus, the Pricing Prospectus or the Final Prospectus, as the case
may be; and any reference herein to the terms "amend," "amendment" or "supplement" with respect to
the Registration Statement, the Base Prospectus, any Preliminary Prospectus, the Pricing Prospectus
or the Final Prospectus shall be deemed to refer to and include any document filed under the
Exchange Act after the date of this Remarketing Agreement, or the issue date of the Base Prospectus,
any Preliminary Prospectus, the Pricing Prospectus or the Final Prospectus, as the case may be,
deemed to be incorporated therein by reference; each Preliminary Prospectus, the Pricing Prospectus
and the prospectuses filed as part of the Registration Statement as originally filed or as part of
any amendment thereto, or filed pursuant to Rule 424 under the Act, complied or will comply, as
applicable, when so filed in all material respects with the Act and the rules thereunder and each
Preliminary Prospectus, the Pricing Prospectus and the Final Prospectus delivered to the Remarketing
Agents for use in connection with this offering will be identical to the electronically transmitted
copies thereof filed with the Commission via the Electronic Data Gathering, Analysis and Retrieval
("EDGAR") system, except to the extent permitted by Regulation S-T.

(b) (i) The Registration Statement, as amended as of any such time, and the Final Prospectus, as
amended or supplemented as of any such time, and, in the case of Securities issued pursuant to the
Indenture, such Indenture, will comply in all material respects with the applicable requirements of
the Act, the Exchange Act and the Trust Indenture Act of 1939, as amended (the "Trust Indenture
Act"), as applicable, and the respective rules thereunder;

(ii) (A) The Registration Statement does not and will not, as of the applicable effective date as to
each part of the Registration Statement, contain any untrue statement of a material fact or omit to
state any material fact required to be stated therein or necessary in order to make the statements
therein not misleading and (B) the Final Prospectus does not and will not, as of its date and as of
its filing date, contain any untrue statement of a material fact or omit to state any material fact
required to be stated therein or necessary in order to make the statements therein, in the light of
the circumstances under which they were made, not misleading; provided, however, that for each of
(A) and (B), the Company makes no representations or warranties as to (i) that part of the
Registration Statement which shall constitute the trustee's Statement of Eligibility and
Qualification (Form T-1) under the Trust Indenture Act or (ii) the information contained in or
omitted from the Registration Statement or the Final Prospectus in reliance upon and in conformity
with information relating to any Remarketing Agent furnished in writing to the Company by such
Remarketing Agent expressly for use in the Registration Statement and the Final Prospectus; 7
<!-- page 8 -->
(iii) As of the Applicable Time, the Issuer Free Writing Prospectus(es) (as defined below) listed on
Schedule 1 hereto, if any, the Pricing Prospectus (as defined below), and the final term sheet
relating to the Remarketed Securities set forth as Annex A to the Pricing Agreement (the "Final Term
Sheet"), all considered together (collectively, the "Disclosure Package"), will not include any
untrue statement of a material fact or omit to state any material fact necessary in order to make
the statements therein, in the light of the circumstances under which they were made, not
misleading; and

(iv) As of the Applicable Time, each Issuer Free Writing Prospectus listed on Schedule 1 hereto, if
any, will not conflict with the information contained or incorporated by reference in the
Registration Statement or the Disclosure Package, and each such Issuer Free Writing Prospectus, as
supplemented by and taken together with the Disclosure Package and any other such Issuer Free
Writing Prospectus, in each case as of the Applicable Time, will not include any untrue statement of
a material fact or omit to state any material fact necessary in order to make the statements
therein, in light of the circumstances under which they were made, not misleading; provided,
however, it is understood and agreed that in no event shall any such Issuer Free Writing Prospectus,
including but not limited to any electronic roadshow, be listed on Schedule 1 hereto unless the
Company (i) has consented to the use thereof and (ii) shall have approved its contents before any
such use, in each case in accordance with the provisions of this Remarketing Agreement.

As used in this subsection and elsewhere in this Remarketing Agreement:

"Applicable Time" means such time as is specified as the "Applicable Time" in the Pricing Agreement
or such other time as agreed by the Company and the Remarketing Agents.

"Issuer Free Writing Prospectus" means any "issuer free writing prospectus," as defined in Rule 433
under the Act ("Rule 433"), relating to the Remarketed Securities.

"Pricing Prospectus" means the Base Prospectus, as amended or supplemented (including by any
Preliminary Prospectus) immediately prior to the Applicable Time. 8
<!-- page 9 -->
(c) At the time the Company or another offering participant first made a bona fide offer (within the
meaning of Rule 164(h)(2) under the Act) of the Securities, the Company was not an "ineligible
issuer" as defined in Rule 405 under the Act.

(d) The Company has not distributed and will not distribute, prior to the later of the Remarketing
Settlement Date and the completion of the Remarketing Agents' distribution of the Remarketed
Securities, any offering material in connection with the Remarketing of the Remarketed Securities
other than the Preliminary Prospectus, the Final Prospectus or any Issuer Free Writing Prospectus
reviewed and consented to by the Remarketing Agents as provided in Section 3(j) of this Remarketing
Agreement.

(e) (i) At the time of filing the Registration Statement, (ii) at the time of the most recent
amendment thereto for the purposes of complying with Section 10(a)(3) of the Act (whether such
amendment was by post-effective amendment, incorporated report filed pursuant to Section 13 or 15(d)
of the Exchange Act or form of prospectus), (iii) at the time the Company or any person acting on
its behalf (within the meaning, for this clause only, of Rule 163(c) under the Act) relied on the
exemption of Rule 163 under the Act, and (iv) as of the date and time that the Pricing Agreement is
executed (the "Execution Time"), the Company was and will be a "well known seasoned issuer" as
defined in Rule 405 under the Act. The Registration Statement is an "automatic shelf registration
statement," as defined in Rule 405 under the Act, that automatically became effective not more than
three years prior to the Execution Time; the Company has not received from the Commission any notice
pursuant to Rule 401(g)(2) under the Act objecting to use of the automatic shelf registration
statement and the Company has not otherwise ceased to be eligible to use the automatic shelf
registration statement. The Company has paid or shall pay the required Commission filing fees
relating to the Remarketed Securities within the time required by Rule 456(b)(1) under the Act and
otherwise in accordance with Rules 456(b) and 457(r) under the Act.

(f) Each document incorporated or deemed to be incorporated by reference in the Registration
Statement, the Disclosure Package and the Final Prospectus, when they became effective or at the
time they were or hereafter are filed with the Commission, complied and will comply in all material
respects with the Act or the Exchange Act, as applicable.

(g) Neither the Company nor any Significant Subsidiary (as defined below) of the Company has
sustained since the date of the latest audited financial statements included or incorporated by
reference in the Disclosure Package any loss or interference material to the business of the Company
and its subsidiaries considered as a whole, other than as described in or contemplated by 9
<!-- page 10 -->
the Disclosure Package, from fire, explosion, flood or other calamity, whether or not covered by
insurance, or from any labor dispute or court or governmental action, order or decree; and, since
the respective dates as of which information is given in the Disclosure Package, other than as
described or contemplated in the Disclosure Package, there has not been any (i) material addition,
or development involving a prospective material addition, to the liability of any Significant
Subsidiary for future policy benefits, policyholder account balances and other claims, other than in
the ordinary course of business, (ii) material decrease in the surplus of any Significant Subsidiary
or material change in the capital stock or other ownership interests (other than issuances of common
stock upon the exercise of outstanding employee stock options or pursuant to existing employee
compensation plans or on the conversion or exchange of convertible or exchangeable securities
outstanding on the date of this Remarketing Agreement) of the Company or any Significant Subsidiary
or any material increase in the long- term debt of the Company or its subsidiaries, considered as a
whole, or (iii) material adverse change, or development involving a prospective material adverse
change, in or affecting the business, financial position, reserves, surplus, equity or results of
operations (in each case considered either on a statutory accounting or U.S. generally accepted
accounting principles ("GAAP") basis, as applicable) of the Company and its subsidiaries considered
as a whole. As of December 31, 2013, the subsidiaries of the Company that would qualify as a
"Significant Subsidiary" of the Company under Regulation S-X were Metropolitan Life Insurance
Company ("MLIC"), MetLife Insurance Company of Connecticut, MetLife Investors USA Insurance Company,
Exeter Reassurance Company, Ltd., MetLife Insurance K.K., American Life Insurance Company, MetLife
Mexico S.A. and MetLife Reinsurance Company of Charleston, and each of such subsidiaries will be
considered a "Significant Subsidiary" for purposes of this Agreement.

(h) The Company and each Significant Subsidiary has good and marketable title in fee simple to all
material real property and good and marketable title to all material personal property owned by it,
in each case free and clear of all liens, encumbrances and defects that materially interfere with
the use made and proposed to be made of such property by the Company or any Significant Subsidiary,
except such as are described in the Disclosure Package or such as would not have a material adverse
effect on the business, financial position, equity, reserves, surplus or results of operations of
the Company and its subsidiaries, considered as a whole ("Material Adverse Effect"), and any
material real property and material buildings held under lease by the Company or any of its
subsidiaries are held under valid, subsisting and enforceable leases with such exceptions that do
not materially interfere with the use made and currently proposed to be made of such property and
buildings by the Company or any Significant Subsidiary. 10
<!-- page 11 -->
(i) The Company has been duly incorporated and is validly existing as a corporation in good standing
under the laws of the State of Delaware, with power and authority (corporate and other) to own its
properties and conduct its business as described in the Disclosure Package and has been duly
qualified as a foreign corporation for the transaction of business and is in good standing under the
laws of each other jurisdiction in which its ownership or lease of property or the conduct of its
business requires such qualification and good standing, except to the extent that the failure to be
so qualified and in good standing would not have a Material Adverse Effect; MLIC was duly converted
from a mutual life insurance company to a stock life insurance company on April 7, 2000 in
accordance with the Plan of Reorganization of MLIC under Section 7312 of the New York Insurance Law;
each Significant Subsidiary is validly existing as a corporation and is in good standing under the
laws of its jurisdiction of incorporation, with power and authority (corporate and other) to own its
properties and conduct its business as described in the Disclosure Package; and each Significant
Subsidiary is duly qualified as a foreign corporation for the transaction of business and is in good
standing under the laws of each other jurisdiction in which its ownership or lease of property or
the conduct of its business requires such qualification and good standing, except to the extent that
the failure to be so qualified and in good standing would not have a Material Adverse Effect.

(j) The Company had or has, as applicable, the corporate power and authority to execute and deliver
each Transaction Document and the Securities and to consummate the transactions contemplated hereby
and thereby.

(k) The Company has an authorized capitalization as set forth and described in the Disclosure
Package, and all of the issued shares of capital stock of the Company have been duly authorized and
validly issued and are fully paid and nonassessable; none of the outstanding shares of capital stock
of the Company was issued in violation of the preemptive or other similar rights of any
securityholder of the Company; except as disclosed in the Disclosure Package, there are no
outstanding options or warrants to purchase, or any preemptive rights or other rights to subscribe
for or to purchase, any securities or obligations convertible into or any contracts or commitments
to sell shares of the Company's capital stock or any such options, rights, warrants, convertible
securities or obligations; the description of the Company's stock option plans and the options or
other rights granted and exercised thereunder set forth in the Disclosure Package accurately and
fairly describe the information required to be shown with respect to such plans, arrangements,
options and rights; except as disclosed in the Disclosure Package, there are no rights of any
person, corporation or other entity to require registration of any shares of common stock or any
other securities of the Company in connection with the filing of the Registration Statement and the
11
<!-- page 12 -->
Remarketing of the Remarketed Securities by the Remarketing Agents pursuant to this Remarketing
Agreement and the Pricing Agreement; all of the issued shares of capital stock or other ownership
interests of MLIC have been duly and validly authorized and issued, are fully paid and nonassessable
and are owned directly or indirectly by the Company free and clear of all liens, encumbrances,
equities or claims.

(l) Each Transaction Document has been duly authorized by the Company and has been or, at the
Remarketing Settlement Date, will have been duly executed and delivered, will conform in all
material respects to the description thereof in the Disclosure Package and the Final Prospectus, and
each Transaction Document other than this Remarketing Agreement and the Pricing Agreement
constitutes or, at the Remarketing Settlement Date, will constitute valid and legally binding
obligations of the Company, enforceable against the Company in accordance with its terms, subject,
as to enforcement, to bankruptcy, insolvency, fraudulent transfer, moratorium and other similar laws
relating to or affecting creditors' rights generally and to general principles of equity; and the
Indenture has been duly qualified under the Trust Indenture Act.

(m) The Series E Debt Securities have been duly authorized, executed, authenticated, issued and
delivered and constitute valid and legally binding obligations of the Company, enforceable against
the Company in accordance with their terms, subject, as to enforcement, to bankruptcy, insolvency,
fraudulent transfer, moratorium and other similar laws relating to or affecting creditors' rights
generally and to general principles of equity, and are entitled to the benefits provided by the
Indenture; the Series E Debt Securities are, and the First Tranche Series E Debt Securities and the
Second Tranche Series E Debt Securities will be, substantially in the form contemplated by the
Indenture.

(n) The Securities have been duly authorized and will, on the Remarketing Settlement Date, have been
duly executed, authenticated, issued and delivered (assuming their due authentication by the
trustee) and constitute valid and legally binding obligations of the Company, enforceable against
the Company in accordance with their terms, subject, as to enforcement, to bankruptcy, insolvency,
fraudulent transfer, moratorium and other similar laws relating to or affecting creditors' rights
generally and to general principles of equity, and will be entitled to the benefits provided by the
Indenture; and the Securities will be substantially in the form contemplated by the Indenture and
will conform in all material respects to the description thereof contained in the Disclosure Package
and the Final Prospectus.

(o) Each Significant Subsidiary that is required to be organized or licensed as an insurance company
in its jurisdiction of incorporation (each, an "Insurance Subsidiary" and collectively, the
"Insurance Subsidiaries") is licensed 12
<!-- page 13 -->
as an insurance company in its respective jurisdiction of incorporation and is duly licensed or
authorized as an insurer in each other jurisdiction where it is required to be so licensed or
authorized to conduct its business, in each case with such exceptions as would not have,
individually or in the aggregate, a Material Adverse Effect; except as otherwise described in the
Disclosure Package, each Insurance Subsidiary has all other approvals, orders, consents,
authorizations, licenses, certificates, permits, registrations and qualifications (collectively, the
"Approvals") of and from all insurance regulatory authorities to conduct its business, with such
exceptions as would not have, individually or in the aggregate, a Material Adverse Effect; there is
no pending or, to the knowledge of the Company, threatened action, suit, proceeding or investigation
that could reasonably be expected to lead to any revocation, termination or suspension of any such
Approval, the revocation, termination or suspension of which would have, individually or in the
aggregate, a Material Adverse Effect; and, to the knowledge of the Company, no insurance regulatory
agency or body has issued any order or decree impairing, restricting or prohibiting the payment of
dividends by any Insurance Subsidiary to its parent which would have, individually or in the
aggregate, a Material Adverse Effect.

(p) The Company and each Significant Subsidiary has all necessary Approvals of and from, and has
made all filings, registrations and declarations (collectively, the "Filings") with, all insurance
regulatory authorities, all Federal, state, local and other governmental authorities, all
self-regulatory organizations and all courts and other tribunals, which are necessary to own, lease,
license and use its properties and assets and to conduct its business in the manner described in the
Disclosure Package, except where the failure to have such Approvals or to make such Filings would
not have, individually or in the aggregate, a Material Adverse Effect; to the knowledge of the
Company, the Company and each Significant Subsidiary is in compliance with all applicable laws,
rules, regulations, orders, by-laws and similar requirements, including in connection with
registrations or memberships in self-regulatory organizations, and all such Approvals and Filings
are in full force and effect and neither the Company nor any Significant Subsidiary has received any
notice of any event, inquiry, investigation or proceeding that would reasonably be expected to
result in the suspension, revocation or limitation of any such Approval or otherwise impose any
limitation on the conduct of the business of the Company or any Significant Subsidiary, except as
described in the Disclosure Package or except for any such non-compliance, suspension, revocation or
limitation which would not have, individually or in the aggregate, a Material Adverse Effect.

(q) Each Insurance Subsidiary is in compliance with and conducts its businesses in conformity with
all applicable insurance laws and regulations of its respective jurisdiction of incorporation and
the insurance laws and regulations of other jurisdictions which are applicable to it, in each case
with such exceptions as would not have, individually or in the aggregate, a Material Adverse Effect.
13
<!-- page 14 -->
(r) Each Significant Subsidiary which is engaged in the business of acting as a broker-dealer or an
investment advisor (respectively, a "Broker-Dealer Subsidiary" and an "Investment Advisor
Subsidiary") is duly licensed or registered as a broker-dealer or investment advisor, as the case
may be, in each jurisdiction where it is required to be so licensed or registered to conduct its
business, in each case, with such exceptions as would not have, individually or in the aggregate, a
Material Adverse Effect; each Broker-Dealer Subsidiary and each Investment Advisor Subsidiary has
all other necessary Approvals of and from all applicable regulatory authorities, including any self-
regulatory organization, to conduct its businesses, in each case with such exceptions, as would not
have, individually or in the aggregate, a Material Adverse Effect; except as otherwise described in
the Disclosure Package, none of the Broker-Dealer Subsidiaries or Investment Advisor Subsidiaries
has received any notification from any applicable regulatory authority to the effect that any
additional Approvals from such regulatory authority are needed to be obtained by such subsidiary in
any case where it could be reasonably expected that (x) any of the Broker-Dealer Subsidiaries or
Investment Advisor Subsidiaries would in fact be required either to obtain any such additional
Approvals or cease or otherwise limit engaging in a certain business and (y) the failure to have
such Approvals or limiting such business would have a Material Adverse Effect; and each
Broker-Dealer Subsidiary and each Investment Advisor Subsidiary is in compliance with the
requirements of the broker-dealer and investment advisor laws and regulations of each jurisdiction
which are applicable to such subsidiary, and has filed all notices, reports, documents or other
information required to be filed thereunder, in each case with such exceptions as would not have,
individually or in the aggregate, a Material Adverse Effect.

(s) The Remarketing of the Remarketed Securities pursuant to this Remarketing Agreement and the
Pricing Agreement, and compliance by the Company with all of the provisions of the Securities and
the Transaction Documents, and the consummation of the transactions herein and therein contemplated,
will not conflict with or result in a breach or violation of any of the terms or provisions of, or
constitute a default under, any indenture, mortgage, deed of trust, loan agreement, or other written
agreement or similar instrument to which the Company or any Significant Subsidiary is a party or by
which the Company or any Significant Subsidiary is bound or to which any of the property or assets
of the Company or any Significant Subsidiary is subject, or which affects the validity, performance
or consummation of the transactions contemplated by this Remarketing Agreement, nor will such action
result in any violation of any statute or any order, rule or regulation of any court or insurance
regulatory 14
<!-- page 15 -->
authority or other governmental agency or body having jurisdiction over the Company or any
Significant Subsidiary or any of their properties, in each case other than such breaches, conflicts,
violations, or defaults which individually or in the aggregate, would not have a Material Adverse
Effect and would not adversely affect the validity or performance of the Company's obligations, as
applicable, under or with respect to the Remarketed Securities or any Transaction Document (in each
case as to which the Company is or is to become a party); nor will such action result in any
violation of the provisions of the certificate of incorporation or by-laws or other charter
documents of the Company or any Significant Subsidiary; and no Approval of or Filing with any such
court or insurance regulatory authority or other governmental agency or body is required for the
execution, delivery and performance by the Company of any Transaction Document or for the issue or
sale of the Securities, except, assuming the accuracy of the Remarketing Agents' representation in
Section 9 of this Remarketing Agreement, (i) the registration under the Act of the Securities which
registration has become effective and (ii) such Approvals or Filings as may be required under the
Trust Indenture Act or state securities or Blue Sky laws in connection with the Remarketing of the
Remarketed Securities by the Remarketing Agents.

(t) Other than as set forth in the Disclosure Package, there are no legal or governmental
proceedings pending to which the Company or any of its subsidiaries is a party or to which any
property of the Company or any of its subsidiaries is subject, challenging the transactions
contemplated by the Transaction Documents or which, if determined adversely to the Company or its
subsidiaries, could reasonably be expected to have, individually or in the aggregate, a Material
Adverse Effect or would materially and adversely affect the ability of the Company to perform its
obligations under the Transaction Documents; and, to the knowledge of the Company, no such
proceedings are threatened or contemplated by governmental authorities or threatened by others other
than as set forth in the Disclosure Package.

(u) Neither the Company nor any Significant Subsidiary is in violation of any of its certificate of
incorporation or by-laws or in default in the performance or observance of any obligation,
agreement, covenant or condition contained in any indenture, mortgage, deed of trust, loan
agreement, lease or other agreement or instrument to which it is a party or by which it is bound or
to which any of its property or assets is subject, which violation or default would have,
individually or in the aggregate, a Material Adverse Effect.

(v) The statements set forth in each of the Disclosure Package and the Final Prospectus under the
captions "Description of Debt Securities" and "Description of Remarketed Series E Debentures"
insofar as they purport to constitute a summary of the terms of the Transaction Documents and other
15
<!-- page 16 -->
documents referred to therein, under the caption "Plan of Distribution," insofar as they purport to
describe the documents referred to therein, and under the caption "Certain Material U.S. Federal
Income Tax Considerations" (subject to the limitations and qualifications set forth therein),
insofar as they purport to describe the provisions of the laws and documents referred to therein,
are accurate and complete in all material respects.

(w) Other than as disclosed in the Disclosure Package, the financial statements of the Company and
its consolidated subsidiaries included or incorporated by reference in the Disclosure Package,
together with the related schedules and notes, comply in all material respects with the requirements
of the Act and the Exchange Act, as applicable, and present fairly in all material respects the
financial position, the results of operations and the changes in cash flows of such entities in
conformity with GAAP at the respective dates or for the respective periods to which they apply; and
such financial statements and related notes and schedules, if any, have been prepared in accordance
with GAAP consistently applied throughout the periods involved.

(x) Deloitte & Touche LLP, which has audited certain consolidated financial statements of the
Company and its subsidiaries, is an Independent Registered Public Accounting Firm as required by the
Act and the rules and regulations of the Commission thereunder.

(y) Neither the Company nor any Significant Subsidiary is, or after giving effect to the offer and
sale of the Securities pursuant to the Pricing Agreement will be, an "investment company", as such
term is defined in the Investment Company Act of 1940, as amended (the "Investment Company Act"),
and the rules and regulations thereunder, although certain separate accounts of MLIC and of certain
Insurance Subsidiaries are required to register as investment companies under the Investment Company
Act.

(z) None of the Company or its subsidiaries or, to the best of their knowledge, any of their
directors, officers or affiliates, has taken or will take, directly or indirectly, any action
designed to, or that might reasonably be expected to cause or result in stabilization or
manipulation of the price of the Remarketed Securities in violation of Regulation M under the
Exchange Act.

(aa) The Company maintains a system of internal control over financial reporting (as such term is
defined in Rule 13a-15(f) under the Exchange Act) that complies with the requirements of the
Exchange Act and has been designed by the Company's principal executive officer and principal
financial officer, or under their supervision, to provide reasonable assurance regarding the
reliability of financial reporting and the preparation of financial statements for external purposes
in accordance with GAAP. As disclosed in the Company's 16
<!-- page 17 -->
Annual Report on Form 10-K for the year ended December 31, 2013, the Company's internal control over
financial reporting was effective as of December 31, 2013 and the Company is not aware of any
material weaknesses in its internal control over financial reporting.

(bb) The Company and its consolidated subsidiaries employ disclosure controls and procedures (as
such term is defined in Rule 13a- 15(e) under the Exchange Act) that are designed to ensure that
information required to be disclosed by the Company in the reports that it files or submits under
the Exchange Act is recorded, processed, summarized and reported, within the time periods specified
in the Commission's rules and forms, and is accumulated and communicated to the Company's
management, including its principal executive officer or officers and principal financial officer or
officers, as appropriate, to allow timely decisions regarding disclosure. As disclosed in the
Company's Quarterly Report on Form 10-Q for the quarter ended June 30, 2014, the Company's
disclosure controls and procedures were effective as of June 30, 2014.

(cc) No stop order suspending the effectiveness of the Registration Statement has been issued under
the Act and the Registration Statement is not the subject of a pending proceeding or examination
under Section 8(d) or 8(e) of the Act, the Company is not the subject of a pending proceedings under
Section 8A of the Act in connection with the Remarketing of the Remarketed Securities and any
request on the part of the Commission for additional information has been complied with.

(dd) Except as would not individually or in the aggregate, reasonably be expected to have a Material
Adverse Effect: (1) all tax returns required to be filed by the Company or any of its subsidiaries
have been timely filed, (2) (x) all taxes (whether imposed directly or through withholding)
including any interest, fine, sales and use taxes, all taxes which the Company and each of its
subsidiaries is obligated to withhold from amounts owing to employees, creditors and third parties
with respect to the period covered by such tax returns, additions to tax, or penalties applicable
thereto due or claimed to be due from such entities have been timely paid, and (y) no deficiency
assessment with respect to a proposed adjustment of the Company or its subsidiaries' federal, state,
local or foreign taxes is pending or, to the best of the Company or its subsidiaries' knowledge,
threatened, in each case of (x) and (y), other than such taxes or adjustments that are being
contested in good faith or for which adequate reserves have been provided, and (3) to the Company
and its subsidiaries' knowledge, there is no tax lien, whether imposed by any federal, state,
foreign or other taxing authority, outstanding against the assets, properties or business of the
Company or its subsidiaries. 17
<!-- page 18 -->
3. Company Covenants. The Company agrees with each of the Remarketing Agents:

(a) To prepare the Final Prospectus as amended and supplemented in relation to the Remarketed
Securities in a form approved by the Remarketing Agents and to file timely such Final Prospectus
pursuant to Rule 424(b) under the Act; to make no further amendment or any supplement to the
Registration Statement or Final Prospectus as amended or supplemented after the Applicable Time and
prior to the Remarketing Settlement Date for the Remarketed Securities unless the Remarketing Agents
for such Remarketed Securities shall have had a reasonable opportunity to review and comment upon
any such amendment or supplement prior to any filing thereof; to advise the Remarketing Agents,
promptly after it receives notice thereof, of the time when any amendment to the Registration
Statement has been filed or becomes effective or any supplement to the Final Prospectus or any
amended Final Prospectus has been filed and to furnish the Remarketing Agents with copies thereof;
to file promptly all reports and any definitive proxy or information statements required to be filed
by the Company with the Commission pursuant to Section 13(a), 13(c), 14 or 15(d) of the Exchange Act
for so long as the delivery of a prospectus is required in connection with the Remarketing of such
Remarketed Securities and, during such same period, to advise the Remarketing Agents, promptly after
it receives notice thereof, of (i) the issuance by the Commission of any stop order or of any order
preventing or suspending the use of the Final Prospectus, (ii) the suspension of the qualification
of such Remarketed Securities for Remarketing in any jurisdiction or of the initiation or
threatening of any proceeding for any such purpose, or (iii) any request by the Commission for the
amending or supplementing of the Registration Statement or Final Prospectus or for additional
information; and, in the event of the issuance of any stop order or of any order preventing or
suspending the use of the Final Prospectus or suspending any such qualification, promptly to use its
best efforts to obtain the withdrawal of such order;

(b) To give the Remarketing Agents notice of any filings made pursuant to the Exchange Act or the
regulations of the Commission thereunder within forty-eight hours prior to the Applicable Time; to
give the Remarketing Agents notice of its intention to make any such filing from the Applicable Time
to the Remarketing Settlement Date and to furnish the Remarketing Agents with copies of any such
documents a reasonable amount of time prior to such proposed filing. The Company shall prepare the
Final Term Sheet and file such Final Term Sheet as an Issuer Free Writing Prospectus within two
Business Days after the Remarketing Date; provided that the Company shall furnish the Remarketing
Agents with copies of any such Final Term Sheet a reasonable amount of time prior to such proposed
filing and will not use or file any such document to which the Remarketing Agents or counsel to the
Remarketing Agents shall object; 18
<!-- page 19 -->
(c) Promptly from time to time to take such action as the Remarketing Agents may reasonably request
to qualify the Remarketed Securities for offering and sale under the securities laws of such
jurisdictions as the Remarketing Agents may reasonably request and to comply with such laws so as to
permit the continuance of sales and dealings therein in such jurisdictions for so long as may be
necessary to complete the distribution of such Remarketed Securities, provided that in connection
therewith the Company shall not be required to qualify as a foreign corporation, to file a general
consent to service of process in any jurisdiction or to subject itself to taxation in respect of
doing business in any jurisdiction in which it is not otherwise subject;

(d) To furnish to the Remarketing Agents a copy of each proposed Issuer Free Writing Prospectus
prepared by or on behalf of, used by, or referred to by the Company and not to use or refer to any
proposed Issuer Free Writing Prospectus to which the Remarketing Agents reasonably object; if at any
time following issuance of an Issuer Free Writing Prospectus there occurred or occurs an event or
development as a result of which such Issuer Free Writing Prospectus conflicted or would conflict
with the information contained in the Registration Statement, the Disclosure Package, the Final
Prospectus or any Preliminary Prospectus or, when taken together with the Disclosure Package and any
other such Issuer Free Writing Prospectus, included or would include an untrue statement of a
material fact or omitted or would omit to state a material fact necessary in order to make the
statements therein, in the light of the circumstances prevailing at that subsequent time, not
misleading, to promptly notify the Remarketing Agents and, if requested by the Remarketing Agents,
to promptly amend or supplement, at its own expense, such Issuer Free Writing Prospectus to
eliminate or correct such conflict, untrue statement or omission; provided, however, that this
covenant shall not apply to any statements or omissions in an Issuer Free Writing Prospectus made in
reliance upon and in conformity with information furnished in writing to the Company by any
Remarketing Agent expressly for use therein;

(e) To furnish the Remarketing Agents with copies of any Issuer Free Writing Prospectus or the Final
Prospectus in such quantities as the Remarketing Agents may from time to time reasonably request,
and if, at any time prior to the earlier of (i) the completion of the distribution of the Remarketed
Securities and (ii) the expiration of nine months after the date of the Final Prospectus, any event
shall have occurred as a result of which any Issuer Free Writing Prospectus or the Final Prospectus
as then amended or supplemented would include an untrue statement of a material fact or omit to
state any material fact necessary in order to make the statements therein, in the light of the
circumstances under which they were made when such Issuer Free Writing Prospectus or the Final
Prospectus were delivered, not misleading, or, if for any 19
<!-- page 20 -->
other reason it shall be necessary during such period to amend or supplement any Issuer Free Writing
Prospectus or the Final Prospectus or to file under the Exchange Act any document incorporated by
reference in any Issuer Free Writing Prospectus or the Final Prospectus in order to comply with the
Act or the Exchange Act, (i) to notify the Remarketing Agents and (ii) upon their request to prepare
and furnish without charge to each Remarketing Agent and to any dealer in securities as many copies
as such Remarketing Agent may from time to time reasonably request of an amended Issuer Free Writing
Prospectus or a supplement to the Final Prospectus or an amended Final Prospectus which will correct
such statement or omission or effect such compliance; and any Issuer Free Writing Prospectus and the
Final Prospectus and any amendments or supplements thereto furnished to the Remarketing Agents shall
be identical to the electronically transmitted copies thereof filed with the Commission pursuant to
EDGAR, except to the extent permitted by Regulation S-T;

(f) To make generally available to securityholders of the Company as soon as practicable, but in any
event not later than eighteen months after the effective date of the Registration Statement (as
defined in Rule 158(c) under the Act), an earnings statement of the Company and its subsidiaries
(which need not be audited) complying with Section 11(a) of the Act and the rules and regulations
thereunder (including, at the option of the Company, Rule 158);

(g) During the period beginning from the Applicable Time and continuing to and including the
Remarketing Settlement Date for the Remarketed Securities, not to offer, sell, contract to offer or
sell or otherwise dispose of any debt securities of the Company having pricing characteristics
similar to the Securities exceeding an aggregate principal amount of $3 billion, except, for the
avoidance of doubt, debt securities issued under the Global Medium Term Note Program of Metropolitan
Life Global Funding I, Global Medium Term Note Program of MetLife Institutional Funding II, or any
commercial paper program of, or sponsored by, the Company or any subsidiaries, without the prior
written consent of the Remarketing Agents, which consent shall not be unreasonably withheld;

(h) During a period of five years from the effective date of the Registration Statement, to furnish
to the Remarketing Agents copies of all reports or other communications (financial or other)
furnished to stockholders of the Company, and to furnish to the Remarketing Agents as soon as they
are available, copies of any reports and financial statements furnished to or filed with the
Commission or any national securities exchange on which the Securities or any class of securities of
the Company is listed (such financial statements to be on a consolidated basis to the extent the
accounts of the Company and its subsidiaries are consolidated in reports furnished to its
stockholders generally or to the 20
<!-- page 21 -->
Commission), provided that reports and financial statements furnished to or filed with the
Commission, and publicly available on EDGAR, or furnished on the Company's website, shall be deemed
to have been furnished to the Remarketing Agents under this Section 3(h);

(i) The Company agrees that, unless it obtains the prior consent of the Remarketing Agents, and each
Remarketing Agent represents and agrees that, unless it obtains the prior consent of the Company, it
has not made and will not make any offer relating to the Remarketed Securities that would constitute
an Issuer Free Writing Prospectus (other than, for the avoidance of doubt, any Bloomberg L.P. or
other electronic communication regarding any preliminary term sheets or comparable bond prices and
the Final Term Sheet filed pursuant to Section 3(b) hereto). Each Remarketing Agent agrees, unless
it obtains the prior consent of the Company, not to take any action that would result in the Company
being required to file with the Commission under Rule 433(d) under the Act a free writing prospectus
prepared by or on behalf of each Remarketing Agent that otherwise would not be required to be filed
by the Company thereunder but for the action of such Remarketing Agent (other than, for the
avoidance of doubt, the Final Term Sheet filed pursuant to Section 3(b) hereto); and

(j) The Company agrees to promptly notify the Remarketing Agents if A.M. Best & Co., Fitch Ratings,
Ltd., Moody's Investors Service, Inc. or Standard & Poor's Ratings Services has given notice of any
intended or potential downgrading or any review for a possible change of its rating of any debt
security or the financial strength or the claims paying ability of the Company or any Significant
Subsidiary.

4. Fees and Expenses. The Company covenants and agrees with the Remarketing Agents that the Company
will pay or cause to be paid the following: (i) the fees, disbursements and expenses of counsel and
accountants to the Company in connection with the registration of the Securities under the Act and
all other expenses in connection with the preparation, printing and filing of the Registration
Statement, any Preliminary Prospectus, any Issuer Free Writing Prospectus and the Final Prospectus
and any amendments and supplements thereto and the mailing and delivering of copies thereof to the
Remarketing Agents and dealers; (ii) the cost of printing or producing the Transaction Documents,
any Blue Sky Survey and any other documents in connection with the Remarketing of the Remarketed
Securities; (iii) all expenses in connection with the qualification of the Remarketed Securities for
offering and sale under state securities laws and insurance securities laws as provided in Section
3(b) hereof, including the reasonable fees and disbursements of counsel for the Remarketing Agents
in connection with such qualification and in connection with the Blue Sky Survey; (iv) the filing
fees incident to, and the fees and disbursements of counsel for the Remarketing Agents in connection
with, securing any required review by the Financial Industry Regulatory 21
<!-- page 22 -->
Authority of the terms of the sale of the Remarketed Securities; (v) any fees charged by securities
rating services for rating the Remarketed Securities; (vi) the cost of preparing the Remarketed
Securities; (vii) the fees and expenses of any trustee, paying agent or transfer agent and the fees
and disbursements of counsel for any such trustee, paying agent or transfer agent in connection with
the Remarketing; (viii) any travel expenses of the Company's officers and employees and any other
expenses of the Company in connection with attending or hosting meetings with respect to this
Remarketing; and (ix) all other costs and expenses incident to the performance of the obligations of
the Company hereunder which are not otherwise specifically provided for in this Section. Except as
provided in this Section, and Sections 6 and 13 hereof, the Remarketing Agents will pay all of their
own costs and expenses, including the fees of their counsel, stock transfer taxes on resale of any
of the Remarketed Securities by them and any advertising expenses connected with Remarketing of the
Remarketed Securities that they may make.

5. Conditions to Remarketing Agents' Obligations. The obligations of the Remarketing Agents shall be
subject, in their discretion, to the condition that all representations and warranties and other
statements of the Company herein or in certificates of any officer of the Company or any subsidiary
of the Company delivered pursuant to the provisions hereof are, at the Applicable Time, the
Remarketing Date and the Remarketing Settlement Date (in each case, to the extent such
representations and warranties are applicable as of such date), true and correct, the condition that
the Company shall have performed all of its covenants and other obligations included hereunder and
in the other Transaction Documents to be performed at or before the date hereof, the Applicable
Time, the Remarketing Date and the Remarketing Settlement Date, and the following additional
conditions:

(a) The Final Prospectus shall have been filed with the Commission pursuant to Rule 424(b) under the
Act within the applicable time period prescribed for such filing by the rules and regulations under
the Act and in accordance with Section 3(a) hereof; the Final Term Sheet shall have been filed with
the Commission pursuant to Rule 433(d); no stop order suspending the effectiveness of the
Registration Statement or any part thereof shall have been issued and no proceeding for that purpose
shall have been initiated or threatened by the Commission; and all requests for additional
information on the part of the Commission shall have been complied with to the Remarketing Agents'
reasonable satisfaction;

(b) All corporate proceedings and other legal matters incident to the authorization, form and
validity of the Transaction Documents, the Remarketed Securities, the Securities, the Final
Prospectus, the Registration Statement and all other legal matters relating to this Remarketing
Agreement and the transactions contemplated hereby shall be reasonably satisfactory in all material
respects to counsel to the Remarketing Agents, and the Company shall have furnished to such counsel
all documents and information that they may reasonably request to enable them to pass upon such
matters; 22
<!-- page 23 -->
(c) Debevoise & Plimpton LLP, counsel for the Remarketing Agents, shall have furnished to the
Remarketing Agents such written opinion, dated the Remarketing Settlement Date, as the Remarketing
Agents may reasonably request, and such counsel shall have received such papers and information as
they may reasonably request to enable them to pass upon such matters;

(d) Willkie Farr & Gallagher LLP, counsel for the Company, shall have furnished to the Remarketing
Agents their written opinions, each opinion dated the Remarketing Settlement Date, substantially in
the form attached hereto as Annex I-A with respect to certain corporate and tax matters, and Annex
I-B with respect to the Registration Statement, Disclosure Package and the Final Prospectus;

(e) Matthew Ricciardi, Chief Counsel -General Corporate of MetLife Group, Inc., an affiliate of the
Company, shall have furnished to the Remarketing Agents his written opinion, dated the Remarketing
Settlement Date, substantially in the form attached hereto as Annex II;

(f) The Company will furnish the Remarketing Agents with such conformed copies of such opinions,
certificates, letters and documents as the Remarketing Agents reasonably request;

(g) (i) On the Remarketing Date, Deloitte & Touche LLP shall have furnished to the Remarketing
Agents a letter, dated the Remarketing Date, in form and substance reasonably satisfactory to the
Remarketing Agents, confirming that they are independent registered public accountants with respect
to the Company and the Company's subsidiaries within the meaning of the Act and the Exchange Act and
the respective applicable published rules and regulations thereunder, and (ii) on the Remarketing
Settlement Date, Deloitte & Touche LLP shall have furnished to the Remarketing Agents a letter,
dated the Remarketing Settlement Date, in form and substance reasonably satisfactory to the
Remarketing Agents, that reaffirms the statements made in the letter furnished pursuant to subclause
(i) of this Section 5(g), except that the specified date referred to shall be a date not more than
three Business Days prior to the Remarketing Settlement Date;

(h) On or after the Remarketing Date, (i) neither the Company nor any Significant Subsidiary shall
have sustained since the date of the latest audited financial statements included or incorporated by
reference in the Disclosure Package any loss or interference with its business from fire, explosion,
flood or 23
<!-- page 24 -->
other calamity, whether or not covered by insurance, or from any labor dispute or court or
governmental action, order or decree, otherwise than as set forth or contemplated in the Disclosure
Package, and (ii) since the respective dates as of which information is given in the Disclosure
Package, there shall not have been any change in the surplus of any Significant Subsidiary or the
capital stock of the Company or any increase in the long-term debt of the Company and its
subsidiaries considered as a whole, or any change, or any development involving a prospective
change, in or affecting the business, financial position, reserves, surplus, equity or results of
operations of the Company and the Significant Subsidiaries considered as a whole, otherwise than as
set forth or contemplated in the Disclosure Package, the effect of which, in any such case described
in clause (i) or (ii), is in the judgment of the Remarketing Agents so material and adverse as to
make it impracticable or inadvisable to proceed with the Remarketing of the Remarketed Securities on
the terms and in the manner contemplated in the Final Prospectus;

(i) On or after the Remarketing Date (i) no downgrading shall have occurred in the rating accorded
the debt securities of the Company or any Significant Subsidiary or the financial strength or claims
paying ability of any Significant Subsidiary by A.M. Best & Co., Fitch Ratings, Ltd., Moody's
Investors Service, Inc. or Standard & Poor's Ratings Services, and (ii) no such organization shall
have publicly announced that it has under surveillance or review, with possible negative
implications, or shall have given notice of its intended or potential downgrading of, its rating of
any debt security or the financial strength or the claims paying ability of any Significant
Subsidiary, the effect of which, in any such case described in clause (i) or (ii), is in the
judgment of the Remarketing Agents so material and adverse as to make it impracticable or
inadvisable to proceed with the Remarketing of the Remarketed Securities on the terms and in the
manner contemplated in the Final Prospectus;

(j) On or after the Remarketing Date, there shall not have occurred any of the following: (i) a
change in U.S. or international financial, political or economic conditions or currency exchange
rates or exchange controls as would, in the reasonable judgment of the Remarketing Agents, be likely
to prejudice materially the success of the Remarketing of the Remarketed Securities, whether in the
primary market or in respect of dealings in the secondary market; (ii) a suspension or material
limitation in trading in securities generally on the New York Stock Exchange; (iii) a suspension or
material limitation in trading in the Company's securities on the New York Stock Exchange; (iv) a
suspension or material limitation in clearing and/or settlement in securities generally; (v) a
general moratorium on commercial banking activities declared by either Federal or New York State
authorities; or (vi) the material outbreak or escalation of hostilities involving the United States
or the declaration by the United States of a 24
<!-- page 25 -->
national emergency or war or any other national or international calamity or emergency (including
without limitation as a result of an act of terrorism) if the effect of any such event specified in
this clause (vi) in the judgment of the Remarketing Agents makes it impracticable or inadvisable to
proceed with the Remarketing of the Remarketed Securities on the terms and in the manner
contemplated in the Final Prospectus;

(k) The Company shall have complied with any request by the Remarketing Agents with respect to the
furnishing of copies of the Final Prospectus in compliance with the provisions of Section 3(e), as
the case may be; and

(l) At the Remarketing Settlement Date, the Remarketing Agents shall have received a certificate of
the Chief Accounting Officer of the Company, dated as of the Remarketing Settlement Date,
substantially in the form of Annex IV hereto.

6. Indemnification and Contribution.

(a) The Company will indemnify and hold harmless each Remarketing Agent, its partners, directors and
officers and each person, if any, who controls such Remarketing Agent within the meaning of either
Section 15 of the Act or Section 20 of the Exchange Act, against any losses, claims, damages or
liabilities, joint or several, to which such Remarketing Agent may become subject, under the Act or
otherwise, insofar as such losses, claims, damages or liabilities (or actions in respect thereof)
arise out of or are based upon an untrue statement or alleged untrue statement of a material fact
contained in (i) the Registration Statement or any amendment or supplement (when considered together
with the document to which such supplement relates) thereto, or arise out of or are based upon the
omission or alleged omission to state therein a material fact required to be stated therein or
necessary to make the statements therein not misleading or (ii) any Preliminary Prospectus, Pricing
Prospectus, any Issuer Free Writing Prospectus or the Final Prospectus or any amendment or
supplement (when considered together with the document to which such supplement relates) thereto, or
any "issuer information" filed or required to be filed pursuant to Rule 433(d) under the Act, or
arise out of or are based upon the omission or alleged omission to state therein a material fact
required to be stated therein or necessary to make the statements therein, in light of the
circumstances under which they were made, not misleading, and will reimburse each Remarketing Agent
for any legal or other expenses reasonably incurred by such Remarketing Agent in connection with
investigating or defending any such action or claim as such expenses are incurred; provided,
however, that the Company shall not be liable in any such case to the extent that any such loss,
claim, damage or liability (or action in respect thereof) arises out of or is based upon an untrue
statement or alleged untrue statement or omission or alleged omission made in any Preliminary
Prospectus, any Issuer Free Writing Prospectus, Pricing Prospectus, the Registration Statement or
the 25
<!-- page 26 -->
Final Prospectus, or any such amendment or supplement(s) in reliance upon and in conformity with
written information furnished to the Company by any Remarketing Agent expressly for use therein.

(b) Each Remarketing Agent will, severally and not jointly, indemnify and hold harmless the Company,
its directors and officers who sign the Registration Statement and each person, if any, who controls
the Company within the meaning of Section 15 of the Act or Section 20 of the Exchange Act against
any losses, claims, damages or liabilities (or actions in respect thereof) to which the Company may
become subject, under the Act or otherwise, insofar as such losses, claims, damages or liabilities
(or actions in respect thereof) arise out of or are based upon an untrue statement or alleged untrue
statement of a material fact contained in any Preliminary Prospectus, any Issuer Free Writing
Prospectus, Pricing Prospectus, the Registration Statement, or the Final Prospectus, or any
amendment or supplement (when considered together with the document to which such supplement
relates) thereto, or arise out of or are based upon the omission or alleged omission to state
therein a material fact required to be stated therein or necessary to make the statements therein
not misleading, in each case to the extent, but only to the extent, that such untrue statement or
alleged untrue statement or omission or alleged omission was made in any Preliminary Prospectus, any
Issuer Free Writing Prospectus, Pricing Prospectus, the Registration Statement, the Final Prospectus
or any such amendment or supplement in reliance upon and in conformity with written information
furnished to the Company by such Remarketing Agent expressly for use therein; and will reimburse the
Company for any legal or other expenses reasonably incurred by the Company in connection with
investigating or defending any such action or claim as such expenses are incurred.

(c) Promptly after receipt by an indemnified party under subsection (a) or (b) above of notice of
the commencement of any action, such indemnified party shall, if a claim in respect thereof is to be
made against the indemnifying party under such subsection, notify the indemnifying party in writing
of the commencement thereof; the omission so to notify the indemnifying party shall relieve it from
any liability which it may have to any indemnified party under such subsection, to the extent the
indemnifying party is actually materially prejudiced by such omission. In case any such action shall
be brought against any indemnified party and it shall notify the indemnifying party of the
commencement thereof, the indemnifying party shall be entitled to participate therein and, to the
extent that it shall wish, jointly with any other indemnifying party similarly notified, to assume
the defense thereof, with counsel reasonably satisfactory to such indemnified party (who shall not,
except with the consent of the indemnified party, be counsel to the indemnifying party or any other
indemnified party), and, after notice from the indemnifying party to such indemnified party of its
election so to assume the defense thereof, the indemnifying party shall not be liable to such
indemnified party under such subsection for any legal expenses of other counsel or any other
expenses, in each case subsequently incurred by such indemnified party, in connection with the
defense thereof 26
<!-- page 27 -->
other than reasonable costs of investigation, unless (i) the indemnifying party and such indemnified
party shall have mutually agreed to the contrary, (ii) the indemnifying party has failed within a
reasonable time to retain counsel reasonably satisfactory to such indemnified party or (iii) the
named parties in any such proceeding (including any impleaded parties) include both the indemnifying
party and such indemnified party and representation of both parties by the same counsel would be
inappropriate due to actual or potential differing interests between them. No indemnifying party
shall, without the prior written consent of the indemnified party, effect the settlement or
compromise of, or consent to the entry of any judgment with respect to, any pending or threatened
action or claim in respect of which indemnification or contribution may be sought hereunder (whether
or not the indemnified party is an actual or potential party to such action or claim) unless such
settlement, compromise or judgment (i) includes an unconditional release of the indemnified party
from all liability arising out of such action or claim and (ii) does not include a statement as to
or an admission of fault, culpability or a failure to act, by or on behalf of any indemnified party.
In no event shall the indemnifying party be liable for fees and expenses of more than one counsel
(in addition to any local counsel) separate from their own counsel for all indemnified parties in
connection with any one action or separate but similar or related actions in the same jurisdiction
arising out of the same allegations or circumstances.

(d) If the indemnification provided for in this Section 6 is unavailable to or insufficient to hold
harmless an indemnified party under subsection (a) or (b) above in respect of any losses, claims,
damages or liabilities (or actions in respect thereof) referred to therein, other than due to the
express provisions thereof, then each indemnifying party shall contribute to the amount paid or
payable by such indemnified party as a result of such losses, claims, damages or liabilities (or
actions in respect thereof) in such proportion as is appropriate to reflect the relative benefits
received by the Company on the one hand and the Remarketing Agents on the other from the Remarketing
of the Remarketed Securities to which any such loss, claim, damage or liability (or action in
respect thereof) relates. If, however, the allocation provided by the immediately preceding sentence
is not permitted by applicable law, then each indemnifying party shall contribute to such amount
paid or payable by such indemnified party in such proportion as is appropriate to reflect not only
such relative benefits but also the relative fault of the Company on the one hand and the
Remarketing Agents of the applicable Securities on the other in connection with the statements or
omissions which resulted in such losses, claims, damages or liabilities (or actions in respect
thereof), as well as any other relevant equitable considerations. The relative benefits received by
the Company on the one hand and the Remarketing Agents on the other shall be deemed to be in the
same proportion as the total net proceeds from such offering (before deducting expenses) received by
the Company bear to the total Remarketing Fee received by the Remarketing Agents, as set forth in
the table on the cover page of the Final Prospectus. 27
<!-- page 28 -->
The relative fault shall be determined by reference to, among other things, whether the untrue or
alleged untrue statement of a material fact or the omission or alleged omission to state a material
fact relates to information supplied by the Company on the one hand or the Remarketing Agents on the
other and the parties' relative intent, knowledge, access to information and opportunity to correct
or prevent such statement or omission. The Company and the Remarketing Agents agree that it would
not be just and equitable if contributions pursuant to this subsection (d) were determined by pro
rata allocation (even if the Remarketing Agents were treated as one entity for such purpose) or by
any other method of allocation which does not take account of the equitable considerations referred
to above in this subsection (d). The amount paid or payable by an indemnified party as a result of
the losses, claims, damages or liabilities (or actions in respect thereof) referred to above in this
subsection (d) shall be deemed to include any legal or other expenses reasonably incurred by such
indemnified party in connection with investigating or defending any such action or claim.
Notwithstanding the provisions of this subsection (d), no Remarketing Agent shall be required to
contribute any amount in excess of the amount by which the total price at which the applicable
Securities remarketed by it and distributed to the public were offered to the public exceeds the
amount of any damages which such Remarketing Agent has otherwise been required to pay by reason of
such untrue or alleged untrue statement or omission or alleged omission. No person guilty of
fraudulent misrepresentation (within the meaning of Section 11(f) of the Act) shall be entitled to
contribution from any person who was not guilty of such fraudulent misrepresentation. The
obligations of the Remarketing Agents in this subsection (d) to contribute are several in proportion
to their respective obligations with respect to such Remarketed Securities and not joint.

(e) The obligations of the Company under this Section 6 shall be in addition to any liability which
the Company may otherwise have and shall extend, upon the same terms and conditions, to each person,
if any, who controls any Remarketing Agent within the meaning of the Act. The obligations of the
Remarketing Agents under this Section 6 shall be in addition to any liability which the respective
Remarketing Agent may otherwise have and shall extend, upon the same terms and conditions, to each
officer and director of the Company (including any person who, with his consent, is named in the
Registration Statement as about to become a director of the Company) and to each person, if any, who
controls the Company within the meaning of the Act.

7. Resignation and Removal of the Remarketing Agents. A Remarketing Agent may resign and be
discharged from its duties and obligations hereunder, and the Company may remove any or all of the
Remarketing Agents, by giving five (5) Business Days' prior written notice to the Stock Purchase
Contract Agent and, in the case of a removal, to the Remarketing Agents; provided that no such
resignation nor any removal of all the Remarketing Agents shall become effective until the Company
shall have appointed at least one nationally recognized broker-dealer as successor to the
Remarketing Agents, and such successor Remarketing Agent shall have entered into a 28
<!-- page 29 -->
letter substantially in the form of Annex III hereof with the Company and the Stock Purchase
Contract Agent in which it shall have agreed to conduct the Remarketing in accordance with the
Remarketing Procedures. The provisions of this Section 7 shall survive the resignation or removal of
the Remarketing Agents pursuant to this Remarketing Agreement.

8. New Remarketing Agents. The Company may appoint any institution or institutions as new
Remarketing Agent(s) hereunder (each a "New Remarketing Agent") in respect of the Remarketing in
which event, upon the confirmation by such institution through a letter to the Company and the Stock
Purchase Contract Agent confirming acceptance of such nomination by the New Remarketing Agent
substantially in the form of Annex III hereof, such New Remarketing Agent shall become a party
hereto, unless otherwise provided for herein, with all the authority, rights, powers, duties and
obligations as if originally named as Remarketing Agent hereunder. The Company will notify the
Remarketing Agent(s) appointed in respect of the Remarketing of the Remarketed Securities and the
Stock Purchase Contract Agent of a change in the identity of other Remarketing Agents appointed or
who have resigned in respect of the Remarketing of the Remarketed Securities generally as soon as
reasonably practicable.

9. Offering Restrictions. Each Remarketing Agent acknowledges, represents and agrees and each
additional Remarketing Agent appointed pursuant to Section 8 of this Remarketing Agreement will be
required to acknowledge, represent and agree that it has not remarketed or delivered and it will not
remarket or deliver, any of the Remarketed Securities, in or from any jurisdiction except under
circumstances that are reasonably designed to result in compliance with the applicable securities
laws and regulations thereof. In particular, each Remarketing Agent acknowledges, represents and
agrees and each additional Remarketing Agent appointed pursuant to Section 8 of this Remarketing
Agreement will be required to acknowledge, represent and agree as set forth in Annex V to this
Remarketing Agreement.

10. Dealing in the Remarketed Securities. Each Remarketing Agent, when acting hereunder, or when
acting in its individual or any other capacity, may, to the extent permitted by law, buy, sell, hold
or deal in any of the Remarketed Securities. The Remarketing Agents may exercise any vote or join in
any action which any beneficial owner of Remarketed Securities may be entitled to exercise or take
pursuant to the Indenture with like effect as if they did not act in any capacity hereunder. The
Remarketing Agents, in their individual capacities, either as principal or agent, may also engage in
or have an interest in any financial or other transaction with the Company as freely as if they did
not act in any capacity hereunder.

11. Termination of Remarketing Agreement. This Remarketing Agreement shall terminate (i) in the
event of a Remarketing that is not a Successful Remarketing or (ii) as to any Remarketing Agent who
resigns or is removed, on the effective date of the resignation or removal of such Remarketing Agent
pursuant to Section 7. In addition, the 29
<!-- page 30 -->
obligations of the Remarketing Agents may be terminated by them by notice given to the Company prior
to 12:00 noon, New York City time on the Remarketing Settlement Date if, prior to that time, any of
the applicable conditions precedent to the obligations of the Remarketing Agents described in
Section 5 hereof shall have failed to occur.

12. Survival. Notwithstanding any such termination set forth in Section 11 hereof, the obligations
set forth in Section 4 hereof shall survive and remain in full force and effect until all amounts
payable under said Section 4 shall have been paid in full. In addition, the former Remarketing
Agents shall be entitled to the rights and benefits under Section 6 of this Remarketing Agreement
notwithstanding the replacement or resignation of the Remarketing Agents. The respective
indemnities, agreements, representations, warranties and other statements of the Company and the
several Remarketing Agents, as set forth in this Remarketing Agreement or made by or on behalf of
them, respectively, pursuant to this Remarketing Agreement, shall remain in full force and effect,
regardless of any investigation (or any statement as to the results thereof) made by or on behalf of
any Remarketing Agent or any controlling person of any Remarketing Agent, the Company or any officer
or director or controlling person of the Company and shall survive delivery of and payment for the
Securities.

13. Notices. All statements, requests, notices and agreements hereunder shall be in writing and
shall be deemed to have been duly given if mailed or transmitted by any standard form of
telecommunication; notices to the Remarketing Agents shall be directed to Deutsche Bank Securities
Inc., 60 Wall Street, New York, NY 10005, with a copy to Debevoise & Plimpton LLP, 919 Third Avenue,
New York, New York 10022, attention of Peter J. Loughran, Esq.; notices to the Company shall be
delivered or sent by mail, telex or facsimile transmission to the address of the Company set forth
in the Registration Statement, Attention: General Counsel, with a copy to Willkie Farr & Gallagher
LLP, 787 Seventh Avenue, New York, NY 10019, attention John M. Schwolsky, Esq. and Vladimir Nicenko,
Esq.; notices to the Trustee shall be delivered or sent by mail or facsimile transmission to The
Bank of New York Mellon Trust Company, N.A., 2 North LaSalle Street, Suite 1020, Chicago, Illinois
60602, telecopy: (312) 827-8542; notices to the Stock Purchase Contract Agent shall be delivered or
sent by mail or facsimile transmission to Deutsche Bank Trust Company Americas, Trust and Securities
Services, 60 Wall Street, 16th Floor, MS: NYC60-2710, New York, NY 10005, telecopy: (732) 578-4635;
and notices to the Collateral Agent or the Custodial Agent shall be delivered or sent by mail or
facsimile transmission to Deutsche Bank Trust Company Americas, Trust and Securities Services, 60
Wall Street, 16th Floor, MS: NYC60-2710, New York, NY 10005, telecopy: (732) 578-4635. Any such
statements, requests, notices or agreements shall take effect at the time of receipt thereof.

14. Successors and Assigns. This Remarketing Agreement and the Pricing Agreement shall be binding
upon, and inure solely to the benefit of, the Remarketing Agents and the Company, and, to the extent
provided in Sections 6 and 12 hereof, the 30
<!-- page 31 -->
officers and directors of the Company and each person who controls the Company or any Remarketing
Agent, and their respective heirs, executors, administrators, successors and assigns, and no other
person shall acquire or have any right under or by virtue of this Remarketing Agreement or the
Pricing Agreement. No purchaser of any of the Securities pursuant to this Remarketing Agreement
shall be deemed a successor or assign by reason merely of such purchase.

15. GOVERNING LAW. THIS REMARKETING AGREEMENT AND THE PRICING AGREEMENT SHALL BE GOVERNED BY AND
CONSTRUED IN ACCORDANCE WITH THE LAWS OF THE STATE OF NEW YORK, WITHOUT REGARD TO PRINCIPLES OF
CONFLICTS OF LAW TO THE EXTENT THAT SUCH PRINCIPLES WOULD REQUIRE OR PERMIT THE APPLICATION OF LAWS
OF ANOTHER JURISDICTION.

16. Consent to Jurisdiction. The Company agrees that any legal suit, action or proceeding against
the Company brought by the Remarketing Agents or by any person, if any, who controls the Remarketing
Agents within the meaning of Section 15 of the Act or Section 20 of the Exchange Act, arising out of
or based upon this Remarketing Agreement or the transactions contemplated hereby may be instituted
in any state or Federal court in the Borough of Manhattan, The City of New York, New York, and, to
the fullest extent permitted by applicable law, waives any objection which it may now or hereafter
have to the laying of venue of any such proceeding, and irrevocably submits to the non-exclusive
jurisdiction of such courts in any suit, action or proceeding.

17. Amendment. This Remarketing Agreement may not be amended or modified except by an instrument in
writing signed by, or on behalf of, each of the parties hereto; provided, however, that in the event
that the Securities to be remarketed, or any portion thereof, are modified in such a way so that
they no longer require registration under the Act, the Company, the Remarketing Agents and the Stock
Purchase Contract Agent hereby agree to promptly enter into an amendment to this Remarketing
Agreement containing such representations, warranties and covenants as would normally be required to
more accurately reflect an offering of unregistered securities.

18. Counterparts. This Remarketing Agreement and the Pricing Agreement may be executed by any one or
more of the parties hereto and thereto in any number of counterparts, each of which shall be deemed
to be an original, but all such counterparts shall together constitute one and the same instrument.

19. No Advisory or Fiduciary Relationship. The Company acknowledges and agrees that (a) the
Remarketing of the Remarketed Securities pursuant to this Remarketing Agreement is an arm's-length
commercial transaction between the Company, on the one hand, and the several Remarketing Agents, on
the other hand, (b) in connection with any Remarketing contemplated by this Remarketing Agreement
and the Pricing Agreement and the process leading to any such transaction, each Remarketing 31
<!-- page 32 -->
Agent is and has been acting solely as a principal and is not the agent or fiduciary of the Company,
or its stockholders, creditors, employees or any other party, (c) no Remarketing Agent has assumed
or will assume an advisory or fiduciary responsibility in favor of the Company with respect to any
such Remarketing contemplated hereby or the process leading thereto (irrespective of whether such
Remarketing Agent has advised or is currently advising the Company on other matters) and no
Remarketing Agent has any obligation to the Company with respect to such Remarketing contemplated
hereby except the obligations expressly set forth in this Remarketing Agreement and the Pricing
Agreement, (d) the Remarketing Agents and their respective affiliates may be engaged in a broad
range of transactions that involve interests that differ from those of the Company, (e) the Company
agrees that it will not claim that the Remarketing Agents, or any of them, have rendered advisory
services of any nature or respect, or owe a fiduciary or similar duty to the Company, in connection
with such transaction or the process leading thereto and (f) the Remarketing Agents have not
provided any legal, accounting, regulatory or tax advice with respect to the offering contemplated
hereby and the Company has consulted its own legal, accounting, regulatory and tax advisors to the
extent it deemed appropriate.

20. Entire Agreement. This Remarketing Agreement supersedes all prior agreements and understandings
(whether written or oral) between the Company and the Remarketing Agents, or any of them, with
respect to the subject matter hereof.

21. Waiver of Jury Trial. The Company and each of the Remarketing Agents hereby irrevocably waives,
to the fullest extent permitted by applicable law, any and all right to trial by jury in any legal
proceeding arising out of or relating to this Remarketing Agreement or the transactions contemplated
hereby.

22. Rights of the Stock Purchase Contract Agent. Notwithstanding any other provision of this
Remarketing Agreement, the Stock Purchase Contract Agent, in connection with its rights and duties
hereunder, shall be entitled to all the rights, protections and privileges granted to the Stock
Purchase Contract Agent in the Stock Purchase Contract Agreement.

[Signature pages follow] 32
<!-- page 33 -->
Very truly yours,

METLIFE, INC.

By: /s/ Marlene B. Debel Name: Marlene B. Debel Title: Senior Vice President and Treasurer

[Signature page to the Remarketing Agreement]

DEUTSCHE BANK TRUST COMPANY AMERICAS, as Stock Purchase Contract Agent
<!-- page 34 -->
By: /s/ Carol Ng Name: Carol Ng Title: Vice President

By: /s/ Anthony D'Amato Name: Anthony D'Amato Title: Associate

[Signature page to the Remarketing Agreement]
<!-- page 35 -->
Accepted as of the date hereof on behalf of the Remarketing Agents: DEUTSCHE BANK SECURITIES INC.

By: /s/ Edward J. Sunoo Name: Edward J. Sunoo Title: Managing Director

By: /s/ Adam Raucher Name: Adam Raucher Title: Director

[Signature page to the Remarketing Agreement]
<!-- page 36 -->
SCHEDULE 1 TO REMARKETING AGREEMENT

None.
<!-- page 37 -->
ANNEX I(a)

FORM OF WILLKIE FARR & GALLAGHER LLP OPINION I(a)-1
<!-- page 38 -->
ANNEX I(b)

FORM OF WILLKIE FARR & GALLAGHER LLP NEGATIVE ASSURANCE LETTER I(b)-1
<!-- page 39 -->
ANNEX II

FORM OF MATTHEW RICCIARDI'S OPINION II-1
<!-- page 40 -->
ANNEX III

FORM OF ACCESSION LETTER

METLIFE, INC.

[Date]

[New Remarketing Agent] [Address]

Dear Sirs,

Remarketing of Series E Senior Component Debentures, Tranche 1, due 2018 and Series E Senior
Component Debentures, Tranche 2, due 2045 of MetLife, Inc. (the "Remarketed Securities")

The undersigned refers to the Remarketing Agreement, dated as of August 26, 2014 (the "Remarketing
Agreement") among ourselves as the Company, Deutsche Bank Trust Company Americas, as Stock Purchase
Contract Agent (the "Stock Purchase Contract Agent"), and the Remarketing Agents from time to time
party thereto, and have the pleasure of inviting you to become a Remarketing Agent subject to and in
accordance with the terms of the Remarketing Agreement, a copy of which has been supplied to you by
us. Please return to the Company a copy of this letter signed by an authorized signatory whereupon
you will become a Remarketing Agent for the purposes of the Remarketing Agreement with all the
authority, rights, powers, duties and obligations of a Remarketing Agent under the Remarketing
Agreement.

This letter is governed by, and shall be construed in accordance with, the laws of the State of New
York. The provisions of Sections 14 and 15 of the Remarketing Agreement shall apply to this letter
as if set out herein in full. III-1
<!-- page 41 -->
Yours faithfully, METLIFE, INC.

By: Name: Title:

Acknowledged as of the date hereof:

DEUTSCHE BANK TRUST COMPANY AMERICAS, as Stock Purchase Contract Agent By: Name: Title: By: Name:
Title: III-2
<!-- page 42 -->
CONFIRMATION

We hereby accept the appointment as a Remarketing Agent and accept all of the duties and obligations
under, and the terms and conditions of the Remarketing Agreement upon the terms of this letter.

We confirm that we are in receipt of all the documents which we have requested and have found them
to be satisfactory.

For the purposes of the Remarketing Agreement our communications details are as set out below. [NEW
REMARKETING AGENT]

By: Name: Title: Date: [ ]

Address: [ ]

Telex: [ ]

Facsimile: [ ]

Attention: [ ]

Copies to:

(i) All existing Remarketing Agents who have been appointed in respect of the Remarketing of the
Remarketed Securities.

(ii) The Stock Purchase Contract Agent. III-3
<!-- page 43 -->
ANNEX IV

METLIFE, INC. CHIEF ACCOUNTING OFFICER CERTIFICATE

METLIFE, INC. CHIEF ACCOUNTING OFFICER'S CERTIFICATE

MetLife, Inc. a Delaware corporation (the "Company"), does hereby certify, pursuant to Section 5(l)
of the Remarketing Agreement, dated August 26, 2014 (the "Remarketing Agreement"), by and among the
Company, Deutsche Bank Trust Company Americas, as Stock Purchase Contract Agent, and Deutsche Bank
Securities Inc. (together with the institutions appointed as Remarketing Agents pursuant to Section
8 of the Remarketing Agreement), that:

(i) the representations and warranties of the Company contained in Section 2 of the Remarketing
Agreement are true and correct in allrespects, as if made at and as of the date hereof; and

(ii) the Company has complied in all respects with all agreements and all conditions on its part to
be performed under the RemarketingAgreement and the other Transaction Documents at or prior to the
date hereof.

Willkie Farr & Gallagher LLP, counsel to the Company, may rely upon this certificate in delivering
its opinion pursuant to Section 5(d) of the Remarketing Agreement. Debevoise & Plimpton LLP, counsel
to the Remarketing Agents, may rely upon this certificate in delivering its opinion pursuant to
Section 5(c) of the Remarketing Agreement.

[Remainder of page intentionally left blank.] IV-1
<!-- page 44 -->
IN WITNESS WHEREOF, the undersigned has hereunto signed his name as of , 2014. METLIFE, INC.

By: Name: Peter M. Carlson

Title: Executive Vice President, Finance Operations and Chief Accounting Officer IV-1
<!-- page 45 -->
ANNEX V

OFFERING RESTRICTIONS

European Economic Area

In relation to each Member State of the European Economic Area which has implemented the Prospectus
Directive (each, a "Relevant Member State"), each Remarketing Agent has represented and agreed that
with effect from and including the date on which the Prospectus Directive is implemented in that
Relevant Member State it has not made and will not make an offer of Series E Debentures which are
the subject of the offering contemplated by this prospectus supplement and accompanying prospectus
to the public in that Relevant Member State other than:

(a) to any legal entity which is a qualified investor as defined in the Prospectus Directive;

(b) to fewer than 100 or, if the Relevant Member State has implemented the relevant provision of the
2010 PD Amending Directive, 150 natural or legal persons (other than qualified investors as defined
in the Prospectus Directive), as permitted under the Prospectus Directive, subject to obtaining the
prior consent of the other Remarketing Agents for any such offer; or

(c) in any other circumstances falling within Article 3(2) of the Prospectus Directive,

provided that no such offer of Series E Debentures shall require MetLife, Inc. or any Remarketing
Agent to publish a prospectus pursuant to Article 3 of the Prospectus Directive or supplement a
prospectus pursuant to Article 16 of the Prospectus Directive.

For the purposes of the above, (i) the expression an "offer of Series E Debentures to the public" in
relation to any Series E Debentures in any Relevant Member State means the communication in any form
and by any means of sufficient information on the terms of the offer and the Series E Debentures to
be offered so as to enable an investor to decide to purchase or subscribe for the Series E
Debentures, as the same may be varied in that Member State by any measure implementing the
Prospectus Directive in that Member State, (ii) the expression "Prospectus Directive" means
Directive 2003/71/EC (and amendments thereto, including the 2010 PD Amending Directive, to the
extent implemented in the Relevant Member State), and includes any relevant implementing measure in
the Relevant Member State and (iii) the expression "2010 PD Amending Directive" means Directive
2010/73/EU. V-1
<!-- page 46 -->
United Kingdom

Each Remarketing Agent has represented and agreed that it has only communicated or caused to be
communicated and will only communicate or cause to be communicated an invitation or inducement to
engage in investment activity (within the meaning of Section 21 of the Financial Services and
Markets Act 2000 ("FSMA")) received by it in connection with the issue or sale of the Series E
Debentures which are the subject of the offering contemplated by this prospectus supplement and the
accompanying prospectus in circumstances in which Section 21(1) of such Act does not apply to
MetLife, Inc., and that it has complied and will comply with all applicable provisions of the FSMA
with respect to anything done by it in relation to any Series E Debentures in, from or otherwise
involving the United Kingdom.

Hong Kong

The Series E Debentures may not be offered or sold by means of any document other than (i) in
circumstances which do not constitute an offer to the public within the meaning of the Companies
Ordinance (Cap.32, Laws of Hong Kong), or (ii) to "professional investors" within the meaning of the
Securities and Futures Ordinance (Cap.571, Laws of Hong Kong) and any rules made thereunder, or
(iii) in other circumstances which do not result in the document being a "prospectus" within the
meaning of the Companies Ordinance (Cap.32, Laws of Hong Kong), and no advertisement, invitation or
document relating to the Series E Debentures may be issued or may be in the possession of any person
for the purpose of issue (in each case whether in Hong Kong or elsewhere), which is directed at, or
the contents of which are likely to be accessed or read by, the public in Hong Kong (except if
permitted to do so under the laws of Hong Kong) other than with respect to Series E Debentures which
are or are intended to be disposed of only to persons outside Hong Kong or only to "professional
investors" within the meaning of the Securities and Futures Ordinance (Cap. 571, Laws of Hong Kong)
and any rules made thereunder.

Japan

The Series E Debentures have not been and will not be registered under the Financial Instruments and
Exchange Act of Japan (Act No. 25 of 1948, as amended; the "Financial Instruments and Exchange Act")
and each Remarketing Agent has represented and agreed that it has not offered or sold and will not
offer or sell any Series E Debentures, directly or indirectly, in Japan or to, or for the benefit
of, any resident of Japan (which term as used herein means any person resident in Japan, including
any corporation or other entity organized under the laws of Japan), or to others for re- offering or
resale, directly or indirectly, in Japan or to, or for the benefit of, a resident of Japan, except
pursuant to an exemption from the registration requirements of, and otherwise in compliance with,
the Financial Instruments and Exchange Act and any other applicable laws, regulations and
ministerial guidelines of Japan. V-2
<!-- page 47 -->
Singapore

This prospectus supplement and the accompanying prospectus have not been registered as a prospectus
with the Monetary Authority of Singapore. Accordingly, this prospectus supplement, the accompanying
prospectus, any free writing prospectus and any other document or material in connection with the
offer or sale, or invitation for subscription or purchase, of the Series E Debentures may not be
circulated or distributed, nor may the Series E Debentures be offered or sold, or be made the
subject of an invitation for subscription or purchase, whether directly or indirectly, to persons in
Singapore other than (i) to an institutional investor under Section 274 of the Securities and
Futures Act, Chapter 289 of Singapore (the "SFA"), (ii) to a relevant person pursuant to Section
275(1), or any person pursuant to Section 275(1A), and in accordance with the conditions specified
in Section 275 of the SFA, or (iii) otherwise pursuant to, and in accordance with the conditions of,
any other applicable provision of the SFA.

Where the Series E Debentures are subscribed or purchased under Section 275 of the SFA by a relevant
person which is: (a) a corporation (which is not an accredited investor (as defined in Section 4A of
the SFA)) the sole business of which is to hold investments and the entire share capital of which is
owned by one or more individuals, each of whom is an accredited investor); or (b) a trust (where the
trustee is not an accredited investor) whose sole purpose is to hold investments and each
beneficiary of the trust is an individual who is an accredited investor, securities (as defined in
Section 239(1) of the SFA) of that corporation or the beneficiaries' rights and interest (howsoever
described) in that trust shall not be transferred within 6 months after that corporation or that
trust has acquired the Series E Debentures pursuant to an offer made under Section 275 of the SFA
except: (1) to an institutional investor or to a relevant person defined in Section 275(2) of the
SFA, or any person arising from an offer referred to in Section 275(1A) or Section 276(4)(i)(B) of
the SFA; (2) where no consideration is or will be given for the transfer; (3) where the transfer is
by operation of law; (4) as specified in Section 276(7) of the SFA; or (5) as specified in
Regulation 32 of the Securities and Futures (Offers of Investments) (Shares and Debentures)
Regulations 2005 of Singapore.

South Korea

The Series E Debentures may not be offered, sold and delivered directly or indirectly, or offered or
sold to any person for re-offering or resale, directly or indirectly, in South Korea or to any
resident of South Korea except pursuant to the applicable laws and regulations of South Korea,
including the Financial Investment Services and Capital Markets Act and the Foreign Exchange
Transaction Law and the decrees and regulations thereunder. The Series E Debentures have not been
registered with the Financial Services Commission of South Korea for public offering in South Korea.
Furthermore, the Series E Debentures may not be re-sold to South Korean residents unless the
purchaser of the Series E Debentures complies with all applicable regulatory V-3
<!-- page 48 -->
requirements (including but not limited to government approval requirements under the Foreign
Exchange Transaction Law and its subordinate decrees and regulations) in connection with their
purchase. V-4
