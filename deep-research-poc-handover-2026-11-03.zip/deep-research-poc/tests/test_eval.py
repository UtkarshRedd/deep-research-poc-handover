"""Eval harness: metrics (deterministic) and the runner end to end with scripted models."""
import json
import uuid
from dataclasses import replace
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage

from dr.config import DEFAULT
from dr.eval.golden import load_golden
from dr.eval.metrics import (
    abstention,
    contains_answer,
    gold_page_cited,
    item_recall,
    judge_correctness,
    render_summary,
    summarize,
)
from dr.eval.run import run_eval
from dr.graph import VARIANTS
from dr.ingest.load import load_dir
from dr.llm import get_scripted_llm
from dr.models import EvidenceItem
from dr.structured import ModelCaller

SAMPLE = Path(__file__).resolve().parents[1] / "data" / "sample_docs"
GOLD = Path(__file__).resolve().parents[1] / "data" / "golden" / "questions.example.jsonl"
QUOTE = "Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00."


def tc(name, args):
    return {"name": name, "args": args, "id": f"call_{uuid.uuid4().hex[:8]}", "type": "tool_call"}


def ai(*calls, content=""):
    return AIMessage(content=content, tool_calls=list(calls))


# --------------------------------------------------------------------------- metrics

def test_answer_metrics():
    assert contains_answer("3.50 to 1.00", "The cap is **3.50 to 1.00** per Section 3.") is True
    assert contains_answer("4.00 to 1.00", "The cap is 3.50 to 1.00.") is False and contains_answer(None, "x") is None
    assert item_recall(["90 days written notice", "Section 4"], "Termination on 90 days written notice.") == 0.5
    assert item_recall([], "x") is None
    assert abstention("not_in_corpus", True) == {"expected": True, "abstained": True, "correct": True}
    assert abstention("single", True)["correct"] is False and abstention("single", False)["correct"] is True
    items = [EvidenceItem(id="e1", doc_id="a", page=2, start_line=1, end_line=1, quote="q"),
             EvidenceItem(id="e2", doc_id="b", page=9, start_line=1, end_line=1, quote="q")]
    assert gold_page_cited([("a", [2]), ("b", [1])], items) == 0.5
    assert gold_page_cited([("b", [])], items) == 1.0 and gold_page_cited([], items) is None


def test_judge_scores_and_unknown_fallback():
    good = ModelCaller(get_scripted_llm([AIMessage(content='{"verdict": "correct", "rubric_hits": [true, false], "reason": "matches"}')]), None, "j", "judge")
    v = judge_correctness("q", "3.50", ["states 3.50", "cites the agreement"], "report", good)
    assert v["verdict"] == "correct" and v["score"] == 1.0 and v["rubric_rate"] == 0.5
    bad = ModelCaller(get_scripted_llm([AIMessage(content="no"), AIMessage(content="still no")]), None, "j", "judge")
    v = judge_correctness("q", None, [], "report", bad)
    assert v["verdict"] == "unknown" and v["score"] is None and "failed" in v["reason"]


def test_summarize_and_render():
    rows = [
        {"qid": "a", "type": "single", "candidate_recall": 1.0, "opened_or_cited_recall": 1.0, "support_rate": 1.0,
         "gate_fail": False, "contains_answer": True, "judge_verdict": "correct", "judge_score": 1.0,
         "wall_s": 10, "tool_calls": 6, "in_tokens": 1000, "out_tokens": 200, "abstention_correct": True},
        {"qid": "b", "type": "single", "candidate_recall": 0.0, "opened_or_cited_recall": 0.5, "support_rate": 0.5,
         "gate_fail": True, "contains_answer": False, "judge_verdict": "incorrect", "judge_score": 0.0,
         "wall_s": 30, "tool_calls": 10, "in_tokens": 3000, "out_tokens": 400, "abstention_correct": True},
        {"qid": "c", "type": "not_in_corpus", "error": "boom"},
    ]
    s = summarize(rows)
    assert s["all"]["n"] == 3 and s["all"]["errors"] == 1 and s["single"]["n"] == 2
    assert s["single"]["candidate_recall"] == 0.5 and s["single"]["gate_fail_rate"] == 0.5
    assert s["single"]["judge_pass_rate"] == 0.5 and s["single"]["tokens_per_correct"] == 4600
    assert s["single"]["wall_s_p50"] == 20
    md = render_summary(s, "A2_fs_agent")
    assert md.startswith("### A2_fs_agent") and "| single |" in md and "| not_in_corpus |" in md


# --------------------------------------------------------------------------- runner

def test_run_eval_end_to_end_with_scripted_models(tmp_path):
    docs = load_dir(SAMPLE)
    qs = [q for q in load_golden(GOLD, docs=docs) if q.qid in ("q001", "q006")]
    a = next(d.doc_id for d in docs if d.title == "Credit Agreement — Acme Industrial LLC")
    cfg = replace(DEFAULT, agents=replace(DEFAULT.agents, RESEARCH_MIN_CALLS=1, RESEARCH_MAX_CALLS=6))
    researcher = get_scripted_llm([
        # q001: grep -> add_evidence + submit
        ai(tc("grep", {"pattern": "Leverage Ratio"})),
        ai(tc("add_evidence", {"doc_id": a, "start_line": 17, "end_line": 17, "quote": QUOTE, "note": "covenant"}),
           tc("submit", {"sub_question": "q", "answer": "3.50 to 1.00 [e1]", "evidence_ids": ["e1"], "confidence": "high"})),
        # q006: grep -> abstain
        ai(tc("grep", {"pattern": "interest rate floor"})),
        ai(tc("submit", {"sub_question": "q", "answer": "Not in the documents.", "evidence_ids": [], "not_in_corpus": True})),
    ])
    writer = get_scripted_llm([
        AIMessage(content=json.dumps({"sections": [{"section_id": "s1", "title": "Covenant", "intent": "ratio"}]})),
        AIMessage(content=json.dumps({"sections": [{"section_id": "s1", "title": "Covenant", "intent": "ratio", "evidence_ids": ["e1"]}]})),
        AIMessage(content="The original agreement caps the Leverage Ratio at 3.50 to 1.00 {{CITE:e1}}."),
        AIMessage(content=json.dumps({"sections": [{"section_id": "s1", "title": "Floor", "intent": "find the floor"}]})),  # q006: no evidence -> gaps only
    ])
    judge = get_scripted_llm([
        AIMessage(content='{"verdict": "correct", "rubric_hits": [true, true], "reason": "states 3.50"}'),
        AIMessage(content='{"verdict": "correct", "rubric_hits": [true, true], "reason": "abstains"}'),
    ])
    rows, summary, paths = run_eval(qs, docs, "A2_fs_agent", cfg, llms={"researcher": researcher, "writer": writer, "judge": judge},
                                    out_dir=tmp_path / "results", concurrency=1, tag="t")
    by = {r["qid"]: r for r in rows}
    r1, r6 = by["q001"], by["q006"]
    assert r1["error"] is None and r1["research_done"] == "submitted"
    assert r1["opened_or_cited_recall"] == 1.0 and r1["gold_page_cited"] == 1.0 and r1["candidate_recall"] is None
    assert r1["support_rate"] == 1.0 and r1["gate_fail"] is False and r1["contains_answer"] is True
    assert r1["judge_verdict"] == "correct" and r1["rubric_rate"] == 1.0 and r1["abstention_correct"] is True
    assert r1["n_model_calls"] == 5 and r1["tool_calls"] == 2            # 2 researcher + 3 writer (judge traced too? no: judge after trace close)
    assert r6["abstained"] is True and r6["abstention_correct"] is True and r6["contains_answer"] is None
    assert r6["opened_or_cited_recall"] is None and r6["n_claims"] == 1 and r6["partial"] is True
    assert summary["all"]["n"] == 2 and summary["all"]["judge_pass_rate"] == 1.0 and summary["all"]["abstention_ok_rate"] == 1.0
    assert summary["single"]["contains_answer_rate"] == 1.0 and summary["not_in_corpus"]["n"] == 1
    assert paths["jsonl"].exists() and paths["summary"].exists() and (paths["runs"] / "q001" / "report.md").exists()
    assert len(paths["jsonl"].read_text().splitlines()) == 2 and "| all |" in paths["summary"].read_text()


def test_run_eval_records_errors_and_rejects_unknown_variants(tmp_path):
    docs = load_dir(SAMPLE)
    qs = [q for q in load_golden(GOLD, docs=docs) if q.qid == "q001"]
    rows, summary, _ = run_eval(qs, docs, "A2_grep_only", llms={"researcher": get_scripted_llm([]), "writer": get_scripted_llm([])},
                                out_dir=tmp_path / "r", concurrency=1, judge=False, tag="e")
    assert rows[0]["error"].startswith("ScriptExhausted") and summary["all"]["errors"] == 1
    with pytest.raises(NotImplementedError, match="LC_small"):
        run_eval(qs, docs, "LC_small", out_dir=tmp_path / "x", judge=False)
    assert set(VARIANTS) >= {"A2_fs_agent", "A2_grep_only", "A1_deep_list", "A1_no_first_move", "A1_bm25_only"}


def test_run_eval_stops_after_consecutive_errors(tmp_path):
    docs = load_dir(SAMPLE)
    qs = load_golden(GOLD, docs=docs)                       # 6 questions; every one fails: no scripted replies
    rows, summary, _ = run_eval(qs, docs, "A2_fs_agent", llms={"researcher": get_scripted_llm([]), "writer": get_scripted_llm([])},
                                out_dir=tmp_path / "r", concurrency=1, judge=False, tag="stop", stop_after_errors=2)
    assert len(rows) == 2 and all(r["error"] for r in rows) and summary["all"]["errors"] == 2


def test_run_eval_resume_reuses_completed_rows_and_counts_model_errors(tmp_path):
    docs = load_dir(SAMPLE)
    qs = [q for q in load_golden(GOLD, docs=docs) if q.qid in ("q001", "q006")]
    prior = tmp_path / "prior.jsonl"
    done_row = {"qid": "q001", "type": "single", "variant": "A2_fs_agent", "research_done": "submitted",
                "judge_verdict": "correct", "judge_score": 1.0, "error": None, "wall_s": 1}
    dead_row = {"qid": "q006", "type": "not_in_corpus", "variant": "A2_fs_agent", "research_done": "model_error",
                "judge_verdict": "unknown", "error": None, "wall_s": 1}
    prior.write_text(json.dumps(done_row) + "\n" + json.dumps(dead_row) + "\n", encoding="utf-8")
    # q006 must be re-run; its researcher fails -> model_error rows count toward the stop rule
    rows, _summary, paths = run_eval(qs, docs, "A2_fs_agent", llms={"researcher": get_scripted_llm([]), "writer": get_scripted_llm([])},
                                    out_dir=tmp_path / "r", concurrency=1, judge=False, tag="res", resume=prior, stop_after_errors=1)
    by = {r["qid"]: r for r in rows}
    assert by["q001"]["resumed_from"] == str(prior) and by["q001"]["judge_verdict"] == "correct"
    assert "resumed_from" not in by["q006"] and by["q006"]["error"] and len(rows) == 2
    assert len(paths["jsonl"].read_text().splitlines()) == 2


def test_cuad_smoke_set_is_a_fixed_two_per_type_subset():
    root = Path(__file__).resolve().parents[1] / "data" / "golden"
    smoke = root / "cuad_smoke.jsonl"
    if not smoke.exists():
        pytest.skip("no CUAD smoke set")
    qs = load_golden(smoke)
    full = {q.qid: q for q in load_golden(root / "cuad_questions.jsonl")}
    from collections import Counter
    assert len(qs) == 12 and dict(Counter(q.type for q in qs)) == {t: 2 for t in ("single", "temporal", "identifier", "coverage", "multihop", "not_in_corpus")}
    assert all(q.qid in full and full[q.qid].question == q.question for q in qs)
    assert {"cq001", "cq037", "cq061", "cq077", "cq089", "cq097"} <= {q.qid for q in qs}
