<!-- page 1 -->
# Guarantee — Corvallis Foods Group
| Field | Value |
|---|---|
| Document Type | Guarantee |
| Effective Date | 2025-04-01 |
| Parties | Corvallis Cold Storage LLC; Willamette Valley Produce, Inc.; Pacific Commerce Bank |
| Facility ID | FAC-2025-0108 |
| Version | Original (Execution Version) |

THIS GUARANTEE (this "Guarantee") is made as of 2025-04-01 by each of the undersigned subsidiaries of Corvallis Foods Group LLC (each a "Guarantor") in favor of Pacific Commerce Bank, as Administrative Agent for the Lenders under the Credit Agreement dated as of 2025-04-01 among Corvallis Foods Group LLC, the Lenders and the Administrative Agent (facility FAC-2025-0108).
<!-- page 2 -->
## Section 1 — Guarantors
The Guarantors on the date hereof are:
(a) Corvallis Cold Storage LLC;
(b) Willamette Valley Produce, Inc.;
together with each other person that becomes a party hereto by executing a Guarantor Joinder pursuant to Section 6.9 of the Credit Agreement.
<!-- page 3 -->
## Section 2 — The Guarantee
Each Guarantor, jointly and severally, unconditionally and irrevocably guarantees the punctual payment when due of all Obligations of the Borrower under the Loan Documents.
This Guarantee is a guarantee of payment and not of collection. The Administrative Agent is not required to exhaust remedies against the Borrower before proceeding against any Guarantor.
## Section 3 — Limitation
The obligations of each Guarantor are limited to the maximum amount that can be guaranteed without rendering this Guarantee voidable under applicable fraudulent transfer law.
<!-- page 4 -->
## Section 4 — Waivers; Reinstatement
Each Guarantor waives presentment, demand, protest and notice of any kind, and any defense arising from any amendment, waiver or release under the Loan Documents.
This Guarantee shall be reinstated if any payment is rescinded or must be returned upon the insolvency of the Borrower.
## Section 5 — Release
A Guarantor is released automatically upon the sale of all of its equity interests in a transaction permitted by Section 7.6 of the Credit Agreement.
<!-- page 5 -->
## Section 6 — Notices; Governing Law
Notices to any Guarantor shall be delivered care of the Borrower at 455 Willamette Avenue, Corvallis, Oregon 97330, Attention: General Counsel, and are effective in the manner provided in Section 10.1 of the Credit Agreement.
This Guarantee shall be governed by the laws of the State of California.
Corvallis Cold Storage LLC, as Guarantor — By: /s/ Authorized Signatory
Willamette Valley Produce, Inc., as Guarantor — By: /s/ Authorized Signatory
