<!-- page 1 -->
# INTELLECTUAL PROPERTY AGREEMENT
| Field | Value |
|---|---|
| Document Type | IP Agreement |
| Agreement Date | 2016-06-30 |
| Parties | THE HERTZ CORPORATION ("THC"); HERTZ SYSTEM, INC. ("HSI"); HERC RENTALS INC. ("HERC"); (hereinafter referred to collectively the "Parties", and individually as a "party" |
| Source | CUAD v1 / HERTZGLOBALHOLDINGS,INC_07_07_2016-EX-10.4-INTELLECTUAL PROPERTY AGREEMENT |

Exhibit 10.4 INTELLECTUAL PROPERTY AGREEMENT This INTELLECTUAL PROPERTY AGREEMENT (this "Agreement"
or "IPA"), effective as of this 30 day of June 2016 (the "Effective Date") among THE HERTZ
CORPORATION, a Delaware corporation, with an address of 8501 Williams Road, Estero, Florida 33928
(hereinafter "THC"); HERTZ SYSTEM, INC., a Delaware corporation, with an address of 8501 Williams
Road, Estero, Florida 33928, United States of America (hereinafter "HSI") and HERC RENTALS INC., a
Delaware corporation, with an address of 27500 Riverview Center Blvd., Bonita Springs, Florida
34134, United States of America (hereinafter "HERC") (hereinafter referred to collectively as the
"Parties" and individually as a "Party"). WITNESSETH WHEREAS, both HSI and HERC are wholly-owned
subsidiaries of THC, and THC is an indirect wholly-owned subsidiary of Hertz Global Holdings, Inc.,
a Delaware corporation ("HGH"); WHEREAS, THC is the owner of a unique plan or system (hereinafter
the "Hertz System") for conducting, inter alia, the business of renting and leasing vehicles with
and without drivers (hereinafter the "Vehicle Rental Business" or "VRB") which it conducts in
collaboration with HSI which is the owner of all trademarks for HERTZ and HERTZ-formative trademarks
and designs and other trademarks and designs worldwide in connection with the Vehicle Rental
Business (the "VRB Trademarks") and Other Intellectual Property (as defined herein); WHEREAS, THC is
the owner of a unique plan or system for conducting an equipment rental business (hereinafter the
"Equipment Rental Business" or "ERB" as further defined below) which it conducts through HERC;
WHEREAS, HGH has approved plans to separate the Vehicle Rental Business and the Equipment Rental
Business into two independent, publicly traded companies (the "Separation") pursuant to, among other
agreements, the Separation and Distribution Agreement by and between Hertz Rental Car Holding
Company, Inc. (to be renamed "Hertz Global Holdings, Inc." in connection with the Separation, "New
Hertz") and HGH (to be renamed Herc Holdings Inc. in connection with the Separation) dated as of
June 30, 2016 (the "Distribution Agreement"); WHEREAS, as a result of the Separation, THC and HSI
will become indirect wholly-owned subsidiaries of New Hertz, and HERC will continue to be an
indirect wholly-owned subsidiary of HGH; WHEREAS, THC exercises control with respect to the use,
registration and enforcement of all of its company trademarks through its subsidiary HSI. HERC uses
certain HERTZ or HERTZ-formative trademarks in connection with the ERB with the

th
<!-- page 2 -->
permission of HSI and THC; WHEREAS, HSI is the owner of certain foreign HERTZ and HERTZ-formative
and other trademarks and logos (the "HSI (HERTZ) Foreign ERB Trademarks") used or to be used by HERC
with the permission of HSI in connection with the Equipment Rental Business, including the trademark
applications and registrations therefor as more fully set forth on Schedule A; WHEREAS, HSI is the
owner of certain United States HERTZ and HERTZ-formative and other trademarks and logos (the "HSI
(HERTZ) US ERB Trademarks") used by HERC with the permission of HSI in connection with the Equipment
Rental Business, including the trademark applications and registrations therefor as more fully set
forth on Schedule B; WHEREAS, HSI is the owner of certain foreign HERC trademarks and logos (the
"HSI HERC Foreign ERB Trademarks") used by HERC with the permission of HSI in connection with the
Equipment Rental Business, including the trademark applications and registrations therefor, as more
fully set forth on Schedule C; WHEREAS, HERC is the owner of certain US HERTZ-formative trademarks
(the "HERC (HERTZ) US ERB Trademarks") used by HERC with the permission of HSI in connection with
the Equipment Rental Business, including the trademark applications and registrations therefore as
more fully set forth on Schedule D; WHEREAS, HERC is the owner of certain US trademarks not derived
from the HERTZ trademark (the "HERC (HERC) US ERB Trademarks") that have been used by HERC with the
permission of HSI in connection with the Equipment Rental Business and, in the case of the
trademarks HERC RENTALS and HERCRENTALS Logo will be used by Herc in connection with the Equipment
Rental Business, including the trademark applications and registrations therefor as more fully set
forth on Schedule E; WHEREAS, HERC is the owner of certain foreign trademarks not derived from the
HERTZ trademark (the "HERC (HERC) Foreign ERB Trademarks") that have been used by HERC with the
permission of HSI in connection with the Equipment Rental Business and, in the case of the
trademarks HERC RENTALS and HERCRENTALS Logo will be used by Herc in connection with the Equipment
Rental Business, including the trademark applications and registrations therefore as more fully set
forth on Schedule F. WHEREAS, THC is the owner of certain HERTZ and HERTZ-formative domain names
(the "THC (HERTZ) ERB Domains") used by HERC with the permission of THC related to the Equipment
Rental Business, as more fully set forth on Schedule G; WHEREAS, THC is the owner of certain
non-HERTZ-formative domain names (the "THC ERB Domains") used by HERC with the permission of THC
related to the Equipment Rental Business, as more fully set forth on Schedule H; 2
<!-- page 3 -->
WHEREAS, as a result of the Separation, the Parties wish to differentiate and distinguish the future
ownership, license and use of the relevant HERTZ, HERTZ-formative, HERC and other trademark rights
and logos on a worldwide basis related to the Vehicle Renting Business which is to remain with HSI
and the Equipment Rental Business to remain with HERC and the Parties have agreed upon a plan going
forward with respect to the ownership, license and use of the HSI (HERTZ) Foreign ERB Trademarks,
the HSI (HERTZ) US ERB Trademarks, the HSI HERC Foreign ERB Trademarks, the HERC (HERTZ) US ERB
Trademarks, the HERC (HERC) US ERB Trademarks, the THC (HERTZ) ERB Domains and the THC ERB Domains;
and NOW, THEREFORE, for good and valuable consideration, the receipt of which is hereby
acknowledged, the parties hereto agree as follows: 1. Definitions 1.1 The "Equipment Rental
Business" or "ERB" has the meaning given to such term in the Distribution Agreement. 1.2 "Interim
Period" means a period of four (4) years commencing from the Effective Date of this Agreement. 1.3
"Other Intellectual Property" means any copyrights, trade dress, content, designs or other indicia
and/or social media accounts and handles owned by THC and/or HSI that are already used or otherwise
in the possession of HERC relating to the HERTZ and HERTZ-formative trademarks and logos in
connection with the Equipment Rental Business. 2. Terms of Transfer, License and Use 2.1. HSI will
retain ownership of the worldwide rights in and to the VRB Trademarks. 2.2 In the case of the HSI
(HERTZ) Foreign ERB Trademarks: 2.2.1 HSI will retain ownership and will grant a royalty-free,
non-exclusive license to HERC to use the HSI (HERTZ) Foreign ERB Trademarks (those foreign
trademarks owned by HSI related to the ERB that incorporate the mark/name HERTZ) as set forth on
Schedule A, for the Interim Period, outside the United States and Puerto Rico, as more fully set
forth in the Trademark, Trade Name, Domain and Related Rights License Agreement attached as Exhibit
A. HERC shall immediately discontinue use of the HSI (HERTZ) Foreign ERB Trademarks upon expiration
of the Interim Period, or the earlier termination of this Agreement or the Trademark, Trade Name,
Domain and Related Rights License Agreement. 2.3 In the case of the HSI (HERTZ) US ERB Trademarks:
2.3.1 HSI will retain ownership and will grant a royalty-free, non-exclusive, license to HERC to use
the HSI (HERTZ) US ERB Trademarks (those US trademarks 3
<!-- page 4 -->
owned by HSI related to the ERB that incorporate the mark/name HERTZ) as set forth on Schedule B,
for the Interim Period, in the United States and Puerto Rico, as more fully set forth in the
Trademark, Trade Name, Domain and Related Rights License Agreement attached as Exhibit A. HERC shall
immediately discontinue use of the HSI (HERTZ) US ERB Trademarks upon expiration of the Interim
Period, or the earlier termination of this Agreement or the Trademark, Trade Name, Domain and
Related Rights License Agreement. 2.4 In the case of the HSI HERC Foreign ERB Trademarks: 2.4.1 HSI
will assign all right, title and interest in and to the HSI HERC Foreign ERB Trademarks (those
foreign trademarks owned by HSI related to the ERB for the HERC trademarks) as set forth on Schedule
C to HERC as more fully set forth in the Trademark Assignment Agreements attached hereto as Exhibit
B-1 (Canada) and Exhibit B-2 (all other foreign countries). 2.5 In the case of the HERC (HERTZ) US
ERB Trademarks owned by HERC: 2.5.1 HERC will have the right to retain ownership and use of the HERC
(HERTZ) US ERB Trademarks (those US trademarks owned by HERC related to the ERB that incorporate the
mark/name HERTZ) as set forth on Schedule D for the Interim Period. HERC shall immediately
discontinue use of the HERC (HERTZ) US ERB Trademarks and abandon or voluntarily withdraw or cancel
any applications or registrations therefor upon expiration of the Interim Period as more fully set
forth in the Coexistence Agreement attached hereto as Exhibit C and/or the earlier termination of
this Agreement or the Trademark, Trade Name, Domain and Related Rights License Agreement. The
Parties shall cooperate to ensure that no confusion arises in the marketplace during the Interim
Period, as more fully set forth in the Coexistence Agreement. 2.6 In the case of the HERC (HERC) US
ERB Trademarks owned by HERC: 2.6.1 HERC shall retain ownership and the right to use the HERC (HERC)
US ERB Trademarks (those US trademarks owned by HERC related to the ERB that do not incorporate the
mark/name HERTZ) as set forth on Schedule E. 2.7 In the case of the HERC (HERC) Foreign ERB
Trademarks owned by HERC: 2.7.1 HERC shall retain ownership and the right to use the HERC (HERC)
Foreign ERB Trademarks (those foreign trademarks owned by HERC related to the ERB that do not
incorporate the mark/name HERTZ) as set forth on Schedule F. 2.8. In the case of the THC (HERTZ) ERB
Domains owned by THC: 2.8.1 THC will retain ownership and will, subject to compliance with the terms
of this Agreement, grant a royalty-free, non-exclusive license to HERC to use the THC (HERTZ) ERB
Domains (those domains owned by THC related to the ERB that 4
<!-- page 5 -->
incorporate the mark/name HERTZ) as set forth on Schedule G, for the Interim Period, as more fully
set forth in the Trademark, Trade Name, Domain and Related Rights License Agreement. HERC shall
immediately discontinue use of the THC (HERTZ) ERB Domains upon the expiration of the Interim Period
or the earlier termination of this Agreement or the Trademark, Trade Name, Domain and Related Rights
License Agreement. HERC shall make certain that no THC (HERTZ) ERB Domains resolve to a website upon
the expiration of the Interim Period or the earlier termination of this Agreement or the Trademark,
Trade Name, Domain and Related Rights License Agreement. 2.9 In the case of the THC ERB Domains
owned by THC: 2.9.1 THC will assign all right, title and interest in and to the THC ERB Domains
(those domains owned by THC related to the ERB that do not incorporate the mark/name HERTZ) as set
forth on Schedule H to HERC and as more fully set forth in the Domain Name Assignment attached
hereto as Exhibit D. 2.10 In the case of the use of the mark/name HERTZ in the company name Hertz
Equipment Rental Corporation (HERC): 2.10.1 HSI will, subject to compliance with the terms of this
Agreement, grant a royalty-free, non-exclusive worldwide license to HERC to use the mark/name HERTZ
as part of company names for the Interim Period, as more fully set forth in the Trademark, Trade
Name, Domain and Related Rights License Agreement attached as Exhibit A. Notwithstanding anything to
the contrary herein, HERC shall immediately discontinue use of the mark/name as part of its company
name upon expiration of the Interim Period or the earlier termination of this Agreement or the
Trademark, Trade Name, Domain and Related Rights License Agreement. HERC shall take all steps to
change the company name so as to not to include the mark/name HERTZ by the expiration of the Interim
Period. 2.11 In the case of the Other Intellectual Property: 2.11.1 THC and/or HSI will retain
ownership and will grant a royalty-free, non-exclusive license to HERC to use such Other
Intellectual Property for the Interim Period, as more fully set forth in the Trademark, Trade Name,
Domain and Related Rights License Agreement attached as Exhibit A. HERC shall immediately
discontinue use of the Other Intellectual Property upon expiration of the Interim Period, or the
earlier termination of this Agreement or the Trademark, Trade Name, Domain and Related Rights
License Agreement. 2.12 With respect to the Parties' use of the HERTZ and HERC trademarks worldwide:
2.12.1 With respect to HSI's worldwide use of the VRB Trademarks incorporating the name/mark HERTZ
and HERTZ-formative trademarks and designs and HERC's use of the HERC trademarks (including HERC,
HERC360 and other HERC-formative 5
<!-- page 6 -->
trademarks and designs) in connection with the ERB, the Parties shall cooperate to ensure that no
confusion arises in the worldwide marketplace, as more fully set forth in the Coexistence Agreement
attached hereto as Exhibit C. 2.13 Nothing in this Agreement or the other ancillary agreements
thereto shall affect or limit the rights confirmed in the license effective April 1, 1998 between
HSI and HERC, and the sublicense effective April 1, 1998 between HERC as Sub-Licensor and Matthews
Equipment Limited and Hertz Canada Equipment Rental Partnership as Sub-Licensees, which remain in
full force and effect, save and except that such license and sublicense shall not expire before the
later of the expiration of the Interim Period or the final determination or resolution of the action
pending as T- 409-16 in the Federal Court of Canada (including any appeals thereof). 3.
Protection/Maintenance and Enforcement of HSI (HERTZ) Foreign ERB Trademarks and HSI (HERTZ) US ERB
Trademarks during Interim Period. 3.1 During the Interim Period, HSI shall take all necessary and
reasonable actions to preserve and protect the validity of the HSI (HERTZ) Foreign ERB Trademarks,
the HSI HERC Foreign ERB Trademarks and the HSI (HERTZ) US ERB Trademarks licensed to HERC and HSI
shall continue to prosecute all applications and maintain any registrations therefor. HERC shall not
take any action that would harm or jeopardize the licensed HSI (HERTZ) Foreign ERB Trademarks, the
HSI HERC Foreign ERB Trademarks or HSI (HERTZ) US ERB Trademarks. HERC shall assist in such actions
to the extent required and requested by HSI for establishing use of the HSI (HERTZ) Foreign ERB
Trademarks, the HSI HERC Foreign ERB Trademarks and HSI (HERTZ) US ERB Trademarks during the Interim
Period. HSI shall also enforce the HSI (HERTZ) Foreign ERB Trademarks, the HSI HERC Foreign ERB
Trademarks and HSI (HERTZ) US ERB Trademarks during the Interim Period as more fully set forth in
the Trademark, Trade Name, Domain and Related Rights License Agreement. HERC shall be responsible
for reimbursing THC and/or HSI for all costs in connection with prosecuting all applications and
maintaining in full force and effect all registrations for the HSI (HERTZ) Foreign ERB Trademarks,
the HSI HERC Foreign ERB Trademarks and HSI (HERTZ) US ERB Trademarks during the Interim Period. 4.
Ownership. The Parties acknowledge and affirm their respective rights in and to the relevant
trademark and related rights subject to this Agreement and neither Party shall directly or
indirectly attack, challenge or impair the title and related rights of the other Party during the
Interim Period or any time thereafter. The Parties shall cooperate to protect, maintain and enforce
all relevant trademark and related rights subject to this Agreement. 5. Infringement and
Indemnification. 5.1 Notice of Infringement. HERC shall promptly notify HSI of the use of any mark
by any third party which HERC considers might be an infringement or passing off of any HERTZ or
HERTZ-formative intellectual property used by or licensed to HERC pursuant 6
<!-- page 7 -->
to the terms hereof or the Trademark, Trade Name, Domain and Related Rights License Agreement.
However, HSI shall have the sole right to decide whether or not proceedings shall be brought against
such third parties. In the event that HSI decides that action should be taken against such third
parties, HSI may take such action either in its own name or, alternatively, HSI may authorize HERC
to initiate such action in HERC's name. In any event, the Parties agree to cooperate fully with each
other to the extent necessary to prosecute such action, all expenses being borne by the Party
bringing such action and all damages which may be recovered being solely for the account of that
Party. 5.2 Indemnification of HERC related to use of HERTZ trademark during the Interim Period. HSI
shall defend, indemnify and hold HERC harmless against any and all claims, suits, actions or other
proceedings whatsoever brought against HERC based on third-party claims of trademark infringement in
connection with HERC'S use of the HSI (HERTZ) Foreign ERB Trademarks, the HSI (HERTZ) US ERB
Trademarks, the HERC (HERTZ) US ERB Trademarks and the Other Intellectual Property to the extent
such claims, suits, actions or other proceedings are based upon use of the HERTZ element comprising
a HSI (HERTZ) Foreign ERB Trademark, HSI (HERTZ) US ERB Trademark, HERC (HERTZ) US ERB Trademark or
Other Intellectual Property during the Interim Period only and from claims of third parties against
HERC or any of its affiliates stemming from HERTZ's use of the HERTZ trademarks. 5.3 Indemnification
of THC and HSI. Except as provided in Section 5.2, HERC shall defend, indemnify and hold THC, HSI,
and their affiliates, and each of their officers, directors, agents, and employees harmless from and
against all costs, expenses, taxes (including interest and penalties, and determined without regard
to the tax attributes of any indemnitee) and losses (including reasonable attorney fees and costs)
incurred from claims of third parties (including any taxing authority) against either THC, HSI or
any of their affiliates stemming from any of the activities contemplated under this Agreement or the
Trademark, Trade Name, Domain and Related Rights License Agreement and HERC's use of the HERC
trademarks, including without limitation any transfers of rights and actions which relate in any way
to the manufacture, distribution, sale or performance or promotion of the Foreign and US Licensed
Products and Services (as defined in the Trademark, Trade Name, Domain and Related Rights License
Agreement). This provision shall survive the expiration or earlier termination of this Agreement and
the Trademark, Trade Name, Domain and Related Rights License Agreement. 5.4 Indemnity Procedure. All
claims for indemnification under Section 5.2 and Section 5.3 and any other disputes that arise under
this Agreement and the ancillary agreements exhibited hereto will be made in accordance with and
governed by the procedures set forth in Article V of the Distribution Agreement. 6. Insurance. HERC
shall, throughout the term of this Agreement, obtain and maintain at its own cost and expense, from
a qualified AAA-rated insurance company, a standard liability insurance and business interruption
policy along with advertising injury 7
<!-- page 8 -->
protection, all of which must be acceptable to THC and HSI, and which must name THC and HSI as
additional insureds. Such policy shall provide, in addition to other protection, protection against
any and all claims, demands, and causes of action arising out of any act, omission, negligence or
otherwise giving rise to a third party claim. The amount of coverage shall be a minimum of three
million dollars ($3,000,000) combined single limit, with no deductible amount for each single
occurrence for bodily injury and/or property damage. HERC shall provide for ten (10) days notice to
THC and HSI in the event of any modification, cancellation or termination. HERC agrees to furnish
THC and HSI Certificates of Insurance evidencing same within thirty (30) days after the execution of
this Agreement. In no event shall HERC perform or promote the carry out the activities contemplated
under this Agreement or the Trademark, Trade Name, Domain and Related Rights License Agreement prior
to receipt by THC and HSI of evidence of insurance. 7. Confidentiality. Unless otherwise agreed to
by the Parties or except as otherwise provided in this Agreement or the Distribution Agreement, any
Confidential Information (as defined in the Distribution Agreement) furnished pursuant to this
Agreement shall be subject to the confidentiality provisions and restrictions on disclosure set
forth in Section 6.7 of the Distribution Agreement. 8. Breach and Termination. 8.1 By THC or HSI
upon Notice. In the event of a material breach of this Agreement or any of the ancillary agreements
exhibited hereto, THC or HSI may notify HERC of such material breach and terminate this Agreement
upon written notice. If HERC has not cured any such breach within thirty (30) days after HERC
receives such notice, this Agreement shall automatically terminate without further notice.
Notwithstanding the foregoing, if the nature of the breach is such that it cannot be cured, then
this Agreement shall automatically terminate upon notice of termination by THC or HSI to HERC
(without any opportunity to cure the breach). 8.2 By THC or HSI Immediately. THC or HSI shall have
the right to immediately terminate this Agreement if HERC: (i) becomes insolvent, or (ii) files a
petition in bankruptcy or is adjudicated a bankrupt, or if a petition in bankruptcy is filed against
HERC and not dismissed within thirty (30) days, or (iii) makes an assignment for the benefit of its
creditors or an arrangement pursuant to any bankruptcy law, or (iv) discontinues its business, or
(v) causes or suffers a receiver to be appointed for it or its business and such receiver has not
been discharged within thirty (30) days after the date of appointment thereof 8.3 No Waiver. No
refusal by either THC or HSI to terminate this Agreement in accordance this section will be deemed
to be a waiver of such Party's right to terminate upon any subsequent or future event by which such
party has, or is provided with, the right to terminate this Agreement. 8
<!-- page 9 -->
8.4 Effect of Termination. Termination of this Agreement shall not result in the termination of any
provisions herein which by their nature are meant to survive termination (including any covenants
herein related to discontinuation of use of licensed intellectual property and the indemnification
provisions hereof), nor shall it relieve any Party of liability for breaches of the terms hereof
prior to termination. For the avoidance of doubt, the Parties agree that in the event of termination
of this Agreement or the Trademark, Trade Name, Domain and Related Rights License Agreement, Section
4.4 of the Trademark, Trade Name, Domain and Related Rights License Agreement contains additional
provisions related to termination of licensed intellectual property pursuant to the terms hereof
that shall apply as if contained herein. 9. Non-Competition. During the Interim Period, neither HERC
nor any of its affiliates or subsidiaries shall, directly or indirectly, engage in the business of
renting or leasing cars, crossovers or light trucks (including sport utility vehicles and light
commercial vehicles) in [any country in which THC or any of its affiliates or subsidiaries rents or
leases cars, crossovers or light trucks (including sport utility vehicles and light commercial
vehicles) as of the date of this Agreement] without THC's prior written consent, except to the
extent materially consistent in type and scope with HERC's operations immediately prior to the date
of this IPA. This provision shall survive the expiration or earlier termination of this Agreement.
10. Governing Law. This Agreement and all disputes or controversies arising out of or relating to
this Agreement or the transactions contemplated hereby shall be governed by, and construed in
accordance with, the internal laws of the State of New York, without regard to the laws of any other
jurisdiction that might be applied because of the conflicts of laws principles of the State of New
York. 11. Notices. 11.1 All notices or other communications required to be sent or given under this
Agreement or any ancillary agreement exhibited hereto will be in writing and will be delivered
personally, by commercial overnight courier, by facsimile or by electronic mail, directed to the
addresses set forth below. Notices are deemed properly given as follows: (a) if delivered
personally, on the date delivered, (b) if delivered by a commercial overnight courier, one (1)
business day after such notice is sent, and (c) if delivered by facsimile or electronic mail, on the
date of transmission, with confirmation of transmission; provided, however, that if the notice is
sent by facsimile or electronic mail, the notice must be followed by a copy of the notice being
delivered by a means provided in (a) or (b): If THC, to: 8501 Williams Road Estero, Florida 33928
Attn: General Counsel 9
<!-- page 10 -->
Fax: (866) 888-3765 E-mail: rfrecker@hertz.com If HSI, to: 8501 Williams Road Estero, Florida 33928
Attn: General Counsel Fax: (866) 888-3765 E-mail: rfrecker@hertz.com If HERC, to: 27500 Riverview
Center Blvd. Bonita Springs, Florida 34135 Attn: Chief Legal Officer Fax: (239) 301-1109 E-mail:
mwaryjas@hertz.com 12. Miscellaneous. 12.1 Authority. Each Party represents, warrants, and agrees
that its corporate officers executing the Agreement have been duly authorized and empowered to do
so. 12.2 Assignment. HERC may not assign, transfer, sublicense or delegate any of its rights
hereunder or delegate its obligations hereunder without the prior written consent of HSI, and any
such purported assignment, transfer, sublicense or delegation, in the absence of such consent, shall
be void and without effect. 12.3 Entire Understanding/Amendment. This Agreement, the agreements
exhibited hereto, the Distribution Agreement and the Ancillary Agreements (as defined in the
Distribution Agreement) set forth the entire agreement and understanding between the Parties with
respect to the subject matter hereof and may not be orally changed, altered, modified or amended in
any respect. To effect any change, modification, alteration or amendment of this Agreement, the same
must be in writing, signed by all Parties hereto. 12.4 Successors and Assigns. This Agreement shall
be binding upon and shall inure to the benefit of all successors and assigns of the Parties
(including by way of merger or sale of all or substantially all assets), subject to the restrictions
on assignment set forth herein. 12.5 No Waiver. Except as otherwise provided in this Agreement,
neither Party waives any rights under this Agreement by delaying or failing to enforce such rights.
No waiver by any Party of any breach or default hereunder shall be deemed to be a waiver of any
subsequent breach or default. Any agreement on the part of any Party to any such waiver shall be
valid only if set forth in a written instrument executed and delivered by a duly 10
<!-- page 11 -->
authorized officer on behalf of such Party. 12.6 Severability. If any provision of this Agreement is
held to be invalid or unenforceable by a court of competent jurisdiction or other authoritative
body, such invalidity or unenforceability will not affect any other provision of this Agreement.
Upon such determination that a provision is invalid or unenforceable, the Parties will negotiate in
good faith to modify this Agreement so as to effect the original intent of the Parties as closely as
possible. 12.7 Relationship of Parties. Each Party shall act as an independent contractor in
carrying out its obligations under this Agreement. Nothing contained in this Agreement shall be
construed to imply a joint venture, partnership or principal/agent relationship between the Parties
and neither Party by virtue of this Agreement shall have the right, power or authority to act or
create any obligation, express or implied, on behalf of the other Party. 12.8 Construction. This
Agreement shall be construed without regard to any presumption or other rule requiring construction
against the Party causing this Agreement to be drafted. 12.9 Exhibits/Schedules. All exhibits and
schedules attached to this Agreement are incorporated herein by reference as though fully set forth
herein. 12.10 Headings. The paragraph headings contained in this Agreement are for reference
purposes only and shall not affect in any way the meaning or interpretation of this Agreement. 12.11
Counterparts. This Agreement may be executed in counterparts, each of which shall be deemed an
original, and all of which shall constitute one and the same agreement. The exchange of copies of
this Agreement and of signature pages by facsimile or PDF transmission shall constitute effective
execution and delivery of this Agreement as to the Parties hereto and may be used in lieu of the
original version of this Agreement for all purposes. Signatures of the Parties hereto transmitted by
facsimile or PDF shall be deemed to be their original signatures for all purposes. 12.12. Conflict.
In the event of a conflict between the terms and conditions of this Agreement and any ancillary
agreement exhibited hereto, the terms and conditions of this Agreement will control. 12.13 Third
Party Beneficiaries. Except as otherwise provided hereunder in Section 5.2 and Section 5.3 with
respect to indemnified parties, nothing contained in this Agreement shall be construed to create any
third-party beneficiary rights in any individual. ***** 11
<!-- page 12 -->
IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be executed by their duly
authorized officers as of the day and year first above written.

THE HERTZ CORPORATION

By: /s/ Richard J. Frecker

Name: Richard J. Frecker

Title: Senior Vice President, Deputy General Counsel Secretary and Acting General Counsel

HERTZ SYSTEM, INC.

By: /s/ Richard J. Frecker

Name: Richard J. Frecker

Title: Vice President

HERC RENTALS INC.

By: /s/ Lawrence H. Silber

Name: Lawrence H. Silber

Title: President and Chief Executive Officer
