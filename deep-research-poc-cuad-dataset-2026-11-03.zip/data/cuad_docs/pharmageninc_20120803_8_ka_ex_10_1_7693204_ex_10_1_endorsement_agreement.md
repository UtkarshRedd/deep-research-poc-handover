<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2012-02-20 |
| Parties | Healthcare Distribution Specialists LLC ("HDS"); Paul Silas ("Celebrity") |
| Source | CUAD v1 / PharmagenInc_20120803_8-KA_EX-10.1_7693204_EX-10.1_Endorsement Agreement |

Exhibit 10.1 ENDORSEMENT AGREEMENT THIS ENDORSEMENT AGREEMENT (the "Agreement") is dated as of this
____day of ____________, 2012, but made effective as of February 20, 2012 ("Effective Date") between
Healthcare Distribution Specialists LLC ("HDS"), a Delaware corporation, and Paul Silas
("Celebrity), an individual. AGREEMENT 1. Engagement. HDS engages Celebrity and Celebrity hereby
accepts the engagement to provide for his endorsement of HDS' product, Clotamin in the United States
(Territory") as further outlined herein. In addition, it is understood and agreed that with respect
to the Website, as defined below, the Territory shall be worldwide. 2. Term of Agreement. The term
of this Agreement shall be for one (1) year commencing on the Effective Date and ending on February
19, 2013 ("Term"). 3. Grant. During the Term and subject to the limitations set forth in Paragraphs
9 and 10, HDS shall have the right to use the name, image, likeness, characterization, visual and
audio representation of Celebrity ("Celebrity Attributes") in connection with HDS' product,
Clotamin, in the Territory as follows: A. In a television commercial (specific spot length to be
mutually agreed upon) promoting Clotamin ("Commercial") aired specifically in the following three
(3) television markets: (1) Washington, DC Metro Area; (2) Florida; and (3) Texas (collectively
"Markets"); B. On HDS' website (www.clotamin.corn) ("Website"); and C. In Clotamin-related press
releases. D. In connection with any HDS' usage of Celebrity Attributes as outlined above in
Paragraphs 3(A)-(C), HDS will feature the following disclaimer in close proximity to said usage:
"PAUL SILAS IS NOT A MEDICAL AUTHORITY. THESE STATEMENTS HAVE NOT BEEN EVALUATED BY THE FOOD AND
DRUG ADMINISTRATION. THIS PRODUCT IS NOT INTENDED TO DIAGNOSE, TREAT, CURE OR PREVENT ANY DISEASE."
4. Duties of Celebrity and Rights of HDS. During the Term and subject to the limitations set forth
in Paragraphs 9 and 10, Celebrity agrees to provide HDS with the following: A. Upon request by HDS,
one (1) production session to be used for the production of the Commercial ("Production Session").
The location, date and time of the Production Session shall be mutually agreed upon by Celebrity and
HDS. In the event the Production Session exceeds eight (8) hours in duration HDS and Celebrity will
negotiate in good faith additional compensation to Celebrity for time in excess of eight (8) hours.

Source: PHARMAGEN, INC., 8-K/A, 8/3/2012
<!-- page 2 -->
B. Celebrity will serve as a member of the Clotamin/HDS Board of Advisors, whose members' sole
responsibility is to be listed as a Clotamin brand ambassador on the Website and/or Clotamin related
press releases. With respect to the Board of Advisors, Celebrity will not be responsible for any
additional services such as attending meetings, corporate functions, etc. C. HDS may request an
additional production session(s), or a media tour or personal appearance(s) for an additional fee to
be mutually agreed upon by the parties. 5. Consideration. As consideration for Celebrity's services
under this Agreement, HDS agrees as follows: A. In-kind Payment: HDS will provide Celebrity with a
one (1) year complimentary supply (i.e., at least 365 caplets) of Clotamin product during the Term.
B. Cash Payment: (1) HDS will provide payment of Fifty Thousand and NO/100 Dollars ($50,000) made
payable to Celebrity's agent. CSE, as follows $10,000 Within ten (10) days of the parties execution
of this Agreement $15,000 Within 60 days of the parties execution of this agreement $25,000* Ten
(10) days prior to the Production Session [*Should Company decide not to conduct the Production
Session, then the $25,000 allocated for said Production Session ("Production Fee") will not be owed
to Celebrity and notice should be given to CSE as soon as reasonably known by Company if Company
does not intend to conduct the Production Session. However, if Company schedules the Production
Session, then said Production Fee is non-refundable regardless if the Production Session occurs. ]
(a) CSE, shall invoice HDS for these fees and HDS shall pay such invoice within ten (10) business
days following receipt of the CSE invoice. (b) Payments shall be made to CSE and delivered to 600
Galleria Parkway, Suite 1900, Atlanta, Georgia 30339. (2) If HDS desires to add an additional market
or state to the Markets for the Commercial to air during the Term, then HOS will pay Celebrity Five
Thousand and NO/100 Dollars ($5,000) for said additional state/market, and the parties will amend
the Agreement to add the additional state/market accordingly. 6. Expenses. If applicable, HDS agrees
to provide and pay for the expenses related to Celebrity's services provided in Paragraph 4, which
shall include but not be limited to the following: A. First-class airfare, first-class ground
transportation, hotel accommodations, and meals for Celebrity; and B. First-class airfare, ground
transportation and hotel accommodations for one (1) representative. 7. Union Dues and Fees. Company
represents that the services hereunder shall not be subject to SAG, AFTRA or any other entertainment
guild contract. 2

Source: PHARMAGEN, INC., 8-K/A, 8/3/2012
<!-- page 3 -->
8. Exclusivity. Celebrity represents and warrants that during the Term and in the Territory,
Celebrity will not endorse or make any appearances or advertisements on behalf of any other
multivitamin. 9. Review, Approval, and Ownership of Advertising. All HDS' uses of Celebrity
Attributes in connection with the Commercial and/or press releases shall be subject to the prior
written approval of Celebrity via his agent, CSE. Said written approval must be given within five
(5) business days of CSE's receipt or said usage shall be deemed unapproved. Any such usage
featuring Celebrity in the Commercial and/or press releases shall be and remain the property of HDS;
however, HDS shall have the right to use said Commercial and/or press releases solely as outlined in
Paragraph 3 and only during the Term. Celebrity may use said materials in whole or in part solely
for the purpose of presenting Celebrity's work in Celebrity's personal portfolio, website or
otherwise and/or on Celebrity's agent's website. Such usage may not be sold or transferred. 10.
Termination A. HDS shall have the right to terminate this Agreement upon ten (10) days prior written
notice to Celebrity in the event Celebrity fails to perform the duties set forth in Paragraph 4
hereof or breaches any other covenant or agreement set forth herein and fails to cure same (if
curable) within seven (7) days of receipt of written notice. Such termination shall relieve HDS of
its obligation to provide any further consideration pursuant to this Agreement. B. Celebrity shall
have the right to terminate this Agreement upon ten (10) days prior written notice to HDS in the
event of the occurrence of any of the following: (1) HDS adjudicates as insolvent or declares
bankruptcy; or (2) HDS fails to provide consideration due pursuant to this Agreement, within ten
(10) days following the date such consideration is due hereunder, provided that HDS is notified in
writing of such non-payment by Celebrity and such payment by HDS is not made within three (3) days
following such notification; or (3) HDS fails breaches any covenant or agreement set forth herein
and fails to cure same (if curable) within seven (7) days of receipt of written notice. Furthermore,
HDS agrees that such termination shall not relieve it of its obligation to provide consideration as
contemplated hereunder. Celebrity shall not have waived any of its rights at law or in equity by
exercising any provision of this paragraph. C. HDS' rights to the use of Celebrity and Celebrity's
Attributes as set forth in Paragraphs 3 and 4 shall end immediately should this Agreement be
terminated pursuant to Paragraph 10(A) or Paragraph 10(B) above. 10. Notices. All notices provided
for herein shall be given in writing by hand delivery, courier service, or by certified mail return
receipt requested to the addresses of the parties set forth as follows (unless change of address by
notice to the other party is given as provided in this paragraph 10): If to Celebrity: If to HDS
Paul Silas Mackie A. Barch, c/o Lonnie Cooper Co-Founder Chief Executive Officer Healthcare
Distribution Specialists LLC CSE 9337 Fraser Avenue 600 Galleria Parkway, Suite 1900 Silver Spring,
MD 20910 Atlanta, GA 30339 with a copy to: Sue Graddy Fax No. (770) 226-5560 3

Source: PHARMAGEN, INC., 8-K/A, 8/3/2012
<!-- page 4 -->
11. Licensing. Nothing contained herein shall be construed to convey to HDS any right to use the
names, trademarks, service marks, symbols, logos, emblems colors, etc. ("Marks") , of the Charlotte
Bobcats, NBA, or any other organization with which the Celebrity is or has been associated. All
rights to the use of such Marks must be acquired from the appropriate rights holder, and if such
Marks are used by HDS then, in such event HDS (a) shall provide Celebrity in advance with
satisfactory evidence of HDS' right to use such Marks and (b) agree to indemnify, protect and hold
Celebrity harmless from and against any and all claims, damages and/or losses which may arise from
HDS' use of such Marks. 12. Representations and Warranties of HDS. Celebrity relies upon HDS' skill
and judgment and also upon the following representations of HDS which shall be in effect throughout
the term of this Agreement: A. HDS' products will be merchantable and fit for the purpose for which
they are intended, and B. HDS' products will conform at all times to all applicable federal, state
and local laws, rules, regulations, ordinances, and other enactments and industry standards,
including, but not limited to, those relating to product safety. 13. Indemnity. HDS shall be solely
responsible for all liability arising out of production, distribution and sale of its product. HDS
hereby agrees to indemnify, defend and hold harmless Celebrity, his agents, representatives and
employees (referred to collectively as "Celebrity Indemnities") from and against any and all claims,
actions, causes or action, damages, injuries, expenses, liabilities (joint and several), penalties
fines, attorneys fees, court costs, and any other expenses incurred by Celebrity Indemnities arising
out of (1) breach by HDS of any of the terms, representations or warranties made by HDS in this
Agreement; or (2) HDS product liability or trademark patent or other proprietary right infringement;
or (3) errors, omissions, fraudulent or negligent acts by HDS, its employees, agents or
subcontractors in connection with (i) any advertising featuring Celebrity; (ii) with the performance
of HDS' duties and obligations under this Agreement; (iii) with the production, distribution,
promotion, marketing and sales of products including related product packaging; and/or (iv) with the
operation and management of its production and distribution facilities, however caused, HDS shall
not be obligated to indemnify Celebrity with respect to damages which are the result of the active
negligence or willful misconduct of Celebrity. 14. Insurance. HDS agrees to provide and maintain at
its own expense, the following insurance coverages: A. Commercial General Liability coverage of
product liability with limits no less than $1,000,000 per occurrence and $2,000,000 aggregate. B.
Umbrella / Excess Liability coverage inclusive of product liability with limits not less than
$5,000,000 per occurrence and aggregate. C. Media Liability insurance with limits not less than
$2,000,000 per occurrence and aggregate. The Celebrity shall be named as an additional insured on
coverages A, B and C. Celebrity is afforded waiver of subrogation on coverages A, B and C. All
policies listed under A, B and C should have a thirty (30) day notice of cancellation provision or
endorsement. HDS will provide Celebrity's agent, CSE, with a certificate of insurance within five
(5) days of its request for same. 15. Relationship of Parties. Nothing contained in this Agreement
shall be deemed or construed to place the parties in the relationship of partners, joint venturers,
principal-agents, or employer-employee, it being understood that the parties hereto are and will
remain independent contractors in all respects and neither party shall have any right to obligate or
bind the other in any manner whatsoever. 4

Source: PHARMAGEN, INC., 8-K/A, 8/3/2012
<!-- page 5 -->
16. Assignment. Neither this Agreement nor any of the rights or obligations contained herein may be
assigned or transferred by either party without the prior written consent of the other party. 17.
Authority to Contract. Each of the parties hereto represents and warrants that it has full right and
power to enter into this Agreement, to perform all obligations to be performed by it hereunder, and
to grant all rights hereunder granted without violating the legal or equitable rights of any other
person or entity, and that the execution and performance of this Agreement will not conflict with or
result in a breach of or default under any of the terms or conditions of any agreement to which
either party has agreed, or is a party, or may be bound. 18. Construction of Agreement. Each party
acknowledges that it has participated in the negotiation of this Agreement and that no provision of
this Agreement shall be construed against or he interpreted to the disadvantage of any party hereto
by any court or other governmental or judicial authority by reason of such party having or deemed to
have structured, dictated or drafted such provision. 19. Merger; Modification. This Agreement
constitutes the entire agreement with respect to the subject matter contained herein and supersedes
all previous communications and agreements between the parties pertaining to the subject matter
hereof, whether written or oral. The terms of this Agreement may not be modified, waived, amended,
discharged, terminated, or supplemented, or otherwise changed, except by a written document executed
by an authorized representative of each party. 20. No Waiver. A waiver by either party of any of the
terms or conditions of this Agreement in any instance shall not be deemed or construed to be a
waiver of such term or condition for the future, or of any subsequent breach thereof, or any other
term or condition of this Agreement. All remedies, rights, undertakings, obligations, and agreements
contained in this Agreement shall be cumulative and none of them shall be in limitation of any other
remedy, right, undertaking, obligation or agreement of either party. 21. Severability. If any
provision of this Agreement, as applied to either party or to any circumstance, shall be adjudged by
a court of competent jurisdiction to be void or unenforceable, whether at law or in equity, then
such determination shall in no way affect any other provision of this Agreement, or the validity or
enforceability of this Agreement. 22. Forum. The parties agree that the U.S. District Court for the
Northern District of Georgia, the Superior Court of Cobb County, the State Court of Cobb County, or
any other forum in Cobb County shall have personal jurisdiction over the parties and that such
courts shall be the exclusive venue with respect to any claims or disputes related to the Agreement.
23. Choice of Law. Regardless of the place of execution hereof, this Agreement, all amendments
hereto, and any and all issues or controversies arising here from or related hereto, shall be
governed by and construed exclusively in accordance with the laws and decisions of the State of
Georgia. 5

Source: PHARMAGEN, INC., 8-K/A, 8/3/2012
<!-- page 6 -->
24. Attorneys' Fees. If any action is necessary to enforce the provisions of this Agreement,
including any claims or demands, or to interpret this Agreement, the prevailing party shall be
entitled to reasonable attorneys' fees, costs and necessary disbursements in addition to any other
relief to which it may otherwise he entitled. 25. Captions: Structure. Section headings used in this
Agreement are for convenience of reference only and shall not in any way affect the interpretation
of any section of this Agreement or of the Agreement itself. 26. Time is of the Essence. Time is of
the essence with respect to the performance of the duties and obligations hereunder. 27.
Counterparts. This Agreement may be executed in one or more counterparts, each of which shall be
deemed an original and all of which when taken together shall he construed as a single instrument.
This Agreement may be executed by facsimile or other electronic transmissions, and signatures on any
facsimile or electronic transmission copy hereof shall be deemed authorized original signatures. 28.
No Third Party Beneficiaries. This Agreement is not for the benefit of any third party and shall be
deemed not to give any right or remedy to such third party, whether referred to herein or not. 29.
Recitals. The recitals contained in this Agreement are true and correct and are incorporated herein
by reference. [SIGNATURE PAGE TO FOLLOW] 6

Source: PHARMAGEN, INC., 8-K/A, 8/3/2012
<!-- page 7 -->
IN WITNESS WHEREOF, the parties hereto have executed this Agreement on the day and date first above
written. WITNESS: Healthcare Distribution Specialists LLC ("HDS") By: /s/ Linda Lee By: /s/ Mackie
A. Barch Date: February 17, 2012 Title: CEO WITNESS: Paul Silas ("Celebrity") By: /s/ Carolyn Silas
By: /s/ Paul Silas Date: March 8, 2012 7

Source: PHARMAGEN, INC., 8-K/A, 8/3/2012
