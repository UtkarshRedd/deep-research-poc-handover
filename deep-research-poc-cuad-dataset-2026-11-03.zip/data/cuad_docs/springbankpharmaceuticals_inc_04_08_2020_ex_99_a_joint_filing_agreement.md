<!-- page 1 -->
# JOINT FILING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| Agreement Date | 2020-04-07 |
| Parties | UBS ONCOLOGY IMPACT FUND L.P.; ONCOLOGY IMPACT FUND (CAYMAN) MANAGEMENT L.P.; MPM ONCOLOGY IMPACT MANAGEMENT LP; MPM ONCOLOGY IMPACT MANAGEMENT GP LLC |
| Source | CUAD v1 / SPRINGBANKPHARMACEUTICALS,INC_04_08_2020-EX-99.A-JOINT FILING AGREEMENT |

EXHIBIT A JOINT FILING AGREEMENT In accordance with Rule 13d-1(k) under the Securities Exchange Act
of 1934, as amended, the undersigned agree to the joint filing on behalf of each of them of a
statement on Schedule 13G (including amendments thereto) with respect to the Common Stock of Spring
Bank Pharmaceuticals, Inc. and further agree that this agreement be included as an exhibit to such
filing. Each party to the agreement expressly authorizes each other party to file on its behalf any
and all amendments to such statement. Each party to this agreement agrees that this joint filing
agreement may be signed in counterparts. In evidence whereof, the undersigned have caused this
Agreement to be executed on their behalf this 7t h day of April, 2020. UBS ONCOLOGY IMPACT FUND L.P.
ONCOLOGY IMPACT FUND (CAYMAN) MANAGEMENT L.P. By: Oncology Impact Fund (Cayman) Management L.P, By:
MPM Oncology Impact Management LP, its General Partner its General Partner By: MPM Oncology Impact
Management LP, By: MPM Oncology Impact Management GP LLC, its General Partner its General Partner
By: MPM Oncology Impact Management GP LLC, By: /s/ Ansbert Gadicke its General Partner Name: Ansbert
Gadicke Title: Managing Member By: /s/ Ansbert Gadicke Name: Ansbert Gadicke Title: Managing Member
MPM ONCOLOGY IMPACT MANAGEMENT LP MPM ONCOLOGY IMPACT MANAGEMENT GP LLC By: MPM Oncology Impact
Management GP LLC, By: /s/ Ansbert Gadicke its General Partner Name: Ansbert Gadicke Title: Managing
Member By: /s/ Ansbert Gadicke Name: Ansbert Gadicke Title: Managing Member
