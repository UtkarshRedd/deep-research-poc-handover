# What renewal term does the Reseller Agreement between McDATA Corporation and MTI Techno...

*Question:* What renewal term does the Reseller Agreement between McDATA Corporation and MTI Technology Corporation (dated 2004-09-29) provide for after the initial term?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Answer

[GAP] No evidence was found for: Answer the question: What renewal term does the Reseller Agreement between McDATA Corporation and MTI Technology Corporation (dated 2004-09-29) provide for after the initial term?

## Verification appendix

Claims: 1 · supported: 0 · partially: 0 · dropped: 0 · gaps: 1

Notes: no evidence in the bank; every section is a gap; OpenAIRateLimitError: Error code: 429

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  |  |

### Evidence

