<!-- page 1 -->
# COOPERATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2015-01-05 |
| Parties | HPIL ENERGYTECH Inc. ("HPIL ET"); GINARES GROUP AG ("GINARES"); HPIL ET and GINARES (individually as "Party, or collectively the "Parties") |
| Source | CUAD v1 / HPILHOLDING_01_07_2015-EX-99.1-COOPERATION AGREEMENT |

COOPERATION AGREEMENT made by and between HPIL ENERGYTECH Inc. and GINARES GROUP AG January 5, 2015
<!-- page 2 -->
Table of Contents 1.
Term...........................................................................................................................................
2 2. Goals And
Objectives................................................................................................................
2 3. Obligations Of The
Parties........................................................................................................
3 4.
Confidentiality...........................................................................................................................
3 5. Relation Of The
Parties.............................................................................................................
3 6.
Closing.......................................................................................................................................
3 7. Representations, Warranties, And Covenants Of
GINARES.................................................... 3 8. Representations, Warranties, And
Covenants Of HPIL ET...................................................... 4 9. GINARES's
Indemnity..............................................................................................................
5 10. HPIL ET's
Indemnity...............................................................................................................
5 11. Payment Of
Expenses................................................................................................................
5 12. Approval Of
Counsel.................................................................................................................
5 13.
Notices.......................................................................................................................................
6 14. Additional
Undertakings............................................................................................................
6 15. Compliance With The Foreign Corrupt Practices Act And Export Control And Antiboycott
Laws...........................................................................................................................................
7 16.
Arbitration..................................................................................................................................
7 17. Governing
Law..........................................................................................................................
7 18. Binding
Effect............................................................................................................................
7 19.
Counterparts...............................................................................................................................
7 20. No
Reliance...............................................................................................................................
8 21. Early
Termination......................................................................................................................
8 22.
Captions.....................................................................................................................................
8 23. Entire
Agreement.......................................................................................................................
8 1
<!-- page 3 -->
COOPERATION AGREEMENT THIS COOPERATION AGREEMENT ("Agreement") is signed this 5th day of January,
2015 (the "Closing Date"), by and between HPIL ENERGYTECH Inc., a Nevada (USA) corporation
(hereafter "HPIL ET") and GINARES GROUP AG, a private company domiciled in Switzerland (hereafter
"GINARES"). R E C I T A L S: The following is a recital of facts underlying this Agreement: A. HPIL
ET is focused on investing in both private and public companies in the energy business sector. HPIL
ET does not restrict its potential candidate target companies to any specific geographical location
and thus acquires various types of business in the energy sector. HPIL ET is active with the
acquisitions of intellectual properties and technologies in the energy sector. B. HPIL ET is a
wholly owned subsidiary of HPIL Holding, a Nevada (USA) corporation and a worldwide diversified
investing holding company. HPIL Holding is a US Public and SEC reporting company. C. GINARES is an
operating international Swiss holding corporation that provides global and independent renewable
energy solutions, in particular related to its NCT technology (Natural Conversion Technology), a
catalytic conversion compression to convert general organic waste (MSW - Municipal Solid Waste) and
all kinds of biomass into liquid fuel energy (such as kerosene and/or diesel) as well as the further
production of electricity, that it has an energy efficiency rate and no toxic chemical byproducts.
D. GINARES operates, and has always operated, according to all regulations in force and is fully
respectful of the environment. GINARES periodically evaluates it's conformity to applicable
regulations and obtains the necessary permits, clearances and certificates. NOW, THEREFORE, HPIL ET
and GINARES (hereafter the "Party" or collectively the "Parties") in consideration of and in
reliance upon the representations, warranties, covenants and agreements contained herein, hereby
agree to cooperate together to expand the GINARES projects and bind themselves to undertake this
Agreement under the following terms and conditions: 1. Term The term of this Agreement shall be one
(1) year unless terminated earlier in accordance with the terms of this Agreement (the "Term"). 2.
Goals And Objectives The Parties are working cooperatively to develop and cooperate to expand the
GINARES projects. The Parties agree to develop a list of target cooperation projects and common
goals, and consequent agreements if required, within six (6) Months of signing this Agreement. 2
<!-- page 4 -->
3. Obligations Of The Parties 3.1. HPIL ET's obligations under this Agreement are to: (i) Follow up
on developments regarding GINARES; (ii) Work with GINARES as appropriate. 3.2. GINARES's obligations
under this Agreement are to: (i) Keep HPIL ET aware of developments regarding GINARES; (ii) Work
with HPIL ET as appropriate. 4. Confidentiality Subject to sub-clause below, each Party shall treat
as strictly confidential all information received or obtained as a result of entering into or
performing this Agreement. Each Party may disclose information which would otherwise be confidential
if and to the extent: (i) required by the law of any relevant jurisdiction; (ii) the information has
come into the public domain through no fault of that Party; or (iii) the other Party has given prior
written approval to the disclosure, provided that any such information disclosed shall be disclosed
only after consultation with and notice to the other Party. 5. Relation Of The Parties The nature of
relationship between the Parties is that of two independent contractor's working together to achieve
common goals. There is no payment or compensation contemplated under this Agreement. 6. Closing The
closing of this Agreement shall take place at the offices of HPIL ET, 7075 Gratiot Road, Suite One,
Saginaw, Michigan 48609 (United States of America), or other mutually agreed upon location. 7.
Representations, Warranties, And Covenants Of GINARES GINARES hereby represents, warrants, and
covenants to HPIL ET that: 7.1. Authorization This Agreement constitutes a valid and legally binding
obligation of GINARES, enforceable in accordance with its terms, except (i) as limited by applicable
bankruptcy, insolvency, reorganization, moratorium and other laws of general application affecting
enforcement of creditors' rights generally and (ii) as limited by laws relating to the availability
of specific performance, injunctive relief or other equitable remedies.

3
<!-- page 5 -->
7.2. Consents To GINARES's knowledge, no consent, approval, order or authorization of, or
registration, qualification, designation, declaration or filing with, any federal, state or local
governmental authority on the part of GINARES is required in connection with the consummation of the
transactions contemplated by this Agreement. 7.3. Compliance With Other Instruments The execution,
delivery and performance of this Agreement contemplated hereby will not result in a violation of, or
default under, any instrument, judgment, order, writ, decree or contract known to GINARES, or an
event that results in the creation of any lien, charge or encumbrance upon the Agreement. 7.4.
Litigation There is no action, suit, proceeding or investigation pending or, to GINARES's knowledge,
currently threatened that questions the validity of this Agreement, or the right of GINARES to enter
into this Agreement. 8. Representations, Warranties, And Covenants Of HPIL ET 8.1. Authorization
This Agreement constitutes a valid and legally binding obligation of HPIL ET, enforceable in
accordance with its terms, except (i) as limited by applicable bankruptcy, insolvency,
reorganization, moratorium and other laws of general application affecting enforcement of creditors'
rights generally and (ii) as limited by laws relating to the availability of specific performance,
injunctive relief or other equitable remedies. 8.2. Consents To HPIL ET's knowledge, no consent,
approval, order or authorization of, or registration, qualification, designation, declaration or
filing with, any federal, state or local governmental authority on the part of HPIL ET is required
in connection with the consummation of the transactions contemplated by this Agreement. 8.3.
Compliance With Other Instruments The execution, delivery and performance of this Agreement
contemplated hereby will not result in a violation of, or default under, any instrument, judgment,
order, writ, decree or contract known to HPIL ET, or an event that results in the creation of any
lien, charge or encumbrance upon the Agreement. 8.4. Litigation There is no action, suit, proceeding
or investigation pending or, to HPIL ET's knowledge, currently threatened that questions the
validity of this Agreement, or the right of HPIL ET to enter into this Agreement. 4
<!-- page 6 -->
9. GINARES's Indemnity 9.1. HPIL ET shall indemnify, defend, and hold harmless GINARES from, against
and with respect to any claim, liability, obligations, loss, damage, assessment, judgment, cost and
expense (including, without limitation, reasonable attorneys' and accountants' fees and costs and
expenses reasonably incurred in investigating, preparing, defending against or prosecuting any
litigation or claim, action, suit, proceeding or demand) or any kind or character (collectively,
"Losses") arising out of or in any manner, incident, relating or attributable to: any inaccuracy in
any representation or breach of warranty of GINARES contained in this Agreement and (ii) any failure
by HPIL ET to perform or observe, or to have performed or observed in full any covenant, agreement
or condition to be performed or observed by HPIL ET under this Agreement or any of the other
agreements or instruments executed and delivered by HPIL ET on the Closing Date. 9.2. GINARES agrees
that the sole and exclusive remedy for money damages related to this Agreement and the transactions
contemplated hereby shall be the rights to indemnification set forth in this Section 9. 10. HPIL
ET's Indemnity 10.1. GINARES shall indemnify, defend, and hold harmless HPIL ET from, against and
with respect to any claim, liability, obligations, loss, damage, assessment, judgment, cost and
expense (including, without limitation, reasonable attorneys' and accountants' fees and costs and
expenses reasonably incurred in investigating, preparing, defending against or prosecuting any
litigation or claim, action, suit, proceeding or demand) or any kind or character (collectively,
"Losses") arising out of or in any manner, incident, relating or attributable to: any inaccuracy in
any representation or breach of warranty of HPIL ET contained in this Agreement and (ii) any failure
by GINARES to perform or observe, or to have performed or observed, in full any covenant, agreement
or condition to be performed or observed by GINARES under this Agreement or any of the other
agreements or instruments executed and delivered by GINARES on the Closing Date. 10.2. HPIL ET
agrees that the sole and exclusive remedy for money damages relating to this Agreement and the
transactions contemplated hereby shall be the rights to indemnification set forth in this Section
10. 11. Payment Of Expenses Each of the Parties shall pay their own expenses associated with this
Agreement and the transactions contemplated herein. 12. Approval Of Counsel All instruments or
documents to be delivered by any Party to this Agreement shall be in form and content reasonably
satisfactory to the counsel for the Party receiving such instrument or document. 5
<!-- page 7 -->
13. Notices All notices and other communications required or permitted hereunder shall be in writing
and shall be deemed to have been duly given (a) when delivered in person, (b) five (5) business days
after being sent by registered or certified mail, return receipt requested, postage prepaid, (c)
when dispatched by electronic facsimile transmission (with confirmation of successful transmission),
or (d) one (1) business day after having been dispatched by an internationally recognized overnight
courier service, in each case to the appropriate Party at the address or facsimile number specified
below: If to HPIL ET: HPIL ENERGYTECH Inc. Attn.: Louis Bertoli, President and CEO 7075 Gratiot
Road, Suite One Saginaw, Michigan 48609 United States of America Facsimile No.: 001(248)750-1016
with a copy (which shall not constitute notice) to the following e-mail addresses:
info@hpilenergytech.com If to the GINARES: GINARES GROUP AG Attn.: Peter Zu Sayn-Wittgenstein,
President and CEO Churerstrasse 47 Pfaeffikon 8808 Switzerland Facsimile No.: +41(55)511-0810 with a
copy (which shall not constitute notice) to the following e-mail address: info@ginares.com Any Party
hereto may change its address or facsimile number for the purposes of this Section 13 by giving
notice as provided herein. 14. Additional Undertakings The Parties shall hereafter each take those
actions and execute and deliver those documents and instruments as shall be reasonably necessary in
order to fulfill the intent and purpose of this Agreement, and shall cooperate in any filing,
registration, investigation or other activity that shall be required or shall occur as a result of
or in connection with this transaction. 6
<!-- page 8 -->
15. Compliance With The Foreign Corrupt Practices Act And Export Control And Antiboycott Laws
Neither GINARES or HPIL ET or any representative of GINARES or HPIL ET in its capacity as such has
violated the Foreign Corrupt Practices Act or the anticorruption laws of any jurisdiction where
GINARES or HPIL ET does business. Each of GINARES and HPIL ET has at all times complied with all
legal requirements relating to export control and trade sanctions or embargoes. Either GINARES or
HPIL ET have violated the antiboycott prohibitions contained in 50 U.S.C. Sections 2401 et seq. or
taken any action that can be penalized under Section 999 of the Internal Revenue Code of 1986, as
amended. 16. Arbitration Any and all disputes or controversies between the Parties arising out of or
in connection with this Agreement shall be finally settled by arbitration in accordance with the
Rules of Arbitration of the International Chamber of Commerce; provided, a Party may seek a
temporary restraining order, preliminary injunction, or other provisional judicial relief if in its
judgment such action is necessary to avoid irreparable damage or to preserve the status quo. Despite
any such action for provisional relief, the Parties will continue to participate in good faith in
the procedures specified in this Section 16. Each Party shall appoint one arbitrator who shall
mutually appoint a third arbitrator who shall be the sole arbitrator for the proceeding. The
arbitration shall be held, and any award shall be rendered, in Paris (France), in the English
language. The award may include reimbursement of the costs of the arbitration (including, without
limitation, reasonable attorney fees) to the prevailing Party or a portion of such costs as
determined by the arbitrator. An award of the arbitrator shall be final and binding on the Parties
and judgment upon the award rendered by the arbitrator may be entered by any court having
jurisdiction. 17. Governing Law This Agreement and its application and interpretation will be
governed exclusively by its terms and the laws of the State of Nevada (USA), and excluding any
conflicts of law provisions which would require the application of any law other than Nevada. 18.
Binding Effect All of the terms and provisions of this Agreement by or for the benefit of the
Parties shall be binding upon and inure to the benefit of their successors, assigns, heirs and
personal representatives. The rights and obligations provided by this Agreement shall not be
assignable by any Party. Except as expressly provided herein, nothing herein is intended to confer
upon any person, other than the Parties and their successors, any rights or remedies under or by
reason of this Agreement. 19. Counterparts This Agreement may be executed simultaneously in two or
more counterparts, each of which shall be deemed an original, but all of which together shall
constitute one and the same Agreement. 7
<!-- page 9 -->
20. No Reliance No third party is entitled to rely on any of the representations, warranties and
agreements contained in this Agreement. The Parties assume no liability to any third party because
of any reliance on the representations, warranties and agreements contained in this Agreement. 21.
Early Termination The Parties may terminate its performance of related obligations under this
Agreement within thirty (30) days of receipt by the Party of written termination notice. 22.
Captions Captions to sections and subsections of this Agreement have been included solely for the
sake of convenient reference and are entirely without substantive effect. 23. Entire Agreement This
Agreement constitutes the entire agreement among the Parties pertaining to the subject matter hereof
and supersedes all prior and contemporaneous agreements, understandings, negotiations and
discussions, whether oral or written, of the Parties and there are no warranties, representations or
other agreements between the Parties in connection with the subject matter hereof except as set
forth specifically herein. No amendment, supplement, modification, waiver or termination of this
Agreement shall be implied or be binding (including, without limitation, any alleged waiver based on
a Party's knowledge of any inaccuracy in any representation or warranty contained herein) unless in
writing and signed by the Party against which such amendment, supplement, modification, waiver or
termination is asserted. No waiver of any of the provisions of this Agreement shall be deemed or
shall constitute a waiver of any other provision hereof (whether or not similar), nor shall such
waiver constitute a continuing waiver unless otherwise expressly therein provided. THIS COOPERATION
AGREEMENT has been entered into as of the date first set forth above. GINARES : GINARES GROUP AG, a
private company domiciled in Switzerland. By: /s/ Peter Zu Sayn-Wittgenstein ​ ​ . Peter Zu Sayn-
Wittgenstein As: President and CEO

HPIL ET : HPIL ENERGYTECH Inc., a Nevada (USA) corporation. By: /s/ Louis Bertoli ​​. Louis Bertoli
As: President and CEO 8
