<!-- page 1 -->
# STRATEGIC ALLIANCE AGREEMENT, d
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2019-12-20 |
| Parties | Farids & Co. LLC ("Farids"); Edible Arrangements, LLC ("EA"); Rocky Mountain Chocolate Factory, Inc. ("Company") |
| Source | CUAD v1 / ROCKYMOUNTAINCHOCOLATEFACTORY,INC_12_23_2019-EX-10.2-STRATEGIC ALLIANCE AGREEMENT |

Exhibit 10.2 PORTIONS OF THIS EXHIBIT MARKED BY [**] HAVE BEEN OMITTED PURSUANT TO RULE 601(B)(10)
OF REGULATION S-K. THE OMITTED INFORMATION IS (I) NOT MATERIAL AND (II) WOULD LIKELY CAUSE
COMPETITIVE HARM TO THE REGISTRANT IF PUBLICLY DISCLOSED. EXECUTION VERSION STRATEGIC ALLIANCE
AGREEMENT STRATEGIC ALLIANCE AGREEMENT, dated as of December 20, 2019 (as amended, supplemented or
otherwise modified from time to time, this "Agreement"), by and among Farids & Co. LLC, a Delaware
limited liability company ("Farids"), Edible Arrangements, LLC, a Delaware limited liability company
("EA"), and Rocky Mountain Chocolate Factory, Inc., a Delaware corporation (the "Company"). W I T N
E S S E T H: WHEREAS, the Company is an international franchisor, confectionery manufacturer and
retail operator; WHEREAS, Farids is a holding company and, together with TF (as defined below),
indirectly controls EA; WHEREAS, EA is a US-based franchisor that specializes in fresh fruit
arrangements and specialty fruit gift items; WHEREAS, the Company desires to issue and sell, and
Farids desires to purchase, 126,839 shares (the "Purchased Shares") of the Company's common stock,
$0.001 par value per share (the "Common Stock"), on the terms set forth herein; WHEREAS,
substantially concurrently with the execution and delivery of this Agreement, the Company and EA
shall execute and deliver the Warrant (as defined below); WHEREAS, substantially concurrently with
the execution and delivery of this Agreement, the Company and EA shall execute and deliver the
Exclusive Supplier Operating Agreement (as defined below); and WHEREAS, in connection with the
foregoing, the Company, Farids and EA agree and acknowledge that the cooperation between the Company
and EA is an important component to achieve their respective strategic objectives, and they desire
to continue and further enhance the strategic cooperation alliance between them as contemplated
under this Agreement. NOW THEREFORE, in consideration of the foregoing and the mutual
representations, warranties, covenants and agreements herein contained, and intending to be legally
bound hereby, the parties hereto agree as follows: ARTICLE I DEFINITIONS Section 1.1 Defined Terms.
(a) "144 Sale" means (i) a Transfer of Shares (including in any broker assisted cashless exercise)
pursuant to Rule 144 under the Securities Act and (ii) for purposes of Article VII only, any
Transfer of Shares pursuant to a Resale Shelf Registration Statement.
<!-- page 2 -->
(b) "Affiliate" of any specified Person means any other Person directly or indirectly controlling or
controlled by or under direct or indirect common control with such specified Person. For purposes of
this definition, "control" (including, with correlative meanings, the terms "controlling,"
"controlled by" and "under common control with"), as used with respect to any Person, shall mean the
possession, directly or indirectly, of the power to direct or cause the direction of the management
or policies of such Person, whether through the ownership of voting securities, by agreement or
otherwise. (c) "Amendment" means the Amendment, dated the date hereof, to the Rights Agreement by
and between the Company and Computershare Trust Company, N.A., as Rights Agent, attached as Exhibit
E hereto. (d) "Board of Directors" means the Board of Directors of the Company. (e) "Bylaws" means
the Second Amended and Restated Bylaws of the Company, as in effect as of the date hereof. (f)
"Certificate of Incorporation" means the Company's Amended and Restated Certificate of
Incorporation, as amended, as in effect as of the date hereof. (g) "Change in Control" means the
occurrence of any of the following: (i) the sale, lease or transfer, in one or a series of related
transactions, of all or substantially all of the assets of the Company to any Person other than a
Permitted Holder; or (ii) at any time, the Company becomes aware of (by way of a report or any other
filing pursuant to Section 13(d) of the Exchange Act, proxy, vote, written notice or otherwise) the
acquisition by any Person or group (within the meaning of Section 13(d)(3) or Section 14(d)(2) of
the Exchange Act, or any successor provision), other than the Permitted Holders, in a single
transaction or in a related series of transactions, by way of merger, consolidation or other
business combination or purchase of beneficial ownership (within the meaning of Rule 13d-3 under the
Exchange Act, or any successor provision) of 50% or more of the total voting power of the Voting
Stock of the Company. (h) "Eligible Registration Statement" means any registration statement (other
than (i) a registration statement on Form S-4 or Form S-8 or any similar or successor form or (ii)
with respect to any corporate reorganization or transaction under Rule 145 of the Securities Act or
other business combination or acquisition transaction, any registration statement related to the
issuance or resale of securities issued in such a transaction) filed by the Company under the
Securities Act in connection with any primary or secondary offering of Common Stock for the account
of the Company and/or any shareholder of the Company, whether or not through the exercise of any
registration rights. (i) "Exchange Act" means the Securities Exchange Act of 1934, as amended. 2
<!-- page 3 -->
(j) "Exclusive Supplier Operating Agreement" means the Exclusive Supplier Operating Agreement, dated
as of the date hereof, by and between EA and the Company, attached as Exhibit B hereto. (k) "Family
Member" means, with respect to any natural person, (i) any child, stepchild, grandchild or more
remote issue, parent, stepparent, grandparent, spouse, domestic partner, sibling, child of sibling,
mother-in-law, father-in-law, son-in-law, daughter-in-law, brother-in-law, sister-in-law, cousin and
adoptive relationships (each, a "family member") or estate of such family member or (ii) any
foundation, trust, family limited partnership, family limited liability company or other entity
created and used for estate planning purposes, so long as any such foundation, trust, family limited
partnership, family limited liability company or other entity is controlled by, for the benefit of,
or owned by such natural person or one or more persons described in clause (i) (such entities
referred to in this clause (ii), the "Permitted Estate Vehicles"). (l) "Farids Group" means Farids,
EA and each and every Farids Transferee. Unless the Company is otherwise notified in writing by
Farids or EA, TF shall at all times serve as the designated representative to act on behalf of the
Farids Group for purposes of this Agreement and shall have the sole power and authority to bind the
Farids Group with respect to all provisions of this Agreement; provided, however, that if TF ceases
to serve as the designated representative of the Farids Group, then TF (or his designated legal
representative in the case of his death or permanent disability) shall have the power to designate a
new designated representative of the Farids Group, which designee (and any successor thereafter
designated and appointed) shall have the sole power and authority to bind the Farids Group with
respect to all provisions of this Agreement. The Company shall be entitled to rely on all actions
taken by TF or such designee on behalf of the Farids Group. (m) "Farids Transferee" means each and
every direct and indirect transferee of Farids (including transferees of Shares from any member of
the Farids Group so long as such Shares were originally held by the Farids Group) pursuant to
Transfer set forth in clause (i) or (ii) of the definition of Permitted Transfer. (n) "FINRA" means
the Financial Industry Regulatory Authority, Inc. (o) "GAAP" means U.S. generally accepted
accounting principles. (p) "Holder" means any Person owning of record Common Stock or any security
convertible into or exercisable or exchangeable for, with or without consideration, any Common
Stock. (q) "Indemnification Agreement" means the Indemnification Agreement, dated as of the date
hereof, by and between the Company and TF, attached as Exhibit D hereto. (r) "Investors" means (i)
Farids, (ii) EA and (iii) TF and his Family Members. (s) "Law" means any domestic or foreign, U.S.
Federal, state, municipality or local law, statute, ordinance, code, rule, or regulation or common
law. 3
<!-- page 4 -->
(t) "Lien" means, with respect to any asset, any mortgage, lien, pledge, charge, security interest
or encumbrance of any kind in respect of such asset, including any agreement to give any of the
foregoing. (u) "Lock-Up Securities" means (i) any Common Stock or Preferred Stock of the Company,
(ii) any security convertible into or exercisable or exchangeable for, with or without
consideration, any Common Stock or Preferred Stock of the Company (including any option to purchase
such a security), (iii) any security carrying any option, warrant or right to subscribe to or
purchase any Common Stock or Preferred Stock of the Company or other security referred to in clause
(ii), or (iv) any such option, warrant or right. (v) "Nasdaq" means The Nasdaq Stock Market LLC. (w)
"Order" means any decree, order, judgment, writ, award, injunction, rule or consent of or by a
Governmental Entity. (x) "Permitted Holders" means each of (i) the Investors and their respective
Affiliates and members of management of the Company and (ii) any group (within the meaning of
Section 13(d)(3) or Section 14(d)(2) of the Exchange Act or any successor provision) of which any of
the foregoing are members; provided that in the case of such group, without giving effect to such
group, Persons specified in clause (i) must collectively beneficially own a majority of the total
voting power of the Voting Stock of the Company beneficially owned by such group. (y) "Permitted
Transfer" means (i) any Transfer to one or more entities that are, directly or indirectly, wholly
owned by Farids or any Family Member of TF, (ii) any Transfer to one or more entities that are
members of the Farids Group and (iii) Transfer made following a Change in Control of Farids or EA or
made pursuant to a Change in Control that constitutes a sale of the Company as a whole; provided,
with respect to each of clause (i)-(iii), so long as the transferee (other than a transferee that
already is party to this Agreement) agrees to be subject to the terms of this Agreement (subject to
any limitation on the assignment of rights by such Person to the transferee in connection with such
Transfer) by executing and delivering a joinder agreement, substantially in the form of Exhibit A
hereto. (z) "Person" means an individual, partnership, corporation, limited liability company,
unincorporated organization, trust, joint venture, government agency, or other entity. (aa)
"Prospectus" means the prospectus included in the Eligible Registration Statement, including any
form of prospectus or any preliminary prospectus, as amended or supplemented by any prospectus
supplement and by all other amendments or supplements to such prospectus, including all
post-effective amendments and all material, if any, incorporated by reference or deemed to be
incorporated by reference into such prospectus. (bb) "Registrable Securities" means all Purchased
Shares and Warrant Shares and any securities into which Common Stock may be converted or exchanged
pursuant to any merger, consolidation, sale of all or any part of the Company's assets, corporate
conversion or other extraordinary transaction of the Company held by the Farids Group, other than
any Common Stock or securities into which Common Stock may be converted or exchanged that (i) have
been sold by the Farids Group to the public either pursuant to a registration statement or Rule 144
or another exemption from the registration requirements of the Securities Act, (ii) except in
connection with a Demand Request by the Farids Group for a registration pursuant to a Resale Shelf
Registration Statement, in the hands of the Farids Group is eligible to be resold pursuant to Rule
144 without any volume limitation or (iii) shall have ceased to be outstanding; provided, that when
determining the amount of Registrable Securities, only the Purchased Shares, any Vested Warrant
Shares and the remaining Warrant Shares eligible for vesting into Vested Warrant Shares shall be
included in such calculation. 4
<!-- page 5 -->
(cc) "Registration Expenses" means all expenses incurred by the Company in complying with Article VI
hereof, including, without limitation, (i) all SEC and other registration and filing fees
(including, without limitation, fees and expenses with respect to (A) filings required to be made
with FINRA and (B) securities or "blue sky" laws, including, without limitation, any fees and
disbursements of counsel for the underwriters in connection with any filing and application made to
or with (and clearance by) FINRA and any "blue sky" qualifications of the Registrable Securities
pursuant to Section 6.6(d)), (ii) preparation, printing, messenger and delivery expenses, (iii) fees
and disbursements of counsel for the Company, (iv) fees and disbursements of independent certified
public accountants and any other persons, including special experts retained by the Company, (v)
expenses related to any special audits incident to or required by any such registration, in each
case, whether or not any Eligible Registration Statement is filed or becomes effective, (vi) all
fees and expenses related to the listing of the Registrable Securities on any securities exchange,
(vii) all internal expenses of the Company, including the compensation of officers and employees of
the Company and the fees and expenses in connection with any annual audit and (viii) the fees and
expenses of one counsel for the Farids Group in connection with the review of any registration
statement, not to exceed $10,000 for each registration. For the avoidance of doubt, any stamp,
transfer or similar taxes or duties payable by the Farids Group in connection with any registration,
sale or distribution of Registrable Securities shall be borne by the Farids Group and not by the
Company. (dd) "Resale Shelf Registration Statement" means a "shelf" registration statement on Form
S-3 pursuant to Rule 415 under the Securities Act; provided that any sales of securities thereunder
will not (i) require a prospectus supplement, (ii) require any additional cooperation from the
Company (except as set forth in Section 6.4(b)) or (iii) be made pursuant to an underwritten
offering. (ee) "Rights Agreement" means the Rights Agreement dated March 1, 2015 between the Company
and Computershare Trust Company, N.A., as Rights Agent. (ff) "SEC" or "Commission" means the
Securities and Exchange Commission. (gg) "Securities Act" means the Securities Act of 1933, as
amended. (hh) "Shares" means, collectively, the Purchased Shares or shares of Common Stock issued or
issuable upon exercise of the Warrants. (ii) "Significant Block" means five percent (5%) or more of
the Company's issued and outstanding Common Stock. 5
<!-- page 6 -->
(jj) "Subsidiary" means, any Person of which at least a majority of the securities or ownership
interests having by their terms ordinary voting power to elect a majority of the board of directors
or other Persons performing similar functions is directly or indirectly owned or controlled by the
Company or by one or more of its Subsidiaries. (kk) "TF" means Tariq Farid, an individual. (ll)
"Threshold Block" means one percent (1%) or more of the Company's issued and outstanding Common
Stock. (mm) "Transaction Documents" means, collectively, this Agreement, the Exclusive Supplier
Operating Agreement, the Warrant, the Indemnification Agreement and the Amendment. (nn) "Transfer"
means any sale, assignment, encumbrance, hypothecation, pledge, conveyance in trust, gift, transfer
by request, devise or descent, entry into any swap or other agreement that transfers, in whole or in
part, any of the economic consequences of ownership (whether to be settled by delivery of the
Purchased Shares, in cash or otherwise) or other transfer or disposition of any kind, including, but
not limited to, transfers to receivers, levying creditors, trustees or receivers in bankruptcy
proceedings or general assignees for the benefit of creditors whether voluntary or by operation of
law, directly or indirectly, of any Purchased Shares. (oo) "Vested Warrant Shares" means the shares
of Common Stock into which the Warrant shall vest and for which the Warrant shall become
exercisable. (pp) "Voting Stock" of the Company as of any date means the shares of capital stock of
the Company that is at the time entitled to vote in the election of the Board of Directors of the
Company. (qq) "Warrant" means the common stock purchase warrant, dated the date hereof, issued to
the EA, providing for the purchase at a purchase price per share of $8.76 of up to 960,677 Warrant
Shares, attached as Exhibit C hereto. (rr) "Warrant Shares" means the shares of Common Stock
issuable upon exercise of the Warrant. ARTICLE II ISSUANCE OF THE PURCHASED SHARES Section 2.1 Share
Purchase. Upon the terms and subject to the conditions set forth in this Agreement, Farids hereby
agrees to purchase, and the Company hereby agrees to issue and sell to Farids, at the Closing (as
defined below), the Purchased Shares (the "Share Purchase"), in consideration of the payment by
Farids to the Company of $999,998.68 (the "Purchase Price") and Farids assistance in developing the
strategic alliance contemplated hereby. The Purchase Price shall be paid by Farids by the Company by
wire transfer of immediately available funds, to one or more bank accounts designated in writing by
the Company, on the Closing Date (as defined below). 6
<!-- page 7 -->
Section 2.2 Closing. The closing of the Share Purchase (the "Closing") shall take place at the
offices of Perkins Coie LLP, 1900 Sixteenth Street Suite 1400, Denver, Colorado 80202, at 11:00 a.m.
Mountain Time or before 90 days after the date hereof (such , the "Closing Date"). Section 2.3
Transactions to be Effected At or Prior to the Closing. At or prior to the Closing, the transactions
below shall take place (except (i) to the extent such day is not a business day, (ii) the
transactions set forth in clauses (a) through (e) below shall take place on or prior to the date
hereof and (iii) the transactions set forth in clauses (f) through (h) shall take place as promptly
as practicable on or after the date hereof, but in no event later than the Closing Date): (a) The
Board of Directors shall have taken all necessary action related to the nomination of TF for
election to the Board of Directors at the Company's annual meeting of stockholders to be held on
January 9, 2020 (the "Annual Meeting"), provided that the mailing and filing of proxy materials
reflecting the nomination of TF to the Board of Directors shall be completed no later than two (2)
business days following the date hereof. (b) The Company and Farids shall execute and deliver this
Agreement. (c) The Company and EA shall execute and deliver the Exclusive Supplier Operating
Agreement and, in consideration of EA entering into the Exclusive Supplier Operating Agreement and
the performance of EA's obligations therein, the Company shall issue the Warrant to EA. Each of the
Exclusive Supplier Operating Agreement and the Warrant is effective as of the date hereof in
accordance with the terms of such document. (d) The Company and TF shall execute and deliver the
Indemnification Agreement. (e) The Company and Computershare Trust Company, N.A. shall execute and
deliver the Amendment. (f) The Company shall receive the approval of Nasdaq with respect to the
supplemental listing of the Purchased Shares and the reservation for issuance on the Nasdaq Global
Market of the Warrant Shares. (g) The Company shall issue to Farids the Purchased Shares in
electronic book-entry form. (h) The Company shall deliver to Farids the irrevocable letter of
instructions addressed to the Company's transfer agent, relating to the issuance of the Purchased
Shares. ARTICLE III REPRESENTATIONS AND WARRANTIES Section 3.1 Representations and Warranties of the
Company. The Company represents and warrants to each of Farids and EA as of the date hereof and as
of the Closing Date that: 7
<!-- page 8 -->
(a) Existence and Power. The Company is a corporation duly organized, validly existing and in good
standing under the laws of the State of Delaware. The Company has all power and authority, corporate
and otherwise, and all governmental licenses, franchises, permits, authorizations, consents and
approvals required to own and operate its properties and assets and to carry on the business as
presently conducted and as proposed to be conducted, except as would not, individually or in the
aggregate, reasonably be expected to have a material adverse effect on the business, results of
operations or financial condition of the Company and its Subsidiaries, taken as a whole (a "Company
Material Adverse Effect"). (b) Capitalization. The authorized capital stock of the Company consists
of (i) 46,000,000 shares of Common Stock and (ii) 250,000,000 shares of preferred stock, $0.001 par
value per share (the "Preferred Stock"), of which 50,000 shares are designated as "Series A Junior
Participating Preferred Stock". As of December 19, 2019, there were 6,004,229 shares of Common Stock
issued and outstanding and no shares of Preferred Stock outstanding. As of December 19, 2019, no
shares of Common Stock or Preferred Stock were reserved for issuance, except for an aggregate of
258,888 shares of Common Stock reserved for issuance upon the exercise of outstanding stock options
and the settlement of restricted stock units issued under the Company's equity incentive plans and
stock incentive plans. All of the issued and outstanding shares of Common Stock have been duly
authorized and validly issued and are fully paid, nonassessable and free of preemptive rights. (c)
Authority; Approvals. The Company has full corporate power and authority to execute and deliver each
of the Transaction Documents to which it is a party and to consummate the transactions contemplated
thereby. The execution and delivery of each of the Transaction Documents to which it is a party and
the consummation by the Company of the transactions contemplated thereby, including, without
limitation, the issuance of the Purchased Shares, the Warrant and the underlying Warrant Shares,
have been duly and validly approved by all necessary corporate action of the Company, and no other
corporate and no shareholder proceedings on the part of the Company are necessary to approve such
Transaction Documents or to consummate the transactions contemplated thereby. The Board of Directors
has taken all actions so that the restrictions contained in Section 203 of the Delaware General
Corporation Law, as amended (the "DGCL"), applicable to a "business combination" (as defined in
Section 203 of the DGCL) do not and will not apply to the execution, delivery or performance of any
Transaction Document and the transactions contemplated hereby and thereby. Each of the Transaction
Documents to which it is a party has been duly and validly executed and delivered by the Company and
(assuming due execution and delivery by Farids and EA, as applicable) constitutes a valid and
binding obligation of the Company, enforceable against the Company in accordance with its terms,
except as enforcement may be limited by general principles of equity whether applied in a court of
law or a court of equity and by bankruptcy, insolvency and similar laws affecting creditors' rights
and remedies generally (collectively, the "Enforceability Exceptions"). (d) Non-Contravention. The
execution, delivery and performance of the Transaction Documents to which it is a party, and the
consummation by the Company of the transactions contemplated hereby and thereby, does not and will
not (i) contravene or conflict with the Certificate of Incorporation or the Bylaws, (ii) contravene
or conflict with or constitute a violation of any provision of any Law or Order binding upon the
Company, (iii) constitute a default under or breach of (with or without the giving of notice or the
passage of time or both) or violate or give rise to any right of termination, cancellation or
acceleration of any material contract or other instrument or obligations binding upon the Company or
by which any shares of the Common Stock or the Preferred Stock or any of the Company's assets is or
may be bound or (iv) result in the creation or imposition of any Lien on any of the shares of Common
Stock or Preferred Stock or any of the Company's assets. 8
<!-- page 9 -->
(e) Consents and Approvals. Assuming the accuracy of the representations and warranties of each of
Farids and EA as set forth in this Agreement and EA as set forth in the Exclusive Supplier Operating
Agreement, as of the Closing Date, no consents or approvals of, or filings or registrations with,
any federal, state or local court, governmental, legislative, judicial, administrative or regulatory
authority, agency, commission, body or other governmental entity or self-regulatory organization
(each, a "Governmental Entity") or of or with any other third party by or on behalf of the Company
or any of its Subsidiaries are necessary for the execution and delivery by the Company of any
Transaction Document to which it is a party and the consummation by the Company of the transactions
contemplated thereby, except for (A) those already obtained or made, (B) the filing of any Eligible
Registration Statement with the Commission pursuant to Article VI, (C) the supplemental listing
application to Nasdaq with respect to the supplemental listing of the Purchased Shares and the
reservation for issuance on the Nasdaq Global Market of the Warrant Shares and (D) any securities or
"blue sky" filings of any state. The transactions contemplated by the Transaction Documents do not
require the consent or approval by the holders of a majority of the outstanding shares of Common
Stock pursuant to Nasdaq Listing Rule 5635. (f) Valid Issuance of Purchased Shares. As of the
Purchase Date, the Purchased Shares shall be, and the Warrant Shares, when issued and delivered to
EA in accordance with the terms of the Warrant will be, validly issued, fully paid, non-assessable
and free of preemptive rights and will be delivered free and clear of all Liens. Except for the
transactions contemplated in the Transaction Documents, the issuance and delivery of the Purchased
Shares and the Warrant does and will not cause the vesting of any securities of the Company to
accelerate, or trigger or create in any Person the right to acquire, purchase, exercise, exchange or
convert any securities of the Company into Common Stock. (g) SEC Filings; Financial Statements. All
forms, reports, schedules, statements and documents required to be filed with the SEC by the Company
(including all exhibits included therein and financial statements, notes and schedules thereto and
documents incorporated by reference therein, the "SEC Reports") during the twelve (12) months prior
to the date hereof were prepared in accordance and complied as of their respective filing dates, in
all material respects, with the requirements of the Securities Act and Exchange Act and the rules
promulgated thereunder and did not at the time they were filed (or if amended or superseded by a
later filing prior to the date hereof, then on the date of such later filing) contain any untrue
statement of material fact or omit to state a material fact required to be stated therein or
necessary in order to make the statements therein, in the light of the circumstances under which
they were made, not misleading. Except as otherwise disclosed in an SEC Report, each of the audited
and unaudited consolidated financial statements (including, in each case, any related notes and
schedules thereto) contained in the SEC Reports (or if amended or superseded by a later filing prior
to the date hereof, then on the date of such later filing) (i) complied in all material respects
with applicable accounting requirements and the published regulations of the SEC with respect
thereto, (ii) were prepared in accordance with GAAP (except, in the case of unaudited financial
statements, to the extent otherwise permitted by the rules and regulations of the SEC) applied on a
consistent basis throughout the periods involved (except as may be indicated therein or as described
in the notes thereto) and (iii) fairly present in all material respects the financial position of
the Company as of the respective dates thereof and the consolidated results of operations and cash
flows for the periods indicated (subject in the case of unaudited financial statements to normal
year-end adjustments and to any other adjustments described therein, including the notes thereto).
Other that certain non-recurring expenses, no material adverse changes have occurred in the
financial condition or business of the Company since the date of the most recent financial statement
included in the SEC reports. 9
<!-- page 10 -->
(h) Application to Takeover Protections. The Company and its Board of Directors have taken all
necessary action, if any, in order to render inapplicable any control share acquisition, fair price,
business combination, poison pill (including any distribution under a rights agreement) or other
similar anti-takeover provision under the Certificate of Incorporation, the Bylaws or the laws of
its jurisdiction of incorporation that is or could become applicable to the Farids Group or any
Person in the Farids Group as a result of Farids, EA and the Company fulfilling their obligations or
exercising their rights under the Transaction Documents, including without limitation as a result of
the Company's issuance of the Purchased Shares, the Warrants and the underlying Warrant Shares and
the ownership of such securities by the Farids Group or any Person in the Farids Group. Section 3.2
Representations and Warranties of Farids and EA. Each of Farids and EA, severally with respect to
itself and not jointly, hereby represents and warrants to the Company, as of the date hereof and as
of the Closing Date that: (a) Existence and Power. Farids is a limited liability company duly
organized, validly existing and in good standing under the laws of the State of Delaware. Farids has
all power and authority, limited liability company and otherwise, and all governmental licenses,
franchises, permits, authorizations, consents and approvals required to own and operate its
properties and assets and to carry on the business as presently conducted and as proposed to be
conducted, except as would not, individually or in the aggregate, reasonably be expected to have a
material adverse effect on the business, results of operations or financial condition of Farids and
its subsidiaries, taken as a whole. EA is a limited liability company duly organized, validly
existing and in good standing under the laws of the State of Delaware. EA has all power and
authority, limited liability company and otherwise, and all governmental licenses, franchises,
permits, authorizations, consents and approvals required to own and operate its properties and
assets and to carry on the business as presently conducted and as proposed to be conducted, except
as would not, individually or in the aggregate, reasonably be expected to have a material adverse
effect on the business, results of operations or financial condition of EA and its subsidiaries,
taken as a whole. (b) Authorization; Approvals. Each of Farids and EA has full power and authority
to execute and deliver each of the Transaction Documents to which it is party, as applicable, and to
consummate the transactions contemplated thereby and the consummation by Farids and EA of the
transactions contemplated thereby have been duly and validly approved by all necessary limited
liability company action of each of Farids and EA, and no other limited liability company and no
member proceedings on the part of either Farids or EA are necessary to approve such Transaction
Documents or to consummate the transactions contemplated thereby. Each of the Transaction Documents
that has been executed and delivered by Farids or EA (assuming due authorization, execution and
delivery by the Company), as applicable, constitutes a valid and binding obligation of Farids or EA,
as applicable, enforceable against Farids or EA, as applicable, in accordance with its terms,
subject to Enforceability Exceptions. 10
<!-- page 11 -->
(c) Non-Contravention. The execution, delivery and performance of the Transaction Documents and the
consummation by Farids and EA of the transactions contemplated hereby and thereby, does not and will
not (i) contravene or conflict with (A) Farids' certificate of formation or operating agreement or
(B) EA's certificate of formation or operating agreement, (ii) contravene or conflict with or
constitute a violation of any provision of any Law or Order binding upon EA or Farids, (iii)
constitute a default under or breach of (with or without the giving of notice or the passage of time
or both) or violate or give rise to any right of termination, cancellation or acceleration of any
material contract or other instrument or obligations binding upon Farids or by which any shares of
the capital stock of Farids or EA or EA or any of Farids' or EA's assets is or may be bound or (iv)
result in the creation or imposition of any Lien on any of the shares of capital stock of Farids or
EA any of Farids' or EA's assets. (d) Consents and Approvals. Assuming the accuracy of the
representations and warranties of the Company as set forth in this Agreement and the Exclusive
Supplier Operating Agreement, as of the Closing Date, no consents or approvals of, or filings or
registrations with, any Governmental Entity or of or with any other third party by or on behalf of
Farids or EA is necessary for the execution and delivery by Farids and EA, as applicable, of the
Transaction Documents and the consummation by Farids and EA, as applicable, of the transactions
contemplated thereby. (e) Ownership of the Company; Control of EA. Except for the transactions
contemplated in the Transaction Documents, none of Farids or any of its Affiliates holds or has any
rights to acquire, whether directly or indirectly, any Common Stock or any other voting or equity
securities of the Company, or any securities convertible into, exchangeable for or exercisable for
Common Stock or any other voting or equity securities of the Company. EA is controlled by Farids.
(f) Accredited Investor; Experience. Farids is an "accredited investor" (as defined in Rule 501
under the Securities Act) and is capable of evaluating the merits and risks of its investment in the
Company and has the capacity to protect its own interests. (g) Acquisition for Own Account. Farids
is acquiring the Purchased Shares for its own account for investment purposes, and not with a view
to, or for the sale in connection with, any distribution thereof in violation of the Securities Act,
and the rules and regulations of the SEC promulgated thereunder, or that would require the issuance
of the Purchased Shares pursuant to this Agreement to be registered under the Securities Act. (h) No
Reliance. Farids has relied upon the representations and warranties set forth herein and its own
investigations and diligence, including a review of the Company's annual, quarterly and current
reports and other documents filed with or furnished to the SEC, and not upon any other information
provided by or on behalf of the Company in making the decision to purchase the Purchased Shares.
Farids understands and acknowledges that neither the Company nor any of the Company's
representatives, agents or attorneys is making or has made at any time any warranties or
representations of any kind or character, express or implied, with respect to any matter or the
Common Stock, except as expressly set forth herein. 11
<!-- page 12 -->
ARTICLE IV BOARD NOMINATION RIGHTS Section 4.1 Springing Nomination Right. Subject to, and only upon
the satisfaction of the conditions set forth in, this Section 4.1 and Section 4.5, (i) the Farids
Group shall have the right to designate TF or, in the event of the death or permanent disability of
TF, another individual that is reasonably acceptable to the Company to be a director of the Company
(TF or its designee in such capacity, the "Director Designee"), and (ii) the Company shall cause the
Director Designee to be nominated as a director of the Company unless and until such Director
Designee is unwilling or unable to serve as a director. The rights and obligations of the Farids
Group and the Company (including, without limitation, the right of the Farids Group to appoint the
Director Designee and the obligation of the Company to cause the Director Designee to be nominated
for election to the Board of Directors (other than with respect to the Annual Meeting)) set forth in
this Article IV shall only be effective immediately after, and only upon, the date the Farids Group
owns 5.0% or more of the issued and outstanding Common Stock. Subject to, and only upon the
satisfaction of the conditions set forth in, this Section 4.1 and Section 4.5, it is understood and
agreed that in the event that a vacancy is created at any time as a result of (i) the death or
permanent disability of any Director Designee or (ii) the retirement, resignation or removal (with
or without cause) of any Director Designee other than TF, then the Farids Group shall have the right
to designate a replacement director (who shall be reasonably acceptable to the Company and shall
satisfy the eligibility requirements in Section 4.3) to fill such vacancy. Section 4.2 Obligations
of the Company. (a) Nomination; Insurance. On or prior to the date of this Agreement or TF's
election to the Board of Directors at the Annual Meeting, as applicable, the Company shall have (x)
nominated TF for election to the Board of Directors at the Annual Meeting, (y) entered into an
Indemnification Agreement with TF as the Director Designee and (z) taken all necessary action for TF
to be covered by the Company's existing directors' liability insurance policy. (b) Nomination.
Subject to, and only upon the satisfaction of the conditions set forth in, this Section 4.1 and
Section 4.5, the Company shall cause the Director Designee to be (x) nominated for election to the
Board of Directors and included in the Board of Director's slate of nominees recommended to the
shareholders of the Company for each election of directors, and recommend to the shareholders of the
Company that the Director Designee be elected to the Board of Directors and (y) included in the
proxy statement (if any) prepared by management of the Company in connection with soliciting proxies
for every meeting of the shareholders of the Company called with respect to the election of members
of the Board of Directors, and at every adjournment or postponement thereof, and on every action or
approval by written consent of the shareholders of the Company or the Board of Directors with
respect to the election of members of the Board of Directors. When applicable pursuant to Section
4.1 and Section 4.5, the Company shall use its commercially reasonable efforts to cause the election
of the Director Designee and otherwise support the Director Designee for election in a manner no
less rigorous and favorable than the manner in which the Company supports, and has historically
supported, its other nominees in the aggregate. Except as otherwise required by applicable Law, the
Company shall not take any action to cause the removal without cause of the Director Designee,
unless it is directed to do so by the Farids Group. 12
<!-- page 13 -->
Section 4.3 Eligibility of Director Designee. Notwithstanding the other provisions of this Article
IV, the Company shall not be obligated to cause to be nominated for election to the Board of
Directors (or to be included in the Board of Directors' slate of nominees to the Company's
stockholders or any proxy statement prepared by management of the Company in connection with
soliciting proxies for meetings of the stockholders of the Company called with respect to the
election of members of the Board of Directors) or recommend to the Company's stockholders the
election of the Director Designee in the event that (i) the Director Designee fails to satisfy all
applicable requirements (other than those relating to independence) regarding qualifying as a
director of the Company under (A) Nasdaq rules (or the rules of the principal market on which shares
of Common Stock are then listed) regarding service as a director and (B) applicable Law; (ii) the
Director Designee has been involved in any of the events enumerated in Item 2(d) or (e) of Schedule
13D under the Exchange Act, (iii) the Director Designee is currently the target of an investigation
by any governmental authority or agency relating to felonious criminal activity or is subject to any
order, decree, or judgment of any court or agency prohibiting service as a director of any public
company or providing investment or financial advisory services or (iv) the Director Designee has
declared or otherwise indicated (whether publicly or to the Company or the Board of Directors) that
she or he is unwilling or unable to serve as a director or otherwise takes actions inconsistent with
her or his election. If any event described in clause (i) through (iv) of the preceding sentence
occurs, (x) if the Director Designee is TF, then the Farids Group shall forfeit its rights under
this Agreement to designate the Director Designee as a member of the Board of Director and shall not
have any right to a replacement designee and (y) if the Director Designee is an individual other
than TF, then the TF Group shall designate a replacement designee who shall be reasonably acceptable
to the Company and shall satisfy the eligibility requirements set forth in this Section 4.3 and such
replacement designee shall thereafter constitute a "Director Designee" under this Agreement. The
Company shall promptly notify the Farids Group in writing of any objection to the Director Designee
in advance of the date on which proxy materials are mailed by the Company in connection with such
election of directors. Section 4.4 Resignation. If Farids' Nomination Right set forth in this
Article IV is currently applicable and is terminated pursuant to Section 4.5, at the request of the
Company, the Director Designee shall offer to resign as a director effective immediately. Section
4.5 Termination. Subject to Section 4.1, the rights and obligations of the Farids Group and the
Company (including, without limitation, the right of the Farids Group to appoint the Director
Designee and the obligation of the Company to cause the Director Designee to be nominated for
election to the Board of Directors) set forth in this Article IV (if applicable, the "Nomination
Right") shall terminate immediately after the date the Farids Group owns less than 5.0% of the
issued and outstanding Common Stock of the Company, and the Director Designee shall no longer be
deemed to be a "Director Designee"; provided further, that, even if the Farids Group owns 5.0% or
more of the issued and outstanding Common Stock, such rights and obligations shall terminate on the
earliest to occur of: (A) for purposes of determining the Nomination Right for the third Contract
Year (as defined in the Exclusive Supplier Operating Agreement), the EA Revenue (as defined in the
Warrant) for the second Contract Year is less than $[**], (B) for purposes of determining the
Nomination Right for the fourth Contract Year, the EA Revenue for the third Contract Year is less
than $[**]; (C) for purposes of determining the Nomination Right for the fifth Contract Year, the EA
Revenue for the fourth Contract Year is less than $[**]; or (D) for purposes of determining the
Nomination Right for the 12-month period following the fifth Contract Year, the EA Revenue for the
fifth Contract Year is less than $[**]. 13
<!-- page 14 -->
ARTICLE V RESTRICTIONS ON TRANSFER Section 5.1 Restrictions on Transfer. (a) Until the second
anniversary of the Closing Date, the Farids Group agrees not to make any Transfer of all or any
portion of the Purchased Shares, except that the Farids Group shall be permitted to make Permitted
Transfers. (b) Notwithstanding anything to the contrary in this Agreement, the Farids Group agrees
that it will not effect any Transfer of Purchased Shares unless such Transfer is made pursuant to an
effective registration statement under the Securities Act or pursuant to an exemption from, or in a
transaction not subject to, the registration requirements of the Securities Act and, in either case,
in compliance with all applicable state securities laws and all applicable securities laws of any
other jurisdiction. The Company agrees, and the Farids Group understands and consents, that the
Company will not take any action to cause or permit the Transfer of any Purchased Shares to be made
on its books (or on any register of securities maintained on its behalf) unless the Transfer is
permitted by and has been made in accordance with the terms of this Agreement and all applicable
securities laws. The Farids Group agrees that in connection with any Transfer of Purchased Shares
that is not made pursuant to a registration statement, the Company may, in its sole discretion,
request an opinion, certifications and other information in form and substance reasonably
satisfactory to the Company and from counsel reasonably satisfactory to the Company stating that
such transaction is exempt from registration under the Securities Act. (c) The Purchased Shares
shall be stamped or otherwise imprinted with legends substantially similar to the following (in
addition to any legend required under applicable state securities laws) or if held in electronic
form, shall be held in an account by the Company's stock transfer agent subject to restrictions on
Transfer substantially consistent with the following legend, which shall be furnished in accordance
with applicable Law: THE SECURITIES REPRESENTED HEREBY HAVE NOT BEEN REGISTERED UNDER THE SECURITIES
ACT OF 1933, AS AMENDED (THE "ACT"), AND MAY NOT BE OFFERED, SOLD OR OTHERWISE TRANSFERRED,
ASSIGNED, PLEDGED OR HYPOTHECATED EXCEPT (A) PURSUANT TO AN EFFECTIVE REGISTRATION STATEMENT UNDER
THE ACT COVERING ANY SUCH TRANSACTION OR (B) PURSUANT TO AN EXEMPTION FROM REGISTRATION THEREUNDER,
SUBJECT TO THE COMPANY'S RIGHT TO RECEIVE AN OPINION OF COUNSEL, CERTIFICATIONS AND OTHER
INFORMATION IN FORM AND SUBSTANCE REASONABLY SATISFACTORY TO THE COMPANY AND FROM COUNSEL REASONABLY
SATISFACTORY TO THE COMPANY STATING THAT SUCH TRANSACTION IS EXEMPT FROM SUCH REGISTRATION
REQUIREMENTS. 14
<!-- page 15 -->
THE SALE, PLEDGE, HYPOTHECATION OR TRANSFER OF THE SECURITIES REPRESENTED BY THIS CERTIFICATE IS
SUBJECT TO THE TERMS AND CONDITIONS OF A CERTAIN STRATEGIC ALLIANCE AGREEMENT DATED AS OF DECEMBER
20, 2019, AMONG FARIDS & CO. LLC, EDIBLE ARRANGEMENTS, LLC AND THE COMPANY (AS THE SAME MAY BE
AMENDED AND IN EFFECT FROM TIME TO TIME). NO SALE, PLEDGE, HYPOTHECATION OR TRANSFER OF THE
SECURITIES REPRESENTED BY THIS CERTIFICATE MAY BE MADE EXCEPT IN ACCORDANCE WITH THE PROVISIONS OF
SUCH STRATEGIC ALLIANCE AGREEMENT. COPIES OF SUCH AGREEMENT MAY BE OBTAINED UPON WRITTEN REQUEST TO
THE SECRETARY OF THE COMPANY. (d) The Farids Group acknowledges and agrees that any Transfer of the
limited liability company interests, partnership interests, shares or other similar equity interests
in any member of the Farids Group or a parent entity of such member will be deemed to constitute a
Transfer of Purchased Shares, and any proposed Transfer of all or any portion of any such interests
in any member of the Farids Group or a parent entity of such member shall be subject to compliance
with the terms of this Agreement as such terms apply to the Farids Group. (e) The Company
acknowledges and agrees that the Farids Group may from time to time pledge, and/or grant a security
interest in, some or all of the legended Purchased Shares in connection with applicable securities
laws, pursuant to a bona fide margin agreement in compliance with a bona fide margin loan. Such a
pledge would not be subject to approval or consent of the Company and no legal opinion of legal
counsel to the pledgee, secured party or pledgor shall be required in connection with the pledge,
but such legal opinion shall be required in connection with a subsequent transfer or foreclosure
following default by the Farids Group transferee of the pledge. No notice shall be required of such
pledge, but the Farids Group's transferee shall promptly notify the Company of any such subsequent
transfer or foreclosure. The Farids Group acknowledges that the Company shall not be responsible for
any pledges relating to, or the grant of any security interest in, any of the Purchased Shares or
for any agreement, understanding or arrangement between the Farids Group and its pledgee or secured
party. At the Farids Group's expense, the Company will execute and deliver such reasonable
documentation as a pledgee or secured party of Purchased Shares may reasonably request in connection
with a pledge or transfer of the Purchased Shares, including the preparation and filing of any
required prospectus supplement under Rule 424(b)(3) of the Securities Act or other applicable
provision of the Securities Act to appropriately amend the list of selling stockholders thereunder.
(f) The legend set forth in Section 5.1(c) above shall be removed and the Company shall issue one or
more certificates without such legend or any other legend to the holder of the Purchased Shares upon
which it is stamped or issue to such holder by electronic delivery, if (i) such Purchased Shares are
registered for resale under the Securities Act, (ii) such Purchased Shares are sold or transferred
pursuant to Rule 144, or (iii) such Purchased Shares are eligible for resale under the Securities
Act without regard to current public information, manner of sale or volume limitations. Any fees
(with respect to the Company's transfer agent, Company counsel or otherwise) associated with the
removal of such legend shall be borne by the Company. 15
<!-- page 16 -->
Section 5.2 Remedy for Prohibited Transfer. In the event that any member of the Farids Group
Transfers any Purchased Shares in contravention of Section 5.1, such Transfer shall be null and
void, and the Company agrees it will not take any action to effect such a Transfer nor will it treat
any alleged transferee as the holder of such Purchased Shares. ARTICLE VI REGISTRATION RIGHTS
Section 6.1 Demand Registration. (a) If the Company shall receive a written request (a "Demand
Request") from the Farids Group that the Company file a registration statement under the Securities
Act covering the registration of all or a portion of the Registrable Securities owned by the Farids
Group, then the Company shall, subject to the limitations of this Section 6.1, effect, as
expeditiously as reasonably possible, the registration under the Securities Act of all Registrable
Securities in accordance with the intended method of distribution thereof that the Farids Group
requests to be registered, subject to the provisions of Section 6.1(c); provided, however, that any
Eligible Resale Registration Statement shall be filed within 90 days following receipt of such
Demand Request and any Resale Shelf Registration Statement shall be filed within 30 days following
receipt of such Demand Request, as applicable. The Farids Group shall have the right to make two (2)
Demand Requests on or after the date that is the second anniversary of the date of this Agreement;
provided, that the Farids Group shall not make more than one (1) Demand Request within any six-month
period. (b) If the Farids Group intends to distribute the Registrable Securities covered by its
request by means of an underwritten public offering, it shall so advise the Company as a part of
their request made pursuant to this Section 6.1. The Farids Group shall have the right to select the
investment bank or banks and managers to administer any offering made in connection with a Demand
Request, including the lead managing underwriter; provided that such investment banks or managers
shall be reasonably acceptable to the Company; provided, further, that if the Farids Group declines
to exercise such right, the Company shall select the investment bank or banks and managers to
administer the offering, but the Farids Group shall continue to have such right pursuant to this
Section 6.1(b) in any subsequent underwritten public offering. (c) Notwithstanding anything herein
to the contrary, the Company shall not be obligated to (i) effect a registration pursuant to Section
6.1 unless the Registrable Securities requested to be registered by the Farids Group, together with
all other shares of Common Stock requested to be registered by any other holder of piggyback
registration rights (each, an "Other Piggyback Holder") pursuant to any agreement containing similar
registration rights as those contained in this Article VI (such other shares, the "Other Registrable
Securities"), are reasonably expected to result in aggregate gross cash proceeds in excess of (x) in
the case of a Resale Shelf Registration Statement, three (3) million dollars ($3,000,000) and (y) in
the case of any other form of registration statement, one (1) million dollars ($1,000,000) or (ii)
prepare, file, effect or maintain a shelf registration statement on Form S-3 (or any successor to
Form S-3) or any similar shelf registration statement (other than a Resale Shelf Registration
Statement) under the Securities Act for the purposes of compliance with any Demand Right pursuant to
this Section 6.1. 16
<!-- page 17 -->
Section 6.2 Piggyback Registrations. (a) From and after the second anniversary of the date of this
Agreement, the Company shall notify the Farids Group (unless the Farids Group has demanded such
registration pursuant to Section 6.1) in writing at least five (5) business days prior to the
initial public filing of any Eligible Registration Statement. Such notice from the Company shall
state the intended method of distribution of the Registrable Securities included in such Eligible
Registration Statement. The Company shall afford the Farids Group the opportunity to include
Registrable Securities in such Eligible Registration Statement so long as it agrees to sell its
Registrable Securities pursuant to the same method of distribution. If the Farids Group desires to
include Registrable Securities held by it in any such Eligible Registration Statement, it shall,
within four (4) business days after the above-described notice from the Company, so notify the
Company in writing. Any such notice from the Farids Group shall (i) specify the amount of
Registrable Securities that the Farids Group would like to include in such Eligible Registration
Statement and (ii) include the agreement of the Farids Group to participate in any related
underwritten offering on the same terms as the other participating Holders. Upon such written notice
from the Farids Group, the Company will use its best efforts to effect the registration under the
Securities Act of all Registrable Securities which the Farids Group has requested to be registered.
If the Farids Group decides not to or is unable to include all of its Registrable Securities in any
Eligible Registration Statement filed by the Company, the Farids Group shall nevertheless continue
to have the right to include Registrable Securities in any subsequent Eligible Registration
Statement as may be filed by the Company, all upon the terms and conditions set forth herein. Prior
to the effectiveness of the applicable Eligible Registration Statement, the Farids Group may
withdraw from such Eligible Registration Statement any of the Registrable Securities at any time
upon written notice to the Company. (b) Underwriting. If the Eligible Registration Statement under
which the Company gives notice under this Section 6.2 is for an underwritten offering, the Company
shall so advise the Farids Group. In such event, the right of the Farids Group to be included in an
Eligible Registration Statement pursuant to this Section 6.2 shall be conditioned upon the Farids
Group's participation in such underwriting by executing and delivering a custody agreement and power
of attorney in form and substance reasonably satisfactory to the Company with respect to such
Registrable Securities (the "Custody Agreement and Power of Attorney"), which Custody Agreement and
Power of Attorney shall permit the Farids Group to, prior to the effectiveness of such Eligible
Registration Statement, withdraw any of the Registrable Securities at any time from such Eligible
Registration Statement upon written notice to the Company and the custodian. The Custody Agreement
and Power of Attorney will provide, among other things, that (i) the Farids Group will, to the
extent applicable, deliver to and deposit in custody with the custodian and attorney-in-fact named
therein one or more certificates representing such Registrable Securities, accompanied by duly
executed stock powers in blank, and irrevocably appoint said custodian and attorney-in-fact with
full power and authority to act under the Custody Agreement and Power of Attorney on the Farids
Group's behalf with respect to the matters specified therein, including, but not limited to, the
entry into an underwriting agreement (the "Underwriting Agreement"") in customary form with the
underwriter(s) and such other documents and agreements reasonably required in connection with such
registration or offering and (ii) the Farids Group will perform its obligations under such
Underwriting Agreement and any other agreement entered into in connection with such registration
and/or offering. The Farids Group also agrees to execute such other documents and agreements as the
Company may reasonably request to effect the provisions of this Section 6.2 and any transactions
contemplated hereby. 17
<!-- page 18 -->
Section 6.3 Priority on Registrations. Notwithstanding any other provision of this Article VI, if
the lead managing underwriter or underwriters advise, in the case of a requested registration
pursuant to Section 6.1, the Farids Group or, in all other cases, the Company that marketing factors
(including, but not limited to, an adverse effect on the per share offering price) require a
limitation of the number of shares to be included in an underwritten offering (including Registrable
Securities), then the Farids Group or the Company, as the case may be, shall so advise all holders
of Registrable Securities and all Other Piggyback Holders who have requested to participate in such
offering, that (i) if the requested registration is pursuant to Section 6.1, the number of shares
that may be included in the underwriting shall be allocated first to the Farids Group for its own
account, and second to the Company (to the extent it is selling shares of Common Stock in such
offering) and the Other Piggyback Holders who have duly requested shares to be included therein on a
pro rata basis based on the number of shares proposed to be sold by the Company and the number of
Other Registrable Securities requested to be included by such Other Piggyback Holders, and (ii) if
the requested registration is not pursuant to Section 6.1, the number of shares that may be included
in the underwriting shall be allocated first to the Company for its own account (to the extent such
registration was initiated by the Company) or to such Holder of Other Registrable Securities who
demanded such registration pursuant to demand rights similar to those set forth in this Agreement,
and second to the Company (to the extent such registration was not initiated by the Company), the
Farids Group and the Other Piggyback Holders who have duly requested shares to be included therein
on a pro rata basis based on the number of shares proposed to be sold by the Company (to the extent
such registration was not initiated by the Company), the number of Registrable Securities requested
to be included by the Farids Group and the number of Other Registrable Securities requested to be
included by all such Other Piggyback Holders. For any Other Piggyback Holder which is a partnership,
limited liability company or corporation, the partners, members or shareholders, as applicable, of
such Other Piggyback Holder and the estates and Family Members of any such partners, members and
shareholders and any trusts for the benefit of any of the foregoing Person(s) shall be deemed to be
a single "Other Piggyback Holder," and any pro rata reduction with respect to such "Other Piggyback
Holder" pursuant to this Section 6.3 shall be based upon the aggregate amount of shares carrying
registration rights owned by all Persons deemed to constitute such "Other Piggyback Holder" (as
defined in this sentence). Section 6.4 Termination, Effectiveness, Postponement and Suspension of
Registration. (a) Right to Terminate Registration. If the Farids Group determines for any reason not
to proceed with any proposed registration requested pursuant to Section 6.1, the Farids Group shall
promptly notify the Company in writing. Upon receipt of such notice, the Company shall withdraw or
terminate such registration whether or not any Other Piggyback Holder has elected to include any
Other Registrable Securities in such registration. In addition, the Company shall have the right to
withdraw or terminate any proposed registration initiated by it and a Holder of Other Registrable
Securities shall have the right to withdraw or terminate any proposed registration initiated by it,
whether or not the Farids Group or any Other Piggyback Holder has elected to include Registrable
Securities or Other Registrable Securities, as the case may be, in such registration. The Company
shall promptly give notice of the withdrawal or termination of any registration to the Farids Group,
to the extent the Farids Group has elected to participate in such registration. The Registration
Expenses of any such withdrawn or terminated registration shall be borne by the Company in
accordance with Section 6.5. 18
<!-- page 19 -->
(b) Effectiveness of the Registration Statement. The Company shall maintain the effectiveness of the
Eligible Registration Statement until the earlier of (i) the date on which all Registrable
Securities included in such Eligible Registration Statement have actually been sold and (ii) the
date that is (x) 180 days (in respect of a Resale Shelf Registration Statement) or (y) 90 days (in
respect of any Eligible Registration Statement other than a Resale Shelf Registration Statement)
from the effective date of such Eligible Registration Statement. (c) Postponement or Suspension of
Registration. If the filing, initial effectiveness or continued use of an Eligible Registration
Statement in respect of a registration pursuant to this Agreement at any time would require the
Company to make a public disclosure of material non-public information, (1) which disclosure in the
good faith judgment of the Board of Directors (after consultation with external legal counsel) (x)
would be required to be made in any registration statement so that such registration statement would
not contain a material misstatement or omission, (y) would not be required by applicable Law to be
made at such time but for the filing, effectiveness or continued use of such Eligible Registration
Statement and (z) would reasonably be expected to have a Company Material Adverse Effect or a
material adverse effect on the Company's ability to effect a material proposed acquisition,
disposition, financing, business opportunity, reorganization, recapitalization or similar
transaction or (2) during a customary "blackout" period of the Company, then the Company may, upon
giving prompt written notice of such determination to the Farids Group, delay the filing or initial
effectiveness of, or suspend the use of, such Eligible Registration Statement; provided, that the
Company shall not be permitted to do so pursuant to clause (1) above (x) more than two times during
any twelve (12) month period or (y) for a period exceeding thirty (30) days on any one occasion
(unless a longer period is consented to by the Farids Group) (the "Suspension Period"). In the event
the Company exercises its rights under the preceding sentence, the Farids Group agrees to suspend,
promptly upon its receipt of the notice referred to above, its use of any prospectus relating to
such registration in connection with any sale or offer to sell Registrable Securities. If so
requested by the Company, the Farids Group shall use its reasonable best efforts to deliver to the
Company (at the Company's expense) all copies, other than permanent file copies then in the Farids
Group's possession, of the prospectus relating to such Registrable Securities at the time of receipt
of such notice. The Company agrees that, in the event it exercises its rights under this Section
6.4(c), it shall (i) promptly notify the Farids Group of the termination or expiration of any
Suspension Period, (ii) within thirty (30) days after delivery of the notice referred to above
(unless a longer period is consented to by the Farids Group), resume the process of filing or
request for effectiveness, or update the suspended registration statement, as the case may be, as
may be necessary to permit the Farids Group to offer and sell its Registrable Securities in
accordance with applicable Law and (iii) if an Eligible Registration Statement that was already
effective had been suspended as result of the exercise of such rights by the Company, promptly
notify the Farids Group after the termination or expiration of any Suspension Period of the
applicable time period during which the Eligible Registration Statement is to remain effective,
which shall be extended by a period of time equal to the duration of the Suspension Period. 19
<!-- page 20 -->
Section 6.5 Expenses of Registration. Except as specifically provided herein, all Registration
Expenses incurred in connection with any registration under Sections 6.1 and 6.2 shall be borne by
the Company. All underwriting fees and selling commissions relating to the distribution of the
Registrable Securities and all taxes, if any, on the transfer and sale, respectively, of the
Registrable Securities being sold that are incurred in connection with any registrations hereunder
shall be borne by the Farids Group. For the avoidance of doubt, all underwriting fees, selling
commissions and taxes incurred in connection with any registration hereunder relating to securities
sold by the Company shall be borne by the Company. Section 6.6 Obligations of the Company. If and
whenever the Company is required to effect the registration of any Registrable Securities under the
Securities Act as provided in Sections 6.1 and 6.2 (to the extent the Farids Group has requested to
include Registrable Securities in an Eligible Registration Statement pursuant to clause (a) of such
Section 6.1 or 6.2, as the case may be), the Company shall effect such registration to permit the
sale of such Registrable Securities in accordance with the intended method or methods of
distribution thereof, and pursuant thereto the Company shall cooperate in the sale of the securities
and shall, as expeditiously as reasonably possible: (a) Prepare and file with the SEC an Eligible
Registration Statement on such form as shall be available for the sale of the Registrable Securities
by the Farids Group in accordance with the intended method of distribution thereof and the
provisions of this Article VI, and use its reasonable best efforts to cause each such Eligible
Registration Statement to become effective and remain effective as provided herein; provided,
however, that before filing any Eligible Registration Statement or Prospectus or any amendments or
supplements thereto (not including documents that would be incorporated or deemed to be incorporated
therein by reference), the Company shall afford the Farids Group, its counsel and the managing
underwriter, if any, an opportunity to review copies of all such documents proposed to be filed. The
Company shall not file any Eligible Registration Statement or Prospectus or any amendments or
supplements thereto in respect of which the Farids Group has a right to review prior to the filing
of such document, if the Farids Group, its counsel or the managing underwriter, if any, shall
reasonably object, in writing, on a timely basis. (b) Prepare and file with the SEC such amendments
and post-effective amendments to each Eligible Registration Statement as may be necessary to keep
such Eligible Registration Statement continuously effective for the effectiveness period; and comply
with the provisions of the Securities Act, the Exchange Act and the rules and regulations of the SEC
promulgated thereunder applicable to it with respect to the disposition of all securities covered by
such Eligible Registration Statement as so amended or in such Prospectus as so supplemented. 20
<!-- page 21 -->
(c) Notify the Farids Group, its counsel and the managing underwriter, if any, promptly (but in any
event within 10 business days), and confirm such notice in writing, (i) when a Prospectus or any
prospectus supplement or post-effective amendment has been filed, and, with respect to an Eligible
Registration Statement or any post-effective amendment, when the same has become effective
(including in such notice a written statement that the Farids Group may, upon request, obtain,
without charge, one conformed copy of such Eligible Registration Statement or post-effective
amendment including financial statements and schedules, all documents incorporated or deemed to be
incorporated by reference and all exhibits), (ii) of the issuance by the SEC of any stop order
suspending the effectiveness of a Eligible Registration Statement or of any order preventing or
suspending the use of any preliminary prospectus or the initiation of any proceedings for that
purpose, (iii) if at any time when a prospectus is required by the Securities Act to be delivered in
connection with sales of the Eligible Registrable Securities the representations and warranties of
the Company contained in any agreement (including any underwriting agreement) contemplated by
Section 6.6(k) below cease to be true and correct in all material respects, (iv) of the receipt by
the Company of any notification with respect to the suspension of the qualification or exemption
from qualification of an Eligible Registration Statement or any of the Registrable Securities for
offer or sale in any jurisdiction, or the initiation or threatening of any proceeding for such
purpose, (v) of the happening of any event that makes any statement made in such Eligible
Registration Statement or related Prospectus or any document incorporated or deemed to be
incorporated therein by reference untrue in any material respect or that requires the making of any
changes in such Eligible Registration Statement, Prospectus or documents so that, in the case of
such Eligible Registration Statement, it will not contain any untrue statement of a material fact or
omit to state any material fact required to be stated therein or necessary to make the statements
therein not misleading, and that in the case of the Prospectus, it will not contain any untrue
statement of a material fact or omit to state any material fact required to be stated therein or
necessary to make the statements therein, in light of the circumstances under which they were made,
not misleading, and (vi) of the Company's reasonable determination that a post-effective amendment
to an Eligible Registration Statement would be appropriate. (d) Use its reasonable best efforts to
prevent the issuance of any order suspending the effectiveness of an Eligible Registration Statement
or of any order preventing or suspending the use of a Prospectus or suspending the qualification (or
exemption from qualification) of any of the Registrable Securities for sale in any jurisdiction,
and, if any such order is issued, to obtain the withdrawal of any such order at the earliest
possible moment. (e) If requested by the managing underwriter, if any, or the Farids Group, (i)
promptly incorporate in a post-effective amendment such information as the managing underwriter, if
any, or the Farids Group reasonably requests to be included therein to comply with applicable Law,
(ii) make all required filings of such post-effective amendment as soon as practicable after the
Company has received notification of the matters to be incorporated in such post-effective
amendment, and (iii) supplement or make amendments to such Eligible Registration Statement;
provided, however, that the Company shall not be required to take any actions under this Section
6.6(e) that are not, in the opinion of counsel for the Company, in compliance with applicable Law.
(f) Furnish to the Farids Group and each managing underwriter, if any, without charge, one conformed
copy of the Eligible Registration Statement or Statements and each post-effective amendment thereto,
including financial statements and schedules, all documents incorporated or deemed to be
incorporated therein by reference and all exhibits. 21
<!-- page 22 -->
(g) Deliver to the Farids Group, its counsel and the underwriters, if any, without charge, as many
copies of the Prospectus or Prospectuses (including each form of prospectus) and each amendment or
supplement thereto as such Persons may reasonably request; and, the Company hereby consents to the
use of such Prospectus and each amendment or supplement thereto by the Farids Group and the
underwriters, if any, in connection with the offering and sale of the Registrable Securities covered
by such Prospectus and an amendment or supplement thereto. (h) Prior to any public offering of
Registrable Securities, to use its reasonable best efforts to register or qualify, and cooperate
with the Farids Group, the underwriters, if any, the sales agent and their respective counsel in
connection with the registration or qualification (or exemption from such registration or
qualification) of such Registrable Securities for offer and sale under the securities or "blue sky"
laws of such jurisdictions within the United States as the Farids Group or the managing underwriter,
if any, reasonably request in writing; use its reasonable best efforts to keep each such
registration or qualification (or exemption therefrom) effective during the period during which the
related Eligible Registration Statement is required to be kept effective and use its reasonable best
efforts to do any and all other acts or things necessary or advisable to enable the disposition in
such jurisdictions of the Registrable Securities covered by the applicable Eligible Registration
Statement; provided, however, that the Company will not be required to (A) qualify generally to do
business in any jurisdiction where it is not then so qualified or (B) take any action that would
subject it to general service of process or taxation in any such jurisdiction where it is not then
so subject. (i) Upon the occurrence of any event contemplated by clause (v) or (vi) of Section
6.6(c) above, as promptly as practicable prepare a supplement or post-effective amendment to the
Eligible Registration Statement or a supplement to the related Prospectus or any document
incorporated or deemed to be incorporated therein by reference, or file any other required document
so that, as thereafter delivered to the purchasers of the Registrable Securities being sold
thereunder, such Prospectus will not contain an untrue statement of a material fact or omit to state
a material fact required to be stated therein or necessary to make the statements therein, in light
of the circumstances under which they were made, not misleading. (j) Enter into an underwriting
agreement in form, scope and substance as is customary in underwritten offerings and take all such
other actions as are reasonably requested by the managing underwriter in order to expedite or
facilitate the registration or the disposition of such Registrable Securities, and in such
connection, (i) make such customary representations and warranties to the underwriters, with respect
to the business of the Company and its subsidiaries, and the Eligible Registration Statement,
Prospectus and documents, if any, incorporated or deemed to be incorporated by reference therein;
(ii) obtain opinions of counsel to the Company and updates thereof (which counsel and opinions shall
be reasonably satisfactory (in form, scope and substance) to the managing underwriter), addressed to
the underwriters covering the matters customarily covered in opinions requested in underwritten
offerings and such other matters as may be reasonably requested by the underwriters; and (iii)
obtain "comfort" letters and updates thereof from the independent certified public accountants of
the Company (and, if necessary, any other independent certified public accountants of any subsidiary
of the Company or of any business acquired by the Company for which financial statements and
financial data are, or are required to be, included in the Eligible Registration Statement),
addressed to each of the underwriters, such letters to be in customary form and covering matters of
the type customarily covered in "comfort" letters in connection with underwritten offerings. The
above shall be done at each closing under such underwriting agreement, or as and to the extent
required thereunder. 22
<!-- page 23 -->
(k) Use its reasonable best efforts to cause all Registrable Securities covered by such Eligible
Registration Statement to be listed on each securities exchange on which the Common Stock is then
listed. (l) Comply with all applicable rules and regulations of the SEC and make generally available
to its security-holders earnings statements satisfying the provisions of Section 11(a) of the
Securities Act and Rule 158 thereunder (or any similar rule promulgated under the Securities Act) no
later than 45 days after the end of any 12-month period (or 90 days after the end of any 12-month
period if such period is a fiscal year) (i) commencing at the end of any fiscal quarter in which
Registrable Securities are sold to underwriters in a firm commitment or best efforts underwritten
offering and (ii) if not sold to underwriters in such an offering, commencing on the first day of
the first fiscal quarter of the Company after the effectiveness date of an Eligible Registration
Statement, which statements shall cover said 12-month periods. Section 6.7 Delay of Registration;
Furnishing Information. It shall be a condition precedent to the obligations of the Company to take
any action pursuant to Section 6.1 or 6.2 that the Farids Group shall furnish to the Company such
information regarding itself, the Registrable Securities held by it and the intended method of
distribution of such securities as required by Section 6.12 or as otherwise reasonably requested by
the Company. Section 6.8 Indemnification. In the event any Registrable Securities are included in an
Eligible Registration Statement under Section 6.1 or 6.2: (a) To the fullest extent permitted by
law, the Company will indemnify and hold harmless the Farids Group, the partners, members, directors
and officers of any member of the Farids Group, any underwriter (as defined in the Securities Act),
the directors and officers of such underwriter, and each person, if any, who controls any member of
the Farids Group or such underwriter within the meaning of the Securities Act or the Exchange Act
(collectively, the "Non-Company Indemnified Parties"), against any losses, claims, damages, or
liabilities (joint or several) to which they may become subject under the Securities Act, the
Exchange Act or other federal or state law, insofar as such losses, claims, damages or liabilities
(or suits, actions or proceedings in respect thereof) and reasonable documented expenses that arise
out of or are based upon any of the following statements, omissions or violations by the Company:
(i) any untrue statement or alleged untrue statement of a material fact contained in such Eligible
Registration Statement or incorporated by reference therein, including any preliminary prospectus,
final prospectus or summary prospectus contained therein or any amendments or supplements thereto or
any document incorporated by reference therein, or any other such disclosure document (including
reports and other documents filed under the Exchange Act and any document incorporated by reference
therein) or related document or report, (ii) any omission or alleged omission to state therein a
material fact required to be stated therein (in the case of an Eligible Registration Statement
only), or necessary to make the statements therein not misleading, in the case of a prospectus, in
the light of the circumstances when they were made, or (iii) any violation or alleged violation by
the Company or any of its subsidiaries of the Securities Act, the Exchange Act, any state securities
law or any rule or regulation promulgated under the Securities Act, the Exchange Act or any federal,
state, foreign or common law, rule or regulation in connection with the offering covered by such
Eligible Registration Statement (collectively, a "Violation"); and the Company will reimburse each
such Non-Company Indemnified Party for any reasonable legal or other expenses reasonably incurred by
them in connection with investigating or defending any such loss, claim, damage, liability, suit,
action or proceeding; provided, however, that the indemnity agreement contained in this Section
6.8(a) shall not apply to amounts paid in settlement of any such loss, claim, damage, liability,
suit, action or proceeding if such settlement is effected without the consent of the Company, which
consent shall not be unreasonably withheld, delayed or conditioned, nor shall the Company be liable
in any such case for any such loss, claim, damage, liability, suit, action or proceeding to the
extent that it arises out of or is based upon a Violation which occurs in reliance upon and in
conformity with written information furnished expressly for use in connection with such Eligible
Registration Statement by such Non-Company Indemnified Party. 23
<!-- page 24 -->
(b) To the fullest extent permitted by law, the Farids Group will, jointly and severally, indemnify
and hold harmless the Company, each of its directors, officers, employees, agents, representatives,
and each person, if any, who controls the Company within the meaning of the Securities Act or the
Exchange Act, any underwriter (as defined in the Securities Act), the directors and officers of such
underwriter, and each person, if any, who controls such underwriter within the meaning of the
Securities Act or the Exchange Act, against any losses, claims, damages or liabilities (joint or
several) to which the Company or any such director, officer, employee, agent, representative,
controlling person or underwriter may become subject under the Securities Act, the Exchange Act or
other federal or state law, insofar as such losses, claims, damages or liabilities (or suits,
actions or proceedings in respect thereof) and reasonable documented expenses that arise out of or
are based upon any of the following statements, omissions or violations: (i) any untrue statement or
alleged untrue statement of a material fact contained in such Eligible Registration Statement or
incorporated by reference therein, including any preliminary prospectus, final prospectus or summary
prospectus contained therein or any amendments or supplements thereto or any document incorporated
by reference therein, or any other such disclosure document (including reports and other documents
filed under the Exchange Act and any document incorporated by reference therein) or related document
or report, (ii) any omission or alleged omission to state therein a material fact required to be
stated therein (in the case of an Eligible Registration Statement only), or necessary to make the
statements therein not misleading, in the case of a prospectus, in the light of the circumstances
when they were made, or (iii) any violation or alleged violation by the Company or any of its
subsidiaries of the Securities Act, the Exchange Act, any state securities law or any rule or
regulation promulgated under the Securities Act, the Exchange Act or any federal, state, foreign or
common law, rule or regulation in connection with the offering covered by such Eligible Registration
Statement (collectively, a "Holder Violation"), in each case to the extent (and only to the extent)
that such Holder Violation occurs in reliance upon and in conformity with written information
furnished by the Farids Group expressly for use in connection with such Eligible Registration
Statement; and the Farids Group will reimburse any legal or other expenses reasonably incurred by
the Company or any such director, officer, employee, agent, representative, controlling person or
underwriter in connection with investigating or defending any such loss, claim, damage, liability,
suit, action or proceeding if it is judicially determined that there was such a Holder Violation;
provided, however, that the indemnity agreement contained in this Section 6.8(b) shall not apply to
amounts paid in settlement of any such loss, claim, damage, liability, suit, action or proceeding if
such settlement is effected without the consent of the Farids Group, which consent shall not be
unreasonably withheld, delayed or conditioned; provided, further, that in no event shall any
indemnity under this Section 6.8(b) exceed the net proceeds from the offering received by the Farids
Group upon the sale of the Registrable Securities giving rise to such indemnification obligation. 24
<!-- page 25 -->
(c) Promptly after receipt by an indemnified party under paragraph (a) or (b) of this Section 6.8
(an "Indemnified Party") of written notice of the commencement of any claim, damage, suit, action or
proceeding (including any governmental or regulatory investigation) being brought or asserted
against it, such Indemnified Party will, if a claim in respect thereof is to be made against any
indemnifying party under paragraph (a) or (b) of this Section 6.8 (an "Indemnifying Party"), deliver
to the Indemnifying Party a written notice of the commencement thereof; provided, that the failure
of the Indemnified Party to deliver written notice to the Indemnifying Party shall not relieve it
from any liability it may have under paragraph (a) or (b) of this Section 6.8 except to the extent
such failure has materially prejudiced the Indemnifying Party's ability to defend such action
(through the forfeiture of substantive rights or defenses). The Indemnifying Party shall have the
right to participate in, and, to the extent the Indemnifying Party so desires, jointly with any
other Indemnifying Party who has received a similar notice, to assume the defense thereof with
counsel reasonably satisfactory to the Indemnified Party to represent the Indemnified Party in such
proceeding and shall pay the fees and expenses of such counsel relating to such proceeding, and
after notice from the Indemnifying Party to the Indemnified Party of its election so to assume the
defense thereof, the Indemnifying Party shall not, except as specified below, be liable to such
Indemnified Party under paragraph (a) or (b) above, as the case may be, for any legal expenses of
other counsel. In any such proceeding, an Indemnified Party shall have the right to retain its own
counsel, with the fees and expenses to be paid by the Indemnified Party; provided the Indemnifying
Party will pay the reasonable fees and expenses of such counsel if (i) the Indemnifying Party and
the Indemnified Party shall have so mutually agreed; (ii) the Indemnifying Party has failed within a
reasonable time to retain counsel reasonably satisfactory to the Indemnified Party; (iii) the
Indemnified Party shall have reasonably concluded, based on the advice of counsel, that there may be
legal defenses available to it that are different from or in addition to those available to the
Indemnifying Party; or (iv) the named parties in any such proceeding (including any impleaded
parties) include both the Indemnifying Party and the Indemnified Party and representation of both
parties by the same counsel would be inappropriate due to actual or potential differing interest
between them. It is understood and agreed that the Indemnifying Party shall not, in connection with
any proceeding or related proceedings in the same jurisdiction, be liable for the fees and expenses
of more than one separate firm (in addition to any local counsel that is required to effectively
defend against any such proceeding) for all Indemnified Parties, and that all such fees and expenses
shall be paid or reimbursed promptly. The Indemnifying Party shall not be liable for any settlement
of any proceeding effected without its written consent (which shall not be unreasonably withheld,
delayed or conditioned), but if settled with such consent or if there be a final judgment for the
plaintiff, the Indemnifying Party agrees to indemnify each Indemnified Party from and against any
loss or liability by reason of such settlement or judgment. No Indemnifying Party shall, without the
written consent of the Indemnified Party (which shall not be unreasonably withheld, delayed or
conditioned), effect any settlement of any pending or threatened proceeding in respect of which any
Indemnified Party is or could have been a party and indemnification could have been sought hereunder
by such Indemnified Party, unless such settlement (x) includes an unconditional release of such
Indemnified Party, in form and substance reasonably satisfactory to such Indemnified Party, from all
liability on claims that are the subject matter of such proceeding and (y) does not include any
statement as to or any admission of fault, culpability or a failure to act by or on behalf of any
Indemnified Party. 25
<!-- page 26 -->
(d) If the indemnification provided for in this Section 6.8 is held by a court of competent
jurisdiction to be unavailable to an Indemnified Party with respect to any losses, claims, damages
or liabilities referred to herein, the Indemnifying Party, in lieu of indemnifying such Indemnified
Party thereunder, shall to the extent permitted by applicable Law contribute to the amount paid or
payable by such Indemnified Party as a result of such loss, claim, damage or liability in such
proportion as is appropriate to reflect the relative fault of the Indemnifying Party on the one hand
and of the Indemnified Party on the other in connection with the actions that resulted in such loss,
claim, damage or liability, as well as any other relevant equitable considerations. The relative
fault of the Indemnifying Party and of the Indemnified Party shall be determined by a court of law
by reference to, among other things, whether the untrue or alleged untrue statement of a material
fact or the omission to state a material fact relates to information supplied by the Indemnifying
Party or by the Indemnified Party and the parties' relative intent, knowledge, access to information
and opportunity to correct or prevent such statement or omission; provided, that in no event shall
any contribution by a Holder hereunder exceed the net proceeds from the offering made under such
Eligible Registration Statement received by such Holder. (e) The parties hereto agree that it would
not be just and equitable if contribution pursuant to Section 6.8(d) were determined by pro rata
allocation or by any other method of allocation that does not take account of the equitable
considerations referred to in the immediately preceding paragraph. No person guilty of fraudulent
misrepresentation (within the meaning of Section 11(f) of the Securities Act) shall be entitled to
contribution from any person who was not guilty of such fraudulent misrepresentation. (f) The
obligations of the Company and the Farids Group under this Section 6.8 shall survive completion of
any offering of Registrable Securities in an Eligible Registration Statement and the termination of
this Agreement. (g) The obligations of the parties under this Section 6.8 will be in addition to any
liability, without duplication, which any party may otherwise have to any other party. Section 6.9
"Market Stand-Off" Agreement. The Farids Group hereby agrees that the Farids Group shall not
Transfer, make any short sale of, grant any option for the purchase of, or enter into any hedging or
similar transaction with the same economic effect as a sale or other Transfer, any Lock-Up Security
held by the Farids Group (other than those included in the registration) for a period specified by
the representative(s) of the underwriters of Registrable Securities or any other securities sold in
any offering in respect of which the Farids Group received notice from the Company in accordance
with Section 6.2, such period not to exceed one hundred and eighty (180) days following the pricing
date of any underwritten offering; provided that the Farids Group shall only be required to comply
with this Section 6.9 if the Farids Group beneficially own (within the meaning of Rule 13d-3 under
the Exchange Act, or any successor provision) at least 3.0% or more of the number of shares of
Common Stock outstanding at such time. The Company may impose stop transfer instructions with
respect to any Lock-Up Security subject to the foregoing restriction until the end of said one
hundred and eighty (180) day or shorter period. 26
<!-- page 27 -->
Section 6.10 Agreement to Furnish Information. The Farids Group agrees to execute and deliver such
other agreements as may be reasonably requested by the Company or the representative(s) of the
underwriter(s) that are consistent with the Farids Group's obligations under Section 6.9 or that are
necessary to give further effect thereto. In addition, if requested by the Company or such
representative(s), the Farids Group shall provide, to the extent the Farids Group has elected to
include Registrable Securities in an Eligible Registration Statement, within one (1) business day of
such request, such information relating to itself, the Registrable Securities held by it and the
registration and the intended method of distribution of the Registrable Securities as may be
reasonably requested by the Company or such representative(s) in connection with the completion of
any public offering of Common Stock pursuant to such Eligible Registration Statement. The
underwriters of Registrable Securities are intended third party beneficiaries of Sections 6.8 and
6.10 and shall have the right, power and authority to enforce the provisions hereof as though they
were a party hereto. Section 6.11 Termination. The rights and obligations of the Farids Group set
forth in this Article VI (other than those set forth in Sections 6.8 and 6.9) shall terminate on the
date that the Farids Group owns less than 3% of the issued and outstanding Common Stock, but in no
event earlier than the Expiration Date (as defined in the Warrant). ARTICLE VII RIGHT OF FIRST
REFUSAL; CHANGE IN CONTROL Section 7.1 Right of First Offer for 144 Sales. (a) Subject to the
restrictions set forth in Section 5.1 of this Agreement and Section 2.3 of the Warrant, in the event
any member of the Farids Group proposes to Transfer (other than a Permitted Transfer) a Threshold
Block, in a transaction or series of related transactions, of Shares in a 144 Sale, the Farids Group
shall furnish to the Company a written notice of such proposed Transfer (a "ROFO Sale Notice") at
least 48 hours prior to the opening of trading on the Nasdaq Global Market (or such other primary
stock exchange upon which the Common Stock is listed) on the business day that the Farids Group
proposes to begin to effect such 144 Sale. (b) The ROFO Sale Notice shall include: (i) (A) the
number of Shares proposed to be sold (the "ROFO Shares"), (B) the per share purchase price in cash
at which the Farids Group is prepared to Transfer such ROFO Shares (the "ROFO Sale Price") and (C)
the date the Farids Group proposes to begin to effect such 144 Sale; and (ii) (ii) an offer to sell
to the Company and/or a designee of the Company all or a portion of the ROFO Shares at the ROFO Sale
Price. (c) If the Company wishes to purchase (and/or cause a designee to purchase) all or a portion
of the ROFO Shares at the ROFO Sale Price, the Company shall deliver a notice (a "ROFO Purchase
Notice") to the Farids Group no later 8:00 a.m. New York time on the business day that the Farids
Group proposes to effect such 144 Sale specifying the number of ROFO Shares it wishes to purchase
(and/or cause a designee to purchase) from the Farids Group. The closing of the purchase of such
ROFO Shares by the Company and/or any such designee shall take place no later than five (5) business
days after delivery of the ROFO Purchase Notice, with payment for such ROFO Shares being made
concurrently with such purchase to the Farids Group's account designated in the ROFO Sale Notice. If
the Company does not timely deliver a ROFO Purchase Notice it shall be deemed to have waived all of
its rights with respect to the offer contained in the ROFO Sale Notice. 27
<!-- page 28 -->
(d) In the event that the number of ROFO Shares offered to be purchased in the ROFO Purchase Notice
is less than the number of ROFO Shares set forth in the Sale Notice (or the Company does not timely
deliver a ROFO Purchase Notice), the Farids Group may sell the ROFO Shares that are not subject to
any such ROFO Purchase Notice during the five (5) day business day period beginning on the date in
the ROFO Sale Notice on which the Farids Group proposed to begin to effect such 144 Sale (the "ROFO
Transfer Period"); provided that no such ROFO Share may be sold for less than the ROFO Sale Price.
(e) (e) If by the expiration of the ROFO Transfer Period, the Farids Group has not completed the
Transfer of any ROFO Shares at the ROFO Sales Price or a higher price, in order for the Farids Group
to Transfer such ROFO Shares (or any other Shares) it shall be necessary for a new ROFO Sale Notice
or ROFR Sale Notice to be delivered, and the terms and provisions of this Article VII to be again
complied with. The Farids Group shall not deliver more than one ROFO Sale Notice or ROFR Sale Notice
in any thirty (30) day period. Section 7.2 Right of First Refusal. (a) Subject to the restrictions
set forth in Section 5.1 of this Agreement and Section 2.3 of the Warrant, in the event any member
of the Farids Group proposes to Transfer (other than a Permitted Transfer) (i) a Threshold Block, in
a transaction or series of related transactions, that, to the Farids Group's knowledge (after due
inquiry in connection with a private, non-open market transaction) is to a Person whom the Company
reasonably determines is a direct or indirect material competitor of the Company or any Affiliate of
such Person or (ii) a Significant Block, in a transaction or series of related transactions, that,
to the Farids Group's knowledge (after due inquiry in connection with a private, non-open market
transaction) is to a Person whom the Company reasonably determines is a direct or indirect material
competitor of the Company or any Affiliate of such Person (in each case, regardless of whether such
Transfer will constitute a 144 Sale), the Farids Group shall furnish to the Company a written notice
of such proposed Transfer (a "ROFR Sale Notice") at least (5) business days prior to the business
day that the Farids Group proposes to effect such Transfer. (b) The ROFR Sale Notice shall include:
(i) (A) the identity of the proposed transferee, (B) the purchase agreement and other documentation
for the proposed Transfer (the "ROFR Sale Documentation"), (C) the number of Shares proposed to be
sold (the "ROFR Shares"), (D) the per share purchase price in cash at which the Farids Group is
prepared to Transfer such ROFR Shares (the "ROFR Sale Price") and (E) the date the Farids Group
proposes to effect such Transfer; and 28
<!-- page 29 -->
(ii) an offer to sell to the Company and/or a designee of the Company all of the ROFR Shares at the
ROFR Sale Price. (c) If the Company wishes to purchase (and/or cause a designee to purchase) all of
the ROFR Shares at the ROFR Sale Price, the Company shall deliver a notice (a "ROFR Purchase
Notice") to the Farids Group within three (3) business day after receipt of the ROFR Sale Notice.
The closing of the purchase of such ROFR Shares by the Company and/or any such designee shall take
place no later than the later of (i) the purchase date set forth in the ROFR Sale Documentation and
(ii) five (5) business days after delivery of the ROFR Purchase Notice, with payment for such ROFR
Shares being made concurrently with such purchase to the Farids Group's account designated in the
ROFR Sale Notice. If the Company does not timely deliver a ROFR Purchase Notice it shall be deemed
to have waived all of its rights with respect to the offer contained in the ROFR Sale Notice. (d) In
the event that Company does not timely delivery a ROFR Purchase Notice, the Farids Group may sell
the ROFR Shares to the proposed transferee identified in the ROFR Sale Notice at the ROFR Sale Price
and on the other terms and conditions set forth in the ROFR Sale Documentation no later than three
(3) business days following the date the Farids Group proposed to effect such Transfer in the ROFR
Sale Notice (the "ROFR Transfer Period"). (e) If by the expiration of the ROFR Transfer Period, the
Farids Group has not completed the Transfer of the ROFR Shares, in order for the Farids Group to
Transfer such ROFR Shares (or any other Shares) it shall be necessary for a new ROFO Sale Notice or
ROFR Sale Notice to be delivered, and the terms and provisions of this Article VII to be again
complied with. The Farids Group shall not deliver more than one ROFR Sale Notice or ROFO Sale Notice
in any thirty (30) day period. ARTICLE VIII MISCELLANEOUS Section 8.1 Notices. All notices and other
communications hereunder shall be in writing and shall be deemed given if delivered personally,
telecopied (upon telephonic confirmation of receipt), on the first business day following the date
of dispatch if delivered by a recognized next day courier service, or on the third business day
following the date of mailing if delivered by registered or certified mail, return receipt
requested, postage prepaid. All notices hereunder shall be delivered as set forth below, or pursuant
to such other instructions as may be designated in writing by the party to receive such notice: (a)
if to the Company to: Rocky Mountain Chocolate Factory, Inc. 265 Turner Drive Durango, Colorado
81303 Attention: Chief Executive Officer and Chief Financial Officer 29
<!-- page 30 -->
with a copy (which shall not constitute notice) to: Perkins Coie LLP 1900 Sixteenth Street, Suite
1400 Denver, Colorado 80202 Attention: Sonny Allison and Ned Prusse (b) If to the Farids Group to:
Farids & Co. LLC 980 Hammond Dr., Suite 1000 Atlanta, GA 30328 USA Attention: Tariq Farid (c) If to
EA to: Edible Arrangement, LLC 980 Hammond Dr., Suite 1000 Atlanta, GA 30328 USA Attention: Tariq
Farid with a copy (which shall not constitute notice) to: DLA Piper LLP (US) 444 West Lake Street
Suite 900 Chicago, IL 60606 Attention: Neal Aizenstein Section 8.2 Further Assurances. Each party
hereto shall do and perform or cause to be done and performed all further acts and shall execute and
deliver all other agreements, certificates, instruments and documents as any other party hereto
reasonably may request in order to carry out the intent and accomplish the purposes of this
Agreement and the consummation of the transactions contemplated hereby. Section 8.3 Amendments and
Waivers. Any provision of this Agreement may be amended or waived if, but only if, such amendment or
waiver is in writing and is duly executed and delivered by the Company and the Farids Group. No
failure or delay by any party in exercising any right, power or privilege hereunder shall operate as
a waiver thereof nor shall any single or partial exercise thereof preclude any other or further
exercise thereof or the exercise of any other right, power or privilege. The rights and remedies
herein provided shall be cumulative and not exclusive of any rights or remedies provided by law. The
execution of a joinder agreement to this Agreement by a Family Member of TF shall not constitute an
amendment to this Agreement requiring the consent of any party hereto. 30
<!-- page 31 -->
Section 8.4 Fees and Expenses. Each party hereto shall pay all of its own fees and expenses
(including attorneys' fees) incurred in connection with this Agreement and the transactions
contemplated hereby. Section 8.5 Successors and Assigns. The provisions of this Agreement shall be
binding upon and inure to the benefit of the parties hereto and their respective successors and
assigns, provided, that, unless in connection with Permitted Transfers, neither party may assign,
delegate or otherwise transfer any of its rights or obligations under this Agreement to any person
without the express written consent of the other party hereto and any such assignment or other
transfer shall be null and void; provided, further, that no such assignment shall relieve the
assigning party of its obligations hereunder if such assignee does not perform such obligations.
Prior to the receipt by the Company of adequate written notice of the Permitted Transfer of any
Purchased Shares in accordance with the provisions of this Agreement and specifying the full name
and address of the transferee, the Company may deem and treat the person listed as the holder of
such shares in its records as the absolute owner and holder of such shares for all purposes,
including the payment of dividends. Section 8.6 Governing Law. (a) This Agreement shall be governed
and construed in accordance with the laws of the State of New York applicable to contracts made and
wholly performed within such state, except for matters directly within the purview of the DGCL,
which shall be governed by the DGCL. Each of the Farids Group and the Company hereby irrevocably and
unconditionally consents to submit to the exclusive jurisdiction and venue of the United States
District Court for the Southern District of New York and in the courts hearing appeals therefrom
unless no basis for federal jurisdiction exists, in which event each party hereto irrevocably
consents to the exclusive jurisdiction and venue of the Supreme Court of the State of New York, New
York County, and the courts hearing appeals therefrom, for any action, suit or proceeding arising
out of or relating to this Agreement and the transactions contemplated hereby. Each of the Farids
Group and the Company hereby irrevocably and unconditionally waives, and agrees not to assert, by
way of motion, as a defense, counterclaim or otherwise, in any such action, suit or proceeding, any
claim that it is not personally subject to the jurisdiction of the aforesaid courts for any reason,
other than the failure to serve process in accordance with this Section 8.6, that it or its property
is exempt or immune from jurisdiction of any such court or from any legal process commenced in such
courts (whether through service of notice, attachment prior to judgment, attachment in aid of
execution of judgment, execution of judgment or otherwise), and to the fullest extent permitted by
applicable Law, that the action, suit or proceeding in any such court is brought in an inconvenient
forum, that the venue of such action, suit or proceeding is improper, or that this Agreement, or the
subject matter hereof, may not be enforced in or by such courts and further irrevocably waives, to
the fullest extent permitted by applicable Law, the benefit of any defense that would hinder, fetter
or delay the levy, execution or collection of any amount to which the party is entitled pursuant to
the final judgment of any court having jurisdiction. Each of the Farids Group and the Company
irrevocably and unconditionally waives, to the fullest extent permitted by applicable Law, any and
all rights to trial by jury in connection with any action, suit or proceeding arising out of or
relating to this Agreement or the transactions contemplated hereby. 31
<!-- page 32 -->
(b) Each of the Farids Group and the Company expressly acknowledges that the foregoing waivers are
intended to be irrevocable under the laws of the State of New York, the State of Delaware and of the
United States of America; provided, that consent by the Farids Group and the Company to jurisdiction
and service contained in this Section 8.6 is solely for the purpose referred to in this Section 8.6
and shall not be deemed to be a general submission to said courts or in the State of New York other
than for such purpose. Section 8.7 Ownership Limitation. The Farids Group shall not (unless
specifically requested in writing by the Company, acting through a resolution of a majority of the
Company's directors), directly or indirectly, and agrees to cause the Affiliates of the Farid Group
to not, directly or indirectly, in any manner acquire, offer or propose to acquire, or agree to
acquire, directly or indirectly, whether by purchase, tender or exchange offer, through the
acquisition of control of another person, by joining a partnership, limited partnership, syndicate
or other group (including any group of persons that would be treated as a single "person" under
Section 13(d) of the Exchange Act), through swap or hedging transactions or otherwise, any
securities of the Company, or any rights decoupled from the underlying securities of the Company
that would result in the Farids Group (together with its Affiliates) owning, controlling or
otherwise having any beneficial ownership (within the meaning of Rule 13d-3 under the Exchange Act,
or any successor provision) of 19.99% or more of the fully diluted number of shares of Common Stock
outstanding at such time; provided, however, that nothing herein will require Common Stock to be
sold to the extent that the Farids Group and its Affiliates, collectively, exceed the ownership
limit under this Section 8.7 as the result of any share repurchase or other Company action that
reduces the number of outstanding shares of Common Stock on or after the date hereof; provided,
further, that (a) this Section 8.7 shall not preclude Farids or EA from privately requesting a
waiver of the provisions of Section 8.7, and (b) the provisions of this Section 8.7 shall terminate
and be of no further force and effect if the Company enters into a definitive agreement with respect
to, or publicly announces that it plans to enter into, a transaction involving all or a controlling
portion of the Company's equity securities or all or substantially all of the Company's assets
(whether by merger, consolidation, business combination, tender or exchange offer, recapitalization,
restructuring, sale, equity issuance or otherwise). Section 8.8 Non-Disparagement. (a) Neither the
Company nor any of its Affiliates shall in any manner, directly or indirectly, in any capacity or
manner, make or cause to be made, or in any way encourage any other person to make or cause to be
made, any public statement or public announcement, including in any document or report filed with or
furnished to the SEC or through the press, media, analysts or other persons, that constitutes an ad
hominem attack on or otherwise disparages, defames or slanders the Farids Group or any of its
Affiliates or any of their respective successors or current or former members, partners, officers,
directors or employees (it being understood and agreed that the restrictions in this Section 8.8(a)
shall not apply to any member of the Board of Directors based upon discussions solely among other
members of the Board of Directors and/or management of the Company); provided, that the limitations
set forth in this Section 8.8(a) shall not prevent the Company or any of its Affiliates from (i)
responding to any public statement or announcement made by the Farids Group or any of its Affiliates
that was made in breach of Section 8.8(b) below or (ii) if solicited by a Third Party, making
objective statements that reflect the Company's view with respect to factual matters concerning
specific acts or determinations of the Farids Group or any of its Affiliates (or their respective
current or former representatives) occurring after the date hereof. For the avoidance of doubt, a
public statement or announcement shall only be deemed to be made by the Company if such public
statement or announcement is made by (X) an executive officer or a member of the Board of Directors
(other than a Director Designee) or (Y) an employee or representative of the Company authorized to
make such statement or announcement on behalf of the Company. 32
<!-- page 33 -->
(b) Neither the Farids Group nor any of its Affiliates shall in any manner, directly or indirectly,
in any capacity or manner, make or cause to be made, or in any way encourage any other person to
make or cause to be made, any public statement or public announcement, including in any document or
report filed with or furnished to the SEC or through the press, media, analysts or other persons,
that constitutes an ad hominem attack on or otherwise disparages, defames or slanders the Company or
any of its Affiliates or any of their respective successors or current or former members, partners,
officers, directors or employees; provided, that, the limitations set forth in this Section 8.8(b)
shall not prevent the Farids Group or any of its Affiliates from (i) responding to any statement
made by the Company or any of its Affiliates or representatives that was made in breach of Section
8.8(a) above or (ii) if solicited by a Third Party, making objective statements that reflect the
Farids Group's or any of its Affiliates' view with respect to factual matters concerning specific
acts or determinations of the Company, any of its Affiliates or any current or former
representatives of the Company or any of its Affiliates occurring after the date hereof. For the
avoidance of doubt, a public statement or announcement shall only be deemed to be made by the Farids
Group or any of its Affiliates if such public statement or announcement is made by (X) a Farids
manager, director or executive officer or an EA manager, director or executive officer (Y) an
employee or representative of Farids or EA authorized to make such statement or announcement on
behalf of Farids or EA, as applicable. Section 8.9 Non-Solicitation. (a) Each of EA, Farids and the
Company shall not, and shall cause their respective controlled Affiliates to not, either directly or
indirectly solicit, hire, or contract with any of the employees of the other party or its Affiliates
during the Term (as defined in the Exclusive Supplier Operating Agreement) and for one (1) year
following the termination or expiration thereof; provided that this Section 8.9(a) shall not apply
with respect to any such employee who employment with the other party and its Affiliates has been
terminated for a period in excess of nine (9) months. (b) Notwithstanding anything to the contrary
in this Agreement, the restrictions regarding solicitation in this Section 8.9 shall not be deemed
to apply to media advertisements of general circulation, open job fairs, the efforts of an
employment search firm or other generalized means of publicizing a job opening, such as on a website
or job board which, in each case, are not targeted primarily at the employees of the other party or
its Affiliates; provided that this Section 8.9(b) shall not limit the restrictions or hiring set
forth in Section 8.9(a). Section 8.10 Entire Agreement. This Agreement and the other Transaction
Documents constitute the entire agreement between the parties with respect to the subject matter of
this Agreement and supersedes all prior agreements and understandings, both oral and written,
between the parties and/or their Affiliates with respect to the subject matter of this Agreement. 33
<!-- page 34 -->
Section 8.11 Effect of Headings. The Article and Section headings herein are for convenience only
and shall not affect the construction hereof. Section 8.12 Severability. If one or more provisions
of this Agreement are held to be unenforceable under applicable Law, such provision shall be deemed
to be excluded from this Agreement and the balance of this Agreement shall be interpreted as if such
provision were so excluded and shall be enforced in accordance with its terms to the maximum extent
permitted by law. Section 8.13 Counterparts; Third Party Beneficiaries. This Agreement may be signed
in any number of counterparts, each of which shall be an original, with the same effect as if the
signatures were upon the same instrument. Facsimile and electronic (.PDF) signatures shall be
sufficient to execute this Agreement. Except for Section 6.8 with respect to the underwriters of
Registrable Securities, no provision of this Agreement shall confer upon any person other than the
parties hereto any rights or remedies hereunder. Section 8.14 Survival. The representations,
warranties, agreements and covenants contained herein shall survive the Closing. Section 8.15
Remedies. The parties agree that irreparable damage would occur in the event that any of the
provisions of this Agreement were not performed in accordance with their specific terms. It is
accordingly agreed that the parties shall be entitled to seek specific performance of the terms
hereof, this being in addition to any other remedies to which they are entitled at law or equity. In
the event of any dispute between the parties concerning the terms and provisions of this Agreement,
the party prevailing in such dispute shall be entitled to collect from the other party all costs
incurred in such dispute, including reasonable attorneys' fees. [Remainder of this page
intentionally left blank] 34
<!-- page 35 -->
IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be signed as of the date first
written above. ROCKY MOUNTAIN CHOCOLATE FACTORY, INC. By: /s/ Bryan J. Merryman Name: Bryan J.
Merryman Title: Chief Executive Officer and Chief Financial Officer FARIDS & CO. LLC By: /s/ Tariq
Farid Name: Tariq Farid Title: Chief Executive Officer EDIBLE ARRANGEMENTS, LLC By: /s/ Tariq Farid
Name: Tariq Farid Title: Chief Executive Officer [Signature Page to Strategic Alliance Agreement]
<!-- page 36 -->
EXHIBIT A FORM OF JOINDER AGREEMENT This JOINDER AGREEMENT (this "Joinder Agreement") is executed
pursuant to the terms of the Strategic Alliance Agreement, dated as of December 20, 2019, by and
among Farids & Co. LLC, a Delaware limited liability company ("Farids"), Edible Arrangements, LLC, a
Delaware limited liability company, and Rocky Mountain Chocolate Factory, Inc., a Delaware
corporation (the "Company"), a copy of which is attached hereto and is incorporated herein by
reference (the "Agreement"), by the undersigned (the "Farids Transferee"). Capitalized terms used
but not defined herein have the meanings set forth in the Agreement. By execution and delivery of
this Joinder Agreement, the Farids Transferee agrees as follows: SECTION 1. Acknowledgment. The
Farids Transferee acknowledges that it has acquired Purchased Shares from a member of the Farids
Group pursuant to a Permitted Transfer. SECTION 2. Agreement. The Farids Transferee (a) agrees that
the Purchased Shares it owns shall be bound by and subject to the terms of the Agreement to the same
extent as if such Farids Transferee were a member of the Farids Group, (b) hereby adopts the
Agreement with the same force and effect as if it were originally a member of the Farids Group and
(c) shall constitute a member of the "Farids Group" under the Agreement. SECTION 3. Notice. Any
notice required to be provided by the Agreement shall be given to the Farids Transferee at the
address of Farids Group listed in the Agreement. SECTION 4. Governing Law. This Joinder Agreement
and the rights of the parties hereto shall be governed by and construed in accordance with the laws
of the State of New York applicable to contracts made and to be performed therein. Executed and
dated this day of . Farids Transferee: [INSERT NAME] By: [Title] Acknowledged and Agreed to by ROCKY
MOUNTAIN CHOCOLATE FACTORY, INC. By: [Title] A-1
<!-- page 37 -->
EXHIBIT B EXCLUSIVE SUPPLIER OPERATING AGREEMENT [Attached] B-1
<!-- page 38 -->
EXHIBIT C WARRANT [Attached] C-1
<!-- page 39 -->
EXHIBIT D INDEMNIFICATION AGREEMENT [Attached] D-1
<!-- page 40 -->
EXHIBIT E AMENDMENT E-1
