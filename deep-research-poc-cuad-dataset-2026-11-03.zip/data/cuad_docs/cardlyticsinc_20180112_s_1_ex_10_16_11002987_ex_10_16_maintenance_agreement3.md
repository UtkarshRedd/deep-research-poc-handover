<!-- page 1 -->
# SCHEDULE TO Software License, Customization and Maintenance Agreement
| Field | Value |
|---|---|
| Document Type | Maintenance Agreement |
| Agreement Date | 2011-03-04 |
| Parties | Cardlytics, Inc. ("Supplier"); Bank of America, N.A ("Bank of America) |
| Source | CUAD v1 / CardlyticsInc_20180112_S-1_EX-10.16_11002987_EX-10.16_Maintenance Agreement3 |

SCHEDULE TO Software License, Customization and Maintenance Agreement Supplier Name: Cardlytics,
Inc. Agreement Number: CW251207

Supplier Address:

621 North Avenue NE Suite C-30 Atlanta, GA 30308

Addendum Number:

CW255039

Supplier Telephone: 888.798.5802 Addendum Effective Date March 3, 2011

This Schedule ("Schedule") is made as of the effective date set forth above to that Software
License, Customization, and Maintenance Agreement, by and between Cardlytics, Inc. ("Supplier") and
Bank of America, N. A, ("Bank of America"), dated November 5, 2010, as amended ("SLCMA"). Each
capitalized term used but not defined herein shall have the meaning assigned in the SLCMA.

WHEREAS, Bank of America and Supplier entered into the SLCMA in order to set forth the terms and
conditions pursuant to which Supplier provides certain Software to Bank of America,

WHEREAS, the parties desire to add to the SLCMA the Supplier Offer Placement System Software;

NOW THEREFORE, in consideration of the promises and accords made herein, and the exchange of such
good and valuable consideration, the receipt and sufficiency of which is hereby acknowledged, Bank
of America and Supplier agree as follows:

The attached Schedule [A] is hereby incorporated into the SLCMA describing the Offer Placement
System Software for use by Bank of America.

THE FOREGOING IS UNDERSTOOD AND AGREED TO BY: Cardlytics, Inc. ("Supplier") Bank of America, N.A.
("Bank of America")

By: /s/ Scott Grimes By: /s/ Chandra Torrence

Name: Scott Grimes Name: Chandra Torrence

Title: Chief Executive Officer Title: V.P., Sourcing Manager

Date: 3/4/11 Date: 3/3/11 1.

Source: CARDLYTICS, INC., S-1, 1/12/2018
