# Which jurisdiction's law governs the Supply Agreement between Vericel Corporation and M...

*Question:* Which jurisdiction's law governs the Supply Agreement between Vericel Corporation and MediWound Ltd. (dated 2019-05-06)?

## Identify governing law clause

Section 11.9 Governing Law states that the Agreement shall be governed by and interpreted in accordance with the substantive laws of the State of New York, without regard to conflict of law principles thereof. [becb201c2f37c92a p.33] The governing law provision is located in Section 11.9 of the Supply Agreement. [becb201c2f37c92a p.33]

## Verify clause applicability

The document is the Supply Agreement between Vericel Corporation and MediWound Ltd., dated 2019-05-06. [becb201c2f37c92a p.1] The parties are Vericel Corporation ("Vericel") and MediWound Ltd. [uncited] ("MediWound"), collectively referred to as the "Parties". [becb201c2f37c92a p.1]

[GAP] The governing law clause text establishing its applicability to the entire agreement is not present in the provided evidence.

## Verification appendix

Claims: 6 · supported: 4 · partially: 0 · dropped: 0 · gaps: 2 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e2→[becb201c2f37c92a p.33] |  |
| s1.2 | s1 | keep | 1.00 | e2→[becb201c2f37c92a p.33] |  |
| s2.1 | s2 | keep | 1.00 | e1→[becb201c2f37c92a p.1] |  |
| s2.2 | s2 | gap |  |  | no evidence cited |
| s2.3 | s2 | keep | 1.00 | e1→[becb201c2f37c92a p.1] |  |
| s2.4 | s2 | gap |  |  |  |

### Evidence

- e1 [becb201c2f37c92a p.1 L6-7] keep (1.0): "| Agreement Date | 2019-05-06 | | Parties | Vericel Corporation ("Vericel"); MediWound Ltd. ("MediWound"); Vericel and MediWound (individually as a “Party” and collectively as the “Parties.”) |"
- e2 [becb201c2f37c92a p.33 L1375-1377] keep (1.0): "11.9 Governing Law. This Agreement, and all claims arising under or in connection therewith, shall be governed by and interpreted in accordance with the substantive laws of the State of New York, without regard to conflict of law principles…"
