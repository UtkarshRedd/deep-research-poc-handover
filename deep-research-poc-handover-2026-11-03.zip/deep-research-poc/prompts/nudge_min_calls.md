REJECTED: submit is not allowed yet. You have made {calls_used} tool calls; the minimum is
{min_calls}. Search more before submitting: try different clues or synonyms with grep, read the
highest-count documents around the matches, and check `list_docs` dates for amendments or later
versions that could change the answer.
