"""End-to-end graph with scripted models: materialize -> research -> write -> verify, and the
deadline path that skips research. No network."""
import json
import time
import uuid
from dataclasses import replace
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage

from dr.config import DEFAULT, StageBudgetsS
from dr.graph import Pipeline, new_run_state, run
from dr.ingest.load import load_dir
from dr.llm import get_scripted_llm

SAMPLE = Path(__file__).resolve().parents[1] / "data" / "sample_docs"
QUOTE = "Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00."


def tc(name, args):
    return {"name": name, "args": args, "id": f"call_{uuid.uuid4().hex[:8]}", "type": "tool_call"}


def ai(*calls):
    return AIMessage(content="", tool_calls=list(calls))


@pytest.fixture()
def docs():
    return load_dir(SAMPLE)


def small_cfg(**stages):
    cfg = replace(DEFAULT, agents=replace(DEFAULT.agents, RESEARCH_MIN_CALLS=1, RESEARCH_MAX_CALLS=6))
    return replace(cfg, stages=StageBudgetsS(**stages)) if stages else cfg


def researcher_script(doc_id):
    return [
        ai(tc("grep", {"pattern": "Leverage Ratio"})),
        ai(tc("add_evidence", {"doc_id": doc_id, "start_line": 17, "end_line": 17, "quote": QUOTE, "note": "covenant"}),
           tc("submit", {"sub_question": "q", "answer": "3.50 to 1.00 [e1]", "evidence_ids": ["e1"], "confidence": "high"})),
    ]


def writer_script():
    outline = AIMessage(content=json.dumps({"sections": [{"section_id": "s1", "title": "Covenant", "intent": "State the ratio"}]}))
    revise = AIMessage(content=json.dumps({"sections": [{"section_id": "s1", "title": "Covenant", "intent": "State the ratio", "evidence_ids": ["e1"]}]}))
    draft = AIMessage(content="The original agreement caps the Leverage Ratio at 3.50 to 1.00 {{CITE:e1}}.")
    return [outline, revise, draft]


def test_pipeline_end_to_end(docs, tmp_path):
    a = next(d.doc_id for d in docs if d.title == "Credit Agreement — Acme Industrial LLC")
    p = Pipeline(small_cfg(), llms={"researcher": get_scripted_llm(researcher_script(a)), "writer": get_scripted_llm(writer_script())})
    state = p.run("What is the maximum Leverage Ratio?", docs, root=tmp_path / "run")
    assert state["research_done"] == "submitted" and not state["partial"] and state["errors"] == []
    assert state["findings"][0]["evidence_ids"] == ["e1"]
    md = state["report_md"]
    assert "## Covenant" in md and f"[{a} p.2]" in md and "## Verification appendix" in md and "dropped: 0" in md
    assert [v["tier1"] for v in state["verify"]] == ["keep"]
    assert set(state["stage_ms"]) == {"materialize", "research", "write", "verify"}
    root = tmp_path / "run"
    for name in ("manifest.json", "evidence.jsonl", "trace.jsonl", "report.md", "verify.json"):
        assert (root / name).exists(), name
    stages = [json.loads(ln) for ln in (root / "trace.jsonl").read_text().splitlines() if '"kind": "stage"' in ln]
    assert [s["stage"] for s in stages] == ["materialize", "research", "research", "write", "write", "verify"]


def test_pipeline_skips_research_when_deadline_leaves_no_room(docs, tmp_path):
    # Only the writer is scripted: if research ran, the researcher model would raise ScriptExhausted.
    outline = AIMessage(content=json.dumps({"sections": [{"section_id": "s1", "title": "Answer", "intent": "Answer it"}]}))
    p = Pipeline(small_cfg(), llms={"researcher": get_scripted_llm([]), "writer": get_scripted_llm([outline])})
    state = new_run_state("q", "A2_fs_agent", tmp_path / "run2", p.config)
    state["deadline_ts"] = time.time() + 1.0          # less than WRITE + VERIFY + RESERVE
    p._docs[state["run_id"]] = docs
    final = p.graph.invoke(state)
    assert final["research_done"] is None and final["partial"]
    assert any("research skipped" in e for e in final["errors"])
    assert "[GAP] No evidence was found for" in final["report_md"] and "gaps: 1" in final["report_md"]
    assert "research" not in final["stage_ms"] and {"materialize", "write", "verify"} <= set(final["stage_ms"])


def test_unimplemented_variant_is_rejected(docs, tmp_path):
    with pytest.raises(NotImplementedError, match="LC_small"):
        run("q", docs, variant="LC_small", root=tmp_path / "x", llms={"researcher": get_scripted_llm([]), "writer": get_scripted_llm([])})
