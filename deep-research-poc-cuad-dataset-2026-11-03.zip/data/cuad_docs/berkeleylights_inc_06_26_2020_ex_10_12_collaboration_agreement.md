<!-- page 1 -->
# COLLABORATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2019-09-13 |
| Parties | Ginkgo Bioworks, Inc. ("Ginko"); Berkely Lights, Inc. ("BLI"); Gingko and BLI ("Party", collectively as the "Parties") |
| Source | CUAD v1 / BERKELEYLIGHTS,INC_06_26_2020-EX-10.12-COLLABORATION AGREEMENT |

Exhibit 10.12

[***] Certain information in this document has been excluded pursuant to Regulation S-K, Item
601(b)(10). Such excluded information is not material and would likely cause competitive harm to the
registrant if publicly disclosed.

Execution Version

COLLABORATION AGREEMENT

This COLLABORATION AGREEMENT (this "Agreement"), effective as of September 13th, 2019 ("Effective
Date"), is between Ginkgo Bioworks, Inc., a Delaware corporation with offices located at 27 Drydock
Avenue, 8th floor, Boston, Massachusetts 02210 ("Ginkgo"), and Berkeley Lights, Inc., a Delaware
corporation with offices located at 5858 Horton Street, Suite 320, Emeryville, California 94608
("BLI"). Ginkgo and BLI may each be referred to herein as a "Party" or, collectively, as the
"Parties."

WHEREAS, BLI and Ginkgo are committed to the goal of developing and deploying workflows on the
Beacon Platform to accelerate the engineering of microbial organisms and mammalian cell lines,
including by developing new Workflows (as defined below) for use on the Beacon Platform for the
Parties' mutual benefit (the "Purpose"); and

WHEREAS, in furtherance of the Purpose, BLI and Ginkgo have decided to enter into this Agreement,
including mutually agreed upon Workflow Development Plans, which establish the terms by which Ginkgo
and BLI will work together to bring their unique resources and experiences to bear on the Purpose.

NOW THEREFORE, in consideration of the above premises and the mutual covenants contained herein, the
Parties hereby agree as follows: 1. DEFINITIONS

1.1 "Affected Party" has the meaning set forth Section 14.8 (Force Majeure).

1.2 "Affiliate" means with respect to a Party, any Person that, directly or indirectly, through one
or more intermediaries, controls, is controlled by, or is under common control with that Party, for
so long as such control exists. For purposes of this definition only, "control" and, with
correlative meanings, the terms "controlled by" and "under common control with" means: (a) in the
case of Persons that are corporate entities, direct or indirect ownership of more than fifty percent
(50%) of the stock or shares (or such lesser percentage which is the maximum allowed to be owned by
a foreign corporation in a particular jurisdiction) entitled to vote for the election of directors,
or otherwise having the power to control or direct the affairs of such corporate entity; and (b) in
the case of Persons that are non-corporate entities, direct or indirect ownership of at least fifty
percent (50%) of the equity interest or the power to direct the management and policies of such
non-corporate entity.

1.3 "Agreement" has the meaning set forth in the Preamble.

1.4 "[***]" means [***]. These include [***]. For clarity, [***] does not include [***].

1.5 "Alliance Manager" has the meaning set forth in Section 3.7 (Alliance Managers).
<!-- page 2 -->
1.6 "Antibody" means a soluble protein derived exclusively from an immunoglobulin protein that
includes at least one hyper-variable antigen- binding region, including any fragment [***] of such
protein, but, for clarity, excluding (i) [***] and (ii) [***].

1.7 "Applicable Law" means federal, state, local, national and supra-national laws, statutes, rules
and regulations, including any rules, regulations, regulatory guidelines or other requirements of
Regulatory Authorities, major national securities exchanges or major securities listing
organizations, that may be in effect from time to time during the Term and applicable to a
particular activity or country hereunder.

1.8 "Arbitration Notice" has the meaning set forth in Section 14.5.2 (Dispute Resolution).

1.9 "Beacon Optofluidic Machine Improvement" means any improvement or modification to the Beacon
Optofluidic Machine conceived, developed, generated or reduced to practice during the Term (a)
solely by a Party, its Affiliates or Persons acting on behalf of such Party or (b) jointly by, on
one hand, Ginkgo, its Affiliates or Persons acting on behalf of Ginkgo and, on the other hand, BLI,
its Affiliates or Persons acting on behalf of BLI, in each case of clauses (a) and (b) of this
Section 1.9 ("Beacon Optofluidic Machine Improvement" definition) through the conduct of activities
under a Workflow Development Plan or otherwise arising out of the Parties' performance of activities
under this Agreement.

1.10 "Beacon Optofluidic Machine" means (i) the machine with the Specifications set forth, as of the
Effective Date, on Schedule 1.10 (Beacon Optofluidic Machine) and (ii) [***] and, with respect to
(i)-(ii), any [***] of such machines, developed during the Term by BLI or its Affiliates that [***].

1.11 "Beacon Platform" means, collectively, (a) the Beacon Optofluidic Machine, (b) the OptoSelect
Chips, (c) Consumables related to the Beacon Optofluidic Machine or the OptoSelect Chips and (d) any
Software.

1.12 "BLI" has the meaning set forth in the Preamble.

1.13 "BLI Background IP" means any Intellectual Property (a) Controlled by BLI or its Affiliates as
of the Effective Date, (b) that comes into the Control of BLI after the Effective Date other than by
means of this Agreement or the activities performed hereunder or (c) developed during the Term by
BLI outside and independently of this Agreement.

1.14 "BLI Indemnitee" has the meaning set forth in Section 12.2 (Indemnification by Ginkgo).

1.15 "BLI Inventions" has the meaning set forth in Section 8.2.2 (Ownership of Materials and Data -
BLI Inventions).

1.16 "BLI Proprietary Workflow" means any workflow on the Beacon Platform that was developed by or
on behalf of BLI prior to the Effective Date or is developed during the Term in the conduct of
activities outside and independent of this Agreement (including, for clarity, outside of any
Workflow Development Plan), in each case whether solely by BLI or jointly by BLI and a Third Party.
Page 2 of 85
<!-- page 3 -->
1.17 "BLI Subcontractor" means a Person to whom BLI has subcontracted any of its activities under
this Agreement pursuant to Section 2.7 (Subcontracting).

1.18 "BLI Terms and Conditions" means those terms and conditions set forth in Schedule 1.18 (BLI
Terms and Conditions) and the Product Warranty, as such may be amended from time to time by BLI,
[***].

1.19 "Budget" means, with respect to a Workflow Development Plan, an itemized budget broken down on
a [***] and high-level task-by-high-level task basis [***], that sets forth the following internal
and out-of-pocket costs anticipated to be incurred in the conduct of activities under such Workflow
Development Plan, to the extent applicable and mutually agreed upon by the Parties:

1.19.1 the FAS Support Costs for services provided by any FAS under such Workflow Development Plan;

1.19.2 other FTE Costs for BLI's personnel in the conduct of activities under, or [***] under, such
Workflow Development Plan, including BLI personnel conducting development of Software for the
Workflow under such Workflow Development Plan; provided that, with respect to the FTE Costs for
BLI's personnel providing [***] under a Workflow Development Plan, such FTE Costs shall not exceed
[***] percent ([***]%) of the total FTE Costs charged to Ginkgo with respect to any invoice;

1.19.3 the out-of-pocket development ([***]) costs paid by BLI to Third Parties to purchase finished
Consumables that are developed and designated as a deliverable under a Workflow Development Plan or
raw materials necessary to manufacture Consumables that are developed and designated as a
deliverable under a Workflow Development Plan , in each case from such Third Parties for the Beacon
Platform, subject to a [***] percent ([***]%) mark-up;

1.19.4 with respect to any then-existing Consumables (i.e. not Consumables for which development or
manufacture is ongoing as described in Section 1.19.3), an amount equal to the number of units used
in the performance of the Workflow Development Plan, multiplied by a price per unit of Consumables
as set forth in Section 5.2.2(b) (Adjustments); and

1.19.5 other out-of-pocket costs paid by BLI to permitted Third Party subcontractors and vendors
attributable to the development of the Workflow or Hardware under such Workflow Development Plan,
[***].

1.20 "Business Day" means any day, other than a Saturday, Sunday or a day on which commercial banks
located in Boston, Massachusetts or San Francisco, California are authorized or required by
Applicable Law or regulation or otherwise to close. Page 3 of 85
<!-- page 4 -->
1.21 "Buy-Down Amount" means, at any given time of a Buy-Down Election, an amount equal to:

1.21.1 if, at such time, [***], [***] ([***]%) of the difference between (a) the Full Purchase
Target and (b) the sum of all the Development Purchases and Production Purchases made or incurred by
Ginkgo;

1.21.2 if, at such time, [***], [***] percent ([***]%) of the difference between (a) the Full
Purchase Target and (b) the sum of all the Development Purchases and Production Purchases made or
incurred by Ginkgo as of such time;

1.21.3 if, at such time, [***], [***] percent ([***]%) of the difference between (a) the Full
Purchase Target and (b) the sum of all the Development Purchases and Production Purchases made or
incurred by Ginkgo as of such time; and

1.21.4 if, at such time, [***], [***].

For illustrative purposes only, Schedule 1.21 (Buy-Down Examples) sets forth a table showing the
calculated Buy-Down Amounts assuming [***] and [***].

1.22 "Buy-Down Election" has the meaning set forth in Section 7.3 (Buy-Down Election).

1.23 "Calendar Quarter" means the respective periods of three (3) consecutive calendar months ending
on March 31, June 30, September 30 and December 31; provided that the first Calendar Quarter of the
Term shall begin on the Effective Date and end on the last day of the then current Calendar Quarter
and the last Calendar Quarter of the Term shall begin on the first day of such Calendar Quarter and
end on the last day of the Term.

1.24 "[***]" means [***] that [***], including [***], by [***], whose [***].

1.25 "[***]" means the offering or performance of any services using the Beacon Platform, [***], to
[***]:

1.25.1 [***];

1.25.2 [***]; or

1.25.3 [***];

provided that in no event shall [***] include the use of the Beacon Platform to (i) [***] or (ii)
[***] but, for clarity, are not in any manner or form used as described in Sections 1.25.1, 1.25.2
or 1.25.3 above.

1.26 "Change in Control" means, with respect to a Person, (a) the acquisition, directly or
indirectly, by a Person or "group" (whether in a single transaction or multiple transactions) of
fifty percent (50%) or more of the voting power of such Person or of beneficial ownership of (or the
right to acquire such beneficial ownership) fifty percent (50%) or more of the outstanding Page 4 of
85
<!-- page 5 -->
equity or convertible securities of such Person (including by tender offer or exchange offer); (b)
any merger, consolidation, share exchange, business combination, recapitalization or similar
corporate transaction involving such Person (whether or not including one or more wholly owned
subsidiaries of such Person) or (c) such Person sells or transfers to any Third Party, in one or
more related transactions, properties or assets representing all or substantially all of such
Person's consolidated total assets to which this Agreement relates.

1.27 "Claims" is defined in Section 12.1 (Indemnification by BLI).

1.28 "Clinical Trial" means a human clinical study conducted on sufficient numbers of human subjects
that is designed to (a) establish that a product is reasonably safe for continued testing, (b)
investigate the safety and efficacy of the product for its intended use, and to define warnings,
precautions and adverse reactions that may be associated with the product in the dosage range to be
prescribed or (c) support Regulatory Approval of such product or label expansion of such product.
Without limiting the foregoing, Clinical Trial includes any Phase II Clinical Trial or Phase III
Clinical Trial conducted by or on behalf of one or both Parties in connection with this Agreement.

1.29 "Collaboration Data" has the meaning set forth in Section 8.5.1 (Disclosure).

1.30 "Collaboration Intellectual Property" means [***], that is conceived, developed, generated or
reduced to practice during the Term (a) solely by a Party, its Affiliates or Persons acting on
behalf of such Party or (b) jointly by, on one hand, Ginkgo, its Affiliates or Persons acting on
behalf of Ginkgo and, on the other hand, BLI, its Affiliates or Persons acting on behalf of BLI, in
each case of clauses (a) and (b) of this Section 1.30 ("Collaboration Intellectual Property"
definition) through the conduct of activities under this Agreement.

1.31 "Collaboration Workflow" means any Workflow on the Beacon Platform that [***] and is (a)
developed jointly by the Parties (or on their behalf) or (b) developed solely by BLI (or on behalf
of BLI) for Ginkgo, in each case of clause (a) and (b) of this Section 1.31 ("Collaboration
Workflow" definition), pursuant to a Workflow Development Plan. For the avoidance of doubt,
Collaboration Workflows shall not include [***].

1.32 "Commercial Services" means any [***] activities conducted by Ginkgo or any sublicensee under
the rights granted to Ginkgo by BLI in Section 9.1.1 (Scope of Grants) in the Licensed Field (a)
under an agreement or arrangement of Ginkgo or any such sublicensee with a Third Party or (b) for
[***] that [***] by Ginkgo, an Affiliate or a Third Party; provided that, notwithstanding the
foregoing, with respect to Third Parties, Workflows may only be [***] by Ginkgo permitted (under
Section 9.1 (Grants to Ginkgo)) sublicensees, but no other Third Parties.

1.33 "Completed Workflow" means any Key Collaboration Workflow that the JRC or the Expert Panel, as
applicable, determines has been Substantially Completed.

1.34 "Confidential Information" has the meaning set forth in Section 10.1 (Confidential
Information). Page 5 of 85
<!-- page 6 -->
1.35 "Conforming Product" means, with respect to a Beacon Optofluidic Machine or Consumable
delivered by BLI to Ginkgo under this Agreement, that such Beacon Optofluidic Machine or Consumable
meets the Product Warranty at the time of delivery.

1.36 "Consumables" means those certain OptoSelect Chips and reagents set forth on Schedule 1.36
(Consumables) or that, during the Term, [***] for the use of the Beacon Platform and are sold by
BLI.

1.37 "Contract Year" means (a) with respect to the first Contract Year, the period of time
commencing on the Effective Date and ending on September 30, 2020 and (b) with respect to each
subsequent Contract Year, commencing on October 1 of such Contract Year and continuing for a period
of twelve (12) consecutive calendar months; provided that the last Contract Year of the Term shall
end on the last day of the Term.

1.38 "Control" means, with respect to any item of Intellectual Property or material, the possession
(whether by ownership or license, other than by a license granted pursuant to this Agreement) by a
Party or its Affiliates of the ability to grant to the other Party access, ownership, a license or a
sublicense as required herein to such item, without: (a) violating the terms of any agreement or
other arrangement with any Third Party in existence as of the time such Party or its Affiliates
would be required hereunder to grant the other Party such access, ownership, license or sublicense;
(b) violating any Applicable Law, or (c) incurring payment obligations by reason of providing
access, ownership, a license or a sublicense to the other Party with respect thereto (unless such
other Party agrees in writing to bear such payment obligations [***] to providing access, ownership,
a license or a sublicense to such item by such other Party).

1.39 "Development Purchase Commitment" means, for a given Contract Year, the amount in the column
named "Development Purchase Commitment" in Table 7.2.2 for such Contract Year, as may be amended
from time to time under this Agreement.

1.40 "Development Purchases" means, during any period of time, the aggregate amount paid by Ginkgo
to BLI for the conduct of activities under any Workflow Development Plan or otherwise under Section
2.4.2 (Costs under Workflow Development Plan - Payment) during such period of time.

1.41 "Disclosing Party" is defined in Section 10.1 (Confidential Information).

1.42 "Discovered Antibody" has the meaning set forth in Section 7.4.2 (Milestone Events).

1.43 "Dollars" means United States dollars ($).

1.44 "Drug Approval Application" means any New Drug Application ("NDA"), as defined in the FFDCA, or
any corresponding foreign applications in the Territory, including (a) with respect to the European
Union, a Marketing Authorization Application (a "MAA") filed with the EMA pursuant to the
Centralized Approval Procedure or with the applicable Regulatory Authority of a country in Europe
with respect to the mutual recognition or any other regional or national approval procedure or (b)
with respect to Japan, an MAA filed with the PMDA. Page 6 of 85
<!-- page 7 -->
1.45 "Effective Date" has the meaning set forth in the Preamble.

1.46 "EMA" means the European Medicines Agency and any successor agency(ies) or authority having
substantially the same function.

1.47 "European Union" or "E.U." means the economic, scientific and political organization of member
states known as the European Union, as its membership may be altered from time to time, and any
successor thereto, except that, for purposes of this Agreement, the E.U. will be deemed to include
[***] the United Kingdom, irrespective of whether any such country leaves the European Union.

1.48 "Excluded Fields" means the use of the Beacon Platform for:

1.48.1 [***];

1.48.2 [***];

1.48.3 [***];

1.48.4 [***];

1.48.5 [***]; and

1.48.6 [***].

1.49 "Expert Panel" has the meaning set forth in Section 3.5.3 (Decision-Making).

1.50 "Expiration" has the meaning set forth in Section 13.3.1 (General).

1.51 "Extended Force Majeure Event" has the meaning set forth Section 14.8 (Force Majeure).

1.52 "Failure to Supply" has the meaning set forth in Section 5.4.3(a) (Remedial Efforts).

1.53 "FAS" means a BLI Field Application Scientist providing [***] to Ginkgo related to a Workflow
Development Plan or a Workflow either (a) at Ginkgo's facilities or (b) [***]; provided that, in the
case of clause (b) of this Section 1.50 ("FAS" definition), such BLI Field Application Scientist
must be specifically dedicated to development of Workflows on at least a part-time basis and
identified as such in the Workflow Development Plan under this Agreement (such identification to
include, in the case of part-time FAS, a specified percentage of dedication to Ginkgo [***]).

1.54 "FAS Support Cost" shall mean, with respect to any services provided by one or more FAS(s) to
Ginkgo over a specified period of time, the amount equal to the aggregate of the applicable FAS
Support Rates for such services during such period of time.

1.55 "FAS Support Rate" means, with respect to any services provided by a FAS pursuant to this
Agreement to Ginkgo, the applicable rate (dependent on the length of support) for such services set
forth in Schedule 5.2.1 (Pricing Schedule), subject to adjustment as set forth in Section 5.2.2(c)
(Adjustments). Page 7 of 85
<!-- page 8 -->
1.56 "FDA" means the United States Food and Drug Administration and any successor agency(ies) or
authority having substantially the same function.

1.57 "FFDCA" means the United States Federal Food, Drug, and Cosmetic Act, 21 U.S.C. § 301 et seq.,
as amended from time to time, together with any rules, regulations and requirements promulgated
thereunder (including all additions, supplements, extensions, and modifications thereto).

1.58 "Force Majeure Event" has the meaning set forth in Section 14.8 (Force Majeure).

1.59 "FOU License Fee" has the meaning set forth in Section 7.4.1 (License Fees).

1.60 "FTE" means (a) with respect to any full-time employee of BLI, [***], who is [***] dedicated to
the development of Workflows under this Agreement, a total of twelve (12) months of [***] work
conducted by such employee or (b) with respect to any full-time employee of BLI that is not [***]
dedicated to the development of Workflows under this Agreement, a full time equivalent effort
consisting of a minimum of a total of [***] ([***]) hours per year of work [***] a Workflow
Development Plan by such employee of a Party. In no event shall the work of one (1) employee exceed
1 full FTE.

1.61 "FTE Costs" means, with respect to any given activity or activities over any specified period
of time, the number of FTEs conducting such activity or activities multiplied by the FTE Rate.

1.62 "FTE Rate" means the rates per annum, listed in Schedule 1.62 (FTE Rate), which rate includes
certain allowable allocations and subject to increase on an annual basis as of January 1 of each
year, beginning in 2020, by a factor which reflects the increase, if any, in the Consumer Price
Index for [***], as reported by the U.S. Bureau of Labor Statistics, for January 1 of such year when
compared to the comparable statistic for January 1 of the preceding year. For clarity, if there is
no such increase in the CPI-[***], the FTE Rate shall remain the same and shall not decrease.

1.63 "Full Purchase Target" has the meaning set forth in Section 7.2.1 (Purchase Commitments -
Generally).

1.64 "Generalized Workflow" means any Collaboration Workflow or component thereof that is designated
as a "Generalized Workflow" by the Parties in a Workflow Development Plan or, if the Parties have
made no designation, is not a Specific Implementation. By way of non-limiting example, Generalized
Workflows would encompass Workflows or components thereof that are not Specific Implementations and
are generally directed to and required to enable:

1.64.1 [***],

1.64.2 [***]; Page 8 of 85

1.64.3 [***];

1.64.4 [***];
<!-- page 9 -->
1.64.5 [***]; or

1.64.6 [***].

For the purposes of Section 1.64.3 and Section 1.128, the following examples serve to illustrate the
concept of a "[***]" (a) [***] (b) [***] and (c) [***]

1.65 "Ginkgo" has the meaning set forth in the Preamble.

1.66 "Ginkgo Background IP" means any Intellectual Property provided or otherwise disclosed to BLI
under this Agreement or otherwise [***] for the performance of any activities allocated to BLI under
a Workflow Development Plan that is (a) Controlled by Ginkgo or its Affiliates as of the Effective
Date, (b) that comes into the Control of Ginkgo after the Effective Date other than by means of this
Agreement or the activities performed hereunder, or (c) developed during the Term by Ginkgo [***].

1.67 "Ginkgo Excluded Use" has the meaning set forth in Section 9.1.6 (Use in Excluded Fields).

1.68 "Ginkgo Indemnitee" has the meaning set forth in Section 12.1 (Indemnification by BLI).

1.69 "Ginkgo Inventions" has the meaning set forth in Section 8.2 (Ownership of Ginkgo Inventions
and BLI Inventions).

1.70 "Ginkgo Licensed IP" has the meaning set forth in Section 9.2 (Grants to BLI).

1.71 "Ginkgo Materials" has the meaning set forth in Section 8.2.1(d) (Ownership of Ginkgo
Inventions and BLI Inventions).

1.72 "Ginkgo Subcontractor" means a Person to whom Ginkgo has subcontracted any of its activities
under this Agreement pursuant to Section 2.7 (Subcontracting).

1.73 "Ginkgo Workflows" means Workflows on the Beacon Platform that are developed by [***]. For
clarity, [***].

1.74 "Go/No-Go Criteria" has the meaning set forth in Section 2.2.1(g) (Workflow Development Plans -
Generally).

1.75 "Hardware" means any and all hardware, equipment, devices, tools, apparatus, machinery, and
electronics including, but not limited to, the Beacon Optofluidic Machine, computer and
computer-related hardware, servers, networking equipment, interfaces, databases, support equipment,
power supplies, wiring and associated equipment. Page 9 of 85
<!-- page 10 -->
1.76 "Headstart Invention" means any (a) specific part or component of a [***] (other than any
[***], including any [***]) or (b) [***] in its entirety, including [***], in each case, either (i)
designated as a "Headstart Invention" in the applicable Workflow Development Plan or (ii) for which
Ginkgo has provided, or is slated to provide, by reference to the applicable category of the
Workflow Development Plan(s) as further described in Section 2.2.1(f) and Section 2.2.1(h),
Development Purchase funding of greater than [***] percent ([***]%) of the Budget set forth in the
applicable Workflow Development Plan(s). For clarity, in no event shall any improvements,
modifications or other changes to the [***], whether [***] based, [***] or [***], deemed to be a
Headstart Invention or be subject to a Headstart Period.

1.77 "[***]" means, [***] and [***] that [***] and (b) [***].

1.78 "Headstart Period" has the meaning set forth in Section 6.1.1 (BLI Standstill).

1.79 "[***]" means the offering or performance of any [***] services using the Beacon Platform, for
commercial sale or otherwise, to [***]; provided that in no event shall [***] include (a) use of the
Beacon Platform to [***] if the same does not [***] or (b) the [***] outside of the Beacon Platform.

1.80 "[***]" means the offering or performance of any [***] services using the Beacon Platform, for
commercial sale or otherwise, for [***] applications to the extent specifically related to [***];
provided that in no event shall [***] include using the Beacon Platform to [***] if the same does
not [***].

1.81 "Incremental Withholding Taxes" has the meaning set forth in Section 7.6 (Taxes).

1.82 "IND" means an application filed with a Regulatory Authority for authorization to commence
Clinical Trials, including: (a) an Investigational New Drug Application as defined in the FFDCA or
any successor application or procedure filed with the FDA; (b) any equivalent of a United States IND
in other countries or regulatory jurisdictions (i.e., clinical trial application); and (c) all
supplements, amendments, variations, extensions and renewals thereof that may be filed with respect
to any of the foregoing.

1.83 "Independent Development" has the meaning set forth in Section 8.9 (Specific Implementation
Restrictions).

1.84 "Initial Workflows" has the meaning set forth in Section 2.2.2 (Committed Workflows).

1.85 "Initiation" or "Initiate" means, with respect to a Clinical Trial, the first dosing of the
first human subject or patient in such Clinical Trial.

1.86 "Intellectual Property" means all intellectual and industrial property, and all rights therein
and thereto, including registration rights thereto, of any kind throughout the world, including
Patent Rights, Software, ideas, data, inventions, discoveries, algorithms, formulas, compositions,
configurations, specifications, sequences, product applications, formulations, assays, techniques,
sketches, drawings, models, works of authorship, copyrights, recordings, moral Page 10 of 85
<!-- page 11 -->
rights, mask works, design rights, trademarks, trade names, trade dress, service marks, logos, trade
secrets, methods, processes, techniques, developments, know-how, and all other similar rights,
whether or not registered or capable of being registered in any jurisdiction.

1.87 "Intended End of Term" means the later of (a) the seventh (7th) anniversary of the Effective
Date and (b) the date determined to be the "Intended End of Term" under Section 7.2.2(d) (Effects of
Tolling).

1.88 "[***]" has the meaning set forth in Section 14.5.2 (Dispute Resolution).

1.89 "JRC" or "Joint Review Committee" is defined in Section 3.1 (Joint Review Committee).

1.90 "Key Collaboration Workflow" means a Collaboration Workflow designated as a "Key Collaboration
Workflow" by the JRC pursuant to Section 3.2.11 (JRC Responsibilities).

1.91 "Key Person" has the meaning set forth in Section 5.4.1(b) (Dedicated FTEs; Key Persons).

1.92 "Lead Time" means, with respect to a Beacon Optofluidic Machine (including related Hardware and
Software), Consumable or Service, the "Lead Time" for such Beacon Optofluidic Machine, Consumable or
Service as set forth in Schedule 1.92 (Lead Time) or as otherwise mutually agreed upon by the
Parties in writing.

1.93 "Licensed Field" means any and all organisms, products, fields and uses other than the Excluded
Fields.

1.94 "Licensed Product" means a [***] product within the Licensed Field, including (a) [***] or (b)
[***] by such [***] described in clause (a) of this Section 1.94, in each case of ((a)-(b)),
initially produced on the Beacon Platform or, if not initially produced on the Beacon Platform, is
later [***] through use of the Beacon Platform, with respect to each, in the conduct of activities
[***] to produce such a product.

1.95 "List Price" means, at any given time and for any Beacon Optofluidic Machine, Consumable or
Service, the price for such Optofluidic Machine, Consumable or Service [***] at such time.

1.96 "Losses" has the meaning set forth in Section 12.1 (Indemnification by BLI).

1.97 "MAA" has the meaning set forth in Section 1.44 ("Drug Approval Application").

1.98 "[***]" means [***].

1.99 "Maximum Amount" has the meaning set forth in Section 5.3.1 (Issuance).

1.100 "Milestone Event" has the meaning set forth in Section 7.4.2 (Milestone Payments). Page 11 of
85
<!-- page 12 -->
1.101 "Milestone Payment" has the meaning set forth in Section 7.4.2 (Milestone Payments).

1.102 "Minimum Cumulative Purchase Commitment" means, with respect to a Contract Year, the amount
set forth in the column "Minimum Cumulative Purchase Commitment" in Table 7.2.2 for such Contract
Year, as such Minimum Cumulative Purchase Commitment may be amended from time to time under this
Agreement.

1.103 "NDA" has the meaning set forth in Section 1.44 ("Drug Approval Application").

1.104 "OptoSelect Chips" means those BLI microfluidic chips described in Schedule 1.104 (OptoSelect
Chips) and any other BLI chip used on the Beacon Optofluidic Machine that is developed to execute
Workflows.

1.105 "Party" and "Parties" has the meaning set forth in the Preamble.

1.106 "Patent Rights" means any and all (a) issued patents, (b) pending patent applications,
including all provisional applications, substitutions, continuations, continuations-in-part,
divisions and renewals, and all patents granted thereon, (c) patents-of-addition, reissues,
reexaminations and extensions or restorations by existing or future extension or restoration
mechanisms, including patent term adjustments, patent term extensions, supplementary protection
certificates or the equivalent thereof, (d) inventor's certificates, (e) other forms of
government-issued rights substantially similar to any of the foregoing and (f) United States and
foreign counterparts of any of the foregoing.

1.107 "Performance Service Plan" shall mean the plan set forth in Schedule 1.107 (Performance
Service Plan).

1.108 "Permitted Subcontractor(s)" means, individually or collectively, BLI Subcontractor(s) and
Ginkgo Subcontractor(s).

1.109 "Person" means any natural person, corporation, unincorporated organization, partnership,
association, joint stock company, joint venture, limited liability company, trust or government or
any agency or administrative or political subdivision of any government, or any other entity.

1.110 "Phase II Clinical Trial" means a Clinical Trial, the principal purpose of which is to make a
preliminary determination as to whether a pharmaceutical product is safe for it intended use and to
obtain sufficient information about such product's efficacy, in a manner that is generally
consistent with 21 CFR § 312.21(b), as amended (or its successor regulation), to permit the design
of further Clinical Trials. For clarity, A "Phase II Clinical Trial" shall include any clinical
trial that would or does satisfy the requirements of 21 C.F.R. § 312.21(b) or any comparable
regulation outside the United States whether or not it is designated a Phase II Clinical Trial.

1.111 "Phase III Clinical Trial" means a pivotal Clinical Trial with a defined dose or a set of
defined doses of a pharmaceutical product designed to ascertain efficacy and safety of such product,
in a manner that is generally consistent with 21 CFR § 312.21(c), as amended (or its successor
regulation), for the purpose of enabling the preparation and submission of a Drug Page 12 of 85
<!-- page 13 -->
Approval Application. A "Phase III Clinical Trial" shall include any clinical trial that would or
does satisfy requirements of 21 C.F.R. § 312.21(c) or any comparable regulation outside the United
States., whether or not it is designated a Phase III Clinical Trial.

1.112 "PMDA" means Japan's Pharmaceuticals and Medical Devices Agency and any successor agency(ies)
or authority having substantially the same function.

1.113 "Preamble" means the first, unnumbered paragraph of this Agreement.

1.114 "Product Warranty" means, with respect to any Beacon Optofluidic Machine or Consumable, that
(a) the representations, warranties and covenants of BLI set forth in the applicable BLI Terms and
Conditions (including the product warranties therein) are true with respect to such Beacon
Optofluidic Machine or Consumable, (b) with respect to a Beacon Optofluidic Machine, installation
and qualification of such Beacon Optofluidic Machines are in accordance with, and meet the standards
of, BLI's then-existing [***], such standards to be at least as stringent as those set forth in
[***] and (c) BLI does not have knowledge of any defect that would result in a [***] other than
those defects [***] or the [***] or any reason that such Beacon Optofluidic Machine or each
Consumable is [***].

1.115 "Production Purchases" means the sum of payments made by Ginkgo to BLI for:

1.115.1 purchases of Beacon Optofluidic Machines together with any associated freight, insurance,
customs charges, tariffs or other transportation charges;

1.115.2 purchases of OptoSelect Chips and other Consumables used by the Beacon Platform outside of a
Workflow Development Plan together with any associated freight, insurance, customs charges, tariffs
or other transportation charges;

1.115.3 FAS or other BLI [***] personnel, as requested by Ginkgo, for general support services
(including all payments for a Performance Service Plan), including [***] with respect to activities
performed outside of a Workflow Development Plan;

1.115.4 [***];

1.115.5 [***]; and

1.115.6 any other amounts, including for [***] (including for Beacon Optofluidic Machines or any
Consumable as applicable, properly charged and invoiced to Ginkgo and paid by Ginkgo under this
Agreement in connection with the supply or provision of goods and services by BLI, which are not
Development Purchases.

1.116 "Purchase Order" has the meaning set forth in Section 5.3.1 (Issuance).

1.117 "Purpose" shall have the meaning set forth in the first WHEREAS clause of this Agreement.

1.118 "Receiving Party" has the meaning set forth in Section 10.1 (Confidential Information). Page
13 of 85
<!-- page 14 -->
1.119 "Regulatory Approval" means, with respect to a country in the Territory, any and all approvals
(including Drug Approval Applications that have been approved by a Regulatory Authority), licenses,
registrations or authorizations of any Regulatory Authority necessary to commercialize a product in
such country[***].

1.120 "Regulatory Authority" means any applicable supra-national, federal, national, regional,
state, provincial or local governmental or regulatory authority, agency, department, bureau,
commission, council or other entities (e.g., the FDA, EMA and PMDA) regulating or otherwise
exercising authority with respect to activities contemplated in this Agreement.

1.121 "Remedial Plan" has the meaning set forth in Section 5.4.3(a) (Remedial Efforts).

1.122 "Responsible Tax Party" has the meaning set forth in Section 7.6 (Taxes).

1.123 "Rolling Forecast" has the meaning set forth in Section 5.1 (Forecasts).

1.124 "Senior Officers" means, (a) with respect to Ginkgo, [***] and (b) with respect to BLI, [***].

1.125 "Services" means services to be provided by or on behalf of BLI to Ginkgo under this
Agreement, including with respect to Beacon Platform Software development services, installation
services, support services and general training services, but excluding those services provided
under a Workflow Development Plan.

1.126 "Service Level Standards" means, with respect to any service at any given time, the standards
for the performance of such service most recently agreed upon by the Parties at such time or if no
such standards have been previously agreed upon by the Parties, the standards for the performance of
such service then in effect for BLI's other [***] customers.

1.127 "Software" means full applications or programs as well as partial applications, programs or
sections of software code, whether source code, object code or other form, in each case incorporated
in or otherwise used by the Beacon Optofluidic Machine.

1.128 "Specific Implementation" means any individual component of any Collaboration Workflow that is
designated as a "Specific Implementation" by the Parties in a Workflow Development Plan or, if the
Parties have made no designation, (a) is [***] for a particular [***] pursuant to a Workflow
Development Plan or [***]; or (b) incorporates [***] proprietary to Ginkgo that [***], provided
that, to the extent such [***] provided by Ginkgo [***].

1.129 "Specifications" means, (a) with respect to any Beacon Optofluidic Machine (including related
Hardware and Software), BLI's specifications set forth in Schedule 1.10 (Beacon Optofluidic
Machine), along with any other specifications mutually agreed upon by the Parties in writing, in
each case for such Beacon Optofluidic Machine (including related Hardware and Software) or (b) with
respect to any Consumable, the specifications set forth in Schedule 1.36 (Consumables), along with
any other specifications mutually agreed upon by the Parties in writing, in each case for such
Consumable. Page 14 of 85
<!-- page 15 -->
1.130 "Substantially Completed" means, with respect to a Workflow, that such Workflow (a) [***] and
(b) is judged by the JRC (or Expert Panel, if applicable) to be substantially complete based upon
[***]. For clarity, [***] will be considered by the JRC (or Expert Panel, if applicable) to be [***]
of substantial completion.

1.131 "Term" has the meaning set forth in Section 13.1 (Term).

1.132 "Territory" means worldwide except for any and all embargoed and sanctioned countries as
identified by the U.S. government.

1.133 "Third Party" means any Person other than Ginkgo and its Affiliates and BLI and its
Affiliates.

1.134 "United States" or "U.S." means the United States of America, including its territories and
possessions.

1.135 "Upfront Payment" has the meaning set forth in Section 7.1 (Upfront Payment).

1.136 "VAT" has the meaning set forth in Section 7.6 (Taxes).

1.137 "Workflow" means a defined set of tasks performed using the Beacon Platform in a certain order
utilizing specific Consumables to [***], including to load, culture, assay and export cells.

1.138 "Workflow Development Plan(s)" has the meaning set forth in Section 2.2 (Workflow Development
Plans).

1.139 "Working Group" has the meaning set forth in Section 3.8 (Working Groups). 2. DEVELOPMENT

2.1 Collaboration in General. The Parties will undertake this Agreement in furtherance of the
Purpose and under the guidance of the JRC pursuant to Article 3 (Joint Review Committee). During the
Term, each Party will use diligent efforts to implement and perform (itself or through its Permitted
Subcontractors) its respective obligations under and in accordance with (a) this Agreement and (b)
each Workflow Development Plan in accordance with the timelines set forth in such Workflow
Development Plan. Each Party will reasonably cooperate with each other in the performance of their
responsibilities under this Agreement and each Workflow Development Plan, including (i) responding
to reasonable requests by the other Party submitted in accordance with this Agreement to provide
information reasonably necessary for the performance of such requesting Party's obligations under
this Agreement (including any Workflow Development Plan) and (ii) causing its personnel, agents and
representatives, while at the other Party's facility, to abide by the written work rules and
facility regulations applicable to such facility as provided in advance by such other Party. Page 15
of 85

2.2 Workflow Development Plans.
<!-- page 16 -->
2.2.1 Generally. Subject to the requirements of Section 2.2.2 (Committed Workflows), from time to
time during the Term, the Parties shall discuss in good faith entering into work plans setting forth
the activities to be undertaken by the Parties to develop a specific Collaboration Workflow in
furtherance of the Purpose (each such work plan that is consistent with the terms of this Agreement
and approved by the JRC, and as may be amended from time to time in accordance with this Agreement,
a "Workflow Development Plan"); provided that the Parties and the JRC will manage the pipeline of
Collaboration Workflows such that [***]. If the Parties mutually agree that a new Workflow
Development Plan should be undertaken by the Parties in order to further the Purpose, then the
Parties shall work together in good faith to prepare an initial draft of the proposed Workflow
Development Plan on commercially reasonable terms. Once the proposed Workflow Development Plan has
been drafted, such proposed Workflow Development Plan will be submitted to the JRC and the JRC shall
review such proposed Workflow Development Plan and either (a) reject the proposed Workflow
Development Plan, (b) accept the proposed Workflow Development Plan or (c) amend the proposed
Workflow Development Plan prior to approving such plan. If the JRC approves a proposed Workflow
Development Plan, such proposed plan shall be deemed a "Workflow Development Plan" under this
Agreement and attached to this Agreement as an Exhibit (the first approved Workflow Development Plan
to be attached as Exhibit A-1 and subsequently approved Workflow Development Plans to be
sequentially numbered as Exhibit A-2, Exhibit A-3, etc.) and, through such attachment, made a part
of this Agreement. BLI hereby acknowledges and agrees that in no event will BLI perform any work for
Ginkgo in connection with this Agreement other than pursuant to a JRC-approved Workflow Development
Plan, other than with respect to BLI providing Ginkgo with any FAS support or other standard service
and support pursuant to the terms of this Agreement. At a minimum, each Workflow Development Plan
will include the following information:

(a) defined objective and scope of the relevant Collaboration Workflow;

(b) a detailed description of the work to be performed under such Workflow Development Plan and
which components of the Collaboration Workflow shall be deemed a Generalized Workflow or a Specific
Implementation;

(c) a detailed description of each Party's roles and responsibilities with respect to the work to be
performed under such Workflow Development Plan;

(d) the Budget[***] and the allocation of responsibility between the Parties for the funding of such
Budget;

(e) timelines for performing and completing work under such Workflow Development Plan; Page 16 of 85
<!-- page 17 -->
(f) identification of deliverables to be created by a Party in connection with the work to be
performed, including (i) any operating protocol, Software, Hardware, consumable, Beacon Optofluidic
Machine Improvement or Workflow to be created and (ii) categories (e.g., [***]) of Headstart
Inventions (and specific Headstart Inventions) that the JRC reasonably believes, during the drafting
of the Workflow Development Plan, will result from the work to be performed by the Parties under the
Workflow Development Plan;

(g) (i) [***] descriptions of one or more go/no-go criteria, if any, at which time the JRC shall
specifically determine whether to continue work under such Workflow Development Plan (each such
criteria, a "Go/No-Go Criteria"); (ii) [***] metrics associated with such Collaboration Workflow
being Substantially Completed; (iii) additional [***] criteria for the work to be performed and (iv)
[***] criteria for any deliverables to be created, including any Workflows (such criteria with
respect to Collaboration Workflows to include any additional criteria to be used when determining if
a Collaboration Workflow has been Substantially Completed); and

(h) (i) the anticipated Development Purchase amounts associated with any Collaboration Workflow that
is the subject of such Workflow Development Plan and (ii) with respect to any Headstart Invention,
the anticipated Development Purchase amounts (based on the Budget) to be paid by Ginkgo for [***] a
Headstart Invention and each category of Headstart Inventions set forth in the applicable Workflow
Development Plan.

2.2.2 Committed Workflows. With respect to the Workflow Development Plans to be proposed to the JRC
for approval and conducted by the Parties during the [***] Contract Years, subject to the
requirement set forth in Section 7.2.2(b)(i) (Development Purchase Commitments) that not less than
[***] ([***]%) of the Development Purchases made in the [***] Contract Years be for the development
of Workflows for [***], the Parties agree that such Workflow Development Plans shall focus on yeast
and mammalian cells and the [***] ([***]) initial Workflow Development Plans shall be directed
toward the categories of Workflows set forth in Schedule 2.2.2 (Initial Workflow Development Plans)
hereto (collectively, the "Initial Workflows"). At least [***] ([***]) of the Initial Workflows
shall also be deemed to be Key Collaboration Workflows by the JRC (including as indicated on
Schedule 2.2.2 (Initial Workflow Development Plans)). A draft outline of the first [***] ([***])
Workflow Development Plans for Initial Workflows are attached hereto as Exhibit B. Promptly
following the Effective Date and in no event later than [***] ([***]) days after the Effective Date,
the Parties shall finalize the Workflow Development Plans for such first [***] ([***]) Initial
Workflows and begin implementation of such Initial Workflows. Promptly thereafter, the Parties shall
develop a Workflow Development Plan for each such Initial Workflow to be submitted to the JRC for
rejection or approval pursuant to Section 2.2.1 (Workflow Development Plans - Generally). Page 17 of
85
<!-- page 18 -->
2.2.3 Retooling and Development Costs. If, pursuant to Section 3.2.6, the JRC determines that
Hardware or Consumables will need to be developed, retooled or modified in order to create
Collaboration Workflows, then Ginkgo and BLI shall discuss and negotiate in good faith the sharing
of the costs associated therewith, which, once mutually agreed by the Parties, will be proposed to
the JRC in the form of an amendment to the applicable Workflow Development Plan pursuant to Section
2.3.2 (Amendments by the Parties); provided that in all events the Intellectual Property in such
developed, retooled or modified Hardware or Consumables will be [***].

2.3 Amendments to Workflow Development Plans.

2.3.1 Amendments Raised by the JRC. The JRC will periodically review (at least once per [***]) each
approved Workflow Development Plan and each Party's performance thereunder to determine whether
amendments are needed with respect to such Workflow Development Plan in order to more efficiently
develop the relevant Workflow, which review will include [***]. If the JRC determines that an
amendment is needed with respect to any approved Workflow Development Plan, then the JRC shall amend
and restate the applicable Workflow Development Plan to reflect such amendment with such amended and
restated Workflow Development Plan to replace the previously attached Workflow Development Plan and,
through such attachment and, after signature by each of the Parties, made a part of this Agreement.

2.3.2 Amendments Raised by the Parties. Notwithstanding anything in Section 2.3.1 (Amendments by the
JRC) to the contrary, either Party may, at any time, propose amendments to a Workflow Development
Plan for the JRC's consideration and such Party shall submit the proposed amendment to the JRC for
consideration. Following submission of a proposed amendment to the JRC, the JRC shall review such
proposed amendment and either (a) reject the proposed amendment to such Workflow Development Plan,
(b) accept the proposed amendment to such Workflow Development Plan or (c) further amend the
proposed amendment to such Workflow Development Plan for approval by the JRC. If the JRC approves a
proposed amendment to a Workflow Development Plan, then the JRC shall amend and restate the
applicable Workflow Development Plan to reflect such amendment with such amended and restated
Workflow Development Plan to replace the previously attached Workflow Development Plan and, after
signature by each of the Parties, be made a part of this Agreement.

2.4 Costs under Workflow Development Plans.

2.4.1 Reporting. Within [***] ([***]) days following the end of each [***], [***], BLI shall provide
a detailed report to Ginkgo setting forth the activities conducted by BLI [***] during such [***]
and the costs for such activities [***]. If Ginkgo disputes any costs set forth in BLI's report, it
shall so notify BLI in writing within [***] ([***]) days of receiving such report and provide the
specific reasons for the dispute and the Parties will attempt to resolve such dispute in good faith
for [***] ([***]) days following such notice. In the event the Parties are unable to resolve such
dispute in such [***] ([***]) day period, then either Party may initiate dispute resolution in
accordance with Section 14.5.2 (Dispute Resolution) and [***]; provided that, during the pendency of
any such dispute, if Page 18 of 85
<!-- page 19 -->
[***], [***] and, if any such disputed costs paid by Ginkgo are finally determined, pursuant to
Section 14.5.2 (Dispute Resolution) or by mutual agreement of the Parties, to not have been owed to
BLI at the time of payment, BLI will provide a credit against future purchases made by Ginkgo in the
amount of the overpayment; provided further that, in the event that there are not sufficient future
purchases made by Ginkgo during the Term to fully so credit, BLI will promptly refund any remaining
amount of the overpayment to Ginkgo.

2.4.2 Payment. [***], after generating and delivering a report as set forth in Section 2.4.1
(Reporting) or at such other time as may be specified [***], BLI shall issue an invoice to Ginkgo
within [***] ([***]) days of Ginkgo receiving such report or, if any costs under BLI's report are
disputed pursuant to Section 2.4.1 (Reporting), within [***] ([***]) days of resolution of such
dispute, such invoice to be for the amount of costs owed by Ginkgo, if any, to effect the
appropriate cost allocation [***] in such [***]. Notwithstanding anything to the contrary in this
Agreement, in no event shall BLI provide an invoice (a) requesting payment, nor shall Ginkgo be
responsible, in any given [***], for any costs incurred by BLI for any activity in excess of [***]
percent ([***]%) of the costs of such activity as set forth in the applicable Workflow Development
Plan's Budget for such [***] or (b) for any Development work performed outside the Workflow
Development Plan. Ginkgo shall pay all undisputed amounts under an invoice received from BLI under
this Section 2.4.2 (Payment) within [***] ([***]) days after receipt of such BLI invoice, and any
overdue payments on undisputed amounts shall be subject to payment of interest pursuant to Section
7.10 (Late Payment). All amounts received by BLI in connection with the performance of each Workflow
Development Plan shall be non-refundable except as otherwise set forth in Section 7.8 (Audits) and
Section 6.1 (Headstart Period).

2.5 Termination of Workflow Development Plans. A Workflow Development Plan, once approved by the
JRC, may be terminated by the JRC, including, by way of example, if: (a) both Parties provide notice
to the JRC requesting such termination or (b) the JRC finds that (i) termination is [***] or (ii)
that [***]. In the event of termination of a Workflow Development Plan under this Section 2.5
(Termination of Workflow Development Plans), BLI will cease working on the Workflow Development Plan
and [***] cancel orders or stop the work of a Permitted Subcontractor or any other supplier.
Notwithstanding termination of a Workflow Development Plan, Ginkgo shall pay BLI for Ginkgo's share,
if any, of the reasonable costs associated with [***] incurred in accordance with this Agreement
prior to the decision to terminate such Workflow Development Plan to the extent that BLI could not,
after using [***], (A) stop or cancel such or (B) relocate or reassign to any work to be performed
for another Person.

2.6 Limitations. Notwithstanding anything to the contrary in this Agreement, neither Party will be
required to conduct any activity to develop a Workflow other than those activities allocated to it
in a Workflow Development Plan and no proposed Workflow Development Plan (or, subject to Section 2.3
(Amendments to Workflow Development Plans), any amendment thereto) shall become binding on the
Parties until approved by the JRC.

2.7 Subcontracting. Each Party may only subcontract its activities under this Agreement (including
under a Workflow Development Plan) with the other Party's consent; provided that such consent shall
not be necessary if (a) such subcontracting of activities is [***] Page 19 of 85
<!-- page 20 -->
of such subcontracting Party (e.g. [***]) or (b) [***] (e.g. [***]) in order for a Party to [***].
In any event, prior to any subcontracting by a Party to a Permitted Subcontractor, the
subcontracting Party shall obtain a written undertaking from the Permitted Subcontractor that it
will be subject to the applicable terms and conditions of this Agreement, including the
confidentiality provisions of Article 10 (Confidentiality). Subcontracting will not relieve a Party
of its obligations under this Agreement and each Party will remain directly liable for the acts and
omissions of its Permitted Subcontractors. Any breach of this Agreement by a Permitted Subcontractor
will be deemed to be a breach by the Party that subcontracted its activities to such breaching
Permitted Subcontractor.

2.8 Records. Each Party shall, and shall cause its Affiliates and Permitted Subcontractors to,
maintain records in sufficient detail for the other Party to confirm compliance with this Agreement
and in good scientific manner appropriate for patent and regulatory purposes under Applicable Law,
which shall [***] properly reflect all activities conducted and results achieved by such Party under
this Agreement. Such records shall be retained by such Party, its Affiliates or Permitted
Subcontractors until [***] ([***]) years after the end of the period to which such books and records
pertain or for such longer period as may be required by Applicable Law. Each Party shall have the
right, during normal business hours and upon reasonable notice, to inspect all such records of the
other Party, its Affiliates or Permitted Subcontractors. The reviewing Party shall be responsible
for all costs of the inspection but shall have no right to copy or retain records. All disclosed
records and the information disclosed therein shall be treated as Confidential Information in
accordance with Article 10 (Confidentiality). 3. JOINT REVIEW COMMITTEE

3.1 Formation; Chairperson. Within [***] ([***]) days of the Effective Date (or such other date as
may be mutually agreed to by the Parties), the Parties will establish a Joint Review Committee
("JRC") comprised of two (2) representatives of Ginkgo and two (2) representatives of BLI, each of
whom must have the requisite experience and seniority to enable such Person to make decisions on
behalf of the Party it represents with respect to the issues falling within the jurisdiction of the
JRC. Each Party may replace its representatives to the JRC at any time upon prior written notice to
the other Party; provided that such replacement representatives must have the experience and
seniority required under this Section 3.1 (Formation; Chairperson). [***] will select from its
representatives the chairperson for the JRC, whose role shall be to call the periodic meetings, and
publish meeting minutes. From time to time during the Term, [***] may change the representative who
will serve as chairperson upon written notice to [***].

3.2 JRC Responsibilities. The JRC will have that specific decision-making authority expressly
enumerated in this Agreement and will provide oversight and a forum for discussing all matters
arising in connection with this Agreement, including with respect to planning, reviewing and
coordinating the various activities to be undertaken by the Parties pursuant to a Workflow
Development Plan. In particular, the JRC will be responsible for:

3.2.1 rejecting or approving proposed Workflow Development Plans submitted to it by a Party or as
amended by the JRC pursuant to Section 2.2.1 (Workflow Development Plans - Generally); Page 20 of 85
<!-- page 21 -->
3.2.2 pursuant to Section 2.2.1 (Workflow Development Plans - Generally), managing the pipeline of
anticipated Collaboration Workflows so that [***] including in the event a Workflow Development Plan
is terminated early by the JRC;

3.2.3 pursuant to Section 2.3.1 (Amendments by the JRC), periodically reviewing (at least once per
[***]) each Workflow Development Plan and each Party's performance thereunder in order to determine
whether amendments are needed with respect to such Workflow Development Plan and, if amendments are
needed, revising the Workflow Development Plan as necessary;

3.2.4 rejecting, prioritizing, approving or amending proposed amendments to Workflow Development
Plans submitted to it by a Party pursuant to Section 2.3.2 (Amendments by the Parties);

3.2.5 deciding whether [***] are at issue and whether to terminate a Workflow Development Plan as
further described in Section 2.5 (Termination of Workflow Development Plans);

3.2.6 in connection with each Workflow Development Plan, determining whether Hardware or Consumables
will need to be developed or retooled in order to create Collaboration Workflows such that the
Parties should discuss sharing of the costs associated therewith pursuant to Section 2.2.3
(Retooling and Development Costs);

3.2.7 in connection with each Workflow Development Plan, designating (a) which components of
Workflows are BLI Proprietary Workflows, which are Generalized Workflows, and which are Specific
Implementations and (b) (i) which categories (e.g., [***]) of Headstart Inventions (and specific
Headstart Inventions within such categories) that the JRC reasonably believes, during the drafting
of the Workflow Development Plan, will result from the work to be performed by the Parties under the
Workflow Development Plan and (ii) a reasonable estimation of the Development Purchase funding to be
paid by Ginkgo with respect to the development of such categories of Headstart Inventions, which
estimation will be set forth in the Budget for the applicable Workflow Development Plan; provided
that, in no event will failure by the JRC to list (A) specific parts or components of Generalized
Workflows or Collaboration Workflows or (B) Consumables, including OptoSelect Chips, with respect to
(A)-(B), as Headstart Inventions in a Workflow Development Plan be given any significance in
determining whether such invention constitutes a Headstart Invention;

3.2.8 determining whether or not a Collaboration Workflow has been Substantially Completed based on
the metrics for such Collaboration Workflow as set forth in the applicable Workflow Development
Plan;

3.2.9 pursuant to Section 7.2.1 (Purchase Commitments - Generally), determining whether additional
development work is necessary in order to enable Ginkgo to deploy the Beacon Platform as specified
in a Workflow Development Plan and if so, then determining how to adjust the Development Purchase
Commitments and Production Purchase Targets for the then-current and future Contract Years (with the
understanding the JRC has no power to modify the Maximum Amount or the Term); Page 21 of 85
<!-- page 22 -->
3.2.10 upon determination by the JRC or the Expert Panel that a Collaboration Workflow has not been
Substantially Completed, discussing if and how to address the Production Purchase amounts that would
have been relevant to such Collaboration Workflow;

3.2.11 designating at least [***] ([***]) Collaboration Workflows as Key Collaboration Workflows
within [***] ([***]) years of the Effective Date and at least [***] ([***]) Collaboration Workflows
as Key Collaboration Workflows within [***] ([***]) years of the Effective Date; and

3.2.12 performing such other functions as expressly set forth in this Agreement as being under the
purview of the JRC or as the Parties may mutually agree in writing, except where in conflict with
any provision of this Agreement.

3.3 Meetings and Minutes. Unless otherwise mutually agreed to by the Parties, the JRC will meet each
[***] by audio or video teleconference and, at a minimum, [***] each Contract Year in person, with
the location for such meetings alternating between Ginkgo and BLI facilities (or such other
locations as are mutually agreed by the Parties). Meetings of the JRC will be effective only if a
quorum of the JRC (as defined in Section 3.4 (Procedural Rules)) is present or participating by
videoconferencing. The chairperson of the JRC will be responsible for calling meetings on no less
than [***] ([***]) Business Days' notice, unless exigent circumstances require shorter notice. Each
Party will make all proposals for agenda items and will provide all appropriate information with
respect to such proposed items at least [***] ([***]) Business Days in advance of the applicable
meeting; provided that under exigent circumstances requiring input by the JRC, a Party may provide
its agenda items to the other Party within a shorter period of time in advance of the meeting, or
may propose that there not be a specific agenda for a particular meeting, so long as the other Party
consents to such later addition of such agenda items or the absence of a specific agenda for such
meeting, such consent not to be unreasonably withheld, conditioned or delayed. The JRC will
designate an individual to prepare and circulate for review and approval of the Parties minutes of
each meeting [***] ([***]) Business Days after the meeting. The Parties will agree on the minutes of
each meeting promptly, but in no event later than the next meeting of the JRC.

3.4 Procedural Rules. The JRC will have the right to adopt such standing rules as will be necessary
for its work, to the extent that such rules are not inconsistent with this Agreement. A quorum of
the JRC will exist whenever there is present at a meeting at least one (1) representative appointed
by each Party. The JRC will take action by consensus of the representatives present at a meeting at
which a quorum exists, with each Party having a single vote irrespective of the number of
representatives of such Party in attendance, or by a written resolution signed by at least one
representative appointed by each Party. From time to time during the Term, a Party may invite
non-voting employees (including its Alliance Manager), consultants and other advisors, experts and
specialists to attend meetings of the JRC; provided that such attendees (a) will not vote in the
decision-making process of the JRC, (b) are bound by obligations of confidentiality and non-use that
are at least as protective of the Parties as set forth in this Agreement and that restrict use and
disclosure of information learned while attending JRC meetings and (c) can be required to depart the
meeting upon the request of the other (non-inviting) Party, in its sole discretion, due to
confidentiality or business reasons. Page 22 of 85
<!-- page 23 -->
3.5 Decision-Making. If the JRC cannot, or does not, reach consensus on an issue at any JRC meeting
or within a period of [***] ([***]) Business Days thereafter (or such other period of time as
mutually agreed by the Parties or by consensus of the JRC), then upon the request of either Party,
the disagreement will first be referred to the Senior Officers of the Parties, who will confer in
good faith on the resolution of the issue. Any final decision mutually agreed to by the Senior
Officers will be conclusive and binding on the Parties. If the Senior Officers are not able to agree
on the resolution of any such issue within [***] ([***]) days after such issue was first referred to
them, then, if such decision is [***], [***] and, for all other decisions, shall be resolved
consistent with the provisions of this Section 3.5 (Decision-Making):

3.5.1 subject to Section 3.5.3, if the matter concerns (a) [***], including any [***] or (b) the
[***], the final decision shall be made by the Senior Officer of Ginkgo; provided that, in no event
may Ginkgo exercise its final-decision making authority, including in connection with amending an
approved Workflow Development Plan, in any manner that would (i) [***] BLI's obligations under such
Workflow Development Plan, (ii) obligate or require BLI to increase its spending under such Workflow
Development Plan by more than [***] percent ([***]%) of BLI's spending obligation under such
Workflow Development Plan or (iii) modify the Minimum Cumulative Purchase Commitment or the Full
Purchase Target;

3.5.2 subject to Section 3.5.3, if the matter concerns [***], including any [***] (provided that any
[***] shall not affect decision-making authority under this Section 3.5 (Decision-Making)), the
final decision shall be made by the Senior Officer of BLI; provided that, in no event may BLI
exercise its final-decision making authority, including in connection with amending an approved
Workflow Development Plan, in any manner that would (a) [***] Ginkgo's obligations under such
Workflow Development Plan [***] or (b) obligate or require Ginkgo to increase its spending under
such Workflow Development Plan by more than [***] percent ([***]%) of Ginkgo's spending obligation
under such Workflow Development Plan, or (c) modify the Minimum Cumulative Purchase Commitment or
the Full Purchase Target;

3.5.3 if the matter is determining (a) whether [***] or (b) whether [***] (including with respect to
[***]), with respect to each, at either Party's request, the dispute shall be resolved in an
accelerated manner by a panel of three (3) independent Third Parties, each having expertise with
respect to the subject matter of the applicable Workflow Development Plan (such panel, an "Expert
Panel"), subject to the following process: (i) each Party will engage one independent Third Party
expert for the Expert Panel [***] after [***] to serve on the Expert Panel, (ii) within [***]
([***]) days of any request to refer the matter to an Expert Panel or, if earlier, as promptly as
reasonably practicable after each Party's engagement of its Third Party Expert, the Parties' two (2)
Third Party experts shall mutually agree on a third (3rd) independent Third Party expert who will
serve on such panel and as chairperson of the panel, (iii) the Expert Panel will reach a decision as
to such matter (including whether [***]) as promptly as practicable, which may include having the
JRC or Parties submit information in support of the Expert Panel making a determination, Page 23 of
85
<!-- page 24 -->
but within no greater than [***] ([***]) days of the third (3rd) expert being chosen and (iv) [***]
the Parties will be bound by the determination of the Expert Panel. Each Party shall bear its own
costs of participating in the proceeding, including the costs incurred by its Third Party expert,
and shall equally share the costs incurred by the third (3rd) Third Party expert selected jointly by
the Parties' two (2) Third Party Experts, except that, with respect to [***]. The Expert Panel shall
be and is empowered to request additional information or materials from one or both Parties as
reasonably necessary for the Expert Panel to investigate and render a decision, [***]. The Parties
shall [***] with all such requests and decisions.

3.6 Limitations on Authority. Each Party will retain the rights, powers and discretion granted to it
under this Agreement and, unless expressly provided in this Agreement, no rights, powers or
discretion will be delegated to or vested in the JRC. The JRC will not have the power to accept,
amend, modify, waive or determine compliance with this Agreement; provided that, for clarity, the
JRC may reject, accept or amend proposed Workflow Development Plans pursuant to Section 2.2.1
(Workflow Development Plans - Generally) or review, amend or restate an approved Workflow
Development Plan pursuant to Section 2.3 (Amendments to Workflow Development Plans) or terminate an
approved Workflow Development Plan but, for clarity, in no event may the JRC amend or restate any
Workflow Development Plan so it includes work in any Excluded Field. Notwithstanding anything to the
contrary, no decision by the JRC or by a Party within the JRC will: (a) require the other Party to
breach any obligation or agreement that such other Party may have with or to a Third Party [***] or
(b) amend, modify, or waive a Party's compliance with, this Agreement (by way of example, a decision
to [***]), any of which shall require mutual written agreement of the Parties.

3.7 Alliance Managers. Each Party will appoint one employee of such Party who will oversee contact
between the Parties for all matters between meetings of each JRC and will have such other
responsibilities as the Parties may agree in writing after the Effective Date (each, an "Alliance
Manager"). Each Party may replace its Alliance Manager at any time by notice in writing to the other
Party. The Alliance Managers will work together to manage and facilitate the communication between
the Parties under this Agreement, including the resolution (in accordance with the terms of this
Agreement) of issues between the Parties that arise in connection with this Agreement.

3.8 Working Groups. From time to time, the JRC may establish and delegate duties to sub-committees
or directed teams (each, a "Working Group") on an "as-needed" basis to oversee particular projects
or activities. Each such Working Group will be constituted and will operate as the JRC determines;
provided that each Working Group will have equal representation from each Party, unless otherwise
mutually agreed. Working Groups may be established on an ad hoc basis for purposes of a specific
project or on such other basis as the JRC may determine. Each Working Group and its activities will
be subject to the oversight, review and approval of, and will report to, the JRC. In no event will
the authority of the Working Group exceed that specified by the JRC for such Working Group. All
decisions of a Working Group will be by consensus. Any disagreement between the designees of Ginkgo
and BLI with respect to a Working Group will be referred to the JRC for resolution. Page 24 of 85
<!-- page 25 -->
3.9 Expenses. Each Party will be responsible for all travel and related costs and expenses for its
members and other representatives to attend meetings of, and otherwise participate in, the JRC or
other Working Group. 4. APPLICABILITY OF BLI TERMS AND CONDITIONS.

With respect to Beacon Optofluidic Machines (including related Hardware and Software), Consumables
and Services for which Ginkgo has placed a Purchase Order pursuant to this Agreement, the Parties
agree to the BLI Terms and Conditions that apply with respect to Beacon Optofluidic Machines
(including related Hardware and Software), Consumables and Services, unless, notwithstanding
anything to the contrary set forth in the BLI Terms and Conditions (including any language regarding
the treatment of additional or different terms set forth therein), a term in such BLI Terms and
Conditions is inconsistent with a term in this Agreement, in which case this Agreement shall
control, including as follows:

4.1.1 this Agreement, and not the BLI Terms and Conditions, shall solely set forth the fields in
which Ginkgo has and does not have the ability to use the Beacon Optofluidic Machines (including
related Hardware and Software), Consumables and Services for certain purposes (e.g., the Excluded
Field);

4.1.2 BLI's liability with respect to any Failure to Supply, penalties for late delivery and
obligations with respect to short supply shall be as set forth in this Agreement, including Section
5.4.3 (Failure to Supply) of this Agreement;

4.1.3 any right of BLI to use Ginkgo's data, including Collaboration Data, is solely set forth in
this Agreement, including Section 8.5 (Use of Collaboration Data) and the BLI Terms and Conditions
shall give BLI no right to use any data of Ginkgo or its Affiliates, including Collaboration Data;

4.1.4 each Party's indemnification obligations and matters relating to the extent of its liability
(e.g. consequential damages waiver) shall solely be determined under the terms of this Agreement
(including Section 11.6 (No Consequential Damages) and Section 12 (Indemnification; Insurance));

4.1.5 any disputes between the Parties related to Beacon Optofluidic Machines (including related
Hardware and Software), Consumables, Services or the activities under this Agreement (including the
performance of the Workflow Development Plans) shall be governed by Section 14.5 (Governing Law;
Dispute Resolution; Equitable Remedies) of this Agreement, including disputes as to whether (a)
[***], (b) [***] or (c) (i) [***], (ii) [***] or (iii) [***], and, with respect to each of (a), (b)
and (c), which Ginkgo shall be entitled to dispute in writing in good faith irrespective of whether
BLI is given sole or final decision-making authority with respect thereto under the applicable BLI
Terms and Conditions;

4.1.6 all payment provisions between the Parties related to the subject matter hereunder shall
solely be under this Agreement and not any of the BLI Terms and Conditions; Page 25 of 85
<!-- page 26 -->
4.1.7 each of the BLI Terms and Conditions shall be freely assignable solely to the applicable
assignee in connection with any assignment permitted under the terms of Section 14.4 (Assignment) of
this Agreement;

4.1.8 no activities by BLI under this Agreement may be terminated or suspended under any of the BLI
Terms and Conditions if such termination or suspension is not permitted under the terms of this
Agreement;

4.1.9 Ginkgo may elect, at any time in its sole discretion, to terminate the Software License
Agreement that comprises part of the BLI Terms and Conditions and, upon such termination, Ginkgo's
right to use such underlying Software shall terminate; and

4.1.10 the BLI Terms and Conditions that apply with respect to any Beacon Optofluidic Machines
(including related Hardware and Software), Consumables or Services for which Ginkgo has placed a
Purchase Order pursuant to this Agreement shall not terminate absent mutual written consent of the
Parties, unless this Agreement has been terminated early (e.g. prior to its Expiration) in which
case such BLI Terms and Conditions shall survive only for so long and to the extent as Ginkgo
continues to have the right to use Beacon Optofluidic Machines or Consumables or receive Services
pursuant to Section 13.3 (Effects of Termination). 5. FORECASTS; ORDERS; SERVICE STANDARDS AND
RELATED OBLIGATIONS

5.1 Forecasts of Production Purchases. Within [***] ([***]) days following the Effective Date and on
or before the first Business Day of each [***] thereafter, Ginkgo shall furnish BLI with a rolling
forecast of the quantities of Beacon Optofluidic Machines (including related Hardware and Software)
and Consumables (on a Consumable-by-Consumable basis) that Ginkgo expects to require from BLI under
this Agreement during the ensuing [***] ([***]) month period on a [***] basis (each such forecast, a
"Rolling Forecast"). Subject to the limitations set forth in this Agreement, Ginkgo may, in its sole
discretion, update its estimated requirements of Beacon Optofluidic Machines (including related
Hardware and Software) and Consumables in the next Rolling Forecast delivered; provided that (a) the
[***] of each Rolling Forecast shall be binding upon the Parties with respect to Beacon Optofluidic
Machines and with respect to Consumables, Ginkgo's Purchase Orders for Consumables during the [***]
may fluctuate by +/- [***] percent ([***]%) of the amount of Consumables set forth in the Rolling
Forecast for the [***]; (b) the [***] of each Rolling Forecast shall include binding amounts
forecasted for Beacon Optofluidic Machines and Consumables within (i) [***] percent ([***]%) of the
number of units of Beacon Optofluidic Machines or (ii) [***] percent ([***]%) of the number of units
of any Consumable; and (c) the [***] of each Rolling Forecast shall be non-binding, good faith
estimates of Ginkgo's demand for Beacon Optofluidic Machines and Consumables. The foregoing, along
with any other relevant provisions in this Agreement, shall be the sole forecasting mechanics for
Ginkgo's requirements of Beacon Optofluidic Machines (including related Hardware and Software) or
Consumables expressly notwithstanding anything to the contrary in the BLI Terms and Conditions with
respect to forecasting. Page 26 of 85
<!-- page 27 -->
5.2 Pricing. Notwithstanding anything to the contrary in the BLI Terms and Conditions with respect
to pricing for Beacon Optofluidic Machines (including related Hardware and Software), Consumables or
Services, the following shall apply:

5.2.1 General. The pricing as of the Effective Date for Beacon Optofluidic Machines, Consumables and
certain services (including Services) are set forth in Schedule 5.2.1 (Pricing Schedule). Such
pricing shall be adjusted pursuant to this Section 5.2 (Pricing). For any Consumable or service not
listed in Schedule 5.2.1 (Pricing Schedule), BLI shall provide the price for such to Ginkgo upon
Ginkgo's request during the Term, such price to be consistent with this Section 5.2 (Pricing). BLI
represents and warrants that the pricing set forth in Schedule 5.2.1 (Pricing Schedule) are BLI's
List Prices for the described Beacon Optofluidic Machines, Consumables and services (including
Services) as of the Effective Date. BLI shall discount List Prices for Ginkgo by [***] percent
([***]%) or such higher amount as agreed by the Parties, and subject to pricing adjustments as set
forth in Section 5.2.2 (Adjustments). For clarity, with respect to Consumables to be purchased under
a Workflow Development Plan, Ginkgo will be responsible for costs for such Consumables as set forth
in the Budget for such Workflow Development Plan.

5.2.2 Adjustments. Notwithstanding anything else to the contrary in this Agreement, and [***], with
respect to the prices charged by BLI to Ginkgo under Section 5.3.2 (Purchase Orders - Acceptance and
Rejection):

(a) With respect to any [***], (i) there will be no increases from the per unit pricing set forth in
Schedule 5.2.1 (Pricing Schedule) for at least the first [***] and (ii) the per unit pricing charged
by BLI to Ginkgo at any time shall be no greater than the lowest of the (A) lowest price per unit
charged by BLI or its Affiliates to any similarly situated Third Party customer (i.e. taking into
account [***]) for such unit at any time in the [***] ([***]) months prior to the delivery of the
applicable Purchase Order by Ginkgo or (B) the then- current List Price; provided, however, that in
no event shall BLI be required to charge a price less than the cost of goods sold for such unit, as
determined in accordance with United States generally accepted accounting principles, consistently
applied.

(b) With respect to any [***], (i) there will be no increases from the per unit pricing set forth in
Schedule 5.2.1 (Pricing Schedule) for at least the first [***], (ii) subject to subclause (iii), the
per unit pricing charged by BLI to Ginkgo shall be no greater than [***] percent ([***]%) of the
lowest List Price for such unit at any time between the delivery of the applicable Purchase Order by
Ginkgo and delivery of such OptoSelect Chip or Consumable and (iii) the per unit pricing charged by
BLI to Ginkgo for such unit that is [***] shall be no greater than [***] percent ([***]%) of the
lowest List Price for such unit. Page 27 of 85
<!-- page 28 -->
(c) With respect to any [***], there will be no increases from the per unit [***] set forth in
Schedule 5.2.1 (Pricing Schedule) for at least the [***] and after such [***], BLI may adjust
pricing for [***] for a Contract Year within the first [***] ([***]) days of such Contract Year by
written notice to Ginkgo; provided that such adjustment [***] for such [***] and in no event will
the [***] charged to Ginkgo for any [***] under this Agreement be higher than the then-current List
Price for the applicable [***].

(d) With respect to any [***], there will be no increases from the rates set forth in Schedule 5.2.1
(Pricing Schedule), except that, on an annual basis, upon written notice to Ginkgo, BLI may increase
the rates set forth in Schedule 5.2.1 (Pricing Schedule) by a percentage [***], not to exceed [***]
percent ([***]%) per calendar year.

(e) With respect to any other Beacon Optofluidic Machines, Consumables and services (including
Services) not listed on Schedule 5.2.1 (Pricing Schedule), the per unit pricing charged by BLI to
Ginkgo shall be no greater than the then-current List Price, [***].

5.3 Purchase Orders; Delivery and Payment.

5.3.1 Issuance. Ginkgo shall submit orders for Beacon Optofluidic Machines (including related
Hardware and Software), Consumables (on a Consumable-by-Consumable basis) and Services pursuant to
written purchase orders (each, a "Purchase Order") issued to BLI in a form consistent with this
Agreement. Purchase Orders shall be provided by Ginkgo, shall specify (a) the quantity of Beacon
Optofluidic Machines (including related Hardware and Software), Consumables (on a
Consumable-by-Consumable basis) or Services ordered and (b) the requested delivery date or service
date and location. The requested delivery dates or service dates set forth in a Purchase Order shall
be no earlier than the Lead Time for such delivery or service. BLI shall not be obligated to supply
in any [***] (i) a quantity of the [***] in excess of the amount designated in such [***] in the
binding portion of the Rolling Forecast or (ii) a quantity of [***] that is greater than [***]
percent ([***]%) of the amount designated for such item or service in such [***] in the binding
portion of the Rolling Forecast (such amount, the "Maximum Amount"); provided that notwithstanding
the provisions set forth in this Section 5.3.1 (Issuance) or Section 5.3.2 (Acceptance and
Rejection) to the contrary, BLI shall use [***] to accept and fulfill Purchase Orders for quantities
of [***] in excess of the Maximum Amount in any [***]. The foregoing shall apply and, along with any
applicable provisions of the Agreement, be the exclusive terms and conditions for Ginkgo's Purchase
Orders under this Agreement, notwithstanding anything to the contrary in the BLI Terms and
Conditions with respect to Ginkgo's orders for or ability to order (and have orders fulfilled for)
[***].

5.3.2 Acceptance and Rejection. BLI shall, by written notice to Ginkgo, accept or, subject to the
terms of this Agreement, reject, each Purchase Order (a) with respect to orders for [***], within
[***] ([***]) days of receipt and (b) with respect to Page 28 of 85
<!-- page 29 -->
orders for [***], within [***] ([***]) days of receipt, with respect to each, by written notice to
Ginkgo. Any failure of BLI to accept or reject a Purchase Order within such [***] day period shall
be deemed an acceptance by BLI of such Purchase Order. Any express acceptance of a Purchase Order by
BLI shall confirm the quantity of Beacon Optofluidic Machines (including related Hardware and
Software), Consumables (on a Consumable-by-Consumable basis) and Services requested to be supplied
or performed, the prices, pursuant to Section 5.2 (Pricing), associated with such Beacon Optofluidic
Machines (including related Hardware and Software), Consumables (on a Consumable-by-Consumable
basis) and Services and that delivery or performance of such Optofluidic Machines (including related
Hardware and Software), Consumables and Services shall occur [***]; provided that (i) BLI shall not
have the right to reject, and shall be deemed to have accepted, any Purchase Order meeting the
requirements of this Section 5.3 (Purchase Orders; Delivery and Payment) and (ii) if any Purchase
Order contains quantities in excess of the Maximum Amount for such month and otherwise meets the
requirements of this Section 5.3 (Purchase Orders; Delivery and Payment), then such Purchase Order
shall be deemed accepted except with respect to such excess quantities and, subject to Section 5.3.1
(Issuance), BLI shall confirm to Ginkgo within [***] ([***]) days of receipt of such Purchase Order
if BLI can supply such excess and if so, such Purchase Order shall be deemed accepted with respect
to such excess quantities as well. The foregoing shall apply notwithstanding anything to the
contrary in the BLI Terms and Conditions with respect to BLI's ability to accept or reject Ginkgo's
orders for Beacon Optofluidic Machines (including related Hardware and Software), Consumables or
Services.

5.3.3 Delivery and Payment. Notwithstanding anything to the contrary in the BLI Terms and Conditions
with respect to the delivery of Beacon Optofluidic Machines (including related Hardware and
Software) or Consumables, the performance of Services and rights and responsibilities arising in
connection with such delivery or performance, the following shall apply:

(a) Machines and Consumables. With respect to Beacon Optofluidic Machines and Consumables for which
Ginkgo has placed a Purchase Order under this Agreement:

(i) such items shall be shipped by BLI (A) [***] or (B) [***], with respect to (A)-(B), to the
delivery point set forth on the Purchase Order; [***];

(ii) a BLI employee will install the Beacon Optofluidic Machines at such delivery point and, within
[***] ([***]) Business Days of installation, will deliver to Ginkgo a completed BLI field service
report confirming installation and qualification of the relevant Beacon Optofluidic Machines in
accordance with Schedule 5.3.3 (Qualification Standards);

(iii) title and risk of loss to (A) [***] or (B) [***]; Page 29 of 85
<!-- page 30 -->
(iv) BLI shall invoice Ginkgo for any Beacon Optofluidic Machine or Consumable at a price calculated
in accordance with Section 5.2 (Pricing) [***];

(v) Ginkgo shall be deemed to have accepted delivery of any Beacon Optofluidic Platform upon [***]
unless Ginkgo delivers, within [***] ([***]) Business Days a written statement detailing the reasons
why the item delivered is not a Conforming Product and, if BLI disputes Ginkgo's allegation of
non-conformance, the matter shall be resolved pursuant to Section 14.5.2 (Dispute Resolution); and

(vi) Ginkgo shall pay BLI for all delivered quantities of Conforming Product within [***] ([***])
days from Ginkgo's [***] under this Agreement[***].

(b) Services. With respect to Services for which Ginkgo has placed a Purchase Order under this
Agreement:

(i) such Services shall be provided at the time and location set forth on an accepted Purchase
Order, unless otherwise mutually agreed by the Parties in writing;

(ii) BLI shall invoice Ginkgo for any Services at a price calculated in accordance with Section 5.2
(Pricing) [***] except [***], which shall be paid [***] and the Terms and Conditions except to the
extent such conflicts with the terms of this Agreement, in which case this Agreement shall supersede
with respect to the conflicting terms; and

(iii) Ginkgo shall pay BLI for all performed Services that meet the applicable Service Standards
within [***] ([***]) days from receipt of invoice[***].

(c) Payments. All Production Purchase amounts paid by Ginkgo to BLI for Beacon Optofluidic Machines,
for Consumables and for Services are non-creditable and non-refundable except as set forth in
expressly set forth in this Agreement (including Section 7.8 (Audits)) and the BLI Terms and
Conditions.

5.4 Capacity; Failure to Supply.

5.4.1 Personnel. Notwithstanding anything to the contrary in the BLI Terms and Conditions for
Services:

(a) Generally. With respect to any [***] in the Term, to [***] continuity of supply with respect to
services (including Services) rendered under this Agreement (including Workflow Development Page 30
of 85
<!-- page 31 -->
Plans) to Ginkgo, BLI shall [***] employs a sufficient number of personnel so that it [***] satisfy,
with respect to the then-current [***], Ginkgo's requirements for Services during such [***], as
specified in the then-applicable Rolling Forecast. BLI shall (a) use qualified personnel in
connection with performing Services for Ginkgo and perform such Services in a competent and
workmanlike manner consistent with prevailing industry standards and in material conformance with
Applicable Laws, the terms of this Agreement (which shall include the terms of any Workflow
Development Plans) and (b) obtain and maintain all material licenses, permits or approvals required
by Applicable Laws, the terms of this Agreement (which shall include the terms of any approved
Workflow Development Plans) in connection with performing Services for Ginkgo.

(b) Dedicated FTEs; Key Persons. In addition to its obligations set forth in Section 5.4.1(a)
(Personnel - Generally), during the period beginning [***] ([***]) Business Days after the Effective
Date and ending on the [***] ([***]) anniversary of the Effective Date, BLI shall [***] provide
Ginkgo with [***] ([***]) FTEs to work on-site at Ginkgo to aid in [***]. Following the [***]
([***]) anniversary of the Effective Date, unless otherwise agreed by the Parties, BLI shall provide
Ginkgo with [***] to work on-site at Ginkgo to aid in [***]. [***] shall designate up to [***]
([***]) BLI employees or personnel as key persons (individually, a "Key Person" and collectively,
"Key Persons"). [***] to the percentage of any such Key Person's time that shall be dedicated to
activities performed under this Agreement. No Key Person shall be reassigned, nor shall the time
dedicated to activities under this Agreement be reduced, without [***], but if such Key Person (i)
is no longer employed by BLI, (ii) [***] or (iii) [***], with respect to (i)-(iii), then the Parties
shall work together to mutually identify in writing a new employee as a replacement for such Key
Person and, upon such mutual identification, such employee shall be deemed a Key Person for all
purposes of this Agreement. For clarity, [***] shall be [***] if [***], that [***] and [***] or
[***]. In the event of a termination of employment at BLI of any Key Person, BLI shall notify Ginkgo
of such circumstance as promptly as practicable. Ginkgo shall have the right, but not the
obligation, at any time, to request that BLI replace such Key Person with another BLI employee
reasonably acceptable to Ginkgo. In such event, BLI shall replace such person [***]. Ginkgo will
provide each BLI FTE that is on-site at Ginkgo with (I) access to Ginkgo's facility to the extent
required to perform each FTE's obligations as set forth in each approved Workflow Development Plan
and (II) [***].

(c) Conduct on Site. BLI acknowledges and agrees that BLI FTEs (including Key Persons) are not
employees or agents of Ginkgo, that Ginkgo has no responsibility to provide worker's compensation or
other Page 31 of 85
<!-- page 32 -->
liability coverage, insurance, benefits or, other than as expressly provided in this Agreement,
compensation for BLI FTEs. BLI further acknowledges and agrees that BLI FTEs are acting solely as
representatives of BLI during any work performed at Ginkgo's facilities. BLI shall (a) comply, and
shall cause each BLI FTE to comply, with all Applicable Laws; (b) abide, and shall cause each
on-site BLI FTE to abide, by [***] guidelines and procedures related to Ginkgo's facilities and use
of its foundries that are [***] (e.g., [***]) made available to BLI or BLI's FTEs; and (c) cause
on-site BLI FTEs to execute a confidentiality agreement with Ginkgo in the form attached hereto as
Exhibit C. Each BLI FTE will be required to complete training offered by Ginkgo regarding the
guidelines and procedures referred to in Section 5.4.1(b) (Dedicated FTEs; Key Persons). Without
limitation of the foregoing, each BLI FTE shall be responsible for performing work in such a manner
as to [***].

5.4.2 Safety Stock Inventory. At any given time during the Term, to ensure continuity of supply with
respect to [***], BLI shall maintain an inventory of [***] sufficient to fulfill orders by Ginkgo
for [***] for the next [***], such amount of [***] to be based on the then-applicable Rolling
Forecast.

5.4.3 Failure to Supply.

(a) Remedial Efforts. If, for any reason, including [***], BLI [***] fails to provide Conforming
Product or Service that conforms with this Agreement and the Service Level Standards for such
Service, in each case in accordance with one or more accepted Purchase Orders for a period of [***]
([***]) consecutive days or more (each, a "Failure to Supply"), BLI shall notify Ginkgo promptly,
including details of the reasons for the Failure to Supply and BLI's estimate of when the Failure to
Supply shall be corrected. BLI shall [***] minimize any shortage or delay in delivery of Beacon
Optofluidic Machines (including related Hardware and Software), Consumables or Services to Ginkgo as
a result of a Failure to Supply. Within [***] ([***]) days of written notification by BLI to Ginkgo
under this Section 5.4.3(a) (Remedial Efforts) of a Failure to Supply, the Parties shall hold a JRC
meeting at which BLI's representatives will explain [***] the cause of such Failure to Supply and
present BLI's remedial plan to [***] Beacon Optofluidic Machines (including related Hardware and
Software), Consumables or Services to be supplied to Ginkgo in accordance with this Agreement and
the accepted Purchase Orders, which plan [***] (the "Remedial Plan"). BLI shall consider [***] in
good faith any reasonable changes proposed by Ginkgo to the Remedial Plan. If the JRC approves the
Remedial Plan, BLI will execute such Remedial Plan [***].

(b) Fees for Late Delivery. [***], the following discounts on the amounts owed by Ginkgo to BLI
under an accepted Purchase Order Page 32 of 85
<!-- page 33 -->
shall be in effect for any [***] not delivered in accordance with this Agreement until after the
applicable delivery date set forth in such Purchase Order: (a) for deliveries made more than [***]
([***]) days and less than [***] ([***]) days after such delivery date, a [***] percent ([***]%)
discount; and (b) for deliveries made after [***] ([***]) days after such delivery date, a [***]
percent ([***]%) discount, in each case of clauses (a) through (b), from the price for the
Consumable delivered late; provided that, any discount shall only apply if the Purchase Order at
issue was for a quantity of [***] at or below the binding forecasted quantity ([***]) provided
pursuant to Section 5.1 (Forecasts of Production Purchases). Any discount in effect under this
Section 5.4.3(b) (Fees for Late Delivery) shall be incorporated under any invoice presented by BLI
to Ginkgo; provided that [***]. For purposes of counting towards Ginkgo's Production Purchases and
Minimum Cumulative Purchase Commitments under this Agreement, Ginkgo shall be deemed to have paid
any invoice as if no discount for delayed delivery was in effect.

(c) Short Supply. Without limiting anything to the contrary in this Agreement, in the event that any
Beacon Optofluidic Machines (including related Hardware and Software), Consumables or the Services
are in short supply, i.e., [***], BLI shall notify Ginkgo in writing of such circumstances as soon
as possible, including the underlying reasons for such shortage, the date such inability is expected
to end and the amount of Beacon Optofluidic Machines (including related Hardware and Software),
Consumables or Services to be allocated to Ginkgo. BLI shall allocate Beacon Optofluidic Machines
(including related Hardware and Software), Consumables and Services in short supply to Ginkgo [***],
with such [***] allocation applicable only up to the number of units of such item set forth in the
binding portions of the then-current Rolling Forecast.

(d) Tolling. Without limiting Ginkgo's rights under this Agreement or under Applicable Law, in the
event of a Failure to Supply, [***] obligations of Ginkgo that are [***] by such Failure to Supply,
including [***], shall be excused by an amount [***] to the Failure to Supply, which excused amount,
in ensuring that such amount is [***] to the Failure to Supply, will include amounts [***] to such
Failure to Supply. In addition, Ginkgo will submit to BLI a good faith proposal with respect to
[***], taking into consideration the [***] that are attributable to such Failure to Supply. BLI
shall promptly review such proposal and send written confirmation to Ginkgo of its [***] or,
alternatively, inform Ginkgo in writing of and discuss with Ginkgo [***]. If [***], BLI will [***].

(e) Material Failure to Supply. If for reasons [***], over the course of any consecutive [***]
period during the Term, BLI fails to provide Page 33 of 85
<!-- page 34 -->
Ginkgo with at least [***] percent ([***]%) of (a) a given [***] or (b) the cumulative total of
[***], with respect to each of clauses (a) and (b), in accordance with accepted Purchase Orders and
this Agreement (including, with respect to [***]) over such [***] period, then, such Failure to
Supply shall be deemed a material breach of this Agreement and Ginkgo shall have the right to
terminate this Agreement pursuant to Section 13.2.1 (Material Breach), subject to BLI's right to
cure such material breach. 6. RESTRICTIONS

6.1 Headstart Period.

6.1.1 BLI Standstill. Unless otherwise expressly agreed to in writing by the Parties, on a Headstart
Invention-by-Headstart Invention basis, beginning on the date that a Workflow Development Plan is
commenced and ending on the earlier of (a) the [***] anniversary of the date on which [***] under
this Agreement or (b) subject to the last sentence of this Section 6.1.1 (BLI Standstill), if [***],
then the [***] anniversary of the date on which [***] under this Agreement (for each such Headstart
Invention, with respect to (a)-(b), the "Headstart Period"): (i) as between the Parties, Ginkgo will
have the sole right to use, practice and exploit such Headstart Invention, and (ii) BLI shall not,
and shall cause its Affiliates to not, directly or indirectly, itself or with or through a Third
Party, use, practice or otherwise exploit such Headstart Invention in any way or grant any right,
title or license to any Third Party to use, practice or otherwise exploit such Headstart Invention;
provided that, for clarity, BLI shall retain the right to use, practice and otherwise exploit such
Headstart Invention in accordance with the terms of this Agreement to perform BLI's obligations
under this Agreement. For further clarity, nothing in this Section 6.1.1 (BLI Standstill) is
intended to prevent a Third Party BLI customer or partner from using, practicing or otherwise
exploiting any independently developed improvement, invention, process or workflow even if similar
to a Headstart Invention as long as BLI and its Affiliates are in compliance with this Section 6.1.1
(BLI Standstill) [***]. If a Workflow Development Plan is cancelled under the terms of this
Agreement, then the Headstart Period with respect to Headstart Inventions under such Workflow
Development Plan shall be deemed to have immediately accelerated to conclusion, unless Ginkgo (x)
identifies in writing one or more Headstart Inventions under the Workflow Development Plan within
[***] ([***]) Business Days of cancellation of the Workflow Development Plan and (y) [***], in which
case such Headstart Invention(s) shall be subject to the applicable Headstart Period under this
Section 6.1.1 (BLI Standstill); provided that, Ginkgo's right to identify [***] under clauses (x)
and (y) shall not exist if the cancellation of a Workflow Development Plan is [***].

6.1.2 [***]. Notwithstanding anything to the contrary in Section 6.1.1 (BLI Standstill), on a
Headstart Invention-by-Headstart Invention basis, BLI may provide written notice to Ginkgo [***]
(i.e. [***]), with respect to a Headstart Invention, such notice to specify (a) the applicable
Headstart Invention [***], (b) the [***] and (c) whether BLI would prefer to [***] or, to the extent
[***], [***] (which may, [***]); provided that to the extent the [***], BLI may only submit such a
notice (and [***]) for [***]. Ginkgo Page 34 of 85
<!-- page 35 -->
shall have [***] ([***]) Business Days following delivery of notice to Ginkgo to [***] by written
notice to BLI. If the Parties [***] within [***] ([***]) Business Days of such written notice by
Ginkgo, [***]. Following BLI's delivery of notice to Ginkgo [***], BLI shall [***] (i) if Ginkgo
does not [***] within the [***] ([***]) Business Day period after notice delivery, within [***]
([***]) Business Days following the expiration of such [***] ([***]) Business Day period and (ii) if
Ginkgo does [***] within the [***] ([***]) Business Day period after notice delivery, within [***]
([***]) Business Days following the [***]. Immediately upon [***] for a Headstart Invention, [***].
For clarity, [***]. For the avoidance of doubt, following the end of the Headstart Period for a
Headstart Invention, Ginkgo shall still have the right to use, practice and exploit such Headstart
Invention under this Agreement.

6.2 Restrictions on the Parties.

6.2.1 Restrictions on BLI. During the Term and for a period of [***] ([***]) months following the
Term of this Agreement, other than pursuant to Sections 13.3.2 (Effects of Termination Based Upon
Ginkgo's Buy-Down Election) or 13.3.3 (Effects of Termination Based Upon an Uncured Ginkgo Breach,
Insolvency or Force Majeure Event), BLI shall not, and shall cause its Affiliates not to, directly
or indirectly, itself or with or through a Third Party, develop, configure, customize, license,
sell, provide or otherwise give access to the Beacon Platform or any [***] to, [***] or its
Affiliates for any use; provided that this restriction shall terminate as set forth in Section 13.3
(Effects of Expiration or Termination) or if Ginkgo has not satisfied its Minimum Cumulative
Purchase Commitments (as such may be adjusted under this Agreement) for a full Contract Year,
including [***] as permitted under Section 7.2.2(a) (Minimum Cumulative Purchase Commitments) or
Section 7.2.2(b)(iii) (Development Purchase Commitments); provided that BLI will provide written
notice to Ginkgo within [***] ([***]) days of the end of any Contract Year with respect to which BLI
believes that Ginkgo has not satisfied its Minimum Cumulative Purchase Commitment. Notwithstanding
the foregoing, in the event that a Change in Control of an existing (as of the Effective Date or at
any time during the Term) Third Party BLI customer results in such customer being controlled [***]
following the date such Third Party became a BLI customer, BLI shall promptly notify Ginkgo in
writing of such Change in Control (in no event later than [***] ([***]) days after BLI first learns
of such Change in Control, [***] (in which case such notice will be provided by BLI no later than
[***] ([***]) days after the earlier of [***] or [***]) and, in such written notice, provide Ginkgo
with information regarding [***] and, if BLI does [***], the [***]. Within [***] ([***]) days of
Ginkgo's receipt of such written notice, Ginkgo will have the option, at its sole discretion, (a) if
[***], to [***] and to [***] and, if Ginkgo makes such election, BLI shall promptly [***] and (i)
Ginkgo will [***] (but in no event [***]) and (ii) in the event [***], Ginkgo and BLI will [***] and
(b) if [***], then [***], to (i) [***], (ii) [***] and (iii) [***]. In the event BLI notifies Ginkgo
as aforesaid and Ginkgo fails to make such election within the [***] ([***]) day period, then, in
the case of (A) or (B), BLI will not be deemed to be in breach of this Section 6.2.1 (Restrictions
on BLI) solely on account of a Third Party customer [***]. Nothing in this Section 6.2.1
(Restrictions on BLI) will require or oblige BLI [***], then [***]. In the event [***], [***] in a
manner that (x) [***], (y) [***] or (z) [***]. For clarity, the foregoing sentence shall not [***].
Except as provided in this Section 6.2.1 (Restrictions on BLI) and the scope of rights granted to
Page 35 of 85
<!-- page 36 -->
Ginkgo under this Agreement (including under Section 6.1 (Headstart Period) and Section 9.1
(Licenses to Ginkgo)), nothing in this Agreement shall otherwise limit, prohibit or preclude BLI
from developing, configuring, customizing, licensing, selling or providing the Beacon Platform or
Collaboration Workflows for itself or to a Third Party for any uses or otherwise entering into a
business or advisory arrangement with any Third Party. As used in this Section 6.2.1 (Restrictions
on BLI), "control" has the meaning set forth in Section 1.2 ("Affiliate" definition). For clarity,
[***].

6.2.2 No Further Restrictions by Ginkgo. During the Term, Ginkgo shall not [***] prohibit (i.e. by
[***]), as part of any [***] arrangement with a Third Party, a Third Party from purchasing a Beacon
Platform or other BLI products or services, or otherwise using or utilizing such Beacon Platforms
for [***], including [***]. For clarity, such obligation shall not prohibit or limit Ginkgo from
entering into generally exclusive relationships with Third Parties (e.g., [***]). 7. ECONOMICS

7.1 Upfront Payment. No later than [***] ([***]) days following the Effective Date, Ginkgo will pay
to BLI a non-refundable upfront amount equal to Ten Million Dollars ($10,000,000) (the "Upfront
Payment"). Such amount will be fully creditable against all Development Purchases and Production
Purchases owed by Ginkgo to BLI [***] and will be fully creditable against the Full Purchase Target
and, [***], the Minimum Purchase Commitment, Development Purchase Commitment and Production Purchase
Target [***]. [***].

7.2 Purchase Commitments.

7.2.1 Generally. Subject to the terms of this Agreement, during the Term, the Parties' target is for
Ginkgo to make a total of One Hundred Fifty Million Dollars ($150,000,000) in Development Purchases
and Production Purchases from BLI (as amended from time to time under this Agreement and as more
fully set forth in this Section 7.2 (Purchase Commitments), the "Full Purchase Target"), which Full
Purchase Target is divided into Contract Year purchase commitment targets with respect to
Development Purchase Commitment and Production Purchase Targets, as more fully set forth in Section
7.2.2 (Contract Year Purchase Targets and Commitments).

7.2.2 Contract Year Purchase Targets and Commitments. Subject to the terms of this Agreement
(including the remainder of this Section 7.2.2 (Contract Year Purchase Targets and Commitments)),
for each Contract Year, Ginkgo shall [***] make Development Purchases and Production Purchases from
BLI in the amounts set forth in the Page 36 of 85
<!-- page 37 -->
"Development Purchase Commitment" and "Production Purchase Target" columns respectively in Table
7.2.2 with respect to such Contract Year:

Table 7.2.2

Development Purchase Commitment

Production Purchase Target

Total Targeted Purchase

Minimum Cumulative Purchase Commitment Contract Year 1 $ [***] $ [***] $ [***] $ [***] Contract Year
2 $ [***] $ [***] $ [***] $ [***] Contract Year 3 $ [***] $ [***] $ [***] $ [***] Contract Year 4 $
[***] $ [***] $ [***] $ [***] Contract Year 5 $ [***] $ [***] $ [***] $ [***] Contract Year 6 $
[***] $ [***] $ [***] $ [***] Contract Year 7 [***] $ [***] $ [***] $ 109,000,000 Total $ [***] $
[***] $150,000,000 N/A

(a) Minimum Cumulative Purchase Commitments. With respect to each Contract Year, by no later than
[***], Ginkgo shall have incurred (including all credits and offsets permitted under this Agreement)
at least, in the aggregate since the beginning of the Term, the Minimum Cumulative Purchase
Commitment amount for such Contract Year. The Minimum Cumulative Purchase Commitments for each of
Contract Years [***] are binding commitments. Any amounts paid by Ginkgo to BLI in excess of the
Minimum Cumulative Purchase Commitment amount for a given Contract Year in Contract Years [***],
regardless of whether such excess constitutes a Development Purchase or Production Purchase, will be
creditable towards the Minimum Cumulative Purchase Commitment in subsequent Contract Year(s) until
such excess amount has been fully credited. Ginkgo covenants to pay the Minimum Cumulative Purchase
Commitments for each Contract Year by the [***] Business Day after the end of the [***]. If BLI has
Substantially Completed at least [***] ([***]) [***] Workflows within the first [***] ([***])
Contract Years, then the Minimum Cumulative Purchase Commitment as of the Contract Year (which may
include a portion of a full Contract Year) that is the last Contract Year during the Term pursuant
to the terms of this Agreement shall change from $109 million (as currently reflected in Table
7.2.2) to $150 million.

(b) Development Purchase Commitments.

(i) Subject to Section 7.2.2(a) (Minimum Cumulative Purchase Commitments), unless the Parties
otherwise mutually agree in writing, the Development Purchase Commitment for the [***] Contract
Years shall constitute a binding obligation on Ginkgo, and, subject to Ginkgo exercising its
Buy-Down Option pursuant to Section 7.3 (Buy-Down Election), the Development Purchase Commitment for
the [***] Contract Years shall also constitute binding obligations on Ginkgo. No less than [***]
percent ([***]%) of the Development Purchases made in the [***] Contract Years will be used by the
Parties to develop Workflows for [***]. Page 37 of 85
<!-- page 38 -->
(ii) At any time during a Contract Year, upon written notice to the JRC, Ginkgo may accelerate its
Development Purchases in such Contract Year to include Development Purchases anticipated to be made
in upcoming Contract Year(s). Such additional Development Purchases in excess of the Development
Purchase Commitment for such Contract Year will be creditable towards Ginkgo's Development Purchases
in subsequent Contract Year(s) until such excess amount has been exhausted and will count towards
the Minimum Cumulative Purchase Commitment for the Contract Year in which it is paid, subject to
allocation to subsequent Contract Year(s) as set forth in Section 7.2.2(a) (Minimum Cumulative
Purchase Commitments).

(iii) Notwithstanding anything to the contrary in this Agreement, in the event that Ginkgo's
Development Purchases in a given Contract Year after [***] are less than the Development Purchase
Commitment for such Contract Year, respectively, Ginkgo shall be able to apply the Development
Purchases made in the first [***] of the next Contract Year to satisfy the previous Contract Year's
Development Purchase Commitment; provided that (i) Ginkgo may only be able to satisfy [***] percent
([***]%) of the relevant Development Purchase Commitment for the previous Contract Year pursuant to
this Section 7.2.2(b)(iii) (Development Purchase Commitments) and (ii) any amount of Development
Purchases credited towards satisfying the previous Contract Year's Development Purchase Commitment
shall not count towards satisfying such targets for the then-current Contract Year.

(iv) Notwithstanding anything to the contrary in this Agreement, in the event that a Workflow
Development Plan is terminated prior to completion by the JRC, including (A) [***], (B) [***], (C)
[***] or (D) [***], then, subject to Section 3.5.1 (Decision-Making), the JRC shall, in good faith,
discuss and approve [***]; provided, however, that such [***] (Term).

(c) Production Purchase Commitments.

(i) Subject to this Section 6.2.2(c) (Production Purchase Commitments), unless the Parties otherwise
mutually agree in writing, the Production Purchase Target for the [***] shall constitute a binding
obligation on Ginkgo and, in partial satisfaction of its Production Purchase commitment for the Page
38 of 85
<!-- page 39 -->
[***], Ginkgo shall purchase [***] ([***]) [***] within [***] ([***]) days of the Effective Date,
the cost of which, for clarity, shall be offset by the upfront payment paid by Ginkgo pursuant to
Section 7.1 (Upfront Payment). Subject to Ginkgo's obligation to satisfy the Minimum Cumulative
Purchase Commitment for a Contract Year, with respect to the second [***] Contract Years), Ginkgo's
Production Purchase Targets for the [***] Contract Years as set forth in Table 7.2.2 are [***], and
the Parties expressly acknowledge and agree that [***].

(ii) At any time during a Contract Year, upon written notice to the JRC, Ginkgo may accelerate its
Production Purchases in such Contract Year to include Production Purchases anticipated to be made in
upcoming Contract Year(s). Such additional Production Purchases in excess of the Production Purchase
Target for such Contract Year will be creditable towards Ginkgo's Production Purchases in subsequent
Contract Year(s) until such excess amount has been exhausted and will count towards the Minimum
Cumulative Purchase Commitment.

(d) Effects of Tolling. Notwithstanding anything to the contrary in this Agreement, Ginkgo's
obligations to satisfy Development Purchase Commitments and Production Purchase Commitments at all
times during the Term (including any Intended End of Term) are subject to Section 5.4.3(d) (Tolling)
and this Section 7.2.2(d) (Effects of Tolling). In the event that, at any time during the Term,
there is a Failure to Supply, then the duration of this Agreement will automatically be extended for
additional calendar months (rounded to the nearest whole calendar month) equal to [***] (the seventh
(7t h) anniversary of the Effective Date plus such additional calendar months, the "Intended End of
Term").

7.3 Buy-Down Election. During the Term following the end of the second (2nd) Contract Year, Ginkgo
may elect, upon written notice to BLI, to buy- down its remaining financial obligations under the
Full Purchase Target (the "Buy-Down Election") by making a one-time payment to BLI in the amount of
the Buy-Down Amount. In the event Ginkgo notifies BLI of its Buy-Down Election as set forth in this
Section 7.3 (Buy-Down Election), then, upon Ginkgo's payment of the Buy-Down Amount to BLI within
[***] ([***]) days of Ginkgo's Buy-Down Election, this Agreement shall automatically terminate, with
the applicable effects of termination set forth in Section 13.3.2 (Effects of Termination Based Upon
Ginkgo's Buy-Down Election).

7.4 Additional Payments.

7.4.1 License Fees. During the Term, and in consideration for the rights granted herein, Ginkgo
shall pay field of use license fees ("FOU License Fees") as follows: (a) with respect to any
calendar year, no FOU License Fees will be due until [***] and (b) [***] ($[***]) per calendar year
per Beacon Optofluidic Machine [***] up to a Page 39 of 85
<!-- page 40 -->
maximum of [***] ($[***]) per calendar year per Beacon Optofluidic Machine; provided that, in no
event will the FOU License Fees paid by Ginkgo for use of a Beacon Optofluidic Machine [***]. FOU
License Fees shall be applied to Ginkgo's use of all Beacon Optofluidic Machines, [***].
Notwithstanding anything to the contrary in this Agreement and without limiting any of Ginkgo's
rights and remedies under Applicable Law and this Agreement, [***],

7.4.2 Milestone Payments. In the event that Ginkgo uses any of the BLI Proprietary Workflows
identified in Exhibit D to conduct Commercial Services for a Third Party customer and such
Commercial Services [***] result in the discovery of an Antibody to be used as the active ingredient
in a therapeutic product for which a Third Party [***] (each such Antibody subject to this Section
7.4.2 (Milestone Payments), a "Discovered Antibody"), then, on a Discovered Antibody-by-Discovered
Antibody basis, in the event such Third Party (a) achieves any of the milestone events noted below
in Table 7.4.2 (each, a "Milestone Event") with respect to a Discovered Antibody and (b) makes a
payment to Ginkgo in connection with such Milestone Event, then Ginkgo will pay BLI [***] percent
([***]%) of such payment received by Ginkgo from such Third Party up to the amount of the
corresponding "Maximum Milestone Payment" for such milestone event set forth below in Table 7.4.2
(each, a "Milestone Payment". Notwithstanding anything to the contrary in this Agreement, in no
event shall a Discovered Antibody include (x) an Antibody [***] (e.g. [***]) through the conduct of
Commercial Services by Ginkgo or (y) an Antibody [***]. Table 7.4.2

Milestone Event

Maximum Milestone Payment [***] $ [***] [***] $ [***] [***] $ [***] [***] $ [***]

Each Milestone Payment shall be payable only once for each and every Discovered Antibody. If any
Milestone Event is achieved for any Discovered Antibody before any of the preceding Milestone Events
are achieved for such Discovered Antibody, then all the Milestone Payments for such unachieved
preceding Milestone Events will be due and payable with the Milestone Payment for the Milestone
Event that was achieved. For example, [***].

7.5 Manner of Payments. Each payment under this Agreement to a Party will be made in Dollars and by
electronic transfer in immediately available funds via either a bank wire transfer, an ACH
(automated clearing house) mechanism, or any other means of electronic funds transfer, at such
receiving Party's election, to such bank account as the receiving Party will designate in writing to
the other Party at least [***] ([***]) Business Days before the payment is due.

7.6 Taxes. It is understood and agreed between the Parties that any payments made by a Party to the
other Party under this Agreement are exclusive of any sales tax, value added tax (if any) or similar
tax ("VAT") upon such payments. Where VAT is properly added to a payment made under this Agreement,
the Party making the payment will pay the amount of VAT only on Page 40 of 85
<!-- page 41 -->
receipt of a valid tax invoice issued in accordance with the laws and regulations of the country in
which the VAT is chargeable. If a Party is required to deduct or withhold from any payment due
hereunder any taxes in the nature of a tax upon or measured by income, then the Parties shall work
together to ensure, subject to this Section 7.6 (Taxes), that the withholding Party is able to
comply with its obligations under Applicable Law and that the non- withholding Party still receives
the net amount due to it following payment of such tax by the withholding Party. [***]. The Parties
will reasonably cooperate to provide sufficient documentation to receive any credits available under
Applicable Law. Notwithstanding the foregoing, to the extent that, due to (a) [***], (b) [***], (c)
[***], (d) [***] or (e) [***], with respect to each, VAT or other taxes are imposed on payments made
by Ginkgo or BLI, as applicable, to the other Party that were not otherwise applicable ("Incremental
Withholding Taxes"), the Party that took such action resulting in Incremental Withholding Taxes
(together with any subsequent successor or assign, "Responsible Tax Party") shall be solely
responsible for and shall solely bear the amount of such Incremental Withholding Taxes. If the other
Party receives a refund or tax credit in connection with the Incremental Withholding Taxes, then
such other Party shall promptly pay the Responsible Tax Party an amount equal to the amount of such
refund or tax credit.

7.7 Financial and Other Records. Each Party shall, and shall cause its Affiliates to, keep complete
and accurate books and records pertaining to its activities conducted and costs incurred under this
Agreement (including each approved Workflow Development Plan), including with respect to Budget
spending, Development Purchases, Production Purchases, FOU License Fees and Milestone Payments, in
sufficient detail to calculate all amounts payable hereunder and to verify compliance with its
obligations under this Agreement. Such books and records shall be retained by such Party and its
Affiliates until [***] ([***]) years after the end of the period to which such books and records
pertain or for such longer period as may be required by Applicable Law.

7.8 Audits. At the request of the other Party, each Party will, and will cause its Affiliates to,
permit an independent public accounting firm of nationally recognized standing designated by the
other Party and reasonably acceptable to the audited Party, at reasonable times during normal
business hours and upon reasonable notice, to audit the books and records maintained pursuant to
Section 7.7 (Financial and Other Records) solely to confirm the accuracy of all financial reports,
invoices and payments made hereunder or Budget spending under an approved Workflow Development Plan.
Such examinations may not (a) be conducted more than once in any [***] month period (unless a
previous audit during such [***] month period revealed an overpayment (or an underpayment of a
Milestone Payment, FOU License Fees, or royalty for Licensed Products) of at least [***] percent
([***]%) of the amount actually due with respect to such period) or (b) [***]. The accounting firm
will execute a reasonable written confidentiality agreement with the audited Party and will disclose
to the auditing Party only such information as is reasonably necessary to provide the auditing Party
with information regarding any actual or potential discrepancies between the amounts actually paid
and the amounts payable under this Agreement. The accounting firm's report will [***] be delivered
to each Party at the same time and will be deemed final [***] ([***]) business days after it is
received by both Parties. The auditing Party shall bear the full cost of any such audit, unless the
accounting firm's report discloses an overpayment (or underpayment) by the auditing Party of more
than [***] percent ([***]%) of the amount due for any Calendar Quarter, in which case the audited
Party shall bear the full cost of such audit. The audited Party shall pay the amount of any
overpayment (or underpayment) disclosed in the accounting firm's report, together with interest
thereon from the date such payment was originally due, within [***] ([***]) days after delivery to
the Parties of the accounting firm's report. Page 41 of 85
<!-- page 42 -->
7.9 Confidentiality. All books and records audited by a Party pursuant to Section 7.8 (Audits) will
be maintained in confidence by such auditing Party in accordance with Article 10 (Confidentiality).

7.10 Late Payment. If any payment due is not paid by the due date, BLI may (a) charge interest on
any outstanding amount of such payment, accruing as of the original due date, at an annual rate
equal to the rate of prime (as reported in The Wall Street Journal, Eastern U.S. Edition) plus [***]
percentage points or the maximum rate allowable by Applicable Law, whichever is less. 8.
INTELLECTUAL PROPERTY OWNERSHIP; USE OF DATA

8.1 Ownership of Background IP; Efforts to Control. As between the Parties, and subject to the
licenses granted under this Agreement, Ginkgo shall own and retain all rights, title, and interests
in, to and under Ginkgo Background IP, and BLI shall own and retain all rights, title, and interests
in, to and under BLI Background IP. With respect to any Intellectual Property developed by BLI or
its Affiliates in collaboration or on behalf of a Third Party during the Term of this Agreement that
is [***] for (a) [***] or (b) [***], with respect to each, BLI and its Affiliates shall [***] to
[***] that BLI or its Affiliates Control such Intellectual Property so that BLI may grant a license
to Ginkgo with respect to such Intellectual Property as set forth in Section 9.1 (Grants to Ginkgo).

8.2 Ownership of Ginkgo Inventions and BLI Inventions.

8.2.1 Ginkgo Inventions. Unless otherwise agreed to in writing by the Parties, as between the
Parties, Ginkgo shall own:

(a) all biological entities, including all organisms, cells, strains, enzymes and other proteins,
nucleic acids and other biomaterials (that are not BLI-provided biological entities listed in
Section 8.2.2(f) (BLI Inventions)) [***], in each case that Ginkgo loads onto the Beacon Platform or
provides to BLI [***];

(b) all [***];

(c) any assays [***];

(d) all chemical entities other than [***], developed, generated, created, used or otherwise
exploited in connection with the use of the Beacon Platform (clauses (a) through (d) of this Section
8.2.1 (Ginkgo Inventions) collectively, with the exception of [***], the "Ginkgo Materials");

(e) all [***]; Page 42 of 85
<!-- page 43 -->
(f) the [***];

(g) the Ginkgo Workflows, with the exception of any BLI Inventions; and

(h) all rights to the Intellectual Property contained or otherwise embodied in the inventions,
discoveries, improvements, materials, chemical entities, Ginkgo Materials, [***], [***], or Ginkgo
Workflows, described in clauses (a) through (g) of this Section 8.2.1 (Ginkgo Inventions) (clauses
(a) through (g) collectively, the "Ginkgo Inventions").

For clarity, Ginkgo's ability to use Ginkgo Inventions are subject to the limitations set forth in
Section 9.1 (Grants to Ginkgo).

8.2.2 BLI Inventions. Unless otherwise agreed to in writing by the Parties, as between the Parties,
BLI shall own:

(a) all inventions or discoveries [***]related to, or improvements or modifications to, the Beacon
Platform that are developed, generated, created, used or otherwise exploited in connection with the
use of the Beacon Platform under a Workflow Development Plan;

(b) any materials or chemical entities that are not Ginkgo Materials that are developed, generated,
created, used or otherwise exploited in connection with the use of the Beacon Platform under a
Workflow Development Plan, with the exception of any materials that are publicly available for
purchase or are otherwise rightfully in the public domain;

(c) all BLI Proprietary Workflows;

(d) Generalized Workflows, with the exception of any Ginkgo Inventions;

(e) all Consumables provided by BLI related to the Beacon Platform and [***], in each case (i)
developed, generated, created, used or otherwise exploited in connection with the use of the Beacon
Platform under a Workflow Development Plan and (ii) [***];

(f) although generally not expected during the Term, any [***]; and

(g) all rights to the Intellectual Property contained or otherwise embodied in the inventions,
discoveries, improvements, materials, chemical entities, Beacon Platform or Consumables described in
clauses (a) through (f) of this Section 8.2.2 (BLI Inventions) (collectively, clauses (a) through
(f) of this Section 8.2.2 (BLI Inventions), the "BLI Inventions"). Page 43 of 85
<!-- page 44 -->
8.3 Ownership of Remaining Collaboration Intellectual Property. Subject to Section 8.2 (Ownership of
Ginkgo Inventions and BLI Inventions), as between the Parties, BLI shall solely own all right, title
and interest to all Collaboration Intellectual Property [***].

8.4 Prosecution and Enforcement Rights. Ginkgo shall have the sole and exclusive right, but not the
obligation, to protect, seek registration for, defend and enforce, in its sole and entire
discretion, the Ginkgo Inventions. BLI shall have the sole and exclusive right, but not the
obligation, to protect, seek registration for, defend and enforce in its sole and entire discretion,
the BLI Inventions and Collaboration Intellectual Property (other than the Ginkgo Inventions). In no
event shall Ginkgo, and Ginkgo shall cause its Affiliates to not, file any patent applications
covering (or support existing patent applications covering) the [***] and, in the event Ginkgo (or
its Affiliates) do file one or more of such patent applications, Ginkgo will and hereby does assign,
and shall cause its employees, agents and contractors to assign, to BLI all rights, title and
interests in, to and under such patent applications. Other than as permitted under Section 8.5.2
(Use of Collaboration Data), in no event shall BLI, and BLI shall cause its Affiliates to not, file
any patent applications covering (or support existing patent applications covering) [***] and, in
the event that BLI (or its Affiliates) do file one or more of such patent applications, BLI will and
hereby does assign, and shall cause its employees, agents and contractors to assign, to Ginkgo all
rights, title and interests in, to and under such patent applications.

8.5 Use of Collaboration Data.

8.5.1 Disclosure. With respect to any data or results that are generated in connection with
activities under a Workflow Development Plan (such data and results (but not Collaboration
Workflows), "Collaboration Data"), each Party shall provide the other Party any Collaboration Data
in its possession; provided that [***] shall provide any such Collaboration Data in its possession
to [***] to the extent permitted under obligations of confidentiality owed by [***] to Third Parties
with respect to such Collaboration Data. Notwithstanding the foregoing, [***] shall have the right
to anonymize any Collaboration Data for disclosure to [***] or use by [***] under Section 8.5.2 (Use
of Collaboration Data) and shall be permitted to remove from such Collaboration Data (a) any Third
Party confidential information, (b) the identity of any [***] and (c) proprietary information
regarding [***] Inventions or Intellectual Property Controlled, possessed or owned by [***] or its
Affiliates.

8.5.2 Use of Collaboration Data. BLI will have the right to use any Collaboration Data provided to
it for disclosure pursuant to Section 8.5.1 (Disclosure) solely for the purposes of (a) [***], (b)
[***], (c) [***], and (d) [***]. For clarity, with respect to clause (d) of this Section 8.5.2 (Use
of Collaboration Data), [***].

8.6 Notification of New Products; [***].

8.6.1 Access to New Products. During the Term, BLI shall promptly notify Ginkgo of any upcoming or
then-current commercial availability of any new Beacon Optofluidic Machine or Consumable that, at
that time, is not listed in Schedule 1.10 (Beacon Optofluidic Machine) or Schedule 1.36
(Consumables) and the Parties shall[***]. Page 44 of 85
<!-- page 45 -->
8.6.2 [***]. During the Term, BLI shall provide Ginkgo with [***] (a) [***], (b) [***] and (c) BLI
[***], with respect to each, [***] and [***]. As used in this Section, "[***]" means [***].

8.7 Inventor's Remuneration. Each Party will be solely responsible for any remuneration that may be
due to such Party's inventors under any applicable inventor remuneration laws.

8.8 [***]. If, at any time during the Term, Ginkgo has purchased from BLI, in the aggregate, [***]
([***]) or more Beacon Optofluidic Machines, then:

8.8.1 Non-Exclusive [***] License. To ensure that, [***], BLI shall, and hereby does, automatically
grant to Ginkgo, as of the date Ginkgo purchases an aggregate of [***] ([***]) Beacon Optofluidic
Machine from BLI, a non-exclusive, non-royalty bearing and sublicensable (through multiple tiers)
worldwide license in any Intellectual Property Controlled by BLI that is necessary to [***], solely
for Ginkgo's [***] own internal use so that Ginkgo (or its Affiliates or permitted sublicensees) may
[***]. Notwithstanding the foregoing, Ginkgo hereby represents, warrants and covenants to BLI that,
as of the date BLI grants such license to Ginkgo and throughout the Term and thereafter, it shall
not, directly or indirectly, conduct any activities under the rights granted to it in this Section
8.8.1 ([***]) unless and until (a) (i) [***] or (ii) [***], with respect to (i)-(ii), and such [***]
or (b) [***]; provided that, after the event(s) sufficient to trigger sub-sections (i) or (ii) of
this sentence occur, Ginkgo must provide BLI with written notice of its intent to conduct activities
under rights granted pursuant to this Section 8.8.1 [***]. In the event Ginkgo has the right to
conduct activities under the rights granted to it in this Section 8.8.1 ([***]), Ginkgo shall [***].
BLI shall [***].

8.8.2 [***]. Upon Ginkgo's written request at any time after [***], BLI shall [***] and will [***]
so that [***]. Notwithstanding the foregoing, Ginkgo hereby represents, warrants and covenants to
BLI as of the Effective Date, throughout the Term that it shall not, directly or indirectly, [***]
unless and until (a) (i) [***] or (ii) [***] or (b) [***]; provided that, after the event(s)
sufficient to trigger sub-sections (i) or (ii) of this sentence occur, Ginkgo must provide BLI with
written notice of its intent to conduct activities under rights granted pursuant to this Section
8.8.2 [***]. In the event Ginkgo has the right to so [***], Ginkgo shall [***].

8.8.3 [***]. Upon Ginkgo's written request to BLI at any time if (a) there is (i) [***] or (ii)
[***], or (b) [***], BLI shall [***] and [***] and shall [***], including by [***]; provided further
that, if [***] either (A) [***] or (B) [***], then [***]. In the event Ginkgo [***], Ginkgo hereby
represents, warrants and covenants to BLI as of the Effective Date, throughout the Term and
thereafter that it shall [***]. BLI shall [***].

8.8.4 Any obligation of Ginkgo to [***] shall be [***].

8.9 Specific Implementation Restrictions. For clarity, this Agreement does not prohibit BLI or its
Affiliates, alone or in combination with a Third Party, from independently developing a Workflow or
a part or component thereof; or a derivative, modification, replication or progeny of Page 45 of 85
<!-- page 46 -->
a biological entity; that is the [***] to a Specific Implementation (each such independently
developed item, an "Independent Development"); provided that the Independent Development does not
use any [***]; and further provided that BLI and its Affiliates do not [***] any [***] to [***] any
Independent Development. Without limiting any other provision of this Agreement or Ginkgo's rights
or remedies under this Agreement or Applicable Law, any use of [***] by BLI or its Affiliates, alone
or in combination with a Third Party to develop a Workflow or a part or component thereof; or a
derivative, modification, replication or progeny of a biological entity that is [***] a Specific
Implementation shall be deemed a material breach of this Agreement by BLI and shall give rise to
Ginkgo's right to terminate this Agreement pursuant to Section 13.2.1 (Material Breach). 9. LICENSE
GRANTS

9.1 Grants to Ginkgo.

9.1.1 Scope of Grants. Subject to the terms and conditions of this Agreement, and in consideration
for the payments to BLI under this Agreement, during the Term, BLI, on behalf of itself and its
Affiliates, hereby grants and shall grant to Ginkgo a non-exclusive, sublicensable (solely in
accordance with Section 9.1.4 (Consent to Sublicense)), non-transferable, non-royalty-bearing
(subject to Section 13.3.2 (Effects of Termination Based Upon Ginkgo Buy-Down Election)) worldwide
license in, to and under (i) BLI Background IP, and (ii) other Intellectual Property that is
Controlled by BLI and that is [***] BLI Inventions, with both of (i) and (ii) being limited to what
is necessary for Ginkgo to [***] and (iii) the Collaboration Intellectual Property solely to:

(a) perform research [***] on biological entities, including organisms, cells and strains (and
sub-components thereof);

(b) (i) design and develop (A) Collaboration Workflows as generally contemplated under a Workflow
Development Plan and (B) Ginkgo Workflows as permitted under this Agreement and (ii) use [***]
Workflows to conduct the activities set forth in clause (a) and clause (c) of this Section 9.1.1
(Scope of Grants);

(c) perform commercial research [***] and other Commercial Services for Third Parties; and

(d) in each case of clauses (a) through (c) of this Section 9.1.1 (Scope of Grants), the license
granted is for activities solely within the Licensed Field.

9.1.2 License Grant to Exploit [***]. Subject to the terms and conditions of this Agreement, during
the Term BLI, on behalf of itself and its Affiliates, hereby grants and shall grant to Ginkgo a
[***] license within the Licensed Field in, to and under any Intellectual Property Controlled by BLI
that is necessary to make, have made, sell, have sold, import or use any [***] to make, have made,
sell, have sold, import or use such [***]. Page 46 of 85
<!-- page 47 -->
9.1.3 No Consumable License. For clarity and without limiting Section 8.8.1 (Non-Exclusive
Manufacturing License; Covenant), the licenses granted to Ginkgo in Section 9.1.1 (Scope of Grants)
and Section 9.1.2 (License Grant to Exploit [***]) do not include the right to make, have made,
offer to sell or sell Consumables, [***], to or for Third Parties or any Ginkgo Affiliate or Ginkgo
Subcontractor that are [***] on the Beacon Platform [***].

9.1.4 Consent to Sublicense. Ginkgo may grant sublicenses of the license granted to Ginkgo under
Section 9.1.1 (Scope of Grants) and Section 9.1.2 (License Grant to Exploit [***]) with the prior
written consent of BLI[***]; provided that such prior written consent of BLI shall not be needed for
any sublicense granted by Ginkgo to (a) a Permitted Subcontractor of Ginkgo under Section 2.7
(Subcontracting) to the extent such sublicense relates to the subcontracted activities, (b) any
wholly-owned subsidiary of Ginkgo existing as of the Effective Date or (c) any other Person,
including other Affiliates and any Third Party, under Section 9.1.2 (License Grant to Exploit [***])
so long as, in the case of this clause (c), the sublicense [***]. Each sublicense of the license
granted to Ginkgo under Section 9.1.1 will (i) be in writing, (ii) be consistent with the terms and
conditions of this Agreement and (iii) require each sublicensee thereunder to comply with all terms
of this Agreement applicable to a sublicensee. Notwithstanding the grant of any sublicense, Ginkgo
shall remain [***] liable to BLI for the performance of all of Ginkgo's obligations under, and
Ginkgo's compliance with all provisions of, this Agreement.

9.1.5 Responsibility. Ginkgo shall not (and Ginkgo shall ensure that its Affiliates and [***]
sublicensees do not) use any Intellectual Property of BLI's that is licensed under Section 9.1
(Grants to Ginkgo), any BLI Confidential Information or any Beacon Platforms that may be transferred
to Ginkgo by BLI under this Agreement, in each case for a purpose other than as expressly permitted
under this Agreement.

9.1.6 Use in Excluded Fields. In the event BLI [***] that Ginkgo is using [***] in the Excluded
Fields ("Ginkgo Excluded Use"), BLI shall send Ginkgo a written notice indicating that it believes
Ginkgo is using [***] in an Excluded Field and, within [***] ([***]) Business Days after Ginkgo's
receipt of BLI's written notice, Ginkgo shall investigate such claim internally and shall either (a)
[***], or (b) [***], and the Parties will resolve such dispute pursuant to Section 14.5.2 (Dispute
Resolution). If, following the dispute resolution process set forth in Section 14.5.2 (Dispute
Resolution), it is determined that Ginkgo is using [***] in an Excluded Field, then BLI may either
(i) [***], (ii) [***] or (iii) [***]; provided that, following determination that Ginkgo is using
[***] in an Excluded Field pursuant to Section 14.5.2 (Dispute Resolution), if BLI wishes to make
any election under clause (i), (ii) or (iii), it must notify Ginkgo within [***] ([***]) Business
Days of such determination. [***].

9.2 Grants to BLI. Subject to the terms and conditions of this Agreement, during the Term, Ginkgo
hereby grants and shall grant to BLI:

9.2.1 a [***] and this Section 9.2 (Grants to BLI)), [***] license in, to and under any Intellectual
Property (a) Controlled by Ginkgo, (b) used by Ginkgo in the conduct of a Workflow Development Plan
and (c) necessary for BLI to perform its obligations under this Agreement ((a)-(c) collectively,
"Ginkgo Licensed IP"), solely to perform BLI's obligations under such Workflow Development Plan; and
Page 47 of 85
<!-- page 48 -->
9.2.2 after any applicable Headstart Period, with respect to any [***], a [***] license in, to and
under any Ginkgo Licensed IP [***] necessary for the performance of, such [***], to make, have made,
offer to sell, sell, have sold, import, use, commercialize or perform such [***] to or for Third
Parties and to license such Third Parties to do the same.

Except as permitted under Sections 9.2.1 and 9.2.2, BLI may not sublicense, assign or otherwise
transfer the rights granted to it in this Section 9.2 (Grants to BLI) without first obtaining the
prior written consent of Ginkgo[***]. Each sublicense of any license granted to BLI under this
Section 9.2 (Grants to BLI) will (i) be in writing, (ii) be consistent with the terms and conditions
of this Agreement and (iii) require each sublicensee thereunder to comply with all terms of this
Agreement applicable to a sublicensee; provided that, subject to Section 6.2.1, such prior written
consent of Ginkgo shall not be needed for any sublicense granted by BLI (a) under Section 9.2.1, to
a Permitted Subcontractor of BLI under Section 2.7 (Subcontracting) to the extent such sublicense
relates to the subcontracted activities, (b) any wholly-owned subsidiary of BLI existing as of the
Effective Date, or (c) any other Person, including other Affiliates and any Third Party, under
Section 9.2.2. Notwithstanding the grant of any sublicense, BLI shall remain liable to Ginkgo for
the performance of all of BLI's obligations under, and BLI's compliance with, all provisions of,
this Agreement. BLI shall not (and BLI shall ensure that any of its Affiliates and sublicensees do
not) use any Intellectual Property or Confidential Information of Ginkgo that is licensed under this
Section 9.2 or otherwise disclosed to BLI under this Agreement for any purpose not expressly
permitted under this Agreement. [***].

9.3 No Implied Rights. Except as expressly provided in this Agreement, neither Party will be deemed
to have granted the other Party (by implication, estoppel or otherwise) any right, title, license or
other interest in or with respect to any Intellectual Property or information Controlled by such
Party. 10. CONFIDENTIALITY

10.1 Confidential Information. Each Party may disclose ("Disclosing Party") to the other Party
("Receiving Party"), and Receiving Party may acquire during the course and conduct of activities
under the Agreement, certain non-public or confidential information of Disclosing Party in
connection with this Agreement. The term "Confidential Information" means all non-public or
confidential information or material in tangible form that one Party discloses to the other Party
hereunder, or proprietary or confidential information disclosed in non-tangible form that a
Disclosing Party identifies to the Receiving Party as confidential information or that, from the
nature of such information, the Receiving Party should reasonably know is the Confidential
Information of the Disclosing Party, including all technical and non-technical information conveyed
from one Party to the other or otherwise accessed or observed by a Party in any form, electronic
data and other proprietary information, data, samples, products, materials, compounds, sequences,
compositions, configurations, methods, formulas, formulations, processes, protocols, specifications,
designs, recordings, drawings, sketches, models, technologies, equipment, information relating to
quality assurance or control, laboratory notebooks, techniques, inventions, Page 48 of 85
<!-- page 49 -->
know-how, apparatuses, formulae, customer lists, pricing information, strategies, business or
marketing plans and other information related to the Disclosing Party's current, future and proposed
products, business, customers, Software or technology. The Parties agree that the terms of this
Agreement will be treated as Confidential Information of each Party. Without limitation of the
foregoing, (i) Ginkgo Background IP, Ginkgo Inventions, Collaboration Data, Specific
Implementations, and Ginkgo Workflows will be treated as the Confidential Information of Ginkgo and
(ii) BLI Background IP, BLI Inventions, Generalized Workflows and BLI Proprietary Workflows will be
treated as the Confidential Information of BLI. Notwithstanding any other provisions herein,
Confidential Information does not include information that:

10.1.1 was known to Receiving Party or any of its Affiliates prior to the time of disclosure other
than under an obligation of confidentiality with respect to such information;

10.1.2 is at the time of disclosure hereunder or later becomes public knowledge through no fault or
omission of Receiving Party or any of its Affiliates;

10.1.3 is obtained by Receiving Party or any of its Affiliates from a Third Party having the right
to disclose such information (e.g. not under an obligation of confidentiality to the Disclosing
Party or its Affiliates) to such Receiving Party or its Affiliates;

10.1.4 has been independently developed by employees, Permitted Subcontractors, consultants or
agents of Receiving Party or any of its Affiliates without the aid, application, or use of or
reliance upon Disclosing Party's Confidential Information, as evidenced by contemporaneous written
records; or

10.1.5 Receiving Party obtains written consent from Disclosing Party to disclose.

Specific aspects or details of Confidential Information will not be deemed to be within the public
domain or in the possession of Receiving Party merely because the Confidential Information is
embraced by more general information in the public domain or in the possession of Receiving Party.
Further, any combination of Confidential Information will not be considered in the public domain or
in the possession of Receiving Party merely because individual elements of such Confidential
Information are in the public domain or in the possession of Receiving Party unless the combination
and its principles are in the public domain or in the possession of Receiving Party.

10.2 Confidential Treatment. At all times during the Term and for a period of [***] ([***]) years
following the end of the Term, or with respect to trade secrets (with such trade secrets either (i)
having been specifically identified in writing to the Receiving Party by the Disclosing Party
claiming ownership of the same or (ii) reasonably distinguishable by its nature or content as a
trade secret of the Disclosing Party), until such time that such information is no longer a trade
secret (including pursuant to Sections 10.1.1 - 10.1.5), Receiving Party will, and will cause its
Affiliates and its and their respective officers, directors, employees, Permitted Subcontractors,
permitted sublicensees and agents to, keep confidential and not publish or otherwise disclose to a
Third Party and not use for any purpose, any Confidential Information furnished or otherwise made
known to it by the Disclosing Party, except to the extent such disclosure or use is expressly Page
49 of 85
<!-- page 50 -->
permitted by the terms of this Agreement or is reasonably necessary for the performance of, or the
exercise of such Party's rights under, this Agreement; provided that such parties to which the
Confidential Information is disclosed are bound by written obligations of confidentiality at least
as stringent as those set forth in this Agreement. Notwithstanding the foregoing, a Receiving Party
will remain liable for any breach of this Article 10 (Confidentiality) by any party to whom the
Receiving Party has disclosed the Disclosing Party's Confidential Information under this Section
10.2 (Confidential Treatment).

10.3 Permitted Disclosures. Receiving Party may disclose the Confidential Information of the
Disclosing Party in the following instances:

10.3.1 in order to comply with Applicable Law (including any securities law or regulation or the
rules of a securities exchange) or with a legal or administrative proceeding; provided that (a) to
the extent legally permitted, Receiving Party gives written notice of such required disclosure to
Disclosing Party prior to disclosing such Confidential Information and (b) Disclosing Party shall
have the opportunity to take appropriate measures to assure confidential treatment of such
Confidential Information to the extent practicable and consistent with Applicable Law and Receiving
Party agrees to reasonably cooperate with the Disclosing Party in connection with such measures at
Disclosing Party's expense;

10.3.2 in connection with (a) prosecuting or defending litigation or (b) obtaining Regulatory
Approval, making other regulatory filings and communications, and filing, prosecuting, enforcing,
and defending patent rights, in each case, in connection with Receiving Party's rights and
obligations pursuant to this Agreement; provided, however, that, where reasonably possible,
Receiving Party will notify Disclosing Party of Receiving Party's intent to make any such disclosure
sufficiently prior to making such disclosure so as to allow Disclosing Party adequate time to take
whatever action it may deem appropriate to protect the confidentiality of the information to be
disclosed; and

10.3.3 with respect to the terms of this Agreement, after having been reasonably redacted by the
Receiving Party, to the extent such disclosure is reasonably required, to a bona fide potential
licensee, investor, investment banker, acquirer, merger partner or other potential financial
partner, and their respective attorneys, professional advisors and agents; provided that each such
Person to whom such information is to be disclosed is informed of the confidential nature of such
information and has entered into a written agreement with the Party requiring such Person to keep
such information confidential.

10.4 Use of Names. Except as expressly provided herein, neither Party will mention or otherwise use
the name, logo or trademark of the other Party or any of its Affiliates (or any abbreviation or
adaptation thereof) in any publication, press release, website or marketing and promotional
materials, or other form of publicity, without the prior written approval of such other Party in
each instance; [***]. The restrictions imposed by this Section 10.4 (Use of Name) will not prohibit
either Party from making any disclosure identifying the other Party that, in the reasonable opinion
of the disclosing Party's counsel, is required by Applicable Law; provided that such Party will
submit the proposed disclosure identifying the other Party in writing to the other Party as far in
advance as reasonably practicable (and in no event less than [***] ([***]) Business Days prior to
the anticipated date of disclosure) so as to provide a reasonable opportunity to comment thereon.
Page 50 of 85
<!-- page 51 -->
10.5 Publicity. Within [***] ([***]) days of the Effective Date (or such other period as mutually
agreed to by the Parties), the Parties shall issue a press release in the form set forth in Schedule
10.5 (Press Release). After such initial press release, neither Party shall issue a press release or
public announcement relating to this Agreement without the prior written approval of the other
Party, which approval shall not be unreasonably withheld, conditioned or delayed, except that a
Party may (a) once a press release or other public statement is approved in writing by both Parties,
make subsequent public disclosure of the information contained in such press release or other
written statement without the further approval of the other Party and (b) issue a press release or
public announcement, including without limitation, the disclosure of this Agreement (or a summary
thereof) in filings, as required, in the reasonable opinion of the publishing Party's counsel, by
Applicable Law (including by the rules or regulations of the United States Securities and Exchange
Commission or any stock exchange on which the equity interests of such Party or its Affiliates (or
any successor entity) are listed), provided, however, that such Party seeking disclosure will
prepare such summary and a proposed redacted version of this Agreement as far in advance as
reasonably practicable (and in no event less than [***] ([***]) Business Days prior to the
anticipated date of disclosure) so as to provide a reasonable opportunity to comment thereon, and
the other Party shall within such [***] ([***]) Business Day period, provide its comments, if any,
which may be incorporated, in the reasonable discretion of the Party seeking disclosure.

10.6 Destruction or Return of Confidential Information. Upon the end of the Term, whether in its
entirety or with respect to a specific Workflow Development Plan, Disclosing Party may request in
writing to Receiving Party, and Receiving Party will, as requested by Disclosing Party except as and
if necessary for such Receiving Party to exercise surviving rights under this Agreement following
such expiration or termination, (a) at the Disclosing Party's request, destroy, as soon as
reasonably practicable, specific Confidential Information identified by the Disclosing Party in
writing to the Receiving Party that are in Receiving Party's possession and confirm such destruction
in writing to Disclosing Party or (b) deliver to Disclosing Party, as soon as reasonably
practicable, at Disclosing Party's expense, all copies of such Confidential Information in the
possession of Receiving Party; provided that the Receiving Party will be permitted to retain one
copy of such Confidential Information for the sole purpose of performing any continuing obligations
hereunder, as required by Applicable Law or for archival purposes. Notwithstanding the foregoing,
Receiving Party also will be permitted to retain such additional copies of or any computer records
or files containing such Confidential Information that have been created solely by Receiving Party's
automatic archiving and back-up procedures, to the extent created and retained in a manner
consistent with Receiving Party's standard archiving and back-up procedures, but not for any other
use or purpose. 11. WARRANTIES AND DISCLAIMER; LIMITATION OF LIABILITY

11.1 Mutual Representations. Each Party hereby represents and warrants to the other Party, as of the
Effective Date, as follows:

11.1.1 such Party is a corporation or limited liability company duly organized, validly existing and
in good standing under the laws of the state in which it is incorporated; Page 51 of 85
<!-- page 52 -->
11.1.2 such Party (a) has the corporate power and authority and legal right to enter into this
Agreement, to perform its obligations and to grant the licenses hereunder and (b) has taken all
necessary corporate action on its part to authorize the execution and delivery of this Agreement and
the performance of its obligations hereunder;

11.1.3 this Agreement has been duly executed and delivered on behalf of such Party and constitutes a
legal and valid obligation binding upon such Party and enforceable against it in accordance with its
terms;

11.1.4 such Party has the right to grant the rights and licenses granted to the other Party pursuant
to this Agreement; and

11.1.5 it has not entered into an agreement with a Third Party, or granted any right or license to
any Third Party that conflicts with any of the rights, obligations or licenses granted to the other
Party hereunder.

11.2 Mutual Covenants. Each Party hereby covenants to the other Party, as of the Effective Date,
that:

11.2.1 all of its and its Affiliates' employees who conduct any work under this Agreement will be,
during the conduct of all such work, bound to a written agreement with such Party or its Affiliate
to automatically assign all right, title and interest in and to their inventions and discoveries,
whether or not patentable, to such Party as the sole owner thereof;

11.2.2 to the best of its knowledge, without further duty of inquiry, such Party will not

(a) employ or use any contractor or consultant that employs any Person debarred by the FDA (or
subject to similar sanction of the EMA or other Regulatory Authority) or (b) employ any Person that
is the subject of an FDA debarment investigation or proceeding (or similar proceeding of the EMA or
other Regulatory Authority), in each of (a)-(b), in the conduct of its activities under this
Agreement;

11.2.3 it will perform or cause to be performed the obligations assigned to it under this Agreement
in good scientific manner and in compliance with all Applicable Laws; and

11.2.4 it shall not, during the Term, enter into an agreement with a Third Party, or grant any right
or license to any Third Party relating to any of the intellectual property rights it Controls, or
otherwise encumber such intellectual property rights it Controls, that would conflict with any of
the rights, obligations or licenses granted to the other Party hereunder. Page 52 of 85
<!-- page 53 -->
11.3 Additional Representations, Warranties and Covenants of BLI. As of the Effective Date, BLI
further represents, warrants and, as applicable, covenants to Ginkgo that:

11.3.1 BLI has, as of the Effective Date, and to its current knowledge will have during the Term,
the full right, power and authority to (a) grant all of the right, title and interest in the
licenses and other rights granted or to be granted to Ginkgo under this Agreement and (b) perform
its obligations under this Agreement; 11.3.2 neither BLI nor its Affiliates have granted, and BLI
and its Affiliates will not grant, any liens or security interest on any assets, including
Intellectual Property, that would limit the scope of any rights or licenses granted to Ginkgo
hereunder;

11.3.3 neither BLI nor its Affiliates have knowledge of or have received any written notice of any
claim that any Intellectual Property Controlled by a Third Party would be infringed or
misappropriated by the activities contemplated under this Agreement, including Ginkgo's use of the
Beacon Platform to perform a general Workflow under this Agreement;

11.3.4 the Beacon Optofluidic Machines (including related Hardware and Software) and Consumables, at
the time of delivery to Ginkgo, (a) shall have been manufactured, stored, shipped and delivered in
accordance with Applicable Law and this Agreement; (b) to BLI's knowledge, [***] and (c) shall be
free from all liens, charges, encumbrances and security interests;

11.3.5 all services, including Services, shall be performed by or on behalf of BLI with requisite
care, skill and diligence, by individuals who are appropriately trained and qualified, and in
accordance with Applicable Law and industry standards;

11.3.6 to BLI's knowledge [***], the use of the Beacon Platform as contemplated under this
Agreement, but without any representation or warranty regarding [***] (a) [***] or (b) [***];

11.3.7 to BLI's knowledge [***], (a) the use of the Beacon Platform as contemplated under this
Agreement and (b) the performance of the activities Ginkgo is granted the right to conduct under
Section 9.1 (Grants to Ginkgo) (but for both (a) and (b) no representation, warranty or covenant is
given by BLI for Ginkgo Materials, Ginkgo Workflows or for Collaboration Workflows) [***]; and

11.3.8 BLI has independently developed all BLI Background IP or otherwise has a valid right to use
and, as applicable, to permit Ginkgo and its permitted sublicensees to use, the BLI Background IP
for all permitted purposes under this Agreement.

11.4 Additional Representations, Warranties and Covenants of Ginkgo. As of the Effective Date,
Ginkgo further represents, warrants and, as applicable, covenants to BLI that:

11.4.1 Ginkgo has, as of the Effective Date, and will have during the Term, the full right, power
and authority to (a) grant all of the right, title and interest in the licenses and other rights
granted or to be granted to BLI under this Agreement and (b) perform its obligations under this
Agreement; Page 53 of 85
<!-- page 54 -->
11.4.2 Ginkgo has independently developed all Ginkgo Background IP or otherwise has a valid right to
use, and, as applicable, to permit BLI and its permitted sublicensees to use, the Ginkgo Background
IP for all permitted purposes under this Agreement; and

11.4.3 neither Ginkgo nor its Affiliates have granted, and Ginkgo and its Affiliates will not grant,
any liens or security interest on any assets, including Intellectual Property, that would limit the
scope of any rights or licenses granted to BLI hereunder.

11.5 DISCLAIMERS.

11.5.1 EXCEPT AS SPECIFICALLY SET FORTH IN THIS AGREEMENT, NEITHER PARTY MAKES ANY REPRESENTATIONS
OR WARRANTIES OF ANY KIND CONCERNING ITS ACTIVITIES UNDER THIS AGREEMENT OR RESULTS OF ANY WORK PLAN
AND HEREBY DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS
OF ITSELF OR THIRD PARTIES, VALIDITY, ENFORCEABILITY AND SCOPE OF PATENT RIGHTS, VALIDITY OF PATENT
RIGHTS CLAIMS, WHETHER ISSUED OR PENDING, AND THE ABSENCE OF LATENT OR OTHER DEFECTS WHETHER OR NOT
DISCOVERABLE.

11.5.2 BEACON PLATFORMS ARE SOLD "FOR RESEARCH USE ONLY. NOT FOR USE IN DIAGNOSTIC PROCEDURES."
GINKGO ACKNOWLEDGES THAT (I) BEACON PLATFORMS HAVE NOT BEEN APPROVED, CLEARED OR LICENSED BY THE
UNITED STATES FOOD AND DRUG ADMINISTRATION OR ANY OTHER REGULATORY ENTITY WHETHER FOREIGN OR
DOMESTIC FOR ANY SPECIFIC INTENDED USE, WHETHER RESEARCH, COMMERCIAL, DIAGNOSTIC OR OTHERWISE AND
(II) GINKGO MUST ENSURE IT HAS ANY REGULATORY APPROVALS THAT ARE NECESSARY FOR GINKGO'S INTENDED
USES OF BEACON PLATFORMS. GINKGO FURTHER AGREES TO COMPLY WITH ALL APPLICABLE LAWS AND REGULATIONS
WHEN USING, MAINTAINING AND DISPOSING OF BEACON PLATFORMS.

11.6 No Consequential Damages. EXCEPT TO THE EXTENT ARISING (A) FROM A PARTY'S BREACH OF ARTICLE 10
(CONFIDENTIALITY), (B) [***] (E) FROM A PARTY'S FRAUD, GROSS NEGLIGENCE OR WILLFUL MISCONDUCT OR (F)
IN CONNECTION WITH A PARTY'S INDEMNIFICATION OBLIGATIONS UNDER ARTICLE 12 (INDEMNIFICATION;
INSURANCE), IN NO EVENT WILL EITHER PARTY BE LIABLE TO THE OTHER PARTY FOR ANY LOST PROFITS,
INDIRECT, SPECIAL, INCIDENTAL, EXEMPLARY OR CONSEQUENTIAL DAMAGES OF ANY KIND ARISING OUT OF OR IN
CONNECTION WITH THIS AGREEMENT, HOWEVER CAUSED AND ON Page 54 of 85
<!-- page 55 -->
ANY THEORY OF LIABILITY (WHETHER IN CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR
OTHERWISE). THE LIMITATIONS SET FORTH IN THIS SECTION WILL APPLY EVEN IF A PARTY HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGES, AND NOTWITHSTANDING ANY FAILURE OF ESSENTIAL PURPOSE OF ANY LIMITED
REMEDY.

11.7 Liability Limit. TO THE GREATEST EXTENT PERMITTED UNDER APPLICABLE LAW, IN NO EVENT WILL A
PARTY'S AGGREGATE LIABILITY (ABOVE AMOUNTS ACTUALLY PAID OR REIMBURSED BY SUCH PARTY'S INSURER (TO
THE EXTENT NOT SELF-INSURED)) FOR A CLAIM ARISING OUT OF OR RELATED TO THIS AGREEMENT UNDER ANY
LEGAL OR EQUITABLE THEORY, INCLUDING BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT
LIABILITY, AND OTHERWISE EXCEED [***], EXCEPT THAT (A) SUCH LIMITATION SHALL NOT APPLY TO (I) A
PARTY'S BREACH OF ARTICLE 10 (CONFIDENTIALITY), [***], (V) A PARTY'S FRAUD, GROSS NEGLIGENCE OR
WILLFUL MISCONDUCT OR (VI) A PARTY'S INDEMNIFICATION OBLIGATIONS UNDER ARTICLE 12 (INDEMNIFICATION;
INSURANCE) AND (B) SUCH LIMITATION ON LIABILITY SHALL NOT INCLUDE ANY AMOUNTS ACCRUED AND ACTUALLY
OWED PURSUANT TO THE TERMS OF THIS AGREEMENT. 12. INDEMNIFICATION; INSURANCE

12.1 Indemnification by BLI. BLI will indemnify, defend and hold Ginkgo and its Affiliates, and its
and their officers, directors, employees, licensees, sublicensees, Permitted Subcontractors and
agents (each, a "Ginkgo Indemnitee") harmless from and against any and all suits, claims,
proceedings and causes of action brought by a Third Party (collectively, "Claims") and all
associated damages, liabilities, expenses and losses, including reasonable legal expenses and
reasonable attorneys' fees (collectively, "Losses"), to the extent caused by or arising as a result
of (a) the breach by BLI of this Agreement or material inaccuracy in any representation or warranty
made by BLI under this Agreement, (b) the negligence, gross negligence, fraud or willful misconduct
by a BLI Indemnitee in connection with this Agreement, (c) [***], and (d) any Claims by BLI's
employees, Permitted Subcontractors or agents for worker's compensation or other liability coverage,
insurance, benefits, and other employee-related claims, in each case of clauses (a)-(d) of this
Section 12.1 (Indemnification by BLI), except to the extent Ginkgo has an obligation to indemnify an
BLI Indemnitee in connection with such Claims and Losses pursuant to Section 12.2 (Indemnification
by Ginkgo).

12.2 Indemnification by Ginkgo. Ginkgo will indemnify, defend and hold BLI and its Affiliates, and
its and their officers, directors, employees, Permitted Subcontractors and agents (each, an "BLI
Indemnitee") harmless from and against any and all Claims and Losses, to the extent caused by or
arising as a result of (a) the breach by Ginkgo of this Agreement or material inaccuracy in any
representation or warranty made by Ginkgo under this Agreement, (b) the negligence, gross
negligence, fraud or willful misconduct by a Ginkgo Indemnitee in connection with this Agreement,
(c) [***] and (d) any Claims by Ginkgo's employees, Permitted Subcontractors or agents for worker's
compensation or other liability coverage, insurance, benefits, and other employee-related claims,
and (e) the development, manufacture, use, handling, storage, importation, distribution, sale or
other commercialization of Ginkgo Inventions by Ginkgo Page 55 of 85
<!-- page 56 -->
or its Affiliates, agents, licensees, sublicensees or customers, in each case of clauses (a)-(e) of
this Section 12.2 (Indemnification by Ginkgo) except to the extent BLI has an obligation to
indemnify a Ginkgo Indemnitee in connection with such Claims and Losses pursuant to Section 12.1
(Indemnification by BLI).

12.3 Procedure. Any Party seeking indemnification under this Article 12 (Indemnification; Insurance)
will promptly notify the indemnifying Party in writing after the Party seeking indemnification has
received notice of any Claim. The Party seeking indemnification will reasonably cooperate with the
indemnifying Party in the defense of any such Claim at the cost of the indemnifying Party. An
indemnifying Party will not be obligated to defend, indemnify and hold harmless the Party seeking
indemnification if, and only to the extent, the Party seeking indemnification delays providing
notice of a Claim to the indemnifying Party and the delay in notice substantively prejudices the
ability of the indemnifying Party to successfully defend the Claim. The indemnifying Party may not
make any admission on behalf of the Party seeking indemnification [***]. Notwithstanding the
foregoing, the Party seeking indemnification may at any time choose to be represented by its own
counsel at its expense (or at the indemnifying Party's expense if the indemnifying Party's defense
is inadequate as determined by a reasonableness standard).

12.4 Insurance. Each Party will obtain and carry in full force and effect the minimum insurance
requirements set forth below. Such insurance (i) will be primary insurance with respect to each
Party's own participation under this Agreement and (ii) will be issued by a recognized insurer rated
by A.M. Best "A-VII" (or its equivalent) or better, or an insurer pre-approved in writing by the
other Party.

12.4.1 Types and Minimum Limits. The types of insurance, and minimum limits will be: (i) any
insurance policy that is required by any Applicable Law, including [***] and [***] policies where
applicable; and (ii) [***] insurance with a minimum limit of [***] Dollars ($[***]) per occurrence
and [***] Dollars ($[***]) in the aggregate. For clarity, [***].

12.4.2 Certificates of Insurance. Upon request by a Party, the other Party will provide Certificates
of Insurance evidencing compliance with this Section 12.4 (Insurance). The insurance policies will
be under an occurrence form, but if only a claims-made form is available to a Party, then such Party
will continue to maintain such insurance after Expiration or the termination of this Agreement for a
period of [***] ([***]) years following the end of the Term. 13. TERM AND TERMINATION

13.1 Term.

13.1.1 General. This Agreement shall commence on the Effective Date and, unless sooner terminated in
accordance with its terms, including by Ginkgo pursuant to Section 7.3 (Buy-Down Election) or
extended by the mutual written agreement of the Parties, shall continue until the Intended End of
Term (such time period, as may be extended pursuant to this Section 13.3.1 (Term - General), the
"Term"); provided that, if, Page 56 of 85
<!-- page 57 -->
at the expiration of the Intended End of Term, Ginkgo has paid the Minimum Cumulative Purchase
Commitment, but will not have paid to BLI the Full Purchase Target, then the Term of this Agreement
shall automatically extend for an additional [***] ([***]) year period from the date of the
expiration of the then-Intended End of Term so that, among other things, BLI may potentially receive
the benefit of the Full Purchase Target and Ginkgo may receive the continuing benefit of
royalty-free licenses.

13.1.2 Effects of Expiration. Upon Expiration of this Agreement: (i) the licenses granted to BLI
from Ginkgo pursuant to Section 9.2 (Grants to BLI) and the licenses granted to Ginkgo from BLI in
Section 9.1.1 (Scope of Grants) and 9.1.2 (License Grant to Exploit [***]) shall survive and become
perpetual, irrevocable, and royalty-free, (ii) no royalties shall be payable by Ginkgo on the sale
or transfer of a Licensed Product, (iii) the pricing terms for Beacon Optofluidic Machines,
Consumables, and services (including Services) set forth in Section 5.2.2 (Pricing - Adjustments)
shall [***], (iv) the restrictions on BLI set forth in Section 6.2.1 (Restrictions on BLI) shall
survive to the extent set forth therein and (v) [***].

13.2 Termination With Cause.

13.2.1 Material Breach. If either Party commits a material breach of any of its obligations under
this Agreement, then the other Party may give the breaching Party written notice of such material
breach. If the breaching Party fails to cure such breach within sixty (60) days after such notice,
then the non-breaching Party may terminate this Agreement upon written notice to the breaching Party
in its entirety. Notwithstanding the foregoing, if the breaching Party has a bona fide dispute as to
whether such breach has occurred or has been cured, it will so notify the non- breaching Party in
writing and the cure period will be tolled until such dispute is resolved pursuant to Section 14.5.2
(Dispute Resolution). Upon a final determination of breach or failure to cure, the breaching Party
will have the remainder of the cure period to cure such breach. [***].

13.2.2 Bankruptcy. Each Party will have the right to terminate this Agreement immediately in its
entirety by giving written notice of termination to the other Party, if the other Party files a
voluntary petition, or if an involuntary petition is granted in respect of the other Party and
appeal proceedings are not commenced within [***] ([***]) Business Days from the date of such
petition under the bankruptcy provisions of Applicable Law, or the other Party is declared
insolvent, undergoes voluntary or involuntary dissolution, or makes an assignment for the benefit of
its creditors, or suffers the appointment of a receiver or trustee over all, or substantially all,
of its assets or properties. All rights and licenses under or to Intellectual Property granted under
or pursuant to this Agreement by one Party to the other are, and will otherwise be deemed to be, for
purposes of Section 365(n) of the U.S. Bankruptcy Code, licenses of rights to "intellectual
property" as defined under Article 101 (52) of the U.S. Bankruptcy Code. The Parties agree that each
Party will retain and may fully exercise all of its rights and elections under the U.S. Bankruptcy
Code or such similar laws in a jurisdiction outside the United States. Page 57 of 85
<!-- page 58 -->
13.3 Effects Termination.

13.3.1 General. As of the effective date of any early termination of this Agreement, (a) neither
Party shall be relieved of any obligation that accrued prior to such effective date of termination;
(b) except as otherwise expressly provided herein, all rights and obligations of each Party
hereunder will cease and (c) each Party shall return or destroy all Confidential Information of the
other Party that is in its possession, subject to and as more fully set forth in Section 10.6
(Destruction or Return of Confidential Information). BLI shall fulfill any Production Purchase
orders placed by Ginkgo prior to the effective date of termination and Ginkgo shall pay for such
orders pursuant to Section 5.3.3 (Delivery and Payment). For all Development Purchases, BLI shall
deliver to Ginkgo all works-in-progress and any report or analysis prepared prior to the effective
date of termination within [***] ([***]) days after the effective date of termination. "Expiration"
of this Agreement occurs only when[***].

13.3.2 Effects of Termination Based Upon Ginkgo's Buy-Down Election. In the event that termination
is the result of Ginkgo exercising the Buy-Down Election (including payment of the Buy-Down Amount),
then, as of the effective date of termination: (a) any and all existing Headstart Periods shall
immediately be deemed to have accelerated to conclusion, (b) the restrictions on BLI set forth in
Section 6.2.1 (Restrictions on BLI) shall terminate; (c) the licenses granted to Ginkgo from BLI in
Section 9.1.1 (Scope of Grants) and 9.1.2 (License Grant to Exploit [***]) shall survive and become
perpetual and irrevocable; (d) the licenses granted to BLI from Ginkgo pursuant to Section 9.2
(Grants to BLI) shall survive; (e) any Licensed Products arising from Collaboration Workflows or
Ginkgo Workflows developed and used by Ginkgo to good effect prior to the effective date of
termination shall be [***] on any sale or transfer of such Licensed Product, (f) (i) for any
Licensed Products arising from Workflows other than those set forth in subclause (e) of this Section
13.3.2 (Effects of Termination Based on Ginkgo's Buy-Down Election), Ginkgo shall pay [***] and (ii)
Ginkgo shall pay [***] for as long as one or more Beacon Optofluidic Machines are in operation at
Ginkgo, (g) the pricing terms for Beacon Optofluidic Machines, Consumables, and services (including
Services) shall be consistent with then-current BLI List Prices, and (h) Ginkgo shall pay BLI for
any amounts due for work performed by BLI under and in accordance with this Agreement prior to the
effective date of termination to the extent that BLI cannot reasonably cancel or reallocate such
work.

13.3.3 Effects of Termination Based Upon an Uncured Ginkgo Breach, Insolvency or Extended Force
Majeure Event affecting Ginkgo. In the event that termination is the result of an uncured, material
Ginkgo breach of the Agreement under Section 13.2.1 (Material Breach), for Ginkgo's insolvency
pursuant to Section 13.2.2 (Bankruptcy) or for an Extended Force Majeure Event with respect to
Ginkgo pursuant to Section 14.8 (Force Majeure), then, as of the effective date of termination: (a)
any and all existing Headstart Periods shall immediately be deemed to have accelerated to
conclusion, (b) the restrictions on BLI set forth in Section 6.2.1 (Restrictions on BLI) shall
immediately deemed to have terminated; (c) the licenses granted to BLI from Ginkgo pursuant to
Section 9.2 (Grants to BLI) shall survive, (d) the licenses granted to Ginkgo under Sections
9.1.1(c) (Grants to Ginkgo - Commercial License) and 9.1.2 (License Grant to Page 58 of 85
<!-- page 59 -->
Exploit [***]) shall survive, but shall convert immediately into royalty-bearing licenses as set
forth in subclause (e) hereof, (e) Ginkgo shall to pay to BLI [***]; provided that in the event such
uncured material breach is [***], Ginkgo, at its election to be made on or before the [***] ([***]t
h) day following the effective date of termination (or, if later, within [***] ([***]) days of
learning of the relevant royalties for Licensed Products), may elect, in lieu of royalties, to pay
to BLI [***]; (f) the pricing terms for Beacon Optofluidic Machines, Consumables, and services
(including Services) shall be consistent with then-current BLI List Prices; and (g) Ginkgo shall pay
BLI for any amounts due for work performed by BLI under and in accordance with this Agreement prior
to the effective date of termination or materials ordered prior to the effective date of termination
to the extent that BLI cannot reasonably cancel or reallocate such work or materials.

13.3.4 Effects of Termination Based Upon an Uncured BLI Breach or Insolvency. In the event that
termination is the result of an uncured material BLI breach of the Agreement under Section 13.2.1
(Material Breach) or for BLI's insolvency pursuant to Section 13.2.2 (Bankruptcy), then: (a)
Ginkgo's obligations to pay to BLI the Minimum Cumulative Purchase Commitment under Section 7.2.2(a)
(Contract Year Purchase Targets and Commitments) shall terminate, (b) BLI shall grant royalty-free
status on all Licensed Products developed using the Beacon Platform and no royalties shall be
payable by Ginkgo on any sale or transfer of such Licensed Products, (c) Ginkgo's obligations to pay
to BLI the FOU License Fees pursuant to Section 7.4.1 (License Fees) shall terminate, (d) the
licenses granted to Ginkgo from BLI in Section 9.1.1 (Scope of Grants) and 9.1.2 (License Grant to
Exploit [***]) shall survive [***], (e) the licenses granted to BLI from Ginkgo pursuant to Section
9.2 (Grants to BLI) shall terminate, except with respect to any sublicenses granted by BLI under
Section 9.2.2 for products and processes that were sold, commercialized or performed by BLI or to or
for Third Parties prior to termination, which shall survive and such termination, but only if such
sublicenses were granted in accordance with this Agreement, (f) the pricing terms for Beacon
Optofluidic Machines, Consumables, and services (including Services) set forth in Section 5.2.2
(Pricing - Adjustments) shall survive for a period of [***] from the effective date of termination,
(g) the restrictions on BLI set forth in Section 6.2.1 (Restrictions on BLI) shall survive to the
extent set forth therein and (h) any and all existing Headstart Periods shall survive for their
duration. If any such uncured, material BLI breach is solely due to BLI's material failure to
perform its supply-related obligations under this Agreement, Section 13.4 (Rights in Lieu of
Termination for BLI's Material Breach of Supply Obligations) may apply in Ginkgo's sole discretion.

13.3.5 Effects of Termination Based Upon Ginkgo's Election to Terminate based on a BLI Extended
Force Majeure Event. In the event that termination is elected by Ginkgo based upon an Extended Force
Majeure Event with respect to BLI pursuant to Section 13.2.1 (Force Majeure), then, as of the
effective date of termination: (a) any and all existing Headstart Periods shall survive for their
duration as if this Agreement had not been terminated, (b) the restrictions on BLI set forth in
Section 6.2.1 (Restrictions on BLI) shall survive to the extent set forth therein as if this
Agreement had not been terminated; (c) the licenses granted to Ginkgo from BLI in Section 9.1.1
(Scope of Grants) and 9.1.2 (License Grant to Exploit [***]) shall survive and become perpetual,
irrevocable and, subject to clause (f) of this Section 13.3.2, royalty-free; (d) the licenses
granted to BLI Page 59 of 85
<!-- page 60 -->
from Ginkgo pursuant to Section 9.2 (Grants to BLI) shall survive; (e) any Licensed Products arising
from Collaboration Workflows or Ginkgo Workflows developed or used by Ginkgo to good effect prior to
the effective date of termination shall be royalty-free and no royalties shall be payable by Ginkgo
on any sale or transfer of such Licensed Product; provided that, if [***], if [***], then, in order
for the sale or transfer of Licensed Products arising from Collaboration Workflows or Ginkgo
Workflows developed or used by Ginkgo to good effect prior to the effective date of termination to
be royalty-free, Ginkgo must pay to BLI [***], but Ginkgo will have [***] ([***]) days following the
effective date of termination to decide whether to make such payment to BLI or to pay royalties for
such Licensed Products under subclause (f) of this Section 13.3.5 (Effects of Termination Based Upon
Ginkgo's Election to Terminate based on a BLI Extended Force Majeure Event), (f) (i) for any
Licensed Products arising from Workflows other than as set forth in subclause (e) of this Section
13.3.5 (Effects of Termination Based Upon Ginkgo's Election to Terminate based on a BLI Extended
Force Majeure Event), Ginkgo shall pay [***] and (ii) Ginkgo shall pay [***]; provided that, if
[***], then [***], (g) the pricing terms for Beacon Optofluidic Machines, Consumables, and services
(including Services) shall be consistent with then-current BLI List Prices and (h) Ginkgo shall pay
BLI for any amounts due for work performed by BLI under and in accordance with this Agreement prior
to the effective date of termination to the extent that BLI cannot reasonably cancel or reallocate
such work.

13.3.6 Non-Limitation of Remedies. Nothing in this Section 13.3 (Effects of Expiration and
Termination) limits or precludes any other remedies available to a Party, including for example, the
seeking and obtaining of injunctive relief.

13.3.7 Annual Royalty Update. The Parties hereby acknowledge that, if this Agreement is terminated,
then, depending on the manner of termination, Ginkgo may, as more fully set forth in Section 13.3
(Effects of Termination), be required to pay royalties to BLI with respect to Licensed Product,
which royalties will be in line with BLI's then-standard commercial terms. In order for Ginkgo to
more fully understand the royalty that may be owed to BLI in the event this Agreement is terminated,
on an annual basis, starting at the end of the [***] Contract Year, BLI will provide Ginkgo, in
writing, its then-current commercial terms with respect to royalties for the Licensed Products.

13.4 Rights in Lieu of Termination for BLI's Material Breach of Supply Obligations. In the event
that Ginkgo has the right to terminate this Agreement under Section 13.2.1 (Material Breach) due to
a material breach of BLI to perform its supply-related obligations under this Agreement (for
clarity, this shall not include (a) [***] or (b) [***], Ginkgo may elect by written notice to BLI
to, instead of terminating this Agreement, keep this Agreement and, without limiting any other right
or remedy under Applicable Law or this Agreement, to decrease the amount of the Minimum Cumulative
Purchase Commitment for the current and future Contract Years, as well as the Full Purchase Target,
in each case in amounts reasonably mutually agreed upon by the Parties in good faith in accordance
with this Section 13.4 (Rights in Lieu of Termination for BLI's Material Breach of Supply
Obligations). Following any notice by Ginkgo to BLI under this Section 13.4 (Rights in Lieu of
Termination for BLI's Material Breach of Supply Obligations), the Parties shall (i) discuss and
implement in good faith a plan to address the supply breach by BLI and shall discuss in good faith
potential approaches to prevent such breach from reoccurring, including a Page 60 of 85
<!-- page 61 -->
modification to Ginkgo's forecasts and BLI's obligation to meet a certain percentage of such
forecasts and (ii) discuss and implement reductions to the Minimum Cumulative Purchase Commitment
for the current and future Contract Years, as well as reductions to the Full Purchase Target, which
reductions will be made based on [***].

13.5 Determination of Use of Workflow to Good Effect. In the event the Parties disagree as to
whether a Collaboration Workflow or Ginkgo Workflow has been developed and used by Ginkgo to good
effect prior to termination pursuant to Section 13.3.2 (Effects of Termination Based Upon Ginkgo's
Buy-Down Election) or Section 13.3.5 (Effects of Termination Based upon Ginkgo's Election to
Terminate based on a BLI Extended Force Majeure Event), with respect to each, at either Party's
request, the dispute shall be resolved in an accelerated manner by an Expert Panel subject to the
process and cost allocation set forth in Section 3.5.3.

13.6 Surviving Provisions. In addition to this Section 13.6 (Surviving Provisions), the following
Sections and Articles will survive Expiration and any termination of this Agreement: Article 1
(Definitions), Section 2.2.3 (Retooling and Development Costs) (solely with respect to (i) [***] and
(ii) [***]), Section 2.4 (Costs Under Workflow Development Plans) (solely with respect to costs
incurred prior to the end of the Term), Section 2.5 (Termination of Workflow Development Plans)
(solely with respect to the effects of termination of a Workflow Development Plan as set forth
therein), Section 2.8 (Records) (solely for [***] ([***]) years following the end of the Term or for
such longer period as required by Applicable Law), Section 3.9 (Expenses) (solely with respect to
expenses incurred prior to the end of the Term), Section 4.1.10 (solely to the extent the BLI Terms
and Conditions need to survive in order to give effect to the surviving terms of this Agreement),
Section 6.1 (Headstart Period) solely to the extent any Headstart Periods extend beyond the Term)
and further subject to each of Section 13.3.2 (Effects of Termination Based Upon Ginkgo's Buy-Down
Election), Section 13.3.3 (Effects of Termination Based Upon an Uncured Ginkgo Breach, Insolvency or
Extended Force Majeure Event affecting Ginkgo) or Section 13.3.5 (Effects of Termination Based upon
Ginkgo's Election to Terminate based on a BLI Extended Force Majeure Event), as applicable), Section
6.2.1 (Restrictions on BLI) (solely for the [***] ([***]) month period following the end of the
Term), Section 7.5 (Manner of Payments) through Section 7.10 (Late Payments) (solely with respect to
any unpaid amounts that accrued prior to the end of the Term or that accrue at any time under
Section 7.4.2 (Milestone Payments)), Article 8 (Intellectual Property Ownership; Use of Data), but
excluding Section 8.4 (Prosecution and Enforcement Rights), Section 8.5.1 (Disclosure), and Section
8.6 (Notification of New Products; Early Access), Article 10 (Confidentiality), Section 11.5
(Disclaimers), Section 11.6 (No Consequential Damages), Section 11.7 (Liability Limit, Section 12.1
(Indemnification by BLI) through Section 12.3 (Procedure), Section 13.1.2 (Effects of Expiration)
(solely for Expiration of this Agreement and only for [***] ([***]) years for under clause (iii)
thereof), Section 13.3 (Effects of Termination) (solely for termination of this Agreement), Section
13.5 (Determination of Use of Workflow to Good Effect), Section 14.5 (Governing Law; Dispute
Resolution; Equitable Remedies), Section 14.9 (Further Assurances) and Section 14.15
(Interpretation). 14. MISCELLANEOUS

14.1 Notice. Any notice given under this Agreement must be in writing and delivered either to the
addresses set forth below in person or via overnight courier (or to such other addresses Page 61 of
85
<!-- page 62 -->
of which the Parties may from time to time be notified in writing) and each such notice will be
effective upon actual receipt:

If to Ginkgo:

Ginkgo Bioworks, Inc. 27 Drydock Avenue, 8th Floor Boston, MA 02210 Attn: [***]

With a copy to:

Ginkgo Bioworks, Inc. 27 Drydock Avenue, 8th Floor Boston, MA 02210 Attn: [***]

with an electronic copy to [***]

With a copy to:

[***]

If to BLI:

Berkeley Lights, Inc. 5858 Horton Street, Suite 320 Emeryville, CA 94608 Attn: [***]

With a copy to:

Berkeley Lights, Inc. 5858 Horton Street, Suite 320 Emeryville, CA 94608 Attn: [***]

With an electronic copy to: [***]

With a copy to:

[***]

Such notice will be deemed to have been given as of the date delivered by hand or on the second
business day (at the place of delivery) after deposit with an internationally recognized overnight
delivery service.

14.2 Independent Contractors. It is understood that both Parties hereto are independent contractors
and are engaged in the operation of their own respective businesses, and neither Party is to be
considered the agent of the other. Neither Party has any authority to enter into any contracts or
assume any obligations for the other. Page 62 of 85
<!-- page 63 -->
14.3 Severability. If any provision of this Agreement is held illegal, invalid or unenforceable by a
court of competent jurisdiction, such decision will in no way affect the validity or enforceability
of any other provisions, which will remain in full force and effect, and the Agreement will be
interpreted as if such provision were not included in this Agreement; provided that the Parties will
negotiate in good faith an amendment to this Agreement that replaces the unenforceable provision
with an enforceable provision (to the extent possible) that reflects their initial intent.

14.4 Assignment.

14.4.1 Permitted Assignments. Neither Party may assign or otherwise transfer this Agreement or any
rights hereunder, without the prior written consent of the other Party; provided that either Party
may assign or otherwise transfer this Agreement or any rights hereunder (a) to a wholly-owned
subsidiary of such Party or (b) in connection with the transfer or sale of all or substantially all
of the business or assets of such Party related to the subject matter of this Agreement, whether by
merger, consolidation, divestiture, restructure, sale of stock sale of assets or otherwise its
successor, whether in a merger, sale of stock or sale of assets or any other transaction, in each
case (a)-(b), without first obtaining the prior written consent of the other Party, so long as the
non-assigning Party is notified in writing of such assignment within [***] ([***]) days following
such assignment; provided further that, in no event may BLI assign this Agreement, in whole or in
part, to any Person [***] without first obtaining Ginkgo's prior written consent. Any purported
assignment of this Agreement by a Party in contradiction to this Section 14.4 (Assignment) will be
void and of no effect.

14.4.2 Transferee. Notwithstanding anything to the contrary set forth herein, if a Party (the
"Assigning Party") assigns or transfers this Agreement to a permitted Third Party pursuant to
Section 14.4.1 (Permitted Assignments) (any such Third Party, a "Transferee"), then the Intellectual
Property that was held or developed by such Transferee prior to or after such assignment or transfer
(other than Intellectual Property developed by such Transferee in the course of conducting the
Assigning Party's activities under this Agreement to the extent such Intellectual Property would
have been so included had it been discovered, created, made, developed, conceived or reduced to
practice by such Assigning Party) shall not be deemed to be Intellectual Property Controlled by such
Assigning Party, and shall also not be affected or otherwise encumbered in any manner, including
without limitation, by being subject to any rights of or licenses under this Agreement. Furthermore,
such Transferee (and Affiliates of such Transferee: (i) existing immediately prior to such merger,
acquisition, assignment or transfer; or (ii) formed on or after such merger, acquisition, assignment
or transfer, which are not controlled by (as defined under the Affiliate definition in Section 1.2
("Affiliate" definition)) the Assigning Party) shall be excluded from the Affiliate definition for
purposes of determining Intellectual Property that is subject to this Agreement. Page 63 of 85

14.5 Governing Law; Dispute Resolution; Equitable Remedies.
<!-- page 64 -->
14.5.1 Governing Law. This Agreement will be construed and interpreted in accordance with the laws
of the State of Delaware, without regard to any choice of law provision.

14.5.2 Dispute Resolution. Except with respect to those disputes in which a Party seeks equitable
relief pursuant to Section 14.5.3 (Equitable Remedies) or for which a Party or Person is expressly
given final decision-making authority as set forth in Section 3.5 (Decision-Making), the Parties,
through their Senior Officers, will make a good faith effort to settle any disputes that may arise
between them with respect to this Agreement. If the Parties do not settle the matter within [***]
([***]) days after the delivery by one Party of written notice (the "Arbitration Notice") to the
other Party involved, then the Parties will submit the matter to binding arbitration in Wilmington,
Delaware. All matters so submitted to arbitration will be settled by three (3) arbitrators in
accordance with the [***], or its successor (the "[***] Rules"). In the event of a conflict between
[***] Rules and this Agreement, this Agreement shall govern. Each Party will designate an arbitrator
and the Parties will cause the designated arbitrators to mutually agree upon and to designate a
third arbitrator who will serve as chairperson; provided, however, that failing such agreement
within [***] ([***]) days of delivery of the Arbitration Notice, the third (3rd) arbitrator will be
appointed in accordance with [***] Rules within an additional [***] ([***]) days. The Parties shall
arrange for a hearing to occur and be completed within [***] ([***]) days after the appointment of
the third (3rd) arbitrator, which hearing shall last no longer than [***], unless the arbitral panel
believes a longer period is required, in which case the hearing may last [***]. The Parties will
cause the arbitrators to decide the matter to be arbitrated within [***] ([***]) days after the
close of evidence unless the chairperson arbitrator determines, at the request of any Party or on
his or her own initiative, that such time period should be extended, in which case such time period
may not be extended beyond an additional [***] ([***]) day period. Each of Ginkgo and BLI will be
permitted to serve one set of document production requests with no more than [***] ([***]) requests;
no more than [***] ([***]) interrogatories, including subparts, no more than [***] ([***]) requests
for admissions; no more than [***] ([***]) subpoenas to Third Parties; and no more than [***]
([***]) notices of deposition per side, in each case, unless the arbitral panel directs otherwise.
Any documents not in English that are produced by a Party will be accompanied by a translation into
English, which translation will not be binding upon the other Party or the arbitrators. Each Party
covenants and agrees that (a) it will produce documents as required by this Section 14.5.2 (Dispute
Resolution), and (b) it will make its employees, and will use commercially reasonable efforts to
make its former employees, available for depositions and hearing testimony as requested by the other
Party. The final decision of the majority of the arbitrators shall be in writing, in all events
follow governing law and will be furnished to all the Parties in such dispute. Judgment on such
decision may be entered in any court having jurisdiction. Such decision may be used in a court of
law only for the purpose of seeking enforcement of the arbitrators' award. Except as required by
Applicable Law or to enforce an arbitrators' award, neither Party may disclose the existence,
contents or results of an arbitration brought in accordance with this Agreement, or the evidence
produced by its opposing Parties, or any analysis or summaries derived from such evidence. The
Parties agree that all applicable statutes of limitation and Page 64 of 85
<!-- page 65 -->
time-based defenses (such as estoppel and laches) will be tolled while the procedures set forth in
this Section 14.5.2 (Dispute Resolution) are pending. The Parties will cooperate in taking any
actions necessary to achieve this result. Except as may be determined by the arbitrators, neither
Party shall be penalized for delays resulting from dispute resolution conducted pursuant to this
Section 14.5.2 (Dispute Resolution).

14.5.3 Equitable Remedies; Single Forum. Notwithstanding any other terms of this Agreement, either
Party may seek a preliminary injunction or other provisional equitable relief in any court of
competent jurisdiction as permitted by Applicable Law. At all times while any claim, action, suit or
other proceeding between the Parties and/or any of their Affiliates (or among the Parties and/or any
of their Affiliates and one or more Third Parties) arising out of or relating to this Agreement is
pending in any court of competent jurisdiction, no dispute that is justiciable and can be joined to
such pending claim, action, suit or other proceeding shall be submitted to arbitration pursuant to
Section 14.5.2 (Dispute Resolution) without both Parties' mutual consent and, instead, either Party
may join such dispute to the pending claim, action, suit or other proceeding by including such
dispute in its pleadings or amending its pleadings. In the event that a motion to amend is required
to achieve such joinder, the non- moving Party shall consent to such motion.

14.6 Entire Agreement; Amendment and Waiver. This Agreement, together with the Exhibits and
Schedules attached hereto, sets forth and constitutes the entire agreement and understanding between
the Parties with respect to the subject matter hereof and all prior agreements, understandings,
promises and representations, whether written or oral, with respect thereto are superseded hereby.
This Agreement may not be amended except by a writing signed by authorized representatives of both
Parties. The failure of a Party at any time or times to require performance of any provision hereof
will in no manner affect its rights at a later time to enforce the same. To be valid, a waiver must
be in writing and signed by an authorized representative of the Party having the right that is
waived or to whom the obligation to be waived is owed.

14.7 English Language. This Agreement will be written and executed in, and all other communications
under or in connection with this Agreement will be in, the English language. Any translation into
any other language will not be an official version thereof, and in the event of any conflict in
interpretation between the English version and such translation, the English version will control.

14.8 Force Majeure. Any delay in the performance of any of the duties or obligations (other than
payment obligations) of either Party hereto caused by a Force Majeure Event (defined below) shall
not be considered a breach of this Agreement and the time required for performance shall be extended
for a period equal to the period of such delay. "Force Majeure Event" shall mean acts of God, acts
of the public enemy, war, terrorism, insurrections, riots, injunctions, embargoes, fires,
explosions, floods, or other unforeseeable causes beyond the reasonable control and without the
fault or negligence of the Party who is so prevented or delayed from fulfilling its obligations
under this Agreement by such Force Majeure Event (the "Affected Party"). The Affected Party shall
give prompt written notice to the other Party of such cause and shall take whatever reasonable steps
are appropriate in the other Party's discretion to relieve the effect of such cause as rapidly as
possible. The Party not directly affected by the Force Majeure Event shall have the right to
terminate this Agreement with written notice effective upon receipt if Force Page 65 of 85
<!-- page 66 -->
Majeure Event continues to prevent performance or compliance in any material respect by the other
Party for a period of more than [***] ([***]) days or should [***] ([***]) Force Majeure Events
apply to the performance of such other Party during any [***] (each a "Extended Force Majeure
Event").

14.9 Further Assurances. Each Party will duly execute and deliver, or cause to be duly executed and
delivered, such further instruments and do and cause to be done such further acts and things,
including the filing of such assignments, agreements, documents, and instruments, as may be
necessary or as the other Party may reasonably request in connection with this Agreement or to carry
out more effectively the provisions and purposes hereof, or to better assure and confirm unto such
other Party its rights and remedies under this Agreement.

14.10 Third Party Beneficiaries. There are no Third Party beneficiaries under this Agreement, except
to the extent a Third Party is indemnified pursuant to Article 12 (Indemnification; Insurance);
provided that, in no event will any Third Party entitled to indemnification pursuant to Article 12
(Indemnification; Insurance) be allowed to enforce the terms thereof against a Party.

14.11 Export Control. This Agreement is made subject to any restrictions concerning the export of
products or technical information from the United States or other countries which may be imposed
upon the Parties from time to time. Each Party agrees that it will not export, directly or
indirectly, any technical information acquired from the other Party under this Agreement or any
products using such technical information to a location or in a manner that at the time of export
requires an export license or other governmental approval, without first obtaining the applicable
license, approval, or written consent to do so from the appropriate agency or other governmental
entity.

14.12 References. Unless otherwise specified, (a) references in this Agreement to any Article,
Section, Exhibit or Schedule will mean references to such Article, Section, Exhibit or Schedule of
this Agreement, (b) references in any Section to any clause are references to such clause of such
Section and (c) references to any agreement, instrument or other document in this Agreement refer to
such agreement, instrument or other document as originally executed or, if subsequently amended,
replaced or supplemented from time to time, as so amended, replaced or supplemented and in effect at
the relevant time of reference thereto.

14.13 Attachments. In the event of any inconsistencies between this Agreement and any Exhibits,
Schedules or other attachments hereto, the terms of this Agreement will control, unless the relevant
Exhibit, Schedule or other attachment explicitly references its inconsistency with this Agreement
and states that it shall control.

14.14 Non-Solicit. Neither Party will, [***], directly or indirectly with or through any Person,
solicit for employment any Person who is an employee of the other Party; provided, however, that
general solicitation of the public for employment shall not constitute a solicitation hereunder so
long as such general solicitation is not designed to target any such Person. In the event that a
Party solicits and then hires an employee of the other Party in violation of this Section 14.4
(Non-Solicit), the hiring Party shall, [***], within [***] ([***]) days of such hire, pay the other
Party an amount equal to the [***] cash compensation actually paid to the individual Page 66 of 85
<!-- page 67 -->
([***]) by the non-hiring Party in the immediately prior calendar year and, further, if the
individual solicited and then hired in violation of this is a Key Person under Section 5.4.1(b)
(Dedicated FTEs; Key Persons), then BLI shall have [***] ([***]) months to identify an employee as
the individual to replace such Key Person and any (a) [***] or (b) [***], in each case (a)-(b), to
the extent due to the absence of such Key Person performing a Workflow Development Plan upon which
the Key Person was engaged, shall be deemed waived for that [***] month period.

14.15 Interpretation. All headings are for convenience only and will not affect the meaning of any
provision of this Agreement. The Parties acknowledge that each Party has read and negotiated the
language used in this Agreement. Because both Parties participated in negotiating and drafting this
Agreement, no rule of construction will apply to this Agreement which construes ambiguous language
in favor of or against either Party by reason of that Party's role in drafting this Agreement.
Except where the context expressly requires otherwise, (a) the use of any gender herein will be
deemed to encompass references to either or both genders, and the use of the singular will be deemed
to include the plural (and vice versa), (b) the words "include," "includes" and "including" will be
deemed to be followed by the phrase "without limitation," whether or not so appearing herein, (c)
the word "will" will be construed to have the same meaning and effect as the word "shall," (d) any
reference herein to any Person will be construed to include the Person's successors and permitted
assigns, (e) the words "herein," "hereof" and "hereunder," and words of similar import, will be
construed to refer to this Agreement in its entirety and not to any particular provision hereof, (f)
references to any Applicable Law, rule or regulation, or article, section or other division thereof,
will be deemed to include the then-current amendments thereto or any replacement or successor
Applicable Law, rule or regulation thereof and (g) the term "or" will be interpreted in the
inclusive sense commonly associated with the term "and/or."

14.16 Counterparts. This Agreement may be executed in one or more counterparts, each of which, when
executed and delivered by facsimile, electronic transmission or by mail delivery, will be deemed an
original and all of which will constitute one and the same instrument.

[Signature Page Directly Follows] Page 67 of 85
<!-- page 68 -->
IN WITNESS WHEREOF, the Parties hereto have caused this Agreement to be executed as of the Effective
Date by their respective duly authorized representatives. GINKGO BIOWORKS, INC. BERKELEY LIGHTS,
INC.

By: /s/ Barry Canton By: /s/ Keith Breinlinger Name: Barry Canton Name: Keith Breinlinger Title: CTO
Title: CTO
<!-- page 69 -->
SCHEDULE 1.10

Beacon Optofluidic Machine Specifications

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)
<!-- page 70 -->
SCHEDULE 1.18

BLI Terms and Conditions

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)

SCHEDULE 1.21
<!-- page 71 -->
Buy-Down Examples

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)
<!-- page 72 -->
SCHEDULE 1.36

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)
<!-- page 73 -->
SCHEDULE 1.62

FTE Rate

$[***] USD per year* * All FTEs (Hardware, Software, Program Manager, FAS, etc.) will be billed to
Ginkgo at this rate. For periods of less than 1 year, billing will be pro-rated based on time. [***]
<!-- page 74 -->
SCHEDULE 1.92

Lead Time

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)

SCHEDULE 1.104
<!-- page 75 -->
OptoSelect Chips

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)
<!-- page 76 -->
SCHEDULE 1.107

Performance Service Plan

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)
<!-- page 77 -->
SCHEDULE 2.2.2

Initial Workflow Development Plans

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)

SCHEDULE 5.2.1
<!-- page 78 -->
Pricing Schedule

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)
<!-- page 79 -->
SCHEDULE 5.3.3

Qualification Standards

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)
<!-- page 80 -->
SCHEDULE [***] 1. [***]
<!-- page 81 -->
SCHEDULE 10.5

Draft Press Release - Subject to further changes by Both Parties

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)
<!-- page 82 -->
EXHIBIT A

Workflow Development Plans

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)
<!-- page 83 -->
EXHIBIT B

Outline of First Two (2) Initial Workflow Development Plans

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)
<!-- page 84 -->
EXHIBIT C

GINKGO BIOWORKS, INC. AGREEMENT CONCERNING RECEIPT OF AND ACCESS TO GINKGO PROPERTY AND CONFIDENTIAL
INFORMATION

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)
<!-- page 85 -->
EXHIBIT D

BLI Proprietary Workflows for Section 7.4.2

Intentionally omitted pursuant to Regulation S-K, Item 601(a)(5)
