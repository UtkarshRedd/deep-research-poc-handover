<!-- page 1 -->
# JOINT VENTURE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture Agreement |
| Agreement Date | 2001-05-18 |
| Parties | IMPCO Technologies Inc. including its successors and permitted assigns ("IMPCO"); MINDA INDUSTRIES LIMITED including its successors and permitted assigns ("MIL"), Nirmal K. MINDA including his heirs, executors, administrators or successors and permitted assigns ("MINDA") |
| Source | CUAD v1 / IMPCOTECHNOLOGIESINC_04_15_2003-EX-10.65-JOINT VENTURE AGREEMENT |

Exhibit 10.65 JOINT VENTURE AGREEMENT MINDA IMPCO TECHNOLOGIES LIMITED This Joint Venture Agreement
(Agreement) is made and executed on this the 18th day of May, 2001 BETWEEN IMPCO Technologies Inc.,
a company incorporated under the laws of the State of Delaware U.S.A. and having its principal
office of business at 16804 Gridley Place, Cerritos, California 90703, U.S.A. (hereinafter referred
to as 'IMPCO', which terms shall unless repugnant to the subject or context mean and include its
successors and permitted assigns), through Ms. Pearl Kamdar a duly authorized person and Director of
Asia-Pacific Operations, AND MINDA INDUSTRIES LIMITED, a company incorporated under the Companies
Act, 1956 having its registered office at 36-A, Rajasthan Udyog Nagar, Delhi-110 033, India,
(hereinafter referred to as 'MIL', which terms shall unless repugnant to the subject or context mean
and include its successors and permitted assigns), through Mr. Nirmal K. Minda its Managing
Director, AND Mr. Nirmal K. MINDA, s/o. Mr. S.L. Minda, r/o. A-15, Ashok Vihar, Phase-I, New
Delhi-110 052 on in his individual capacity and on behalf of his relatives and associates listed in
Schedule-I (hereinafter referred to as 'MINDA', which terms shall unless repugnant to the subject or
context mean and include his heirs, executors, administrators or successors and permitted assigns).
WHEREAS IMPCO is engaged in the business of development, manufacture and sale of alternate fuel
management systems and components for operating motor vehicles, forklifts, industrial engines and
other engines of various horsepower; and WHEREAS MIL is engaged in the manufacturing and sale of
auto electrical parts such as switches, lamps and horns; and WHEREAS IMPCO and MIL/MINDA have
entered into a joint venture to promote a company under the name of MINDA IMPCO LIMITED for
manufacturing and selling alternate fuel management systems and components, including but not
limited to CNG, LPG and Propane Kits for operating motor vehicles, forklifts, industrial engines and
other engines of various horsepower in India ; and WHEREAS, MIL represents that it has the
technical, marketing skills and financial wherewithal to install, sell and service the alternate
fuel systems and components manufactured by MINDA IMPCO Limited and enjoys a respected business
relationship with 1
<!-- page 2 -->
cognizant governmental and industrial authorities, all of which may be advantageously employed in
the safe and professional marketing of MINDA IMPCO Limited products, as specified above, in India
with the approval of and in compliance with such governmental authorities; and WHEREAS the Parties
hereto have agreed, subject to obtaining all necessary approvals, permissions, consents,
validations, confirmations, licenses and any other authorizations required to incorporate a company
in India ("the Joint Venture Company" or the "JVC") with the main object of inter alia marketing and
selling of alternate fuel management systems, including but not limited to CNG, LPG and Propane Kits
and its components for automobiles and other associated and incidental services to customers; and
WHEREAS IMPCO will contribute to the JVC in cash and the JVC will issue equity shares to IMPCO; and
WHEREAS MIL/MINDA will contribute to the JVC in cash and subject to IMPCO's consent in kind and the
JVC will issue equity shares to MIL/MINDA; and WHEREAS the Parties hereto are ready, willing and
able to assist each other and cooperate in the manner set out hereinafter, to ensure the
establishment and success of the JVC. The Parties shall cooperate with each other in the highest
degree in the performance of all such acts and the passing of all resolutions as are required for
the purpose of achieving the terms, purposes and intent of this Agreement and the Parties shall in
particular exercise their respective voting and other rights and power of control over the JVC so as
to give effect to the rights conferred upon the respective Parties by the terms of this Agreement.
NOW THEREFORE in consideration of the mutual promises and covenants hereby contained, this Agreement
witnesses and the Parties hereto have agreed as follows: 2
<!-- page 3 -->
ARTICLE - 1 DEFINITIONS 1.1 In this Agreement, unless the context otherwise requires, the following
shall have the meaning as set forth against them below: "Act" shall mean the Companies Act, 1956,
and includes, where the context so requires, any re-enactment or statutory modifications thereof for
the time being in force. "Affiliate(s)" shall mean with respect to any Party to this Agreement any
entity which controls, is controlled by, or is under common control with such Party. An entity
controls another entity when it owns or controls, directly or indirectly, fifty-one percent (51%) or
more of the equity share capital issued and outstanding of the other entity or when it controls, on
its own or jointly, the majority of the composition of the Board of Directors of such other entity.
"Agreement" or "this Agreement" shall mean this joint venture Agreement, alongwith all attachments
annexed hereto, and shall include any subsequent modifications, alterations and additions and
deletions therefrom made in writing after the date of execution of this Agreement. "Approval(s)"
shall mean all government, statutory and/or regulatory permissions, consents, validations,
confirmations, licenses and any other authorizations required to be obtained in order to implement
the provisions of this Agreement including, but not limited to, all necessary approvals of the
Government of India and the Reserve Bank of India. "Articles" or "Articles of Association" shall
mean the Articles of Association of the MINDA IMPCO Technologies Limited. "Alternate Director" shall
mean an Alternate Director appointed in terms of Article 3.7 herein to act for a Director during his
absence for a period of not less than three (3) months from the State in which the registered office
of the JVC is situated and such Alternate Director shall not hold office as such for a period longer
than that permissible to the Director in whose place the Alternate Director has been appointed and
shall vacate office when the Director returns to such State. "Financial Institutions" shall mean
Indian financial institutions, including but not limited to, ICICI, Industrial Development Bank of
India, Industrial Finance Corporation of India and shall also include foreign financial
institutions. "Joint Venture Company" or "the JVC" shall mean the Indian company to be established
and incorporated under the laws of India pursuant to the terms of this Agreement and, subject to the
approval of the Registrar of Companies, Delhi and Haryana, with the name "MINDA IMPCO Technologies
Limited" or such other name as may be agreed by the Parties, with the main object of, inter alia,
marketing and selling of alternate fuel management systems, including but not limited to, CNG, 3
<!-- page 4 -->
LPG and Propane Kits and its components for automobiles and other associated and incidental services
to customers. "Memorandum" or "Memorandum of Association" shall mean the Memorandum of Association
of the MINDA IMPCO Technologies Limited. "Products" shall mean alternate fuel management systems,
including but not limited to, CNG Kits, Propane Kits and its components for automobiles to be
marketed and sold by the JVC, adopting the existing, as well as future development(s) in the
technical know-how of IMPCO, as per terms of the Technical Assistance Agreement and any other
products as may be mutually agreed from time to time by the Parties to this Agreement. "Effective
Date" shall mean the date on which the Parties sign and execute this Agreement . "Board" or "Board
of Directors" shall mean the Board of Directors MINDA IMPCO Technologies Limited. "Parties" shall
mean IMPCO, MIL and MINDA collectively, and the term "Party" shall individually refer to IMPCO, MIL
and/or MINDA, as the case may be. "RBI" shall mean the Reserve Bank of India. "Technical Know-How"
shall mean available secret, specialized and proprietary know-how, technical information, drawings,
data, charts, graphs, procedure books, operation manuals and data, technical processes and other
technical literature including but not limited to information of the type listed on Appendix A to
the TAA, tangible or intangible, necessary for manufacture and testing of the Products which (i) is
possessed and controlled by IMPCO at the date of this Agreement and (ii) IMPCO has the right to
grant licenses to MINDA-IMPCO LTD. during the term of this Agreement. "Territory" shall mean the
geographical area under the jurisdiction of the Government of the Republic of India. 1.2
Interpretation: In this Agreement, unless the contrary intention appears, a reference to: i) an
"amendment" includes a supplement, novation, replacement or re-enactment and "amended" is to be
construed accordingly; ii) "assets" includes properties (both present and future and whether
tangible or intangible and including Intellectual Property and Intellectual Property Rights),
revenues, investments, cash flows, rights, benefits, interests and titles of every description; iii)
an "authorisation" includes an authorisation, consent, clearance, approval, resolution, license,
permit, exemption, filing, registration or notarisation; 4
<!-- page 5 -->
iv) "control" means: (a) the ability to appoint more than one half of the members of the board of
directors or board of management (howsoever described) of an entity or to control more than 50 per
cent of the voting rights of the members of such board; or (b) the power to direct or cause the
direction of the management and policies of an entity, whether through the ownership of voting
capital, by contract, laws and regulations or otherwise; v) a "law" includes any constitution,
statute, law, rule, ordinance, judgment, order, decree, authorisation, or any published directive,
guideline, requirement or governmental restriction having the force of law, or any determination by,
or interpretation of any of the foregoing by any judicial authority, whether in effect as of the
date of this Agreement or thereafter and each as amended or re-enacted from time to time; vi) a
"month" is a reference to a period starting on one day in a calendar month and ending on the date
immediately before the numerically corresponding day in the next calendar month, except that if
there is no numerically corresponding day in the month in which that period ends, that period shall
end on the last day in that calendar month; vii) a "person" includes:

a) any individual, corporation, partnership, joint venture, association of persons, trust,
unincorporated organisation, government (central, state or otherwise), sovereign state (or any
agency, department, authority or political subdivision thereof), international organisation, agency,
authority or other entity (in each case whether or not having separate legal personality) and
includes any of its successors, transferees and assigns and, in particular: b) in the case of an
individual, any legal representative, administrator, executor and heir of that individual; and c) in
the case of a trust, any trustee of that trust; viii) a "regulation" includes any applicable
regulation, rule, official directive, order, decree, request, guideline, requirement or restriction
(whether or not having the force of law but if not, being of a kind with which it is customary for
companies within the relevant industry to comply) of any governmental, inter-governmental or ,
agency, department or regulatory, self-regulatory or other authority or organisation, each as
amended or re-enacted from time to time; ix) a clause, a schedule or an annex is a reference to a
clause of or a schedule or annex to this Agreement; x) a schedule, an appendix or an annex to or of
a document forms an integral part of that document; 5
<!-- page 6 -->
xi) the singular includes a reference to the plural (and vice versa); xii) the masculine includes a
reference to the feminine and neuter; xiii) a time of day is a reference to Indian Standard Time.;
xiv) the term "including", "include" or "includes" shall be deemed to be followed by the phrase "but
not limited to"; xv) the index to and the headings in this Agreement are for convenience only and
are not to be relied upon in construing this Agreement. ARTICLE - 2 INCORPORATION OF JVC AND ITS
SHARE CAPITAL 2.1 The Parties hereby agree to incorporate the JVC in accordance with the laws of
India for the purpose of marketing and selling the Products. Subject to the approval of the
Registrar of Companies, Delhi and Haryana, the name of the company will be 'MINDA IMPCO Technologies
Limited' or such other name as may be agreed by the Parties. MINDA will take all necessary steps for
the incorporation of MINDA-IMPCO Technologies Limited. 2.2 It is further agreed between the Parties
that in order to fulfill the requirement of a minimum of seven (7) shareholders under the Act, the
Memorandum and Articles of Association (hereinafter referred to as "M&A") of the JVC shall be
subscribed to by seven (7) subscribers. 2.3 All reasonable costs, fees and other expenses necessary
for the incorporation of the JVC, such as registration fee etc., excluding any legal fees, shall be
paid by MIL and will be reimbursed by the JVC upon ratification by a resolution of the Board of
Directors of the JVC. 2.4 The principal activities of the JVC shall be carried out in accordance
with its object clause incorporated in the Memorandum and Articles of Association (M&A). 2.5 The
initial authorized capital of the JVC shall be Rs. 5,00,000/- (Rs. Five lacs only) divided into
50,000 equity shares of the nominal value of Rs. 10 each. The initial seven (7) subscribers shall
collectively subscribe to 50,000 equity shares of face value of Rs. 10 each. 2.6 Subject to the
approval of the Government of India (`GOI'), Reserve Bank of India (`RBI') and other Government
agencies, if any, the shares in the JVC shall be issued to the Parties in the following percentage
of the total paid-up capital of the JVC. MIL, MINDA and its associates - 40% - In cash and /or in
Kind. IMPCO - 60% - In cash 6
<!-- page 7 -->
In consideration thereof, the JVC will issue equity shares either at par or at premium as mutually
agreed by the Parties. 2.7 Subject to regulatory approvals, if any, and the provisions of the Act,
the issue, transfer and/or transmission of shares or any other dealing with the shares of the JVC,
shall be in the manner prescribed in the M&A. 2.8 (a) If in future the Parties agree that it is
necessary for the JVC to raise finances by loans and/or equity or otherwise, the Board of the JVC
shall decide the mode of contribution ( cash or kind ) and the extent of debt and equity. All
capital contributions will be made by the Parties in proportion to their shareholding as mentioned
in Article 2.6. In the event a Party fails to make its respective capital contribution to such
extent, the other Party ('Acquiring Party') shall have the right to make additional capital
contributions to such extent . The Party who failed to make contribution of additional capital shall
provide full cooperation and assistance to the Acquiring Party in obtaining government and
regulatory approvals, if any, and in executing necessary documents, including consents and no-
objection certificates as may be required. In case finances are to be raised by way of loans, the
Parties agree to take necessary steps to arrange for the same, including execution of corporate
guarantees in favor of Financial Institutions, as and when required.

(b) In future, subject to the terms of this Agreement and the M&A, if the share capital of the JVC
increases as a result of issue of shares to a third party or to the public, the Parties hereto shall
acquire shares of the JVC in the same proportion as mentioned in Article 2.6 or as otherwise
mutually agreed in writing by them. It is understood that in case of a public issue of equity shares
of the JVC, the percentage shareholding of MIL/MINDA and IMPCO will be reduced to the extent of
additional shares allotted to the public. Provided, however, that in such a case the Parties hereto
shall endeavor to avoid any substantial dilution of their collective control over the JVC. (c) Issue
of shares in the JVC to IMPCO shall be after taking the requisite approval of RBI and/or other
regulatory authorities if any. ARTICLE - 3 MEMORANDUM & ARTICLES OF ASSOCIATION OF THE JVC AND
GOVERNANCE OF JVC 3.1 The M&A shall be in accordance with the law for the time being in force in
India. Those provisions of this Agreement which are in conformity with the Act, shall be reflected
in the M&A. 3.2 The Parties agree that the M&A shall, inter alia, to the extent possible and as
permitted by law, incorporate and reflect the understanding contained in this Agreement and the
Parties expressly agree that whether or not the M&A fully incorporates the stipulations hereof, or
any of them, the Parties' rights and 7
<!-- page 8 -->
obligations inter se shall be governed by this Agreement which shall also prevail in the event of
any ambiguity or inconsistency between the two documents. 3.3 Unless otherwise agreed, between the
Parties, the Board of Directors of the JVC shall consist of not less than five (5) and not more than
twelve (12) Directors, including the Managing Director (MD). Out of the minimum number of five (5)
Directors, the Parties shall be represented in the ratio of 3 : 2, i.e., three (3) Directors shall
be nominated by IMPCO and two (2) Directors shall be nominated by MIL and MINDA The Directors
nominated by MINDA and MIL will be referred as MINDA Directors and Directors nominated by IMPCO will
be referred as IMPCO Directors. Subject to the terms of this Agreement, the representation of
MIL/MINDA and IMPCO on the Board of the JVC shall always be maintained in the above mentioned ratio
and IMPCO will always have a majority on the board. It is further agreed that the first four (4 )
Directors of the JVC shall be nominated by IMPCO . 3.4 a) IMPCO shall designate one (1) of its
Directors as the Managing Director ('MD') of the JVC in accordance with the provisions of the Act.
The MD shall have substantial powers of management of the JVC, subject to the supervision and
control of the Board. b) The other Directors will hold appropriate positions in the JVC, as may be
decided by the Board. 3.5 Subject to the supervision and control of the Board, the MD shall be
in-charge of all day to day management of the JVC, including but not limited to all aspects of
marketing, operations, sales promotion,, after sales services, personnel, employment or termination
as well as remuneration of key executives, personnel, information services, customer services,
marketing and sales, accounting, finance and credit collections. The MD and such other Director(s)
shall conduct the business and the management operations of the JVC and the MD may, in writing,
authorize officers in this behalf. 3.6 The remuneration of the MD and/or other whole time
Director(s) shall be fixed and may be varied from time to time by the Board within the limits
prescribed under the Act/Guidelines issued by the Government of India and subject to the approval of
the shareholders and of the appropriate authorities. 3.7 a) In the event an IMPCO Director
(hereinafter called "Original IMPCO Director") is away for a continuous period of not less than
three (3) months from the State in which the registered office of the JVC is located, the IMPCO
Director shall, during his absence, nominate a person to act as an Alternate Director on behalf of
the Original Director. The Alternate Director shall not hold office for a period longer than that
permissible to the Original IMPCO Director in whose place he has been appointed. 8
<!-- page 9 -->
b) If the term of office of the Original IMPCO Director is determined before he so returns to the
State as aforesaid, any provision for the automatic re- appointment of retiring Director, in default
of another appointment, shall apply to the Original IMPCO Director and not to the Alternate
Director. 3.8 The Parties to this Agreement shall at all times co-operate, act and vote at all
meetings in support of the election of the nominee Directors to the Board. ARTICLE - 4 GENERAL
MEETINGS 4.1 The JVC shall hold the General Meeting in the manner prescribed in the Act and the
Articles. The remuneration payable to the, Managing or whole-time Directors and Managers shall be
determined, in accordance with and subject to the provisions of the Act. 4.2 The quorum for a
General Meeting shall be five (5) members present in person or through a duly authorised
representative in case of a member which is a company, provided that there shall be no quorum unless
one (1) representative of IMPCO and one (1) representative of MIL/MINDA is present. If within half
an hour from the time appointed for holding a General Meeting a quorum as specified above is not
present, the General Meeting shall stand adjourned by seven (7) days on the same time and place or
to such other day and such other time as the Board may determine and if at such adjourned General
Meeting a quorum is not present within half an hour from the time appointed for holding the General
Meeting, the members present shall constitute a valid quorum . ARTICLE - 5 BOARD MEETING 5.1 It is
hereby agreed and understood between the parties that the Directors present at the Board meeting
will elect the Chairman of the Board ("the Chairman"), who shall be a IMPCO Director. The Chairman
shall have a second vote or a casting vote as per the provisions of the Act. 5.2 The Board shall
decide all important matters pertaining to the management and administration of the JVC subject to
the provisions of this Agreement, the M&A and the Act. 5.3 The Board meeting shall be convened and
conducted in the manner laid down in the M&A. 5.4 The quorum at and throughout meetings of the
Board, including adjourned meetings, shall be one third of its total strength or two Directors,
whichever is higher, of which at least one will be a MIL/MINDA Director and one will be an IMPCO
Director. Provided that if an MIL/MINDA or an IMPCO Director fails to be present for two consecutive
meetings of the Board as a result of which a meeting of the Board 9
<!-- page 10 -->
cannot be held for want of quorum, then either the three IMPCO or the two MIL/MINDA Directors shall
constitute the requisite quorum. 5.5 All management decisions of the JVC shall require the simple
majority vote of the Board either at a meeting of the Board or by resolution passed by circulation
subject to the provisions of the Article 5.6 Meetings of the Board shall take place in Delhi or such
other place as may be decided by the Board. For calling a Board meeting, a notice of at least
fourteen [14 ] days in advance in writing shall be given to each of the Directors, including those
outside India. However, a meeting of Directors may be called by giving a shorter notice provided it
is mutually agreed by the Directors. Subject to the provisions of the Act, a resolution circulated
and signed by all Directors shall be effective, as a resolution duly passed at a meeting of
Directors. Sitting fees, travel and stay expenses (incurred by the Directors) for attending the
Board meeting, if claimed by the Director(s) shall be met by the JVC as per Articles of Association
of the JVC. 5.6 IMPCO shall at all times be entitled to invite any of its Affiliates, managerial,
technical or financial personnel to attend the Board meetings of the JVC. ARTICLE - 6 TRANSFER OF
SHARES 6.1 (a) Each party hereto agrees not to transfer, sell, pledge, mortgage or make other
disposition (whether by way of fixed or floating charge) or encumbrance on its shares in the JVC
except as otherwise provided in this Agreement and/or except by consent of the Parties to this
Agreement and in the manner laid out in the M&A.

(b) It is agreed that MIL/MINDA may, inter se, transfer their shares in the JVC amongst their
relatives and associates as mentioned in Schedule- I annexed hereto. . (c) No party hereto may
transfer its shares in the JVC for a period of five (5) years from the date of allotment except as
provided above. 6.2 After the expiry of the five (5) year period, if a Party intends to sell any or
all of its shares of the JVC (the "Transferor"), it shall first make an offer by a written notice to
the other Parties (the "Transferee") to purchase such shares and the other Parties shall have the
right to purchase the offered shares in proportion of their existing shareholding. . If any of the
Transferees intends to purchase all or any portion of the said shares so offered, such Party shall
dispatch a written notice of acceptance to the transferor describing the number of the shares it
intends to purchase within three (3) weeks after the date of receipt of the offer. The sale price of
the shares shall be determined in terms of Article 6.3(c) hereof. 10
<!-- page 11 -->
6.3 a) Pursuant to Article 6.2, if a Transferee does not, in whole or in part, accept to purchase
the shares offered in terms of Article 6.2 by the Transferor, the other Transferee may purchase all
the shares offered by the Transferor at a price determined as per Article 6.3(c) hereof. If no
Transferee accepts to purchase the shares offered by the Transferor, in whole or in part, the
Transferor may sell such shares to a third party on terms and conditions no more favourable than
those offered to the Transferees, including the price of the shares.

b) Any transfer of the shares of the JVC to a third party shall be subject to the full unconditional
assumption in writing by such third party of all obligations of the Transferor as provided in
Article 6.4.

c) The transfer of shares, as stated hereinabove, shall be subject to all the regulatory approvals
that may be required in this behalf. Such shares shall be transferred at a price which shall be the
price indicated in the offer notice to the extent the same is in accordance with, the regulations of
the Securities and Exchange Board of India or the Reserve Bank of India, if applicable. 6.4 Transfer
of shares to a Third Party In case of transfer of shares by the Transferor to any third party in
pursuance of the above Articles, the following conditions will apply: i) The third party shall enter
into a deed of adherence agreeing to be bound by the provisions of this Agreement; and ii) The third
party shall not have a conflict of interest and should not be strategically incompatible to the
other Parties to the Agreement. Notwithstanding the restriction on transfer of shares stipulated
hereinabove, IMPCO and MIL/MINDA may transfer any of its holdings in the JVC to an Affiliate,
without requiring the consent of the other Parties, provided that, such an Affiliate shall also be
bound by the provisions of this Agreement and shall execute a deed of adherence as mentioned above.
It is expressly agreed by MINDA and MIL that, in order to give effect to the provisions of Articles
6.4, they shall provide all necessary co- operation to IMPCO, including but not limited to
assistance for obtaining the necessary RBI/FIPB and other regulatory or government approvals.
Further, MINDA and MIL agrees to sign/execute/file any and all documents with the Government of
India or its agencies, departments or any other third party to give effect to any transfer of shares
in accordance with the provisions of this Agreement. 11
<!-- page 12 -->
6.5 Pledge of shares The Parties agree that the shares held by them shall not be pledged to a third
party or otherwise encumbered during the term of this Agreement. In the event the pledge of shares
of any Party is necessitated for the purposes of the JVC, such pledge will be made only with the
prior written consent and on terms acceptable to the other Parties. ARTICLE - 7 BUSINESS ACTIVITIES
7.1 General Purpose: IMPCO and MIL/MINDA have entered into this Agreement for the purpose of
establishing the JVC with the main objects of, inter alia, marketing and selling of the Products and
providing other associated and incidental services to customers, and undertake other activities as
mentioned in its M&A. 7.2 The JVC will be permitted to use the following words in Products which are
manufactured by MINDA IMPCO Limited. "Manufactured by MINDA IMPCO Limited, an Indo American Joint
Venture". Subject to the provisions of this Agreement, all products, will carry the trademark of
MINDA IMPCO. ARTICLE - 8 ROLE OF CONTRACTING PARTIES 8.1 Each of the Parties to this Agreement shall
give their assistance to the JVC according to their respective roles to make the JVC a successful
venture. 8.2 MIL/MINDA at its sole discretion will assist without any legal obligation the JVC in
the following: - Business contacts in India and the neighboring countries; - Access to Indian
Know-how; - Procurement of Indian equipment; - Financing from Indian sources; - Personnel
recruitment; and - Administration and fiscal. - Support for additional business from Indian/Foreign
customers; and - Setting up of the business of the JVC. 8.3 a) IMPCO, at its sole discretion and
without any legal obligation may assist the JVC with the following: i) Sales and service training
ii) After sales services .

b) IMPCO may assist the JVC in getting quotations from itself and from its Affiliates for equipment
and components. IMPCO and MINDA agree to assist the JVC in adopting the most economical methods of
procurement. 12
<!-- page 13 -->
c) IMPCO may make available to the JVC the services of its international marketing and distribution
network and of its Affiliates.

d) IMPCO will provide, on the basis of a program to be mutually agreed with the Parties as to people
and time, training to the JVC personnel in various fields like manufacturing, design, quality,
testing, etc. IMPCO will not charge any cost from the JVC. However, all the travelling, boarding and
lodging expenses of the personnel of MINDA IMPCO Technologies Limited will be borne by the JVC.
ARTICLE - 9 EXPORTS 9.1 IMPCO understands and appreciates that the cost of production of products in
India based on IMPCO technology could be attractive and competitive. IMPCO is confident that with
their support and backing, the potential for export of the Products is likely to increase further.
IMPCO may arrange for considerable export from India, subject to price competitiveness and quality.
IMPCO may undertake to buy back substantial Products, subject to price competitiveness and quality.
IMPCO also agrees that in accordance with their policy of global sourcing they might consider
sourcing other products/components from the JVC. 9.2 Subject to the agreement of the Parties, the
JVC may export the Products. Such export shall be through IMPCO. The Parties agree that any direct
export of the Products would only be with the prior written consent of IMPCO. IMPCO agrees that they
may consider sourcing the Products from the JVC for their Asia-Pacific operations. 9.3 Compliance
with Laws. The Parties agree to comply with the Export Control Regulations of the United States
Department of Commerce and other United States Government Regulations relating to the export and
re-export of technical data and equipment and products produced therefrom. Each Party agrees that it
will not take any action in violation of, and will not cause the Company to take any action in
violation of: (i) applicable laws, rules and regulations of United States of America related to the
subject matter of this Agreement, or

(ii) the U.S. Foreign Corrupt Practices Act, 15 U.S.C. Sections 78dd-1 et seq. Which, in general,
prohibits any person from making any payment of money or anything of value, directly or indirectly,
to any government official and which requires the keeping of financial records in connection with
foreign activities, or (iii) the export control laws of any country, with respect to products,
services and technology obtained from such country, to the extent that any of such laws shall be
applicable, or 13
<!-- page 14 -->
(iv) the laws of the United States prohibiting or restricting business dealings with Persons of or
in Cuba, Iran, Iraq, Libya, Federal Republic of Yugoslavia (Serbia and Montenegro), Republic of
Bosnia and Herzegovina, North Korea and UNITA (Angola) or persons owned or controlled by any of the
foregoing (including any of the "specially designated nationals" specified under such laws. ARTICLE
- 10 BUSINESS INFORMATION 10.1 Books of Accounts, Records and Reports: The JVC will make and keep
all books of accounts, records and reports in accordance with (i) Generally Accepted Accounting
Principles and (ii) as required under the Companies Act, 1956 and other applicable laws. 10.2
Financial Statements: Promptly after the end of each financial year (as defined in 9.6 below) and
without any charge, the JVC will submit to IMPCO and MIL/MINDA the annual financial statement
including Balance Sheets and Profit and Loss account, related Auditors Reports for such year. 10.3
Availability of Business Records: During reasonable business hours IMPCO and MIL/MINDA will have the
right to inspect, and make copies of any and all of the JVC 's business records, including but not
limited to financial records, books, accounts and reports. In exercising such right IMPCO and
MIL/MINDA will be reasonable. 10.4 Plant Inspection: During reasonable business hours IMPCO and
MIL/MINDA will have the right to visit, enter and inspect each plant and other establishment at
which the JVC manufactures and/or processes the Products. In exercising such right, the Parties will
be reasonable. 10.5 The financial year of the JVC shall be from 1st April to 31st March of each
year. ARTICLE - 11 SUCCESSORS & ASSIGNS Successors & Assigns: All provisions of this Agreement shall
inure to the benefit of and be binding upon the respective successors, representatives, heirs and
permitted assigns of the Parties hereto. ARTICLE - 12 INDEMNIFICATION 12.1 Indemnification by IMPCO:
IMPCO hereby indemnifies MIL/MINDA and the JVC and agree to defend, and hold each of them harmless
from and against any and all liabilities, damages, losses, claims, costs and expenses (including
attorneys fees) arising out of or resulting from any misrepresentation or breach of covenant by 14
<!-- page 15 -->
IMPCO or the non- performance of any obligation to be performed on the part of IMPCO under this
Agreement. 12.2 Indemnification by MIL/MINDA: MIL/MINDA hereby jointly and severally indemnifies
IMPCO and the JVC agree to defend and hold each of them harmless from and against any and all
liabilities damages, losses, claims, costs and expenses (including attorney fees) arising out of or
resulting from any misrepresentation or breach of covenant by MIL/MINDA or non performance of any
obligations to be performed on the part of MIL/MINDA under this Agreement. ARTICLE - 13 TRADE MARK
13.1 MINDA IMPCO Limited shall register the Trademarks "IMPCO" and "MINDA-IMPCO", or such other
Trademark as may be mutually decided. 13.2 MINDA IMPCO Limited has agreed to allow the JVC, the
right to use the two trade marks in respect of the products, the first being under the name of
"IMPCO" and the second being in the name of "MINDA IMPCO". Unless otherwise agreed between the
parties, the MINDA IMPCO trademark will be used on the products for sale within the Territory and
the products exported would be sold with the trademark IMPCO. 13.3 LEGEND: The JVC shall have the
option to carry the following legend in product advertisements, on labels or packaging of Products
manufactured by MINDA IMPCO Limited under this Agreement - "Manufactured by MINDA-IMPCO Limited, an
Indo-American Joint Venture" ARTICLE - 14 NON-COMPETITION AND EXCLUSIVE RIGHTS 14.1 IMPCO expressly
agrees that during the existence of this Agreement, IMPCO shall not enter into any other Joint
Venture Agreement or Marketing/Distribution Agreement, with any company or person(s) in the
Territory with respect to the Products. 14.2 MINDA/MIL, since it will have access to the Technical
Know-How which it would not have had otherwise, expressly agree that:

(a) during the term of the Agreement, and thereafter for a period of five (5) years after the
termination of the Agreement (such termination being termination by IMPCO due to default by
MINDA/MIL), MIL/MINDA shall not, directly or indirectly, either alone or collectively or through any
of its associates, affiliates, including subsidiaries or any entity owned or controlled by it enter
into another joint venture agreement or marketing/distribution agreement with any company or persons
in respect 15
<!-- page 16 -->
of the marketing and sale of goods similar to the Products in the Territory. by using the Technical
Know-How

(b) the damages that would be suffered by IMPCO as a result of breach of the provisions of this
Article may not be calculable and that an award of a monetary judgment for such a breach would be an
inadequate remedy. Consequently, IMPCO shall have the right, in addition to any other rights it may
have, to obtain, in any court of competent jurisdiction, injunctive relief to restrain any breach or
threatened breach of any provision of this Article or otherwise to specifically enforce any of the
provisions hereof. This remedy is in addition to any remedy for, and not in lieu of damages,
directly or indirectly suffered by IMPCO and reasonable attorney's fees.

(c) the duration for which the covenants in this Article are to be effective is reasonable. In the
event that any court finally determines that the time period or the geographic scope of any such
covenant is unreasonable or excessive and any covenant is to that extent made unenforceable, the
parties agree that the restrictions of this Article shall remain in full force and effect for the
greatest time period and within the Territory that would not render it unenforceable. The Parties
agree that each of the covenants in Article shall be deemed to be a separate or independent
covenant. ARTICLE - 15 EVENTS OF DEFAULT AND CONSEQUENT TRANSFER OF SHARES 15.1 A party shall be
deemed to be in default if: a) such party makes a material breach of any provision of this Agreement
and fails to cure such breach within thirty (30) days after having received notice and demand for
cure of such breach from one or more of the non-defaulting Parties; b) such party becomes insolvent;
or c) such party passes a resolution to dissolve, to liquidate whether voluntary or involuntary
(except for the purpose of bonafide reconstruction or amalgamation). 15.2 If any event of default
provided in Article 15.1 above happens with respect to a party: If any event of default provided in
Article 15.1 above occurs with respect to a party:

a) The non-defaulting Party shall after the expiry of the thirty (30) day period referred to in
Article 15.1 above, at its option, be entitled to purchase all of the shares of the JVC owned by the
defaulting party. For this purpose, the non-defaulting Party would make a written offer to purchase
the shares of the defaulting Party at the price determined in terms of Article 15.3, and the
defaulting Party will be obliged to transfer its shares within one (1) month of 16
<!-- page 17 -->
the receipt of the written notice from the non-defaulting Party. It is clarified that the time
period required to obtain Government approvals, if any, for such transfer will not be included for
the purpose of calculation of the period of one (1) month stated above. It is further clarified that
such transfer shall be free of all liens, charges and encumbrances in return for the payment of the
purchase price stated in the offer. OR After the expiry of the thirty (30) day period referred to in
15.1 (a) above, the non-defaulting Party at its option, shall be entitled to sell all the shares
owned by it in the JVC to the defaulting Party at the price determined in accordance with Article
15.3 below.

b) The Parties agree that they will render full co-operation and execute all necessary documents,
including consents and no-objection certificates to the Government of India, to ensure that all
necessary government approvals can be procured to give effect to the provisions of this Article.
15.3 The price per share in the sale described in Article 15.2 above shall be i) the price
determined in accordance with the regulations of the Securities and Exchange Board of India or the
Reserve Bank of India, if applicable or, ii) in case no Government Regulations apply to price
determination, then fair market price as determined by an international auditing firm or other
expert designated by the party who would purchase shares from the defaulting party, whichever is
lower; and ARTICLE - 16 TERM AND TERMINATION 16.1 This Agreement shall become effective on the date
of execution and shall continue in force and effect for an indefinite term thereafter unless
terminated pursuant to the provisions of Article 16 or by all the Parties in writing. 16.2 A party
shall be automatically excluded from the provisions of this Agreement if it ceases to be a
shareholder in the JVC. In such event, such party shall cause all its Directors and other nominees
and representatives to resign from their positions held in the JVC, immediately. 16.3 Even if this
Agreement is terminated or a party is excluded from this Agreement, the claims and the liabilities
of each party, existent at the time of the termination or exclusion or which shall be subsequently
incurred by the cause(s) existent at the time of termination or exclusion, shall survive and be
effective until they are fully performed/discharged. 16.4 If the JVC fails to sell [one million
dollars (US$ 1,000,000.00)] worth of Products in the Territory within [eighteen (18)] months from
the date of execution of this Agreement, both the Parties will mutually discuss whether to continue
or terminate the Agreement. 17
<!-- page 18 -->
16.5 In addition to anything contained hereinabove, this Agreement may be terminated by either Party
upon the following:

(i) in the event of an enactment of any law or regulation in India, or the adoption by the
Government of India or any political subdivision thereof of any policy, guideline or other similar
direction which would have the effect of requiring any change in the terms of this Agreement adverse
to IMPCO; or (ii) in the event that all or any portion of the facilities or other assets of the JVC
are nationalised or expropriated by, or taken over for a period in excess of one (1) month by the
Government of India or any political subdivisions thereof; or (iii) an event of Force Majeure
preventing the JVC from carrying on its business for a continuous period of six (6) months. (iv) if
any Party is required, other than in accordance with the provisions of this Agreement, to transfer
all or part of its shares or to reduce its percentage of shareholding in the JVC due to a change in
or enactment of any law or regulation in India. ARTICLE - 16A USE OF TECHNICAL KNOW-HOW AFTER
TERMINATION 16A.1 The Parties agree that in the event of termination of this Agreement due to any of
the reasons mentioned in Article 16 above (and consequent termination of the TAA) the JVC and/or
MINDA/MIL will not be entitled to use the Technical Know-How for any reason whatsoever. Provided,
however, that in the event the termination of this Agreement is followed by a sale of all of the
shares held by IMPCO in the JVC to MINDA/MIL, the JVC will have a right to continue to use the
Technical Know How already received and absorbed on the condition that royalty payments under the
TAA have been paid by the JVC to IMPCO or will be paid, as the case may be, for a minimum period of
five (5) years, as provided in the TAA. 16A.2 The Parties agree that in the event of termination of
the JVA (and consequently the Technology License Agreement) neither Party is agreeable to the sale
of its shareholding to the other party or conversely the purchase of the shareholding of the other
party, the parties will proceed to dissolve the JVC by the mechanism of voluntary winding up. For
this purpose, each party will provide full cooperation and execute necessary documents and make
necessary filings with any Government authorities and/or judicial bodies to ensure that JVC can be
voluntarily wound up in the most time and cost efficient manner. The Parties agree that during the
pendency of the winding up, the JVC will be allowed to use the Technical Know How to the extent the
same is necessary for the purpose of implementing any orders pending in favour of its customers. 18
<!-- page 19 -->
ARTICLE - 17 REPRESENTATIONS AND WARRANTIES 17.1 As of the date of this Agreement, IMPCO represents
and warrants that it is a company duly incorporated and in good standing under the laws of the State
of Delaware USA with an office and legal address at 16804 Gridley Place, Cerritos, California 90703
USA; that it has full legal power and authority to execute this Agreement and to form and subscribe
to the Venture under the terms of this Agreement; and that performance of and compliance with the
terms, provisions, and conditions of this Agreement do not conflict with or will not result in any
violation of any applicable bylaw, mortgage, indenture, contract, agreement, instrument, franchise,
permit, judgment, decree, order, statute, rule or regulation. 17.2 As of the date of this Agreement,
MINDA and MIL, hereby represent and warrant to IMPCO as follows: Warranties as to the Authority This
Agreement has been validly executed by MINDA and MIL and constitutes a valid and binding obligation
of MINDA and MIL, enforceable in accordance with its terms. The execution and performance by MINDA
and MIL of this Agreement will not:

(a) conflict with, or result in any breach, violation of or default under the Articles or any note,
bond, mortgage, lease, license, permit, agreement or other instrument or obligation to which MINDA
and MIL are a party; or (b) to the best of MINDA and MIL's knowledge, violate any law, order, rule
or regulation applicable to the them. All actions, consents, conditions and things required to be
taken, fulfilled and done (including the obtaining of any necessary consents or approvals) in order
to enable MINDA and MIL to enter into, execute, and exercise its rights and perform and comply with
its obligations under this Agreement as well as to ensure that those obligations are legally binding
and enforceable have been obtained, fulfilled and done. That MINDA and MIL acknowledge that IMPCO
has entered into this Agreement in reliance on the warranties and representations made herein,
collectively and severally, by MINDA and MIL. MINDA and MIL represents and warrants that the
statements given in this Agreement are correct. Warranties as to Organisation and Power That MIL is
a company limited by Shares, duly incorporated and existing under the laws of India. That MIL was
incorporated on September 16, 1992 under the provisions of the Act and has its registered office at
36A, Rajasthan Udyog Nagar, Delhi 110 033 (India). 19
<!-- page 20 -->
That MIL has all requisite corporate power and authority to own and operate its properties and to
carry out the Business. That MIL has all permits, licenses and authorisations required by the
concerned governmental authorities for the conduct of its Business. Financial Information All
Financial Information furnished by MIL/MINDA is accurate and complete. The Financial Statements of
MIL/MINDA have been prepared in accordance with the generally accepted accounting principles,
consistently applied, in India and present a true and fair representation of the financial position
of MIL/MINDA as of March 31, 2001. The net worth of MIL/MINDA as at that date is equal to at least
RS 100 million. Tax and other matters That MIL/MINDA has duly and timely filed all tax returns
required to be filed by it and has paid all taxes which are due and payable and has paid all
assessments and reassessments, and all other taxes, governmental or municipal charges or levies,
penalties, interest and fines due and payable by MIL/MINDA on or prior to the date hereof, which
will result in any liability on its part after the Effective Date. That MIL has not incurred any
liabilities for taxes since March 31, 2000 other than those in the ordinary course of business.
There are no actions, suits, proceedings, investigations or claims pending or, to the best knowledge
MIL/MINDA, threatened against MIL/MINDA in respect of taxes, governmental, provincial or municipal
charges, levies or assessments, nor are there any matters under discussion with any governmental,
provincial or municipal charges, levies or assessments asserted by any such authority. Legal
proceedings That no legal, administrative or other proceeding or governmental investigation or
unresolved dispute is pending involving, directly or indirectly, MIL/MINDA, and no legal,
administrative or other proceeding or governmental investigation is threatened, which might
adversely affect the condition (financial or otherwise), Business, operations, prospects or
properties of MIL/MINDA. That MIL/MINDA is not subject to any judgement or court order which
adversely affects or might reasonably be expected to adversely affect, the Business, operations,
prospects, properties or conditions (financial or otherwise) of MIL. 20
<!-- page 21 -->
ARTICLE - 18 CONFIDENTIALITY 18.1 During the term of this Agreement and for a period of three (3)
years thereafter, all the Parties to this Agreement shall take reasonable steps to prevent
disclosure of any confidential or proprietary information to any third party, which it may have
received from the JVC or other Parties to this Agreement. They shall not use for any purpose (other
than authorized by the supplying party) the confidential information marked or designated as
"confidential", except for the following information: (a) Which, at the time of disclosure, is in
the public domain or publicly known or available; (b) Which, after disclosure to the recipient,
becomes part of the public domain or publicly known or available, except by breach of the terms of
this Agreement. (c) Which the recipient can establish by conclusive proof that the information was
in its possession at the time of disclosure to the recipient; (d) Which, the recipient received
rightfully without any confidentiality obligation from a third party, who is not prohibited from
disclosing such information; (e) Which is independently developed by the receiving party; and

(f) Which is information required to be disclosed by law or as per request of any Governmental body
or court of Law. Provided that the disclosing party is given prior notice and such court or
Government body is requested to keep such information confidential to the extent permissible under
law. 18.2 Information disclosed under this Agreement should remain the property of the disclosing
party. 18.3 Without the prior consent of the disclosing Parties, no party will disclose to any third
party the fact that any such information has been made available to a Party hereto. 18.4 The Parties
to this Agreement shall take all reasonable efforts to ensure that the officers, employees and
agents of the JVC shall observe a similar obligation of confidentiality. ARTICLE - 19 ARBITRATION
19.1 Difference: All matters, questions, disputes, differences or claims arising between the Parties
as to the effect, interpretation or application of this Agreement or as to their rights, duties or
liabilities hereunder, or as to any act, matter or thing arising out of consequent to, or in
connection with this Agreement (hereinafter called the Difference') will be resolved amicably
through negotiations. Such negotiations will 21
<!-- page 22 -->
commence within a period of seven (7) working days of the issue of notice in writing by either party
calling for the same (hereinafter called 'the Notice'). 19.2 Arbitration: In the event that such
negotiations fail to so resolve the difference within a period of ninety (90) working days from the
date of receipt of the notice by the other party, such difference shall be finally settled under the
rules of the International Chamber of Commerce by arbitrator(s) appointed in accordance with the
said Rules. The arbitration proceedings shall be conducted at London, United Kingdom, in the English
language. 19.3 Cost of Arbitration: The Parties hereto shall bear respective costs in connection
with the arbitration proceedings. 19.4 Performance of undisputed obligations: The existence of the
Differences between the Parties hereto, or the initiation or continuance of any arbitration
proceedings referred to above, will not delay or postpone the performance of the undisputed
obligations of the Parties hereto and the arbitrator will take full cognizance and give due
consideration to such performance, if any, in the making of the final award. ARTICLE - 20 FORCE
MAJEURE No Party shall be held liable or responsible to the other Party for failure or delay in
fulfilling or performing any obligation in this Agreement in case such failure or delays are caused
by actions or events which are beyond the reasonable control of the affected party, the effect of
which is to prevent or interfere with that party's performance hereunder, including, without
limitation, (i) any Act of God or public enemy, fire, explosion, accident, embargo, or any other
circumstances of like or different character commonly referred to as force majeure; or (ii)
interruption of or delay in transportation or shortage or failure of supply of materials or
equipment, breakdowns, strikes, or other labor strife from whatever cause arising; or (iii)
compliance by either party here to with any order, action, directive, or request of any governmental
official, department, agency, or authority. Each party agrees to give the other party prompt written
notice of the occurrence of any such condition, the occurrence and the extent to which the affected
Party will be unable to fully perform its obligations hereunder. Each Party further agrees to use
all reasonable efforts to correct such conditions as quickly as possible and to give the other Party
prompt written notice when it is again fully able to perform such obligation. Provided further that,
in the event of such prevention or delay as aforesaid, both Parties hereto, instead of exercising
the aforesaid option, may consult with each other in order to mutually determine the course of
action to be taken, in order to minimize the effects of such prevention or delay and continue the
operation of this Agreement. 22
<!-- page 23 -->
ARTICLE - 21 WAIVER Failure or delay by a party to require the performance of any provision of this
Agreement shall not affect or impair that party's right to require full performance thereof at any
time thereafter. Each party may specifically waive any breach of this Agreement by the other Party
or Parties but no such waiver shall constitute a continuing waiver of similar or other breaches by
the other Party or Parties. ARTICLE - 22 SEVERABILITY If any provision of this Agreement is
determined by judicial decision to be unlawful, unenforceable or invalid, or is discovered to be so,
such provision shall be severed from this Agreement. Such invalid provision(s) shall be replaced by
a valid provision(s). Provided however, that the remaining provisions of this Agreement shall remain
in effect and be binding on the Parties. ARTICLE - 23 NOTICES All notices, requests and other
communications under this Agreement shall be in writing and shall be deemed to have been duly given
if delivered by hand, at the time of receipt or, if communicated by cable or similar electronic
means, at the time receipt thereof has been confirmed by return electronic communication or signal
that the message has been clearly received, or if mailed seven (7) days after mailing, registered
airmail return receipt requested, with postage prepaid. In case of IMPCO to: Mr. Don L. Dominic,
Vice President and General Counsel IMPCO TECHNOLOGIES, INC. 6804 Gridley Place Cerritos, California
90703 U.S.A. Fax No.: 562 860-5106

In case of MIL to: Mr. Nirmal K. Minda Managing Director 36-A, Rajasthann Udyog Nagar, Delhi-110033
Fax No.: 0091 11 7241524

If to Nirmal K. Minda: Mr. Nirmal K. Minda and/or relatives & associates A-15, Ashok Vihar, Phase-I,
Delhi-110 052. Fax No.: 0091 11 7241524 23
<!-- page 24 -->
Provided, however, that if the party shall have designated a different address by notice to the
other party, then to the last address, so designated. ARTICLE - 24 MISCELLANEOUS 24.1 English shall
be used in all correspondence and communications between the Parties. This Agreement and the
Associated Agreements shall be prepared and executed in English. Translation of this Agreement into
any other language shall be for the convenience of the Parties and all questions arising from this
Agreement shall be determined by reference to the official English-language version of the
Agreement. 24.2 Governing Law: This Agreement shall be governed by and construed in accordance with
the laws of India and the Delhi Courts shall have exclusive jurisdiction over any legal proceedings
in respect of this Agreement. The Parties hereby stipulate irrevocably that they hereby submit to
the exclusive jurisdiction of the above-referred courts and for such purpose hereby waive all and
any challenges to the exclusive jurisdiction of the above referred courts. 24.3 Schedule or Exhibit:
Each of the Schedule(s) or Exhibit(s) referred to herein be attached hereto as an integral part of
this Agreement. 24.4 Entire Agreement: This Agreement sets forth the entire agreement between the
Parties and supersedes all prior other agreements and understandings between the Parties, and their
officers, directors, or employees as to the subject matter hereof. None of the Parties has relied
upon any oral representation or oral information given to it by any representative of any of the
other Parties. No change in this Agreement shall be effective either as a result of a course of
conduct or oral statements, other than by an agreement in writing duly authorized by the
representatives of each of the Parties hereto. 24.5 Counterparts: the Parties shall execute this
Agreement hereto, in four counterparts and each executed copy thereof shall be deemed an original
without production of the others. 24.6 Any amendment(s) to this Agreement shall be made in writing
and signed by the Parties to this Agreement. 24.7 Legal Costs: The Parties agree that all legal
costs, expenses and fees would be borne by the respective Parties. 24.8 Winding Up: In the event of
termination of this Agreement and consequent winding up of the JVC, the Parties agree to cooperate
with each other for adequate discharge and fulfillment of the JVC's liabilities, commitments and
obligations as may be necessary. 24
<!-- page 25 -->
ARTICLE - 25 NO THIRD PARTY PAYMENT 25.1 Definition of Third Parties. The Parties represent to each
other that it has not made, and agrees that it will not make, in connection with the transactions
contemplated by this Agreement, or in connection with any other business transactions involving the
JVC, any payment or transfer of anything of any value, directly or indirectly, to the following: (a)
to any government official or employee (including employees of government corporations), or to any
political party or candidate; or (b) to any officer, director, employee or representative of any
actual or potential JVC customer; or (c) to any other person or entity if such payment or transfer
would violate the laws of the country in which such payment or transfer is made or violate the laws
of the United States. 25.2 Anti-Kickback. It is the intent of the Parties that no payment or
transfers of value shall be made which have the purpose or effect of public or commercial bribery,
acceptance of or acquiescence in extortion, kickbacks or other unlawful or improper means of
obtaining business. This section shall not, however, prohibit normal and customary business
entertainment or the giving of business momentos of nominal value. 25.3 Anti-Government Official
Ownership. MIL/MINDA affirms that it has disclosed to Company that no government official has an
ownership interest, director indirect, in MIL/MINDA or in the contractual relationship established
by this Agreement. In the event that during the term of this Agreement, there is the acquisition of
an interest in MINDA/MIL, or in this Agreement by a government official, MIL/MINDA agrees to make
immediate disclosure to IMPCO and agrees that this Agreement may become subject to immediate
termination. For the purpose of this Article, "government official" means any officer or employee of
the government or any department, agency, corporation or instrumentality thereof, or any political
party, and includes immediate family members and nominees of such governmental officials. 25
<!-- page 26 -->
IN WITNESS WHEREOF, the Parties hereto have executed this Agreement and caused their respective
corporate seals to be affixed by their officers thereunto duly authorized as of the day and year
first written above. Signed for & on behalf of : MINDA INDUSTRIES LIMITED

/s/ Nirmal K. Minda

Nirmal K. Minda Managing Director MR. NIRMAL K. MINDA & ASSOCIATES

/s/ Nirmal K. Minda

Nirmal K. Minda IMPCO TECHNOLOGIES INC.

/s/ Pearl Kamdar

Pearl Kamdar Director, Asia Pacific Operations WITNESS:

1.

/s/ Rob Mercer

2.

/s/ Don Dominic

3.

26
<!-- page 27 -->
SCHEDULE - I Schedule I to the Joint Venture Agreement (JVA) dated May 18, 2001 DETAILS OF MINDA AS
REFERRED IN JVA; A. MINDA FAMILY A.1 MR. S.L. MINDA & FAMILY 1. MR. S.L. MINDA 2. MRS. SAVITRI DEVI
MINDA 3. S.L. MINDA & SONS (HUF) A.2. MR. NIRMAL K. MINDA & FAMILY 1. MR. NIRMAL K. MINDA 2. MRS.
SUMAN MINDA 3. PALAK MINDA 4. PRIDHI MINDA 5. NIRMAL K.MINDA (HUF) A.3. 1. MR. AND MRS. SHISHIR
AGARWAL 2. MR. AND MRS. GAGAN AGARWAL B. ASSOCIATE COMPANIES B1. SWITCH AUTO PVT.LTD. B2. SOPAN
INVESTMENT & AGRO FARMS PVT. LTD. B3. LATTU FINANCE & INVESTMENTS PVT.LTD. B4. PJPS FINANCE &
INVESTMENTS PVT.LTD. 27

Signed for & on behalf of : MINDA INDUSTRIES LIMITED IMPCO TECHNOLOGIES INC.
<!-- page 28 -->
/s/ Nirmal K. Minda

/s/ Pear Kamdar

Nirmal K. Minda Pearl Kamdar Managing Director Director, Asia Pacific Operations

MR. NIRMAL K. MINDA & ASSOCIATES

/s/ Nirmal K. Minda

Nirmal K. Minda

28
