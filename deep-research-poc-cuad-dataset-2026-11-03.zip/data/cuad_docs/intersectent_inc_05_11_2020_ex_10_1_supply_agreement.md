<!-- page 1 -->
# SUPPLY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Supply Agreement |
| Agreement Date | 2020-01-20 |
| Parties | HOVIONE INTER AG ("HOVIONE"); INTERSECT ENT, Inc. ("INTERSECT"); (each as "Party", together as "Parties") |
| Source | CUAD v1 / INTERSECTENT,INC_05_11_2020-EX-10.1-SUPPLY AGREEMENT |

Exhibit 10.1 [*] Certain confidential information contained in this document, marked by brackets, is
omitted because it is both (i) not material and (ii) would be competitively harmful if publicly
disclosed.

SUPPLY AGREEMENT

THIS SUPPLY AGREEMENT (this "Agreement") is made this, 20t h day of January, 2020 (the "Effective
Date"), by and between HOVIONE INTER AG, together with its subsidiaries and affiliates, and
organized and existing under the laws of Switzerland and having its registered office at
Pilatusstrasse 23, CH-6003, Luzern, Switzerland (hereafter referred to as "HOVIONE"), and INTERSECT
ENT, Inc. together with its subsidiaries and affiliates, and organized and existing under the laws
of Delaware and having its registered office at 1555 Adams Drive, Menlo Park, CA 94025 (hereafter
referred to as "INTERSECT"). HOVIONE and INTERSECT are each sometimes referred to herein as a
"Party" and together as the "Parties."

WHEREAS, HOVIONE has developed and manufacturers the active pharmaceutical ingredient(s) identified
in Exhibit A hereto (the "API"); and

WHEREAS, INTERSECT develops and markets Finished Product based on the API, as defined herein; and

WHEREAS, INTERSECT desires to acquire API from HOVIONE to incorporate into the Finished Product; and

WHEREAS, HOVIONE is willing to supply such API for INTERSECT's use, on the terms and conditions set
forth in this Agreement.

NOW THEREFORE, in consideration of the promises and the mutual covenants set forth herein and for
other good and valuable consideration, the receipt and sufficiency of which are hereby acknowledged,
the Parties hereby agree and covenant as follows: 1. Definitions 1.1. "Active Pharmaceutical
Ingredient" or "API" shall have the meaning given such term in the preamble hereof. 1.2. "Affiliate"
means any entity controlling, controlled by or under common control with either Party hereto. For
purpose of this definition, "control" shall mean ownership of over fifty percent (50%) of the equity
capital, the outstanding voting securities or other ownership interest of an entity, or the right to
receive over fifty percent (50%) of the profits or earnings of an entity. In the case of non-stock
organizations, the term "control" shall mean the power to control the distribution of profits. 1.3.
"Applicable Law" shall mean the laws, regulations, rules and guidelines pertaining to the
development, manufacture, packaging, labeling, storage, import, export, distribution, marketing,
sale and/or intended use of the API or the Finished Product. 1.4. "Batch Record" shall mean a batch
manufacturing record, prepared according to applicable cGMP guidelines, for every production batch
of API. 1.5. "Confidential Information" shall mean all the technical information, whether tangible
or intangible, including (without limitation) any and all data, techniques, discoveries, inventions,
processes, know-how, patent applications, inventor certificates, trade secrets, methods of
production and other proprietary information, that either Party or its Affiliates have ownership
rights to (as either owner, licensee or sub-licensee), or may hereafter obtain rights. 1
<!-- page 2 -->
1.6. "Current Good Manufacturing Practices" or "cGMP" shall mean current Good Manufacturing Practice
as set forth by the US FDA as well as current good manufacturing practices applicable to the API, or
the making thereof at HOVIONE's manufacturing facility, set forth by the relevant Regulatory Agency.
1.7. "Defect" with respect to the API shall mean failure of the API to comply with the Product
Specifications. 1.8. "FDA shall mean the US Food and Drug Administration, and any successor thereto.
1.9. "Finished Product" shall mean the finished dosage form combination drug and device product that
contains the API ready for clinical use or commercial sale. 1.10. "Firm Forecast" shall have the
meaning given to such term in Section 3.2 hereof. 1.11. "Product Specifications" shall have the
meaning given to such term in Section 2.2 hereof. 1.12. "Quality Agreement" shall mean that certain
Quality Assurance Agreement, dated of even date herewith, by and between INTERSECT and HOVIONE,
which sets forth (a) the roles and responsibilities of the Parties with respect to the quality
assurance for the API and (b) how the Parties' quality operations shall interact with each other in
connection with the same. 1.13. "Regulatory Agency" shall mean national, or other government
entities regulating or otherwise exercising authority with respect to the API or the Finished
Product in the United States including, without limitation, the US FDA 1.14. "Term" shall have the
meaning assigned to such term in Section 10. 2. Manufacture and Sale 2.1. Supply. During the term of
this Agreement and subject to the terms and conditions set forth herein, INTERSECT shall purchase
[*] of its annual API requirement, from HOVIONE and HOVIONE shall manufacture and supply API to
INTERSECT (or a third party designated by INTERSECT) in such quantities as from time to time may be
ordered by INTERSECT. 2.2. Product Specifications. The specifications of the API as set out in in
Exhibit B to this Agreement (the "Product Specifications"); as such Exhibit may be amended according
to the terms of the quality agreement between the parties. 3. Costs. HOVIONE shall be responsible
for all costs and expenses related to the maintenance of a US DMF or European CEP for the API. Any
additional submissions, technical work, documents, data or materials requested by INTERSECT may be
chargeable by HOVIONE. 4. Price, Orders and Terms of Payment 4.1. Pricing. The price for the API
shall be as set forth on Exhibit C hereto. All sums shall be expressed in and payable in US Dollars.
4.2. Forecasting. For each calendar year during the term of this Agreement, INTERSECT shall submit a
twelve (12) month rolling forecast updated on a quarterly basis, broken down on a quarterly basis
covering INTERSECT's anticipated requirements of API, each such forecast to be provided to HOVIONE
at least ninety (90) days prior to the start of the relevant twelve (12) month period. The rolling
forecast shall be for information purposes only and non- binding so long as the INTERSECT provides a
blanket purchase order covering their demand for the next six (6) months. In the case that INTERSECT
does not provide a blanket purchase order, the forecast will be considered binding. INTERSECT shall
place all purchase orders with HOVIONE at least ninety (90) days in advance of required delivery to
INTERSECT. Within five (5) days of receipt of a purchase order, HOVIONE shall notify INTERSECT in
writing of its acceptance of the purchase order and confirm the delivery date. If the purchase order
exceeds the Firm Forecasted amount, HOVIONE shall use commercially reasonable efforts to fill such
order but shall not be in breach of this Agreement if HOVIONE does not supply the excess. 2
<!-- page 3 -->
4.3. Delivery Terms. Each purchase order shall specify: (i) an identification of the API ordered;
(ii) quantity requested; (iii) the requested delivery date; and (iv) shipping instructions and
address. HOVIONE agrees to deliver the API DDP Menlo Park, CA USA (Incoterms 2010). 4.4. Payment
Terms. HOVIONE shall invoice INTERSECT upon dispatch of the API. INTERSECT shall pay the price to
HOVIONE for API within thirty (30) calendar days of the date of invoice of such API. Payments shall
be made to HOVIONE by wire transfer. 4.5. Scope of Agreement. In no event shall any terms or
conditions included on any purchase order, invoice or acknowledgement thereof or any other document,
whether paper, electronic or otherwise, relating thereto, apply to the relationship between the
Parties under this Agreement, unless such terms are expressly agreed to by the Parties in writing.
If there is a conflict between the terms of any purchase order or other document and this Agreement,
the terms of this agreement shall apply. The Parties further agree that no course of dealing between
the Parties shall in any way modify, change or supersede the terms and conditions of this Agreement.
5. Manufacture and Delivery of API. 5.1. Manufacture. The API shall be manufactured by HOVIONE at
its facilities in accordance with all relevant current Good Manufacturing Practices ("cGMPs"), the
Specifications, and Applicable Laws, and pursuant to HOVIONE's Drug Master File ("DMF"), prepared by
HOVIONE and filed with the US FDA. HOVIONE shall advise INTERSECT in writing in advance of making
any changes to the Product Specifications or any material changes in the methods, processes or
procedures in manufacturing the API that could affect the quality, purity and/or physical properties
of the API, any changes will be made according to the terms of the quality agreement between the
parties. HOVIONE shall provide sufficient notice of any such change to INTERSECT to allow INTERSECT
to make any required notices to and obtain any required approvals from any Regulatory Agency with
respect to such change. 5.2. Right of Audit. See Quality Agreement. 5.3. Certificate of Analysis;
Product Release. The quality control(s) and the release(s) of API (including documentation) shall be
done by HOVIONE in accordance with the Quality Agreement. HOVIONE shall provide certificates of
analysis to INTERSECT for each batch of API delivered under this Agreement. API shall have at least
[*] remaining on the date of delivery. 5.4. Cooperation. During the term of this Agreement, HOVIONE
shall assist and cooperate in a timely manner INTERSECT in its preparation of any documents or other
materials which may be required by the US FDA to validate sell and/or distribute the API to be
supplied by HOVIONE under this Agreement or the Finished Product. HOVIONE shall file with the US FDA
and shall maintain at all times as current, a DMF for the API. HOVIONE shall also provide INTERSECT
with a referral letter permitting INTERSECT to use HOVIONE's DMF. 5.5. Required Changes. INTERSECT
shall deliver to HOVIONE written notice of any required changes to the Product Specifications
requested by the Regulatory Authorities, and HOVIONE shall use its commercially reasonable efforts
to make such changes to the Product Specifications. If any change to Product Specifications
requested by INTERSECT materially affects HOVIONE's costs of producing the API, then HOVIONE shall
promptly so inform INTERSECT in writing and the Parties shall negotiate, in good faith, an
adjustment to the pricing paid by INTERSECT for API under this Agreement. If the Parties cannot
mutually agree, following good faith negotiations, on an equitable adjustment to pricing, then
either HOVIONE or INTERSECT may terminate this Agreement for business reasons on not less than
ninety (90) days prior written notice, without any further obligation to the other party; provided,
however, that INTERSECT shall remain liable for all sums owed to HOVIONE for orders of API that were
placed prior to the date of termination. 3
<!-- page 4 -->
5.6. Inspection of API. Within thirty (30) calendar days of the arrival of each lot of API at the
manufacturing facility designated by INTERSECT, INTERSECT shall inspect and test each lot of API at
its own cost and expense. If, upon inspecting and testing the API, INTERSECT determines that a lot
of API does not conform to the Product Specifications, then INTERSECT shall, within such thirty (30)
day period, give HOVIONE written notice of such non-conformity (setting forth the details of such
non-conformity):Unless HOVIONE objects, within 20 working days from the notice by INTERSECT, to the
non-conformity INTERSECT will return the non-conforming API to HOVIONE. Any API rejected by
INTERSECT may not be reshipped to INTERSECT except if the API is reprocessed according to the DMF.
HOVIONE sole responsibility shall be to replace any non-conforming API within thirty (30) days of
receiving the notice of non- conformity. Disputes between the Parties as to whether all or any part
of a shipment rejected by INTERSECT materially conforms to the Product Specifications shall be
resolved by a mutually acceptable third-party testing laboratory located in a neutral country.
HOVIONE shall pay all the fees of the third-party laboratory, unless the third-party testing
laboratory determines that the delivered API materially conforms to the Product Specifications, in
which case INTERSECT shall pay all the fees of such third-party laboratory and also any additional
costs that HOVIONE incurred in providing replacement material. 5.7. Regulatory Communications.
During the Term, HOVIONE shall notify INTERSECT after receipt of any communication from any
Regulatory Agency in connection or that can affect INTERSECT Marketing Authorization. 5.8.
Liability. It is understood that HOVIONE has no control over the ultimate use of the Finished
Product once it leaves INTERSECT's manufacturing facility. HOVIONE shall have no liability arising
out of or in connection with the sale or use of the API or any product or material made from or
incorporating the API, except to the extent that the API was not manufactured in accordance with the
Product Specifications, cGMPs or Applicable Law or the liability otherwise arises from a breach of
this Agreement by HOVIONE. 5.9. Recall. INTERSECT shall be responsible for conducting any recall of
Finished Product, and HOVIONE shall co-operate with and give all reasonable assistance to INTERSECT
in conducting any such recall to the extent it relates to the API. HOVIONE shall bear the expense of
any recall resulting from a material breach of its obligations hereunder and/or of the Quality
Agreement and/or from its gross negligence or willful misconduct subject to the limits set out in
8.4. Otherwise, INTERSECT shall bear such expenses. In the event of such recall or similar action,
each Party shall use commercially reasonable efforts to mitigate the costs associated therewith. In
the case of a disagreement as to the existence or level of nonconforming API, then the matter shall
be referred to an independent third-party laboratory. The decision of the laboratory shall be final
and binding on the Parties. 5.10. Retention of Documentation. All documentation related to the
manufacturing of the API shall be archived with HOVIONE after manufacturing in accordance with
HOVIONE's document retention policies. 5.11. Safety of API. Each Party shall immediately notify the
other Party of any unusual health or environmental occurrence relating to API. Each Party shall
advise the other Party immediately of any safety or toxicity problems of which it becomes aware
regarding API. 6. Warranties. 6.1. HOVIONE's Warranties. HOVIONE represents and warrants to
INTERSECT that: (a) It has full right and power to enter into this Agreement and perform its
obligations hereunder in accordance with its terms; (b) The API and all components and ingredients
thereof shall be manufactured and delivered in strict compliance with: (i) the Product
Specifications; (ii) the methods processes and procedures, including the site manufacture, set forth
in the DMF, together with all applicable regulatory requirements relating to the manufacture of the
API 4
<!-- page 5 -->
(c) the plant(s) for manufacture of the API is and shall be in compliance with all applicable cGMPs
and that such plant(s) is and shall continue to be available for inspection if and when the
Regulatory Authorities so requests; 6.2. INTERSECT's Warranties. INTERSECT represents and warrants
to HOVIONE that: (a) It has the full right and power to enter into this Agreement and perform its
obligations hereunder in accordance with its terms; and (b) That it will purchase the API in strict
compliance with the terms of this agreement. as set forth under Section 2.1 and 2.1. 6.3.
DISCLAIMER. EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, NEITHER PARTY MAKES ANY REPRESENTATION
OR EXTENDS ANY WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED INCLUDING, BUT NOT LIMITED TO,
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT. 6.4. Mutual
Warranties. Each party represents and warrants to the other party that it holds all necessary and
required permits and authorizations, including, but not limited to, those required by the FDA, and
shall undertake throughout the term of this Agreement to maintain the same in full force and effect.
Each party further covenants that it shall use commercially reasonable efforts to obtain all such
other permits and authorizations as may be reasonably required from time to time in either case to
operate their respective facilities and/or businesses in order to manufacture, provide, distribute
and/or sell API hereunder. 7. Confidentiality. 7.1. Confidentiality. Each party agrees to retain in
confidence all Confidential Information disclosed to it pursuant to this Agreement, whether such
disclosure occurred before or after the date hereof. Disclosed information shall not be deemed
Confidential Information hereunder if: (a) it is now or later becomes publicly known, other than
through the fault of the receiving party; (b) it is lawfully known without restriction to the
receiving party at the time of disclosure as evidenced by written documentation; (c) it is
rightfully obtained by the receiving party from a third party without restriction and without breach
of this Agreement or any similar agreement; and/or (d) it is independently developed by the
receiving party without access to the disclosing party's information, as evidenced by written
documentation. If either Party is required under Applicable Law to disclose Confidential Information
by any court or to any Regulatory Agency, the Party required disclosing the Confidential Information
shall, prior to such disclosure, notifying the other Party of such requirement and all particulars
related to such requirement. The notified Party shall have the right, at its expense, to object to
such disclosure and to seek confidential treatment of any Confidential Information to be so
disclosed on such terms as it shall determine, and the other Party shall fully cooperate with the
notified Party in this regard. The confidentiality of disclosed Confidential Information and the
obligation of confidentiality hereunder shall survive any expiration or termination of this
Agreement for a period of ten years. The Parties specifically agree that all terms of this
Agreement, all sales and API requirements and costs and all purchase orders shall be deemed to be
confidential. 7.2. Separate Confidentiality Agreement. If the Parties entered into one or more
separate confidentiality agreements or non-disclosure agreements (each, a "Confidentiality
Agreement"), such Confidentiality Agreement(s) shall be and remain in full force and effect as
provided therein. In the event of any conflict between the terms of this Agreement and the terms of
any such Confidentiality Agreement, the terms of such Confidentiality Agreement shall control. 7.3.
Public Announcements. During the term of this Agreement, no party hereto shall issue or release,
directly or indirectly, any press release, marketing material or other communication to or for the
media or the public that pertains to this Agreement, the API, the Finished Product or the
transactions contemplated hereby (collectively, a "Press Release") unless the content of such Press
Release has been approved by the other party hereto, such approval not to be unreasonably withheld
or delayed; provided, however, that nothing contained in this Agreement shall prevent or preclude
any party from making such disclosures as may be required by applicable law, including, but not
limited to, any disclosures required applicable securities laws. 5
<!-- page 6 -->
8. Indemnification. 8.1. INTERSECT shall indemnify, defend and hold HOVIONE and its officers,
directors, affiliates, agents and employees harmless from and against any and all claims, demands,
costs, expenses, losses, liabilities and/or damages (including, but not limited to, reasonable
attorneys' fees) of every kind and nature caused by, arising out of or resulting from INTERSECT's
negligence relating to, or breach of, this Agreement, and any claim for personal or bodily injury
arising from the use of the Finished Product or any substance, dosage composition or compound
manufactured therefrom; provided, however, that in no event shall this Section apply to any claim
covered by Section 8.2 below. 8.2. HOVIONE shall indemnify, defend and hold INTERSECT and its
officers, directors, affiliates, agents and employees harmless from and against any and all claims,
demands, costs, expenses, losses, liabilities and/or damages (including, but not limited to,
reasonable attorneys' fees and court costs) of every kind and nature caused by, arising out of or
resulting from HOVIONE's negligence relating to, or breach of, this Agreement and any claim for
personal or bodily injury arising from the manufacture and/or distribution of API by HOVIONE. This
indemnification obligation does not apply to any claim for personal or bodily injury arising from
the use or administration of the API except to the extent such injury is attributable to a Defect in
the API arising out of HOVIONE's gross negligence, willful misconduct, or failure to manufacture and
deliver the API in accordance with the Product Specifications and all Applicable Law. 8.3. Each
party will promptly notify the other of any actual or threatened judicial or other proceedings which
could involve either or both parties. Each party reserves the right to defend itself in any such
proceedings; provided, however, that, if indemnity is sought, then the party from whom indemnity is
sought shall have the right to control the defense of the claim, and the indemnified party may
participate with counsel of its choice at its own expense. The Parties shall cooperate with each
other to the extent reasonably necessary in the defense of all actual or potential liability claims
and in any other litigation relating to the API supplied pursuant to this Agreement. Each party will
supply information to the other relevant to any product liability claims and litigation affecting
the API and/or the Finished Product, as the case may be. 8.4. NOTWITHSTANDING ANYTHING IN THIS
AGREEMENT TO THE CONTRARY, IN NO EVENT WILL EITHER PARTY BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
CONSEQUENTIAL OR INDIRECT DAMAGES ARISING OUT OF THIS AGREEMENT, HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY. THIS LIMITATION WILL APPLY EVEN IF THE OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE; PROVIDED, HOWEVER, THAT THIS LIMITATION WILL NOT APPLY TO DAMAGES RESULTING FROM
BREACHES BY A PARTY OF ITS DUTY OF CONFIDENTIALITY AND NON-USE IMPOSED UNDER THIS AGREEMENT OR THE
CONFIDENTIALITY AGREEMENT OR SUCH PARTY'S INDEMNIFICATION OBLIGATIONS STATED ABOVE. FURTHER AND
NOTWITHSTANDING ANYTHING TO THE CONTRARY IN THIS AGREEMENT, THE TOTAL LIABILITY PER YEAR OF HOVIONE
SHALL BE LIMITED TO THE VALUE OF THE REVENUES COLLECTED IN THE PREVIOUS CONTRACTUAL YEAR. 9.
Insurance. Unless the Parties otherwise agree in writing, the following terms shall apply: 9.1.
During the term of this Agreement and for a period [*] after any expiration or termination of this
Agreement, each of INTERSECT and HOVIONE shall maintain in full force and effect a comprehensive
general liability insurance policy, including Products Liability coverage, with minimum limits of
[*] for bodily injury including death. 6
<!-- page 7 -->
10. Term and Termination. 10.1. Term.

Unless terminated in accordance with the provisions of Section 10.2 below, the term of this
Agreement shall commence on the Effective Date and shall continue in effect for a FIVE (5) year
period. 10.2. Grounds for Termination. (a) Either party shall have the right to terminate this
Agreement upon the occurrence of any of the following events: (i) the failure of the other party to
comply with any of the terms of this Agreement or otherwise discharge its duties hereunder in any
material respect, or the breach by the other party of any of its representations or warranties
herein in any material respect, if such failure or breach is not cured within ninety (90) days of
such breaching party's receipt of written notice specifying the nature of such failure or breach
with particularity; or (ii) the making by the other party of an assignment for the benefit of its
creditors, or the filing by or against such other party of any petition under any federal, state or
local bankruptcy, insolvency or similar laws, if such filing has not been stayed or dismissed within
sixty (60) days after the date thereof. 10.3. INTERSECT shall also have the right to suspend further
performance under this Agreement and/or terminate this agreement in its entirety, without liability
except for unpaid previously delivered API that conforms with the terms hereof, if: (i) HOVIONE
loses any approval(s) from the US FDA required to perform its obligations under this Agreement or if
HOVIONE is involved in felonious or fraudulent activities. 10.4. HOVIONE shall also have the right
to suspend further performance under this Agreement, terminate this Agreement and demand
compensation if INTERSECT fails to comply with any of the terms and conditions of this Agreement;
provided, however, that if any such failure is disputed by INTERSECT in good faith, HOVIONE shall
not have the right to terminate this Agreement with respect to such dispute until such dispute is
adjudicated in favor of HOVIONE in accordance with Section 14.6. 10.5. Obligations on Termination:
10.5.1. Of HOVIONE. Upon termination of this Agreement pursuant to this Section 10, HOVIONE will not
perform any further work, except the following: 10.5.1.1. perform only those services and other
activities mutually agreed upon by INTERSECT and HOVIONE as being necessary or advisable to comply
with issued and paid for purchase orders; 10.5.1.2. promptly return all Confidential Information of
INTERSECT that it has received pursuant to this Agreement. 10.5.2. Of INTERSECT. Upon termination of
this Agreement pursuant to this Section 10, COMPANY will: 10.5.2.1. promptly pay HOVIONE any monies
due and owing HOVIONE, up to the time of termination, for API actually manufactured, all authorized
expenses actually incurred and any uncancellable commitments made by HOVIONE in connection with the
scope of this Agreement; and 10.5.2.2. promptly return all Confidential Information of HOVIONE that
it has received pursuant to this Agreement. 11. Continuing Obligations; Survival. In no event shall
any termination or expiration of this Agreement excuse either party from any breach or violation of
this Agreement and full legal and equitable remedies shall remain available therefore, nor shall it
excuse either party from making any payment due under this Agreement with respect to any period
prior to the date of expiration or termination. 12. Agreement to Consummate; Further Assurances.
Subject to the terms and conditions of this Agreement, each of the Parties hereto agrees to use
commercially reasonable efforts to do all things necessary, proper or advisable under this
Agreement, applicable laws and regulations to consummate and make effective the transactions
contemplated hereby. If, at any time after the date hereof, any further action is necessary, proper
or advisable to carry out the purposes of this Agreement, then, as soon as is reasonably
practicable, each party to this Agreement shall take, or cause its proper officers to take, such
action. 7
<!-- page 8 -->
13. Force Majeure. Any delay in the performance of any of the duties or obligations of either party
hereto (except for the payment of money) caused by an event outside the affected party's reasonable
control shall not be considered a breach of this Agreement and the time required for performance
shall be extended for a period equal to the period of such delay. Such events shall include, but
will not be limited to, acts of God, acts of a public enemy, acts of terrorism, insurrections,
riots, injunctions, embargoes, fires, explosions, floods, or other unforeseeable causes beyond the
reasonable control and without the fault or negligence of the Party so affected. The Party so
affected shall give prompt written notice to the other party of such event. The suspension of
performance shall be of no greater scope and no longer duration than is reasonably required and the
nonperforming Party shall use its commercially reasonable efforts to remedy its inability to
perform; provided, however, that in the event the suspension of performance continues for sixty (60)
days after the date of the occurrence, and such failure to perform would constitute a material
breach of this Agreement in the absence of such force majeure event, the no affected Party may
terminate this Agreement immediately by written notice to the affected Party. 14. General
Provisions. 14.1. Assignment. Neither this Agreement nor any interest herein may be assigned, in
whole or in part, by either party without the prior written consent of the other, which consent
shall not be unreasonably withheld or delayed, except that either party may assign its rights and
obligations under this Agreement: (a) to an affiliate, division or subsidiary of such party; and/or
(b) to any third party that acquires all or substantially all of the stock or assets of such party,
whether by asset sale, stock sale, merger or otherwise, and, in any such event such assignee shall
assume the transferring party's obligations hereunder. However, notwithstanding any such assignment,
in the case of an assignment to an affiliate, division or subsidiary, the transferring party shall
remain liable under this Agreement (in addition to the transferee) unless such liability is
specifically waived in writing by the other party hereto. Subject to the foregoing, this Agreement
shall be binding upon and inure to the benefit of the Parties hereto, and their respective
successors and permitted assigns. (a) Buyout. In the case that either company is acquired by, or
merges with, another company which has reason to not wish to continue the relationship, that company
may make a contract buyout payment [*] for the [*], with a [*] buyout payment amount of [*]. 14.2.
Notice. Any notice or request required or permitted to be given under or in connection with this
Agreement shall be deemed to have been sufficiently given if in writing and sent by: (a) personal
delivery against a signed receipt therefore, (b) certified mail, return receipt requested, first
class postage prepaid, (c) nationally recognized overnight delivery service (signature required),
(d) confirmed facsimile transmission, or (e) electronic mail (with any notices to send by facsimile
transmission or electronic mail to also be sent by one of the other methods set forth in this
Section), addressed as follows: If to HOVIONE, then to: Hovione FarmaCiencia SA Attention: General
Counsel Estrada do Paco do Lumiar Campus do Lumiar, Edificio R 1649-038 Lisboa, Portugal

With a copy, sent as provided herein, to: gc@hovione.com If to INTERSECT, then to: 1555 Adams Dr.,
Menlo Park, CA 94025 Attn: Chief Operations Officer email: purchasing@intersectent.com 8
<!-- page 9 -->
Any party may alter the address to which communications are to be sent by giving notice of such
change of address in conformity with the provisions of this Section providing for the giving of
notice. Notice shall be deemed to be effective, if personally delivered, when delivered; if mailed,
at midnight on the third business day after being sent by certified mail; if sent by nationally
recognized overnight delivery service, on the next business day following delivery to such delivery
service; and if sent by confirmed facsimile transmission or electronic mail, on the next business
day following transmission (so long as any notices sent by facsimile transmission or electronic mail
are also sent by one of the other methods set forth in this Section). 14.3. Entire Agreement. This
Agreement sets forth the entire agreement and understanding between the Parties as to the subject
matter hereof and merges all prior discussions and negotiations between them, and neither party
shall be bound by any conditions, definitions, warranties, understandings or representations with
respect to such subject matter other than as expressly provided herein or as duly set forth on or
subsequent to the date hereof in writing and signed by a proper and duly authorized officer or
representative of the Parties to be bound thereby, except that this Agreement shall not supersede
any separate confidentiality or non-disclosure agreement that may have been, or that may be, entered
into by the Parties. To the extent that any conflict arises among the documents that comprise this
Agreement (including any schedules or exhibits), the terms and conditions of this Agreement shall
govern. The terms and conditions of this Agreement shall control over and supersede any contrary
term in any purchase order, 14.4. Amendment and Modification. This Agreement may be amended,
modified and supplemented only by written agreement duly executed and delivered by each of the
Parties hereto. 14.5. Waiver. The failure of any party to exercise any right or to demand the
performance by the other party of duties required hereunder shall not constitute a waiver of any
rights or obligations of the Parties under this Agreement. A waiver by any party of a breach of any
of the terms of this Agreement by any other party shall not be deemed a waiver of any subsequent
breach of the terms of this Agreement. 14.6. Governing Law. This Agreement is to be governed by and
construed in accordance with the laws of the State of New York, United States, notwithstanding any
conflict of law provisions to the contrary. The United Nations Convention on Contracts for the
International Sale of Goods shall not apply to this Agreement. Any action which in any way involves
the rights, duties and obligations of either party hereto under this Agreement shall be brought in
the courts of Geneva and the Parties to this Agreement hereby submit to the personal jurisdiction of
any such court. The Parties waive any and all rights to have any dispute, claim or controversy
arising out of or relating to this Agreement tried before a jury. 14.7. Severability. Whenever
possible, each provision of this Agreement shall be interpreted in such manner as to be effective
and valid under applicable law, but if any provision of this Agreement is held to be invalid,
illegal or unenforceable in any respect under any applicable law or rule in any jurisdiction, such
invalidity, illegality or unenforceability shall not affect any other provision of this Agreement or
any action in any other jurisdiction, but this Agreement shall be reformed, construed and enforced
in such jurisdiction as if such invalid, illegal or unenforceable provision had not been contained
herein. 14.8. Construction. The Parties have participated jointly in the negotiation and drafting of
this Agreement. In the event of any ambiguity or question of intent or interpretation arises, this
Agreement shall be construed as if drafted jointly by the Parties and no presumption or burden of
proof shall arise favoring or disfavoring any party by virtue of the authorship of any of the
provisions of this Agreement. As used in this Agreement, the singular shall include the plural and
vice versa, and the terms "include" and "including" shall be deemed to be immediately followed by
the phrase "but not limited to." The terms "herein" and "hereunder" and similar terms shall be
interpreted to refer to this entire Agreement, including any schedules attached hereto. 14.9.
Parties/Relationship. Neither party shall hold itself out to third parties as possessing any power
or authority to enter into any contract or commitment on behalf of any other party. This Agreement
is not intended to, and shall not; create any agency, partnership or joint venture relationship
between or among the Parties. Each Party is an independent contractor with respect to the others. No
Party is granted any right or authority to assume or create any obligation or responsibility,
express or implied, on behalf of, or in the name of any other Party hereto, or to bind any other
party hereto in any manner or with respect to anything, whatsoever. 9
<!-- page 10 -->
14.10. Captions. The captions and headings in this Agreement are inserted for convenience and
reference only and in no way define or limit the scope or content of this Agreement and shall not
affect the interpretation of its provisions. 14.11. Counterparts. This Agreement may be executed in
multiple counterparts, each of which shall be deemed an original and all of which together shall
constitute one and the same instrument. 14.12. Subcontractors. Any work that is to be done by any
Party under this Agreement may be subcontracted to a third party in accordance with the approved
Marketing Authorisation, cGMPs and any applicable PMDA guidelines which relate to the work to be
performed under the direction and supervision of such party, as the case may be; provided, however,
that the subcontracting party exercises reasonable diligence in selecting such subcontractor and, as
between the parties hereto, the subcontracting party shall be and remain responsible for all acts
and omissions of any such subcontractor. 14.13. Schedules and Exhibits. All Schedules and Exhibits
referenced in this Agreement, if any, are hereby incorporated by reference into, and made a part of,
this Agreement. 14.14. Currency. All sums set forth in this Agreement and ay appendices, exhibits or
schedules hereto are, and are intended to be, expressed in US dollars.

IN WITNESS WHEREOF, the parties have executed the Agreement as of the date first above written.
HOVIONE INTER AG:

By: /s/ Frederic Kahn Name: Frederic Kahn Its: VP Marketing and Sales 10
<!-- page 11 -->
INTERSECT ENT, INC.:

By: /s/ Thomas A. West Name: Thomas A. West Its: CEO 11
