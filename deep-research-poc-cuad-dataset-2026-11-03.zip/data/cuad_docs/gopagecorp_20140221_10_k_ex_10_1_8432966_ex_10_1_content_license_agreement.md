<!-- page 1 -->
# WEBSITE CONTENT LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2014-02-10 |
| Parties | PSiTech Corporation ("Licensor"); Empirical Ventures, Inc ("Licensee") |
| Source | CUAD v1 / GopageCorp_20140221_10-K_EX-10.1_8432966_EX-10.1_Content License Agreement |

CONFIDENTIAL

PSiTECHCORPORATION WEBSITE CONTENT LICENSE AGREEMENT This Content License Agreement ("Agreement"),
dated as of Feb 10, 2014 (the "Effective Date"), is by and between PSiTech Corporation, a BVI
Corporation, with offices located at 303, 3rdFl, St. Georges Bldg, 2 Ice House St, Central, Hong
Kong("Licensor"), and Empirical Ventures, Inc., a Nevada corporation with offices located at 100, 40
Lake Bellevue Dr, Bellevue, WA("Licensee"). WHEREAS, Licensee owns, operates and controls the
Licensee Site (as defined below); WHEREAS, Licensor owns or otherwise has the right to license the
Licensed Content (as defined below); WHEREAS, Licensee wishes to make Licensed Content accessible on
the Licensee Site; and WHEREAS, Licensor is willing to license the Licensed Content to Licensee,
subject to all terms and conditions set forth herein. NOW, THEREFORE, in consideration of the mutual
covenants, terms and conditions set forth herein, and for other good and valuable consideration, the
receipt and sufficiency of which are hereby acknowledged, the parties agree as follows: 1.
Definitions. For purposes of this Agreement, the following terms have the following meanings. Other
terms defined in the body of the Agreement shall have the meanings so given. "Affiliate" of a Person
means any other Person that directly or indirectly, through one or more intermediaries, controls, is
controlled by, or is under common control with, such Person. The term "control" (including the terms
"controlled by" and "under common control with") means the direct or indirect ownership of more than
fifty percent (50 %) of the voting securities of a Person. "Confidential Information" means any
information that is treated as confidential by a party, including, without limitation, trade
secrets, technology, information pertaining to business operations and strategies, and information
pertaining to customers, pricing and marketing, in each case to the extent it is: (a) if in tangible
form, marked as confidential; or otherwise, identified at the time of disclosure as confidential, or
(b) would be considered as confidential information by one who is reasonably knowledgeable and
experienced in the field to which the information relates. With respect to each party, the terms of
this Agreement are Confidential Information of the other party.

1

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 2 -->
"Content Item" means each discrete creative work (for example, article, photograph or video), as
designated by the Licensor, that is included in the Licensed Content. "End User" means each natural
person that has access to Licensed Content on the Licensee Site. "Gross Revenues" means the gross
revenues received by the Licensee and derived from or in connection with the Licensee Site, from any
sources whatsoever, including but not limited to fees for access to and use of the Licensee Site and
advertising, sponsorship, marketing and other paid-for placements, andmaintenance, support and other
services. "Law" means any statute, law, ordinance, regulation, rule, code, order, constitution,
treaty, common law, judgment, decree, other requirement or rule of law of any federal, state, local
or foreign government or political subdivision thereof, or any arbitrator, court or tribunal of
competent jurisdiction. "Licensed Content" means those materials and content identified in Schedule
2, as may be amended by the parties as set forth herein. "Licensee Site" means the website operated
by Licensee on or through which the Licensed Content is displayed. "Losses" means losses, damages,
liabilities, deficiencies, actions, judgments, interest, awards, penalties, fines, costs or expenses
of whatever kind, including reasonable attorneys' fees and the cost of enforcing any right to
indemnification hereunder and the cost of pursuing any insurance providers.] "Mark" means any
trademark, trade name, service mark, design, logo, domain name or other indicator of the source or
origin of any product or service. Licensor's Mark as used in Section 3.3shall mean the Mark
"Go­Page", either in standard character or stylized format. "Multi­level Marketing" or "MLM" means a
direct sales or marketing strategy in which the sales force is compensated both for sales they
personally generate and for sales made by sales people they recruit. "Person" means an individual,
corporation, partnership, joint venture, limited liability entity, governmental authority,
unincorporated organization, trust, association or other entity. "Related Media" means those mobile
sites, mobile applications (apps), widgets, gadgets, RSS feeds, e-mail newsletters and other content
delivery media owned, operated and controlled by Licensee. "Territory" means Canada, United States
and Mexico.

2

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 3 -->
2. Delivery of Content. During the Term, except as otherwise set forth herein, Licensor shall make
available to Licensee the Licensed Content for display on the Licensed Site. Licensor reserves the
right to modify the Licensed Content in its reasonable discretion. Licensor shall notify Licensee of
any such modifications. Licensor is not liable for delays or failures of delivery beyond its
reasonable control. Licensor's sole responsibility for any such delay or failure is to deliver or
re-deliver the relevant Licensed Content as soon as reasonably possible. 3. License Grants. 3.1
Content License. Subject to Licensee's on­going compliance with Section 3.2 and all other terms and
conditions of this Agreement, Licensor grants to Licensee an exclusive (save for rights reserved to
Licensor hereunder), non-transferable (except as provided in Section 11.7) and non- sublicensable
license, during the License Term, to reproduce, perform, display, transmit and distribute the
Licensed Content on the Licensee Siteand Related Media intended solely for use by End Usersin the
Territory within the scope set forth in Schedule 1 (License Scope), which is attached hereto and
incorporated herein by this reference. The foregoing includes the right to permit End Users to
access the Licensed Content solely for their own end use and not for redistribution and otherwise
subject to Terms of Use that comply with Section 4.3. Licensee is not granted any right to, and
shall not, permit any other use of the Licensed Content by End Users, or any use of the Licensed
Content by any other Person (including Licensee's Affiliates). 3.2 Content License Restrictions. The
license granted in Section 3.1 is subject to the following: (a) Licensee shall not include Licensed
Content on the Licensee Site or any Related Media other than as expressly permitted herein and in
accordance with all terms and conditions of Section 4. (b) Licensee shall not make the Licensed
Content available, or otherwise use the Licensed Content, except as expressly licensed pursuant to
Section 3.1. Any use by Licensee of the Licensed Content on any other website, mobile site or
application or other media of Licensee other than the Licensee Site and Related Media as expressly
provided herein requires a separate written agreement between Licensor and Licensee, and Licensor
has no obligation to enter into any such agreement. (c) Licensee shall not permit the Licensed
Content to be, or appear to be, reproduced, displayed or distributed on, as part of or in connection
with any website or other online (including mobile) area other than the Licensee Site and Related
Media, whether by framing, in-line linking, appearing in a new window or otherwise. (d) Licensee
shall not edit, alter, modify, combine with other content or create any derivative works of the
Licensed Content without the prior written consent of Licensor. (e) Licensee shall not display, and
shall not permit others to display, on the Licensee Site any images or content that is or could be
reasonably construed to be offensive, pornographic, defamatory or libelous, infringing the
intellectual property rights of any third party, promoting terrorism or other unlawful violence, or
for any other purpose that violates applicable Law.

3

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 4 -->
(f) If Licensor instructs Licensee to delete or make inaccessible any Content Item because such
Content Item may contain errors, is or could be subject to a third-party claim or for any other good
faith reason, Licensee shall comply with such instruction as promptly as reasonably possible and, in
any case, within twenty-four (24) hours. The License Term for each such Content Item terminates at
the end of such 24-hour period. All uses of the Licensed Content that do not comply fully with the
provisions of this Section 3.2 shall for all purposes be deemed beyond the scope of the license
granted hereunder. Any violation of this Section 3.2 by Licensee shall be a material breach of this
Agreement for which Licensor may terminate this Agreement as set forth in Section 6.2(a). 3.3
Trademark License. (a) Licensor grants to Licensee a limited, non-exclusive, non-transferable
(except as provided in Section 11.7) and non-sublicensable royalty-free license during the Term to
those of Licensor's Marks designated by Licensor from time to time to: (i)display such Marks on the
Licensee Site: (x) with the Licensed Content to provide source attribution; or (y) as links to the
Licensed Content; (ii)comply with its express obligations under this Agreement; and (iii)advertise,
market and promote the availability of the Licensed Content or the Licensee Site and identify the
Licensor as a content provider; provided, that all uses of Licensor's Marks shall require Licensor's
prior written approval.

4

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 5 -->
(b) Licensee shall use the Marks solely in accordance with Licensor's trademark usage guidelines and
quality control standards as the same may be updated from time to time by Licensor. If Licensor
notifies Licensee that any use does not so comply, Licensee shall immediately either remedy the use
to the satisfaction of Licensor or terminate such use. Licensee shall not use, register or attempt
to register in any jurisdiction any Mark that is confusingly similar to or incorporates any of the
Licensor's Marks. All uses of the Licensor's Marks, and all goodwill associated therewith, shall
inure solely to the benefit of Licensor. 3.4 Reservation of Rights. Neither this Agreement nor the
licenses granted hereunder convey any ownership right in any of the Licensed Content, Licensor's
Marks or other materials provided by or on behalf of Licensor under this Agreement. Except for the
express licenses granted in this Agreement, all right, title and interest in and to the Licensed
Content and Licensor's Marks are and will remain with Licensor and its licensors. 4. Licensee
Obligations. 4.1 Content Display. Throughout the Term, Licensee shall provide the Licensed Content
on the Licensee Site and Related Media solely to the extent of and within the scope of the license
granted in this Agreement and otherwise in accordance with the following: (a) Licensee shall present
the Licensed Content solely in accordance with the specifications and restrictions set forth in
Schedule 4. (b) Licensee shall update Licensed Content on the Licensee Site and Related Media
promptly upon receipt of such updates from the Licensor. (c) Licensee shall present each Content
Item solely in its entirety (without any addition, modification or deletion). (d) Licensee shall
remove the Licensed Content from the Licensee Site and Related Media immediately upon the expiration
or earlier termination of the License Term for such Content Item. 4.2 Required Notices. Licensee
shall display with each Content Item the appropriate copyright and trademark notices and any other
source attribution required by Licensor. Licensee shall not alter, remove or obstruct any such
notices or attribution included with any Content Item as delivered by Licensor.

5

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 6 -->
4.3 Terms of Use. Throughout the Term, Licensee shall have in effect and maintain accessible on the
Licensee Site and Related Media website terms of use ("Terms of Use") and privacy policy ("Privacy
Policy") on which use of the Licensee Site and Related Media, including the Licensed Content, is
expressly conditioned, and which in form and substance are reasonably acceptable to Licensor. 4.4
Content Hosting and Support; User Complaints. Throughout the Term, Licensee shall host, operate,
maintain and make accessible to End Users the Licensed Content on the Licensee Site. The service
level standards and procedures used by Licensee with respect to the Licensed Content, including but
not limited to those regarding End User requests and communications, will be consistent with those
it employs with respect to other content on the Licensee Site. Without limiting the foregoing, if
Licensee receives any notice claiming that the Licensed Content infringes or otherwise violates any
intellectual property or other third-party right, Licensee shall: (a) immediately notify Licensor in
writing (which may include e-mail), including such detail as is available and necessary for Licensor
to evaluate and address such complaint; and (b) fully cooperate with Licensor in addressing such
claims. 5. Fees and Payment. 5.1 License Fees. In consideration of the licenses granted and other
undertakings by Licensor hereunder, Licensee shall pay Licensor a License Fee in the amount of two
hundred thousand dollars (US$200,000) ("License Fee"). The License Fee shall be due and payable as
follows: (a) US$50,000 upon signing the Memorandum of Understanding ("MOU") between the Parties
(provided, however, that Licensor hereby acknowledges receipt of this portion of the License Fee);
(b) US$50,000 upon signing of this Agreement; and (c) US$100,000 upon on or before March 28, 2014.
The License Fees are non-cancellable and non-refundable.

6

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 7 -->
5.2 In addition to the License Fee payable in accordance with Section 5.1, Licensee shall pay a
royalty ("Royalty") to Licensor according to the following schedule ("Royalty Schedule"):
Subscribers Royalty Payable as Percentage of Gross Revenue 0 - 5000 6.25% 5001 - 7500 6.75% 7501 -
10,000 7.00% 10,001 - 15,000 8.00% 15,001 - 20,000 8.50% 20,001 - 25,000 9.25% 25,001+ 9.75% 5.3
Reports and Payment (a) Not later than the fifteenth (15th) calendar day of each calendar quarter
(or the first business day thereafter), Licensee shall deliver to Licensor (i) a report accurately
showing Gross Revenues of the Licensee for the previous quarter, the number of Subscribers on the
last day of such previous quarter and the amount of Royalties due thereon, and (ii) payment of the
Royalties payable for such previous quarterbased on the Subscriber information as reflected in the
report. All payments under this Agreement shall be made in US dollars. (b) If Licensee fails to make
any payment when due: (i)Licensor shall have the right to terminate this Agreement and all licenses
granted hereunder as provided in Section 6.2; and] (ii)If any License Fees or Royalties are more
than ten (10) days past due, Licensor may assess interest on the past due amount at the rate of one
and a half percent (1.5%) per month or, if lower, the highest rate permitted under applicable Law.

7

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 8 -->
5.4 Taxes. All License Fees are exclusive of sales, use, value added, and similar taxes, which are
the responsibility of Licensee. If Licensee is required under any applicable Law to withhold any
amount from such payment, Licensee shall hold such funds in trust for Licensor and shall cooperate
with Licensor in completing and filing all forms and other documents required for the release of the
funds withheld for payment to Licensor. 5.5 Audit Right. During the Term and for five (5) years
thereafter, Licensee shall maintain complete and accurate books and records regarding its business
operations relevant to the calculation of License Fees and any other information required to be
reported to Licensor under this Agreement. Licensee shall make such books and records, and
appropriate personnel, available during normal business hours for audit by Licensor or its
authorized representative; provided that Licensor shall: (a) provide Licensee with reasonable prior
notice of any audit; (b) undertake an audit no more than once per calendar year, unless a prior
audit has disclosed a balance due; and (c) conduct or cause to be conducted such audit in a manner
designed to minimize disruption of Licensee's normal business operations. Licensor may take copies
and abstracts of materials audited. Licensor will pay the cost of such audits unless an audit
reveals a discrepancy in payment or reporting of five percent (5%) or more, in which case the
Licensee shall reimburse the Licensor for the reasonable cost of the audit. Licensee shall
immediately upon notice from Licensor pay Licensor the amount of any underpayment revealed by the
audit, including interest calculated in accordance with Section 5.3(b)(ii), together with any
reimbursement pursuant to the preceding sentence.

8

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 9 -->
6. Term and Termination. 6.1 Term. The initial term of this Agreement commences as of the Effective
Date and, unless terminated earlier pursuant to any express provision of this Agreement, shall
continue until five (5) years following the Effective Date (the "Initial Term"). Thereafter, this
Agreement shall renew automatically for one (1) additional three (3) year period (the "Renewal Term"
and collectively, together with the Initial Term, the "Term") unless either party provides the other
with written notice of non-renewal at least ninety (90) days before the expiration of the Initial
Term]. 6.2 Termination. (a) Either party may terminate this Agreement, effective upon written notice
to the other party, if the other partymaterially breaches this Agreement, and such breach is
incapable of cure or, if capable of cure, (i) fails to commence a plan of action approved by
Licensor to cure such breach within thirty (30) days, or (ii) fails to cure such breach within
ninety (90) days after receiving written notice thereof, in either case after receiving notice of
the breach. Provided, however, that if the breach giving rise to the termination right under this
Section 6.2is non-payment of License Fees or Royalties, the cure period shall be ten (10) days. (b)
Either party may terminate this Agreement by written notice to the other party if the other party:
(i) becomes insolvent or admits its inability to pay its debts generally as they become due; (ii)
becomes subject, voluntarily or involuntarily, to any proceeding under any domestic or foreign
bankruptcy or insolvency law, which is not fully stayed within ten (10) business days or is not
dismissed or vacated within sixty (60) days after filing; (iii) is dissolved or liquidated or takes
any corporate action for such purpose; (iv) makes a general assignment for the benefit of creditors;
or (v) has a receiver, trustee, custodian or similar agent appointed by order of any court of
competent jurisdiction to take charge of or sell any material portion of its property or business.
6.3 Effect of Expiration or Termination. Upon any expiration or termination of this Agreement: (a)
All licenses granted under this Agreement shall also terminate, and Licensee shall immediately
delete from its systems and servers all Licensed Content, Licensor's Marks and any other materials
provided by Licensor. Upon Licensor's written request, Licensee shall promptly provide Licensor with
written certification of such deletion. (b) Licensee shall promptly pay all unpaid License Fees that
relate to the period prior to the effective date of expiration or termination.

9

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 10 -->
(c) If termination is by Licensor pursuant to Section 6.2(a), all License Fees that would have been
payable through the end of the then- current Term had the Agreement not been terminated early shall
become immediately due and payable. (d) If termination is by Licensee pursuant to Section 6.2(a),
Licensee shall be relieved of any obligation to pay License Fees that relate to the period after the
effective date of termination. (e) Each party shall (i) return to the other party all documents and
tangible materials (and any copies) containing, reflecting, incorporating or based on the other
party's Confidential Information, (ii) permanently erase all of the other party's Confidential
Information from its computer systems and (iii) certify in writing to the other party that it has
complied with the requirements of this Section 6.3(e). 6.4 Surviving Terms. The provisions set forth
in the following Sections, and any other right or obligation of the parties in this Agreement that,
by its nature, should survive termination or expiration of this Agreement, will survive any
expiration or termination of this Agreement: Section 3.4, Section 5.5,Section 6.3, this Section 6.4,
Section 7, Section 8, Section 9, Section 10 and Section 11. 7. Representations and Warranties. 7.1
Mutual Representations and Warranties. Each party represents and warrants to the other party that:
(a) it is duly organized, validly existing and in good standing as a corporation or other entity as
represented herein under the laws and regulations of its jurisdiction of incorporation, organization
or chartering; (b) it has the full right, power and authority to enter into this Agreement, to grant
the rights and licenses granted hereunder and to perform its obligations hereunder; (c) the
execution of this Agreement by its representative whose signature is set forth at the end hereof has
been duly authorized by all necessary corporate action of the party; and (d) when executed and
delivered by such party, this Agreement will constitute the legal, valid and binding obligation of
such party, enforceable against such party in accordance with its terms.

10

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 11 -->
7.2 DISCLAIMER. EXCEPT FOR THE EXPRESS WARRANTIES IN THIS AGREEMENT, (A) EACH PARTY HEREBY DISCLAIMS
ANY WARRANTY, WHETHER EXPRESS, IMPLIED, STATUTORY OR OTHERWISE, UNDER THIS AGREEMENT; AND (B)
LICENSOR SPECIFICALLY DISCLAIMS ALL IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE, TITLE AND NON- INFRINGEMENT. 8. Indemnification. 8.1 By Licensor. Licensor shall indemnify,
defend and hold harmless Licensee against all Losses arising out of or resulting from any claim,
suit, action or proceeding (each, an "Action") by an unaffiliated third party related to or arising
out of a claim that the Licensed Content or Licensor's Marks, or Licensee's use thereof solely in
compliance with this Agreement, infringes a copyright or trademark right of any third party
registered in any country in the Territory. The foregoing obligation shall not apply to Losses for
which Licensee is required to indemnify Licensor pursuant to Section 8.2. 8.2 By Licensee. Licensee
shall indemnify, defend and hold harmless Licensor against all Losses arising out of or resulting
from any Action by a third party related to or arising out of: (a) the Licensee Site or Related
Media, including any material displayed or services provided thereon but excluding Licensed Content
and Marks used in accordance with this Agreement; (b) Licensee's use of the Licensed Content and/or
Licensor's Marks in a manner not permitted by this Agreement (including Licensee's continued use of
any Content Item in violation of Section 4.1(d) or any of Licensor's Marks after Licensor has
directed Licensee to cease using any such Marks; or (c) Licensee's failure to comply fully with
Section 4.3. 8.3 Indemnification Procedure. The indemnified party shall promptly notify the
indemnifying party in writing of any Action and cooperate with the indemnifying party at the
indemnifying party's sole cost and expense. The indemnifying party shall not settle any Action in a
manner that adversely affects the rights of the indemnified party without the indemnified party's
prior written consent, which shall not be unreasonably withheld or delayed. The indemnified party
may retain counsel of its choice to observe the proceedings at its own cost and expense. 9.
LIMITATIONS OF LIABILITY. 9.1 No Consequential or Indirect Damages. NEITHER PARTY SHALL BE LIABLE
UNDER OR IN CONNECTION WITH THIS AGREEMENT FOR INDIRECT, INCIDENTAL, CONSEQUENTIAL, LIQUIDATED,
SPECIAL OR EXEMPLARY DAMAGES OR PENALTIES, INCLUDING WITHOUT LIMITATION, LOSSES OF BUSINESS, REVENUE
OR ANTICIPATED PROFITS, REGARDLESS OF WHETHER SUCH DAMAGE WAS FORESEEABLE AND WHETHER LICENSOR HAS
BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

11

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 12 -->
9.2 Cap on Monetary Damages. EACH PARTY'S LIABILITY ARISING OUT OF OR RELATED TO THIS AGREEMENT WILL
NOT EXCEED AN AMOUNT EQUAL TO THE AGGREGATE AMOUNTS PAID OR PAYABLE TO LICENSOR IN THE TWELVE (12)
MONTHS PRECEDING THE COMMENCEMENT OF THE CLAIM. 9.3 Exceptions. The provisions of Section 9.1 and
Section 9.2 will not apply to limit the Licensee's indemnification obligations under Section 8.2, or
in the case of Licensee's gross negligence or wilful misconduct. 10. Confidentiality. Obligation of
Confidentiality. Each party (the "Recipient") acknowledges that in connection with this Agreement
such party may gain access to Confidential Information of the other party (the "Disclosing Party").
As a condition to being furnished with Confidential Information, the Recipient agrees, during the
Term and for five (5) years thereafter. Confidential Information excludes such information required
to be disclosed pursuant to federal or state securities rules and regulations, including but not
limited to, disclosure of the Company in their filings with the Securities and Exchange Commission:
to 10.1 (a) not use the Disclosing Party's Confidential Information other than in connection with
performing its obligations under this Agreement and shall make no use of any such Confidential
Information, directly or indirectly, in any manner to the detriment of the Disclosing Party or in
order to obtain any competitive benefit with respect to the Disclosing Party; and (b) maintain the
Disclosing Party's Confidential Information in confidence and, subject to Section 10.2 below, not
disclose any of the Disclosing Party's Confidential Information without the Disclosing Party's prior
written consent; provided, however, that Recipient may disclose the Disclosing Party's Confidential
Information to its officers, employees, consultants and legal advisors ("Representatives") who: (i)
have a "need to know" for purposes of the Recipient's performance under this Agreement, (ii) have
been apprised of this restriction; and (iii) are themselves bound by nondisclosure restrictions at
least as restrictive as those set forth in this Section 0. The Recipient shall be responsible for
ensuring its Representatives' compliance with, and shall be liable for any breach by its
Representatives, of this Section 10. The Receiving Party shall employ the same efforts it uses with
respect to its own confidential information to safeguard the Disclosing Party's Confidential
Information from use or disclosure to anyone other than as permitted hereby.

12

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 13 -->
10.2 Exceptions. (a) Confidential Information does not include information of the Disclosing Party
that: (i)is already known to the Recipient without restriction on use or disclosure prior to receipt
of such information from the Disclosing Party; (ii)is or becomes generally known by the public other
than by breach of this Agreement by, or other wrongful act of, the Recipient; or (iii)is received by
the Recipient from a third party who is not under any obligation to the Disclosing Party to maintain
the confidentiality of such information. (b) If the Recipient becomes legally compelled to disclose
any of the Disclosing Party's Confidential Information, the Recipient shall: (i)provide prompt
written notice to the Disclosing Party notice so that the Disclosing Party may seek a protective
order or other appropriate remedy or waive its rights under this Section 10; and (ii)disclose only
the portion of Confidential Information that it is legally required to furnish. If a protective
order or other remedy is not obtained, or the Disclosing Party waives compliance, the Recipient
shall, at the Disclosing Party's expense, use reasonable efforts to obtain assurance that
confidential treatment will be afforded the Confidential Information.

13

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 14 -->
11. Miscellaneous. 11.1 Further Assurances. Upon a party's reasonable request, the other party
shall, at its sole cost and expense, promptly execute and deliver all such further documents and
instruments, and take all such further actions, necessary to give full effect to the terms of this
Agreement. 11.2 Relationship of the Parties. The relationship between the parties is that of
independent contractors. Nothing contained in this Agreement shall be construed as creating any
agency, partnership, joint venture or other form of joint enterprise, employment or fiduciary
relationship between the parties, and neither party shall have authority to contract for or bind the
other party in any manner whatsoever. Public Announcements. Neither party shall issue or release any
announcement, statement, press release or other publicity or marketing materials relating to this
Agreement or, unless expressly permitted under this Agreement, otherwise use the other party's
Marks, in each case, without the prior written consent of the other party, which shall not be
unreasonably withheld or delayed; except the provisions of this paragraph excludes such information
required to be disclosed pursuant to federal or state securities rules and regulations, including
but not limited to, disclosure of the Company in their filings with the Securities and Exchange
Commission. 11.3 Notices. All notices, requests, consents, claims, demands, waivers and other
communications hereunder shall be in writing and addressed to the parties as follows (or as
otherwise specified by a party in a notice given in accordance with this Section):

If to Licensor: Room 303, 3rd Floor, St. George's Building, 2 Ice House Street, Central, Hong Kong
Facsimile: (852) 3526 0355 E-mail:angela@sg-cs.com Attention: Angela Jen If to Licensee: 100, 40
Lake Bellevue Dr, Bellevue, WA, 98005 Facsimile: [FAX NUMBER] E-mail: Peter@go-page.com Attention:
Peter Schulhof, President

14

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 15 -->
Notices sent in accordance with this Section shall be deemed effectively given: (a) when received,
if delivered by hand (with written confirmation of receipt); (b) when received, if sent by a
nationally recognized overnight courier (receipt requested); (c) on the date sent by facsimile or
e-mail (in each case, with confirmation of transmission), if sent during normal business hours of
the recipient, and on the next business day, if sent after normal business hours of the recipient;
or (d) on the third business day after the date mailed, by certified or registered mail, return
receipt requested, postage prepaid. 11.4 Interpretation. For purposes of this Agreement, (a) the
words "include," "includes" and "including" are deemed to be followed by the words "without
limitation"; (b) the word "or" is not exclusive; (c) the words "herein," "hereof," "hereby,"
"hereto" and "hereunder" refer to this Agreement as a whole; (d) words denoting the singular have a
comparable meaning when used in the plural, and vice-versa; and (e) words denoting any gender
include all genders. Unless the context otherwise requires, references in this Agreement: (x) to
sections, exhibits, schedules, attachments and appendices mean the sections of, and exhibits,
schedules, attachments and appendices attached to, this Agreement; (y) to an agreement, instrument
or other document means such agreement, instrument or other document as amended, supplemented and
modified from time to time to the extent permitted by the provisions thereof; and (z) to a statute
means such statute as amended from time to time and includes any successor legislation thereto and
any regulations promulgated thereunder. The parties intend this Agreement to be construed without
regard to any presumption or rule requiring construction or interpretation against the Party
drafting an instrument or causing any instrument to be drafted. The exhibits, schedules, attachments
and appendices referred to herein are an integral part of this Agreement to the same extent as if
they were set forth verbatim herein. 11.5 Headings. The headings in this Agreement are for reference
only and do not affect the interpretation of this Agreement. 11.6 Entire Agreement. This Agreement,
together with the attached Schedules and any other documents incorporated herein by reference,
constitutes the sole and entire agreement of the Parties with respect to the subject matter of this
Agreement and supersedes all prior and contemporaneous understandings, agreements, representations
and warranties, both written and oral, with respect to such subject matter. 11.7 Assignment. This
Agreement is personal to Licensee. Licensee shall not assign or otherwise transfer any of its
rights, or delegate or otherwise transfer any of its obligations or performance, under this
Agreement, in each case whether voluntarily, involuntarily, by operation of law or otherwise,
without Licensor's prior written consent. For purposes of the preceding sentence, and without
limiting its generality, any merger, consolidation or reorganization involving Licensee (regardless
of whether Licensee is a surviving or disappearing entity) will be deemed to be a transfer of
rights, obligations or performance under this Agreement for which Licensor's prior written consent
is required. No delegation or other transfer will relieve Licensee of any of its obligations or
performance under this Agreement. Any purported assignment, delegation or transfer in violation of
this Section 11.7 is void from the outset and shall be of no force or effect. Licensor may freely
assign or otherwise transfer all or any of its rights, or delegate or otherwise transfer all or any
of its obligations or performance, under this Agreement without Licensee's consent. This Agreement
is binding upon and inures to the benefit of the parties hereto and their respective permitted
successors and assigns.

15

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 16 -->
11.8 No Third-Party Beneficiaries. This Agreement is for the sole benefit of the parties hereto and
their respective successors and permitted assigns and nothing herein, express or implied, is
intended to or shall confer upon any other Person any legal or equitable right, benefit or remedy of
any nature whatsoever, under or by reason of this Agreement. 11.9 Amendment and Modification;
Waiver. No amendment to or modification of this Agreement is effective unless it is in writing and
signed by an authorized representative of each party. No waiver by any party of any of the
provisions hereof shall be effective unless explicitly set forth in writing and signed by the party
so waiving. Except as otherwise set forth in this Agreement, no failure to exercise, or delay in
exercising, any rights, remedy, power or privilege arising from this Agreement shall operate or be
construed as a waiver thereof; nor shall any single or partial exercise of any right, remedy, power
or privilege hereunder preclude any other or further exercise thereof or the exercise of any other
right, remedy, power or privilege. 11.10 Severability. If any term or provision of this Agreement is
invalid, illegal or unenforceable in any jurisdiction, such invalidity, illegality or
unenforceability shall not affect any other term or provision of this Agreement or invalidate or
render unenforceable such term or provision in any other jurisdiction. Upon such determination that
any term or other provision is invalid, illegal or unenforceable, the parties hereto shall negotiate
in good faith to modify this Agreement so as to effect the original intent of the parties as closely
as possible in a mutually acceptable manner in order that the transactions contemplated hereby be
consummated as originally contemplated to the greatest extent possible. 11.11 Governing Law;
Submission to Jurisdiction. This Agreement shall be governed by and construed in accordance with the
internal laws of the State of Nevada without giving effect to any choice or conflict of law
provision or rule. 11.12 Dispute Resolution. In the event of a dispute arising out of this
Agreement, the parties shall first negotiate in good faith in an effort to reach a settlement of the
dispute. If having negotiated in good faith, the parties are unable to resolve their dispute, the
parties shall submit the dispute to binding arbitration by a single arbitrator. The arbitration
shall be governed by the Commercial Rules of Arbitration of the American Arbitration Association.
The arbitration shall take place at an agreed location, or if the parties cannot agree on a venue in
Reno, Nevada or Vancouver, BC, as determined by the flip of a coin. The arbitrator shall have
jurisdiction over the conduct of discovery prior to the hearing. Notwithstanding the foregoing,
nothing in this Section 11.13 shall be construed to prohibit either party from seeking appropriate
injunctive or other equitable relief in a court of competent jurisdiction.

16

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 17 -->
11.13 Attorneys' Fees. In the event that any action, suit, or other legal or administrative
proceeding is instituted or commenced by either party hereto against the other party arising out of
this Agreement, the prevailing party shall be entitled to recover its reasonable attorneys' fees and
court costs from the non-prevailing party. 11.14 Counterparts. This Agreement may be executed in
counterparts, each of which is deemed an original, but all of which together are deemed to be one
and the same agreement. A signed copy of this Agreement delivered by facsimile, e-mail or other
means of electronic transmission is deemed to have the same legal effect as delivery of an original
signed copy of this Agreement.

IN WITNESS WHEREOF, the parties hereto have executed this Agreement as of the date first above
written. PSITech Corporation By /s/Cameron Investments Limited Name: Cameron Investments Limited
Title: Director

Empirical Ventures, Inc. By /s/Peter Schulhof Name: Peter Schulhof Title: President

17

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 18 -->
SCHEDULE 1 LICENSE SCOPE

Display the Licensed Content on the Licensee Site to actual and prospective customers or End-Users
located within Canada, the United States or Mexico engaged in any vertical market business except(i)
the offer or brokering of vacation home rentals, and (ii) the offering or sale of any products or
services using a Multi-level Marketing system.

18

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 19 -->
SCHEDULE 2 LICENSED CONTENT The Licensed Content consists of content and images and code.

19

Source: GO-PAGE CORP, 10-K, 2/21/2014
<!-- page 20 -->
Source: GO-PAGE CORP, 10-K, 2/21/2014
