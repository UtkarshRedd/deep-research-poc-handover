<!-- page 1 -->
# Amended and Restated Unconditional Capital Maintenance Agreement
| Field | Value |
|---|---|
| Document Type | Maintenance Agreement |
| Agreement Date | 2014-02-18 |
| Parties | American International Group, Inc. ("AIG"); American General Life Insurance Company ("Company") |
| Source | CUAD v1 / VARIABLESEPARATEACCOUNT_04_30_2014-EX-13.C-UNCONDITIONAL CAPITAL MAINTENANCE AGREEMENT |

Exhibit (13)(c)

AMENDED AND RESTATED UNCONDITIONAL CAPITAL MAINTENANCE AGREEMENT BETWEEN AMERICAN INTERNATIONAL
GROUP, INC. AND AMERICAN GENERAL LIFE INSURANCE COMPANY

This Amended and Restated Unconditional Capital Maintenance Agreement (this "Agreement"), is made,
entered into and effective as of February 18, 2014, by and between American International Group,
Inc., a corporation organized under the laws of the State of Delaware ("AIG"), and American General
Life Insurance Company, a corporation organized under the laws of the Texas (the "Company").

WITNESSETH:

WHEREAS, the Company is a life insurer subject to certain capital requirements of the insurance laws
and regulations of Texas (the "Domiciliary State");

WHEREAS, the Company is an indirect wholly owned subsidiary of AIG;

WHEREAS, AIG has an interest in unconditionally maintaining the Company's financial condition; and

WHEREAS, AIG and the Company executed that certain Unconditional Capital Maintenance Agreement,
dated March 30, 2011 (as amended, the "2011 CMA"), and the parties have agreed to amend and restate
such 2011 CMA as provided in this Agreement:

NOW, THEREFORE, in consideration of the mutual promises herein contained, the parties hereto agree
as follows:

1. Capital Contributions. In the event that the Company's Total Adjusted Capital for each of the
Company's first and third fiscal quarters (as determined based on the Company's first and third
fiscal quarterly filed statutory financial statements, respectively, subject to any adjustments or
modifications thereto required by the Domiciliary State's insurance department or the Company's
independent auditors) falls below the Specified Minimum Percentage of the Company's projected
Company Action Level RBC (in each case as estimated by the Company as of the end of each such first
and third fiscal quarters, as the case may be, taking into account (for purposes of such estimation)
facts and circumstances occurring after the end of such fiscal quarter but before such time as AIG
would be obligated pursuant to paragraph 3 to make a contribution), AIG shall, within the respective
time periods set forth under paragraph 3, in accordance with paragraph 4 and in compliance with
applicable law, provide to the Company cash, cash equivalents, securities or other
<!-- page 2 -->
instruments that qualify (as admitted assets) for purposes of calculating the Company's Total
Adjusted Capital, as a contribution and not as a loan, in an amount such that the Company's Total
Adjusted Capital as of the end of each of the Company's second and fourth fiscal quarter, as the
case may be, will be projected to be at least equal to the Specified Minimum Percentage of the
Company's Company Action Level RBC. Notwithstanding the foregoing, AIG may, at any time as it deems
necessary in its sole discretion and in compliance with applicable law, make a contribution to the
Company in such amount as is required for the Company's Total Adjusted Capital to equal a percentage
of its Company Action Level RBC determined to be appropriate by the Company and AIG.

2. Defined Terms. For the avoidance of doubt, the terms "Total Adjusted Capital" and "Company Action
Level RBC" shall have the meanings ascribed thereto under the insurance laws and regulations of the
Domiciliary State, or, if not defined therein, shall have the meanings ascribed thereto in the
risk-based capital ("RBC") instructions promulgated by the National Association of Insurance
Commissioners ("NAIC"). The term "Specified Minimum Percentage" shall be equal to the percentage set
forth on Schedule 1 attached hereto, which shall be agreed to by AIG and the Company at least once
every year beginning upon the date of the filing of the Company's 2014 Annual Statement with the
Domiciliary State's insurance department and following review against the capital adequacy standards
and criteria ("Agency Criteria") of each of Standard & Poor's Corp. ("S&P"), Moody's Investors
Service ("Moody's") and A.M. Best Company ("A.M. Best"). Notwithstanding the obligation of the
Company and AIG to review the Specified Minimum Percentage on an annual basis, the parties hereto
agree to review and revise the Specified Minimum Percentage on a more frequent basis, if the parties
agree it is appropriate, to take into account (a) any material changes after the date hereof to any
Agency Criteria adopted by any of S&P, Moody's or A.M. Best, on the one hand, or to the law of the
Domiciliary State or NAIC RBC rules or instructions, on the other hand, which causes the results
under the Agency Criteria to diverge from that under the law of the Domiciliary State or NAIC RBC
rules or instructions, (b) the Company completes a material transaction that is treated materially
differently by the Agency Criteria, on the one hand, and the NAIC RBC rules or instructions, on the
other hand, or (c) any other material development or circumstance affecting the Company which AIG
and the Company agree merits a reevaluation of the Specified Minimum Percentage then in effect.

3. Timing of Capital Contributions. The Company and AIG agree that any contribution to be made under
paragraph 1 will take place within the following two time periods per year, as applicable: (a)
during the time beginning on the first business day after the filing of the Company's first

2
<!-- page 3 -->
fiscal quarterly statutory financial statements and ending on the last business day prior to the end
of the Company's second fiscal quarter; and (b) during the time beginning on the first business day
after the filing of the Company's third fiscal quarterly statutory financial statements and ending
on the last business day prior to the end of the Company's fourth fiscal quarter. Notwithstanding
the foregoing, in compliance with applicable law, any capital contribution provided for under
paragraph 1 may be made by AIG after the close of any fiscal quarter or fiscal year of the Company
but prior to the filing by the Company of its statutory financial statements for such fiscal quarter
or fiscal year, respectively, and contributions of this nature shall be recognized as capital
contributions receivable as of the balance sheet date of the yet to be filed quarterly or annual
financial statement (as the case may be), pursuant to paragraph 8 of Statement of Statutory
Accounting Principles No. 72, to the extent approved by the Domiciliary State.

4. Funding Mechanics. At the time that any contribution is due under paragraph 3, AIG agrees that it
will either (a) make such contribution to the Company's direct parent and cause such direct parent
to then contribute such funds, securities or instruments so contributed by AIG to the Company, or
(b) make such contribution directly to the Company without receiving any capital stock or other
ownership interest in exchange therefor. All contributions contemplated under this Agreement shall
be approved and made in compliance with applicable law, including, without limitation, approval by
the board of directors of each applicable entity and any prior notice or approval requirements
specified under applicable rules and regulations.

5. AIG Policies. Subject to the requirements of applicable law and the approval, to the extent
required, by any or all of the Company's senior management, relevant management committees, board of
directors, and of any insurance regulator, the Company hereby acknowledges that, in a manner
consistent with past practice and any other reasonable requirements of AIG, it will comply with all
financial and budgetary planning, risk mitigation, derisking or pricing, corporate governance,
investment, informational and procedural requirements set forth by AIG.

6. No Failure to Claim. AIG hereby waives any failure or delay on the part of the Company in
asserting or enforcing any of its rights or in making any claims or demands hereunder.

7. Termination. Unless earlier terminated in accordance with this paragraph 7, this Agreement shall
continue indefinitely. AIG shall have the absolute right to terminate this Agreement upon thirty
(30) days' prior written notice to the Company, which notice shall state the effective date of
termination (the "Termination Date"); provided, however, that AIG agrees not to terminate this
Agreement unless (a) AIG significantly modifies the

3
<!-- page 4 -->
corporate structure or ownership of the Company, or (b) AIG sells the Company to an acquirer, in
each case, (i) having a rating from at least one of S&P, Moody's, A.M. Best or a substitute agency,
which is a nationally recognized statistical rating organization, that is at least equal to the
lower of (x) AIG's then-current rating from such agency or (y) the Company's then-current rating as
supported by this Agreement from such agency; or (ii) such that, immediately on the effective date
of the modification of corporate structure or sale by AIG of the Company, the Company's
capitalization is consistent with the minimum capital adequacy standards and criteria of at least
one of S&P, Moody's, A.M. Best or a substitute agency, which is a nationally recognized statistical
rating organization, for a rating that is equal to or better than the Company's then-current rating
on the date immediately preceding such modification of corporate structure or sale. To the extent
not terminated previously by AIG pursuant to the foregoing, this Agreement will terminate
automatically one year after the closing of any sale of the Company by AIG, and all provisions
hereof will be of no further force and effect. For the avoidance of doubt, the termination of this
Agreement pursuant to this paragraph 7 shall not relieve either party of any obligation it may owe
to the other party hereunder that existed prior to, and remains outstanding as of, the Termination
Date.

8. Policyholder Rights. Any policyholder holding a policy issued by the Company prior to the
termination of this Agreement shall have the right to demand that the Company enforce the Company's
rights under paragraphs 1, 3 and 4 of this Agreement, and, if the Company fails or refuses to take
timely action to enforce such rights or the Company defaults in any claim or other payment owed to
any such policyholder when due, such policyholder may proceed directly against AIG to enforce the
Company's rights under paragraphs 1, 3 and 4 of this Agreement; provided, however, that no
policyholder of the Company may take any action authorized under this paragraph 8 unless and until
(a) such policyholder has given AIG written notice of its intent to enforce the terms of this
Agreement as provided in this paragraph 8, which notice shall specify in reasonable detail the
nature of and basis for the policyholder's complaint and (b) AIG has failed to comply with this
Agreement within sixty (60) days after such notice is given; and, provided, further, that upon
termination of this Agreement in accordance with paragraph 7 hereof, the rights of any policyholder
as provided for under this paragraph 8 shall terminate effective as of the Termination Date, except
with respect to the obligation of AIG (if any) to make capital contributions to the Company pursuant
to paragraphs 1, 3 and 4 of this Agreement solely to the extent such obligation arose prior to, and
remained unsatisfied as of, the Termination Date (it being understood that upon AIG's satisfaction
of all such obligations after the Termination Date, no such policyholder shall have any rights
against the Company or AIG, as the case may be, under this paragraph 8).

4
<!-- page 5 -->
9. No Indebtedness; No Policyholder Recourse Against AIG. This Agreement is not, and nothing herein
contained and nothing done pursuant hereto by AIG shall constitute or be construed or deemed to
constitute, an evidence of indebtedness or an obligation or liability of AIG as guarantor, endorser,
surety or otherwise in respect of any obligation, indebtedness or liability, of any kind whatsoever,
of the Company. This Agreement does not provide, and is not intended to be construed or deemed to
provide, any policyholder of the Company with recourse to or against any of the assets of AIG.

10. Notices. Any notice, instruction, request, consent, demand or other communication required or
contemplated by this Agreement shall be in writing, shall be given or made or communicated by United
States first class mail, addressed as follows:

If to AIG:

American International Group, Inc. 175 Water Street New York, New York 10038 Attention: Secretary

If to the Company:

American General Life Insurance Company

2919 Allen Parkway Houston, Texas 77019 Attention: Chief Financial Officer

with a copy (which shall not constitute notice) to:

American General Life Insurance Company c/o AIG Life and Retirement 1999 Avenue of the Stars, 27t h
Floor Los Angeles, CA 90067 Attention: General Counsel

11. Successors. The covenants, representations, warranties and agreements herein set forth shall be
mutually binding upon and inure to the mutual benefit of AIG and its successors and the Company and
its successors.

12. Governing Law. This Agreement shall be governed by and construed in accordance with the laws of
New York, without giving effect to the principles of conflict of laws.

5
<!-- page 6 -->
13. Severability. If any provision of this Agreement shall be declared null, void or unenforceable
in whole or in part by any court, arbitrator or governmental agency, said provision shall survive to
the extent it is not so declared and all the other provisions of this Agreement shall remain in full
force and effect unless, in each case, such declaration shall serve to deprive any of the parties
hereto of the fundamental benefits of or rights under this Agreement.

14. Entire Agreement; Amendments. This Agreement constitutes the entire agreement between the
parties hereto with respect to the subject matter hereof and supersedes all prior and
contemporaneous agreements, understandings, negotiations and discussion, whether oral or written, of
the parties. This Agreement may be amended at any time by written agreement or instrument signed by
the parties hereto.

15. Headings. The section headings contained in this Agreement are inserted for convenience only and
shall not affect in any way the meaning or interpretation of this Agreement.

16. Counterparts. This Agreement may be signed by the parties in one or more counterparts which
together shall constitute one and the same agreement among the parties.

[signature page follows]

6
<!-- page 7 -->
IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be duly executed by their
respective authorized officers as of the day and year first above written. AMERICAN INTERNATIONAL
GROUP, INC. By: /s/ Charles S. Shamieh

Name: Charles S. Shamieh Title: Senior Vice President and Chief Corporate Actuary AMERICAN GENERAL
LIFE INSURANCE COMPANY By: /s/ Mary Jane Fortin

Name: Mary Jane Fortin Title: Executive Vice President & Chief Financial Officer
<!-- page 8 -->
SCHEDULE 1

The Specified Minimum Percentage shall equal 385% of the Company's Company Action Level RBC.
