<!-- page 1 -->
# JOINT FILING STATEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| Agreement Date | 2020-04-08 |
| Parties | SCULPTOR CAPITAL LP; SCULPTOR CAPITAL HOLDING CORPORATION; SCULPTOR MANAGEMENT, INC.; SCULPTOR MASTER FUND LTD |
| Source | CUAD v1 / VIRGINGALACTICHOLDINGS,INC_04_08_2020-EX-99.1-JOINT FILING STATEMENT |

Schedule 13 G CUSIP No. 30734W208 EXHIBIT 1 JOINT FILING STATEMENT PURSUANT TO RULE 13d-1(k)

The undersigned acknowledge and agree that the foregoing statement on this Schedule 13G is filed on
behalf of each of the undersigned and that all subsequent amendments to this statement on Schedule
13G shall be filed on behalf of each of the undersigned without the necessity of filing additional
joint acquisition statements. The undersigned acknowledge that each shall be responsible for the
timely filing of such amendments and for the completeness and accuracy of the information concerning
him or it contained herein or therein, but shall not be responsible for the completeness and
accuracy of the information concerning the others, except to the extent that he or it knows or has
reason to believe that such information is inaccurate.

DATED: April 8, 2020 SCULPTOR CAPITAL LP

By: /s/ Thomas Sipp Thomas Sipp Chief Financial Officer SCULPTOR CAPITAL HOLDING CORPORATION

By: /s/ Thomas Sipp Thomas Sipp Chief Financial Officer SCULPTOR MANAGEMENT, INC.

By: /s/ Thomas Sipp Thomas Sipp Chief Financial Officer SCULPTOR MASTER FUND LTD

By: /s/ Thomas Sipp Thomas Sipp Chief Financial Officer
