<!-- page 1 -->
# JOINT FILING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| SEC Filing Date | 2020-01-22 |
| Parties | ARES TRADING SA; MERCK SERONO SA COINSINS, SWITZERLAND, AN AFFILIATE OF MERCK KGAA, DARMSTADT, GERMANY; MERCK KGAA DARMSTADT, GERMANY |
| Source | CUAD v1 / PRECIGEN,INC_01_22_2020-EX-99.1-JOINT FILING AGREEMENT |

Exhibit 99.1 JOINT FILING AGREEMENT Additional Reporting Person (a): Merck Serono SA Address: Zone
Industrielle 1267 Coinsins, Switzerland Additional Reporting Person (b): Merck KGaA Address:
Frankfurter Str. 250 64293 Darmstadt, Germany Designated Filer: Ares Trading SA Issuer and CUSIP:
Intrexon Corporation (46122T102) Dated: January 7, 2019 ARES TRADING SA ARES TRADING SA By: /s/
Cédric Hyde By: /s/ Luigia Bocola Name: Cédric Hyde Name: Luigia Bocola Title: CFO Title: Finance
Manager MERCK SERONO SA, COINSINS, SWITZERLAND, AN AFFILIATE OF MERCK KGAA, DARMSTADT, GERMANY MERCK
SERONO SA, COINSINS, SWITZERLAND, AN AFFILIATE OF MERCK KGAA, DARMSTADT, GERMANY By: /s/ Cédric Hyde
By: /s/ Tearaboth Te Name: Cédric Hyde Name: Tearaboth Te Title: CFO Title: Treasury Director MERCK
KGAA, DARMSTADT, GERMANY MERCK KGAA, DARMSTADT, GERMANY By: /s/ Rando Bruns By: /s/ Tim Nielsen
Name: Rando Bruns Name: Tim Nielsen Title: Head of Treasury Title: Head of Capital Markets
