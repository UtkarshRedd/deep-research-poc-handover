<!-- page 1 -->
# Credit Agreement — Halvorsen Marine Holdings
| Field | Value |
|---|---|
| Document Type | Credit Agreement |
| Effective Date | 2025-02-14 |
| Parties | Halvorsen Marine Holdings, Inc.; Meridian Trust Bank, N.A. |
| Facility ID | FAC-2025-0042 |
| Version | Original (Execution Version) |

THIS CREDIT AGREEMENT (this "Agreement") is entered into as of 2025-02-14 (the "Effective Date"), among Halvorsen Marine Holdings, Inc., a Delaware entity (the "Borrower"), the Lenders party hereto, and Meridian Trust Bank, N.A., as administrative agent for the Lenders (in such capacity, the "Administrative Agent").

## Recitals
WHEREAS, the Borrower has requested that the Lenders make available a revolving credit facility in an aggregate principal amount of $150,000,000 (one hundred fifty million dollars) for working capital and general corporate purposes;
WHEREAS, the Lenders are willing to do so on the terms and subject to the conditions set forth herein;
NOW, THEREFORE, the parties agree as follows.
<!-- page 2 -->
## Article I — Definitions
Section 1.1 Defined Terms. As used in this Agreement, the following terms have the meanings set forth below.
"Administrative Agent" has the meaning assigned in the preamble.
"Aggregate Commitment" means the aggregate of the Commitments of all Lenders, which on the Effective Date is $150,000,000.
"Applicable Margin" means, for any day, 2.75% per annum for Term SOFR Loans and, for Base Rate Loans, the Applicable Margin for Term SOFR Loans minus 1.00% per annum.
"Base Rate" means, for any day, the greatest of (a) the Prime Rate, (b) the Federal Funds Effective Rate plus 0.50% and (c) Adjusted Term SOFR for a one-month tenor plus 1.00%.
"Business Day" means any day other than a Saturday, Sunday or other day on which commercial banks in New York City are authorized or required by law to close.
"Change of Control" means the acquisition by any person or group of beneficial ownership of more than 35% of the voting equity interests of the Borrower.
"Consolidated EBITDA" means, for any period, Consolidated Net Income for such period plus, without duplication, interest expense, taxes, depreciation and amortization, each to the extent deducted in determining Consolidated Net Income.
"Consolidated Total Debt" means, as of any date, the aggregate principal amount of Indebtedness of the Borrower and its Subsidiaries on a consolidated basis.
<!-- page 3 -->
Section 1.1 Defined Terms (continued).
"Facility" means the revolving credit facility established hereunder, identified in the Administrative Agent's records as FAC-2025-0042.
"Guarantors" means each Subsidiary party to the Guarantee and each other person that becomes a Guarantor pursuant to Section 6.9.
"Interest Coverage Ratio" means, for any period of four consecutive fiscal quarters, the ratio of Consolidated EBITDA to Consolidated Interest Expense for such period.
"Leverage Ratio" means, as of the last day of any fiscal quarter, the ratio of Consolidated Total Debt as of such day to Consolidated EBITDA for the period of four consecutive fiscal quarters then ended.
"Loan Documents" means this Agreement, the Notes, the Guarantee, the Security Agreement, the Fee Letter and each other agreement designated as a Loan Document by the Borrower and the Administrative Agent.
"Maturity Date" means 2030-02-14, or, if such day is not a Business Day, the immediately preceding Business Day.
"Material Adverse Effect" means a material adverse effect on the business, assets, operations or financial condition of the Borrower and its Subsidiaries, taken as a whole.
"Term SOFR" means the forward-looking term rate based on SOFR published by the CME Term SOFR Administrator for the applicable interest period.
Section 1.2 Interpretation. Section and Article references are to this Agreement unless otherwise specified. The word "including" is not limiting.
<!-- page 4 -->
## Article II — The Commitments and Loans
Section 2.1 Commitments. Subject to the terms and conditions set forth herein, each Lender severally agrees to make Revolving Loans to the Borrower in an aggregate principal amount not exceeding its Commitment. The Aggregate Commitment on the Effective Date is $150,000,000.
Section 2.2 Borrowing Procedure. The Borrower shall deliver a Borrowing Request to the Administrative Agent not later than 11:00 a.m. New York City time three (3) Business Days before the date of a proposed Term SOFR borrowing and one (1) Business Day before a Base Rate borrowing.
Section 2.3 Revolving Nature. Within the limits of the Commitments, the Borrower may borrow, prepay and reborrow prior to the Maturity Date.
Section 2.4 Repayment. The Borrower unconditionally promises to pay the outstanding principal amount of the Loans on the Maturity Date.
Section 2.5 Evidence of Debt. Each Lender shall maintain accounts evidencing the Indebtedness of the Borrower to such Lender; such accounts are prima facie evidence absent manifest error.
<!-- page 5 -->
## Article III — Interest and Fees
Section 3.1 Interest. Each Term SOFR Loan shall bear interest at Adjusted Term SOFR for the applicable interest period plus the Applicable Margin. Each Base Rate Loan shall bear interest at the Base Rate plus the Applicable Margin.
Section 3.2 Interest Payment Dates. Accrued interest on each Loan is payable in arrears on each Interest Payment Date and on the Maturity Date.
Section 3.3 Commitment Fee. The Borrower shall pay to the Administrative Agent for the account of each Lender a commitment fee at a rate per annum equal to 0.375% on the daily unused amount of such Lender's Commitment, payable quarterly in arrears.
Section 3.4 Computation. Interest and fees are computed on the basis of a year of 360 days and the actual number of days elapsed.
Section 3.5 Benchmark Replacement. If a Benchmark Transition Event occurs, the Administrative Agent and the Borrower may amend this Agreement to replace Term SOFR with a Benchmark Replacement in accordance with Section 10.2.
<!-- page 6 -->
## Article IV — Prepayments and Conditions Precedent
Section 4.1 Voluntary Prepayments. The Borrower may prepay the Loans in whole or in part without premium or penalty upon not less than three (3) Business Days' prior written notice to the Administrative Agent, in minimum amounts of $1,000,000 and integral multiples of $500,000 in excess thereof.
Section 4.2 Conditions to Effectiveness. The obligations of the Lenders hereunder become effective on the date on which the Administrative Agent has received executed counterparts of this Agreement, the Guarantee, the Security Agreement and the Fee Letter, customary legal opinions, and evidence of payment of all fees then due.
Section 4.3 Conditions to Each Borrowing. The representations and warranties in Article V shall be true and correct in all material respects, and no Default shall have occurred and be continuing, on the date of each borrowing.
<!-- page 7 -->
## Article V — Representations and Warranties
Section 5.1 Organization. The Borrower is duly organized, validly existing and in good standing under the laws of Delaware.
Section 5.2 Authorization; No Conflict. The execution and performance of the Loan Documents are within the Borrower's organizational powers and do not violate any law or material agreement binding on the Borrower.
Section 5.3 Financial Statements. The audited consolidated financial statements most recently delivered to the Administrative Agent fairly present the financial condition of the Borrower in accordance with GAAP.
Section 5.4 Litigation. There is no pending or, to the knowledge of the Borrower, threatened litigation that could reasonably be expected to result in a Material Adverse Effect.
Section 5.5 Sanctions; Anti-Corruption. Neither the Borrower nor any Subsidiary is a Sanctioned Person, and the Borrower has implemented policies reasonably designed to ensure compliance with Anti-Corruption Laws.
<!-- page 8 -->
## Article VI — Affirmative Covenants
Section 6.1 Financial Statements. The Borrower shall deliver to the Administrative Agent (a) within ninety (90) days after the end of each fiscal year, audited consolidated financial statements, and (b) within forty-five (45) days after the end of each of the first three fiscal quarters, unaudited consolidated financial statements.
Section 6.2 Compliance Certificate. Concurrently with each delivery under Section 6.1, the Borrower shall deliver a Compliance Certificate demonstrating compliance with Article VII.
Section 6.3 Notices of Material Events. The Borrower shall furnish prompt written notice, and in any event within five (5) Business Days, of the occurrence of any Default or any event that could reasonably be expected to result in a Material Adverse Effect.
Section 6.4 Existence; Conduct of Business. The Borrower shall preserve its legal existence and the rights, licenses and permits material to its business.
Section 6.5 Insurance. The Borrower shall maintain insurance with financially sound insurers in such amounts as are customary for companies engaged in similar businesses.
Section 6.9 Additional Guarantors. Within thirty (30) days after any Subsidiary becomes a Material Subsidiary, the Borrower shall cause such Subsidiary to become a Guarantor.
<!-- page 9 -->
## Article VII — Financial and Negative Covenants
Section 7.1 Maximum Leverage Ratio. The Borrower shall not permit the Leverage Ratio as of the last day of any fiscal quarter to exceed 4.00 to 1.00.
Section 7.2 Minimum Interest Coverage Ratio. The Borrower shall not permit the Interest Coverage Ratio for any period of four consecutive fiscal quarters to be less than 3.00 to 1.00.
Section 7.3 Indebtedness. The Borrower shall not, and shall not permit any Subsidiary to, incur Indebtedness other than Permitted Indebtedness, including purchase money Indebtedness not exceeding $10,000,000 in the aggregate at any time outstanding.
Section 7.4 Liens. The Borrower shall not create or permit any Lien on its property other than Permitted Liens.
Section 7.5 Fundamental Changes. The Borrower shall not merge, consolidate or dispose of all or substantially all of its assets, except as permitted under Section 7.6.
Section 7.6 Dispositions. The Borrower shall not dispose of assets outside the ordinary course of business with an aggregate fair market value exceeding $15,000,000 in any fiscal year without the consent of the Required Lenders.
Section 7.7 Restricted Payments. The Borrower shall not declare or pay dividends if a Default exists or would result therefrom or if, on a pro forma basis, the Leverage Ratio would exceed the level set forth in Section 7.1 less 0.50 to 1.00.
<!-- page 10 -->
## Article VIII — Events of Default
Section 8.1 Events of Default. Each of the following constitutes an Event of Default:
(a) failure to pay principal when due, or failure to pay interest or fees within three (3) Business Days after the due date;
(b) any representation or warranty proves to have been incorrect in any material respect when made;
(c) failure to observe any covenant in Article VII, or failure to observe any other covenant that continues unremedied for thirty (30) days after notice from the Administrative Agent;
(d) cross-default to other Indebtedness in an aggregate principal amount exceeding $5,000,000;
(e) bankruptcy or insolvency of the Borrower or any Material Subsidiary; or
(f) a Change of Control.
Section 8.2 Remedies. Upon an Event of Default, the Administrative Agent may, at the request of the Required Lenders, terminate the Commitments and declare the Loans immediately due and payable.
<!-- page 11 -->
## Article IX — The Administrative Agent; Assignments
Section 9.1 Appointment. Each Lender irrevocably appoints Meridian Trust Bank, N.A. as Administrative Agent and authorizes it to take such actions on its behalf as are delegated by the Loan Documents.
Section 9.2 Required Lenders. "Required Lenders" means Lenders holding more than 50% of the sum of the outstanding Loans and unused Commitments.
Section 9.3 Assignments. A Lender may assign all or a portion of its rights and obligations with the consent of the Borrower and the Administrative Agent (not to be unreasonably withheld), in minimum amounts of $5,000,000; the Borrower's consent is not required during an Event of Default.
Section 9.4 Resignation of Agent. The Administrative Agent may resign upon thirty (30) days' notice to the Lenders and the Borrower.
<!-- page 12 -->
## Article X — Miscellaneous
Section 10.1 Notices. All notices shall be in writing and delivered by hand, overnight courier or electronic mail: if to the Borrower, to 1200 Harbor Way, Suite 400, Seattle, Washington 98101, Attention: General Counsel; if to the Administrative Agent, to One Meridian Plaza, 18th Floor, New York, New York 10005, Attention: Agency Services. Notices are effective upon receipt, provided that notices received after 5:00 p.m. local time are deemed received on the next Business Day.
Section 10.2 Amendments and Waivers. No amendment or waiver of any provision of this Agreement is effective unless in writing and signed by the Required Lenders and the Borrower; provided that no such amendment shall, without the consent of each Lender affected, increase any Commitment, reduce the principal of or rate of interest on any Loan, or extend the Maturity Date.
Section 10.3 Governing Law. This Agreement shall be governed by, and construed in accordance with, the laws of the State of New York.
Section 10.4 Counterparts. This Agreement may be executed in counterparts, each of which constitutes an original.

IN WITNESS WHEREOF, the parties have caused this Agreement to be executed as of the Effective Date.
Halvorsen Marine Holdings, Inc., as Borrower — By: /s/ Authorized Signatory
Meridian Trust Bank, N.A., as Administrative Agent — By: /s/ Authorized Signatory
