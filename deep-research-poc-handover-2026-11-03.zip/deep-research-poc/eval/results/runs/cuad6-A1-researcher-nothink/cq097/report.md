# What non-compete clause does the Exclusive Distributor Agreement between WATER NOW, INC...

*Question:* What non-compete clause does the Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc. (dated 2019-11-12) contain? Quote the clause and cite its page.

## Locate the Exclusive Distributor Agreement

The Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc. dated 2019-11-12 is present in the fixed set. [c3ea62bed0707060 p.1]

[GAP] The non-compete clause is not present in the provided evidence.

## Identify the non-compete clause

The Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc. dated 2019-11-12 does not contain a clause explicitly titled "non-compete."  The closest provision to a non-compete is Section 2.3 Noncircumvention on page 4, which states: "2.3 Noncircumvention. [c3ea62bed0707060 p.4] Hydraspin certifies, stipulates, and agrees that the Hydraspin will deal exclusively with and through the Distributor in relation to the distribution of the Products in the Territory. [uncited] Hydraspin will not in any way or in any capacity, either directly or indirectly (including without limitation acting by, with or through one or more Persons in which the Hydraspin has an interest and/or with whom Hydraspin has a relationship): except pursuant to an agreement with the Distributor, (a) contact, approach or negotiate with any Customer outside of the Distributor, or (b) contact,…"  [GAP] The full text of Section 2.3 is missing because the evidence ends with an ellipsis. [c3ea62bed0707060 p.4]

## Verification appendix

Claims: 5 · supported: 3 · partially: 0 · dropped: 0 · gaps: 2 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[c3ea62bed0707060 p.1] |  |
| s1.2 | s1 | gap |  |  |  |
| s2.1 | s2 | keep | 1.00 | e2→[c3ea62bed0707060 p.4] |  |
| s2.2 | s2 | gap |  |  | no evidence cited |
| s2.3 | s2 | keep | 1.00 | e2→[c3ea62bed0707060 p.4] |  |

### Evidence

- e1 [c3ea62bed0707060 p.1 L1-8] keep (1.0): "# EXCLUSIVE DISTRIBUTOR AGREEMENT | Field | Value | |---|---| | Document Type | Distributor Agreement | | Agreement Date | 2019-11-12 | | Parties | WATER NOW, INC.; ("Water Now"); Hydraspin USA, Inc. ("Subsidiary", collectively with Water N…"
- e2 [c3ea62bed0707060 p.4 L129-141] keep (1.0): "2.3 Noncircumvention. Hydraspin certifies, stipulates, and agrees that the Hydraspin will deal exclusively with and through the Distributor in relation to the distribution of the Products in the Territory. Hydraspin will not in any way or i…"
