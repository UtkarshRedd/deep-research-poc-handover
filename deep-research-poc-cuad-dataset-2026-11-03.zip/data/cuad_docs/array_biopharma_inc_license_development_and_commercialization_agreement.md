<!-- page 1 -->
# LICENSE, DEVELOPMENT AND COMMERCIALIZATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2017-05-31 |
| Parties | Array BioPharma Inc., ("Array"); Ono Pharmaceutical Co., Ltd. ("Ono"); (individually "Party", collectively "Parties") |
| Source | CUAD v1 / Array BioPharma Inc. - LICENSE, DEVELOPMENT AND COMMERCIALIZATION AGREEMENT |

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

CONFIDENTIAL

EXECUTION VERSION

LICENSE, DEVELOPMENT AND COMMERCIALIZATION AGREEMENT

THIS LICENSE, DEVELOPMENT AND COMMERCIALIZATION AGREEMENT (this "Agreement") dated as of May 31,
2017 (the "Effective Date"), is made and entered into by and between Array BioPharma Inc., a company
organized under the laws of Delaware and having its principal place of business at 3200 Walnut
Street, Boulder, CO 80301 USA, ("Array") and Ono Pharmaceutical Co., Ltd., a company duly organized
and existing under the laws of Japan, having offices and principal place of business at 8-2,
Kyutaromachi 1-chome, Chuo-ku, Osaka 541-8564, Japan ("Ono").

BACKGROUND

A. Array now owns or controls certain patents, know-how and other intellectual property relating to
the Products (as defined below);

B. Ono has experience in developing, marketing and distributing pharmaceutical products;

C. Array and Ono wish to collaborate on the further development, manufacture and commercialization
of the Products, with Ono taking the lead role in such efforts in the Ono Territory (as defined
below); and

D. Array is willing to grant to Ono, and Ono desires to obtain, certain exclusive rights and
licenses with respect to the manufacture, registration and commercialization of the Products in the
Ono Territory. Array will retain the right to develop and commercialize the Products for the Array
Territory, all on the terms and conditions set forth herein.

NOW, THEREFORE, in consideration of the foregoing premises and the mutual covenants herein
contained, and for other good and valuable consideration, the receipt and sufficiency of which are
hereby acknowledged, the Parties hereby agree as follows:

ARTICLE I DEFINITIONS

1.1 "Affiliate" of a Party means any person, corporation or other entity that, directly or
indirectly, controls, is controlled by, or is under common control with such Party, as the case may
be. As used in this Section 1.1, the word "control" (including, with correlative meaning, the terms
"controlled by" or "under the common control with") shall mean the actual power, either directly or
indirectly through one or more intermediaries, to direct or cause the direction of the management
and policies of such entity, whether by the ownership of more than fifty percent (50%) of the voting
share capital in such person, corporation, or other entity, or by contract or otherwise.

1.2 "Annual Net Sales" means the Net Sales generated over any given Fiscal Year, or in the case of
the Fiscal Year in which the First Commercial Sale of the first Product occurs, the Net Sales
generated during the period commencing on the date of such First Commercial Sale and continuing
until the end of such Fiscal Year.
<!-- page 2 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

1.3 "Applicable Regulatory Exclusivity Period" means with respect to a particular Product and
particular country in the Ono Territory, the period commencing upon the receipt of the first grant
of Regulatory Exclusivity in such country for such Product ("Initial Regulatory Exclusivity"), and
continuing until the later of (i) the expiration of such Initial Regulatory Exclusivity, or (ii) if
any subsequent grant of Regulatory Exclusivity is received prior the expiration of the Initial
Regulatory Exclusivity, then until the expiration of such additional Regulatory Exclusivity if such
expiration would occur after the expiration of the Initial Regulatory Exclusivity.

1.4 "Array Know-How" means, subject to Section 4.4(c)(ii), all scientific, medical, technical,
manufacturing, marketing, regulatory, market access and other information (including clinical data
and other related information generated in compliance with CDISC standards) relating to Binimetinib,
Encorafinib, a Product and/or any Companion Diagnostic useful with respect to the Development,
Manufacturing, registration (including registration for MAA) or Commercialization of a Product
(including the Data), to the extent Controlled by Array or its Controlled Affiliates as of the
Effective Date or during the term of this Agreement, and needed by or reasonably useful to Ono in
order for Ono to exercise its rights or perform its obligations under this Agreement.
Notwithstanding the foregoing or Section 1.18 (Data) below, but subject to Section 2.4 (Future Third
Party Partners), Array Know-How shall in any case include all such items that are generated by or
under authority of Array, or any of its Affiliates, in connection with Development Manufacturing,
and/or Commercialization of the Product during the term of this Agreement.

1.5 "Array Patents" means the Patents Controlled by Array or its Controlled Affiliates as of the
Effective Date or during the term of this Agreement that:

(a) are listed on Exhibit 1.5; or

(b) but for the license granted under this Agreement, would be infringed by the Development,
Manufacturing, registration, packaging, or Commercialization of a Product in the Ono Territory
(including the identification of patients who would benefit from the Product based on the presence
or absence of selected biomarkers); and

(c) all additions, divisions, continuations, substitutions, re-issues, re-examinations,
registrations, patent term extensions, supplemental protection certificates, and renewals of any the
Patents listed on Exhibit 1.5 or to the extent the same would satisfy the requirements of subsection
(b) above.

1.1 "Array Territory" means all countries worldwide, excluding the Ono Territory.

2
<!-- page 3 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

1.2 "Binimetinib" means the compound known as MEK162, the chemical structure of which is depicted in
Exhibit 1.7 as well as all salts, non-covalent complexes, hydrates, solvates, chelates, crystal
polymorph or radiolabeled equivalent thereof.

1.3 "Business Days" means any day other than Saturday, Sunday, a day within Array's company-wide
corporate holidays (for Array's obligations) or Ono's company-wide corporate holidays (for Ono's
obligations) or any other day on which commercial banks in USA or Japan are authorized or required
by law to remain closed.

1.4 "Calendar Year" means any period of time commencing on January 1 and ending on the next December
31 unless otherwise noted.

1.5 "CDISC" means Clinical Data Interchange Standards Consortium which is an interdisciplinary
nonprofit organization that establishes international standards for data collection, interchange,
application, and storage for the purpose of promoting interoperation of clinical research data.

1.6 "Change in Control" means, with respect to a Party, that any of the following occurs with
respect to such Party after the Effective Date:

(a) any "person" or "group" (as such terms are defined below) (i) is or becomes the "beneficial
owner" (as defined below, except that a "person" or "group" shall be deemed to have "beneficial
ownership" of all shares of capital stock or other equity interests if such person or group has the
right to acquire, whether such right is exercisable immediately or only after the passage of time),
directly or indirectly, of shares of capital stock or other interests (including partnership
interests) of such Party then outstanding and normally entitled (without regard to the occurrence of
any contingency) to vote in the election of the directors, managers or similar supervisory positions
("Voting Stock") of such Party representing more than fifty percent (50%) of the total voting power
of all outstanding classes of Voting Stock of such Party or (ii) has the power, directly or
indirectly, to elect a majority of the members of such Party's board of directors or similar
governing body;

(b) such Party enters into a merger, consolidation or similar transaction with another Person
(whether or not such Party is the surviving entity) and as a result of such merger, consolidation or
similar transaction the Persons that beneficially owned, directly or indirectly, the shares of
Voting Stock of such Party immediately prior to such transaction cease to beneficially own, directly
or indirectly, shares of Voting Stock of such Party representing at least a majority of the total
voting power of all outstanding classes of Voting Stock of the surviving Person in substantially the
same proportions as their ownership of Voting Stock of such Party immediately prior to such
transaction; or

3
<!-- page 4 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(c) such Party sells or transfers to any Third Party, in one or more related transactions,
properties or assets representing all or substantially all of such Party's assets to which this
Agreement relates.

For the purpose of this definition of Change in Control: (i) "person" and "group" have the meanings
given such terms under Section 13(d) and 14(d) of the United States Securities Exchange Act of 1934
and the term "group" includes any group acting for the purpose of acquiring, holding or disposing of
securities within the meaning of Rule 13d-5(b)(1) under the aforesaid Act; (ii) a "beneficial owner"
shall be determined in accordance with Rule 13d-3 under the aforesaid Act; (iii) the terms
"beneficially owned" and "beneficially own" shall have meanings correlative to that of "beneficial
owner"; and (iv)"Person" means any natural person, corporation, firm, business trust, joint venture,
association, organization, company, partnership or other business entity or any government, any
agency or political subdivisions thereof.

Such "person" or "group" in Section 1.11(a), such surviving Person in Section 1.11(b) or such Third
Party in Section 1.11(c) shall be referred to herein as "Acquirer".

1.7 "Clinical Studies" means any human clinical study of a Product, including without limitation
Post-Approval Marketing Clinical Studies.

1.8 "Combination Product" means any pharmaceutical preparations, in any dosage strengths,
formulations and methods of administration, that combine Binimetinib or Encorafenib and one or more
other active ingredients (other than Binimetinib or Encorafenib) in fixed dose combination, whether
co-formulated or co-packaged.

1.9 "Commercialization" means all processes and activities conducted to establish and maintain sales
for the Products, including offering for sale, distribution, detailing, selling (including launch),
promoting, importing, exporting, market access activities, all marketing activities undertaken prior
to and after the launch of the Products (including education and advertising activities), branding,
developing promotional materials, advertising, organizing speakers programs and post-marketing
safety surveillance and reporting. "Commercialize" and "Commercializing" shall have the correlative
meanings.

1.10 "Companion Diagnostic" means an in vitro diagnostic medical device as defined in the European
directive 98/79/EC; for the avoidance of doubt the term Companion Diagnostic includes companion
diagnostics for a pharmaceutical product as defined in FDA's "Draft Guidance for Industry and Food
and Drug Administration Staff - In Vitro Companion Diagnostic Devices".

1.11 "Control" (including any variations such as "Controlled" and "Controlling"), in the context of
intellectual property rights, data and/or other information, means that such Party or its Affiliate
owns, is licensed or otherwise possesses rights to such intellectual property, data and/or
information,

4
<!-- page 5 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

as applicable, sufficient to grant the applicable license or sublicense under this Agreement,
without violating the terms of an agreement with a Third Party in existence as of the time such
Party or its Affiliates would first be required hereunder to grant the other Party such
(sub)license, right to use or access.

1.12 "Controlled Affiliates" means, with respect to a Party, any Affiliate that is controlled (as
defined in Section 1.1) by such Party.

1.13 "Data" means, subject to Section 1.51 (Ono Know-How) and Section 4.4(c)(ii), any and all
research data, pharmacology data, preclinical data, clinical data and/or all Regulatory Filings
and/or other regulatory documentation, information and submissions pertaining to, or made in
association with an IND, Marketing Approval Application, Marketing Approval or Pricing and
Reimbursement Approvals, or any Post-Approval Marketing Clinical Study for each Product, in each
case to the extent Controlled by a Party or its Affiliates as of the Effective Date or during the
term of this Agreement.

1.14 "Development" or "Develop" means non-clinical and clinical research and drug development
activities, including toxicology, pharmacology, statistical analysis, Clinical Studies (including
pre- and post-approval studies, Post-Approval Marketing Clinical Studies and Investigator Sponsored
Clinical Studies), stability testing, formulation, process development, quality assurance/control
development, regulatory affairs, and regulatory activities pertaining to designing and carrying out
Clinical Studies and obtaining and maintaining Marketing Approvals (including pre-marketing
activities but excluding regulatory activities directed to obtaining Pricing and Reimbursement
Approvals).

1.15 "Diligent Efforts" means, with respect to the efforts to be expended by a Party, with respect
to any objective, reasonable, good faith efforts to accomplish such objective as such Party would
normally use to accomplish a similar objective under similar circumstances for such Party's benefit.
Without limiting the foregoing, with respect to efforts relating to the Development of, obtaining
Marketing Approval or Pricing and Reimbursement Approval for, or Commercialization of the Product,
generally or with respect to any particular country, "Diligent Efforts" means a sustained, continued
and active commitment of efforts and resources by a Party consistent with those normally applied in
the pharmaceutical industry with respect to compounds or products with similar market at a similar
stage in the product life cycle that such Party is actively developing or commercializing (as
applicable), taking into account the stage and risk of development or commercialization of the
Product, issues of safety or efficacy, the cost effectiveness of efforts or resources while
optimizing profitability, the competitiveness of alternative Third Party compounds, products or
generics that are or are expected to be in the marketplace, the scope and duration of Patents or
other intellectual property rights related to the compound or product (including any Regulatory
Exclusivity), the profitability of the Product (including pricing and reimbursement status achieved
or likely to be achieved) or other relevant commercial factors,

5
<!-- page 6 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

but not taking into account (a) any other pharmaceutical product such Party is then researching,
developing or commercializing, alone or with one or more collaborators, or (b) any payments required
to be made to the other Party hereunder.

1.16 "EMA" means the European Medicines Agency, or any successor entity thereto performing similar
functions.

1.17 "Encorafenib" means the compound known as LGX818, the chemical structure of which is depicted
in Exhibit 1.22, as well as all salts, non-covalent complexes, hydrates, solvates, chelates, crystal
polymorph, or radiolabeled equivalent thereof.

1.18 "FDA" means the U.S. Food and Drug Administration, or any successor entity thereto performing
similar functions.

1.19 "Field" means the diagnosis, treatment and/or prevention of diseases and conditions in humans.

1.20 "First Commercial Sale" means, with respect to a Product the first bona fide, arm's length sale
of such Product in the Ono Territory following receipt of the first Marketing Approval of such
Product in the Ono Territory.

1.21 "Fiscal Year" means each successive period of twelve (12) months commencing on April 1 of a
particular calendar year and ending on March 31 of the immediately following the calendar year.
Notwithstanding the foregoing, it is understood that the first Fiscal Year shall commence on the
Effective Date and end on March 31, 2018.

1.22 "Global Registration Study" means a study of a Product conducted by or under authority of a
Party that is intended to support the filing of an MAA for such Product with the FDA, the PMDA and,
as applicable, the EMA and/or MFDS. Global Registration Studies shall include human clinical studies
designed as a pivotal study to confirm with statistical significance the efficacy and safety of the
Product with respect to a given Indication (whether structured as a superiority, equivalence or non-
inferiority study), which study is performed for purposes of filing an MAA or similar application to
obtain Marketing Approval for a Product for such Indication from the FDA, the PMDA and, as
applicable, the EMA or MFDS (regardless of whether such Clinical Study is identified as a Phase III
clinical study on ClinicalTrials.gov), including a clinical study as described under 21 C.F.R.
§312.21(c) with respect to the United States (or, with respect to a jurisdiction other than the
United States, a similar clinical study).

6
<!-- page 7 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

1.23 "Good Clinical Practice or "GCP" means the current standards for clinical studies for
pharmaceuticals, as set forth in the ICH guidelines and applicable regulations promulgated
thereunder, as amended from time to time.

1.24 "Good Laboratory Practice or "GLP" means the current standards for laboratory activities for
pharmaceuticals, as set forth in the FDA's Good Laboratory Practice regulations or the Good
Laboratory Practice principles of the Organization for Economic Co-Operation and Development, as
amended from time to time, and such standards of good laboratory practice as are required by the
MHLW and other organizations and governmental agencies in countries in which a Product is intended
to be sold, to the extent such standards are not less stringent than United States Good Laboratory
Practice.

1.25 "Good Manufacturing Practices or "GMP" means all laws and guidelines applicable to the
Manufacture of Binimetinib, Encorafenib or Product, including (i) the FD&C Act (21 U.S.C. 321 et
seq.); (ii) relevant United States regulations in Title 21 of the United States Code of Federal
Regulations (including Parts 11, 210, and 211); (iii) European Community Directives 2001/83/EC and
2003/94/EC; (iv) the EU Guidelines to Good Manufacturing Practice Medicinal Products for Human and
Veterinary Use, as set out in Volume 4 of the European Commission's Rules governing medicinal
products in the EU; (v) those standards required by the Japanese Ministry of Health Labour and
Welfare (MHLW); (vi) International Conference on Harmonisation of Technical Requirements for
Registration of Pharmaceuticals for Human Use ("ICH"), Q7 Good Manufacturing Practice Guidance for
Active Pharmaceutical Ingredients; (vii) similar standards and Laws to those in (i) through (vi), as
are in effect at the time of Manufacture; and (viii) all additional Regulatory Authority documents
or regulations that replace, amend, modify, supplant or complement any of the foregoing.

1.26 "Governmental Authority" means any domestic or foreign entity exercising executive,
legislative, judicial, regulatory or administrative functions of or pertaining to government,
including any governmental authority, agency, department, board, commission, court, tribunal,
judicial body or instrumentality of any union of nations, federation, nation, state, municipality,
county, locality or other political subdivision thereof.

1.27 "Improvement" means any Patent, invention or other intellectual property made or used by or
under authority of Ono (including any Ono Know-How) in connection with Development, Manufacture
and/or Commercialization of Binimetinib, Encorafenib and/or a Product, in each case, to the extent
the same is owned or Controlled by Ono or any of its Affiliates.

1.28 "IND" means an investigational new drug application (including any amendments thereto) filed
with the PMDA before the commencement of Clinical Studies for a Product in Japan, or any comparable
filing with any Regulatory Authority in any other jurisdiction within or outside the Ono Territory
(including any Investigational New Drug Application filed with a Regulatory Authority in the United
States pursuant to 21 C.F.R. §321).

7
<!-- page 8 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

1.29 "Indication" means an initial, expanded or additional patient population for which use of a
Product is indicated, as reflected or to be reflected in the approved label for such Product.

1.30 "Initial Royalty Term" means, on a Product-by-Product and country-by-country basis within the
Ono Territory, the period beginning on the date of the First Commercial Sale of such Product in a
country until the last of: (a) [ * ] thereafter; (b) the expiration of all Valid Claims within the
Array Patents that would, but for the license granted under this Agreement, be infringed by the sale
or use of such Product in such country or (c) the expiration of the Applicable Regulatory
Exclusivity Period for such Product in such country. Notwithstanding the foregoing, in the event
that it has been more than [ * ] since the First Commercial Sale of a Product in a country and the
Initial Regulatory Exclusivity with respect to such Product has expired but either (i) a subsequent
grant of Regulatory Exclusivity is still in effect, and/or (ii) one or more Valid Claims within the
Array Patents that cover such Product in such country are still in effect, then if Generic Market
Share with respect to such Product in such country equals or exceeds [ * ], the Initial Royalty Term
will immediately terminate with respect to such Product.

1.31 "Investigator Sponsored Clinical Study" means a clinical study of a Product that is sponsored
and conducted by a physician, physician group or other Third Party not acting on behalf of a Party
or an Affiliate and who does not have a license from a Party or its Affiliate to commercialize such
Product, pursuant to an IND owned by such Third Party, and with respect to which a Party or its
Affiliate provides clinical supplies of the Product, funding or other support for such clinical
study.

1.32 "IST Guidelines" means the guidelines governing the conduct of Investigator Sponsored Clinical
Studies of the Product, which is attached hereto as Exhibit 1.37.

1.33 "Joint Inventions" means all inventions arising during the term of the Agreement that (a) are
jointly created or reduced to practice by employees, consultants, or contractors of Array or its
Affiliates and by employees, consultants, or contractors of Ono or its Affiliates, and (b) relate to
Binimetinib, Encorafenib and/or Products.

1.34 "Joint Know-How" means all know-how arising during the term of the Agreement that (a) is
jointly generated by employees, consultants, or contractors of Array or its Affiliates and by
employees, consultants, or contractors of Ono or its Affiliates, and (b) relates to Binimetinib,
Encorafenib and/or Products.

1.35 "Joint Patent" means a Patent that covers or claims a Joint Invention.

1.36 "Law" means any applicable national, supranational, federal, state, local or foreign law,
statute, ordinance, principle of common law, or any rule, regulation, standard, judgment, order,
writ, injunction, decree, arbitration award, agency requirement, license or permit of any
Governmental

8
<!-- page 9 -->
<!-- page 10 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

Authority, including any rules, regulations, guidelines, directives or other requirements of
Regulatory Authorities, including all GMP, GLP and GCP, and including all laws pertaining to the
pharmaceutical industry or the healthcare industry and all anti-bribery or anti-corruption laws, as
applicable.

1.37 "Manufacture" means any activities related to the production, manufacture, processing, filling,
packaging, labeling, releasing, shipping (including shipping configurations and shipping studies),
supply and holding of a compound or product or any intermediate thereof, including process
development, process qualification and validation, scale-up, improvements or changes, pre- clinical,
clinical and commercial manufacture and analytic development, product characterization, quality
assurance and quality control (including in-process testing, release testing or stability testing).
When used as a verb, "to Manufacture" and "Manufacturing" mean to engage in Manufacture and
"Manufactured" has a corresponding meaning.

1.38 "Marketing Approval" (or "MA") means such approvals, licenses, registrations or authorizations
of the Regulatory Authorities in a country, that are necessary to Commercialize a Product in such
country. Marketing Approval shall not be deemed to include Pricing and Reimbursement Approval.

1.39 "Marketing Approval Application" (or "MAA") means an application requesting Marketing Approval
for the Commercialization of a Product for a particular Indication in a particular jurisdiction
filed with the relevant Regulatory Authorities in such jurisdiction.

1.40 "Market Access" means any and all processes and activities conducted to establish and maintain
national country reimbursement, as well as at country level, regional and local payor processes and
activities to obtain and maintain local and regional patient access for the Products, including
price setting, national mandatory rebate negotiations with Governmental Authorities and preparing
reimbursement and economic dossiers.

1.41 "MFDS" means the Ministry of Food and Drug Safety in Korea, or any successor entity thereto
performing similar functions.

1.42 "MHLW" means the Ministry of Health, Labour, and Welfare in Japan, or any successor entity
thereto performing similar functions.

1.43 "Net Sales" means the gross amounts invoiced by Ono, its Affiliates and/or Sublicensees (each,
a "Selling Party") for the sales of a Product to a Third Party, less reasonable and customary
deductions for the following costs incurred by the Selling Party on the sale to such Third Party:

(a) trade, quantity and cash discounts actually granted to such Third Party;

9
<!-- page 11 -->
<!-- page 12 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(b) credits, rebates, chargeback and allowances to such Third Party on account of rejection or
returns of such Product (including wholesaler and retailer returns) or on account of retroactive
price reductions affecting the Product;

(c) a fixed amount of [ * ] of gross sales to cover freight, postage, insurance costs on shipments
to such Third Party, packing costs, and other transportation charges; and

(d) sales and excise taxes, other consumption taxes, customs duties, and compulsory payments to
Governmental Authorities, including mandatory sales-based contributions actually made by the Selling
Party for "Contributions for Drug Induced Suffering" and any sales-based contribution for
"Contribution for Measure for Drug Safety," in the amount determined by and payable to PMDA each as
consistently applied by the Selling Party across all of its pharmaceutical products sold in Japan,
and any other governmental, health insurance or other payers' charges, rebates, or discounts,
retroactive or otherwise, imposed by or negotiated with Governmental Authorities with respect to the
sale of such Product to such Third Party actually paid and separately identified on the invoice or
other documentation maintained in the ordinary course of business.

Ono shall ensure that all sales of Products are accurately invoiced and that Net Sales are
calculated and accounted for in accordance with IFRS as consistently applied. Sales between Ono and
its Affiliates or Sublicensees for resale shall be excluded from the computation of Net Sales, but
the subsequent resale of such Product shall be included within the computation of Net Sales.

For the purposes hereof, "Net Sales" shall not include any consideration received with respect to a
sale, use or other disposition of any Product in a country for Development purposes or as samples or
for charitable purposes, provided such consideration is no greater than the cost of goods of the
Product units so sold, used or distributed.

In the event that the Product is sold as a Combination Product, the Net Sales will be calculated by
multiplying the Net Sales of the Combination Product by the fraction, A/(A+B) where A is the
weighted (by sales volume) average sale price in the relevant country of the Product containing
Binimetinib or Encorafenib as the sole active ingredient in finished form, and B is the weighted
average sale price (by sales volume) in that country of the product(s) containing the other
component(s) as the sole active ingredient(s) in finished form. Regarding prices comprised in the
weighted average price when sold separately referred to above, if these are available for different
dosages from the dosages of Binimetinib or Encorafenib and other active ingredient components that
are included in the Combination Product, then the applicable Party shall be entitled to make a
proportional adjustment to such prices in calculating the Net Sales of the Combination Product. If
the weighted average sale price cannot be determined for the Product or other product(s) containing
the single licensed compound or component(s), the calculation of Net Sales for Combination Products
will be agreed by the Parties based on the relative value contributed by each component (each
Party's agreement not to be unreasonably withheld or delayed).

10
<!-- page 13 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

1.44 "Party" means Array or Ono, individually; and "Parties" means Array and Ono, collectively.

1.45 "Patent(s)" means any patents and patent applications, together with all additions, divisions,
continuations, continuations-in-part, substitutions, reissues, re-examinations, registrations,
patent term extensions, supplemental protection certificates, and renewals of any of the foregoing.

1.46 "Ono Know-How" means all scientific, medical, technical, marketing, regulatory, market access
and other information (including clinical data and other related information generated in compliance
with CDISC standards) relating to Binimetinib, Encorafenib and/or a Product (including the Data),
that (a) exists as of the Effective Date or is developed, acquired or otherwise comes within the
Control of Ono during the term of this Agreement and (b) in each case is actually used by Ono in the
Development, Manufacturing or Commercialization of a Product, and is needed by or reasonably useful
to Array in order for Array to exercise its rights (including the conduct of activities directed
towards Developing the Product for Commercialization outside the Ono Territory and/or the
Commercialization of the Product outside the Ono Territory) or perform its obligations under this
Agreement. Notwithstanding the foregoing or Section 1.18 (Data) above, Ono Know-How shall in any
case include all such items that are generated by or under authority of Ono, or any of its
Affiliates or Sublicensees, in connection with Development, Manufacturing and/or Commercialization
of the Product during the term of this Agreement.

1.47 "Ono Territory" means Japan and Republic of Korea ("Korea").

1.48 "Post-Approval Marketing Clinical Study" means a Clinical Study that is a marketing study,
epidemiological study, pharmacoeconomic study, or post-marketing surveillance study of a Product, in
each case that is conducted after Marketing Approval has been obtained in the applicable territory
and that is not intended for use as a basis for obtaining Marketing Approval (e.g., for a further
Indication, label expansion or otherwise) with respect to the Product and that is not being
conducted as a commitment made to a Regulatory Authority as a condition of, or in connection with
obtaining or maintaining, a Marketing Approval).

1.49 "Pricing and Reimbursement Approval" means, with respect to any country or jurisdiction in the
Ono Territory in which Governmental Authorities determine the pricing at which the Product will be
reimbursed, the approval, agreement, determination or decision by the applicable Governmental
Authorities establishing the pricing and reimbursement status for the Product.

1.50 "Product" means shall mean any pharmaceutical product containing, as an active ingredient, one
or more of Binimetinib or Encorafenib, including, without limitation, any Combination Product.

11
<!-- page 14 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

1.51 "Product Trademarks" means: (a) the product-specific trademarks owned or Controlled by Array
and designated by Array for use with Products containing Binimetinib, as reflected on Exhibit
1.56(a); (b) the product-specific trademarks owned or Controlled by Array and designated by Array
for use with Products containing Encorafenib, as reflected on Exhibit 1.56(b); and (c) any other
product-specific trademark(s) and service mark(s) as may be proposed by either Party and reviewed by
the JCC for use in connection with the distribution, marketing, promotion and sale of a Product in
the Ono Territory, or accompanying logos, trade dress or indicia of origin.

1.52 "Regulatory Authority" means the MHLW or its review agency, the Pharmaceutical and Medical
Devices Agency (generally known as IYAKUHIN IRYOKIKI SOGO KIKO) in Japan ("PMDA") or a regulatory
body with similar regulatory authority in any country/jurisdiction within the Ono Territory or in
any jurisdiction outside the Ono Territory (e.g., the FDA and EMA).

1.53 "Regulatory Exclusivity" means any exclusive marketing rights or data exclusivity rights
conferred by any applicable Regulatory Authority, other than an issued and unexpired Patent,
including any regulatory data protection exclusivity (including, where applicable, pediatric
exclusivity and/or orphan drug exclusivity) and/or any other exclusivity afforded by restrictions
which prevent the granting by a Regulatory Authority of regulatory approval to market a Generic
Version.

1.54 "Regulatory Filing" means all approvals, licenses, registrations, submissions and
authorizations made to or received from a Regulatory Authority in a jurisdiction necessary for or in
connection with the development, manufacture and/or commercialization of a pharmaceutical product,
including any INDs, Marketing Approval Applications, Marketing Approvals, and Pricing and
Reimbursement Approvals.

1.55 "Secondary Royalty Term" means on a Product-by-Product and country by country basis within the
Ono Territory, the period commencing on the expiration of the Initial Royalty Term for such Product
and continuing until the [ * ] of the expiration of the Initial Royalty Term for such Product in
such country.

1.56 "Senior Executives" means the Executive Directors of each of Ono and Array.

1.57 "Subcontractor" means any Third Party to which a Party or its Affiliate may subcontract the
performance of any activities undertaken in accordance with this Agreement, provided that for
clarity any entity which is involved in the selling of Products and is responsible for booking sales
of Products shall not be included within this definition.

1.58 "Sublicensee" means a Third Party that has been granted a right to market and sell a Product in
the Ono Territory (and optionally, the additional right to Develop such Product) pursuant to Section
2.2; and "Sublicense" shall mean an agreement or arrangement granting such rights. As used

12
<!-- page 15 -->
<!-- page 16 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

in this Agreement, "Sublicensee" shall not include a wholesaler, distributor or reseller of such
Product, to the extent that Ono sells to such person the Product at supply prices, and the
arrangement does not include royalty payments or other payments tied to the revenue such wholesaler,
distributor or reseller receives upon resale of the Product, whether paid in arrears or as transfer
price unless such payment structure is consistent to that applied by Ono for its other oncology
products in the relevant country, and /or significant lump sum payments.

1.59 "Third Party" means any person, corporation, joint venture or other entity, other than Array,
Ono and their respective Affiliates.

1.60 "Third Party Partner" means Pierre Fabre Medicament SAS ("PFM") and any other Third Party to
which Array grants a license or sublicense, as applicable, under the Array Patents and Array Know
How to market and sell Product(s) outside the Ono Territory, either with or without accompanying
rights to Develop and/or Manufacture such Product(s).

1.61 "Valid Claim" means a claim of an issued and unexpired Patent (including the term of any patent
term extension, supplemental protection certificate, renewal or other extension) which has not been
held unpatentable, invalid or unenforceable in a final decision of a court or other government
agency of competent jurisdiction from which no appeal may be or has been taken, and which has not
been admitted to be invalid or unenforceable through reissue, re-examination, disclaimer or
otherwise.

1.62 Additional Definitions. Each of the following terms shall have the meaning described in the
corresponding section of this Agreement indicated below:

13
<!-- page 17 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

Term Section Defined Term Section Defined Approved Clinical Study 4.4(a)(i) Infringement Actions
11.4(a) Arbitration Tribunal Array Array Indemnitees

17.3(a) Introduction 16.1

Infringing Product JCC Chairperson 11.3(a)(i) 3.3

Array Regulatory Filings 4.6(b) JDRC Chairperson 3.3 Audited Site 4.6(d)(ii) Joint Clinical Study
Proposal 4.4(a) Auditor AZ 7.4 11.3(a)(ii) Joint Commercial Committee /JCC 3.2(a)

AZ Agreement BEACON Clinical Study 11.3(a)(ii) 4.1(c) Joint Development and Regulatory Committee
/JDRC 3.1(a)

Blocking Patent 6.5 Joint Development Plan 4.4(a)(i) CAPA COLUMBUS Clinical Study Combination
Study(ies)

4.6(d)(ii) 4.1(c) 4.5(b)(i)

Liabilities Liaison Local Study(ies)

16.1 3.7 4.5(b)(i) Commercializing Party 2.3(a) Marketing Materials 5.1(c) Commercialization Plan
5.1(b) Materials 9.1(a) Committee 3.3 Medical Journal 10.4 Committee Dispute Competing Product
3.5(a) 8.2 NEMO Clinical Study [ * ] 4.1(c) 14.2(a)(ii)

Confidential Information Declined Clinical Study Development Plan Dispute Domain Name

10.1 4.4(c)(i) 4.2(a) 17.3 12.6

Non-Performing Party Novartis Ono Ono Indemnitees Patient Sample

4.4(c)(i)(D) 4.1(c) Introduction 16.2 4.10 Drug Product Drug Substance 9.1(b) 9.1(b) Performing
Party 4.4(c)(i)(D)

Education Materials Effective Date 5.1(c) Introduction PFM Agreement Product Materials 2.4(a)
14.2(a)(vi) Enforcing Party Existing Clinical Studies Expert Dispute Expert Resolution Notice

11.3(a)(i) 4.1(c) 17.2(a) 17.2(b)

Quality Agreement Royalty Payments Royalty Report Rules

9.4(b) 6.3 6.3(d) 17.3(a) Experts Generic Version Global Study(ies)

17.2(c) 6.4(c)(i) 4.5(b)(iii)

Scientific Meeting Scientific Paper Subcontract

10.5 10.4 18.11 Government Official 15.1(f) Subject Party 11.4(a) Grant-Back License Indemnitee
Indemnitor

2.6 16.3 16.3

Sublicensing Party Supply Agreement Third Party Claim

2.3(a) 9.4(b) 16.1

Third Party Technology Wind-down Period 2.3(a) 14.2(a)(ii) Working Group 3.6

14
<!-- page 18 -->
<!-- page 19 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

ARTICLE II GRANT OF LICENSE

2.1 Licenses.

(a) Development License. Subject to the terms and conditions of this Agreement, including without
limitation Array's retained rights under Section 2.1(e) below, Array hereby grants to Ono an
exclusive license, with the right to grant sublicenses as provided in Section 2.2, under the Array
Patents, Array Know-How and Array's interests in the Joint Patents and Joint Know- How to Develop
the Products in accordance with the Development Plan and Joint Development Plan(s) in the Ono
Territory solely for purposes of obtaining Marketing Approval for use of the Product in the Field in
the Ono Territory.

(b) Manufacturing License. Subject to the terms and conditions of this Agreement, Array hereby
grants to Ono a worldwide non-exclusive license under the Array Patents, Array Know-How and Array's
interests in the Joint Patents and Joint Know-How to (i) Manufacture and have Manufactured
Binimetinib and Encorafenib for use in the Manufacture of Products, and (ii) Manufacture and have
Manufactured Products, in each case for use in Developing and Commercializing such Products in
accordance with the rights and license granted to Ono under Sections 2.1(a) and 2.1(c). The licenses
granted under this Subsection 2.1(b) may be sublicensed by Ono only to its Affiliates, and then only
for so long as such entities remain as Affiliates. For clarity, the licenses granted under this
Subsection 2.1(b) may be extended by Ono to Third Party manufacturers for Manufacturing the Products
on Ono's behalf.

(c) Commercialization License. Subject to the terms and conditions of this Agreement, Array hereby
grants to Ono an exclusive license, with the right to grant sublicenses and appoint distributors as
provided in Section 2.2, under the Array Patents, Array Know-How and Array's interests in the Joint
Patents and Joint Know-How to Commercialize the Products in the Field in the Ono Territory.

(d) Certain Clarifications. For clarity, it is understood that the foregoing licenses do not include
the right to modify Binimetinib or Encorafenib and Ono agrees that it shall not, and shall ensure
that its Affiliates, Sublicensees and any other Third Parties to whom it provides Products,
Binimetinib or Encorafenib, do not, modify or make improvements to Binimetinib or Encorafenib.

(e) Array Retained Rights. Except for the rights and licenses expressly granted to Ono in this
Agreement, Array retains all rights under the Array Patents and Array Know-How, including its
interest in the Joint Patent and Joint Know-How. Without limiting the foregoing and notwithstanding
the exclusive license granted to Ono under Section 2.1(a) above, Array retains

15
<!-- page 20 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

all rights to, itself, through Affiliates and/or through Third Party contractor or Third Party
Partner, conduct Clinical Studies (and file all Regulatory Filings required in connection with the
such Clinical Studies) with respect to Products in the Ono Territory to the extent permitted under
Section 4.5 below.

2.2 Sublicensees and Distributors.

(a) It is understood and acknowledged that Array's decision to select Ono to commercialize Products
in the Ono Territory was based in part on the understanding that Ono currently markets
pharmaceutical products in the Ono Territory and that Ono intends to market Products in the same
manner. Ono shall have the right, in accordance with this Section 2.2, to grant sublicenses under
the Array Patents and Array Know-How to its Affiliates and to Third Parties, provided that Ono shall
not engage a Third Party as either (i) a Sublicensee of the Product, or (ii) as a distributor of the
Product, without Array's prior written consent. For clarity, a wholesaler shall not be considered a
"distributor" for purposes of the foregoing restriction.

(b) Ono shall ensure that each of its Sublicensees and distributors is bound by a written agreement
between Ono and such Sublicensee or distributor that does not conflict with, and contains provisions
as protective of the Products and Array, as this Agreement. Without limiting any of Ono's
obligations under this Agreement, Ono shall also ensure that each Sublicensee expressly agrees in
writing to be bound by all of Ono's obligations under this Agreement to the extent applicable to
such Sublicensee, including without limitation, the following provisions of this Agreement (as if
such Sublicensee were expressly named in each such provision, to the extent Ono's Sublicensees are
not so named therein): Sections 2.6 (Grantback License to Array), 4.7 (Exchange of Data and
Know-How); 4.8 (Right of Reference and Access to Data); 7.4 (Records), 8.2 (Exclusivity of Efforts)
and 14.2 (transition obligations on termination).

(c) Ono shall in all cases remain responsible for any actions of its Affiliates and Sublicensees
exercising rights under a sublicense of the rights granted by Array to Ono under this Agreement to
the same extent as if such actions had been taken by Ono itself.

(d) Promptly following the execution of each Sublicense to a Sublicensee, Ono shall provide Array
with an executed copy of such Sublicense which may be redacted as described below (together with a
detailed English summary of such sublicense agreement if such Sublicense was originally executed in
a language other than English); and Ono shall also provide to Array an executed copy (which may be
redacted as described below) of any amendment to a Sublicense that relates to a Product (together
with a detailed English summary of such amendment, if such amendment was originally executed in a
language other than English), promptly following the execution of each such amendment. Ono may
redact from copies of executed Sublicenses and Sublicense amendments

16
<!-- page 21 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

to be provided hereunder any confidential terms that are not necessary to enable Array determine
Ono's compliance with its obligations under this Agreement.

(e) Ono shall not grant sublicenses or appoint distributors other than in accordance with this
Section 2.2.

2.3 Third Party Technology Acquired after Effective Date.

(a) Generally. If after the Effective Date, Array or Ono (the "Sublicensing Party") acquire rights
from a Third Party that are to be licensed to the other Party under this Agreement, respectively
("Third Party Technology"), but that is subject to royalty or other payment obligations to the Third
Party, then the following shall apply: The licenses granted to the other Party (the "Commercializing
Party") hereunder with respect to such Third Party Technology shall be subject to the
Commercializing Party's agreeing to promptly reimburse and promptly reimbursing the Sublicensing
Party for any milestone payments, royalties or other amounts that become owing to such Third Party
by reason of the Commercializing Party's exercise of such license or sublicense to the Third Party
Technology. To the extent that any such payments made by a Sublicensing Party under an agreement to
acquire Third Party Technology are not attributable to either the Array Territory or Ono Territory,
but are attributable to the acquisition of rights to a Third Party Technology used for the Product,
such payments shall be allocated [ * ] to Array and [ * ] to Ono to the extent that such Third Party
Technology has been licensed by the Sublicensing Party on a global basis and is equally applicable
to the Products being sold in the Array Territory and the Ono Territory. In all other cases such
costs shall be allocated between Array and Ono by the JDRC on a pro rata basis based on the
respective value of Third Party Technology in the Array Territory or Ono Territory. At the inception
of the inclusion of any Third Party Technology in such license under this Agreement and thereafter
upon request by the Commercializing Party, the Sublicensing Party shall disclose to the
Commercializing Party a true, complete and correct written description of such payment obligations,
and the Commercializing Party's obligation to reimburse such amounts following such request shall be
limited to those payment obligations as so disclosed by the Commercializing Party. In the event that
the Commercializing Party does not agree to reimburse or does not promptly reimburse the
Sublicensing Party for such amounts upon request (such amounts as determined by the JDRC in
accordance with this Agreement, to the extent so provided above), then such Third Party Technology
shall thereafter be deemed excluded from the licenses or other subject matter licensed hereunder.

(b) Right to Offset. With respect to payments that Ono has agreed to reimburse to Array pursuant to
subsection 2.3(a) above, Ono shall be entitled to treat such payments as payments made to Third
Parties with respect to Blocking Patents for purposes of Section 6.6 below.

2.4 Future Third Party Partners.

17
<!-- page 22 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(a) Array and Pierre Fabre Medicament SAS ("PFM") have previously entered into that certain
Development and Commercialization Agreement, dated as of November 10, 2015 (such agreement, as
subsequently amended, the "PFM Agreement") pursuant to which Array and PFM are collaborating on the
Development of Products in the U.S. and Europe. Under the PFM Agreement, Array is authorized to
provide Ono with access to data, know-how and improvements generated by PFM and a right of reference
with respect to PFM's Regulatory Filings provided that Ono consents to Array granting to PFM
reciprocal access to data, know-how, rights of reference and improvements generated by Ono. Such
access and rights of reference shall be granted to Ono without charge, provided that the reciprocal
rights of access and rights of reference granted by Ono are without charge.

(b) If after the Effective Date, Array retains a Third Party Partner for the Product in one or more
countries in the Array Territory, Array shall use Diligent Efforts to gain such Third Party
Partner's consent to allow Array to (i) share with Ono under Section 4.7 (Exchange of Data and
Know-How) the clinical data and know-how generated by such Third Party Partner, (ii) extend to Ono
under Section 4.8 (Rights of Reference and Access to Data) a right to reference the Regulatory
Filings of such Third Party Partner with respect to Products, and (iii) extend to Ono a license
under improvements made by such Third Party Partner, in each case: (A) to the extent that such data,
know-how, rights of reference and improvements are necessary or reasonably useful for Ono's
Development, preparation of MAAs and filing of MAAs with respect to Products in the Ono Territory or
Commercialization of the Product in the Ono Territory and (B) without charge, however it is
understood that a failure of Array to obtain such rights shall not be deemed a breach of this
Section 2.4. Notwithstanding any other provisions of this Agreement, Array agrees that it shall not
provide such future Third Party Partner with access to Data and Improvements generated by Ono or a
right of reference with respect to Ono's Regulatory Filings except to the extent such Third Party
Partner agrees to Ono with reciprocal access to data, know-how, rights of reference and improvements
generated by such Third Party Partner. It is further agreed that to the extent that such future
Third Party Partner conditions Ono's access to such data, know-how, rights of reference and
improvements on payment from Ono, Ono may require that Array conditions such future Third Party
Partner's access to Ono's data, know-how, rights of reference and improvements on receipt of similar
payment.

2.5 Activities Outside the Respective Territory.

(a) To the extent permitted under applicable Law, Ono agrees that neither it, nor any of its
Affiliates, will sell or provide the Product to any Third Party, if Ono or its relevant Affiliate
knows, or has reason to know, that Products sold or provided to such Third Party may be sold or
transferred, directly or indirectly, for use in the Array Territory.

18
<!-- page 23 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(b) To the extent permitted under applicable Law, Array agrees that neither it, nor any of its
Affiliates, will sell or provide the Product to any Third Party, if Array or its relevant Affiliate
knows, or has reason to know, that Products sold or provided to such Third Party may be sold or
transferred, directly or indirectly, for use in the Ono Territory.

2.6 Grant-Back License to Array. Ono hereby grants to Array a non-exclusive, worldwide, royalty free
license, with the right to issue and authorize sublicenses through multiple tiers subject to the
last sentence of Section 2.4(b), under any Improvements and Ono's interest in Joint Patent and Joint
Know-How solely to make, use, sell, offer for sale, import, the Products (collectively, the
"Grant-Back License"), subject to the exclusive rights granted to Ono under this Agreement. Promptly
following the execution of a sublicense to a Third Party Partner, Array shall notify Ono of such
sublicense in writing.

2.7 No Other Rights. Except for the rights and licenses expressly granted in this Agreement, each
Party retains all rights under its intellectual property, and no additional rights shall be deemed
granted to the other Party by implication, estoppel or otherwise. For clarity, the licenses and
rights granted in this Agreement shall not be construed to convey any licenses or rights under the
Array Patents or Improvements with respect to any drug substances other than Binimetinib or
Encorafenib or to any products other than Products.

ARTICLE III GOVERNANCE

3.1 Joint Development and Regulatory Committee.

(a) Establishment. As soon as reasonably practicable after the Effective Date, but in no event later
than sixty (60) days following the Effective Date, Array and Ono shall establish a Joint Development
and Regulatory Committee ("Joint Development and Regulatory Committee" or "JDRC").

(b) Duties. The JDRC shall:

(i) review and discuss and accept or reject the initial Development Plan;

(ii) review and update the Development Plan, as needed, but no less frequently than once each Fiscal
Year, and present to the JDRC for review and approval all proposed material changes to the
Development Plan;

(iii) oversee Ono's implementation of the Development Plan;

19
<!-- page 24 -->
<!-- page 25 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(iv) review, discuss and accept or reject Joint Clinical Study Proposals submitted by either Party;

(v) prepare any Joint Development Plans with respect to any Joint Clinical Study Proposals agreed by
the Parties as well as any changes to such Joint Development Plans;

(vi) review, discuss and accept or reject any changes to the Joint Development Plans;

(vii) oversee both Parties' implementation of the Joint Development Plans, allocate responsibilities
to each Party in connection with executing such Joint Development Plans and review Ono's execution
of its responsibilities under the Development Plan

(viii) review, discuss and accept or reject clinical study design and protocols for Clinical Studies
included in the Development Plan or within any Joint Development Plan, including clinical study
endpoints, clinical methodology and monitoring requirements for such Clinical Studies;

(ix) establish, review and update the IST Guidelines; review and discuss plans for any proposed
Investigator Sponsored Clinical Studies that are not expressly authorized in the IST Guidelines;

(x) discuss clinical supply and CMC activity;

(xi) review and discuss the regulatory strategy and Market Access strategies for the Product in the
Ono Territory (and substantive amendments and updates thereto);

(xii) provide a forum for the Parties: (A) to discuss and agree upon, material issues pertaining to
the Development of the Product for the Ono Territory, and matters pertaining to Regulatory Filings
for the Product in the Ono Territory; and (B) to coordinate their respective activities with respect
to the foregoing matters;

(xiii) provide a forum for resolving disputing and other matters referred to the JDRC under this
Agreement, pursuant to the procedures set out in Section 3.5 below; and

(xiv) perform such other duties as are specifically assigned to the JDRC in this Agreement.

20
<!-- page 26 -->
<!-- page 27 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

3.2 Joint Commercial Committee.

(a) Establishment. At the appropriate timing determined by the Parties, but no less than one (1)
year prior to expected approval of the Product in the Ono Territory, Ono and Array shall establish a
joint commercial committee ("Joint Commercial Committee" or "JCC").

(b) Duties. The JCC shall:

(i) review the Commercialization Plan (including any substantive amendments and updates thereto);

(ii) review the commercialization plan and marketing strategy of Array in the Array Territory;

(iii) serve as the first forum for discussing disputes or disagreements resulting from, arising out
of or in relation to the Commercialization of the Product in the Ono Territory; and

(i) have such other responsibilities as may be assigned to the JCC pursuant to this Agreement or as
may be mutually agreed upon by the Parties in writing from time to time.

3.3 Committee Membership. The JDRC and JCC (each, a "Committee") shall each be composed of an equal
number of representatives from each of Ono and Array, selected by such Party. Unless the Parties
otherwise agree, the exact number of representatives for each of Ono and Array shall be: (a) with
respect to the JDRC, four (4) representatives drawn from the ranks of senior directors or employees
of each Party having appropriate expertise in the area of the Development and possessing authority
to make decisions on behalf of the Party they represent; and (b) with respect to the JCC, three (3)
representatives drawn from the ranks of senior directors or employees of each Party having
appropriate expertise in the area of the Commercialization and at least one (1) of whom shall be at
a level which allows him/her to make decisions on behalf of the Party they represent. Either Party
may replace its respective Committee representatives at any time with prior written notice to the
other Party; provided that the criteria for composition of each Committee set forth in the preceding
sentence continues to be satisfied following any such replacement of a Party's representative on any
such Committee. An alternate member designated by a Party may serve temporarily in the absence of a
member each of the JDRC or JCC for such Party. Each Party may invite its employees involved in each
of the Development or the Commercialization of the Product for each of JDRC meeting or JCC meeting
with the prior notice to the other Party. Each Party shall designate one of their members each of
the JDRC or the JCC to be a co-chairperson. The JDRC shall be co-chaired by one (1) representative
selected by Array and one (1) representative selected by Ono (the "JDRC Chairpersons"). The JCC
shall be co-chaired by one (1) representative selected by Array and one (1) representative selected
by Ono (the "JCC

21
<!-- page 28 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

Chairpersons"). Either Party shall have the right to change their JDRC Chairperson or JCC
Chairperson from time to time by written notice to the other Party.

3.4 Committee Meetings. The JDRC and JCC shall meet at least twice each Calendar Year, or as more or
less often as otherwise agreed to by the Parties. All Committee meetings may be conducted by
telephone, video-conference or in person as determined by the applicable Committee; provided that
the JDRC shall meet in person at least once each Calendar Year. Unless otherwise agreed by the
Parties, all in-person meetings for each Committee shall be held on an alternating basis between
Array's facilities and Ono's facilities. In addition to the regular meetings, either Party may
request an ad-hoc meeting of the JDRC and JCC to solve any specific issues from time to time. Each
Party shall bear its own personnel and travel costs and expenses relating to Committee meetings.
With the consent of the Parties (not to be withheld unreasonably), other employee representatives of
the Parties may attend any Committee meeting as non-voting observers.

3.5 Decision-Making.

(a) Escalation; Default Rules for Resolution. With respect to any decisions delegated to the
Committees, decisions of each Committee shall be made by unanimous vote, with at least one (1)
representative from each Party participating in any vote. The JDRC and JCC shall use good faith
efforts to reach consensus on matters within its decision-making authority. In the event the JDRC or
JCC fails to reach unanimous agreement with respect to a particular matter within its authority,
then such matter shall be referred to an executive of each Party who is senior in rank and authority
to such Party's JDRC or JCC representatives ("Senior Executive(s)") who shall meet promptly and
negotiate in good faith to resolve the dispute. If, despite such good faith efforts, the Senior
Executives are unable to resolve such dispute (each, a "Committee Dispute"), then, Ono shall have
the casting vote for the matter, except for those matters expressly set forth in Section 3.5(b)
below; provided, however, any and all casting votes shall be made in good faith, and after good
faith consideration of Array's comments or requests on such matters, and with due regard for the
impact of such casting vote on Development and Commercialization of the Products outside the Ono
Territory.

(b) Exceptions to Default Rules for Resolution.

(i) To the extent the subject of a Committee Dispute is a modification of the Development Plan or
the design or protocol of a Clinical Study to be conducted thereunder, Ono shall cast the deciding
vote on such matter; provided that such deciding vote shall be subject to and limited by the
following:

(A) If such Committee Dispute relates to whether a new Indication outside oncology should be
included in the Development Plan, then such matter shall be determined in accordance with Section
17.2 (and such determination shall become the decision of the JDRC);

22
<!-- page 29 -->
<!-- page 30 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(B) If such Committee Dispute relates to a proposal to adopt a new formulation (i.e., other than
solid dose oral formulations) for use in the Ono Territory, then such matter shall be determined in
accordance with Section 17.2 (and such determination shall become the decision of the JDRC); and

(C) If such Committee Dispute relates to a proposal to develop a new fixed dose Combination Product
for use in the Ono Territory, then such matter shall be determined in accordance with Section 17.2
(and such determination shall become the decision of the JDRC).

(ii) If such Committee Dispute relates to whether to accept or reject under Section 4.4(b) a Joint
Clinical Study Proposal, neither Party shall have a deciding vote, such matter shall not be
determined in accordance with Section 17.2 and such Joint Clinical Study Proposal shall be adopted
only as the Parties mutually agree. For clarity, once a Joint Clinical Study Proposal has been
agreed by the Parties, then any Committee Dispute with respect to such Joint Development Plan or
Approved Clinical Studies, or the performance thereof or changes thereto, shall be subject to
resolution in accordance with Section 17.2.

(iii) If such Committee Dispute relates to the allocation of costs for Third Party Technology under
Section 2.3(a), then such matter shall be determined in accordance with Section 17.2 (and such
determination shall become the decision of the JDRC).

(iv) If such Committee Dispute relates to whether to approve a request by Ono to authorize an
Investigator Sponsored Clinical Study that falls within one of the categories listed in the IST
Guidelines, then such matter shall be determined in accordance with Section 17.2 (and such
determination shall become the decision of the JDRC).

(v) If such Committee Dispute relates to the establishment of trademark guidelines for use of the
Binimetinib Product Trademark or Encorafenib Product Trademark to be established by the JCC, Array
shall have the casting vote.

(vi) If such Committee Dispute relates to whether any Marketing Materials, training manuals and/or
Educational Materials developed and used by Ono, its Affiliates and Sublicensees for the Product in
the Ono Territory are consistent with the reasonable trademark guidelines for use of the Binimetinib
Product Trademark or Encorafenib Product Trademark agreed upon by the JCC, then such matter shall be
determined in accordance with Section 17.2 (and such determination shall become the decision of the
JDRC).

(vii) If such Committee Dispute relates to whether any action by either Party under this Agreement
would negatively impact the safety, commercial value or reputation of the Products, then such matter
shall be determined in accordance with Section 17.2 (and such determination shall become the
decision of the JDRC).

23
<!-- page 31 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

For clarity: (x) in the event of a Committee Dispute with respect to a proposed action that,
pursuant to Section 3.5(a), has been referred to the Experts for a determination in accordance with
Section 17.2, the Party proposing to take the action that is the subject of such dispute shall not
proceed with such action unless and until the dispute has been resolved and JDRC has determined to
authorize such action (either by agreement or decision of the Experts pursuant to Section 17.2); and
(y) neither Party shall have the right to cast a deciding vote: (1) to excuse itself from any of its
obligations specifically enumerated under this Agreement; or (2) to amend, modify or update to the
Joint Development Plan. The resolution of the Experts with respect to a matter referred to the
Experts for a determination pursuant to this Section 3.5 (b) shall be deemed a resolution of the
JDRC thereafter and, subject to the terms and conditions of this Agreement, such decision shall be
binding on the Parties.

3.6 Working Groups. Upon mutual agreement, the Parties may establish other committees or working
groups (each, a "Working Group") as they deem appropriate. These Working Groups shall report to the
JDRC or JCC depending on the subject matter of such Working Group's oversight. Each Working Group
shall have equal number of representatives from each Party. Working Group may be established on an
ad hoc basis for purposes of a specific project. In no event shall the authority of a Working Group
exceed that of the JDRC or JCC.

3.7 Liaisons. Within thirty (30) days following the Effective Date, each Party shall appoint a
representative ("Liaison") to facilitate communications between the Parties (including, coordinating
the exchange of Data and know-how of each Party as required under this Agreement) and to act as a
liaison between the Parties with respect to such other matters as the Parties may mutually agree in
order to maximize the efficiency of the collaboration. Each Party may replace its Liaison with an
alternative representative at any time with prior written notice to the other Party. Each Party's
Liaisons shall be entitled to attend all Committee meetings. Each Liaison may bring any matter to
the attention of the Committees where such Liaison reasonably believes that such matter requires
attention of the Committees. Each Liaison shall be responsible with creating and maintaining a
collaborative work environment within and among the Committees.

3.8 Scope of Governance. Notwithstanding the creation of the JDRC or JCC, each Party shall retain
the rights, powers and discretion granted to it hereunder, and no Committee shall be delegated or
vested with rights, powers or discretion unless such delegation or vesting is expressly provided
herein, or the Parties expressly so agree in writing. No Committee shall have the power to amend or
modify this Agreement and shall only have such powers as are specifically delegated to it hereunder.
No decision of any Committee shall be in contravention of any terms and conditions of this
Agreement. The Liaisons shall not have any rights, powers or discretion except as expressly granted
to the Liaisons hereunder and in no event shall the Liaisons have any power to modify or amend this
Agreement. It is understood and agreed that issues to be formally decided by the JDRC or JCC, as
applicable, are only those specific issues that are expressly provided in this Agreement to be
decided by the JDRC or

24
<!-- page 32 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

JCC, as applicable. It is also understood that no Committee shall have any authority to take any
decision over activities related to the registration and/or commercialization of the Product for use
in the Array Territory.

3.9 Cost of Governance. The Parties agree that the costs incurred by each Party in connection with
its participation at any meetings under this Article 3 shall be borne solely by such Party.

ARTICLE IV DEVELOPMENT AND REGULATORY ACTIVITIES

4.1 Overview.

(a) General. Except as otherwise expressly provided in a Joint Development Plan, Ono (itself or
through its Affiliates or respective licensees or sublicensees) shall be responsible for the
Development of the Products for the Ono Territory. All Development activities conducted by or on
behalf of Ono hereunder shall be conducted in accordance with the Development Plan or Joint
Development Plan(s), as applicable, and in compliance with applicable Law, including laws regarding
environmental, safety and industrial hygiene, Good Laboratory Practice and Good Clinical Practice,
current standards for pharmacovigilance practice, and all applicable requirements relating to the
protection of human subjects. Except as otherwise set forth in a Joint Development Plan, Ono shall
bear all of the costs and expenses which it incurs in connection with any of the activities it
performs in the course of the Development of the Products for the Ono Territory.

(b) Collaborative Development. The Parties recognize that since the Products will be developed both
in the Ono Territory and the Array Territory, regulatory and budget efficiencies can be achieved
through the Parties' coordination and worldwide use of preclinical and clinical data and in
cooperatively conducting certain joint Clinical Studies. Accordingly, the Parties agree that it is
their mutual interest to cooperatively conduct the Approved Clinical Studies to be agreed upon and
set forth in Joint Development Plans as described in Section 4.4 below.

(c) Current Development Status. Prior to the Effective Date, Novartis AG ("Novartis") and/or Array
have independently initiated the following Clinical Studies of the Products: (i) a Phase III
clinical trial in NRAS Melanoma ("NEMO Clinical Study"), (ii) a Phase III clinical trial in BRAF
Melanoma ("COLUMBUS Clinical Study"), (iii) a Phase III clinical trial in BRAF Colorectal Cancer
("BEACON Clinical Study"), and (iv) those additional Phase 1 and Phase 2 Clinical Studies and
Investigator Sponsored Clinical Studies set forth in Exhibit 4.1 (collectively, the "Existing
Clinical Studies"). Array shall use Diligent Efforts to complete, at its expense, the Existing
Clinical Studies (including all pharmacovigilance aspects), including contracting and managing any
contract research organization(s) that may be involved in such Existing Clinical Studies, and Array
shall keep the JDRC informed of the status thereof and Ono

25
<!-- page 33 -->
<!-- page 34 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

shall have the opportunity to comment on the progress of the BEACON study through the JDRC. As
between the Parties: (and subject to applicable agreements and consent requirements) Array shall
have the right to implement modifications to any Existing Clinical Study(ies), provided that Array
shall not implement any modification to any Existing Clinical Study(ies) that would prejudice Ono as
regards safety or reputational issues, or the intended objectives for such Clinical Studies, or
cause a material delay in such Existing Clinical Study(ies), and provided further that Array shall
use Diligent Efforts to keep Ono informed through the JDRC of any material modification to any
Existing Clinical Study(ies) being conducted in the Ono Territory.

(d) Investigator Sponsored Clinical Studies. Notwithstanding Section 3.1(b)(viii) above, Ono shall
have the right to authorize the protocol for Investigator Sponsored Clinical Study in the Ono
Territory and support such Clinical Study at Ono's own discretion so long as such study does not
fall within one of the categories listed in the IST Guidelines, however Ono agrees to inform Array
of all such Investigator Sponsored Clinical Study(ies) in order to allow Array to provide Ono
comments with respect to such proposed Investigator Sponsored Clinical Study(ies) in a timely
manner. For clarity, in the event that a proposed Investigator Sponsored Clinical Study falls within
one of the categories listed in the IST Guidelines, then authorization of such Investigator
Sponsored Clinical Study shall require the agreement between the Parties through the JDRC.

4.2 Development Plan; Amendments.

(a) Initial Development Plan. Promptly following the Effective Date, and in any event within one
hundred and twenty (120) days following the Effective Date, Ono shall prepare a plan detailing the
Development activities ("Development Plan"), if any, that are necessary for obtaining Marketing
Approval in the Ono Territory of (i) a Binimetinib Product and an Encorafenib Product for
BRAF-mutant melanoma and (ii) a Binimetinib Product and an Encorafenib Product for BRAF-mutant
colorectal cancer for review, discussion and approval (or rejection) by the JDRC. The initial
Development Plan shall outline all of the regulatory activities, as well as of the Development
activities, if any, planned to be conducted in order to obtain Marketing Approval in each country in
the Ono Territory for the Products and Indications described in (i) and (ii) above and shall set out
a more detailed description of the designs for any (A) all Clinical Studies, (B) pre-clinical
studies and (C) other Development activities, that may be are necessary for obtaining the above
referenced Marketing Approval and which are planned to be conducted during the first twelve (12)
month period covered by such plan.

(b) Updates and Changes to the Development Plan. Ono shall provide to the JDRC, for its review,
discussion and approval (or rejection), an updated version of the Development Plan at least once
each Fiscal Year, at the first JDRC meeting in each Fiscal Year; and such updated Development Plan
shall include at least the level of detail regarding Ono's Development and

26
<!-- page 35 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

regulatory activities for the Products as the level of detail included in the Development Plan to be
provided within one hundred and twenty (120) days after the Effective Date pursuant to Section
4.2(a). In addition, Ono shall provide to the JDRC any material modifications or additions to the
then-current Development Plan for review, discussion and approval (or rejection) by the JDRC.

(c) Diligence. Ono shall use Diligent Efforts to achieve the goals set forth in the then-current
Development Plan in accordance with the timelines specified therein.

4.3 Development by Ono. Except with respect to the Existing Clinical Studies and as provided in
Section 4.4 (Joint Clinical Studies), subject to the oversight of the JDRC, Ono shall, at its
expense, be responsible for the conduct of all further Development of the Product for the Ono
Territory. Ono shall use Diligent Efforts to Develop, at its expense, the Products for the Ono
Territory so as to maximize the sales potential for the Product in the Ono Territory for the initial
Indications set forth in Section 4.2(a)(i) and (ii) and such other Indications as the Parties may
elect through the JDRC to include within the Development Plan, including conducting Clinical Studies
and other Development efforts in order to obtain and maintain Marketing Approval for the Product in
the Ono Territory for such other Indications as the Parties may elect through the JDRC to include
within the scope of this Agreement. Ono shall carry out all such activities in accordance with the
then-current Development Plan and the provisions of this Agreement.

4.4 Joint Clinical Studies.

(a) Joint Clinical Study Proposals. From time to time during the term of this Agreement, either
Party may submit to the JDRC a proposal for one or more joint Clinical Studies that would support
the filing of Marketing Approval Applications for the Product with Regulatory Authorities in both
the Ono Territory and the Array Territory (a "Joint Clinical Study Proposal"). Each such Joint
Clinical Study Proposal shall include a draft synopsis, proposed timelines for the conduct of such
studies, as well a proposed budget for such studies. The JDRC shall review and discuss each such
Joint Clinical Study Proposal and shall approve or reject such Joint Clinical Study Proposal in its
discretion.

(i) If the JDRC approves a Joint Clinical Study Proposal, such Joint Clinical Study Proposal shall
thereafter be deemed to be an "Approved Clinical Study" and the JDRC will create a Working Group to
prepare a full development plan ("Joint Development Plan") covering the Approved Clinical Study
based on the Joint Clinical Study Proposal. Unless otherwise agreed by the Parties, if such Approved
Clinical Study(ies) are Global Registration Studies, then the cost of such Approved Clinical
Study(ies) (including out-of-pocket costs incurred by the Parties together with FTE-costs associated
with the Parties' personnel managing such Approved Clinical Study) shall be allocated eighty eight
percent (88%) to Array and twelve percent (12%) to Ono.

27
<!-- page 36 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(ii) In the event that the JDRC does not approve the Joint Clinical Study Proposal (or a
substantially similar proposal) within sixty (60) days after such Joint Clinical Study Proposal has
been submitted to the JDRC, the each Party shall be free to carry out at its own expense the
relevant Clinical Study(ies) described in such Joint Clinical Study Proposal independently, subject
to the terms of Sections 2.1 and 4.4(c).

(b) Joint Development Plans. Pursuant to Section 4.4(a), the Working Group designated by JDRC shall
in good faith discuss and prepare the Joint Development Plan covering Approved Clinical Study(ies)
for review by JDRC.

(i) Once Joint Development Plan prepared by the Working Group is approved at JDRC, the Parties shall
initiate the Approved Clinical Study(ies) in accordance with the Joint Development Plan.

(ii) In the event that the JDRC is unable to agree upon a Joint Development Plan for such Approved
Clinical Study within sixty (60) days after the applicable Joint Study Proposal has been approved by
the JDRC, each Party shall be free to carry out such Approved Clinical Study(ies) at its own expense
independently upon notice to the other Party, and subject to the terms of Sections 2.1 and 4.4(c).

(iii) The JDRC shall review the Joint Development Plan on an ongoing basis from time-to-time as
needed. The JDRC may make adjustments to the then-current Joint Development Plan from time-to-time
as it deems appropriate.

(c) Consequences of Rejection of Joint Clinical Study Proposals or Joint Development Plan.

(i) In case of the rejection of a Joint Clinical Proposal by the JDRC pursuant to Section 4.4(a)(ii)
or the inability of the Parties to agree upon a Joint Development Plan for an Approved Clinical
Study as described in Section 4.4(b)(ii), each Party may, upon notice to the other Party, conduct
the relevant Clinical Study described in the Joint Clinical Study Proposal (hereinafter the
"Declined Clinical Study") at its own expense, subject to Section 2.1 above; provided, however,
that:

(A) any Declined Clinical Study conducted by Ono (or its Affiliates or Sublicensees) shall be
conducted solely within the Ono Territory;

(B) each Party, should it elect to conduct any Declined Clinical Study on its own shall keep the
JDRC and the other Party informed as to the design of any such Declined Clinical Study(ies) to be
conducted by or under its authority;

(C) any Declined Clinical Study conducted by Array or PFM shall be permitted to include clinical
sites within the Ono Territory to the extent consistent with the requirements of Section 4.5;

28
<!-- page 37 -->
<!-- page 38 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(D) if the Party that is not conducting a Declined Clinical Study (the "Non-Performing Party")
determines reasonably and in good faith that the Declined Clinical Study is reasonably likely to
adversely affect the Development or Commercialization of the Products in the Field, then the Party
performing such Declined Clinical Study (the "Performing Party") shall not undertake such Declined
Clinical Study unless and until the JDRC determines that such Declined Clinical Study should be
permitted; and

(E) The Performing Party shall provide formal written reports of the results of the Declined
Clinical Study and the costs of such Declined Clinical to the Non-Performing Party when such written
reports are available, and the JDRC during meetings of the JDRC, upon request of the other Party but
not more than twice a year during the period in which any study within the Declined Clinical Study
is being performed. For clarity, Section 18.11 shall apply with respect to Declined Clinical Studies
undertaken by either Party in accordance with this Section 4.4(c).

(ii) Costs of Declined Clinical Studies and Use of related Data. The Performing Party shall bear all
costs associated with Declined Clinical Studies it undertakes. If Ono (or an Ono Affiliate or
Sublicensee) submits to a Regulatory Authority in Ono Territory Data generated by Array (including
its Affiliates) or a Third Party Partner pursuant to a Declined Clinical Study (either directly or
by reference under Section 4.8 below) for purposes of obtaining new or expanded Marketing Approval
for the Product for the same Indication that was the subject of study in such Declined Clinical
Study, Ono shall reimburse Array an amount equal to [ * ] of the costs incurred by Array (including
by its Affiliates) and/or such Third Party Partner for the Declined Clinical Study. If Array
(including its Affiliates) and/or PFM submits to a Regulatory Authority in the Array Territory Data
generated by Ono pursuant to a Declined Clinical Study (either directly or by reference under
Section 4.8 below) for purposes of obtaining new or expanded Marketing Approval for the Product for
the same Indication that was the subject of study in such Declined Clinical Study, Array shall
reimburse Ono an amount equal to [ * ] of the costs incurred by Ono (including by its Affiliates)
for the Declined Clinical Study. Notwithstanding the foregoing, in the event that Ono is the
Non-Performing Party and the PMDA (or MHLW), based on the fact that the Declined Clinical Study
utilized clinical sites in Japan, compels Ono to file for a new or expanded Marketing Approval for
the Product based on the Data generated by Array pursuant to a Declined Clinical Study, then the
foregoing obligation to reimburse Array [ * ] of the costs of the Declined Clinical Study shall be
waived.

(d) Except for Investigator Sponsored Clinical Studies included in the Existing Clinical Studies,
neither Party shall authorize or support an Investigator Sponsored Clinical Study or any
Post-Approval Marketing Clinical Study in the other Party's territory without obtaining prior
written consent.

(e) Development Efforts; Manner of Performance; Reports.

29
<!-- page 39 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(i) Development Efforts. Each of Array and Ono shall use Diligent Efforts to execute and to perform,
or cause to be performed, the activities assigned to it in the Joint Development Plan(s), and to
cooperate with the other in carrying out the Joint Development Plan(s), in accordance with the
timetables therein. Each Party and its Affiliates shall conduct its Development activities in good
scientific manner and in compliance with applicable Law, including Laws regarding environmental,
safety and industrial hygiene, Good Manufacturing Practice, Good Laboratory Practice and Good
Clinical Practice, current standards for pharmacovigilance practice, and all applicable requirements
relating to the protection of human subjects. Before commencement of each Clinical Study pursuant to
a Joint Development Plan, the JDRC shall define the common database format to be used, the owner of
such database, the access of the other Party to the database, and the relevant clinical information
to be contained within. This will be done in a manner designed to address both FDA and PMDA
requirements.

(ii) Day-to-Day Responsibility. Each Party shall be responsible for day-to-day implementation of the
Development activities for which it (or its Affiliate) has or otherwise is assigned responsibility
under this Agreement or the Joint Development Plan(s) and shall keep the other Party reasonably
informed as to the progress of such activities, as determined by the JDRC.

(iii) Development Reports. At each meeting of the JDRC, each Party shall report on the Development
activities such Party, its Affiliates, Sublicensees and Third Party Partners (subject in the case of
Third Party Partners, to confidentiality obligations Array owe to such Third Party Partners) has
performed or caused to be performed under all ongoing Approved Clinical Studies since the last
meeting of the JDRC, evaluate the work performed in relation to the goals of the applicable Joint
Development Plans and provide such other information as may be reasonably requested by the JDRC with
respect to such Development activities. If a Party fails to adequately provide such report at a
meeting of the JDRC, the other Party may request, and such Party shall provide to such other Party,
a written progress report that includes information regarding accrual, site initiation, progress on
protocol writing, meeting requests and briefing documents, in the case of clinical or regulatory
activities, and in other cases such information as is reasonably necessary to convey a reasonably
comprehensive understanding of the status of the applicable Development activity.

(f) Ownership of INDs for Approved Clinical Studies. Ownership of all INDs and other related
regulatory filings filed in connection with each Approved Clinical Study shall be specified in the
Joint Development Plan for such Approved Clinical Study, provided that in the absence of any
agreement to the contrary in the Joint Development Plan, Ono shall be the owner of all INDs and
other related regulatory filings filed in connection with each Approved Clinical Study in the Ono
Territory and Array shall be the owner of all INDs and other related regulatory filings filed in
connection with each Approved Clinical Study in the Array Territory.

30
<!-- page 40 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

4.5 Right to Conduct Clinical Studies in Other Party's Territory.

(a) Generally. Neither Party shall conduct Clinical Studies in the other Party's Territory without
the prior written approval of the other Party, except that Array shall be entitled to conduct
Declined Clinical Studies utilizing sites within the Ono Territory without obtaining Ono's consent
(but prior notification is required), subject to the following:

(i) Array shall not conduct Clinical Studies for a Product in the Ono Territory with respect to an
Indication for which such Product has received Marketing Approval in the Ono Territory if Ono
reasonably believes that the conduct of such Clinical Studies is likely to materially adversely
affect the commercial value of such Product. In the event of a dispute between the Parties as to
whether Ono's belief regarding the harm to its market is reasonable, the Parties shall promptly
resolve such matter in accordance with the provisions of Section 17.2 below; provided that Array
shall not conduct such Clinical Studies in the Ono Territory unless and until such matter is
resolved in favor of such Clinical Studies proceeding.

(ii) Prior to commencing a Clinical Study in countries of the Ono Territory, Array shall inform and
coordinate with Ono regarding the conduct of such Clinical Study. In the event that Array proceeds
with a Clinical Study in the Ono Territory without Ono's participation, then the Parties shall enter
into a pharmacovigilance agreement pursuant to which Array shall provide Ono with the safety data.

(b) Combination Studies with [ * ] in the Ono Territory. Without limiting the limitations described
in Section 4.5(a), Array further agrees as follows:

(i) Array shall not sponsor any Clinical Studies of Binimetinib and/or Encorafenib in combination
with a [ * ] ("Combination Studies") where the such Clinical Studies are conducted solely for
purposes of obtaining Marketing Approval of the studied [ * ] in combination with Binimetinib and/or
Encorafenib in the Ono Territory ("Local Studies"); and

(ii) Array shall not supply Binimetinib, Encorafenib or Products to any Third Party for use in the
conduct of Local Studies; and

(iii) Array shall not include clinical sites in the Ono Territory in any Combination Study,
including but not limited to Phase1/2 studies, sponsored by Array that is intended to support
Marketing Approval of the studied [ * ] in combination with Binimetinib and/or Encorafenib in the
United States or Europe ("Global Studies"), unless Ono has previously declined a Joint Clinical
Study Proposal to conduct a Global Registration Study in the same patient population for a [ * ],
Binimetinib and/or Encorafenib combination. For the avoidance of doubt, Array shall make [ * ],
Binimetinib and/or

31
<!-- page 41 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

Encorafenib combination the highest priority in case Array intends to sponsor any Clinical Study of
Binimetinib and/or Encorafenib in combination with a [ * ] in the Ono Territory.

For clarity, it is understood and agreed that (w) nothing in this Section 4.5 shall prevent Array
from supplying Third Parties with Binimetinib, Encorafenib or Products for use by such Third Party
in Combination Studies so long as such Combination Studies are not Local Studies, (x) in the event
Array determines to supply any Third Party with Binimetinib, Encorafenib or Products for use by such
Third Party in any global Combination Studies sponsored by such Third Party that includes the Ono
Territory, Array shall notify Ono of such supply of Binimetinib, Encorafenib or Products to such
Third party promptly following Array's decision to supply such Third Party, (y) Array shall have no
obligation to prevent Third Parties from acquiring Product on the open market for use in conducting
Local Studies, and (z) the restrictions in this Section 4.5(b) shall not apply to PFM, and shall
immediately terminate upon a Change in Control of Array; provided however that, any Combination
Study shall be conducted subject to appropriate firewall procedures as described in Section 18.10 to
segregate such activities (and the personnel conducting such activities) from the activities
performed by or on behalf of Array pursuant to this Agreement, to ensure that [ * ] is used in
connection with such Combination Study in case of Change in Control of Array.

(c) Ono acknowledges that under the PFM Agreement, PFM has a right under certain circumstances to
conduct Clinical Studies in the Ono Territory. Without limiting PFM's rights under the PFM
Agreement, Array agrees that in the event that PFM submits an Additional Development Proposal (as
defined in the PFM Agreement) that would utilize clinical sites in the Ono Territory, Array shall
submit such proposal to the JDRC as a Joint Clinical Study Proposal under Section 4.4(a) and provide
Ono the opportunity to include the Clinical Study described in such Additional Development Proposal
as an Approved Clinical Study under this Agreement.

4.6 Regulatory Submissions and Marketing Approvals.

(a) Regulatory Responsibilities. Ono or its Affiliates shall be responsible for seeking and
attempting to obtain all Marketing Approvals for the Products in the Field in the Ono Territory, and
Array or its Affiliate or licensees shall be responsible for seeking and attempting to obtain all
Marketing Approvals for the Products in the Field in the Array Territory.

(b) INDs. Except for any INDs filed by Array in the Ono Territory (i) with respect to an Approved
Clinical Study for which the Parties agree in the applicable Joint Development Plan that the
applicable Regulatory Filing will be owned by Array, and/or (ii) with respect to Clinical Studies
conducted by Array in one or more countries of the Ono Territory pursuant to Section 4.5 above,
which Regulatory Filings, the "Array Regulatory Filings", shall be owned by Array, Ono shall be
responsible, at its expense, for filing, obtaining and maintaining, and shall own, all INDs for the
Product in the Ono Territory.

32
<!-- page 42 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(c) Ownership of Marketing Approvals. Ono or an Ono Affiliate shall own and maintain Marketing
Approvals for the Products in the Field in the Ono Territory including all regulatory submissions
and applications, provided that Ono may assign Marketing Approvals for the Product to its Affiliates
or permitted Sublicensees to the extent that such Affiliates or permitted Sublicensees have been
delegated primary responsibility for the commercialization of the Product in such countries. As
between the Parties, Array or an Array Affiliate shall own all regulatory submissions, including all
applications, for Marketing Approvals for the Products in the Field in the Array Territory.

(d) Regulatory Cooperation. Except with respect to (i) the Existing Clinical Studies, (ii) any
Approved Clinical Studies for which Array is the owner of the IND in a given country in the Ono
Territory, and/or (iii) with respect to Clinical Studies conducted by Array in one or more countries
of the Ono Territory pursuant to Section 4.5 above, Ono shall be responsible for liaising with and
managing all interactions with Regulatory Authorities in the Ono Territory, including with respect
to all Regulatory Filings for the Product in the Ono Territory (other than the Array Regulatory
Filings) and Array shall cooperate with Ono in such regulatory interactions (e.g. Ono's
correspondence to matters of inquiry from Regulatory Authorities) in a timely manner. Array shall be
entitled to participate in such interactions as provided in this Section 4.6(d) subject to receipt
of any required permissions of such Regulatory Authorities in the Ono Territory. Ono shall be
entitled to participate in interactions with Regulatory Authorities in Korea with respect to the
Existing Clinical Studies as provided in this Section 4.6(d) subject to receipt of any required
permissions of such Regulatory Authorities in Korea. Ono shall also be entitled to attend selected
material meetings with the FDA as an observer.

(i) To the extent relating to a Product within the Ono Territory or activities under this Agreement,
Ono shall provide Array with:

(A) reasonable advanced notice of substantive meetings (or telephone or similar substantive
interactions) that are either scheduled or initiated by or under the authority of Ono with a
Regulatory Authority in the Ono Territory and immediate notice of any unscheduled substantive
interactions that are initiated by such a Regulatory Authority (including, the PMDA or MHLW or any
committee to whom the PMDA or MHLW have delegated activities relating to the review or approval of
MAAs filed with the PMDA) other than meetings or interactions with any such Regulatory Authority
pertaining to Pricing and Reimbursement Approval of the Product in the applicable country, and
advance copies of all related documents and other relevant information relating to such meetings or
other contact except where the provision of advance copies is not possible as in the case of
unscheduled substantive interactions that are initiated by a Regulatory Authority.

(B) an opportunity to have up to two (2) representatives attend all substantive meetings and
interactions with Regulatory Authorities in the Ono Territory, subject to receipt of any required
permissions of such Regulatory Authorities in the Ono Territory, and if requested by Ono or required

33
<!-- page 43 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

under applicable Law, to actively participate in, all substantive meetings and interactions with any
Regulatory Authority in the Ono Territory; provided that Ono shall not be required to delay the
occurrence of any substantive meetings or interactions with any such Regulatory Authority to the
extent that Array representatives are not available to attend such substantive meetings or
interactions on the date and time the same are scheduled to occur; and in any case, Ono shall keep
Array informed as to all material interactions with Regulatory Authorities within the Ono Territory;
and

(C) a copy of any material documents, information and correspondence that Ono (or its designee)
proposes to submit to a Regulatory Authority in the Ono Territory relating to Regulatory Filings for
the Product reasonably in advance of the date on which such documents, information and/or
correspondence are proposed to be submitted, together with English translations thereof, if such
translations exist. Array shall have the right to consult with, and provide comments to, Ono in
connection with (1) any substantive meetings and/or interactions with Regulatory Authorities in the
Ono Territory and (2) any material documents, information and correspondence that Ono (or its
designee) proposes to submit to any Regulatory Authority in the Ono Territory; and Ono shall
consider in good faith all reasonable comments provided by Array with respect to such meetings,
interactions, documents, information and/or correspondence. Without limiting the foregoing, Ono
shall provide to Array copies of the proposed labeling for the Product in the local language to be
filed in the Ono Territory. Additionally, Ono shall provide Array with (1) a copy of the MAA in
electronic format provided that in cases where the MAA was not filed electronically, Ono will
provide the electronic files used to generate such submission, and (2) copies of the final labeling
for the Product in the local language in all countries in the Ono Territory in which Ono obtains
Marketing Approvals. Array shall provide to Ono copies of the proposed labeling for the Product in
the local language to be filed by Array in USA and by PFM in France, Germany, Italy, Spain and the
United Kingdom. Additionally, (1) Array shall provide Ono with a copy of the MAA filed by Array with
the FDA and a copy of the MAA filed by PFM with the EMA, in each case in electronic format, provided
that in cases where the MAA was not filed electronically, Array will provide the electronic files
used to generate such submission, and (2) Array shall provide to Ono copies of the final labeling
for the Product in the local language in all countries in the Array Territory in which Array and
Array's Third Party Partners obtains Marketing Approvals.

(ii) The Parties shall cooperate in good faith with respect to Regulatory Authority inspections of
any site or facility where Clinical Studies, manufacturing or pharmacovigilance activities with
respect to the Product are conducted by or on behalf Ono pursuant to this Agreement, whether such
site or facility is Ono's or its Affiliate's or Subcontractor's (each an "Audited Site"). Array
shall be given a reasonable opportunity (taking into account the timing and notice provided by the
applicable Regulatory Authority) to assist in the preparation of the Audited Sites for inspection,
where appropriate, and to attend any inspection by any Regulatory Authority of the Audited Sites,
and the summary, or wrap-up, meeting with a Regulatory Authority at the conclusion of such
inspection subject to any required

34
<!-- page 44 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

permission of such Regulatory Authorities. If such attendance would result in the disclosure to
Array of Confidential Information unrelated to the subject matter of this Agreement, upon Ono's
request the Parties shall enter into a reasonable and customary confidentiality agreement with
respect to such unrelated subject matter. Ono shall use Diligent Efforts to secure for the other
Party the rights set forth in this Section 4.6(d)(ii) from its Subcontractors. In the event that Ono
is unable to secure such inspection rights from any of its Subcontractors, Ono agrees to secure such
rights for itself and, if requested by Array, shall exercise such rights, at its own expense, on
behalf of Array and fully report the results thereof to Array. In the event that any Audited Site is
found to be non-compliant with one or more Good Laboratory Practice, Good Clinical Practice, Good
Manufacturing Practice or current standards for pharmacovigilance practice, Ono shall submit to
Array a proposed recovery plan or Corrective and Preventative Actions ("CAPA") within a reasonable
period after Ono, its Affiliate or its Subcontractor receives notification of such non- compliance
from the relevant Regulatory Authority and Ono shall use Diligent Efforts to implement such recovery
plan or CAPA promptly after submission.

(iii) Ono shall propose to the JDRC, and the JDRC shall review and approve or reject on the overall
strategy of all material Regulatory Filings with applicable Regulatory Authorities in the Ono
Territory through JDRC (other than any such Regulatory Filings pertaining to Pricing and
Reimbursement Approval of the Product in the Ono Territory) prior to their submission or filing by
or under the authority of Ono. Ono shall have the sole right to negotiate with, and obtain from, the
applicable Regulatory Authorities a reimbursement drug price of the Products within the Ono
Territory. [ * ]

(iv) Each Party shall promptly provide the other Party with copies of all material documents,
information and correspondence received from a Regulatory Authority within the Ono Territory as well
as Array Territory directed to the Development of the Product for Commercialization within the Ono
Territory (including a written summary in English of any material communications in which such other
Party did not participate) and, upon reasonable request, with copies of any other documents, reports
and communications from or to any Regulatory Authority within the Ono Territory directed to the
Product or activities under the Agreement.

(v) Notices, copies of submissions and correspondence, and other materials to be given in advance as
provided in this Section 4.6(d) shall be provided in any event not less than a reasonable time in
advance.

4.7 Exchange of Data and Know-How.

(a) By Array. Array or its Affiliates will make available to Ono, all additional (i.e., beyond that
already made available to Ono as of the Effective Date) Array Know-How relating to Binimetinib,
Encorafenib and the Products containing Binimetinib or Encorafenib currently under Development by
Array that exists as of the Effective Date as may be reasonably requested

35
<!-- page 45 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

by Ono, in each case that is reasonably available to Array and is necessary or materially useful for
Ono to Develop, Manufacture and/or Commercialize the Product(s) in accordance with this Agreement,
including all Data from the Existing Clinical Studies and any other Clinical Studies and
pre-Clinical Studies for the Product that have been conducted by or on behalf of Array prior to the
Effective Date. Array shall make any such Data available in the original language in which such Data
was generated.

(b) By Either Party. During the term of this Agreement, Array shall provide to Ono all Array
Know-How, and Ono shall provide to Array all Ono Know-How, that is generated during the term of this
Agreement and that has not previously been provided hereunder, in each case promptly upon request by
the other Party. The Party providing such Party's know-how shall provide the same in electronic form
to the extent the same exists in electronic form, and shall provide copies or an opportunity to
inspect (and copy) for all other materials comprising such know-how (including, for example,
original patient report forms and other original source data). Any Data provided by one Party to the
other under this Subsection 4.7(b) shall be provided in the original language in which such Data was
generated, provided that, with respect to Data relating to any Joint Development Plan, if such
original language is not English, then the Party supplying such Data shall also provide English
translations thereof and the expense for such English translations shall be borne by the receiving
Party. The Parties will cooperate and reasonably agree upon formats and procedures to facilitate the
orderly and efficient exchange of the Array Know-How and the Ono Know-How in accordance with the
last sentence of Section 4.7(b).

4.8 Rights of Reference and Access to Data. Subject to Section 2.4 and 4.7, each Party shall have
the right to cross- reference the other Party's Regulatory Filings (and in the case of Ono, Array's
Third Party Partners' Regulatory Filings) related to the Products, and to access such Regulatory
Filings and any Data therein and use such Data in connection with the performance of its obligations
and exercise of its rights under this Agreement, including inclusion of such Data in its own
Regulatory Filings for Product; provided, however, that with respect to Data obtained from Declined
Clinical Studies conducted at the Performing Party's expense in accordance with Section 4.4(c), the
Non-Performing Party's right to cross-reference, or to include such Data in its Regulatory Filings
for Product, shall be subject to compliance with the corresponding reimbursement obligation set
forth in Section 4.4(c)(ii). Each Party hereby grants to the other Party, its Affiliates and
Sublicensees (or in the case of Array, its other licensees) a "Right of Reference," as that term is
defined in 21 C.F.R. § 314.3(b) in the United States, or an equivalent right of access/reference in
any other country or region, to any Data, including such Party's or its Affiliate's clinical
dossiers, Controlled by such Party or such Affiliate that relates to the Product for use by the
other Party to Develop and Commercialize the Product in the Field pursuant to this Agreement,
subject to Section 4.4(c)(ii) above. Each Party or such Affiliate shall provide a signed statement
to this effect, if requested by the other Party, in accordance with 21 C.F.R. § 314.50(g)(3) or the
equivalent as required in any country or region or otherwise provide

36
<!-- page 46 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

appropriate notification of such right of the other Party to the applicable Regulatory Authority.
Each Party will provide, and cause its Affiliates to provide, cooperation to the other Party to
effect the foregoing.

4.9 Inspection Right.

(a) Ono shall, and shall require its Affiliates to, permit Array, and/or an authorized
representative reasonably acceptable to Ono, to enter the relevant facilities of Ono and its
Affiliates during normal business hours and upon reasonable advance notice to inspect and verify
compliance with applicable regulatory and other requirements, as well as with this Agreement, with
respect to all matters relating to the Product, all Ono Know-How to be provided to Array pursuant to
Section 4.7 and the activities generating such Ono Know-How. Such inspection right shall include the
right to examine any internal procedures or records of Ono and/or its Affiliates relating to the
Product. Ono and its Affiliates shall give Array or its authorized representative, all necessary and
reasonable assistance for a full and correct carrying out of the inspection. Such inspection shall
not relieve Ono of any of its obligations under this Agreement.

(b) Ono shall use Diligent Efforts to secure for Array the rights set forth in Section 4.9(a) from
Ono's Sublicensees and other contractors for the Product. In the event Ono is unable to secure such
inspection rights from any of its Sublicensees or contractors, Ono agrees to secure such rights for
itself and, if requested by Array, Ono shall exercise such rights, at Array's expense, on behalf of
Array and fully report the results thereof to Array.

4.10 Patient Samples. To the extent permitted by applicable Laws, each Party shall own or control
any patient samples (together with compilations of Data comprising annotations, or correlating
outcomes, with respect to such samples, "Patient Samples") collected and retained in connection with
Clinical Studies of which it is the sponsor.

4.11 Reporting; Adverse Drug Reactions.

(a) Array shall hold and maintain the global safety database with respect to the Products. Array
shall be responsible for core safety management of the Product, as provided in a pharmacovigilance
agreement executed by the Parties pursuant to section 4.11(b), within and outside the Ono Territory;
and Ono shall cooperate with and assist Array, as requested and/or as provided in the
pharmacovigilance agreement executed by the Parties, to enable Array to meet its regulatory
reporting requirements with respect to the core safety management for the Product within and outside
the Ono Territory. Ono shall be responsible for all other pharmacovigilance activities associated
with the Product in the Ono Territory, including filing all reports required to be filed in order to
maintain any IND for the Product filed by or under the authority of Ono as the sponsor, and/or any
Marketing Approvals granted for the Product, in the

37
<!-- page 47 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

Ono Territory (including reporting of adverse drug experiences, product quality complaints and
safety data relating to the Product in the Ono Territory). Each Party shall promptly notify the
other Party with respect to any material changes or material issues that may arise in connection
with any IND for the Product filed by or under the authority of such Party as the sponsor, and/or
any Marketing Approvals for the Product, in any country within such Party's territory.

(b) The Parties shall enter into pharmacovigilance agreements on reasonable and customary terms no
less stringent than those required by applicable ICH Guidelines, including: (i) providing detailed
procedures regarding the responsibilities for the creation and maintenance of core safety
information (e.g.,: Core Data Sheet, Risk Management Plan, Local Product Safety Labeling,
Development and Product Safety Updates); (ii) the exchange of safety data relating to the Product
within and outside the Ono Territory within appropriate time frames and in an appropriate format to
enable each Party to meet its expedited and periodic regulatory reporting requirements; and (iii)
ensuring compliance with the reporting requirements of all applicable Regulatory Authorities on a
worldwide basis for the reporting of safety data in accordance with all applicable legal and
regulatory requirements regarding the management of safety data. Promptly following the Effective
Date but no later than sixty (60) days before Ono's IND filing for the first Clinical Study in the
Ono Territory, the Parties shall enter into such a pharmacovigilance agreement, which shall be
applicable to such pre-marketing safety information that will be available from Clinical Studies. As
soon as practicable following the Effective Date, the Parties shall initiate negotiation of a
post-marketing safety data exchange agreement, and shall enter into such agreement no later than
sixty (60) days before approval of such MAA by Regulatory Authority (or as otherwise agreed by the
Parties), which shall be applicable to such post-marketing safety information that will be available
from post-marketing experiences with the Product.

ARTICLE V COMMERCIALIZATION AND PROMOTION

5.1 Ono Commercialization.

(a) Ono's Responsibility. Except as provided below, Ono shall be responsible for, and shall control
the conduct of, the Commercialization of the Products in the Ono Territory, at its expense, in
accordance with Section 8.1.

(b) Commercialization Plan.

(i) No later than one hundred eighty (180) days prior to the anticipated filing of the first MAA in
the Ono Territory, Ono shall provide Array with the plan for Commercialization of the Product in the
Ono Territory ("Commercialization Plan") through JCC. Further, Array shall also provide Ono with
Array's plan for commercialization of the Product in USA and, to the extent it is able to do so

38
<!-- page 48 -->
<!-- page 49 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

without violating its contractual obligations to PFM, PFM's plan for commercialization of the
Product in France, Germany, Italy, Spain and the United Kingdom, in each case through JCC, in order
for Ono to maximize its commercial activities conducted in the Ono Territory.

(ii) Ono shall provide to the JCC an updated version of the Commercialization Plan for its review
during the JCC meeting; and such updated Commercialization Plan shall include an equivalent level of
detail regarding Ono's Commercialization activities for the Products as the level of detail included
in the Commercialization Plan. Further, Array shall also provide to the JCC an updated version of
the commercialization plan for the USA and, to the extent it is able to do so without violating its
contractual obligations to PFM, an updated version of PFM's plan for commercialization of the
Product in France, Germany, Italy, Spain and the United Kingdom for their review during the JCC
meeting to be provided pursuant to Section 5.1(b)(i).

(iii) Ono shall use Diligent Efforts to carry out, and to cause its Affiliates and Sublicensees to
carry out, all Commercialization of the Products in the Ono Territory in accordance with the
then-current Commercialization Plan and the provisions of this Agreement.

(c) Marketing Materials. Marketing, advertising and promotional materials ("Marketing Materials")
concerning the Products for use in the Ono Territory, as well as training manuals and education and
communication materials ("Educational Materials") for sales representatives in the Ono Territory
shall be developed and prepared by Ono, at its own expense. Array shall provide reasonable
assistance to Ono in connection with the foregoing, including supplying to Ono representative forms
of Marketing Materials, training manuals and Educational Materials for the Product used by Array in
the United States, France, Germany, Italy, Spain and the United Kingdom, which Ono, its Affiliates
and Sublicensees may adapt for use in the Ono Territory. Any Marketing Materials, training manuals
and/or Educational Materials developed and used by Ono, its Affiliates and Sublicensees for the
Product in the Ono Territory shall be consistent with the Marketing Approval in the applicable
country and with the reasonable trademark guidelines for use of the Binimetinib Product Trademark
and Encorafenib Product Trademark agreed upon by the JCC, and shall comply with all applicable Laws,
rules and regulations. Ono shall keep Array reasonably informed with respect to Marketing Materials
and Educational Materials used in the in the Ono Territory and shall provide to Array copies (in
electronic form) of any Marketing Materials and/or Educational Materials to be used in the Ono
Territory for the Product developed by Ono (and/or any of its Affiliates or Sublicensees) and any
material changes to any such Marketing Materials and/or Educational Materials.

ARTICLE VI PAYMENTS

39
<!-- page 50 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

6.1 Upfront Fee. Ono shall pay to Array a license fee equal to Three Billion Five Hundred Million
Japanese Yen (¥3,500,000,000), on or before the date that is ten (10) Business Days after the
receipt by Ono of invoice for such license fee and the taxation documents expressly described in
Section 7.3. This license fee set forth in this Section 6.1 shall not be refundable or creditable
against any future milestone payments, royalties or other payments by Ono to Array under this
Agreement.

6.2 Milestone Payments.

(a) BEACON Milestone Payments. Ono shall pay to Array the milestone payments set out below following
the first achievement by Array of the corresponding milestone events set out below with respect to
the Product, in accordance with this Section 6.2(a) and the payment provisions in Article 7:

Milestone Event Milestone Payment

1. [ * ] ¥[ * ]

2. [ * ] ¥[ * ]

3. [ * ] ¥[ * ]

4. [ * ] ¥[ * ]

With respect to the milestones set forth in this Section 6.2(a), the total amount of such milestones
to be paid by Ono to Array shall not exceed [ * ].

(b) Regulatory and Sales Milestone Payments. In addition, Ono shall pay to Array the milestone
payments set out below following the first achievement by Ono, and/or any of its Affiliates or
Sublicensees, of the corresponding milestone events set out below with respect to the Product, in
accordance with this Section 6.2(b) and the payment provisions in Article 7:

40
<!-- page 51 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

Milestone Event Milestone Payment

Regulatory Milestone Event

1. [ * ] ¥[ * ]

2. [ * ] ¥[ * ]

3. [ * ] ¥[ * ]

4. [ * ] ¥[ * ]

5. [ * ] ¥[ * ]

6. [ * ] ¥[ * ]

7. [ * ] ¥[ * ]

8. [ * ] ¥[ * ]

Sales Milestone Event

1. [ * ] ¥[ * ]

2. [ * ] ¥[ * ]

3. [ * ] ¥[ * ]

4. [ * ] ¥[ * ]

5. [ * ] ¥[ * ]

With respect to the milestones set forth in this Section 6.2 (b), the total amount of such
milestones to be paid by Ono to Array shall not exceed [ * ].

(c) Certain Definitions. For purposes of Section 6.2(b) above:

(i) "Binimetinib Product" shall mean a Product containing Binimetinib as an active pharmaceutical
ingredient;

(ii) "Encorafenib Product" shall mean a Product containing Encorafenib as an active pharmaceutical
ingredient; and

(iii) [ * ]

(d) Reports and Payments. Array shall notify Ono in writing within fifteen (15) Business Days after
the achievement of each milestone set out in Section 6.2(a) by Array. Then, the corresponding
milestone payment shall be due within thirty (30) days of receipt by Ono of an invoice for payment
and the taxation documents delivered from Array. Ono shall notify Array in writing within fifteen
(15) Business Days after the achievement of each milestone set out in Section 6.2(b) by Ono, or any
of its Affiliates
<!-- page 52 -->
or Sublicensees. Then, the corresponding milestone payment shall be due within thirty (30) days of
receipt by Ono of an invoice and the taxation documents delivered from Array. Any milestone payable
by Ono pursuant to this Section 6.2 shall be made only once with respect to the achievement of each
milestone set out in Section 6.2(a) and Section

41
<!-- page 53 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

6.2(b) above, regardless of subsequent or repeated achievement of such milestone event by any
Product.

6.3 Earned Royalties For Products. During the term of this Agreement, Ono shall pay to Array, on a
quarterly basis, a royalty on the Net Sales of Products by Ono, its Affiliates or Sublicensees. Such
royalty shall be paid quarterly, at the applicable rates set forth in Section 6.3 below, based on
the Annual Net Sales of all Products, subject to the adjustments set forth in Sections 6.4 to 6.7
(the "Royalty Payments").

(a) General.

(i) Subject to the other provisions of Sections 6.4 to 6.7, the applicable royalty rate shall be as
follows:

Annual Net Sales in a Given Fiscal Year Royalty Rate

With respect to the portion of Annual Net Sales lower than or equal to [ * ] [ * ]

With respect to the portion of Annual Net Sales greater than [ * ] [ * ]

(ii) Notwithstanding Section 6.3(a)(i) and subject to the other provisions of Sections 6.4 to 6.7,
the royalty rate applicable to an Annual Net Sale of a Product in a country during the Secondary
Royalty Term shall be equal to [ * ] of the otherwise applicable royalty rate under 6.3(a)(i).

(b) For purposes of determining the royalty rate(s) pursuant to Section 6.3 that is or are
applicable hereunder on the Net Sales of Products and for determining Net Sales for the Commercial
Milestones, all Annual Net Sales of all Products in all countries of the Ono Territory shall be
aggregated on a Fiscal Year basis and the applicable royalty rate shall be determined.

(c) For purposes of determining the royalty rate applicable under Section 6.3(a)(i) and 6.3(a)(ii),
the Annual Net Sales of Products for which the royalty rate is subject to adjustment under Sections
6.4 below (Reduction for Generic Competition) and of Products not subject to such adjustment shall
be allocated proportionately to the two Annual Net Sales levels (i.e., to the first [ * ], and
amounts over [ * ]). Such allocation shall initially be made on a quarterly basis for each calendar
quarter, but shall be reconciled in the royalty report under Section 6.3(d) below for the fourth
quarter of each Fiscal Year, based on total Annual Net Sales for the full Fiscal Year. If as a
result of such reconciliation, Ono has underpaid Array for the full Fiscal Year, the shortfall shall
be due with such final royalty payment for such Fiscal Year. If as

42
<!-- page 54 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

a result of such reconciliation, Ono has overpaid Array for the full Fiscal Year, Ono shall be
entitled to credit such overpaid amounts against future royalties due hereunder, provided that Array
shall remit any such overpaid amounts that remain uncredited as of the termination of this Agreement
within fifteen (15) days after such termination takes effect.

(d) Royalty Reports. Within forty five (45) days after the end of each calendar quarter, commencing
with the calendar quarter in which the First Commercial Sale occurs, Ono shall deliver to Array a
report (each, a "Royalty Report") setting out all details necessary to calculate the payments due
under this Section 6.3, including:

(i) gross sales of the Product in the Ono Territory in the relevant calendar quarter on a
country-by-country basis;

(ii) Net Sales in the relevant calendar quarter on a country-by-country basis;

(iii) all relevant exchange rate conversions in accordance with Section 7.2;

(iv) all deductions in total in accordance with Sections 1.48 and 6.5; and

(v) the amount of any payment due from Ono to Array, calculated in accordance with this Article 6.

Simultaneously with the delivery of each such report, Ono shall pay to Array the total amounts due
under Section 6.3 for the period covered by such report subject to Ono's receipt of taxation
documents.

6.4 Reduction for Generic Competition.

(a) Initial Royalty Term. During the Initial Royalty Term for a Product in a particular country of
the Ono Territory, the royalty rate applicable to such Product in such country under Section 6.3(a)
(i) above is subject to reduction in certain events, based on the level of competition from Generic
Versions of such Product in such country as follows. During the Initial Royalty Term for a Product
in a country:

(i) If Generic Market Share with respect to such Product in such country equals or exceeds [ * ],
then for so long as such Generic Market Share with respect to such Product equals or exceeds [ * ]
in such country, the royalty rate under Section 6.3(a) (i) applicable to the Annual Net Sales of
such Product in such country shall be adjusted to [ * ].

(i) It is understood that the adjustment in this Section 6.4(a) shall apply to a particular Product
in a particular country only during the Initial Royalty Term for such Product in

43
<!-- page 55 -->
<!-- page 56 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

such country. After such Initial Royalty Term, any adjustment based on Generic Market Share of
Generic Versions of such Product in such country will be governed by Section 6.4(b) below, if
applicable.

(a) Secondary Royalty Term. During the Secondary Royalty Term for a Product in a country:

(i) If Generic Market Share with respect to such Product in such country equals or exceeds [ * ],
but is less than [ * ], then the royalty rate under Section 6.3(a) (ii) applicable to the Annual Net
Sales of such Product in such country shall be [ * ].

(ii) If Generic Market Share with respect to such Product in such country equals or exceeds [ * ],
then the royalty rate under Section 6.3(a) (ii) applicable to Annual Net Sales of such Product in
such country shall be equal to [ * ].

(b) Certain Terms. For purposes of this Section 6.4:

(i) "Generic Version" means a product that: (i) contains as an active pharmaceutical ingredient a
chemical composition that is assigned the same INN (international nonproprietary name) or JAN
(Japanese Accepted Names for Pharmaceuticals) as is assigned to active pharmaceutical ingredient
contained in the corresponding Product being marketed in the Ono Territory; (ii) obtained Marketing
Approval in a country in the Ono Territory by means of an abridged procedure that relies (A) in
whole or in part on the safety and efficacy data contained in the MAA for such Product submitted by
Ono in such country, and (B) on establishing bioequivalence to the Product; and (iii) is legally
marketed in the Ono Territory by an entity other than Ono, its Affiliates or its Sublicensees
without infringing any Valid Claim of an Array Patent.

(ii) "Generic Market Share" means, with respect to a Product in a country, for any calendar month,
the fraction B/(A+B), where: A is the quantity (e.g. the number of tablets) of the Products sold by
Ono, its Affiliates and Sublicensees in such country in the Ono Territory in such calendar month and
B is the total quantity of the Generic Versions sold in such country in the Ono Territory in such
calendar month. Generic Versions sales shall be determined by a reputable Third Party data source
generally accepted in the pharmaceutical industry in the relevant country and mutually agreed by the
Parties).

6.5 Third Party Licenses. If Ono or any of its Affiliates or Sublicensees (i) becomes obliged to pay
any amount to a Third Party with respect to any Blocking Patent or otherwise determines in its good
faith judgment with advice from independent legal counsel that it is necessary or advisable to
obtain a license from any Third Party with respect to any Blocking Patent in order to make, have
made, use, sell, offer for sale or import the Product for any given country of the Ono Territory,
Ono may deduct up to [ * ] of any such Third Party payments from the Royalty Payment; provided that
such deduction

44
<!-- page 57 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

shall not exceed in any calendar quarter [ * ] of the aggregate Royalty Payment otherwise payable in
such calendar quarter, with any amounts in excess of the permitted deduction be carried forward to
the subsequent calendar quarters until exhausted. As used herein, "Blocking Patent" shall mean a
Patent owned or controlled by a Third Party that covers the Product in the applicable country.

6.1 Third Party Payments. Array shall be solely responsible for all Third Party license payments,
milestones and royalties owed with respect to the Product, on intellectual property that is owned or
licensed by Array on or prior to the Effective Date, or any Blocking Patent of which Array was
actually aware but did not disclose to Ono on or prior to the Effective Date.

6.2 Aggregate Floor for Royalty Reductions. Royalty Floor. Notwithstanding Sections 6.4, 6.5, and
6.6, the Royalty Payment to Array shall not be reduced in any calendar quarter (a) during the
Initial Royalty Term to less than [ * ] of the amount due under Section 6.3(a)(i), and (b) during
the Secondary Royalty Term to less than [ * ] of the amount due under Section 6.3(a) (ii) (provided
that any amounts in excess of the permitted deduction shall be carried forward to the subsequent
calendar quarters until exhausted), unless 6.4(b) applies in which case royalty shall be as set
forth therein.

ARTICLE VII PAYMENTS; BOOKS AND RECORDS

7.1 Payment Method. All payments under this Agreement shall be made by bank wire transfer in
immediately available funds to an account designated by the Party to which such payments are due.
Any payments or portions thereof due under this Agreement that are not paid by the date such
payments are due under this Agreement shall bear interest at a rate equal Libor US Dollars one month
with respect to payments in US Dollars, or the one month equivalent interbank offered rate with
respect to payments in other currencies, plus in each case [ * ] per year, calculated on the number
of days such payment is delinquent, compounded monthly and computed on the basis of a three hundred
sixty five (365) day year. This Section 7.1 shall in no way limit any other remedies available to
the Parties.

7.2 Currency Conversion. All amounts specified in this Agreement are in Japanese Yen. All payments
hereunder shall be made in US Dollars. All such payment shall be converted into US Dollars at the
exchange rate (TTS rate) for the conversion of Japanese Yen into US Dollars posted by the Bank of
Tokyo-Mitsubishi UFJ, Ltd. on the date on which Ono will make the applicable payment hereunder,
provided that no deduction from any amount shall be made in respect of bank fees or charges. All
such payments shall be paid by bank wire transfer in immediately available funds to bank account
designated in writing by Array from time to time. The first designated bank account of Array shall
be as follows:

45
<!-- page 58 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

Account name: [ * ]

Reference: [ * ]

Account number: [ * ]

Bank name: [ * ]

Address: [ * ]

Swift code: [ * ]

[ * ]

If any currency conversion shall be required in connection with the payment of royalties or other
amounts under this Agreement, such conversion shall be calculated using at the exchange rate for the
conversion of foreign currency into Japanese Yen posted by the Bank of Tokyo-Mitsubishi UFJ.

7.3 Taxes.

(a) Withholding Taxes. If Laws or regulations require withholding by Ono of any taxes imposed upon
Array on account of any royalties or other payments paid under this Agreement, such taxes shall be
deducted by Ono as required by Law from such payment and shall be paid by Ono to the proper taxing
authorities. Ono shall use Diligent Efforts to secure official receipts of payment of any
withholding tax and shall send them to Array as evidence of such payment. Array shall provide to Ono
any taxation documents (Form 3 and Form 17), and the Residency Certificate of Array issued by the US
Internal Revenue Service (which Residency Certificate is effective for three (3) years after its
issuance to a public company) that may be reasonably necessary in order for Ono not to withhold tax
or to withhold tax at a reduced rate under an applicable bilateral income tax treaty. Without
limiting the foregoing, the Parties shall exercise their reasonable efforts to ensure that any
withholding taxes imposed are reduced as far as possible under the provisions of any applicable tax
treaty, and shall cooperate in filing any forms required for such reduction. Each Party shall
cooperate with the other and furnish the other Party with appropriate documents to secure
application of the most favorable rate of withholding tax under applicable Law (or exemption from
such withholding tax payments, as applicable).

(b) Sales Taxes. Any sales taxes (including any consumption tax or value added tax), use tax,
transfer taxes, duties or similar governmental charges required to be paid in connection with the
transfer to a Party of a Product (including for clarity, Drug Substance or Drug Product) produced by
or on behalf of the supplying Party pursuant to this Agreement shall be the sole responsibility of
the receiving Party. In the event that the supplying Party is required to pay any

46
<!-- page 59 -->
<!-- page 60 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

such amounts, the receiving Party shall promptly remit payment to the supplying Party of such
amounts.

7.4 Records; Inspection. Ono shall keep, and require its Affiliates and Sublicensees to keep,
complete, true and accurate books of accounts and records for the purpose of determining the amounts
payable to Array pursuant to this Agreement. Such books and records shall be kept for at least three
(3) years following the end of the calendar quarter to which they pertain. Such records will be open
for inspection during such three (3) year period by an independent certified public accounting firm
of nationally (the US or Japan) recognized standing (the "Auditor"), chosen by Array and reasonably
acceptable to Ono for the purpose of verifying the amounts payable by Ono hereunder. Such
inspections may be made no more than once each Calendar Year, at reasonable times and on reasonable
prior written notice. Such records for any particular calendar quarter shall be subject to no more
than one inspection. The Auditor shall be obligated to execute a reasonable confidentiality
agreement prior to commencing any such inspection. Inspections conducted under this Section 7.4
shall be at the expense of Array, unless a variation or error producing an underpayment in amounts
payable exceeding [ * ] of the amount paid for a period covered by the inspection is established, in
which case all reasonable costs relating to the inspection for such period and any unpaid amounts
that are discovered shall be paid by Ono, together with interest on such unpaid amounts at the rate
set forth in Section 7.1 above. The Parties will endeavor in such inspection to minimize disruption
of Ono's normal business activities to the extent reasonably practicable. For clarity, while Ono
does not engage in the bundling of products as of the Effective Date, in the event that Ono elects
in the future to provide a discount for the purchase of a bundle of products that includes a
Product, or if its Affiliates or Sublicensees sell Product as part of said discounted bundle, such
discount shall be allocated to Product, for purposes of this Agreement, based on the ratio,
calculated on a quarterly basis, of Product sales to sales of all of Ono's products sold in the Ono
Territory. It is understood that the foregoing audit rights shall include the right to have the
Auditor verify Ono's compliance (and the compliance of its Affiliates and Sublicensees) with the
above requirements.

ARTICLE VIII CERTAIN COVENANTS

8.1 Diligence Obligations.

(a) General Diligence Obligations. Ono shall use Diligent Efforts (itself or through its Affiliates)
to obtain in a prompt and expeditious manner Marketing Approvals and Pricing and Reimbursement
Approvals in the Ono Territory for the Products and Indications specified in the Development Plan
(including, conducting any Development that may be required by the Regulatory authorities in the Ono
Territory to obtain and maintain such Marketing

47
<!-- page 61 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

Approvals), and thereafter shall use Diligent Efforts to Commercialize the Product(s) for such
Indication(s) in the Ono Territory in a manner intended to maximize Net Sales in the Ono Territory
as a whole. For the avoidance of doubt, a decision by Ono not to seek a new or expanded Marketing
Approval for a Product in the Ono Territory based on a Declined Clinical Study or a Combination
Study shall not constitute a breach by Ono of its diligence under this Section 8.1(a).

(b) Conflicts of Interest. Ono and its Affiliates shall set prices and discounts for and shall
otherwise Develop and Commercialize the Products solely in the interest of the commercial success of
such Products in the Ono Territory and not for the interest of any of their other products and
services.

8.2 Exclusivity of Efforts. Prior to the [ * ], neither Ono or its Affiliates, nor Array or its
Controlled Affiliates, shall Commercialize in the Ono Territory: (i) a product that includes, as an
active pharmaceutical ingredient, an agent that is a [ * ] (other than Binimetinib), or (ii) a
product that includes, as an active pharmaceutical ingredient, an agent that is a [ * ] (other than
Encorafenib), or grant the right to a licensee or distributor to Commercialize in the Ono Territory
any of the above described products (each a "Competing Product"). In addition, in the event that
Array terminates this Agreement for Ono's breach pursuant to Section 13.3 during the [ * ], or Ono
exercises its right to terminate this Agreement "at will" pursuant to Section 13.2 during the
Initial Royalty Term, then neither Ono nor its Affiliates shall Commercialize a Competing Product or
grant the right to a licensee or distributor to Commercialize a Competing Product in the Ono
Territory prior to the [ * ] anniversary of the date such termination takes effect. If during the [
* ], Array Commercializes a Competing Product in the Ono Territory, the royalty payment period shall
terminate and Ono may continue to Commercialize the Product. If Ono Commercializes a Competing
Product in the Ono Territory during [ * ], Array may immediately terminate this Agreement. As used
herein, (i) "[ * ]" means a compound that [ * ], and (ii) "[ * ]" means a compound that [ * ]. For
the avoidance of doubt, [ * ] and [ * ] shall not include a [ * ].

ARTICLE IX PRODUCT MANUFACTURING AND SUPPLY

9.1 General.

(a) It is understood that Array procures supplies of Drug Substance and Drug Product (collectively,
the "Materials") from Subcontractors. Subject to the terms and conditions of this Agreement, Array
shall supply, or secure supply of, Ono's requirements for Materials for the Ono Territory pursuant
to one or more supply agreements to be entered into by the Parties as set forth below.

48
<!-- page 62 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(b) For purposes of this Article 9, "Drug Substance" shall mean active ingredient containing
Binimetinib or Encorafenib that is intended to furnish pharmacological activity or other direct
effect in the diagnosis, cure, mitigation, treatment, or prevention of disease or to affect the
structure or any function of the human body, but does not include intermediates used in the
synthesis of such ingredient; and "Drug Product" shall mean a finished dosage form containing Drug
Substance.

9.2 Related Substance Supply. Upon Ono's written request, Array agrees to supply to Ono from
available quantities in its possession (i.e., quantities not otherwise required by Array in its own
development and commercialization efforts) certain related materials (e.g., reference standard,
internal standard and impurities) necessary for Ono to conduct non-clinical studies, clinical
studies, including, but not limited to analytical test method development and/or validation, for
regulatory submissions or Commercialization in the Ono Territory, at Array's manufacturing cost or
the purchase price of Array from Array's Subcontractors. For clarity, the forgoing supply
obligations not apply to materials that are generally commercially available.

9.3 Clinical Supply. The Parties shall establish as soon as practicable following the Effective Date
procedures for the supply of Materials to Ono for use in performing Ono's Development activities
under Development Plan and any Joint Development Plans that may subsequently be agreed to by the
Parties, and the Parties shall enter into a clinical supply agreement and quality agreement within
three (3) months of the Effective Date pursuant to which:

(a) Array shall procure Materials on behalf of and as reasonably requested in writing by Ono, which
Materials will be supplied to Ono at transfer price equal to: (i) Array's manufacturing cost to the
extent that Array or its Affiliate(s) Manufacture such Materials itself, or (ii) the purchase price
paid by Array for such Materials to the extent that Array elects to have such Materials Manufactured
by a Subcontractor. The clinical supply agreement shall contain forecasting and ordering procedures
(including lead times), product specifications, delivery terms and other customary terms, which
terms shall in all cases be consistent with Array's contractual arrangements with its
Subcontractors;

(b) Array may place orders for Materials with its Subcontractors on Ono's behalf, or, subject to Ono
and the Subcontractors entering into an agreement or other arrangement therefor, Array shall arrange
with such Subcontractors for Ono to place such orders, for shipment to Ono and for Ono to pay for
such Materials directly to the particular supplier. Array shall not require Ono to place orders
directly with a Subcontractor if such Subcontractor is unwilling to fulfill such orders on terms as
favorable to Ono as the terms such Subcontractors have extended to Array.

(c) Array shall use Diligent Efforts to secure for Ono the inspection rights from Array's
Subcontractors for Materials. In the event Array is unable to secure such inspection rights from any
of its Subcontractors, Array agrees to secure such rights for itself and, if requested by Ono, Array

49
<!-- page 63 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

shall exercise such rights, at Ono's expense, on behalf of Ono and fully report the results thereof
to Ono.

9.4 Commercial Supply.

(a) Ono shall have the right (but not the obligation) to Manufacture and/or package, or engage a
Subcontractor to Manufacture, Ono's requirements of particular Materials (e.g., Ono's requirements
of Drug Substance or Ono's requirements of Drug Product of a particular Product) related to any
Product for the Ono Territory. Promptly following Ono's request, Array shall transfer, or cause to
be transferred, to Ono or such Subcontractor all Array's Know-How that is necessary, useful or
actually used for such Manufacture, packaging and/ or testing and release of Materials (and the cost
of such transfer of Array Know-How shall be borne by Ono), and shall make personnel of Array
reasonably available to assist Ono and/or its contractor in implementing the Array Know-How
necessary to Manufacture and/or control and release such Materials. Upon completion of the
technology transfer enabling Ono to Manufacture the Materials for the Ono Territory under the
Marketing Approval, Array's supply obligations under Sections 9.2 and 9.3(b) with respect to such
Materials shall terminate and Ono shall assume all supply-related liability with respect to such
Materials which it Manufactures or sources from Subcontractor.

(b) Without limiting the foregoing, Ono shall have the right to obtain from Array Ono's commercial
requirements of Materials for the Ono Territory. Upon Ono's request, the Parties shall enter into a
commercial supply agreement (a "Supply Agreement") and commercial quality agreement (a "Quality
Agreement") on commercially reasonable terms documenting the arrangement pursuant to which:

(i) Array shall supply Ono's reasonable requirements for Materials for the Ono Territory, which
Supply Agreement shall contain forecasting and ordering procedures (including lead times), product
specifications, delivery terms and other appropriate provisions mutually acceptable, and any
customary terms, which terms shall in all cases be consistent with Array's contractual arrangements
with its Subcontractors, and taking into account the regulatory requirements imposed on Ono as the
holder of the Marketing Approval.

(ii) Array has made arrangements with Novartis to transfer and validate at no cost to Ono all
technology reasonably necessary for the manufacturing and analytical testing of the Materials by [ *
] so that commercial quantities of Materials and can be supplied to Ono and released for the Ono
Territory;

(iii) Materials supplied by Array to Ono for commercial sale of the Products shall be charged to Ono
in an amount equal to (A) [ * ] of Array's manufacturing cost to the extent that Array or its

50
<!-- page 64 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

Affiliate(s) Manufacture such Materials itself, or (ii) [ * ] of the purchase price paid by Array
for such Materials to the extent that Array elects to have such Materials Manufactured by a
Subcontractor.

9.5 Limitation; Manufacturing by Ono. Array shall (a) cooperate fully with Ono to make available for
the benefit of Ono the benefits of Array's supply agreements and/or arrangements with its Third
Party suppliers of Materials, and (b) administer such agreements or arrangements diligently and
pursue its rights and remedies thereunder.

9.6 Companion Diagnostics. Array shall use Diligent Efforts to make available in the Ono Territory
any Companion Diagnostic developed by or on behalf of Array for use with one or more Products.

(a) Existing Clinical Studies. It is understood that Array is contracting or has contracted with
Third Parties to develop Companion Diagnostics (i) for use with Binimetinib for the treatment of
NRAS melanoma and (ii) for use with Binimetinib and Encorafenib for the treatment of BRAF melanoma.
The Parties shall discuss and agree on the strategy to ensure such Third Party contractor makes such
Companion Diagnostics available with respect to the Development, the registration and the
Commercialization of the relevant Product(s) in such Indications in countries where the relevant
Product will be Commercialized. In the event such Third Party contractor(s) fails to commercialize
or ceases commercialization of a Companion Diagnostic subject to this Section 9.6(a), Array shall
cooperate with Ono either to obtain from such Third Party contractor(s) quantities of such Companion
Diagnostic to supply Ono's reasonable requirements for the Ono Territory or enable Ono to conclude
appropriate agreements with such Third Party contractor for commercialization of such Companion
Diagnostics in the Ono Territory.

(b) Other. It is anticipated that the development of any necessary Companion Diagnostics for use
with the Products will be outsourced to Subcontractor(s) by Array. The Parties shall discuss and
agree on the strategy to ensure such Subcontractor makes such Companion Diagnostics available with
respect to the Development, the registration and the Commercialization of the relevant Product(s) in
the Ono Territory. In the event such Subcontractor(s) fails to commercialize or ceases
commercialization of a Companion Diagnostic subject to this Section 9.6(b), Array shall cooperate
with Ono either to obtain from such Third Party contractor(s) quantities of such Companion
Diagnostic to supply Ono's reasonable requirements at the cost charged by the Third Party contractor
to Array plus any other documented out-of-pocket costs and reasonable internal costs actually
incurred by Array directly in procuring such Companion Diagnostic or enable Ono to conclude
appropriate agreements with such Subcontractor for commercialization of such Companion Diagnostics
in the Ono Territory.

ARTICLE X CONFIDENTIALITY

51
<!-- page 65 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

10.1 Confidential Information. Except as expressly provided in this Agreement, the Parties agree
that the receiving Party shall not provide or otherwise disclose to any Third Party, and shall not
use for any purpose, any information furnished to it by the other Party hereto pursuant to this
Agreement (collectively, "Confidential Information"), without the prior written consent of the
disclosing Party. Notwithstanding the foregoing, Confidential Information shall not include
information that, in each case as demonstrated by written documentation:

(a) was already known to the receiving Party, other than under an obligation of confidentiality, at
the time of disclosure, or was developed by the receiving Party prior to disclosure by the
disclosing Party;

(b) was generally available to the public or otherwise part of the public domain at the time of its
disclosure to the receiving Party;

(c) became generally available to the public or otherwise part of the public domain after its
disclosure to the receiving Party, and other than through any act or omission of the receiving Party
in breach of this Agreement;

(d) was subsequently lawfully disclosed to the receiving Party on a non-confidential basis by a
person other than the disclosing Party, and who did not directly or indirectly receive such
information from disclosing Party; or

(e) is developed by the receiving Party without use of or reference to any information or materials
disclosed by the disclosing Party.

The Parties agree that Data generated in the course of performing any Joint Development Plan shall
be deemed Confidential Information of both Ono and Array.

10.2 Permitted Uses; Disclosures. Notwithstanding the provisions of Section 10.1 above and subject
to Sections 10.3 and 10.4 below, a receiving Party hereto may disclose the disclosing Party's
Confidential Information to: (a) in case of Array, its Affiliates, subcontractors, licensees, and
Third Party Partners, (b) in case of Ono, its Affiliates, Sublicensees and Subcontractors, and, (c)
in case of either Party, any other Third Parties to the extent such disclosure is reasonably
necessary to exercise the rights granted to it, or reserved by it, under this Agreement, performing
its obligations under this Agreement, prosecuting or defending litigation, complying with applicable
governmental Laws or regulations or the rules of any public stock exchange, submitting information
to tax or other Governmental Authorities or conducting Clinical Studies hereunder with respect to
the Product. If a receiving Party is required by Law, regulations or guidances to make any such
disclosure of the disclosing Party's Confidential Information, to the extent it may legally do so,
it will give notice to the disclosing Party of such disclosure as far in advance as is practicable
and, save to the extent inappropriate in the

52
<!-- page 66 -->
<!-- page 67 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

case of patent applications or otherwise, shall use Diligent Efforts to secure confidential
treatment of such Confidential Information of the disclosing Party prior to its disclosure (whether
through protective orders or otherwise). For any other disclosures of the other Party's Confidential
Information, including: (i) in case of Array, its Affiliates, subcontractors, licensees, and Third
Party Partners, (ii) in case of Ono, its Affiliates, Sublicensees and Subcontractors and (iii) in
case of either Party, other Third Parties as above, a Party shall ensure that the recipient thereof
is bound by a written confidentiality agreement as materially protective of such Confidential
Information and the disclosing Party as this Article 10, it being however understood that,
notwithstanding any other provision of this Agreement, in the case of disclosures made to academic
clinical trial sites and investigators, CROs, and other Third Parties involved in the Development of
the Product or Companion Diagnostic, the duration and of the confidentiality and non-use obligations
provided in a Party's agreement with such academic clinical trial sites and investigators, CROs,
and/or other Third Parties may be less than the duration and of the confidentiality and non-use
obligations in this Agreement so long as (A) they have a duration of at least five (5) years from
the date of first disclosure of such information to such institutions, investigators, CROs, and
other Third Parties, and (B) the receiving Party uses Diligent Efforts to limit the amount of
information disclosed to such institutions, investigators, CROs, and other Third Parties. For
clarity, it is understood that Array may use and disclose, in accordance with the foregoing, Ono
Know-How provided to Array by Ono, and that Ono may use and disclose, in accordance with the
foregoing, Array Know-How provided to Ono by Array in each case to the extent reasonably necessary
for the Development, Commercialization and/or Manufacturing of the Product for such Party's
Territory, subject to the requirements of Sections 10.3, 10.4, 10.5 and 10.7.

10.3 Confidential Terms. Each Party agrees not to disclose to any Third Party the terms of this
Agreement without the prior written consent of the other Party hereto, except each Party may
disclose the terms of this Agreement: (a) to advisors (including financial advisors, attorneys and
accountants), actual or potential acquisition partners or private investors, and others on a need to
know basis, in each case under appropriate confidentiality provisions substantially equivalent to
those in this Agreement; or (b) to the extent necessary to comply with applicable Laws and court
orders, including securities Laws, regulations or guidances; provided that in the case of paragraph
(b) the disclosing Party shall promptly notify the other Party and (other than in the case where
such disclosure is necessary, in the reasonable opinion of the disclosing Party's legal counsel, to
comply with securities Laws, regulations or guidances) allow the other Party a reasonable
opportunity to review the proposed disclosure and oppose with the body initiating the process and,
to the extent allowable by Law, to seek limitations on the portion of the Agreement that is required
to be disclosed. In addition, with respect of the required disclosure of a redacted version of this
Agreement pursuant to applicable securities Laws, regulations or guidance, the disclosing Party
shall provide the other Party with a draft of any disclosure it intends to issue at least fifteen
(15) Business Days in advance and take into account the other Party's reasonable comments.

53
<!-- page 68 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

10.4 Scientific Papers. Each Party through the JDRC or its designee shall provide to the other,
prior to submission for publication, a draft of any articles and papers containing Confidential
Information or concerning a Product which have been prepared by or on behalf of such Party (or by a
Clinical Study site contracted by such Party as sponsor of the relevant Clinical Study) (each a
"Scientific Paper") to be published in indexed medical and scientific journals and similar
publications ("Medical Journals"). Commencing with the receipt of such draft Scientific Paper, the
receiving Party shall have fifteen (15) Business Days to notify the sending Party of its
observations and suggestions with respect thereto (it being understood that, during such fifteen
(15) Business Days period, no submission for publication thereof shall take place) and the Parties
shall discuss these observations and suggestions. The Party proposing to publish such Scientific
Paper shall, in good faith, consider the comments made by the other Party, particularly if
disclosure may be prejudicial to the other Party's opportunity to obtain any Patent. The other Party
may require that the publication be suspended for a period of time not exceeding sixty (60) days if
a Patent may be filed using the Data or Know How covered in the proposed publication. Neither Party
will publish or present any Confidential Information of the other Party without such other Party's
prior written consent. The sending Party shall provide to the Receiving Party copies of any final
Scientific Paper accepted by a Medical Journal, within ten (10) Business Days after the approval
thereof (upon availability and distribution of such information assuming that providing such
information is acceptable taking into consideration the publishers' need to comply with any
healthcare compliance guidelines). To enable free exchange of copyrighted material between the
Parties, each Party agrees that it has or shall (i) obtain and maintain, at its own expense, an
annual copyright license or equivalent license from the copyright clearance center and (ii) list the
other Party as a collaborator in an agreement with the copyright clearance center if required by
such agreement.

10.5 Abstracts, Posters and Slide Decks. If a Party (or a Clinical Study site contracted by such
Party as sponsor of the relevant Clinical Study) intends to present findings with respect to a
Product at symposia or other meetings of healthcare professionals, or international and/or US,
European or Japanese congresses, conferences or meetings organized by a professional society or
organization (any such occasion, a "Scientific Meeting"), such Party through the JDRC or its
designee shall provide to the other Party, within ten (10) days prior to submission or presentation,
as the case may be, copies of (i) all abstracts that will be submitted for publication (ii) all
draft slide presentations for use in oral presentations, and (iii) all posters that will be
presented at such Scientific Meeting, in each case, concerning the Product which have been prepared
by or on behalf of one of the Parties, for submission or presentation. Commencing with the receipt
of any such abstract, draft slide presentation or poster, the receiving Party shall have ten (10)
days to inform the sending Party of its observations and suggestions with respect thereto (it being
understood that, during such review period, as applicable, no submission or presentation thereof
shall take place) and the Parties shall discuss these observations and suggestions. The Party
proposing to publish such an abstract or make such a presentation shall, in good faith, consider the
comments made by the other Party, particularly if disclosure may be prejudicial to

54
<!-- page 69 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

the other Party's opportunity to obtain a Patent. The other Party may require that the abstract or
presentation be suspended for a period of time not exceeding sixty (60) days if a Patent may be
filed using the Data or Know-How covered in the proposed abstract or presentation. A Party shall not
publish or present any Confidential Information of the other Party without such other Party's prior
written consent. The sending Party shall provide to the receiving Party copies of (i) all final
abstracts as soon as reasonably practicable after the approval of the Scientific Meeting, and (ii)
all final posters accepted for publication or to be presented five (5) Business Days prior to the
planned publication or presentation thereof (upon availability and distribution of such information
assuming that providing such information is acceptable taking into consideration the publishers'
need to comply with any healthcare compliance guidelines). The Parties shall use good faith and
reasonable efforts to provide the other Party with draft slide presentations in accordance with the
foregoing time periods.

10.6 Registries. Each Party shall be free to (a) register/publish the Clinical Studies they are
sponsoring with respect to the Product, and (b) disclose any Data from such registered Clinical
Trials concerning the Product, in each case on ClinicalTrials.gov or in similar clinical trial
registries; provided, however, that the Party proposing to make such disclosure shall have provided
the other Party a copy of the synopsis of the Clinical Study or a detailed description of any other
proposed disclosure, as applicable, that it proposes to have published in such clinical trial
registry at least thirty (30) days prior to such registration or disclosure and shall, in good
faith, consider the comments made by the other Party regarding the proposed registration or
disclosure and the protection of any intellectual property contained therein.

10.7 Publicity. Notwithstanding anything to the contrary in Section 10.3, the Parties have agreed on
a mutual press release to announce the execution of this Agreement, together with a corresponding
Question & Answer outline for use in responding to inquiries about the Agreement; thereafter, each
Party may each disclose to Third Parties the information contained in such press release and
Question & Answer outline without the need for further approval by the other Party. Each Party may
also desire to issue subsequent press releases or other public statements relating to this Agreement
or activities hereunder, including information which pertains to the development and regulatory
progress of any Product. Such disclosure may include, without limitation, the achievement of a
milestone and any payments received in respect of such milestone in accordance with applicable Laws,
as well as periodic updates regarding the status of the development and/or regulatory affairs
pertaining to such Product. The Parties agree to consult with each other reasonably and in good
faith with respect to the text and timing of such press releases or other disclosures and obtain the
approval of the other Party, no later than within five (5) Business Days prior to the issuance
thereof; provided, however, that a Party may not unreasonably withhold or delay consent to such
releases unless such release would adversely affect the rights or interests of such Party. After
release of a press release, each Party may each disclose to Third Parties the information contained
in such press release without the need for further approval by the other.

55
<!-- page 70 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

10.8 Prior Non-Disclosure Agreements. Upon execution of this Agreement, the terms of this Article 10
shall supersede any prior non-disclosure, secrecy or confidentiality agreement between the Parties,
including the Confidentiality Agreement between the Parties dated August 26, 2016. Any information
disclosed under such prior agreements shall be deemed disclosed under this Agreement.

ARTICLE XI

PATENT PROSECUTION AND ENFORCEMENT

11.1 Ownership of Inventions.

(a) Title to all know-how, inventions and other intellectual property made solely by Ono personnel
(or that of any Affiliate) in connection with this Agreement shall be owned by Ono (or its
respective Affiliate).

(b) Title to all know-how, inventions and other intellectual property made solely by Array personnel
(or that of any Affiliate) in connection with this Agreement shall be owned by Array (or its
respective Affiliate).

(c) Title to all know-how, inventions and other intellectual property made jointly by personnel of
Array (or that of any Affiliate) and Ono (or that of any Affiliate) in connection with this
Agreement shall be jointly owned by Array (or its respective Affiliate) and Ono (or its respective
Affiliate).

(d) Except to the extent any jointly-owned inventions or intellectual property are included in
subject matter licensed by one Party to the other Party under this Agreement, each Party may only
practice any such jointly-owned inventions or intellectual property for its own internal purposes,
and neither Party shall have the right to enforce, license, or assign such jointly- owned inventions
or intellectual property, without the prior written consent of the other Party. The filing,
prosecution and enforcement of Joint Patents is described in Section 11.2(b) below. With respect to
the filing, prosecution and enforcement of all other Patents directed to inventions made jointly by
personnel of Array (or that of any Affiliate) and Ono (or that of any Affiliate) in connection with
this Agreement that are not Joint Inventions relating to Binimetinib and Encorafenib and/or
Products, the Parties shall consult with one another and mutually agree upon such actions.

11.2 Prosecution and Maintenance of Array Patents and Joint Patents.

(a) Prosecution of Array Patents. As between Ono and Array, Array shall, have responsibility for the
filing, prosecution and maintenance of all Array Patents in the Ono Territory at Array's sole cost
and expense. Array agrees to keep Ono generally informed as to the

56
<!-- page 71 -->
<!-- page 72 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

course of such patent filing, prosecution, maintenance or other proceedings with respect to Array
Patents. Array shall provide Ono with copies of each draft patent application with respect to Array
Patents (in English, unless Japanese translation is available) to be filed as well as copies of each
office action received from the relevant patent offices in each country of the Ono Territory, in
each case with enough lead time where reasonably practicable, to enable Ono to review and comment on
such application or action; provided that Array shall have no obligation to delay any action or
response pending receipt of such comments or suggestions. Additionally, Array will provide Ono with
copies of the patent applications and responses to office actions it ultimately files with the
patent offices in the Ono Territory (in the original language, unless English translation is
available). If Array determines not to file within any jurisdiction requested by Ono, not to
continue the prosecution of, or not to continue to maintain or defend, any Array Patent in any
country in the Ono Territory, or if Array otherwise determines to abandon any such Array Patent,
Array shall promptly notify Ono of such determination sufficiently in advance to enable Ono to
undertake or continue the prosecution, maintenance or defense of such Array Patent without a loss of
rights, and Ono shall have the right to undertake or continue such prosecution, maintenance or
defense at its sole cost and expense. Ono shall hold all information disclosed to it under this
Section 11.2 as confidential.

(b) Prosecution of Joint Patents. Prior to preparation and filing of any Joint Patent, the Parties
shall consult with one another and mutually agree upon a lead Party to file, prosecute and maintain
such Joint Patent under the names of both Array and Ono. The Joint Patents shall be prepared and
prosecuted by a mutually acceptable patent law firm and allocation of costs for preparation, filing,
prosecution and maintenance shall be agreed by the Parties prior to preparation and filing of such
Joint Patent. Notwithstanding the foregoing, either Party may elect not to support the filing,
prosecution and maintenance of all or part of any Joint Patent in any country in the world.

(c) Patent Term Extensions. Array shall have the right, in consultation with Ono with respect to
Array Patents, and Ono shall have the right, with respect to any Patents owned or Controlled by Ono,
its Affiliates or Sublicensees related to the Product, to file all applications and take actions
necessary to obtain patent term extensions, or similar additional or supplemental protection, with
respect to the Product under statutes in any other country within the Ono Territory, which
extensions shall be owned by the Party that owns or Controls the underlying Patent. If such Party
declines to pursue such patent term extensions, then the other Party shall have the right on behalf
of such Party to file all such applications and take all such actions necessary to obtain such
patent term extensions (or similar additional or supplemental protection) with respect to the
Product. In each case, the Parties shall fully cooperate to obtain such extensions and additional
protection.

57
<!-- page 73 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

11.3 Enforcement.

(a) Enforcement Actions.

(i) In the event that Array or Ono becomes aware of actual or threatened infringement or
misappropriation of any Array Patent or Array Know-How in any country within the Ono Territory by
the Manufacture or sale or use of an unauthorized version of a Product ("Infringing Product"), then
such Party shall promptly notify the other Party in writing and the Parties shall consult with each
other with respect to the strategy in response to such Infringing Product. Array shall have the
first right, but not the obligation, to initiate proceedings or take other appropriate action in Ono
Territory, at its own expense, against any such Third Party. If Array does not initiate proceedings
or take other appropriate action within ninety (90) days of receipt of a request by Ono to initiate
an enforcement proceeding, or if a legal proceeding must be commenced prior to the end of such
ninety(90) day period to avoid a loss of rights, then no later than five (5) days prior to such
deadline, then Ono shall be entitled to initiate infringement proceedings or take other appropriate
action against an Infringing Product at its own expense. The Party conducting such action
("Enforcing Party") shall have full control over its conduct, including settlement thereof;
provided, however, that the Enforcing Party may not settle any such action, or make any admissions
or assert any position in such action, in a manner that would materially adversely affect the rights
or interests of the other Party, without the prior written consent of the other Party, which shall
not be unreasonably withheld or delayed. In any event, the Parties shall assist one another and
cooperate in any such litigation at Enforcing Party's reasonable request.

(ii) With respect to Infringing Products containing Binimetinib, Ono's rights under Section
11.3(a)(i) are subject to the rights previously granted to AstraZeneca AB ("AZ") pursuant to
Sections 8.3.1 and 8.3.3 of that certain Collaboration and License Agreement between Array and AZ,
effective as of December 18, 2003, as amended by that certain Amendment to Collaboration and License
Agreement, between Array and AZ, effective as of June 1, 2009 (collectively, the "AZ Agreement").
For the avoidance of doubt, the rights granted to or retained by Array pursuant to Sections 8.3.1
and 8.3.3 of the AZ Agreement shall, to the extent relating to Infringing Products containing
Binimetinib, be subject to this Agreement, including this Section 11.3. Any enforcement actions
initiated by AZ with respect to an Infringing Product shall be deemed initiated by Array for
purposes of Section 11.3(a)(i), and the costs and expenses incurred by Array in such enforcement
action shall include any costs and expenses reimbursed or required to be reimbursed by Array to AZ
in accordance with the AZ Agreement in such enforcement action. Additionally it is further
understood that notwithstanding anything to the contrary in this Agreement, the AZ Agreement, and
the rights granted to AZ thereunder, shall in no event constitute a breach of Sections 8.2 and 15.1.

(iii) With respect to the responsibility and allocation of costs for the enforcement of the Joint
Patents (i) against Third Party products that infringe the Joint Patents outside the Ono Territory,
or (ii)

58
<!-- page 74 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

against Third Party products in the Ono Territory that infringe the Joint Patents but that are not
"Infringing Products", the Parties shall discuss and agree at the time when the Parties consult with
respect to the strategy of such enforcement action in response to such Third Party infringement.

(b) Recovery.

(i) Array and Ono shall recover their respective actual out-of-pocket expenses (including attorneys'
fees), or equitable proportions thereof, associated with any litigation against infringers
undertaken pursuant to Section 11.3(a) (i) or (ii) above or settlement thereof from any resulting
recovery made by either Party. Any excess amount of such a recovery shall be allocated as follows:
(i) if Ono initiated such litigation, [ * ] of such excess amount shall be retained by Ono and [ * ]
by Array, and (ii) if Array initiated such litigation, Array shall retain [ * ] of such excess
amount and Ono shall obtain [ * ] of such excess amount, to the extent such excess amount represents
damages relating to Manufacture or sale or use of an Infringing Product in the Ono Territory.

(ii) With respect to enforcement actions against infringers relating to Joint Patents undertaken
pursuant to 11.3(a)(iii) above, the Parties shall discuss and agree in good faith at the time when
the Parties consult with respect to the strategy of such enforcement action in response to such
Third Party infringement.

(c) Cooperation. The Parties shall keep one another informed of the status of their respective
activities regarding any litigation or settlement thereof concerning the Array Patents or the Array
Know-How within the Ono Territory, and shall assist one another and cooperate in any such litigation
at the other's reasonable request (including joining as a party plaintiff to the extent necessary
and requested by the other Party).

11.4 Third Party Infringement Claims.

(a) If the production, sale or use of any Product in the Ono Territory pursuant to this Agreement
results in a claim, suit or proceeding alleging patent infringement against Array and/or Ono (or
their respective Affiliates, licensees or Sublicensees) (collectively, "Infringement Actions"), the
Party subject to such claim, suit or proceeding ("Subject Party") shall promptly notify the other
Party hereto in writing and shall discuss with the other Party the strategy for defending such
Infringement Actions but shall have the right to direct and control the defense thereof in its sole
discretion and at its own expense, with counsel of its choice; provided, however, the other Party
may participate in the defense and/or settlement thereof, at its own expense with counsel of its
choice. In any event, the Subject Party agrees to keep the other Party hereto reasonably informed of
all material developments in connection with any such Infringement Action. Ono agrees not to settle
such Infringement Action, or make any admissions or assert any position in such Infringement Action,
in a manner that would adversely affect the allegedly infringing Product

59
<!-- page 75 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

or the Manufacture, use or sale of such Product in any country of the world, without the prior
written consent of Array; and Array agrees not to settle such Infringement Action, or make any
admissions or assert any position in such Infringement Action, in a manner that would adversely
affect the allegedly infringing Product, or the Manufacture, use or sale of such Product, within the
Ono Territory, without the prior written consent of Ono, which shall not be unreasonably withheld or
delayed.

ARTICLE XII TRADEMARKS

12.1 Display.

(a) All packaging materials, labels and Marketing Materials for the Products shall display the
Product Trademarks in katakana or in other applicable language and no other product-specific
trademarks or branding.

(i) Products Containing Binimetinib. Where possible, Ono shall utilize "mektovi" as the Product
Trademark for Products containing Binimetinib. If the use of "mektovi" is not advisable for legal,
regulatory or other material reasons outside the Parties' reasonable control, in one or more
countries of the Ono Territory, Ono shall utilize "balimek" as such Product Trademark is such
country or countries. If neither "mektovi" not "balimek" can be used (or if it is not advisable to
use them) for legal, regulatory or other material reasons outside the Parties' reasonable control,
in one or more countries of the Ono Territory, Ono may select an alternative Product Trademark
reasonably acceptable to Array for use in such country or countries, with any disputes being
referred to the JCC for resolution, it being understood that in resolving any such dispute the JCC
shall give preference to the creation of a single brand for Products containing Binimetinib in
countries where neither "balimek" or "mektovi" can be used.

(ii) Products Containing Encorafenib. Where possible, Ono shall utilize "braftovi" as the Product
Trademark for Products containing Encorafenib. If the use of "braftovi" is not advisable for legal,
regulatory or other material reasons outside the Parties' reasonable control, in one or more
countries of the Ono Territory, Ono may select an alternative Product Trademark reasonably
acceptable to Array for use in such country or countries, with any disputes being referred to the
JCC for resolution, it being understood that in resolving any such dispute the JCC shall give
preference to the creation of a single brand for Products containing Encorafenib in countries where
"braftovi" cannot be used.

(b) Each Product shall be sold in the Ono Territory under the trade name Ono or other trade name
chosen by Ono and the logo of Ono; provided, however that to the extent permissible under applicable
Law within the Ono Territory, such packaging materials, labels and Marketing Materials shall also
display the trade name of Array in reasonable size and prominence,

60
<!-- page 76 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

as reasonably approved by Array. The trademarks of Ono, trade dress, style of packaging and the like
with respect to the Product in the Ono Territory may be determined by Ono in a manner that is
consistent with Ono's standard trade dress and style, but shall be subject to the approval by the
JCC to ensure the same are consistent with Array's global trademark guidelines.

12.2 Assignment. Subject to the terms and conditions of this Agreement, following registration of
the Product Trademark(s) by Array in the Ono Territory pursuant to Section 12.3 below, Array shall
assign, and shall cause its Affiliates to assign, to Ono all rights to the Product Trademark(s) so
registered in the Ono Territory at Ono's cost and expense, in each case solely for the purpose of
Commercializing the Products in the Ono Territory in accordance with this Agreement. Ono shall be
responsible for maintenance of such Product Trademark(s) at its cost and expense in the Ono
Territory.

12.3 Registration of Trademarks and Trade Dress.

(a) Products Containing Binimetinib. If the Product Trademark for Products containing Binimetinib is
balimek or mektovi, Array (or its designee) shall use Diligent Efforts to file and register at
Array's expense and in its own name (to the extent permitted by applicable Law), appropriate
registrations for such Product Trademarks in the Ono Territory. If, however, neither balimek nor
mektovi is available or desirable in a given country or countries, Ono agrees to file and register,
at Ono's expense and name, appropriate registrations for an alternative Product Trademark (selected
in accordance with Section 12.1(a)(i)) in such country or countries of the Ono Territory. As between
the Parties, Ono shall have the sole right to file at its expense and in its own name, appropriate
registrations for the trade dress utilized with the Product in the Ono Territory.

(b) Products Containing Encorafenib. If the Product Trademark for Products containing Encorafenib is
braftovi, Array (or its designee) shall use Diligent Efforts to file and register at Array's expense
and in its own name (to the extent permitted by applicable Law), appropriate registrations for such
Product Trademarks in the Ono Territory. If, however, braftovi is not available or desirable in a
given country or countries, Ono agrees to file and register, at Ono's expense and name, appropriate
registrations for an alternative Product Trademark (selected in accordance with Section 12.1(a)(ii))
in such country or countries of the Ono Territory. As between the Parties, Ono shall have the sole
right to file at its expense and in its own name, appropriate registrations for the trade dress
utilized with the Product in the Ono Territory.

12.4 Approval of Packaging and Promotional Materials. The Parties agree that the quality of the
Products packaging shall be consistent with the highest standards of quality in the pharmaceuticals
industry.

(a) Mektovi/Balimek/Array. Without limiting Section 5.1(c) above, to the extent necessary to
preserve Array's legal rights in the balimek or mektovi Product Trademarks,

61
<!-- page 77 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

Ono shall submit representative Marketing Materials, packaging and Product displaying the balimek or
mektovi Product Trademarks and/or Array's trade name to Array for Array's review and approval (such
approval shall not be unreasonably withheld or delayed) prior to the first use of such Marketing
Materials, packaging or Product and prior to any subsequent change or addition to such Marketing
Materials, packaging or Product; provided that if Array has not responded within ten (10) Business
Days after the submission of such Marketing Materials, packaging or Product, Array's approval will
be deemed to have been received.

(b) Braftovi/Array. Without limiting Section 5.1(c) above, to the extent necessary to preserve
Array's legal rights in the braftovi Product Trademark, Ono shall submit representative Marketing
Materials, packaging and Product displaying the braftovi Product Trademark and/or Array's trade name
to Array for Array's review and approval (such approval shall not be unreasonably withheld or
delayed) prior to the first use of such Marketing Materials, packaging or Product and prior to any
subsequent change or addition to such Marketing Materials, packaging or Product; provided that if
Array has not responded within ten (10) Business Days after the submission of such Marketing
Materials, packaging or Product, Array's approval will be deemed to have been received.

(c) Other. With respect to all Product Trademarks other than balimek, mektovi or braftovi, Ono
shall, and shall cause its respective Affiliates and Sublicensees to, comply with trademark style
and usage standards approved by Array from time to time in connection with use of the Product
Trademark(s). Ono shall, and shall cause its Affiliates to, at its own expense, submit
representative Marketing Materials, packaging and Product displaying such Product Trademarks to
Array for approval, which approval shall not be unreasonably withheld or delayed. In the event that
Array reasonably objects to a proposed usage of the Product Trademark(s), it shall give written
notice of such objection to Ono within sixty (60) days of receipt of such sample, specifying the way
in which such usage of its Product Trademark(s) fails to meet the style, usage or quality standards
for the Product or Product Trademark set forth in the first two sentences of this Section 12.4(c).
If Ono or its Affiliate wishes to use such representative Marketing Materials, it must remedy the
failure and submit further samples to Array's for approval.

12.5 Enforcement.

(a) If either Party becomes aware of any actual or threatened infringement of any Product Trademark
in the Ono Territory, such Party shall promptly notify the other Party in writing. Ono shall, at its
own expense, initiate infringement proceedings or take other appropriate actions against an
infringement of any Product Trademark in the Ono Territory and/or to defend any actions or
proceedings involving the Product Trademarks in the Ono Territory, as the case may be. Ono shall
have full control over the conduct of such action, including settlement thereof;

62
<!-- page 78 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

provided, however, Ono may not settle any such action, or make any admissions or assert any position
in such action, in a manner that would materially adversely affect the Product Trademarks in the Ono
Territory nor the rights or interests of Array, without the prior written consent of Array, which
shall not be unreasonably withheld or delayed. In any event, the Ono shall keep Array informed of
the status of its activities regarding any litigation in the Ono Territory involving a Product
Trademark or settlement thereof and Array shall assist Ono and cooperate in any such litigation at
Ono's reasonable request and expense.

(b) Ono and Array shall recover their respective actual out-of-pocket expenses, or proportionate
percentages thereof, associated with any litigation against infringers undertaken pursuant to this
Section 12.5 or settlement thereof from any resulting recovery made by either Party. Any excess
amount of such a recovery shall be [ * ] between Ono and Array, to the extent such recovery
represents damages pertaining to the infringement of a Product Trademark in the Ono Territory.

12.6 Domain Names. Array shall own rights to, and shall be responsible, at its own expense, for
registering and maintaining, the Internet domain names listed on Exhibit 12.6 (each of the
foregoing, a "Domain Name") and agrees to grant, and hereby grants to Ono a royalty-free, fully
paid-up exclusive license to use those particular Domain Names which Ono elects to use (and actually
uses) in connection with Ono's commercialization of the Product in the Ono Territory in accordance
with this Agreement. In the event Ono would like to use an available Internet domain name including
the balimek, mektovi or braftovi, or Product Trademarks not previously registered to Array, Array
grants Ono its consent to register and maintain such Internet domain names in Ono's name and at
Ono's expense, provided that upon termination (but not expiration) of this Agreement, Ono shall
transfer full and exclusive ownership and control of such Internet domain names to Array, or if
Array so requests, promptly withdraw registration of such Internet domain name(s), in each case at
Ono's sole cost and expense. Each Party shall own rights to any Internet domain names incorporating
the Product Trademark(s) owned by such Party under Section 12.1 or any variation or part of such
Product Trademark(s) as its URL address or any part of such address, and agrees to grant, and hereby
grants to the other Party a royalty-free, fully paid-up exclusive license to use those particular
Internet domain names which the grantee Party elects to use (and actually uses) in connection with
the grantee Party's commercialization of the applicable Product in the grantee Party's Territory in
accordance with this Agreement. The use rights granted to the Internet domain names under this
Section 12.6 are limited to the grantee Party's Territory, and neither Party shall actively make or
authorize any use, direct or otherwise, of its Internet domain names outside its respective
territory. Each Party acknowledges and agrees that the Internet domain names and the goodwill
pertaining to such Internet domain names shall belong exclusively to the Party owning such Internet
domain name, who shall be registered as "Registrant" or "Owner" and as "Administrative Contact" of
the relevant domain name. The Parties agree that any use of a Product Trademark in any content
describing or referring to a Product: (i) on any internet page or web site operated by Array in

63
<!-- page 79 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

the Array Territory shall be in the sole control of Array, and (ii) on any internet page or web site
operated by Ono in the Ono Territory, subject to the terms of this Agreement, shall be in the sole
control of Ono, and therefore Ono and Array, respectively, shall be responsible for any damage
caused to the Product Trademarks as a result of their use of the Product Trademarks on any internet
page or web site in their respective territories.

ARTICLE XIII

TERM AND TERMINATION

13.1 Term. This Agreement shall commence on the Effective Date and, unless terminated earlier
pursuant to this Article 13, shall continue in full force and effect, on a Product-by-Product and
country-by-country basis until the Secondary Royalty Term with respect to such Product expires, at
which time this Agreement shall expire in its entirety with respect to such Product in such country.
Upon expiration of this Agreement, the licenses granted to Ono under Section 2.1 shall become
non-exclusive, fully paid- up, irrevocable, perpetual, royalty free licenses, with sublicensing
rights, to Develop, Manufacture, and/or Commercialize the Products in the Ono Territory. From and
after the expiration of this Agreement, Ono shall have the exclusive, fully paid up, royalty- free
right to use (i) Product Trademarks assigned to Ono under Section 12.2, and (ii) those Domain Names
licensed to Ono under Section 12.6, in each case solely for purposes of, and to the extent
necessary, for Ono to continue to Commercialize the Products in the Field in the Ono Territory.

13.2 Termination by Ono without Cause. Commencing on the later of (i) [ * ] of the First Commercial
Sale of the Binimetinib Product in the Ono Territory, or (ii) [ * ] of the First Commercial Sale of
the Encorafenib Product in the Ono Territory, Ono shall have the right to terminate this Agreement,
for any reasons by giving [ * ] advance written notice to Array which shall be accompanied by the
rationale for such termination.

13.3 Termination for Material Breach. Either Party may terminate this Agreement in its entirety in
the event the other Party shall have materially breached or defaulted in the performance of any of
its material obligations hereunder, and such default shall have continued for ninety (90) days (or
with respect to any breach of any payment obligations, for sixty (60) days) after written notice
thereof was provided to the breaching Party by the non‑breaching Party. Any such termination shall
become effective at the end of such ninety (90) day period (or sixty (60) day period with respect to
any failure to pay) unless the breaching Party has cured any such breach or default prior to the
expiration of the applicable cure period. Exercising the right to terminate this Agreement by a
Party pursuant to this Section 13.3 shall not preclude a claim or a compensation for damages on the
other Party.

13.4 Termination for Bankruptcy. Either Party shall have the right to terminate this Agreement upon
written notice to the other Party: (a) if such other Party is declared insolvent or bankrupt by a

64
<!-- page 80 -->
<!-- page 81 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

court of competent jurisdiction; (b) if a voluntary or involuntary petition in bankruptcy is filed
in any court of competent jurisdiction against such other Party and such petition is not dismissed
within ninety (90) days after filing; (c) if such other Party shall make or execute an assignment of
substantially all of its assets for the benefit of creditors; or (d) substantially all of the assets
of such other Party are seized or attached and not released within ninety (90) days thereafter.

13.5 Termination for Safety Reasons and Efficacy Reason.

(a) Ono shall have the right to terminate this Agreement, on a Product-by-Product basis, for Safety
Reasons upon thirty (30) days written notice to Array or within a shorter period if required under
applicable Law, but only after consulting with Array and obtaining Array's agreement with Ono's
assessment with respect to such Safety Reasons (or as provided for below, the agreement of the
Experts). Ono shall have the right to terminate this Agreement for Efficacy Reasons upon one hundred
and eighty (180) days written notice to Array.

(b) If Array disagrees with Ono's assessment with respect to Safety Reasons, such matter shall be
resolved in accordance with the procedures set forth in Section 17.2, which shall apply mutatis
mutandis, which Experts shall determine whether the Safety Reasons are justified and are unlikely to
be reversed, within a reasonable period of time with a commercially reasonable level of investment.
The opinion of the majority of the Experts shall be finally binding on the Parties.

(c) "Safety Reasons" shall mean that, based upon all relevant scientific data, there are safety and
public health issues relating to the Product such that the medical benefit/risk ratio of such
Product is sufficiently unfavorable as to materially compromise the welfare of patients so that the
use in patients is no longer justifiable and that such issues are unlikely to be reversed within a
reasonable period of time with a commercially reasonable level of investment.

(d) "Efficacy Reasons" shall mean that either (i) there is no efficacy or lower efficacy of the
Products in comparison with control arm in COLUMBUS Clinical Study as well as BEACON Clinical Study
(neither triplet therapy nor doublet therapy demonstrates statistically significant efficacy in
comparison with control arm), or (ii) as of the fifth anniversary of the Effective Date, neither
BRAF-mutant Melanoma and Marketing Approval nor BRAF-mutant colorectal cancer have received
Marketing Approval from MHLW.

ARTICLE XIV EFFECT OF TERMINATION

65
<!-- page 82 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

14.1 Accrued Obligations. The expiration or termination of this Agreement for any reason shall not
release either Party from any liability which, at the time of such expiration or termination, has
already accrued to the other Party or which is attributable to a period prior to such expiration or
termination, nor will any termination of this Agreement preclude either Party from pursuing all
rights and remedies it may have under this Agreement, or at law or in equity, with respect to breach
of this Agreement.

14.2 Rights on Termination of Agreement. In case of termination of this Agreement by either Party,
this Section 14.2 shall apply:

(a) Wind-down.

(i) Development. In the event Ono is the sponsor of or conducting any on-going Clinical Studies of
the Product following the date a notice of termination has been issued by Array or Ono, to the
extent requested by Array, Ono agrees to: (A) continue to sponsor or conduct any such Clinical
Studies in normal course if such Clinical Studies can be completed (i) within [ * ] following the
effective date of termination in the case of a termination by Ono pursuant to Section 13.2, or (ii)
within [ * ] following the effective date of termination in the case of any other termination of
this Agreement by either Party, or (B) promptly transition to Array or its designee such sponsorship
or Clinical Studies (or portions thereof) provided that in such case, Array shall take over such
studies (i) within [ * ] following the effective date of termination in the case of a termination by
Ono pursuant to Section 13.2, or (ii) within [ * ] following the effective date of termination in
the case of any other termination of this Agreement by either Party. In addition, in the event Ono
is conducting any on-going pre-clinical studies and/or formulation studies (e.g., stability studies)
of the Product, Ono agrees to promptly transition to Array or its designee such pre-clinical studies
and/or formulation studies to the extent such transfer is reasonably possible. In the case of a
termination by Array pursuant to Section 8.2, 13.3 or 13.4 or by Ono pursuant to Section 13.2, Ono
shall be responsible for (1) costs of carrying out the transfers described in this Section
14.2(a)(i), and (2) all costs of on-going Clinical Studies through the termination of the wind-down
period (including for clarity, the costs incurred by Array in carrying out any transferred Clinical
Studies through the termination of the wind-down period). In all other cases Array shall be
responsible for such costs. Notwithstanding the foregoing, if Ono terminates this Agreement with
respect to a Product pursuant to Section 13.5(a), Ono shall not be obligated to continue to sponsor
or conduct any Clinical Studies with respect to such Product under Section 14.2(a)(i)(A) above.

(ii) Commercialization. To avoid disruption in the availability of Product to patients, if this
Agreement is terminated after the First Commercial Sale of the Product in the Ono Territory other
than pursuant to Section 13.5, then to the extent requested by Array, Ono, its Affiliates and its
Sublicensees shall continue to distribute (but shall not be obligated to market or promote) the
Product, in accordance

66
<!-- page 83 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

with the terms and conditions of this Agreement, in each country of the Ono Territory for which
Marketing Approval therefor has been obtained, taking into account applicable issues, if any, for
patient safety or the requirements of a Regulatory Authority within the Ono Territory, until the
date on which Array notifies Ono in writing that Array has secured an alternative distributor or
licensee for the Product in such country, but in no event more for than (A) [ * ] after the date of
such notice of termination of this Agreement by Ono pursuant to Section 13.2 or by Array pursuant to
Section 13.4 or (B) [ * ] after the date of such notice of termination of this Agreement by Array
pursuant to Sections 8.2 or 13.3 or by Ono pursuant to Section 13.3 or 13.4 ("Wind- down Period");
provided that Ono, its Affiliates and its Sublicensees shall cease such activities, or any portion
thereof, in a given country upon sixty (60) days' notice by Array requesting that such activities
(or portion thereof) be ceased. Notwithstanding any other provision of this Agreement, during the
Wind-down Period, Ono's and its Affiliates' and, subject to Section 14.2(a)(viii) below,
Sublicensees' rights with respect to the Product (including the Product Trademarks) in the Ono
Territory shall be non- exclusive and, without limiting the foregoing, Array shall have the right to
engage one or more other distributor(s) and/or licensee(s) of the Product in all or part of the Ono
Territory. Any Product sold or disposed by Ono, its Affiliates and, subject to Section 14.2(a)
(viii) below, its Sublicensees in the Ono Territory during the Wind-down Period shall be subject to
royalties under Section 6.3 above, provided that in the event of a termination by Ono pursuant to
13.3 or 13.4, if Array requests that Ono continue distributing the Product beyond the first
anniversary of the date on which such notice of termination was given, then, the royalties owed by
Ono under Section 6.3 above with respect to sales of Product occurring during the remainder of the
Wind-down Period shall be reduced by [ * ] of the otherwise applicable royalty rate, provided
further that in no event shall such royalties be reduced to less than the royalty due to [ * ]
pursuant to that certain agreement dated [ * ]. Within thirty (30) days of expiration of the Wind-
down Period, Ono shall notify Array of any quantity of the Product remaining in Ono's inventory and
Array shall have the option, upon notice to Ono, to purchase any such quantities of unlabeled and
unpackaged Product from Ono at the price equal to the price paid by Ono for such quantities of
unlabeled and unpackaged Product manufactured by a Third Party manufacturer or, to the extent Ono
manufactured such quantities of unlabeled and unpackaged Products itself, the cost of direct
materials and direct labor for such unlabeled and unpackaged Products.

(iii) Assignment of Regulatory Filings and Marketing Approvals. Ono shall assign (or cause to be
assigned) to Array or its designee, at Array's cost, except in case of termination by Array pursuant
to Section 13.3 or 13.4 or by Ono pursuant to Section 13.2, in which case the expenses will be borne
by Ono, (or to the extent not so assignable, Ono shall take all reasonable actions to make available
to Array or its designee the benefits of) all Regulatory Filings for the Product in the Ono
Territory, including any such Regulatory Filings made or owned by its Affiliates and/or
Sublicensees. In each case, unless otherwise required by any applicable Law or regulation or
requested by Array, the foregoing assignment (or availability) shall be made within a period of time
agreed upon and consistent

67
<!-- page 84 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

with Ono's obligations during the Wind Down Period. In addition, Ono shall promptly provide to Array
a copy of all Data and Ono Know-How pertaining to the Product in the Ono Territory to the extent not
previously provided to Array and Array shall have a fully-paid-up right to use and disclose all Data
and Ono Know-How pertaining to the Product following termination of this Agreement, except in case
of termination by Ono pursuant to Section 13.3 or 13.4, in which case the Section 14.2(a)(ix) shall
apply. In addition, all such Data and Ono Know-How, to the extent solely related to the Product,
shall be deemed Confidential Information of Array and not Confidential Information of Ono (and will
not be subject to the exclusions under Sections 10.1(a) or (e) above).

(iv) Transition. Each Party shall use Diligent Efforts to cooperate with the other and/or its
designee to effect a smooth and orderly transition in the Development, sale and ongoing marketing,
promotion and commercialization of the Product in the Ono Territory during the Wind-down Period and
to conduct in an expeditious manner any activities to be conducted under this Section 14.2. Without
limiting the foregoing, Ono shall, upon written request from Array, provide Array copies of customer
lists, customer data and other customer information relating to the Product in the Ono Territory
(except as prevented by the applicable Laws and regulations relating to the protection of personal
information), which Array shall have the right to use and disclose. For clarity, "customers" means
prescribers and individuals and entities with the ability to influence use of the Product (e.g.
individuals responsible for hospital formularies and/or making purchasing decisions on behalf of the
hospital) that are called on by Ono representatives when detailing the Product.

(v) Licenses. Effective as of the date of expiration, Ono shall grant to Array a non-exclusive,
worldwide, royalty-free license, with the right to grant sublicenses, (A) under any Improvements,
and (B) under any other Patents owned or Controlled by Ono related to any Product(s) (including
without limitation, Ono's interest in any Joint Patents) for the purposes of making, using,
developing, importing, selling, distributing, marketing and promoting the Product(s) in the form
they exist as of the time the Agreement is terminated, Notwithstanding the foregoing, in the event
of a termination by Ono pursuant Section 13.3 or 13.4, Section 14.2(a)(ix) shall apply.

(vi) Return of Materials. Within ninety (90) days after the end of the Wind-down Period, upon
request by Array, Ono shall either deliver to Array or destroy all tangible items comprising,
bearing or containing trademarks of Array (including the Product Trademarks), trade names, patents,
copyrights, designs, drawings, formulas or other Data, photographs, samples, literature, sales and
promotional aids ("Product Materials") and Confidential Information of Array, that is in Ono's
possession, subject to Ono's right to keep one (1) copy for archiving purposes. Effective upon the
end of the Wind-down Period, Ono shall cease to use all trademarks and trade names of Array
(including the Product Trademarks) in the Ono Territory, and all rights granted to Ono hereunder
with respect to the Product in the Ono Territory shall terminate.

68
<!-- page 85 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(vii) Marks and Domains. Effective upon the effective date of termination, Ono hereby assigns and
shall cause to be assigned to Array all worldwide rights in and to (i) any Product Trademarks
specific to one or more Products that Ono or any of its Affiliates used in connection with
Product(s), and (ii) all Internet domain names incorporating the applicable Product Trademark(s) or
any variation or part of such Product Trademark(s) as its URL address or any part of such address,
for domains outside the Array Territory. It is understood that such assignment shall not include the
name of Ono or any of its Affiliates, nor the corporate logo, service mark, or trademark for Ono or
for any of its Affiliates as a corporate entity.

(viii) Sublicensees. Any contracts with Sublicensees in the Ono Territory engaged by Ono shall, at
the request of Array in its discretion, be assigned to Array to the furthest extent possible;
provided that such assignment is accepted by the Sublicensee(s) in any country or countries within
the Ono Territory. In the event such assignment is not requested by Array or is not accepted by such
Sublicensee(s), then the rights of such Sublicensees with respect to the Product in relevant country
or countries within the Ono Territory shall terminate upon the termination of Ono's rights with
respect to the Ono Territory. Subject to Ono's Affiliates' and Sublicensees' obligations under
Section 14.2(a)(ii) above, Ono shall ensure that its Affiliates and such Sublicensees (if not
assigned to Array pursuant to this Section 14.2(a)(viii)) shall transition all rights in and to the
Product back to Array in the manner set forth in this Section 14.2 as if such Affiliate or
Sublicensee were named herein.

(ix) Following a termination by Ono pursuant to Section 13.3 or 13.4, in the event that Array wishes
to have Ono: (A) assign to Array the Regulatory Filings for the Product in the Ono Territory and
provide to Array a copy of all Data and Ono Know-How pertaining to the Product as described in
14.2(a)(iii) above, and/or (B) grant to Array a non-exclusive license under any Improvements, and/or
under any other Patents owned or Controlled by Ono related to any Product(s) (including without
limitation, Ono's interest in any Joint Patents) as described in 14.2(a)(v) above, Array shall so
notify Ono and Ono shall make such rights for consideration consistent with then-prevailing market
conditions, on customary terms and conditions to be negotiated in good faith. In the event that the
Parties cannot finalize such an agreement within sixty (60) days of commencing negotiations with
respect thereto, the agreement shall be referred for resolution pursuant to Section 17.3 applied
mutatis mutandis to such agreement.

14.3 Liquidated Damages. In the event that Array (a) [ * ] during [ * ], or (b) intentionally
conceals or falsifies a material result and/or material item of data concerning the safety or
efficacy of the Product, which concealment or falsification (i) is undertaken to induce Ono to not
terminate this Agreement and (ii) results in a substantial reduction to the value of the Product in
the Ono Territory, then, as an alternative to its right to terminate this Agreement pursuant to
Section 13.3 above, Ono may in its discretion elect to continue this Agreement, in which case (A)
Ono shall be relieved of its due diligence obligations under this Agreement; and (B) as liquidated
damages for the breaches described

69
<!-- page 86 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

in (a) or (b) above, the otherwise applicable royalty rate with respect to Products shall thereafter
be [ * ] for the [ * ].

14.4 No Renewal, Extension or Waiver. Acceptance of any order from, or sale or license of, any
Product to Ono after the notice or effective date of expiration or termination of this Agreement in
its entirety shall not be construed as a renewal or extension hereof, or as a waiver of expiration
or termination of this Agreement in its entirety.

14.5 Survival. Upon the expiration or termination of this Agreement, all rights and obligations of
the Parties under this Agreement shall terminate except those described in the following Articles
and Sections: Articles I (Definitions), XIV (Effect of Termination), XVI (Indemnification; Recalls)
and XVII (Dispute Resolution), and Sections 2.7, 4.10, 4.11 (to the extent required by applicable
Law), Sections 6.2-6.5 and 7.1-7.3 (with respect to milestone payments and royalty payments accruing
prior to, but not yet paid as of, the effective date of termination); 7.4 (for a period of three (3)
years from the end of the calendar quarter in which termination or expiration occurs, or if later,
(3) years after the last relevant payment was made under this Agreement), Sections 10.1-10.3, 10.4
(to the extent any Confidential Information of Ono would be included in any publication of Data
pursuant to Section 10.4), 10.5 (to the extent any Confidential Information of Ono would be included
in any abstract, slide presentation or poster pursuant to Section 10.5) ; 11.1(a)-(c), 11.2(b), 11.3
(with respect to any enforcement actions being prosecuted by Ono as of the effective date of
termination, but only until such enforcement action can be assumed by Array), 12.6 (with respect to
Ono's obligation to transfer or withdraw registration of Internet domain names registered by Ono
pursuant to this section and Array's ownership and other rights with respect to the Domain Names),
18.3, 18.7, 18.8, 18.13 and 18.14 and, in addition, any other provisions of this Agreement shall
survive solely for so long as, and to the extent, reasonably necessary to enable Ono to perform its
obligations under Section 14.2, and to the extent that any Product is sold during the period defined
in Section 14.2(a)(ii) above, Sections 6.2-6.4 and 7.1-7.3 shall apply to such sales and Array's
information, audit an inspection rights under Sections 4.7(b) and 4.9 shall continue to apply.

14.6 Rights in Bankruptcy. The Parties acknowledge and agree that all rights and licenses granted
under or pursuant to this Agreement to Ono or Array are, and shall otherwise be deemed to be, for
purposes of Section 365(n) of the United States Bankruptcy Code and other similar foreign Laws,
licenses of rights to "intellectual property" as defined under Section 101 of the United States
Bankruptcy Code or other similar foreign Laws. The Parties agree that the Parties shall retain and
may fully exercise all of their rights and elections under the United States Bankruptcy Code,
Article 53 and 56 of the Japanese bankruptcy Law (or any comparable provision of Japanese Laws
applicable to bankruptcies or insolvencies), and other similar foreign Laws. The Parties further
agree that, in the event of the commencement of a bankruptcy proceeding by or against a Party under
the United States Bankruptcy Code, the non debtor Party shall be entitled to a complete duplicate of
(or complete access to, as

70
<!-- page 87 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

appropriate) any such intellectual property and all embodiments of such intellectual property and
the same, which, if not already in the non debtor Party's possession, shall be promptly delivered to
it (a) upon any such commencement of a bankruptcy proceeding upon the non debtor Party's written
request therefor, unless the debtor Party continues to perform all of its obligations under this
Agreement or (b) if not delivered under clause (a) above, following the rejection of this Agreement
by or on behalf of the debtor Party upon written request therefor by the non debtor Party.
Similarly, the Parties agree that, to the maximum extent permitted by applicable Law, in any
bankruptcy proceeding by or against a Party under the Japanese bankruptcy Law, the non debtor Party
shall retain the licenses and other rights granted to it under Article II hereof and may continue to
exercise such rights in accordance with the terms and conditions of this Agreement, irrespective of
whether or not the debtor Party elects to rescind this Agreement pursuant to Article 53 of the
Japanese bankruptcy Law (or any comparable provision of other Japanese Laws applicable to
bankruptcies or insolvencies).

ARTICLE XV

REPRESENTATIONS, WARRANTIES AND COVENANTS

15.1 Mutual Covenants, Representations and Warranties. Each Party covenants, represents and warrants
to the other Party that, as of the Effective Date:

(a) it is a corporation duly organized, validly existing and is in good standing under the Laws of
the jurisdiction in which it is incorporated, is qualified to do business and is in good standing as
a foreign corporation in each jurisdiction in which the conduct of its business or the ownership of
its properties requires such qualification and failure to have such would prevent the Party from
performing its obligations under this Agreement;

(b) this Agreement is a legal and valid obligation binding upon the Party and enforceable in
accordance with its terms.

(c) the execution, delivery and performance of this Agreement by the Party has been duly authorized
by all necessary corporate action and does not and will not: (i) require the consent or approval of
the Party's stockholders; (ii) to its knowledge, violate any Law, rule, regulation, order, writ,
judgment, decree, determination or award of any court, governmental body or administrative or other
agency having jurisdiction over the Party; nor (iii) conflict with, or constitute a default under,
any agreement, instrument or understanding, oral or written, to which it is a party or by which it
is bound;

(d) it has the full right and authority to grant the rights and licenses granted herein;

71
<!-- page 88 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(e) all necessary consents, approvals and authorizations of all Regulatory Authorities, other
Governmental Authorities and other persons or entities required to be obtained by it in order to
enter into this Agreement have been obtained;

(f) it, its subsidiaries, and its Affiliates are in compliance with, and at all times during the
term of this Agreement shall remain in compliance with, all applicable antibribery or anticorruption
Laws. Neither such Party nor any of its subsidiaries, or Affiliates has, or will, authorize, offer,
promise, or make payments or otherwise provide anything of value directly or indirectly to: (i) an
executive, official, employee or agent of a government, governmental department, agency or
instrumentality, (ii) a director, officer, employee or agent of a wholly or partially
government-owned or controlled entity, (iii) a political party or official thereof, or candidate for
political office, or (iv) an executive, official, employee or agent of a public international
organization (e.g., the International Monetary Fund or the World Bank) ("Government Official") for
purposes of (A) (i) improperly influencing any act or decision of such Government Official in his or
her official capacity, (ii) inducing such Government Official to do or omit to do any act in
violation of the lawful duty of such Government Official, or (iii) securing any improper advantage;
or (B) inducing such Government Official improperly to use his or her influence in order to assist
it or any of its subsidiaries in obtaining or retaining business or to direct business to any
person. Neither Party shall, during the term of this Agreement, provide anything of value to any
person that may be considered a bribe, kickback, an illegal influence payment, or other illegal
payment.

15.2 Representations and Warranties of Array. Array represents, warrants to Ono that, as of the
Effective Date:

(a) Array has not previously granted any right, license or interest in or to the Array Patents, the
Array Know-How, or the Product Trademarks or any portion thereof, that is in conflict with the
rights or licenses granted to Ono under this Agreement;

(b) there are no actual, pending, or, to Array's knowledge, alleged or threatened action, suits,
claims, interference or governmental investigations involving a Product (including with respect to
the manufacturing of a Product), the Array Patents, the Array Know-How or the Product Trademarks
listed on Exhibit 1.56 by or against Array, or any of its Affiliates or, to Array's knowledge, Third
Party Partners;

(c) Array has not brought a claim alleging an infringement by a Third Party of any of the Array
Patents or the Array Know-How;

(d) to Array's knowledge, there is no actual, alleged or threatened infringement by a Third Party of
any of the Array Patents or the Array Know-How;

72
<!-- page 89 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(e) to Array's knowledge, none of the issued Array Patents are invalid or unenforceable;

(f) the Array Patents in the Ono Territory listed on Exhibit 1.5 constitute a true, accurate and
complete list of all Patents in the Ono Territory in existence as of the Effective Date that are
Controlled by Array and relate to the Products, indicating the owner, licensor and/or co-owner(s)
thereof if any such Array Patent is not, solely owned by Array;

(g) to Array's knowledge, Array and its Affiliates (i) have generated, prepared, and maintained all
material Regulatory Filings in the Ono Territory in accordance with applicable Law and (ii) have
conducted (and each of their respective Subcontractors and consultants have conducted) all
Development of the Products in the Ono Territory in accordance with applicable Law;

(h) to Array's knowledge, all material information with respect to the safety and efficacy of
Encorafenib and Binimetinib has been provided or made available to Ono prior to the Effective Date
through on site due diligence, in the electronic data room to which access was provided to Ono in
connection with the negotiation of this Agreement or by other means. In addition, to Array's
knowledge, there are no, and there have been no, material safety issues relating to Encorafenib or
Binimetinib as of the Effective Date that have been provided or made available to Ono prior to the
Effective Date through on site due diligence, in the electronic data room to which access was
provided to Ono in connection with the negotiation of this Agreement or by other means. With respect
to any information provided by Array to Ono prior to the Effective Date relating to the on-going
Clinical Studies, Ono acknowledges and agrees that such information is partial, preliminary, and
will not be finalized until the completion of data analysis, lock and transfer. Array is not aware
of any fact or circumstance that would reasonably be expected to materially adversely affect the
acceptance or the subsequent approval, by any Regulatory Authority of any filing, application or
request for Marketing Approval;

(i) Array and its Affiliates, and to Array's knowledge, its Subcontractors and PFM, have conducted
all Development of the Products in accordance with applicable Law, including where required by
applicable Law, in accordance good laboratory and clinical practice; and

(j) Array is the sole and exclusive owner, the co-owner, or exclusive licensee with respect to the
Products of all of the Array Patents listed in Exhibit 1.5, or the Product Trademarks listed on
Exhibit 1.56 free from encumbrances and, with respect to Patents owned or co-owned by Array, is,
listed in the records of the appropriate Governmental Authorities as the sole and exclusive owner or
the co-owner of the Array Patents and has the right to grant to Ono the rights granted herein with
the respect to the Array Know-How.

15.3 Additional Covenants: Each Party hereby covenants as of the Effective Date, as follows:

73
<!-- page 90 -->
<!-- page 91 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(a) during the period from the Effective Date through the end of the term of this Agreement, such
Party shall obtain (to the extent that it has not already obtained) from each of its employees, and
from each of its Affiliates and Subcontractors who are or will be involved in the Manufacture of the
Product or who are participating in the Development of the Product (and Ono shall obtain from each
of its Sublicensees), rights to any and all scientific, medical, technical, manufacturing,
marketing, regulatory, market access and other information (including clinical data and other
related information generated in compliance with CDISC standards) generated pursuant to the above
described activities and relating to Binimetinib, Encorafenib, the Products and/or the Companion
Diagnostic, such that each Party shall, by virtue of this Agreement, receive from the other Party
the licenses and other rights to which it is entitled hereunder (and such that the scope of such
licenses and other rights are not limited in scope or exclusivity by a failure to obtain such rights
from such persons);

(b) Neither Party shall (i) employ, or use a Subcontractor or consultant that employs, any
individual or entity that has been debarred by the FDA (or is subject to a similar sanction of the
EMA or PMDA), or (ii) employ or use a Subcontractor or consultant that employs any individual or
entity that is the subject of an FDA debarment investigation or proceeding (or similar proceeding of
the EMA or PMDA);

(c) Neither Party, nor any of its Affiliates, nor any of its or their respective officers or
employees (i) will commit an act, (ii) will make a statement or (iii) will fail to act or make a
statement, in any case ((i), (ii), or (iii)), that (A) would constitute a fraudulent statement to
the FDA, PMDA or any other Regulatory Authority with respect to the Development, Manufacture or
Commercialization or use of the Products or (B) could reasonably be expected to provide a basis for
the FDA, the PMDA or any other Regulatory Authority to invoke its policy respecting "Fraud, Untrue
Statements of Material Facts, Bribery and Illegal Gratuities", set forth in 56 Fed. Reg. 46191
(September 10, 1991) and any amendments thereto or any analogous laws or policies in the Ono
Territory, with respect the Development, Manufacture, Commercialization or use of Products; and

(d) Neither Party shall bring any claim or pursue any remedy against the other Party for breach of
any of such other Party's covenants, representations or warranties under this Article 15 to the
extent that the first Party had knowledge that such other Party was in breach of such
representations or warranties as of the Effective Date.

15.4 Except as otherwise expressly set forth in this Agreement, neither Party makes any
representation or extends any warranties of any kind either express or implied, including, but not
limited to, warranties of merchantability, fitness for a particular purpose, noninfringement or
validity of any patents issued or pending

74
<!-- page 92 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

ARTICLE XVI

INDEMNIFICATION; RECALLS

16.1 Indemnification of Array. Ono shall indemnify and hold harmless each of Array, its Affiliates
and the directors, officers and employees of such entities and the successors and assigns of any of
the foregoing (the "Array Indemnitees"), from and against any and all liabilities, damages,
penalties, fines, costs, expenses (including, reasonable attorneys' fees and other expenses of
litigation) ("Liabilities") from any claims, actions, suits or proceedings brought by a Third Party
(a "Third Party Claim") incurred by any Array Indemnitee, arising from, or occurring as a result of:
(a) the use, marketing, distribution, importation or sale of any Product by Ono, its Affiliates or
Sublicensees in the Ono Territory, including any Products Liability Claim arising therefrom; (b)
injury or death of patients participating in any Clinical Studies conducted by or on behalf of Ono
anywhere in the world, including any Products Liability Claim arising therefrom, (c) injury or death
of patients participating in Clinical Studies conducted under any Joint Development Plan and
sponsored by or on behalf of Ono, including any Products Liability Claim arising therefrom, and (d)
any breach of any representations, warranties or covenants by Ono in Article 15 above; except to the
extent such Third Party Claims result from the gross negligence or willful misconduct of an Array
Indemnitee.

16.2 Indemnification of Ono. Array shall indemnify and hold harmless each of Ono, its Affiliates and
Sublicensees and the directors, officers and employees of Ono, its Affiliates and Sublicensees and
the successors and assigns of any of the foregoing (the "Ono Indemnitees"), from and against any and
all Liabilities from any Third Party Claims incurred by any Ono Indemnitee, arising from, or
occurring as a result of: (a) the use, marketing, distribution. importation or sale of any Product
by Array, its Affiliates or licensees in the Array Territory (or following termination of this
Agreement, anywhere in the world), including any Products Liability Claim; (b) injury or death of
patients participating in any Clinical Studies conducted by or on behalf of Array anywhere in the
world, including any Products Liability Claim arising therefrom, (c) injury or death of patients
participating in Clinical Studies conducted under any Joint Development Plan and sponsored by or on
behalf of Array, including any Products Liability Claim arising therefrom, and (d) any breach of any
representations, warranties or covenants by Array in Article 15 above, except to the extent such
Third Party Claims result from the gross negligence or willful misconduct of a Ono Indemnitee.

16.3 Procedure. A Party that intends to claim indemnification under this Article 16 (the
"Indemnitee") shall promptly notify the other Party (the "Indemnitor") in writing of any Third Party
Claim, in respect of which the Indemnitee intends to claim such indemnification, and the Indemnitor
shall have sole control of the defense and/or settlement thereof provided that the Indemnitor shall
keep the Indemnitee regularly informed of the status of the defense of the Third Party Claim and
shall take into consideration the Indemnitee's reasonable comments thereon. The indemnity
arrangement in this

75
<!-- page 93 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

Section 16.3 shall not apply to amounts paid in settlement of any action with respect to a Third
Party Claim, if such settlement is effected without the consent of the Indemnitor, which consent
shall not be withheld or delayed unreasonably. The failure to deliver written notice to the
Indemnitor within a reasonable time after the commencement of any action with respect to a Third
Party Claim, if prejudicial to its ability to defend such action, shall relieve such Indemnitor of
any liability to the Indemnitee under this Section 16.3, but the omission to so deliver written
notice to the Indemnitor shall not relieve the Indemnitor of any liability that it may have to any
Indemnitee otherwise than under this Section 16.3. The Indemnitee under this Section 16.3 shall
cooperate fully with the Indemnitor and its legal representatives in the investigation of any action
with respect to a Third Party Claim covered by this indemnification.

16.4 Allocation. In the event a claim falls with the scope of the indemnity given by each Party, any
payments in connection with such claim shall be apportioned between the Parties in accordance with
the degree of fault attributable to each Party.

16.5 Disclaimer of Liability for Consequential Damages. UNLESS EXPRESSLY PROVIDED HEREUNDER, IN NO
EVENT SHALL EITHER PARTY OR ANY OF ITS RESPECTIVE AFFILIATES AND THEIR RESPECTIVE OFFICERS,
DIRECTORS AND EMPLOYEES BE LIABLE UNDER THIS AGREEMENT FOR SPECIAL, INDIRECT, PUNITIVE, INCIDENTAL
OR CONSEQUENTIAL DAMAGES SUFFERED BY THE OTHER PARTY UNDER THIS AGREEMENT, OF ANY KIND WHATEVER AND
HOWEVER CAUSED, AND WHETHER BASED ON AN ACTION OR CLAIM IN CONTRACT, TORT (INCLUDING NEGLIGENCE),
BREACH OF STATUTORY DUTY OR OTHERWISE, AND EVEN IF FORESEEABLE OR SUFFERED IN CIRCUMSTANCES WHERE A
PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH LOSSES. NOTWITHSTANDING THE FOREGOING, NOTHING IN
THIS SECTION 16.5 IS INTENDED TO OR SHALL LIMIT OR RESTRICT THE AMOUNTS PAYABLE TO THIRD PARTIES
UNDER THE INDEMNITIES PROVIDED PURSUANT TO ARTICLE 10, SECTIONS 16.1 AND 16.2 ABOVE; PROVIDED,
FURTHER, THAT THE FOREGOING LIMITATION OF LIABILITY SHALL NOT APPLY IN THE CASE OF GROSS NEGLIGENCE
OR WILLFUL MISCONDUCT.

16.6 Recalls. To the extent that: (i) any Regulatory Authority in the Ono Territory issues a
directive or order that the Product be recalled or withdrawn in any country within the Ono
Territory; (ii) a court of competent jurisdiction orders a recall or withdrawal of the Product in
any country within the Ono Territory, or (iii) the Parties mutually agree, or a Party reasonably
determines and the JCC or JDRC agrees, that the Product should be recalled or withdrawn voluntarily
in any country within the Ono Territory, the Parties shall recall or withdraw the Product in such
country as set forth in this Section 16.6. As between the Parties, Ono shall control and coordinate
all activities that Ono reasonably believes to be necessary in connection with such recall or
withdrawal of the Product in the Ono Territory, including

76
<!-- page 94 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

making all contact with relevant Regulatory Authorities; provided, however, that Ono shall not take
any action with respect to any such recall without first consulting in good faith with Array and
obtaining approval of the JDRC, to the extent practicable, and Ono shall consider in good faith any
comments of Array in connection with any aspect of the management of any such recall. For clarity,
all matters relating to a withdrawal or recall of the Product in the Array Territory shall, as
between the Parties, be determined, controlled and coordinated by Array.

ARTICLE XVII DISPUTE RESOLUTION

17.1 Referral to Senior Executives. The Parties recognize that disputes as to certain matters
relating to this Agreement may from time to time arise during the term of this Agreement. Any such
dispute which cannot be resolved by good faith negotiations shall be referred, by written notice
from either Party to the other, to the Senior Executives (or their respective designees) for
resolution. The Senior Executives (or their respective designees) shall negotiate in good faith to
resolve such dispute through discussions promptly following such written notice. If the Senior
Executives cannot resolve the dispute within forty-five (45) days of such written notice, or either
Party concludes that the matter will not be so resolved, then, (a) with respect to disputes or
decisions regarding matters described in Section 17.2(a), the provisions set forth in Section 17.2
shall apply, and (b) with respect to all other disputes, the provisions of Section 17.3 shall apply.
If the Parties should resolve such dispute pursuant to the procedures in this Section 17.1, a
memorandum setting forth their agreement will be prepared and signed by both Parties, if requested
by either Party.

17.2 Resolution of Certain Disputes.

(a) Application to Certain Disputes. The provisions of this Section 17.2 shall apply with respect to
any dispute that has not been resolved following referral to Senior Executives described in Section
17.1, where such dispute concerns any matter (i) to be decided by the JDRC or JCC and for which a
different means of resolution (e.g., a deciding vote of either Party) is not specified pursuant to
Section 3.5 above, or (ii) that is otherwise expressly provided for in this Agreement to be resolved
pursuant to this Section 17.2 (each of the foregoing cases referred to as an "Expert Dispute").

(b) Resolution by Experts. If the Parties do not reach a mutually acceptable resolution as to an
Expert Dispute following referral to Executive Officers described in Section 17.1, then upon written
notice by either Party (an "Expert Resolution Notice"), the Expert Dispute shall be resolved by a
final, binding determination by independent experts in the manner described in this Section 17.2.

77
<!-- page 95 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

(c) Selection of Experts. Each Party shall select an independent Third Party expert who is neutral,
disinterested and impartial, is not affiliated with either Party, has expertise and experience
relevant to the specific subject matter of the particular Expert Dispute, and does not have a
conflict of interest, and two experts so elected shall elect the third expert with qualification as
set forth above (the three experts so selected, the "Experts"). Once the Experts have been selected,
each Party shall, in accordance with mutually agreed timelines and procedures, but in no event later
than fifteen (15) Business Days from the selection of the Experts, provide the Experts and the other
Party with a written report setting forth its position with respect to the substance of the Expert
Dispute and may submit a revised or updated report and position to the Experts as mutually agreed or
as determined by the Experts. If so requested by the Experts, each Party shall make oral submissions
to the Experts based on such Party's written report delivered pursuant to this Section 17.2(c), and
each Party shall have the right to be present during any such oral submissions.

(d) Determination by the Experts. The Experts shall, no later than ten (10) Business Days after the
last submission of the written reports and, if any, oral submissions, select one of the Parties'
positions as their final decision, and shall not have the authority to modify either Party's
position or render any substantive decision other than to so select the position of either Ono or
Array as set forth in their respective written report (as initially submitted, or as revised in
accordance with Section 17.2(c), as applicable). The Parties agree that the decision of the Experts
shall be the sole, exclusive and binding remedy between them regarding any Expert Dispute presented
to the Experts, provided that the Experts' decision with respect to disputes referred to it pursuant
to Section 3.5 shall become the decision of the JDRC on the matter for all purposes of this
Agreement. The proceedings and the decision of the Experts shall not be made public without the
joint consent of the Parties and each Party shall maintain the confidentiality of such proceedings
and decision unless each Party otherwise agrees in writing; provided that either Party may make such
disclosures as are permitted for Confidential Information of the other Party under Article 10 above.

(e) Timetable for Completion in Thirty (30) business days. The Parties shall use, and shall direct
the Experts to use, diligent efforts to resolve any Expert Dispute within thirty (30) Business Days
after the selection of the Experts, or if resolution within thirty (30) Business Days is not
reasonably achievable, as determined by the Experts, then as soon thereafter as is reasonably
practicable, provided that the Experts shall resolve the Expert Dispute no later than ninety (90)
Business Days after the selection of the Experts.

17.3 Arbitration. Except with respect to (i) those matters subject to determination by the Experts
as provided in Section 17.2, or (ii) any dispute between the Parties concerning the inventorship of
intellectual property rights for which either Party may pursue such remedies as it may deem
necessary

78
<!-- page 96 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

or appropriate, any dispute arising out of or in connection with this Agreement (each, a "Dispute")
shall be exclusively resolved by final and binding arbitration as follows:

(a) Arbitration under the ICC Rules of Arbitration. The arbitration shall be conducted by three (3)
arbitrators according to the ICC Rules of Arbitration ("Rules"), and the panel of three arbitrators
so selected is referred to herein as the "Arbitration Tribunal." The seat of the arbitration shall
be in Osaka, Japan, if it is demanded by Array, and in New York, NY, USA, if it is demanded by Ono,
with hearings to held in the same location. The Emergency Arbitrator Provisions shall not apply.

(b) Conduct of the proceedings. The language of arbitration shall be English. If so requested by the
Arbitration Tribunal, any documents originally in a language other than English shall be submitted
with an English translation. The Arbitration Tribunal shall have the authority to order document
production taking guidance from the applicable rules under the laws of the seat of the arbitration.
If the tribunal orders production of documents, the tribunal shall take guidance from the IBA Rules
on the Taking of Evidence in International Arbitration as current on the dated the commencement of
the arbitration. The Parties wish to avoid a costly and time-consuming discovery exercise. The
Arbitration Tribunal shall have the power to appoint one or more experts after having consulted with
the Parties. For the avoidance of doubt, the governing law set forth in Section 18.3 shall not apply
to determine any procedural issues. In particular, but without in any way restricting the generality
of the foregoing, the Parties agree that the procedural rules of the governing law set forth in
Section 18.3 shall not apply with respect to document production or other evidentiary issues, except
that all privileges restricting disclosure established under such governing law shall apply and may
be invoked by both Parties

(c) Time limit for rendering the award. The Parties and the Arbitration Tribunal shall endeavor to
complete any arbitration within twelve (12) months following the full constitution of the
Arbitration Tribunal. However, this period is not a deadline and failure to render an award within
them shall not be a ground for annulment of an award.

(d) Decision of the Arbitration Tribunal. Every award shall be binding on the Parties. By submitting
the dispute to arbitration under the Rules, the Parties undertake to carry out any award without
delay and shall be deemed to have waived their right to any form of recourse insofar as such waiver
can validly be made. The Parties agree that they can seek recognition and enforcement of any order
and/or award made by the Arbitration Tribunal before any competent court. The Arbitration Tribunal
shall have no authority to award punitive damages or other damages exceeding the damages actually
suffered by the prevailing Party, and may not, in any event, make any ruling, finding or award that
does not conform to the provisions of this Agreement. The fees and expenses of the Arbitration
Tribunal (the translation fee described Section 17.3 (b) shall be

79
<!-- page 97 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

included) shall be shared equally by the Parties, and each Party shall bear its own expenses
incurred in connection with the proceeding, in each case unless the Arbitration Tribunal in the
award assesses such fees and/or expenses against one of the Parties or allocates such fees and
expenses other than equally between the Parties.

(e) Confidentiality. The existence and content of the Arbitration proceedings and any rulings or
award shall be deemed Confidential Information of both Parties hereunder and kept confidential by
the Parties and members of the Arbitration Tribunal except (i) where such disclosure is permitted
under Article 10 of this Agreement, (ii) to the extent that disclosure may be required of a Party to
fulfil a legal duty, protect or pursue a legal right, or enforce or challenge an award in bona fide
legal proceedings before a state court or other judicial authority, (iii) with the consent of all
Parties made in writing subsequently to this Agreement, (iii) where needed for the preparation or
presentation of a claim or defense in this arbitration, (iv) where such information is already in
the public domain other than as a result of a breach of this clause, or (v) by order of the
Arbitration Tribunal upon application of a Party.

(f) Non-Disclosure of Communications with Internal Counsel. Notwithstanding any rights to the
contrary under applicable procedural or substantive rules of Law, any communications exchanged
between members of each Party's respective legal department and directors, employees or agents in
connection with any disputes, investigations, administrative or other proceedings, shall not be
requested, produced or otherwise used, to the extent such communications would have been covered by
legal privilege and not disclosable, had these communications been exchanged between such Party and
its external attorneys.

(g) Interim Relief. The Arbitration Tribunal shall have the power to grant any remedy or relief that
it deems appropriate, whether provisional or final, including but not limited to conservatory relief
and injunctive relief, and any such measures ordered by the Arbitration Tribunal shall,
notwithstanding anything to the contrary in the governing law selected by the Parties pursuant to
Section 18.3, be deemed to be a final award on the subject matter of the measures and shall be
enforceable as such. Each Party retains the right to apply to any court of competent jurisdiction
for provisional and/or conservatory relief, including injunctions or temporary restraining orders
before or after the constitution of the Arbitration Tribunal, and any such request shall not be
deemed incompatible with the Agreement to arbitrate or a waiver of the right to arbitrate.

ARTICLE XVIII

GENERAL PROVISIONS

18.1 Force Majeure. If the performance of any part of this Agreement (except for any payment
obligation under this Agreement) by either Party is prevented, restricted, interfered with or
delayed by

80
<!-- page 98 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

reason of any cause beyond the reasonable control of such Party (including, fire, flood, earthquake,
tsunami, embargo, power shortage or failure, acts of war, insurrection, riot, terrorism, strike,
lockout or other labor disturbance, acts of God or any acts, omissions or delays in acting of the
other Party), the Party so affected shall, upon giving written notice to the other Party, be excused
from such performance to the extent of such prevention, restriction, interference or delay; provided
that the affected Party shall use its reasonable efforts to avoid or remove such causes of
non-performance and shall continue performance with the utmost dispatch whenever such causes are
removed.

18.2 Hardship. Should the occurrence of events not contemplated by the Parties fundamentally after
the equilibrium of the present contract thereby placing an excessive burden on one of the Parties in
the performance of its contractual obligations, that Party may proceed as follows: The party shall
make a request for revision within a reasonable time from the moment it become aware of the event
and of its effect on the economy of the present contract. The request shall indicate the grounds on
which it is based. The Parties shall then consult one another with a view to revising the contract
an equitable basis, in order to ensure that neither Party suffers excessive prejudice. The request
for revision does not of itself suspend performance of the contract. If the Parties fail to agree on
the revision of the contract within time limit of ninety (90) business days of the request, the
contract remains in force in accordance with its original terms.

18.3 Governing Law. This Agreement and all questions regarding its validity or interpretation, or
the breach or performance of this Agreement, shall be governed by, and construed and enforced in
accordance with, the laws of the State of New York, United States, without reference to conflict of
law principles. The Parties hereby agree that the provisions of the United Nations Convention on
Contracts for the International Sale of Goods shall not apply to this Agreement and are strictly
excluded.

18.4 Waiver of Breach. The failure of either Party at any time or times to require performance of
any provision hereof shall in no manner affect its rights at a later time to enforce the same. No
waiver by either Party of any condition or term in any one or more instances shall be construed as a
further or continuing waiver of such condition or term or of another condition or term.

18.5 Modification. No amendment or modification of any provision of this Agreement shall be
effective unless in writing signed by both Parties hereto. No provision of this Agreement shall be
varied, contradicted or explained by any oral agreement, course of dealing or performance or any
other matter not set forth in an agreement in writing and signed by both Parties hereto.

18.6 Severability. In the event any provision of this Agreement should be held invalid, illegal, or
unenforceable in any jurisdiction, the Parties shall negotiate in good faith a valid, legal and
enforceable substitute provision that most nearly reflects the original intent of the Parties and
all other provisions of this Agreement shall remain in full force and effect in such jurisdiction.
Such invalidity, illegality

81
<!-- page 99 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

or unenforceability shall not affect the validity, legality or enforceability of such provision in
any other jurisdiction.

18.7 Entire Agreement; Amendments. This Agreement (including the Exhibits attached hereto), together
with the pharmacovigilance agreement specified in Section 4.11(b), the Quality Agreement, and the
Supply Agreement (in each case, when executed) constitute the entire agreement between the Parties
relating to the subject matter hereof and supersede all prior and contemporaneous agreements,
representations and/or understandings, including the Confidentiality Agreement between the Parties
dated August 26, 2016. No terms or provisions of this Agreement shall be varied or modified by any
prior or subsequent statement, conduct or act of either of the Parties, except that the Parties may
amend this Agreement by written instruments specifically referring to and executed in the same
manner as this Agreement.

18.8 Notices. Unless otherwise agreed by the Parties or specified in this Agreement, all
communications between the Parties relating to, and all written documentation to be prepared and
provided under, this Agreement shall be in the English language. Any notice required or permitted
under this Agreement shall be in writing in the English language, and (a) delivered personally, (b)
sent by air mail or express courier service providing evidence of receipt, postage pre-paid where
applicable, or (c) by electronic transmission or facsimile (complete transmission confirmed and a
copy promptly sent by another permissible method of providing notice described in paragraph (a) or
(b) above), to the following addresses of the Parties (or such other address for a Party as may be
specified by like notice):

To Array:

Array BioPharma Inc. 3200 Walnut Street Boulder, CO 80301 USA Attn: Chief Operating Officer

To Ono:

Ono Pharmaceutical Co., Ltd. 8-2, Kyutaromachi 1-chome, Chuo-ku, Osaka, 541-8564, Japan Attn:
Director, License

With a copy to (which shall not constitute notice):

Array BioPharma Inc. 3200 Walnut Street Boulder, CO 80301 USA Attn: General Counsel

With a copy to (which shall not constitute notice):

Ono Pharmaceutical Co., Ltd. 8-2, Kyutaromachi 1-chome, Chuo-ku, Osaka, 541-8564, Japan Attn:
General Manager, Legal Department

Any notice required or permitted to be given concerning this Agreement shall be effective upon
receipt by the Party to whom it is addressed. Notices given by the condition (b) shall be deemed to
have been received seven business days after mailing or posting and notices given by the condition
(c) shall be deemed to have been received on the first Business Day following its dispatch.

82
<!-- page 100 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

18.9 Assignment. This Agreement may not be assigned by either Party to any Third Party without the
written consent of the other Party hereto; except either Party may assign this Agreement without the
other Party's consent to an entity that acquires substantially all of the business or assets of the
assigning Party, whether by merger, acquisition or otherwise; provided that the acquiring party
agrees in a writing delivered to the non-assigning Party to assume all of the rights and obligations
of the assigning Party under this Agreement. In addition, either Party shall have the right to
assign this Agreement to an Affiliate, with the prior written consent of the other Party (which
shall not be unreasonably withheld or delayed); provided that the assigning Party guarantees the
performance of this Agreement by such Affiliate and such Affiliate agrees in a writing delivered to
the non-assigning Party to assume all of the rights and obligations of the assigning Party under
this Agreement; and further provided that if the non- assigning Party reasonably believes such
assignment could result in material adverse tax consequences to the non-assigning Party, the
non-assigning Party shall have no obligation to consent to the proposed assignment. For clarity, any
assignment of this Agreement shall be without prejudice to any required review by the relevant
competition law authorities. Subject to the foregoing, this Agreement shall inure to the benefit of
each Party, its successors and permitted assigns. Any assignment of this Agreement in contravention
of this Section 18.9 shall be null and void.

18.10 Change in Control. In the event of a Change in Control of Array in which the Acquirer is
developing or commercializing [ * ] in the Field, any Development and Commercialization of a [ * ],
Binimetinib and/or Encorafenib combination by the Parties shall be conducted subject to appropriate
firewall procedures to segregate such activities (and the personnel conducting such activities) from
the activities performed by or on behalf of Acquirer with respect to [ * ] it is developing or
commercializing, to ensure that [ * ] is disclosed to employees of the Acquirer who are developing
or commercializing the Acquirer's [ * ].

18.11 Performance. Unless expressly otherwise provided hereunder, each Party or its Affiliates may
perform its obligations hereunder through its Affiliates or Subcontractors, provided that such Party
shall have entered into a written agreement (a "Subcontract") with its Subcontractors which shall be
consistent with the terms and conditions of this Agreement, shall contain confidentiality provisions
no less restrictive than those set forth in Article 10. Additionally, to the extent that such
Subcontractor shall be responsible for performance of any Development activities undertaken in
accordance with this Agreement, then the applicable Subcontract shall contain a certification that
such Subcontractor has not been debarred, and is not subject to debarment, pursuant to Section 306
of the United States Federal Food, Drug and Cosmetics Act (or similar Laws of any other country),
and is not the subject of a conviction described in such section. Notwithstanding the foregoing, the
subcontracting Party (or Party whose Affiliate enters into a Subcontract) shall remain liable under
this Agreement for the performance of all its obligations under this Agreement and shall be
responsible for and liable for compliance by its Subcontractors with the applicable provisions of
this Agreement.

83
<!-- page 101 -->
[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

18.12 No Partnership or Joint Venture. Nothing in this Agreement is intended, or shall be deemed, to
establish a joint venture or partnership between Ono and Array. Neither Party to this Agreement
shall have any express or implied right or authority to assume or create any obligations on behalf
of, or in the name of, the other Party, or to bind the other Party to any contract, agreement or
undertaking with any Third Party.

18.13 Interpretation. The captions to the several Articles and Sections of this Agreement are not a
part of this Agreement, but are included for convenience of reference and shall not affect its
meaning or interpretation. In this Agreement: (a) the word "including" shall be deemed to be
followed by the phrase "without limitation" or like expression; (b) the singular shall include the
plural and vice versa; and (c) masculine, feminine and neuter pronouns and expressions shall be
interchangeable. Each accounting term used herein that is not specifically defined herein shall have
the meaning given to it under generally accepted cost accounting principles, but only to the extent
consistent with its usage and the other definitions in this Agreement. This Agreement shall not
confer any benefits on any third parties. No third party may enforce any term of this Agreement. The
provisions of the Contracts (Rights of Third Parties) Act 1999 are hereby expressly excluded from
this Agreement.

18.14 Counterparts; Other Matters. This Agreement may be executed in any number of counterparts,
each of which shall be deemed an original, and all of which together shall constitute one and the
same instrument. Signatures to this Agreement delivered by facsimile or similar electronic
transmission will be deemed to be binding as originals. This Agreement is established in the English
language. Any translation in another language shall be deemed for convenience only and shall never
prevail over the original English version.

[Page Signature Follows]

84

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

CONFIDENTIAL
<!-- page 102 -->
EXECUTION VERSION

IN WITNESS WHEREOF, the Parties have executed this Development and Commercialization Agreement as of
the Effective Date.

ARRAY BIOPHARMA INC.

BY: _______________________________

NAME: Ron Squarer

TITLE: Chief Executive Officer

ONO PHARMACEUTICAL CO., LTD.

BY: _______________________________

NAME: Gyo Sagara

TITLE: President, Representative Director and CEO

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

CONFIDENTIAL
<!-- page 103 -->
EXECUTION VERSION

EXHIBIT 1.5

ARRAY PATENTS

[ * ]

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

CONFIDENTIAL
<!-- page 104 -->
EXECUTION VERSION

EXHIBIT 1.7

BINIMETINIB

[ * ]

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

CONFIDENTIAL
<!-- page 105 -->
EXECUTION VERSION

EXHIBIT 1.22

ENCORAFENIB

[ * ]

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 24b-2 of
the Securities Exchange Act of 1934, as amended.

CONFIDENTIAL
<!-- page 106 -->
EXECUTION VERSION

EXHIBIT 1.37

IST GUIDELINES

[ * ]

EXHIBIT 1.56(a)

BINIMETINIB PRODUCT TRADEMARKS

[ * ]

EXHIBIT 1.56(b)

ENCORAFENIB PRODUCT TRADEMARKS

[ * ]

EXHIBIT 4.1 EXISTING CLINICAL STUDIES

Phase III Trials:

BEACON CRC Trial / NCT02928224 "Phase 3 Randomized Encorafenib plus Cetuximab vs. Irinotecan A
Multicenter, Randomized, Open-label Phase 3 Study of Encorafenib + Cetuximab +/- Binimetinib vs.
Irinotecan + Cetuximab with a Safety Lead-in of Encorafenib + Binimetinib + Cetuximab in Patients
with BRAF V600E-mutant Metastatic Colorectal Cancer" COLUMBUS Trial / NCT01909453 "A 2-part phase
III randomized, open label, multicenter study of LGX818 plus MEK162 versus vemurafenib and
LGX818monotherapy in patients with unresectable or metastatic BRAF V600 mutant melanoma" NEMO Trial
/ NCT01763164 "A Randomized Phase III, Open Label, Multicenter, Two- arm Study Comparing the
Efficacy of MEK162 Versus Dacarbazine in Patients With Advanced Unresectable or Metastatic NRAS
Mutation-positive Melanoma" MILO Trial / NCT01849874 " A Multinational, Randomized, Open-label Phase
3 Study of MEK162 vs. Physician's Choice Chemotherapy in Patients with Recurrent or Persistent
Low-grade Serous
<!-- page 107 -->
Carcinomas of the Ovary, Fallopian Tube or Primary Peritoneum" [ * ] [ * ]

EXHIBIT 12.6

DOMAIN NAMES

[ * ]
