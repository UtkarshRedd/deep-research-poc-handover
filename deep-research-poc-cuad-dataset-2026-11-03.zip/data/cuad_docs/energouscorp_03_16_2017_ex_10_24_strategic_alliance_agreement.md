<!-- page 1 -->
# STRATEGIC ALLIANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2016-11-06 |
| Parties | Dialog Semiconductor (UK) Ltd. (“DIALOG”); Energous Corporation (“ENERGOUS”) |
| Source | CUAD v1 / ENERGOUSCORP_03_16_2017-EX-10.24-STRATEGIC ALLIANCE AGREEMENT |

Exhibit 10.24 [***] Certain confidential information contained in this document, marked by brackets,
has been omitted and filed separately with the Securities and Exchange Commission pursuant to Rule
24b-2 of the Securities Exchange Act of 1934, as amended. EXECUTION VERSION STRATEGIC ALLIANCE
AGREEMENT

THIS STRATEGIC ALLIANCE AGREEMENT ("Agreement") is made and entered into as of November 6, 2016 (the
"Effective Date") by and between Dialog Semiconductor (UK) Ltd., a corporation organized under the
laws of England and Wales, having its principal office at 100 Longwater Avenue, Green Park, Reading,
RG2 6GP, United Kingdom ("DIALOG") and Energous Corporation, a Delaware corporation, having its
principal office at 3590 North First Street, Suite 210, San Jose, CA 95134 ("ENERGOUS"). WHEREAS
DIALOG is a supplier of mixed-signal semiconductor products; WHEREAS ENERGOUS is a supplier of
uncoupled wirefree charging systems, including antennas, semiconductors, firmware, software,
algorithms, and sensors; WHEREAS concurrently with their execution of this Agreement, DIALOG and
ENERGOUS are entering into a separate Securities Purchase Agreement, pursuant to which DIALOG will
make an investment in ENERGOUS, and ENERGOUS will issue to DIALOG shares of its common stock and a
warrant to purchase its common stock on the terms set forth therein. WHEREAS DIALOG and ENERGOUS
desire to enter into a strategic relationship to distribute to the marketplace certain ENERGOUS
products and technology and to potentially collaborate on further initiatives pursuant to the terms
and conditions of this Agreement. NOW, THEREFORE, in consideration for the premises and mutual
covenants contained herein, DIALOG and ENERGOUS hereby agree as follows: 1. DEFINITIONS. All
capitalized terms used in this Agreement will have the meaning set out below, or if not defined
below, the meaning as defined elsewhere in the Agreement. 1.1 "Affiliate" means any person or entity
that controls, is controlled by or is under common control with the specified person or entity, but
only so long as such control exists. The term "control" means the possession, directly or
indirectly, of the power to direct or cause the direction of the management and policies of an
entity, whether through ownership of voting securities, by contract or otherwise. 1.2 "Approved
Production Specifications" means those materials, processes and workmanship specifications of
Manufacturing Subcontractors as approved by ENERGOUS for the manufacture and production of the
Products. 1.3 "Change of Control" means any transaction or series of transactions that results in
(i) the consolidation or merger of the specified party ("Target") into or with any other corporation
or corporations, (ii) the sale, conveyance or disposition of all or substantially all of the assets
of the Target, (iii) the transfer of more than fifty percent (50%) of the voting power of the Target
to any entity or entities not controlled by the Target, or (iv) any similar form of acquisition or
any liquidation, dissolution or winding up of the Target or other transaction that results in the
discontinuance of the Target's business; provided, however, that Change of Control will not include
any transaction or series of transactions entered into primarily for equity financing purposes
(including, without limitation, any private equity investment or any public offering of securities).
<!-- page 2 -->
1.4 "Deposit Materials" means all chip level design databases, circuit schematics, test and
characterization programs and associated documentation reasonably required to have Products
manufactured, or to allow design bugs or Epidemic Defects to be fixed in the Product. 1.5 "Design-In
Phase" means the phase in the sales cycle with a prospective customer for a Product that follows the
customer's decision to move forward with the potential Product, during which chip samples are
delivered to customer and the parties work together to design the evaluation board for in-system
evaluation. 1.6 "Documentation" means all information that is necessary or useful to support
DIALOG's authorized manufacture, testing, sale and support of the Products, including but not
limited to Product Specifications, data sheets, application notes, application board gerber
files/BOM, sales and marketing collateral, Product errata, test reports, characterization reports,
software (e.g., firmware, GUI), test plans and yield data in connection with the manufacture and
sale of Products, Approved Production Specifications, test and characterization programs and
associated documentation reasonably required to have Products manufactured, assembled and tested,
designs of all Tooling and all other items reasonably required for the manufacture of the Products.
1.7 "Epidemic Defects" means material defects of any Product resulting from a common root cause
solely attributable to the Product Specifications or Approved Production Specifications and which
results in returns (in accordance with the returns procedure mutually agreed between the parties in
the Commercialization Plan) of more than [***] percent ([***]%) of the quantity of such Product
manufactured in any [***] day period. Any number of material defects affecting any number of
Products which result from a single common root cause or combination of causes and result in returns
of more than [***] ([***]%) of such Products manufactured in any [***] day period will be treated as
the occurrence of a single Epidemic Defect for purposes of this Agreement. 1.8 "Insolvency Event"
means (a) without a successor, the specified party fails to function as a going concern or to
operate in the ordinary course, or (b) other than in the case when the specified party is a
debtor-in-possession and continuing to fulfill all its obligations under this Agreement, a receiver
or trustee in bankruptcy is appointed for such party or its property, or such party makes a general
assignment for the benefit of its creditors, or such party commences, or has commenced against it,
proceedings under any bankruptcy, insolvency or debtor's relief law, in each case which proceedings
are not dismissed within ninety (90) days. 1.9 "Intellectual Property Rights" means any and all
Patent Rights, copyright rights, Marks rights (including all associated goodwill), mask work rights,
trade secret rights and all other intellectual and industrial property rights of any sort throughout
the world (including any application therefor). * Confidential Treatment Requested

Page 2
<!-- page 3 -->
1.10 "Invention" means any idea, concept, discovery, invention, development, technology, work of
authorship, trade secret, software, firmware, library, component, tool, mask work, process, method,
technique, know-how, show-how, data, plan, formula, device, apparatus, specification, design,
documentation or other material or information, tangible or intangible, whether or not it may be
patented, copyrighted or otherwise protected (including all versions, modifications, enhancements
and derivative works thereof). 1.11 "Manufacturing Subcontractors" means (a) [***] and/or its
Affiliate that is the wafer foundry for the Products ("[***]"), (b) [***] and/or its Affiliate that
is responsible for the assembly, packaging and testing of the Products, and (c) and other third
party contractors DIALOG or ENERGOUS use, or may from time to time use, for the manufacturing,
assembly, testing, or packaging of the Licensed Products or Licensed Product components. 1.12
"Marks" means trademarks, service marks, trade dress and trade names. 1.13 "Mask Set" means the mask
set for fabrication of wafers at a foundry supplier. 1.14 "Mass Production Qualified Product" means
a fully qualified Product which has completed 500 hour high temperature over lifetime (HTOL) testing
and has been shipped in excess of [***] units for purposes of incorporation in customer products.
1.15 MCM means a multichip module, being a single package that includes multiple integrated circuit
dies, including a Product die. 1.16 "Net Sales" means the invoiced amounts for the Sale of Products
less: (a) amounts credited for return of any such Products; (b) amounts separately stated with
respect to shipment of such Products for insurance, handling, duty, freight, and taxes; and (c) any
discounts, credits or rebates in the relevant royalty or service fee period. 1.17 "New Product"
means a product developed by or on behalf of ENERGOUS after the Effective Date that is not a Product
Update; provided, however, that "New Products" exclude any product developed by a successor or
acquirer of ENERGOUS. 1.18 "Patent" means any United States or foreign patent or patent application,
including any provisional application, continuation, continuation-in-part, divisional, registration,
confirmation, revalidation, reissue, PCT application, patent term extension, supplementary
protection certificate, and utility model, as well as all foreign counterparts of any of the
foregoing, and related extensions or restorations of terms thereof. 1.19 "Patent Rights" means
rights under any Patent. 1.20 "Person" a human being or group of human beings, a company,
corporation, a partnership or other legal entity (artificial or juristic person) recognized by law
as having rights and duties. * Confidential Treatment Requested

Page 3
<!-- page 4 -->
1.21 "Products" means the ENERGOUS products set forth in Exhibit A, as such Exhibit may be amended
from time to time by mutual agreement between the parties, that have been released by ENERGOUS to
production, including all Product Updates, which will be deemed to have been added to Exhibit A
automatically, without any further action required by the parties, immediately following the release
to production date. 1.22 "Product Die" means the silicon die incorporated within Products. 1.23
"Product IP" means (a) all Intellectual Property Rights in and to the Products, including all
Product Updates, (b) any other Inventions and work products created or developed in connection with
research and development or manufacturing efforts relating to the Products, including all
Intellectual Property Rights therein and (c) all Intellectual Property Rights in and to the Mask
Sets and Tooling, in each of the foregoing cases, that are owned or controlled by ENERGOUS, its
Affiliates or any successor or assign. 1.24 "Product Specifications" means ENERGOUS' written
technical specifications for the Products as referenced in datasheets and related documentation such
as errata sheets. All Product Specifications are subject to change with at least one (1) months
prior written notice to DIALOG, provided that with respect to any warranty for Products covered by
this Agreement, the Product Specification in effect at the time of shipment of the relevant Product
will apply for warranty purposes notwithstanding any subsequent change to the Product Specifications
as provided herein. 1.25 "Product Updates" means any updates, improvements and other modifications
to the Products made by or for ENERGOUS, including, without limitation: (a) any updates or
modifications to the software (DSP code, firmware, GUI (graphical user interface) code); (b)
modifications of silicon, including, without limitation; such modifications made solely for cost
reduction purposes, and including only metal layer as well as all layer mask changes; (c)
modifications which increase the distance over which wireless power is transmitted or received,
subject to the limitations set out in Exhibit A; (d) modifications which increase the amount of
power which is transmitted or received; (e) modifications to improve functionality or efficiency or
add or improve features; and (f) modifications required to attain regulatory approvals, including,
but not limited to, FCC approval; provided, however, that "Product Updates" will only include any of
the foregoing developed by an acquirer or successor of ENERGOUS for a period of [***] after a Change
of Control of ENERGOUS, and provided further that any Products incorporating Product Updates will be
subject to separate terms and conditions to be agreed in good faith by the Parties, which terms and
conditions will be no less favourable to DIALOG than those with respect to the Product to which the
Product Update corresponds. 1.26 "Sale," "Sell" or "Sold" mean the sale, transfer, exchange or other
disposition of Products, by DIALOG or any of its Affiliates to any customer or other third party,
directly or indirectly through one or more tiers of distribution, for consideration that is
recognized as revenue by DIALOG or its Affiliates according to applicable generally accepted
accounting principles. 1.27 "Semiconductor Supplier" means any Person, other than DIALOG or its
Affiliates, which primarily, or in its ordinary course of business, sells or distributes integrated
circuits in packaged, die, multichip module or similar form. * Confidential Treatment Requested

Page 4
<!-- page 5 -->
1.28 "Term" means the Initial Term and any and all Renewal Term(s) as set forth in Section 15.1
hereof. 1.29 "Third Party IP" means Intellectual Property Rights licensed from a third party
relating to the Products. 1.30 "Tooling" means the physical Mask Sets, packaging fixtures, test
fixtures, test programs, processes, software source code and any other physical tooling or program
source code required for the manufacture, packaging, assembly and testing of the Products. 1.31
"Uncoupled Power Transfer Technology" means a family of wire-free technology defined by the AirFuel
Alliance that provides power to devices at a distance, and that currently includes (i) RF, (ii)
ultrasonic transduction, and (iii) Laser power beaming. Notwithstanding the foregoing, the meaning
of Uncoupled Power Transfer Technology excludes technology which functions primarily for data
transmission or direct- current-to-direct-current (DC-to-DC) power conversion. 2. LICENSE. 2.1
License Grant. Subject to the restrictions set out in Section 2.2, ENERGOUS hereby grants to DIALOG
a non-exclusive (subject to Section 2.5), irrevocable, worldwide, sub-licensable (solely in
accordance with Section 2.4), royalty-bearing license during the Term under all Product IP to: (a)
repackage or have repackaged the Product Die into various package formats or layouts, and to
integrate the Product Die into MCMs, which may incorporate DIALOG or third party intellectual
property (such repackaged Product Die, MCMs and Products, are individually and/or collectively
referred to as the "Licensed Products"); (b) have the Licensed Products manufactured, tested and
packaged by Manufacturing Subcontractors; (c) Sell, offer for Sale, import, export and support the
Licensed Products, including without limitation, providing system design, troubleshooting and
failure analysis support for DIALOG's customers and their customers; (d) use and modify the Tooling
and Documentation for the purposes of paragraphs (a) to (d) of this Section 2.1. 2.2 Excluded
Applications. Until the earlier of (i) termination of ENERGOUS' exclusivity obligations to the Key
Customer set forth in Exhibit F (the "Key Customer") existing as of the Effective Date with respect
to the following applications, or (ii) [***] that incorporates ENERGOUS wireless charging
technology, or (iii) [***] and subject to the exceptions set out in Section 2.3, DIALOG will not be
permitted to Sell Licensed Products for use in the following applications (the "Excluded
Applications"): (a) [***]; * Confidential Treatment Requested

Page 5
<!-- page 6 -->
(b) [***]; (c) [***]; (d) [***]; and (e) [***] designed for use with any of the applications in
paragraphs (a) to (d) of this Section 2.2. For the avoidance of doubt, DIALOG will be permitted to
Sell Licensed Products for use in any or all of the Excluded Applications (A) at any time on or
after [***] or, if earlier, (B) [***] that incorporates ENERGOUS wireless charging technology, or
(C) upon the termination of ENERGOUS' exclusivity obligations to the Key Customer existing as of the
Effective Date with respect to the above applications. 2.3 Exceptions to Excluded Applications. The
following applications are exceptions to and excluded from the Excluded Applications (the "Permitted
Applications"): (a) [***]; (b) [***]; (c) [***]; (d) [***]; (e) [***]; (f) [***]; (g) [***]; (h)
[***]; (i) [***]; and (j) [***]. The fact that a [***] has [***] does not automatically preclude
such device from falling under paragraphs (b), (c) and (d) of this Section 2.3 2.4 Sublicenses.
DIALOG may sublicense the foregoing license rights to any of its Affiliates. DIALOG will be
responsible for the observance and performance by all such Affiliates of all of DIALOG's obligations
pursuant to this Agreement. DIALOG may sublicense the foregoing license rights to Manufacturing
Subcontractors solely to the extent necessary and appropriate for them to manufacture, assemble,
test and provide support for the Products. DIALOG may not sublicense the foregoing license rights to
any other third party without ENERGOUS' prior written consent. * Confidential Treatment Requested

Page 6
<!-- page 7 -->
2.5 Exclusivity. (a) Subject to paragraph (b) of this Section 2.5, ENERGOUS will not, and will not
enable any Semiconductor Supplier, to manufacture, have manufactured, offer for sale, sell, import
or export the Products or Product Die in commercial volumes, except a Semiconductor Supplier to the
Key Customer for use in the Excluded Applications. (b) ENERGOUS will use its diligent, good faith
efforts to promote DIALOG as the preferred supplier of Products and Product Die. However, ENERGOUS
is allowed to engage with a Semiconductor Supplier to supply comparable products or product die to a
customer if either (i) the customer which has not been engaged with DIALOG with respect to such
product or product die notifies ENERGOUS or DIALOG in writing by an authorized officer of the
customer that it does not want to use DIALOG or a DIALOG Affiliate as a supplier of such product or
product die; or (ii) if DIALOG has been engaged with the customer, the customer notifies ENERGOUS or
DIALOG in writing prior to commencement of the Design-In Phase that it does not want to use DIALOG
or a DIALOG Affiliate as a supplier of such product or product die. For clarity, ENERGOUS shall not
intentionally supply Products, Product Die or comparable products or product die to customers
directly or through distribution channels. 2.6 Branding. (a) Products Sold by DIALOG or its
Affiliates may be branded as DIALOG products. All sales and marketing collateral, software tools and
material for promotional activities relating to the Products will utilize ENERGOUS branding in a
prominent basis as an equivalent partner with respect to such Products. (b) To the extent the
parties engage in any co-branding activities, then, subject to the terms and conditions of this
Agreement and during the Term, each party (in such capacity, "Licensor") hereby grants to the other
party (in such capacity, "Licensee") a non-exclusive, non- transferable, worldwide right and license
(without the right to sublicense), under Licensor's Intellectual Property Rights in Licensor's
Marks, to use those Marks of Licensor set forth in Exhibit D solely in connection with the
marketing, sale and distribution of such co-branded Products in accordance with this Agreement. (c)
Use of Licensor's Marks will be subject to the following terms and conditions: (i) all goodwill
generated by use of Licensor's Marks by Licensee will inure to the benefit of Licensor; (ii)
Licensee will use Licensor's Marks only in such forms and with such graphics as authorized by
Licensor; and (iii) Licensee will identify Licensor's Marks as being owned by Licensor and will (A)
cause the symbol "®" to appear adjacent to and slightly above any registered Licensor Mark, or (B)
alternatively, for any Licensor Marks that are not registered, the symbol "TM" or "SM", as
applicable. 2.7 No Other Rights. Except for the rights and licenses expressly granted in this
Agreement, no other right is granted, no other use is permitted and all other rights are expressly
reserved.

Page 7
<!-- page 8 -->
3. SOURCING. 3.1 Product Manufacture. Concurrent with or before execution of this Agreement, and
substantially in the form attached as Exhibit C, ENERGOUS will provide written authorization to its
Manufacturing Subcontractors to confirm DIALOG's and, if applicable, DIALOG's Affiliates' rights to
procure the Licensed Products and related services directly from such Manufacturing Subcontractors
utilizing ENERGOUS' Tooling and any associated manufacturing resources. DIALOG and its sublicensed
Affiliates may directly contract with the Manufacturing Subcontractors for the manufacture and
supply of Licensed Products under terms and conditions that DIALOG or such Affiliates may directly
negotiate with such third parties. 3.2 Additional Manufacturing Subcontractors. DIALOG at its sole
discretion may qualify and establish an alternative source to some or all of ENERGOUS' Manufacturing
Subcontractors for the manufacturing of the Licensed Products and ENERGOUS will provide its written
authorization thereof if requested by DIALOG. 3.3 Tooling. Subject to ENERGOUS' rights in the
Product IP and any Third Party IP (including, without limitation, that of any Manufacturing
Subcontractors), each party will own all right, title and interest in the physical Tooling procured
or generated by that party for the manufacturing, testing and packaging of the Licensed Products.
For the avoidance of doubt, as between the parties, ENERGOUS will also continue to own all right,
title and interest in and to the firmware, DSP code and GUI software embedded in the Products,
including all Intellectual Property Rights embodied therein. Upon the termination of DIALOG's right
to manufacture the Licensed Products following any expiration or termination of the Agreement or any
Wind Down Period or Continuing Obligation period, as applicable, then all right, title and interest
in the Tooling will automatically transfer to ENERGOUS subject to any Third Party IP, and DIALOG
will, at ENERGOUS' option, either sell any Tooling in its possession to ENERGOUS at cost or destroy
the Tooling and certify in writing as to same. 4. PRODUCT COMMERCIALIZATION. 4.1 Commercialization
Plan. (a) Exhibit E hereto sets out the plan for the commercialization of the Licensed Products (the
"Commercialization Plan"). The Commercialization Plan sets forth the parties' respective rights and
obligations with respect to commercial and technical activities to be performed to maximize
potential Sales of Licensed Products. The Commercialization Plan will be reviewed and (if necessary)
updated by the parties on a quarterly basis during the Term. (b) Each party will appoint (and notify
the other party of the name of) a member of their management team who will serve as that party's
primary contact for all matters related to this Agreement (each, a "Liaison"), including resolution
of issues that may arise under this Agreement. Each party may replace its Liaison at any time by
notice in writing to the other party. (c) The Commercialization Plan includes a go-to-market plan.
ENERGOUS will provide commercially reasonable sales training, material and support to DIALOG's
global application, sales and marketing teams and customers, including the support set out in
Section 4.3.

Page 8
<!-- page 9 -->
(d) ENERGOUS will also support DIALOG with an operations and quality plan, which will set forth
information relating to quality matters, including, but not limited to, testing, yield management,
RMA process, failure analysis/corrective action procedure, ECN/PCN process and detailed agreement on
mutual rights and responsibilities with respect to any quality issues or warranty claims
(hereinafter "Quality Plan"). Both parties will work in good faith to finalize and implement the
Quality Plan within 90 days after the Effective Date of this Agreement. DIALOG will be responsible
for its own frontline quality function and corrective actions, with technical input from ENERGOUS as
required. (e) The parties may promote the relationship with marketing initiatives and also agree to
engage in joint marketing communication activities related to the relationship described in this
Agreement or to the promotion of the Licensed Products, as set forth in the Commercialization Plan
or otherwise mutually agreed between the parties from time to time. 4.2 Commercialization Meetings.
The parties will meet regularly, but at least once each month during the Term, either in person or
by telephone, video or internet conference call, to share technical and commercial information as
reasonably required to facilitate the parties' exercise of their respective rights and performance
of their respective obligations under this Agreement. The information shared by the parties will
include, but is not limited to (a) market and competitive dynamic updates, (b) activities and
progress updates at DIALOG's customers, (c) technical review and feedback from customers, (d)
non-binding 12 month rolling Sales and Royalty and Service Fee forecasts for the Licensed Products,
(e) initiatives to boost sales potential for the Licensed Products. Customer information shared will
be within the limits allowed by any non-disclosure agreements DIALOG may have entered into with such
customers. 4.3 Technical Support. ENERGOUS will support DIALOG's or its Affiliates' engineers and,
in some cases and at DIALOG's request, the customer directly in providing standard design-in support
(including antenna design support) for customers' products. If the customer requires unique or
custom engineering services (i.e., support and services not limited to those with general
application to Product customers), then ENERGOUS will contract directly with such customer for the
provision of such services. ENERGOUS will provide DIALOG with any and all information that is
necessary or useful to support its authorized manufacture, testing, marketing, Sale,
troubleshooting, compatibility analysis, performance tuning, failure analysis, and other support of
the Licensed Products, including the Documentation and any updates thereto or revisions thereof
which are reasonably necessary or appropriate to provide technical support for the Products to
DIALOG customers. ENERGOUS receives the Service Fee for providing the support described in this
Section 4.3 to DIALOG and its customers during the Term. In the event the Technical Support provided
by ENERGOUS falls below a mutually-agreed upon service level that is common to the semiconductor
industry or reasonably requested by DIALOG's customers, and after failure by ENERGOUS to address
such deficiency within a twenty (20) day notice period, DIALOG may suspend the payment of Service
Fees until such service level is provided. Furthermore, in the event ENERGOUS fails to meet its
obligations as set forth in the Quality Plan, and after failure by ENERGOUS to address such
deficiency within a thirty (30) day notice period, DIALOG may suspend the payment of Service Fees
until such obligations are met.

Page 9
<!-- page 10 -->
5. PRODUCT DEVELOPMENT AND PRODUCT UPDATES. ENERGOUS will have control and authority over the design
and development of the Products, including without limitation, developing and implementing all
Product Updates. ENERGOUS reserves the right to implement Product Updates at any time in its sole
discretion. The parties will consult each other on the perceived product needs of the market and
DIALOG's customers and how best to respond to such needs. DIALOG may suggest Product Updates to
ENERGOUS provided, but all the development of Product Updates will be at ENERGOUS' sole discretion.
ENERGOUS will share its relevant product roadmaps from time to time to maximize collaboration
opportunities. 6. INTELLECTUAL PROPERTY OWNERSHIP. 6.1 Product IP. ENERGOUS retains right, title and
interest in and to the Product IP, ENERGOUS' Marks and ENERGOUS' Confidential Information, including
all Intellectual Property Rights embodied therein. No transfer or grant is made hereunder by
ENERGOUS of any of these rights or any of its other rights, whether by implication, estoppel or
otherwise, other than the limited rights and licenses expressly granted by ENERGOUS in this
Agreement, and all such other rights are hereby reserved. 6.2 DIALOG Intellectual Property. DIALOG
retains rights, title and interest in and to DIALOG's Marks and DIALOG's Confidential Information,
including all Intellectual Property Rights embodied therein. No transfer or grant is made hereunder
by DIALOG of any of these rights or any of its other rights, whether by implication, estoppel or
otherwise, other than the limited rights and licenses expressly granted by DIALOG in this Agreement
and all such other rights are hereby reserved. 7. PRODUCT SALES. 7.1 Sales. Subject to the terms and
conditions of this Agreement, and except as set forth in the Commercialization Plan or otherwise
agreed in writing between the parties, DIALOG will market and Sell the Licensed Products as
authorized under this Agreement. DIALOG will independently manage and process its own forecasting,
operations and order management. 7.2 Discontinuation of Sale of Products. If DIALOG decides to
discontinue Sales of any Product, it will notify ENERGOUS at least [***] prior to such
discontinuance, and following such notification, the exclusivity rights, if any, associated with
that Product will cease; provided, however, this provision will not apply in the event that DIALOG
continues Sales of Product Updates, repackaged Product Dies or MCMs. 7.3 Supply of Products to
ENERGOUS. DIALOG will provide 1000 samples of each Product free of charge to ENERGOUS for the
purposes of evaluation and demonstration. For additional volumes required by ENERGOUS, DIALOG will
sell to ENERGOUS on a reasonable cost plus basis for the purposes of evaluation and demonstration.
These samples are provided as is, are not intended for resale by ENERGOUS, and no indemnification or
other warranties from DIALOG will apply. * Confidential Treatment Requested

Page 10
<!-- page 11 -->
8. OTHER PRODUCTS. 8.1 New Products. In the event that ENERGOUS develops New Product, ENERGOUS will
provide DIALOG with written notice describing the New Product before marketing, selling or
distributing the New Product with or to any third party. Upon receipt of such notice, DIALOG will
have [***] to notify ENERGOUS in writing that it desires to add such New Product as Product under
this Agreement. If DIALOG provides such a notice, for a period of [***] following ENERGOUS' receipt
of such notice, ENERGOUS and DIALOG will negotiate in good faith the terms pursuant to which such
New Product will be added as a Product to this Agreement. ENERGOUS may not negotiate with any third
party the rights to market, sell or distribute any New Product until the earliest to occur of the
following (a) DIALOG does not provide ENERGOUS with notice that it desires to add such New Product
to this Agreement within the above-described [***] period, (b) ENERGOUS and DIALOG do not reach
mutually agreeable terms for adding such New Product to this Agreement during the [***] negotiation
period or (c) DIALOG provides ENERGOUS with written notice that it does not wish to negotiate with
respect to such New Product. For clarity, after any of the events described in the foregoing
subsections (a), (b) or (c) occurs, the New Product will not be covered under this Agreement, and
ENERGOUS will be free to manufacture, market, sell, distribute and otherwise exploit such New
Product as it deems fit in its sole discretion, including in collaboration with or through one or
more third parties. 8.2 No Competing Products. (a) Until expiration or earlier termination of the
Agreement, DIALOG agrees that it and its Affiliates will not, without ENERGOUS' written approval,
intentionally sell, distribute or work with any third party to develop products incorporating any
Uncoupled Power Transfer Technology other than Licensed Products; provided, however, that DIALOG
shall not be under any such restrictions in relation to services or products it provides to the Key
Customer in the event the Key Customer terminates its agreement with ENERGOUS. (b) In the event that
ENERGOUS does not receive Federal Communications Commission approval of any Licensed Product for
power transmission [***] by the [***], (i) ENERGOUS may provide written notice to DIALOG which
references this Section 8.2(b) and indicates ENERGOUS' intention to enable one or more Semiconductor
Suppliers to supply Products for [***]; and (ii) DIALOG may provide written notice to ENERGOUS which
references this Section 8.2(b) and indicates DIALOG's intention to sell, distribute or work with one
or more third parties to develop products incorporating Uncoupled Power Transfer Technology for
[***]. [***] following the date such notice is given pursuant to Section 20.1, the restrictions in
Section 8.2(a) shall no longer apply to DIALOG for Uncoupled Power Transfer Technology in [***] and
the restrictions relating to enabling a Semiconductor Supplier in Section 2.5(a) shall no longer
apply to ENERGOUS for Products or Product Die in [***]. (c) In the event that ENERGOUS does not
receive Federal Communications Commission approval of any Licensed Product for power transmission in
[***] by the [***], (i) ENERGOUS may provide written notice to DIALOG which references this Section
8.2(c) and indicates ENERGOUS' intention to enable one or more Semiconductor Suppliers to supply
Products for [***]; and (ii) DIALOG may provide written notice to ENERGOUS which references this
Section 8.2(c) and indicates DIALOG's intention to sell, distribute or work with one or more third
parties to develop products incorporating Uncoupled Power Transfer Technology for [***]. [***]
following the date such notice is given pursuant to Section 20.1, the restrictions in Section 8.2(a)
shall no longer apply to DIALOG for Uncoupled Power Transfer Technology in [***] and the
restrictions relating to enabling a Semiconductor Supplier in Section 2.5(a) shall no longer apply
to ENERGOUS for Products or Product Die in [***]. * Confidential Treatment Requested

Page 11
<!-- page 12 -->
9. ROYALTIES AND SERVICE FEES. 9.1 Royalties. DIALOG will pay ENERGOUS the Royalties set forth in
Exhibit B. For clarity, DIALOG will be responsible for paying to ENERGOUS any Royalties payable
hereunder as a result of its Affiliates' Licensed Product Sales. 9.2 Service Fee. Subject to Section
4.3, DIALOG will pay ENERGOUS the Service Fees set forth in Exhibit B. For clarity, subject to
Section 4.3, DIALOG will be responsible for paying to ENERGOUS any Service Fees payable hereunder
for services provided by ENERGOUS hereunder to DIALOG's Affiliates or any of DIALOG's or its
Affiliates' customers. 9.3 Payment. Payments of Royalties and Service Fees will be due on a calendar
quarterly basis, within [***] days after the end of the calendar quarter in which the applicable
Licensed Products were Sold or services were rendered. From the date a payment is due, unless
otherwise agreed, any late payment will accrue a late payment fee of [***] per month, or the highest
interest rate permitted by law, whichever is less. 9.4 Reports. Each payment made hereunder will be
accompanied by a report detailing (a) the total number of units, on a product-by- product basis, of
the Licensed Products Sold during the previous calendar quarter, (b) DIALOG's and its Affiliates'
Net Sales attributable to such Licensed Product units during such calendar quarter, and (c)
reasonable details regarding the calculation of the quarterly Royalty payment and Service Fee. Such
information will be maintained in strict confidence by ENERGOUS under Section 10 of this Agreement.
9.5 Books. With respect to its exercise of the rights and licenses granted in, and payment
obligations under, this Agreement, DIALOG and its Affiliates will keep accurate books and other
records, including but not limited to supporting documentation for the Royalties and Service Fees
paid hereunder (the "Records"). These Records will be maintained for a period of at least three (3)
years from the date of the related payment ("Record Retention Period"), notwithstanding any
termination of expiration of this Agreement. 9.6 Audit Rights. During the Record Retention Period,
ENERGOUS may appoint a mutually agreed independent, internationally recognized third-party certified
auditor who will have the right to inspect and copy the Records upon reasonable prior notice, and
DIALOG will (and will cause its Affiliates to) allow necessary access including, as applicable, to
its premises where such Records are located. ENERGOUS may exercise such right to this
independent-third party audit no more than one time per calendar year and each such audit will be
conducted during normal business hours. Such audit may also not interfere with DIALOG's or its
Affliates' quarterly closing of its books. In the event that such audit reveals an underpayment of
Royalties or Service Fees owed by DIALOG, DIALOG will promptly pay ENERGOUS the amount of the
underpayment. If such underpayment is in excess of [***] of the Royalties or Service Fee due for the
period audited, DIALOG will also reimburse ENERGOUS for its reasonable, out-of-pocket cost of such
audit. In the event that such audit reveals an overpayment of Royalties or Service Fees owed by
DIALOG, ENERGOUS will promptly pay DIALOG the amount of the overpayment. * Confidential Treatment
Requested

Page 12
<!-- page 13 -->
9.7 Taxes. Each party will be responsible to collect, bear and pay any and all taxes levied or based
upon the party's sale of the Products, Product Die or Licensed Products, including, all sales, use,
value added, withholding or similar taxes. In the event that the government of a country imposes any
income taxes on payments made by a party to the other hereunder and requires a party to withhold
such tax from such payments, such party may deduct such tax from such payments. Each party will be
responsible for its own banking costs relating to the receipt of payments of Royalties and Service
Fees and any other monies payable to it in connection with this Agreement. 9.8 Payment Currency. All
payments due under this Agreement will be payable in U.S. Dollars. With respect to Net Sales
invoiced in a currency other than U.S. Dollars, the Net Sales will be expressed in the domestic
currency of the entity making the Sale, together with the U.S. Dollar equivalent, calculated using
the conversion rate existing in the United States (as reported in the Wall Street Journal) on the
last working day of each month of the calendar quarter in which the Net Sales were made. Such
payments will be without deduction of exchange, collection or other charges. 10. CONFIDENTIALITY.
10.1 Scope. The term "Confidential Information" means all financial, business and technical
information disclosed by or on behalf of a party in relation to this Agreement (whether tangible or
intangible, and including all copies, analyses and derivatives thereof), that is marked or otherwise
identified as proprietary or confidential at the time of disclosure, or which by its nature would be
understood by a reasonable person to be proprietary or confidential, including all copies,
abstracts, summaries, analyses and derivatives thereof. Confidential Information does not include
information the receiving party can demonstrate (a) was rightfully furnished to it without
restriction by a third party without breach of any obligation to the disclosing party, (b) is
generally available to the public without breach of this Agreement, (c) was available to or already
in the possession or control of the receiving party on a non-confidential basis before receipt from
the disclosing party or (d) is independently developed by it or its employees without reliance on
such information. Information associated with DIALOG's quarterly Royalty or Service Fee disclosures
is Confidential Information of DIALOG. 10.2 Non-Disclosure. The receiving party agrees (a) not to
copy or use the disclosing party's Confidential Information except and only for the purposes
contemplated by this Agreement, (b) to maintain it as confidential, and exercise reasonable
precautions to prevent unauthorized access, use and disclosure, (c) not to disclose it to any third
party other than the receiving party's employees and contractors who have a need to know for the
permitted purpose and who are bound by obligations that are at least as protective as the
restrictions in this Agreement and (d) not to export or re-export in violation of U.S. or other
export control laws or regulations any such Confidential Information or product thereof. Each party
will bear the responsibility for any breach of this Section 10 by its and its Affiliates' employees
and contractors. Upon any termination of this Agreement or, in the event of any Wind Down Period or
Continuing Obligation period, upon the expiration of such period, and within fifteen (15) days after
request by the disclosing party, each receiving party will return the Confidential Information of
the other or destroy such Confidential Information and all copies of it and all information, records
and materials developed therefrom, except that the recipient may retain one copy for archival
purposes to ensure compliance with the provisions of this Agreement, and nothing contained herein
will require the erasure, deletion, alteration or destruction of any Confidential Information
required to be retained for legal or regulatory purposes or stored on back-up tapes or other back-up
media or archiving systems made in the ordinary course of business, subject in each case to the
confidentiality obligations set forth herein. Each party may only disclose the general nature, but
not the specific terms, of this Agreement without the prior consent of the other party; provided,
however, either party may provide a copy of this Agreement or otherwise disclose its terms on a
confidential basis in connection with any legal or regulatory requirement, financing transaction or
due diligence inquiry. For clarity, in the event that use, disclosure or retention of any
Confidential Information is required in order for DIALOG to exercise the license granted in Section
2, this Section 10 will not be deemed to prevent such use, disclosure or retention.

Page 13
<!-- page 14 -->
10.3 Required Disclosure. Nothing herein will prevent a receiving party from disclosing all or part
of the other's Confidential Information as necessary pursuant to court order, the lawful requirement
of a governmental agency or when disclosure is required by operation of law (including disclosures
pursuant to applicable securities laws or regulations thereunder); provided, that prior to any such
disclosure, the receiving party will use reasonable efforts to (a) promptly notify the disclosing
party in writing of such requirement to disclose, and (b) cooperate fully with the disclosing party
in protecting against or minimizing any such disclosure or obtaining a protective order. 11.
REPRESENTATIONS AND WARRANTIES; DISCLAIMERS. 11.1 Mutual Representations and Warranties. ENERGOUS
and DIALOG hereby each represent and warrant to the other that as of the Effective Date: (a) it is a
duly and validly organized and existing corporation in good standing under the laws of the state or
country of its incorporation, as applicable, and that it is legally qualified to do business in each
jurisdiction in which this Agreement may be performed and the performance of its activities
hereunder requires such qualification; (b) the performance of this Agreement and the consummation of
the transactions contemplated herein will not result in any breach or violation of any terms or
provisions of, or constitute a default under, its certificate of incorporation or by-laws or other
organizational documents, or any material agreement or instrument to which it is a party, by which
it is bound, or to which any of its property is subject; (c) all requisite corporate action has been
taken for the due authorization, execution, delivery and performance of this Agreement by it, and
this Agreement constitutes a legally binding obligation, enforceable against such party in
accordance with its terms, except insofar as enforceability may be limited by bankruptcy,
insolvency, reorganization or similar laws affecting the rights of creditors generally; and

Page 14
<!-- page 15 -->
(d) it is not a party to any litigation relating to, or that could reasonably be expected to affect,
its ability to perform its obligations under this Agreement. 11.2 Product Warranty. (a) ENERGOUS
warrants that (i) when manufactured in accordance with the Approved Production Specifications, and
as implemented in a suitable circuit application in accordance with the Product Specifications, the
Products and Product Die will conform to the Product Specifications and will be free from defects
that could have been avoided in their design; (ii) the Products, any constituent parts or
functionality thereof, the Documentation and the Deposit Materials do not infringe any third party's
Intellectual Property Rights; (iii) it did not misappropriate any third party's trade secrets in the
development of the Products, any constituent parts or functionality thereof, the Documentation or
the Deposit Materials; and (iv) when delivered (including any software updates if any), no Product
will contain any viruses, "Trojan horses" or other harmful code. The above warranties are valid for
a period of [***] from the date of shipment of any Licensed Product to any customer. (b) The
warranty contained in Section 11.2(a) does not apply to the extent any Product is operated in a
manner other than that specified by the Product Specifications, is treated with abuse, negligence or
other improper treatment (including, without limitation, use outside the device maximum ratings,
package MSL (moisture sensitivity level) guidelines or environmental limits as may be set forth in
the Product Specifications), or is defective as a result of any materials or workmanship of the
Manufacturing Subcontractors or failure of the Manufacturing Subcontractors to manufacture the
Product according to Approved Production Specifications. As such, any warranty claims due to defects
in build, materials or workmanship will be directed to the Manufacturing Subcontractors as part of
that contract between DIALOG or, if applicable, its Affiliate and such parties. (c) With the
exception of the warranties in Section 11.2(a)(ii) (third party IP infringement) and Section
11.2(a)(iii) (misappropriation of third party trade secrets) related to any Product Die, the
warranties in this Section 11.2 do not apply to MCMs or repackaged Product Die developed by or for
DIALOG or its Affiliates. (d) In the event any warranty claim is due to or arises from an Epidemic
Defect, ENERGOUS will be responsible for all costs and expenses directly incurred by DIALOG or its
Affiliates or their respective customers as a result of reasonable inspection, servicing, repairs,
replacements, recall notices, recalls and responses with respect thereto, provided that ENERGOUS'
aggregate liability to DIALOG and its Affiliates and their respective customers under this paragraph
(d) will not exceed [***] per occurrence of an Epidemic Defect. Each party will immediately notify
the other upon becoming aware of the circumstance that could reasonably be construed to be an
indication of an Epidemic Defect, and, in any event, will notify the other party immediately upon
becoming aware of the existence of an Epidemic Defect. ENERGOUS and DIALOG will expeditiously work
together in good faith to determine a technical resolution of the Epidemic Failure. ENERGOUS agrees
to make all commercially reasonable efforts to promptly diagnose the Epidemic Failure's root cause,
provide DIALOG a report detailing the results of ENERGOUS' investigation and plan an effective
workaround and a permanent solution. ENERGOUS will consult with DIALOG on any proposed workarounds
and other solutions. * Confidential Treatment Requested

Page 15
<!-- page 16 -->
11.3 Infringement of Intellectual Property Rights. If any of the Products, Product Die,
Documentation or Deposit Materials is, or in ENERGOUS' or DIALOG's opinion is likely to become, the
subject of an Intellectual Property Rights infringement claim, and as a result DIALOG or any of its
Affiliates or their respective customers are enjoined, or in ENERGOUS' or DIALOG's opinion are
likely to be enjoined, from using the Products, Product Die, Documentation or Deposit Materials,
ENERGOUS will use its best efforts to: (a) procure for DIALOG and its Affiliates and their
respective customers the right to continue to use the Products, Product Die, Documentation or
Deposit Materials, as applicable; or, but only in the event that, despite ENERGOUS' best efforts to
do so, ENERGOUS is unable to so procure such right, (b) replace or modify the Products, Product Die,
Documentation or Deposit Materials, as applicable, to make them non-infringing, provided that the
replaced or modified Products, Product Die, Documentation and Deposit Materials remain substantially
similar in performance to the infringing Products, Product Die, Documentation and Deposit Materials.
If none of the foregoing alternatives is available within a commercially reasonable time period,
DIALOG may terminate this Agreement with immediate effect, provided that it will give ENERGOUS
prompt prior written notice thereof. Nothing in this Section 11.3 is intended to limit DIALOG's
rights to indemnification under Section 12 in connection with any such infringement claim. 11.4
Disclaimer. EXCEPT AS EXPRESSLY SET FORTH IN THIS SECTION 11, THE PRODUCTS, THE PRODUCT IP, TOOLING,
DOCUMENTATION, DEPOSIT MATERIALS, CONFIDENTIAL INFORMATION AND ALL LICENSES, SERVICES AND OTHER
ITEMS PROVIDED BY A PARTY TO THE OTHER PARTY HEREUNDER ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
KIND. EXCEPT FOR THOSE WARRANTIES EXPRESSLY PROVIDED HEREIN, EACH PARTY SPECIFICALLY DISCLAIMS ALL
WARRANTIES, WHETHER ORAL OR WRITTEN, EXPRESS, IMPLIED, STATUTORY OR OTHERWISE, WITH RESPECT TO ANY
SUBJECT MATTER OF THIS AGREEMENT, INCLUDING, WITHOUT LIMITATION, ALL WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR PURPOSE AND ALL WARRANTIES ARISING FROM COURSE OF PERFORMANCE, COURSE
OF DEALING OR USAGE IN TRADE. 12. INDEMNIFICATION. 12.1 Indemnification by Energous. Subject to
Section 12.2, ENERGOUS agrees to indemnify, hold harmless and, in the case of any third party
claims, defend DIALOG and its Affiliates and each of their respective directors, officers,
employees, contractors, agents, distributors and customers (collectively, "DIALOG Indemnitees") from
and against and in respect of any and all alleged or actual demands, claims, actions, causes of
action, suits or proceedings, assessments, awarded damages (including punitive damages),
liabilities, interest and penalties, costs and expenses (including, without limitation, court costs
and reasonable legal fees and disbursements in connection therewith) (each, a "Claim") to the extent
resulting from, arising out of, relating to, or imposed upon or incurred by any DIALOG Indemnitees
by reason of (a) death or bodily injury caused by or resulting from use of the Products, (b) any
breach of any representation or warranty made by ENERGOUS hereunder or to any third party in
relation to the Products or Product Die, (c) the infringement or misappropriation of any third party
Intellectual Property Rights in relation to the Products or Product Die, (d) the infringement or
misappropriation of any third party Intellectual Property Rights as a result of DIALOG's or its
Affiliates' exercise of rights in accordance with the terms of this Agreement, including, but not
limited to, the Manufacturing Subcontractors' manufacture of the Products on their behalf, provided
that the Products are manufactured in strict compliance with the Product Specifications and Approved
Production Specifications and only to the extent such Claims arise due to compliance with the
Product Specifications and/or the Approved Production Specifications or use of the Tooling provided
by ENERGOUS hereunder, (e) the infringement by DIALOG of any third party Marks rights as a result of
its authorized use of the ENERGOUS Marks, (f) any failure by ENERGOUS to comply with applicable
laws, regulations and standards, or (g) ENERGOUS' negligence, intentional misconduct or fraud.

Page 16
<!-- page 17 -->
12.2 Exclusion. Notwithstanding the provisions of Section 12.1, ENERGOUS will not be liable to the
extent any Claim results from (a) modification of the Products by DIALOG, its Affiliates and/or any
third party (including the Manufacturing Subcontractors), or combination of the Products with other
products, offered by DIALOG, its Affiliates and/or any third party, (b) acts or omissions of any
Manufacturing Subcontractor (except to the extent such Claims are due to the infringement or
misappropriation of third party Intellectual Property Rights arising from such Manufacturing
Subcontractor's manufacturing of the Products on behalf of DIALOG in strict compliance with the
Product Specifications, Approved Production Specifications and Tooling provided by ENERGOUS), (c)
failure of any DIALOG Indemnitee to comply with applicable laws, regulations and standards, or (d)
negligence, intentional misconduct or fraud of any DIALOG Indemnitee. For clarification, if any of
the foregoing is not the cause, in whole or in part of the Claim, ENERGOUS is not relieved of its
obligations under Section 12.1. 12.3 Conditions. DIALOG must notify ENERGOUS within thirty (30)
business days after receipt of actual notice of any Claim by a third party for which it seeks
indemnification; provided, however, any failure or delay in notice will not relieve ENERGOUS of its
obligations hereunder except to the extent that ENERGOUS is actually prejudiced by such failure to
notify. ENERGOUS will have control and authority with respect to the defense, litigation, compromise
or settlement of such third party Claim (except to the extent that any settlement involves any
commitments, responsibilities or obligations on the part of DIALOG, in which case such settlement
will require the prior written consent of DIALOG, which consent will not be unreasonably delayed,
conditioned or withheld). DIALOG will cooperate and provide assistance and information as may
reasonably be required by ENERGOUS (but at ENERGOUS' expense) in connection therewith. DIALOG
reserves the right to participate at its own cost in any third party proceedings with counsel of its
own choosing. In the event that ENERGOUS does not respond to any third party Claim or does not
sufficiently defend such third party Claim, DIALOG, acting reasonably, may step in and take over the
defense of such Claim. Costs incurred in the settlement of any Claim, including, but not limited to,
reasonable legal expenses, may be off set against future Royalties and Service Fees payable.

Page 17
<!-- page 18 -->
12.4 Insurance. Each party will maintain, during the Term and for three (3) years thereafter, such
comprehensive general liability insurance (including without limitation, products liability) as will
adequately protect it against its potential liabilities under this Agreement, in amounts customary
in the semiconductor industry for similar services and products. Each party will, at the other
party's request, provide to the other party a certificate of insurance evidencing the foregoing
insurance coverage. 13. LIMITATION OF LIABILITY. 13.1 EXCEPT IN THE CASE OF (a) ANY BREACH OF
SECTION 10 (CONFIDENTIALITY), (b) THE PARTIES' OBLIGATIONS UNDER SECTION 12 (INDEMNIFICATION), (c) A
PARTY'S GROSS NEGLIGENCE OR WILLFUL MISCONDUCT, OR (d) LIABILITY ARISING FROM EPIDEMIC DEFECTS
(WHICH WILL BE SUBJECT TO THE LIMITATION SET FORTH IN SECTION 11.2(d)), IN NO EVENT WILL EITHER
PARTY BE LIABLE UNDER THIS AGREEMENT, REGARDLESS OF THE FORM OF ANY CLAIM OR ACTION (WHETHER IN
CONTRACT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE), FOR ANY (i) INDIRECT, PUNITIVE, INCIDENTAL,
RELIANCE, SPECIAL, EXEMPLARY OR CONSEQUENTIAL DAMAGES, INCLUDING, BUT NOT LIMITED TO, LOSS OF
BUSINESS, REVENUES, PROFITS OR GOODWILL, OR (ii) AGGREGATE DAMAGES IN EXCESS OF [***]. IN ADDITION,
ENERGOUS' LIABILITY WITH RESPECT TO ITS OBLIGATIONS UNDER SECTION 12.1(b) SHALL IN NO EVENT EXCEED
[***]. THESE LIMITATIONS ARE INDEPENDENT FROM ALL OTHER PROVISIONS OF THIS AGREEMENT AND WILL APPLY
NOTWITHSTANDING THE FAILURE OF ANY REMEDY PROVIDED HEREIN. 14. COMPLIANCE WITH LAWS. Each party will
comply with all law and regulations applicable such party's performance under this Agreement,
including but not limited to U.S. Export Administration laws and regulations and any other export,
import and re-export control laws applicable to such party. The parties will refrain from exporting
or re-exporting the Products or Product IP or any technical data or other materials received from
each other, or the direct product of any of these, to any country, individual or organization
proscribed by the United States government, unless properly authorized by the appropriate agencies
of the United States government. Each party will provide all information under its control which is
necessary or useful for the other party to ship or receive the Products, including, but not limited
to, U.S. Export Control Classification Numbers (ECCNs), U.S. Customs Certificates of Delivery,
Certificates of Origin and U.S. Federal Communications Commission identifier, if applicable. Each
party agrees that it will not act in any fashion or take any action in violation of any applicable
anti-bribery or anti-corruption legislation in any jurisdiction in which it does business, which
prohibits the offering, giving or promising to offer or give, directly or indirectly, money or
anything of value to any official of a government, political party or instrumentality to assist it
in obtaining or retaining business, including the U.S. Foreign Corrupt Practices Act or any
comparable legislation in another country. * Confidential Treatment Requested

Page 18
<!-- page 19 -->
15. TERM AND TERMINATION. 15.1 Term. This Agreement is effective on the Effective Date. Unless
earlier terminated as provided herein, this Agreement continues in effect for an initial term of
seven (7) years ("Initial Term") and will automatically renew for one or more annual periods after
the Initial Term (each a "Renewal Term") unless either party gives notice of non-renewal at least
one hundred eighty (180) days prior to the beginning of any Renewal Term. 15.2 Termination. (a)
Mutual Termination Rights. Either party may, in addition to any other remedies available to it under
this Agreement or at law or in equity, terminate this Agreement (or, in the event this Agreement has
been previously terminated, the Wind Down Period, if any) immediately upon the issuance of written
notice to the other party in the event that (i) the other party materially breaches a material
provision of this Agreement, and fails to cure such breach within thirty (30) days, or (ii) the
other party undergoes an Insolvency Event. (b) Termination By ENERGOUS. (i) If ENERGOUS is acquired
by a third party, ENERGOUS' acquirer will have the right, for a period of [***] following closing of
such acquisition, to terminate this Agreement upon written notice to DIALOG. (ii) ENERGOUS will have
the right to terminate this Agreement immediately upon the issuance of written notice to DIALOG (A)
if DIALOG undergoes a Change of Control involving a competitor of ENERGOUS (as reasonably determined
by ENERGOUS), or (B) if DIALOG or any of its Affiliates acquires, whether directly or indirectly
through a sale of assets or a Change of Control transaction or otherwise, any competitor of
ENERGOUS. DIALOG will provide ENERGOUS with notice of any such Change of Control or acquisition
within [***] after the closing thereof and ENERGOUS' right to terminate the Agreement will expire
[***] after receipt of such notice. (iii) ENERGOUS may, at any time after the third anniversary of
the Effective Date, terminate this Agreement with or without cause upon not less than one hundred
and eighty (180) days prior written notice to DIALOG. (iv) ENERGOUS will have the right to terminate
this Agreement, upon not less than [***] prior written notice to DIALOG, in the event that,
following termination by the [***] of its agreement with ENERGOUS, DIALOG participates in or
indicates its intention to participate in the development, design or manufacture of products
incorporating Uncoupled Power Transfer Technology not provided by ENERGOUS to [***]. (c) Termination
by DIALOG. (i) If DIALOG is acquired by a third party, DIALOG's acquirer will have the right, for a
period of [***] following closing of such acquisition, to terminate this Agreement upon written
notice to ENERGOUS. * Confidential Treatment Requested

Page 19
<!-- page 20 -->
(ii) DIALOG may terminate this Agreement, immediately upon issuance of written notice to ENERGOUS in
the event that: (A) DIALOG or its Affiliates fail to achieve a design-win pipeline with an annual
projected sales value to DIALOG of at least [***] in the [***] after the availability of a Mass
Production Qualified Product; or (B) the aggregate annual Net Sales of Products are below [***] by
the [***] of the availability of a Mass Production Qualified Product, or below [***] by the [***] of
the availability of a Mass Production Qualified Product, or below [***] by each [***] of the
availability of a Mass Production Qualified Product during the remainder of the Term. (iii) DIALOG
will have the right to terminate this Agreement immediately upon the issuance of written notice to
ENERGOUS (A) if ENERGOUS undergoes a Change of Control involving a competitor of DIALOG, or (B) if
ENERGOUS acquires, whether directly through a sale of assets or through a Change of Control
transaction, any competitor of DIALOG (as reasonably determined by DIALOG). ENERGOUS will provide
DIALOG with notice of any such Change of Control or acquisition within [***] after the closing
thereof and DIALOG's right to terminate the Agreement will expire [***] after receipt of such
notice. 15.3 Effect of Termination. Upon any termination or expiration of this Agreement, all
rights, licenses (including any sublicenses granted by DIALOG) and obligations hereunder will cease,
except that the provisions of Sections 6 (Intellectual Property Ownership), 9 (Royalties and Service
Fees), 10 (Confidentiality), 11 (Representations and Warranties; Disclaimers), 12 (Indemnification),
13 (Limitation of Liability), 15.3 (Effect of Termination), 15.4 (Wind Down Period), 16 (Escrow), 18
(Non-Solicitation), 19 (Choice of Law and Dispute Resolution) and any provisions to give effect
thereto, will survive such termination or expiration and remain in full force and effect in
accordance with their terms. 15.4 Wind Down Period. (a) Notwithstanding any statement in Section
15.3 to the contrary, upon any termination or expiration of this Agreement and until the later to
occur of (i) [***] from the Effective Date or (ii) [***] following the effective date of termination
or expiration of this Agreement (the "Wind Down Period"), the parties' respective rights and
obligations under Sections 2 (License), 3 (Sourcing), 7 (Product Sales), 9 (Royalties and Service
Fees), 11 (Representations and Warranties; Disclaimers), 12 (Indemnification), 13 (Limitation of
Liability), 14 (Compliance with Laws), 15.2 (Termination), 16 (Escrow) and all Exhibits hereto which
are associated with any of the foregoing listed sections will remain in full force and effect as to
(A) any Products or repackaged Product Die with respect to which DIALOG or any of its Affiliates has
secured a design win at a customer prior to or within one (1) month after the start of the Wind Down
Period, or (B) the sale of any MCMs which have been released for production at a foundry, provided,
however, that DIALOG's license rights under Section 2.1 (including any sublicenses granted by DIALOG
pursuant to Section 2.4) will be non-exclusive during the Wind Down Period. (b) If, at the time of
notice of any termination of this Agreement, DIALOG or any of its Affiliates has a written supply
contract with a customer that extends beyond the end of the Wind Down Period (a "Continuing
Obligation"), DIALOG and/or its Affiliates may continue to Sell Licensed Products to such customer
through the term of the Wind Down Period and for the remainder of the term of such Continuing
Obligation, provided that in no event may DIALOG or its Affiliates Sell Licensed Products to such
customer pursuant to this Section 15.4(b) for a period longer than [***] after the effective date of
termination of this Agreement. In such event, the provisions of this Agreement that survive during
the Wind Down Period will continue to survive for the remainder of the period of time that DIALOG is
authorized to Sell Licensed Products to any customer in accordance with the foregoing sentence. The
rights granted under this Section 15.4(b) will be conditioned upon DIALOG providing ENERGOUS a
complete or redacted copy of the applicable supply contract demonstrating the existence of the
Continuing Obligation as of the date of notice of termination or, if DIALOG or its Affiliate is
prohibited from providing a copy of the contract by the confidentiality obligations set forth
therein, a written certification from an officer of DIALOG attesting to the existence of the
Continuing Obligation. * Confidential Treatment Requested

Page 20
<!-- page 21 -->
16. ESCROW. 16.1 Escrow. ENERGOUS will at its expense, at DIALOG's written request during the Term
and any Wind Down Period, enter into a three- party escrow deposit arrangement, in accordance with
this Section 16, with a recognized escrow agent (the "Escrow Agent") of mutual agreement. ENERGOUS
will keep the Deposit Materials in escrow and ensure on a quarterly basis that all the information
relating to the Deposit Materials in escrow is current, including deposit of any Product Updates.
16.2 Release of Deposit Materials. In the event of any Insolvency Event and where the design files
need to be accessed by DIALOG to fix an Epidemic Defect or other Product design or production issue
impacting yield or quality ("Release Condition"), the Escrow Agent will, in accordance with the
terms of the escrow agreement between the parties and the Escrow Agent (the "Escrow Agreement"),
release the Deposit Materials to DIALOG. 16.3 License. ENERGOUS hereby grants DIALOG a
non-exclusive, non-transferable (except as set forth in Section 2) license under the Product IP to
use any of the Deposit Materials released from escrow for the purpose of fixing an Epidemic Defect
or other Product design or production issue impacting yield or quality during the Term and, if
applicable, any Wind Down Period or Continuing Obligation period, including, but not limited to,
authorizing any third party subcontractor to manufacture and supply Products, provided, however,
that DIALOG continues to make all Royalty payment owed to ENERGOUS (or the then-current owner of the
Product IP) as provided in this Agreement. No Service Fees will be payable under this license.
DIALOG agrees not to exercise such license until occurrence of a Release Condition, subject to the
other restrictions set forth in this Section 16. Such license may be exercised by DIALOG only during
the Term and any Wind Down Period or Continuing Obligation period and is subject to DIALOG's
continued compliance with all of the other applicable terms and conditions of this Agreement during
any such applicable period. All Deposit Materials will be deemed ENERGOUS' Confidential Information
hereunder. DIALOG's license to possess and use the Deposit Materials does not include any right to
disclose, market, sublicense or distribute the Deposit Materials to any third party other than its
Affiliates and Manufacturing Subcontractors. 16.4 Rights in Bankruptcy. The licenses granted
pursuant to this Agreement are license to rights in "intellectual property" (as that term is defined
in Section 101 of the United States Bankruptcy Code) and governed by 11 USC Section 365(n).
Accordingly, if a trustee in bankruptcy rejects the Escrow Agreement and/or this Agreement as
executory contracts, then Company may elect to retain its rights under this Agreement in accordance
with and subject to the provisions of 11 USC Section 365(n).

Page 21
<!-- page 22 -->
17. PUBLICITY. 17.1 Publicity. Within 30 days of the Effective Date each party will issue a mutually
agreed joint press release regarding the strategic cooperation for the supply of Products and the
strategic cooperation between the parties. 18. NON-SOLICITATION. 18.1 Non-Solicitation. During the
Term and for a [***], neither party will without the written consent of the other party (which may
be granted or denied in its sole discretion) (a) directly or indirectly recruit or solicit for
employment or for the provision of services any employee of the other party, (b) otherwise solicit,
induce or influence any employee to leave their employment with the other party, or (c) attempt to
do any of the foregoing; provided, however, that the foregoing will not apply to (y) any employee of
the other party that responds to a public advertisement of employment opportunities or (z) any
employee that was terminated without cause by the other party. ENERGOUS and DIALOG acknowledge and
agree that the covenants in this Section 18 are reasonable and necessary to protect each of their
trade secrets, Confidential Information and stable workforces. 19. CHOICE OF LAW AND DISPUTE
RESOLUTION. 19.1 Applicable Law. This Agreement will be governed by and construed in accordance with
the laws of the State of California, exclusive of conflict of laws principles. 19.2 Dispute
Resolution; Jurisdiction. Any dispute or claim arising out of or relating to this Agreement
(including any matters regarding its existence, scope, validity, breach or termination, or any
non-contractual obligations arising out of or related to it) that is not able to be resolved through
negotiations will be submitted to arbitration in San Francisco, California, administered by the
International Chamber of Commerce under its Rules of Arbitration. There will be one arbitrator. The
language of the arbitration will be English. The award will be in writing, state the reasons for the
award and be final and binding. Judgment on the award may be enforced in any court of competent
jurisdiction. Except as may be required by law, the parties will preserve the confidentiality of all
aspects of the arbitration. The arbitration will be the sole and exclusive forum for final
resolution of any such dispute or claim, provided, however, that, because each party will have
access to and become acquainted with Confidential Information of the other party, the unauthorized
use or disclosure of which may cause irreparable harm and significant injury which may be difficult
to ascertain and which may not be compensable by damages alone, the parties agree that the damaged
party will have the right to seek an injunction, specific performance or other equitable relief
without prejudice to any other rights and remedies that it may have for such unauthorized use or
disclosure. Each party irrevocably waives all rights to a jury trial in any judicial proceeding
permitted hereunder. For the avoidance of doubt, the validity, construction, and enforceability of
this Agreement and the resolution of disputes arising out of and relating to this Agreement, will be
governed solely by this Section 19. * Confidential Treatment Requested

Page 22
<!-- page 23 -->
20. MISCELLANEOUS PROVISIONS. 20.1 Notices. All notices required or permitted under this Agreement
will be in writing, reference this Agreement and be deemed given: (a) when delivered personally; or
(b) when sent by electronic mail with electronic confirmation of receipt, provided that such notice
is immediately confirmed as provided in (c) or (d) below; or (c) seven (7) days after having been
sent by registered or certified mail,; or (d) two (2) days after deposit with a commercial courier
service, with written verification of receipt. All communications will be sent to the addresses set
forth below. Either party may change its address by giving notice pursuant to, and specifically
referring to, this Section 20. If to ENERGOUS: Energous Corporation 3590 North First Street Suite
210 San Jose, California 95134 U.S.A. Attn: Brian Sereda, CFO

If to DIALOG: Dialog Semiconductor (UK) Ltd 100 Longwater Avenue Green Park Reading, RG2 6GP United
Kingdom Attn: Legal Department 20.2 Relationship of Parties. ENERGOUS and DIALOG are independent
business entities. Neither party nor its employees, consultants, contractors or agents are agents,
employees, partners or joint venturers of the other party, nor do they have any authority to bind
the other party by contract or otherwise to any obligation. The parties will not represent to the
contrary, either expressly, implicitly, by appearance or otherwise. 20.3 Force Majeure. Except for
obligations to pay amounts due under this Agreement, neither party will be liable for any failure or
delay in its performance under this Agreement due to causes which are beyond its reasonable control,
including, but not limited to, acts of God, acts of civil or military authority, fires, epidemics,
floods, earthquakes, riots, wars, sabotage, labor shortages or disputes, and governmental actions;
provided, however, that the affected party: (a) gives the other party written notice of such cause
promptly, and in any event within fifteen (15) days of discovery thereof; and (b) uses its
reasonable efforts to correct such failure or delay in its performance as soon as possible. The
affected party's time for performance or cure under this Section 20.3 will be extended for a period
equal to the duration of the cause. 20.4 Severability. If any provision of this Agreement is held to
be invalid or unenforceable in any jurisdiction in which this Agreement is being performed, then:
(a) such provision will be deleted from this Agreement in that jurisdiction to the extent of such
invalidity or unenforceability without invalidating the remaining provisions of this Agreement, and
any such unenforceability in that jurisdiction will not make that provision unenforceable in any
other jurisdiction; and (b) the parties will agree on an alternative provision that best
accomplishes the objectives of such provision, to the extent legally permissible in such
jurisdiction.

Page 23
<!-- page 24 -->
20.5 No Waiver. No waiver or consent in connection with or relating to this Agreement will bind
either party unless in writing and signed by the party against which enforcement is sought. Waiver
by either party of any default will not be deemed a waiver by such party of the same or any other
default that may thereafter occur. 20.6 Counterparts. This Agreement may be executed in one or more
counterparts, each of which will be an original, but taken together constituting one and the same
instrument. Execution of a facsimile copy (including PDF) will have the same force and effect as
execution of an original, and a facsimile/electronic signature will be deemed an original and valid
signature. 20.7 Headings and References. The headings and captions used in this Agreement are used
for convenience only and are not to be considered in construing or interpreting this Agreement. 20.8
Construction. The parties and their respective counsel have negotiated this Agreement. This
Agreement will be fairly interpreted in accordance with its terms and without any strict
construction in favor of or against either party. 20.9 Complete Agreement. This Agreement
constitutes the entire agreement between the parties with respect to the subject matter hereof and
supersedes and replaces all prior or contemporaneous understandings or agreements, written or oral,
regarding such subject matter. No amendment to or modification of this Agreement will be binding
unless in writing and signed by a duly authorized representative of both parties. 20.10 Assignment.
This Agreement may not be assigned by either party without the express written consent of the other
party, which approval will not be unreasonably withheld or delayed, except that either party may
(without consent but with notice to the other party) assign this Agreement in its entirety to any
successor in the event of a Change of Control of such party. 20.11 Notice of Merger or Acquisition.
Until the date that this Agreement terminates or is terminated in accordance with Section 15 hereof,
ENERGOUS agrees that, [***]. * Confidential Treatment Requested

Page 24
<!-- page 25 -->
IN WITNESS WHEREOF, the parties have caused this Agreement to be executed by their duly authorized
representatives as of the Effective Date. ENERGOUS CORPORATION DIALOG SEMICONDUCTOR (UK) LTD By: /s/
Stephen R. Rizzore By: /s Mark Tyndall Name: Stephen R. Rizzore Name: Mark Tyndall Title: President
and Chief Executive Officer Title: SVP Corporate Development and Strategy

Page 25
<!-- page 26 -->
EXHIBIT A PRODUCTS Any ENERGOUS integrated circuit (IC) designed to receive power wirelessly and any
ENERGOUS IC used in a wireless transmitter, including, but not limited to, the following Products
(and any related Product Updates): [***] * Confidential Treatment Requested

Page 26
<!-- page 27 -->
EXHIBIT B ROYALTIES AND SERVICE FEES Royalties and Service Fees payable by DIALOG and/or its
Affiliates to ENERGOUS hereunder will be calculated on a Product by Product basis as defined herein.
Margin Split: Combined Royalties and Service Fees shall equal [***]. Dialog will retain the
remaining [***]. [***]. [***]. Notwithstanding any provision of the Agreement, no Royalties or
Service Fees will be payable to ENERGOUS hereunder in connection with any Sale to any customer of
prototype or sample Licensed Products [***]. * Confidential Treatment Requested

Page 27
<!-- page 28 -->
EXHIBIT C Example of Letter of Authorization: Mask Set(s) Authorization for Third Party's Product(s)
To whom it may concern Pursuant to a STRATEGIC ALLIANCE Agreement between Dialog Semiconductor (UK)
Ltd and Energous Corporation dated November 6, 2016 (to which [Manufacturing Subcontractor] is not a
party), we, Energous Corporation (Energous), hereby agree and authorize [Manufacturing
Subcontractor], under the terms of this Letter of Authorization, to use the Mask Set(s) specified
below for manufacturing products for the supply to the Third Party specified in paragraph 2 below
only: 1. Mask Set(s) details: Mask Set(s) Product Type: Foundry Code: 2. Third Party details: Third
Party's Name: Dialog Semiconductor [purchasing entity to be determined] Third Party's Address:
Contact name of Third Party: 3. Volume of products The number of products to be manufactured with
the Mask Set(s) will be unlimited, unless otherwise instructed by us below: Authorized Amount:
[UNLIMITED] 4. Duration of Authorization The duration of this Letter of Authorization will be
unlimited, unless otherwise instructed by us below: Duration of Authorization: [UNLIMITED] 5.
Confidential Information Other than wafers for products specified under paragraph 1 above (which
contain Energous designs), [Manufacturing Subcontractor] will not disclose to the Third Party any
information which is proprietary or confidential to Energous.

Page 28
<!-- page 29 -->
6. Reporting Upon Energous' request (but not more frequently than once per calendar year),
[Manufacturing Subcontractor] will provide Energous with the accumulated wafer volumes ordered (and
shipped) to the Third Party under this Letter of Authorization. By signing this Letter of
Authorization, the Third Party authorizes [Manufacturing Subcontractor] to report to Energous
accordingly. 8. Governing Law This Letter of Authorization will be governed by and construed in
accordance with the laws of California, excluding its conflict of laws provisions, and be subject to
the non-exclusive jurisdiction of the California courts. Very truly yours, Energous Incorporated
Name: Title: Date: Agreed by Dialog Semiconductor (UK) Ltd Name: Title: Date: This Letter of
Authorization is subject to the approval of the Manufacturing Subcontractors.

Page 29
<!-- page 30 -->
EXHIBIT D LICENSED MARKS DIALOG LICENSED MARKS: Dialog Dialog Semiconductor ENERGOUS LICENSED MARKS:
Energous WattUp Unleash your power Pending: [***] * Confidential Treatment Requested

Page 30
<!-- page 31 -->
EXHIBIT E Commercialization plan Objective The Commercialization Plan sets forth the parties'
respective rights and obligations with respect to commercial and technical activities to be
performed to maximize potential Sales of Licensed Products. [***] Review O The Commercialization
Plan will be reviewed and (if necessary) updated by the parties on a quarterly basis throughout the
Term of the agreement. * Confidential Treatment Requested

Page 31
<!-- page 32 -->
EXHIBIT F CUSTOMER: [***] * Confidential Treatment Requested

Page 32
