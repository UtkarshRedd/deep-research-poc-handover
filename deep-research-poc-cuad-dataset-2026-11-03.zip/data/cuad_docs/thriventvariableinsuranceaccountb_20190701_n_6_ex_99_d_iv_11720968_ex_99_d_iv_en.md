<!-- page 1 -->
# ENDORSEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2019-07-01 |
| Parties | Thrivent Financial for Lutherans |
| Source | CUAD v1 / ThriventVariableInsuranceAccountB_20190701_N-6_EX-99.D(IV)_11720968_EX-99.D(IV)_Endorsement Agreement |

ENDORSEMENT

Contract Number: ENDORSEMENT

Effective Date: July 1, 2019

Thrivent Life Insurance Company has been dissolved. (Thrivent Life Insurance Company was formerly
known as Lutheran Brotherhood Variable Insurance Products Company.) All assets and related
liabilities of Thrivent Life Insurance Company have been transferred to Thrivent Financial for
Lutherans. That includes contracts of insurance, separate accounts, and cash and investment
securities. Thrivent Financial for Lutherans now has all obligations under this contract. It is the
same as if Thrivent Financial for Lutherans had originally issued the contract. All references to
"Thrivent Life Insurance Company" are amended to read "Thrivent Financial for Lutherans." All
benefits and other terms of this contract remain unchanged except as described below.

You may direct inquiries to:

Thrivent Financial for Lutherans 4321 N. Ballard Road Appleton, WI 54919-0001 (800) 847-4836

The following amendments apply in lieu of any contract provisions to the contrary.

The following provisions are included as part of this contract:

MAINTENANCE OF SOLVENCY. This provision applies only to benefits provided through the General
Account. If the solvency of the Society becomes impaired, you may be required to make an extra
payment. The Board of Directors will determine the amount of any extra payment. It will be based on
each member's fair share of the deficiency. You may make the extra payment by an equivalent
reduction in benefits or by a payment in cash. If you do not make the extra payment within 60 days
from the date we notify you of your share of the deficiency, the amount will be charged as an
indebtedness against the contract with interest compounded at the rate of 5% per year.

MEMBERSHIP. The person(s) named as the Insured(s) or the Annuitant(s) is a benefit member of the
Society. Rights and privileges of membership are set forth in the Articles of Incorporation and
Bylaws of the Society. These rights and privileges are separate from the ownership of this contract.

DIVIDENDS. Each year, we will determine our divisible surplus. This contract's share, if any, will
be credited as a dividend. Since we do not expect this contract to contribute to divisible surplus,
it is not expected that any dividends will be credited.

DIVIDEND OPTIONS. If dividends are credited after premiums can no longer be paid under this
contract, dividends will be paid in cash. Otherwise, dividends will be applied under the Payment of
Premium option unless the Cash option has been chosen in writing.

Cash. Dividends are paid in cash.

Payment of Premium. Dividends are applied as payment of a Net Premium. VB-TL-TFFL (18) page TL-1
@TL18#AA

Source: THRIVENT VARIABLE INSURANCE ACCOUNT B, N-6, 7/1/2019
<!-- page 2 -->
Contract Number: ENDORSEMENT (continued)

The following provisions of this contract are amended:

DEFINITIONS

The DEFINITIONS section of the contract is amended to include the following:

Service Center. Where this contract is administered. Our Service Center address is 4321 North
Ballard Road, Appleton, WI 54919-0001.

And in the DEFINITIONS section, the definition:

We, Our, Us. Lutheran Brotherhood Variable Insurance Products Company.

Which previously was amended to read:

We, Our, Us. Thrivent Life Insurance Company.

Is amended to read:

We, we, Our, our, Us, us, Society. Thrivent Financial for Lutherans.

ENTIRE CONTRACT

In the ENTIRE CONTRACT section, the first phrase and numbered list are amended to read:

The Entire Contract consists of: 1) This contract including any attached riders, amendments, or
endorsements; 2) The Application attached to this contract; and 3) The Articles of Incorporation and
Bylaws of the Society and all amendments to them. Benefits will not be reduced or eliminated by any
future amendments to our Articles of Incorporation or Bylaws.

ASSIGNMENT

The ASSIGNMENT section is amended to include the following:

You may transfer ownership of this contract in accordance with our bylaws. Society membership rights
and privileges cannot be transferred or assigned. VB-TL-TFFL (18) page TL-2

Source: THRIVENT VARIABLE INSURANCE ACCOUNT B, N-6, 7/1/2019
<!-- page 3 -->
Contract Number: ENDORSEMENT (continued)

The following words or phrases in this contract are amended as follows. Any reference to: Is amended
to read:

Thrivent Life Insurance Company Thrivent Financial for Lutherans

the Company the Society

the company. the Society

A Stock Life Insurance Company. A Fraternal Benefit Society

625 Fourth Avenue South. 4321 North Ballard Road Minneapolis, MN 55415 Appleton, WI 54919-0001

Minneapolis, MN Appleton, WI

Home Office. Service Center

Nonparticipating Eligible for annual dividends Signed for Thrivent Financial for Lutherans

President

Secretary VB-TL-TFFL (18) page TL-3

Source: THRIVENT VARIABLE INSURANCE ACCOUNT B, N-6, 7/1/2019
