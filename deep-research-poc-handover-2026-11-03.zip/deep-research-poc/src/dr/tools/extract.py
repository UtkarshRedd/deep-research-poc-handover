"""Extract grid (Approach 3, PLAN Phase 5): one structured question over N documents in parallel,
answered by the cheap extractor model, each hit saved to the evidence bank as a verbatim quote.

Per document the model sees a bounded context (EXTRACT_DOC_MAX_TOKENS): the first lines of the
document (title, parties, dates) plus the document's EXTRACT_CHUNKS_PER_DOC best BM25 chunks for
the question, every line prefixed with its number so the reply can cite a line range. The harness
validates the quote against that line range with the same guard as `add_evidence`; a paraphrase or
a wrong range is rejected and recorded, never saved. Whole documents never enter context.
"""
from __future__ import annotations

import re
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any

from langchain_core.messages import HumanMessage
from pydantic import BaseModel, field_validator

from ..config import DEFAULT, Config
from ..evidence import EvidenceBank
from ..prompts import load
from ..structured import ModelCaller
from ..tools.bm25 import BM25Index, tokenize
from ..trace import Trace
from ..workspace import Workspace


class ExtractJSON(BaseModel):
    found: bool = False
    answer: str = ""
    quote: str = ""
    start_line: int | None = None
    end_line: int | None = None

    @field_validator("start_line", "end_line", mode="before")
    @classmethod
    def _first_int(cls, v):
        """Small models write '12', 'L12' or '12-13': take the first integer."""
        if v is None or isinstance(v, int):
            return v
        m = re.search(r"\d+", str(v))
        return int(m.group(0)) if m else None


@dataclass
class ExtractRow:
    doc_id: str
    found: bool
    answer: str = ""
    evidence_id: str | None = None
    page: int | None = None
    error: str | None = None


@dataclass
class GridResult:
    question: str
    rows: list[ExtractRow] = field(default_factory=list)
    n_added: int = 0
    n_found: int = 0
    n_rejected: int = 0
    elapsed_ms: int = 0

    def summary(self) -> str:
        hits = [r for r in self.rows if r.found and r.evidence_id]
        lines = [f"Extract grid over {len(self.rows)} documents for: {self.question}",
                 f"{len(hits)} with a verified quote, {self.n_rejected} rejected, {len(self.rows) - self.n_found} without."]
        for r in hits:
            pg = f" p.{r.page}" if r.page else ""
            lines.append(f"- {r.doc_id}{pg} [{r.evidence_id}]: {r.answer[:160]}")
        return "\n".join(lines)


def document_context(ws: Workspace, doc_id: str, question: str, bm25: BM25Index | None, config: Config = DEFAULT) -> str:
    """Numbered lines: the document head plus its best chunks for the question, within the token cap."""
    caps = config.agents
    lines = ws.lines(doc_id)
    budget = caps.EXTRACT_DOC_MAX_TOKENS * 4
    head_n = min(len(lines), 15)
    picked: list[tuple[int, int]] = [(1, head_n)]
    if bm25 is not None:
        # the question's own words plus the corpus vocabulary the first move borrowed for them
        # (a "non-compete" clause is often worded "shall not sell competing products")
        q_exp = bm25.expand_query(question, feedback_docs=config.tools.FIRST_MOVE_FEEDBACK_DOCS,
                                  n_terms=config.tools.FIRST_MOVE_EXPANSION_TERMS)
        seen: set[int] = set()
        hits = []
        for q in (question, q_exp):
            for h in bm25.ranking(q):
                if h.doc_id == doc_id and h.start_line not in seen:
                    seen.add(h.start_line)
                    hits.append(h)
        hits = hits[: caps.EXTRACT_CHUNKS_PER_DOC]
        if not hits:   # nothing scored inside this doc: fall back to its own keywords
            q = " ".join(tokenize(question, bm25._stop)[:8])
            hits = [h for h in bm25.ranking(q) if h.doc_id == doc_id][: caps.EXTRACT_CHUNKS_PER_DOC]
        for h in hits:
            picked.append((h.start_line, h.end_line))
    else:
        picked.append((head_n + 1, len(lines)))
    # merge overlapping ranges, keep document order
    picked.sort()
    merged: list[list[int]] = []
    for s, e in picked:
        if merged and s <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    out: list[str] = []
    used = 0
    for s, e in merged:
        if out:
            out.append("…")
        for i in range(s, min(e, len(lines)) + 1):
            ln = f"{i}| {lines[i - 1]}"
            used += len(ln) + 1
            if used > budget:
                return "\n".join(out)
            out.append(ln)
    return "\n".join(out)


def extract_grid(ws: Workspace, bank: EvidenceBank, question: str, doc_ids: list[str], llm: Any | None = None,
                 bm25: BM25Index | None = None, config: Config = DEFAULT, trace: Trace | None = None,
                 deadline_ts: float | None = None, created_by: str = "extract") -> GridResult:
    if llm is None:
        from ..llm import get_llm

        llm = get_llm("extractor")
    t0 = time.perf_counter()
    caller = ModelCaller(llm, trace, "extract", "extractor", deadline_ts=deadline_ts)
    res = GridResult(question=question)

    def one(doc_id: str) -> ExtractRow:
        if doc_id not in ws.manifest:
            return ExtractRow(doc_id=doc_id, found=False, error="unknown doc_id")
        text = document_context(ws, doc_id, question, bm25, config)
        got = caller.json([HumanMessage(content=load(
            "extract", question=question, doc_id=doc_id, title=ws.manifest[doc_id].title[:100], text=text
        ))], ExtractJSON)
        if got is None:
            return ExtractRow(doc_id=doc_id, found=False, error="extractor failed or invalid JSON")
        if not got.found or not got.quote.strip():
            return ExtractRow(doc_id=doc_id, found=False, answer=got.answer[:300])
        if got.start_line is None or got.end_line is None:
            return ExtractRow(doc_id=doc_id, found=True, answer=got.answer[:300], error="no line range")
        try:
            it = bank.add(doc_id, int(got.start_line), int(got.end_line), got.quote, got.answer[:200],
                          sub_question=question[:200], created_by=created_by)
        except (ValueError, KeyError) as e:
            return ExtractRow(doc_id=doc_id, found=True, answer=got.answer[:300], error=f"rejected: {e}"[:200])
        return ExtractRow(doc_id=doc_id, found=True, answer=got.answer[:300], evidence_id=it.id, page=it.page)

    with ThreadPoolExecutor(max_workers=max(1, min(config.agents.EXTRACT_CONCURRENCY, len(doc_ids) or 1))) as ex:
        res.rows = list(ex.map(one, doc_ids))
    res.n_found = sum(1 for r in res.rows if r.found)
    res.n_added = sum(1 for r in res.rows if r.evidence_id)
    res.n_rejected = sum(1 for r in res.rows if r.found and not r.evidence_id)
    res.elapsed_ms = int((time.perf_counter() - t0) * 1000)
    if trace:
        trace.stage("extract", "end", n_docs=len(doc_ids), n_found=res.n_found, n_added=res.n_added,
                    n_rejected=res.n_rejected, ms=res.elapsed_ms)
    return res
