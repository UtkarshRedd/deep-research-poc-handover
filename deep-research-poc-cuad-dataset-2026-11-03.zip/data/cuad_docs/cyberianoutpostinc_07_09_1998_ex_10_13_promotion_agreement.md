<!-- page 1 -->
# Promotion Agreement
| Field | Value |
|---|---|
| Document Type | Promotion Agreement |
| Agreement Date | 1998-01-26 |
| Parties | CNET, Inc. ("CNET"); Cyberian Outpost, Inc. ("Company") |
| Source | CUAD v1 / CYBERIANOUTPOSTINC_07_09_1998-EX-10.13-PROMOTION AGREEMENT |

EXHIBIT 10.13 Cyberian Outpost, Inc. has omitted from this Exhibit 10.13 portions of the Agreement
for which Cyberian Outpost, Inc. has requested confidential treatment from the Securities and
Exchange Commission. The portions of the Agreement for which confidential treatment has been
requested are marked with X's in brackets and such confidential portions have been filed separately
with the Securities and Exchange Commission.

PROMOTION AGREEMENT

This Promotion Agreement (the "Agreement") is dated as of January 26, 1998 between CNET, Inc.
("CNET") and Cyberian Outpost, Inc. (the "Company"). Pursuant to this Agreement, CNET will provide
various links and other online and television promotions (collectively, the "Promotions") to the
Company to assist the Company in promoting its products and services and facilitating the sale of
products to potential buyers through its Internet site. CNET will be compensated by the Company for
providing the Promotions. Accordingly, the parties hereby agree as follows:

1. Background.

1.1 The Company. The Company operates an electronic retailing operation through its Internet sites
located at www.cyberianoutpost.com or www.outpost.com (together with any successors to such sites,
the "Company Site"). Through the Company Site, the Company sells or facilitates the sale of various
products and services, either directly or as an agent for third party vendors. All products and
services offered for sale through the Company Site are referred to as the "Products."

1.2 CNET. CNET produces television programs and operates a network of Internet sites on the world
wide web. For purposes of this Agreement, the "CNET Sites" refer to any Internet sites operated by
CNET or its subsidiaries, including without limitation the sites referenced in Section 2.5 and
Exhibit A.

2. CNET's Obligations.

2.1 TV Promotions. CNET will provide the Company one 15 second "spot" for Promotions on its
syndicated weekly TV program, TV.COM. Promotions will run on each weekly episode of TV.COM during
the Term; provided that TV.COM remains on the air throughout such period. Should TV.COM not be run
on the air during a portion of the Term, CNET will run two download.com banner advertising programs
per month during such portion of the Term in lieu of the foregoing TV.COM Promotions.

2.2 Banner Promotions. CNET will provide advertising banners to the Company during the Term as
described in Exhibit A.

2.3 Retail Promotions.

2.3.1 CNET will provide for various retail Promotions across the CNET Sites, which may include
text/HTML links, buttons, portals and other fixed Promotions that include embedded links to the
Company Site (the "Retail Promotions" and, together with the advertising banners contemplated in the
preceding paragraph, the "Online Promotions").

2.3.2 Subject to Section 4 below, CNET will provide the Company with a total of at least (a)
[XXXXXX] Retail Impressions during the first three months of the Term, (b) [XXXXXX] Retail
Impressions during the second three months of the Term, (c) [XXXXXX] Retail Impressions during the
third three months of the Term, and (d) [XXXXXX] Retail Impressions during the fourth three months
of the Term. For such purposes, a "Retail Impression" means the display of one page of a CNET Site
that contains at least one Retail Promotion. If CNET fails to provide the Retail Impressions
required by the preceding sentence during the Term, then CNET will continue to display Retail
Impressions in accordance with this Agreement following the Term (notwithstanding the termination or
expiration of the Term) until the required number of Retail Impressions has been delivered.

2.4 Placement of Retail Promotions. CNET will determine the location and type of each Retail
Promotion displayed throughout the CNET Sites and may phase in certain types of Retail Promotions as
they are developed. CNET currently intends to display Retail Promotions consisting of text/HTML
links, pre-filled with an appropriate query string or link ("Pre-Filled Links"), as set forth in
this Section. The Retail Promotions contemplated by this Section will be displayed above the fold
where the graphical layout of the page reasonably permits such positioning (as determined by CNET),
and in other cases the Retail Promotions will be prominently positioned below the fold. For the
purposes of clarity, the "fold" is defined as the visible portion of the screen on a standard 640 x
480 screen size.

2.4.1 On SEARCH.COM, CNET intends to display a Pre-Filled Link on the
<!-- page 2 -->
search query page related to Shopping and on every search results page served by CNET.

2.4.2 On CNET.COM, CNET intends to display a Pre-Filled Link on pages within the site except the
Front Door and except for pages within the Personalities and Community sections.

2.4.3 On BUILDER.COM, CNET intends to display a Pre-Filled Link on pages within the site except the
Front Door and the "Builder Buzz" section.

2.4.4 On GAMECENTER.COM, NEWS.COM, DOWNLOAD.COM and SHAREWARE.COM, CNET will display a Pre-Filled
Link on pages within the site except the Front Door.

2.4.5 Other pages of the CNET Sites, CNET will display additional Retail Promotions as appropriate
and as mutually agreed upon.

2.5 Design and Production of Online Promotions. The Company will design any graphics required for
the Online Promotions and provide pre-filled query strings or links for all of the Pre-Filled Links,
with reasonable assistance from CNET, and the Company will supply digital copies of such graphics
and other materials to CNET. CNET will be responsible for incorporating the Online Promotions into
the CNET Sites and for ensuring that the Online Promotions are accessible to users of the CNET Sites
("Users").

2.6 Reporting. Within 30 days after the end of each month during the Term, CNET will provide a
report to the Company indicating the number of Retail Promotions displayed on the CNET Sites during
such month and the number of times that a User clicked on a Retail Promotion during such month. CNET
will also provide standard reporting for banner advertisements and television Promotions.

3. The Company's Obligations:

3.1 Operation of Company Site. The Company will be responsible for ensuring that each link embedded
within an Online Promotion takes the User to the appropriate area within the Company Site, and that
the Company Site functions with reasonable reliability and in a commercially reasonable manner
throughout the Term. In particular, the Company agrees that the Company Site will comply with the
performance standards set forth in Exhibit B throughout the Term. Any failure by the Company to
comply with this paragraph will be deemed to be a material breach of this Agreement.

3.2 Reporting. Within 30 days after the end of each month during the Term, the Company will provide
a report to CNET indicating the aggregate number of referrals from the CNET Sites to the Company
Site during such month, the resulting number of buyers, the aggregate behavior (including orders and
sales volume) of those buyers, and the total revenue attributable to the Online Promotions minus
applicable sales tax, shipping costs, returns and cancellations (the "CNET Sales"). The "CNET Sales"
will be counted as sales by the Company to each User who accesses the Company Site through a link
from an Online Promotion for a period of 4 hours from the referral, CNET and The Company will agree
on technical procedures to allow the easy and accurate reporting of CNET Sales. The Company will
make this information available in a manner which

allows CNET and the Company to understand the performance of the various Online Promotions.

3.3 Cash Consideration.

3.3.1 For each month during the Term, the Company will pay CNET a minimum of [XXXX] in cash, plus
[XXX] of CNET Sales. Payments under this paragraph will be based on the reports prepared by the
Company under Section 3.2 (although CNET may challenge such reports as contemplated by Section 9.5)
and will be due within 30 days after the end of each month of the Term.

3.3.2 Payments under this Section 3.3 will be made by wire transfer of immediately available funds
and are nonrefundable once paid.

3.4 User Information. At least once each calendar quarter, the Company will deliver to CNET all
aggregate data collected as a result of the CNET Sales, including but not limited to, demographic
data, buying behavior as measured by conversion to sale, frequency of purchasing, average order
size, and a comparison to the respective average for the Company.

3.5 Reciprocal Marketing. For the duration of the Term, the Company will place a link within the
Beta Report Newsletter, the Cyberian Express Newsletter, the Gamer's Express newsletter, or any
newsletter to which users can subscribe to which is provided by the Company to its users (expressly
excluded from this obligation are emails that are sent by the Company for product announcements, or
personalized emails sent to users upon product purchase. This link will be a text phrase or series
of text phrases encouraging the users to sign up for CNET's free email newsletters for technology
News, CNET Dispatch, and Software & Hardware Services. CNET will provide all entry forms and operate
the production and sending of the newsletter. CNET agrees not to specifically target these
subscribers separately from the general
<!-- page 3 -->
database of subscribers to CNET's various newsletters. Should the Company provide a persistent link
or series of links (as distinguished from occasional and ad hoc links to product reviews either on
the Company Site or in any communication by the Company to its customers) to a "Technology Content
Provider", CNET shall be given at least equal prominence to any other Technology Content Provider
provided that CNET offers comparable editorial content. A Technology Content Provider is defined as
a company providing news product information or reviews about technology products that is not a
manufacturer of those products.

4. Term and Termination. The term of this Agreement (the "Term") will begin on February 1, 1998 and
end on the first anniversary of the date of this Agreement; provided that (a) either party may
terminate this Agreement, effective at any time after the first three

months of the Term, by giving 30 days' written notice of termination to the other party, and (b)
either party may terminate this Agreement at any time by giving written notice of termination to the
other party, if the other party commits a material breach of its obligations hereunder that is not
cured within 30 days after notice thereof from the non-breaching party. If this Agreement is
terminated during any of the three month periods referenced in Section 2.3.2, then the required
number of Retail Impressions applicable thereunder to such three month period will be pro rated
accordingly.

5. Exclusivity. For purposes of this agreement "Competing Computer Products Retailer" means any
company other than the Company that is engaged in the retail sale of computer products, with the
exception of CNET Direct, which operates BuyDirect.com. During the Term, CNET will not enter into
more than two other agreements under which CNET receives consideration from a Competing Computer
Products Retailer for displaying permanent links to or other fixed promotions for such Competing
Computer Products Retailer on any CNET Site; provided that the foregoing will not restrict the
display of(a) standard advertisements for any Competing Computer Products Retailer or its products
or (b) any promotions within COMPUTERS.COM or within CNET's Snap! Online service (which are
expressly excluded from this provision). The parties acknowledge that the foregoing will not prevent
CNET from displaying text links and other references to Competing Computer Products Retailers as
reasonably necessary to provide appropriate editorial and search related services on the CNET Sites.
The Retail Promotions granted to the Company shall be placed in such a way as to provide no more or
less prominence to the Company than is provided to any other Competing Computer Retailer signing an
agreement with CNET.

6. Trademark Licenses.

6.1 The Company hereby grants to CNET a non-exclusive, royalty-free license, effective throughout
the Term, to use, display and publish any of the Company trademarks, tradenames, service marks and
logos that may be delivered by the Company to CNET expressly for inclusion in the Promotions, solely
for use in connection with the Promotions. Any use of the Company Marks by CNET must comply with any
reasonable usage guidelines communicated by the Company to CNET from time to time. Nothing contained
in this Agreement will give CNET any right, title or interest in or to the Company Marks or the
goodwill associated therewith, except for the limited usage rights expressly provided above. CNET
acknowledges and agrees that, as between the Company and CNET, the Company is the sole owner of all
rights in and to the Company Marks.

6.2 The Company hereby represents and warrants to CNET that the Company has, and will have
throughout the Term, all necessary rights in and to the Company Marks to grant CNET the licenses and
usage rights contemplated by this Agreement without violating the rights of any third party.

7. Responsibility for the Company Products. The Company acknowledges and agrees that, as between the
Company and CNET, the Company will be solely responsible for any claims or other losses associated
with or resulting from the marketing or operation of the Company Site or the offer or sale of any
Products by the Company or through the Company Site. CNET is not authorized to make, and agrees not
to make, any representations or warranties concerning the Products, except to the extent (if any)
contained within Promotions delivered to CNET by the Company.

8. Mutual Indemnification.

8.1 Indemnification by CNET. CNET shall indemnify and hold the Company harmless from and against any
costs, losses, liabilities and expenses, including all court costs, reasonable expenses and
reasonable attorney's fees (collectively, "Losses") that the Company may suffer, incur or be
subjected to by reason of any legal action, proceeding, arbitration or other claim by a third party,
whether commenced or threatened, arising out of or as a result of (a) any breach or alleged breach
by CNET of its representations, warranties or covenants hereunder; or (b) the operation of the CNET
Sites (except in cases where the Company is required to indemnify CNET under the following
paragraph), including claims of infringement or misappropriation of intellectual property rights.

8.2 Indemnification by the Company. The Company shall indemnify and hold CNET harmless from and
against any Losses that CNET may suffer, incur or be subjected to by reason of any legal action,
proceeding,
<!-- page 4 -->
arbitration or other claim by a third party, whether commenced or threatened, arising out of or as a
result of (a) any breach or alleged breach by the Company of its representations, warranties or
covenants hereunder; (b) the use by CNET of the Company Marks or any content provided by the Company
to CNET expressly for display in connection with or as part of the Promotions, including claims of
infringement or misappropriation of intellectual property rights; or (c) the operation of the
Company Site or the offer or sale of the Products by the Company or through the Company Site.

8.3 Indemnification Procedures. If any party entitled to indemnification under this section (an
"Indemnified Party") makes an indemnification request to the other, the Indemnified Party shall
permit the other party (the "Indemnifying Party") to control the defense, disposition or settlement
of the matter at its own expense; provided that the Indemnifying Party shall not, without the
consent of the Indemnified Party enter into any settlement or agree to any disposition that imposes
an obligation on the Indemnified Party that is not wholly discharged or dischargeable by the
Indemnifying Party, or imposes any conditions or obligations on the Indemnified Party other than the
payment of monies that are readily measurable for purposes of determining the monetary
indemnification or reimbursement obligations of Indemnifying Party. The Indemnified Party shall

notify Indemnifying Party promptly of any claim for which Indemnifying Party is responsible and
shall cooperate with Indemnifying Party in every commercially reasonable way to facilitate defense
of any such claim; provided that the Indemnified Party's failure to notify Indemnifying Party shall
not diminish Indemnifying Party's obligations under this Section except to the extent that
Indemnifying Party is materially prejudiced as a result of such failure. An Indemnified Party shall
at all times have the option to participate in any matter or litigation through counsel of its own
selection and at its own expense.

9. Miscellaneous.

9.1 LIMITATION OF DAMAGES. NEITHER PARTY WILL BE LIABLE FOR ANY SPECIAL, INDIRECT, CONSEQUENTIAL OR
INCIDENTAL DAMAGES ARISING OUT OF OR RELATED TO THIS AGREEMENT, HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY (INCLUDING NEGLIGENCE), AND EVEN IF SUCH PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.

9.2 Assignment. This Agreement may not be assigned by either party, except (a) to the transferee of
substantially all of the business operations of such party (whether by asset sale, stock sale,
merger or otherwise) or (b) to any entity that controls, is controlled by or is under common control
with such party.

9.3 Relationship of Parties. This Agreement will not be construed to create a joint venture,
partnership or the relationship of principal and agent between the parties hereto, nor to impose
upon either party any obligations for any losses, debts or other obligations incurred by the other
party except as expressly set forth herein.

9.4 Entire Agreement. This Agreement constitutes and contains the entire agreement between the
parties with respect to the subject matter hereof and supersedes any prior oral or written
agreements. This Agreement may not be amended except in writing signed by both parties. Each party
acknowledges and agrees that the other has not made any representations, warranties or agreements of
any kind, except as expressly set forth herein.

9.5 Audit Rights. Each party will have the right to engage an independent third party to audit the
books and records of the other party relevant to the calculation of Retail Impressions or CNET
Sales, upon reasonable notice and during normal business hours, and the other party will provide
reasonable cooperation in connection with any such audit. The party requesting the audit will pay
all expenses of the auditor unless the audit reveals an underpayment by the other party of more than
5%, in which case the other party will reimburse all reasonable expenses of the auditor.

9.6 Applicable Law. This Agreement will be construed in accordance with and governed by the laws of
the State of California, without regard to principles of conflicts of law.

9.7. Confidentiality. The material terms of this agreement and any information exchanged in
connection herewith shall be covered by the Non-Disclosure Agreement between CNET and the Company
dated December 5, 1997 (the "NDA"). Notwithstanding the foregoing the following information will not
be considered "Confidential Information" for purposes of the NDA provided that such information is
not publicly identified as belonging to or coming from the Company: (a) information contained in the
reports described in Section 3.2, (b) the names and e-mail addresses referenced in Section 3.4 and
(c) any information obtained by CNET from Users who affirmatively request to be added to an e-mail
newsletter pursuant to Section 3.5.

9.8 Press Release. Each party may issue a press release concerning the business relationship
contemplated by this Agreement, and each party will provide an appropriate quote from one of its
senior executive officers for use in the other party's release. The Company agrees that CNET's press
release may disclose the total consideration payable
<!-- page 5 -->
to CNET hereunder. Each Party will provide the other with a reasonable opportunity to review and
comment on its press release.

IN WITNESS WHEREOF, the parties have caused this Agreement to be executed by their duly authorized
representatives as of the date first written above.

CNET, INC. Cyberian Outpost

By: /s/ By: /s/ Darryl Peck ------------------------------ --------------------------- Title:
Director, Business Development Title: President and CEO ------------------------------
----------------------

EXHIBIT A

ADVERTISING BANNERS

For each of the first 12 calendar months of the Term, CNET will provide the Company with one
advertising banner "program" (which has a retail value of $20,000) on each of the following CNET
Sites:

1. CNET.COM ([XXXXX] impressions per month) 2. SEARCH.COM ([XXXXX]impressions per month) 3.
GAMECENTER.COM ([XXXXX] impressions per month) (two programs per month) 4.
SHAREWARE.COM/DOWNLOAD.COM ([XXXXX] impressions per month; this is a single unit, which may be
satisfied by delivering banners on either site)

EXHIBIT B

PERFORMANCE STANDARDS

The Company Site and the Company's related operations must comply with the following performance
standards throughout the Term

1. The Company Site will be operational and fully functional in all material respects (i.e. capable
of displaying information, receiving purchases and conducting transactions as contemplated in the
ordinary course of business) at least 97% of the time during any 30 day period.

2. Without limiting the effect of 1, the Company shall provide to users coming to the Company Site
from the Retail Promotions at least the same level of service as is offered to users coming directly
to the Company Site or from agreements with other distribution partners.
