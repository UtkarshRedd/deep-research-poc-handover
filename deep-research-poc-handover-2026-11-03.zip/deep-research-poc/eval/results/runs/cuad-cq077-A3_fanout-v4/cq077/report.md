# Among the following 8 agreements, which contain a non-compete clause? For each, quote t...

*Question:* Among the following 8 agreements, which contain a non-compete clause? For each, quote the clause. Agreements: the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley (dated 2017-11-14); the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. (dated 2011-03-14); the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc (filed 2018-11-09); the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC (dated 2013-05-15); the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies (filed 2005-11-02); the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01); the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. (dated 2010-01-01); the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. (filed 2013-09-26).

## Does the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley da...

The Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley dated 2017-11-14 contains an exclusivity clause that restricts endorsements of competing products during the Term. [4cb98e07400203bf p.3] The clause states: "8. [uncited] Exclusivity. [uncited] Talent represents and warrants that during the Term and in the Territories, Talent will not endorse or make any appearances or advertisements on behalf of any other product which is directly competitive to ESSI's products."  A severability clause appears elsewhere in the agreement but does not establish a non-compete obligation. [4cb98e07400203bf p.3] [4cb98e07400203bf p.5]

## Does the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema...

The Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp dated 2011-03-14 contains a non-compete clause. [23e65a3b8bc5cc9e p.25] Section 11.3(a) states: "Section 11.3 Non-Competition and Non-Solicitation. [uncited] (a) During the Term, except as otherwise provided in this Agreement, Network Affiliate and its affiliates agree not to engage or participate in any business, hold equity interests, directly or indirectly, in another entity, whether currently existing or hereafter created, or participate in any other joint venture that competes or would compete with any business that NCM is authorized to conduct in the Territory pursuant to this Agreement, whether or not NCM is actually conducting such business in a particular portion of the Territory. [uncited] The foregoing restrictions shall not apply (i) in the event Network Affiliate or its affiliate acquires a competing business as an incidental part of an acquisition of any other business that is not prohibited by the foregoing, if Network Affiliate disposes of the portion of such business that is a competing business as soon as commercially reasonable, (ii) to any direct or indirect ownership or other equity investments by Network Affiliate or its affiliates in such other competing business that represents in the aggregate less than 10% of the voting power of all outstanding equity of such business, o…". [23e65a3b8bc5cc9e p.25]

## Does the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope He...

[DROPPED: claim s3.1 could not be verified against its cited source.] The agreement contains a non-compete clause restricting the promotion of competing products during the term. [61c29bdb3ab6960e p.2] The clause states: "3. [uncited] Restriction on Promotion of Competing Products. [uncited] During the term of this agreement, Distributor shall not market, sell advertise or promote the sale or use of any product or device which is competitive with or substantially similar to the Products, without the prior express written consent of Erchonia, nor shall they assist any third party in doing so. [uncited] Notwithstanding the foregoing, to the extent Distributor or Distributor's customer is a licensed health care professional or licensed health care practitioner, nothing in this paragraph shall prevent or limit Distributor or Distributor's customer from exercising their independent medical judgment with regard to the treatment of any patient." [61c29bdb3ab6960e p.2]

## Does the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC date...

Section 7.2(e) titled "Non-Compete" addresses only a third-party settlement agreement's lack of a non-compete affecting employment; it is not a non-compete clause binding either party to this Supply Agreement. [31cbf0d18f7d763e p.13] Section 3.1 provides an exclusivity provision stating that neither PcoMed nor its Affiliates shall sell or offer for sale, or grant rights under the PcoMed Surface Modification Technology to any Third Party in the Field in the Territory for products that utilize or embody the PcoMed Surface Modification Technology. [31cbf0d18f7d763e p.7] Section 3.1 further states that except as expressly stated in the preceding sentence, PcoMed shall not be subject to any restriction under this Agreement with regard to the PcoMed Surface Modification Technology. [31cbf0d18f7d763e p.7] Section 3.1 also states that without limiting the foregoing or Section 8.3 below, the exclusive nature of the Rights shall not in any way limit PcoMed from making, having made, using, selling or offering for sale products and/or services that do not utilize or embody the PcoMed Surface Modification Technology. [31cbf0d18f7d763e p.7]

## Does the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity...

The Cooperation Agreement between e.l.f. [uncited] Beauty, Inc. and Marathon Partners Equity Management, LLC is dated 2020-07-01. [e42a4ef8cda58762 p.1] Section 6 of the agreement addresses mutual non-disparagement and public statements, but it does not contain a non-compete clause. [e42a4ef8cda58762 p.7] The text of Section 6 states: "6. [uncited] Mutual Non-Disparagement; No Public Statements. [uncited] (a) Subject to applicable law, the Company, on the one hand, and each of the Marathon Parties on the other hand, covenants and agrees that, during the Support Period or if earlier, until such time as the other Party or any of its or her officers, directors, employees, subsidiaries, Affiliates,". [e42a4ef8cda58762 p.7]

[GAP] The evidence does not contain any non-compete clause for this agreement.

## Does the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GA...

The Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. dated 2010-01-01 does not contain a non-compete clause. [ab1fd1dd637746ab p.2] The closest provision is an endorsement restriction on competitors rather than a non-compete clause. [ab1fd1dd637746ab p.2] That provision states: “(v) prohibiting the endorsement by Racing and any members of Racing, including the drivers, of any entities, products or services which are in direct competition or otherwise inconsistent with the Sponsor or it products or services, unless such endorsement activity is approved in writing by Racing and the Sponsor; and (vi) allowing”. [ab1fd1dd637746ab p.2]

## Does the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry H...

The Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. filed 2013-09-26 does not contain a non-compete clause. [64e3019755b942aa p.8] The only match for "competition" in the document appears in a severability clause stating that invalidity, illegality, or unenforceability of any provision shall not affect any other provisions of the Agreement. [64e3019755b942aa p.8] The entire agreement clause confirms there are no restrictions, agreements, promises, warranties, covenants, or undertakings between the Parties other than those expressly set forth in the Agreement. [64e3019755b942aa p.8]

[GAP] No non-compete clause text is present in the provided evidence.

## Not established by the evidence

[GAP] No evidence was found for: Does the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies filed 2005-11-02 (doc c7883d92d25ee9ea) contain a non-compete clause? Quote it.

## Verification appendix

Claims: 33 · supported: 19 · partially: 0 · dropped: 1 · gaps: 13 · tier-1 support rate: 0.95

Notes: outline from 8 fan-out findings (no outline call); 1 empty section(s) collapsed into gaps: Does the Reseller Agreement between Touchstar Software Corporation and Worldwide Strate...

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[4cb98e07400203bf p.3] |  |
| s1.2 | s1 | gap |  |  | no evidence cited |
| s1.3 | s1 | gap |  |  | no evidence cited |
| s1.4 | s1 | keep | 1.00 | e1→[4cb98e07400203bf p.3] e2→[4cb98e07400203bf p.5] |  |
| s2.1 | s2 | keep | 1.00 | e3→[23e65a3b8bc5cc9e p.25] |  |
| s2.2 | s2 | gap |  |  | no evidence cited |
| s2.3 | s2 | gap |  |  | no evidence cited |
| s2.4 | s2 | keep | 1.00 | e3→[23e65a3b8bc5cc9e p.25] |  |
| s3.1 | s3 | drop | 0.00 | e7→[61c29bdb3ab6960e p.1] |  |
| s3.2 | s3 | keep | 1.00 | e8→[61c29bdb3ab6960e p.2] |  |
| s3.3 | s3 | gap |  |  | no evidence cited |
| s3.4 | s3 | gap |  |  | no evidence cited |
| s3.5 | s3 | gap |  |  | no evidence cited |
| s3.6 | s3 | keep | 1.00 | e8→[61c29bdb3ab6960e p.2] |  |
| s4.1 | s4 | keep | 1.00 | e5→[31cbf0d18f7d763e p.13] |  |
| s4.2 | s4 | keep | 1.00 | e6→[31cbf0d18f7d763e p.7] |  |
| s4.3 | s4 | keep | 1.00 | e6→[31cbf0d18f7d763e p.7] |  |
| s4.4 | s4 | keep | 1.00 | e6→[31cbf0d18f7d763e p.7] |  |
| s6.1 | s6 | gap |  |  | no evidence cited |
| s6.2 | s6 | keep | 1.00 | e12→[e42a4ef8cda58762 p.1] |  |
| s6.3 | s6 | keep | 1.00 | e13→[e42a4ef8cda58762 p.7] |  |
| s6.4 | s6 | gap |  |  | no evidence cited |
| s6.5 | s6 | gap |  |  | no evidence cited |
| s6.6 | s6 | keep | 1.00 | e13→[e42a4ef8cda58762 p.7] |  |
| s6.7 | s6 | gap |  |  |  |
| s7.1 | s7 | keep | 1.00 | e9→[ab1fd1dd637746ab p.2] |  |
| s7.2 | s7 | keep | 1.00 | e9→[ab1fd1dd637746ab p.2] |  |
| s7.3 | s7 | keep | 1.00 | e9→[ab1fd1dd637746ab p.2] |  |
| s8.1 | s8 | keep | 1.00 | e10→[64e3019755b942aa p.8] |  |
| s8.2 | s8 | keep | 1.00 | e11→[64e3019755b942aa p.8] |  |
| s8.3 | s8 | keep | 1.00 | e10→[64e3019755b942aa p.8] |  |
| s8.4 | s8 | gap |  |  |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [4cb98e07400203bf p.3 L105-107] keep (1.0): "8. Exclusivity. Talent represents and warrants that during the Term and in the Territories, Talent will not endorse or make any appearances or advertisements on behalf of any other product which is directly competitive to ESSI's products."
- e2 [4cb98e07400203bf p.5 L238-241] keep (1.0): "20. Severability. If any provision of this Agreement, as applied to either party or to any circumstance, shall be adjudged by a court of competent jurisdiction to be void or unenforceable, whether at law or in equity, then such determinatio…"
- e3 [23e65a3b8bc5cc9e p.25 L947-963] keep (1.0): "Section 11.3 Non-Competition and Non-Solicitation. (a) During the Term, except as otherwise provided in this Agreement, Network Affiliate and its affiliates agree not to engage or participate in any business, hold equity interests, directly…"
- e5 [31cbf0d18f7d763e p.13 L640-642] keep (1.0): "(e) Non-Compete. The Settlement Agreement and Mutual Release between *** and *** does not contain a covenant-non-compete applicable to *** and, to the best of PcoMed's current knowledge, *** is not subject to any covenant-non-compete that w…"
- e6 [31cbf0d18f7d763e p.7 L340-347] keep (1.0): "Neither PcoMed nor its Affiliates shall sell or offer for sale, or grant rights under the PcoMed Surface Modification Technology to any Third Party in the Field in the Territory for products that utilize or embody the PcoMed Surface Modific…"
- e7 [61c29bdb3ab6960e p.1 L1-5] drop (0.0): "EXCLUSIVE DISTRIBUTOR AGREEMENT"
- e8 [61c29bdb3ab6960e p.2 L98-105] keep (1.0): "3. Restriction on Promotion of Competing Products. During the term of this agreement, Distributor shall not market, sell advertise or promote the sale or use of any product or device which is competitive with or substantially similar to the…"
- e9 [ab1fd1dd637746ab p.2 L55-58] keep (1.0): "(v) prohibiting the endorsement by Racing and any members of Racing, including the drivers, of any entities, products or services which are in direct competition or otherwise inconsistent with the Sponsor or it products or services, unless …"
- e10 [64e3019755b942aa p.8 L359-364] keep (1.0): "This Agreement, including the Exhibits and Schedules hereto and the documents and other writings referred to herein or therein or delivered pursuant hereto, contains the entire agreement and understanding of the Parties with respect to its …"
- e11 [64e3019755b942aa p.8 L370-374] keep (1.0): "In the event that any one or more provisions of this Agreement shall for any reason be held invalid, illegal or unenforceable in any respect, by any court of competent jurisdiction, such invalidity, illegality or unenforceability shall not …"
- e12 [e42a4ef8cda58762 p.1 L1-9] keep (1.0): "# Cooperation Agreement
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2020-07-01 |
| Parties | e.l.f. Beauty, Inc. ("Company", "Party"); Marathon Partners Equity Management, LLC ("Marathon Partne…"
- e13 [e42a4ef8cda58762 p.7 L413-420] keep (1.0): "6. Mutual Non-Disparagement; No Public Statements.

(a) Subject to applicable law, the Company, on the one hand, and each of the Marathon Parties on the other hand, covenants and agrees that, during the Support Period or if earlier, until s…"
