"""Eval harness. golden.py loads questions; metrics.py computes retrieval/citation/cost
metrics; run.py executes a variant over the golden set and writes results.
"""
