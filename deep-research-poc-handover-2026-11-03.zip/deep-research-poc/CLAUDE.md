# deep-research-poc — project context for Claude Code

**Starting with no prior context? Read `HANDOVER.md` first.** Its §0.2 lists which status blocks in other files
are stale; it wins where they disagree.

Read this first. `PLAN.md` holds the phased implementation plan; `TODO.md` holds approaches
to explore later; this file holds the design decisions and invariants every change must respect.
`docs/findings.md` is the running log of experiments, measured numbers, model decisions and open
problems — read it before continuing any phase, and append to it after every live run or eval.
`eval/README.md` holds the eval tables; `docs/architecture.md` the one-page diagram.

## What we are building

A **deep-research feature** over a pre-filtered set of **500–1,000+ documents**. Upstream
metadata filtering has already happened; this project starts at "here is a list of documents
(markdown, already parsed from PDF) and their metadata" and must produce a cited research
report in **≤ 5 minutes wall-clock**.

We implement **three approaches in sequence** on one shared foundation, then compare them on
the same golden set:

- **Approach 2 — Materialized working set + filesystem agent** (built first; simplest).
  Documents are written to a per-query workspace as line-addressable markdown; one agent
  uses `grep` / `read` / `outline` / `list_docs` (+ optional sandboxed `bash`).
  Evidence: DCI 80% vs 69% for the same model with a dense tool; RISE 81–83% at 1M docs.
- **Approach 1 — Deep-list search loop.** Adds an **ephemeral per-query BM25** index,
  a cached 1,000-deep ranking the agent can `page_results()` through, and a **first move**
  (decompose the question into clues → retrieve per clue → union → optional rerank →
  opening observation). Evidence: Pi-Serini 83%; Question's Gambit +5.5–10.9 pts.
- **Approach 3 — Plan → parallel sub-agents → synthesize.** Planner-selected branch for
  breadth/enumeration questions: context-isolated researchers over doc batches or
  sub-questions, plus a parallel `extract` grid tool. Evidence: ~2× item recall on
  enumeration tasks; 3–10× tokens, so never the default.

Shared stages for all three: **evidence bank** in harness state → **outline-first,
fact-bound writer** → **tier-1 deterministic citation alignment** (+ tier-2 agentic check
later) → wall-clock deadline that forces synthesis from the bank.

```
docs (markdown + metadata)
  └─ materialize → workspace: docs/<doc_id>.md (line-addressable, page markers) + manifest.json (+ TOC)
       └─ [A1] first move → clues → grep/BM25 per clue → opening observation + cached deep ranking
            └─ route → single (A2/A1 loop) | breadth (A3 fan-out) | long_context (tiny evidence only)
                 └─ research → tools write verbatim quotes to the EVIDENCE BANK
                      └─ write → outline from question → sections from assigned evidence → {{CITE:e<n>}}
                           └─ verify → tier 1 n-gram alignment → tier 2 grouped agentic → appendix
```

## Inputs we have

- **Parsed markdown per document** (already done) and the **raw PDFs**.
- Document **metadata sits in the first ~2 pages of each markdown**. At materialize time we
  parse it into the manifest (`dr/ingest/metadata.py`) and *also* write it as a sidecar
  `meta.json` per document so the manifest loads without reading bodies. Decision in
  PLAN Phase 0: keep the in-body block as is, or move metadata to a sidecar / YAML front
  matter so body line numbers stay clean for citations (recommended: sidecar).
- Page markers `<!-- page N -->` are required for page-level citations. If the markdown
  lacks them, derive them from the PDFs (`dr/ingest/pages.py`, pymupdf) — Phase 0 task.

## Models and endpoints — the only ones available

| Role | Model | Why |
|---|---|---|
| planner / router / researcher | **GPT-OSS** (120B preferred; 20B fallback) | strongest tool-caller of the three; native multi-tool calls; `reasoning_effort` knob |
| extractor (grid), tier-2 verifier groups, first-move helper | **Nemotron Nano** | cheap, fast, tool-calling capable; runs in parallel over many docs |
| writer / outline / judge (no tools needed) | **Gemma** | prose quality; confirm whether its endpoint supports the OpenAI `tools` param — if not, it stays tool-free |

All three are reached as **OpenAI-compatible endpoints** via `dr/llm.py::get_llm(role)`
(`ChatOpenAI(base_url=..., model=...)`; swap to `ChatNVIDIA` if served by NIM). Nothing
else in the codebase names a model. Expect lower absolute accuracy than frontier-model
papers; the harness carries more of the load (FinanceHarness: harness +7.1, RL +0.4).

**No embedding endpoint** → Approach 1's deep list is BM25-only unless a local
sentence-transformers model is permitted (`TODO.md`). Optional local cross-encoder
reranker likewise.

Small-model rules: ≤ 6 tools exposed per agent, flat JSON schemas, structured outputs via
pydantic with one JSON-repair retry, programmatic control flow in LangGraph rather than
free-form agency wherever possible, per-turn width instruction, minimum-calls floor.

## Hard constraints

- **No knowledge graphs, no GraphRAG.** Do not add them, even as an optional layer.
- **No persistent index.** An ephemeral, in-memory BM25 built per query (seconds) is a tool,
  not infrastructure, and is the only index allowed.
- **No model training.**
- **5-minute budget**, enforced by a deadline that forces report synthesis from the bank.
- Regulated domain: **every claim traceable to a verbatim span**; unverifiable claims are
  dropped or flagged, never silently kept.
- Prototype runs in a **Jupyter notebook**; code lives in `src/dr`; notebooks only orchestrate.

## Frameworks (decided)

- **`langgraph`** — orchestration for all three approaches (ReAct loop, `Send` fan-out,
  state, deadline, retries).
- **`langchain-core`, `langchain-openai`** (or `langchain-nvidia-ai-endpoints`) — tools,
  messages, chat clients for the OpenAI-compatible endpoints.
- **`deepagents`** — optional for Approach 3 (sub-agents + virtual FS + todos). Tuned for
  Claude-class models; validate with GPT-OSS before depending on it (see `TODO.md`).
- **LlamaIndex** — not required; do not run two orchestrators. Its Retrieval Harness
  (grep/read tools) is tied to LlamaParse. Keep only for ingestion utilities if the team prefers.
- Work libraries: `bm25s`, `rapidfuzz`, `pydantic`, `ripgrep` (optional; pure-Python
  fallback mandatory), `pymupdf` (page markers only), `datasketch` (provenance, later).
- Internal agent SDK: an **adapter target** for the tools in `dr/tools/registry.py`, nothing more.

## Invariants — do not violate

1. **Whole documents never enter model context.** `read` returns capped, line-numbered
   windows; `grep` returns counts + capped hits with short context; `list_docs` returns
   compact rows. Tool results above `OFFLOAD_TOKENS` go to a file with a pointer.
2. **Tools are scoped to the workspace.** No path escapes, no network.
3. **Evidence is harness state, not transcript.** Verbatim quotes with `doc_id`, page, line
   range in the `EvidenceBank` (JSONL in the workspace). The writer reads the bank, never
   the chat history. Compaction is a lossy safety net.
4. **Every report sentence binds to evidence IDs** (`{{CITE:e<n>}}`) at construction time.
   A sentence without a marker is a flagged coverage gap, not an invention.
5. **Tier-1 verification is deterministic** (5-gram alignment, threshold 0.7). LLM judgment
   is tier 2, runs on claim groups, and never overrides a tier-1 drop.
6. **Framework-agnostic tools.** Logic in plain functions with pydantic schemas
   (`dr/tools/*`); adapters in `registry.py`. No retrieval logic inside framework classes.
7. **Single agent with parallel tool calls is the default.** Fan-out is planner-selected for
   breadth only, with a strict contract (narrow sub-question or doc batch, injected doc_ids,
   call budget, schema-validated `Finding` ≤ 1.5K tokens).
8. **Counts, not booleans.** `grep` returns per-doc counts; `read` returns `already_read`
   at zero cost via the read tracker.
9. **Deterministic tests for every tool** on `data/sample_docs`, no model calls. Agent
   behavior is measured by the eval harness, not unit tests.
10. **Budgets are explicit** in `dr/config.py` and passed down; nothing hard-codes a limit.
11. **One model-naming point.** Only `dr/llm.py` knows endpoint URLs and model ids.

## Conventions

- `doc_id` is stable and opaque (hash of source path + content). Page markers are exactly
  `<!-- page N -->` on their own line. `Workspace.page_of(doc_id, line)` maps line → page.
- Citations render as `[doc_id p.N]`; internally they are evidence IDs `e<n>`.
- Prompts live in `prompts/*.md`, loaded by name; no prompt strings inline in code.
- Every stage emits a trace event (`dr/trace.py`): tokens, latency, tool, args hash. This is
  the audit log.
- `pytest -q` before committing. Notebooks import from `dr`, call, inspect.

## Things we decided NOT to do (and why)

- One long-context pass over the whole subset: multi-hop accuracy degrades with topically
  similar distractors; no cacheable prefix. Router branch only for evidence < ~100K tokens.
- Rerank to a top-20 and hand that to the agent: SOTA pages a 1,000-deep list and reads
  full documents; the reranker belongs in the first move.
- Pre-summarize documents into context: AutoCompaction-style baselines score near zero.
- Librarian-Agents offline curation: needs RL; break-even ~30 queries per partition (TODO).
- Multi-agent by default: 3–10× tokens for ≤ 5 points on single-answer questions.

## Evidence behind the design

`docs/research/Agentic retrieval at million doc scale.md` and
`docs/research/Deep research SOTA for private corpora.md` (Oct 2026). Cite these when a design
question comes up rather than re-deriving the argument.
