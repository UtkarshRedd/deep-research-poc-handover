<!-- page 1 -->
# Endorsement Agreement
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 1996-01-01 |
| Parties | Teardrop Putter Corporation ("TPC"); Consolidated Artists Inc. ("Consolidated Artists") |
| Source | CUAD v1 / TEARDROPGOLFCO_10_23_1996-EX-10.12-ENDORSEMENT AGREEMENT |

EXHIBIT 10.12

ENDORSEMENT AGREEMENT

This Endorsement Agreement is made and entered into this first (1st) day of January, 1996, by and
between Teardrop Putter Corporation having its principal office at 207 WatersEdge, Shelter Cove,
Hilton Head Island, South Carolina 29928 (hereinafter referred to as "TPC"), and Consolidated
Artists Inc., Sommerville House, Phillips Street, St. Helier, Jersey JE1 1DE, Channel Islands,
British Isles (hereinafter referred to as "Consolidated Artists").

WITNESSETH:

WHEREAS, Brett Ogle (hereinafter referred to as "Ogle") is recognized and widely known throughout
the world as an expert golfer; and

WHEREAS, Ogle's name, by virtue of his ability and extensive experience, has acquired a secondary
meaning in the mind of the purchasing public important to the advertisement, promotion and sale of
golf putters; and

WHEREAS, TPC is engaged in the manufacture, distribution and sale of golf putters, and is desirous
of acquiring the exclusive right to utilize Ogle's name in connection with the advertisement,
promotion and sale of the Teardrop Putter; and

WHEREAS, Consolidated Artists holds all rights to and in Ogle's name and endorsement for purposes of
this Agreement; and

WHEREAS, Consolidated Artists being exclusively entitled to such rights within the Contract
Territory (as hereinafter defined)

- 2 -

has agreed to authorize such use upon the terms and conditions hereinafter contained;

NOW, THEREFORE, for and in consideration of the premises and mutual covenants herein set forth and
for other good and valuable consideration, it is agreed as follows:

1. DEFINITIONS: As used herein, the terms set forth below shall be defined as follows:

(a) "Ogle Endorsement" shall mean the name, likeness, photograph, and endorsement of Ogle.

(b) "Endorsed Product" shall mean a putter manufactured, distributed, promoted, advertised and sold
by TPC bearing the "Teardrop Putter" name and/or logo.

(c) "Contract Territory" shall mean the entire world.

(d) "Contract Period" shall mean that period of time commencing January 1, 1996, and concluding
December 31, 1998, unless sooner terminated in accordance with the terms and conditions hereof.

(e) "Contract Year" shall mean that twelve (12)month period of time commencing each first (1st) day
of January throughout the Contract Period.

(f) "Major Tournament" shall mean any of the following tournaments: the Masters, the U.S. Open, the
British Open and the PGA Championship.

- 3 -

(g) "PGA Tour Tournament" shall mean PGA Tour tournaments, excluding the Major Tournaments.

(h) "International Tournament" shall mean European PGA Tour tournaments (excluding the British
Open),Japan PGA Tour tournaments and Australian PGA Tour tournaments.

2. OGLE TO USE ENDORSED PRODUCT. Consolidated Artists agrees to cause Ogle to use the Endorsed
Product during the Contract Period and throughout the Contract Territory whenever he is playing
competitive golf or otherwise participating in golf clinics and outings.

3. GRANT OF ENDORSEMENT RIGHTS. Subject to the terms and conditions set forth herein, Consolidated
Artists grants to TPC the exclusive right and license, within the Contract Territory and during the
Contract Period, to use the Ogle Endorsement in connection with the manufacture, distribution,
advertisement, promotion and sale of the Endorsed Product.
<!-- page 2 -->
4. CLOTHING IDENTIFICATION. Consolidated Artists agrees to cause Ogle to wear a patch and/or an
embroidered non-patch bearing the Teardrop name and/or logo on the right chest, left sleeve, and
back of his golf shirt and/or sweater (near the collar) and/or rain gear whenever he is playing
competitive golf, participating in golf clinics and outings or otherwise engaging in golf
promotional activities during the Contract Period and throughout the Contract Territory. The
expenses for the clothing and placement of the

- 4 -

patch and/or embroidered non-patch shall be borne by TPC. TPC agrees to supply Consolidated Artists
or its designee with adequate quantities of said patch and embroidered non-patch at no charge to
Consolidated Artists.

5. RETENTION OF ENDORSEMENT RIGHTS. Subject to the provisions of Paragraphs 2, 3 and 4 above, TPC
agrees that Consolidated Artists shall retain all rights in and to the Ogle Endorsement and shall
not be prevented from using or permitting or licensing others to use his name or endorsement in
connection with the promotion, advertisement, or sale of any product or service other than a golf
putter in the Contract Territory during the Contract Period. TPC further agrees that upon the
termination of this Endorsement Agreement for any cause whatsoever, it will cease using the Ogle
Endorsement, the name "Brett Ogle," or any facsimile thereof, for any promotional or advertising
purposes; provided, however, that TPC shall have the right to use the Ogle Endorsement in
advertisements for ad space purchased by TPC prior to the termination of this Agreement for a period
of up to six (6) months following such termination. In this connection, TPC shall provide
Consolidated Artists with a list of such previously purchased ad space within seven (7) days of the
effective date of termination and all such advertisements released after the effective date of
termination shall be subject to Consolidated Artists' prior approval pursuant to the terms of
Paragraph 7 below.

- 5 -

6. PHOTOGRAPH SHOOTS; PERSONAL APPEARANCES. Consolidated Artists agrees, if requested by TPC, to
make Ogle available for one (1) day on behalf of TPC in each Contract Year during the Contract
Period at times and places mutually convenient to Ogle and TPC for the purpose of taking still
photographs for the preparation and production of advertising and promotional materials. TPC agrees
that such photograph shoots shall not exceed five (5) hours each in duration. Further, Consolidated
Artists agrees, if requested by TPC, to make Ogle available for two (2) personal appearance days on
behalf of TPC in each Contract Year during the Contract Period at times and places mutually
convenient to Ogle and TPC. Such personal appearances shall be limited to one (1) day and shall not
exceed five (5) hours each in duration. In addition, TPC agrees to pay all reasonable and necessary
expenses (including first class travel, hotel accommodations and meal expenses) incurred by
Consolidated Artists in connection with such photograph shoots and personal appearances.

7. PROMOTIONAL AND ADVERTISING MATERIALS. TPC agrees to provide Consolidated Artists and its
representative, Advantage International Management, Inc. ("Advantage"), with a copy of all
advertising and promotional materials which will use or show the Ogle Endorsement for their
approval. Such promotional or advertising materials shall be delivered to Advantage at least
fourteen (14) days prior to their release to the general public, and TPC agrees that the same shall
not be released without the

- 6 -

prior written approval of Advantage. Advantage agrees that it will not unreasonably disapprove or
reject promotional or advertising materials hereunder, and that Advantage's failure to disapprove
such materials within fourteen (14) days of receipt shall be deemed to be approval. In addition, TPC
agrees to provide Consolidated Artists with complimentary duplicates of all promotional and/or
advertising materials featuring Ogle or the Ogle Endorsement.

8. RETAINER FEE. In consideration of the rights and benefits granted to TPC hereunder, TPC agrees to
pay Consolidated Artists on behalf of Ogle a retainer fee in each Contract Year during the Contract
Period ("Retainer Fee") in accordance with the following schedule:

CONTRACT YEAR RETAINER FEE

First (1st) Contract Year Fifty-Five Thousand U.S. (Jan. 1, 1996-Dec. 31, 1996) Dollars ($55,000)

Second (2nd) Contract Year Seventy Thousand U.S. (Jan. 1, 1997-Dec. 31, 1997) Dollars (70,000)

Third (3rd) Contract Year Ninety Thousand U.S. (Jan. 1, 1998-Dec. 31, 1998) Dollars ($90,000)

Said Retainer Fee shall be paid in four (4) equal installments on or before the first (1st) day of
February, May, August and November in each Contract Year.

9. TOURNAMENT BONUSES. In addition to the Retainer Fee set forth in Paragraph 8 above, TPC agrees to
pay Consolidated Artists on behalf of Ogle the
<!-- page 3 -->
following tournament bonuses for Ogle's

- 7 -

tournament performances during the Contract Period (the "Tournament Bonus or Bonuses"):

(a) Sixty Thousand U.S. Dollars ($60,000), each time Ogle wins a Major Tournament; and

(b) Twenty Thousand U.S. Dollars ($20,000), each time Ogle wins a network televised US PGA Tour
Tournament; and

(c) Ten Thousand U.S. Dollars ($10,000) each time Ogle wins a cable televised US PGA Tour
Tournament; and

(d) Seven Thousand Five Hundred U.S. Dollars ($7,500) each time Ogle wins a Golf Channel televised
US PGA Tour Tournament or a Golf Channel televised International Tournament; and

(e) Five Thousand U.S. Dollars ($5,000) each time Ogle wins an International Tournament not
televised by Golf Channel or a non-televised US PGA Tour Tournament.

TPC shall pay any Tournament Bonuses due Consolidated Artists for a Major Tournament win within
sixty (60) days following TPC's receipt of an invoice from Consolidated Artists or Advantage and any
Tournament Bonuses due Consolidated Artists for a network televised US PGA Tour Tournament win shall
be paid within forty-five (45) days following TPC's receipt of an invoice from Consolidated Artists
or Advantage. All other Tournament Bonuses due to Consolidated Artists shall be paid by TPC within
thirty (30) days following TPC's receipt of an invoice from Consolidated Artists or Advantage.

- 8 -

10. MONEY LIST BONUS(ES). In addition to the Retainer Fee and the Tournament Bonuses set forth in
Paragraphs 8 and 9 above, TPC agrees to pay Consolidated Artists on behalf of Ogle the following
bonuses in each Contract Year for Ogle's position on the Official Year-End PGA Tour Money List
("Money List Bonus(es)"):

(a) Fifty Thousand U.S. Dollars ($50,000) each time Ogle finishes in first (1st) place on the
Official Year-End PGA Tour Money List; and (b) Twenty-Five Thousand U.S. Dollars ($25,000) each time
Ogle finishes between second (2nd) and tenth (10th) place on the Official Year-End PGA Tour Money
List; and

(c) Fifteen Thousand U.S. Dollars ($15,000) each time Ogle finishes between eleventh (11th) and
twentieth (20th) place on the Official Year-End PGA Tour Money List; and

(d) Seven Thousand Five Hundred U.S. Dollars ($7,500) each time Ogle finishes between twenty-first
(21st) and thirtieth (30th) place on the Official Year-End PGA Tour Money List; and

(e) Five Thousand U.S. Dollars ($5,000) each time Ogle finishes between thirty-first (31st) and
fortieth (40th) place on the Official Year-End PGA Tour Money List.

TPC shall pay any Money List Bonuses due to Consolidated Artists within thirty (30) days following
TPC's receipt of an invoice from Consolidated Artists or Advantage.

- 9 -

11. ROYALTY COMPENSATION FOR ENDORSED PRODUCT. In addition to the Retainer Fee, Tournament Bonuses
and Money List Bonuses set forth in Paragraphs 8, 9 and 10 above, TPC agrees to pay Consolidated
Artists on behalf of Ogle royalty compensation of ten percent (10%) of the net sales of all Endorsed
Products distributed or sold during the Contract Period in or to the Countries of Australia and New
Zealand ("Royalty Compensation"). "Net sales" shall mean the gross invoice price billed to
customers, less customary trade/quantity discounts, rebates and returns actually credited, but with
no deductions of any kind. No costs incurred by TPC in the manufacture, advertisement, promotion or
exploitation of any Endorsed Product shall be deducted as a cost in calculating the net sales. TPC
agrees to guarantee to Consolidated Artists on behalf of Ogle a minimum Royalty Compensation of
Twenty Thousand U.S. Dollars ($20,000) payable in four (4) equal installments of Five Thousand U.S.
Dollars ($5,000) and due simultaneously with the Retainer Fee on or before the first (1st) day of
February, May, August and November in each Contract Year.

12. PAYMENT OF ROYALTY COMPENSATION. Within thirty (30) days of the conclusion of each three (3)
month period in each Contract Year during the Contract Period, TPC agrees to deliver to Consolidated
Artists and Advantage an
<!-- page 4 -->
itemized statement setting forth the actual number of all Endorsed Products distributed and sold
during the preceding three (3) month period. Simultaneous with the delivery of each statement
setting forth such totals, TPC

- 10 -

agrees to pay Consolidated Artists the appropriate Royalty Compensation in excess of the $5,000
quarterly payment set forth in Paragraph 10 above, due on the sales of the Endorsed Product for the
period covered by such statement.

13. ACCOUNTING FOR ROYALTY COMPENSATION. TPC agrees that it shall keep accurate and complete books
and records showing all Endorsed Products manufactured, distributed and sold. Consolidated Artists
and Advantage, at Consolidated Artists' expense, shall have the right during the Contract Period and
until two (2) years after the termination of this Agreement to inspect and make copies of the books
and records of TPC insofar as they relate to the computation of royalty payments due and owing to
Consolidated Artists hereunder.

14. PAYMENTS TO CONSOLIDATED ARTISTS. All payments to be made to Consolidated Artists pursuant to
the terms hereof shall be made by wire transfer in U.S. Dollars to the following account:

Account Name: Advantage International Escrow Fund Account #: 20068160-13 ABA #: 054001547 Bank Name:
Franklin National Bank of Washington Address: 1722 Eye Street Washington, D.C. 20006 U.S.A. Re:
Consolidated Artists

15. MINIMUM PLAY REQUIREMENT. TPC shall have the right to prorate the Retainer Fee due Consolidated
Artists upon fourteen (14) days written notice to Consolidated Artists or Advantage in the event
Ogle fails to play a minimum of seventeen (17) U.S. PGA

- 11 -

Tour Events and the British Open in each Contract Year during the Contract Period.

16. TIME OF THE ESSENCE. TPC acknowledges that time is of the essence in the payment of all
compensation due Consolidated Artists hereunder. For the purposes of this Agreement, all payments
not received within thirty (30) days of the date due shall be deemed "past due". Such past due
payments shall bear interest at a rate of two percent (2%) per month OR the maximum rate permissible
by law, whichever is less. The imposition of interest provided for in this Paragraph shall be in
addition to any other remedies available to Consolidated Artists under this Agreement or otherwise.
Accordingly, Consolidated Artists shall not be precluded from exercising any other remedies, whether
at law or in equity, to enforce the terms of this Agreement.

17. SPECIAL RIGHT OF NEGOTIATION AND TERMINATION. If at any time during the Contract Period Ogle
determines that he no longer desires to use the Endorsed Product Consolidated Artists shall so
notify TPC in writing and the parties shall meet and negotiate in good faith an amicable solution.
Such discussion shall take place within fourteen (14) days of Consolidated Artists' notice and shall
include such issues as Ogle's continued use of the Endorsed Product, the continued use of the Ogle
Endorsement and the termination of this Agreement. If no solution is reached within fourteen (14)
days of such negotiation, the parties agree that this Agreement shall automatically terminate and
that TPC will cease

- 12 -

using the Ogle Endorsement, the name "Brett Ogle," or any facsimile thereof, for any promotional or
advertising purposes in accordance with the terms set forth in Paragraph 5 above. In addition, TPC
agrees that Consolidated Artists shall be entitled to the Retainer Fee prorated to the effective
date of termination as well any Tournament Bonuses, Money List Bonuses and any Royalty Compensation
earned by Consolidated Artists prior to the effective date of termination.

18. PRODUCTS FOR OGLE'S USE. During the Contract Period, TPC shall supply Consolidated Artists, at
no charge, with such quantities of the Endorsed Product as Consolidated Artists may reasonably
request for Ogle's use and the personal use of Ogle's immediate family. In addition, TPC shall
supply Consolidated Artists at normal wholesale price with such quantities of the Endorsed Product
as Ogle may reasonably request for gifts to others.

19. PROTECTING THE OGLE ENDORSEMENT. TPC and Consolidated Artists agree that they will take all
necessary steps during the Contract Period and thereafter to protect the Ogle Endorsement, the name
"Brett Ogle" or any facsimile thereof in connection with the advertisement, promotion, distribution
and sale of the Endorsed Product.
<!-- page 5 -->
20. TERM OF AGREEMENT. The term of this Agreement shall commence January 1, 1996, and shall continue
for a period of three (3) years, concluding December 31, 1998.

- 13 -

21. SPECIAL RIGHT OF TERMINATION BY CONSOLIDATED ARTISTS. Consolidated Artists shall have the right
to terminate this Agreement upon thirty (30) days prior written notice to TPC in the event of the
occurrence of any of the following contingencies:

(a) If TPC is adjudicated as insolvent, declares bankruptcy or fails to continue its business of
selling the Endorsed Product; or

(b) If TPC fails to make payment to Consolidated Artists of any sums due pursuant to this Agreement
within thirty (30) days following the date such payment is due hereunder, provided that TPC is
notified in writing of such nonpayment by Consolidated Artists or Advantage and such payment is not
made within ten (10) days following such notification.

TPC agrees that such termination shall not relieve it of its obligation to pay Consolidated Artists
all compensation contemplated hereunder. Accordingly, Consolidated Artists shall not waive any of
its rights at law or in equity.

22. SPECIAL RIGHT OF TERMINATION BY TPC. TPC shall have the right to terminate this Agreement upon
thirty (30) days prior written notice to Consolidated Artists or Advantage in the event of the
occurrence of any of the following contingencies:

(a) In the event of 0gle's death during the Contract Period; or

- 14 -

(b) In the event Ogle is convicted of a felony involving moral turpitude.

In the event of such termination above, the parties agree that the Retainer Fee due Consolidated
Artists shall be prorated to the effective date of termination. Furthermore, TPC agrees that any
Tournament Bonuses, Money List Bonuses and any Royalty Compensation earned by Ogle prior to the
effective date of termination shall be paid in full within thirty (30) days of such effective date
of termination.

23. INDEMNITY. TPC agrees to protect, indemnify and hold harmless Consolidated Artists and Ogle from
and against any and all expenses, damages, claims, suits, actions, judgments and costs whatsoever,
including attorneys' fees, arising out of, or in any way connected with, any claim or action which
arises from the use of the Endorsed Product, the use of the Ogle Endorsement, or the performance of
Consolidated Artists' and Ogle's obligations hereunder.

24. WAIVER. The failure of TPC or Consolidated Artists at any time or times to demand strict
performance by the other of any of the terms, covenants or conditions set forth herein shall not be
construed as a continuing waiver or relinquishment thereof and either may at any time demand strict
and complete performance by the other of said terms, covenants and conditions.

25. ASSIGNMENT. Neither TPC nor Consolidated Artists shall have any right to grant sublicenses
hereunder or to otherwise

- 15 -

assign, transfer, alienate, encumber or hypothecate any of its rights or obligations hereunder
without the express prior written consent of the other party, except that Consolidated Artists shall
have the right to assign the financial benefits hereof and TPC hereby consents to such assignment.

26. NOTICES. All notices required hereunder shall be sent by telefax, overnight mail or first class
mail, return receipt requested, as appropriate, to the parties at the following addresses:

TPC Mr. Fred A. Hochman President Teardrop Putter Corporation 207 WatersEdge, Shelter Cove Hilton
Head Island, South Carolina 29928

Consolidated Consolidated Artists, Inc. Artists Sommerville House Phillips Street St. Helier Jersey
JE1 1DE Channel Islands British Isles

cc: Advantage International Management, Inc. 1751 Pinnacle Drive Suite 1500 McLean, Virginia 22102
Attention: Mr. Peter Roisman
<!-- page 6 -->
Advantage and TPC shall promptly notify each other in writing of any change of address.

27. EMPLOYER/EMPLOYEE RELATIONSHIP. Nothing contained in this Agreement shall be construed as
establishing an employer/employee relationship between TPC and Consolidated Artists. Accordingly,
there shall be no withholding for tax

- 16 -

purposes from any payments due hereunder to Consolidated Artists by TPC.

28. GOVERNING LAW. This Agreement shall be governed by and construed in accordance with the laws of
the Commonwealth of Virginia applicable to contracts entered into and wholly to be performed within
the Commonwealth of Virginia and, in the event of any litigation arising out of this Agreement,
venue shall be the Commonwealth of Virginia. Should Consolidated Artists be required to institute
litigation due to TPC's breach of any terms of this Agreement, all costs of such litigation,
including reasonable attorneys' fees, shall be borne by TPC.

29. SIGNIFICANCE OF HEADINGS. Paragraph headings contained hereunder are solely for the purpose of
aiding in speedy location of subject matter and are not in any sense to be given weight in the
construction of this Agreement. Accordingly, in case of any question with respect to the
construction of this Agreement, it is to be construed as though such paragraph headings had been
omitted.

30. ENTIRE AGREEMENT. This Agreement constitutes the entire understanding between Consolidated
Artists and TPC, and cannot be altered or modified except by an agreement in writing signed by both
parties. Upon its execution, this Agreement shall supersede all prior negotiations, understandings
and agreements, whether oral or written, and such prior agreements shall thereupon be null and void
and without further legal effect.

- 17 -

IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be executed as of the date
first above written.

TEARDROP PUTTER CORPORATION

Date: 2-27-96 BY: /s/ Brian R. Hochman -------------------- -------------------------------- Brian
R. Hochman President

CONSOLIDATED ARTISTS, INC.

Date: 10-4-96 By: /s/ M. M. Murray -------------------- -------------------------------- Its: Ass
Secretary -------------------------------

GUARANTY

I, the undersigned, Brett Ogle, do hereby acknowledge that I have read the foregoing Agreement
between Teardrop Putter Corporation ("TPC") and Consolidated Artists, Inc. ("Consolidated Artists")
and am aware of the terms thereof. In this connection, I agree that I will be bound by the terms and
conditions of such Agreement and that I will be entitled to the rights and benefits set forth
therein, as fully as if I have been a party to such Agreement. Furthermore, in consideration of the
mutual covenants and conditions and as a material inducement to TPC to enter into said Agreement
with Consolidated Artists, I do hereby guarantee the performance of said Agreement by Consolidated
Artists. This guaranty shall only be effective upon the execution of the Agreement by Consolidated
Artists.

DATE: 3/28/96 /s/ Brett Ogle -------------------- ----------------------------------- BRETT OGLE
