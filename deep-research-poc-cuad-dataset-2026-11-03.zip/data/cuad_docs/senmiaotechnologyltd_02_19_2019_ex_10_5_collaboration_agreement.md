<!-- page 1 -->
# Collaboration Agreement
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2018-12-17 |
| Parties | Didi Chuxing Technology Co., Ltd. ("Party A"); Hunan Ruixi Financial Leasing Co., Ltd ("Party B"); Party A and Party B (individually referred to as a “Party” and collectively as the “Parties”) |
| Source | CUAD v1 / SENMIAOTECHNOLOGYLTD_02_19_2019-EX-10.5-Collaboration Agreement |

Contract No.: DDCX S DG KC 201812130044 Exhibit 10.5 Collaboration Agreement This Collaboration
Agreement (hereinafter referred to as this "Agreement") is made and entered into by and between the
following parties in Haidian District, Beijing. This Agreement may be executed in paper form offline
or in electronic form through the Didi Chuxing Online Contracting Platform (website:
https://Agreement.didichuxing.com/, hereinafter referred to as the "Contracting Platform"). The
Agreement executed offline in paper form shall become effective upon the completion of the execution
by both Parties (hereinafter referred to as the "Effective Date"); and the Agreement executed online
in electronic form shall become effective upon the completion of the execution on the Contracting
Platform by both Parties (hereinafter referred to as the "Effective Date") recorded by the
third-party Online Document Depository. Party A: Didi Chuxing Technology Co., Ltd. Legal
Representative: Ting Chen Party B: Hunan Ruixi Financial Leasing Co., Ltd Legal Representative:
Xianglong Li Party A and Party B shall be individually referred to as a "Party" and collectively as
the "Parties". Whereas 1. As a company providing third-party e-commerce platform services, and
desires to assist the Driver User (hereinafter referred to as the "Driver User") registered on the
platform to lease vehicles from Party B with the most favorable treatment in the market, so as to
reduce the cost of using vehicles for the Driver User; 2. Party B is an automobile leasing company,
with the qualification, resources and ability to carry out the automobile financial leasing
business, and it acknowledges and undertakes to implement the platform rules formulated by Party A;
3. Both Parties hope to clarify the cooperation contents, rights and obligations of each Party And
other matters through this Agreement. NOW, THEREFORE, the Parties hereto agree as follows: 1.
Definitions Unless otherwise stated, the following terms used in this Agreement shall have the
following meanings: 1.1 "Platform" refers to the third-party e-commerce platform operated by Party
A: Xiaoju Online Ride-Hailing Marketplace.
<!-- page 2 -->
Contract No.: DDCX S DG KC 201812130044 1.2 "Platform Rules" refers to normative documents related
to the platform noticed to Party B by Party A by E-mail or other means as well as the various
normative documents published on the platform such as the Regulations on Vehicle Rental Service
Business of Xiaoju Online Ride-hailing Marketplace and Code of Conduct and Risk Notification of
Vehicle Service Company. 1.3 "Didi" refers to Party A, Party A's Affiliates and their respective
software and platforms operated by them. 1.4 "Ride-hailing Vehicles" refers to the online
car-hailing vehicles. 1.5 "Ride-hailing Service" refers to the online non-peripatetic car hailing
service provided by certain entities through the service platforms based on Internet technology
using qualified vehicles and Driver Users, which integrates supply and demand information. 1.6
"Affiliates" refers to companies that have an affiliated relationship with each other, including,
but not limited to, the companies, firms, corporations or other organizations of such nature
established, participated in the establishment, operated, controlled by shareholders, legal
representative, actual controllers or directors, supervisors, etc. and their immediate family
members, collateral relatives within three generations, close relatives, etc. 1.7 "Senior
Management" refers to the officers defined in the Company Law of the People's Republic of China and
the chief executive officer, chief financial officer, supervisors, etc. in a company. 1.8 "Laws"
refers to laws, administrative regulations, local laws and regulations, autonomous regulations and
separate regulations promulgated by the competent authorities, rules and regulations of the
Ministries and Commissions of the State Council and local governments, judicial interpretations,
normative documents, etc. in China. 1.9 "Period of Cooperation" refers to the term of validity of
this Agreement. 1.10 "Confidential Information" refers to any oral or written materials and
information exchanged between the Parties in respect of this Agreement, including, but not limited
to, the following: 1.10.1 The content of this Agreement and its supplemental agreement(s); 1.10.2
The business (including, but not limited to, business decisions, management methods, operating
strategies, incentive strategies, promotional information), operating, financial, technical,
product, service information of any party obtained or received by the other party during the
performance of this Agreement or during the term of this Agreement; 1.10.3 The other party's user
profiles, information, etc.; 1.10.4 The processes and results of settlement of any dispute arising
from this Agreement 1.11 "Intellectual Property Rights" refers to: (a) patents and patent
applications; (b) trademarks, service marks, trade names, trade dress and domain names, and goodwill
exclusively attached thereto; (c) copyrights, including the copyrights of computer software and the
copyrights of the database; (d) secrets and proprietary information, including trade secrets and
technical secrets; and (e) any rights similar to subparagraphs (a)-(d) provided in any law, whether
or not any one of the foregoing has been applied for registration or registered. 1.12 "Personal
Injury Compensation" refers to the compensation provided in the Interpretation of the Supreme
People's Court on Several Issues Concerning the Application of Law in the Trial of Cases on Personal
Injury Compensation.
<!-- page 3 -->
Contract No.: DDCX S DG KC 201812130044 1.13 "Xiaoju online Ride-Hailing Marketplace SaaS System"
refers to the operation and management service system for Party B's vehicles developed by Xiaoju
online Ride-Hailing Marketplace. When Party B signs the Vehicle Operation Management Service
Agreement, it shall be deemed to be connected to the SaaS system of Xiaoju online Ride-Hailing
Marketplace. Party B is free to choose the following two types of services: One is the regular free
service of Xiaoju online Ride-Hailing Marketplace. One is the regular value-added charging service
of Xiaoju online Ride-Hailing Marketplace. 2. The Cooperation During the term of cooperation, Party
B shall, through the Platform provided by Part A, present to the Driver User the vehicle for rent
and financing and leasing solutions in line with this agreement between Party A and Party B and the
Platform Rules. Party B shall provide the Driver User with long-term and stable rental sources and
the most favorable financial leasing scheme, complete the vehicle leasing transactions with the
Driver User through the Platform, and provide the Driver User with high-quality financial leasing
services. 3. Rights and Obligations 3.1 Party A's rights and obligations: 3.1.1 Party A shall
maintain and operate the Platform in accordance with the available technology, so that the Platform
can operate normally, and Party B can use the Platform normally and conduct vehicle financial
leasing transactions with the Driver User smoothly. 3.1.2 Party A shall reply to problems
encountered by Party B during the registration in and use of the Platform in a timely manner. 3.1.3
Party A is entitled to inspect any information and materials submitted by Party B and the
information generated by the use of the Platform from time to time. In case any problem or question
is discovered in the aforesaid information or materials, Party A is entitled to take the following
measures: 3.1.3.1 To request Party B to submit more information or documentary evidence; 3.1.3.2 To
request Party B to correct such problem; 3.1.3.3 Removing commodities from the shelves and
temporarily shutting down some functions of the Platform account and other measures considered
necessary by Party A. 3.1.4 Party A is entitled to inspect the information released by Party B on
the Platform. If the information released by Party B contains the following information, Party A
may, without informing Party B, take restrictive measures such as deleting the information or
removing the commodities from the shelves: 3.1.4.1 Information unrelated to or not intended for a
vehicle leasing transaction;
<!-- page 4 -->
Contract No.: DDCX S DG KC 201812130044 3.1.4.2 False information that is misleading or exaggerating
the facts or inconsistent with the facts; 3.1.4.3 Information of malicious competition or other
information that may disrupt the normal transaction order of the Platform; 3.1.4.4 Information that
violates the Laws or the public interests or may harm the legitimate interests of the Platform
and/or other third parties. 3.1.5 During the cooperation, Party A shall have the right to inquire
relevant information of Party B through various channels and investigate Party B's background. If
the investigation results show that Party B has major business risks and other conditions, Party A
shall have the right to unilaterally terminate the cooperation if the assessment suggests that Party
A's reputation is sufficiently affected therefrom. 3.2 Party B's rights and obligations: 3.2.1 Party
B shall be entitled to use the Platform to publish commodities and its own information subject to
the compliance with this Agreement and the Platform Rules and prior approval by Party A. 3.2.2 Party
B shall guarantee the authenticity, legality, completeness, accuracy and validity of any materials
and information provided by it to Party A, and guarantee that such materials and information are in
compliance with this Agreement and the Platform Rules during the Period of Cooperation; and shall
guarantee the validity and security of the email address, telephone number, address, postal code,
etc., provided by it to Party A, and the successful contact by Party A or the Driver Users with
Party B through the aforementioned contact information. In case such materials or information or
contact information is changed or invalid, Party B shall notify Party A of the changed information
or the invalidity at least 3 working days in advance. 3.2.3 Party B guarantees that the vehicles
released and leased on the Platform shall meet the following conditions simultaneously: 3.2.3.1 Obey
the requirements of this agreement, Platform Rules, Laws; can drive on the road, and can be used to
engage in online Ride-hailing operation in the place where the leased vehicle is used; 3.2.3.2 The
vehicles are passenger cars that meet the Safety Specifications for Power-driven Vehicles Operating
on Roads (GB 7258-2012) and have less than 7 seats, including the driver's seat; 3.2.3.3 No
decorations, devices or equipment (except those required by law) have been installed, and there are
no other modifications or additions that may affect the safe operation of the vehicle or endanger
the personal and property safety of the vehicle drivers and passengers; 3.2.3.4 The engine has not
been replaced or adjusted in a way different from that of the factory, or the performance has been
substantially modified or installed (except those permitted by local laws and passed the safety
inspection of the traffic administrative department of the public security organ).
<!-- page 5 -->
Contract No.: DDCX S DG KC 201812130044 3.2.3.5 There is no any right defect or ownership dispute.
Party B is entitled to lease the vehicle to others in the form of financial leasing for the
operation of online Ride-hailing or other purposes. 3.2.4 Party B shall be obliged to verify the
actual use of the leased vehicles, assist and ensure that the Driver User purchases corresponding
insurance according to the actual use of the leased vehicles; if the leased vehicle is used for
online Ride- hailing operation, in case that the provisions of the local Laws on online Ride-hailing
insurance are changed within the term of cooperation or the provisions of the local Laws on online
Ride-hailing are officially implemented within the term of cooperation, Party B shall inform the
Driver User within 3 working days after the change of local Laws and regulations on Ride-hailing or
the effective implementation thereof, assist the Driver User and ensure that the insurance of the
leased vehicle shall be changed in accordance with the provisions of local Laws on ride-hailing to
make the insurance of the leased vehicle comply with the provisions of relevant Laws and regulations
on Ride-hailing at that time. 3.2.5 If the vehicle released by Party B on the Platform does not
comply with the Platform Rules or legal provisions irregularly updated, Party B shall notify the
Platform within 1 working day after the new Platform Rules or new Laws come into force and remove
the vehicle by itself. 3.2.6 When the vehicle leased by Party B is used by the Driver User to
provide online Ride-hailing Services on Didi platform, Party B shall try its best to cooperate with
Party A to conduct investigation and collect evidence and assist Party A to deal with relevant
matters in case of passenger complaints, traffic accidents or complaints received by Party A or
reports of Party B's behaviors in violation of this Agreement or platform rules. 3.2.7 Party B shall
ensure a long-term and stable supply of vehicles and give priority to meeting the rental needs of
the Driver User. 3.2.8 Party B shall complete automobile lease transactions with Driver Users
through the Platform, and enter into agreements with Driver Users by using the Financial Leasing
Agreement template provided by Party A. 3.2.9 Party B shall truthfully provide Party A with one
original copy of the Financial Leasing Agreement signed by and between Party B and the Driver User,
together with its annexes of Vehicle Handover List and Financial Leasing Confirmation Letter, etc.,
and shall upload the scanned copy to the Platform within 1 working day after the signing of the
Agreement. 3.2.10 Party B shall fulfill its rights and obligations to the Driver User who has signed
the Agreement with Party B by means of strictly following the template of Financial Leasing
Agreement and its annex provided by Party A. 3.2.11 Party B is entitled to collect a deposit from
the Driver User for the leased vehicle. The amount of the deposit shall be the same as or lower than
the amount of the deposit announced by Party B on the Platform, and the collected deposit shall be
less than RMB20,000 (RMB TWENTY THOUSAND ).
<!-- page 6 -->
Contract No.: DDCX S DG KC 201812130044 3.2.12 Party B shall ensure that the Driver User's down
payment, monthly rent, last payment, deposit (fee items shall not exceed the aforementioned items)
are collected only in accordance with the Financial Leasing Agreement, and the overall internal rate
of return (IRR) of the financial leasing scheme shall be kept within 25%. 3.2.13 In the cases that
Party B guarantees to sign the Financial Leasing Agreement with Party A's users, Party B will agree
on the provisions of terminating the Financial Leasing Agreement unilaterally by the Driver User in
advance with the Driver User according to the conditions or better conditions specified in Annex 2
Terms and Conditions for the Driver User to Terminate Financial Leasing Agreement in Advance, and
the relevant provisions shall at least comply with the following agreements: 3.2.13.1 Party B shall
clarify the logic and method for calculating the liquidated damages due to the unilateral
termination of the Financial Leasing Agreement by the Driver User; 3.2.13.2 After signing the
agreement with Party B, the Driver User is entitled to terminate the Financial Leasing Agreement 7
days in advance in the last week (7 natural days) of every three months. 3.2.13.3 In case that the
Driver User unilaterally terminates the Financial Leasing Agreement in advance, he/she does not need
to pay the remaining rent and the last payment; 3.2.13.4 In case that the Driver User unilaterally
terminates the Financial Leasing Agreement in advance, Party B shall collect the liquidated damages
from the Driver User within 30% of the "down payment + total monthly rent + last payment" stipulated
in the Financial Leasing Agreement; If major maintenance (maintenance fee is RMB3,000 or above) of
the leased vehicle occurs during the lease period, Party B may charge the depreciation expense of
the Driver User's rental of the vehicle in addition to the liquidated damages mentioned above, and
the depreciation expense for each time shall be less than 20% of the current maintenance fee.
(Depreciation expense can only be charged in that the Driver User unilaterally terminates the
Agreement in advance without paying the full amount to buy the vehicle.) 3.2.13.5 Party B shall
refund all the monthly rental paid by the Driver User in accordance with the Financial Leasing
Agreement and all the other expenses excluding that paid to the third party (e.g. vehicle purchase
tax, insurance premium, etc.). 3.2.13.6 Party B shall explain the conditions for the termination of
the Agreement to the Driver User, fully communicate to reach consensus, and obtain the signature
confirmation from the Driver User. 3.2.13.7 In case that Party B has different conditions for
termination of agreement for different types of vehicles, they shall all conform to the provisions
of this agreement, and the written consent of Party A shall be obtained in advance before they can
be applied to the Financial Leasing Agreement signed with the Driver User.
<!-- page 7 -->
Contract No.: DDCX S DG KC 201812130044 3.2.14 Where a traffic accident or other safety accident
occurs in a leased vehicle, Party B shall actively deal with relevant matters and settle insurance
claims. If the Driver User has paid the maintenance fee and personal injury compensation for the
leased vehicle caused by traffic accident or other safety accident, Party B shall pay full insurance
premium after deducting the expenses that the Driver User shall pay to Party B (if any) to the
Driver User within 1 working day after receiving the insurance compensation. 3.2.15 In case that the
vehicle leased by Party B to the Driver User is used for the online Ride-Hailing Service, where a
traffic accident or other safety accident occurs when a leased vehicle provides an online
Ride-Hailing Service, if passengers or other subjects in traffic accidents or safety accidents
(subjects other than the Driver User who rent vehicles and passengers) require the Driver User to
Compensate For Their Personal Injury, or if the Driver User fails to pay or is unable to pay while
the carriage Agreement losses, or if the passenger requests the Driver User or other subjects to
bear the carriage liability of the online Ride-hailing Service, Party B shall deal with these
situations timely, assume the carrier responsibility of leasing the vehicle which provides online
Ride-Hailing Service and pay the compensation in time; If it is the Driver User's responsibility,
Party B may recover it from the Driver User. 3.2.16 In case that the Driver User fails to pay the
monthly rent in full and on time as stipulated in the Financial Leasing Agreement, Party B shall
deal with it according to the following procedures: a notification shall be sent to the Driver User
to require the Driver User to pay the monthly rent within a reasonable time firstly. If the Driver
User refuses to correct and delays the payment of the monthly rent for more than 30 days, Party B
can take reasonable measures to recover the vehicle or terminate or waive the Financial Leasing
Agreement. 3.2.17 Party B guarantees that the Driver User will enjoy the most favorable treatment in
accordance with the terms and conditions stipulated in This Agreement during the Period of
Cooperation. In case that the price and other substantive terms offered by Party B to such entity
are more favorable than those enjoyed by the Driver User in any commercial cooperative relationship
signed or formed between Party B and any entity, the Driver User and Party B shall amend the
provisions in the Financial Leasing Agreement signed by both parties to enable the Driver User to
enjoy the same or more favorable provisions as those enjoyed by such other entities, such
modifications shall include but not limit to the modifications of the monthly rent terms. 3.2.18
Party B shall guarantee that after this agreement comes into force, Party B shall sign the Vehicle
Operation Management Service Agreement on the related platform of Party A (i.e. "Xiaoju online
Ride-Hailing Marketplace") and uniformly access to the SaaS system of Xiaoju online Ride-Hailing
Marketplace, otherwise, Party A is entitled to unilaterally terminate this agreement. 4. Deposit 4.1
Party B confirms that the deposit paid in accordance with this Agreement is a deposit for the
successful cooperation between Party B and Party A on the vehicle operational leasing business and
the vehicle financing leasing business to guarantee that Party B will fulfill its obligations under
this Agreement and the Cooperation Agreement signed by and between Party A and Party B regarding the
vehicle operational leasing business and the Platform Rules and Party B agrees that Party A may
deduct reasonable liquidated damages, overdue fines, compensations, etc. from the deposit when Party
B breaches this Agreement, or the above mentioned Cooperation Agreement or the Platform Rules. In
case that Party A deducts any amount from the deposit, it shall issue a corresponding receipt to
Party B.
<!-- page 8 -->
Contract No.: DDCX S DG KC 201812130044 4.2 During the period of cooperation, Party B shall pay the
deposit in accordance with the following rules: For each payment of RMB 100,000, Party B can list up
to 100 vehicles on Party A's platform (for example, if Party B wishes to list 275 vehicles, it shall
pay RMB 300,000. A deposit of RMB300,000 permits Party B to list up to 300 (included) vehicles on
Party A's platform. 4.3 Party B shall first pay a deposit of RMB100,000 to Party A within 5 working
days after the signing of this Agreement. For list more products, Party B shall apply to Party A 3
working days in advance and after obtaining the consent of Party A, pay the deposit in full within 5
working days from the date of receipt of the deposit notice from Party A. 4.4 If Party B shall pay
liquidated damages for breach of this Agreement or violation of the platform rules, Party A is
entitled to request Party B to pay the liquidated damages. If Party B refuses or fails to pay, Party
A is entitled to deduct the corresponding amount from the deposit. In this case, Party B shall pay
additional deposit equivalent to the liquidated damages when it pays the liquidated damages. For
example, if Party B shall pay liquidated damages as much as RMB N, it shall pay additional RMB N to
increase the deposit paid in accordance with Article 4.2 after it pays the liquidated damages or
Party A deducts the liquidated damages from the deposit. 4.5 If Party B shall increase the deposit
in accordance with this Agreement, it shall pay the additional deposit in full within 5 working days
from the date of receipt of Party A's deposit payment notice. If Party B's deposit is deducted in
whole or in part due to Party B's breach of this Agreement or other reasons, Party B shall replenish
the deposit within 5 working days from the deduction date of the deposit as well as pay the
additional deposit in full in accordance with Article 4.4. 4.6 If Party B fails to pay, increase or
replenish the deposit in accordance with this Agreement, Party A shall have the right to charge a
penalty as much as 1‰ of the unpaid amount for each day. If Party B fails to pay, increase or
replenish the deposit in full within 15 days after the expiration of the payment period specified in
this Agreement, Party A shall have the right to terminate this Agreement unilaterally. 4.7 After
Party B terminates or rescinds this Agreement, if there is no effective Vehicle Lease Agreement
between Party B and a Driver User (if the operational leasing business is conducted) and there is no
dispute on the vehicle lease between Party B and a Driver User, Party A shall refund the remaining
deposit to Party B on a interest-free basis within 30 days after receipt of the deposit receipt
returned by Party B; if there is any effective Vehicle Lease Agreement between Party B and a Driver
User or if there is any disputes on the vehicle lease between Party B and a Driver User, Party A
shall refund the remaining deposit to Party B on a interest-free basis within 30 days after receipt
of the deposit receipt returned by Party B after the driver confirms the Vehicle Lease Agreement has
been fulfilled or the dispute has been resolved.
<!-- page 9 -->
Contract No.: DDCX S DG KC 201812130044 5. Taxes The taxes incurred by the Parties hereto due to the
performance of this Agreement shall be borne by the Parties respectively. 6. Intellectual Property
Rights Party A has exclusive rights and interests in all rights, ownership, titles, interests and
intellectual property rights arising from or created by the performance of this Agreement. 7.
Confidentiality 7.1 Each party shall maintain the confidentiality of all confidential information
and shall not disclose any confidential information to any third party without the prior written
consent of the other party, except for the information which (a) is or will be known by public (not
caused by the disclosure to the public by the receiving party); (b) is required to be disclosed by
the applicable law or any securities exchange rules or regulations; (c) is necessary to be disclosed
to the counsels or financial consultants by either party in respect of the transaction under this
Agreement, and such counsels or financial consultants are bound by similar confidentiality
obligations hereunder. Disclosure of any confidential information by an employee or agency employed
by either party shall be deemed to be a disclosure of such confidential information by that party,
and the party shall be liable for breach of this Agreement. This provision shall survive any change
or the termination of this Agreement for any reason. 7.2 Without the written consent of Party A,
Party B shall not disclose the relevant information of Party A or Party A's Driver Users obtained by
Party B due to this Agreement or the cooperation hereunder to any third parties (including but not
limited to disclosing the cooperation content to any media, website, WeChat Official Account and
other promotional channels or making false propaganda and report), or Party A is entitled to
unilaterally cancel the cooperation and pursue Party B's liability for breach of the Agreement
according to the actual loss. 8. Representations and Warranties 8.1 Party A represents and warrants
as follows: 8.1.1 Party A is a company duly incorporated and validly existing under the Laws of
China; 8.1.2 The execution and performance of this Agreement by Party A is within the scope of its
corporate capacity and its business scope approved by and registered with competent authorities;
Party A has taken necessary corporate actions and has been duly authorized and has obtained the
consent and approval from third parties and governmental agencies, and will not be in violation of
any Laws or other restrictions binding upon Party A. 8.1.3 This Agreement constitutes the legal,
valid and binding obligations of Party A and may be enforced in accordance with its terms.
<!-- page 10 -->
Contract No.: DDCX S DG KC 201812130044 8.2 Party B represents and warrants as follows: 8.2.1 Party
B is a company duly incorporated and validly existing under the Laws of China; 8.2.2 The registered
capital of Party B is more than RMB5 million (FIVE MILLION) 8.2.3 Party B is in good standing and
has not been included in the Lists of Enterprises with Abnormal Operations and the List of
Enterprises with Serious Illegal and Dishonest Acts; 8.2.4 Party B's signing and performance of this
Agreement is within the permissive scope registered by virtue of its legal personality (the
administrative license for or filing of the business scope has been obtained or completed if
required); Party B has taken necessary corporate actions and has been duly authorized and has
obtained the consent and approval from third parties and governmental agencies, and will not be in
violation of any laws or other restrictions binding upon Party B. 8.2.5 This Agreement constitutes
the legal, valid and binding obligations of Party B and may be enforced in accordance with its
terms. 9. Termination 9.1 In the following cases, either party may terminate this Agreement
immediately by written notice to the other party, and this Agreement shall terminate as of the date
on which such party gives such written notice of termination: 9.1.1 The other party ceases to carry
on business or goes into liquidation (other than voluntary liquidation for the purpose of
reorganization or combination of bona fide bankruptcy with prior written consent of such party) or
dissolution; 9.1.2 The other party is unable to pay its debts as they become due, or has a receiver,
administrative receiver or administrator (or any similar person provided by the Laws of the place
where the company is located or incorporated) appointed for bankruptcy of all or any part of its
property, or will go into any bankruptcy; 9.1.3 Unless otherwise agreed, the other party is in
violation of any provision of this Agreement and fails to remedy such violation within 30 days from
the receipt of notice of such violation from such party (if capable of remedy); 9.1.4 The other
Party Breaches the Agreement, and such party may terminate this Agreement in accordance with this
Agreement or the Platform Rules. 9.2 In the event of any changes in industry policies, industry
restrictions, business strategy adjustments and/or business adjustments, the Parties shall notify
the other Party At least 30 days in advance to terminate this Agreement. This Agreement shall
terminate as of the date of termination specified in the notice of termination. If this Agreement
terminates pursuant to this Article, in addition to the payment of the amount incurred and confirmed
under this Agreement to the other Party, the Parties shall not be liable for the termination of this
Agreement, including, but not limited to, payment of late fees, liquidated damages, compensation.
9.3 In the case of a written notice 15 days in advance from either party to the other Party And a
payment of the liquidated damages of RMB10,000 (RMB TEN THOUSAND), this Agreement shall terminate as
of the date of termination stated in the notice of termination.
<!-- page 11 -->
Contract No.: DDCX S DG KC 201812130044 9.4 Upon the termination of this Agreement, Party A is not
obliged to retain any information on the Platform or provide such information to Party B; but Party
A is entitled to retain Party B's registration data and Party B's data in connection with the driver
services during the Period of Cooperation. Upon the termination of the Agreement, in the event of
any violation by Party B of this Agreement or the Platform Rules during the Period of Cooperation is
discovered, Party A is still entitled to exercise its rights under this Agreement to prosecute Party
B for such violation 9.5 After the termination of this Agreement, Party B shall strictly perform the
Financial Leasing Agreement signed with the Driver User until the lease expires. 9.6 Upon the
termination of this Agreement, Party B shall remove and delete any information or signs related to
Didi contained in the materials in the building, equipment, furnishings inside and outside Party B's
premises and materials published by Party B in any form. 10. Liability for Breach 10.1 The following
acts belong to Class I breaches of the Agreement. If Party B has any of the following acts, Party B
shall immediately correct the breach and Party A is entitled to send to Party B a Confirmation
Letter on the Breach of the Partner of Xiaoju Online Ride-Hailing Marketplace 10.1.1 Party B fails
to cooperate with Didi's staff, for example: 10.1.1.1 Party B is in violation of Article 3.1.3.1,
and fails to provide more information or documentary evidence as required by Party A; 10.1.1.2 Party
B is in violation of Article 3.2.6, and fails to cooperate with Party A in the investigation and
evidence collection or to assist Party A in handling related matters; 11.1.1.3 Party B fails to
affix its seal on the reply letter of the Confirmation Letter on the Breach of the Partner of Xiaoju
Online Ride-hailing Marketplace or fails to provide Party A with such original sealed letter;
11.1.1.4 Other noncooperation with Didi's staff by Party B. 10.1.2 Being complained due to the
service for more than 3 times by different Driver Users within 1 natural month, including but not
limited to the noncompliance of the requirements for the time limits for telephone invitations and
offline interviews (Party B shall make an invitation by phone within 1 day after a Driver User
places an order and conduct an offline interview with the driver within 7 days), bad service
attitude, etc. 10.1.3 Party B is in violation of Article 3.2.2, and fails to notify Party A of any
change or invalidity of any material, information, contact information provided to Party A at least
3 working days prior to such change or invalidity; 10.1.4 Party B is in violation of Article 3.2.9,
and fails to upload the scanned copy of the Consulting Service Agreement to the Platform within 1
working day from the execution of such Agreement with any Driver User;
<!-- page 12 -->
Contract No.: DDCX S DG KC 201812130044 10.1.5 Party B disseminates any information not published
through Didi's official channels, or disseminates rumors relating to Didi; 10.1.6 Party B conducts
other Class A breaches specified in the Platform Rules. 10.2 The following acts constitute Class B
breaches. In the event of any breach below by Party B, Party B shall immediately remedy the breach,
and Party A is entitled to request Party B to pay the liquidated damages of an amount from RMB1,000
(RMB ONE THOUSAND) to RMB 5,000 (RMB FIVE THOUSAND) based on the consequences of the breach, and
send the Confirmation Letter on the Breach of the Partner of Xiaoju Online Ride-hailing Marketplace
to Party B. 10.2.1 In the event of any Class A breach, Party B fails to remedy such breach in a
timely manner or within the time limit notified by Party A, or the Agreement is still breached upon
the completion of the remedy; 10.2.2 In the event of three Class A breaches in 12 consecutive
calendar months, the third Class A breach shall be regarded as a Class B breach; 10.2.3 The breach
provided in Article 10.1.3 occurs twice in 12 consecutive natural months; 10.2.4 Violating Article
3.2.7 for being complained due to no stock of vehicles for more than 3 times by different Driver
Users within 1 natural month; 10.2.5 Listing or leasing on the platform a vehicle that does not meet
the requirements of this Agreement or the requirements of the Platform Rules. For example: 10.2.5.1
Any vehicle listed and leased on the Platform failing to comply with Article 3.2.3; 10.2.5.2 Any
vehicle listed and leased on the Platform failing to meet the other requirements of the Platform
Rules; 10.2.6 Party B failing to remove any vehicle from the Platform within 1 working day after a
recall decision is issued for breach of Article 3.2.5 or in case that any vehicle is recalled after
being listed on the Platform; 10.2.7 Violating Article 3.1.4 for releasing information which is not
related to the vehicle lease business or releasing malicious competition and other information which
may disrupt the normal trading order of the Platform, or releasing any information in violation of
the Law or against the public interest or any information which may damage the legitimate interests
of the three parties; 10.2.8 Concealing significant vehicle information (eg, whether a major repair
has occurred), or the vehicle information published on the Platform (eg, service life) and the
financial leasing programs (including but not limited to the down payment, monthly rent, balance
payment, value-added services, etc.) being inconsistent with the actual vehicles delivered by the
drivers or the Financial Leasing Agreement; 10.2.9 Being complained due to any failures of Class A
vehicles (including but not limited to oil leakage, safety system failure, power system failure,
etc.) listed on the Platform for more than 5 times from different Driver Users;
<!-- page 13 -->
Contract No.: DDCX S DG KC 201812130044 10.2.10 The monthly efficiency indicators failing to meet
the standards or the assessment results of the experience indicators failing to meet the standards
(failing to reach 60 points (excluded)) in three consecutive indicator assessments; 10.2.11
Violating Article 3.2.11 for charging a Driver User a deposit of more than RMB20,000 (twenty
thousand); 10.2.12 Violating Article 3.2.17 due to not providing the most preferential treatment to
a Driver User; 10.2.13 Being in any Class II violations as specified in the Platform Rules. 10.3 The
following acts constitute Class C breaches. In the event of any breach below by Party B, Party B
shall immediately remedy the breach, and Party A is entitled to request Party B to pay the
liquidated damages of an amount from RMB5,000 (RMB FIVE THOUSAND) to RMB50,000 (RMB FIFTY THOUSAND)
based on the consequences of the breach, and send the Confirmation Letter on the Breach of the
Partner of Xiaoju Online Ride-hailing Marketplace to Party B. 10.3.1 In the event of any Class B
breach, Party B fails to remedy such breach in a timely manner or within the time limit notified by
Party A, or the Agreement is still breached upon the completion of such remedy; 10.3.2 In the event
of three Class B breaches in 12 consecutive calendar months, the third Class B breach shall be
regarded as a Class C breach; 10.3.3 Inducing Platform users to transfer the vehicle ownerships to
Party B; 10.3.4 Violating Article 3.2.3.3 or 3.2.3.4 for leasing an unqualified vehicle, which later
causes a traffic accident or any other safety accident due to retrofitting or installation of new
parts; 10.3.5 Violating Article 3.2.4 for the following reasons: The actual use of a leased vehicle
is inconsistent with the purpose as agreed in the Financial Leasing Agreement, or although the
actual use of the leased vehicle is consistent with the purpose as agreed in the Financial Leasing
Agreement, the Driver User is not pursued to buy the corresponding insurance according to the actual
use nature of the leased vehicle and therefore the insurance company refuses to pay for the
compensation when the leased vehicle has a traffic accident or the Driver User is not pursued to buy
the insurance meeting the requirements for the insurance value and type as provided by the law for
online vehicle leasing in accordance with Article 3.2.4 and therefore the compensation amount paid
by the insurance company is insufficient to cover the Driver User's liability for tort or carrier
liability in the traffic accident or safety accident. 10.3.6 Violating Article 3.2.8 for inducing
the Driver User to carry out a vehicle leasing transaction outside the Platform or sign a Agreement
without using the platform's template of Financial Leasing Agreement; 10.3.7 Violating Article
3.2.10 for failing to perform its obligations to the Driver User in accordance with the Financial
Leasing Agreement signed with the Driver User; 10.3.8 Violating Platform Rules for carrying out
misleading propaganda (including but not limited to exaggerating the scale of the company, making
exaggerated advertisement or fictitious promise of service projects, preferential programs, etc., or
misleading the Driver User by use of false facts such as Didi's order precedence);
<!-- page 14 -->
Contract No.: DDCX S DG KC 201812130044 10.3.9 Entering into other agreements with the Driver User
in any form other than the Platform's template of Financial Leasing Agreement; or restricting the
rights of the Driver User or increasing the obligations of the driver in any form, without a prior
written notice to Party A and without the written consent of Party A; 10.3.10 Charging the Driver
User any fees under any name in any form other than Party A's template of Financial Leasing
Agreement or forcing the Driver User to subscribe any business not related to Didi or forcing Driver
Users to make unreasonable consumption; 10.3.11 Disseminate any information not published by Didi
through official channels, or spreading rumors that have a negative impact on Didi (eg, causing
losses to drivers); 10.3.12 Insulting, intimidating, threatening, deceiving, or forcing any Driver
User; 10.3.13 Publishing a system that does not comply with or goes against Didi's business policy
or the Platform Rules; 10.3.14 Violating Article 3.2.12 for the IRR of the Financial Leasing Program
exceeding the upper limit as agreed in this Agreement; 10.3.15 Violating Article 3.2.13; 10.3.16
Violating Article 3.2.14; 10.3.17 Violating Article 3.2.15; 10.3.18 Violating Article 3.2.16;
10.3.19 Party B conducts other Class C breaches specified in the Platform Rules. 10.4 The following
acts constitute Class D breaches. In the event of any breach below by Party B, Party B shall
immediately remedy the breach, and Party A is entitled to request Party B to pay the liquidated
damages of not less than RMB50,000 (RMB FIFTY THOUSAND) based on the consequences of the breach, and
send the Confirmation Letter on the Breach of the Partner of Xiaoju Online Ride-hailing Marketplace
to Party B, and terminate the Agreement. 10.4.1 In the event of any Class C breach, Party B fails to
remedy such breach in a timely manner or within the time limit notified by Party A, or this
Agreement is still breached upon the completion of such remedy; 10.4.2 In the event of three Class C
breaches in 12 consecutive calendar months, the third Class C breach shall be regarded as a Class D
breach; 10.4.3 Party B is in violation of Article 3.2.2 and provides false materials or information
to Party A ; 10.4.4 Party B or Party B's Affiliates use or use in disguised form the company name,
trade name, trademark and logo of Party A or Party A's Affiliates without the consent of Party A or
Party A's Affiliates or fail to use such names, trademark or logo as agreed, or Party B uses the
company name and logo similar to above trademarks and logo (if Party A or Party A's Affiliates
considers that the company name or logo used by Party B or Party B's Affiliates is similar to the
trade name or trademark of Party A or Party A's Affiliates, Party A may notify Party B and Party B's
Affiliates to change its name. If Party B or Party B's Affiliates fail to take measures within 20
days from the receipt of such notice, it shall be deemed as a use of trademark and logo similar to
those of Party A or Party A's Affiliates).
<!-- page 15 -->
Contract No.: DDCX S DG KC 201812130044 10.4.5 Party B or Party B's Affiliates conduct illegal or
criminal activities relying on the partnership with Didi; 10.4.6 Party B, Party B's shareholders,
legal representatives, Senior Management or Party B's Affiliates make illegal profits relying on
their relationship with the Didi's staff (including, but not limited to, relatives, couples,
friends); 10.4.7 Party B or Party B's shareholders, legal representative, Senior Management or Party
B's Affiliates is in violation of the provisions of the Trust and Integrity and Commercial
Anti-Bribery Agreement between the Parties; 10.4.8 Party B charges any fee against the Driver Users
in the name of Didi; 10.4.9 Party B forces the Driver Users to transact any business irrelative to
Didi or forces the Driver Users to have unreasonable consumption, which causes material adverse
effects to Didi or causes adverse social effects (including but not limited to collective
complaints, illegal assembly, petitions, march, sit-in or containment of Didi by Driver Users, news
media releases); 10.4.10 Party B, Party B's staff or Party B's Affiliates are in violation of
Article 7 and discloses Party A's confidential information to third parties in any form; 10.4.11 In
consideration of the fact that Party B may have access to the relevant trade secrets of Didi during
the cooperation, Party B or Party B's any affiliate cooperates with any entity competitive with Didi
(including but not limited to Meituan, CAR, Yongche, izu, Caocao, Dida) in any form without prior
written notice to and confirmation by Didi; 10.4.12 Party B introduces the entities competitive with
Didi (including but not limited to Meituan, CAR, Yongche, izu, Caocao, Dida) to Driver Users, and
induces Driver Users to conduct activities directly competing or conflicting with Didi; 10.4.13
Party B instigates and organizes the Driver Users to conduct illegal assembly, petition, march,
sit-in or containment of Didi, etc. in any form, or any collective complaints, illegal assembly,
petitions, marches, sit-in or containment of Didi and other mass disturbances by Driver Users are
incurred by the products or services provided by Party B; 10.4.14 Party B disseminates any
information not published through Didi's official channels, or disseminates rumors and causes
material adverse effects to Didi (including but not limited to collective complaints, illegal
assembly, petitions, marches, sit-in or containment of Didi by Driver Users, and News media
releases); 10.4.15 Party B maliciously slanders other companies or takes other mean measures to
disrupt the market order and conducts unfair competition: 10.4.15.1 Party B disseminates other
rumors to maliciously slander other companies; 10.4.15.2 Party B dispatches undercover personnel to
other companies to disrupt the operation order of other companies and solicits Driver Users or
management personnel of other companies;
<!-- page 16 -->
Contract No.: DDCX S DG KC 201812130044 10.4.15.3 Party B conducts other activities of unfair
competition which seriously disrupt the market order; 10.4.16 Violating Article 8.2 for failing to
meet Party A's requirements for cooperative vehicle leasing companies; 10.4.17 Party B conducts
other Class D breaches stipulated in the Platform Rules; 10.5 If Party B has a violation of Article
10.3.5, resulting in the insurance company's refusal to pay or insufficient compensation to pay the
driver's tort liability or carrier's liability in the traffic accident, the claim amount rejected by
the insurance company and the compensation supposed to be paid by the insurance company if the
corresponding insurance has been bought shall be borne by Party B. If Party B fails to bear the
above mentioned amount rejected and compensation, resulting in any losses to Party A or its users,
Party B shall compensate Party A for the losses of Party A and Party A shall have the right to
terminate this Agreement unilaterally and shall pursue Party B's liability for breach in accordance
with Articles 10.3 and 10.6. 10.6 In the event of any breach of the terms of this Agreement by
either party, the breaching party shall remedy such breach within the time limit notified by the
observing party. In the event of any losses incurred to the observing party, in addition to the
corresponding liability for breach under the Agreement, the breaching party shall also be liable for
the compensation for such losses (including, but not limited to, the losses incurred to the
counterParty By such breach, the legal costs, notarial fees, appraisal fees, the attorney's fee, the
travel expenses, etc., arising from the investigation and affixation of the liabilities of the
breaching Party By the counterparty) . Unless any party is in violation of the confidentiality
clause, in any case, neither party shall be liable for any indirect, punitive claims, or claims for
losses of commercial profits, or damages for business losses of the company or any third Party
Arising from this Agreement, or for any loss or inaccuracy of data of any form, whether based on
Agreement, tort or any other legal principle, even though the party has been informed of the
possibility of such damage. 10.7 If Party B violates this Agreement or the Platform Rules, Party A
is entitled to take measures such as suspending the platform services, permanently stopping the
platform services, and/or temporarily or permanently disabling the corresponding functions of the
vehicle service company, and/or removing the products from the platforms. 10.8 In case any act of
either party is in violation of several provisions of this Agreement at the same time, the observing
party is entitled to choose one provision as the basis for the investigation and affixation of the
liability for breach of the breaching party. In case several acts of either Party Are in violation
of several provisions of this Agreement at the same time, the observing party is entitled to
investigate and affix the liability for breach of the breaching party in accordance with each
provision violated. 10.9 In the event of several valid agreements between Party A and Party B, any
act of either party is in violation of such agreements between the Parties at the same time, the
observing party is entitled to choose to investigate and affix the liability for breach of the
breaching party in accordance with all provisions of all of such agreements or provisions of part of
such agreements.
<!-- page 17 -->
Contract No.: DDCX S DG KC 201812130044 11. Governing Law; Dispute Settlement 11.1 The execution,
validation, interpretation, performance, modification and termination of this Agreement and the
settlement of disputes under this Agreement shall be governed by the Laws of China. 11.2 Any dispute
arising from the interpretation and performance of the terms of this Agreement shall be settled by
the Parties through negotiation in good faith. If the Parties fail to reach an agreement on the
settlement of such dispute within 30 days from the requirement of such negotiation by either party,
such dispute may be submitted to the Beijing Arbitration Commission for arbitration in accordance
with its arbitration rules in force then. The arbitral award shall be final and binding upon the
Parties. 11.3 During the settlement of the dispute, the Parties shall continue to fully perform this
Agreement, except for the matters in dispute. 12. Notices 12.1 All notices and other communications
to either party hereto required or permitted hereunder shall be made in Chinese, by personal
delivery or by registered mail with postage prepaid, commercial courier service or by e-mail to the
address of the party specified in this Agreement. The date on which such notice shall be deemed to
have been served upon such party shall be determined as follows: 12.1.1 Notices given by personal
delivery, registered mail with postage prepaid or commercial courier service shall be deemed
effectively given on the date of receipt or rejection at the designated address for notices; 12.1.2
Notices given by e-mail shall be deemed effectively given when the mail enters into the addressee's
e-mail address contained in this article or at the time of the receipt of the system prompt for the
failed transaction in the case of the invalidation of receiver's e-mail address. 12.2 For the
purpose of notices, the contacts and contact information designated by the Parties are as follows:
12.2.1 Party A's contacts: (Telephone/Mobile number:) Address: E-mail: 12.2.2 Party B's contacts:
Xianglong Li (Telephone/Mobile number: 0731-85240273) Address:Floor 9, Huitong Building, No. 168
Hehua Road, Hehua Street, Furong District, Changsha City, Hunan Province E-mail: 77128824@qq.com
12.3 In the event of any change to the contacts, address or e-mail address of either party, such
party shall notify the other Party At least 3 working days in advance by the means provided in this
article. Otherwise, the original address or e-mail address shall still be the valid address for
notices.
<!-- page 18 -->
Contract No.: DDCX S DG KC 201812130044 13. Force Majeure 13.1 "Force Majeure" means an event beyond
the reasonable control of the Parties, unforeseeable or even foreseeable, but unavoidable by the
Parties to this Agreement, which prevents, affects or delays the performance by either party of its
obligations under this Agreement in whole or in part. Such event includes, but is not limited to,
natural disaster, war, fire, riot, strike, Internet connection failure, computer system failure,
communication failure, computer virus, hacker attack or any other similar events that shall be
considered as events of force majeure in accordance with commercial practices. 13.2 The affected
party may temporarily suspend the performance of its obligations under this Agreement until the
effects of the event of force majeure are eliminated. The affected party shall fully notify the
other party in writing of the occurrence of such event of force majeure in a timely manner,
notifying the other party of the possible effects of such event on this Agreement, and shall use its
best efforts to eliminate such event and mitigate its adverse effects, and provide the written
evidence issued by relevant notary office within a reasonable period. Upon the fulfillment of the
aforesaid obligations, the affected party shall not be liable to the other party for the breach
within the scope of effects of such event of force majeure. 13.3 In case the event of force majeure
sustains for more than 20 days, either party is entitled to terminate this Agreement unilaterally by
written notice, and this Agreement shall terminate from the date on which such party gives such
written notice of termination. 14. Independent Contractor Nothing in this Agreement shall be deemed
to create any joint venture, partnership, or agency relationship between the Parties. Without the
written consent of the authorized representative of the other party, neither party is entitled to
execute any agreement on behalf of the other party or cause the other party to be bound by any law
or borrow money or incur any liability or obligation on behalf of the other party hereto. Each party
shall be solely liable for the actions of its employees and contractors employed for the purposes of
the promotional activities. 15. Data and Privacy Protection The collection, storage and maintenance
by either party of the third-party data, personal data or information obtained as a result of the
execution or performance of this Agreement shall comply with all applicable laws, regulations or
rules.
<!-- page 19 -->
Contract No.: DDCX S DG KC 201812130044 16. Business Principles 16.1 Party B warrants that it does
not give or offer any gift to any employee, agent or representative of Party A, and that there is no
other improper interest transfer (including but not limited to giving material benefits or other
non-material benefits in the form of gifting or lending or at a price significantly higher or lower
than the market price) with the aforesaid persons, and it will not offer or grant such items or
carry out improper benefits transfer in the future, in order to obtain any business from Party A, or
to affect the aforesaid persons in the aspects of the terms, conditions or performance of any
purchase agreement or order (including but not limited to this Agreement) between the Parties. 16.2
Party B warrants and undertakes that it will strictly abide by the commercial anti-bribery Laws and
regulations in force in China and provisions for anti-corruption in all applicable Laws and
regulations including the Foreign Corrupt Practices Act (FCPA) of the United States, and it shall
not provide any bribes to any government official, employee of state-owned enterprises or public
agency during the performance of this Agreement. Any violation of this article by Party B shall be
considered as a material breach of the this Agreement, and Party A is entitled to immediately
terminate this Agreement and the cooperation relationship between the Parties, and request Party B
to pay the liquidated damages of RMB 50,000 (RMB FIFTY THOUSAND) and indemnify for all losses
incurred to Party A thereby. 16.3 Party A's e-mail address for receiving the report of any violation
of Code of Business Conduct is jubao@didiia.com. In the event of any violation of its Code of
Business Conduct found by Party A, Party B shall cooperate with Party A in the investigation as
required by Party A. If Party B fails to cooperate with Party A in such investigation, it shall be
deemed as a material breach by Party B. In such case, Party A is entitled to immediately terminate
the Agreement and the cooperation relationship between the Parties, and request Party B to pay the
liquidated damages of RMB50,000 (RMB FIFTY THOUSAND) and indemnify for all losses incurred to Party
A thereby. 17. Transfer During the term of this Agreement, neither party may assign, or transfer its
rights and obligations under this Agreement in whole or in part, without the prior written consent
of the other party. However, Party A may transfer its rights and obligations under this Agreement to
any of its Affiliates in whole or in part with the written notice to Party B, and Party B
irrevocably agrees and permits Party A's such rights, provided that Party A shall ensure that such
transferee or assignee will comply with relevant laws and regulations, and ensure that Party B is
exempt from any liability and consequences arising from any violation of applicable laws and
regulations by such transferee or assignee, and Party A shall indemnify for the losses incurred to
Party B thereby. 18. Severability If any one or more provisions contained in this Agreement is held
to be invalid, illegal or unenforceable in any way in accordance with any law or regulation, the
validity, legality or enforceability of the remaining provisions in this Agreement shall not in any
way be affected or impaired. Such invalid, illegal or unenforceable provision shall be replaced by a
valid, legal or enforceable provision that has similar economic effects of such invalid, illegal or
unenforceable provision by the Parties through good faith negotiation to the fullest extent
permitted by laws and expected by the Parties.
<!-- page 20 -->
Contract No.: DDCX S DG KC 201812130044 19. Composition, Modification and Supplement of this
Agreement 19.1 All Platform Rules are an integral part of this Agreement. In the event of any
inconsistence between the Platform Rules and this Agreement, the Platform Rules shall prevail. If
Party B signs this Agreement and uses the Platform, it shall accept to be bound by the Platform
Rules. Party A is entitled to develop and revise the Platform Rules pursuant to the operation of the
Platform. For the development and revision of the Platform Rules that may affect Party B's rights
and obligations, Party A will notify Party B in writing via email 10 days prior to the
implementation of the new Platform Rules, and Party B shall decide whether to continue to perform
this Agreement within 10 days from the date of receipt of the notice via email. If Party B rejects
the new Platform Rules, it shall send a written application for the termination of this Agreement to
Party A within 10 days from the date of receipt of such notice. If Party B fails to terminate this
Agreement or continue to log in and use the Platform within such 10-day period, it shall be deemed
to agree to the new Platform Rules. The new Platform Rules shall become effective as of the
effective date specified in the Platform Rules, and Party B shall strictly abide by the new Platform
Rules as of the effective date. 19.2 Except for the Platform Rules, any modification and addition to
this Agreement shall be signed by the Parties in writing. The modified and supplemental agreements
signed by the Parties in connection with this Agreement shall be an integral part of this Agreement
and shall have the same legal effect as this Agreement. 20. Limited Liability 20.1 Party A only
provides the Platform, and Party B shall select (at its own discretion) the Driver Users to
establish the consulting service relationship. Any dispute or controversy arising from the
consulting services between Party B and any Driver User shall be settled by Party B and the Driver
User, and Party A neither shall be liable for such dispute, nor shall be liable for the losses
incurred to Party B and the Driver User during the provision of the consultation service by Party B
to the Driver User. 20.2 Party A shall only conduct a formal review for the materials submitted and
the information published by Party B. The approval by Party A shall not represent that Party A
acknowledges the authenticity and legality of such material and information. In the event of any
loss incurred to Party A or any third party due to the false materials and information provided by
Party B, Party B shall be liable for compensation and shall be liable to Party A for the breach.
20.3 Party B has fully understood the functions and characteristics of services of the Platform
prior to the use of the Platform and agrees that Party A shall not be liable to Party B for any
defect in software, insufficiency of function or any necessary improvement. 20.4 Party B's use of
the Platform and the acquisition of any information by using the Platform are solely at Party B's
independent judgment and is at Party B's own risk (including but not limited to the losses caused by
damage to Party B's computer system or mobile phone system or loss of data.)
<!-- page 21 -->
Contract No.: DDCX S DG KC 201812130044 21. Validation and Term This Agreement shall enter into
force as of the effective date. Unless this Agreement is early terminated in accordance with this
Agreement or other agreements signed by the Parties hereof, the term of the validity of this
Agreement shall be one year from the effective date. Party A is entitled to unilaterally terminate
this Agreement within three natural months from the signing date of this Agreement. 22.
Miscellaneous 22.1 The online Ride-hailing Service agreements such as the Vehicle Leasing Service
Cooperation Agreement, the Management Consulting Service Agreement, the Consultation Service
Cooperation Agreement, and the Corporate Franchising Management Consulting Service Agreement, the
vehicle leasing and consulting service agreements (only limited to the Agreements relevant to Party
A's fast ride business, except for those on general franchise business) shall continue to be valid
within the scope of cooperation before the signing of this Agreement by and between the Parties
hereof, and the deposits received by Party A in accordance with such agreements will temporarily not
be refunded. Such agreements shall not be terminated until the end of the cooperation between the
Parties under the agreements, at which time the Parties will conduct friendly negotiations on the
termination of these agreements. 22.2 The expressions of "not less than", "no more than" and
"within" in this Agreement, include the given figure; the expressions of "N working days in
advance", "within N working days", "N days in advance", "within N days", include the Nth working day
and the Nth day. 22.3 This Agreement shall be executed in triplicate of equal legal effect, with two
original copies for Party A and one original copy for Party B. Annex: Agreement for Didi Chuxing
Partners on Honesty & Integrity and Anti-Commercial Bribery ————————— [REMAINDER OF PAGE
INTENTIONALLY LEFT BLANK]—————— Party A: Didi Chuxing Technology Co., Ltd. /s/ Didi Chuxing
Technology Co., Ltd. [signature authenticated by third party document depository on December 17,
2018] Party B: Hunan Ruixi Financial Leasing Co., Ltd. /s/ Hunan Ruixi Financial Leasing Co., Ltd.
[signature authenticated by third party document depository on December 17, 2018]
<!-- page 22 -->
Contract No.: DDCX S DG KC 201812130044 Agreement for Didi Chuxing Partners on Honesty & Integrity
and Anti-Commercial Bribery Party A: Didi Chuxing Technology Co., Ltd. Party B: Hunan Ruixi
Financial Leasing Co., Ltd [Instruction: this Agreement shall be exclusively used by Didi Chuxing
Technology Co., Ltd. to conclude Agreements with external sides. This Agreement shall be attached to
all Agreements signed with external sides as an appendix to guarantee the interests of Contracting
parties.] To build a fair and honest business cooperation ecology, the cooperating Parties hereby
make and enter into the honesty & integrity and anti-commercial bribery agreement binding on both
Parties. To ensure stricter compliance with the provisions of laws and regulations concerning the
prohibition of commercial bribery, maintain common interests, and promote sound development of the
Parties' relationship, the Parties hereby agree as follows through friendly negotiation for mutual
compliance: Article I [Purpose of Contracting] The Parties shall comply with national laws and
regulations on anti-commercial bribery, ensure legal business transactions between the Parties, and
shall never damage either party's interest for the purpose of improper cooperation interest in any
illegal or corruptible manner. The Parties shall strictly comply with this Agreement. The term
commercial bribery used in this Agreement refers to all direct or indirect improper interests in
material, service or spiritual forms given by Party B or its personnel to Party A's employees in
order to obtain the opportunity of cooperation with Party A and cooperation benefits. Article II
[Honesty and Integrity Commitments] (I) Party B undertakes: 1. Not to bribe any employee of Didi
Chuxing or family members thereof in any way. 2. To support the honesty and integrity construction
of Didi Chuxing and assume the obligation of real-name reporting; if any employee directly under
Party B or involved in the cooperation doesn't refuse or report any bribe demand from the employees
of Didi Chuxing or their family members and meets such demand, it shall be deemed Party B's
commitment of bribery. 3. To voluntarily report the connection and interest relationship with the
employees of Didi Chuxing. 4. To insist on integrity principle during transactions with Didi Chuxing
and at least ensure: all information, documents, materials, data and relevant written and oral
statements provided for Didi Chuxing are true and accurate.
<!-- page 23 -->
Contract No.: DDCX S DG KC 201812130044 5. To strictly comply with the commitments made to Didi
Chuxing, Agreements, agreements and memos between the Parties, not to conceal any information that
may impact the interest of Didi Chuxing, and actively cooperate in the audit of Didi Chuxing. 6. To
comply with the provisions in the code of conduct for Didi Chuxing partners, cooperation agreements
and other policies. 7. To strictly comply with the provisions concerning Didi Chuxing brand
management, and without authorization, shall not use 滴滴, DIDI, Didi Chuxing, DIDI Club, authorized
partner and any other easily confusing words. 8. To strictly comply with relevant national laws and
regulations, and not to engage in any illegal activity. 9. To strictly manage company employees. 10.
To keep practical and realistic, not to communicate any false information internally or to the
society, and not to disclose any business secrets of Didi Chuxing. 11. To comply with national laws,
regulations and Didi Chuxing provisions, keep honest in bid & tender or business cooperation course,
and participate in bid or tender activities and business cooperation according to laws and
regulations. Article III [Improper Interest] Party B, Party B's associated companies or employees
and associated persons thereof: (1) shall not give cash gift, articles, negotiable securities
directly or indirectly, or provide improper interest in other disguised forms in the name of Party B
or in personal name to any employee of Party A or associated person (including but not limited to
direct relative, collateral relative within three generations, close relatives by marriage or other
persons who are closely related or have interest relationship); including but not limited to cash,
checks, credit card gifts, samples, or other commodities, entertainment tickets, membership cards,
or kickback, return commission in the form of currency or goods, employment or properties,
introduction of private business cooperation, and travel, entertainment or personal service at the
cost of Party B. (2) Introduce business or other activities to Party A, or to any spouse, friend or
relative of Party A's employees as required by Party A's employees. Article IV [Conflicts of
Interest] including but not limited to: (1) Party B shall not provide loan or financing of any form
for Party A's employees and associated persons; (2) If any of Party B's shareholders, supervisors,
managers, senior management personnel (including but not limited to the senior management, chief
executive officer, chief financial officer, and other department managers subject to powers or
duties as defined in the Company Law), cooperation project manager and project members is Party A's
employee or its associated person, the aforesaid person shall truthfully and fully report the same
to Party A in writing before cooperation;
<!-- page 24 -->
Contract No.: DDCX S DG KC 201812130044 (3) In the process of cooperation, Party B shall not allow
Party A's employees and their direct relative to hold or have a third party to hold Party B's
equities (other than shares held through less than 1% outstanding equities in open securities
exchange market, through funds without actual control right held directly or indirectly, or through
trust of which the beneficiary is not any of the aforesaid person or his/her associated person), or
employ Party A's employees and their direct relative (including but not limited to the establishment
of formal labor relations, labor dispatching and outsourcing services, part-time consulting, and
other forms). If Party B has employed any relative or other associated person of Party A's employees
(including but not limited to direct relative, collateral relative within three generations, close
relatives by marriage or other persons who are closely related or have interest relationship), Party
B shall truthfully and fully report to Party A in written form before Party A and Party B conclude
the cooperation agreement or within three days upon employment. Article V [Liability for Default]
(1) If Party B commits any violation of the aforesaid agreements, Party A is entitled to
unilaterally and completely terminate the Agreement and cooperation with Party B, and no associated
entities of Party A will establish commercial cooperation with Party B at any time and under any
circumstance in the future, including but not limited to Party B and all of its subsidiaries,
branches and associated companies (the associated companies of Party B includes without limitation
the companies or other organizations established, participated in, operated, controlled by or
otherwise affiliated with Party B's shareholders, legal person, actual controller or directors,
supervisors, and their direct relative, collateral relative within three generations, close
relatives by marriage or other persons who are closely related or have interest relationship);
besides, Party B shall pay liquidated damages to Party A at an amount of RMB 100,000 or 50% of the
total amount paid/discharged under the involved order (Agreement), whichever is higher; if Party B's
default causes any loss to Party A that cannot be covered by liquidated damages, Party A will
recover compensations for actual losses from Party B. (2) Party B shall pay the liquidated damages
within 5 working days upon Party A's discovery of any breach, and if the payment is not made in
time, Party A is entitled to directly deduct the same from the Agreement price. (3) Where any
improper interest is provided for any employee of Party A or his/her associated person, whether
actively or passively, if Party B voluntarily provides effective information for Party A actively,
Party A will consider based on actual situations whether to continue cooperation with Party B and/or
waive the aforesaid liability for default. (4) The aforesaid circumstances are at absolute sole
discretion of Party A. (5) Where any violation of the commitments on part of either party or its
employee constitutes a crime, either party may report the crime to a judicial authority, and the
persons involved will be prosecuted for criminal offense; the party violating the commitments and
its employees, if causing economic loss to other party, shall provide compensations. Article VI
[Reporting Channels and Reward] If Party B becomes aware of/suspects any violation of the aforesaid
provisions on part of Party A's employees, Party B shall contact the Risk Control Compliance
Department (RCCD) of Party A. If the information provided by the information provider about any
commercial bribery is verified to be true, Party A will reward the information provider depending on
the influence extent of the event, and in case of any event producing significant influence, will
give special reward. Party A has a special email address to accept the complaints from Party B:
jubao@didiia.com; complaint hotline: 010-62962880. Party A will keep all information providers and
all materials provided by them strictly confidential.
<!-- page 25 -->
Contract No.: DDCX S DG KC 201812130044 Article VII [Miscellaneous] This Agreement is an appendix to
the Cooperation agreement, made in two copies, and have equal legal force to the Cooperation
agreement. The issues that are not agreed upon in this Agreement shall be subject to the terms of
the Master Agreement. Party A: Didi Chuxing Technology Co., Ltd. /s/ Didi Chuxing Technology Co.,
Ltd. [signature authenticated by third party document depository on December 17, 2018] Party B:
Hunan Ruixi Financial Leasing Co., Ltd. /s/ Hunan Ruixi Financial Leasing Co., Ltd. [signature
authenticated by third party document depository on December 17, 2018]
