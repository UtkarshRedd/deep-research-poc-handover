<!-- page 1 -->
# MANUFACTURING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Manufacturing Agreement |
| Agreement Date | 2017-07-01 |
| Parties | Stremicks Heritage Foods, LLC ("Heritage"); PREMIER NUTRITION CORPORATION ("Premier")("Party:, collectively, the "Parties") |
| Source | CUAD v1 / BellringBrandsInc_20190920_S-1_EX-10.12_11817081_EX-10.12_Manufacturing Agreement1 |

Exhibit 10.12

CERTAIN IDENTIFIED INFORMATION CONTAINED IN THIS DOCUMENT, MARKED BY [***], HAS BEEN OMITTED BECAUSE
IT IS BOTH (1) NOT MATERIAL AND (2) WOULD LIKELY CAUSE COMPETITIVE HARM TO THE COMPANY IF PUBLICLY
DISCLOSED.

STREMICK HERITAGE FOODS, LLC and PREMIER NUTRITION CORPORATION MANUFACTURING AGREEMENT

THIS MANUFACTURING AGREEMENT (the "Agreement") is made this first day of July, 2017 (the "Effective
Date") between Stremicks Heritage Foods, LLC ("Heritage"), a Delaware limited liability company with
an address of 4002 Westminster Avenue, Santa Ana, CA 92703 and PREMIER NUTRITION CORPORATION
("Premier"), a Delaware corporation with a principal place of business at 5905 Christie Avenue,
Emeryville, California 94608 (each a "Party", collectively, the "Parties").

WHEREAS, Heritage is engaged in the business of producing food products on a contract basis and
desires to produce Products (as defined below) for Premier at its facilities in [***] as well as at
its majority-owned subsidiary, Jasper Products, L.L.C. ("Jasper") in [***];

WHEREAS, Premier is the owner of certain proprietary formulations, manufacturing processes and
techniques and wishes to have Product manufactured and packaged by Heritage in accordance with the
terms and conditions set forth herein;

NOW, THEREFORE, in consideration of the mutual covenants contained herein and intending to be
legally bound, the Parties agree as follows: 1. BASIC TERMS

(a) This Section contains the basic terms of this Agreement between Heritage and Premier. All other
provisions of this Agreement are to be read in accordance with the provisions herein contained. (i)
Commencement Date July 1, 2017

(ii) Termination Date December 31, 2022

(iii) Product Descriptions Schedule A (2(a))

(iv) Records Schedule B (2(i), 3(e))

(v) Ingredients/Materials/Packaging Purchased by Premier Schedule C (3(b))

(vi) Ingredient/Materials/Packaging Purchased by Heritage Schedule C (3(c))

(vii) Material loss allowance Schedule C

(viii) Pricing and terms Schedule C, 3(d)

(ix) Premier Contacts Schedule D

(x) Post Holdings' Quality Expectations Manual Schedule E 1

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 2 -->
(b) The term of this Agreement will commence on the Commencement Date and will continue through
December 31, 2022 or until this Agreement is otherwise terminated in accordance with its provisions
("Term"). 2. PRODUCTION OF PRODUCT

(a) Heritage shall produce the products described on Schedule A attached hereto, as may be amended
by the Parties hereafter from time to time (the "Products"), for Premier at [***] Heritage's or
Heritage's wholly owned subsidiary, Jasper's, [***] (the "Facilities"). [***] For the purposes of
this paragraph, [***] facilities located at [***] are considered one Facility. Any facility that
Heritage wishes to use, other than [***] to manufacture the Products must be approved by Premier in
writing, in advance. For the avoidance of doubt, Heritage's [***] facility must be approved by
Premier before it may be used to manufacture the Products. Such facility approvals shall not be
unreasonably withheld or delayed. Premier's facility approval will be based, in part, on the
successful completion of a trial production run that is sufficient in meeting finished product
specifications, and an evaluation of the stability and specifications of trial production product
within [***] of the trial production run.

(b) Heritage and Premier agree that all Products subject to this Agreement, and their current and
subsequently modified respective formulas are confidential and proprietary, and the sole property of
Premier unless otherwise agreed in writing by both Parties.

(c) Minimum Annual Order Volume. During the Term of this Agreement, Premier shall be required to
purchase a Minimum Annual Order Volume ("MAOV") of [***] ("Units") for each twelve-month period
commencing July 1, 2017, and for the six-month period commencing July 1, 2022 and ending December
31, 2022, Premier will be required to purchase [***] Units (the twelve-month periods and the six
month period are each a "Contract Period").

(d) During the Term, Premier shall have the right (but not the obligation) to order from Heritage
quantities of Products in excess of [***] and provided Heritage has the capacity and the ability to
produce such additional quantities of Products, Heritage agrees to produce such additional
quantities per the pricing and terms on Schedule C.

(e) [***]

(f) [***]

(g) Within [***] of each calendar month during the Term, Premier shall provide to Heritage a [***]
rolling production forecast which shall set forth Premier's non-binding good faith estimated
purchases (each, a "Forecast") for the [***] period commencing on the date thereof (the "Forecast
Delivery Date"). Each Forecast shall also designate which Facility shall manufacture the Products
set forth in such Forecast (i.e. Heritage's [***] Facility, Jasper's [***] Facility, or some other
facility agreed to by the Parties). Heritage shall notify Premier, in writing (or email), within
[***] of each Forecast Delivery Date, if Heritage's or Jasper's Facilities will not be able to
fulfill Premier's estimated purchases as set out in the [***] of such Forecast. For the avoidance of
doubt, the [***] are 2

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 3 -->
the [***] immediately following the Forecast Delivery Date. If Heritage notifies Premier that it can
fulfill Premier's Forecast for this [***] period, or if it fails to notify Premier that it cannot
fulfill that portion of the Forecast, Heritage shall be obligated to fulfill, or cause Jasper to
fulfill as applicable, if ordered through POs, the full amount of Product set forth for purchase
during [***] ("Firm Forecast").

(h) Within the [***] of each calendar month during the Term, Heritage shall provide to Premier a
[***] rolling production forecast which shall set forth Heritage's good faith estimated maximum
monthly unit volume ("Maximum Volume") for each Facility during such [***] period. Modifications to
the Maximum Volume shall be negotiated in good faith and agreed upon by both Parties in writing or
email by the [***] of the calendar month.

(i) Premier shall provide Heritage with Purchase Orders (or "POs") [***] in advance of the date
referred to as the "Due Date" in such POs. The POs, at a minimum, will give the Products and
quantities ordered, the Due Date requested, and designate which Facility will manufacture the
Products. "Due Date" shall mean the production start date requested by Premier.

(j) Within [***] of receipt of a PO, Heritage shall (i) provide to Premier email confirmation of
acceptance of the PO, a schedule of production and an estimated production completion date (the
"Estimated Completion Date"), or (ii) notify Premier if any term of the PO cannot be met. Heritage's
failure to notify Premier, within the time specified herein, of an inability to meet a term of the
PO shall constitute acceptance of such PO in its entirety. If Heritage notifies Premier that it or
Jasper cannot meet the Due Date, the Parties shall discuss an acceptable alternate date on which
production will commence (the "Production Date"). Once a Due Date is accepted or a Production Date
is mutually agreed upon, Heritage shall, or shall cause Jasper to, use all commercially reasonable
efforts to start production on or before the Due Date (or Production Date, as applicable), but in no
case more than [***] earlier or later than the Due Date (or Production Date, as applicable) unless
mutually agreed otherwise by Premier.

(k) If PREMIER requests that Products be produced at the Heritage Facility, Heritage may either
produce such Products at the Heritage Facility or cause Jasper to produce such Products at the
Jasper Facility, in which case Heritage shall be responsible for all shipping costs of transporting
the Products to the Heritage Facility. If Premier requests that Products be produced at the Jasper
Facility, Heritage may either cause Jasper to produce such Products at the Jasper Facility or
produce such Products at the Heritage Facility, in which case Heritage shall be responsible for all
shipping costs of transporting the Products to the Jasper Facility.

(l) If a PO is accepted by Heritage as described in Section 2(j) above but such PO is not filled in
accordance with its terms, or if Heritage or Jasper, as applicable, fails to complete production of
the Products [***], Premier shall have the right to use an alternate co-packer for the Products
specified in the PO and Heritage shall, or shall cause Jasper to, provide Premier with Premier owned
packaging needed to support such production by an alternate co-packer.

(m) Purchase Orders will be Premier's best estimate of its current requirements, but may be amended
up or down or canceled in their entirety by Premier to reflect changing demand for Products. The
final Unit quantities on Premier's Purchase Orders will count towards the MAOV. However, if (i) any
increase or decrease in Unit volume under a particular PO is greater than [***] of the initial PO
quantity and (ii) Premier requests such change or cancellation within the [***] period prior to the
Due Date (or Production Date, as applicable) (the "[***] Period"), Heritage in its sole discretion,
may charge Premier [***]. In no event shall Premier pay [***] if (i) it cancels or modifies any PO
prior to the commencement of the [***] Period (i.e.; prior to the commencement of the [***] period
preceding the Due Date (or Production Date, as applicable), (ii) Heritage or Jasper fails to timely
start production in the [***] period before or after the Due Date (or Production Date, as
applicable), or (iii) the basis for Premier's cancellation is a breach by Heritage of its
obligations, representations or warranties hereunder. 3

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 4 -->
(n) Heritage shall within [***] after the end of the production run, notify Premier via email of the
final estimated production quantity and the estimated quantity, including losses, of all
Premier-supplied materials used. If the final production quantity for any accepted PO is less than
[***] of the PO quantity ordered, or if the quantity of production released for shipment within
[***] from the last day of production is less than [***] of the PO quantity, upon request by
Premier, Heritage shall take all commercially reasonable steps to produce or replace the shortfall
within [***]. The final production quantity by Heritage and Jasper will count towards the MAOV
requirements.

(o) Heritage represents and warrants that:

(i) All Products manufactured, packaged and delivered by Heritage or Jasper under the terms of this
Agreement shall conform to the specifications supplied to Heritage by Premier as listed on Schedule
A, which Schedule may from time to time be modified by Premier in writing (the "Specifications"),
shall conform to Post Holdings' Quality Expectations Manual attached hereto as Schedule E, and shall
conform in all material respects to samples previously supplied to Premier by Heritage. No change in
Specifications shall be binding on Heritage until Premier has provided written Specifications for
each SKU, and each Specification is signed and dated by the Parties. Any additional net cost
increases or decreases associated with any modifications to Premier's Specifications shall be borne
by or credited to Premier.

(ii) Heritage and Jasper will comply with all laws and regulations applicable to production of the
Products, including without limitation, the laws and regulations of the United States Food and Drug
Administration ("FDA"), United States Public Health Service ("PHS"), and any and all other
applicable federal, state and local laws and regulations. Heritage warrants that the Products shall
be released free from defects in workmanship and shall be manufactured in accordance with this
Agreement and 21 C.F.R. Part 110 which is entitled "Current Good Manufacturing Practice in
Manufacturing, Packing or Holding Human Food" and as it may be amended from time-to-time.

(iii) The Products, when delivered to Premier in accordance with this Agreement, shall be free of
contaminants, merchantable, fit for intended use and shall not be adulterated within the meaning of
the Federal Food, Drug and Cosmetic Act.

(iv) Heritage and Jasper hold all permits and licenses required for Heritage and/or Jasper to
manufacture the Products under the Agreement. Heritage will obtain, and shall ensure that Jasper
obtains, all ingredients and packaging materials from suppliers that are approved by Premier in
writing.

(p) Upon reasonable notice, and during normal operating hours, Heritage shall permit Premier or its
representatives reasonable access to portions of the Heritage Facilities, the Jasper Facility or any
other Facility used to produce the Products for the purpose of ascertaining Heritage's and Jasper's
compliance with good manufacturing practices and Premier's Specifications and Post Holdings' Quality
Expectations. Heritage agrees to disclose to Premier and provide a list, upon request, of any
material violations or deficiencies noted during any inspection by the FDA, United States Department
of Agriculture, PHS, or any other federal, state or local health or food regulatory agency of the
Heritage Facilities, Jasper Facility or any other Facility used to produce the Products, which have
a material adverse effect on the manufacture or packaging of the Products. Heritage agrees to
provide to Premier each FDA Form 483 and any related Establishment Inspection Report ("EIR") that is
received from the FDA by Heritage or Jasper, along with any response provided to the regulatory
authority by Heritage or Jasper, as long as this Agreement is in effect. Heritage agrees to do so
within [***] of Heritage or Jasper receiving the Report or of sending the response as appropriate.
If Heritage wishes to redact any material from any EIR, it shall indicate that deletion by use of
the following note where each redaction occurs: "REDACTED MATERIAL". Heritage agrees that it will
not redact any information on an EIR that directly relates to any aspect of its manufacturing of
Products for Premier. 4

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 5 -->
(q) Heritage will keep, and will ensure that Jasper keeps [***] complete and accurate records in
connection with each unique production lot of Products with respect to manufacturing practices,
quality assurance measures, analytical procedures and their resultant data. Such records shall
include at least those listed on attached Schedule B. Upon reasonable notice, Heritage shall allow,
and Heritage shall ensure that Japer allows, Premier access to such records during normal working
hours. 3. DELIVERY, PRICING, BILLING AND PAYMENT

(a) Heritage and Jasper shall coordinate shipments to meet scheduled delivery dates of the Products
with Premier designated transportation providers. All shipments of the Products shall be by common
carrier, F.O.B. the Heritage [***] Facility or the Jasper Facility, as indicated by Premier in the
Purchase Order.

(b) Heritage shall purchase all ingredients and packaging materials identified in Schedule C to be
used in connection with the manufacture of the Products. Heritage shall invoice Premier through the
[***] billing as identified on Schedule C.

(c) Heritage shall charge Premier [***] as set forth in Schedule C.

(d) For Product produced at Jasper facilities, Jasper shall invoice Premier on the date Jasper
issues a Certificate of Analysis (COA) for those Products. Payment terms for these Product invoices
shall be [***]. For Product produced at Heritage facilities, Heritage shall invoice Premier on the
date the Products are loaded onto Premier's carrier. Payment terms for all these Product invoices
shall be [***]. Failure by Premier to meet payment terms of any invoice shall result in interest
being imposed on any unpaid balance at the rate of [***] per month, pro rata on a daily basis for
partial months, accrued from its due date or in the event such rate exceeds that permitted to be
charged by law, the maximum rate permitted by law.

(e) Heritage will maintain accurate and complete books of account and records covering all its
operations and transactions relating to this Agreement, including detailed purchasing and accounting
records, master manufacturing, batching, & quality control records, pertaining to the manufacture of
the Products, including records relating to the procurement and cost of all raw materials, packaging
materials, equipment, and any other cost associated with the manufacture of the Products until
[***]. Premier, shall have the right, directly or through its representative, to inspect, copy, and
audit all such records upon reasonable request and during normal business hours, acknowledging that
access to accounting and purchasing records will be limited to those supporting pass-through
materials costs and purchases of Premier specified equipment if any. 4. STORAGE, SHIPPING AND
INVENTORY

(a) During the term of this Agreement, Heritage agrees to handle and store reasonable amounts of raw
materials based upon the level of production expected [***]. With regard to finished Products,
Heritage agrees during the Term to store finished Products at no cost to Premier for a period not to
exceed [***] from the date of Heritage's issuance of a Certificate of Analysis ("COA"). Commencing
on [***] after the date the COA is delivered to Premier, a warehouse fee will be imposed that will
equal $[***], until such Products are delivered to Premier's carrier. [***] Capability of a
corrugated shipping case to withstand double stacking shall be mutually determined and agreed by
both Parties.

(b) Premier agrees to issue shipping instructions in full pallet increments of [***] and Heritage
agrees to make the Products available for shipping within [***]. Heritage shall ship oldest Products
first, unless otherwise directed in writing by Premier. Release of Products shall only be from
inventory that has completed any required incubation period and Heritage quality control release
protocols. 5

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 6 -->
(c) Heritage shall perform, and shall ensure Jasper performs, a documented inspection of all
trailers before loading to confirm they are free of any visible contamination or odors and fit for
use with food products. When products are properly palletized and loaded by Heritage or Jasper,
Premier shall be responsible for physical, in-transit damage loss of finished Products upon Heritage
or Jasper completing loading of the designated container or trailer, and sealing the same.

(d) Heritage shall notify Premier via email within [***] that Products are available for shipment.

(e) The following series of standard, regular, required reports and scorecard shall be provided by
Heritage to Premier at the indicated frequency:

1. Weekly Production Report.

2. Monthly Inventory Reports at Supplier's end of fiscal month to include

a. Inventory on hand,

b. Inventory on hold, and

c. Inventory adjusted.

3. Monthly Purchase Order receipt report - at the end of Supplier's fiscal month 5. TRADEMARKS

Premier represents and warrants that it owns or otherwise has the right to use all trademarks (the
"Trademarks") and copyrighted material (the "Copyrights") provided by Premier to Heritage, which are
provided solely for use in connection with the manufacture or packaging of the Products. Heritage
will not, and will ensure that Jasper does not, use any of the Trademarks or any marks that are
confusingly similar to, or likely to cause confusion with regard to, the Trademarks or Copyrights
owned or licensed by Premier for any other purpose without the prior written consent of Premier in
each instance. Provided, however, that the foregoing covenant shall not be construed to restrict or
prohibit Heritage from using any trademark, trade name, trade dress, labeling or packaging that
Heritage is using in commerce as of the date of this Agreement. Nothing contained in this Section 5
is intended to or does preclude Premier from enforcing any of its intellectual property rights,
including without limitation, its trademark rights. 6. QUALITY CONTROL

(a) Heritage agrees to perform, at its expense, sampling and testing procedures for the Products in
accordance with Schedule B, attached hereto, and all applicable governmental regulations. If
additional testing, not identified in Schedule B, is required by Premier, a reasonable additional
fee will be agreed upon between Heritage and Premier to cover the associated incremental cost. Other
quality control items to be performed under this Agreement are as follows:

(i) Normal production runs shall require Premier to provide at least two (2) non-work hour phone
numbers for Premier employees who can be contacted in the event a problem occurs during a production
run not being conducted during normal business hours. Said contacts and contact information shall be
listed in Schedule D.

(ii) Heritage shall keep retention samples in accordance with Schedule B.

(iii) Heritage shall not modify any processing instructions or Specifications without obtaining
Premier's prior written consent.

(iv) Heritage shall evaluate Products on a regular schedule at a sufficient frequency to confirm
that Products meet the Specifications, including the Post Holdings Quality Expectations Manual. Any
Products not conforming to the Specifications shall not be released for shipment. 6

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 7 -->
7. INDEMNITY

(a) Premier shall indemnify, defend and hold Heritage harmless from and against any and all loss,
cost, expense, claim, suit, damage or liability (including reasonable attorneys' fees and court
costs) (collectively "Losses") arising out of or relating to an infringement or alleged infringement
of any Trademarks or Copyrights in connection with the Products to the extent Heritage follows
Premier's instructions with regard to the proper display and use of the Trademarks and Copyrights.
In addition, Premier shall indemnify, defend and hold Heritage harmless from and against any and all
Losses arising out of or relating to: (i) Heritage's adherence to the Product Specifications,
identified in Schedule A, or written orders or instructions given by Premier to Heritage relating to
the manufacture or packaging of Products; (ii) Premier's breach of any of its obligations contained
herein; and (iii) the storage, sale, marketing, distribution and consumption of the Products, other
than any Losses which would be covered under Section 7(b) hereof.

(b) Heritage shall indemnify, defend and hold Premier harmless from and against any Losses arising
out of or relating to (i) Heritage's or Jasper's negligence or willful misconduct, (ii) the
manufacturing, packaging, storing and consumption of the Products (except to the extent resulting
from Heritage's compliance with Premier's Specifications), (iii) any breach of the Agreement by
Heritage or (iv) ingredients or packaging materials purchased by Heritage or Jasper. Heritage shall
not be responsible for any Losses arising out of or attributable to Heritage's manufacturing of the
Products in adherence with the Product Specifications, this Agreement, or any written orders or
instruction(s) from Premier regarding the manufacture or packaging of the Products, as set forth in
Section 7(a) above.

(c) The Party seeking indemnification shall promptly notify the other Party hereto in writing of any
suit, claim, or damage for which such Party has notice and to which these provisions may apply. In
the event suit is commenced, the indemnifying Party shall have the right to control the defense of
any such suit at its own cost. The appearance of the indemnifying Party in such proceeding shall not
be construed as an admission of liability and shall not constitute a waiver of any of its rights,
including, but not limited to, the indemnifying Party's right to hire its own counsel. 8. RISK OF
LOSS AND INSURANCE

(a) Title to the Products shall be in and remain with Premier from the date Products are delivered
to a carrier pursuant to Premier's instructions for delivery to Premier. Heritage shall bear the
risk of loss to the Products until the Products are delivered to such carrier for delivery to
Premier as set forth herein. Risk of loss to the Products shall also be with Heritage during
shipment between the Heritage Facilities pursuant to Section 2.

(b) Heritage and Jasper shall maintain insurance of the following kinds and in the following amounts
during the Term of this Agreement: i. Commercial General Liability Insurance with a limit of $[***]
each occurrence and $[***] in the aggregate, including Contractual, Completed-Operations and
Product-Liability Coverage with a limit of $[***] for each occurrence, covering both bodily injury
and property damage liability. ii. Umbrella/Excess Liability with a limit of $[***]. 7

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 8 -->
iii. Workers' Compensation Coverage plus Occupational Disease Insurance if Occupational Disease
coverage is required by the laws of the state where the Facility is located or work is to be
performed. Employers Liability $[***] each accident; $[***] disease, each employee; $[***] disease,
policy limit iv. Auto Liability $[***] combined single limit v. Product Recall Insurance coverage
for Products determined to be in violation of laws administered by the authorized government entity
who classifies the Products as unfit for intended use with limits of $[***] per policy year.

Heritage and Jasper shall have Premier named as an additional insured on its insurance policies in
subparts i, ii and iv above. Heritage and Jasper shall furnish Premier with a certificate from its
insurer verifying that it has the above insurance in effect during the duration of this Agreement
and that insurer acknowledges (a) the contractual liability assumed by Heritage and Jasper in this
Agreement and (b) that Premier is an additional insured on such policies and (c) Heritage's and
Jasper's CGL policies are primary and Premier's CGL policy is non-contributory and (d) a waiver of
subrogation shall be provided in favor of Premier on the CGL, Workers' Compensation and Auto
policies. Said certificate of insurance shall require Heritage's and Jasper's insurance carrier to
give Premier [***] written notice of any cancellation or change in coverage. Failure to provide such
certificate within [***] shall constitute a breach of this Agreement.

Certificate of Insurance:

Certificate holder language must read:

Premier Nutrition Corporation 5905 Christie Avenue Emeryville, CA 94608

Please send certificates to: [***] 9. CONFIDENTIALITY

Each Party recognizes that in the performance of this Agreement, it may acquire, directly or
indirectly from the other Party, proprietary, confidential, trade secret, or information that is not
otherwise available to the general public ("Confidential Information"). Each Party shall maintain
control of all Confidential Information it receives and not disclose it or use it for any other
purpose other than to perform its obligations under this Agreement. Each Party shall return the
Confidential Information, along with all materials derived therefrom, to the disclosing Party upon
demand or, destroy them and provide verification of destruction upon the termination of this
Agreement at the request of the disclosing Party. Each Party acknowledges that the value of the
other Party's Confidential Information is unique and substantial, and it may be impractical or
difficult to assess its value in monetary terms. Accordingly, in the event of an actual or potential
violation of this paragraph, the violating Party expressly consents to the enforcement of this
Agreement by injunctive relief or specific performance in addition to any and all other remedies
available to them. The Parties also agree to treat the terms and conditions of this Agreement as
Confidential Information.

The term Confidential Information shall not apply to portions of the Confidential Information that
Party receiving it can show: (i) are or become generally available to the public other than as a
result of a disclosure by the receiving Party; (ii) are in the receiving Party's possession from a
source (other than the furnishing Party) that is not prohibited from disclosing such information,
(iii) was known to the receiving Party prior to disclosure thereof by the furnishing Party; or (iv)
are independently developed by the receiving Party without the use of any non-public, confidential
or proprietary information received from the furnishing Party. A Party shall be entitled to disclose
the 8

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 9 -->
other Party's Confidential Information as required pursuant to judicial action, governmental
regulations or investigation, or other requirements. Such Party shall, to the extent allowed or
permitted by the applicable judicial action, governmental regulation or investigation or other
requirements, promptly notify the Party that furnished the Confidential Information prior to any
such disclosure, and reasonably cooperate (at the request and expense of the furnishing Party) with
the furnishing Party to contest or limit such disclosure. 10. FORCE MAJEURE

In the event that either Party shall be totally or partially unable to fulfill one or more of its
obligations hereunder as a result of acts or occurrences beyond the control of the Party affected,
such as, but not limited to, actions, omissions or impositions by local, state or federal
governmental authorities, fire, flood, earthquake or other natural disasters, acts of God,
revolution, strikes or fuel shortages, the Party so affected shall be totally or partially relieved
from fulfilling its obligations under this Agreement during the period of such force majeure;
provided, however, that the affected Party shall notify the other Party of the circumstances as soon
as reasonably possible; and further provided that if such period of force majeure shall continue for
a period of [***] or more, the Party not affected shall be entitled to terminate this Agreement by
giving notice to take effect immediately. The foregoing shall not relieve either Party of any
obligation to make payments required pursuant to this Agreement in accordance with the terms hereof.
Notwithstanding the foregoing, in the event there is a force majeure at either Heritage production
facility, then the non-force majeure facility shall not be required to produce the total production
quantities agreed upon for both facilities. However, the non-force majeure facility shall use
commercially reasonable efforts to produce as much Product as possible for Premier during the force
majeure period. Heritage shall not be responsible for any excess freight expense on Product incurred
by Premier due to the force majeure. 11. TERMINATION

(a) This Agreement shall commence on the Effective Date and shall terminate automatically without
notice on December 31, 2022, unless the Parties agree in writing to extend the term of the Agreement
(the initial term and any renewal terms are referred to collectively herein as the "Term"). Either
Party may terminate this Agreement immediately without notice should the other Party fail to cure,
within [***] after receipt of written notice thereof, any material breach of its obligations or
duties hereunder, provided, however that in the event of a material breach that cannot be cured
within [***], a Party shall not be deemed in default if it commences curing such default within the
[***] period, notifies the other Party of that commencement by e-mail, and thereafter cures such
default within [***] of the original written notice thereof. The following provisions shall survive
termination or expiration of this Agreement:

2(o) (warranties);

2(p)(q), 3(e) audit rights/access;

Schedule B (records);

7 (Indemnification); and

Section 8 (Risk of Loss and Insurance)

Section 9 (Confidentiality).

and Premier shall remain as an additional insured on the Heritage's policies, for [***]. If either
Party shall file a voluntary petition in bankruptcy, be declared bankrupt, make an assignment for
the benefit 9

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 10 -->
of the creditors, or suffer the appointment of a receiver or a trustee of its assets, that Party
shall be in breach of this Agreement and the other Party shall have the right to terminate this
Agreement by giving written notice to take effect immediately.

(b) So long as Premier has satisfied its payment obligations to Heritage pursuant to Section 3, upon
termination or expiration of this Agreement, any releasable Product in Heritage's possession shall
be promptly delivered to Premier within [***]. In addition, Premier shall purchase all Products and
ingredients, packaging and material Heritage has on hand and not previously billed to Premier at the
time of the termination that are used solely for the production of the Products, if any exist. The
ingredients, packaging, and materials used solely for Premier shall be so identified in Schedule C
and shall not exceed a [***] supply as calculated based on the previous [***] usage for the material
in question. If the vendor's minimum order quantity for a particular material exceeds a [***]
supply, then Heritage shall obtain permission from Premier to order such quantity. If Premier grants
permission to order the quantity greater than a [***] supply, then Heritage shall not be liable for
the excess inventory of this particular material. The cost of all ingredients and packaging material
to be purchased by Premier shall be [***]. In the event that Premier has defaulted in its payment
obligations hereunder, and failed to cure such default following notice as set forth in Section
11(a), Heritage shall have no obligation to deliver such releasable Product to Premier. In no event,
however, shall Heritage have the right to resell or otherwise use the releasable Product held in its
custody. 12. GOVERNING LAW

Venue for any litigation arising out of this Agreement shall be in any court of competent
jurisdiction located in San Francisco, California. The Parties hereby submit to the jurisdiction of
that state for such purposes. All matters relating to this Agreement, the rights of the Parties
hereunder and the construction of the terms hereof shall be governed by the laws of the State of
California, without regard to conflicts of laws principles. 13. NOTICES

Except as otherwise expressly set forth in this Agreement, all consents, authorizations, agreements,
approvals, notices, demands and other communications to be given or delivered under or by reason of
the provisions of this Agreement shall be in writing and shall be deemed to have been given when
delivered personally or by documented overnight delivery services, or sent by facsimile or other
electronic transmission service provided they are sent in a manner that provides confirmation of
their receipt. Notices, demands, and communications to the respective Parties shall, unless another
address is specified in writing, be sent to the address indicated below:

Notice to PREMIER:

VP Operations Premier Nutrition Corporation 188 Spear Street, Suite 600 San Francisco, CA 94608
Email: [***]

With a copy to General Counsel: Email: [***] 10

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 11 -->
Notice to JASPER/HERITAGE:

Chief Financial Officer Stremicks Heritage Foods, LLC 4002 Westminster Avenue Santa Ana, CA
92703-1310 Email: [***]

With a copy to: President of Jasper Products, L.L.C. Email: [***] 14. CONFLICTING TERMS

The terms of this Agreement shall supersede and take precedent over any conflicting terms found in
any purchase order issued by Premier or any invoice issued by Heritage. 15. NO WAIVER

The failure of either Party to assert a right hereunder or to insist upon compliance with any terms
or condition of this Agreement shall not constitute a waiver of that right or excuse the subsequent
performance or non-performance of any such term or condition by the other Party. 16. ENTIRE
AGREEMENT AND HEADINGS

This Agreement, schedules or addenda attached hereto and incorporated herein, as amended from time
to time, constitute the entire agreement of the Parties relating to the manufacture, packaging,
storage, and shipping of the Products, and any prior or contemporaneous agreements or understandings
relating thereto are superseded hereby. This Agreement may not be amended except by an instrument in
writing duly executed on behalf of the Party against whom such amendment is sought to be enforced.
All headings utilized herein are inserted for reference only and shall have no effect on the meaning
or construction of any terms of this Agreement. Notwithstanding the above, Premier shall have the
right to supplement, modify or amend, from time to time, the Specifications set forth on Schedule A
attached hereto; provided, however, that no such modification or amendment shall become part of this
Agreement until the same is delivered in writing to Heritage. All such modified products and their
formulations are and shall remain the proprietary and sole property of Premier unless otherwise
specified. 17. BINDING EFFECT

This Agreement, schedules or addenda attached hereto and incorporated herein, shall be binding upon
and shall inure to the benefit of the Parties hereto and their respective assignees and successors
in interest. This Agreement is not assignable or transferable by either Party, in whole or in part,
without the prior written consent of the other Party; provided, however that Premier may assign this
Agreement in the event that Premier is sold, merged into or with another entity, or undergoes a
"change in control". "Change in control" shall include without limitation (i) the cumulative sale,
assignment or other transfer of voting or beneficial equity securities of Premier representing more
than fifty percent (50%) of its voting or beneficial equity securities; (ii) Premier being a
constituent party to a merger, reorganization or similar transaction; or (iii) a sale, assignment or
other transfer of substantially all of Premier s assets or business. 18. NON-EXCLUSIVITY AND
NON-COMPETITION

(a) Nothing herein shall be construed to create a requirements contract or to require Premier to
purchase any Products, other than the Minimum Annual Order Volume as specified in 2 (c). Premier
reserves the right to buy Products or similar product from other co-packers, manufacturers, or
third-parties. 11

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 12 -->
(b) [***] 19. ATTORNEY FEES

Should either Heritage or Premier be required to institute legal action to enforce any of its rights
set forth in this Agreement, then the prevailing Party shall be entitled to reimbursement for all
reasonable attorneys' fees and costs incurred as determined by the court in any such action. If
Heritage or Premier become engaged in litigation (i) that is in any way connected with this
Agreement and (ii) in which either or both of the Parties assert and file one or more claims against
the other, the prevailing Party shall be entitled to an award of reasonable attorneys' fees, court
costs and out-of-pocket expenses, as determined by the trial court. 20. INDEPENDENT CONTRACTOR

The relationship of Heritage to Premier under this Agreement shall be that of an independent
contractor and no agency or employment relationship shall be implied by this Agreement. Accordingly,
Heritage shall be responsible for payment of all taxes including federal, state and local taxes
arising out of Heritage's activities under this Agreement, including, but not limited to, federal
and state income tax, social security tax, unemployment insurance tax, and any other taxes or
business license fees as required. 21. PRODUCT RECALLS

Premier shall have the sole right, exercisable in its discretion, to initiate and direct the content
and scope of a recall, market withdrawal, stock recovery, product correction and/or advisory safety
communication (any one or more referred to as a "Recall Action") regarding the Products. At
Premier's option, Premier can direct Heritage to, and upon such direction Heritage shall, conduct
such Recall Action (and Heritage shall ensure Jasper's cooperation). Premier shall determine, in its
sole discretion, the manner, text and timing of any publicity to be given such matters upon prior
consultation with Heritage. In the event a Recall Action is initiated or directed by Premier,
Heritage agrees to fully cooperate and take all such steps as are reasonably requested to implement
the Recall Action in a timely and complete manner. Any and all action to be taken in connection with
a Recall Action shall be in accordance with FDA policies and other applicable laws and regulations.
Heritage shall bear all costs, fees and out-of-pocket expenses associated with any Recall Action
which results from (i) Heritage's or Jasper's negligence or willful misconduct, (ii) Heritage's or
Jasper's failure to comply with Product Specifications or the Post Holdings Quality Expectations
Manual set forth on Schedule A, (iii) any breach of this Agreement by Heritage or (iv) ingredients
or packaging materials purchased by Heritage or Jasper. In all other cases, Premier shall bear all
costs associated with any Recall Action.

[Signature Page Next Following] 12

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 13 -->
IN WITNESS WHEREOF, the Parties have caused this Agreement to be executed by a duly authorized
officer on the day and year first above written. PREMIER NUTRITION CORPORATION STREMICKS HERITAGE
FOODS, LLC

BY: /s/ Darcy Davenport BY: /s/ Sam Stremick NAME (print): Darcy Davenport NAME (print): Sam
Stremick TITLE: President TITLE: President DATE: 1/8/18 DATE: 1/8/18 13

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
<!-- page 14 -->
[The schedules described below have been omitted pursuant to Item 601(a)(5) of Registration S-K.]

Schedules: A. Products Processing and Analytical Requirements B. HERITAGE Records C. Ingredients &
Materials to be supplied by HERITAGE and PREMIER, waste allowance, pricing schedule and all other
terms and conditions of sale. D. Premier Nutrition Contacts E. Post Holdings Quality Expectations
Manual

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
