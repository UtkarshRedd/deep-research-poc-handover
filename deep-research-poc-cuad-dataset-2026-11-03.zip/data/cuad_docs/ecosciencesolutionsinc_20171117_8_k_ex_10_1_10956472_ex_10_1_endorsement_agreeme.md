<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2017-11-14 |
| Parties | Eco Science Solutions, Inc ("ESSI"); Stephen Marley ("Talent") |
| Source | CUAD v1 / EcoScienceSolutionsInc_20171117_8-K_EX-10.1_10956472_EX-10.1_Endorsement Agreement |

ENDORSEMENT AGREEMENT

THIS ENDORSEMENT AGREEMENT (the "Agreement") is dated as of this 14th day of November 2017
("Effective Date"), by and between Eco Science Solutions, Inc. ("ESSI"), a Nevada corporation, and
Stephen Marley ("Talent"), an individual.

AGREEMENT

1. Engagement. ESSI engages Talent and Talent hereby accepts the engagement to act as a Spokesperson
for ESSI, and to provide his endorsement of all ESSI products and services, domestically and
worldwide.

2. Term of Agreement. The term of this Agreement shall be for one (1) year commencing on the
Effective Date and automatically renewing annually thereafter, unless either party provides a
thirty-day notice of written termination one to the other ("Term").

3. Grant. During the Term and subject to the limitations set forth in Paragraphs 9 and 10, ESSI
shall have the right to use the name, image, likeness, characterization, visual and audio
representation of Talent ("Talent Attributes") in connection with the ESSI product suite, in the
venue(s) as follows:

A. Promotional Territories ("Territories") shall include various online, outdoor, radio and
television promotional spots (specific promotional spots and content specifics to be mutually agreed
upon) promoting the ESSI product suite ("Commercial Placements") aired in various venues as
determined to best suit the needed promotion of ESSI products;

B. On ESSI's downloaded apps (UseHerbo, Herbo Wallet, FitRx) and websites (www.useherbo.com;
www.eccossi.com) ("Websites"), of which new ESSI owns and operates downloadable apps and websites
may be added to this list at the will of ESSI; and

C. ESSI Natural Supplementation Products.

D. In ESSI product-related press releases (of which only ESSI may produce and publish).

In connection with any ESSI's usage of Talent Attributes as outlined above in Paragraphs 3(A)-(D)
that are applicable to Dietary Supplements, ESSI will feature the following disclaimer in close
proximity to said usage: "STEPHEN MARLEY IS NOT A MEDICAL AUTHORITY. THESE STATEMENTS HAVE NOT BEEN
EVALUATED BY THE FOOD AND DRUG ADMINISTRATION. THIS PRODUCT IS NOT INTENDED TO DIAGNOSE, TREAT, CURE
OR PREVENT ANY DISEASE."

1

Source: ECO SCIENCE SOLUTIONS, INC., 8-K, 11/17/2017
<!-- page 2 -->
4. Duties of Talent and Rights of ESSI. During the Term and subject to the limitations set forth in
Paragraphs 9 and 10, Talent agrees to provide ESSI with the following:

A. Upon request by ESSI, two (2) production sessions to be used for the production of the various
medias to be used in Commercial placements ("Production Sessions"); the location, date and time of
the Production Sessions shall be mutually agreed upon by Talent and ESSI. In the event any
Production Session exceeds eight (8) hours in duration ESSI and Talent will negotiate in good faith
additional compensation to Talent for time in excess of eight (8) hours.

B. Talent will serve as a Special Advisor to ESSI, whose sole responsibility is to be listed as a
brand ambassador on the Websites and/or ESSI related press releases. With respect to Talent's
position as Special Advisory, Talent will not be responsible for any additional services such as
attending meetings, corporate functions, etc.

C. ESSI may request an additional production session(s), or a media tour or personal appearance(s)
of Talent for an additional fee to be mutually agreed upon by the parties.

5. Consideration. As consideration for Talent's services under this Agreement, ESSI agrees as
follows:

A. Equity Payment: ESSI will provide Talent with one-million (1,000,000) shares of restricted common
stock issued within ten business days of execution of this Agreement. B. Cash Payments:

(1) ESSI will provide monthly payment of Ten Thousand and NO/100 Dollars ($10,000) made payable to
Talent for Talent's social communications with its followers on popular social media venues,
including, but not limited to, Facebook, Instagram, Twitter and Snap Chat where Talent may
communicate about the ESSI product suite ("Social Communication"). The monthly Social Communication
schedule will be mutually agreed upon by Talent and ESSI one month in advance of the actual month of
communications. Once the monthly Social Communication schedule is set, the volume of Posts, Tweets
and Snaps will determine the total amount of monthly compensation available to Talent. ESSI's Social
Media Manager will keep track of Talent's activity pursuant to ESSI's Company quarter to determine
the amount of Cash Payment due for the quarter.

(a) Payments shall be made to Talent in the following manner, and to the following address:

6. Expenses. If applicable, ESSI agrees to provide and pay for the expenses related to Talent's
services provided in Paragraph 4, which shall include but not be limited to the following:

A. First-class airfare, first-class ground transportation, hotel accommodations, and meals for
Talent; and

2

Source: ECO SCIENCE SOLUTIONS, INC., 8-K, 11/17/2017
<!-- page 3 -->
B. First-class airfare, ground transportation and hotel accommodations for one (1) representative.

7. Union Dues and Fees. Talent represents that the services hereunder shall not be subject to SAG,
AFTRA or any other entertainment guild contract of which Talent is now, has been, or will be in the
future, bound to and that this Agreement is not in conflict with any contract Talent is bound.

8. Exclusivity. Talent represents and warrants that during the Term and in the Territories, Talent
will not endorse or make any appearances or advertisements on behalf of any other product which is
directly competitive to ESSI's products.

9.Review, Approval, and Ownership of Commercial Placements. All ESSI uses of Talent Attributes in
connection with the Commercial Placements and/or press releases shall be subject to the prior
written approval of Talent. Said written approval must be given within five (5) business days of
Talent's receipt or said usage shall be deemed unapproved. Any such usage featuring Talent in the
Commercial Placements and/or press releases shall be and remain the property of ESSI; however, ESSI
shall have the right to use said Commercial Placements and/or press releases solely as outlined in
Paragraph 3 and only during the Term. Talent may use said materials in whole or in part solely for
the purpose of presenting Talent's work in Talent's personal portfolio, website or otherwise and/or
on Talent's agent's website. Such usage may not be sold or transferred.

9.1 Press Releases. Talent may not, at any time, individually, or through his agent, manager,
family, friends, or associates publish a press release relative to ESSI without first obtaining the
written consent and approval of ESSI's management and counsel. In the event Talent does publish any
such press release, this Agreement shall be null and void and any outstanding balance owed to Talent
shall be voided and the 1,000,000 Shares of ESSI common stock issued to Talent returned to the
Company.

10. Termination for Cause

A. ESSI shall have the right to terminate this Agreement upon ten (10) days prior written notice to
Talent in the event Talent fails to perform the duties set forth in Paragraph 4 hereof or breaches
any other covenant or agreement set forth herein and fails to cure same (if curable) within seven
(7) days of receipt of written notice. Such termination shall relieve ESSI of its obligation to
provide any further consideration pursuant to this Agreement. B. Talent shall have the right to
terminate this Agreement upon ten (10) days prior written notice to ESSI in the event of the
occurrence of any of the following: (1) ESSI adjudicates as insolvent or declares bankruptcy; or (2)
ESSI fails to provide consideration due pursuant to this Agreement, within ten (10) days following
the date such consideration is due hereunder, provided that ESSI is notified in writing of such
non-payment by Talent and such payment by ESSI is not made within three (3) days following such
notification; or (3) ESSI breaches any representation, warranty, covenant or agreement set forth
herein and fails to cure same (if curable) within seven (7) days of receipt of written notice.
Furthermore, ESSI agrees that such termination shall not relieve it of its obligation to provide
consideration as contemplated hereunder. Talent shall not have waived any of its rights at law or in
equity by exercising any provision of this paragraph.

C. ESSI's rights to the use of Talent and Talent's Attributes as set forth in Paragraphs 3 and 4
shall end immediately should this Agreement be terminated pursuant to Paragraph 10(A) or Paragraph
10(B) above.

10. Notices. All notices provided for herein shall be given in writing by hand delivery, courier
service, or by certified mail return receipt requested to the addresses of the parties set forth as
follows (unless change of address by notice to the other party is given as provided in this
paragraph 10):

3

Source: ECO SCIENCE SOLUTIONS, INC., 8-K, 11/17/2017
<!-- page 4 -->
If to Talent:

Mr. Stephen Marley 16115 SW 117t h Ave Suite 21-A Miami, Florida 33177 If to ESSI: Mr. Jeffery
Taylor, President 1135 Makawao Avenue, Suite 103-188 Makawao, Hawaii 96768 with a copy to: Sharon
Mitchell, Corporate Counsel for ESSI

Sharon D. Mitchell SD Mitchell & Associates, PLC 829 Harcourt Rd. Grosse Pointe Park, Michigan 48230
11. Licensing. Nothing contained herein shall be construed to convey to ESSI any right to use the
names, trademarks, service marks, symbols, logos, emblems colors, etc. ("Marks"), of the Bob Marley
Family Foundation, or any other organization with which the Talent is or has been associated. All
rights to the use of such Marks must be acquired from the appropriate rights holder, and if such
Marks are used by ESSI then, in such event ESSI (a) shall provide Talent in advance with
satisfactory evidence of ESSI's right to use such Marks and (b) agree to indemnify, protect and hold
Talent harmless from and against any and all claims, damages and/or losses which may arise from
ESSI's use of such Marks.

12. Representations and Warranties of ESSI. Talent relies upon ESSI's skill and judgment and also
upon the following representations of ESSI which shall be in effect throughout the term of this
Agreement:

A. ESSI's products are, and will remain, merchantable and fit for the purpose for which they are
intended, and

B. ESSI's products do, and will, conform at all times to all applicable federal, state and local
laws, rules, regulations, ordinances, and other enactments and industry standards, including, but
not limited to, those relating to product safety.

4

Source: ECO SCIENCE SOLUTIONS, INC., 8-K, 11/17/2017
<!-- page 5 -->
13. Indemnity. ESSI shall be solely responsible for all liability arising out of production,
distribution and sale of its product(s). ESSI hereby agrees to indemnify, defend and hold harmless
Talent, his agents, representatives and employees (referred to collectively as "Talent Indemnities")
from and against any and all claims, actions, causes of action, damages, injuries, expenses,
liabilities (joint and several), penalties fines, attorney fees, court costs, and any other expenses
incurred by Talent Indemnities arising out of (1) breach by ESSI of any of the terms,
representations or warranties made by ESSI in this Agreement; or (2) ESSI product liability or
trademark patent or other proprietary right infringement; or (3) errors, omissions, fraudulent or
negligent acts by ESSI, its employees, agents or subcontractors in connection with (i) any
advertising featuring Talent; (ii) with the performance of ESSI's duties and obligations under this
Agreement; (iii) with the production, distribution, promotion, marketing and sales of products
including related product packaging; and/or (iv) with the operation and management of its production
and distribution facilities, however caused.

13.1 ESSI shall not be obligated to indemnify Talent with respect to damages which are the result of
the active negligence or willful misconduct of Talent. 14. Relationship of Parties. Nothing
contained in this Agreement shall be deemed or construed to place the parties in the relationship of
partners, joint venture participants, principal-agents, or employer-employee, it being understood
that the parties hereto are and will remain independent contractors in all respects and neither
party shall have any right to obligate or bind the other in any manner whatsoever.

15. Assignment. Neither this Agreement nor any of the rights or obligations contained herein may be
assigned or transferred by either party without the prior written consent of the other party.

16. Authority to Contract. Each of the parties hereto represents and warrants that it has full right
and power to enter into this Agreement, to perform all obligations to be performed by it hereunder,
and to grant all rights hereunder granted without violating the legal or equitable rights of any
other person or entity, and that the execution and performance of this Agreement will not conflict
with or result in a breach of or default under any of the terms or conditions of any agreement to
which either party has agreed, or is a party, or may be bound.

17. Construction of Agreement. Each party acknowledges that it has participated in the negotiation
of this Agreement and that no provision of this Agreement shall be construed against or he
interpreted to the disadvantage of any party hereto by any court or other governmental or judicial
authority by reason of such party having or deemed to have structured, dictated or drafted such
provision.

18. Modification. This Agreement constitutes the entire agreement with respect to the subject matter
contained herein and supersedes all previous communications and agreements between the parties
pertaining to the subject matter hereof, whether written or oral. The terms of this Agreement may
not be modified, waived, amended, discharged, terminated, or supplemented, or otherwise changed,
except by a written document executed by an authorized representative of each party.

19. No Waiver. A waiver by either party of any of the terms or conditions of this Agreement in any
instance shall not be deemed or construed to be a waiver of such term or condition for the future,
or of any subsequent breach thereof, or any other term or condition of this Agreement. All remedies,
rights, undertakings, obligations, and agreements contained in this Agreement shall be cumulative
and none of them shall be in limitation of any other remedy, right, undertaking, obligation or
agreement of either party.

20. Severability. If any provision of this Agreement, as applied to either party or to any
circumstance, shall be adjudged by a court of competent jurisdiction to be void or unenforceable,
whether at law or in equity, then such determination shall in no way affect any other provision of
this Agreement, or the validity or enforceability of this Agreement.

21. Choice of Law. Regardless of the place of execution hereof, this Agreement, all amendments
hereto, and any and all issues or controversies arising here from or related hereto, shall be
governed by and construed exclusively in accordance with the laws and decisions of the State of
Michigan.

5

Source: ECO SCIENCE SOLUTIONS, INC., 8-K, 11/17/2017
<!-- page 6 -->
22. Attorneys' Fees. If any action is necessary to enforce the provisions of this Agreement,
including any claims or demands, or to interpret this Agreement, the prevailing party shall be
entitled to reasonable attorneys' fees, costs and necessary disbursements in addition to any other
relief to which it may otherwise he entitled.

23. Captions: Structure. Section headings used in this Agreement are for convenience of reference
only and shall not in any way affect the interpretation of any section of this Agreement or of the
Agreement itself.

24. Time is of the Essence. Time is of the essence with respect to the performance of the duties and
obligations hereunder.

25. Counterparts. This Agreement may be executed in one or more counterparts, each of which shall be
deemed an original and all of which when taken together shall be construed as a single instrument.
This Agreement may be executed by facsimile or other electronic transmissions, and signatures on any
facsimile or electronic transmission copy hereof shall be deemed authorized original signatures.

26. No Third-Party Beneficiaries. This Agreement is not for the benefit of any third party and shall
be deemed not to give any right or remedy to such third party, whether referred to herein or not.

27. Recitals. The recitals contained in this Agreement are true and correct and are incorporated
herein by reference.

28. Confidentiality and Non-Disclosure

A. Talent's endorsement and position of spokesperson of ESSI is for the sole purpose of the
endorsement of the Company's products, and to offer information, based upon Talent's use and
knowledge of ESSI's products. At no time whatsoever, in any manner whatsoever, is Talent authorized
to discuss ESSI's financial condition, either in speculation or actual knowledge of such.

B. Talent's position as a special advisor may provide Talent access to information that has not been
made public and Talent agrees, to, at all times, keep in strict confidence any information he may
come across that is not yet public, including, but not limited to, information about ESSI's stock,
new products, acquisitions, and/or any other corporate action the Company may take, or has taken.
Confidential treatment of this information extends to non-disclosure to Talent's friends, family,
business associates, and any other person seeking information regarding the Company's financial
information, stock, or corporate actions.

6

Source: ECO SCIENCE SOLUTIONS, INC., 8-K, 11/17/2017
<!-- page 7 -->
The parties hereto have caused this Agreement to be executed and delivered as of the date first
above written.

STEPHEN MARLEY

By: /s/Stephen Marley Stephen Marley Talent

ECO SCIENCES SOLUTIONS, INC.

By: /s/Jeffery Taylor Jeffery Taylor CEO

7

Source: ECO SCIENCE SOLUTIONS, INC., 8-K, 11/17/2017
