<!-- page 1 -->
# First Amendment to Credit Agreement — Halvorsen Marine Holdings
| Field | Value |
|---|---|
| Document Type | Amendment |
| Effective Date | 2025-07-31 |
| Parties | Halvorsen Marine Holdings, Inc.; Meridian Trust Bank, N.A. |
| Facility ID | FAC-2025-0042 |
| Version | First Amendment |

THIS FIRST AMENDMENT TO CREDIT AGREEMENT (this "Amendment") is entered into as of 2025-07-31 (the "First Amendment Effective Date") among Halvorsen Marine Holdings, Inc. (the "Borrower"), the Lenders party hereto and Meridian Trust Bank, N.A., as Administrative Agent.

## Recitals
WHEREAS, the Borrower, the Lenders and the Administrative Agent are parties to that certain Credit Agreement dated as of 2025-02-14 (the "Credit Agreement"; facility FAC-2025-0042);
WHEREAS, the Borrower has requested, and the Lenders have agreed, to relax the maximum Leverage Ratio and to reprice the Loans;
NOW, THEREFORE, the parties agree as follows.
<!-- page 2 -->
## Section 1 — Amendments to the Credit Agreement
Effective as of the First Amendment Effective Date, the Credit Agreement is amended as follows:
1.1 Section 7.1 is amended by replacing "4.00 to 1.00" with "4.50 to 1.00", so that the Borrower shall not permit the Leverage Ratio as of the last day of any fiscal quarter to exceed 4.50 to 1.00.
1.2 The definition of "Applicable Margin" in Section 1.1 is amended by replacing "2.75%" with "3.00%", so that the Applicable Margin for Term SOFR Loans is 3.00% per annum.

## Section 2 — Conditions to Effectiveness
This Amendment becomes effective on the date the Administrative Agent receives counterparts hereof executed by the Borrower and the Required Lenders, together with an amendment fee for the account of each consenting Lender equal to 0.125% of such Lender's Commitment.
<!-- page 3 -->
## Section 3 — Representations; Reaffirmation
The Borrower represents that no Default has occurred and is continuing and that the representations in Article V of the Credit Agreement are true and correct in all material respects on the date hereof.
Each Guarantor, by its acknowledgment below, reaffirms its obligations under the Guarantee and the Security Agreement after giving effect to this Amendment.
## Section 4 — Effect; Governing Law
Except as expressly amended hereby, the Credit Agreement and the other Loan Documents remain in full force and effect and are hereby ratified and confirmed. This Amendment is a Loan Document.
This Amendment shall be governed by the laws of the State of New York. Notices hereunder shall be given in the manner set forth in Section 10.1 of the Credit Agreement.
Halvorsen Marine Holdings, Inc., as Borrower — By: /s/ Authorized Signatory
Meridian Trust Bank, N.A., as Administrative Agent — By: /s/ Authorized Signatory
