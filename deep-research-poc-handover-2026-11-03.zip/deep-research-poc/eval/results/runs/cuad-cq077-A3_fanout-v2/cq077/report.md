# Among the following 8 agreements, which contain a non-compete clause? For each, quote t...

*Question:* Among the following 8 agreements, which contain a non-compete clause? For each, quote the clause. Agreements: the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley (dated 2017-11-14); the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. (dated 2011-03-14); the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc (filed 2018-11-09); the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC (dated 2013-05-15); the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies (filed 2005-11-02); the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01); the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. (dated 2010-01-01); the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. (filed 2013-09-26).

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Does the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley da...

The Endorsement Agreement between Eco Science Solutions, Inc. and Stephen Marley is dated as of November 14, 2017. [4cb98e07400203bf p.1] This agreement contains an exclusivity/non-compete clause. [4cb98e07400203bf p.3] Section 8 states: "8. [uncited] Exclusivity. [uncited] Talent represents and warrants that during the Term and in the Territories, Talent will not endorse or make any appearances or advertisements on behalf of any other product which is directly competitive to ESSI's products." [4cb98e07400203bf p.3]

## Does the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema...

The Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. is dated March 14, 2011. [23e65a3b8bc5cc9e p.1] This agreement contains a non-compete clause in Section 11.3(a). [23e65a3b8bc5cc9e p.25] The clause states: "Section 11.3 Non-Competition and Non-Solicitation. [uncited] (a) During the Term, except as otherwise provided in this Agreement, Network Affiliate and its affiliates agree not to engage or participate in any business, hold equity interests, directly or indirectly, in another entity, whether currently existing or hereafter created, or participate in any other joint venture that competes or would compete with any business that NCM is authorized to conduct in the Territory pursuant to this Agreement, whether or not NCM is actually conducting such business in a particular portion of the Territory. [uncited] The foregoing restrictions shall not apply (i) in the event Network Affiliate or its affiliate acquires a competing business as an incidental part of an acquisition of any other business that is not prohibited by the foregoing, if Network Affiliate disposes of the portion of such business that is a competing business as soon as commercially reasonable, (ii) to any direct or indirect ownership or other equity investments by Network Affiliate or its affiliates in such other competing business that represents in the aggregate less than 10% of the voting power of all outstanding equity of such business, o…". [23e65a3b8bc5cc9e p.25]

## Does the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope He...

The Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc filed 2018-11-09 contains a non-compete clause. [61c29bdb3ab6960e p.2] [61c29bdb3ab6960e p.2] Section 3 states: "3. [uncited] Restriction on Promotion of Competing Products. [uncited] During the term of this agreement, Distributor shall not market, sell advertise or promote the sale or use of any product or device which is competitive with or substantially similar to the Products, without the prior express written consent". [61c29bdb3ab6960e p.2] The clause continues: "of Erchonia, nor shall they assist any third party in doing so. [uncited] Notwithstanding the foregoing, to the extent Distributor or Distributor's customer is a licensed health care professional or licensed health care practitioner, nothing in this paragraph shall prevent or limit Distributor or Distributor's customer from exercising their independent medical judgment with regard to the treatment of any patient.". [61c29bdb3ab6960e p.2]

## Does the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC date...

Section 7.2(e) titled "Non-Compete" states that the referenced Settlement Agreement does not contain a covenant-non-compete applicable to the relevant party, and PcoMed is not aware of any such covenant preventing employment with PcoMed. [31cbf0d18f7d763e p.13] The provision reads: "(e) Non-Compete. [uncited] The Settlement Agreement and Mutual Release between *** and *** does not contain a covenant-non-compete applicable to *** and, to the best of PcoMed's current knowledge, *** is not subject to any covenant-non-compete that would prevent is employment with PcoMed."  Section 3.2 discusses conversion of exclusive rights to non-exclusive upon default, allowing third parties to use the technology in competing products. [31cbf0d18f7d763e p.13] [31cbf0d18f7d763e p.7] The provision reads: "If PcoMed makes such election, the Right shall be a nonexclusive right at the end of such 45-day cure period, and PcoMed may thereafter allow other Third Parties to use the PcoMed Surface Modification Technology in products that are in competition with the Integra Products."  Neither provision constitutes a non-compete clause binding the parties to this Supply Agreement. [31cbf0d18f7d763e p.7] [31cbf0d18f7d763e p.13] [31cbf0d18f7d763e p.7]

[GAP] The evidence does not contain any other non-compete clause binding the parties to the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC dated 2013-05-15.

## Does the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity...

The Cooperation Agreement between e.l.f. [uncited] Beauty, Inc. and Marathon Partners Equity Management, LLC dated 2020-07-01 does not contain a non-compete clause. [e42a4ef8cda58762 p.5] The closest provision is Section 5 Standstill Covenants, which restricts competitive and activist actions against the Company during the Support Period but does not use the term "non-compete" and does not restrict the Marathon Parties from competing in the beauty business. [e42a4ef8cda58762 p.5] Section 5(a) states: "5. [uncited] Standstill Covenants. [uncited] (a) Except as otherwise contemplated in Section 4 of this Agreement, at all times during the Support Period, the Marathon Parties shall not, and shall cause their Affiliates and Associates and their and such Affiliates' and Associates' respective equity owners (including members and limited partners), directors, officers, managers and employees not to, and will direct their consultants, agents, representatives, attorneys and advisors (to the extent directly or indirectly acting on behalf of the Marathon Parties) (collectively, the "Marathon Party Representatives") not to, directly or indirectly, in any manner, alone or in concert with others:". [e42a4ef8cda58762 p.5]

## Does the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GA...

The Sponsorship Agreement dated 2010-01-01 between Stallings Capital Group Consultants, Ltd. [uncited] ("Racing") and GAINSCO, INC. [uncited] ("Sponser") contains a non-compete-type restriction. [ab1fd1dd637746ab p.1] Section 2(v) restricts Racing from endorsing competing entities, products, or services during the term. [ab1fd1dd637746ab p.2] The clause states: "(v) prohibiting the endorsement by Racing and any members of Racing, including the drivers, of any entities, products or services which are in direct competition or otherwise inconsistent with the Sponsor or it products or services, unless such endorsement activity is approved in writing by Racing and the Sponsor; and". [ab1fd1dd637746ab p.2]

## Does the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry H...

The Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. was filed on 2013-09-26. [64e3019755b942aa p.1] The document contains an entire agreement clause stating that there are no restrictions, agreements, promises, warranties, covenants or undertakings between the Parties other than those expressly set forth in the document. [64e3019755b942aa p.8] No non-compete clause is present in the provided evidence. [64e3019755b942aa p.8]

[GAP] The evidence does not include a non-compete clause for this agreement.

## Not established by the evidence

[GAP] No evidence was found for: Does the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies filed 2005-11-02 contain a non-compete clause, and if so quote it?

## Verification appendix

Claims: 37 · supported: 21 · partially: 0 · dropped: 0 · gaps: 16 · tier-1 support rate: 1.00

Notes: outline from 8 fan-out findings (no outline call); 1 empty section(s) collapsed into gaps: Does the Reseller Agreement between Touchstar Software Corporation and Worldwide Strate...

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e8→[4cb98e07400203bf p.1] |  |
| s1.2 | s1 | keep | 1.00 | e7→[4cb98e07400203bf p.3] |  |
| s1.3 | s1 | gap |  |  | no evidence cited |
| s1.4 | s1 | gap |  |  | no evidence cited |
| s1.5 | s1 | keep | 1.00 | e7→[4cb98e07400203bf p.3] |  |
| s2.1 | s2 | keep | 1.00 | e10→[23e65a3b8bc5cc9e p.1] |  |
| s2.2 | s2 | keep | 1.00 | e3→[23e65a3b8bc5cc9e p.25] |  |
| s2.3 | s2 | gap |  |  | no evidence cited |
| s2.4 | s2 | gap |  |  | no evidence cited |
| s2.5 | s2 | keep | 1.00 | e3→[23e65a3b8bc5cc9e p.25] |  |
| s3.1 | s3 | keep | 1.00 | e1→[61c29bdb3ab6960e p.2] e2→[61c29bdb3ab6960e p.2] |  |
| s3.2 | s3 | gap |  |  | no evidence cited |
| s3.3 | s3 | gap |  |  | no evidence cited |
| s3.4 | s3 | keep | 1.00 | e1→[61c29bdb3ab6960e p.2] |  |
| s3.5 | s3 | gap |  |  | no evidence cited |
| s3.6 | s3 | keep | 1.00 | e2→[61c29bdb3ab6960e p.2] |  |
| s4.1 | s4 | keep | 1.00 | e5→[31cbf0d18f7d763e p.13] |  |
| s4.2 | s4 | gap |  |  | no evidence cited |
| s4.3 | s4 | keep | 1.00 | e5→[31cbf0d18f7d763e p.13] e6→[31cbf0d18f7d763e p.7] |  |
| s4.4 | s4 | keep | 1.00 | e6→[31cbf0d18f7d763e p.7] e5→[31cbf0d18f7d763e p.13] e6→[31cbf0d18f7d763e p.7] |  |
| s4.5 | s4 | gap |  |  |  |
| s5.1 | s5 | gap |  |  | no evidence cited |
| s5.2 | s5 | keep | 1.00 | e14→[e42a4ef8cda58762 p.5] |  |
| s5.3 | s5 | keep | 1.00 | e14→[e42a4ef8cda58762 p.5] |  |
| s5.4 | s5 | gap |  |  | no evidence cited |
| s5.5 | s5 | gap |  |  | no evidence cited |
| s5.6 | s5 | keep | 1.00 | e14→[e42a4ef8cda58762 p.5] |  |
| s6.1 | s6 | gap |  |  | no evidence cited |
| s6.2 | s6 | gap |  |  | no evidence cited |
| s6.3 | s6 | keep | 1.00 | e11→[ab1fd1dd637746ab p.1] |  |
| s6.4 | s6 | keep | 1.00 | e9→[ab1fd1dd637746ab p.2] |  |
| s6.5 | s6 | keep | 1.00 | e9→[ab1fd1dd637746ab p.2] |  |
| s7.1 | s7 | keep | 1.00 | e12→[64e3019755b942aa p.1] |  |
| s7.2 | s7 | keep | 1.00 | e13→[64e3019755b942aa p.8] |  |
| s7.3 | s7 | keep | 1.00 | e13→[64e3019755b942aa p.8] |  |
| s7.4 | s7 | gap |  |  |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [61c29bdb3ab6960e p.2 L98-101] keep (1.0): "3. Restriction on Promotion of Competing Products. During the term of this agreement, Distributor shall not market, sell advertise or promote the sale or use of any product or device which is competitive with or substantially similar to the…"
- e2 [61c29bdb3ab6960e p.2 L101-105] keep (1.0): "of Erchonia, nor shall they assist any third party in doing so. Notwithstanding the foregoing, to the extent Distributor or Distributor's customer is a licensed health care professional or licensed health care practitioner, nothing in this …"
- e3 [23e65a3b8bc5cc9e p.25 L947-963] keep (1.0): "Section 11.3 Non-Competition and Non-Solicitation. (a) During the Term, except as otherwise provided in this Agreement, Network Affiliate and its affiliates agree not to engage or participate in any business, hold equity interests, directly…"
- e5 [31cbf0d18f7d763e p.13 L640-642] keep (1.0): "(e) Non-Compete. The Settlement Agreement and Mutual Release between *** and *** does not contain a covenant-non-compete applicable to *** and, to the best of PcoMed's current knowledge, *** is not subject to any covenant-non-compete that w…"
- e6 [31cbf0d18f7d763e p.7 L356-359] keep (1.0): "If PcoMed makes such election, the Right shall be a nonexclusive right at the end of such 45-day cure period, and PcoMed may thereafter allow other Third Parties to use the PcoMed Surface Modification Technology in products that are in comp…"
- e7 [4cb98e07400203bf p.3 L105-107] keep (1.0): "8. Exclusivity. Talent represents and warrants that during the Term and in the Territories, Talent will not endorse or make any appearances or advertisements on behalf of any other product which is directly competitive to ESSI's products."
- e8 [4cb98e07400203bf p.1 L10-14] keep (1.0): "THIS ENDORSEMENT AGREEMENT (the "Agreement") is dated as of this 14th day of November 2017 ("Effective Date"), by and between Eco Science Solutions, Inc. ("ESSI"), a Nevada corporation, and Stephen Marley ("Talent"), an individual."
- e9 [ab1fd1dd637746ab p.2 L55-58] keep (1.0): "(v) prohibiting the endorsement by Racing and any members of Racing, including the drivers, of any entities, products or services which are in direct competition or otherwise inconsistent with the Sponsor or it products or services, unless …"
- e10 [23e65a3b8bc5cc9e p.1 L10-13] keep (1.0): "DIGITAL CINEMA DESTINATIONS CORP. NETWORK AFFILIATE AGREEMENT THIS NETWORK AFFILIATE AGREEMENT (this "Agreement") is made as of this 14th day of March, 2011 by and between National CineMedia, LLC, a Delaware limited liability company ("NCM"…"
- e11 [ab1fd1dd637746ab p.1 L2-8] keep (1.0): "# SPONSORSHIP AGREEMENT | Field | Value | |---|---| | Document Type | Sponsorship Agreement | | Agreement Date | 2010-01-01 | | Parties | Stallings Capital Group Consultants, Ltd. ("Racing"); GAINSCO, INC. ("Sponser")"
- e12 [64e3019755b942aa p.1 L2-8] keep (1.0): "# Strategic Alliance Agreement | Field | Value | |---|---| | Document Type | Strategic Alliance Agreement | | SEC Filing Date | 2013-09-26 | | Parties | Freedom Mortgage Corporation ("Freedom Mortgage"); Cherry Hill Mortgage Investment Corp…"
- e13 [64e3019755b942aa p.8 L359-364] keep (1.0): "This Agreement, including the Exhibits and Schedules hereto and the documents and other writings referred to herein or therein or delivered pursuant hereto, contains the entire agreement and understanding of the Parties with respect to its …"
- e14 [e42a4ef8cda58762 p.5 L279-287] keep (1.0): "5. Standstill Covenants.

(a) Except as otherwise contemplated in Section 4 of this Agreement, at all times during the Support Period, the Marathon Parties shall not, and shall cause their Affiliates and Associates and their and such Affili…"
