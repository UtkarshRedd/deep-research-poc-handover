<!-- page 1 -->
# PROMOTION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Promotion Agreement |
| Agreement Date | 1998-06-01 |
| Parties | ASHWORTH, INC. ("Company, "Ashworth"); JAMES W. NANTZ III ("Nantz"); NANTZ COMMUNICATIONS, INC. ("Nantz Communications") |
| Source | CUAD v1 / ASHWORTHINC_01_29_1999-EX-10.(D)-PROMOTION AGREEMENT AND NANTZ COMMUNICATIONS, INC. |

EXHIBIT 10(d)

PROMOTION AGREEMENT ASHWORTH, INC., JAMES W. NANTZ III AND NANTZ COMMUNICATIONS, INC. THIS AGREEMENT
is entered into by and among ASHWORTH, INC. (The "Company" or "Ashworth"), JAMES W. NANTZ III
("Nantz") and NANTZ COMMUNICATIONS, INC. ("Nantz Communications"), effective as of June 1, 1998.

WHEREAS, the Company desires to retain Nantz Communications and Nantz to provide certain promotional
and other services and Nantz Communications and Nantz are willing to provide such services on the
terms and conditions set forth herein; and

WHEREAS, the parties hereto desire to set forth in writing their agreement as to such promotion
arrangement;

NOW, THEREFORE, in consideration of the mutual covenants contained herein and other good and
valuable consideration, the receipt and sufficiency of which are hereby acknowledged, the parties
hereto hereby agree as follows:

DEFINITIONS

As used herein, the terms set forth below shall be defined as follows:

ENDORSEMENT shall include only the right to use the name, any nickname, initials, autograph,
facsimile signature, photograph, portrait, likeness, and/or endorsement of Nantz.

ASHWORTH APPAREL shall mean all ASHWORTH(R) brand sportswear apparel contained in the Company's
present and future collections (during the Term (as defined below)).

ASHWORTH PRODUCTS shall mean, collectively, Ashworth Apparel and Ashworth hats and shoes.

DISABILITY shall mean mental or physical illness or condition rendering Nantz incapable of
fulfilling the services to be provided by him under this Agreement for a continuous period of at
least 60 days.

PREMIUM PROGRAM shall mean any traffic builder or other program involving the use of a premium to
sell products or services other than Ashworth products and shall include any program primarily
designed to attract the consumer to purchase a product or service other than Ashworth Products
themselves.

CONTRACT YEAR shall mean a period of twelve (12) successive months commencing on any first day of
June during the Term.

Ashworth/Nantz Promotion Agreement - -------------------

TERM OF RELATIONSHIP 1. GRANT AND ACCEPTANCE. The Company hereby retains Nantz Communications and
Nantz to provide the below described services (the "Services") and Nantz Communications and Nantz
agree to provide the Services upon the terms and conditions herein set forth.

2. TERM. Except as otherwise provided herein, this Agreement shall commence effective June 1, 1998,
and shall continue for a term of three (3) years expiring May 31, 2001 (the "Term").

SERVICES

Nantz Communications and Nantz shall furnish the following Services:

1. ENDORSEMENT. Subject to the terms and conditions hereof, Nantz Communications grants to the
Company the Endorsement throughout the world during the Term in connection with the advertisement,
promotion and sale by the Company of Ashworth Products except in connection with Premium Programs.

2. ASHWORTH APPAREL AND PRODUCTS. Subject to any restrictions, contractual or otherwise, on Nantz
Communications or Nantz (collectively, the "Restrictions"), Nantz shall wear Ashworth Products, when
possible and as reasonably appropriate, while broadcasting all professional sports tournaments and
other professional sports outings, and during any professional sports clinics or instructions given
by Nantz Communications or Nantz; provided that the Company has provided Nantz, at no charge, with
sufficient amounts of Ashworth Products in styles and sizes Nantz finds suitable and appropriate for
his use, subject to the restriction under Paragraph 4 of Section COMPENSATION AND CONSULTING FEES.

3. LOGOS. Except as otherwise provided herein, and subject to the Restrictions, Nantz Communications
agrees that such Products may prominently bear the Company's logo and shall not bear any other
logos.
<!-- page 2 -->
4. PHOTOGRAPHY, SPEAKING AND STORE APPEARANCES. Nantz agrees to be available for up to four
photography sessions (2 in Southern California during the week and 2 to be at Nantz's site locations
or tournaments), two speaking engagements, and three store appearances each Contract Year, at times
and places mutually convenient for Nantz and the Company but in no event at times which adversely
impact on the schedules of Nantz Communications or Nantz. Nantz Communications shall have the right
to review and reject in good faith the use of any advertising, promotion or other programs and
materials which include Nantz or his image. No use shall be made of any such programs or materials
hereunder unless and until the same has been approved by Nantz

Ashworth/Nantz Promotion Agreement - -------------------

Communications. The Company agrees that each photography session shall not exceed one and one-half
days and each speaking engagement and store appearance shall not exceed one-half day. The Company
further understands that failure to utilize services of Nantz pursuant to this section shall not
result in any reduction in payments to Nantz Communications hereunder, nor may the obligations to
provide Services be carried forward from one Contract Year to another Contract year. The obligations
of Nantz Communications and Nantz to provide the Services hereunder are subject to the condition
that payments to Nantz Communications are current and up to date.

5. NEW ACCOUNTS, CELEBRITIES. Nantz agrees to assist Ashworth in locating potential new accounts
based on his professional contacts, assist Ashworth in gaining access to celebrities and CBS
executives which Ashworth could provide clothes for special events and also assist in gaining access
to non-golf professionals who potentially would wear Ashworth clothes.

6. SPECIAL EVENTS. Nantz will assist Ashworth in creating, promoting and participating in an event
(i.e., golf tournament, cocktail reception, etc.) ---- to be associated with a major sporting event
(i.e., PGA Championship, ---- Masters, etc.).

7. EMPLOYEE STATUS. Nantz will be a full time Ashworth employee rather than an independent
contractor.

8. BOARD OF DIRECTORS. Nantz agrees to be nominated, elected to and serve on the Board of Directors
of Company in the capacity of voting director.

9. OTHER OBLIGATIONS. The Company acknowledges that Nantz Communications' and Nantz's obligations to
CBS or any other television station or network with which Nantz Communications or Nantz has a
contract or arrangement shall take precedence over any other commitments of Nantz Communications or
Nantz under this Agreement.

INDEMNIFICATION

Neither Nantz Communications nor Nantz shall be liable for any obligations of the Company resulting
directly or indirectly from the Endorsement of Ashworth Products. The Company shall protect,
indemnify and hold harmless each of Nantz Communications and Nantz against any and all expenses,
damages, claims, suits, actions, judgments and costs whatsoever, arising out of, or in any way
connected with such Endorsement, in any advertising or promotional materials furnished by or on
behalf of the Company, actions or omissions of the Company or any claim or action for personal
injury, death or other cause of action involving alleged defects in Ashworth Products, including but
not limited to indemnification of reasonable legal expenses incurred in defense of all such claims.
Further, Nantz Communications or Nantz shall have the

Ashworth/Nantz Promotion Agreement - -------------------

right to select legal counsel to represent it or him in the event of any such claims or legal
proceedings, and the costs of such legal representation shall be paid by the Company.

INSURANCE

The Company agrees to provide and maintain, at its own expense, advertising and product liability
insurance each with limits no less than $5,000,000 and within thirty (30) days from the date hereof,
the Company will submit to Nantz Communications a fully paid policy or certificate of insurance
naming Nantz Communications and Nantz as insured parties, requiring that the insurer shall not
terminate or materially modify such without written notice to Nantz Communications at least twenty
(20) days in advance thereof.

The Company further agrees to provide and maintain, at its own expense, a policy of Directors and
Officers Insurance with limits no less than $25,000,000 and within thirty (30) days from the date
hereof, the Company will submit to Nantz Communications a fully paid policy or certificate of
insurance naming Nantz as an insured party, requiring that the insurer shall not terminate or
materially modify such without written notice to Nantz Communications at least twenty (20) days in
advance hereof.

COMPENSATION AND CONSULTING FEES
<!-- page 3 -->
As full compensation for Services, the Company shall pay Nantz Communications the following fees:

10. CONSULTING FEE. The Company shall pay Nantz Communications an annual consulting fee of $30,000,
such fee to be paid in equal quarterly installments of $7,500 on the 1st day of each June,
September, December and March of each Contract year.

11. ADDITIONAL FEES. If Nantz agrees to participate in more than three store appearances in any
given Contract Year, the Company shall pay Nantz Communications an additional fee of $7,500 for such
additional appearance prior to or simultaneously with such appearances.

12. REIMBURSEMENT OF EXPENSES. The Company shall reimburse Nantz Communications for expenses
reasonably incurred by Nantz or Nantz Communications in connection with the Services to the Company
including, but not limited to, first-class air fare, hotel accommodations, local transportation and
meals. Nantz Communications shall furnish the Company with an itemized statement from time to time,
together with, whenever possible, actual bills, receipts, and other evidence of expenditure. Nantz
Communications shall be reimbursed within thirty (30) days after receipt by the Company of such
itemized statements and attachments.

Ashworth/Nantz Promotion Agreement - -------------------

As full compensation for Services, the Company shall provide and issue to Nantz the following:

13. APPAREL. The Company shall furnish Nantz, at no cost, with sufficient Ashworth Products to be
used by him in connection with the Services and for the personal use of Nantz and his immediate
family. The cost of said Product shall not exceed $12,000 (at wholesale) during any single Contract
Year.

14. STOCK OPTIONS. a) As consideration for the rights granted and the services to be rendered
hereunder, the Company hereby grants to Nantz options (the "Options"), to purchase shares of the
common stock of the Company par value $.001 per share (the "Share"), which are exercisable as
follows:

15. The first Option to purchase 40,000 Shares upon payment of the aggregate Option Share Price (as
defined below) for the number of Shares so purchased shall become exercisable on June 1, 1999,
unless this Agreement is terminated as provided herein prior to such date, in which case this Option
shall be canceled. Once exercisable, this Option may be exercised in full or in any number of
partial exercises or in combination with the full or partial exercise of any other Option for a
period terminating upon the earlier to occur of (A) the fifth anniversary of the initial
exercisability date or (B) the date of termination of this Agreement, as provided herein, if this
Agreement is terminated prior to May 30, 2001.

16. The second Option to purchase up to an additional 40,000 shares upon payment of the aggregate
Option Share Price for the number of Shares so purchased shall become exercisable on June 1, 2000,
unless this Agreement is terminated as provided herein prior to such date, in which case this Option
shall be canceled. Once exercisable, this Option may be exercised in full or in any number of
partial exercises or in combination with the full or partial exercise of any other Option for a
period terminating upon the earlier to occur of (A) the fifth anniversary of the initial
exercisability date or (B) the date of termination of this Agreement, as provided herein, if this
Agreement is terminated prior to May 30, 2001;

17. The third Option to purchase up to an additional 40,000 shares upon payment of the aggregate
Option Share Price for the number of Shares so purchased shall become exercisable on June 1, 2001,
unless this Agreement is terminated as provided herein prior to such date, in which case this Option
shall be canceled. Once exercisable, this Option may be exercised in full or in any number of
partial exercises or in combination with the full or partial exercise of any other Option for a
period terminating upon the earlier to occur of (A) the fifth anniversary of the initial
exercisability date or (B) the date of termination of this Agreement, as provided herein, if this
Agreement is terminated prior to May 30, 2001;

The "Option Share Price" shall initially be $6 per Share as approved by the Compensation Committee
at its regular meeting held on December 15, 1998.

Ashworth/Nantz Promotion Agreement - -------------------

b) The Options being granted hereunder are being granted under and subject to the terms and
conditions of the Ashworth, Inc. Amended and Restated Incentive Stock Option Plan, dated November 1,
1996, ("Amended Plan") and all Shares issued upon the exercise of any Option shall be registered
under the Securities Act of 1933, as amended.

EXCLUSIVITY

During the Term, neither Nantz Communications nor Nantz shall enter into
<!-- page 4 -->
any activity, employment, independent contract, or other business arrangement which conflicts with
Nantz Communications' or Nantz's obligations under this Agreement or perform any service which
reasonably appears to be an endorsement of the sportswear apparel, hats and shoes of a third party
without the Company's prior written approval. Nantz Communications and Nantz expressly agree that
the Endorsement will not be granted to anyone other than the Company for use during the Term in
connection with the advertisement and promotion of sportswear apparel, hats and shoes.
Notwithstanding the foregoing Nantz shall be permitted to wear a Lynx hat or clothing logo when
performing promotional services for Lynx and to use Lynx equipment when performing any promotional
services for the Company in which equipment will be used.

TERMINATION

This Agreement may be terminated by any party in the following circumstances:

18. Upon mutual consent of the Company, on the one hand, and Nantz Communications and Nantz, on the
other hand;

19. Nantz's Disability or death, in which event the Agreement shall terminate on the May 1 following
such Disability or death;

20. Repeated misconduct of Nantz which subjects Nantz to continued public ridicule causing a
substantial loss of Nantz's positive public image;

21. Nantz's conviction or plea of guilty or no contest to a felony involving moral turpitude;

22. A finding of insolvency or bankruptcy against the other party (which, in the case of a desired
termination by the Company, shall mean Nantz Communications or Nantz); and

23. Failure to comply with the terms and conditions of this Agreement after being given notice
thereof and, where applicable, a reasonable opportunity to cure the failure (which shall be 10 days
in the event of a failure to timely make a payment pursuant hereto; 30 days otherwise). In order to
be a sufficient notice hereunder, any such written notice shall specify in detail each item of
default, and shall specify in detail the action the defaulting party is required to take in order to
cure each item.

Ashworth/Nantz Promotion Agreement - -------------------

Notwithstanding the foregoing, upon the occurrence of repeated intentional failures to comply with
the terms and conditions of this Agreement, which have been noticed in accordance with the terms
hereof (regardless of whether such failures have been cured), the non-defaulting party may
immediately terminate this Agreement upon written notice to the defaulting party without affording a
further opportunity to cure.

Should Nantz Communications or Nantz disagree with the Company as to the existence of a condition
affording the Company the right to so terminate this Agreement, Nantz Communications or Nantz shall,
within thirty (30) days following the receipt of any such notice of termination, submit the matter
to arbitration pursuant to the provisions of this Agreement.

The termination rights set forth in this section shall not constitute the exclusive remedy of the
non-defaulting party hereunder, however, and if a default is made by either party hereunder, the
other may resort to such other remedies as said party would have been entitled to if this section
had been omitted from this Agreement. Termination under the provisions of this section shall be
without prejudice to any rights or claims which the terminating party may otherwise have against the
defaulting party.

From and after the termination of the Term all of the rights of the Company to the use of the
Endorsement shall cease absolutely and the Company shall not thereafter use or refer to the
Endorsement in advertising or promotion in any manner whatsoever. The Company shall not advertise,
promote, distribute or sell any item whatsoever in connection with the use of any name, figure,
design, logo, trademark or trade name confusingly similar to or suggestive of the Endorsement
following the termination of the Term.

ASSIGNMENT This Agreement shall bind and inure to the benefit of the parties hereto and their
respective successors and permitted assigns. Nantz Communications and Nantz acknowledge that the
Services to be rendered by Nantz Communications and Nantz are unique and personal. Accordingly,
except as otherwise expressly provided below, neither Nantz Communications nor Nantz shall assign
any of their respective rights or delegate any of their respective duties or obligations under this
Agreement without the written consent of the Company. Nothing herein shall prevent Nantz
Communications from assigning the monetary benefits of this Agreement as it may so desire. Further,
inasmuch as it is recognized that Nantz Communications is the representative of Nantz, Nantz
Communications may at any time assign this Agreement to Nantz and, in such event, Nantz
Communications shall have no further obligation or liability in connection herewith and Nantz
Communications' position vis-a'-vis the Company in connection herewith shall be in all respects the
same as if Nantz Communications had signed this Agreement as agent rather than as a principal from
the beginning. The rights granted the Company hereunder shall be used only by it and shall not,
without the prior written consent of Nantz Communications or Nantz, be transferred or assigned to
<!-- page 5 -->
any other. In the event of the merger or consolidation of the Company with any other entity, Nantz
Communications shall have the right to terminate the Agreement by so notifying the Company in
writing on or before sixty (60) days

Ashworth/Nantz Promotion Agreement - -------------------

after Nantz Communications has received notice of such merger or consolidation if and only if, by
virtue of such merger or consolidation Nantz Communications or Nantz would be in default under or
violating any provisions of any agreement to which he or it is subject entered into prior to June 1,
1994.

ARBITRATION Unless otherwise mutually agreed to in writing by the Company, Nantz Communications and
Nantz, any controversy or claim arising out of or related to this Agreement, or the breach thereof,
shall be settled by arbitration in accordance with the Rules of the American Arbitration Association
or any successor. Each of the Company, on the one hand, and Nantz Communications and Nantz, on the
other hand, shall select one arbitrator and the two so selected shall select a third. Failing the
selection of an arbitrator by either party or by the two so selected, the claim or controversy shall
be settled by the American Arbitration Association upon the application of either party. Judgment
upon any award of a majority of the arbitrators filed in a court of competent jurisdiction shall be
binding.

MISCELLANEOUS 24. NOTICES. Any and all notices required pursuant to this Agreement shall be deemed
given if in writing and delivered in person, sent by certified or registered mail, return receipt
requested, or set by telefax at or to the addresses and telefax numbers set forth below or such
other addresses and telefax numbers as the parties may direct by notice given as herein provided:

Ashworth, Inc.

Attention: President and Chief Executive Officer 2791 Loker Avenue West Carlsbad, California 92008
Telephone: (619) 438-6610 Telefax: (619) 438-9107 James W. Nantz III Nantz Communications, Inc. c/o
International Merchandising Corporation 22 East 71st Street New York, New York 10021 Attention:
Barry Frank Telephone: (212) 774-8900 Telefax: (212) 772-2617

Ashworth/Nantz Promotion Agreement - -------------------

25. GOVERNING LAW. This Agreement and its formation, operation and performance shall be governed,
construed, performed, and enforced in accordance with the laws of the State of California.

26. JURISDICTION AND VENUE. For the purposes of any dispute arising hereunder, jurisdiction and
venue shall lie in the appropriate court in California.

27. ATTORNEY FEES AND EXPENSES. In any legal action or alternative dispute resolution instituted to
interpret or enforce the terms and/or conditions of this Agreement, the prevailing party shall be
entitled to recover reasonable attorney fees and expenses.

28. WAIVER. A waiver by either party of any provision of this Agreement shall not be deemed a waiver
of any other portion of this Agreement. Failure to require performance of any provision of this
Agreement shall not be deemed a continuing waiver of that provision or any other provision of this
Agreement.

29. SEVERABILITY. In the event that any provision or any portion of any provision of this Agreement
shall be held invalid, illegal or unenforceable, the remainder of this Agreement shall remain valid,
enforceable, the remainder of this Agreement shall remain valid, enforceable, and in effect.

30. CAPTION REFERENCES. All items headings and captions are for reference purposes only and do not
in any way modify or limit the provisions set forth thereunder.

31. ENTIRE AGREEMENT. This Agreement contains the entire understandings and agreement of the parties
and supersedes any prior understandings and/or agreement of the parties. This Agreement may not be
modified or amended without the written consent of all parties hereto.
<!-- page 6 -->
[REMAINDER OF PAGE INTENTIONALLY LEFT BLANK]

Ashworth/Nantz Promotion Agreement - -------------------

IN WITNESS WHEREOF, the parties hereto have executed this Agreement on the date indicated below,
effective the date first above mentioned.

THE COMPANY:

ASHWORTH, INC. a Delaware corporation

Date: December 16, 1998 By: /s/ RANDALL L. HERRAL, SR. ------------------------------ Randall L.
Herrel, Sr. President & Chief Executive Officer

NANTZ COMMUNICATIONS, INC.

Date: December 16, 1998 By: /s/ JAMES W. NANTZ III -------------------------- James W. Nantz III
President

Date: December 16, 1998 /s/ JAMES W. NANTZ III -------------------------- James W. Nantz III
