<!-- page 1 -->
# CONTENT LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2008-09-17 |
| Parties | World Book, Inc. ("World Book"); HSW International, Inc. ("HSWI") |
| Source | CUAD v1 / RemarkHoldingsInc_20081114_10-Q_EX-10.24_2895649_EX-10.24_Content License Agreement |

Exhibit 10.24 *Portions of this exhibit marked [*] are requested to be treated confidentially.
CONTENT LICENSE AGREEMENT This CONTENT LICENSE AGREEMENT (the "Agreement") is entered into and
effective September 17, 2008 (the "Effective Date"), by and between World Book, Inc. ("World Book"),
a Delaware corporation with offices at 233 North Michigan Avenue, Suite 2000, Chicago, IL 60601, and
HSW International, Inc. ("HSWI"), a Delaware corporation with offices at One Capital City Plaza,
3350 Peachtree Road, Suite 1600, Atlanta, Georgia 30326. WHEREAS, World Book owns or licenses
certain articles and other materials including, without limitation, the Reference Content and Images
content. WHEREAS, HSWI desires to Display certain Content on the HSWI Websites and World Book
desires to license the Content for this use in accordance with the terms and conditions set forth
herein. NOW, THEREFORE, in consideration of the mutual promises and covenants set forth below, the
parties hereto agree as follows: 1. DEFINITIONS. Capitalized terms not otherwise defined herein
shall have the meanings specified below. 1.1 "Acquisition" is defined in Section 11.8 hereof. 1.2
"Payments/Advances" is defined in Section 4.1(ii) hereof. 1.3 "Affiliate" means any distributor or
franchisee of HSWI or any company or other entity worldwide, including without limitation
corporations, partnerships, joint ventures, and limited liability companies in which HSWI directly
or indirectly holds at least a 19% ownership, equity, control or financial interest and which HSWI
intends to enjoy any of HSWI's rights hereunder. A list of Affiliates as of the Effective Date is
attached hereto as Attachment A. Attachment A may be modified from time to time upon notice by HSWI
to reflect a revised list of Affiliates and each modified Attachment A shall be deemed incorporated
herein by reference. 1.4 "Affinity" means the arrangement of Reference Content and Images into
articles about a variety of subjects as agreed by HSWI and World Book in accordance with this
Agreement and identified in detail in Schedule A. 1.5 "Article" is defined in Section 2.2(i) hereof.
1.6 "Buy-Out Fee" is defined in Section 4.2 hereof. 1.7 "Competitors" is defined in Section 11.8
hereof. 1.8 "Competitors II" is defined in Section 2.1(ii) hereof.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 2 -->
1.9 "Confidential Information" means any and all trade secrets, proprietary or confidential
information of either party and includes, without limitation: (a) any information, software,
material, data or business, financial, operational, customer, vendor, and other information
disclosed by one party to the other, (b) the terms of this Agreement, and/or (c) the fact of the
existence of this Agreement except as specifically permitted in Section 7. Confidential Information
will not include information that the receiving party can prove: (w) was already in such party's
possession prior to receipt; (x) was independently developed by such party; (y) was obtained from a
third party who had the right to disclose such information to such party, and/or (z) was or became
generally available to the public other than as a result of disclosure by such party. 1.10 "Content"
means, collectively: (a) the Reference Content; (b) Translated Content; (c) any updates to any of
the foregoing provided by World Book; and (d) World Book Derivatives. The term "Content" shall not
include any HSWI Modifications. 1.11 "Delivery Period" means the following: (i) July 1, 2008 -
December 30th, 2009 1.12 "Display" means to use, publicly display, publicly perform, provide a link
to, provide the ability to download and/or print and otherwise make available on or through web
sites. 1.13 "Effective Date" is defined in the preamble of this Agreement. 1.14 "Encyclopedia" means
a tab or section of a website: (a) branded with the word "encyclopedia"; or (b) that consists solely
of multiple unrelated Affinities as provided by World Book hereunder. 1.15 "Excess Royalties" is
defined in Section 4.1(iii) hereof. 1.16 "Exclusive" shall mean World Book shall have no further
right to grant to third parties the same or any other licenses to the Content in the Open Free Web
and itself retains no such rights or other licenses. 1.17 "Force Majeure Event" is defined in
Section 11.1 hereof. 1.18 "HSWI Modifications" means modifications to the Content made by or on
behalf of HSWI or its Affiliates in accordance with this Agreement, except to the extent the HSWI
Modifications are World Book Derivatives. 1.19 "HSWI Websites" means, collectively, the Chinese
language website found at bowenwang.com.cn, and all other websites (be they Chinese language or
non-Chinese language) owned or controlled by HSWI or its Affiliates whether presently existing or
later developed, and all successor websites to any of the foregoing websites

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 3 -->
1.20 "Images" means illustrative materials, including but not limited to charts, graphs,
photographs, tables and renderings wholly owned by World Book and licensed to HSWI. 1.21
"Intellectual Property Rights" means any and all rights, titles and interests, whether foreign or
domestic, in and to any and all trade secrets, patents, copyrights, service marks, trademarks,
know-how, or similar intellectual property rights, as well as any and all moral rights, rights of
droit moral, rights of privacy, publicity and similar rights of any type under the laws or
regulations of any governmental, regulatory, or judicial authority, foreign or domestic. 1.22 "Net
Revenue" means gross revenue less costs not to exceed [*] percent ([*]%) of such gross revenue,
including reasonable third-party agency/ third-party advertising sales commissions and rebates and
serving, bad debts and applicable taxes. 1.23 "Open Free Web" means all websites (i) through which
content can be indexed by Google and/or other consumer search engines; (ii) through which content is
openly accessible by the public free of charge, and/or (iii) that do not charge a subscription fee
or other fee for access to the content of the website. 1.24 "Reference Content" means content
created from various World Book digital databases, print products, outside reference sources or
materials acquired by World Book and which shall be provided in simplified Chinese characters and
shall consist of sixteen million (16,000,000) to [*] ([*]) Chinese characters. 1.25 "Royalties"
means fees payable by HSWI to World Book and calculated on the basis set forth in Section 4.1
hereof. 1.26 "Significant Breach" means an uncured breach (pursuant to the cure provisions of
Section 6.2(i)) by HSWI of one or more of the following: (i) HSWI brands the Affinities with the
word "Encyclopedia" and/or Displays the Affinities or the underlying Reference Content and/or Images
as an Encyclopedia in breach of Section 2.2(iii); (ii) HSWI uses or Displays the World Book Brand to
promote the Content in violation of Section 7.4; (iii) HSWI assigns this Agreement to a Competitor
(as defined in Section 11.8) of World Book in violation of Section 11.8; and/or (iv) HSWI fails to
make payments as required by Section 4. 1.27 "Translated Content" means non-Chinese versions of the
Affinities and/or the Reference Content, created pursuant to Section 2.3. [*] Confidential treatment
requested; certain information omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 4 -->
1.28 "Updating Services" means that upon World Book's update to or maintenance of the World Book
Online Reference Center or the Reference Content, World Book will provide notice, a reference to the
affected Articles, and the actual content of the update to HSWI so that HSWI can update and maintain
the factual data in the Affinities. Such services shall be of the scope and nature with which World
Book updates and maintains its content in the normal course of its own updating and maintenance
process. 1.29 "World Book Brand" is defined in Section 7.4 hereof. 1.30 "World Book Derivatives"
means any modifications, updates or other derivative works to the Content based on other Content
provided by World Book regardless of who performs such modifications, updates or other derivative
works. 1.31 "World Book Online Reference Center" means World Book's online product found at
www.worldbookonline.com or any successor URL thereto. 2. LICENSE GRANT. 2.1 License Grant and
Restrictions. (i) License Grant. Subject to the terms and conditions set forth herein, World Book
hereby grants to HSWI, a perpetual, irrevocable limited license to use, copy, store, archive,
distribute, transmit, modify (subject to Section 2.1(iv)), and Display the Content, Images and
Affinities in whole or in part, only on the HSWI Websites or in promotions in any media for the HSWI
Websites. The license to each component of the Content, Images and Affinities shall be subject to
the term and exclusivity provisions set forth in this Section 2. The license to each component of
the Content, Images and Affinities shall be supplemented by any additional license rights in this
Section 2, and in the event of any conflict with this Section 2.1 such other additional license
rights in this Section 2 shall prevail. (ii) Right to Sublicense. World Book further grants HSWI the
right to sub-license the Content, Images and Affinities to users of the HSWI Websites to view, to
store, and to make reasonable copies of the Content, Images and Affinities to use such Content,
Images and Affinities for non-commercial, private purposes, provided that HSWI sets forth the
limited terms of such sublicense in writing in the HSWI Websites' terms and conditions. In addition,
World Book grants HSWI the right to sub-license the Content for business development purposes, with
no more than [*] ([*]%) of the Content being licensed to any single third party, and in limited,
non-material usage in other mediums for promotional or public relations purposes. HSWI may not
sublicense the Content, Images or Affinities to any paid-subscription website which is an aggregator
of third-party content (for the avoidance of doubt, such shall not include the [*] Confidential
treatment requested; certain information omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 5 -->
HSWI Websites). Notwithstanding anything to the contrary herein, attached as Attachment B is a list
of companies (the "Competitors II") which are competitors with World Book and to whom sublicense may
be made only with prior written consent of World Book, which World Book may withhold at its sole
discretion. The Competitors II may be modified from time to time by notice to and approval of the
other party, not to be unreasonably withheld. HSWI shall provide World Book on or before June 30th
and December 31st of each year with a list of third parties to whom sublicense hereunder has been
made during such semiannum. (iii) No Other Rights. Except as set forth herein, HSWI has no other
right to sublicense the Content except with the advance written consent of World Book. World Book
retains all rights not specifically granted herein. (iv) Restrictions. The Content and Images shall
be available to Display on the HSWI Websites as one or more individual articles, via commercially
available browsers using personal computers, mobile devices, kiosks, or other equipment. HSWI may
modify the Content, including using excerpts, for purposes of exercising its rights under this
Agreement, including without limitation, to fit the format and the look-and-feel of the HSWI
Websites, for promotion of the Content or HSWI Websites, for allowing third parties to sponsor
certain Content, and to include links in the Content to HSWI Websites or third party websites;
provided, however, HSWI may not edit, modify, or create derivative works from the Content for
purposes of changing the substantive information contained in the Content, except (i) as otherwise
approved by World Book in writing; or (ii) as otherwise expressly provided in this Agreement. HSWI
may not Display the Content or Images on any website which is pornographic. HSWI may not translate
the Content provided by World Book hereunder except as set forth in Section 2.3 or for purposes of
performing updates. (v) Third Party Service Provider Rights. HSWI may permit third party suppliers
of services and facilities (including, without limitation, agents, consultants, host providers, data
centers, outsource service providers, disaster backup and recovery service providers) to use the
Content, Images and Affinities under the terms of this Agreement in support of HSWI exercising its
rights under this Agreement. HSWI also may designate one or more third party suppliers of services
as HSWI's agent for the administration of this Agreement and the receipt of services under this
Agreement from World Book. (vi) Affiliate Rights. All rights granted to HSWI under this Agreement
may be exercised by or through HSWI and/or its Affiliates.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 6 -->
2.2 Affinities. (i) Creation. World Book shall create and deliver the Affinities in the Delivery
Period. The Affinities will be organized into stand-alone articles around specific topics (each, an
"Article") according to the taxonomy set forth in Schedule A. Any given Affinity will consist of
multiple Articles in the same subject area (i.e., history or life sciences). There shall be at least
one Article for each of those topics identified in Schedule B. World Book shall create the
Affinities based on Reference Content and other content owned or licensed by World Book, including
without limitation, various World Book digital databases, print products, outside reference sources
or materials acquired by World Book. World Book will make reasonable efforts to cross check the
Reference Content against other World Book products for factual accuracy. World Book will create the
Affinities according to the guidelines and instructions provided by HSWI from time to time, and
agreed to by World Book whose consent shall not be unreasonably withheld, and according to the high
quality standards for commercially published works, but in no event less than the standards of World
Book for its own published works. If an Affinity does not meet the requirements set forth herein,
World Book will promptly revise the Affinity to meet such. The total amount of material World Book
makes available for all Affinities shall be no less than sixteen million (16,000,000) Chinese
characters. Additionally, the Affinities shall collectively contain at least sixteen thousand
(16,000) Articles written in simplified Chinese characters, with an average and median number of
words per Article of no less than one thousand (1,000) simplified Chinese characters. (ii) Delivery.
World Book will deliver at least [*] percent ([*]%) of the Articles in the Affinities on or before
[*], and at least [*] percent ([*]%) on or before the [*]. World Book will deliver the Affinities
according to the following schedule. Date for Delivery Affinities for Delivery a) [*] Prior to [*]
b) [*] c) [*] a) [*] b) [*] Prior to [*] c) [*] d) [*] e) [*] f) [*] [*] Confidential treatment
requested; certain information omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 7 -->
The format and media for the delivery of the Affinities, such as FTP or other mutually-agreeable
method, and the XML schema and applicable metadata requirements are set forth in Schedule C. (iii)
Scope of License for Affinity & Content Included in Affinity. Subject to the terms and conditions of
this Agreement, World Book grants HSWI the right to use, copy, store, archive, distribute, transmit,
modify, translate (subject to Section 2.3), and Display the Content that comprises the Affinities as
part of the Affinities, and the Affinities themselves, in any manner and in any digital media (and
to sublicense such rights to third parties), provided that HSWI does not resell all or license
substantially all of the Content for a fee to other content publishers. The term of the license for
the Content delivered to HSWI as part of the Affinities, and the Affinities themselves, shall be
perpetual, Exclusive, and irrevocable. World Book shall have no right to allow any party other than
HSWI, including World Book, to publish, distribute, duplicate, or otherwise use the Reference
Content that comprises the Affinities on the Open Free Web for purposes of creating any materials
that are the same or similar to the Affinities and published online or in any other free digital
media. World Book shall have no right to use the Reference Content that comprises the Affinities on
the Open Free Web except for purposes of performing its obligations to HSWI under this Agreement.
HSWI may not brand the Affinities with the word "Encyclopedia." Notwithstanding anything to the
contrary in this Agreement, the Affinities or the underlying Reference Content and/or Images may not
be Displayed as an Encyclopedia. World Book shall not license to any third parties or otherwise use
the Content as Affinities in any digital form during the term of the license. (iv) Scope of License
for Images Included in Affinity. World Book grants HSWI the right to use, copy, store, archive,
distribute, transmit, modify, translate (subject to Section 2.3), and Display the Images as part of
the Affinity. The term of the license for the Images delivered to HSWI as part of the Affinity,
shall be perpetual and irrevocable. [*] ([*]) of the Images shall be Exclusive for the Open Free
Web. [*] Confidential treatment requested; certain information omitted and filed separately with the
SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 8 -->
2.3 Translated Content. (i) Right to Create Translated Content. Where rights permit, HSWI shall have
the right to translate the Affinities for Display on the Open Free Web on HSWI Websites. HSWI shall,
promptly after creating such Translated Content, provide World Book with a copy of the Translated
Content in a format and manner acceptable to the parties. HSWI shall advise World Book that it
desires to translate the Affinities prior to commencing such translation and World Book shall notify
HSWI if World Book does not hold the rights necessary to allow HSWI to translate any Articles or
portions thereof. HSWI may not Display the Translated Content as an Encyclopedia, and may not
translate any Affinity for which a same subject-matter Affinity has not been previously licensed by
HowStuffWorks, Inc. Additionally, if HSWI translates any of the Affinities into English, HSWI's sole
rights to publish such English Translated Content shall be as a translation on those foreign
language HSWI Websites which are not intended for English-language audiences. Notwithstanding the
foregoing, HSWI may not translate any Affinity into English for which a same subject Affinity has
not been previously licensed by World Book to HowStuffWorks, Inc. (ii) Scope of License. The term of
the license for Translated Content shall be for a term of [*] ([*]) years from the time such
Translated Content is first Displayed on an HSWI Website. In addition, such license for Translated
Content shall be Exclusive for Display on the Open Free Web. At the end of such [*] ([*]) year
period, HSWI shall have the right to renew the Agreement under materially the same terms or shall
have an option to purchase the Translated Content outright to the extent rights permit and to the
extent the parties mutually agree to terms for such sale. 2.4 Non-Display. HSWI may, in its sole
discretion, decide not to Display Content obtained from World Book. If HSWI elects in a written
notice to World Book that HSWI will not Display any such Content, notwithstanding anything to the
contrary herein, the license to such Content shall be non-Exclusive. 2.5 Exclusivity. Commencing on
the Effective Date and continuing for eighteen (18) months, World Book shall work exclusively with
HSWI to publish Chinese language Content for the Open Free Web and shall not itself, directly or
indirectly, publish Chinese language Content for the Open Free Web. For purposes of clarity, and
except as otherwise set forth herein, World Book maintains the right to continue to publish Content
and Images for its paid-subscription websites and other existing or new partner paid-subscription
websites, provided that such are not within the definition of the Open Free Web. Additionally
commencing on the Effective Date and continuing for eighteen (18) months, World Book shall offer
HSWI a right of first refusal to create any paid-subscription Chinese language websites, which do
not exist as of the date hereof, using the Content on equal or better terms as agreed to between
World Book and a third party. [*] Confidential treatment requested; certain information omitted and
filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 9 -->
2.6 Updating Services. World Book shall provide Updating Services to HSWI until the later of: (a)
such time as World Book's cessation of providing Updating Services to HowStuffWorks, Inc. or its
successor, but such Updating Services shall be only for the same Content under this Agreement for
which World Book is obligated to provide Updating Services to HowStuffWorks, Inc. or its successor;
(b) such time as the Royalties paid in a given year are less than $[*]; or (c) [*] years from the
Effective Date. World Book shall provide the updates in the manner and form as set forth in Schedule
D. HSWI acknowledges that the Updating Services will not be automated and may require review and
editing by HSWI. Notwithstanding anything to the contrary, HSWI shall have the right to update the
Content, Affinity and Images to correct errors or alleged errors (including, without limitation,
errors of omission) in such or in response to third party claims related to the Content, Images or
Affinity, and may use World Book content and data in connection with such updates. World Book shall
provide the Updating Services in English, and HSWI may translate any such updates into Chinese only.
Any authored content provided under the Updating Services, even when translated into Chinese by
HSWI, shall be subject to the license herein for that Content which is being updated, and for the
avoidance of doubt shall not be considered Translated Content. 3. INTELLECTUAL PROPERTY RIGHTS;
OWNERSHIP AND LICENSES. 3.1 World Book's Ownership Rights. World Book shall own all right, title and
interest, including all Intellectual Property Rights, in and to the Content and in all Intellectual
Property Rights in the Content, including, without limitation, World Book Brands (as defined in
Section 7.4) and any derivative works to any of the foregoing. HSWI shall have no proprietary
interest in the Content, other than the license rights set forth herein. 3.2 HSWI's Ownership
Rights. HSWI shall own all right, title and interest, including all Intellectual Property Rights, in
and to (i) the HSWI Websites, their look and feel and the software code or web site infrastructure
that it develops, licenses, or purchases to support Display of the Content; and (ii) the HSWI
Modifications. 3.3 Documents. Each party agrees (without further compensation) to execute any
applications, agreements and instruments and to do all other things reasonably requested by the
other party, at the requesting party's expense (both during and after the term of this Agreement) in
order to vest the rights provided in this Agreement. 4. PAYMENT. 4.1 Royalties. (i) Royalty Rates.
HSWI shall pay to World Book Royalties calculated as a defined percentage of the Net Revenue
received by HSWI from [*] Confidential treatment requested; certain information omitted and filed
separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 10 -->
advertising generated directly from Content by web pages containing Content or any portion of the
Content provided by World Book to HSWI hereunder. The Royalty rate shall be [*] percent ([*]%) on
the Affinities and Reference Content; and [*] percent ([*]%) on Translated Content. (ii)
Payments/Advances. During the applicable Contract Period, HSWI shall pay World Book non-refundable
advances towards the Royalties in the amounts set forth below ( "Payments/Advances"): Due Date
Amount [*] $[*] [*] [*] $[*] [*] $[*] [*] $[*] [*] $[*] [*] [*] $[*] [*] $[*] [*] $[*] TOTAL $[*]
World Book will submit invoices to HSWI for the Payments/Advances at least [*] ([*]) days prior to
the due date of such Payment/Advance, with the exception of the first payment which shall be due
[*]. No Royalty payments will be due until the amount of the Royalties exceed the amount of the
Payments/Advances described above for the development and delivery of the Affinities and Content
licensed hereunder, and then Royalties will only be owed for any Royalties in excess of the amount
of the Payments/Advances, as further detailed in the following Sub-Section. If, subsequent to the
Effective Date and prior to the end of 2009, HowStuffWorks, Inc. enters into one or more new
agreements or modifies an existing agreement with World Book to license content with guaranteed
payment obligations in such new agreement or in such modification totaling at least [*] dollars
($[*]) in additional fees, then each of HSWI's [*], and [*], [*] shall be reduced from $[*] to $[*].
Nothing paid in Contract Period 1 pursuant to the [*], as amended shall be used to calculate
guaranteed payment obligations hereunder. [*] Confidential treatment requested; certain information
omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 11 -->
(iii) Calculation and Payment of Excess Royalties. Royalties for Content will be calculated based on
the Royalty rates set forth in Subsection (i) and compared to the Payments/Advances paid by HSWI
during the term of this Agreement. If such calculated Royalties exceed all Payments/Advances paid
during the term of this Agreement ("Excess Royalties"), HSWI will pay such Excess Royalties within
[*] ([*]) days after the end of the calendar year in which such Excess Royalties were earned.
Additionally, within [*] ([*]) days after the end of each calendar year, HSWI will provide to World
Book a report of its Royalty calculations. If Excess Royalties are earned before all
Payments/Advances have been paid, the Excess Royalties will be deducted from future
Payments/Advances. In the event that Royalties are [*] than Payments/Advances, [*]. By way of
example, if the calculated Royalties for 2008 are $[*]. Royalty statements shall be final and
accepted by the parties unless World Book has, in good faith, notified HSWI of the amount and
specific reasons for the dispute within [*] ([*]) days from the date of the statement. 4.2 Buy-Out
Option. HSWI shall have the right at any time following [*] to pay World Book a single fee (the
"Buy-Out Fee"), the payment of which would eliminate HSWI's obligation to pay any further Excess
Royalties. The Buy-Out Fee shall be the [*] of: a) the amount [*], or b) an amount equal to [*]
times the calculated Royalties of the most recent calendar year. 4.3 Taxes. To the extent required,
HSWI shall pay all sales, use or similar state or local taxes in connection with this Agreement,
except for employment taxes or taxes related to World Book's income. 5. AUDIT. HSWI shall maintain
complete and accurate records to support and document the Royalties owed under this Agreement in
accordance with generally accepted accounting principles consistently applied and to document
compliance with the terms of this Agreement. HSWI shall also provide reasonable assistance to World
Book or its designated agent to conduct audits to confirm the payments hereunder. Any such audit
will be conducted upon [*] ([*]) days notice and during regular business hours, and shall be at [*]
expense, unless such audit reveals a discrepancy of more than [*] percent ([*]%) in the total
applicable amount reported by HSWI, in which case [*] shall pay for, or reimburse [*] the cost of,
such audit. Any such audit shall be conducted by an independent certified public accounting firm
which is not engaged in performing other work for World Book or its affiliates; which agrees to
enter into a confidentiality agreement with HSWI; and which is not compensated in any manner of
contingency arrangements on the basis of its findings. HSWI further agrees that until the expiration
of [*] ([*]) year after the termination of this Agreement, HSWI will make available upon written
request to World Book or any of its duly authorized representatives, this Agreement and books,
documents, and records of HSWI that are necessary to verify the nature and extent of the revenue
derived by HSWI from advertising related to the Content hereunder. No more than [*] audit may be
conducted in any [*] month period, unless the then-most-recent audit reveals a discrepancy of more
than [*] percent ([*]%) in the total applicable amount reported by HSWI. [*] Confidential treatment
requested; certain information omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 12 -->
6. TERM, EXTENSION, AND TERMINATION. 6.1 Term. (i) Term of Agreement. This Agreement shall commence
on the Effective Date and, except as set forth in Subsection (ii), continue in full force and effect
through the Delivery Period. (ii) Term of Licenses. Notwithstanding Subsection (i), certain license
grants for Content, Images and Affinities extend beyond the expiration or earlier termination of
this Agreement as set forth herein. With respect to such Content, Images and Affinities, the terms
and conditions of this Agreement shall continue to apply. 6.2 Termination for Cause or Bankruptcy.
This Agreement may be terminated by a party in the event of: (i) any material default in, or
material breach of, any of the material terms and conditions of this Agreement by the other party,
which default continues in effect after the defaulting party has been provided with written notice
of default and sixty (60) days to cure such default; (ii) the commencement of a voluntary case or
other voluntary proceeding seeking liquidation, reorganization or other relief with respect to the
other party of its debts under any bankruptcy, insolvency, or other similar law now or hereafter in
effect, that authorizes the reorganization or liquidation of such other party or its debt or the
appointment of a trustee, receiver, liquidator, custodian or other similar official of it or any
substantial part of its property; (iii) the other party's consent to any such relief or to the
appointment of or taking possession by any such official in an involuntary case or other proceeding
commenced against it; or (iv) the other party's making a general assignment for the benefit of
creditors; or the other party's being adjudicated insolvent; or the other party taking any corporate
action to authorize any of the foregoing. 6.3 Effect of Termination. Upon the expiration or
termination of this Agreement, HSWI shall pay World Book all amounts due and owing up to the date of
termination, within [*] ([*]) days after such expiration or termination. In addition, upon the
expiration or termination of the applicable license, HSWI shall cease to Display the applicable
Content that is not licensed under a perpetual license, return or destroy such Content within [*]
([*]) days after such expiration or termination at the direction of World Book, and, upon request by
World Book, certify completion of the return or destruction in writing. There shall be no effect
upon the applicable Content that is licensed under a perpetual license. [*] Confidential treatment
requested; certain information omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 13 -->
Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 14 -->
6.4 Remedies. The termination or expiration of this Agreement for any reason shall not affect either
party's rights or obligations arising prior to the effective date of such termination. For purposes
of clarification, upon a Significant Breach of this Agreement by HSWI which remains uncured, the
rights to publicly use the World Book Brand as set forth in Section 7.4 may be revoked by World
Book. Notwithstanding anything in this Agreement to the contrary, the rights and remedies of the
parties as set forth in this Agreement are not exclusive and are in addition to any other rights and
remedies available to it at law or in equity. 6.5 Equitable Relief. Each party acknowledges that its
breach of certain provisions of this Agreement would cause irreparable injury to the other party for
which monetary damages may not be an adequate remedy. Accordingly, each party will be entitled to
seek injunctions and other equitable remedies in the event of such a breach or threatened breach by
the other party, or to seek specific performance of any provision hereof. A party's right to seek
equitable relief shall not limit in any manner such party's respective rights to seek other and/or
additional remedies at law or in equity. 7. CONFIDENTIALITY. 7.1 Protection of Confidential
Information. Solely for the purposes of the use and disclosure of Confidential Information, each of
World Book and HSWI is defined to include such party's directors, officers, employees, legal
counsel, and consultants, with a need to know, and who are advised by such party of the confidential
nature of the information or who are required to execute a nondisclosure agreement with the
confidentiality terms at least as restrictive in all material respects as set forth in this
Agreement. Each party shall maintain all of the Confidential Information disclosed to it by the
other party in strict confidence and will protect such information with the same degree of care that
each party exercises with its own Confidential Information, but in no event less than a reasonable
degree of care. Each party may use the Confidential Information disclosed to it by the other party
only to perform its obligations under this Agreement. Except as provided in this Agreement, neither
party shall use or disclose any Confidential Information disclosed to it by the other party without
the express prior written consent of such disclosing party. Neither party shall decompile,
disassemble, or reverse engineer any Confidential Information disclosed to such party by the other
party, and any information derived in violation of such covenant shall automatically be deemed
Confidential Information. All of the Confidential Information, and all copies, extracts, summaries
and other reproductions thereof, shall be and remain the property of the respective disclosing
party. Upon written request or upon the expiration of this Agreement, all Confidential Information
(and all copies thereof) will be returned to the party disclosing such or destroyed, with written
certification thereof, except that one archival copy of written material to be kept confidential and
segregated from the parties' regular files may be retained by each party's legal counsel solely for
purposes of verifying compliance with this Agreement.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 15 -->
7.2 Disclosures Required by Law. If a party is required to disclose Confidential Information
received from the other party, by law or a governmental authority, including, without limitation,
pursuant to a subpoena, court order, interrogatories, civil investigation demand, or other process,
such Confidential Information may be disclosed, provided that the disclosing party, if permitted:
(a) promptly notifies the other party of the disclosure requirement; (b) cooperates with the other
party's efforts to resist or narrow the disclosure and to obtain an order or other reliable
assurance that confidential treatment will be accorded Confidential Information; and (c) furnishes
only Confidential Information that is legally compelled to be disclosed according to advice of its
legal counsel. 7.3 Disclosures to Investors. HSWI may disclose the contents of this Agreement to
promote investment to potential financial investors or institutions, provided that such parties are
subject to a confidentiality agreement at least as restrictive in all material respects as the
confidentiality terms in this Agreement. 7.4 Use of World Book Brand. Except as set forth herein,
neither party shall issue any press releases or public statements concerning this Agreement or the
subject matter herein without the other party's prior written agreement, except as required by law.
World Book grants no right to HSWI for the use or Display of World Book's brands, logos, service
marks, or other trade names or trademarks of World Book ("World Book Brand") in any manner, except
as permitted in this Section. HSWI may not use the World Book Brand to promote the Content on any of
the HSWI Websites to existing or potential users. HSWI may use World Book's name solely to promote
advertising or investment to potential advertising clients or financial investors or institutions.
Notwithstanding the foregoing, and subject to the terms and conditions of this Agreement, HSWI may
identify the Content on the HSWI Websites and elsewhere as "From the editors of World Book, Inc.,"
in simplified Chinese language as set forth in Schedule E or such other credit or credits as the
parties hereto may mutually agree in writing, except for any of that Content which has been modified
without the approval of World Book. Additionally, World Book agrees to cooperate with HSWI's issuing
a press release within one month of entering into this Agreement which identifies HSWI as receiving
exclusive content created by World Book and includes relevant quotes from World Book executives. Any
press releases issued by HSWI including the World Book Brand shall be previously approved in writing
by World Book, which consent shall not be unreasonably withheld. 7.5 Required Disclosures.
Notwithstanding the foregoing, World Book acknowledges that HSWI is a publicly listed company
subject to various disclosure regulations. In connection with such, World Book acknowledges that
HSWI may disclose in its regulatory filings, investor communications, and associated statements the
World Book Brand and those aspects of this Agreement that HSWI reasonably finds are required to be
disclosed by law or regulation. HSWI will use its commercially reasonable efforts to consult with
World Book on any such legally required public disclosures of the World Book Brand and this
Agreement.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 16 -->
7.6 The restrictions on use and disclosure of Confidential Information under this Section 7 shall
remain in effect [*] ([*]) years following disclosure of the Confidential Information; provided,
however, for trade secrets such restrictions shall continue for so long as such information is
deemed a trade secret under applicable law. 8. REPRESENTATIONS AND WARRANTIES. 8.1 Mutual
Representations. Each party represents and warrants to the other party that: (i) It is duly
organized and validly existing under the laws of the jurisdiction of its organization or
incorporation and, if relevant under such laws, in good standing; (ii) It has the corporate and/or
other legal capacity, authority and power to execute, deliver, and perform its obligations under
this Agreement and any other document relating hereto to which it is a party, and has taken all
necessary action to authorize such execution, delivery and performance; (iii) Such execution,
delivery and performance do not violate or conflict with any law applicable to it, any provision of
its constitutional documents, any order or judgment of any court or other agency of government
applicable to it or any of its assets or any contractual restriction binding on or affecting it or
any of its assets; (iv) All governmental and other authorizations, approvals, consents, notices and
filings that are required to have been obtained or submitted by it with respect to this Agreement
and any other document relating hereto to which it is a party have been obtained or submitted and
are in full force and effect and all conditions of any such authorizations, approvals, consents,
notices and filings have been complied with; (v) Its obligations under this Agreement and any other
document relating hereto or thereto to which it is a party constitute its legal, valid and binding
obligations, enforceable in accordance with their respective terms; (vi) There is not pending or, to
its knowledge, threatened against it any action, suit or proceeding at law or in equity or before
any court, tribunal, governmental body, agency or official or any arbitrator that is likely to
affect the legality, validity or enforceability against it of this Agreement or any other document
relating hereto to which it is a party or its ability to perform its obligations under the same; [*]
Confidential treatment requested; certain information omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 17 -->
(vii) There is not pending or, to its knowledge, threatened against it any action, suit or
proceeding at law or in equity or before any court, tribunal, governmental body, agency or official
or any arbitrator related to the violation of the Intellectual Property Rights of a third party
related to the subject matter of this Agreement; and (viii) It is not relying upon any
representations of the other party other than those expressly set forth in this Agreement or any
other document relating hereto. 8.2 HSWI's Representations and Warranties. HSWI hereby represents
and warrants that it has all applicable rights in and to the HSWI Websites and the HSWI Websites do
not and will not infringe or misappropriate the Intellectual Property Rights of any third persons.
8.3 World Book's Representations and Warranties. World Book hereby represents and warrants that: (i)
it has all applicable rights in and to the Content and the Content does not and will not infringe or
misappropriate any Intellectual Property Rights of any third persons; (ii) it will perform all
services in a professional, diligent, and workmanlike manner; (iii) the Content will be free from
material errors or inaccuracies; (iv) the Content will comply with all laws and regulations of the
People's Republic of China, including without limitation for distribution, publication and
educational use as contemplated herein; and, (v) the Content as delivered by World Book is expressly
approved by or within the applicable guidelines of the national government, any ministries, and
provincial governments, as applicable, of the People's Republic of China for distribution,
publication and education use as contemplated herein. In the event of a breach of the foregoing
warranties, and without limitation to any other remedies of HSWI, World Book shall promptly remedy
the breach at no additional cost or expense to HSWI. 8.4 Disclaimer. EXCEPT AS SET FORTH IN THIS
AGREEMENT, NEITHER PARTY MAKES ANY OTHER REPRESENTATIONS OR WARRANTIES, INCLUDING, WITHOUT
LIMITATION, AS TO THE ACCURACY OR COMPLETENESS OF THE CONTENT. TO THE FULL EXTENT ALLOWED BY
APPLICABLE LAW, EACH PARTY DISCLAIMS ALL OTHER WARRANTIES, WHETHER EXPRESS, IMPLIED, STATUTORY, OR
OTHERWISE INCLUDING, WITHOUT LIMITATION, ANY IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR USE OR PURPOSE.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 18 -->
9. INDEMNIFICATION. 9.1 HSWI HSWI hereby agrees to defend, indemnify and hold harmless World Book
and its officers, directors, agents, and employees from all costs, damages, liabilities and expenses
(including reasonable attorneys fees) arising out of: (a) any third party claim or action alleging
that any of the following infringe or misappropriate the Intellectual Property Rights of a third
party: (i) the HSWI Websites or the HSWI trade dress utilized in the Display of the Content on the
HSWI Websites; (ii) any Translated Content; or (iii) any HSWI Modifications and any World Book
Derivatives independently created by or on behalf of HSWI; and/or (b) any third party claim or
action arising out of HSWI's material breach of this Agreement; provided that (i) World Book
notifies HSWI promptly in writing of any such threat, claim, and/or proceedings related thereto;
(ii) HSWI is given the opportunity to assume sole control over the defense and all related
settlement negotiations, except that World Book shall have sole authority over approval of any
settlement that admits fault or liability on the part of World Book; and, (iii) World Book provides
HSWI with all reasonably necessary assistance, information and authority to perform the foregoing at
HSW's expense. Notwithstanding anything to the contrary, the indemnity under this Section shall not
apply to the extent the Content provided by World Book, or any accurate translation, contributes or
results in an infringement or misappropriation of the Intellectual Property Rights of a third party.
9.2 World Book. World Book hereby agrees to defend, indemnify and hold harmless HSWI, its
Affiliates, and their officers, directors, agents, employees, advertisers, service providers, end
users and related entities from all costs, damages, liabilities and expenses (including reasonable
attorneys fees) arising out of: (a) any third party claim or action alleging that the Content,
Affinities and Images (excluding any World Book Derivatives independently created by or on behalf of
HSWI) in the manner delivered by World Book or as contemplated for HSWI's use hereunder infringes or
misappropriates any Intellectual Property Rights of any third party; and/or (b) any third party
claim or action arising out of World Book's material breach of this Agreement; provided that: (i)
HSWI notifies World Book promptly in writing of any such threat, claim, and/or proceedings related
thereto; (ii) World Book is given the opportunity to assume sole control over the defense and all
related settlement negotiations, except that HSWI shall have sole authority over approval of any
settlement that admits fault or liability on the part of HSWI; and, (iii) HSWI provides World Book
with all reasonably necessary assistance, information and authority to perform the foregoing at
World Book's expense.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 19 -->
10. LIMITATIONS OF LIABILITY. 10.1 EXCEPT FOR EITHER PARTY'S VIOLATION OF THE CONFIDENTIALITY
OBLIGATIONS AND FOR EITHER PARTY'S INDEMNIFICATION OBLIGATIONS, NEITHER PARTY SHALL BE LIABLE UNDER
ANY CONTRACT, NEGLIGENCE, STRICT LIABILITY, OR OTHER LEGAL OR EQUITABLE THEORY FOR ANY AMOUNTS IN
EXCESS IN THE AGGREGATE OF THE AMOUNT OF THE FEES PAID OR PAYABLE UNDER THIS AGREEMENT. 10.2 EXCEPT
FOR EITHER PARTY'S VIOLATION OF THE CONFIDENTIALITY OBLIGATIONS AND FOR EITHER PARTY'S
INDEMNIFICATION OBLIGATIONS, IN NO EVENT WILL EITHER PARTY BE LIABLE FOR SPECIAL, INCIDENTAL,
CONSEQUENTIAL, INDIRECT OR PUNITIVE DAMAGES, OR LOST PROFITS, REGARDLESS OF WHETHER SUCH LIABILITY
IS BASED ON BREACH OF CONTRACT, TORT, STRICT LIABILITY, BREACH OF WARRANTIES, FAILURE OF ESSENTIAL
PURPOSE OR OTHERWISE AND EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 11. MISCELLANEOUS
PROVISIONS. 11.1 Force Majeure. In the event that either party is unable to perform any of its
obligations under this Agreement or to enjoy any of its benefits because of any event beyond the
control of the affected party including, but not limited to, natural disaster, acts of God, actions
or decrees of governmental bodies or failure of communication lines (a "Force Majeure Event"), the
party who has been so affected shall promptly give written notice to the other party and shall use
commercially reasonable efforts to resume performance. Upon receipt of such notice, all obligations
under this Agreement shall be immediately suspended for the duration of such Force Majeure Event.
11.2 Notice. All notices, demands, requests or other communications required or permitted under this
Agreement will be deemed given when (i) personally delivered; (ii) upon receipt after being sent by
registered U.S. mail, return receipt requested; or (iii) upon receipt after being sent by commercial
overnight carrier service with tracking capabilities to the address of the party set forth below, or
such other address as such party last provided to the other party by written notice. World Book,
Inc. 233 North Michigan Avenue Suite 2000 Chicago, IL 60601 Attn: Chief Financial Officer

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 20 -->
HSW International, Inc. One Capital City Plaza 3350 Peachtree Road, Suite 1600 Atlanta, Georgia
30326 Attn: Chief Executive Officer with a copy to: HSW International, Inc. One Capital City Plaza
3350 Peachtree Road, Suite 1600 Atlanta, Georgia 30326 Attn: General Counsel 11.3 Waiver. Failure to
enforce any term of this Agreement at any time for any period shall not be construed as a waiver of
such rights. No waiver shall be valid against any party hereto unless made in writing and signed by
the party against whom enforcement of such waiver is sought and then only to the extent expressly
specified therein. 11.4 Amendments. No changes or modifications to any provision of this Agreement
shall be effective unless made in writing and signed by both parties. 11.5 Severability. In the
event any one or more of the provisions of this Agreement shall for any reason be held to be
invalid, illegal or unenforceable, the remaining provisions of this Agreement shall be unimpaired
and the parties will substitute a new enforceable provision of like economic intent and effect. 11.6
Governing Law. This Agreement, the rights and obligations of the parties hereto, and any claims or
disputes thereto, shall be governed by and construed in accordance with the laws of the State of New
York without reference to conflict of law principles. Venue for any proceedings not subject to
arbitration under this Agreement shall be in the state and federal courts located in New York, New
York. 11.7 Arbitration. If any dispute arises under this Agreement that is not settled promptly in
the ordinary course of business, the Parties shall seek to resolve any such dispute between them;
first, by negotiating promptly with each other in face-to-face negotiations. Any controversy or
claim arising out of or relating to the interpretation, enforcement or breach of this Agreement that
cannot be resolved within fifteen (15) business days (or such period as the Parties shall otherwise
agree) through face-to-face negotiations shall be resolved by binding arbitration in accordance with
the Commercial Arbitration Rules of the American Arbitration Association. Arbitration shall be by a
single arbitrator mutually acceptable to the parties and experienced in the matters at issue and
selected by the Parties in accordance with the Commercial Arbitration Rules of the American
Arbitration Association. If the parties are unable to agree upon a single arbitrator, each party
shall select an arbitrator and the two arbitrators shall select the third arbitrator. The
arbitration shall only be held in New York, New York. The decision of the arbitrator shall be final
and binding and may be enforced in any court having jurisdiction over the subject matter or either
of the Parties, except that each party reserves all rights of appeal. The arbitrator(s) shall
determine to what extent each of the Parties shall bear the costs and expenses incurred in
connection with any such arbitration proceeding (including reasonable attorneys' fees and expenses)
on the basis of the arbitrator's assessment of the relative merits of the Parties' positions.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 21 -->
11.8 Assignment. Except as set forth herein, the parties shall not have any right or ability to
assign, transfer, or sublicense any obligations or benefit under this Agreement without the prior
written consent of the other party, which shall not be unreasonably withheld, except that, upon
written notice to the other party, a party (i) may assign and transfer this Agreement and its rights
and obligations hereunder to any third party who succeeds to substantially all its business, stock,
or assets related to this Agreement, including, without limitation, to a Competitor (as defined
below) (an "Acquisition"); and (ii) may assign or transfer any rights to receive payments hereunder.
Notwithstanding the foregoing, attached as Attachment C is a list of companies (the "Competitors")
to whom assignment of this Agreement outside of an Acquisition may be made only with prior written
consent of the other party, which the other party may withhold at its sole discretion. Such list of
Competitors may be modified from time to time by notice to and approval of the other party, not to
be unreasonably withheld. In the event of an assignment of this Agreement in connection with an
Acquisition of HSWI by any party other than a Competitor, notwithstanding anything to the contrary
herein, such acquiring party's license to the Content shall be expanded, to the extent the licenses
are available, to include also such acquiring party's paid subscription site(s) (if any) so long as:
(i) such acquiring party's paid subscription site(s) are not primarily marketed to the school and/or
library market; and (ii) such Content is not provided to any Competitor or Competitor II; and (iii)
the Royalties shall also be calculated as the applicable defined percentage of the Net Revenues
received by HSWI from subscription fees generated on the paid-subscription websites where the
Content is Displayed. In addition, in the event of an Acquisition of HSWI by a Competitor of World
Book, in no event shall the Content be provided to such Competitor or to any Competitor II.
Notwithstanding the foregoing, nothing in this Agreement shall be deemed to prevent an Acquisition
of HSWI by any party, including without limitation a Competitor. 11.9 Additional Actions and
Documents. Each of the parties hereto hereby agrees to take or cause to be taken such further
actions, to execute, deliver and file or cause to be executed, delivered and filed such further
documents, and will obtain such consents, as may be necessary or as may be reasonably requested in
order to fully effectuate the purposes, terms and conditions of this Agreement. However, in no case
will World Book be required to execute any lien UCC documentation for public filing. 11.10 Headings.
Section headings contained in this Agreement are inserted for convenience or reference only, shall
not in no way affect the interpretation of any of the provisions herein. 11.11 Independent
Contractors. Notwithstanding any provision hereof, for purposes of this Agreement, each party shall
be and act as an independent contractor and not as a partner, a joint venturer, or an agent of the
other party, and shall not bind nor attempt to bind the other party in any way without prior written
consent. 11.12 Survival. Sections 1, 2, 3, 4, 6.1(ii), 6.3, 6.4, 6.5, 7, 8, 9, 10 and 11 shall
survive the expiration or termination of this Agreement for any reason. 11.13 Entire Agreement. This
Agreement, including all Attachments hereto, constitutes the entire agreement of the parties and
supersedes all proposals, oral or written, all negotiations, conversations, discussions, or
agreements between the parties relating to the subject matter of this Agreement and all past dealing
or industry custom. [Signatures Follow On Next Page]

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 22 -->
IN WITNESS WHEREOF, the parties hereto have executed this Agreement as of its Effective Date.
AGREED: HSW International, Inc. WORLD BOOK, INC. By: /s/ Bradley T. Zimmer By: /s/ Donald Keller
Name: Bradley T. Zimmer Name: Donald Keller Title: Executive Vice President & General Counsel Title:
VP & CFO

LIST OF ATTACHMENTS Attachment A List of HSWI Affiliates Attachment B List of Competitors II
Attachment C List of Competitors Schedule A Taxonomy Schedule Schedule B Article Schedule Schedule C
Format and Delivery Schedule Schedule D Updating Format Schedule E World Book Brand Translation

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 23 -->
Attachment A HSWI AFFILIATES 1.HSW (HK) Inc. Limited 2.HSWI (HK) Holdings, Ltd. 3.HSW Brasil -
Tecnologia e Informacao, Ltda. 4.Bowenwang Technology (Beijing) Limited Liability Company 5.HSW
(PRC) Co. 6.BoNet (Beijing) Technology Limited 7.Intac International, Inc. 8.[*] 9.[*] 10.[*] 11.[*]

[*] Confidential treatment requested; certain information omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 24 -->
Attachment B COMPETITORS II ·[*] ·[*] ·[*] ·[*] ·[*] ·[*] ·[*] ·[*] ·[*] ·[*] ·[*]

[*] Confidential treatment requested; certain information omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 25 -->
Attachment C COMPETITORS World Book Competitors ·[*] ·[*] ·[*] ·[*] ·[*] ·[*] ·[*] ·[*] ·[*]

[*] Confidential treatment requested; certain information omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 26 -->
Schedule A AFFINITIES TAXONOMY [*] [*] Confidential treatment requested; certain information omitted
and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 27 -->
Schedule B ARTICLES The topics for the Articles include the following, which may be expanded upon.
[*]

[*] Confidential treatment requested; certain information omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 28 -->
Schedule C FORMAT & DELIVERY To Be Determined

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 29 -->
Schedule D UPDATING FORMAT Updating Services shall be provided in the following or substantially
similar format, e-mailed by World Book to an address or addresses specified by HSWI. Data for such
will be provided, expressed as [*], in the form [*], or as World Book [*], in order by World Book
[*].

[*] [*]

[*]

[*] [*]

[*]

[*]

[*]

[*]

[*] Confidential treatment requested; certain information omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
<!-- page 30 -->
Schedule E WORLD BOOK BRAND TRANSLATION

[*]

[*] Confidential treatment requested; certain information omitted and filed separately with the SEC.

Source: REMARK HOLDINGS, INC., 10-Q, 11/14/2008
