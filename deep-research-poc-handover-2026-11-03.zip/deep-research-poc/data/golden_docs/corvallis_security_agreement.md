<!-- page 1 -->
# Security Agreement — Corvallis Foods Group
| Field | Value |
|---|---|
| Document Type | Security Agreement |
| Effective Date | 2025-04-01 |
| Parties | Corvallis Foods Group LLC; Corvallis Cold Storage LLC; Willamette Valley Produce, Inc.; Pacific Commerce Bank |
| Facility ID | FAC-2025-0108 |
| Version | Original (Execution Version) |

THIS SECURITY AGREEMENT (this "Security Agreement") is made as of 2025-04-01 among Corvallis Foods Group LLC (the "Borrower"), the other Grantors party hereto and Pacific Commerce Bank, as Administrative Agent (in such capacity, the "Secured Party"), to secure the Obligations under the Credit Agreement dated as of 2025-04-01 (facility FAC-2025-0108).
<!-- page 2 -->
## Section 1 — Grant of Security Interest
Each Grantor hereby grants to the Secured Party, for the benefit of the Secured Parties, a continuing security interest in all of its right, title and interest in the following (the "Collateral"): all Accounts, Chattel Paper, Deposit Accounts, Documents, Equipment, General Intangibles, Instruments, Inventory, Investment Property and all Proceeds of the foregoing.
Without limiting the foregoing, the Collateral includes all Inventory and Equipment located at the Grantors' principal facility in Albany, Oregon.
## Section 2 — Excluded Assets
The Collateral does not include any lease, license or contract to the extent the grant of a security interest therein is prohibited by its terms, or any Deposit Account used exclusively for payroll or trust purposes.
<!-- page 3 -->
## Section 3 — Perfection
Each Grantor authorizes the Secured Party to file financing statements describing the Collateral in the jurisdiction of organization of such Grantor, including Oregon.
Each Grantor shall deliver to the Secured Party all certificated Investment Property and Instruments with a value exceeding $250,000, together with undated instruments of transfer.
## Section 4 — Covenants of the Grantors
Each Grantor shall give the Secured Party at least thirty (30) days' prior written notice of any change in its legal name, jurisdiction of organization or chief executive office.
Each Grantor shall keep the Collateral insured and shall not permit any Lien on the Collateral other than Permitted Liens.
<!-- page 4 -->
## Section 5 — Remedies
Upon the occurrence and during the continuance of an Event of Default, the Secured Party may exercise all rights of a secured party under the Uniform Commercial Code, including the right to sell the Collateral at public or private sale upon ten (10) days' notice to the Grantors, which the Grantors agree is commercially reasonable.
Proceeds of Collateral are applied first to the costs of enforcement, second to interest and fees, third to principal, and last to the Grantors or as a court may direct.
<!-- page 5 -->
## Section 6 — Termination
This Security Agreement terminates, and the security interest is released, when the Commitments have terminated and all Obligations (other than contingent indemnification obligations) have been paid in full.
## Section 7 — Notices; Governing Law
All notices hereunder shall be given in the manner set forth in Section 10.1 of the Credit Agreement, to the Grantors at 455 Willamette Avenue, Corvallis, Oregon 97330.
This Security Agreement shall be governed by the laws of the State of California.
<!-- page 6 -->
## Schedule 1 — Grantors and Filing Offices
Corvallis Foods Group LLC — Oregon — Secretary of State
Corvallis Cold Storage LLC — Oregon — Secretary of State
Willamette Valley Produce, Inc. — Oregon — Secretary of State
## Schedule 2 — Collateral Locations
Albany, Oregon
