<!-- page 1 -->
# Consulting and Product Development Agreement
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2016-09-01 |
| Parties | Emerald Health Sciences Inc. ("EHS"); Emerald Health Nutraceuticals Inc. ("EHN"); Michael T. Murray, N.D. ("Dr. Murray") |
| Source | CUAD v1 / EmeraldHealthBioceuticalsInc_20200218_1-A_EX1A-6 MAT CTRCT_11987205_EX1A-6 MAT CTRCT_Development Agreement |

Consulting and Product Development Agreement

ARTICLE 1 -- PREAMBLE This Consulting and Licensing Agreement ("Agreement") is entered into this 1st
day of September 2016 ("Effective Date") by and between Emerald Health Sciences Inc. ("EHS"),
Emerald Health Nutraceuticals Inc. ("EHN"), and Michael T. Murray, N.D. ("Dr. Murray"). This
Agreement sets forth a description of those responsibilities of EHS, EHN, and Dr. Murray, of certain
rights granted to EHS and EHN, and of certain other terms.

ARTICLE 2 -- RESPONSIBILITIES 2.1 EHS and EHN shall bear all costs associated with the development,
inventory, sales, and marketing of any product ("Products") which EHS or EHN sells. 2.2 EHS: During
any Services Term (defined below), Dr. Murray shall provide the following ongoing services to EHS
for the compensation set forth in Article 5: (a) Provide guidance and/or lead initiatives related to
the development of pharmaceutical forms of the EHS cannabinoid portfolio including methods to
enhance bioavailability or delivery of these compounds. (b) Provide guidance and/or lead initiatives
related to the scientific or clinical validation of the pharmaceutical forms of the EHS cannabinoid
portfolio. (c) Provide such other services related to the foregoing as EHS may reasonably request
from time to time. 2.3 EHN: During any Services Term (defined below), Dr. Murray shall provide the
following ongoing services to EHN for the compensation set forth in Article 5: (a) Provide advice
and general assistance in EHN's business efforts primarily involving product development, but also
including guidance on marketing, sales, and product education. (b) Dr. Murray will act as public and
private advocate for EHN at appropriate opportunities, including mutually agreed upon EHN
educational events, public relations opportunities, and marketing efforts. (c) Provide such other
services related to the foregoing as EHN may reasonably request from time to time.

ARTICLE 3 -- DEFINITION OF SCOPE 3.1 Licensing rights. EHS and EHN agree that they shall not use Dr.
Murray's name or likeness on its products or product marketing materials unless specifically
approved by Dr. Murray by written acknowledgement including emails and facsimile transmissions of
his approval. 3.2 Exclusivity. Dr. Murray shall not directly assist in the development of any
product competitive to products developed by EHS or EHN. 3.3 Additional Services. Compensation for
any other mutually agreed upon project that is outside the scope of this Agreement will be
negotiated and mutually agreed upon by the parties.

ARTICLE 4 -- PROPERTY RIGHTS 4.1 EHS and EHN shall have the exclusive rights in and to all
ingredients, product specifications, goodwill, and all other intellectual property rights associated
with any Product(s); provided, however, that EHS and EHN shall not have any rights in or to Dr.
Murray's name or likeness except as expressly granted in writing herein or via electronic
transmission by Dr. Murray. Neither shall Dr. Murray have any rights or interest whatsoever in any
intellectual property, trademarks, trade names, service marks, or other names or marks owned or used
by EHS.

1

Source: EMERALD HEALTH BIOCEUTICALS INC., 1-A, 2/18/2020
<!-- page 2 -->
ARTICLE 5 -- COMPENSATION 5.1 Payment for Services. EHN will pay Dr. Murray $8,333 per month at the
end of each month during the first twelve months that this agreement is in effect. 5.2 Options. Upon
execution of this Agreement and on each anniversary date of this Agreement for as long as this
Agreement is active, EHS will grant Dr. Murray options to purchase 25,000 shares of EHS common stock
at their then fair market value (the "Options"). The Options will vest immediately on the date of
grant. 5.3 Royalty/Commission Payments. Dr. Murray will receive an annual royalty on net sales
(defined as gross sales minus returns) for any products (the "Dr. Murray Products") developed by Dr.
Murray for EHN for as long as the Dr. Murray Products are being sold. The Dr. Murray Products will
be listed on Schedule A attached hereto as they are developed and added to product portfolio. During
each year of this agreement, Dr. Murray will be paid no later than the 30st day of January based on
the cumulative Net Sales of the Dr. Murray Products for the preceding 12 months based upon the
following scale:

Net Sales per 12 Months Royalty $2,000,001 to $3,500,000 $150,000 $3,500,001 to $5,000,000 $250,000
$5,000,001 to $10,000,000 $350,000 $10,000,001 to $25,000,000 $500,000 $25,000,001 to $50,000,000
$1,000,000 $50,000,001 to $75,000,000 $1,500,000 $75,000,001 to $100,000,000 $2,000,000 Greater than
$100,000,000 $2,500,000

5.4 Ownership in EHN. Upon execution of this agreement, EHN will issue to Dr. Murray sufficient
shares to represent a 5% equity ownership in EHN. 5.5 Expenses and Travel. Any pre-approved expenses
incurred by Dr. Murray on behalf of EHS or EHN during any Services Term will be reimbursed,
including but not limited to travel expenses incurred for air travel, car rental, hotels and meals,
subject to prior approval in each case. EHS or EHN agrees to reimburse Dr. Murray for all reasonable
expenses (air travel, hotel, car rental, meals, materials, etc.) relating to EHS or EHN directed
activities, subject to prior approval in each case. 5.6 Withholdings and Taxes. Dr. Murray shall be
responsible for all federal or state withholdings and taxes, and shall indemnify EHS or EHN for any
actions brought against EHS or EHN with respect thereto. 5.7 Instructions for Payment. All payments
due and payable to Dr. Murray hereunder shall be paid to:

Michael T. Murray, N.D. [intentionally omitted] Or via electronic transfer as directed by Dr. Murray

2

Source: EMERALD HEALTH BIOCEUTICALS INC., 1-A, 2/18/2020
<!-- page 3 -->
5.8. EHS or EHN Benefits. Dr. Murray and Dr. Murray acknowledge and agree and it is the intent of
the parties hereto that except as set forth in Section 5, neither Dr. Murray nor any employees or
contractors of Dr. Murray receive any EHS-sponsored benefits, either as a consultant or employee.
Such benefits include, but are not limited to, paid vacation, sick leave, medical insurance, and
401(k) participation.

ARTICLE 6 - TERM and TERMINATION of AGREEMENT 6.1 Term. This Agreement shall become effective as of
the Effective Date and shall remain in effect as follows. (a) Dr. Murray's obligations set out
herein shall be performed from the Effective Date until December 31, 2018 (the initial "Services
Term"). The Services Term of this Agreement shall be automatically renewed for successive two-year
terms thereafter unless written notice is given by either party to the other, indicating that
party's intention not to renew the Services Term of this Agreement, at least ninety (90) days prior
to the end of the initial Services Term or any renewed Services Term. (b) Except as otherwise stated
herein as pertaining only to a Services Term, this Agreement shall remain in effect for ten years,
unless terminated in accordance with Sections 6.1 (a) or 6.2(b). For the avoidance of doubt, it is
the intent of the parties that subject to the terms and conditions set forth herein, the royalty
payments set out above shall continue in perpetuity for as long as the Dr. Murray Products are being
sold. 6.2 Termination EHS or EHN, on the one hand, and Dr. Murray, on the other, may terminate any
Services Term of this Agreement by delivering 60 days written notice to the other party.
Notwithstanding the foregoing, EHS or EHN may immediately terminate the Services Term without notice
should Dr. Murray be in breach of this Agreement. 6.3 Effect of Termination. (a) If a Services Term
is terminated or expires but this Agreement is not otherwise terminated in accordance with Section
6.2, all other rights and obligations shall remain in effect following the termination or expiration
of the Services Term. These include without limitation Sections 2.1, 3.1, 3.2, 4.1, 5.2, 5.3, 7, 8
and 9. (b) If this Agreement is termination in accordance with Section 6.2 by Dr. Murray, all of the
rights and obligations hereunder shall cease and be of no further force or effect, except that
Sections 4, 5 (to the extent obligations have accrued prior to termination), 7, 8 and 9 shall
survive. (c) If this Agreement is termination in accordance with Section 6.2 by EHS or EHN, all of
the rights and obligations hereunder shall cease and be of no further force or effect, except that
Sections 2.1, 3.1, 3.2, 4.1, 5.3, 7, 8 and 9 shall survive.

ARTICLE 7 -CONFIDENTIAL INFORMATION Neither EHS, EHN nor Dr. Murray shall disclose to any third
parties, except as required by law, at any time during or subsequent to the term of this Agreement,
any Confidential Information. "Confidential Information: includes proprietary information, technical
data, trade secrets or know-how, including, but not limited to, the terms and conditions of this
Agreement, research, product plans, products, services, suppliers, customer lists and customers,
prices and costs, markets, inventions, technology, formulas, specifications, designs, drawings,
marketing, licenses, finances, budgets and other business information. Confidential information does
not include information that (i) is or becomes generally known to the public, through no wrongful
act of the receiving party; (ii) is lawfully obtained by the receiving party from a third party
which has no obligation to maintain the information as confidential; (iii) was known prior to its
disclosure to the receiving party without any obligation to keep it confidential as evidenced by
tangible records kept by the receiving party

3

Source: EMERALD HEALTH BIOCEUTICALS INC., 1-A, 2/18/2020
<!-- page 4 -->
in the ordinary course of its business; (iv) is independently developed by the receiving party
without reference to the disclosing party's Confidential Information; or (v) is the subject of a
written agreement whereby the disclosing party consents to the use or disclosure of such
Confidential Information. If the disclosure of any such confidential information by EHS or Dr.
Murray to any third party is required in order to carry out the purpose and intent of this
Agreement, then EHS and Dr. Murray shall cause such third party to enter into a non-disclosure
Agreement with EHS and/or Dr. Murray as a condition to such disclosure.

ARTICLE 8 -- NOTICES All notices, communications, payments or other correspondence required to be
given or made under this Agreement shall be in writing and shall be deemed received (a) on the same
day if delivered in person, courier service, confirmed e-mail delivery, or facsimile transmission,
(b) on the next day if delivered by next day Federal Express, UPS, or other reputable overnight
carrier, or (c) within three (3) days if delivered by mail. All notices shall be given to the
parties at the following addresses, or such other addresses as may be the subject of a notice given
hereunder:

Emerald Health Sciences Inc. Dr. Avtar Dhillon ad@dhillon.com

Emerald Health Nutraceuticals Inc. Dr. Gaetano Morello gm@emerald.life

Michael T. Murray, N.D. 8305 N. Ridgeview Drive Paradise Valley, AZ 85253 (480) 659-6733 Fax (480)
659-6753

ARTICLE 9 - GENERAL LEGAL MATTERS (1) Governing Law, Venue, Amendments and Merger: This Agreement
shall be governed by and construed and enforced in accordance with the laws of the State of Arizona
without regard to conflict of law principles, may not be amended except by a writing signed by both
parties, and shall supersede any and all prior discussions and writings between the parties
concerning the subject matter. The parties hereby unconditionally consent to the federal courts
located in Arizona as the venue in any action arising out of or relating to this Agreement.

(2) Waiver: No waiver by either party of a right on any one occasion shall constitute a waiver of
such right on another occasion, and all such claimed waivers must be in writing signed by the party
against whom the waiver is claimed.

(3) Enforceability of Clauses: If any provision of this Agreement violates any law or is
unenforceable for any other reason, it shall be severed from this Agreement without affecting the
rest of the Agreement.

(4) Consent Required: Neither party is the agent or franchisee of the other party, and neither
party, under any circumstances, may bind the other party to any agreement or obligation to any third
person without the written consent of the party being bound.

4

Source: EMERALD HEALTH BIOCEUTICALS INC., 1-A, 2/18/2020
<!-- page 5 -->
In all matters relating to thisAgreement, both parties shall be acting solely as independent
contractors and shall be solely responsible for the acts of their respective employees, contractors
and agents. Employees, agents and contractors of one party shall not be considered employees, agents
or contractors of the other party. Any consent or approval by a party to this Agreement shall be
made only by a duly authorized officer of that party.

(5) Warranty of Authority: Each party represents and warrants that it has the full right and
authority to enter into this Agreement without violating the rights of any third party or violating
any applicable law or court order.

(6) Disputes: The parties shall first attempt to resolve any dispute related to this Agreement in an
amicable manner by mediation conducted in Phoenix, Arizona. The mediation shall take place no more
than sixty (60) days after written notice from the party requesting such mediation. Any disputes
remaining unresolved after mediation shall be settled by binding arbitration conducted in Phoenix,
Arizona under the Commercial Arbitration Rules of the American Arbitration Association (AAA).
Notwithstanding the foregoing, (i) the AAA shall not mediate or arbitrate the dispute, and the
parties shall agree upon a mediator and arbitrator, if necessary, but if the parties cannot agree
upon such mediator or arbitrator, Judicial Dispute Resolution of Phoenix, AZ shall select one of its
mediators/arbitrators to serve pursuant to this Agreement, and (ii) either party may apply to any
court of competent jurisdiction in Maricopa County, Arizona for such equitable, extraordinary or
injunctive relief as may be necessary to enforce the respective rights of the parties under this
Agreement. The prevailing party in arbitration or litigation shall be entitled to recover its costs
and reasonable attorney's fees and expenses, as determined by the arbitrator or judge, as
applicable.

(7) Entire Agreement: This Agreement contains the entire agreement of the parties.

(8) Force Majeure: A party shall not be responsible for any failure to timely perform due to a
"Force Majeure" event, which is an event that is beyond the reasonable control of a party and not
reasonably foreseeable with the exercise of reasonable care, nor avoidable through the payment of
nonmaterial additional sums (nor due the negligence, inattention, misconduct or inexperience of the
affected party). In such event, the party affected shall give prompt written notice to the other
party of the cause and shall take whatever reasonable steps are necessary to relieve the effect of
such cause as rapidly as possible.

(9) Counterparts: This Agreement may be executed in any number of counterparts, each of which shall
be an original, but all of which together shall be deemed to constitute one instrument.

(10) Electronic Means: Delivery of an executed copy of this Agreement by electronic facsimile
transmission or other means of electronic communication capable of providing a printed copy will be
deemed to be execution and delivery of this Agreement as of the Effective Date. A confirming copy of
the same shall be sent by mail to the above address

(11) Assignment: Dr. Murray has unique qualifications to provide the services contemplated herein,
and shall not assign any of its or his rights or obligations to any other person or entity without
EHS's written consent, which may be withheld or granted in EHS's discretion.

In witness whereof the parties have caused this Agreement to be executed and delivered by their
respective duly authorized representatives as of the Effective Date.

5

Source: EMERALD HEALTH BIOCEUTICALS INC., 1-A, 2/18/2020
<!-- page 6 -->
Dr. Murray Emerald Health Sciences Inc.

/s/Michael T. Murray, N.D By:/s/ Avtar Dhillon Michael T. Murray, N.D

Emerald Health Nutraceuticals Inc. By:/s/Gaetano Morello

1

Source: EMERALD HEALTH BIOCEUTICALS INC., 1-A, 2/18/2020
