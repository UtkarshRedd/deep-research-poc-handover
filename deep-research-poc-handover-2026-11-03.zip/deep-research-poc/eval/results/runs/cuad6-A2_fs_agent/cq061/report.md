# Which agreement in the corpus was entered into between Holiday RV Superstores, Inc. and...

*Question:* Which agreement in the corpus was entered into between Holiday RV Superstores, Inc. and Affinity Group, Inc.? Give its title and date.

## Identify agreement between Holiday RV Superstores, Inc. and Affinity Group, Inc.

[DROPPED: claim s1.1 could not be verified against its cited source.] The agreement date is 2002-03-20. [dac76ece63f3755d p.1] The agreement body states it is made as of the 20th day of March 2002. [dac76ece63f3755d p.1]

## Verification appendix

Claims: 3 · supported: 2 · partially: 0 · dropped: 1 · gaps: 0 · tier-1 support rate: 0.67

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | drop | 0.00 | e1→[dac76ece63f3755d p.1] e3→[dac76ece63f3755d p.1] |  |
| s1.2 | s1 | keep | 1.00 | e2→[dac76ece63f3755d p.1] |  |
| s1.3 | s1 | keep | 1.00 | e3→[dac76ece63f3755d p.1] |  |

### Evidence

- e1 [dac76ece63f3755d p.1 L2-2] drop (0.0): "# ENDORSEMENT AGREEMENT"
- e2 [dac76ece63f3755d p.1 L6-6] keep (1.0): "| Agreement Date | 2002-03-20 |"
- e3 [dac76ece63f3755d p.1 L14-18] keep (1.0): "This Agreement is made as of the 20th day of March 2002, by and between Holiday RV Superstores, Inc., d/b/a Recreation USA (the "Company"), a Delaware corporation having its principal office at 200 East Broward Boulevard, Suite 920, Ft. Lau…"
