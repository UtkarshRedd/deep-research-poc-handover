<!-- page 1 -->
# SUPPLY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Supply Agreement |
| Agreement Date | 2018-05-29 |
| Parties | SutroVax, Inc. ("SutroVax"); Sutro Biopharma, Inc. ("Sutro"); SutroVax and Sutro (individually, as a “Party” and collectively, as the “Parties") |
| Source | CUAD v1 / VAXCYTE,INC_05_22_2020-EX-10.19-SUPPLY AGREEMENT |

Exhibit 10.19

CERTAIN CONFIDENTIAL INFORMATION CONTAINED IN THIS DOCUMENT, MARKED BY [***], HAS BEEN OMITTED
BECAUSE IT IS BOTH (I) NOT MATERIAL AND (II) WOULD LIKELY CAUSE COMPETITIVE HARM IF PUBLICLY
DISCLOSED.

SUPPLY AGREEMENT

This SUPPLY AGREEMENT ("Supply Agreement") is made as of May 29, 2018 (the "Effective Date") by and
between SutroVax, Inc., a Delaware corporation having principal offices at 353 Hatch Dr., Foster
City, CA 94404 ("SutroVax") and Sutro Biopharma, Inc., a Delaware corporation, having principal
offices at 310 Utah Ave, Suite 150, South San Francisco, CA, 94080 ("Sutro"). SutroVax and Sutro may
be referred to herein by name or individually, as a "Party" and collectively, as the "Parties."

BACKGROUND

A. Sutro controls certain proprietary technology which permits cell-free expression of proteins, and
Sutro licensed such technology to SutroVax under that certain Amended and Restated SutroVax
Agreement dated as of October 12, 2015 (the "License Agreement").

B. SutroVax is a vaccine company primarily in the business of developing, manufacturing and
marketing vaccine products; and

C. SutroVax desires to purchase from Sutro, and Sutro desires to supply to SutroVax, the Extracts
and Custom Reagents (as defined below) upon the terms and subject to the conditions set forth
herein.

NOW, THEREFORE, in consideration of the covenants, conditions and undertakings hereinafter set
forth, and for other good and valuable consideration, the receipt and sufficiency of which is hereby
acknowledged, the Parties hereby agree as follows:

AGREEMENT

ARTICLE 1

DEFINITIONS/ INTERPRETATION

For the purposes of this Supply Agreement, the following capitalized words and phrases shall have
the following meanings:

1.1 "Affiliate" means, with respect to either Party, any business entity controlling, controlled by,
or under common control with such Party. For the purpose of this definition only, "control" means
(i) the possession, directly or indirectly, of the power to direct the management or policies of a
business entity, whether through the ownership of voting securities, by contract or otherwise, or
(ii) the ownership, directly or indirectly, of at least fifty percent (50%) of the voting securities
or other ownership interest of a business entity. Notwithstanding the above, in no event shall Sutro
(or any entity that would be an Affiliate of SutroVax solely because it is an Affiliate of Sutro) be
deemed an Affiliate of SutroVax, or SutroVax (or any entity that would be an Affiliate of Sutro
solely because it is an Affiliate of SutroVax) an Affiliate of Sutro.
<!-- page 2 -->
1.2 "Applicable Law" means all laws, ordinances, rules, rulings, directives and regulations of any
Governmental Authority that apply to the development, manufacture or supply of any Product or the
other activities contemplated under this Supply Agreement, including (i) all applicable federal,
state and local laws, rules and regulations; (ii) the U.S. Federal Food, Drug and Cosmetic Act;
(iii) regulations and guidelines of the FDA and other Regulatory Authorities, including cGMPs, if
applicable; and (iv) any applicable non-U.S. equivalents of any of the foregoing, including
guidelines of the International Conference on Harmonization of Technical Requirements for
Registration of Pharmaceuticals for Human Use (as amended from time to time).

1.3 "cGMPs" means current good manufacturing practices and standards as set forth (and as amended
from time to time) in the current Good Manufacturing Practice Regulations of the U.S. Code of
Federal Regulations, including 21 C.F.R. Sections 210 and 211, the European Community Directive
2003/94/EC and the ICH Harmonised Tripartite Guideline, Good Manufacturing Practice Guides for
Active Pharmaceutical Ingredients (Q7).

1.4 "Components" means any product or material used in the Manufacture of the Products including the
packaging materials.

1.5 "Extract" means Sutro's extract derived from strains of E. coli identified on Schedule 1
attached hereto, as may be amended from time to time in accordance with Section 12.7, and any new
versions and improvements thereof that may be included in Schedule 1 by written agreement of the
Parties in accordance with Section 12.7.

1.6 "Facility" or "Facilities" means the facilities where Product will be Manufactured as set forth
in Schedule 1. Schedule 1 may be amended from time to time in accordance with this Supply Agreement
to add or remove facilities.

1.7 "FDA" means the United States Food and Drug Administration, or any successor agency thereto
performing similar functions.

1.8 "Fully Burdened Manufacturing Costs" means, with respect to a Product, Sutro's costs of
manufacturing such Product, which manufacturing costs shall mean: (a) [***], and (b) [***], in each
case to the extent directly allocated to and incurred in the manufacture by Sutro of such Product
supplied to SutroVax, its Affiliates and Sublicensees. Fully Burdened Manufacturing Costs shall not
include any [***] and shall be calculated in accordance with the foregoing, GAAP and Sutro's
policies and procedures for its other products, in each case consistently applied (and such plant
operations and support services costs shall be allocated consistent with GAAP and other products of
Sutro in that facility).

1.9 "Governmental Authority" means any court, agency, department, authority or other instrumentality
of any nation, state, country, city or other political subdivision, including any Regulatory
Authority.
<!-- page 3 -->
1.10 "Manufacture" or "Manufacturing" means the processes and procedures for the supply of the
Products, including, (a) the supply and quality control of the Components; (b) the manufacture of
the Products in bulk; (c) the Packaging and labeling of the Products; (d) the quality control of the
Products; and (e) the storage of the Products until shipment.

1.11 "Package" or "Packaging" means packaging Product(s) in accordance with applicable
Specifications.

1.12 "Person" means an individual, a corporation, a partnership, an association, a trust or other
entity or organization, including a government or political subdivision or an agency thereof.

1.13 "Price" means the price to be paid by SutroVax for each Product as set forth on Schedule 1 of
this Supply Agreement and as may be modified from time to time in accordance with Section 3.2.

1.14 "Product(s)" means the Extract and Custom Reagents.

1.15 "Custom Reagents" means Sutro's custom reagents identified on Schedule 1 attached hereto, and
any new versions and improvements thereof that may be included in Schedule 1 by written agreement of
the Parties in accordance with Section 12.7.

1.16 "Regulatory Approval" means, with respect to a product, all approvals, licenses, registrations
or authorizations necessary to market and sell such product in a particular jurisdiction in the
Territory (including applicable approvals of labeling, price and reimbursement for such product in
such jurisdiction).

1.17 "Regulatory Authority" means any federal, national, multinational, state, provincial or local
regulatory agency, department, bureau or other governmental entity, including the FDA, with
authority over the development, Manufacture or commercialization (including approval of Regulatory
Approvals) of any Product(s) in any jurisdiction in the Territory.

1.18 "Regulatory Materials" means regulatory applications, submissions, notifications,
communications, correspondence, registrations, Regulatory Approvals and/or other filings made to,
received from or otherwise conducted with a Regulatory Authority (including minutes of meeting with
Regulatory Authorities) that are necessary or reasonably desirable to access in connection with the
development, manufacture, marketing, sale or other commercialization of any Product in a particular
country or regulatory jurisdiction. Regulatory Materials include, without limitation, INDs, NDAs,
BLAs, clinical trial applications, marketing approval applications and applications for pricing
approvals.

1.19 "Required Standards" means Applicable Law, the Specifications, and the warranties given by
Sutro in Section 7.3, provided that Required Standards shall not include compliance with cGMPs for
Custom Reagents, Extract identified as "research grade" Extract or Other Extracts.
<!-- page 4 -->
1.20 "Specifications" means, with respect to a Product or applicable Component thereof, all written
product, regulatory, Manufacturing, release criterion, quality control and quality assurance
procedures, processes, practices, standards, instructions and specifications applicable to the
Manufacture of such Product or Component, as agreed to by the Parties in writing from time to time.
The initial Specifications for the Products are attached hereto as Schedule 2.

1.21 "SutroVax CMO" means any contract manufacturer responsible for supplying or manufacturing a
Vaccine Composition on behalf of SutroVax or its Affiliates, selected in accordance with Section .2.

1.22 "Territory" means worldwide.

1.23 "Third Party" means any Person other than SutroVax, Sutro, or their respective Affiliates.

1.24 Additional Definitions. Each of the following terms shall have the meaning described in the
corresponding Section of this Supply Agreement indicated below:

1.25 Interpretation. The captions and headings to this Supply Agreement are for convenience only,
and are to be of no force or effect in construing or interpreting any of the provisions of this
Supply Agreement. Unless specified to the contrary, references to Articles, Sections, Schedules or
Exhibits mean the particular Articles, Sections, Schedules or Exhibits to this Supply Agreement and
references to this Supply Agreement include all Schedules and Exhibits hereto. Unless context
clearly requires otherwise, whenever used in this Supply Agreement: (i) the words "include" or
"including" shall be construed as incorporating, also, "but not limited to" or "without limitation;"
(ii) the word "or" shall have its inclusive meaning of "and/or;" (iii) the word "notice" shall
require notice in writing (whether or not specifically stated) and shall include notices, consents,
approvals and other written communications contemplated under this Supply Agreement; (iv) the words
"hereof," "herein," "hereunder," "hereby" and derivative or similar words refer to this Supply
Agreement (including any Schedules and

Term Section Defined Alternate Supplier 2.15 Acceptance Period 4.2 COA/COC 4.1 CMC 6.2 CMO 2.15
Delivery Time Period 2.9.2 Disputed Matter 11.4 Drug Master File 6.2 Effective Date Preamble Force
Majeure 12.3 Forecast 2.3 Indemnify 9.1.1 Laboratory 4.3 Latent Defect 4.2 Liabilities 9.1.1 License
Agreement Background Manufacturing Change 6.6 MSDS 4.1 Other Extract 2.16 Party or Parties Preamble

Term Section Defined Phase 3/Commercial Supply Agreement 2.14 Q1, Q2 or Q3 2.3 Quality Agreement 6.7
Senior Management 11.2 Short Dated Product 2.11 Sutro Preamble Sutro Activity Criteria 4.1 Sutro
Activity Test 4.1 Sutro Indemnitees 9.1.2 SutroVax Preamble SutroVax Activity Criteria 4.1 SutroVax
Activity Test 4.1 SutroVax Indemnitees 9.1.1 Supply Agreement Preamble Term 10.1 Third-Party Claim
9.1.1 Transfer Addendum 2.15 Work Order 2.3
<!-- page 5 -->
Exhibits); (v) provisions that require that a Party or the Parties "agree," "consent" or "approve"
or the like shall require that such agreement, consent or approval be specific and in writing; (vi)
words of any gender include the other gender; (vii) words using the singular or plural number also
include the plural or singular number, respectively; (viii) references to any specific law, or
article, section or other division thereof, shall be deemed to include the then-current amendments
thereto or any replacement thereof; (ix) neither Party shall be deemed to be acting "under the
authority" of the other Party; and (x) any capitalized terms used and not defined in this Supply
Agreement shall have the meaning set forth in the License Agreement.

ARTICLE 2 SUPPLY

2.1 Supply. Pursuant to the terms and conditions of this Supply Agreement, Sutro agrees that it will
Manufacture the Product(s) at the Facility(ies) for SutroVax and shall supply the Product(s) to
SutroVax, its Affiliates, and any SutroVax CMO, for purposes of production of Vaccine Compositions
(including development of processes for the production of Vaccine Compositions), solely for
non-clinical research purposes or in Phase I or Phase II clinical trials of such Vaccine
Compositions..

2.2 Transfer of Product. Subject to Section 2.1, SutroVax may transfer Products to SutroVax CMOs
selected by SutroVax and that are reasonably acceptable to Sutro (the acceptance of which by Sutro
not to be unreasonably withheld, conditioned or delayed) or previously approved by Sutro.

2.3 Work Orders. From time to time, Sutro and SutroVax may execute one or more work orders, that
describe the Product to be Manufactured, the quantities of each Product to be Manufactured and
supplied to SutroVax, the Price to be charged by Sutro (which shall be as set forth in Section 3.2)
and paid by SutroVax for the Product, and the delivery date(s) for such Product, (as executed, a
"Work Order"). Each Work Order will expressly refer to this Supply Agreement, will form a part of
this Supply Agreement, and will be subject to the terms and conditions contained herein. Sutro shall
not unreasonably withhold its agreement to any proposed Work Order requested by SutroVax. Sutro
shall be obligated to execute proposed Work Orders requested by SutroVax (except with respect to
Other Extracts) with respect to quantities in such proposed Work Order for delivery at least [***]
months after SutroVax's request to the extent such quantities of Product (when added to the
quantities of such Product in Work Orders previously agreed between the Parties for delivery within
the one (1) calendar year period prior to the requested delivery date of the proposed Work Order)
are less than (a) [***] liters with respect to Extract or (b) a corresponding amount of each Custom
Reagent to support use of [***] liters of Extract. Sutro shall notify SutroVax as soon as possible
if Sutro believes it will be unable to deliver Product in accordance with the applicable Work Order.
Sutro's providing of such notification shall not be interpreted in any manner as relieving Sutro of
its obligations under this Supply Agreement, nor shall it prevent SutroVax from pursuing any and all
rights and remedies SutroVax may have based on Sutro's failure to be able to deliver any Product in
accordance with the terms of this Supply Agreement.
<!-- page 6 -->
2.4 Orders.

2.4.1 Purchase Orders. Once both parties have executed a Work Order, SutroVax shall place a purchase
order for the amounts of Products to be purchased under such Work Order with delivery dates for such
amounts consistent with such Work Order. Additionally, SutroVax may from time to time place purchase
orders for additional quantities specifying requested delivery dates in accordance with reasonable
delivery schedules and lead times; in each case, as may be agreed upon from time to time by the
Parties. Each purchase order placed by SutroVax shall specify the quantity of Product,
destination(s) and requested delivery dates. Sutro shall promptly accept all purchase orders with
respect to the amounts of Products to be purchased under the applicable Work Order and shall accept
or reject any amount in the purchase order in excess of the amounts of Products to be purchased
under the applicable Work Order and all other purchase orders for Product submitted by SutroVax in
accordance with this Article 2 within [***] days from receipt of the order; provided however that
Sutro shall use Commercially Reasonable Efforts to accept such amounts and purchase orders. Accepted
purchase orders may not be cancelled without the prior written agreement of both Parties except as
set forth in Sections 2.5. Unless otherwise directed by SutroVax, Sutro shall fill all accepted
purchase orders for Product in accordance with the requested due dates as set forth in further
detail in Section 2.9.2.

2.4.2 No Conflicting Terms. The terms and conditions of this Supply Agreement shall be controlling
over any conflicting terms and conditions stated in SutroVax's purchase order or Sutro's invoice,
confirmation or other standardized document. Any purchase order, order acknowledgement, invoice,
proposal or other document which conflicts with or adds to the terms and conditions of this Supply
Agreement with respect to the Manufacture and supply of Product for the Territory is hereby
rejected, unless the Parties mutually agree to the contrary in writing.

2.4.3 Initial Order. Notwithstanding Section 2.3 or this Section 2.4, Sutro accepts and agrees to
fulfil the order previously placed by or on behalf of SutroVax (or to be placed by or on behalf of
SutroVax, if no already placed) for the quantities of Product set forth in Schedule 3 by the
delivery date set forth therein (the "Initial Order").

2.5 Cancellation. Notwithstanding anything herein to the contrary, SutroVax may not modify or cancel
purchase orders with respect to the amounts of Product to be purchased under the applicable Work
Order, however SutroVax may modify or cancel other purchase orders (including amounts in a purchase
order in excess of the amounts of Product to be purchased under the applicable Work Order) for the
Products provided that such modification or change is made further in advance of the originally
requested delivery date than the required lead time, where the agreed required lead time for the
applicable purchase order has been evidenced in writing (including, for example, by email) between
the Parties.

2.6 Delivery and Risk of Loss. Sutro shall mark Product for delivery to the destination(s) specified
by SutroVax. All shipments of Product(s) shall be delivered [***] (lncoterms 2010) Sutro Facility.
Title and risk of loss and damage to the Product(s) shall remain with Sutro until the Product(s) are
delivered in accordance with the foregoing, at which time title and risk ofloss and damage to the
Product(s) shall pass to SutroVax. SutroVax will arrange for shipping from Sutro's Facility to the
destination specified by SutroVax at SutroVax's cost and expense.
<!-- page 7 -->
2.7 Packaging. Sutro shall provide the Product to SutroVax in Packaged form in accordance with the
Required Standards.

2.8 Conformance to Required Standards. Sutro shall Manufacture the Product(s) in accordance with the
Required Standards, as the same may be amended or supplemented from time to time. Each Party shall
keep the other promptly and fully advised of any new requirements of the applicable Regulatory
Authority or Applicable Law of which it becomes aware and Sutro shall promptly implement such
requirements as described in Section 6.6.

2.9 Supply and Delivery.

2.9.1 Shortage. Sutro shall use reasonable efforts to promptly notify SutroVax in writing in the
event that Sutro is unable or anticipates that it will be unable to supply compliant Product in
accordance with the requirements of this Supply Agreement, including the Quality Agreement and all
Required Standards, and each Work Order. Sutro shall use Commercially Reasonable Efforts to overcome
any inability or anticipated inability to so supply compliant Product to SutroVax.

2.9.2 Delivery Delays. Subject to Section 2.4.1 (including applicable lead times agreed upon in
accordance with Section 2.4.1) Sutro shall make deliveries of Product(s) in accordance with Section
2.6, no more than [***] days before or [***] after the delivery dates specified by SutroVax in the
relevant purchase order (provided that such delivery date is in accordance with the applicable Work
Order or such purchase order was otherwise accepted by Sutro) (the "Delivery Time Period"). For any
failure to supply compliant Product(s) in the later of the Delivery Time Period and the period
ending [***] after the delivery date specified under the Work Order, without limiting SutroVax's
other remedies, subject to this Section 2.9.2 and Section 9.3 (Limitation of Liability), Sutro shall
be liable for any non-cancelable Third Party penalties, costs and expenses incurred by SutroVax as a
result of Sutro's failure to supply Product(s) as aforesaid, subject to receipt by Sutro of
appropriate documentary evidence of such penalties, costs and expenses to the extent such evidence
of such amounts may be provided by SutroVax without breaching SutroVax's or its Affiliates' duties
of confidentiality to such Third Party (and provided that SutroVax shall use commercially reasonable
efforts to (i) minimize or eliminate such penalties, costs and expenses and (ii) where provision of
such evidence to Sutro would result in a breach of such duties of confidentiality, to obtain the
consent of the applicable Third Party to the provision of such evidence to Sutro). In the event that
Sutro makes a Manufacturing Change and is not able to Manufacture and supply Product in conformance
with the Required Standards within [***] days of the delivery date identified on the applicable
purchase order, Sutro shall Manufacture such Product without such Manufacturing Change. The rights
of SutroVax set forth in this paragraph are in addition to any other rights set forth in this Supply
Agreement.

2.10 Allocation. Without limiting any other rights or remedies available to SutroVax, if the demand
for a Product in aggregate exceeds available supply or Sutro otherwise concludes that it may be
unable to supply a Product in accordance with the requirements of this Supply Agreement in the
quantities and within the time periods specified in each Work Order and the corresponding purchase
orders that have been accepted by Sutro, Sutro shall immediately notify SutroVax of such shortfall
(or anticipated shortfall), and shall use Commercially Reasonable
<!-- page 8 -->
Efforts to procure Components and capacity adequate to meet accepted purchase orders and supply
compliant Product in accordance with the requirements of this Supply Agreement. Sutro shall allocate
its available Components and manufacturing capacity to provide SutroVax with quantities of such
Product at least equal to the greater of (a) [***] of the amount of Product (or products equivalent
to Product) that Sutro allocates for itself and its Affiliates (but in no event less than [***]
liters of Extract per month and the minimum allocation volume set out in Schedule 1 of each Custom
Reagent per month), provided that SutroVax demonstrates actual need for the applicable quantities of
Extract, and (b) the [***]. Without limiting the foregoing, if there is a shortage of supply of
Product, Sutro shall provide Product to SutroVax for any quantities of Product ordered by SutroVax
in accordance with the applicable Work Order or purchase order in priority to any subsequent Third
Party purchase orders, but not in priority to any Third Party purchase orders or other binding
commitment placed before placement of the applicable SutroVax Work Order or purchase order.

2.11 Short Dated Product. Sutro agrees to ship all Product(s) so that they are delivered to SutroVax
and will remain compliant with the Specifications for at least [***] months from the date of
delivery in accordance with this Supply Agreement.

2.12 Subcontracting by Sutro. Sutro shall (a) ensure that any subcontractor or delegatee of Sutro's
obligations under this Supply Agreement has and maintains all appropriate qualifications; (b) enter
into a quality agreement with each such subcontractor and delegatee which terms are similar to the
terms of the Quality Agreement between SutroVax and Sutro; and (c) be responsible for each
subcontractor's and delegatee's performance hereunder (including performance or non-performance by
such subcontractor or delegatee that would constitute a breach of this Supply Agreement or such
quality agreement if conducted by Sutro) as if Sutro were itself performing such activities. Sutro
shall not subcontract the Manufacture of Product to a Third Party without SutroVax's prior consent
other than to an Alternate Supplier as expressly set forth in Section 2.15.

2.13 CMOs. Notwithstanding anything to the contrary in this Supply Agreement, SutroVax shall have
the rights to purchase Available Extracts and Extracts from CMOs (as defined in the License
Agreement) to the extent provided in section 3.1 of the License Agreement.

2.14 Phase 3/Commercial Supply Agreement. If requested by SutroVax in writing (which request shall
not be made prior to [***]), the Parties shall negotiate in good faith reasonable terms and
conditions of an agreement for the supply by Sutro of the Products for the production of Vaccine
Compositions for use in phase 3 clinical studies and for commercial purposes ("Phase 3/Commercial
Supply Agreement"). The price for the Products Manufactured by Sutro under the Phase 3/Commercial
Supply Agreement shall not exceed [***] of the Fully Burdened Manufacturing Cost thereof. If the
Parties have not entered into the Phase 3/Commercial Supply Agreement within [***] after SutroVax's
request to negotiate the Phase 3/Commercial Supply Agreement, upon either Party's request by written
notice to the other Party the terms and conditions of the Phase 3/Commercial Supply Agreement shall
be determined by binding arbitration in accordance with the procedures set forth in Section 11.4.
Upon the selection of one draft Phase 3/Commercial Supply Agreement by the arbitrator pursuant to
Section 11.4, unless SutroVax elects not to enter into such Phase 3/Commercial Supply
<!-- page 9 -->
Agreement by written notice thereof to Sutro within [***] days after such selection, the Parties
shall execute the definitive Phase 3/Commercial Supply Agreement selected by the arbitrator (but
excluding, for clarity, any provision granting to SutroVax or its Affiliates or Sublicensees any
right to obtain or use any Sutro Core Know-How); and if SutroVax elects to not enter into the Phase
3/Commercial Supply Agreement selected by the arbitrator by providing notice thereof within such
[***] day period, then neither Party shall be obligated to enter into the Phase 3/Commercial Supply
Agreement.

2.15 Qualification of Alternate Supplier.

2.15.1 Transfer Addendum.

(a) Transfer Addendum. Upon SutroVax' written request, the Parties agree to negotiate in good faith
an addendum to this Supply Agreement setting forth the terms and conditions pursuant to which Sutro
will conduct a Process Transfer to a Third Party contract manufacturer ("CMO") and/or engage such
CMO to establish Capacity to Manufacture Extract (as Process Transfer and Capacity are defined
below), in each case for the Manufacture and supply of such Extract for SutroVax' (or its
Affiliate's or SutroVax CMO's) use to manufacture Vaccine Compositions, consistent with the
remainder of this Section 2.15 (such addendum, a "Transfer Addendum"). As requested by SutroVax,
this procedure may also be used in the event that SutroVax wishes Sutro to conduct a Process
Transfer to a Third Party CMO in order to establish Capacity to Manufacture Custom Reagents. In
connection with such request, SutroVax shall provide to Sutro a description of the desired Process
Transfer and/or Capacity, including timing and other requirements thereof. Such Transfer Addendum
shall:

(i) include a plan and budget for the conduct of the Process Transfer and/or establishment of such
Capacity, which shall include amounts charged by the CMO (as defined further below, the "Alternate
Supplier") to receive and conduct such Process Transfer and/or establish such Capacity, as well as
reasonable FTE costs for Sutro personnel performing and managing technology transfer activities in
accordance with the Transfer Addendum·

(ii) require SutroVax to fund the costs incurred by Sutro to conduct Process Transfer and/or
establish such Capacity in accordance with such budget;

(iii) provide for initiation and completion of the Process Transfer and establishment of Capacity as
requested by SutroVax, to the extent possible;

(iv) to the extent requested by SutroVax, be designed to enable the Alternate Supplier to
Manufacture Extract of suitable quality for use in Phase 3 clinical trials and commercialization of
a Vaccine Composition at a capacity to support SutroVax' projected commercial requirements for
Extract (or other capacity identified by SutroVax in connection with the negotiation of the Transfer
Addendum), as requested by SutroVax;

(v) require the Parties to fully cooperate to verify that the Extract supplied by the Alternate
Supplier meets the Specifications, to validate the Manufacturing process implemented at the
Alternate Supplier and to qualify the Alternate Supplier, in each case to supply Extract for
SutroVax' use in Phase 3 clinical trials and commercialization of a Vaccine Composition
(collectively, with respect to Capacity established, "Validating" such Capacity);
<!-- page 10 -->
(vi) include mechanisms for keeping SutroVax fully informed, at scheduled intervals not to exceed
once per quarter, of the progress of the Process Transfer and establishing such Capacity, as
applicable, including with respect to the anticipated date for qualifying the Alternate Supplier and
any changes to such anticipated date;

(vii) provide a right for SutroVax to modify the timing of or terminate the Process Transfer,
Capacity or specified aspects thereof on reasonable notice, subject to SutroVax' agreement to bear
any resulting termination or cancellation fees charged by the Alternative Supplier; and

(viii) include a mechanism for Sutro to cooperate with SutroVax and keep SutroVax reasonably
informed with respect to Sutro's negotiation of an agreement with a potential Alternate Supplier for
a Process Transfer and/or establishment of Capacity, including with respect to pricing for Extract
from the Alternate Supplier to Sutro and any commitments to purchase quantities of Extract from the
Alternate Supplier that SutroVax would be obligated to assume (e.g., in connection with establishing
Capacity), if any, and require Sutro to obtain SutroVax' approval (not to be withheld unreasonably)
of the terms of such agreement prior to entering into such agreement to the extent that the terms
apply to SutroVax (it being understood that Sutro may redact any terms that are not relevant to
SutroVax).

(b) Scope. As used above, "Process Transfer" means a technology transfer of Sutro's know-how and
information as is necessary or useful for the Third Party CMO to Manufacture in its own facilities
Extract that meets SutroVax' requirements, including any such information and know-how as would be
needed for such CMO to scale up such Manufacture to the requested commercial volumes. To establish
"Capacity" means that the CMO would take such actions as are necessary (including validation and if
necessary adapting or reserving existing facilities, establishing new facilities and/or procuring
necessary equipment) to Manufacture Extract meeting SutroVax' requirements for Phase 3 and
commercial supply in such quantities as SutroVax designates. It is understood that SutroVax may
request that the Process Transfer and establishment of Capacity be undertaken in separate steps, for
example by undertaking an initial Process Transfer to demonstrate the CMO's ability to Manufacture
Extract, and then later establishing Capacity for Phase 3 and commercial supply, as requested by
SutroVax in accordance with Section 2.15.1(a) (i.e., in separate requests).

(c) Selection of Alternate Supplier. The "Alternate Supplier" will be selected by Sutro, provided
that Sutro must select an "Alternate Supplier" that is substantially similar to those CMOs
identified on Schedule 2.15.1 hereto and provided further that SutroVax shall have the right to veto
such selection based only on a genuine and material conflict of interest between SutroVax and the
Alternate Supplier. Additional CMOs may be added to Schedule 2.15.1 by Sutro with SutroVax's
approval (not to be withheld unreasonably).
<!-- page 11 -->
(d) Alternate Supplier as Subcontractor. It is understood that the Alternate Supplier established
under the Transfer Addendum shall operate as a subcontractor of Sutro under this Supply Agreement
and the Phase 3/Commercial Supply Agreement, and as such SutroVax will order from Sutro thereunder
any Extract to be Manufactured by such Alternate Supplier. Subject to the foregoing, the Transfer
Addendum and the Phase 3/Commercial Supply Agreement will include reasonable and customary rights
for SutroVax to conduct audits/inspections, site visits, quarterly meetings, each such
audit/inspection, site visit and quarterly meeting to be coordinated by Sutro and to occur in the
presence of a representative for Sutro and SutroVax, in connection with the Alternate Supplier's
manufacture of Extract for supply to SutroVax. For clarity, SutroVax shall not conduct any business
discussions for the supply of Extract with the Alternate Supplier in a manner that induces the
Alternate Supplier to breach its agreement with Sutro. Notwithstanding the foregoing, in the event
Sutro undergoes a Change of Control or Sutro permits any third party to acquire Extract directly
from an Alternate Supplier established under the Transfer Addendum, then SutroVax shall thereafter
have the right to establish a supply agreement with and obtain supply of Extract directly from such
Alternate Supplier.

(e) Quotations. Upon SutroVax's request (which request, for clarity, may be before a request to
negotiate a Transfer Addendum), Sutro shall seek quotations from one or more Third Party CMO(s) for
such a Process Transfer and/or establishment of such Capacity, in each case as requested by
SutroVax, and the Parties shall reasonably cooperate to establish requests for quotations for such
purposes.

(f) Arbitration. If the Parties have not agreed upon a Transfer Addendum within [***] after
SutroVax' request, upon SutroVax' request by written notice to Sutro, the terms and conditions of
the Transfer Addendum shall be determined by binding arbitration in accordance with the procedures
set forth in Section 11.4. For clarity, however, it is understood that a Transfer Addendum shall not
include any provision granting to SutroVax or its Affiliates or Sublicens.ee s any right to obtain
or use any Sutro Core Know-How.

2.15.2 Source of Supply. It is understood that after the Alternate Supplier is qualified, SutroVax
shall have the right under this Supply Agreement and the Phase 3/Commercial Supply Agreement to
specify whether Extract ordered from Sutro pursuant to this Agreement or the Phase 3/Commercial
Supply Agreement will be Manufactured at Sutro's Facility or at the Alternate Supplier's facilities
(and to the extent Extract from the Alternate Supplier is ordered under this Supply Agreement or the
Phase 3/Commercial Supply Agreement, the facility of the Alternate Supplier shall be deemed a
Facility for purposes of this Supply Agreement and the Phase 3/Commercial Supply Agreement).
Notwithstanding the foregoing, to the extent the FDA and EMA have confirmed that Extract
manufactured at Sutro's Facility and the Alternate Supplier's Facility are interchangeable and can
be supplied from either such Facility without any additional regulatory requirements or regulatory
delay with respect to the applicable Vaccine Composition, and such Extract otherwise meets SutroVax'
requirements, then with SutroVax' consent (not to be withheld unreasonably) Sutro may supply Extract
from either Sutro's Facility or the Alternate Supplier's Facility.

2.15.3 Price. To the extent Sutro or its Affiliate Manufactures Extract supplied to SutroVax, the
Price (per unit volume or unit weight) under this Supply Agreement and the Phase 3/Commercial Supply
Agreement for such Extract shall not exceed [***] of the Fully Burdened Manufacturing Costs of such
Extract; and to the extent the Extract to be supplied to SutroVax is Manufactured by a Third Party
(including the Alternate Supplier), the Price to be
<!-- page 12 -->
charged to SutroVax under this Supply Agreement and the Phase 3/Commercial Supply Agreement for such
Extract shall equal the amount Sutro paid such Third Party for such Extract ("OOP Cost") plus an
amount reasonably calculated to cover Sutro's FTE costs to procure and manage the relationship with
such Third Party, such amount not to exceed [***] of the OOP Cost for such Extract. To the extent
that Sutro or its Affiliate receives any portion of the amounts paid to such Third Party to
Manufacture Extract (e.g., as a profit share or otherwise), the Price to be charged SutroVax shall
be the lesser of i) [***], or ii) [***]; in either case, [***]. For clarity, Section 3.4 of the
License Agreement shall apply with respect to the Alternate Supplier.

2.15.4 Sutro/Third Party use of Alternate Supplier. Once the Alternate Supplier is qualified
pursuant to this Section 2.15, SutroVax shall have the first right (as between SutroVax and Sutro or
Third Parties supplied or authorized by Sutro) to obtain Extract Manufactured by the Alternate
Supplier up to the Capacity established pursuant to the Transfer Addendum for a period ending the
later of [***] or [***], and provided SutroVax commits to [***] or [***].

2.16 Other Extracts. From time-to-time, subject to an agreed-upon Work Order, SutroVax may place
purchase orders for quantities of research grade extract derived from strains of E. Coli other than
that set forth on Schedule 1 attached hereto (each an "Other Extract"). Sutro shall use Commercially
Reasonable Efforts to accept such purchase orders (and shall accept such purchase orders placed
consistent with an agreed-upon Work Order) and manufacture and supply to SutroVax such Other
Extracts. For the purpose of calculating the Price for Other Extracts in accordance with this
Section, the Price will be the cost of materials and Sutro's labor at an FTE rate of [***] per year
for Sutro laboratory scientists. Upon Sutro's acceptance of a purchase order for Other Extract, such
Other Extract in such purchase order shall be deemed Extract for purposes of Sections 2.1, 2.2, 2.3,
2.4.1 (solely with respect to the last two sentences thereof), 2.5, 2.6, 2.7, 2.8, 2.9.1 , 3.1, 4,
5, 6, 7 and 9.

2.17 Manufacture of Custom Reagents. For clarity, SutroVax may Manufacture Custom Reagents itself or
obtain supply thereof through a Third Party independent of this Supply Agreement and nothing in this
Supply Agreement is intended to restrict SutroVax from doing so. Upon SutroVax's request, and
subject to the remainder of the terms of this Section 2.17, Sutro shall (a) transfer to SutroVax or
a contract manufacturer designated by SutroVax (which contract manufacturer is reasonably acceptable
to Sutro, the approval of which shall not be unreasonably withheld, conditions or delayed by Sutro)
as soon as reasonably practicable the process to Manufacture each Custom Reagent and the items of
Sutro Know-How reasonably necessary for SutroVax or its designee to Manufacture each Custom Reagent,
including cell lines, standard operating procedures, protocols, batch records, analytical method
standard operating procedures and analytical method transfer protocols and (b) make Sutro Personnel
reasonably available to SutroVax or its designee for scientific and technical explanations and
on-site support that may reasonably be requested by SutroVax or its designee to Manufacture the
Custom Reagents; provided however, that SutroVax shall fully reimburse Sutro for all documented time
spent by Sutro's personnel to perform such transfer (on an FTE basis, each such FTE charged at an
annual rate of [***]) and out-of-pocket costs incurred by Sutro in connection with all of the
activities under the preceding sub-clauses (a) and (b), in accordance with a budget reasonably
approved in advance by SutroVax. Upon such SutroVax request, Sutro and SutroVax shall, within [***]
days, agree on a scope of work for such transfer, including
<!-- page 13 -->
scale, timeline, estimated budget, and required materials; both parties shall use reasonable efforts
to complete the transfer as soon as reasonably practical. If requested by SutroVax (including if
such request is prior to agreement on a scope of work), Sutro shall promptly transfer to SutroVax or
its designee the cell lines, manufacturing instructions and analytical methods used for Manufacture
of each Custom Reagent. For clarity, SutroVax shall have the right to enter into an agreement
directly with such designee for the Manufacture and supply of Custom Reagents directly to SutroVax,
its Affiliates, and any SutroVax CMO and, upon SutroVax's request, to the extent necessary, Sutro
shall authorize such designee to enter into such agreement with SutroVax and perform such
activities. For further clarity, Sutro shall not be responsible for any damages resulting from delay
or failure in establishing the processes for Manufacture of Custom Reagents at SutroVax's designee
resulting from action or inaction on the part of the designee or to the extent beyond Sutro's
control. SutroVax shall have the right to obtain from such designee such items of Sutro Know-How
transferred to such designee and use such items in connection with the exercise of its rights
pursuant to the License Agreement, including for the Manufacture of Custom Reagents and the
management of such designee. SutroVax shall use such Sutro Know-How transferred under this Section
2.17 (to the extent it is Discloser's Information of Sutro and does not meet one or more the
criteria in clause (a) through (e) of Section 10.1 of the License Agreement) only for the
Manufacture of Custom Reagents or otherwise within the scope of rights and licenses granted SutroVax
in the License Agreement. In case of such a transfer to SutroVax or its designee, SutroVax will
share with Sutro (i) the proposed process for manufacture of Custom Reagents through a Third Party
so that Sutro may provide feedback and ensure that the process and Specifications are consistent
with Sutro's process, and (ii) all regulatory submissions (including DMFs with respect to Custom
Reagents) at least [***] days in advance of their intended date of submission to a Regulatory
Authority in the Territory, and shall take into account Sutro's feedback to ensure alignment with
Sutro's regulatory submissions and Regulatory Approvals with respect to Custom Reagents. Following
completion of the transfer set forth above, Sutro shall provide reasonable support for the use of
Third Party Custom Reagents in conjunction with Extract supplied by or on behalf of Sutro. In
addition, Extract supplied by Sutro that conforms to the Required Standards when tested with Custom
Reagents supplied by Sutro but not with Custom Reagents manufactured under this Section shall be
deemed to conform to the Required Standards and SutroVax may not reject such Extract as a result of
such non-conformance to the Required Standards when tested with Custom Reagents. SutroVax shall not
prevent Sutro from separately contracting with the contract manufacturer for Manufacture of Custom
Reagents for use on its own behalf or on behalf of other third parties.

2.18 Sutro Core Know-How. Notwithstanding anything to the contrary, except as set forth in Section
15.3 of the License Agreement, in no event shall SutroVax, its Affiliates or Sublicensees have the
right to access any Sutro Core Know-How (as defined in the License Agreement), whether directly from
Sutro or its Affiliates or through a CMO or otherwise, and SutroVax, its Affiliates and Sublicensees
shall not require, request or solicit any CMO to deliver any Sutro Core Know-How to SutroVax, its
Affiliates and/or its Sublicensees, and no agreement between any CMO and Sutro, its Affiliates and
Subsidiaries shall contain any provision granting to SutroVax or its Affiliates or Sublicensees any
right to obtain or use any Sutro Core Know-How. Without limiting the foregoing, in the event any
item of Sutro Core Know-How is delivered to SutroVax, its Affiliates and/or its Sublicensees (except
as set forth in Section 15.3 of the License Agreement), SutroVax, its Affiliates and Sublicensees
shall immediately return such item to Sutro. Notwithstanding the foregoing, to the extent SutroVax
or any of its Affiliates
<!-- page 14 -->
or Sublicensees is required by a Regulatory Authority (or Applicable Law) in the United States,
Europe or Japan to confidentially disclose, as part of the applicable regulatory filings with
respect to a Vaccine Composition, any Sutro Core Know-How (for clarity, excluding any tangible
embodiments of such Sutro Core Know-How other than information and documentation), Sutro shall, upon
SutroVax's written request, confidentially disclose such Sutro Core Know-How as part of the
applicable regulatory filings, subject to the payment obligations set forth in Section 5.4 of the
License Agreement.

2.19 Express Rights. Except as expressly set forth in this Supply Agreement, no rights or licenses
are granted to SutroVax under this Supply Agreement.

2.20 Extract Requirements. SutroVax agrees to purchase all its requirements of Extract from Sutro in
accordance with this Agreement, except to the extent SutroVax is allowed to purchase Extract from
(a) Alternate Suppliers engaged by Sutro in accordance with Section 2.15 of this Agreement; (b) a
CMO engaged or established and authorized by Sutro under Section 3.l(d) of the License Agreement; or
(c) a CMO authorized by Sutro under Section 3.l(e) of the License Agreement. Manufacturing of
Extracts in breach of this Section 2.20 shall be deemed a material breach of this Agreement and the
License Agreement by SutroVax.

ARTICLE 3 PRICING AND PAYMENT

3.1 Invoices. Sutro shall invoice SutroVax at the time of each shipment of Product(s) for the Price
for such shipment. SutroVax will pay such invoices within [***] days of receipt of invoice
(including all required documentation) by SutroVax.

3.2 Prices. The Prices for the Products shall not exceed [***] of the Fully Burdened Manufacturing
Costs of such Product at the time such Product is manufactured and shall be set forth in the
applicable Work Order. Upon SutroVax's request from time-to-time, Sutro shall disclose to SutroVax
the then- current Price for Product. The Price for the Products as of the Effective Date is set
forth in Schedule 1.

3.3 Recordkeeping. During the Term and for [***] years thereafter, or for such longer period as may
be required by Applicable Law, Sutro shall prepare and retain, and shall cause its subcontractors to
prepare and retain, accurate books and records related to transactions made pursuant to this Supply
Agreement and Prices. Such records shall be made available for reasonable review, audit and
inspection upon reasonable notice and with reasonable frequency, upon SutroVax's request for the
purpose of verifying Sutro's calculations of amounts due hereunder, the basis for such calculations
(including Sutro's calculation of the Fully Burdened Manufacturing Costs) or payments and Sutro's
compliance with the terms and conditions of this Supply Agreement. Audits and inspections may be
conducted by SutroVax's own personnel or retained consultant(s), subject to the confidentiality
obligations set forth in this Supply Agreement.

3.4 Taxes. The Prices are exclusive of all Taxes. SutroVax will pay all taxes and duties that are
assessed by any national, federal, state or local governmental authority on SutroVax's purchase or
use of the Products, including, without limitation, sales, use, excise, value-added and withholding
taxes, but excluding any taxes based on Sutro's income or gross receipts (collectively, "Taxes").
Sutro will separately identify all such Taxes on Sutro's invoice.
<!-- page 15 -->
ARTICLE 4 PRODUCT TESTING

4.1 Product Testing and Inspections. Each shipment of Product shall be accompanied by a certificate
of analysis describing all current requirements of the Specifications and results of tests performed
on such Product and a certificate of conformity certifying that the quantities of Product supplied
have been Manufactured, controlled and released according to the Required Standards ("COA/COC") as
set forth in the applicable Quality Agreement (subject to SutroVax's conduct of the SutroVax
Activity Test to confirm Extract meets the SutroVax Activity Criteria). The COA/COC acceptance
criteria for each Product shall be set forth in the Specification for such Product. Two of the tests
and corresponding COA/COC acceptance criteria for the Extract shall be the performance of a
productivity (Activity) test of the applicable Sutro protein (the "Sutro Activity Test" and "Sutro
Activity Criteria") and the performance of a productivity (activity) test of the applicable Vaccine
Composition (the "SutroVax Activity Test" and "SutroVax Activity Criteria"). Sutro shall perform the
Sutro Activity Test to confirm that all shipments of Extract meet the Sutro Activity Criteria and
SutroVax (or its designee) shall perform the SutroVax Activity Test to confirm that all shipments of
Extract meet the SutroVax Activity Criteria. Sutro will also provide SutroVax with Material Safety
Data Sheets ("MSDS") or an equivalent instrument recognized by the applicable Regulatory Authority
as required for the Product(s), and updates of the same as necessary.

4.2 Acceptance/Rejection of Non-Conforming Goods. SutroVax or its designee shall have a period of
[***] calendar days from the date of delivery of the Product(s) in accordance with Section 2.6 and
the COA/COCs or the equivalent instrument recognized by the applicable Regulatory Authority for such
Product(s) ("Acceptance Period"), to inspect any shipment of Product(s) and conduct the SutroVax
Activity Test to determine whether such shipment conforms to the Required Standards. If SutroVax
determines that the Product(s) do not conform to the Required Standards, it hall notify Sutro within
the Acceptance Period, and, if requested by Sutro, SutroVax shall ship a sample of such
non-conforming Product(s) to Sutro at Sutro's expense. SutroVax's failure to notify Sutro of the
non-conformity within the Acceptance Period will be deemed for purposes of this Supply Agreement to
constitute SutroVax's acceptance of such shipment, provided, however, that such acceptance shall be
subject to SutroVax's right to reject Product(s) until [***] days from the delivery date of the
applicable Product, in each case, due to discovery by SutroVax or SutroVax's Affiliates or designees
that the applicable Product does not conform to the Required Standards and such non-conformance
could not reasonably be discovered within the Acceptance Period ("Latent Defects") provided that
SutroVax gives Sutro with written notice of such Latent Defect within [***] days of SutroVax or any
SutroVax Affiliate or designee becoming aware of such defect.

4.3 Disputes Regarding Conformance to Required Standards. If Sutro does not agree with SutroVax's
determination that Product fails to conform to the Required Standards, then Sutro shall so notify
SutroVax in writing within [***] days of its receipt of SutroVax's notice of non-conformity with
respect to such Product and (if requested) Product sample. Sutro and SutroVax shall use reasonable
efforts to resolve such disagreement as promptly as possible.
<!-- page 16 -->
Without limiting the foregoing, Sutro and SutroVax shall discuss in good faith mutually acceptable
testing procedures pursuant to which both Sutro and SutroVax will re-test a sample of the disputed
Product to determine whether such Product meets the Required Standards. Notwithstanding the
foregoing, in the event that Sutro and SutroVax are unable to resolve such disagreement within [***]
days of the date of the applicable rejection notice, either Party may submit a sample of the
allegedly non-conforming Product for testing and a determination as to whether or not such Product
conforms to the Required Standards to an independent testing organization, or to a consultant of
recognized repute within the United States pharmaceutical industry, in either case mutually agreed
upon by the Parties (such organization or consultant, the "Laboratory"), the appointment of which
shall not be unreasonably withheld or delayed by either Party. The determination of the Laboratory
with respect to all or part of any shipment of Product shall be final and binding upon the Parties.
The fees and expenses of the Laboratory making such determination shall be borne by Sutro, in the
event that the Laboratory determines that the Product was non-conforming and by SutroVax, in the
event that the Laboratory determines that the Product did conform to the Required Standards.

4.4 Return and Replacement of Non-Conforming Goods. Product that is either rejected by SutroVax as
not meeting the Required Standards, or that is determined by the Laboratory not to meet such
Required Standards, shall, [***], be returned by SutroVax to Sutro, or destroyed pursuant to
Applicable Law, at Sutro's reasonable expense. Sutro shall replace any non-conforming Product(s)
within the shortest possible time. SutroVax shall have no responsibility to Sutro for the amounts
invoiced for non-conforming Product(s), and shall be credited for any amounts paid, but shall pay
Sutro the applicable Price for the replacement Product(s) under the terms of Section 3.1.

ARTICLE 5 INSPECTION

5.1 Right to Audit. During the Term and the [***] period thereafter, SutroVax or a SutroVax
Affiliate may, during normal working hours and upon reasonable advance notice perform site audits
and inspect, or request information relating to, Sutro's or its subcontractor's Facilities and
records directly or indirectly involved in the performance of this Supply Agreement or related to
the Product(s). Such requests should be made in writing and Sutro will allow for such audits or
inspection to occur within [***] days from request (excepting for cause audits) for Sutro's
Facilities and within [***] days' from request (excepting for cause audits) for Sutro's
subcontractor's facilities. Reasonable advance notice for audits for cause shall not require more
than [***] advance notice. During such an inspection or request for information the inspectors may
inquire about the progress of the work being carried out by Sutro or its subcontractor, and are in
particular but not exclusively authorized to:

5.1.1 Inspect the Facilities, documents and equipment used, or to be used, in the Manufacture of the
Product(s);

5.1.2 Verify the qualifications of the employees and subcontractors carrying out such work and their
use of the relevant equipment;
<!-- page 17 -->
5.1.3 Evaluate all scientific techniques used by Sutro, its subcontractors and their respective
employees in the performance of this Supply Agreement and the procedures used in the creation and
storage of samples of the Product(s), provided that nothing in this Section 5.1.3 shall require
Sutroto disclose any Sutro Core Know-How;

5.1.4 Verify and evaluate information relating to the utilization of the Manufacturing capacity of
Sutro's Facilities or its subcontractor's Facilities;

5.1.5 Review correspondence, reports, filings and other documents from Regulatory Authorities to the
extent related to the Manufacturing activities hereunder;

5.1.6 Evaluate the implementation of all Manufacturing and process changes made with respect to the
Product, including pursuant to any corrective action plan; and

5.1.7 Ascertain compliance with Applicable Laws, the Specifications and this Supply Agreement.

5.2 Access. Sutro shall provide SutroVax's and its Affiliate's and Sublicensee's inspectors with
access to its Facilities, and information related to such Facilities, in order that the inspectors
may carry out the inspections or inquiries referred to in the provisions of this Article 5. For the
avoidance of doubt, neither SutroVax nor any of its Affiliates or Sublicensees (or their respective
inspectors) shall have the right to observe the Manufacture of the Extract or be present at Sutro
and its subcontractors' Facilities at such times when Extract is being Manufactured. Sutro shall use
Commercially Reasonable Efforts to obtain from its subcontractors commitments similar to those
contemplated in this Section 5.2. Audits and inspections may be conducted by SutroVax's own
personnel or retained consultant(s), subject to the confidentiality obligations set forth in this
Supply Agreement.

5.3 Sutro Audits. Without limiting the foregoing; Sutro is responsible for auditing the facilities
of the suppliers of Components, if any, periodically, and Sutro agrees to provide SutroVax, upon
SutroVax's request with a current copy of the audit report of such facilities and to incorporate
SutroVax's comments with respect to any corrective action plan related to the Product.

ARTICLE 6 REGULATORY AND QUALITY RESPONSIBILITIES

6.1 Regulatory Responsibilities. Sutro shall obtain and maintain any and all regulatory and
governmental permits, licenses and approvals that are necessary for Sutro to Manufacture the
Product(s) for SutroVax or its Affiliates in accordance with the terms of this Supply Agreement and
Applicable Law. As between the Parties, SutroVax shall have the sole responsibility for all
Regulatory Approvals of the Vaccine Compositions.

6.2 Right of Reference; Drug Master Files. Sutro shall (a) file Drug Master File(s) for the Products
with the FDA as requested by SutroVax, and with Regulatory Authorities in the European Union
(including the United Kingdom) and Japan in accordance with timelines to be mutually agreed upon
(such agreement not to be unreasonably withheld by either Party) (provided at SutroVax's request,
Sutro shall do so within [***] of SutroVax's request using
<!-- page 18 -->
Regulatory Filings that comprise versions of the DMF(s) filed with the FDA that have been
reformatted to comply with EU and Japanese requirements), and (b) provide the appropriate
authorizations to such Regulatory Authority(ies) allowing the Regulatory Authority the right to
review and SutroVax or its designee to reference such Drug Master File(s) in support of (and other
Regulatory Materials, to the extent necessary to support) an application for Regulatory Approval
submitted by SutroVax (or its permitted designee) for any Vaccine Composition produced using the
Product the subject of the applicable Drug Master File (it being understood that SutroVax, its
Affiliates· and Sublicensees shall not have access to the information contained in such Drug Master
Files (or other confidential Regulatory Materials submitted for a similar purpose as a Drug Master
File (e.g., a clinical trial application for such purpose in the European Union)) as a result of
such authorization and right to reference). Sutro shall file such Drug Master File in coordination
with SutroVax's efforts to file and prosecute the applicable regulatory filings to such Regulatory
Authority and Sutro shall be responsible, at SutroVax's sole expense (subject to a budget reasonably
approved in advance by SutroVax), for providing the applicable Regulatory Authorities with such
additional data as they may request (which may in some cases require Sutro to conduct additional
studies), and for correcting any deficiencies of such Drug Master File identified by such Regulatory
Authority, in each case in a reasonably prompt and efficient manner so as to prevent any delay in
obtaining Regulatory Approvals for any Vaccine Composition based on such Drug Master File. In
addition, Sutro shall be responsible for maintaining such Drug Master File in accordance with
applicable Laws as necessary to support filing and prosecuting the applicable regulatory filing(s)
and obtaining and maintaining the applicable Regulatory Approval(s) for Vaccine Compositions
produced using the Products. For further clarity, to the extent Sutro discloses. Sutro Know- How to
SutroVax, SutroVax shall have the right to include (and authorize the inclusion of) such Sutro
Know-How in Regulatory Materials to the extent it is necessary or useful for the purpose of
obtaining Regulatory Approval of a Vaccine Composition. Sutro's obligations under this Section 6.2
shall [***]. Sutro shall cause its personnel to record time spent performing such activities to a
job code specific to such activities. For purposes of this Article 6 "Drug Master File" or "DMF"
means a submission to a Regulatory Authority of information concerning the chemistry, manufacturing
and controls ("CMC") of the Products to permit such Regulatory Authority to review this information
in support of any application for Regulatory Approval for a product submitted by a party that has
been granted a right to reference such submission without disclosing the contents of such submission
to such party. Sutro shall file DMF(s) for the Products with other Regulatory Authorities in the
Territory in accordance with the terms and conditions of the Phase 3/Commercial Supply Agreement
referenced in Section 2.14 (and, for clarity, shall file DMF(s) for the Products with Regulatory
Authorities in the European Union (including the United Kingdom) and Japan as necessary to comply
with the requirements of such Regulatory Authorities, to the extent not filed under this Supply
Agreement).

6.2.1 Compliance. Subject to the foregoing, Sutro shall provide the information set forth under this
Section 6.2 in a timely manner and compliant with the reporting requirements of the Regulatory
Authorities.
<!-- page 19 -->
6.2.2 Safety Data. Each Party understands and acknowledges that the other Party and its Affiliates
and respective licensees or sublicensees may need to access and utilize and include certain safety
data (e.g., adverse event reports) pertaining to product made using Products that is generated or
received by such Party and its Affiliates and respective licensees or sublicensees in its Regulatory
Materials in its respective Territory as required by applicable Laws. Each Party shall have the
right to share any and all such safety data generated by the other Party or the other Party's
Affiliates or licensees or sublicensees with its Affiliates and Third Parties (including its
licensees and sublicensees) as permitted under section 10.2 of the License Agreement.

6.2.3 Cooperation. Each Party agrees to (i) make its personnel reasonably available at their
respective places of employment to consult with the other Party on issues related to the activities
conducted in accordance with this Article 6 or otherwise relating to the development of the Products
or Vaccine Compositions and thereafter in connection with any request from any Regulatory Authority,
including with respect to regulatory, scientific, technical and clinical testing issues, or
otherwise, throughout the Term, and (ii) otherwise provide such assistance as may be reasonably
requested by the other from time-to-time in connection with the activities to be conducted under
this Article 6 or otherwise relating to the development of the Vaccine Compositions or Products.

6.3 Recalls. Each of SutroVax and Sutro will immediately inform the other in writing if it believes
one or more lots of any Product(s), or any products made by Sutro or its licensees using the
Products (to the extent such products are made using Products from the same batch provided to
SutroVax), or any Vaccine Compositions should be subject to recall from distribution, withdrawal or
some other field action, or that potential adulteration, misbranding, and/or other issues have
arisen that relate to the safety or efficacy of such Product. SutroVax shall have the final
decision-making authority as to any such recall or field action and the sole right to initiate any
such recall or field action with respect to Vaccine Compositions made using the Products. Sutro
shall cooperate in the conduct of any recall or field action with respect to the Vaccine
Compositions as reasonably requested by SutroVax. In the event it is determined that such a recall
resulted from a breach by either Party of any of its representations, warranties, duties or
obligations under this Supply Agreement, such Party shall be responsible for the costs of the recall
and shall reimburse the other Party as necessary; provided that if both Parties share responsibility
with respect to such recall, the costs shall be shared in the ratio of the Parties' contributory
responsibility.

6.4 Retention of Samples. Sutro shall prepare and retain, and shall cause its subcontractors to
prepare and retain, such samples and records in respect of the Product(s) and the Manufacture
thereof as are required by Applicable Law (including, as applicable, cGMPs).

6.5 Regulatory Authority Inspections and Correspondence. Sutro shall permit Regulatory Authorities
to conduct such inspections of any Facility at which any of the Manufacturing activities relating to
the Product(s) are performed, as such Regulatory Authorities may request, including pre-approval
inspections,· and shall cooperate with such Regulatory Authorities with respect to such inspections
and any related matters, in each case that is related to the Manufacture of Product(s). Sutro shall
give SutroVax or its Affiliates prior written notice of any such inspections, and shall keep
SutroVax informed about the results and conclusions of each such regulatory inspection, including
actions taken by Sutro to remedy conditions cited in such inspections. Sutro shall provide SutroVax
with copies of any written inspection reports issued by anyRegulatory Authority and all
correspondence between Sutro and any Regulatory Authority with respect thereto, including any
notices of observation and all related
<!-- page 20 -->
correspondence, in each case relating to the Product(s) or its Manufacture or to general
manufacturing concerns (e.g., facility compliance or the like) that are reasonably likely to impact
the Product(s) to the extent such general manufacturing matters would be reasonably expected to have
a material effect on the manufacture of Vaccine Compositions; provided that Sutro may redact from
any such report and correspondence any Sutro Core Know-How and any information subject to an
obligation of confidentiality to a Third Party. In addition, Sutro agrees to promptly notify and
provide SutroVax copies of any material request, directive, or other written communication to or
from Regulatory Authorities related to the Product or its Manufacture that would reasonably be
expected to have a material effect on the manufacture of Vaccine Compositions (it being understood
that SutroVax, its Affiliates and Sublicensees shall not have access to Sutro Core Know How (which
Sutro may redact from such reports or correspondence provided to SutroVax) or Sutro's Drug Master
Files or other confidential Regulatory Materials submitted for a similar purpose as a Drug Master
File). Sutro shall provide SutroVax with a copy of the applicable portion of any correspondence made
by Sutro to a Regulatory Authority for review and comment prior to submission to the applicable
Regulatory Authority solely to the extent such correspondence made by Sutro is related to SutroVax
or is in response to a request, directive or correspondence from the applicable Regulatory Authority
regarding SutroVax or a Vaccine Composition (e.g., in response to a report regarding a pre- approval
inspection for SutroVax). Sutro will consider in good faith any comments received from SutroVax
within the time period indicated by Sutro (which shall not be less than [***], to the extent
consistent with the require timeline for Sutro's response) with respect to any matter that relates
to SutroVax. In addition, Sutro shall notify SutroVax of any occurrences or information that arise
out of Sutro's Manufacturing activities that have, or could reasonably be expected to have, adverse
regulatory compliance or reporting consequences concerning any Product(s) or which might otherwise
be reasonably expected to adversely affect the supply by Sutro of Product(s) to SutroVax.

6.6 Changes or Modifications in Manufacturing Activities. Sutro shall not make any changes to the
Specifications, processes, Facilities, raw materials, raw material suppliers or any other item that
would affect the Manufacturing activities related to the Product (a "Manufacturing Change") that (a)
would require a change to the applicable Drug Master File, (b) would be reasonably expected to cause
SutroVax to be materially delayed obtaining any Regulatory Approval with respect to Vaccine
Compositions or (c) causes the Product to not meet the Specification therefor (including the
Activity Test with respect to Extract); without SutroVax's prior written consent (not to be
unreasonably withheld, conditioned or delated). Notwithstanding the foregoing, Sutro shall promptly
make and implement such changes as are required by Applicable Law provided that, prior to
implementation, Sutro shall provide notice thereof to SutroVax and confer with SutroVax with respect
to its timelines, estimated effect on Price and other issues regarding such implementation. Sutro
shall provide SutroVax at least [***] days' written notice prior to implementing any Manufacturing
Change. Sutro shall not make any change to the Specification for a Product without SutroVax's prior
written consent. In addition, SutroVax shall have the right to request changes in or modifications
to the Specifications and Sutro will consider in good faith any such requested changes or
modifications. All such changes or modifications shall be documented in writing and shall be signed
by an authorized representative of SutroVax and Sutro. If such changes or modifications result in a
material change in Sutro's Manufacturing costs or lead times, the Parties shall agree upon an
appropriate adjustment to the Price or in the delivery schedules, as the case may be, for Product(s)
to be provided by Sutro hereunder. Sutro shall promptly implement any agreed upon changes to the
Specifications.
<!-- page 21 -->
6.7 Quality Agreement. As soon as reasonably practicable after the Effective Date, the Parties shall
enter into a quality agreement governing Sutro's supply of Products (the "Quality Agreement"), which
Quality Agreement shall include the Specifications for the Product(s) consistent with the
Specifications set forth in Schedule 2. Accordingly, to permit the Quality Agreement to be finalized
within such period, Sutro shall provide SutroVax or its designee access to Sutro's Facilities and
records to enable SutroVax or its designee to complete an audit pursuant to Section 5.1 within [***]
days after the Effective Date.

ARTICLE 7 REPRESENTATION AND WARRANTIES

7.1 SutroVax Warranties and Representations. SutroVax represents and warrants the following:

7.1.1 SutroVax is a corporation duly organized, validly existing and in good standing under the laws
of the State of Delaware.

7.1.2 SutroVax has all requisite power and authority to enter into this Supply Agreement. The person
signing this Supply Agreement has the necessary corporate authority to legally bind SutroVax to the
terms set forth herein.

7.1.3 SutroVax's execution of this Supply Agreement and performance of the terms set forth herein
will not cause SutroVax to be in conflict with or constitute a breach of its organizational
documents nor any other agreement, court order, consent decree or other arrangement, whether written
or oral, by which it is bound.

7.1.4 SutroVax's execution of this Supply Agreement and performance hereunder are in, and will be
in, compliance with any Applicable Law in all material respects.

7.1.5 This Supply Agreement is its legal, valid and binding obligation, enforceable against SutroVax
in accordance with the terms and conditions hereof, except as such enforceability may be limited by
applicable bankruptcy, insolvency, reorganization, moratorium or similar laws affecting creditors'
rights generally or by the principles governing the availability of equitable remedies.

7.2 Sutro Warranties and Representations. Sutro represents and warrants the following:

7.2.1 Sutro is a corporation duly organized, validly existing and in good standing under the laws of
the State of Delaware.

7.2.2 Sutro has all requisite power and authority to enter into this Supply Agreement and has the
requisite skill, knowledge, staffing, financial resources, capacity and ability to carry out its
obligations hereunder. The person signing this Supply Agreement has the necessary authority to
legally bind Sutro to the terms set forth herein.
<!-- page 22 -->
7.2.3 Sutro's execution of this Supply Agreement and performance of the terms set forth herein will
not cause Sutro to be in conflict with or constitute a breach of its organizational documents nor
any other agreement, court order, consent decree or other arrangement, whether written or oral, by
which it is bound.

7.2.4 Sutro's execution of this Supply Agreement and performance hereunder are in, and will be in,
compliance with any Applicable Law in all material respects.

7.2.5 Sutro has and will maintain throughout the Term all permits, licenses, registrations and other
forms of governmental authorization. and approval as required by Applicable Law in order for Sutro
to execute and deliver this Supply Agreement and to perform its obligations hereunder in accordance
with all Applicable Law.

7.2.6 as of the Effective Date, to the best of Sutro's knowledge, the practice of the Sutro
Platform, including the use of the Products, does not infringe any Third Party patents.

7.2.7 7.2.7 Sutro is not debarred and Sutro has not and will not use in any capacity the services of
any person debarred under subsection 306(a) or (b) of the U.S. Generic Drug Enforcement Act of 1992,
or other Applicable Law, nor have debarment proceedings against Sutro or any of its employees or
permitted subcontractors been commenced.

7.2.8 This Supply Agreement is its legal, valid and binding obligation, enforceable against Sutro in
accordance with the terms and conditions hereof, except as such enforceability may be limited by
applicable bankruptcy, insolvency, reorganization, moratorium or similar laws affecting creditors'
rights generally or by the principles governing the availability of equitable remedies.

7.2.9 As of the Effective Date, there are no claims, judgments or settlements against or owed by
Sutro or its Affiliates, or pending or, to the best of Sutro's knowledge, threatened claims or
litigation, relating to the Product(s).

7.3 Product Warranties. Sutro represents and warrants that:

7.3.1 Sutro's Facility and all Product (as delivered in accordance with Section 2.1 and until the
expiration date thereof) supplied hereunder (and the Manufacture thereof) shall comply with this
Supply Agreement, all Applicable Law (including cGMPs, if applicable),·be free from defects in
material and workmanship, and meet all Specifications.

7.3.2 Title to all Product(s) provided under this Supply Agreement shall pass to SutroVax as set
forth in Section 2.6, free and clear of any security interest, lien, or other encumbrance.

7.4 Disclaimer. EACH PARTY AGREES AND ACKNOWLEDGES THAT, EXCEPT AS SET FORTH IN THIS ARTICLE 7,
NEITHER PARTY MAKES ANY REPRESENTATIONS OR WARRANTIES OF ANY KIND WHATSOEVER, IMPLIED OR STATUTORY,
AND EACH PARTY HEREBY EXPRESSLY DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES, IMPLIED OR STATUTORY,
INCLUDING ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AGAINST
NON-INFRINGEMENT OR THE LIKE, OR ARISING FROM COURSE OF PERFORMANCE.
<!-- page 23 -->
ARTICLE 8 CONFIDENTIALITY

8.1 Article 10 of the License Agreement (Confidentiality) is hereby incorporated into this Supply
Agreement by reference. The terms and provisions of this Supply Agreement (which shall be the
Discloser's Information of both Parties) and all other information and data, including all notes,
books, papers, diagrams, documents, reports, e-mail, memoranda, visual observations, oral
communications and all other data or information in whatever form, that one Party or any of its
Affiliates or representatives supplies or otherwise makes available to the other Party or its
Affiliates or representatives pursuant to this Supply Agreement shall be deemed Discloser's
Information pursuant to Article 10 of the License Agreement.

ARTICLE 9 INDEMNIFICATION AND INSURANCE

9.1 Indemnification.

9.1.1 Indemnification by Sutro. Sutro hereby agrees, at its sole cost and expense, to defend, hold
harmless and indemnify, to the extent permitted by Applicable Law, (collectively, "Indemnify")
SutroVax and its Affiliates and their respective agents, directors, officers and employees of such
Persons and the respective successors and assigns of any of the foregoing (the "SutroVax
Indemnitees") from and against any and all liabilities, damages, penalties, fines, costs and
expenses (including, reasonable attorneys' fees and other expenses of litigation) (collectively,
"Liabilities") resulting from suits, claims, actions and demands, in each case brought by a Third
Party (each, a "Third-Party Claim") against any SutroVax Indemnitee and arising from or occurring as
a result of: [***]. Sutro's obligation to Indemnify the SutroVax Indemnitees pursuant to this
Section 9.1.1 shall not apply to the extent that any such Liabilities are the result of a material
breach by SutroVax of its obligations, representations, warranties or covenants under this Supply
Agreement or the License Agreement or any SutroVax Indemnitee' s negligence or willful misconduct.

9.1.2 Indemnification by SutroVax. SutroVax hereby agrees to Indemnify Sutro and its agents,
directors, officers and employees and the respective successors and assigns of any of the foregoing
(the "Sutro lndemnitees") from and against any and all Liabilities resulting from Third-Party Claims
against any Sutro Indemnitee arising from or occurring as a result of: [***]. SutroVax's obligation
to Indemnify the Sutro Indemnitees pursuant to this Section 9.1.2 shall not apply to the extent that
any such Liabilities are the result of a material breach by Sutro of its obligations,
representations, warranties or covenants under this Supply Agreement or the License Agreement or any
Sutro Indemnitee's negligence or willful misconduct.
<!-- page 24 -->
9.1.3 Procedure. To be eligible to be Indemnified hereunder, the indemnified Person shall provide
the indemnifying Party with prompt written notice of the Third-Party Claim giving rise to the
indemnification obligation pursuant to this Section 9.1 and the right to control the defense (with
the reasonable cooperation of the indemnified Person) or settlement any such claim; provided,
however, that the indemnifying Party shall not enter into any settlement that admits fault,
wrongdoing or damages without the indemnified Person's written consent, such consent not to be
unreasonably withheld or delayed. The indemnified Person shall have the right to join, but not to
control, at its own expense and with counsel of its choice, the defense of any claim or suit that
has been assumed by the indemnifying Party.

9.2 Insurance. Each Party shall procure and maintain insurance, including clinical trials and
product liability insurance, adequate to cover its obligations hereunder and consistent with normal
business practices of prudent companies similarly situated at all times during which any Product or
Vaccine Compositions is being clinically tested in human subjects or commercially distributed or
sold by such Party. It is understood that such insurance shall not be construed to create a limit of
either Party's liability or indemnification obligations under this Article 9, or that the
maintenance of such insurance shall not be construed to relieve either Party of its other
obligations under this Supply Agreement. Each Party shall provide the other with written evidence of
such insurance upon request. Each Party shall provide the other with written notice at least [***]
days prior to the cancellation, non renewal or material change in such insurance.

9.3 LIMITATION OF LIABILITY. EXCEPT (I) WITH RESPECT TO ANY BREACH OF ARTICLE 8 (CONFIDENTIALITY),
(II) FOR THIRD PARTY PENALTIES, COSTS AND EXPENSES AS SET FORTH IN SECTION 2.9, OR (III) FOR [***],
TO THE MAXIMUM EXTENT PERMITTED BY LAW, (A) NEITHER PARTY SHALL BE LIABLE TO THE OTHER PARTY FOR ANY
INDIRECT, INCIDENTAL, CONSEQUENTIAL, SPECIAL OR PUNITIVE DAMAGES, WHETHER LIABILITY IS ASSERTED IN
CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY, OR ANY OTHER THEORY OR FORM OF ACTION, EVEN
IF SUCH PARTY HAS BEEN ADVISED OF THE POSSIBILITY THEREOF; AND (B) EACH PARTY'S TOTAL LIABILITY TO
THE OTHER PARTY UNDER THIS SUPPLY AGREEMENT SHALL NOT EXCEED [***]. SUTRO'S LIABITY TO SUTROVAX FOR
THIRD PARTY PENALTIES, COSTS AND EXPENSES UNDER SECTION 2.9 SHALL NOT EXCEED [***].

ARTICLE 10 TERM AND TERMINATION

10.1 Term. The term of this Supply Agreement shall begin on the Effective Date first set forth above
and shall remain in effect until the later of (a) July 31, 2021 or (b) the date that the Parties
enter into the Phase 3/Commercial Supply Agreement and Sutro is supplying to SutroVax each Product
under the Phase 3/Commercial Supply Agreement (the "Term"), unless it is terminated earlier in
accordance with Section 10.2.

10.2 Termination. Notwithstanding anything to the contrary in this Supply Agreement, this Supply
Agreement may be terminated:

10.2.1 in its entirety or with respect to one or more Products, on a Product-by-Product basis, by
mutual written consent of Sutro and SutroVax;
<!-- page 25 -->
10.2.2 in its entirety by a Party if the other Party materially breaches any of the material terms,
conditions or agreements contained in this Supply Agreement to be kept, observed or performed by the
other Party, by giving the Party who committed the breach [***] days' prior written notice, unless
the notified Party shall have cured the breach within such [***]-day period; and

10.2.3 in its entirety or with respect to one or more Products, on a Product-by-Product basis, by
SutroVax upon [***] days' prior written notice to Sutro for any reason.

10.3 Effects of Termination. Upon the expiration of the Term or termination of this Supply
Agreement, in its entirety or with respect to one or more Products, this Supply Agreement shall,
except as otherwise provided in this Section 10.3 or Section 10.5, be of no further force or effect;
provided, however, that (a) in the event this Supply Agreement is terminated by SutroVax pursuant to
Section 10.2.3 and there are outstanding Work Orders or other purchase orders accepted by Sutro that
would not be fulfilled as a result of such termination, SutroVax shall reimburse Sutro for all
supplies and materials purchased by Sutro and time incurred by Sutro personnel (to the extent
incurred solely for manufacture of Product for SutroVax) for the manufacture, or preparation for the
manufacture, of Products for any Work Orders placed by SutroVax and any other purchase orders
accepted by Sutro prior to such expiration or termination, in each case to the extent Sutro cannot
otherwise reasonably mitigate such the costs and expenses of such supplies, materials and time
(e.g., by use of resulting supplies, materials and work-in-progress Product for other purposes);
provided that to the extent SutroVax pays for any supplies or materials, upon SutroVax's request
Sutro shall promptly transfer and deliver such supplies and materials to SutroVax; and (b) if this
Supply Agreement is terminated with respect to one or more Products, but not all Products, then this
Supply Agreement shall continue in full force and effect with respect to the applicable Product(s)
for which it is not terminated.

10.4 Nonexclusive Remedy. Exercise of any right of termination afforded to either Party under this
Supply Agreement (i) shall not prejudice any other legal rights or remedies either Party have
against the other in respect of any breach of the terms and conditions of this Supply Agreement, and
(ii) shall be without any obligation or liability arising from such termination other than such
obligations expressly arising from termination of this Supply Agreement.

10.5 Survival. Expiration of the Term or termination of this Supply Agreement (for any reason) shall
not affect any accrued rights or liabilities of either Party. Article 4 (Product Testing), Article 5
(Inspection), Article 8 (Confidentiality), Article 9 (Indemnification and Insurance), Article 11
(Disputes), Article 12 (Miscellaneous), and Sections 2.2 (Transfer of Product), 2.14 (Phase
3/Commercial Supply Agreement), 2.15 (Qualification of Alternate Supplier), 2.17 (Manufacture of
Custom Reagents), 3.3 (Recordkeeping), 3.4 (Taxes), 6.2 (Right of Reference; Drug Master Files), 6.3
(Recalls), 6.4 (Retention of Samples), 6.5 Regulatory Authority Inspections and Correspondence), 7.3
(Product Warranties), 7.4 (Disclaimer), 10.3 (Effects of Termination), 10.4 (Nonexclusive Remedy),
and 10.5 (Survival) shall survive any expiration of the Term or termination of this Supply
Agreement.
<!-- page 26 -->
ARTICLE 11 DISPUTE RESOLUTION

11.1 Principal Contacts. Each Party will appoint an individual employed by it to serve as its
"Principal Contact" for purposes of this Supply Agreement. Either Party may from time to time
replace its Principal Contact with a different employee, but unless required due to events beyond
its control, neither Party will replace its Principal Contact without at least [***] days prior
notice to the other Party. The two Principal Contacts shall communicate with each other regularly
during the Term as the Parties may agree or as the Principal Contacts shall mutually determine to be
useful.

11.2 Escalation. The Parties intend that, to the maximum extent practicable, they shall reach
decisions hereunder cooperatively through discussions among the Principal Contacts and by mutual
consent of the Parties. In situations in which that does not occur, disputes or differences arising
out of or in connection with this Supply Agreement shall initially be referred for review by the
Parties' respective Senior Managements (as defined below). Such Senior Managements shall discuss the
proposed dispute or difference, and shall meet with respect thereto if either of them believes a
meeting or meetings are likely to be useful. If the Senior Managements do not resolve the dispute or
difference within [***] days (or such lesser or longer period as they may agree is a useful period
for their discussions), then either Party may pursue its other available remedies, consistent with
this Supply Agreement. As used herein, Sutro's "Senior Management" means its then-current CEO, and
SutroVax's "Senior Management" means its then-current CEO. For clarity, there shall be no obligation
for any Disputed Matter arising out of Section 2.14 or 2.15 to be referred to the Senior Management
to review prior to such matters being resolved by arbitration pursuant to Sections 11.3 and 11.4.

11.3 Arbitration. If the Senior Managements are not able to resolve such dispute referred to them
under Section 11.2 within such [***] day period, then such dispute shall be resolved by final and
binding arbitration as follows: The Parties shall select a mutually agreeable arbitrator who has
significant relevant experience in the subject matter of the disputed issue and no affiliation or
pre-existing relationship with either Party. If the Parties cannot agree on an arbitrator within
[***] days after the end of the [***] day period referred in Section 11.2 (or with respect to a
Disputed Matter described in Section 11.4, after referral by a Party of such Disputed Matter to
arbitration), either Party may request the Judicial and Mediation Services ("JAMS") in San
Francisco, CA to appoint an arbitrator on behalf of the Parties in accordance with the commercial
arbitration rules of JAMS, and the proceeding shall be conducted in accordance with JAMS rules. The
arbitrator may decide any issue as to whether, or as to the extent to which, any dispute is subject
to the arbitration and other dispute resolution provisions in this Supply Agreement. The arbitrator
must base the award on the provisions of this Supply Agreement and must render the award in a
writing which must include an explanation of the reasons for such award. Judgment upon the award
rendered by the arbitrator may be entered by any court having jurisdiction thereof. The arbitrator's
fees and expenses shall be shared equally by the Parties, unless the arbitrator in the award
assesses such fees and expenses against one of the Parties or allocates such fees and expenses other
than equally between the Parties. Each Party shall bear and pay its own expenses incurred in
connection with any dispute resolution under this Section 11.3. Notwithstanding the foregoing,
either Party shall have the right, without waiving any right or remedy available to such Party under
this Supply Agreement or otherwise, to seek and obtain from any court of competent jurisdiction any
interim or provisional relief that is necessary or desirable to protect the rights or property of
such Party, pending the selection of the arbitrator hereunder or pending the arbitrator's decision
of the dispute subject to arbitration.
<!-- page 27 -->
11.4 Baseball Arbitration. In the event (a) the Parties do not enter into a Phase 3/Commercial
Supply Agreement as described in Section 2.14 or (b) the Parties do not enter into a Transfer
Addendum as described in Section 2.15 ("Disputed Matter"), then upon either Party's request with
respect to the Disputed Matter in clause (a) or SutroVax's request with respect to the Disputed
Matter in clause (b), such Disputed Matter shall be resolved by binding arbitration conducted
pursuant to Section 11.3, except that the procedures for the conduct of such arbitration shall be as
follows:

11.4.1 Each Party shall provide the arbitrator and the other Party with a written report setting
forth its position with respect to the substance of such Disputed Matter and a full draft Phase
3/Commercial Supply Agreement or Transfer Addendum, as applicable, and may submit a revised report,
position and draft Phase 3/Commercial Supply Agreement or Transfer Addendum, as applicable, to the
arbitrator within [***] days of receiving the other Party's report and draft Phase 3/Commercial
Supply Agreement or Transfer Addendum, as applicable. If so requested by the arbitrator, each Party
shall make oral and/or other written submissions to the arbitrator in accordance with procedures to
be established by the arbitrator; provided that other Party shall have the right to be present
during any oral submissions. The arbitrator shall select one of the Party's draft Phase 3/Commercial
Supply Agreement or Transfer Addendum, as applicable, as his or her decision, based on what is most
reasonable and equitable to each of the Parties under the circumstances and reflective of reasonable
and customary terms in the biopharmaceutical industry for agreements of this type and most closely
reflects the Parties' intent as expressed in this Supply Agreement and the License Agreement, and
shall not have the authority to render any substantive decision other than to so select the draft
Phase 3/Commercial Supply Agreement or Transfer Addendum, as applicable, of Sutro or SutroVax (as
initially submitted, or as revised in accordance with the foregoing, as applicable). For clarity, it
is understood that the Parties intend the arbitration under this Section 11.4 to be a "baseball
arbitration" type proceeding; and the arbitrator may fashion such detailed procedures as the
arbitrator considers appropriate to implement this intent. Notwithstanding anything to the contrary,
in no event shall the Phase 3/Commercial Supply Agreement or Transfer Addendum contain any provision
granting to SutroVax or its Affiliates or Sublicensees any right to obtain or use any Sutro Core
Know-How.

11.4.2 In any arbitration under this Section 11.4, the arbitrator and the Parties shall use their
best efforts to resolve such Disputed Matter within [***] days after the selection of the
arbitrator, or as soon thereafter as is practicable.

ARTICLE 12 MISCELLANEOUS

12.1 Expenses. Except as otherwise expressly provided herein, each Party shall bear its own costs,
fees and expenses incurred by such Party in connection with this Supply Agreement.

12.2 Licenses and Permits. Each Party shall, at its sole cost and expense, maintain in full force
and affect all necessary licenses, permits, and other authorizations required by Applicable Law in
order to carry out its duties and obligations hereunder.
<!-- page 28 -->
12.3 Force Majeure. No Party shall be liable for a failure or delay in performing any of its
obligations under this Supply Agreement if, but only to the extent that such failure or delay is due
to causes beyond the reasonable control of the affected Party, including: (a) acts of God; (b) fire,
explosion, or unusually severe weather; (c) war, invasion, riot, terrorism, or other civil unrest;
(d) governmental laws, orders, restrictions, actions, embargo or blockages; (e) national or regional
emergency; (f) strikes or industrial disputes at a national level which directly impact the affected
Party's performance under this Supply Agreement; or (g) other similar cause outside of the
reasonable control of such Party ("Force Majeure"); provided that the Party affected shall promptly
notify the other of the Force Majeure condition and shall use reasonable efforts to eliminate, cure
or overcome any such causes and resume performance of its obligations as soon as possible. If the
performance of any obligation of a Party under this Supply Agreement is delayed owing to such a
Force Majeure for any continuous period of more than [***] days, the other Party shall have the
right to terminate this Supply Agreement.

12.4 Neither Party may assign or transfer this Supply Agreement, including by merger, operation of
law, or otherwise, without the other Party's prior written consent (which shall not be withheld
unreasonably) except each Party may assign this Supply Agreement without the other Party's consent
in the case of assignment or transfer to a Third Party that succeeds to all or substantially all of
the assigning Party's business and assets relating to the subject matter of this Supply Agreement,
whether by sale, merger, operation of law or otherwise. Any attempted assignment by a Party in
violation of this Section without the written consent of the other Party will be null and void.
Except as above limited, this Supply Agreement is binding upon and will inure to the benefit of each
of the Parties, its successors and assigns. Without limiting the foregoing, in the event that a
Party is acquired, the acquiring Party shall agree in writing to abide by the terms of this Supply
Agreement. Sutro agrees that if it assigns the License Agreement to any successor as allowed under
section 15.1 of the License Agreement, it will also assign to such successor this Supply Agreement
in accordance with this Section 12.4.

12.5 This Supply Agreement incorporates the Exhibits referenced herein. This Supply Agreement,
together with the License Agreement, constitutes the entire agreement and supersedes all prior
agreements and understandings, both written and oral, between the Parties hereto with respect to its
subject matter. To the extent of any conflict between this Agreement and the License Agreement, the
License Agreement shall govern and control.

12.6 All notices, requests or other communication provided for or permitted hereunder shall be given
in writing and shall be hand delivered or sent by confirmed facsimile, reputable courier or by
registered or certified mail, postage prepaid, return receipt requested, to the address set forth
below, or to such other address of which either Party may inform the other in writing. Notices will
be deemed delivered on the earliest of transmission by facsimile, actual receipt or [***] days after
mailing as described herein.

If to Sutro: Sutro Biopharma, Inc. 310 Utah Ave., Suite 150 South San Francisco, CA 94080 Attention:
Chief Executive Officer
<!-- page 29 -->
If to SutroVax: SutroVax, Inc. 353 Hatch Dr. Foster City, CA 94404 Attention: Chief Executive
Officer

12.7 This Supply Agreement may be amended, modified or waived only in a writing signed by the Party
or Parties to be bound thereby.

12.8 If any provision of this Supply Agreement shall be held invalid, illegal or unenforceable, such
provision shall be enforced to the maximum extent permitted by law and the Parties' fundamental
intentions hereunder, and the remaining provisions shall not be affected or impaired.

12.9 Nothing herein contained shall constitute this a joint venture agreement and nothing herein
shall constitute any Party as a partner, principal or agent of any other, this being an agreement
between independent contracting entities. Except as expressly set forth herein, no Party shall have
the authority to bind any other in any respect whatsoever to Third Parties. Except as provided
herein, nothing contained in this Supply Agreement shall be construed as conferring any right on any
Party to use any name, trade name, trademark or other designation of any other Party hereto, unless
the express, written permission of such other Party has been obtained.

12.10 This Supply Agreement has been submitted to the scrutiny of, and has been negotiated by, both
Parties and their counsel, and shall be given a fair and reasonable interpretation in accordance
with its terms, without consideration or weight being given to any such term's having been drafted
by any Party or its counsel.

12.11 This Supply Agreement shall be governed by, and construed and enforced in accordance with, the
laws of the State of California, without regard to any conflict of laws rules to the contrary.

12.12 Each Party acknowledges that the other Party may likely suffer irreparable harm from such
Party's breach or threatened breach of this Agreement and the other Party, in such cases, would
therefore be entitled, without waiving any other right or remedy available to, to injunctive relief
(including specific performance) without the requirement to post a bond, provided the waiver by such
Party of the other Party's requirement to post a bond shall expire on the Change of Control of the
other Party, and each party agrees that the arbitrator selected under Section 11.3 shall have the
power to grant such injunctive relief (or order specific performance). The Parties shall comply with
any such injunctive relief (including specific performance) ordered by the arbitrator and agree that
such order may, to the extent not precluded by applicable law, be enforceable as a final award in
any court of competent jurisdiction.

12.13 This Supply Agreement may be executed in two (2) or more counterparts, each of which shall be
deemed an original, but all of which together shall constitute one and the same instrument.
Facsimile and other electronically scanned signatures shall have the same effect as their originals.

[The remainder of this page is left intentionally blank]
<!-- page 30 -->
IN WITNESS WHEREOF, the Parties have caused this Supply Agreement to be executed by their respective
duly authorized officers as of the Effective Date, each copy of which will for all purposes be
deemed to be an original. SUTRO BIOPHARMA, INC. SUTROVAX, INC.

By: /s/ William J. Newell By: /s/ Grant E. Pickering Name: William J. Newell Name: Grant E.
Pickering Title: CEO Title: President & CEO

SCHEDULE 1
<!-- page 31 -->
PRODUCTS AND PRICE

[***]

SCHEDULE2
<!-- page 32 -->
SPECIFICATIONS

{6 pages omitted}

[***]
<!-- page 33 -->
SCHEDULE3

INITIAL ORDER

[***]
<!-- page 34 -->
SCHEDULE 2.15.1

REPRESENTATIVE CMOS

[***]
