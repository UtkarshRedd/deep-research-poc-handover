<!-- page 1 -->
# Cooperation Agreement
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| SEC Filing Date | 2013-11-14 |
| Parties | Xi'an Zhonghong New Energy Technology Co., Ltd. ("Party A"); Boxing County Chengli Gas Supply Co., Ltd. ("Party B") |
| Source | CUAD v1 / CHINARECYCLINGENERGYCORP_11_14_2013-EX-10.6-Cooperation Agreement |

Xi'an Zhonghong New Energy Technology Co., Ltd. Boxing County Chengli Gas Supply Co., Ltd.

Project Cooperation Agreement July 2013
<!-- page 2 -->
Cooperation Agreement Coke Dry Quenching (CDQ) and CDQ Waste Heat Power Generation Project Party A:
Xi'an Zhonghong New Energy Technology Co., Ltd. Legal Representative: Ku Guohua Xi'an Zhonghong New
Energy Technology Co., Ltd. is a subsidiary of Xi'an TCH Energy Technology Co. and is also the third
tire subsidiary of China Recycling Energy Corporation, and it engages in the project operations in
China. China Recycling Energy Corporation (the "Company") is a NASDAQ listing company. Its stock
trading symbol is CREG and is a leading industrial waste-to-energy solution provider in China. The
Company is the first in the recycling energy industry with the most completed projects and the
widest ranges in the industry. As the direct investor, the Company provides recycling energy
integrated solution covering technology, investment, and operation. Party B: Boxing County Chengli
Gas Supply Co., Ltd. Legal Representative: Li Shuxun Boxing County Chengli Gas Supply Co., Ltd. is
located in the Industrial Park, Chunhua Town, Boxing County, Shandong Province, which is mainly
engaged in coal coke production and coal chemical industry. After friendly negotiation between two
parties, based on the principle of equality and autonomy, Party A and Party B reached following
items with respect to the coke dry quenching (CDQ) and CDQ waste heat power generation project. Item
One, Investment Construction Projects 1. Construction of CDQ and CDQ recycling economic projects
Construct CDQ system and CDQ waste heat power generation station as a part of of tamping coke oven
with 2 x 60 holes, 5.5 meters and JNDK55-07 of model at Boxing County Chengli Gas Supply Co., Ltd.
The designed total capacity is 25 MW. 2. Under the premise of consistent with the CDQ main equipment
and main parameter descriptions, Party A will be in charge of layout, technical performance index
and technical specifications of CDQ system and CDQ waste heat power generation system; if there is
any difference between CDQ main equipment and main parameters description, Party B will make the
decision. Major equipment and design will be implemented after Party A obtains Party B's consent.
All requirements, statistics should be scientific, reasonable, and operable.
<!-- page 3 -->
3. Party A is responsible for the investment in the construction and operation of CDQ system and CDQ
waste heat power generation system project, including design of the project, equipment selection,
equipment procurement and manufacturing, construction, engineering, installation, formal power
generation. Item Two, Operation of Recycling Project 1. After complete of the project construction,
Party A shall be responsible for the operation, maintenance and management of the recycling project.
Party A shall charge Party B energy saving service fee according to the income from CDQ waste heat
power generation station. 2. Both Parties jointly determine the territorial boundary line of power
transmission pursing to technical appendix. 3. The operation of CDQ system and CDQ waste heat power
generation system includes but is not limited to: equipment maintenance, repair, and update; Party A
will not be responsible for the quality and quantity of the coal coke of CDQ. Item Three, Cost and
Operation Target Party B shall pay Party A energy saving service fee after the construction of CDQ
system and CDQ waste heat power generation system are completed (upon passing evaluation of the
ability of connection to the grid for power generation). 1. The energy saving service fee is paid in
the form of electricity fee. The calculation basis of energy saving service fee is as follows:
average operational time is 8,000 hours per annually; if the annual average operational time was
less than 8,000 hours due to the reasons of Party B, the operational time is calculated as 8,000
hours per year; if the annual average operational time was less than 8,000 hours due to the reasons
by Party A, the operational time is calculated based on the actual operational hours. 2. If the
grid-connected electricity price is adjusted since the execution of this agreement, the fee shall be
calculated as the energy saving service fee (stipulated in section 1 of Item III ) plus 85% of the
price change/adjustment from the original grid-connected electricity price. The starting day for the
change will be from the date of adjustment by Shandong Provincial Price Department. 3. The amount of
power generated shall be calculated based on the indicator of electricity meter in the power
station. 4. The settlement date is the first day of the next month. Deducting the dues of Party A,
Party B should pay Party A the energy saving service fee of the last month before the 15t h of each
month.
<!-- page 4 -->
5. Payment method: Wire or transfer. 6. The policy rebate, award, and preferential treatment shall
be shared by both Parties. Each party shares 50% of the policy rebate, award, and preferential
treatment. Both Parties share the expenses incurred in the process of the application for the policy
rebate, award, and preferential treatment. Item Four Starting and End Date for Recycling Project and
Term 1. The date when Party A completes the construction and installation of CDQ system and CDQ
waste heat power generation system and the power generating system has been in operation and meets
the requirements of the design standard for 72 hours. The Parties agree that date after the
recycling project meets the evaluation requirement as the starting date for the recycling project.
From that date, Party B shall pay the service fees monthly according to the power generated and
Party B shall also pay for the power generated during the 72 hours testing run period. 2. The
cooperation model is BO model. The expected total project cost is 176 million RMB. For the amount of
electricity generated up to 800 million KWH after the project is put into operation, it shall be
charged of the energy saving service fee at 0.40 RMB/KWH. After 800 million KWH, it shall be charged
energy saving service fee with the rate of 0.20 RMB/KWH. The term of the agreement is 20 years,
during which if any main equipment of any Party stops operation due to technical problem or at the
end of its life cycle, the agreement shall be automatically terminated. In case of that happens, the
Party B will have the full rights to dispose the system of Party A. Item Five Construction and
Construction Period of CDQ System and CDQ waste heat power generation system 1. The construction
period of the project is 12 months from the execution of technology agreement. If the project was
delayed due to Party A, Party B has right to dispose the equipment on the construction site after
two month past due date. 2. If the project is stalled due to Party B's reason (including but not
limited its activities that affect daily construction, installation, testing and safety), the
construction period shall be extended accordingly. 3. If any party delays the construction without a
good reason, which results the construction of the whole project or part of the project cannot be
completed on schedule, the other party has right to terminate wholly or part of the agreement and
incurred loss will be assumed by the breaching party.
<!-- page 5 -->
Item Six Raw Material Consumption of the project of CDQ system and CDQ waste heat power generation
system 1. All raw materials such as water, electricity consumed in the operation of the project
shall be settled based on the party B's local price. Party A makes monthly payment. Party B provides
pipeline up to designated boundary line on the construction site and then Party A will connect water
lines and electricity lines into the site and assumes related expenses. 2. The Parties agree that
Party B shall provide steady qualified coal coke production according to the technology agreement
which will be used for CDQ system. Party A guarantees the steady operation of the CDQ and CDQ waste
heat power generating systems. 3. Party B shall provide effective assistance to the construction and
operation management of the recycling project. 4. The land for CDQ and CDQ waste heat power
generation project shall be provided by Party B to Party A with no charge. Item Seven Meter
Confirmation, Management and Maintenance 1. The power generation system of Party A has electricity
meters. If Party B wants to separately conduct electricity measurement, the meters shall be provided
by Party B and be responsible for the its maintenance and expenses. 2. The selection and maintenance
of meters shall not affect the normal operation of CDQ and CDQ waste heat power generation project.
3. Both Parties have right to examine and verify the electricity meters so as to make sure their
accuracy. Item Eight Ownership and Intellectual Property of the Recycling Project 1. During the
contact period, Party A has the ownership of the CDQ and CDQ waste heat power generation systems.
After the termination of the contact, Party B has the disposition right to the project. 2. The
intellectual property of the project belongs to Party A. Without written consent of Party A, Party B
is not allowed to disclose the intellectual property to the other third party.
<!-- page 6 -->
Item Nine Quality Assurance 1. Party A is responsible for the equipment quality, technical
performance, and construction quality. Party B is responsible for the technical specifications and
energy media quality. 2. For the CDQ system and waste heat power generation of CDQ system of Party
A, Party B shall keep the coking and CDQ process functional, and provide necessary guidance and
assistance. Parties shall fully cooperate to ensure the quality of the project. Item Ten Warrants of
Party A Besides responsibilities in this agreement, Party A shall also: 1. Keep the power station
operating properly and ensure that the electricity supplied to Party B complies with national safety
standards. 2. Ensure the safety of its employees during construction and operation. 3. Provide
reliable technical support and guarantee for the project. 4. Responsible for the operation of CDQ
system and waste heat power generation from CDQ system, and bear operation costs. 5. Responsible for
the design, equipment procurement, construction, installation, and test and adjustment. Item Eleven
Warrants of Party B Besides responsibilities in this agreement, Party B shall also: 1. Provide
Performance Guarantee Letter to state that Party B will purchase all electricity generated from the
project. 2. Responsible for the permits and approvals for operation of the project. Party A is
responsible for the permits, inspection and acceptance of the construction and Party B provides
assistance. 3. Purchase all generated electricity from the project. 4. Cooperate with Party A's due
diligence and provide required documents, and ensure that provided documents are true and authentic.
5. Provide leveled construction site. For details, refer to the Technology Attachment.
<!-- page 7 -->
Item Twelve Promises 1. Party A and B agree to have long-term cooperation for current and further
recycling energy projects. Party A has priority to develop further recycling energy projects for
Party B. 2. If the change or update of industrial process or facility of Party B forces Party A to
change its system, Party A will use new system cost and loss for replacement as the new system cost
to calculate numbers according to Item Three to continue execute the project. 3. From the starting
day of the project, Party B must ensure that the coking system works properly and working hours of
the CDQ system must be no less than 8,000 hours/year. Party A must ensure the waste heat power
generation system of CDQ working hours no less than 7,200 hours/year. Item Thirteen Liability for
Breach of Agreements 1. Unless otherwise agreed, either party cannot change or terminate the
agreement without written consent of the other party except for force majeure. Equipment of both
parties must work properly. 2. Party B shall pay Party A the energy saving service fee at the
stipulated time, otherwise: 2.1 If Party B fails to pay Party A the energy saving service fee by 15t
h of the month and the delay is within 60 days, the daily penalty is 0.05% of the overdue payment.
2.2 If the delay is over 60 days, it is regarded that Party B has no ability to perform its payment
obligation. Party A can enforce the Performance Guarantee by Party B to take all project assets.
Party B shall pay the actual energy saving service fees at once and pay Party A losses. 3. If any
event affects the ability to its continue operation of the Party A or Party B, such as bankruptcy,
going out of business, merging, transferring, separation or being dissolution, such party must give
the other party a written notice within 30 days and provide documentary evidences. If such party
cannot perform the contractual obligation, the other party suffered from loss could claim for
compensation. 4. If the power plant cannot operate properly due to the shutdown of furnaces,
facilities, or valves of Party B and such failure cannot be corrected upon a written notice from
Party A to Party B within two days of occurrence of such event, Party B shall compensate the actual
loss of Party A.
<!-- page 8 -->
5. If the facilities and power plant cannot operate properly because of the equipment or human
errors of Party A, then upon three consecutive months of the power generation system cannot reach
65% of its designed capacity, Party A shall compensate actual loss of Party B. 6. Party A shall
adjust its maintenance time based on the production schedule of Party B. If Party A affects the
production of Party B, Party A shall compensate for the loss. 7. Party A cannot transfer or mortgage
the CDQ and CDQ power generation systems without the consent of Party B, otherwise it shall be
responsible for the losses. 8. The CDQ and CDQ power generation systems shall comply with the
national environmental protection standards. If the environment is polluted during the operation of
the power plant, Party A shall bear the liability. 9. If the power generation causes upper level
power network, each party shall bear their own liabilities based on the determination of the upper
level power network operator. Term Fourteen Force Majeure If the project cannot be completed on
schedule or supply power normally due to force majeure, such as war, flood, and earthquake, both
parties shall be partially or fully exempt from their liabilities based on the effects of force
majeure. If any party cannot perform the agreement due to force majeure, the party shall notify the
other party immediately, provide the proof within 15 days, and keep the loss to a minimum with
reasonable efforts. Term Fifteen Settlement of Disputes Both parties shall settle all disputes
through amicable negotiations. If negotiations fail, either party could take a legal action to the
local people's court where Party A is located. Term Sixteen Agreement, Appendix, and Others 1. This
agreement shall be signed and sealed by legal representatives or authorized representatives of both
parties and take effect from the effective date.
<!-- page 9 -->
2. After the agreement is signed, Party A shall complete its due diligence and provide Party B with
the letter of confirmation. Parties shall sign Technical Appendix within 90 days after the agreement
is signed. 3. The Technical Appendix and Performance Guarantee are an integral part of the agreement
and have the same legal effect of the agreement. 4. The agreement can only be terminated after
negotiation and agreement by Party A and B in writing. When the agreement is terminated, Party A has
rights to dispose all assets of the recycling project. 5. As for matters not mentioned herein, Party
A and Party B shall sign a supplemental agreement through negotiation. The supplemental agreement
has same effect to the agreement. If there is any conflicts, the latest supplemental agreement
prevails. The agreement is made in quadruplicate. Each party holds two copies and they have the same
legal effect. Party A: Xi'an Zhonghong New Energy Technology Co., Ltd. (Seal) Representative: Party
B: Boxing Cheng Li Gas Supply Co., Ltd. (Seal) Representative:
