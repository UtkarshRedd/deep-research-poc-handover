# Which jurisdiction's law governs the Endorsement Agreement between Teardrop Putter Corp...

*Question:* Which jurisdiction's law governs the Endorsement Agreement between Teardrop Putter Corporation and Consolidated Artists Inc. (dated 1996-01-01)?

## Identify governing law clause

The Endorsement Agreement between Teardrop Putter Corporation ("TPC") and Consolidated Artists Inc. [uncited] ("Consolidated Artists") is dated 1996-01-01. [21ec1cb8e3926ed1 p.1] Section 28 of the Agreement states: "28. [uncited] GOVERNING LAW. [uncited] This Agreement shall be governed by and construed in accordance with the laws of the Commonwealth of Virginia applicable to contracts entered into and wholly to be performed within the Commonwealth of Virginia and, in the event of any litigation arising out of this Agreement, venue shall be the Commonwealth of Virginia.". [21ec1cb8e3926ed1 p.6] The Agreement contains an express choice-of-law provision designating the Commonwealth of Virginia. [21ec1cb8e3926ed1 p.6]

## Verification appendix

Claims: 6 · supported: 3 · partially: 0 · dropped: 0 · gaps: 3 · tier-1 support rate: 1.00 · tier 2 checked: 1 (unsupported 0, partially 0)

| claim | section | tier 1 | score | tier 2 | clusters | sources | note |
|---|---|---|---|---|---|---|---|
| s1.1 | s1 | gap |  | skipped |  |  | no evidence cited |
| s1.2 | s1 | keep | 1.00 | supported | 1 | e1→[21ec1cb8e3926ed1 p.1] |  |
| s1.3 | s1 | gap |  | skipped |  |  | no evidence cited |
| s1.4 | s1 | gap |  | skipped |  |  | no evidence cited |
| s1.5 | s1 | keep | 1.00 | skipped | 1 | e2→[21ec1cb8e3926ed1 p.6] |  |
| s1.6 | s1 | keep | 1.00 | skipped | 1 | e2→[21ec1cb8e3926ed1 p.6] |  |

### Evidence

- e1 [21ec1cb8e3926ed1 p.1 L2-8] keep (1.0): "# Endorsement Agreement
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 1996-01-01 |
| Parties | Teardrop Putter Corporation ("TPC"); Consolidated Artists Inc. ("Consolidated Artists") |"
- e2 [21ec1cb8e3926ed1 p.6 L373-378] keep (1.0): "28. GOVERNING LAW. This Agreement shall be governed by and construed in accordance with the laws of
the Commonwealth of Virginia applicable to contracts entered into and wholly to be performed within
the Commonwealth of Virginia and, in the…"
