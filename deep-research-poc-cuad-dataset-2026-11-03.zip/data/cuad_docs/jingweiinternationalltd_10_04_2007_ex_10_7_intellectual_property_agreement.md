<!-- page 1 -->
# Intellectual Property Agreement
| Field | Value |
|---|---|
| Document Type | IP Agreement |
| Agreement Date | 2007-02-08 |
| Parties | JingWei HengTong Technology ("ShenZhen"); ShenZhen JingWei Communication Co., Ltd. |
| Source | CUAD v1 / JINGWEIINTERNATIONALLTD_10_04_2007-EX-10.7-INTELLECTUAL PROPERTY AGREEMENT |

INTELLECTUAL PROPERTY AGREEMENT

This Intellectual Property Agreement (this "Agreement") is entered into in ShenZhen on February 08,
2007 between the following two parties:

Party A: JingWei HengTong Technology (ShenZhen) Co., Ltd. (经纬恒通科技（深圳）有限公司 ) Registration Address:
Room 1605 B,Tianan Hi-tech Plaza Tower A,Tian An Cyber Park,Futian District,Shenzhen,China

Party B: ShenZhen JingWei Communication Co., Ltd.(深圳经纬通信技术有限公司) Registration Address: Tianxiang
Building Block A 13th, Tian An Cyber Park, Futian District, Shenzhen.

WHEREAS:

1. Party A, a wholly foreign-owned enterprise incorporated under the laws of the People's Republic
of China (the "PRC"), which has the right of the intellectual property (including but not limited to
Trademark, the Ownership of Consumer Data Base, Software Copyright and License) specified in the
Appendix I of this Agreement (the "intellectual property").

2. Party B is a limited liability company duly incorporated and validly existing under the PRC law,
which is licensed by relevant government authorities to engage in the internet information service
value-added telecommunication service;

3. Party A agrees to license the non- exclusive right to use the intellectual property pursuant to
this Agreement to Party B in accordance with the terms and conditions set forth herein and Party B
agrees to accept the right to use the intellectual property on the same terms and conditions set
forth herein.

NOW THEREFORE, both Parties agree as follows:

1. Grant of License

1.1 The Intellectual Property

1.1.1 Upon the terms and conditions hereinafter set forth, Party A hereby agrees to grant and Party
B hereby agree to accept the right to use the intellectual property in PRC. The license under this
Agreement is a non-exclusive, non-assignable and non-transferable license.

1.1.2 Party A owns the sole and exclusive right of the intellectual property, including any
improvement, upgrades and derived products, no matter whether such products are created by Party A
or Party B. The right and obligation under 1.1.2 of this article shall survive upon termination of
this Agreement.

1.2 Scope

Intellectual Property Agreement 1
<!-- page 2 -->
1.2.1 The Intellectual Property granted to Party B shall only be used to the scope of Party B's
Business operated by Party B. Party B shall not sub-license the Intellectual Property to others or
use the Intellectual Property in the third party's training, business share, lease without the
consent from Party A, unless there are opposite stipulations in this Agreement.

1.2.2 The use right granted under this Agreement is only valid in the PRC. Party B agrees not to
directly or indirectly use or authorize to use the Intellectual Property in the other regions.

2. Terms of Payment: Party B agrees to pay Party A the Intellectual Property License fees (the
"License Fees") and the specified amount of the license fees and the form of payment are set forth
in Appendix 2. Party A has the right to exempt the obligation of payment or adjust the amount of the
License Fees set forth in Appendix 2 according to the actual circumstances from time to time.

3. Party A's Rights and Protection of the Party A's Rights

3.1 Party B agrees, during the term of this Agreement, or thereafter, not to query the copyright or
any rights of Party A in connection with the Intellectual Property, and conduct any actions that is
deemed by Party A as harmful to its rights or license.

3.2 Party B agrees to provide necessary assistances to help Party A to protect the rights of
Intellectual Property. Party A may participate the lawsuits related to the claims of compensation
with its own desire, on behalf of itself, Party B or both Parties, once any third party claims the
compensation in connection with the Intellectual Property of Party A. If any third party infringes
any right of Intellectual Property, Party B shall notify Party A immediately in written of such
infringements within the scope that it knows, and only Party A has the right to take actions against
such infringements.

3.3 Party B agrees to use the Intellectual Property only pursuant to this Agreement and not to use
the Intellectual Property by manner of deceit, misleading or others manners that are deemed by Party
A as harmful to the Intellectual Property or the reputation of Party A.

4. Confidentiality

4.1 Party B shall protect and maintain the confidentiality of any and all confidential data and
information acknowledged or received by Party B from Party A (collectively the "Confidential
Information"). Upon termination of this Agreement, Party B shall return Confidential Information to
Party A or destroy it itself and delete Confidential Information from any electronic devices and
cease to use them as required by Party A. Party B shall not disclose, grant or transfer any
Confidential Information to any third party and will not use the Confidential Information without
Party A's written consent.

4.2 Both Parties agree that the Article 4 shall survive whatever this agreement is amended,
rescinded or terminated.

5. Representations and Warranties

5.1 Party A represents and warrants as follows:

Intellectual Property Agreement 2
<!-- page 3 -->
5.1.1 Party A is a wholly foreign-owned enterprise duly incorporated and validly existing under the
laws of the PRC.

5.1.2 Party A, subject to its company power and business scope, has taken necessary company actions
to get the proper authorization and the consents or approvals (if necessary) from other third party
or governments, without breaching any restricts of the laws and company that binds or affects Party
A to execute and perform this Agreement.

5.1.3 The Agreement will constitute a legal, valid and binding agreement of Party A and will be
enforceable against Party A in accordance with its terms upon its execution.

5.1.4 Party A owned copyright or license of the Intellectual Property.

5.2 Party B represents and warrants as follows:

5.2.1 Party B is a company duly registered and validly existing under the laws of the PRC and is
licensed by relevant government authorities to engage in the internet information service
value-added telecommunication service.

5.2.2 Party B, subject to its company power and business scope, has taken necessary company actions
to get the proper authorization and the consents or approvals (if necessary) from other third party
or governments, without breaching any restricts of the laws and company that binds or affects Party
B to execute and perform this Agreement.

5.2.3 The Agreement will constitute a legal, valid and binding agreement of Party B and will be
enforceable against Party B in accordance with its terms upon its execution.

6. Effective Date and Term

6.1 This Agreement has been duly executed as of the date first set forth above and shall be
effective simultaneously. The term of this Agreement is five (5) years unless the early termination
in accordance with this Agreement. However, Party A and Party B shall review this Agreement every
six (6) months to determine whether any amendment or supplement to the Agreement is necessary by
considering the circumstances after the executing of this Agreement.

6.2 This Agreement may be extended by both Parties in writing upon the expiration of this Agreement.
The term of extension will be decided by the consultation of both Parties.

7. Termination

7.1 Early Termination

Without prejudice to any legal or other rights or remedies of the party who asks for termination of
this Agreement, any Party has the right to terminate this Agreement immediately with written notice
to the other party in the event the other party materially breaches this Agreement including but not
limited to the obligation under Article 3 of this Agreement and fails to cure its breach within
thirty (30) days from the date it receives written notice of its breach from the non-breaching
party. During the term of this Agreement, Party A may terminate this Agreement at any time with a
written notice to Party B 30 days before such termination.

Intellectual Property Agreement 3
<!-- page 4 -->
7.2 Effect of Termination or Expiration

Upon and after the expiration or termination of this Agreement, Party B shall not have all rights
granted pursuant to this Agreement and will refrain from further direct or indirect use of the
Intellectual Property.

8. Force Majeure

8.1 Force Majeure, which includes but not limited to acts of governments, acts of nature, fire,
explosion, typhoon, flood, earthquake, tide, lightning or war, means any event that is beyond the
party's reasonable control and cannot be prevented with reasonable care of the affected party.
However, any shortage of credit, capital or finance shall not be regarded as an event beyond the
party's reasonable control. The party affected by Force Majeure and seeks for the exemption from
performing the obligations under this Agreement shall inform the other party of such exemption and
any action taken by it for performing this Agreement.

8.2 In the event that the affected party is delayed in or prevented from performing its obligations
under this Agreement by Force Majeure, only within the scope of such delay or prevention, the
affected party will not be responsible for any damage by reason of such a failure or delay of
performance. The affected party shall take appropriate manners to minimize or remove the effects of
Force Majeure and attempt to resume the performance of the obligations delayed or prevented by the
event of Force Majeure. Once the event of Force Majeure is removed, both parties agree to resume the
performance of this Agreement with their best efforts.

9. Settlement of Disputes: Both Parties shall strive to settle any dispute arising from the
interpretation or performance through friendly consultation. In case no settlement can be reached
through consultation within 30 days after one party ask for consultation, each party can submit such
matter to China International Economic and Trade Arbitration Commission (the "CIETAC") in accordance
with its rules, and the arbitration proceedings shall be conducted in Chinese and shall take place
in Beijing. The arbitration award shall be final and conclusive and binding upon the parties and
shall be enforceable in accordance with its terms.

10. Notices: Notices or other communications required to be given by any party pursuant to this
Agreement shall be written in English and Chinese and delivered personally or sent by registered
mail or postage prepaid mail or by a recognized courier service or by facsimile transmission to the
address of relevant each party or both parties set forth below or other address of the party or of
the other addressees specified by such party from time to time. The date when the notice is deemed
to be duly served shall be determined as the follows: (a) a notice delivered personally is deemed
duly served upon the delivery; (b) a notice sent by mail is deemed duly served the tenth (10th) day
after the date when the air registered mail with postage prepaid has been sent out (as is shown on
the postmark), or the fourth (4th) day after the delivery date to the internationally recognized
courier service agency; and (c) a notice sent by facsimile transmission is deemed duly served upon
the receipt time as is shown on the transmission confirmation of relevant documents. Intellectual
Property Agreement 4
<!-- page 5 -->
Party A: JingWei HengTong Technology (ShenZhen) Co., Ltd. Address: Room 1605 B,Tianan Hi-tech Plaza
Tower A,Tian An Cyber Park,Futian District,Shenzhen Attn: Ms. Wei Zhang Fax: 86-0755-82924449 Tel:
86-0755-82924488

Party B: ShenZhen JingWei Communication Co., Ltd. Address: Tianxiang Building Block A 13th, Tian An
Cyber Park, Futian District, Shenzhen. Attn: Mr. Wei Li Fax: 86-0755-82924449 Tel: 86-0755-82924488

11. Assignment or Sublicense: This Agreement and all the rights and obligations of Party B hereunder
shall not be assigned, pledged, sublicensed without the prior written consent of Party A.

12. Applicable Law: The validity, implementation and interpretation of this Agreement shall be
governed by the laws of PRC.

13. Amendment and Supplement: Any amendment and supplement of this Agreement shall be made by both
parties in writing. The amendment and supplement duly executed by both parties shall be deemed as a
part of this Agreement and shall have the same legal effect as this Agreement.

14. Severability: If any clause hereof is judged as invalid or non-enforceable according to relevant
laws, such clause shall be deemed invalid only within the applicable area of the Laws and without
affecting other clauses hereof in any way.

15. Appendices: The Appendices referred to in this Agreement are an integral part of this Agreement
and have the same legal effect as this Agreement.

IN WITNESS THEREOF Both Parties hereto have caused this Agreement to be duly executed on their
behalf by a duly authorized representative as of the date first set forth above.

Party A: JingWei HengTong Technology (ShenZhen) Co., Ltd. Legal Representative/Authorized
Representative: Seal:

Party B: ShenZhen JingWei Communication Co., Ltd. Legal Representative/Authorized Representative:
Seal:

5
<!-- page 6 -->
Appendix 1

List of Intellectual property

Item Certificate Name Certificate number Issue date

1 Product Registration Certificate (Operation analysisV1.0) (经篛分析炑件V1.0) 深 DGY - 2003 - 0164
2003.3.6

2 Product Registration Certificate (NGNbilling and operationV2.1)(NGN综合篛帐和瑟狇炑件V2.1) 深 DGY - 2005 -
0030 2005.1.27

3 Product Registration Certificate (YL-2000Telecom operation billingV3.X)(宇恧YL-2000电信业务瑟狇帐务系统V3.X) 深
DGY - 2001 - 0177 2001.6.15

4 Product Registration Certificate (YLDC-2000multiserver data collectionV2.10)(YLDC-2000羬机渹椺炑件V2.10)
深 DGY - 2003 - 0163 2003.3.6

5 Product Registration Certificate (YL-2001major account managementV2.0)(YL-2001大客户管理炑件V2.0) 深 DGY -
2003 - 0105 2003.3.6

6 Product Registration Certificate (Data ware housingV1.0)(新宇恧炑件数据仓库炑件V1.0) 深 DGY - 2006 - 0780
2006.3.16

7 Product Registration Certificate (GT800-OBSSoperationV3.0)新宇恧GT800-OBSS篛帐炑件V3.0) 深 DGY - 2006 -
0363 2006.4.29

8 software ownership certificate (NGNopeation and billingV2.1)(NGN综合篛帐和瑟狇炑件V2.1) 2005SR02400
2005.03.03

9 software ownership certificate (telecom operation strategic analysisV1.0)(电信决策支持系统V1.0)
2004SR03050 2004.04.08

List of Consumer Data Acquisition and Management Contracts

Contract Contract Partner 1 Consumer Data Acquisition and Management Contract ShenZhen HongTian
Hi-Tech Development Co, Ltd 深圳市宏天攨科技发展有榰公司 2 Consumer Data Acquisition and Management Contract
ShenZhen Doubi Digital Tech Co, Ltd 深圳市多比数码技术有榰公司 3 Consumer Data Acquisition and Management
Contract GuangDong FengDa Hi-Tech Co, Ltd 广东丰灂攨科技有榰公司 Intellectual Property Agreement 6
<!-- page 7 -->
Appendix 2 Account and payment method of License Fee

Party B should pay for All Intellectual Property RMB 1,000,000 per year to Party A as license fee.
Party B shall pay the license fee to the account designated by Party A before December 31 each year.
Party A has the right to determine whether or not to exempt the Party B's obligation to pay license
fee at its discretion. Intellectual Property Agreement 7
