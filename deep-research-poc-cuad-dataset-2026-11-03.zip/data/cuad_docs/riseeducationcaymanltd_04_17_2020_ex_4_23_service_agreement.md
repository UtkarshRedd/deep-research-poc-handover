<!-- page 1 -->
# SERVICE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| SEC Filing Date | 2020-04-17 |
| Parties | Rise (Tianjin) Education Information Consulting Co., Ltd. ("Service Provider"); [*] ("Service Recipient") |
| Source | CUAD v1 / RISEEDUCATIONCAYMANLTD_04_17_2020-EX-4.23-SERVICE AGREEMENT |

Exhibit 4.23

Rise Education Group

SERVICE AGREEMENT

This Service Agreement (this "Agreement") is entered into as of [Date] in Beijing, China, by and
between:

Party A: Rise (Tianjin) Education Information Consulting Co., Ltd. ("Service Provider")

Address: Room C209, C210, C213, C214, C217 and C218, 2/F, Building 1, No. 8 Huanhe West Road,
Airport Economic Zone, Tianjin, China

Party B: [•] ("Service Recipient")

Address: [•]

Whereas: 1. Service Provider is a company with adequate financial and other resources in the field
of English teaching and training for children, capable of providing valuable and sophisticated
educational services solutions to educational institutions and teachers; 2. Service Recipient
engages in the field of English teaching and training for children. Service Recipient agrees to
accept Service Provider's services as specified in this Agreement and utilize Service Provider's
resources to provide services to relevant education and training institutions.

This Agreement is entered into by and between Service Provider and Service Recipient (each a "Party"
and collectively, the "Parties") upon mutual consultation to promote the development of education
and training and cultivate talents for the society. 1. Scope of Services

Service Provider shall provide the following operation support services (the "Services") to Service
Recipient: (1) Academic Support Services

Service Provider, having a dedicated team for research and development in courses and teaching
methods, will provide Service Recipient with customized academic supports, including those in
respect of teaching skills, operation guidance for teachers, codes of conduct and staff training, to
meet the needs of Service Recipient for academic support in its operations. 1
<!-- page 2 -->
Rise Education Group (2) Enrollment Support Services

Service Provider, having a dedicated student enrollment support team, will provide Service Recipient
with customized student enrollment support services, including recommending Service Recipient's
courses to potential users, through the internet, WeChat, offline activities and other methods, to
meet the needs of Service Recipient for student enrollment support in its operations and promote
student enrollments with Service Recipient. (3) [Human Resources Support Services

Service Provider, having a dedicated human resources support team, will provide Service Recipient
with customized human resources support services, including but not limited to those in connection
with staff recruitment, onboarding, probation, job transfers, departure, social security and
provident funds, to meet the needs of Service Recipient for human resources support in its
operations.] (4) [Financial Management Support Services

Service Provider, having a dedicated financial management support team, will provide Service
Recipient with customized financial management support services, including but not limited to
consulting services relating to accounting management, cash flow management, financial analysis and
financial budgeting, to meet the needs of Service Recipient for financial management support in its
operations.] (5) [Legal Support Services

Service Provider, having a dedicated legal support team, will provide Service Recipient with
customized legal support services, including but not limited to those relating to the management of
legal and regulatory matters, contract review, dispute resolution, litigation and arbitration
proceedings, and acquisition and merger transactions, to meet the needs of Service Recipient for
legal support in its operations.] (6) Customer Support Services

Service Provider, having a dedicated team operating a national customer service center, will provide
Service Recipient with customized customer support services, including but not limited to answering
customers' incoming calls, following up on customers' telephone inquiries, arranging return visits,
inviting customers to trial courses, assisting on handling customers' complaints and conducting ad
hoc customer satisfaction surveys, to meet the needs of Service Recipient for customer support
services in its operations. (7) [Internet Technology Support Services

Service Provider, having a dedicated internet technology support team, will provide Service
Recipient with customized internet technology support services, including but not limited to network
engineering services and cybersecurity support services, to meet the needs of Service Recipient for
internet technology support in its operations.] (8) [Administrative Support Services

Service Provider, having a dedicated administrative support team, will provide Service Recipient
with customized administrative support services, including but not limited to centralized
procurement services and inventory management services, to meet the needs of Service Recipient for
administrative support in its operations.] 2
<!-- page 3 -->
Rise Education Group 2. Non-exclusivity

The provision of the Services under this Agreement is non-exclusive. Service Provider may use the
Services by itself or provide similar services to any other third party within the area where
Service Recipient operates or other areas. 3. Assignment

Unless otherwise provided herein, Service Recipient shall not assign or transfer any rights or
obligations hereunder to any third party without the prior written consent of Service Provider.
Service Provider may assign or transfer its rights and obligations hereunder to any third party in
connection with, among other things, equity restructuring or business restructuring, without the
consent of Service Recipient. 4. Service Fee

Service Recipient shall pay Service Provider the [service fees]/ [commissions and service fees]
([collectively,] "Service Fee") (inclusive of all applicable taxes) in accordance with Schedule 1
for the Services provided by Service Provider.

[To facilitate the operation of Service Recipient, in the event that Service Recipient incurs
losses, Service Provider may agree to waive the obligations of Service Recipient to pay Service Fee
to Service Provider.] 5. Payment Methods

Service Recipient shall make the payment of Service Fee through bank remittance or other payment
methods to the following account designated by Service Provider:

Account Name: Rise (Tianjin) Education Information Consulting Co., Ltd.

Account Bank: Bank of China (Tianjin Ronghe Square Sub-branch)

Account Number: 272672784101 6. Intellectual Property

All the legal rights in respect of the Services shall be owned by Service Provider. Service
Recipient does not obtain any intellectual property rights in respect of the Services by entering
into this Agreement. All the intellectual property rights created or derived from the provision of
the Services, including but without limitation, copyrights, patents, patent applications,
trademarks, trademark applications, software, know-how, technology data and commercial secrets,
regardless of whether being developed or created by Service Provider or Service Recipient, shall be
exclusively and solely owned by Service Provider. 3
<!-- page 4 -->
Rise Education Group 7. Representations and Warranties (1) Service Provider hereby represents and
warrants to Service Recipient as follows: (a) Service Provider is a limited liability company duly
organized and existing under the laws of China. (b) Service Provider has legal rights to execute and
perform this Agreement. The execution and performance of this Agreement does not contravene the
articles of association or other constitutional documents of Service Provider. Service Provider has
obtained all necessary and appropriate approvals and authorizations to execute and perform this
Agreement. (c) The execution and performance of this Agreement by Service Provider will not violate
any provisions of laws and regulations, governmental approvals, authorizations, notifications, or
any other regulatory documents binding or affecting Service Provider, and will not violate any of
its agreements with, or commitments to, any third party. (d) This Agreement constitutes legal, valid
and enforceable obligations of Service Provider. (2) Service Recipient hereby represents and
warrants to Service Provider as follows: (a) Service Recipient is a [private non-enterprise entity]/
[limited liability company] duly organized and existing under the laws of China. (b) Service
Recipient has legal rights to execute and perform this Agreement. The execution and performance of
this Agreement does not contravene the articles of association or other constitutional documents of
Service Recipient. Service Recipient has obtained all necessary and appropriate approvals and
authorizations to execute and perform this Agreement. (c) The execution and performance of this
Agreement by Service Recipient will not violate any provisions of laws and regulations, governmental
approvals, authorizations, notifications, or any other regulatory documents binding or affecting
Service Recipient, and will not violate any of its agreements with, or commitments to, any third
party. (d) This Agreement constitutes legal, valid and enforceable obligations of Service Recipient.
8. Confidentiality

The Parties covenant and confirm that any verbal communications, written documents or electronic
information (including but not limited to software codes and any contents contained in the software)
relating to this Agreement between the Parties shall be confidential information. Neither Party may
disclose any confidential information of the other Party without prior written consent from the
other Party, except that: (1) relevant information has been made public not as a result of any fault
or disclosure by the information recipient; (2) such disclosure is required under applicable laws or
regulations or rules of securities exchanges. Any employees of one Party disclosing any confidential
information shall be deemed as the Party disclosing confidential information and such Party shall be
liable therefor under this Agreement. This clause shall survive the termination of this Agreement. 4
<!-- page 5 -->
Rise Education Group 9. Events of Default

Failure by a Party to perform its obligations under this Agreement or any non-compliance of its
performance of obligations with this Agreement or any of its representations and warranties under
this Agreement being materially untrue or inaccurate shall constitute an event of default. The
defaulting Party shall indemnify the non-defaulting Party for all the direct and indirect losses
arising from its default.

Notwithstanding the foregoing, upon any delay by Service Recipient in its payment of any Service Fee
to Service Provider, for each day of delay in such payment, Service Recipient must pay Service
Provider liquidated damages at 0.5 percent (0.5%) of the Service Fee that are due and unpaid. In the
event that such delay in payment is more than fifteen (15) days, Service Provider may terminate this
Agreement. Service Recipient shall be liable for indemnifying Service Provider in full for the
losses it incurred therefrom.

Either Party's failure to exercise the right to claim liquidated damages or indemnification for
losses against the other Party shall not be deemed as a waiver of such right. 10. Termination

This Agreement shall be terminated upon the occurrence of any of the following: (1) The validity
period of this Agreement expires and the Parties fail to reach an agreement on renewal; (2) The
Parties mutually agree to terminate this Agreement; or (3) Service Provider exercises the right to
terminate this Agreement upon a default by Service Recipient.

If this Agreement is terminated by Service Provider upon a default by Service Recipient, Service
Provider will not refund the prepaid Service Fee to Service Recipient. 11. Notice

Any written notice sent by registered or express mail shall be deemed being delivered three (3)
business days after the date on which the mail is dispatched (evidenced by the postmark) unless the
address on the mailing slip is different from the address specified in this Agreement. Any written
notice sent by facsimile shall be deemed being delivered when the receipt is confirmed.

In addition, Service Provider may send any notice by email to the email address provided by Service
Recipient in this Agreement, and the notice shall be deemed as being delivered when such email is
successfully sent. 5
<!-- page 6 -->
Rise Education Group The address of each Party for notice purposes shall be as follows:

Service Provider: Rise (Tianjin) Education Information Consulting Co., Ltd.

Mailing address: Room C209, C210, C213, C214, C217 and C218, 2/F, Building 1, No.8 Huanhe West Road,
Airport Economic Zone, Tianjin, China

Attention: SUN Yiding

Service Provider: [•]

Mailing address: [•]

Attention: [•] 12. Dispute Resolution and Governing Law

The Parties shall seek to resolve all the disputes arising from or in connection with this Agreement
through friendly consultation. In the event that any dispute cannot be resolved through such
consultation, such dispute shall be submitted to the Beijing Arbitration Commission ("BAC") for
arbitration pursuant to the then effective arbitration procedures and rules of BAC. The arbitral
award shall be final and binding upon the Parties. 13. Renewal

This Agreement shall be effective as of the date set forth above in this Agreement. The term of this
Agreement shall be five (5) years. This Agreement shall be renewed automatically for another five
(5) years upon the expiration unless the Parties confirm, in writing, the termination of this
Agreement. 14. Miscellaneous (1) [This Agreement shall supersede other service agreements previously
entered into by both Parties. In case of any conflicts in any terms and conditions or any dispute on
the interpretation, application or implementation of this Agreement, this Agreement shall prevail.
Any amendment to this Agreement shall be in writing and executed by both Parties hereto.] (2) This
Agreement is executed in two (2) original copies and each Party shall hold one original copy. Both
original copies shall have the same legal effect. (3) This Agreement shall become effective upon
being affixed with both Parties' official seals.

[The remainder of this page is left blank] 6
<!-- page 7 -->
Rise Education Group IN WITNESS WHEREOF, the Parties hereto have caused this Agreement to be
executed Rise (Tianjin) Education Information Consulting Co., Ltd.

(Corporate Seal)

Date:

[•]

(Seal)

Date: 7
<!-- page 8 -->
Rise Education Group SCHEDULE 1

Service Fees

During the term of this Agreement, Service Recipient shall pay to Service Provider the Service Fee
on a quarterly basis. The amount of the Service Fee shall be [determined on the basis of the actual
costs incurred by Service Provider in connection with its provision of the services, plus a mark-up
at a percentage as agreed upon between both Parties, to be allocated to Service Recipient and other
service recipients in proportion to their respective revenues] / [computed at a percentage (as
agreed upon between both Parties) of Service Recipient's revenues] and confirmed by a letter of
confirmation substantially in the form attached hereto.

Service Fee shall be paid after each quarter. Service Recipient shall pay the Service Fee for the
preceding quarter in accordance with a written payment instruction of Service Provider during each
quarter. 8
<!-- page 9 -->
Rise Education Group Annex 1 - Form of the Letter of Confirmation on the Amount of Service Fee

Letter of Confirmation on the Amount of Service Fee

Reference is made to the Service Agreement (the "Agreement"), dated as of [Date], by and between
Rise (Tianjin) Education Information Consulting Co., Ltd. ("Service Provider") and [•] ("Service
Recipient"). Pursuant to Section 4 and Schedule 1 of the Agreement, Service Provider and Service
Recipient agree that the amount of the Service Fee for the [•] quarter of 20[•] shall be [RMB [•]
([•][in letters]) in total]/[set at [•]% of the revenues booked by Service Recipient during the
quarter, amounting to RMB [•] ([•][in letters])]. The above-referenced Service Fee shall be paid by
Service Recipient to the account designated by Service Provider not later than [Date] in accordance
with a written payment instruction of Service Provider. Rise (Tianjin) Education Information
Consulting Co., Ltd. [•]

(Corporate Seal) (Seal)

[Date] 9
