<!-- page 1 -->
# COLLABORATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2014-08-18 |
| Parties | Capsugel US, LLC ("CAPSUGEL"); Cardax, Inc. ("CARDAX"); CARDAX and CAPSUGEL (each a “Party” and together the “Parties”) |
| Source | CUAD v1 / CARDAX,INC_08_19_2014-EX-10.1-COLLABORATION AGREEMENT |

Exhibit 10.1 COLLABORATION AGREEMENT THIS COLLABORATION AGREEMENT ("Agreement") is made as of this
18t h day of August 2014 (the "Effective Date"), by and between Capsugel US, LLC and its Affiliates
with an address at 412 Mt. Kemble Ave, Suite 200C, Morristown, NJ 07960 ( "CAPSUGEL") and Cardax,
Inc., and its Affiliates, with a corporate address at 2800 Woodlawn Dr., Suite 129, Honolulu, HI
96822 ("CARDAX"). CARDAX and CAPSUGEL are each a "Party" and together constitute the "Parties"
RECITALS WHEREAS, CAPSUGEL is experienced in formulating, developing, manufacturing, testing and
packaging of health and nutrition products; and WHEREAS, CARDAX is experienced in developing
products that are based on its astaxanthin technologies; and WHEREAS, CAPSUGEL and CARDAX desire to
enter into an arrangement under which the Product (as defined below) will be formulated and
developed for the purpose of identifying a marketing partner(s) ("Marketer") for Marketer's onward
sale of the Product in the Territory. NOW, THEREFORE, the Parties hereto agree to the following:
SECTION 1 DEFINITIONS The following terms for the purpose of this Agreement shall have the following
respective meanings: 1.1 "Active Ingredient" shall mean the synthetic Astaxanthin and/or esters
thereof that will be formulated in the Product as the active ingredient of the Product. 1.2
"Adjusted Net Sales" shall mean [***]. 1.3 "Administrative Cost" shall mean [***]. 1.4 "Affiliate"
shall mean, with respect to either Party, all entities which, directly or indirectly, are controlled
by, control or are under common control with such Party. For purposes of this Agreement, the word
"control" shall mean the possession, directly or indirectly, of the power to direct or cause the
direction of the management and policies of an entity, including through ownership of more than
fifty percent (50%) of the voting shares or interest of an entity; provided, however, with respect
to CAPSUGEL, the term "Affiliate" shall be limited to entities who directly or indirectly through
one or more intermediaries are controlled by the parent of CAPSUGEL's direct parent entity and with
respect to CARDAX the term "Affiliate" shall not include Cardax Pharmaceuticals, Inc. CERTAIN
PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT UNDER
RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE DESIGNATED [***]. A COMPLETE
VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION. 1
<!-- page 2 -->
1.5 "Applicable Laws" shall mean all applicable laws, statutes, ordinances, codes, rules and
regulations applicable to the formulation, development and/or manufacture, marketing, distribution
sale, and disposal of the Product or any aspect thereof and the obligations of CAPSUGEL or CARDAX,
as the context requires under this Agreement. 1.6 "Annual Period" shall mean the twelve (12) month
period beginning on the first day in which the Launch Date occurs and each twelve (12) month period
beginning on the anniversary of such day thereafter. 1.7 "Commercially Reasonable Efforts" means a
Party's reasonable efforts and diligence, consistent with professional business standards generally
practiced in the health and nutrition industry, applied in accordance with the Party's commercially
reasonable business, legal, medical and scientific judgment, including the efforts and resources the
Party would use for a product owned by it or to which it has rights, which is of similar market
potential at a similar stage in its product life, taking into account the competitiveness of the
marketplace, the proprietary position of the compound, the Applicable Laws, the profitability of the
applicable products, and other relevant factors including, without limitation, technical, legal,
scientific or medical factors. 1.8 "Development Plan" shall have the meaning set forth in Section
2.1. 1.9 "Disclosing Party" shall have the meaning set forth in the Confidentiality Agreement. 1.10
"Formulation" means a specific combination of excipient(s) that can formulate the Active Ingredient,
as well as compounds other than the Active Ingredient, developed as a result of the work conducted
under the Development Plan. 1.11 "Force Majeure" shall have the meaning set forth in Section 10.5.
1.12 "Indemnified Party" shall have the meaning set forth in Section 8.3. 1.13 "Indemnifying Party"
shall have the meaning set forth in Section 8.3. 1.14 "Intellectual Property Rights" means a
composition of matter, formula, process, method of use, invention, improvement, business name,
domain name or database right to the extent any of the foregoing is protected in a utility model,
trademark, service mark, trade name or business name, copyright, registered design, design right,
patent, know-how, trade secret, rights in or to confidential information all goodwill related
thereto and any other intellectual property right of any nature whatsoever throughout the world
(whether registered or unregistered and including all applications and rights to apply for the
same). CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR CONFIDENTIAL
TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE DESIGNATED
[***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 2
<!-- page 3 -->
1.15 "Launch Date" shall mean the date [***]. 1.16 "Loss or Losses" shall mean any and all damages,
fines, fees, settlements, payments, obligations, penalties, deficiencies, losses, costs and
expenses, including, without limitation, environmental losses, interest, court costs, reasonable
fees of attorneys, accountants and other experts and other reasonable expenses of litigation or
other proceedings or of any claim, default or assessment. 1.17 "Manufacturing Facility" shall mean
those areas of CAPSUGEL or CAPSUGEL's subcontractors manufacturing, packaging, laboratory and
warehousing facilities utilized in the formulation, manufacture, packaging, storage, testing,
shipping or receiving of the Product. 1.18 "Materials" mean all excipient(s) and inactive raw
materials used in the formulation of the Product. For the avoidance of doubt, "Materials" does not
include any Active Ingredient or work in process or finished goods inventory. 1.19 "Net Sales" means
[***]. 1.20 "Product" shall mean Active Ingredient Formulated in CAPSUGEL's proprietary Lipid
Multi-Particulate Technology, including any improvements or derivatives of such technology. 1.21
"Receiving Party" shall have the meaning set forth in the Confidentiality Agreement. 1.22
"Regulatory Approvals" means any and all approvals, licenses, registrations, or authorizations of
the relevant Regulatory Authority, necessary for the development, manufacture, use, storage, import,
transport, export or commercialization of the Product in a particular country or jurisdiction. 1.23
"Regulatory Authority (ies)" means any governmental regulatory authority within a Territory involved
in regulating any aspect of the development, manufacture, testing, market approval, sale,
distribution, packaging or use of the Product. 1.24 "Regulatory Filings" shall mean the
registrations, permits, licenses, authorizations, presentations, notifications, filings and/or
approvals (together with all applications therefore and all related documents required by the FDA
and all other laws for the development, manufacture, use, importation, export, marketing, sale and
distribution of the Product within the Territory. CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED
PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT
OF 1934. OMISSIONS ARE DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED
SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION. 3
<!-- page 4 -->
1.25 "Royalty Payment" shall have the meaning set forth in Section 5.1. 1.26 "Specifications" shall
mean the Product description and attributes agreed upon between the Parties upon conclusion of the
Development Plan and appended to this Agreement as Exhibit B that will be attached hereto and, when
attached, will be a part hereof, prior to commercialization of the Product. 1.27 "Territory" shall
mean worldwide. Section 2 Product Development, Manufacture and Commercialization 2.1 Governance
Process Among the Parties . Both CARDAX and CAPSUGEL will agree upon a development plan, which shall
be in writing and attached hereto as Exhibit A (the "Development Plan"), which shall describe
various parameters including each Party's duties, obligations, time schedule and deliverables
schedule. The activities performed under the Development Plan (the "Development Activities") shall
be administered by a joint project team ("JPT"), which shall review/update/amend the Development
Plan for the Product in the Territory and coordinate the Formulation, development, manufacturing and
commercialization of the Product, including identifying and selecting one or more Marketers as
contemplated under Section 2.4. Each Party shall appoint a project manager to oversee that Party's
performance of its obligations under this Agreement and shall notify the other Party of the name and
full contact details of its appointed project manager. The JPT shall comply with this Agreement for
decisions specifically assigned to a Party pursuant to this Agreement. Meetings shall take place by
telephone or in person and the JPT will operate by consensus. If consensus cannot be reached, the
matter will be submitted to the Head of Dosage Form Solutions of CAPSUGEL and the President and CEO
of CARDAX for resolution. If such matter is not resolved, then the Parties may attempt to mediate
such issue under the JAMS mediation rules. No member or any Affiliate of any member of the JPT shall
have any liability under this Agreement and shall be exculpated to the fullest extent not prohibited
by law from any liability to any Party that such member is not an employee, officer, consultant or
acting in any similar capacity. 2.2 CAPSUGEL Responsibilities. With respect to the Product,
CAPSUGEL, [***] shall [***] perform the development work necessary to formulate, analytically
develop and take all other developmental actions necessary or required to develop the Product and
manufacture pre- clinical and clinical batches (collectively, the "CAPSUGEL Development Activities"
). For purposes of further clarification, CAPSUGEL Development Activities shall include, without
limitation, each of the following performed with all due diligence, care and skill and in accordance
with all other Applicable Laws:

CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT
UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 4
<!-- page 5 -->
(a) Formulation Development. Formulation shall mean a specific combination of Materials that
formulate the Active Ingredient, as well as compounds other than the Active Ingredient, developed as
a result of the work conducted under the Development Plan. The development of the Formulation of the
Product, includes without limitation, all stability tests and other studies as applicable, providing
CARDAX reports of such stability tests, using Commercially Reasonable Efforts to modify the
Formulation as necessary and develop processes capable of scale-up and commercialization in
accordance with Applicable Laws. (b) Analytical Methods. Developing and validating analytical
methods including but not limited to dissolution, assay, and stability as agreed upon by the
Parties. (c) Manufacture of Study Batches. The manufacture [***] of batches of Product in amounts
specified on or about the dates determined a s reasonably necessary for conducting all required for
CAPSUGEL/CARDAX funded studies. Any other batches required or reasonably required by the Marketer
for applying for and all actions related to additional Regulatory Approvals and Regulatory Filings
of the Product and any related communications, studies or support for the FDA or any other
Regulatory Authority (ies), which may include human and animal studies, shall be paid for by the
Marketer, unless the Parties agree otherwise. (d) Manufacturing Development. Development of
manufacturing processes and systems in conformance with cGMP requirements of FDA to manufacture
pilot batches, exhibit batches and commercial batches of Product. (e) Reporting. CAPSUGEL shall,
throughout the performance of the Development Plan studies, consult with CARDAX on matters including
technical, intellectual property and regulatory aspects and keep the other apprised of all
developments. (f) Commercial Manufacturing. CAPSUGEL shall manufacture the Product for each Marketer
unless otherwise agreed by the Parties and the applicable Marketer.

2.3 CARDAX Responsibilities.

(a) CARDAX shall be responsible for [***] the Active Ingredient [***], subject to reasonable notice
and delivery schedules and reasonable amounts required by CAPSUGEL for it to perform its obligations
under this Agreement or as otherwise agreed by CARDAX. (b) [***] CERTAIN PORTIONS OF THIS EXHIBIT
HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE
SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT
HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION. 5
<!-- page 6 -->
2.4 Joint Responsibilities.

[***] The marketing of the Product shall be carried out by one or more mutually identified
Marketer(s) by the JPT or otherwise in accordance with Section 2.1. CAPSUGEL and CARDAX will jointly
control identification, decision rights, and terms for a Marketer as determined by the JPT or
otherwise in accordance with Section 2.1. If a Marketer is not identified, or the terms are not
determined, by the JPT or otherwise in accordance with Section 2.1, then the Marketer (and such
terms) may be designated by either Party, subject to the reasonable approval of the other Party. Any
additional costs/activities required from a Marketer will be subject to agreement of the JPT or
otherwise as provided in Section 2.1, including but not limited to pre-launch out-of-pocket expenses
and the funding of such costs and expenses. These costs will be shared [***]. 2.5 Ownership of
Application. CARDAX shall own and control all information and rights in, to and under all Regulatory
Approvals in the Territory (including all associated contents and correspondences) and applications
therefore related to the Product and any other marketing authorizations within the Territory, unless
otherwise mutually agreed upon by the Parties.

Section 3 Intellectual Property Matters 3.1 Background IP. This Agreement shall not change, modify
or otherwise affect any rights to any confidential information, inventions, patents, patent
applications or other Intellectual Property Rights owned or developed by either Party before the
Effective Date or developed by a Party after the Effective Date other than under the terms of this
Agreement ("Background IP"). This Agreement shall not confer on either Party any rights in and/or to
any Background IP of the other party, except as otherwise provided in this Agreement. 3 .2 CAPSUGEL
Property. CARDAX acknowledges that CAPSUGEL possesses certain inventions, processes, know-how, trade
secrets, improvements, other intellectual properties and other assets, including but not limited to
formulation recipes, processing details, laboratory analyses, analytical methods, procedures and
techniques, computer technical expertise and software, which have been independently developed by
CAPSUGEL, including but not limited to, the Background IP of CAPSUGEL (collectively "Capsugel
Property"). CARDAX and CAPSUGEL agree that any Capsugel Property or improvements thereto which are
used, improved, modified or developed by CAPSUGEL under or during the term of this Agreement are the
product of CAPSGUEL's technical expertise possessed and developed by CAPSUGEL prior to the Effective
Date and are the sole and exclusive property of CAPSUGEL. CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN
OMITTED PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES
EXCHANGE ACT OF 1934. OMISSIONS ARE DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN
FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION. 6
<!-- page 7 -->
3 . 3 CARDAX Property. CAPSUGEL acknowledges that CARDAX possesses certain inventions, processes,
know-how, trade secrets, improvements, other intellectual properties and other assets, which have
been independently developed by CARDAX, including but not limited to, the Background IP of CARDAX
(collectively "CARDAX Property"). CAPSUGEL and CARDAX agree that any CARDAX Property or improvements
thereto which are used, improved, modified or developed by CARDAX under or during the term of this
Agreement are the product of CARDAX's technical expertise possessed and developed by CARDAX prior to
the Effective Date and are the sole and exclusive property of CARDAX. 3.4 Use of Confidential
Information. CARDAX may use the confidential information of CAPSUGEL generated under this Agreement,
except for CAPSUGEL's internal technical protocols and Background IP, to the extent necessary (i) in
connection with seeking regulatory approval for a Compound Formulation or the Product and/or (ii)
filing a patent application. "Compound Formulation" means any specific combination of excipient(s)
and the Active Ingredient developed as a result of the work conducted under this Agreement. CARDAX
may use and disclose CAPSUGEL's internal technical protocols and Background IP, to the extent
necessary for Regulatory Approvals as contemplated by Section 2.3(b) to the extent reasonably
determined by CAPSUGEL after notice and consultation with CAPSUGEL by CARDAX. 3.5 Inventions. Each
Party will own all of its inventions and other Intellectual Property Rights made under this
Agreement, including any patents, patent applications and other Intellectual Property Rights related
to such inventions, if any, made solely by its employees or independent contractors or employees or
independent contractors of its Affiliates, unless otherwise expressly set forth herein. 3.6 Joint
Inventions. The Parties will jointly own all inventions and other Intellectual Property Rights
jointly made under this Agreement that are directly resulting from work conducted under this
Agreement in accordance with the Development Plan and related specifically to the Product or the
Compound Formulation, including any patents, patent applications and other Intellectual Property
Rights related to such inventions, if any, unless otherwise expressly set forth herein. During the
Term, each Party hereby provides a worldwide, exclusive, royalty free, perpetual license of such
Intellectual Property Rights for use by each licensee in its business in connection with the
development and marketing and commercialization of the Product. For avoidance of doubt, no Party or
any of its Affiliates shall have any rights to the Background IP of the other Party nor shall any
Party have rights to any trademarks, service marks, trade names, business names or product names
developed by the other Party. All decisions regarding the protection and exploitation of joint
investments and other Intellectual Property Rights shall be determined by the JPT or otherwise in
accordance with Section 2.1. 3.7 [reserved] CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED
PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT
OF 1934. OMISSIONS ARE DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED
SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION. 7
<!-- page 8 -->
3.8 Freedom to Operate. CARDAX acknowledges that it shall be solely and fully responsible to use its
Commercially Reasonable Efforts for doing any and all freedom to operate assessments regarding
possible infringement of third party intellectual property rights for the Product in the part of the
Territory that the Parties reasonably determine require such protection; provided, however, each
Party shall be solely and fully responsible for doing any and all freedom to operate assessments
regarding possible infringement of third party intellectual property rights for any and all of its
Intellectual Property Rights. Section 4 Exclusivity [***] Section 5 Consideration 5.1 Royalty
Payments. CAPSUGEL shall pay to CARDAX a royalty equal to [***] of the Adjusted Net Sales ("Royalty
Payment") within [***] after the end of [***]. 5.2 Mode of Payment. CAPSUGEL will endeavor to
contract with Marketer to receive profit sharing payments in U.S. dollars and CAPSUGEL will in turn
pay CARDAX its share in U.S. dollars. Should Marketer require that local currency based payments be
made to CAPSUGEL then CAPSUGEL will pay CARDAX its share in such local currency unless otherwise
agreed. For instances in which Marketer sells the product in a local currency other than U.S.
dollars but agrees to pay CAPSUGEL in U.S. dollars, the conversion of local currency to USD will be
a mutually agreeable methodology with such Marketer (e.g., using the Marketer's standard accounting
methodology such as its average daily rate for its accounting month). 5.3 Taxes. All federal,
national, regional, district, local or other governmental income tax or similar tax that is imposed
on either Party as a result of income, shall be the responsibility of such Party. All amounts
payable by CAPSUGEL to CARDAX under this Agreement shall be paid free and clear of all deductions or
withholdings whatsoever, except as may be required by law. If any deductions or withholdings are
required by law to be made from any of the amounts payable by CAPSUGEL to CARDAX, the amount of any
such withholding may be treated as part of the Royalty Payment, depending on the timing and the
applicable legal requirements and CAPSUGEL shall provide CARDAX a receipt of any such withholdings.
CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT
UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 8
<!-- page 9 -->
Section 6 Regulatory Requirements 6.1 Regulatory Contacts. [***] CAPSUGEL shall notify CARDAX
immediately, and in no event, no later than three (3) business day(s), after it receives any contact
or communication from any governmental or regulatory authority, including without limitation the
FDA, that in any way relates to or may have an impact on a Product or the CAPSUGEL Development
Activities. 6.2 Regulatory Inspections. Throughout the Term of this Agreement, CAPSUGEL agrees to
cooperate with any governmental or regulatory body, particularly the FDA, which requests a general
GMP inspection or audit or any inspection or audit relative to the manufacture, storage, handling,
or shipment of Product manufactured, stored, handled, or shipped by CAPSUGEL. In addition, CAPSUGEL
shall use its Commercially Reasonable Efforts to meet all reasonable U.S. FDA and other appropriate
regulatory demands. 6.3 CARDAX Inspection. CARDAX shall have the right to audit CAPSUGEL's
facilities, quality systems and records from time to time upon reasonable notice and CARDAX shall
have the right to have a third party accounting firm, subject to a non-disclosure agreement, audit
CAPSUGEL's financials as they relate to Net Sales and Adjusted Net Sales. In the event that the
amount of the Royalty Payment for any quarter is 10% or more than the amount reported by CAPSUGEL,
then CAPSUGEL will pay the costs and expenses of the audit or investigation. 6.4 Regulatory Notices.
CAPSUGEL shall provide prompt written notice to CARDAX of the occurrence of, and the results of any
regulatory notices including inspections as referenced in this Section 6 relating to the manufacture
of Product. 6.5 Recordkeeping. CAPSUGEL shall keep true, accurate, and complete books, records,
reports, and accounts (hereinafter "Records") of all business or activities in connection with or
relating to the manufacture, storage, handling, and shipment, including all validations,
qualification, and validation protocols, of Product and this Agreement. CARDAX has the right, upon
reasonable prior notice and during normal business hours, to inspect and examine such Records.
CAPSUGEL agrees to retain all such Records for a period of five (5) years after the expiration of
the Term or after termination of this Agreement. CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED
PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT
OF 1934. OMISSIONS ARE DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED
SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION. 9
<!-- page 10 -->
6.6 Recall. In the event that either Party believes it may be necessary to conduct a recall, field
correction, market withdrawal, stock recovery, or other similar action with respect to any Product
which was sold under this Agreement (a "Recall"), CARDAX and CAPSUGEL shall promptly consult with
each other in good faith as to how best to proceed, it being understood and agreed that the final
decision as to any Recall of any Product sold by Marketer(s) shall be made jointly; provided,
however, that neither Party shall be prohibited hereunder from taking any action that it is required
to take by Applicable Law or taking Commercially Reasonable Efforts to mitigate the loss from any
Recall or seizure or to protect the public. Each of CAPSUGEL and CARDAX shall make a permanent,
complete and accurate record of all costs incurred by it in connection with any Product Recall or
seizure. With respect to any Recall or seizure of any Product caused by the negligence, mistake or
omission of CAPSUGEL, CAPSUGEL shall (i) reimburse CARDAX for all out-of-pocket costs and expenses
reasonably incurred by CARDAX in connection with the Recall or seizure, including, without
limitation, replacing the Product subject to the Recall or seizure in accordance with this
Agreement; and (ii) as provided in Section 8.1, indemnify and save CARDAX and its Affiliates
harmless from and against any and all damages to or claims by third parties associated (or
Affiliated) with or resulting from any such Recall or seizure. With respect to any Recall or seizure
caused by the negligence, mistake or omission of CARDAX (including but not limited to failure of the
Active Ingredient to meet the Specifications), CARDAX shall: (i) reimburse CAPSUGEL for all
out-of-pocket costs and expenses reasonably incurred by CAPSUGEL in connection with the Recall or
seizure; and (ii) as provided in Section 8.2, indemnify and save CAPSUGEL and its Affiliates
harmless from and against any and all damages to or claims by third parties associated with or
resulting from any such Recall or seizure. With respect to any Recall or seizure of a Product not
caused by the negligence, mistake or omission of either Party, each Party shall bear [***] of the
aggregate costs of any and all out-of-pocket costs, expenses and losses reasonably incurred by
either Party in connection with the Recall or seizure. If CAPSUGEL and CARDAX cannot agree which
party is at fault or whether a Recall or seizure was reasonably beyond the control of the Parties,
then an independent technical expert, acceptable to both Parties, shall be designated to make such
determination. The designated technical expert shall not be an employee, consultant, officer,
director or shareholder of, or otherwise associated with, CAPSUGEL, CARDAX or their respective
Affiliates. The technical expert's determination will be, in the absence of fraud or manifest error,
binding and conclusive upon the Parties. Each Party shall keep the other fully informed of any
notification or other information, whether received directly or indirectly, which might affect the
marketability, safety or effectiveness of a Product, or which might result in liability issues or
otherwise necessitate action on the part of either party, or which might result in Recall or seizure
of the Product. Prior to any reimbursement pursuant to this Section 6 the Party claiming
reimbursement shall provide the other Party with all available documentation of all reimbursable
costs and expenses. CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR
CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE
DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES
AND EXCHANGE COMMISSION. 10
<!-- page 11 -->
Section 7 Representations and Warranties 7.1 Representations and Warranties of CAPSUGEL. CAPSUGEL
hereby represents and warrants to CARDAX as follows: (a) CAPSUGEL is a corporation in good standing
under the laws of the jurisdiction of its organization and authorized to do business wherever
necessary to fulfill the terms and conditions of this Agreement; (b) CAPSUGEL has the full power and
authority to execute and deliver this Agreement and perform its covenants, duties and obligations
described in this Agreement; (c) This Agreement is the valid, legal and binding obligation of
CAPSUGEL, enforceable in accordance with its terms; (d) Neither the execution and delivery of this
Agreement nor the performance of CAPSUGEL's covenants, duties and obligations described in this
Agreement constitute or will constitute a default under or conflict with any judgment, decree or
order of any court or other governmental body to which CAPSUGEL is subject and will not conflict or
be inconsistent with or result in the termination, modification, breach or default under the terms
of any contract, commitment, covenant, agreement, instrument, document or understanding to which
CAPSUGEL is a party; (e) CAPSUGEL is not a party to, nor to CAPSUGEL's knowledge is CAPSUGEL as of
the Effective Date threatened with, any legal or equitable action or proceeding before any court,
arbitrator, administrative agency or other tribunal which is reasonably likely to adversely affect
its ability to execute and deliver this Agreement or fully and timely perform its covenants, duties
and obligations described in this Agreement; (f) CAPSUGEL has obtained and continuously maintained
all permits, authorizations and licenses issued by all federal, state and local governmental
agencies and authorities necessary for the conduct of CAPSUGEL's businesses as of the Effective
Date; (g) CAPSUGEL has and shall continue to follow, comply with and adhere to all Applicable Laws
necessary for the conduct of CAPSUGEL's businesses;

CAPSUGEL shall during the performance of the CAPSUGEL Development Activities ensure that, at all
times, its employees, contractors, consultants, sub-contractors carry out their duties with all
reasonable skill and care customary for the type of scientific research and development work covered
by this Agreement and shall at all times comply with all applicable laws and regulations; record
experimental data and all other material information relating to the CAPSUGEL Development Activities
in individual notebooks or other appropriate formats and treat the same as Confidential Information;
ensure that, at all times, its employees, contractors, consultants and sub-contractors are fully
aware of and comply with the confidentiality provisions of their respective contracts which, for the
avoidance of doubt, are comparable to the confidentiality provisions set out in this Agreement; keep
CARDAX informed of the progress of the CAPSUGEL Development Activities by providing bi-weekly
written reports and such other interim reports or updates as CARDAX may reasonably request. CERTAIN
PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT UNDER
RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE DESIGNATED [***]. A COMPLETE
VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION. 11
<!-- page 12 -->
7.2 Representations and Warranties of CARDAX. CARDAX hereby represents and warrants to CAPSUGEL as
follows: (a) CARDAX is a corporation in good standing under the laws of the jurisdiction of its
organization and authorized to do business wherever necessary to fulfill the terms and conditions of
this Agreement; (b) CARDAX has the full power and authority to execute and deliver this Agreement
and perform its covenants, duties and obligations described in this Agreement; (c) This Agreement is
the valid, legal and binding obligation of CARDAX, enforceable in accordance with its terms; (d)
Neither the execution and delivery of this Agreement nor the performance of CARDAX's covenants,
duties and obligations described in this Agreement constitute or will constitute a default under or
conflict with any judgment, decree or order of any court or other governmental body to which CARDAX
is subject and will not conflict or be inconsistent with or result in the termination, modification,
breach or default under the terms of any contract, commitment, covenant, agreement, instrument,
document or understanding to which CARDAX is a party; (e) CARDAX is not a party to, nor to CARDAX's
knowledge is CARDAX as of the Effective Date threatened with, any legal or equitable action or
proceeding before any court, arbitrator, administrative agency or other tribunal which is reasonably
likely to adversely affect its ability to execute and deliver this Agreement or fully and timely
perform its covenants, duties and obligations described in this Agreement; and (f) CARDAX has
obtained and continuously maintains all permits, authorizations and licenses issued by all federal,
state and local governmental agencies and authorities necessary for the conduct of CARDAX's
businesses as of the Effective Date.

Disclaimer. THE REPRESENTATIONS AND WARRANTIES SET FORTH IN THIS AGREEMENT ARE THE PARTIES' ONLY
WARRANTIES AND NO OTHER WARRANTY, EXPRESS, IMPLIED OR STATUTORY, WILL APPLY. EACH PARTY EXPRESSLY
DISCLAIMS ALL OTHER WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. FOR THE AVOIDANCE OF DOUBT, EACH PARTY
EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES OF NON-INFRINGEMENT THAT ARE NOT EXPRESSLY SET FORTH IN
THIS AGREEMENT. CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR
CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE
DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES
AND EXCHANGE COMMISSION. 12
<!-- page 13 -->
Section 8 Indemnification 8.1 CAPSUGEL's Indemnification of CARDAX. CAPSUGEL shall indemnify, defend
and hold CARDAX, its Affiliates and their respective officers, directors, employees and agents
harmless from and against any and all third party Losses suffered, incurred or sustained by CARDAX
or to which CARDAX becomes subject at any time, to the extent arising out of or resulting, directly
or indirectly, from: (a) any breach of CAPSUGEL's representations, warranties or obligations under
this Agreement; (b) any personal injury, death or property damage caused by the possession, use, or
consumption by any person of any Product that does not comply with the Specification in any way or
is the result of actions or inactions of CAPSUGEL in its manufacturing or is alleged to result from
any inherent risk of the Formulation or a defect in the Formulation; and (c) any other negligent act
or omission on the part of CAPSUGEL, its Affiliates or their respective employees or agents except,
in each case, to the extent such claims are attributable to the gross negligence or willful
misconduct of CARDAX. 8.2 CARDAX's Indemnification of CAPSUGEL. CARDAX shall indemnify, defend and
hold CAPSUGEL, its Affiliates and their respective officers, directors, employees and agents
harmless from and against any and all third party Losses suffered, incurred or sustained by CAPSUGEL
or to which CAPSUGEL becomes subject at any time, to the extent arising out of or resulting,
directly or indirectly, from (a) any breach of CARDAX's representations, warranties or obligations
under this Agreement; (b) any personal injury, death or property damage caused by the possession,
use or consumption by any person of any Product supplied by CAPSUGEL under this Agreement that does
not comply with the Specifications as a result of actions or inactions of CARDAX or is alleged to
result from any inherent risk of the Product or a defect in the Active Ingredient; and (c) any other
negligent act or omission on the part of CARDAX, its Affiliates or their respective employees or
agents except, in each case, to the extent such claims are attributable to the gross negligence or
willful misconduct of CAPSUGEL. CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A
REQUEST FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934.
OMISSIONS ARE DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH
THE SECURITIES AND EXCHANGE COMMISSION. 13
<!-- page 14 -->
8.3 Indemnification Process. If CARDAX, Affiliates or their respective employees, servants or
agents, or CAPSUGEL, its Affiliates or their respective employees, servants or agents (in each case
an "Indemnified Party"), receive any written claim which such Indemnified Party believes is the
subject of indemnity hereunder by the other Party hereto (an "Indemnifying Party"), the Indemnified
Party shall, as soon as reasonably practicable after forming such belief, give notice thereof to the
Indemnifying Party, provided that the failure to give timely notice to the Indemnifying Party as
contemplated hereby shall not release the Indemnifying Party from any liability to the Indemnified
Party unless the Indemnifying Party demonstrates that the defense of such claim is prejudiced by
such failure. The Indemnifying Party shall have the right, by prompt notice to the Indemnified Party
to assume the defense of such claim at its cost, with counsel reasonably satisfactory to the
Indemnified Party. If the Indemnifying Party does not so assume the defense of such claim or, having
done so, does not diligently pursue such defense, the Indemnified Party may assume the defense, with
counsel of its choice, but at the cost of the Indemnifying Party. If the Indemnifying Party so
assumes the defense, it shall have absolute control of the litigation; the Indemnified Party may,
nevertheless, participate therein through counsel of its choice and at its cost. The Party not
assuming the defense of any such claim shall render all reasonable assistance to the Party assuming
such defense, and out-of-pocket costs of such assistance shall be for the account of the
Indemnifying Party. No such claim shall be settled other than by the Party defending the same, and
then only with the consent of the other Party, which consent shall not be unreasonably withheld;
provided that the Indemnified Party shall have no obligation to consent to any settlement of any
such claim which (i) imposes on the Indemnified Party any liability or obligation which cannot be
assumed or performed in full by the Indemnifying Party, (ii) does not unconditionally release the
Indemnified Party, (iii) does require a statement as to or an admission of fault, culpability or
failure to act by or on behalf of Indemnified Party or any of its Affiliates or (iv) does impose any
restrictions on the conduct of business by the Indemnified Party or its Affiliates. 8.4 Limitation
of Damages. IN NO EVENT SHALL EITHER PARTY BE LIABLE FOR ANY CONSEQUENTIAL, SPECIAL OR PUNITIVE
DAMAGES OR LOST PROFITS ARISING UNDER OR RELATING TO THIS AGREEMENT. Except in the event of (i) a
Party's gross negligence or willful misconduct and/or (ii) a Party's breach of its confidentiality
obligation, the total liability of one Party to the other Party (and its Affiliates) arising out of
or in connection with this Agreement or the Products, whether in contract, tort (including
negligence), statute or otherwise, shall, to the maximum extent permitted by Applicable Law, be
limited to the amount of revenues it receives under this Agreement. 8.5 Insurance. During the Term
and for a period of two (2) years after the termination of the Agreement or the expiry date of the
last batch manufactured whichever is later, thereafter, each Party shall obtain and maintain, at its
sole expense adequate product liability insurance for the Product as it reasonably deems necessary
and appropriate. Evidence of coverage, in the form of certificates of insurance, shall be provided
promptly upon registration of the Product in given countries and as reasonably requested thereafter.
CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT
UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION. 14
<!-- page 15 -->
Section 9 Confidentiality and Publicity Confidentiality. The Parties agree that the terms of the
Confidentiality Agreement entered into between the parties dated Nov 19, 2013 shall govern this
Agreement. Section 10 Term and Termination 10.1 Term and Renewal. [***] In addition, any contract
entered into by the Parties with a Marketer for the Product shall survive termination of this
Agreement in accordance with its terms, including any renewal rights provided therein. 10.2
Termination for Breach . A material breach that is subject to cure that is not cured within [***] of
written notice of breach shall be cause for termination, provided that if the breaching party is
diligently pursuing in good faith the remedy of the breach at the expiration of such [***] cure
period, then such [***] cure period shall be extended for a reasonable period to effect the cure.
Upon any breach by CAPSUGEL, CARDAX shall be permitted to use all Intellectual Property of CAPSUGEL
used in the Formulation and the Product to the extent necessary for the development and marketing of
the Product. Upon any breach by CARDAX, CAPSUGEL shall be permitted to use all Intellectual Property
of CARDAX used in the Active Ingredient and the Product to the extent necessary for the development
and marketing of the Product in accordance with the terms of this Agreement as of the date of such
termination. 10.3 Termination for Bankruptcy . This Agreement may be terminated by either Party,
forthwith, or at any time thereafter by notice to the other if the other becomes bankrupt or
insolvent, or enters into liquidation whether compulsorily or voluntarily, or convenes a meeting of
its creditors, or has a receiver appointed over all or part of its assets, or ceases for any reason
to carry on business. 10.4 Development or Commercial Non-Viability. In the event that CAPSUGEL
reasonably determines that the development of the Compound Formulation is not feasible with
Commercially Reasonable Efforts in accordance with the Development Plan, with such changes as
reasonably requested by CAPSUGEL, then CAPSUGEL may discontinue the development of the Compound
Formulation and Product and terminate this Agreement, in which case, CARDAX shall have the right to
license the Intellectual Property Rights as provided in Section 4. CERTAIN PORTIONS OF THIS EXHIBIT
HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE
SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT
HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION. 15
<!-- page 16 -->
In the event that CARDAX reasonably determines that, with Commercially Reasonable Efforts by the
Parties, the development of a Product is not feasible due to any legal, or technical developments
with respect to the Product, including but not limited to conflicts of Intellectual Property Rights;
withdrawal of a Product by a major regulatory agency for safety or efficacy reasons; or inability of
the Parties to produce a Product that passes FDA required biostudies, in which such developments
make the Product nonviable or that the Product is not acceptable to any applicable Marketer, then,
CARDAX may elect to discontinue the development of the Product and terminate this Agreement. 10.5
Termination for Force Majeure. Neither Party shall be liable to the other for default or delay in
the performance of any of its obligations under this Agreement if such default or delay shall be
caused directly or indirectly by accident, fire, flood, riot, war, terrorism, act of God, embargo,
strike, failure or delay of normal source of supply of materials, or delay of carriers, equipment
failure or complete or partial shutdown of plant by any of the foregoing causes or other causes
beyond its reasonable control, including FDA action ("Force Majeure"). 10.6 No Waiver. The failure
of either Party to terminate this Agreement by reason of the breach of any of its provisions by the
other Party shall not be construed as a waiver of the rights or remedies available for any
subsequent breach of the terms and provisions of this Agreement. 10.7 Property. In the event of
termination of this Agreement for whatever cause, in addition to the other obligations of the
Parties hereunder, each Party shall return to the other Party or to the other Party's designee no
later than thirty (30) days after the effective date of termination all of such other Party's
property, including all proprietary information, in its possession, except to the extent required to
be retained by law or to comply with such Party's continuing obligations hereunder. 10.8 Survival.
The provisions of Sections 3.6, 4, 6, 8, 9 and 11 shall survive any termination of this Agreement.
Section 11 Miscellaneous 11.1 Dispute Resolution. This Agreement shall be governed by and
interpreted in accordance under the laws of the State of New York. Any dispute, controversy or claim
arising out of this Agreement, or the breach, termination or invalidity thereof, shall be discussed
between the senior management of the Parties who will attempt to resolve the matter amicably. Any
disputes which cannot be resolved in this way within sixty (60) days of one Party notifying the
other of the existence of a dispute shall be finally settled before JAMS in accordance with the
expedited arbitration procedures of JAMS. The arbitration shall be conducted in English in New York,
New York, USA. The costs of the arbitration payable to JAMS shall be funded equally by the parties,
provided that the prevailing party shall be reimbursed for such costs and expenses and its own
actual out of pocket costs CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A REQUEST
FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE
DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES
AND EXCHANGE COMMISSION. 16
<!-- page 17 -->
11.2 Integration and Amendment . This Agreement, the Exhibits hereto contain the complete agreement
between the Parties with respect to the subject matter hereof. All previous and collateral
agreements, representations, warranties, promises and conditions relating to the subject matter of
this Agreement are superseded by this Agreement. This Agreement may only be amended by a written
instrument duly executed by the Parties hereto. 11.3 Assignment. Neither Party may assign this
Agreement without the prior written consent of the other Party; provided, however that either Party
may assign in connection with a merger or sale of all or substantially all of its stock or assets,
provided the assignee agrees to be bound by all of the terms and conditions of this Agreement. 11.4
Waiver. No waiver of any default by either Party shall be deemed to constitute a waiver of any
subsequent default with respect to the same or any other provision hereof. No waiver shall be
effective unless made in writing with specific reference to this Agreement and signed by a duly
authorized representative of the Party granting the waiver. 11.5 Notice. Any notice or request
expressly provided for or permitted under this Agreement shall be in writing, delivered manually or
by mail, e- mail, or facsimile and shall be deemed sufficiently given if and when received by the
Party to be notified at its address first set forth below, or if and when mailed by registered mail
or certified mail, postage prepaid, addressed to such Party at such address, or upon delivery
confirmation. Either Party, by notice to the other, may change its address for receiving such
notices. If to CAPSUGEL: CAPSUGEL US, LLC 412 Mt. Kemble Ave. Suite 200C Morristown, NJ 07960 USA
Attn: President, Dosage Form Solutions Telephone: [***] Facsimile: [***] E-mail: [***] With a copy
to CAPSUGEL US, LLC 412 Mt. Kemble Ave. Suite 200C Morristown, NJ 07960 USA Attn: General Counsel
Telephone: [***] Facsimile: [***] E-mail: [***] CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED
PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT
OF 1934. OMISSIONS ARE DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED
SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION. 17
<!-- page 18 -->
If to CARDAX: CARDAX, Inc. 2800 Woodlawn Dr., Suite 129 Honolulu, HI 96822 Attn: President and CEO
Telephone: [***] Facsimile: [***] E-mail: [***] With a copy to Herrick, Feinstein LLP 2 Park Avenue
New York, NY 10016 Attn: Richard M. Morris Telephone: [***] Facsimile: [***] E-mail: [***] 11.6
Severability of Provisions. Each provision of this Agreement shall be treated as a separate and
independent clause, and the unenforceability of any one clause shall in no way impair the
enforceability of any of the other clauses herein. Moreover, if one or more of the provisions
contained in this Agreement shall for any reason be held to be excessively broad as to scope,
activity, subject or otherwise so as to be unenforceable at law, such provision or provisions shall
be construed by the appropriate judicial body or arbitration panel by limiting or reducing such
provision or provisions, so as to be enforceable to the maximum extent allowable under the
applicable law as such law shall then be. 11.7 Independent Contractors. Each Party hereto shall be
an independent contractor of the other. Neither Party shall be the legal agent of the other for any
purpose whatsoever and therefore has no right or authority to make or underwrite any promise,
warranty or representation, to execute any contract or otherwise to assume any obligation or
responsibility in the name of or on behalf of the other Party, except to the extent specifically
authorized in writing by the other Party. Neither Party shall be bound by or liable to any third
persons for acts or obligations or debts incurred by the other toward such third party, except to
the extent specifically agreed to in writing by the Party to be so bound. This Agreement shall not
create a partnership or other similar arrangement. 11.8 Announcement. The Parties agree to
coordinate external communications (e.g. joint press release) regarding this collaboration. CERTAIN
PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT UNDER
RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE DESIGNATED [***]. A COMPLETE
VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION. 18
<!-- page 19 -->
11.9 Headings; Interpretation. The section headings contained in this Agreement are for convenience
of reference only, do not form a part of this Agreement and shall not affect in any way the meaning
or interpretation of this Agreement. Whenever the context may require, any pronoun shall include the
corresponding masculine, feminine and neuter forms. The words "include," "includes" and "including"
shall be deemed to be followed by the phrase "but not limited to." All references herein to
Sections, Sections and Exhibits shall be deemed references to Sections and Sections of, and Exhibits
to, this Agreement unless the context shall otherwise require. All Exhibits attached to this
Agreement shall be deemed incorporated herein by reference as if fully set forth herein. Words such
as "herein," "hereof," "hereto," "hereby" and "hereunder" refer to this Agreement and to the
Exhibits, taken as a whole. Except as otherwise expressly provided herein: (a) any reference in this
Agreement to any agreement shall mean such agreement as amended, restated, supplemented or otherwise
modified from time to time; (b) any reference in this Agreement to any law shall include
corresponding provisions of any successor law and any regulations and rules promulgated pursuant to
such law or such successor law; and (c) all terms of an accounting or financial nature shall be
construed in accordance with generally accepted accounting principles, as in effect in the United
States from time to time. 11.10 Counterparts. This Agreement may be executed by the Parties hereto
in separate counterparts, each of which when so executed and delivered shall be deemed an original
and all of which counterparts taken together shall constitute but one and the same instrument. * * *
Signature Page Follows * * * CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A
REQUEST FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934.
OMISSIONS ARE DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH
THE SECURITIES AND EXCHANGE COMMISSION. 19
<!-- page 20 -->
IN WITNESS WHEREOF, the Parties have caused this this Agreement to be executed by their respective
duly authorized representatives as of the day and year first above written. CAPSUGEL US, LLC By: /s/
Amit Patel Name: Amit Patel Title: President, Dosage Form Solutions CARDAX, INC. By: /s/ David G.
Watumull Name: David G. Watumull Title: President and CEO CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN
OMITTED PURSUANT TO A REQUEST FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES
EXCHANGE ACT OF 1934. OMISSIONS ARE DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN
FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION. 20
<!-- page 21 -->
EXHIBIT A DEVELOPMENT PLAN [***] CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A
REQUEST FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934.
OMISSIONS ARE DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH
THE SECURITIES AND EXCHANGE COMMISSION. 21
<!-- page 22 -->
EXHIBIT B SPECIFICATIONS As provided in Section 1.26, to be provided upon conclusion of the
Development Plan CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR
CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE
DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES
AND EXCHANGE COMMISSION. 22
<!-- page 23 -->
EXHIBIT C [***] CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO A REQUEST FOR
CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934. OMISSIONS ARE
DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES
AND EXCHANGE COMMISSION. 23
<!-- page 24 -->
<!-- page 25 -->
EXHIBIT D MASS MARKET CHANNELS [***] CERTAIN PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED PURSUANT TO
A REQUEST FOR CONFIDENTIAL TREATMENT UNDER RULE 24B-2 UNDER THE SECURITIES EXCHANGE ACT OF 1934.
OMISSIONS ARE DESIGNATED [***]. A COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH
THE SECURITIES AND EXCHANGE COMMISSION. 24
