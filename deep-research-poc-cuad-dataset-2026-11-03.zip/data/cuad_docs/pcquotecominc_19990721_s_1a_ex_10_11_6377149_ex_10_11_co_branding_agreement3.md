<!-- page 1 -->
# SECOND AMENDMENT TO CO-BRANDING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Co-Branding Agreement |
| Agreement Date | 1998-02-23 |
| Parties | PC QUOTE, INC. ("PCQ"); A.B. Watley, Inc. ("ABW") |
| Source | CUAD v1 / PcquoteComInc_19990721_S-1A_EX-10.11_6377149_EX-10.11_Co-Branding Agreement3 |

[LOGO]

SECOND AMENDMENT TO CO-BRANDING AGREEMENT

THIS SECOND AMENDMENT TO CO-BRANDING AGREEMENT (this "Amendment") is made and entered into,
effective for all purposes and in all respects as of the 23rd day of February, 1998, by and between
PC QUOTE, INC., with its principal place of business at 300 South Wacker Drive, Chicago, Illinois
60605 ("PCQ") and A.B. Watley, Inc., with its principal place of business at 33 West 17th Street,
New York, New York 10011 ("ABW").

WHEREAS, PCQ and ABW have executed that certain Co-Branding Agreement dated October 11, 1996, as
amended on December 10, 1996 (as so amended, the "Agreement");

WHEREAS, the parties hereto desire to further amend the Agreement to modify the provisions of the
Agreement regarding [***] of the term thereof; and

WHEREAS, the parties hereto desire to set forth herein the terms and conditions of their agreements
and understandings with respect to the foregoing.

NOW, THEREFORE, in consideration of the foregoing, of the mutual promises for the parties contained
herein and of other good valuable consideration, the receipt and sufficiency of which are hereby
acknowledged, the parties hereto, intending legally to be bound, hereby covenant and agree as
follows:

1. The preamble hereto is incorporated herein and, by this reference, is made a substantive part
hereof.

2. The text of Section 2. A. and B. of the Agreement is hereby deleted in its entirety and the
following language is inserted in its stead:

[***]

3. To the extent, if any, that provision of this Agreement conflicts with or differs from any
provision of the Agreement, such provision of this Second Amendment shall prevail and govern for all
purposes and in all respects.

4. Except as modified hereby, the Agreement and its terms and provisions are hereby ratified and
confirmed for all purposes and in all respects.

5. This Second Amendment may be executed in several counterparts, each of which shall be deemed an
original but all of which collectively shall constitute the same instrument.

Source: PCQUOTE COM INC, S-1/A, 7/21/1999
<!-- page 2 -->
IN WITNESS WHEREOF, the undersigned parties have hereunto affixed their signatures and seals as of
the day and year first above written.

PC QUOTE, INC.

By: /s/ Scott Clyde ------------------------ Name: Scott Clyde ---------------------- Title: VP
--------------------

A. B. WATLEY, INC.

By: /s/ Robert Malin ------------------------ Name: Robert Malin ---------------------- Title:
President --------------------

-2-

Source: PCQUOTE COM INC, S-1/A, 7/21/1999
