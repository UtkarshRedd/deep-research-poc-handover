<!-- page 1 -->
# Network Build and Maintenance Agreement
| Field | Value |
|---|---|
| Document Type | Maintenance Agreement |
| Agreement Date | 2019-07-31 |
| Parties | Commnet Wireless, LLC ("Vendor"); AT&T Mobility LLC ("AT&T") ("Party" or in the plural as the "Parties.") |
| Source | CUAD v1 / AtnInternationalInc_20191108_10-Q_EX-10.1_11878541_EX-10.1_Maintenance Agreement |

Exhibit 10.1 CERTAIN CONFIDENTIAL PORTIONS OF THIS EXHIBIT HAVE BEEN OMITTED AND REPLACED WITH
"[***]". SUCH IDENTIFIED INFORMATION HAS BEEN EXCLUDED FROM THIS EXHIBIT BECAUSE IT IS (I) NOT
MATERIAL AND (II) WOULD LIKELY CAUSE COMPETITIVE HARM TO THE COMPANY IF DISCLOSED. Execution Version
Network Build and Maintenance Agreement Between Commnet Wireless, LLC And AT&T Mobility LLC

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 2 -->
Mobility Network General Agreement TABLE OF CONTENTS Page 1.1 Scope 1 1.2 Scope of Agreement 1 1.3
Term of Agreement 1 2.1 Definitions 1 2.2 Affiliate 1 2.3 Agreement 2 2.4 Attorney's Fees 2 2.5 AT&T
Competitor 2 2.6 AT&T Indemnified Parties 2 2.7 Cell Site 2 2.8 Change Management Plan 2 2.9 Change
of Control 2 2.10Change Order 2 2.11Control 2 2.12Customer Information 3 2.13Deliverable 3
2.14Delivery or Completion 3 2.15Delivery Date or Completion Date 3 2.16Documentation 4 2.17Drug
Screen 4 2.18Employment Claims 4 2.19Excusable Delay 4 2.20FirstNet Authority 4 2.21Information 5
2.22Intellectual Property Rights 5 2.23Items 5 2.24Laws 5 2.25Liability 5 2.26Lien 5 2.27Litigation
Expense 5 2.28Loss 5 2.29Material 6 2.30Non-Service Affecting Defect 6 2.31OEM 6 2.32Permits 6
2.33Person 6 2.34Physical Entry 6 2.35Restricted Entities 6 2.36Service Affecting Defect 7
2.37Services 7

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. ii

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 3 -->
Mobility Network General Agreement TABLE OF CONTENTS 2.38Software 7 2.39Specifications 7
2.40Subcontractor 7 2.41Suspend a Site, Suspend or Suspension 7 2.42System 7 2.43Third Party Loss 7
2.44Vendor Indemnified Parties 7 2.45Vendor Person 8 2.46Work 8 2.47Writing or Written 8 3.1 General
Terms 8 3.2 Affiliate 8 3.3 Amendments and Waivers 8 3.4 Anticipated and Actual Delays in Delivery
and Performance 8 3.5 Anticorruption Laws 9 3.6 Assignment and Delegation; Change of Control 10 3.7
Compliance with Laws 11 3.8 Conflict of Interest 11 3.9 Construction and Interpretation 11
3.10Cumulative Remedies 12 3.11Delivery, Performance and Acceptance 12 3.12Entire Agreement 13
3.13Force Majeure 14 3.14Government Contract Provisions and Flow Downs 14 3.15Governing Law 16
3.16Indemnity 16 3.17Information 18 3.18Infringement 21 3.19Insurance 25 3.20Invoicing and Payment
28 3.21Licenses and Patents 29 3.22Limitation of Damages 29 3.23Offset Right 29 3.24Material and
Services Furnished by Vendor and AT&T 29 3.25Non-Exclusive Market 29 3.26Notice of Certain Events 30
3.27Notices 30 3.28Offshore Work Prohibited 32 3.29Order of Precedence 32 3.30Ownership of Paid-For
Development, Use and Reservation of Rights 32 3.31Publicity 33

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 3

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 4 -->
Mobility Network General Agreement TABLE OF CONTENTS 3.32Records and Audits 34 3.33Restricted
Entities 37 3.34Severability 37 3.35Supplier Citizenship and Sustainability 37 3.36Survival of
Obligations 37 3.37Taxes 37 3.38Termination and Suspension 39 3.39Third Party Administrative
Services 42 3.40Third Party Beneficiaries 42 3.41Title and Risk 43 3.42Title To Material Furnished
by AT&T 43 3.43Transaction Costs 44 3.44Utilization of Minority, Women, and Disabled Veteran Owned
Business Enterprises 44 3.45Vendor Personnel and Employment Matters 44 3.46Warranty 44
3.47Subcontractors; Work Done By Others 47 3.48Affordable Care Act 48 3.49Customer Information 48
3.50Reimbursable Expenses 50 4.1 Special Terms 50 4.2 Access 50 4.3 AT&T Supplier Information
Security Requirements (SISR) 50 4.4 Background Checks 51 4.5 Clean Up 52 4.6 Vendor's Audited
Financial Statements 52 4.7 Vendor Personnel Information 52 4.8 Damage to Property 52 4.9 Dispute
Resolution 53 4.10Electronic Data Interchange (EDI) 54 4.11Emergency Work 55 4.12Hazardous Material
and Regulated Substances 55 4.13Identification of Vendor's Personnel and Equipment 57
4.14Independent Contractor 57 4.15Inspection of Material 58 4.16Inspection of Work 58 4.17Liens 58
4.18Notification of Injury or Damage 59 4.19Protection of Property 59 4.20Releases Void 59
4.21Removal and Management of Used Batteries 59 4.22Resource Recovery Center 60

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 4

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 5 -->
Mobility Network General Agreement TABLE OF CONTENTS 4.23Safety Management 60 4.24Technical Support
61 4.25Testimony 61 4.26AT&T Data and AT&T Derived Data (Big Data) 61 4.27Business Continuity Plan
63 4.28Change in Laws 63 4.29FOSS 63 5.1 Execution of Agreement 64 5.2 Transmission of Original
Signatures and Executing Multiple Counterparts 64 Exhibit A: Government Flow Downs and Contract
Clauses

Exhibit B: Supplier Information Security Requirements (SISR)

Exhibit C: Change Management Plan

Addendum 1: Network Build and Structured Payments

Addendum 2: Maintenance

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 5

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 6 -->
This Network Build and Maintenance Agreement is entered into as of the 31 day of July, 2019 (the
"Effective Date") by and between Commnet Wireless, LLC, a Delaware limited liability company
(hereinafter referred to as "Vendor"), and AT&T Mobility LLC, a Delaware limited liability company
on behalf of itself and its Affiliates (as such term is defined herein) (collectively and
hereinafter referred to as "AT&T"), each of which may be referred to in the singular as a "Party" or
in the plural as the "Parties."

1.0 Scope

1.1 Scope of Agreement. Subject to the terms and conditions of this Agreement, Vendor shall (i)
build, install and deploy a radio access network ("RAN") at certain Cell Sites in one or more states
for AT&T and its Affiliates as more particularly described in Addendum 1: Network Build and
Structured Payments (the "Build Addendum") attached hereto, (ii) provide ongoing maintenance of the
RAN network constructed by Vendor pursuant to the Build Addendum as more particularly described in
Addendum 2: Maintenance (the "Maintenance Addendum") attached hereto and (iii) provide to AT&T
certain other Material and Services related thereto as described herein and therein. In exchange for
the provision of the Material and Services set forth in the Build Addendum, the Parties agree that
AT&T will pay to Vendor the Structured Payments (as such term is defined in the Build Addendum) and
in exchange for the provision of the Material and Services set forth in the Maintenance Addendum,
the Parties agree that AT&T will pay to Vendor the Maintenance Fees (as such term is defined in the
Maintenance Addendum). Vendor agrees that the Material and Services provided pursuant to this
Agreement, the Build Addendum and the Maintenance Addendum shall strictly conform to the
Specifications contained herein and therein.

Concurrently herewith, the Parties or their Affiliates have entered into (i) that certain Cell Site
Backhaul Master Services Agreement between Vendor and AT&T Corp. pursuant to which Vendor is
responsible for providing transport services from the Cell Sites to AT&T's designated MTSO (the
"Transport Agreement") and (ii) that certain Master License Agreement that governs all site license
agreements between AT&T and Vendor (or its Affiliates) for the Cell Sites (the "Master License
Agreement").

1.2 Term of Agreement. The "Term" of this Agreement shall commence on the Effective Date and shall
continue in full force and effect until the expiration or earlier termination of the last Addendum
to expire or be terminated, at which time this Agreement will expire, unless this Agreement is
sooner terminated in accordance with the terms and provisions of this Agreement.

2.0 Definitions

2.1 Affiliate. "Affiliate" of a Person means any other Person, directly or indirectly, through one
or more intermediaries, Controlling, Controlled by or under common Control with such Person or any
other Person in which such Person beneficially owns a majority of the outstanding capital stock,
membership interests or partnership interests.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 1

st

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 7 -->
2.2 Agreement. "Agreement" means the written agreement between the Parties as set forth in this
document and the attached addendums, exhibits, schedules and appendices and shall include the terms
of such other documents as are incorporated by express reference in this document and the attached
addendums, exhibits, schedules and appendices. All references herein to this Agreement shall include
the Build Addendum and the Maintenance Addendum and all attachments, exhibits and schedules attached
thereto, as amended from time to time.

2.3 Attorney's Fees. "Attorney's Fees" include all reasonable outside counsel fees and expenses.

2.4 AT&T Competitor. "AT&T Competitor" means [***].

2.5 AT&T Indemnified Parties. "AT&T Indemnified Parties" means AT&T and its Affiliates, as well as
their respective officers, directors, employees, representatives and agents, individually or
collectively, as the case may be, and all of their successors and assigns.

2.6 Cell Site. "Cell Site" means a wireless communications tower or other structure on which cell
site equipment is located, and for purposes of this Agreement shall refer to AT&T's space on such
structure and all of the AT&T Provided Equipment (as such term is defined in the Build Addendum) and
Vendor Provided Equipment (as such term is defined in the Build Addendum), including all Material
contemplated herein or in the Build Addendum, together with all related ground space and other
property and rights ancillary thereto as set forth in the Master License Agreement and the
applicable Site License for the Vendor Cell Sites or the applicable Tower Lease for the Third Party
Cell Sites.

2.7 Change Management Plan. "Change Management Plan" means the process to accommodate changes to the
Specifications or Work set forth in Exhibit C attached hereto.

2.8 Change of Control. "Change of Control" means any contract or transaction or series of related
contracts or transactions (regardless of form or structure) that would directly result in the
Control of a Person or its business or assets changing from one Person to another Person (alone or
in combination with any other third Person).

2.9 Change Order. "Change Order" means any written request by any Party hereto to make any change to
the Work, including the Services, Material, Delivery Dates or Completion Dates, Specifications or
other terms and conditions of this Agreement, that is authorized and approved in writing by the
other Party in accordance with the Change Management Plan.

2.10 Control. "Control" (including the terms "Controlling" and "Controlled by") of a Person shall
mean (i) holding fifty percent (50%) or more ownership or beneficial interest of income and capital
of such Person; or (ii) having ownership of at least fifty percent (50%)

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 2

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 8 -->
of the voting power or voting equity of such Person; or (iii) regardless of the percentage ownership
interest held, having the ability to appoint a majority of the board of directors, managers or other
governing body of such Person or otherwise direct management policies of such Person by contract or
otherwise.

2.11 Customer Information. "Customer Information" includes, to the extent received, observed,
collected, stored, or accessed, in any way, in connection with this Agreement: AT&T's or its
Affiliates' customers' names, addresses, and phone numbers, any such customer's or its employee's
personal, health or financial information, authentication credentials, Internet activities, history,
and/or patterns of use, information concerning accounts, network performance and usage information,
web browsing and wireless application information, location information, any other information
associated with a customer of AT&T or its Affiliates or with persons in the household of a customer
of AT&T or its Affiliates, and any information available to AT&T, its Affiliates and/or the
suppliers and/or subcontractors of AT&T or its Affiliates (for avoidance of doubt, including Vendor)
by virtue of AT&T's or its Affiliates' relationship with customers as a provider of mobile and
non-mobile communications, Internet, data, video, information or other services, including the
quantity, technical configuration, location, type, destination, and amount of use of communications
or other services subscribed to, and information contained on the bills of AT&T's or its Affiliates'
customers.

2.12 Deliverable. "Deliverable" means any and all deliverables set forth in this Agreement,
including all deliverables set forth in the Build Addendum and the Maintenance Addendum, which are
to be provided by Vendor to AT&T pursuant to the terms of any exhibit, schedule or appendix attached
hereto or thereto. Deliverables include, but are not limited to, any cell site configuration files,
reports, data, designs, plans, specifications, models, prototypes, performance requirements, and/or
Documentation delivered pursuant to this Agreement.

2.13 Delivery or Completion. "Delivery" or "Completion" or any similar terms mean Vendor's
obligation to provide Material and Services that strictly conform to the Specifications, including,
without limitation, Location Acceptance of the Cell Sites described in the Build Addendum. Vendor
completes Delivery of Material or Completion of Services: (i) in the case of any Cell Site (and all
Material and Services incorporated therein or related thereto) upon Location Acceptance, and (ii) in
the case of delivery of Material or Services that are required to be delivered prior to or following
Location Acceptance, (A) upon AT&T's possession of the Material if Vendor is not required to provide
additional Services, such as installation, (B) upon completing such additional Services, if Vendor
is required to provide such Services in connection with providing Material, or (C) for Services,
upon completing the provision of Services. Notwithstanding the above, Delivery and Completion shall
not be deemed to have occurred until Vendor causes the Material and Services to strictly conform to
the Specifications and in the case of any Cell Site, Location Acceptance has occurred.

2.14 Delivery Date or Completion Date. "Delivery Date" or "Completion Date" means the date on which
the Parties agree Vendor is scheduled in this Agreement or the Build

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 3

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 9 -->
Addendum or Maintenance Addendum or as such date may be extended due to an Excusable Delay, as
applicable, to complete its Delivery of Material and Completion of Services, as applicable.

2.15 Documentation. "Documentation" means all documentation included with Vendor's purchase of
Vendor Provided Equipment, including user instructions, training materials and, if applicable, the
source code for Software.

2.16 Drug Screen. "Drug Screen" means the testing of any individual for the use of illicit drugs
(including opiates, cocaine, cannabinoids, amphetamines, and phencyclidine (PCP)).

2.17 Employment Claims. "Employment Claims" means any claims by any federal, state or local
governmental agency or any of Vendor's current or former applicants, agents, employees or
Subcontractors, or agents or employees of Vendor's Subcontractors arising out of the employment
relationship with Vendor, or otherwise with respect to performance under this Agreement, including
claims, charges and actions arising under Title VII of the Civil Rights Act of 1964, as amended, The
Equal Pay Act, the Age Discrimination in Employment Act, as amended, The Rehabilitation Act, the
Americans with Disabilities Act, as amended, the Fair Labor Standards Act, the Family and Medical
Leave Act, Workers' Compensation Laws, the National Labor Relations Act and any other applicable
Laws, including any liability, cause of action, lawsuit, penalty, claim, demand or administrative
proceeding in which AT&T or its Affiliates is named as or alleged to be an "employer" or "joint
employer" with Vendor as a result of this Agreement.

2.18 Excusable Delay. "Excusable Delay" means a delay in Vendor's performance or obligations with
respect to any Cell Site past any scheduled Delivery Date or Completion Date (including any
scheduled Completion Date for a Milestone, scheduled Completion Date for Location Acceptance or
scheduled Phase Completion Date set forth in the Build Addendum) that is caused by any of the
following events: (a) a Force Majeure Event affecting Vendor's performance with respect to such Cell
Site, subject to Section 3.12(b); (b) a Change Order that extends a Completion Date or Delivery Date
with respect to such Cell Site; (c) a Permitting Delay affecting such Cell Site, subject to the
process set forth in Section 3.3(b); (d) AT&T's failure to deliver the AT&T Provided Equipment (as
such term is defined in the Build Addendum) within sixty (60) days prior to the applicable Phase
Completion Date for such Cell Site; (e) any material defect, insufficiency, error or deficiency in
any AT&T Provided Equipment or other items supplied by AT&T under this Agreement; or (f) AT&T's
failure to satisfy any of the AT&T Task Service Level Agreements within the time periods set forth
on Schedule 14 to the Build Addendum. Upon the occurrence of any of the triggering events set forth
in clauses (a) through (f) causing a delay, such delay shall only be an Excusable Delay for the
number of days that such triggering event was in existence and the applicable Delivery Date or
Completion Date shall be extended on a day-for-day basis for the length of such triggering event.

2.19 FirstNet Authority. "FirstNet Authority" or "FNA" means the First Responder Network Authority.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 4

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 10 -->
2.20 Information. "Information", with respect to a Party, means all confidential, proprietary or
trade secret information, including discoveries, ideas, concepts, know-how, techniques, processes,
procedures, designs, specifications, strategic information, proposals, requests for proposals,
proposed products, drawings, blueprints, tracings, diagrams, models, samples, flow charts, data,
computer programs, marketing plans, Customer Information (including Internet activities, history,
and/or patterns of use), employee personal information, health or financial information,
authentication credentials, and other technical, financial or business information, whether
disclosed in writing, orally, or visually, in tangible or intangible form, including in electronic
mail or by other electronic communication.

2.21 Intellectual Property Rights. "Intellectual Property Rights" means all patents (including all
reissues, divisions, continuations, and extensions thereof) and patent applications, trade names,
trademarks, service marks, logos, trade dress, copyrights, trade secrets, mask works, rights in
technology, know-how, rights in content (including performance and synchronization rights), or other
intellectual property rights that are in each case protected under the Laws of any governmental
authority having jurisdiction.

2.22 Items. "Items" means any or all inventions, discoveries, ideas (whether patentable or not), and
all works and materials, including but not limited to products, devices, computer programs, source
codes, designs, files, specifications, texts, drawings, processes, data or other information or
documentation in preliminary or final form, and all Intellectual Property Rights in or to any of the
foregoing.

2.23 Laws. "Laws" includes all federal, state, provincial, regional, territorial and local laws,
statutes, ordinances, regulations, rules, executive orders, supervisory requirements, directives,
circulars, opinions, interpretive letters and other official releases of or by any governmental
authority.

2.24 Liability. "Liability" means all losses, damages, expenses, costs, penalties, fines and fees,
including Litigation Expenses, arising from or incurred in connection with a claim or cause of
action related to performance or omission of acts under this Agreement, including, but not limited
to, claims or causes of action brought by third parties.

2.25 Lien. "Lien" means any mortgage, lien, pledge, security interest, charge, claim, restriction or
other encumbrance of any nature whatsoever.

2.26 Litigation Expense. "Litigation Expense" means any court filing fee, court cost, arbitration
fee, and each other fee and cost of investigating or defending an indemnified claim or asserting any
claim for indemnification or defense under this Agreement, including Attorney's Fees, other
professionals' fees, and disbursements.

2.27 Loss. "Loss" means any Liability, loss, claim, demand, suit, cause of action, settlement
payment, cost, expense, interest, award, judgment, damage (including punitive damages), fine, fee,
penalty, and Litigation Expense.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 5

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 11 -->
2.28 Material. "Material" means all units of equipment, apparatus, components, tools, supplies,
material, structures, "as built" drawings, contract rights, Intellectual Property Rights or
Documentation, including third party materials provided or furnished by Vendor, that are
contemplated in this Agreement, the Build Addendum and the Maintenance Addendum (including all
schedules thereto), including all such items that are used in connection with the Build Services (as
such term is defined in the Build Addendum) provided hereunder or sold or transferred to AT&T in
connection with the Build Addendum, including all Vendor Provided Equipment set forth in the Build
Addendum. Material shall be deemed to include all rights to any replacement parts, but shall not be
deemed to include any rights to Vendor's transport network (other than the rights to receive
transport services in accordance with the terms of the Transport Agreement) or any tower or other
structure owned or leased by Vendor (other than the rights set forth in the Master License Agreement
and applicable Site License for any Vendor Cell Site or any Tower Lease for any Third Party Cell
Site).

2.29 Non-Service Affecting Defect. "Non-Service Affecting Defect" means any incorrect or incomplete
Cell Site (or any Material, Services or Deliverables relating thereto) or defect or issue of or
relating to a Cell Site that is not a Service Affecting Defect.

2.30 OEM. "OEM" means original equipment manufacturer.

2.31 Permits. "Permits" means all permits, licenses, franchises, approvals, authorizations,
registrations, certificates and variances required to be obtained from any federal, state, local or
foreign government or political subdivision thereof, or any agency or instrumentality of such
government or political subdivision.

2.32 Person. "Person" means an individual, corporation, limited liability company, partnership,
trust, association, joint venture, unincorporated organization or entity of any kind or nature, or a
governmental entity or authority.

2.33 Physical Entry. "Physical Entry" means that an individual (a) is permitted to bodily enter, on
an unsupervised (or badged) basis, into secured areas not available to the general public, or (b) is
permitted on a regular basis to have supervised or escorted bodily access into secured areas not
available to the general public for more than thirty (30) days in the aggregate annually.

2.34 Restricted Entities. "Restricted Entities" means [***].

2.35 Service Affecting Defect. "Service Affecting Defect" means any incorrect or incomplete
construction or maintenance by Vendor of a Cell Site (or any Material, Services or Deliverables
relating thereto) that, if not promptly corrected or completed, is reasonably likely to (i) be a
safety hazard to persons having access to a Cell Site, (ii) inhibit proper operation of a Cell Site
or satisfaction of the Quality Metrics or Specifications and key performance indicators set forth in
this Agreement, or (iii) prevent subsequent work required for "on-air" operation from taking place.
For the avoidance of doubt, a Service Affecting Defect shall not include regular or routine failures
of Material located at a Cell

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 6

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 12 -->
Site that are not a result of the construction or maintenance of such Cell Site by Vendor.

2.36 Services. "Services" means all of the services contemplated in the Build Addendum and the
Maintenance Addendum (and all schedules thereto).

2.37 Software. "Software" means any and all software (irrespective of whether it is Paid-For
Development) and firmware in any form (including source code and object code), as well as any
Documentation, licensed or otherwise provided by or on behalf of Vendor.

2.38 Specifications. "Specifications" means (i) all of the Build Out Specifications set forth in the
Build Addendum (and all schedules thereto, except as expressly waived by AT&T in writing), (ii) all
of the specifications set forth in the Maintenance Addendum (and all schedules thereto) with respect
to the Services contemplated therein, and (iii) all applicable OEM specifications.

2.39 Subcontractor. "Subcontractor" means any Person (including an agent) supplying labor or
materials to perform any or all of Vendor's obligations under this Agreement, including any Person
at any tier of subcontractors, and shall not be limited to those Persons with a direct relationship
with Vendor.

2.40 Suspend a Site, Suspend or Suspension. "Suspend a Site", "Suspend" or "Suspension" means Vendor
shall stop work on a Cell Site and not incur additional costs against the Cell Site and the
Completion Date is suspended until AT&T notifies Vendor to resume work or AT&T terminates this
Agreement with respect to such Cell Site.

2.41 System. "System" means the hardware, operating system and application Software, interfaces, and
databases that interact with Software.

2.42 Third Party Loss. "Third Party Loss" means any Loss or Liability resulting from or relating to
a claim or cause of action asserted by a third party.

2.43 Vendor Indemnified Parties. "Vendor Indemnified Parties" means Vendor and its Affiliates, as
well as their respective officers, directors, employees, representatives and agents, individually or
collectively, as the case may be, and all of their successors and assigns.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 7

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 13 -->
2.44 Vendor Person. "Vendor Person" means any officer, director, employee, representative, agent,
contractor or Subcontractor of Vendor and any officer, director, employee, representative or agent
of any Vendor contractor or Subcontractor.

2.45 Work. "Work" means all or any portion, as the case may be, of the Material, Deliverables and
Services that Vendor is supplying pursuant to this Agreement, including all Material, Deliverables,
Services and other Work contemplated in the Build Addendum and Maintenance Addendum (and all
schedules thereto).

2.46 Writing or Written. "Writing" or "Written" (whether or not capitalized) means a tangible
document with an original signature or an electronic transmission of data pursuant to the Electronic
Data Interchange ("EDI") Section of this Agreement.

3.0 General Terms

3.1 Affiliate. An Affiliate of AT&T may transact business under this Agreement. References to "AT&T"
herein are deemed to refer to any Person that qualifies as an Affiliate of AT&T under the definition
set forth in Section 2.1 when such Affiliate transacts business with Vendor under this Agreement;
provided that AT&T Mobility LLC shall be responsible for any and all obligations of any such
Affiliate under this Agreement.

3.2 Amendments and Waivers. The Parties may not amend this Agreement except by a written agreement
of the Parties that identifies itself as an amendment to this Agreement or by a Change Order
modifying the terms or conditions of this Agreement, which in either case is signed by both Parties,
or as otherwise expressly provided below in this Section. No waiver of any right or condition is
effective unless given in writing and signed by the Party waiving such right or condition. No delay
or omission by either Party to exercise any right or power it has under this Agreement shall impair
or be construed as a waiver of such right or power. A waiver by any Party of any breach, condition
or covenant shall not be construed to be a waiver of any succeeding breach or condition or of any
other covenant. All waivers must be in writing and signed by the Party waiving its rights.

3.3 Anticipated and Actual Delays in Delivery and Performance.

(a) Anticipated Delays. Upon discovery of information indicating that Material and/or Services will
not be Delivered by the scheduled Delivery Date or Completion Date (including any scheduled
Completion Date for a Milestone, scheduled Completion Date for Location Acceptance or scheduled
Phase Completion Date set forth in the Build Addendum) or other information causing Vendor to
reasonably anticipate a delay in its performance of its obligations beyond the scheduled Delivery
Date or Completion Date (collectively, the "Delay Information"), Vendor shall promptly notify AT&T
of such Delay Information and the estimated length of the anticipated delay. If Vendor desires to
request an extension of the applicable Delivery Date or Completion Date implicated by the Delay
Information, Vendor may submit a change request to AT&T in accordance with the Change Management
Plan. The Parties shall cooperate and work jointly in good faith toward resolving the delayed
Delivery or Completion or adopting the requested Change Order.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 8

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 14 -->
(b) Permitting Delays. Vendor shall timely, diligently and continuously pursue and use reasonable
best efforts to obtain as soon as possible any Permits required to be obtained in connection with or
in order to perform the Work and otherwise fulfill its obligations under this Agreement, the Build
Addendum and/or the Maintenance Addendum, including without limitation requesting assistance from
AT&T as appropriate. Upon Vendor's reasonable request for AT&T's assistance in obtaining any such
Permit, the Parties agree to cooperate in good faith to obtain such Permit. To the extent that
Vendor (x) has timely notified AT&T of related Delay Information contemplated in Subsection (a)
above, (y) has complied with this Section 3.3(b) and (z) is nevertheless unable to obtain or delayed
in obtaining a required Permit which is reasonably likely to result in Vendor missing a Delivery
Date or Completion Date (a "Permitting Delay"), then the Parties shall cooperate in good faith to
extend such Delivery Date or Completion Date and such Permitting Delay shall constitute an Excusable
Delay; provided, however that if the Parties cannot agree on a new Delivery Date or Completion Date
or in the event of a Permitting Delay preventing or delaying Vendor's performance which AT&T
determines is reasonably likely to cause a material delay of the ultimate Delivery Date or
Completion Date applicable to a Cell Site, AT&T may elect to, after consultation with Vendor and
good faith discussion to negotiate another resolution:

(i) terminate its obligations solely with respect to each Cell Site affected by or related to such
Permitting Delay under this Agreement and exercise any of the Termination Remedies set forth in the
Build Addendum, without liability to Vendor; provided that AT&T shall pay to Vendor, an amount equal
to the demonstrated costs incurred by Vendor for any Work completed (in accordance with applicable
Specifications and requirements) to the extent such Work is transferred to AT&T as of the effective
time of termination of the applicable terminated Cell Site, which amount shall not exceed $[***]; or

(ii) suspend this Agreement or any part hereof for the duration of such Permitting Delay (as such
period is reasonably determined by AT&T) solely with respect to any Cell Site affected by or related
to such Permitting Delay, obtain Work elsewhere (including AT&T's performance of the Work itself),
at AT&T's cost and expense (which shall reduce the Structured Payments applicable to such Cell Site
by such amount, but in no event shall such reduction cause the Structured Payments to be less than
an amount equal to the demonstrated costs incurred by Vendor up to the date of suspension), and
provide notice to Vendor when AT&T desires for Vendor to resume its performance under this Agreement
for the remaining Work at such Cell Site.

(c) Actual Delays. Except in the case of an Excusable Delay and subject to any applicable cure
period, in the event of any actual delay reasonably attributable to Vendor that causes Vendor to
miss a Delivery Date or Completion Date, Vendor will provide written notice to AT&T and if the
condition remains uncured after the expiration of any applicable cure period set forth in this
Agreement, the Build Addendum and/or the Maintenance Addendum, AT&T may exercise any remedies
available to AT&T under this Agreement, the Build Addendum and/or the Maintenance Addendum, as
applicable.

3.4 Anticorruption Laws. Vendor hereby represents and warrants that the employees, agents,
consultants, partners, officers, directors, members or representatives of Vendor and its

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 9

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 15 -->
Subcontractors, if any, performing Services or other activities under this Agreement (each and any
of the foregoing individuals, for the purpose of this Section, a "Vendor Representative") shall
comply with the US Foreign Corrupt Practices Act and all applicable anticorruption laws (including
commercial bribery laws). Vendor Representatives shall not directly or indirectly pay, offer, give,
promise to pay or authorize the payment of any portion of the compensation received in connection
with this Agreement or any other monies or other things of value in connection with its performance
to a Government Official, as such term is defined below, to obtain or retain business or secure any
improper advantage nor shall it permit such actions by a third party in connection with this
Agreement. For purposes of this Section, "Government Official" means: (i) an officer or employee of
any government or any department, agency, or instrumentality thereof, including government-owned or
government-controlled commercial entities; (ii) an officer or employee of a public international
organization; (iii) any person acting in an official capacity for or on behalf of any government or
department, agency, or instrumentality or public international organization; (iv) any political
party or official thereof; (v) any candidate for political office; or (vi) any other Person at the
suggestion, request or direction or for the benefit of any of the above-described Persons.

3.5 Assignment and Delegation; Change of Control.

(a) Neither Party may assign, delegate, or otherwise transfer any of its duties or obligations under
this Agreement, voluntarily or involuntarily, without the prior written consent of the other Party
(which shall not be unreasonably withheld, conditioned or delayed and which shall be signed by an
authorized representative of the Party giving such consent); provided, however, that without the
consent of Vendor, AT&T may assign its rights, or delegate its duties, or both, in whole or in part,
to any present or future Affiliate of AT&T so long as AT&T Mobility LLC shall remain liable for such
Affiliate's failure to satisfy its obligations hereunder.

(b) Each Party may assign its rights under the Agreement, but any assignment of rights will be void
to the extent that (i) the assignment purports to impose upon the non-assigning Party additional
costs or obligations or requires AT&T to make payments to any Person other than Vendor, (ii) the
assignment purports to preclude AT&T from dealing solely and directly with Vendor in all matters
pertaining to this Agreement, including with respect to payments of Structured Payments and
Maintenance Fees or (iii) the assignee is a Restricted Entity.

(c) Subject to Section 3.5(b), in the event that Vendor, prior to Location Acceptance at all Cell
Sites and without the prior written consent of AT&T, consummates (i) any sale, assignment, transfer,
license, lease or conveyance of any interest in any Cell Site or any of the Material or Services
contemplated in this Agreement or (ii) any Change of Control of Vendor to a Restricted Entity or to
any other Person who, in AT&T's reasonable discretion, lacks the financial or operational resources,
skill or expertise to fulfill the obligations of Vendor contemplated by this Agreement, then AT&T
may terminate this Agreement and exercise any other remedies available to AT&T under this Agreement
or at law or equity, including any of its Termination Remedies set forth in the Build Addendum. If,
following Location Acceptance of all Cell Sites, Vendor consummates any Change of Control of Vendor
to any Restricted Entity without the prior written consent of AT&T, then AT&T shall have the right,
in its sole

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 10

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 16 -->
discretion, to (x) immediately terminate the Maintenance Addendum without further liability or
obligation (other than payment of Maintenance Fees for Maintenance Services performed prior to the
date of such termination), but not this Agreement or the obligation to make the Structured Payments
herein; and/or (y) prepay all of the remaining Structured Payments at any time in one lump sum
payment without penalty, liability or obligations (including any "make- whole" obligation or
Close-Out Costs (as such term is defined in the Build Addendum)).

(d) Any assignment, delegation or transfer for which consent is required hereby and which is made
without such consent given in writing will be void. No assignment by a Party will relieve such Party
of its obligations under this Agreement.

3.6 Compliance with Laws. Vendor shall comply with all Laws applicable to Vendor's performance under
this Agreement, including all Work contemplated herein and all Material, Services and Deliverables
provided hereunder, and AT&T's utilization of the Cell Sites. Vendor shall procure all approvals,
bonds, certificates, insurance, inspections, licenses, and permits that such Laws require for the
performance of this Agreement. Vendor shall create and maintain any necessary records and provide
any certificate, affidavit or other information or documentation requested or as otherwise required
by AT&T: (a) to show compliance by Vendor and its Subcontractors with Laws, (b) to comply or
otherwise establish AT&T's compliance with Laws or (c) to allow AT&T to timely respond to any
complaints, filings, or other proceedings.

3.7 Conflict of Interest. Vendor represents and warrants that, to its knowledge, no officer,
director, employee or agent of AT&T has been or will be employed, retained or paid a fee, or
otherwise has received or will receive, any personal compensation or consideration, by or from
Vendor or any of Vendor's officers, directors, employees or agents in connection with the obtaining,
arranging or negotiation of this Agreement or other documents entered into or executed in connection
with this Agreement.

Vendor shall not offer or give gratuities in the form of gifts, entertainment, concessions, or
otherwise to AT&T or its employees or representative(s), or any person related by blood or marriage
to such individuals for the express or implied purpose of obtaining or securing favorable treatment
with respect to this Agreement, or in the inspection or acceptance of the Services to be performed
thereunder. Vendor shall not engage in any conduct which will constitute or appear to constitute a
conflict of interest between Vendor's responsibility to AT&T under this contract and Vendor's
responsibility to any person, business, or other entity with which Vendor may have had any dealings.

3.8 Construction and Interpretation

(a) This Agreement has been prepared jointly and has been the subject of arm's length and careful
negotiation. Each Party has been given the opportunity to independently review this Agreement with
legal counsel and other consultants, and each Party has the requisite experience and sophistication
to understand, interpret and agree to the particular language of its provisions. Accordingly, the
drafting of this Agreement is not to be attributed to either Party.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 11

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 17 -->
(b) Article, Section and paragraph headings contained in this Agreement are for reference purposes
only and are not to affect the meaning or interpretation of this Agreement. The word "include" in
every form means to include without limitation by virtue of enumeration and a derivative of a
defined term shall have the meaning appropriate to the context of its use. Whenever this Agreement
refers to a consent or approval to be given by either Party, unless such consent is expressly
required to be given in writing and signed by the Party giving approval or consent, then such
consent or approval is effective if given in an email from the individuals identified in Section
3.26 or designated by Vendor as its Project Manager pursuant to Section 18 of the Build Addendum.
The Parties agree that time is of the essence with respect to AT&T's approval rights pursuant to
this Agreement and the Build Addendum and Maintenance Addendum and Vendor is relying on the
timeliness of such approvals or consents as set forth herein in order to complete the Services. The
use of singular words includes the plural and vice versa.

3.9 Cumulative Remedies. The rights and remedies of the Parties set forth in this Agreement are not
exclusive of, but are cumulative to, any rights or remedies now or subsequently existing at law, in
equity, by statute or otherwise, except in those cases where this Agreement specifies that a
particular remedy is sole or exclusive, but neither Party may retain the benefit of inconsistent
remedies. No single or partial exercise of any right or remedy with respect to one breach of this
Agreement precludes the simultaneous or subsequent exercise of any other right or remedy with
respect to the same or a different breach.

3.10 Delivery, Performance and Acceptance

(a) Vendor acknowledges that AT&T is responsible for the deployment of the FirstNet Nationwide
Public Safety Broadband Network (the "NPSBN") in accordance with the terms of AT&T's agreement with
the FirstNet Authority and that AT&T has provided certain terms of such agreement to Vendor but has
not provided Vendor with a copy of such agreement with the FirstNet Authority. Therefore, Vendor
understands generally that AT&T's business requires prompt Delivery of Material and provision of
Services by the specified Delivery Dates. Furthermore, the Parties agree that dates for Delivery of
Material and Services are firm subject to any Excusable Delay, time is of the essence, and, subject
to any Excusable Delay, Vendor will complete such Delivery in strict conformance with the
Specifications.

(b) Vendor shall perform or cause to be performed testing sufficient to ensure that all of the
Material and Deliverables perform in accordance with the Specifications, including all of the Cell
Site optimization and testing contemplated by the Build Addendum. If testing indicates that any of
the Cell Sites (or any of the Material or Deliverables relating thereto) does not conform to the
Specifications, then Vendor shall notify AT&T, in writing, of such non- conformance promptly
following Vendor's knowledge of such non- conformance. AT&T will advise Vendor whether Vendor should
Deliver the non-conforming Cell Site or any of the Deliverables or Material relating thereto. In the
event AT&T and Vendor agree in a signed writing to Deliver non-conforming Cell Sites or any of the
Deliverables or Material relating thereto ("Provisional Location Acceptance"), Vendor shall use all
commercially reasonable efforts promptly to cure any such non- conformance after Provisional
Location Acceptance of

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 12

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 18 -->
the non-conforming Cell Site; provided, however, that if Vendor has not cured all such non-
conformance with respect to the Cell Site within nine (9) months following Provisional Location
Acceptance (or sixty (60) days if the non-conformance is caused by the existence of a Lien, and in
each case subject to an Excusable Delay), then AT&T may elect in its sole discretion, to complete
any outstanding work, and recoup any costs by an offset against the Maintenance Fees due to Vendor
for all Cell Sites. If such non-conforming Cell Site has not been cured within such nine (9) month
cure period (or 60-day cure period in the case of a Lien), AT&T shall have no further obligation to
pay any Maintenance Fees to Vendor with respect to such non-conforming Cell Site until the
non-conformance has been cured. Provisional Location Acceptance of any such non-conforming Cell Site
or receipt of any of the Deliverables or Material relating thereto shall not constitute Location
Acceptance and shall not constitute a waiver of any of AT&T's rights, warranties, or remedies under
this Agreement or elsewhere, including Termination Remedies under the Build Addendum. Location
Acceptance of any such non-conforming Cell Site shall not occur until all non-conformance has been
cured; provided, that AT&T shall begin making Structured Payments for such Cell Site upon
Provisional Location Acceptance in the same manner as if it were Location Acceptance.

(c) In no event shall Location Acceptance be deemed to occur absent a signed writing from AT&T prior
to the date Vendor completes its Delivery of all Material and Services in accordance with the
Specifications related to the Cell Site as required by the Build Addendum.

(d) If AT&T advises Vendor of, or Vendor becomes aware of a landlord complaint, Vendor shall, if
necessary, promptly respond to the landlord complaint, shall commence any agreed upon corrections
promptly, and shall diligently pursue the same until completion.

(e) In addition to the provisions set forth in this Section, AT&T shall be able to exercise any or
all remedies available to it under the Build Addendum and Maintenance Addendum.

3.11 Entire Agreement. Except to the extent otherwise expressly referenced herein, including the
matters set forth in the Transport Agreement and the Master License Agreement, this Agreement and
all addendums, appendices, exhibits, attachments, schedules and documents incorporated herein by
reference, constitutes the final, complete, and exclusive expression of the Parties' agreement on
the matters contained in this Agreement. The terms of this Agreement shall govern in lieu of all
other pre-printed, standardized or other provisions that may otherwise appear in any other paper or
electronic record of either Party (such as standard terms on order or acknowledgment forms, advance
shipping notices, invoices, time sheets, and packages, shrink wrap terms, and click wrap terms).
Except to the extent set forth in the Transport Agreement and the Master License Agreement, all
prior written and oral negotiations and agreements, and all contemporaneous oral negotiations and
agreements, between the Parties on the matters contained in this Agreement are expressly merged into
and superseded by this Agreement. The Parties do not intend that the provisions of this Agreement be
explained, supplemented, or qualified through evidence of trade usage or any prior course of
dealings or any course of performance under any prior agreement. In entering into this Agreement,
neither Party has relied upon any statement, estimate, forecast, projection, representation,
warranty, action or agreement of the other Party except for those expressly contained in this
Agreement. There are no

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 13

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 19 -->
conditions precedent to the effectiveness of this Agreement other than any such condition expressly
stated in this Agreement.

3.12 Force Majeure

(a) Except for AT&T's obligations to make the Structured Payments and pay the Maintenance Fees, a
Party is excused from performing its obligations under this Agreement only if, to the extent that,
and for so long as such Party's performance is actually prevented or delayed by acts of God or the
public enemy, acts of civil or military authority, terrorists acts, embargoes, epidemics, war,
riots, insurrections, fires, explosions, earthquakes, floods, and weather events that are beyond its
reasonable control and could not have been prevented or avoided by its exercise of due diligence and
such Party gives written notice to the other Party, as soon as practicable under the circumstances,
of the act or event that so prevents such Party from performing its obligations (each, a "Force
Majeure Event"). After Vendor provides written notice to AT&T of any Force Majeure Event in
accordance with the preceding sentence, the Parties shall extend the applicable Delivery Date or
Completion Date for the length of such Force Majeure Event and, subject to Subsection (b) below,
such Force Majeure Event shall be an Excusable Delay.

(b) If Vendor is the Party whose performance is prevented or delayed by a Force Majeure Event and
AT&T determines that the Force Majeure Event is reasonably likely to cause a material delay of the
ultimate Delivery Date or Completion Date for any Cell Site, then AT&T may elect to, after
consultation with Vendor and good faith discussion to negotiate another resolution:

(i) terminate its obligations with respect to each Cell Site affected by or related to such Force
Majeure Event under this Agreement and exercise any of the Termination Remedies set forth in the
Build Addendum, in each case without liability to Vendor; provided that AT&T shall pay to Vendor, an
amount equal to demonstrated costs incurred by Vendor for any Work completed (in accordance with
applicable Specifications and requirements) to the extent such Work is transferable to and usable by
AT&T as of the effective time of termination of the applicable terminated Cell Site, which amount
shall not exceed $[***]; or

(ii) suspend this Agreement or any part hereof for the duration of such Force Majeure Event solely
with respect to any Cell Site affected by or related to such Force Majeure Event, obtain Work
elsewhere (including AT&T's performance of the Work itself), at AT&T's cost and expense (which shall
reduce the Structured Payments applicable to such Cell Site by such amount, but in no event shall
such reduction cause the Structured Payments to be less than an amount equal to the demonstrated
costs incurred by Vendor up to the date of suspension), and provide notice to Vendor when AT&T
desires for Vendor to resume its performance under this Agreement for the remaining Work at such
Cell Site.

3.13 Government Contract Provisions and Flow Downs

(a) To the extent that Vendor's performance is required to comply with certain executive orders
(including E.O. 11246 and E.O. 13201) and statutes (including Section 503 of the

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 14

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 20 -->
Rehabilitation Act of 1973, as amended; the Vietnam Era Veteran's Readjustment Assistance Act of
1974; Section 8116 of the Defense Appropriations Act for Fiscal Year 2010 (Pub. L. 111-118); and the
Jobs for Veterans Act) pertaining to government contractors, Vendor shall:

(i) comply with such executive orders and statutes, and their implementing regulations, as amended
from time to time; and

(ii) fulfill the obligations of a contractor under the clauses incorporated by this Section,

in each case, to the extent that Vendor's Services are required to comply with such rules and
regulations.

(b) This Section incorporates the following statutes and rules:

(i) "Affirmative Action For Workers With Disabilities" (at 48 CFR §52.222-36); (ii) "Employment
Reports On Special Disabled Veterans, Veterans Of The Vietnam Era, and Other Eligible Veterans" (at
48 CFR §52.222-37); (iii) "Equal Employment Opportunity" (at 48 CFR §52.222-26); (iv) "Equal
Employment Opportunity Clause" (at 41 CFR §60-1.4(a)); (v) "Equal Opportunity For Special Disabled
Veterans And Veterans of the Vietnam Era" (at 41 CFR §60- 250.5); (vi) "Equal Opportunity for
Disabled Veterans, Recently Separated Veterans, Other Protected Veterans, and Armed Forces Service
Medal Veterans" (at 41 CFR §60- 300.5); (vii) "Equal Opportunity For Workers With Disabilities" (at
41 CFR §60-741.5); (viii) "Prohibition of Segregated Facilities" (at 48 CFR §52.222-21); (ix) "Small
Business Subcontracting Plan" (at 48 CFR §52.219-9); (x) "Utilization Of Small Business Concerns"
(at 48 CFR §52.219-8); (xi) "Whistleblower Protections Under the American Recovery and Reinvestment
Act of 2009" (FAR 52.203-15); (xii) "American Recovery and Reinvestment Act - Reporting
Requirements" (FAR 52.204- 11); (xiii) "GAO/IG Access" (FAR 52.212-5(d) (Alt. II), FAR 52.214-26(c)
(Alt. I), FAR 52.215- 2(d) (Alt. I)); (xiv) "Davis-Bacon Act" (FAR 52.222-6); (xv) "Buy American
Act" (FAR 52.225-21, FAR 52.225-22, FAR 52.225-23, & FAR 52.225-24); (xvi) "Whistleblower
Protections" (Pub. L. No. 111-5, Section 1553); (xvii) "Award term—Reporting and registration
requirements under section 1512 of the Recovery Act" (2 CFR §176.50); (xviii) "GAO/IG Access" (Pub.
L. No. 111-5, Section 902, 1514 and 1515); (xix) "Award term—Wage Rate Requirements under Section
1606 of the Recovery Act" (2 CFR §176.190); and (xx) "Buy American Requirements" (2 CFR §176.140, 2
CFR §176.150, 2 CFR §176.160, & 2 CFR §176.170).

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 15

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 21 -->
(c) Vendor agrees to comply with all Government Flow Downs and Contract Clauses to the extent
applicable to Vendor's performance as specifically required by that certain contract awarded to an
Affiliate of AT&T by the FirstNet Authority regarding the FirstNet Nationwide Public Safety
Broadband Network (the "FirstNet Agreement") and such Government Flow Downs and Contract Clauses
that may be applicable are attached to this Agreement as Exhibit A, the terms of which are hereby
fully incorporated into the Agreement.

3.14 Governing Law. The laws of the State of New York (excluding any laws that direct the
application of another jurisdiction's law) govern all matters arising out of or relating to this
Agreement and all of the transactions it contemplates, including its validity, interpretation,
construction, performance, and enforcement.

3.15 Indemnity

(a) Except for Covered Losses that are exclusively provided for in the Section entitled
"Infringement," Vendor shall indemnify, hold harmless, and defend the AT&T Indemnified Parties, in
accordance with this Section, against any Third Party Loss arising from, or in connection with, or
resulting from, (i) any default, violation, breach or nonperformance by Vendor or any Vendor Person
of Vendor's representations, warranties, covenants and obligations under this Agreement, the Build
Addendum or the Maintenance Addendum, (ii) the Deliverables, Material or Services furnished by
Vendor or any Vendor Person and the use, construction, maintenance, operation or occupancy of any
Cell Site by Vendor or any Vendor Person, (iii) the negligent or willful acts or omissions of Vendor
and each Vendor Person with respect to this Agreement or (iv) Employment Claims. Subject to AT&T's
obligation to reimburse or indemnify Vendor as set forth in Subsection (c) or (d) below,
respectively, Vendor's duty to indemnify, hold harmless, and defend the AT&T Indemnified Parties
against any Third Party Loss extends to any Third Party Loss that may be caused or alleged to be
caused in part by the negligence of any of the AT&T Indemnified Parties to the fullest extent that
such indemnification is permitted by applicable Law.

(b) AT&T shall promptly notify Vendor in writing of any claim, demand, suit, cause of action or
legal proceeding that may give rise to a claim against Vendor for defense and indemnification under
this Section 3.15. If AT&T fails to give notice, Vendor is still obligated to indemnify, hold
harmless and defend the AT&T Indemnified Parties, except that Vendor is not liable for any
Litigation Expense that AT&T incurs before the time when notice is given or for any Loss or
Liability to the extent that Vendor can show that such delay or failure to provide notice actually
and materially prejudiced it in defending against such Loss or Liability.

(c) Vendor shall conduct the defense (employing one or more competent attorneys from a nationally
recognized law firm), at Vendor's expense, against any claim, demand, suit or cause of action within
the scope of Subsection (a) above, whether or not litigation is actually commenced or the
allegations are meritorious and, upon AT&T's request, keep AT&T informed as to the progress of such
defense. At its own option and expense, AT&T may employ separate counsel, including in- house
counsel, to conduct the AT&T

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 16

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 22 -->
Indemnified Parties' defense against such a claim. AT&T and Vendor shall cooperate in the defense of
any such claim. Vendor may control the defense and settlement of such a claim, but if the settlement
of a claim may have an adverse effect on any of the AT&T Indemnified Parties, then Vendor shall not
settle such claim without the consent of AT&T, and AT&T shall not unreasonably withhold, condition
or delay its consent. To the extent that Vendor pays any part of a judgment, award or settlement
with respect to the Third Party Loss and any other expenses related to the resolution of the Third
Party Loss, including costs, interest, and Attorneys' Fees, as a result of being self-insured
(including any deductible) or as a result of insurance coverage being insufficient to cover the
amount of the judgment, award or settlement, upon final resolution of the claim, demand, suit or
cause of action, AT&T shall reimburse Vendor for the pro-rata portion of any such payment based on
the AT&T Indemnified Parties' fault relative to Vendor's fault.

(d) In addition to AT&T's obligation to reimburse Vendor as set forth in Subsection (c) above, AT&T
shall indemnify, hold harmless and defend the Vendor Indemnified Parties against any Third Party
Loss arising solely from or in connection with, resulting solely from, or relating solely to (i) the
AT&T Provided Equipment furnished by AT&T or (ii) the negligent or intentionally wrongful acts or
omissions of any of the AT&T Indemnified Parties under this Agreement; in each case in the same
manner as set forth in Subsection (b) and in the first four sentences of Subsection (c), with the
appropriate changes having been made.

(e) Subject to AT&T's obligation to reimburse or indemnify Vendor as set forth in Subsection (c) and
(d) above, respectively, Vendor shall bring no claim or action for indemnification, contribution, or
subrogation against any of the AT&T Indemnified Parties nor shall Vendor implead any of them in any
action brought by another, based on injury to the person or death arising out or relating to
Vendor's performance under this Agreement. If, through any such action, Vendor ever acquires a Lien
on a judgment against any of the AT&T Indemnified Parties, then Vendor shall assign such Lien to
AT&T. Vendor waives any immunity from indemnification (only with respect to the AT&T Indemnified
Parties) that Vendor may hold, by virtue of Vendor's compliance with its workers' compensation
obligations in any jurisdiction, even if such immunity arises under the constitution or statutes of
such jurisdiction.

(f) Notwithstanding anything to the contrary contained in this Section, the Parties intend that any
amount for which any of the AT&T Indemnified Parties might otherwise have an obligation of
reimbursement to Vendor for its pro-rata portion pursuant to this Section will be net of any
insurance proceeds or other amounts paid by Vendor's insurance company ("Insurance Proceeds") that
actually reduce the amount that Vendor is required to pay on account of a Third Party Loss.
Accordingly, the amount with respect to which AT&T is required to reimburse Vendor its pro-rata
portion will be reduced by any Insurance Proceeds theretofore actually paid on behalf of Vendor in
respect of the related Third Party Loss. If Vendor receives a reimbursement required by this Section
from AT&T in respect of the AT&T Indemnified Parties' pro-rata share

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 17

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 23 -->
of the amount of any Third Party Loss and subsequently receives Insurance Proceeds or the benefit of
any payments made for Vendor or on its behalf by any insurance company or other entity with respect
to such Third Party Loss, then Vendor will pay to AT&T, within fifteen (15) days after such receipt
of Insurance Proceeds or benefit of any payments, an amount equal to the excess of the reimbursement
that Vendor received from AT&T over the amount of the reimbursement that would have been due under
this Section from AT&T if the Insurance Proceeds had been received, realized or recovered before the
reimbursement was made by AT&T. An insurer that would otherwise be obligated to pay any amount as a
result of a Third Party Loss shall not be relieved of the responsibility with respect thereto or, by
virtue of the indemnification or reimbursement provisions hereof, have any subrogation rights with
respect thereto, it being expressly understood and agreed that no insurer or any other third party
shall be entitled to a "wind-fall" (i.e., a benefit they would not be entitled to receive in the
absence of the indemnification provisions) by virtue of the indemnification or reimbursement
provisions hereof. Vendor shall have a good faith obligation to seek, and AT&T shall provide its
reasonable cooperation to Vendor in its efforts, to collect or recover any Insurance Proceeds that
may in any way be available to reduce the amount of any Third Party Loss.

3.16 Information

(a) In connection with this Agreement, including Vendor's performance of its obligations hereunder
and AT&T's receipt of Work, either Party may find it beneficial to disclose to the other Party
(which may include permitting or enabling the other Party's access to) certain of its Information.
For the purpose of this clause, AT&T's disclosure of Information to Vendor includes any Information
that Vendor receives, observes, collects, stores, or accesses, in any way, in connection with this
Agreement and all such Information disclosed by AT&T hereunder shall be and shall remain the sole
and exclusive property of AT&T. Information of a disclosing Party shall be deemed to be confidential
or proprietary only if it is clearly marked or otherwise identified by the disclosing Party as being
confidential or proprietary, provided that if it is orally or visually disclosed (including
Information conveyed to an answering machine, voice mail box or similar medium), the disclosing
Party shall designate it as confidential or proprietary at the time of such disclosure, however,
failure to do so shall not prevent such Information from receiving the protections afforded to it in
this Section 3.16. Notwithstanding the foregoing, a disclosing Party shall not have any such
obligation to so mark or identify, or to so designate, Information that the disclosing Party
discloses to or is otherwise obtained by the other Party's employees, contractors, or
representatives (i) who are located on the disclosing Party's premises; (ii) who access the
disclosing Party's systems; or (iii) who otherwise obtain AT&T Information and/or AT&T Customer
Information in connection with this Agreement; any such Information so disclosed shall automatically
be deemed to be confidential and proprietary. Additionally, the failure to mark or designate
information as being confidential or proprietary will not waive the confidentiality where it is
reasonably obvious, under the circumstances surrounding disclosure, that the Information is
confidential or proprietary; any such Information so disclosed or obtained shall automatically be
deemed to be confidential and proprietary. For greater certainty, Information provided by either
Party to the other Party prior to the Effective Date of this Agreement in connection with a separate

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 18

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 24 -->
non-disclosure agreement (howsoever denominated) is also subject to the terms of this Agreement.
Neither Party shall disclose Information under this Agreement that includes, in any form, any of the
following: customer or employee personal information, credit card and credit related information,
health or financial information, and/or authentication credentials, without the express consent of
the disclosing Party, which consent shall be in writing and signed by the disclosing party.

(b) With respect to the Information of the disclosing Party, the receiving Party shall:

(i) hold all such Information in confidence with the same degree of care with which it protects its
own confidential or proprietary Information, but with no less than reasonably prudent care;

(ii) restrict disclosure of such Information solely to its and its Affiliates' employees,
contractors, directors, advisors, financing sources and agents with a need to know such Information,
advise such persons of their confidentiality obligations with respect thereto, and ensure that such
persons are bound by obligations of confidentiality reasonably comparable to those imposed in this
Agreement;

(iii) use such Information only as needed to perform its obligations (and, if AT&T is the receiving
Party, to receive the benefits of the Work provided) under this Agreement;

(iv) except as necessary under the immediately preceding Subsection (iii), not copy, distribute, or
otherwise use any such Information or allow anyone else to copy, distribute, or otherwise use such
Information; and ensure that any and all copies bear the same notices or legends, if any, as the
originals; and

(v) upon the disclosing Party's request, promptly return, or destroy all or any requested portion of
the Information, including tangible and electronic copies, notes, summaries, extracts, mail or other
communications, and provide written certification within fifteen (15) business days to the
disclosing Party that such Information has been returned or destroyed; provided, however, that (i)
the receiving Party may retain copies of such documents and other tangible embodiments of
Information as required by applicable Law to which the receiving Party is subject and (ii) the
receiving Party shall have no obligation to destroy or delete electronic copies of, or material
containing, Information that are automatically generated through data backup and/or archiving
systems and that are not readily accessible by the receiving Party's business personnel.
Notwithstanding the expiration or termination of this Agreement or any return or destruction of
Information, all Information, including without limitation that as may be retained in accordance
with the above-referenced exceptions, will continue to be subject to the provisions of this Section
3.16 for so long as such Information remains in the custody or control of the receiving Party.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 19

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 25 -->
(c) Except for Customer Information, neither Party shall have any obligation to the other Party with
respect to Information which:

(i) at the time of disclosure was already known to the receiving Party free of any obligation to
keep it confidential (as evidenced by the receiving Party's written records prepared prior to such
disclosure);

(ii) is or becomes publicly known through no wrongful act of the receiving Party (such obligations
ceasing at the time such Information becomes publicly known);

(iii) is lawfully received from a third party, free of any obligation to keep it confidential;

(iv) is independently developed by the receiving Party or a third party, as evidenced by the
receiving Party's written records, and where such development occurred without any direct or
indirect use of or access to the Information received from the disclosing Party, or

(v) the disclosing Party consents in writing to be free of restriction.

(d) If a receiving Party is required to provide Information of a disclosing Party to any court or
government agency pursuant to a written court order, subpoena, regulatory demand, request under the
National Labor Relations Act (an "NLRA Request"), or process of law, the receiving Party must,
unless prohibited by applicable Law, first provide the disclosing Party with prompt written notice
of such requirement and reasonable cooperation to the disclosing Party should it seek protective
arrangements for the production of such Information. The receiving Party will (i) take reasonable
steps to limit any such provision of Information to the specific Information required by such court
or agency, and (ii) continue to otherwise protect all Information disclosed in response to such
order, subpoena, regulation, NLRA Request, or process of law.

(e) A receiving Party's obligations with respect to any particular Information of a disclosing Party
shall remain in effect and survive the expiration or termination of this Agreement for a period of
five (5) years thereafter. Notwithstanding anything to the contrary herein, Customer Information and
trade secrets shall remain confidential indefinitely and shall never be disclosed or used without
the prior written approval of an authorized representative of AT&T.

(f) Notwithstanding anything to the contrary in this Agreement (including in this Section), Vendor
understands and acknowledges that Vendor information related to installation, operation, repair, or
maintenance shall not be considered confidential or proprietary, and AT&T may disclose any such
information for purposes of installing, operating, repairing, replacing, removing, and maintaining
the Material.

(g) Notwithstanding anything to the contrary contained in this Agreement (including in this
Section), AT&T may disclose the existence of this Agreement and the FirstNet-related terms contained
herein and high level confidential information (excluding fees and specific terms and conditions) to
relevant employees of the FirstNet Authority and any state, county, city, or

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 20

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 26 -->
other locality in which the Cell Sites that are to be built in accordance with this Agreement and
the Build Addendum will be located.

3.17 Infringement

(a) Definitions. For purposes of this Section:

(i) "Infringement Loss" shall mean any Liability, loss, claim, demand, suit, cause of action,
settlement payment, cost, expense, interest, award, judgment, damages (including punitive and
exemplary damages and increased damages for willful infringement), Liens, fines, fees, penalties,
and Litigation Expense.

(ii) "Provided Elements" shall mean any Material, Services or Deliverables or other products,
hardware, software, interfaces, systems, content, services, processes, methods, documents,
materials, data or information, or any functionality therein, provided to any AT&T Indemnified Party
by or on behalf of Vendor (including by any of Vendor's Subcontractors or distributors or any Vendor
Person) pursuant to this Agreement (including under any addendum, order, statement of work, exhibit,
schedule or other document under, subordinate to, or referencing this Agreement); provided, however,
that Provided Elements shall not include any AT&T Provided Equipment.

(b) Obligations.

(i) Vendor shall indemnify, hold harmless, and defend (which shall include cooperating with AT&T as
set forth below in the defense of) each of the AT&T Indemnified Parties against any Infringement
Loss or other Liability resulting from, arising out of or relating to any allegation, threat,
demand, claim or lawsuit brought by any third party ("Covered Claim"), regardless of whether such
Covered Claim is meritorious, of:

1. infringement (including direct, contributory and induced infringement) of any patent, copyright,
trademark, service mark, or other Intellectual Property Right in connection with the Provided
Elements, including any Covered Claim of infringement based on:

A. making, repair, receipt, use, importing, sale or disposal (and offers to do any of the foregoing)
of Provided Elements (or having others do any of the foregoing, in whole or in part, on behalf of or
at the direction of the AT&T Indemnified Parties), or

B. use of Provided Elements in combination with products, hardware, software, interfaces, systems,
content, services, processes, methods, documents, materials, data or information not furnished by
Vendor, including use in the form of the making, having made or using of an apparatus or system, or
the making or practicing of a process or method unless the function performed by the Provided
Elements in such combination is of a type that is neither normal nor reasonably anticipated for such
Provided Elements (a "Combination Claim");

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 21

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 27 -->
2. misappropriation of any trade secret, proprietary or non-public information in connection with
the Provided Elements;

any and all such Infringement Loss or other Liabilities referenced in this Subsection (b)(i) being
hereinafter referred to as a "Covered Loss."

(ii) Insofar as Vendor's obligations under Subsection (b)(i) result from, arise out of, or relate to
a Covered Claim that is a Combination Claim, Vendor shall be liable to pay only its Proportionate
Share of the Covered Loss associated with such Combination Claim. The "Proportionate Share" payable
by Vendor shall be a portion of the Covered Loss determined, not at AT&T's sole discretion, but
rather on an objectively fair and equitable basis (taking into account the relevant facts and
circumstances and using the same standards that would be applied by a court or other neutral
adjudicator under applicable Law) to be attributable to Vendor based on the relative materiality of
the role played by the applicable Provided Elements in the Combination Claim. If Vendor believes
AT&T's assessment of Vendor's Proportionate Share is not fair and equitable, then Vendor's
Proportionate Share shall be determined, insofar as possible, through good faith negotiation between
the Parties; provided, however, that a failure of the Parties to agree on Vendor's Proportionate
Share shall not relieve Vendor of its obligations to pay its Proportionate Share under this Section.
Vendor shall make payments in satisfaction of its Proportionate Share obligation whenever such
payments become due. In no event shall Vendor be liable, with regard to a Combination Claim, for
more than its Proportionate Share. If the Parties cannot mutually agree on Vendor's Proportionate
Share within sixty (60) days of AT&T's providing Vendor with AT&T's assessment of Vendor's
Proportionate Share, either Party may notify the other Party that a dispute has occurred, at which
point the Parties shall follow the dispute resolution procedures set forth in Section 4.8 ("Dispute
Resolution"), provided that in preparation for the escalation set forth in Section 4.8(a), Vendor
shall notify AT&T in writing of the percentage which Vendor believes, in good faith, constitutes
Vendor's Proportionate Share ("Vendor's Minimum Share"). If arbitration is invoked under Section
4.8(b), all arbitrators shall be qualified by education, training, and experience in both the
intellectual property law (e.g., patent law) and the technology relevant to any dispute under this
Section. Throughout the course of attempting to resolve the dispute, Vendor shall continue to pay
Vendor's Minimum Share to AT&T as such payments become due. When Vendor's Proportionate Share is
finally determined (either through escalation or arbitration, as the case may be) ("Determined
Proportionate Share"), there shall be a true-up and Vendor shall promptly pay to AT&T the aggregate
amount of past underpayments (i.e., the difference between monies previously due computed at the
Determined Proportionate Share, minus those amounts that Vendor had actually paid to AT&T), if any.
Thereafter, Vendor shall promptly pay its Determined Proportionate Share. (In the event that the
Determined Proportionate Share is less than the Vendor's Minimum Share, AT&T shall refund to Vendor
any past overpayments.) In no event shall AT&T's acceptance of payments computed at Vendor's Minimum
Share prejudice or waive any of AT&T's rights under this Agreement.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 22

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 28 -->
(iii) AT&T shall have sole control over the defense of (1) any Combination Claim and (2) any other
Covered Claim that involves Vendor and one or more other suppliers of AT&T or its Affiliates ((1)
and (2) being hereinafter referred to separately and collectively as a "Compound Claim"). Vendor
shall cooperate with AT&T to facilitate the defense and may, at its option and at its own expense,
participate with AT&T in the defense with counsel of its own choosing. Where AT&T controls the
defense under this Subsection (b)(iii), AT&T shall make good faith efforts to enter into a
reasonable joint defense or common interest agreement with Vendor.

(iv) Insofar as Vendor's obligations under Subsection (b)(i) result from, arise out of, or relate to
a Covered Claim other than a Compound Claim, Vendor shall have the discretion, but not the
obligation, to control the defense of the Covered Claim. In the event that Vendor controls the
defense of the Covered Claim, Vendor shall retain as its lead counsel, subject to AT&T's approval
(which shall not be withheld, conditioned or delayed except for reasons of apparent or actual
conflict of interest), one or more competent attorneys from a nationally recognized law firm who
have significant experience in litigating intellectual property claims of the type at issue, and the
AT&T Indemnified Parties may, at their option and sole expense, participate with Vendor in the
defense of such Covered Claim.

(v) AT&T shall notify Vendor promptly of any Covered Claim; provided, however, that any delay in
such notice shall not relieve Vendor of its obligations under this Section, except insofar as Vendor
can show that such delay actually and materially prejudiced Vendor.

(vi) In no event shall Vendor settle, without AT&T's prior written consent, any Covered Claim, in
whole or in part, in a manner that would require any AT&T Indemnified Party to discontinue or
materially modify its products or services (or offerings thereof). In no event shall Vendor enter
into any agreement related to any Covered Claim or to the Intellectual Property Rights asserted
therein that discharges or mitigates Vendor's liability to the third-party claimant but fails to
fully discharge all of AT&T's liabilities as to the Covered Loss.

(c) Continued Use of Provided Elements Upon Injunction. Without in any manner limiting the foregoing
indemnification, if, as a result of a Covered Claim, (i) the AT&T Indemnified Parties' rights under
this Agreement are restricted or diminished, or (ii) an injunction, exclusion order, or other order
from a court, arbitrator or other competent tribunal or governmental authority preventing or
restricting the AT&T Indemnified Parties' use or enjoyment of the Provided Elements is issued,
imminent, or reasonably likely to be issued, then, in addition to its other obligations set forth in
this Section, Vendor, in any case at its sole expense (or, in the case of a Combination Claim, at
its fairly and equitably apportioned expense) and at no loss, cost or damage to the AT&T Indemnified
Parties or their customers, shall use commercially reasonable efforts to obtain for the AT&T
Indemnified Parties the right to continue using or conducting other activities with respect to the
Provided Elements (or, in the case of a Combination Claim, shall use commercially reasonable
efforts, in cooperation as reasonably needed with other interested parties, to obtain for the AT&T
Indemnified Parties the right to continue using or conducting other activities with respect to the
Provided Elements in the combination at issue); provided that if Vendor is unable to obtain such
right, then Vendor

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 23

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 29 -->
shall, after consulting with and obtaining the written approval of the AT&T Indemnified Parties,
provide modified or replacement non-infringing Provided Elements that are (or, in the case of a
Combination Claim, shall use commercially reasonable efforts, in cooperation as reasonably needed
with other interested parties, to provide a modified or replacement non- infringing combination,
with the Provided Elements being modified or replaced as needed therein, that is) equally suitable
and functionally equivalent while retaining the quality of the original Provided Elements and
complying fully with all the representations and warranties set forth in this Agreement and all
Specifications; provided further that if Vendor is unable in this way to provide such modified or
replacement non-infringing Provided Elements, then AT&T shall have the right, at its option and
without prejudice to any other rights or remedies that AT&T has in contract, law or equity: (1) to
exercise any of the Termination Remedies set forth in the Build Addendum and to terminate AT&T's
obligations under this Agreement with respect to the impacted Cell Sites and receive a reduction in
the Maintenance Fees with respect to such Cell Site(s), and/or (2) to require Vendor, as applicable,
to remove, accept return of, or discontinue the provision of the Provided Elements, to refund to
AT&T the purchase price thereof or other monies paid therefor (subject, in the case of Provided
Elements other than services, to reduction based on the amount of depreciation or amortization over
the useful life of the Provided Elements at issue), and to reimburse AT&T for any and all reasonable
out-of- pocket expenses of removing, returning or discontinuing such Provided Elements.

(d) Elimination of Charges. After AT&T ceases, as a result of actual or claimed infringement or
misappropriation, to exercise the rights granted under this Agreement with respect to the Provided
Elements, AT&T has no obligation to pay Vendor any Structured Payments or Maintenance Fees that
would otherwise be due under this Agreement for such rights.

(e) Exceptions. Vendor shall have no liability or obligation to any of the AT&T Indemnified Parties
for that portion of a Covered Loss which is based on (and only to the extent such portion is based
on):

(i) use of the Provided Elements by the AT&T Indemnified Parties in a manner that constitutes a
material breach of this Agreement; or

(ii) an unauthorized modification of the Provided Elements by an AT&T Indemnified Party; or

(iii) Vendor's conformance to the AT&T Indemnified Party's written specifications, unless any one or
more of the following is true:

1. there was a technically feasible non-infringing means of complying with those specifications,
unless Vendor can show that, at the time of such compliance, such non- infringing means would have
been cost-prohibitive (whether on an individual Cell Site basis, or across multiple Cell Sites as
set forth in the Build Addendum); or

2. the relevant specifications are designed to bring the Provided Elements into compliance with, or
have the Provided Elements conform to, an industry standard, which standard is promulgated by a
generally recognized industry standards-setting body and which standard is not required for
compliance with an applicable law, ordinance, regulation,

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 24

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 30 -->
or building code governing the manner in which Cell Sites may lawfully be constructed; or

3. products, services, or other items that substantially meet such written specifications, and that
in other respects are substantially similar to the Provided Elements are typically provided by or on
behalf of Vendor to third parties in connection with Services substantially similar to those
provided herein; or

4. the relevant specifications for the Provided Elements are of Vendor's (or one or more of its sub-
suppliers') origin, design, or selection.

(f) OTHER LIMITATIONS OF LIABILITY NOT APPLICABLE. NOTWITHSTANDING ANY OTHER PROVISION IN THIS
AGREEMENT TO THE CONTRARY (AND WHETHER OR NOT SUCH A PROVISION CONTAINS LANGUAGE TO THE EFFECT THAT
THE PROVISION TAKES PRECEDENCE OVER OTHER PROVISIONS CONTRARY TO IT), WHETHER EXPRESS OR IMPLIED,
NONE OF THE LIMITATIONS OF LIABILITY (INCLUDING ANY LIMITATIONS REGARDING TYPES OF OR AMOUNTS OF
DAMAGES OR LIABILITIES) CONTAINED ANYWHERE IN THIS AGREEMENT WILL APPLY TO VENDOR'S OBLIGATIONS
UNDER THIS SECTION.

3.18 Insurance

(a) With respect to Vendor's performance under this Agreement, and in addition to Vendor's
obligation to indemnify, Vendor shall at its sole cost and expense:

(i) maintain the insurance coverages and limits required by this Section and any additional
insurance and/or bonds required by Laws:

1. at all times during the term of this Agreement and until completion of all Work associated with
this Agreement, whichever is later; and

2. with respect to any coverage maintained in a "claims-made" policy, for two (2) years following
the term of this Agreement or completion of all Work associated with this Agreement, whichever is
later. If a "claims-made" policy is maintained, the retroactive date must precede the commencement
of Work under this Agreement;

(ii) require each Subcontractor who may perform Work under this Agreement or enter upon any Cell
Site to maintain coverages, requirements, and limits at least as broad as those listed in this
Section, when prorated for the value of the Work to be performed by such Subcontractor from the time
when the Subcontractor begins Work, throughout the term of the Subcontractor's Work and, with
respect to any coverage maintained on a "claims made" policy, if any, for two (2) years thereafter;

(iii) procure the required insurance from an insurance company eligible to do business in the state
or states where Work will be performed and having and maintaining a Financial Strength Rating of
"A-" or better and a Financial Size Category of "VII" or better, as rated in the A.M. Best Key
Rating Guide for Property and Casualty Insurance Companies, except that, in the case of Workers'
Compensation insurance, Vendor may procure insurance from the state fund of the state where Work is
to be performed; and

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 25

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 31 -->
(iv) if requested, provide to AT&T or AT&T's third party administrator certificates of insurance
stating the types of insurance and policy limits. Vendor shall provide or have the issuing insurance
company provide at least thirty (30) days' advance written notice of cancellation, non-renewal, or
reduction in insurance coverage, terms, or limits.

(b) The Parties agree that:

(i) the failure of AT&T to request such certificate of insurance or failure of AT&T to identify a
deficiency will not be construed as a waiver of Vendor's obligation to maintain the insurance
required under this Agreement;

(ii) the insurance required under this Agreement does not represent that coverage and limits will
necessarily be adequate to protect Vendor, nor shall it be deemed as a limitation on Vendor's
liability to AT&T in this Agreement;

(iii) Vendor may meet the required insurance coverages and limits below with any combination of
primary and Umbrella/Excess liability insurance; and

(iv) Vendor is responsible for any deductible or self-insured retention.

(c) The insurance coverage required by this Section includes:

(i) Workers' Compensation insurance with benefits afforded under the laws of any state in which the
Work is to be performed and Employers Liability insurance with limits of at least:

$500,000 for Bodily Injury - each accident $500,000 for Bodily Injury by disease - policy limits
$500,000 for Bodily Injury by disease - each employee

To the fullest extent allowable by Law, the policy must include a waiver of subrogation in favor of
AT&T, its Affiliates, and their directors, officers and employees. In states where Workers'
Compensation insurance is a monopolistic state-run system, Vendor shall add Stop Gap Employers
Liability with limits not less than $500,000 each accident or disease.

(ii) Commercial General Liability insurance written on Insurance Services Office (ISO) Form CG 00 01
12 04 or a substitute form providing equivalent coverage, covering liability arising from premises,
operations, personal injury, products/completed operations, and liability assumed under an insured
contract (including the tort liability of another assumed in a business contract) with limits of at
least:

$2,000,000 General Aggregate limit $1,000,000 each occurrence limit for all bodily injury or
property damage incurred in any one (1) occurrence $1,000,000 each occurrence limit for Personal
Injury and Advertising Injury

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 26

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 32 -->
$1,000,000 each occurrence limit for Products/Completed Operations

If applicable, Vendor will maintain Products/Completed Operations for at least two (2) years
following completion of the Work.

The Commercial General Liability insurance policy must:

1. include AT&T, its Affiliates, and their directors, officers, and employees as additional
insureds. Vendor shall provide a copy of the additional insured endorsement to AT&T. The additional
insured endorsement may either be specific to AT&T or may be "blanket" or "automatic" addressing any
Person as required by contract. A copy of the additional insured endorsement must be provided within
sixty (60) days of execution of this Agreement and within sixty (60) days of each Commercial General
Liability policy renewal;

2. include a waiver of subrogation in favor of AT&T, its Affiliates, and their directors, officers
and employees; and

3. be primary and non-contributory with respect to any insurance or self-insurance that is
maintained by AT&T.

(iii) Property Insurance with limits sufficient to cover the full replacement cost of all of the
Cell Sites against direct and indirect loss or damage by fire and all other casualties and risks
covered under "all risk" insurance respecting the tower and other improvements located at the Cell
Site(s).

(iv) Business Automobile Liability insurance if vehicles will be used in the performance of the
Agreement with limits of at least $1,000,000 each accident for bodily injury and property damage,
extending to all owned, hired, and non-owned vehicles. AT&T, its Affiliates and their directors,
officers and employees shall be included as additional insureds on a primary and non-contributory
basis.

(v) Umbrella/Excess Liability insurance with limits of at least $10,000,000 each occurrence, claim
or wrongful act with terms and conditions at least as broad as the underlying Commercial General
Liability, Business Automobile Liability, and Employers Liability policies. Umbrella/Excess
Liability limits will be primary and non-contributory with respect to any insurance or
self-insurance that is maintained by AT&T.

(vi) Professional Liability (Errors & Omissions) insurance with limits of at least $5,000,000 each
claim or wrongful act.

(vii) Explosion, Collapse, and Underground Damage Liability must not be excluded from the Commercial
General Liability policy for any Work involving explosives or any underground Work. Explosion,
Collapse, and Underground Damage Liability will have the same limit requirement as the Commercial
General Liability policy.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 27

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 33 -->
(viii) To the extent that Vendor utilizes drones, Aircraft Liability insurance covering drones and
similar devices, with limits of One Million and No/100 Dollars ($1,000,000.00) combined single limit
for bodily injury and property damage and providing coverage on a worldwide basis and including
commercial use and hired operations.

3.19 Invoicing and Payment

(a) Promptly after Location Acceptance, Vendor will render an invoice in duplicate to AT&T with
respect to the applicable Cell Site. Such invoice for such Cell Site shall be consistent with the
AT&T purchase order and detail the Material, Deliverables and Services provided for such Cell Site.
The Vendor invoice must specify in detail, if applicable, (i) quantities of each item of Material,
Deliverable, and Services, (ii) prices of each item of Material, Deliverable, and Services, (iii)
whether the item is taxable and the amount of tax per item, (iv) total amounts for each item, (v)
total amount of applicable sales or use taxes, (vi) discounts, if any, (vii) shipping charges, if
any, (viii) total amount due, (ix) remit to address, (x) description of Material, Deliverables, and
Services, and (xi) special service charges, if any. Each invoice shall specifically reference that
the invoice will be paid in accordance with the terms set forth in this Agreement and all payments
for amounts due on such invoice for Material, Deliverables, and Services provided under the Build
Addendum will be made in accordance with the Structured Payments Schedule attached as Schedule 3 to
the Build Addendum. AT&T will promptly review such invoice and, unless AT&T disputes in good faith
the amounts set forth therein, will promptly acknowledge that the Structured Payment set forth
therein is due in accordance with the terms of this Agreement and the Build Addendum. In the event
that AT&T disputes in good faith any amounts set forth in any such invoice, AT&T shall give written
notice of such disputed amounts to Vendor prior to the due date of the first Structure Payment set
forth in such invoice. Vendor will provide a payment request to AT&T on a monthly basis on the first
day of each calendar month for the Structured Payments set forth in the Build Addendum and the
Maintenance Fees set forth in the Maintenance Addendum, in each case as provided in the respective
addendum. AT&T shall pay Vendor no later than sixty (60) days after receipt of such monthly payment
request for Structured Payments. AT&T shall pay, or provide a written notice of any good faith
dispute to, Vendor no later than ninety (90) days after receipt of an invoice for Maintenance Fees.
Any dispute of an invoice for Maintenance Fees shall be made by AT&T in good faith and shall set
forth in writing a detailed description of the disputed amounts and the reason for such dispute.
Notwithstanding any good faith dispute, AT&T shall pay all undisputed amounts in full to Vendor no
later than the due date for such invoice. Invoices received by AT&T more than one (1) year after the
Delivery of Material and Deliverables or the provision of Services are untimely and AT&T has no
obligation to pay such invoices.

(b) Vendor shall pay any amount due to AT&T or its Affiliates within sixty (60) days after written
demand or invoice by AT&T.

(c) Vendor agrees to accept standard, commercial methods of payment and evidence of payment
obligations, including, but not limited to, credit card payments, purchasing card payments, AT&T's
purchase orders, and electronic fund transfers, in connection with any amounts owed by AT&T
hereunder.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 28

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 34 -->
3.20 Licenses and Patents. Except as provided in Section 3.29, no license, express or implied, is
granted under this Agreement to Vendor for any patent, trademark, copyright, trade secret or any
other intellectual property or application therefor which is now or may hereafter be owned by AT&T
or its Affiliates.

3.21 Limitation of Damages. Notwithstanding anything contained in this Agreement to the contrary,
neither Party shall be liable to the other Party for any special, consequential, incidental or
punitive damages, however caused, based on any theory of liability except to the extent such damages
are payable by such Party (a) pursuant to its indemnification obligations under Section 3.15 and
infringement indemnification obligations under Section 3.17, (b) arising out of or resulting from
such Party's breach of its confidentiality obligations set forth in this Agreement (including
Section 3.16, Section 3.48, Section 4.2 and Exhibit A attached hereto) or (c) in connection with a
Third Party Loss arising out of or resulting from such Party's violation of applicable Law.

3.22 Offset Right. Any amounts payable (including any recoupment claims or other amounts to be
reimbursed) by Vendor or its Affiliates to AT&T or its Affiliates under this Agreement (including
under the Build Addendum or the Maintenance Addendum) may be offset against the Maintenance Fees or
any payment due or to become due to Vendor or its Affiliates from AT&T or its Affiliates under the
Transport Agreement, Master License Agreement; provided, however, that AT&T's offset right under
this Section 3.22 shall not apply to any Structured Payments for any Cell Site that has reached
Location Acceptance and AT&T hereby waives all such rights of setoff and recoupment against such
Structured Payments. Prior to exercising its right to offset amounts pursuant to this Section 3.22,
AT&T shall provide written notice to Vendor of its intention to offset such amounts and to the
extent any dispute between the Parties exists in respect of the amount to be offset, AT&T must first
utilize the Escalation Procedure in Section 4.8(a).

3.23 Material and Services Furnished by Vendor and AT&T. Vendor shall furnish all Services,
including individuals to provide field and administrative support, and Vendor shall furnish all
Material required to perform the Work, except those items specifically listed in this Agreement, the
Build Addendum or the Maintenance Addendum to be furnished by AT&T. Any material provided by AT&T
shall remain AT&T's material and shall be used only in connection with Work under this Agreement.
Vendor shall protect and preserve AT&T's material and shall promptly return at the end of contracted
Work, at Vendor's expense, any material not used, unless AT&T instructs Vendor otherwise in writing.
AT&T shall receive full title and ownership rights to all Material furnished by Vendor relating to
any Cell Site upon Location Acceptance of such Cell Site.

3.24 Non-Exclusive Market. Other than with respect to the Cell Sites expressly contemplated in the
Build Addendum, this Agreement does not grant Vendor any right or privilege to provide to AT&T any
Work of the type described in or purchased under this Agreement in any market or geographic area.
Except for obligations arising under the Build Addendum or the Maintenance Addendum and any work
orders or trouble tickets thereunder that have not been terminated as provided herein, this
Agreement does not obligate AT&T to purchase or license any such Work from Vendor. AT&T may contract
with other

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 29

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 35 -->
manufacturers and vendors for the procurement or trial of Work comparable to that described in or
purchased under this Agreement for sites other than the Cell Sites expressly contemplated in the
Build Addendum, and AT&T may itself perform such Work.

3.25 Notice of Certain Events. Vendor shall promptly notify AT&T of any of the following which is
connected with any Deliverables: (a) any material investigation, indictment, lawsuit, or
administrative or other proceeding, or (b) the revocation of any license, permit or other document
issued to Vendor by any governmental authority necessary for Vendor to complete its obligations as
set forth herein. Prior to Location Acceptance of all Cell Sites pursuant to the Build Addendum,
Vendor must notify AT&T immediately (and in any event within three (3) business days) in writing, if
it breaches (or is given written notice of an alleged breach or prospective breach of) a material
covenant in any material financial or material operational arrangement of Vendor. Following Location
Acceptance of all Cell Sites pursuant to the Build Addendum, Vendor must notify AT&T immediately
(and in any event within three (3) business days) in writing, if it breaches (or is given written
notice of an alleged breach or prospective breach of) a material covenant in any material financial
or material operational arrangement of Vendor that could reasonably be expected to adversely impact
Vendor's ability to perform its obligations under this Agreement.

3.26 Notices

(a) Each Party giving or making any notice, consent, request, demand, or other communication (each,
a "Notice") pursuant to this Agreement must give the Notice in writing and use one of the following
methods, each of which for purposes of this Agreement is a writing: certified mail (return receipt
requested and postage prepaid); U.S. Postal Service overnight or priority mail; internationally
recognized overnight courier (in either case with all fees prepaid); or email. If a Notice is given
by e-mail, then it must be confirmed by a copy sent by any one of the other methods. Each Party
giving a Notice shall address the Notice to the appropriate person (the "Addressee") at the
receiving Party at the address listed below:

Commnet:

Commnet Wireless, LLC 400 Northridge Road, Suite 31100 Atlanta, GA 30350 Attn: Joseph Moravec Email
Address: jmoravec@atni.com Business Number: 404-649-6625

With a copy (which shall not constitute notice) to:

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 30

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 36 -->
Commnet Wireless, LLC c/o ATN International, Inc. 500 Cummings Center, Suite 2450 Beverly, MA 01915
Attn: General Counsel Email Address: legalnotices@atni.com Business Number: (978) 619-1323

AT&T:

AT&T Mobility LLC 1025 Lenox Park Blvd Atlanta, GA 30319 Attn: Kurt Dresch, Director - Global
Connection Management Email: kurt.dresch@att.com

and

AT&T Mobility LLC 2180 Lake Blvd. NE B1260 Atlanta, GA 30319 Attn: Anu Seam, Assistant Vice
President and Senior Legal Counsel Email Address: anu.seam@att.com

With a required copy to:

Kilpatrick Townsend & Stockton LLP 1100 Peachtree Street NE, Suite 2800 Atlanta, Georgia 30309
Attention: S. Joel Cartee Telephone: (404) 815-5909 Facsimile: (404) 541-3238 E-mail:
JCartee@kilpatricktownsend.com

(b) A Notice is effective only if the Party giving notice has complied with the foregoing
requirements of this Section and the Addressee has received the Notice. A Notice is deemed to have
been received as follows:

(i) If a Notice is sent by certified mail, U.S. Postal Service overnight or priority mail, or
internationally recognized overnight courier, upon the date of delivery as indicated by the receipt
or other tracking record;

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 31

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 37 -->
(ii) If a Notice is sent by e-mail, upon successful transmission to the recipient's email account,
if such Notice is sent in time to allow it to be accessible by the Addressee before the time allowed
for giving such Notice expires, and a confirmation copy is sent by one of the other methods.

(c) The addresses and telephone numbers to which Notices may be given to the Addressees of either
Party may be changed by written Notice given by such Party to the other pursuant to this Section.

3.27 Offshore Work Prohibited. None of the Services under this Agreement shall be performed or
provided and no Information related to this Agreement shall be collected, stored, handled or
accessed by Vendor or its Subcontractors at any location outside of the United States. Additionally,
Vendor shall not allow any of the Services under this Agreement to be performed or provided by any
Restricted Entity and any Services performed or provided by a Subcontractor shall be subject to
Vendor's compliance with the requirements of the Section entitled "Work Done by Others".

3.28 Order of Precedence. The terms of this Agreement govern all Work to be performed by Vendor
while this Agreement remains in effect. This Agreement shall govern in lieu of all other pre-printed
or standardized provisions that may otherwise appear in any other paper or electronic record of
either Party (such as standard terms on order or acknowledgment forms, advance shipping notices,
invoices, time sheets, and packages, shrink wrap terms, and click wrap terms).

In the event of a conflict between the terms of the body portion of this Agreement and any of the
addendums, exhibits, schedules or appendices attached hereto, the order of precedence for
controlling clauses shall be as follows: (a) Government Flow Downs and Contract Clauses attached to
this Agreement as Exhibit A; (b) the Build Addendum or Maintenance Addendum, as applicable; and (c)
the remaining provisions of this Agreement.

3.29 Ownership of Paid-For Development, Use and Reservation of Rights

(a) Paid-For Development. AT&T shall be the exclusive owner of all right, title, and interest in and
to all Paid- For Development (defined below), including, without limitation, all Intellectual
Property Rights therein and thereto. Vendor shall assign or have assigned to AT&T and hereby assigns
to AT&T all Intellectual Property Rights in and to the Paid-For Development. "Paid- For Development"
shall mean any and all Items to the extent produced or developed by or on behalf of Vendor or its
employees, agents, or direct or indirect contractors or suppliers (and whether completed or
in-progress), and forming part of any Deliverable, Material or Service pursuant to this Agreement
(including, without limitation, under the Build Addendum, Maintenance Addendum or any statement of
work, exhibit, schedule, order or other document under, subordinate to, or referencing this
Agreement) for which AT&T has been or will be charged Structured Payments, Maintenance Fees or any
monies in connection with a Change Order. Paid-For Development shall always include (without
limitation) any modifications, alterations or updates that fall within the definition of Paid-For
Development but shall not

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 32

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 38 -->
include any Items produced by Vendor for its own use in connection with performance of the Services
and for which AT&T has not been charged.

(b) License Grant to AT&T. Vendor hereby grants and promises to grant and have granted to AT&T and
its Affiliates a royalty-free, nonexclusive, sublicensable, assignable, transferable, irrevocable,
perpetual, world- wide license in and to any applicable Intellectual Property Rights of Vendor to
use, copy, modify, distribute, display, perform, import, make, sell, offer to sell, and exploit (and
have others do any of the foregoing on or for AT&T's or any of its customers' behalf or benefit) any
Intellectual Property Rights of Vendor or any third party that are not included in Material or
Paid-For Development but necessary to operate the Cell Sites or receive the full benefit of the
Work.

(c) Further Acts and Obligations. Vendor will take or secure such action (including, but not limited
to, the execution, acknowledgment, delivery and assistance in preparation of documents or the giving
of testimony) as may be reasonably requested by AT&T to evidence, transfer, perfect, vest or confirm
AT&T's right, title and interest in any Paid-For Development. Vendor shall, in all events and
without the need of AT&T's request, secure all Intellectual Property Rights in any Paid-For
Development (and any licenses specified above) from each employee, agent, Subcontractor or
sub-contractor of Vendor who has or will have any rights in the Paid- For Development or
Intellectual Property Rights.

(d) Reservation of Rights and Limited License. Notwithstanding any other provision in this
Agreement, AT&T is not transferring or granting to Vendor any right, title, or interest in or to (or
granting to Vendor any license or other permissions in or to) any or all: (i) Items created by or on
behalf of AT&T or directly or indirectly provided to Vendor (in any form, including, without
limitation, verbally) by or on behalf of AT&T or its third party providers, including the AT&T
Provided Equipment (as such term is defined in the Build Addendum) ("AT&T Provided Items"); (ii)
Paid-For Development or (iii) Intellectual Property Rights, including, without limitation, any
Intellectual Property Rights in or to any AT&T Provided Items or Paid- For Development. The sole
exception to the foregoing reservation of rights is that AT&T hereby grants Vendor a limited,
nonexclusive, non-transferable license (that shall automatically terminate upon the termination or
expiration of this Agreement), under any rights owned by AT&T, to use the AT&T Provided Items and
Paid- For Development solely as instructed by AT&T and to the extent necessary for Vendor to perform
its obligations under this Agreement, subject further to the terms and conditions of this Agreement.
In no way expanding the foregoing license, said license in no manner permits Vendor to (and Vendor
hereby promises not to without the explicit prior written and signed consent of AT&T Intellectual
Property, LLC ("ATTIP Consent")) make use of any AT&T Provided Items, Paid- For Development or AT&T
Intellectual Property Rights either for the benefit of any third party or other than as instructed
in writing by AT&T (AT&T may be willing, in its sole discretion, to grant ATTIP Consent in exchange
for appropriate additional compensation). Paid-For Development and AT&T Provided Items shall
constitute AT&T Information under this Agreement.

3.30 Publicity. Other than use of AT&T's name in connection with Permit applications, Vendor shall
not use AT&T's or its Affiliates' names, trademarks, service marks, designs,

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 33

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 39 -->
logos or symbols. In addition, Vendor shall not use any language or pictures which could in AT&T's
judgment imply AT&T's or its Affiliates' identities, or endorsement by AT&T, its Affiliates or any
of its or their employees, in any (i) written, electronic, or oral advertising or presentation, or
sales meeting, or (ii) brochure, newsletter, book, electronic database, testimonial quotation, thank
you letter, reference letter or other communication of whatever nature, without prior written ATTIP
Consent.

Vendor and its employees, agents, and Subcontractors shall refer any questions from the media or
third parties regarding the Work to AT&T and shall not discuss the Work with the media or third
parties, without the prior written ATTIP Consent. For the purpose of clarity, any disclosure of the
existence of this Agreement or the Work by Vendor as required by Law, including the regulations of
the Securities and Exchange Commission, shall not be a violation of this section; provided that,
prior to any such disclosure being made in the first instance, Vendor shall give AT&T a reasonable
opportunity to review and comment thereon (including any press release). To the extent that any
disclosure required to be made by Vendor to the Securities and Exchange Commission has been
previously reviewed by AT&T, then Vendor shall not be required to provide AT&T with a reasonable
opportunity to review and comment thereon prior to such disclosure being made thereafter so long as
no substantive changes have been made thereto. A breach of this "Publicity" Section shall be deemed
a material breach of this Agreement.

3.31 Records and Audits

(a) Vendor shall maintain complete and accurate records relating to the Work and the performance of
this Agreement. AT&T and its auditors (including internal audit staff and external auditors) and
governmental authorities shall have the right to review such records ("AT&T Audits") held and
created by Vendor, to verify the following:

(i) the accuracy of Vendor's invoices and AT&T's payment obligations hereunder;

(ii) that the Work charged for was actually performed;

(iii) that the Services have been and are being provided in accordance with this Agreement;

(iv) the integrity of Vendor's systems that process, store, support, maintain, and transmit AT&T
data;

(v) Vendor's records relating to the performance of Vendor's Subcontractors with respect to any
portion of the Services; and

(vi) that Vendor and its Subcontractors are complying with Section 3.6 hereof.

When the FirstNet Authority or other governmental authority requests to review Vendor's records,
AT&T and its auditors will review these records first if the FirstNet Authority or other
governmental authority permits such review, and provide the records to the requesting governmental
authority; provided, however, the FirstNet Authority and other governmental authorities retain the
right to perform audits independent of AT&T.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 34

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 40 -->
(b) Subject to Subsection (g) below, Vendor shall provide and shall require that its Subcontractors
provide to AT&T, its auditors (including internal audit staff and external auditors), and
governmental authorities access at all reasonable times to:

(i) any facility at which the Services or any portion thereof are being performed;

(ii) systems and assets used to provide the Services or any portion thereof;

(iii) Vendor employees and Subcontractor employees providing the Services or any portion thereof;
and

(iv) all Vendor and Subcontractor records, including financial records relating to the invoices and
payment obligations and supporting documentation, pertaining to the Services.

The scope of AT&T Audits shall also include:

(i) practices and procedures used in performing the Services;

(ii) systems, communications and information technology used in performing the Services;

(iii) general controls and security practices and procedures;

(iv) supporting information and calculations regarding invoices and compliance with service
requirements;

(v) quality initiatives and quality assurance; and

(vi) compliance with the terms of this Agreement.

AT&T's access to the records and other supporting documentation shall include the right to inspect
and photocopy Vendor's documentation and the documentation of its Subcontractors as provided to
Vendor, and the right to retain copies thereof outside of their physical location with appropriate
safeguards, if such retention is deemed reasonably necessary by AT&T and only to the extent that all
such records are maintained by AT&T in accordance with Section 3.16 hereof.

(c) AT&T Audits may be conducted once a year (or more frequently if requested by governmental
authorities who regulate AT&T's business, if required by applicable Law or if auditors require
follow-up access to complete audit inquiries or if an audit uncovers any problems or deficiencies),
upon at least ten (10) business days advance notice (unless otherwise mandated by Law) and during
business hours. Vendor will cooperate, and will ensure that its Subcontractors cooperate, in the
AT&T Audits, and will make the information reasonably required to conduct the AT&T Audits available
on a timely basis.

(d) If, as a result of an AT&T Audit, AT&T determines that Vendor has not performed or has
unsatisfactorily performed any obligation under this Agreement, then Vendor will promptly remedy the
non-performance or unsatisfactory performance.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 35

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 41 -->
(e) Vendor will maintain and retain the records set forth in Subsection (a) during the term of the
Agreement and for three (3) years thereafter (unless a discovery or legal hold request is made with
respect to such records, in which case Vendor shall retain such records until AT&T notifies Vendor
that such discovery or legal hold request has expired). Vendor will provide AT&T, at AT&T's request
and cost, with paper and electronic copies of documents and information reasonably necessary to
verify Vendor's compliance with this Agreement. Upon notification by AT&T of a discovery or legal
hold request, Vendor shall fully cooperate with such request and immediately preserve any Vendor
records covered by such request and promptly provide such Vendor records requested by AT&T related
to the inquiry.

(f) Except as provided in Subsection (d), all reasonable out-of-pocket costs and expenses incurred
by AT&T in connection with an AT&T Audit shall be paid by AT&T. Vendor shall be solely responsible
for all costs and expenses incurred by Vendor in connection with its obligations under this Section.
In the event that either Party requires that an audit be performed by an independent auditor, unless
otherwise specified herein, the Party requesting such independent auditor will be responsible for
the costs and expenses associated with the independent auditor.

(g) With respect to AT&T requests for audits or inspections of Vendor's Subcontractors, the
following applies:

(i) If Vendor's agreement with its applicable Subcontractor permits an AT&T Audit, AT&T shall be
permitted to conduct such audit directly or through a third party representative. Vendor shall work
with AT&T in facilitating the Subcontractor's cooperation for an expeditious and thorough audit or
inspection.

(ii) If Vendor's contract with its applicable Subcontractor precludes AT&T from directly conducting
an audit or inspection, Vendor shall use reasonable best efforts to enable AT&T to perform an audit
of the Subcontractor with Vendor coordinating the audit process. Failing those efforts, Vendor
shall, upon AT&T's request and at AT&T's expense, conduct the audit or inspection on behalf of AT&T,
subject to terms agreed to by Vendor and AT&T for the Subcontractor audit, such as areas to be
audited, applicable fees, and the timeframe for reporting audit results to AT&T. If AT&T's request
for a Vendor audit or inspection arises from, in AT&T's good faith opinion, materially or
consistently deficient Service provided by the Subcontractor under AT&T's account, and the audit in
both Parties' opinions confirms such deficiencies, Vendor shall not charge AT&T a fee for the
Vendor's audit of its Subcontractor.

(iii) If Vendor's contract with its applicable Subcontractor does not allow Vendor access to the
facilities and systems of Subcontractor required to conduct the audit described in Subsection (b)
above, then Vendor shall provide a list of such Subcontractors and the services being provided by
such Subcontractor to AT&T for its review. To the extent AT&T deems it reasonably necessary to
require such access, then Vendor will renegotiate its contract with the applicable Subcontractor in
order to obtain the audit rights described in Subsection (b) above.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 36

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 42 -->
3.32 Restricted Entities. Vendor may not deliver or obtain any Material or Deliverables from or use
any Restricted Entities to provide any Services under this Agreement, without prior written consent
from AT&T. Vendor may not use, in connection with any Deliverable, Material or Service provided
hereunder, any element, equipment, location, instrumentality or the like where a Restricted Entity
has a security interest in that element, equipment, location, instrumentality or the like. Vendor
may not obtain financing from any Restricted Entity or use any Cell Sites or Material owned, leased
from, operated or financed by any Restricted Entity.

3.33 Severability. If any provision of this Agreement is determined to be invalid, illegal, or
unenforceable, the Parties agree that the remaining provisions of this Agreement shall remain in
full force if both the economic and legal substance of the transactions contemplated by this
Agreement are not affected in any manner that is materially adverse to either Party by severing the
provision determined to be invalid, illegal, or unenforceable.

3.34 Supplier Citizenship and Sustainability. Vendor shall conduct business with an abiding respect
for corporate citizenship, sustainability, and human rights ("Citizenship and Sustainability"). Upon
AT&T's request, which request may only be made once per calendar year, Vendor shall provide to AT&T
reasonable information, reports, or survey responses to demonstrate Vendor's operation of its
business in the context of Citizenship and Sustainability.

3.35 Survival of Obligations. Obligations and rights under this Agreement that by their nature would
reasonably continue beyond the termination or expiration of this Agreement (including those in the
Sections entitled "Compliance with Laws," "Construction and Interpretation," "Cumulative Remedies,"
"Entire Agreement," "Governing Law," "Information," "Indemnity," "Infringement," "Insurance,"
"Limitation of Damages," "Order of Precedence," "Ownership of Paid-For Development, Use and
Reservation of Rights," "Publicity," "Severability," "AT&T Supplier Information Security
Requirements (SISR)," "Warranty," "Customer Information," "Dispute Resolution" and the
representations, warranties, indemnities and Termination Remedies) will survive the termination or
expiration of this Agreement.

3.36 Taxes

(a) Vendor shall invoice AT&T the amount of any federal excise, state, and local transaction taxes
imposed upon the sale of Material, Delivery of Deliverables, and provision of Services under this
Agreement. All such taxes must be stated as separate items on the applicable Material, Deliverable,
or Services invoice listing the taxing jurisdiction imposing the tax. Installation, labor and other
non-taxable charges must be separately stated. AT&T shall pay all applicable taxes to Vendor that
are stated on and at the time the Material, Deliverables, or Services invoice is submitted by
Vendor. Vendor shall remit taxes to the appropriate taxing authorities. Vendor shall honor tax
exemption certificates, and other appropriate documents, which AT&T provides to Vendor, pursuant to
relevant tax provisions of the taxing jurisdiction providing the exemption.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 37

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 43 -->
(b) Vendor will pay any penalty, interest, additional tax, or other charge that may be levied or
assessed as a result of the delay or failure of Vendor, for any reason other than AT&T's failure to
reimburse Vendor in a timely manner for such amounts, to pay any tax or file any return or
information required by law, rule, or regulation or by this Agreement to be paid or filed by Vendor.

(c) Upon AT&T's request, the Parties shall consult with respect to the basis and rates upon which
Vendor shall pay any taxes or fees for which AT&T is obligated to reimburse Vendor under this
Agreement. If AT&T determines that, in good faith and pursuant to applicable Law, any such taxes or
fees are not payable or should be paid on a basis less than the full price or at rates less than the
full tax rate, AT&T shall notify Vendor in writing of such determinations, Vendor shall make payment
in accordance with such determinations, and AT&T shall be responsible for such determinations. If
collection is sought by the taxing authority for a greater amount of taxes than that so determined
by AT&T, Vendor shall promptly notify AT&T. If AT&T desires to contest such collection, AT&T shall
promptly notify Vendor. Vendor shall cooperate with AT&T in contesting such determination, but AT&T
shall be responsible and shall reimburse Vendor for any tax, interest, or penalty in excess of
AT&T's determination and shall reimburse Vendor for Litigation Expense incurred by Vendor in
connection with contesting such determination.

(d) If the parties agree, where such agreement shall not be unreasonably withheld, conditioned, or
delayed, that AT&T has paid Vendor for any taxes in excess of the amount that AT&T is obligated to
pay Vendor under this Agreement, AT&T and Vendor shall consult in good faith to determine the
appropriate method(s) to seek recovery of such excess payments, which method(s) may include, but are
not limited to, (i) Vendor crediting any excess payments against tax amounts or other payments due
from AT&T solely to the extent Vendor has successfully made corresponding adjustments to its
payments to the relevant tax authority, (ii) Vendor timely filing claims for refund and any other
documents required to recover any excess payments and Vendor promptly remitting to AT&T all such
refunds and interest received, and (iii) Vendor immediately refunding to AT&T such excess payments.

(e) If any taxing authority advises Vendor that it intends to audit Vendor with respect to any taxes
for which AT&T is obligated to reimburse Vendor under this Agreement, Vendor shall (i) promptly so
notify AT&T, (ii) afford AT&T an opportunity to participate with Vendor in such audit with respect
to such taxes, and (iii) keep AT&T fully informed as to the progress of such audit. Except as set
forth in Subsection (c) above, each Party shall bear its own expenses with respect to any such
audit, and the responsibility for any additional tax, interest, or penalty resulting from such audit
is to be determined in accordance with the applicable provisions of this Section 3.36. Vendor's
failure to comply with the notification requirements of this Section 3.36 will relieve AT&T of its
responsibility to reimburse Vendor for taxes only to the extent that Vendor's failure actually and
materially prejudiced AT&T's ability to contest imposition or assessment of those taxes.

(f) In addition to its rights under Subsections (c), (d), and (e) above with respect to any tax or
tax controversy covered by this Section 3.36, AT&T is entitled to contest, pursuant to applicable
Law and tariffs and at its own expense, any tax previously invoiced that AT&T is ultimately

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 38

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 44 -->
obligated to pay. AT&T is entitled to the benefit of any refund or recovery of amounts actually
received by AT&T or Vendor that AT&T has previously paid to Vendor resulting from such a contest.
Vendor shall cooperate in any such contest, but AT&T shall reimburse Vendor for Litigation Expense
incurred by Vendor in obtaining a refund or credit for AT&T.

(g) If either Party is audited by a taxing authority or other governmental entity in connection with
taxes under this Section 3.36, the other Party shall reasonably cooperate with the Party being
audited in order to respond to any audit inquiries in an appropriate and timely manner, so that the
audit and any resulting controversy may be resolved expeditiously.

(h) AT&T and Vendor shall reasonably cooperate with each other with respect to any tax planning to
minimize taxes.

(i) Vendor and any of its Affiliates, as appropriate, receiving payments hereunder shall provide
AT&T with a valid United States Internal Revenue Service ("IRS") Form W-8BEN, W-8BEN- E, W-8ECI,
W-8EXP, W- 8IMY, or W-9 (or any successor form prescribed by the IRS). AT&T may reduce any payment
otherwise due to Vendor in connection with the sale of Material, Delivery of Deliverables, or
provision of Services under this Agreement by the amount of any tax imposed on Vendor that AT&T is
required to pay directly to a taxing or other governmental authority ("Withholding Tax").
Alternatively, if applicable Law permits, AT&T agrees that it will honor a valid exemption
certificate or other mandated document evidencing Vendor's exemption from payment of, or liability
for, any Withholding Tax as authorized or required by statute, regulation, administrative
pronouncement, or other Law of the jurisdiction providing said exemption. AT&T shall provide Vendor
with documentation evidencing withholding in a reasonable time.

3.37 Termination and Suspension

(a) Mutual Agreement - This Agreement, the Build Addendum and/or the Maintenance Addendum may be
terminated at any time upon the mutual written consent of the Parties.

(b) Termination for Convenience - This Agreement, the Build Addendum and the Maintenance Addendum
may not be terminated by either Party at any time for its own convenience.

(c) Termination for Cause

(i) If either Party breaches any provision of this Agreement (which for purposes of this Section
3.37(c) shall not mean any breaches of the Build Addendum or Maintenance Addendum) and (i) if the
breach is one that by its nature could be cured, and such breach is not cured within thirty (30)
days (or such other applicable cure period expressly provided herein and applicable to such breach)
after the breaching Party receives written notice, provided that if such breach is not reasonably
susceptible of cure within such thirty (30) day period (or such other applicable cure period) and
Vendor is diligently and continuously pursuing a cure, the Parties shall cooperate in good faith to
establish by mutual written agreement a reasonable extension of the applicable cure period, or (ii)
if the breach is one that by its nature cannot be cured, or (iii) if the breach is a material
violation of Laws that is not reasonably susceptible of cure, then, in addition to all other rights
and remedies at law or

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 39

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 45 -->
in equity or otherwise, the non-breaching Party shall have the right upon written notice to
immediately terminate this Agreement (which termination shall include the Build Addendum and
Maintenance Addendum), and exercise all Termination Remedies set forth in the Build Addendum, except
AT&T cannot terminate its obligation to pay Vendor all Structured Payments for Cell Sites that have
achieved Location Acceptance prior to the effective date of termination or any Maintenance Fees for
Services performed under the Maintenance Addendum prior to the effective date of such termination.
Failure of the non- breaching Party to immediately terminate this Agreement (x) following a breach
which continues longer than such cure period, provided such breach has not been cured prior to the
non-breaching Party's providing notice of termination, or (y) following a breach that cannot be
cured or that constitutes a material violation of Laws that is not reasonably susceptible to cure
shall not constitute a waiver of the non- breaching Party's rights to terminate.

(ii) If Vendor becomes insolvent or generally fails to pay, or admits in writing its inability or
refusal to pay, debts as they become due, then AT&T shall have the right upon written notice to
immediately terminate AT&T's obligations under this Agreement or the Build Addendum or Maintenance
Addendum, as applicable, and exercise all Termination Remedies set forth in the Build Addendum.

(iii) If (1) Vendor (A) receives a notice of default (or similar breach or violation) and has not
cured such default (or similar breach or violation) within thirty (30) days from the receipt of such
notice or (B) is in default under any credit facility or other financing arrangement, (2) any Vendor
credit facility or other financing arrangement has been terminated or suspended (other than by
Vendor or as a result of an expiration in accordance with its terms) or (3) Vendor no longer has
access to funding under any credit facility or other financing arrangement required by Vendor to
fulfill its obligations to AT&T under this Agreement, the Master License Agreement, the Transport
Agreement and the Roaming Agreement (as such term is defined in the Build Addendum), then Vendor
shall promptly, but no later than one (1) business day following Vendor's receipt of notice of any
such event, notify AT&T of such event and in addition to all other rights and remedies at law or in
equity or otherwise, AT&T shall have the right upon written notice to immediately terminate AT&T's
obligations under this Agreement or the Build Addendum or Maintenance Addendum, as applicable, and
exercise all Termination Remedies set forth in the Build Addendum; provided, that prior to
exercising such termination right, AT&T shall enter into good faith discussions with Vendor to
determine if Vendor can obtain alternative financing.

(d) Bankruptcy. In addition to all other termination rights set forth herein, this Agreement may be
terminated by either Party or either Party may terminate its obligations hereunder, in each case in
whole or in part (including terminating only specific addendums or specific Cell Sites), if the
other Party files, or has filed against it, any voluntary petition seeking liquidation,
reorganization, arrangement or readjustment of its debts or for any other relief under the United
States Bankruptcy Code or under any other act or Law pertaining to insolvency or debtor relief,
whether state, federal or foreign, now or hereafter existing; or such other Party has filed against

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 40

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 46 -->
it any petition which petition seeks any of the foregoing relief or substantive consolidation of the
assets of such other Party with a debtor in bankruptcy or liquidation and which is not dismissed
within forty-five (45) days after the effective service of same; or the appointment is made of a
receiver, custodian or trustee of such other Party or for all or a substantial part of the assets of
such other Party.

(e) Termination Events. In addition to all other termination rights set forth herein, this Agreement
may be terminated by AT&T or AT&T may terminate its obligations hereunder (including terminating
only specific addendums or specific Cell Sites), upon the occurrence of (i) any Termination Event
(as defined in the Build Addendum) applicable to one or more Cell Sites and upon such termination
AT&T may exercise any or all of the Termination Remedies (as defined in the Build Addendum)
available to it pursuant to the Build Addendum with respect to such impacted Cell Sites; or (ii) any
termination (regardless of the reason therefor) of the Master License Agreement resulting in AT&T's
inability to use the impacted Cell Site.

(f) Partial Termination - Whenever Law or a provision of this Agreement permits AT&T to terminate
this Agreement with respect to a single Cell Site or group of Cell Sites or with respect to either
the Build Addendum or Maintenance Addendum, AT&T may, at its option, terminate this Agreement in
part with respect to such Addendum or on a Cell Site basis without further liability or obligation;
provided that no such termination shall relieve AT&T's obligation to make Structured Payments with
respect to any Cell Sites that have reached Location Acceptance prior to the effective date of such
termination and pay any Maintenance Fees for Services performed under the Maintenance Addendum prior
to the effective date of such termination. The Parties acknowledge that the Build Addendum and
Maintenance Addendum include specific partial termination rights on a Cell Site by Cell Site basis,
including the Termination Remedies that allow for termination of AT&T's obligations with respect to
an individual Cell Site hereunder and special remedies to AT&T in connection with such termination.

(g) Termination Charges - AT&T shall not be liable for any termination charges (or any charges for
any Material or Services already ordered or performed at the time of termination) in any case when
any termination results from a termination right granted to AT&T in this Agreement; provided that
AT&T shall remain obligated to make Structured Payments with respect to any Cell Sites that have
reached Location Acceptance prior to the effective date of such termination and pay any Maintenance
Fees for Services performed under the Maintenance Addendum prior to the effective date of such
termination.

(h) Obligations upon Expiration or Termination - Upon expiration or termination of this Agreement,
but prior to the effectiveness of full termination of the Agreement, AT&T may exercise any rights
and remedies available to AT&T under this Agreement, at law or in equity, including AT&T's right to
exercise any one or more of the Termination Remedies set forth in the Build Addendum, and Vendor
shall, upon the request and at the expense (other than termination in accordance with Subsection (c)
hereof) of AT&T: (i) return all papers, materials, equipment, assets and property of AT&T held by
Vendor, including title and ownership to all Material, (ii) provide reasonable assistance as may be
necessary for the orderly, non-disrupted continuation of the Services, (iii) transfer all of the
contracts related to the Cell Sites to AT&T

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 41

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 47 -->
as contemplated in the Build Addendum and (iv) reimburse AT&T for any AT&T Provided Equipment or
other assets that are not installed at a Cell Site and cannot be returned in good working order
(based on the acquisition costs plus taxes and shipping costs). Vendor also agrees to assist AT&T in
coordinating the transfer of the provision of the Services to a successor contractor, which shall
include continuing to provide the required level of Services until the date of expiration or
termination and providing the successor contractor with all pertinent information about the
Services. For the purposes of clarity and notwithstanding any other provisions herein, no
termination under this Agreement shall relieve AT&T's obligation to make Structured Payments with
respect to any Cell Sites that have reached Location Acceptance prior to the effective date of such
termination and pay any Maintenance Fees for Services performed under the Maintenance Addendum prior
to the effective date of such termination.

3.38 Third Party Administrative Services

(a) Vendor acknowledges that a third party administrator will perform certain administrative
functions for AT&T in relation to this Agreement. Such administrative functions may include:

(i) Collecting and verifying certificates of insurance;

(ii) Providing financial analysis;

(iii) Verifying certifications under the Section entitled "Utilization of Minority, Women, and
Disabled Veteran Owned Business Enterprises"; and

(iv) Collecting and verifying Vendor profile information.

(b) Vendor shall cooperate with such third party administrator in its performance of such
administrative functions and shall provide such data as from time to time the third party
administrator may request. Further, notwithstanding any other provision of this Agreement, Vendor
agrees that AT&T may provide any information regarding Vendor to such third party administrator.
AT&T shall contractually require the third party administrator to maintain confidentiality of
Vendor's information with rights to use it solely for purposes of the administrative functions.
Vendor agrees to pay the third party administrator an annual fee for the performance of these
administrative functions, which annual fee shall not exceed three hundred dollars ($300.00), and a
one-time set-up fee of thirty dollars ($30.00). AT&T agrees to reimburse Vendor for such fees listed
as a line item expense on the invoice issued by Vendor to AT&T pursuant to Section 3.19 for the
month immediately following such payment.

3.39 Third Party Beneficiaries. All AT&T Affiliates receiving Material or Services under this
Agreement and the federal government of the United States shall be express third party beneficiaries
under this Agreement. Except to the extent expressly set forth to the contrary in this Agreement
(including with respect to Affiliates of AT&T and the U.S. Government), there are no third party
beneficiaries of this Agreement, and this Agreement shall not provide any third Person other than
AT&T Affiliates and the U.S. Government with any

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 42

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 48 -->
remedy, claim, liability, reimbursement, claim of action or other legal or equitable right in excess
of those existing without reference to this Agreement.

3.40 Title and Risk. Title to Material furnished by Vendor shall vest in AT&T immediately and
automatically upon Location Acceptance (as defined in the Build Addendum) or, if after Location
Acceptance of a Cell Site, with respect to any Material provided in connection with the Maintenance
Addendum, when actually installed or incorporated in the Work; provided, if the Material was paid
for or provided by AT&T prior to incorporation into the Work, title shall always be vested in AT&T;
provided, further, in both cases Vendor shall retain risk of loss and damages to all of the Material
(including all AT&T Provided Equipment (as such term is defined in the Build Addendum)) until
Location Acceptance and thereafter to the extent such Material is in the custody or control of
Vendor.

3.41 Title To Material Furnished by AT&T. Title to material furnished by AT&T under this Agreement
shall at all times be in AT&T's name. Vendor assumes full responsibility for any loss or damage to
such material while material is in Vendor's or its Subcontractor's possession or control and shall
be liable for the full value of the material (which shall include AT&T's acquisition cost plus all
taxes and shipping). Vendor shall not allow or permit any Lien to be placed upon or otherwise
encumber any AT&T Provided Equipment or other assets, properties or rights owned, operated or leased
by AT&T or any of its Affiliates.

AT&T may inspect and inventory the material furnished by AT&T under this Agreement during Vendor's
normal business hours. Prior to Location Acceptance, Vendor shall provide AT&T escorted access to
the premises wherein all such material is located and, following Location Acceptance, AT&T shall
have access to the premises wherein all such material is located pursuant to the terms of the Master
License Agreement and the applicable Site License thereunder or any third party Tower Lease, as
applicable. The obligations assumed by Vendor with respect to material furnished by AT&T under this
Agreement are for the protection of AT&T's property. Should Vendor fail to comply in any respect, in
addition to any other right or remedy AT&T may have, upon ten (10) days' written notice to Vendor,
AT&T may withdraw all or any part of the material furnished. Vendor shall, at AT&T's option, return
to AT&T, or hold for AT&T's disposition, any or all of such material provided by AT&T under this
Agreement upon termination of this Agreement or the withdrawal of the material furnished; provided
however, that with respect to any scrap produced as a by-product remaining in Vendor's possession at
the completion of all Work to be provided at a Cell Site, Vendor shall, at AT&T's option, return to
AT&T, or hold for AT&T's disposition, such scrap material for a period of one hundred twenty (120)
days following the earlier of Location Acceptance at such Cell Site or the earlier termination of
this Agreement with respect to such Cell Site.

At all times and at Vendor's expense, Vendor shall maintain property insurance for all perils, for
full replacement cost for all property of AT&T in the care, custody and control of the Vendor. AT&T
shall be named as an additional insured and loss payee.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 43

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 49 -->
3.42 Transaction Costs. Except as expressly provided in this Agreement, each Party shall bear its
own fees and expenses (including the fees and expenses of its agents, representatives, attorneys,
and accountants) incurred in connection with the negotiation, drafting, execution, and performance
of this Agreement and the transactions it contemplates.

3.43 Utilization of Minority, Women, and Disabled Veteran Owned Business Enterprises

(a) Vendor shall submit annual participation plans in the form set forth at
http://www.attsuppliers.com no later than the Effective Date and by December 31 of each calendar
year thereafter, establishing Vendor's goals for the upcoming reporting period for participation by
minority owned business enterprises ("MBE"), women owned business enterprises ("WBE") and disabled
veteran owned business enterprises ("DVBE"), with "participation" expressed as a percentage of
aggregate estimated annual purchases by AT&T for the reporting period.

(b) By the tenth day following the close of each calendar month, Vendor shall, in a format and
manner acceptable to AT&T, report actual results of its efforts to meet the goals set forth in the
applicable participation plan during the preceding calendar month. When reporting results, Vendor
shall count only expenditures with entities that are certified as MBE, WBE, or DVBE firms by third
party certifying agencies recognized by AT&T, as listed on http://www.attsuppliers.com.

3.44 Vendor Personnel and Employment Matters

(a) Personnel provided by Vendor shall be considered solely the employees of Vendor or its
Subcontractors and not employees or agents of AT&T. Vendor has and shall retain the right to
exercise full control of and supervision over the performance of the Services and full control over
the employment, direction, assignment, compensation, and discharge of all personnel performing the
Services. Vendor and its Subcontractors are and shall be solely responsible for all matters relating
to compensation and benefits for all personnel provided by Vendor. Vendor shall ensure that all
persons furnished by Vendor conduct themselves in a professional manner and in accordance with all
policies set forth in this Agreement, the Build Addendum and the Maintenance Addendum.

(b) If AT&T requests that Vendor or its Subcontractor remove any person provided by Vendor or its
Subcontractor from AT&T's account for any lawful reason, then Vendor shall immediately comply with
such request. Vendor shall, at no cost to AT&T, provide a qualified replacement.

3.45 Warranty

(a) The warranty period for all Material (excluding AT&T Provided Equipment) shall commence upon
Delivery of such Material to Vendor from the OEM and shall continue for a period equal to the longer
of (i) [***] or (ii) the applicable warranty period actually received by Vendor from the OEM for
such Material Vendor acquired directly from the OEM, including the Vendor Provided Equipment as
defined in the Build Addendum (the "Material Warranty Period"). Vendor provides no warranty for
Material with respect to any AT&T Provided Equipment. The warranty period for workmanship and all
Services provided

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 44

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 50 -->
hereunder, including the Build Services contemplated in the Build Addendum, shall commence upon
Location Acceptance of the applicable Cell Site and continue for a period equal to [***] from
Location Acceptance of the applicable Cell Site (the "Workmanship Warranty Period"). For the
duration of such warranty period, Vendor represents and warrants to AT&T as follows:

(i) Material (excluding AT&T Provided Equipment) furnished hereunder will be merchantable, free from
defects in design, material and workmanship, fit and sufficient for the purposes set forth in the
Agreement, free from all Liens at the time of Location Acceptance, and will during the Material
Warranty Period strictly conform to and perform in accordance with applicable Specifications,
drawings and samples.

(ii) Services provided hereunder will be performed (A) in a professional and efficient manner, in
strict compliance with the Specifications, (B) with the care, skill, and diligence, and in
accordance with professional industry standards and practices, currently recognized in Vendor's
profession or industry, (C) in compliance with all applicable Laws and all descriptions and
representations as to the Services (including performance capabilities, accuracy, completeness,
characteristics, specifications, configurations, standards, functions and requirements) set forth in
this Agreement, the Build Addendum and the Maintenance Addendum (and all schedules thereto), and (D)
by personnel with appropriate experience, knowledge and competence. If Vendor fails to meet
applicable professional standards, Vendor will, without additional compensation, promptly correct or
revise any errors or deficiencies in the Services furnished hereunder.

(b) In addition, Vendor represents and warrants that:

(i) Vendor is duly organized, validly existing and in good standing under the laws of its state of
formation with all requisite power to enter into and perform its obligations under this Agreement,
the Build Addendum and the Maintenance Addendum and has the full power, authority and right to
provide the Material and Services specified herein;

(ii) The execution, delivery and performance of this Agreement, the Build Addendum and the
Maintenance Addendum has been duly and validly authorized and approved by all necessary action of
Vendor and will constitute legal, valid and binding obligations of Vendor enforceable in accordance
with their respective terms;

(iii) Vendor has (or will have at the time of the performance of the applicable Services) and will
continue to hold during the performance of the applicable Services during the Term of this Agreement
(or the Build Addendum Term or Maintenance Addendum Term, as applicable) all permits, licenses and
Contracts required to enter into and perform this Agreement, the Build Addendum and Maintenance
Addendum and to deliver the Material and Services hereunder;

(iv) As of the Effective Date, there are no actions, suits, or proceedings, pending or threatened,
which will have a material adverse effect on Vendor's ability to fulfill its

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 45

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 51 -->
obligations under this Agreement and Vendor will immediately notify AT&T if, during the Term, Vendor
becomes aware of any such action, suit, or proceeding;

(v) Vendor has, as of the Effective Date, and will continue to have during the Term of the Build
Addendum or Maintenance Addendum, as applicable, all necessary skills, rights, and financial
resources (including any required binding commitments for financing from third Persons) applicable
to such obligations then in effect, and authority to enter into this Agreement, the Build Addendum
or the Maintenance Addendum, including the authority to provide or license the Material or Services,
and satisfy all of its obligations hereunder and thereunder;

(vi) As of the Effective Date, no third party claim has been alleged against Vendor that any
Material and Services provided hereunder infringes upon such third party's intellectual property
rights and Vendor will immediately notify AT&T if, during the Term, Vendor becomes aware of any such
third party claim;

(vii) No consent, approval, or withholding of objection is required from any entity, including any
governmental authority, with respect to the entering into or the performance of this Agreement, the
Build Addendum or the Maintenance Addendum;

(viii) At the time of Location Acceptance (or, if later, at the time of Delivery), the Material and
Services will be provided free of any Lien of any kind;

(ix) Vendor will be fully responsible and liable for all acts, omissions, and Work performed by any
of its representatives, including any Subcontractors;

(x) All representatives, including Subcontractors, will strictly comply with the provisions
specified in this Agreement and all applicable Laws;

(xi) Vendor will strictly comply with the terms of this Agreement, the Build Addendum and the
Maintenance Addendum, including those specified in any exhibits, schedules or appendices attached
hereto or thereto; and

(xii) All Material provided to AT&T hereunder shall be tested by or on behalf of Vendor prior to
installation and prior to Location Acceptance to ensure its compliance with the Specifications.

(c) All representations and warranties set forth above in Section 3.46(b) or elsewhere in this
Agreement (other than the specific warranty periods specified in Section 3.46(a)) will survive
expiration or termination of this Agreement for a period of [***] years from such expiration or
termination; provided however, that any such representation and warranty that relates solely to the
Build Services provided pursuant to the Build Addendum shall survive for a period of [***] years
following Location Acceptance of all Cell Sites. The foregoing warranties will be in addition to all
other warranties, express, implied or statutory. Vendor shall defend, indemnify and hold AT&T, its
Affiliates, and their agents and representatives harmless from

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 46

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 52 -->
and against all Third Party Losses arising out of or resulting from a breach of these
representations and warranties, in accordance with the Section herein entitled "Indemnity".

(d) If at any time during the warranty period for Material or Services AT&T believes there is a
breach of any warranty, AT&T will notify Vendor setting forth the nature of such claimed breach.
Vendor shall promptly investigate such claimed breach and shall either (i) provide Information
satisfactory to AT&T that no breach of warranty in fact occurred or (ii) at no additional charge to
AT&T, promptly take such action as may be required to correct such breach. If the required
corrective action is to re-perform the Services and/or repair the Material, and if Vendor fails or
refuses to make such repairs and/or re-perform such Services, then, in addition to any other
remedies, AT&T shall have the right, at its option, either (1) to perform such Services and to
repair such Material itself or engage a third party to do so, in either case at Vendor's expense; or
(2) to receive a full refund of any amounts paid for such Material and Services. Vendor shall bear
all transportation costs and risk of loss and damage in transit with respect to all Material
transported in connection with this Section, and all repaired and replacement Material is warranted
as provided herein.

(e) If a breach of warranty for which Vendor is responsible has not been corrected within a
commercially reasonable time, and such breach has caused material and irreparable damage and harm to
AT&T, then upon thirty (30) days' notice to Vendor, AT&T may terminate this Agreement with respect
to the applicable Cell Site(s) without further liability to Vendor for those Cell Sites.

3.46 Subcontractors; Work Done By Others.

(a) If any part of Vendor's Work is dependent upon work performed by others or subcontracted
consistent with the terms herein, Vendor shall inspect and promptly report to AT&T any defect that
renders such other work unsuitable for Vendor's proper performance. Vendor's silence shall
constitute approval of such other work as fit, proper and suitable for Vendor's performance of its
Services or provision of Material.

(b) Any use of, including any changes to the use of, a Subcontractor shall be subject to the
requirements of this Section 3.46. Vendor shall provide and keep current a list of all
Subcontractors and certain information about each such Subcontractor, including the identity of, the
location of, and a complete description of the activities to be performed by such Subcontractor.
Vendor will provide such list of Subcontractors to AT&T upon request. If AT&T notifies Vendor that a
particular Subcontractor is unacceptable to AT&T because use of the Subcontractor could adversely
affect the security of AT&T's networks, or cause material financial harm to AT&T, or have a material
and detrimental effect on AT&T's reputation, Vendor shall promptly cease use of such Subcontractor
and provide a replacement Subcontractor or perform the Services itself. Should Vendor fail or refuse
to cease use of any Subcontractor and provide a substitute Subcontractor or perform the Services
itself after AT&T's request, AT&T shall have the right to terminate this Agreement. Where a portion
of the Work is subcontracted, Vendor remains fully responsible for performance thereof and shall be
responsible to AT&T for the acts and omissions of any Subcontractor, to the same extent as if such
acts or omissions were performed by Vendor. Nothing in this Agreement shall create

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 47

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 53 -->
any contractual obligation or other liability of AT&T to any Subcontractor or its employees. Vendor
shall require all Subcontractors performing Work on the project or who may enter upon the Work site
to maintain the same insurance requirements as those set forth in the Section entitled "Insurance"
of this Agreement. Vendor agrees to bind every Subcontractor to terms consistent with the terms of
this Agreement. Prior to Location Acceptance of all Cell Sites pursuant to the Build Addendum,
Vendor shall immediately notify AT&T of any (i) failure or inability of Vendor to pay to any
Subcontractor or other Vendor Person when due any amount owed to such Subcontractor or Vendor Person
or (ii) any claim, notice or action asserted by any such Subcontractor or Vendor Person of or
relating to any such failure or inability to pay amounts when due. Following Location Acceptance of
all Cell Sites pursuant to the Build Addendum, Vendor shall immediately notify AT&T of any (x)
failure (in the absence of a good faith dispute) or inability of Vendor to pay to any Subcontractor
or other Vendor Person when due any amount owed to such Subcontractor or Vendor Person or (y) any
claim, notice or action asserted by any such Subcontractor or Vendor Person of or relating to any
such failure (in the absence of a good faith dispute) or inability to pay amounts when due.

3.47 Affordable Care Act. For purposes of the Affordable Care Act (ACA), and in particular for
purposes of Section 4980H of the Internal Revenue Code of 1986, as amended, and the regulations
thereunder, with respect to each individual provided by Vendor to work on AT&T project(s) for at
least thirty (30) hours per week for at least ninety (90) days, whether consecutive or not, Vendor
represents and warrants that it or one of its Subcontractors is the common law employer of such
individual and shall be responsible for either providing healthcare coverage as required by the ACA
(to the extent applicable) or for paying any Section 4980H assessable payments that may be required
for failure to provide to such individual: (a) health care coverage, or (b) affordable healthcare
coverage. In no event will AT&T be considered to be the common law employer of such individual for
purposes of the ACA. Vendor shall maintain for a period of ten (10) years (or such shorter period as
required by applicable Law) information to show compliance with the ACA notwithstanding any other
provision in this Agreement to the contrary.

3.48 Customer Information

(a) As between Vendor and AT&T, title to all Customer Information and customer proprietary network
information ("CPNI") (as that term is defined in Section 222 of the Communications Act of 1934, 47
U.S.C. §222 (as amended, "Section 222")) shall be in AT&T. Except as otherwise provided herein, no
license or rights to any Customer Information are granted to Vendor hereunder.

(b) Vendor acknowledges that Customer Information received may be subject to certain privacy laws
and regulations and requirements, including requirements of AT&T. Vendor shall consider Customer
Information to be private, sensitive and confidential. Accordingly, with respect to Customer
Information, Vendor shall comply with all applicable privacy laws and regulations and requirements,
including the CPNI restrictions contained in Section 222. Accordingly, Vendor shall:

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 48

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 54 -->
(i) not use any CPNI to market or otherwise sell products to AT&T's customers, except to the extent
necessary for the performance of Services for AT&T or as otherwise approved or authorized by AT&T in
this Agreement or in writing;

(ii) make no disclosure of Customer Information to any party other than AT&T, except to the extent
necessary for the performance of Services for AT&T or except such disclosure required under force of
law; provided that Vendor shall provide AT&T with notice immediately upon receipt of any legal
request or demand by a judicial, regulatory or other authority or third party to disclose or produce
Customer Information; Vendor shall furnish only that portion of the Customer Information that it is
legally required to furnish and shall provide reasonable cooperation to AT&T should AT&T exercise
efforts to obtain a protective order or other confidential treatment with respect to such Customer
Information;

(iii) not incorporate any Customer Information into any database other than in a database maintained
exclusively for the storage of AT&T's Customer Information;

(iv) not incorporate any data from any of Vendor's other customers, including Affiliates of AT&T,
into AT&T's customer database;

(v) make no use whatsoever of any Customer Information for any purpose except to comply with the
terms of this Agreement;

(vi) make no sale, license or lease of Customer Information to any other party;

(vii) restrict access to Customer Information to only those employees of Vendor that require access
to perform Services under this Agreement;

(viii) prohibit and restrict access or use of Customer Information by any of Vendor's other
customers, any of Vendor's affiliates, or third parties except as may be agreed otherwise by AT&T;

(ix) promptly return all Customer Information to AT&T upon expiration or termination of this
Agreement, unless expressly agreed or instructed otherwise by AT&T; and

(x) immediately notify AT&T upon Vendor's awareness of (1) any breach of the above- referenced
provisions, (2) any disclosure (inadvertent or otherwise) of Customer Information to any third party
not expressly permitted herein to receive or have access to such Customer Information, or (3) a
breach of, or other security incident involving, Vendor's systems or network that could cause or
permit access to Customer Information inconsistent with the above-referenced provisions, and such
notice shall include the details of the breach, disclosure or security incident. Vendor shall fully
cooperate with AT&T in determining, as may be necessary or appropriate, actions that need to be
taken including the full scope of the breach, disclosure or security incident, corrective steps to
be taken by Vendor, the nature and content of any customer notifications, law enforcement
involvement, or news/press/media contact etc., and Vendor shall not

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 49

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 55 -->
communicate directly with any AT&T customer without AT&T's consent, which such consent shall not be
unreasonably withheld.

3.49 Reimbursable Expenses. AT&T is not responsible for any travel, meal or other business related
expense incurred by Vendor, whether or not incurred in its performance of its obligations under this
Agreement, in addition to any such amounts that are included in the Structured Payments.

4.0 Special Terms

4.1 Access

(a) Following Location Acceptance and in connection with the Maintenance Addendum, Vendor shall have
reasonable access to AT&T's Cell Sites contemplated in the Build Addendum to enable Vendor to
perform its obligations under the Maintenance Addendum. Vendor shall coordinate such access with
AT&T's designated representative prior to visiting such premises. Vendor will ensure that only
Vendor Persons will be allowed to enter AT&T's premises by using AT&T systems, such as the NFSD
portal. If AT&T requests Vendor or its Subcontractors to discontinue furnishing any person provided
by Vendor or its Subcontractor from performing Work on AT&T's premises or at any Cell Site, Vendor
shall immediately comply with such request. Such person shall leave AT&T's premises or Cell Site
promptly, and Vendor shall not furnish such person again to perform Work on AT&T's premises without
AT&T's written consent. The Parties agree that, where required by governmental regulations, Vendor
will submit satisfactory clearance from the U.S. Department of Defense and/or other federal, state,
or local authorities.

(b) AT&T requires Vendor or its representatives, including any Vendor Persons, to exhibit
identification credentials, which AT&T may issue, to gain access to AT&T's premises for the
performance of Services. If for any reason, any Vendor Person is no longer performing such Services,
Vendor shall immediately inform AT&T. Notification shall be followed by the prompt delivery to AT&T
of the identification credentials, if issued by AT&T, or a written statement of the reasons why the
identification credentials cannot be returned.

(c) Vendor shall ensure that its representatives, including any Vendor Persons, while on or off
AT&T's premises, will (i) perform Services which conform to the Specifications, (ii) protect AT&T's
material, buildings, and structures, (iii) perform Work which does not interfere with AT&T's
business operations, and (iv) perform with care and due regard for the safety, convenience, and
protection of AT&T, its employees, and property.

4.2 AT&T Supplier Information Security Requirements (SISR). Vendor shall comply with AT&T's Supplier
Information Security Requirements (the "SISR") set forth in Exhibit B attached hereto and
incorporated herein by reference. Vendor shall cooperate fully with AT&T, including by completing
checklists or similar documentation, to ensure that Customer Information, AT&T Derived Data,
Software and/or computer systems

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 50

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 56 -->
Vendor develops, designs, supports and/or uses under this Agreement comply with the standards and
requirements set forth in the SISR.

4.3 Background Checks

(a) To assist AT&T's compliance with the law and its duties to protect its own employees and
customers, Vendor, and subject to any Laws to the contrary that limit any Vendor action otherwise
required by this Section, Vendor shall:

(i) make all reasonable efforts, including checking the background, verifying the personal
information and checking each Vendor Person's identification credentials, to determine all
information necessary to verify whether any Vendor Person whom Vendor proposes to have perform any
Service that permits Physical Entry or virtual or other access to AT&T's or its customers' systems,
networks, or Information ("Access") at any time during the term of this Agreement (provided that the
terms of this Section shall not apply to Vendor Persons having escorted access to secured AT&T areas
not available to the general public where such Vendor Persons will not be providing "Services",
delivering/installing "Material", or otherwise engaged in work activities under this Agreement,
e.g., does not apply to attending meetings, reviewing locations to prepare contract bids, etc.):

(1) has been convicted of any felony, or has been convicted of any misdemeanor involving violence,
sexual misconduct, theft or computer crimes, fraud or financial crimes, drug distribution, or crimes
involving unlawful possession or use of a dangerous weapon ("Conviction") or is identified on any
government registry as a sex offender ("Sex Offender Status"); and

(2) in addition to the requirements of Subsection (1) above, perform a Drug Screen on any Vendor
Person whom Vendor proposes to have access to Customer Information, Systems, or Physical Entry onto
AT&T's or its customers' premises, and not permit any such Vendor Person presenting a positive Drug
Screen to have access to Customer Information, Systems, or Physical Entry onto AT&T's or its
customers' premises.

(ii) Comply with the obligations of Subsection (a)(i)(1) above by a Background Check, including
credit history, employment history, driving records and criminal history ("Background Check") of
applicable records for those counties, states, and federal court districts in which a proposed
Vendor Person has identified as having resided, worked, or attended school in the previous ten (10)
years, unless a shorter period is required by any Laws.

(b) It is Vendor's sole and exclusive responsibility to determine whether a Vendor Person's
Conviction or Sex Offender Status has a reasonable relationship to the individual's fitness or
trustworthiness to perform the Service or other work activity, subject to applicable Laws on the
consideration of criminal convictions in making employment decisions. If however a Vendor Person
needs to have Physical Entry onto the premises of an AT&T customer, AT&T may require additional
background information about and/or drug screening for the Vendor Person, when required by
applicable Law, before permitting that individual to enter the customer's premises.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 51

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 57 -->
(c) Upon discovering that any Vendor Person has falsified any of his or her Social Security number,
driver's license, educational credentials, employment history, home address, and citizenship
indicia, such Vendor Person shall not have Access or perform work for AT&T under this Agreement.
Vendor shall maintain records of all Background Checks and Drug Screens performed for Vendor Persons
under this Agreement for the Term of this Agreement, or for such shorter period if provided by
applicable Law, for AT&T to verify compliance with this Section.

4.4 Clean Up. Vendor at all times, and at its expense, shall keep AT&T and its landlord's premises
safe and free from accumulation of waste materials or rubbish caused by Vendor's operations. Upon
completion of the Work, Vendor shall, at its expense, remove promptly from the premises all of
Vendor's implements, equipment, tools, machines, surplus and waste materials and debris. If Vendor
fails to clean up as provided herein, AT&T may hire another contractor to do so and charge the cost
thereof to Vendor or deduct same from AT&T's payments to Vendor.

4.5 Vendor's Audited Financial Statements. Vendor shall provide to AT&T (or its third party
delegate), upon request and at no charge, its parent company, ATN International, Inc.'s bona fide
and unedited: (a) financial statements for each quarter of each fiscal year during the term of the
Build Addendum and (b) audited fiscal year financial statements for each fiscal year during the Term
hereof.

4.6 Vendor Personnel Information. In order to satisfy physical and network security requirements for
AT&T, which may include both issuance of a building access badge and picture ID badge to Vendor
personnel, Vendor and/or its personnel agree to provide any and all personal information required by
the AT&T security department. This information includes, but is not limited to, social security
numbers. Vendor personnel will not be authorized to perform Work for AT&T if Vendor personnel refuse
to provide any and all information necessary to complete the process of issuing a badge or acquiring
network access. AT&T will not be required to pay Vendor for the time spent trying to acquire a badge
or network access for Vendor personnel while on premises at AT&T.

Vendor is responsible for notifying the AT&T project manager of all Vendor information related to
new hires, termination or changes in information. This includes but is not limited to starting date,
end date and location changes.

4.7 Damage to Property. Vendor assumes full responsibility for any damage or loss to AT&T's property
that may be caused by or result from any tortious act or omission of Vendor or any person employed
by or under contract with Vendor. In the event of such damage, AT&T may elect to have repairs made
by Vendor, by AT&T personnel, or by other contractors. In the event AT&T shall elect to have Vendor
repair the damage, Vendor shall promptly do so, at its own expense and to AT&T's satisfaction. In
the event AT&T

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 52

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 58 -->
shall elect to have the damage repaired by its own personnel or other contractors, Vendor shall
reimburse AT&T for the cost to it of such repairs.

If Vendor causes damage to AT&T's property, including damage to copper or fiber cable, Vendor shall
reimburse AT&T for any actual direct damages or losses incurred in connection therewith.

4.8 Dispute Resolution.

(a) Escalation Procedure. The Parties agree to seek to resolve any dispute between the Parties or
otherwise arising out of this Agreement or an Addendum in accordance with the following escalation
procedures before commencing the arbitration procedures described below.

(i) The contact persons of both Parties shall work in good faith to try to resolve the dispute
within twenty (20) days from the date that a Party first gives notice that a dispute has occurred.

(ii) If the contact persons fail to reach an agreement on the dispute within twenty (20) days, the
dispute shall be referred to more senior persons within the respective Parties who shall try to
resolve the dispute within a further twenty (20) day period. If no resolution is found each Party is
entitled to commence the arbitration proceedings described below.

(b) Arbitration. Any controversy or claim between the Parties or otherwise arising out of or
relating to this Agreement, or the breach thereof, other than any action taken to enforce the right
to payment of Structured Payments, shall be resolved by arbitration administered by the American
Arbitration Association under its Commercial Arbitration Rules then in effect, and judgment on the
award rendered by the arbitrator(s) may be entered in any court having jurisdiction thereof. Each of
the Parties hereby submits to the jurisdiction of the United States District Court for the Southern
District of New York and of any New York state court sitting in New York, New York for purposes of
all actions taken to enforce the right to payment of the Structured Payments.

(c) Locale. The hearings shall be held at a mutually agreed upon location within the United States
at which the Parties may present evidence (including, without limitation, witnesses and
documentation) and argument in support of their respective positions. If the Parties cannot agree
upon an arbitration location within 3 business days, the arbitration shall be conducted in New York
City, New York.

(d) Award. The arbitrators shall make a reasoned award which may include an award of damages (but
may not include attorney fees except in a case where a Party has failed to defend or indemnify the
other Party where it had an obligation to do so pursuant to Sections 3.15 or 3.36) and said award
shall be in writing setting forth the statement of facts to support their conclusions and decision.
The decision rendered by the arbitrators will be final, conclusive, and binding upon the Parties,
and any judgment thereon may be entered and enforced in any court of competent jurisdiction.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 53

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 59 -->
(e) Continuation of Service Pending Arbitration. Vendor and AT&T will continue to provide all
Services and honor all other commitments under this Agreement in accordance with this Agreement
during the course of resolution of disputes and arbitration pursuant to this Agreement.

4.9 Electronic Data Interchange (EDI)

(a) The Parties may exchange orders, payments, acknowledgements, invoices, remittance notices, and
other records ("Data") electronically, in place of tangible documents, and agree to exchange such
Data in accordance with the Telecommunications Industry Forum EDI Guidelines for use of American
National Standards Institute (ANSI) Accredited Standards Committee X12 transaction sets, unless they
mutually agree to a proprietary format or another standard such as Extensible Markup Language (XML).

(b) The following additional conditions apply to any such exchanges:

(i) Garbled Transmissions: If any Data is received in an unintelligible, electronically unreadable,
or garbled form, the receiving Party shall promptly notify the originating Party (if identifiable
from the received Data) in a reasonable manner. In the absence of such notice, the originating
Party's record of the contents of such Data shall control.

(ii) Signatures: Each Party will incorporate into each EDI transmission an electronic identification
consisting of symbol(s) or code(s) ("Signature"). Each Party agrees that any predetermined Signature
of such Party included in or affixed to any EDI transmission shall be sufficient to verify such
Party originated, "signed" and "executed" such transmission. No Party shall disclose to any
unauthorized Person the Signatures of the Parties hereto.

(iii) Statute of Frauds: The Parties expressly agree that all Data transmitted pursuant to this
clause shall be deemed to be a "writing" or "in writing" for purposes of the Uniform Commercial Code
(UCC). Any such Data containing or having affixed to it a Signature shall be deemed for all purposes
to: (i) to have been "signed" and "executed"; and (ii) to constitute an "original" when printed from
electronic files or records established and maintained in the normal course of business.

(iv) Method of Exchange: Exchange of Data will be made by direct electronic or computer systems
communication between AT&T and Vendor or by indirect communications using a third party service
provider ("Provider") or Value Added Network ("VAN") to translate, forward and/or store such Data.
Each Party shall be responsible for the cost(s) and associated cost(s) of any Provider or VAN with
which it contracts.

(v) When the Parties are using EDI, the requirements of the EDI system will govern and will control
if in conflict with any other provision of this Agreement.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 54

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 60 -->
4.10 Emergency Work. In an emergency, AT&T's representative may orally request Vendor to perform
Work.

4.11 Hazardous Material and Regulated Substances

(a) If Vendor or its Subcontractors provide Material and/or Services in a state other than
California, then Subparagraphs (i) through (iv) of this Subsection (a) shall apply.

(i) A "Regulated Substance" as referenced in this Subsection is a generic term used to describe all
materials that are regulated by the federal or any state or local government during transportation,
handling and/or disposal. This includes, but is not limited to, materials that are regulated as (a)
"hazardous materials" under the Hazardous Materials Transportation Act, (b) "chemical hazards" under
the Occupational Safety and Health Administration (OSHA) standards, (c) "chemical substances or
mixtures" under the Toxic Substances Control Act, (d) "pesticides" under the Federal Insecticide,
Fungicide and Rodenticide Act and (e) "hazardous wastes" as defined or listed under the Resource
Conservation and Recovery Act.

(ii) Vendor shall comply with all applicable Laws, including any notice requirements, regarding any
Material ordered hereunder which contains or consists of a Regulated Substance or any Service
ordered hereunder which involves the handling, use, storage, recycling, disposal or transportation
of Regulated Substances. Vendor shall notify AT&T and provide AT&T with all necessary information
(including but not limited OSHA Material Safety Data Sheets (MSDS)) at least thirty (30) days before
shipping Material containing or consisting of Regulated Substances to AT&T or commencing the
performance of Services for AT&T involving the handling or use of Regulated Substances. Each MSDS
must include information indicating the specific worker protection equipment requirement for use of
the Regulated Substance covered thereby.

(iii) AT&T and Vendor shall cooperate concerning the acceptance of any Material containing or
consisting of a Regulated Substance or for Services involving the handling or use of Regulated
Substances. Vendor shall provide assistance to AT&T of an advisory nature in the handling and use of
Regulated Substances provided hereunder and the disposal of "hazardous waste", as defined by
applicable Laws ("Hazardous Wastes"), resulting therefrom.

(iv) Vendor shall provide AT&T with the same information pertaining to Regulated Substances in the
Material and Services and used in the Services it provides to AT&T or Hazardous Waste resulting
therefrom as Vendor provides to Vendor's employees or agents involved in the disposition or
treatment of such Regulated Substances or Hazardous Waste.

(b) If Vendor or its Subcontractors provide Material and/or Services in the state of California,
then Subparagraphs (i) through (vi) of this Subsection (b) shall apply.

(i) A "Regulated Substance" as referred to in this Subsection is a generic term used to describe all
materials that are regulated by federal or any state or local government during transportation,
handling and/or disposal. These include, but are not limited to, materials

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 55

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 61 -->
that are regulated as (a) "hazardous material" under the Hazardous Material Transportation Act and
the Control of Radioactive Contamination Law, Title 8 of the California Code of Regulation, Section
5194, and the Hazardous Substances Information and Training Act, (b) "chemical hazards" under the
Occupational Safety and Health Administration (OSHA) standards, (c) "chemical substances and
mixtures" under the Toxic Substances Control Act and "chemicals" on the Governor's List known to the
State of California to cause cancer, birth defects, and/or other reproductive harm, as that term is
defined in the California Safe Drinking Water and Toxic Enforcement Act of 1986 ("Proposition 65"),
(d) "pesticides" under the Federal Insecticide, Fungicide and Rodenticide Act, and (e) "hazardous
waste" as defined or listed under the Resource Conservation and Recovery Act and the Hazardous Waste
Control Law.

(ii) Vendor shall comply with all applicable Laws, including any notice requirements, regarding any
Material ordered hereunder which contains or consists of a Regulated Substance or any Service
ordered hereunder which involves the use, handling, storage, recycling, disposal or transportation
of Regulated Substances. Vendor shall notify AT&T and provide AT&T with all necessary information
(including but not limited OSHA Material Safety Data Sheets (MSDS)) at least thirty (30) days before
shipping Material containing or consisting of Regulated Substances to AT&T or commencing the
performance of Services for AT&T involving the handling or use of Regulated Substances. Each MSDS
must include information indicating the specific worker protection equipment requirement for use
with the Regulated Substance covered thereby. If the Regulated Substance is a chemical defined by
Proposition 65, the MSDS for said chemical should indicate that the chemical is one which is known
to the state of California to cause cancer, birth defects or other reproductive harm. Vendor shall
maintain and distribute such information upon request to AT&T and/or any other Vendor at the same
location.

(iii) AT&T and Vendor shall cooperate concerning the acceptance by AT&T of any Material consisting
of or containing a Regulated Substance or Service involving the use and handling of Regulated
Substances. Vendor shall provide assistance to AT&T of an advisory nature in the handling and use of
Hazardous Wastes provided hereunder and the disposal of Hazardous Wastes resulting therefrom.

(iv) Vendor shall provide AT&T with the same information pertaining to Regulated Substances in or
used in the Material and Services it provides to AT&T or Hazardous Waste as Vendor provides to
Vendor's employees or agents involved in the disposition or treatment of such Regulated Substances.

(v) Vendor shall, and shall require its Subcontractors to, issue warnings in accordance with
Proposition 65 for exposure to chemicals covered by Proposition 65 introduced by Vendor or its
Subcontractor to personnel at AT&T's California facilities, the public and AT&T from the time Vendor
and/or its Subcontractor enter AT&T's California facilities and/or commences performing Services
through the completion of such performance. Vendor shall, and shall require its Subcontractors to,
warn AT&T of any exposure to chemicals covered by Proposition 65, which may continue after Vendor or
its Subcontractors have

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 56

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 62 -->
completed the performance of Services. Such warning may take the form of, but not be limited to, a
MSDS for each such chemical.

(vi) VENDOR IS HEREBY WARNED IN ACCORDANCE WITH PROPOSITION 65 THAT EXPOSURE TO CHEMICALS MAY OCCUR
AT AT&T'S FACILITIES. VENDOR IS ALSO HEREBY WARNED THAT AT&T POLES MAY CONTAIN CHEMICALS KNOWN TO
THE STATE OF CALIFORNIA TO CAUSE CANCER IN CERTAIN SITUATIONS. If requested, AT&T shall make
available to Vendor, its Subcontractors, and any of their employees, a MSDS for the chemicals
covered by Proposition 65, if any, at AT&T's facilities where Vendor is providing Services or in
poles which will be handled by or sold to Vendor hereunder. Vendor shall issue appropriate warnings
to inform and educate employees, agents, Subcontractors, other invitees and employees of any of
them, entering AT&T's facilities or handling poles hereunder of the above information in accordance
with applicable Laws.

4.12 Identification of Vendor's Personnel and Equipment. Vendor's personnel, who may have contact
with the public while performing Work for AT&T, shall carry and display upon request identification
showing that they are the employees of Vendor. Vendor's personnel shall be responsible for securing
permission to enter upon private property when entry is necessary to Vendor's performance of the
Service.

4.13 Independent Contractor. Vendor hereby represents and warrants to AT&T that:

(a) Vendor is engaged in an independent business and will perform all obligations under this
Agreement as an independent contractor and not as the agent or employee of AT&T;

(b) Vendor's personnel performing Services shall be considered solely the employees or agents of
Vendor and not employees or agents of AT&T;

(c) Vendor has and retains the right to exercise full control of and supervision over the
performance of the Services and full control over the employment, direction, assignment,
compensation and discharge of all personnel performing the Services; and

(d) Vendor is solely responsible for all matters relating to compensation and benefits for all of
Vendor's personnel who perform Services. This responsibility includes, but is not limited to, (i)
timely payment of compensation and benefits, including, but not limited to, overtime, medical,
dental, and any other benefit, and (ii) all matters relating to compliance with all employer
obligations to withhold employee taxes, pay employee and employer taxes, and file payroll tax
returns and information returns under local, state, and federal income tax laws, unemployment
compensation insurance and state disability insurance tax laws, social security and Medicare tax
laws, and all other payroll tax laws or similar laws with respect to all Vendor personnel providing
Services. Vendor will indemnify, defend, and hold AT&T, its Affiliates, and their respective agents
and employees, harmless from and against all Loss, arising out of or related to Vendor's failure to
comply with this Subsection (d), in accordance with the Section titled "Indemnity."

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 57

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 63 -->
4.14 Inspection of Material. Vendor shall inspect all Material used in the performance of the Work,
whether or not furnished by AT&T, for defects or hazardous conditions which could cause property
damage, personal injury, or otherwise affect the quality of the Work. Vendor shall report all
defects or hazardous conditions to an AT&T representative as soon as the defect has been identified.

4.15 Inspection of Work. AT&T may have inspectors at the Cell Sites to inspect the performance and
quality of the Work and to ensure Vendor's compliance with the plans and Specifications and with the
terms and conditions of this Agreement. Any AT&T inspectors, employees or agents, however, shall
have no authority to direct or advise Vendor concerning the method or manner by which the Work is to
be performed. Vendor has sole authority, responsibility and control over the Work and shall exercise
its full responsibilities as an independent contractor.

4.16 Liens

(a) At the time of Location Acceptance (or, if delivered thereafter, at the time of Delivery), the
Work (including the Material and Services provided) shall be delivered to AT&T free and clear of all
Liens of any kind. Following Location Acceptance of each Cell Site, if any Lien or notice of Lien is
recorded or stop notice is served upon AT&T for or in connection with labor performed upon, or for
or in connection with furnishing Material for use in, or for or in connection with furnishing
appliances, teams or power contributing to, the Work (including without limitation Liens securing
indebtedness for money borrowed or any obligations for the deferred purchase price of property or
services related to or in connection with the Work), Vendor shall promptly discharge any such Liens
and shall furnish AT&T with release vouchers or termination statements in settlement and
satisfaction of such Liens in forms satisfactory to AT&T. If Vendor does not settle such a Lien or
cause the Lien to be released and discharged within a reasonable period of time, not to exceed sixty
(60) days after the Lien is filed or asserted, then AT&T shall have the right to procure the
discharge of the Lien and, in such event, Vendor shall reimburse AT&T for all moneys paid by AT&T to
procure the discharge, including costs and Attorneys' Fees. AT&T may require Vendor to prove payment
of bills for Services, Material, or other things furnished or done for the performance of the Work,
before making payment to the Vendor. AT&T may request at the time of Location Acceptance of each
Cell Site that Vendor furnish an affidavit, stating that all bills in question have been paid in
full, and that there are no outstanding claims, admitted or disputed, except as stated in the
affidavit. AT&T may request that Vendor furnish receipts, release and Lien waivers, and Lien
terminations releasing any Lien. AT&T reserves the right to pay any undisputed bill directly to such
Person to whom it is owed and offset the amount (plus any other amounts permitted under this
Section) pursuant to Section 3.22 against any amount payable to Vendor.

(b) To the extent permitted by applicable state law, Vendor agrees that no mechanic's liens or other
claim or claims in the nature of a Lien or charge shall be filed or maintained by Vendor or by any
claimant claiming through Vendor against the real estate owned by, leased by, licensed to, or
otherwise used or occupied by AT&T, or against any Structured Payments or Maintenance Fees, and that
such right to file any such Lien is hereby expressly waived by Vendor. Vendor shall not serve or
file any notice or document, or take any other action, which

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 58

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 64 -->
would be a prerequisite for filing a claim for any Lien. Further, Vendor shall include the following
language in any of its contracts or permitted subcontracts with Persons performing the Work or
furnishing Material or Services:

"Subcontractor agrees that no mechanic's liens or other claim or claims in the nature of a lien or
charge for materials, labor, services or equipment in connection with the Services shall be filed or
maintained by Subcontractor or by any claimant claiming through Subcontractor against real estate
owned by, leased by, licensed to or otherwise used or occupied by Vendor or AT&T or against any
amounts due to or coming due from AT&T to the general contractor and that any such right to file
such lien, claim or charge is expressly waived."

In the event that any Lien described in this Section 4.16(b) is filed by Vendor or its Subcontractor
and Vendor does not remove such Lien within sixty (60) calendar days of written notification by
AT&T, AT&T will have the right, but not the obligation, to pay such sums or take such actions as it
deems necessary to have such Lien removed or discharged, and Vendor shall indemnify, defend and save
AT&T harmless from and against all resulting Losses, including Attorneys' Fees.

4.17 Notification of Injury or Damage. Vendor shall promptly notify AT&T of any injury, death, loss
or damage to persons, animals, or property which is in any way related to the Work performed under
this Agreement, even though such occurrence was not caused or contributed to by Vendor, its
employees, or its agents.

4.18 Protection of Property. Vendor shall immediately report to AT&T's representative any hazardous
or unusual conditions or damage to any property caused or observed by Vendor or Vendor's agents on
or about the property where the Work is being performed. Vendor agrees to make reasonable efforts to
watch for any type of unsatisfactory or unsafe plant condition in need of correction and report such
to AT&T's representative.

4.19 Releases Void. Neither Party shall require waivers or releases by any person or representative
of the other Party for visits to its premises, and no such releases or waivers shall be pleaded by
either Party in any action or proceeding.

4.20 Removal and Management of Used Batteries. Upon the Effective Date of this Agreement and
thereafter Vendor shall comply with the requirements set forth in AT&T's Appendix BA - Removal and
Management of Used Batteries ("RMUB") available at http://www.attsuppliers.com/misc/Appendix-BA-
Removal-and-Management-of-Used- Batteries.pdf and incorporated herein by reference. Vendor further
agrees to comply with the terms and conditions of the RMUB. Vendor agrees to cooperate fully with
AT&T, including completing checklists, surveys, or similar documentation, to ensure that any
management, shipment, smelting, recycling, and/or disposal of used batteries by Vendor and its
Subcontractors on behalf of AT&T comply with the standards and requirements set forth in the RMUB.
Note that the RMUB includes AT&T's requirement that all lead acid

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 59

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 65 -->
batteries used in the United States may not be exported outside of the United States for recycling,
smelting, or other disposition.

4.21 Resource Recovery Center. Vendor and any Subcontractors it utilizes to perform the Services
will accurately and completely fill out and sign any necessary shipping documentation on behalf of
AT&T or as an authorized agent of AT&T prior to transporting Hazardous Waste, hazardous materials,
or universal waste off-site for disposal. Prior to leaving any AT&T facility with such Hazardous
Waste, hazardous materials, or universal waste for disposal off-site, Vendor shall sign and date any
required shipping documentation on behalf of AT&T and provide a copy of the signed shipping
documents to the responsible AT&T employee. Vendor shall subsequently fax a copy of the final
shipping document (with signatures) to the AT&T RRC for retention in the project file (if
applicable) and mail the original generator copy to the RRC not more than fifteen (15) days after
pick-up. Documentation shall be mailed to the appropriate address as detailed below:

Outside of California: AT&T Services Inc., Attn: Environment, Health & Safety (EH&S), Resource
Recovery Center (RCC), One AT&T Way, Room 2C140, Bedminster, NJ 07921-- Phone: (800) 566- 9347
(Prompt 4) -- Fax: (512) 646-3596

California: AT&T Services Inc., Attn: Environment, Health & Safety (EH&S), Resource Recovery Center
(RCC), P.O. Box 5095, Room 3E000, San Ramon, CA 94583-0995 -- Phone: (800) 566-9347 (Prompt 4) -
Fax: (925) 973-0584.

4.22 Safety Management

(a) Vendor is responsible for the safe performance of all Services provided hereunder, and shall
maintain a safety program appropriate to the Services being performed which complies with all laws
and any requirements applicable to the Services. Vendor shall have at least Support Membership
status (as defined by NATE) with the National Association of Tower Erectors ("NATE"), or a successor
organization approved by AT&T, and shall be actively engaged in implementing best practices, safety
requirements and training as advocated by the NATE organization or such successor organization.
Further, Vendor, its applicable Subcontractors and their respective tower crews are required to be
certified by a training provider recognized by NATE or such successor. Additionally, Vendor shall
ensure that all tower workers have Competent Climber certification as defined by OSHA.

(b) AT&T does not undertake to provide Vendor, its Subcontractors or their employees or
representatives with a safe place to work. Vendor is responsible for providing such a safe place to
work and shall not be relieved of its duties with regard to the safe performance of the Services by
reason of any conduct, acts or omissions of any inspector, employee or representative of AT&T or its
landlord or customer. Vendor shall take all reasonable measures and precautions at all times to
prevent any bodily injury (including death) of its personnel, its Subcontractors' personnel, and any
person who is on or near the premises where such Work is being performed. Vendor further agrees to
perform all Work and furnish tools and equipment that comply with known safety regulations,
practices, and precautions, including, but not limited to, regulations under the Occupational Safety
and Health Act of 1970, as amended, or regulations of any Federal, State or local authorities.
Vendor shall comply with the Federal

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 60

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 66 -->
Communications Commission ("FCC") regulations that cover Radio Frequency ("RF") radiation safety,
including ANSI C95.1-1982 adopted by the FCC in 1986, and 47 CFR 1.1310 RF Maximum Permissible
Exposure limits. Vendor shall operate under an RF safety program, and workers must be fully aware
and able to exercise control over their exposure to RF fields. Vendor shall establish a safety
organization to implement safety management roles and responsibilities, which include training
content and description, communications, inspection and audit, standards and criteria, and frequency
and timing of aforementioned aspects of the safety program. Vendor shall develop a system to record
and report tower crew personnel certificates, OSHA, EPA and other federal, state and local required
information for environmental and public health and safety. Vendor shall maintain staff necessary to
provide functional oversight and perform audits to ensure compliance at the national, regional, and
market level. Vendor shall provide a "recovery plan" within thirty (30) days of experiencing a
work-related or OSHA reportable "major incident" (hospital/death). Such plan shall identify what
specific failures contributed to the incident and what practices have been or will be implemented to
ensure that the incident does not recur. In the event of conflict between the requirements of this
Subsection and any Vendor requirements imposed on its Subcontractors, the stricter health and safety
requirements of the two shall prevail.

4.23 Technical Support. Vendor will provide, at no additional cost to AT&T, full and complete
technical assistance to AT&T for the Material and Services provisioned under this Agreement,
including ongoing technical support and field service and assistance, and telephone assistance to
assist with installation, operation, maintenance and problem resolution as set forth in the terms of
the Maintenance Addendum. The availability or performance of this technical support will not be
construed as altering or affecting Vendor's obligations as set forth in the "Warranty" Section or as
provided elsewhere in this Agreement. Field Service and technical support, including emergency
support (service affecting), will be available on call twenty-four (24) hours a day. Vendor will
provide to AT&T, and keep current, an escalation document that includes names, titles and telephone
numbers, including after-hours telephone numbers, of Vendor personnel responsible for providing
technical support to AT&T. Vendor will maintain a streamlined escalation process to speed resolution
of reported problems.

4.24 Testimony. Matters relating to Work under this Agreement may be at issue before various
governmental bodies. Vendor agrees to have appropriate members of its company willing to testify at
appropriate times at no additional cost, regarding any aspect of the Work, unless otherwise mutually
agreed upon by the Parties.

4.25 AT&T Data and AT&T Derived Data (Big Data)

(a) Definitions. For purposes of this Section:

(i) "AT&T Data" means any data or information (i) of AT&T or its customers, that is disclosed or
provided to Vendor by, or otherwise obtained by Vendor from, AT&T or any of its customers, including
Customer Information and customer proprietary network information (as that term is defined in
Section 222 of the Communications Act of 1934, as amended, 47 U.S.C. § 222), as well as data and
information with respect to the businesses, customers,

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 61

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 67 -->
operations, networks, systems, facilities, products, rates, regulatory compliance, competitors,
consumer markets, assets, expenditures, mergers, acquisitions, divestitures, billings, collections,
revenues and finances of AT&T; and (ii) not supplied by AT&T or any of its customers but created,
generated, collected or harvested by Vendor either (a) in furtherance of this Agreement or (b) as a
result of Vendor's having access to AT&T infrastructure, systems, data, hardware, software or
processes (for example, through data processing input and output, service level measurements, or
ascertainment of network and system information).

(ii) "AT&T Derived Data" means any data or information that is a result of any modification,
adaption, revision, translation, abridgement, condensation, compilation, evaluation, expansion or
other recasting or processing of the AT&T Data, for example, as a result of Vendor's observation,
analysis, or visualization of AT&T Data arising out of the performance of Vendor's obligations
hereunder.

(b) Ownership of AT&T Data and AT&T Derived Data.

(i) AT&T Data is the property of AT&T. To the extent needed to perfect AT&T's ownership in AT&T
Data, Vendor hereby assigns all right, title and interest in AT&T Data to AT&T. No transfer of title
in AT&T Data to Vendor is implied or shall occur under this Agreement. AT&T Data shall not be (a)
utilized by Vendor for any purpose other than as required to fulfill its obligations under this
Agreement, (b) sold, assigned, leased, commercially exploited or otherwise provided to or accessed
by third parties, whether by or on behalf of Vendor, (c) withheld from AT&T by Vendor, or (d) used
by Vendor to assert any Lien or other right against or to it. Vendor shall promptly notify AT&T if
Vendor believes that any use of AT&T Data by Vendor contemplated under this Agreement or to be
undertaken as part of the performance of this Agreement is inconsistent with the preceding sentence.

(ii) AT&T shall own all right, title and interest in and to the AT&T Derived Data. To the extent
needed to perfect AT&T's ownership in AT&T Derived Data, Vendor hereby assigns all right, title and
interest in AT&T Derived Data to AT&T. AT&T grants to Vendor a license to access, use, and copy the
AT&T Derived Data, with no right to grant sublicenses, solely for the performance of Vendor's
obligations during the Term of this Agreement and solely in compliance with AT&T's privacy policies,
including obligations relating to Customer Information. For the avoidance of doubt, Vendor shall not
create or develop AT&T Derived Data after the expiration or termination of this Agreement.

(iii) Vendor shall promptly deliver AT&T Data and AT&T Derived Data to AT&T at no cost to AT&T, and
in the format, on the media and in the timing prescribed by AT&T (i) at any time at AT&T's request,
(ii) at the expiration or termination of this Agreement and the completion of any requested
termination assistance services or (iii) with respect to particular AT&T Data or AT&T Derived Data,
at such earlier date that such data is no longer required by Vendor to perform the Services.
Thereafter, Vendor shall return or destroy, as directed by AT&T, all copies of the AT&T Data and
AT&T Derived Data in Vendor's possession or under Vendor's control within ten (10) business days and
deliver to AT&T written certification of such return or destruction signed by an officer of Vendor.

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 62

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 68 -->
(iv) The provisions of this Section shall apply to all AT&T Data and AT&T Derived Data, regardless
of whether such data was first disclosed or otherwise provided to, or created, developed, modified,
recast or processed by, Vendor before, on or after the Effective Date of this Agreement, and shall
survive the expiration or termination of this Agreement. Vendor shall secure AT&T Data and AT&T
Derived Data pursuant to the provisions applicable to AT&T Information under the Section titled
"AT&T Supplier Information Security Requirements (SISR)." Vendor's obligation to return AT&T Data
and AT&T Derived Data upon AT&T's request shall not apply to such data which, at the time of AT&T's
request for return, is no longer retained by or on behalf of Vendor.

4.26 Business Continuity Plan. Vendor shall maintain and upon AT&T's request, promptly furnish to
AT&T Supplier's Business Continuity Plan that complies with the requirements set forth in Appendix F
- Business Continuity Plan Requirements (BCPR) available at
http://attsuppliers.com/downloads/Business-Continuity- Plan-Requirements-BCPR.pdf, and incorporated
herein by reference, which may be changed from time to time by AT&T.

4.27 Change in Laws. If AT&T becomes aware of any change in Law or proposed change in Law, or there
occurs a change in Law, that has or reasonably would be expected to have an adverse impact on the
aggregate costs or aggregate benefits of transactions contemplated by this Agreement to AT&T
(including without limitation by causing AT&T to incur taxes, costs, losses or expenses as a result
of or in connection with the transactions contemplated by this Agreement that are incremental to
those that would have been incurred by AT&T in the absence of such change in Law), then AT&T may, as
promptly as reasonably practicable, inform the Vendor in writing of the change in Law or anticipated
change in Law and the impact or expected impact to AT&T (a "Change in Law Notice"). Within fifteen
(15) days after AT&T's delivery of a Change in Law Notice, Vendor and AT&T shall meet in good faith
to formulate an action plan to mitigate, minimize or eliminate the impact of such change in Law on
AT&T, which, upon the Parties' mutual agreement, may include restructuring the transaction
contemplated by this Agreement, and/or adjustment(s) to pricing, fees and costs or Material or
Services hereunder.

4.28 FOSS

(a) For purposes of this Section, "FOSS" means any and all freeware, open source software or
shareware used or included in, or combined by or on behalf of Vendor with, the Deliverables or
otherwise provided by or on behalf of Vendor under this Agreement; and a "FOSS Disclosure" means a
complete, current, and accurate listing of all FOSS, which identifies for each FOSS component: (i)
the component name; (ii) its version or release number; (iii) its web site URL of origin; (iv) the
applicable software license and its version number; (v) the URL where Vendor identifies or sets
forth the applicable software license; (vi) a brief (e.g., one- line) description of the purpose of
the component; and (vii) how the component is linked within the Deliverables or as otherwise
provided. A FOSS Disclosure may be provided in the form of a web site made accessible to AT&T where
Vendor posts the foregoing information.

(b) Upon AT&T's request Vendor shall promptly, but in any event within thirty (30) days of such
request, furnish to AT&T a FOSS Disclosure that is complete, current and accurate when

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 63

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 69 -->
furnished. Neither response nor non-response by AT&T concerning the receipt or non-receipt of any
FOSS Disclosure or any reference to FOSS in the Agreement shall be deemed as acceptance, approval or
acquiescence by AT&T that Vendor's use of the FOSS complies with the legal requirements of
applicable FOSS license(s), or is suitable for the intent and purposes furnished hereunder. After
receiving any FOSS Disclosure, AT&T may, upon written notice to Vendor, ask Vendor to use alternate
FOSS (or other alternate software), if reasonably warranted to avert a risk that the rights of AT&T
or its third-party Contractors in any proprietary software may be compromised. In that event, if
Vendor cannot or will not use such alternate FOSS, then AT&T may immediately terminate the relevant
purchase or funding commitments under this Agreement, without further cost, expense or liability to
AT&T.

(c) Vendor represents and warrants to AT&T: (i) that Vendor has satisfied all its obligations to any
third parties with respect to all FOSS and the applicable FOSS licenses (including, for example, any
obligation to make publicly available the FOSS source code for modifications to such FOSS); (ii)
that the FOSS, in the form provided to AT&T, is suitable for the intent and purposes furnished
hereunder; (iii) that use of the FOSS in such form for such intent and purposes in no manner creates
any added obligation on the part of AT&T (including, for example, the payment of any additional
monies), or diminishes, conditions or eliminates any of the rights, title, or interest that Vendor
grants AT&T in or to any Deliverables or that Vendor may otherwise provide AT&T under this
Agreement; and (iv) that use of the FOSS in such form for such intent and purposes, including, but
not limited to, AT&T's use or combination of the FOSS, in the form provided to AT&T, with any
proprietary software of AT&T or AT&T's third-party Contractors, does not subject AT&T to any
obligation of disclosure or distribution to any third party or to the public of any such proprietary
software, or otherwise make such proprietary software subject to the terms of any FOSS license or
impair AT&T's or its third-party Contractors' rights, title, or interest in or to such proprietary
software.

(d) In the event that AT&T notifies Vendor or Vendor becomes aware of Vendor's noncompliance with
any FOSS license term, then in either case, Vendor shall use all reasonable efforts promptly to cure
such noncompliance so as to eliminate risks of public disclosure of proprietary software and prevent
disruption of any AT&T business activity. Vendor shall promptly notify AT&T of all actions taken by
Vendor to cure such noncompliance. Should AT&T receive notice from any third party alleging acts or
omissions which, notwithstanding AT&T's use of the FOSS for the intent and purposes furnished
hereunder, constitute noncompliance with any FOSS license term, then promptly upon AT&T's notice to
Vendor of such allegation, Vendor shall indemnify, defend and hold harmless AT&T against such
allegation in accordance with Vendor's obligations to do so as set forth elsewhere in this
Agreement, in a manner that preserves any proprietary software of AT&T or its third-party
Contractors from any public disclosure obligation or any other FOSS license noncompliance
allegations.

5.1 Execution of Agreement

5.1 Transmission of Original Signatures and Executing Multiple Counterparts. Original signatures
transmitted and received via facsimile or other electronic transmission of a

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 64

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 70 -->
scanned document (e.g., pdf or similar format) are true and valid signatures for all purposes
hereunder and shall bind the Parties to the same extent as that of original signatures. This
Agreement may be executed in multiple counterparts, each of which shall be deemed to constitute an
original but all of which together shall constitute only one document.

[Signature page follows]

Proprietary and Confidential This Agreement and information contained therein is not for use or
disclosure outside of AT&T, its Affiliates, and third party representatives, and Vendor except under
written agreement by the contracting parties. 65

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
<!-- page 71 -->
IN WITNESS WHEREOF, the Parties have caused this Agreement to be executed as of the date the last
Party signs.

Commnet Wireless, LLC AT&T Mobility LLC By AT&T Services, Inc., its authorized representative

By: /s/ Joseph Moravec By: /s/ Susan A. Johnson

Printed Name: Joseph Moravec Printed Name: Susan A. Johnson

Title: President Title: EVP, Global Connections & Supply Chain

Date: July 31, 2019 Date: July 31, 2019

Source: ATN INTERNATIONAL, INC., 10-Q, 11/8/2019
