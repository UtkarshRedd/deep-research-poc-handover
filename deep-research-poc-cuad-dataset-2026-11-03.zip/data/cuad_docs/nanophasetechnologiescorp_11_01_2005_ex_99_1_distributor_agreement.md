<!-- page 1 -->
# DISTRIBUTOR AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| Agreement Date | 2005-10-24 |
| Parties | JOHNSON MATTHEY CATALOG COMPANY, INC. d/b/a ALFA AESAR (“ALFA AESAR”); Nanophase Technologies Corporation (“NTC”) |
| Source | CUAD v1 / NANOPHASETECHNOLOGIESCORP_11_01_2005-EX-99.1-DISTRIBUTOR AGREEMENT |

Exhibit 99.1 DISTRIBUTOR AGREEMENT THIS AGREEMENT, dated as of October 24, 2005 is between JOHNSON
MATTHEY CATALOG COMPANY, INC., a Delaware corporation, d/b/a ALFA AESAR (hereinafter referred to as
"ALFA AESAR"), having a mailing address of 30 Bond Street, Ward Hill, MA 01835-8099 and Nanophase
Technologies Corporation, a Delaware corporation ("NTC"), having its principal offices at 1319
Marquette Drive, Romeoville, IL 60446. Whereas NTC is in the business of manufacturing and selling
nanoparticles and nanoparticle dispersions (collectively "nanomaterials") and wishes to expand the
availability and marketing of nanomaterials for research purposes, and Whereas ALFA AESAR is in the
business of efficiently packaging, marketing, selling and distributing research materials, and NTC
desires to appoint and name ALFA AESAR, and ALFA AESAR desires to be appointed and named, exclusive
distributor of the Products (as defined below) on a worldwide basis in research quantities for
research purposes. NOW, THEREFORE, in consideration of the mutual promises herein contained, the
parties hereto, each intending to be legally bound hereby, agree as follows: 1. Definitions: 1.1
"Product" or "Products" mean those nanomaterials, coated nanomaterials and dispersions of
nanomaterials listed in Schedule A, as amended from time to time by mutual written agreement signed
by the parties. 1.2 "Product Price" means the price for Products listed in Schedule A sold by NTC to
ALFA AESAR. 1.3 "Research Quantities" means, in the case of nanomaterials and coated nanomaterials,
quantities purchased and distributed in individual orders of 54 kilograms or less, and, in the case
of dispersions of nanomaterials, quantities purchased and distributed in individual orders of 60
kilograms or less. 1.4 "Commercial Quantities" means in the case of nanomaterials and coated
nanomaterials, quantities purchased and distributed in individual orders greater than 54 kilograms,
and, in the case of dispersions of nanomaterials, quantities purchased and distributed in individual
orders greater than 60 kilograms. 1.5 "Custom Services" is any program or product offered by NTC
other than the manufacture of Products as listed in Schedule A. 1.6 "Territory" is all areas in
which ALFA AESAR markets, sells or distributes chemicals or other materials through its various
sales channels, including but not limited to its present and future catalog distribution networks,
Internet web sites, and other distribution channels. 1
<!-- page 2 -->
1.7 "Trademark" means all common law, registered and unregistered state, federal and foreign trade
names, trademarks, and service marks, including without limitation any logos and slogans. 1.8 "Net
Sales" means the cost charged to a customer for goods and services less the costs for shipping,
handling, taxes, duties and credits. 2. Appointment; Reservation of Rights; Referrals. 2.1 NTC
hereby grants to ALFA AESAR, and its subsidiaries and affiliates, the exclusive right to market,
sell and distribute Research Quantities of the Products within the Territory, ALFA AESAR hereby
accepts such right and agrees to use its reasonable efforts to promote the marketing, sale and
distribution of Research Quantities of the Products throughout the Territory in accordance with the
terms and conditions of this Agreement using normal and standard practices. ALFA AESAR shall have
the right, in its sole discretion, to sell Products outside of the Territory. ALFA AESAR agrees
that, so long as NTC provides ALFA AESAR with Products for ALFA AESAR' S marketing, sale and
distribution of Research Quantities of the Products within the Territory, ALFA AESAR shall purchase
all its requirements of the Products (including nanomaterials with physical or chemical properties
substantially the same as the Products) exclusively from NTC during the term of this Agreement, ALFA
AESAR shall: i) buy the Products in quantities listed in Schedule A and repackage into the research
sample quantities as it deems reasonable and appropriate for distribution and sale on a worldwide
basis at such resale prices it shall determine from time to time, provided that any such repackaging
shall comply with applicable safety laws and regulations; ii) attempt to keep reasonably sufficient
stocks of the Products to meet customer orders and to store such stocks in such conditions as NTC
may recommend from time to time to prevent deterioration or damage. 2.2 NTC reserves for itself the
right (i) to sell Commercial Quantities of the Products in individual order quantities of single
commercial packages or greater, subject to Section 6; and (ii) to provide samples of the Products in
any quantity, free of charge, to its commercial partners or potential partners. 3. Pricing,
Exclusions and Purchase Orders. 3.1 Subject to Section 2.2, NTC shall sell Products to ALFA AESAR,
at the Product Price as amended from time to time pursuant to this Section 3.1. NTC agrees that the
Product Prices, benefits and allowances offered to ALFA AESAR shall not be less favorable than those
offered on Products provided to agents, distributors or marketed directly by NTC to any customers,
other than the Product Prices existing as of the date of this Agreement with NTC's commercial
partners. Subject to the preceding sentence, NTC may increase the Product Price set forth in
Schedule A at the end of the first full calendar year of this Agreement and from year to year
thereafter, by providing ALFA AESAR with 90 days prior written notice of the changes to the 2
<!-- page 3 -->
Product Prices. Any such increase in the Product Price shall not be effective for any unshipped
portion of an order previously placed by ALFA AESAR prior to the end of the calendar year in which
such notice is provided. NTC may decrease the Product Price at any time by providing ALFA AESAR with
30 days prior written notice. 3.2 NTC's prices do not include sales, use, excise, or similar taxes.
The amount of any valid present or future sales, use, excise, or other similar tax that is
attributable to ALFA AESAR shall be paid by ALFA AESAR; or in lieu thereof, ALFA AESAR shall provide
NTC with a tax exemption certificate acceptable to the taxing authorities. Product Prices do not
include any transportation or shipping expenses. NTC shall ship Products at ALFA AESAR's expense
FOB/FCA (Incoterms 2000) NTC's facilities. 3.3 Subject to Section 2.2, NTC agrees to sell to ALFA
AESAR such quantities of Products ordered by ALFA AESAR by written purchase orders. Purchase orders
for Products shall be initiated by facsimile transmission, electronic mail or other written
communication and shall be binding upon the parties upon acceptance by NTC. NTC shall be deemed to
have accepted a purchase order unless NTC provides written notice of rejection to ALFA AESAR within
three (3) days of NTC's receipt of such order, not including weekends and nationally recognized
holidays. 4. Payment and Delivery. 4.1 Subject to Section 2.2, NTC shall use all reasonable
commercial efforts to fill orders placed by ALFA AESAR with all reasonable promptness provided,
however, that NTC shall have no obligation to furnish any Products hereunder which have been
discontinued. In the event any order is not filled within thirty (30) days of receipt by NTC, ALFA
AESAR has the right, but not the obligation, to seek alternative sourcing from a third- party
without liability to NTC. 4.2 NTC shall ship Products FOB/FCA its facilities and will arrange
delivery of the Products to ALFA AESAR using a nationally recognized carrier. Title to the Products,
and the risk of loss or damage to the Products, each will pass to ALFA AESAR upon shipment from
NTC's dock in compliance with United States D.O.T. requirements and all applicable laws and
regulations. 4.3 NTC shall invoice ALFA AESAR for payment of Products delivered to ALFA AESAR on a
Net 30 day basis. Excepting any amounts disputed in good faith, balances unpaid after such period
will be subject to a finance charge of 1% per month or may be offset against any balances owed by
NTC to ALFA AESAR. The parties agree to work in good faith to resolve any disputed invoice. In the
event such efforts do not resolve the dispute within sixty (60) days, either party may initiate
Arbitration proceedings pursuant to Section 16. 5. Returns; Discontinued Products. 5.1 Return
Rights. Subject to the protocol described below, ALFA AESAR shall have the right to return at NTC's
expense, and for full credit of ALFA AESAR's cost, any Products (i.) for which a legitimate and
credible allegation is made that the use of such Products infringes on any patent, trademark, trade
secret, copyright, right of privacy or publicity, or any other tangible or 3
<!-- page 4 -->
intangible proprietary or intellectual property right; (b) that are not manufactured, packaged, or
labeled in accordance with specifications or industry standards; (c) that are shipped in error or in
non-conformance with ALFA AESAR's purchase order; or (d) that are damaged or defective. In the event
that ALFA AESAR believes that it is entitled to return any Products delivered under this Agreement,
the parties will adhere to the following protocol: (w) ALFA AESAR will contact NTC's Quality
Director and then forward to the Quality Director, via a carrier selected by and at NTC's expense, a
sample of the Product that ALFA AESAR believes is non-conforming; (x) upon receipt of the sample,
NTC will test it and then notify ALFA AESAR of the test results; (y) where the test results confirm
that the sample is non-conforming, NTC will provide ALFA AESAR with NTC's Return Authorization
Number ("RAN"); and (z) any returned non-conforming Product must be in its original container, with
original labels in act, and all paperwork concerning the returned Product must include NTC's RAN.
5.2 NTC may discontinue offering any Product for any reason by providing six (6) months advance
written notice to ALFA AESAR, provided however, NTC shall continue supplying ALFA AESAR with such
discontinued Product until the expiration of such six (6) month notice period. Notwithstanding the
foregoing, NTC may discontinue any Product immediately upon written notice to ALFA AESAR if such
discontinuation is due to any actual or alleged Product defect which may actually or allegedly cause
damage to person, property rights or property, With respect to ALFA AESAR's existing inventory of
discontinued Product, ALFA AESAR may, its sole discretion, return such Product at any time to NTC
for full credit or refund. 6. ALFA AESAR Referrals. 6.1 The following shall be deemed referral sales
for which NTC shall pay a commission in accordance with Section 6.2. a. ALFA AESAR shall refer to
NTC the following sales requests either directly or by navigation on ALFA AESAR's Web site: i) any
sales for single Product orders in excess of Research Quantities; or ii) any sales inquiries for
Custom Services. 6.2 NTC shall pay ALFA AESAR a commission for all sales under Section 6.1 as
follows. The terms of this Section 6.2 shall survive any expiration or termination of this
Agreement.

a) For all referrals under Section 6.1, except where NTC has evidence that it referral the customer
(including its affiliates) to ALFA AESAR to purchase a prior sample of the Product in question, or
where NTC has made sales to the customer (including its affiliates) referred to NTC by ALFA AESAR
within a period of twelve (12) months before ALFA AESAR's referral under Section 6.1, NTC shall pay
ALFA AESAR a commission at the rate of [***] on the Net Sales made to each such customer so referred
to NTC under Section 6.1. NTC shall pay ALFA AESAR on a monthly basis for all such commissions for a
period of three (3) years from the date of such referred customer's first order of Products or
Custom Services from NTC.

*** CONFIDENTIAL TREATMENT REQUESTED—This confidential portion has been omitted from this document
and filed separately with the Commission. 4
<!-- page 5 -->
6.3 NTC shall maintain adequate records of its invoices and accounting records reflecting all such
sales in accordance with standard accounting principles. Within twelve (12) months after the date
this Agreement has been terminated by the parties, ALFA AESAR may engage an independent certified
public accounting firm reasonably acceptable to NTC to audit the NTC invoices and accounting records
pertaining to those customers identified as referrals under Section 6.1 at NTC's offices during
normal business hours by providing thirty (30) days advance notice of such audit for the purpose of
determining the accuracy of the commissions paid or payable to ALFA AESAR hereunder. NTC shall
promptly pay ALFA AESAR for any deficiencies between the commission earned and the commission paid
to ALFA AESAR. 7. Trademarks. 7.1 Each party hereby covenants and agrees that the Trademarks,
copyrights and other proprietary rights of the other party are and shall remain the sole and
exclusive property of that party and neither party shall hold itself out as having any ownership
rights with respect to or, except as specifically granted hereunder, in any other rights therein.
Any and all goodwill associated with any such rights shall inure directly and exclusively to the
benefit of the owner thereof. 7.2 ALFA AESAR hereby grants to NTC a limited non-exclusive license to
use the ALFA AESAR Trademarks in the form provided by ALFA AESAR during the Term of this Agreement
in accordance with the terms set forth herein. Such license is granted solely in connection with
NTC's rights and obligations under this Agreement and, in particular, for the purpose of licensing
NTC to use the ALFA AESAR Trademark on the NTC web site as expressly contemplated herein for
referral of customers of Research Quantities to ALFA AESAR and is a link/navigational button to the
ALFA AESAR Site. All such uses will be subject to ALFA AESAR's approval as to the manner and/or form
of use. NTC will not be allowed to use or reproduce the ALFA AESAR Trademark for any other purpose,
including the general promotion of the NTC Site, without the prior written approval of ALFA AESAR.
7.3 NTC hereby grants ALFA AESAR a limited non-exclusive license to use, exhibit, excerpt,
reproduce, publish, publicly perform and transmit via the Internet and otherwise use the NTC
Trademarks in substantially the form as NTC may provide to ALFA AESAR from time to time during the
Term of this Agreement in accordance with the terms set forth herein. Such license is granted solely
in connection with ALFA AESAR's rights and obligations under this Agreement and, in particular, for
the purpose of licensing ALFA AESAR to use the NTC Trademarks in ALFA AESAR's marketing, sales and
distribution materials relative to the Products, including without limitation on the ALFA AESAR's
Web site as a link/navigational button to the NTC Web site as posted by NTC. All such uses shall be
subject to NTC's prior written approval as to manner and/or form of use. 7.4 Except as provided for
in this Agreement, each party understands that the Web site links contemplated above to the other
party's site may not be used in any manner to provide viewers access to the other party's Site via
any caching, framing, layering or other techniques that cause 5
<!-- page 6 -->
intermediate copying of the other party's Site (or elements thereof) or display of the other party's
site or portions thereof in any manner unintended by the owner of the Site. 7.5 Upon termination of
this Agreement, ALFA AESAR may continue to advertise and promote the Products, using the NTC's
Trademarks and NTC content until ALFA AESAR's inventory depletion. 8. Training; Product Material.
8.1 NTC will provide training to ALFA AESAR's personnel on ALFA AESAR's premises as reasonably
necessary, but no less than once annually, at mutually agreed upon times and dates to provide ALFA
AESAR's sales and service personnel with adequate knowledge with respect to the Products. 8.2 NTC
will provide to ALFA AESAR marketing and technical support for products as reasonably necessary and
requested by ALFA AESAR, including providing Product materials which shall include, without
limitation, Product specifications, images, and other textual, graphical and/or multimedia content
regarding the Products for use in preparing advertising and promotional material. Subject to any
limitations which NTC communicates to ALFA AESAR in writing, NTC hereby grants ALFA AESAR a license
to use, exhibit, excerpt, reformat, modify, reproduce, publish, publicly perform and transmit via
the Internet and otherwise use such NTC content for the purpose of marketing, advertising and
promoting the Products, provided that ALFA AESAR obtains NTC's prior written approval for NTC
content to be included in such literature. 9. Representations; Limited Warranty; Remedies. 9.1 NTC
represents and warrants that i) the execution and delivery of this Agreement has been authorized by
all requisite corporate action, ii) subject to Section 2.2, it in under no contractual or other
obligation or restriction that is inconsistent with its execution or performance of this Agreement,
iii) subject to Section 2.2, NTC will not enter into any agreement, either written or oral, that
would conflict with NTC's responsibilities under this Agreement, iv) the Products do not infringe
the intellectual property rights of any third party and NTC is not aware of any infringement claims
relating to the Products, v) it will comply with all applicable laws, rules, regulations of any US
or foreign laws, rules, or regulations in the manufacture and supply of Product, and vi) Products
sold hereunder will be in compliance with the current Product description set forth in Schedule A,
as amended from time to time by agreement of the parties. NTC shall further grant to ALFA AESAR the
same warranty, as set forth in NTC's General Terms and Conditions of Sale for its products set forth
in Schedule B. The foregoing warranties shall apply only to, and is intended for the benefit of,
ALFA AESAR's customers. 9.2. Subject to the protocol in Section 5.1, ALFA AESAR may return to NTC
any Product that is defective or that fails to comply with the purchase order provided by ALFA
AESAR. NTC shall return to ALFA AESAR as promptly as possible, a working replacement or, in the
event such replacement is not possible or at ALFA AESAR's election, it shall credit ALFA AESAR's
account for the invoiced price and shipping charges of the defective Product. The 6
<!-- page 7 -->
correction of such defective Product shall be at no cost to ALFA AESAR. The cost of shipping the
replacement Product back to ALFA AESAR shall be paid by NTC. THE CORRECTION OF SUCH DEFECT BY REPAIR
OR CREDITING ALFA AESAR'S ACCOUNT FOR THE COST OF THE PRODUCT IN THE MANNER SET FORTH ABOVE SHALL
CONSTITUTE THE SOLE AND EXCLUSIVE REMEDY OF DISTRIBUTOR WITH RESPECT TO ANY WARRANTY GIVEN HEREIN
RELATING TO ANY PRODUCT SOLD OR DELIVERED HEREUNDER. 9.3 ALFA AESAR represents and warrants that i)
the execution and delivery of this Agreement has been authorized by all requisite corporate action,
ii) it is under no contractual or other obligation or restriction that is inconsistent with its
execution or performance of this Agreement, iii) ALFA AESAR will not enter into any agreement,
either written or oral, that would conflict with ALFA AESAR's responsibilities under this Agreement,
iv) it will comply with applicable safety laws and regulations for the repackaging and storage of
Products, and v) excepting such warranties provided by NTC herein, it will make no warranties or
other representations of any kind about the merchantability or fitness for any particular purpose of
any Products, whether used alone or in connection with any other substance. 10. Indemnification.
10.1 NTC shall protect, defend, indemnify and hold ALFA AESAR, its directors, officers, employees,
and agents harmless from any and all claims, actions, causes of action, liabilities, losses,
damages, costs or expenses, including reasonable attorneys' fees, which directly or indirectly arise
out of or relate to i) NTC's breach of warranties in Section 9.1, or ii) NTC's gross negligence or
willful misconduct arising out of its manufacture, sale or transfer of the Products to ALFA AESAR,
excepting indemnification for which ALFA AESAR is obligated under 10.3. 10.2 ALFA AESAR agrees to
give NTC (i) prompt written notice of any claims made for which NTC might be liable under the
foregoing indemnification, and (ii) the opportunity to defend, negotiate, and settle such claims.
ALFA AESAR shall provide NTC with all information in its possession, all authority, and all
assistance reasonably necessary to enable the indemnifying party to carry on the defense of such
suit; provided, however, that each party shall have the right, at its own expense, to retain its own
counsel to defend itself in such suit. 10.3 ALFA AESAR shall protect, defend, indemnify and hold
NTC, its directors, officers, employees, and agents harmless from any and all claims, actions,
causes of action, liabilities, losses, damages, costs or expenses, including reasonable attorneys'
fees, which directly or indirectly arise out of or relate to i) ALFA AESAR's breach of warranties in
Section 9.3, (iii) ALFA AESAR's gross negligence or willful misconduct arising out of its sale or
transfer of the Products to ALFA AESAR's customers, excepting indemnification for which NTC is
obligated under 10.1. 10.4 NTC agrees to give ALFA AESAR (i) prompt written notice of any claims
made for which ALFA AESAR might be liable under the foregoing indemnification, and (ii) the
opportunity to defend, negotiate and settle such claims. NTC shall provide ALFA AESAR with all
information in its possession, all authority, and all assistance reasonably necessary to enable the
indemnifying party to carry on the defense of such suit; provided, however, that each party shall
have the right, at its own expense, to retain its own counsel to defend itself in such suit. 7
<!-- page 8 -->
11. Relationship and Conduct of Business. 11.1 ALFA AESAR shall use its reasonable efforts and
devote such time as may be reasonably necessary to sell and promote the sale of Products within the
Territory. 11.2 ALFA AESAR agrees not to manufacture, buy, sell, distribute, deal in or be the agent
for any products with the specifications of any of the Products, excluding any preexisting ALFA
AESAR products. 12. No Joint Venture. 12.1 This Agreement does not in any way create the
relationship of franchisor and franchisee, joint venture, partnership, employment or principal and
agent between ALFA AESAR and NTC. Neither party, nor any person acting on behalf of a party, is or
shall be considered an employee of the other party for any reason whatsoever, and does not and shall
not have any rights to, or participate in, any pension or welfare plans, or any other benefits which
now or hereafter maintains for or provides to its employees. Neither party, or any person acting on
behalf of a party, is or shall be deemed to be the legal representative or agent of the other party
for any purpose whatsoever, and is not authorized to transact business, incur obligations, express
or implied, or otherwise act in any manner, in the name or on behalf of the other party, or to make
any promise, warranty or representation with respect to Products (except as provided herein by NTC
or as NTC otherwise expressly approves as to its Products) or any other matter in the name of or on
behalf of the other party. 13. Term. 13.1 The initial term of this Agreement shall be for a period
of five (5) years from the date first set forth above and shall thereafter automatically renew for
additional two (2) year terms unless a party provides the other party with notice of non-renewal no
less than 6 months prior to the expiration of the initial term or any renewal term unless earlier
terminated as follows: 13.1.1 In the event of material breach, the non-breaching party shall give
the breaching party sixty (60) days written notice of such breach. If substantial efforts to cure
the breach are not taken within the sixty (60) day notice period, the non-breaching party may, at
its sole discretion, terminate the agreement. 13.1.2 In the event a party becomes insolvent or if a
party is declared bankrupt or makes an assignment for the benefit of creditors or in the event a
receiver is appointed or any proceeding is demanded by, for or against a party under any provision
of any bankruptcy law which is not withdrawn within sixty (60) days, the other party to this
Agreement shall have the sole right to immediately terminate; or 13.1.3 By either party for any
reason by providing six (6) months prior written notice expressly terminating this Agreement. Such
notice may be by facsimile transmission or other written communication. 8
<!-- page 9 -->
13.2 Termination of this Agreement shall not affect the rights or obligations of the parties accrued
as of the date of termination. The provisions of Sections 6, 9, 10, 15 will survive termination of
the Agreement. 13.3 Upon termination of this Agreement for any reason, ALFA AESAR may i) return its
current inventory of Products for reimbursement by NTC or ii) keep its current inventory of Products
and continue to sell such Products pursuant to the terms hereof until depletion of inventory. Upon
termination of this Agreement, NTC shall promptly refund to ALFA AESAR all outstanding credits
accrued on ALFA AESAR's account. 14. Insurance. Each party agrees to maintain and provide the other
with evidence of insurance coverage for comprehensive general liability in an amount no less than
$2,000,000.00 U.S. dollars. 15. Confidentiality. The parties agree as follows; "Confidential
Information" shall mean trade secret, technical, commercial, or financial information and all other
nonpublic proprietary or confidential information. Each party receiving Confidential Information
from the other party agrees to maintain in confidence and not divulge such Confidential Information,
in whole or in part, to any third party, including subsidiaries or affiliates, licensees or clients
anywhere, and not make use of such Confidential Information other than in relation to its
performance under this Agreement. This obligation shall not apply to: (i) Confidential Information
which at the time of disclosure by the disclosing party is in the public domain; or (ii)
Confidential Information which, after disclosure by the disclosing party, becomes part of the public
domain by publication or otherwise, other than by an unauthorized act or omission by the receiving
party; (iii) Confidential Information which receiving party can show by contemporary written records
was in its possession at the time of the disclosure and which was not acquired, directly or
indirectly from disclosing party; or (iv) Confidential Information which receiving party rightfully
receives from a third party and which was not acquired, directly or indirectly, from the disclosing
party; (v) information which is developed independently without reference to the Confidential
Information of the other party; or (v) Confidential Information which, if disclosed in written or
other tangible form, is not marked "Confidential", or if disclosed orally is not summarized in a
writing identifying the Confidential Information and submitted to the receiving party within thirty
(30) days of the oral disclosure; or (vi) Confidential Information which is compelled by law to be
disclosed by the receiving party, provided that the receiving party shall use its best efforts to
give the disclosing party ten (10) days prior written notice of any such compelled disclosure. Each
party agrees that it shall restrict its disclosures of the disclosing party's Confidential
Information within its own organization to those persons having a need to know it for the purposes
of performance under this Agreement and that such persons shall be advised of the obligations of
confidentiality set forth herein and shall be obligated in like fashion. Upon request on termination
or expiration of this Agreement, the receiving party shall promptly return to the disclosing party
all Confidential Information and shall retain no copies except that one copy may be retained for
purposes of determining such receiving party's compliance with the terms of this paragraph. 16.
Disputes and Arbitration. The parties shall first seek to resolve any dispute by negotiations
between their senior executives. When a party believes there is a dispute under this Agreement, that
party will give the other party written notice of the dispute. Failing settlement of the dispute
within 60 days of notice, either party may initiate binding arbitration proceeding; by 9
<!-- page 10 -->
written notice to the other party, provided however, no dispute arising from any actual or
threatened breach of any provisions in Sections 10 or 15 of this Agreement shall be subject to
Arbitration. However, any other claims or disputes arising hereunder, including the construction or
application of this Agreement, shall be settled by arbitration before a single arbitrator in
accordance with the Rules for Commercial Arbitration of the American Arbitration Association ("AAA")
then in force. The place of arbitration shall be the location of the party hereto against whom the
claim is made. If the parties cannot agree on an arbitrator within 10 days after demand by either of
them, then the arbitrator shall be selected pursuant to the AAA's Commercial Arbitration rules. The
decision of the arbitrator shall be final and binding upon the parties and may be submitted to any
court of competent jurisdiction for entry of a judgment thereon in accord with the Federal
Arbitration Act or the Uniform Arbitration Act. The expense of the arbitration shall be shared
equally by both parties. Each party shall bear its own "other" costs, i.e. fees and costs of its own
lawyers and witnesses. 17. Notices. Any notice required or permitted to be given hereunder shall be
deemed to have been duly given if delivered by hand, overnight courier delivery or mailed, certified
and registered mail, with postage prepaid to the addresses first set forth above or at such other
addresses as either party may designate in writing to the other, and if to ALFA AESAR with a copy to
Johnson Matthey, 435 Devon Park, Suite 600. Wayne PA 19087, Attention: Vice President & General
Counsel. This section is not intended to govern the day-to-day business communications necessary
between the parties in performing their duties, in due course, under the terms of this Agreement.
18. Severability. The provisions of this agreement shall be severable, and if any provision of this
Agreement is held to be invalid or unenforceable, it shall be construed to have the broadest
interpretation which would render it valid and enforceable. Invalidity or unenforceability of one
provision shall not affect any other provision of this Agreement. 19. Entire Agreement. This
Agreement contains the entire agreement with respect to the subject matter hereof, and there are no
other agreements or understandings, express or implied, written or oral, as to the subject matter
hereof. This Agreement may not be amended or altered except by a written instrument signed by both
parties, expressly stating that it is intended as an amendment hereto. No purchase order or other
written order or acknowledgment issued by either party shall serve to vary the terms and conditions
of this Agreement, or otherwise alter the obligations of the parties provided herein. 20. Waiver.
The waiver by either party of any breach or failure to enforce any of the terms and conditions of
this Agreement at any time shall not in any way affect, limit or waive either party's rights
thereafter to enforce and compel strict compliance with every term and condition of this Agreement.
21. Counterparts. This Agreement may be executed in one or more counterpart copies, each of which
shall be deemed an original and all of which shall together be deemed to constitute one agreement.
22. Governing Law. This Agreement shall be governed by and interpreted under and in accordance with
the laws of the State of Delaware without regard to principles of conflicts of laws. 10
<!-- page 11 -->
23. Public Announcements. Upon execution and at any time during the term of this Agreement, the
parties shall cooperate in preparing a joint press release announcing this Agreement and the
availability of NTC Products in Research Quantities through ALFA AESAR, provided that no such joint
press release shall be issued without both parties' prior approval. 24. Headings. The headings in
this Agreement are for convenience only and do not in any way limit or amplify the terms or
conditions of this Agreement. IN WITNESS WHEREOF, the parties have duly executed this Agreement as
of the date first set forth above. NANOPHASE TECHNOLOGIES CORPORATION JOHNSON MATTHEY CATALOG
COMPANY, INC.

By: /s/ W. Ian Roberts By: /s/ Barry Singelais W. Ian Roberts Barry Singelais V.P. U.S. &
International Sales General Manager

Dated: October 14, 2005 Dated: October 24, 2005 11
<!-- page 12 -->
Schedule A List of Products to be offered by ALFA AESAR. Quantities and NTC pricing to ALFA AESAR
are included. All prices are USD, FOB Romeoville IL, net 30. Product Specification Nanopowders: Name

Product Code

Quantity

Price/kg

NanoTek® Aluminum Oxide 0115 [***] $[***] NanoDur™ Aluminum Oxide 0119 [***] $[***] NanoTek®
Antimony Tin Oxide 2400 [***] $[***] NanoArc® Bismuth Oxide EXP 0250 [***] $[***] NanoArc® Copper
Oxide EXP 0502 [***] $[***] NanoTek® Indium Tin Oxide 0600 [***] $[***] NanoArc® Cosmetic Iron Oxide
EXP 0807 [***] $[***] NanoArc® Magnetic Iron Oxide EXP 0806 [***] $[***] NanoTek® Tin Oxide 1400
[***] $[***] NanoGard® Zinc Oxide 1700 [***] $[***] NanoTek® Zinc Oxide 1701 [***] $[***] NanoTek®
Zinc Oxide C1 1716 [***] $[***] NanoTek® Zinc Oxide C2 EXP 1726 [***] $[***]

Nanoparticle dispersions: Name

Product Code

Quantity

Price/kg

NanoDur™ X1121W, 50wt% EXP 0187 [***] $[***] NanoDur™ X1130PMA, 50wt% EXP 0151 [***] $[***]
NanoShield® ZN-2000, 50wt% EXP 1754 [***] $[***] NanoShield® ZN-3010, 50wt% EXP 1769 [***] $[***]
NanoTek® Z1102PMA, 50wt% EXP 1707 [***] $[***] NanoTek® AL-6081, 23wt% EXP 0180 [***] $[***]
NanoTek® AL-6051, 23 wt% EXP 0142 [***] $[***] NanoTek® CE-6042, 18wt% 0311 [***] $[***] NanoTek®
CE-6080, 20wt% 0315 [***] $[***] NanoTek® CE-6082, 18wt% 0314 [***] $[***] NanoTek® CE-6086, 18wt%
EXP 0333 [***] $[***]

*** CONFIDENTIAL TREATMENT REQUESTED—This confidential portion has been omitted from this document
and filed separately with the Commission. 12
<!-- page 13 -->
Schedule B NANOPHASE TECHNOLOGIES CORPORATION STANDARD TERMS AND CONDITIONS 1. General Terms: As
used in these Terms and Conditions, the terms (a) "Seller" shall mean Nanophase Technologies
Corporation and (b) "Buyer" shall mean the party ordering shipment of Seller's products under the
Order. These Terms and Conditions, including the provisions on the face hereof, constitute the
exclusive contract between the parties for the products provided by Seller ("Order" or "Agreement").
Seller will be deemed to have accepted this Order when Seller returns an acknowledged copy of this
Order, or, at Seller's option, when Seller begins substantial performance under this Order. Buyer
accepts this Order by acknowledging a copy of this Order, by confirming this Order by its purchase
order, purchase requisition or confirmation, or by accepting for shipment the products hereunder.
Notwithstanding the manner in which Buyer accepts, Buyer's acceptance is limited exclusively to the
acceptance of Seller's terms and conditions set forth in this Order only. Seller hereby rejects any
proposal by Buyer for additional or different terms in connection with the products or services
provided. Buyer may acknowledge this Order by purchase order, but any and all terms, conditions and
provisions contained in said purchase order, acknowledgment form or other communications with
respect to the transaction contemplated by this Order, or subsequent to the date hereof, are agreed
to be superfluous and without any force and effect. This Order, which includes all terms and
conditions hereof, is intended to be the exclusive and final statement of the terms and
understandings relative to the subject matter hereof, merging herein and superseding all
negotiations and prior written or oral agreements between the parties as to the subject matter of
the purchase of the products hereunder. There are no promises, representations or understandings
made in connection with this Order or contemporaneous with the execution hereof, except as set forth
herein. 2. Prices and Taxes: All prices are set forth on the face of this Order. Seller is entitled
to defer shipment of products in the event all amounts due it under this or any other Agreement are
not paid in full. All payments shall be made to Seller at its offices. The failure to make prompt
payment shall be a material breach of this Agreement. The price of the products specified in this
Order does not include federal taxes, state or local sales taxes, value added taxes, use taxes or
occupational taxes. Unless prohibited by law, Buyer is responsible for and shall pay all applicable
sales, use, occupational, excise, value added or other similar taxes applicable to the manufacture,
sale, price, shipment or use of the products provided by Seller. 3. Delivery and Risk of Loss: All
sales are FOB Seller's premises in Burr Ridge or Romeoville, Illinois. Seller shall have no
liability or responsibility for the late or non-shipment of products hereunder. Title to, risk of
loss, destruction of or damage to the products shall be Seller's until delivery of the products to a
carrier at the Seller's premises in Burr Ridge, Illinois. Thereafter, Buyer shall be fully
responsible for and assume all ownership, risk of loss, destruction of or damage to the products.
Loss or damage to the products after title and risk of loss have passed to Seller will not release
or excuse Buyer from its obligations under this Order to Seller, including the obligation to make
full payment. 4. Short Shipments/Damage Claims: Seller will endeavor to ship all Orders complete or
as complete as reasonably possible. Seller will, however, ship incomplete orders upon written
authorization by Buyer. In that event, Seller shall have no liability for short, incomplete or
delayed orders. All damage claims shall be made within fourteen (14) days of delivery and shall be
in writing. 5. Rejection and Revocation of Acceptance: Any rejection or revocation of acceptance by
Buyer (a) must be made within thirty (30) days of the products being made available for shipment to
Buyer, (b) any attempted rejection or revocation of acceptance made thereafter shall be null and
void, and (c) any rejection or revocation of acceptance shall comply with Seller's return protocol.
<!-- page 14 -->
6. Compliance with Governing Laws: Buyer warrants that its performance hereunder, including the use
of the products hereunder, shall comply with all applicable state, federal and foreign law,
regulations, environmental regulations, statutes or requirements, including, but not limited to, FDA
approvals or any other approvals or certifications required by law 7. Assignment and Modification:
The rights and obligations of the parties under this Agreement shall not be assignable unless
consent to the assignment is in writing and signed by the parties. This Order shall not be modified,
altered or amended in any respect except by a writing signed by the parties. Any variation,
modification, or addition to the terms set forth in this Order shall be considered a material
modification and shall not be considered part of this Agreement. 8. Limited Warranty and Disclaimer
of All Other Warranties: EXCEPT FOR THE EXPRESS WARRANTY, IF ANY, THAT THE PRODUCTS COMPLY WITH THE
SPECIFICATIONS IDENTIFIED IN WRITING ON THE FACE OF OR ACCOMPANYING THIS ORDER, SELLER MAKES NO
EXPRESS OR IMPLIED WARRANTIES IN THIS ORDER OR OTHERWISE. TO THE FULLEST EXTENT PERMITTED BY LAW,
SELLER DISCLAIMS ALL WARRANTIES, WRITTEN, EXPRESS OR IMPLIED, INCLUDING ALL WARRANTIES OF
MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. SELLER EXPRESSLY DISCLAIMS ANY AND ALL
LIABILITY TO BUYER FOR ANY CONSEQUENTIAL DAMAGES, DAMAGES FOR LOSS OF USE, LOSS OF PROFITS, INCOME,
OR REVENUE, LOSS OF TIME OR INCONVENIENCE, LOSS OR DAMAGE TO ASSOCIATED EQUIPMENT, COST OF
SUBSTITUTED OR REPLACEMENT EQUIPMENT, LOSS TO FACILITIES, LOSS OF CAPITAL, LOSS OF SERVICES OR ANY
OTHER INCIDENTAL, CONSEQUENTIAL OR SPECIAL DAMAGE ARISING OUT OF THIS ORDER OR THE OPERATION,
FUNCTION OR CHARACTERISTICS OF THE PRODUCTS PURCHASED HEREUNDER OR OTHERWISE PROVIDED BY SELLER. IN
THE EVENT THAT PRODUCTS DO NOT SATISFY SPECIFICATIONS, THEY WILL BE REPLACED, AT SELLER'S OPTION,
WITH PRODUCTS THAT DO SATISFY THE SPECIFICATIONS AT SELLER'S SOLE EXPENSE. SAID REPLACEMENT IS THE
SOLE AND EXCLUSIVE REMEDY OF BUYER. 9. Limitation of Liability: To the fullest extent permitted by
law, the parties waive and relinquish any claims, demands, causes of action or recoveries for
punitive damages, exemplary damages, or statutory damages. Seller shall not be liable for indirect,
special, incidental or consequential damages arising under this Agreement or otherwise with respect
to the sale of the products, including any lost revenues or profits, consequential and/or incidental
damages, business interruption or damage to business reputation, regardless of the theory upon which
any claim may be based, including any statutory causes of action or claims. In no event will
Seller's entire liability to Buyer, including any liability in the event the exclusive remedy set
forth in this Agreement fails of its essential purpose, exceed the purchase price actually paid by
Buyer for the products hereunder, or any defective portion thereof, whichever is the lesser amount.
10. Force Majeure: Seller shall have no liability or obligation to Buyer of any kind, including but
not limited to any obligation to ship products, arising from any delay or failure to perform all or
any part of this Order as a result of causes, conduct or occurrences beyond Seller's reasonable
control, including, but not limited to, commercial impracticability, fire, flood, act of war, civil
disorder or disobedience, act of public enemies, terrorist acts, terrorism generally affecting
commerce, problems associated with transportation (including car or truck shortages), acts or
failure to act of any state, federal or foreign governmental or regulatory authorities, labor
disputes or strikes. 11. Relationship: The relationship between Seller and Buyer shall be that of
independent contractors. Seller, its agents and employees, shall under no circumstances be deemed
the employees, distributors, franchisees, agents or representatives of Buyer.
<!-- page 15 -->
12. Default: The failure of Buyer to perform any obligations hereunder, including without
limitation, the payment of the purchase price for products and all other amounts due hereunder, the
failure to materially perform other agreements between Buyer and Seller, or Buyer's bankruptcy or
insolvency, shall constitute a default under this Agreement and shall, in addition to any other
remedies, afford Seller all of the remedies of a secured party under the Uniform Commercial Code of
the State of Illinois. In the event of default, Seller may, in addition to pursuing any of the
remedies provided by law, equity or as set forth in this Agreement, refuse to make available for
shipment products under this or any other agreement relating to the products, and may also cancel
this Order and any pending orders without liability to Buyer. It is expressly understood that
Seller's remedies are cumulative to the fullest extent permitted by law. 13. Attorneys' Fees: In the
event it becomes necessary for Seller to enforce the terms and conditions of this Order by
litigation or otherwise, or to defend itself in any Controversy (as defined herein), litigation,
claim, demand or cause of action arising out of or as a result of this Order or the products or
services provided hereunder, and if Seller is the substantially prevailing party in said
Controversy, litigation, claim, demand or cause of action, then Seller shall be entitled to recover,
in addition to any other relief granted or damages assessed, its reasonable attorneys' fees, expert
witness fees, costs, and all expenses of litigation. 14. Waiver: No claim or right arising out of a
breach of this Order can be discharged in whole or in part by a waiver or renunciation of the claim
or right unless the waiver or renunciation is supported by consideration and is in writing signed by
the aggrieved party. 15. Severability: If any term, covenant, warranty or condition of this Order,
or the application thereof to any person or circumstance shall, to any extent, be held or deemed
invalid or unenforceable, the remainder of this Order or the application of such term, covenant or
provision, to persons or circumstances other than those to which it is held invalid or
unenforceable, shall not be affected thereby, and each remaining term, covenant or provision of this
Order shall be deemed valid and enforced to the fullest extent permitted by law. 16.
Indemnification: To the fullest extent permitted by law, Buyer shall defend, indemnify and hold
Seller harmless from any and all claims, demands, subrogation claims by Buyer's insurers, causes of
action, liabilities, fines, regulatory actions, seizures of product, losses, costs, expenses
(including, but not limited to attorneys' fees, expert witness expenses and litigation expenses)
(hereinafter "Claim"), arising from or in connection with any Claim asserted against Seller for any
damage, injury, death, loss, property damage, environmental liability, or any other Claim, whether
in tort, contract, or otherwise, relating to this Order, the business relationship between the
parties or the goods provided hereunder. Notwithstanding the foregoing, Buyer has no indemnity
obligation to Seller with respect to any Claims that result solely from the negligence of Seller and
this indemnity provision does not purport to indemnify Seller solely for its own negligence, but
rather for the negligence or conduct, whether sole or concurrent, of Buyer. Buyer, for itself and
its insurers, expressly waives any and all limitations or liability caps, if any, on Buyer's
contribution liability to Seller, and any and all statutory or common law lien rights or Claims
against Seller arising from any applicable workers compensation or disability acts, which Buyer
might or could assert against Seller or Seller's insurers in the event of the personal injury or
death of Buyer's employees, representatives or servants. Without limiting the foregoing, Buyer, for
itself and its insurers, also waives any liens, claims or other rights it may have as a result of
being subrogated to any rights of its employees, representatives or servants. 17. Insurance: Buyer
shall obtain comprehensive general liability coverage, including contractual liability coverage,
naming Seller as an additional named insured, in amounts sufficient to fully protect Seller under
this Agreement from loss, damage or casualty caused by Buyer or incurred by Seller under this
Agreement. 18. Governing Law and Forum Selection: This agreement shall be governed by and subject to
the internal laws (exclusive of the conflicts of law provisions) and decisions of the courts of the
State of Illinois. The parties consent to the exclusive jurisdiction of the federal court in
Chicago, Illinois or the state court located in DuPage County, Illinois with respect to all
litigation, claims, causes of action, demands, Controversies (as defined
<!-- page 16 -->
herein) or disputes among the parties. The only exception to this forum selection provision is a
claim by Seller seeking the replevin of the products in the event the courts specified in this
provision will not or cannot assert jurisdiction. All counterclaims, if any, in connection with the
replevin claim, shall be subject to this forum selection provision.
