<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 1999-02-17 |
| Parties | Tickets.com Inc. "Tickets"; MP3.com Inc. "MP3.com" |
| Source | CUAD v1 / TICKETSCOMINC_06_22_1999-EX-10.22-SPONSORSHIP AGREEMENT |

1

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR CERTAIN REDACTED PROVISIONS OF THIS AGREEMENT. THE
REDACTED PROVISIONS ARE IDENTIFIED BY THREE ASTERISKS AND ENCLOSED BY BRACKETS. THE CONFIDENTIAL
PORTION HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION.

EXHIBIT 10.22

MP3.com, Inc. P.O. BOX 910091 San Diego, CA 92191 (619) 558-9390

SPONSORSHIP AGREEMENT

This Sponsorship Agreement ("Agreement") is made an entered into on February 17, 1999 ("Effective
Date"), by and between Tickets.com, Inc., a Delaware corporation, located at 4061 Glencoe Ave.,
Marina del Rey, CA 90292 ("Tickets") and MP3.com, Inc., having an address at P.O. Box 910091, San
Diego, CA 92191-0091 ("MP3.com"). MP3.com owns and operates the website located at www.mp3.com (the
"Website").

1. Form of Sponsorship. During the term of this Agreement, Tickets shall be MP3.com's exclusive
partner/source for sports, entertainment, and travel tickets, and MP3.com shall include a Tickets
Portal on the "Music" page and the "Pop," "Rock" and "Alternative" genre pages on the Website. A
"Portal" is defined as a web graphic with the dimensions not to exceed 125 x 125 pixels and 20Kb in
size. The content of the Portal shall be supplied by Tickets and shall conform with reasonable
technical and content specifications supplied by MP3.com.

2. Impressions. MP3.com agrees to deliver a guaranteed minimum of 3,000,000 Impressions per month
for the term of this Agreement. An "Impression" is defined as the display of the Tickets Portal to a
user on one of the above referenced pages.

3. Sponsor Fees. Tickets agrees to pay MP3.com, during the term of this Agreement, as follows: (i)
$[***] payable on the Effective Date; (ii) $[***] payable on or before one month subsequent to the
Effective Date; (iii) $[***] payable on or before two months subsequent to the Effective Date; (iv)
$[***] payable on or before three months subsequent to the Effective Date; (v) $[***] payable on or
before four months subsequent to the Effective Date; (vi) $[***] payable on or before five months
subsequent to the Effective Date. Any late payments under this Agreement will be assessed a service
fee of one and one-half percent (1.5%) per month, to the extent allowed by law.

4. Term and Termination. This Agreement shall commence on the Effective Date and shall remain in
full force and effect until one (1) year subsequent to the Effective Date, provided however, that
Tickets may terminate this Agreement for any reason upon thirty (30) days' notice to MP3. com at any
time prior to the expiration of sixty (60) days subsequent to the Effective Date. Furthermore, for a
thirty (30) day period, beginning thirty (30) days prior to the first anniversary of this Agreement,
Tickets shall have the right to renew the Agreement for another year with Sponsor Fees that do not
exceed a [***] percent increase over the existing Sponsor Fees. Any payments which have accrued
prior to the date of termination shall remain due and payable. Sections 6, 7, and 8 shall survive
termination of this agreement.

5. Measurement. Upon request, Tickets shall have access to pertinent statistics related to
Impressions covering the period of this contract. Tickets agrees to accept MP3.com's measurement of
Impressions (the "Count") according to MP3.com's logs and other tracking devices and/or software
MP3.com may use, provided however, that Tickets shall have the right to audit MP3.com's records in
this regard. If Tickets reasonably disputes the Count pursuant to this Agreement, then Tickets shall
have the right to select the independent auditor of its choice to conduct an audit of MP3.com's
records (the "Audit"). The Audit will be conducted in such a way so as not to interfere to any
material extent with MP3.com's operations. If, for any applicable period, the independent auditor
determines that MP3.com overstated the Count by more than five percent (5%), than MP3.com shall pay
the cost of the Audit and shall refund Tickets the difference between the amount originally paid and
the amount which should have been paid, or MP3.com shall credit the appropriate amount of
Impressions to Tickets' account.

[***] Confidential treatment has been requested for redacted portion. The confidential redacted
portion has been omitted and filed separately with the Securities and Exchange Commission.

2

6. Representations and Warranties. Each party is solely responsible for any legal liability arising
out of or relating to the content of its site and any material to which users can link through the
sites. Each party represents and warrants that its sites will not: (i) infringe upon any third
party's copyright, patent, trademark, trade secret or other proprietary rights or rights of
publicity or privacy; (ii) violate any law, statue, ordinance or regulation, including without
limitation any laws regarding unfair competition, antidiscrimination or false advertising; (iii) be
pornographic or obscene; (iv) be defamatory or trade libelous; or (v) contain viruses other harmful
programming routines. Each party agrees to defend, indemnify and hold harmless the other and its
shareholders, directors, officers, agents and employees for any and all losses, costs, liabilities
or expenses (including without limitation
<!-- page 2 -->
reasonable attorneys' and expert witnesses' fees) incurred or arising from: (a) any breach of the
foregoing representations or warranties; (b) any claim arising from the sale or license of either
party's goods or services; or (c) any other act, omission or representation by either party. Either
party may participate in the defense of itself at its option and expense.

7. No Consequential Damages. Except for claims arising under section 6, in no event will either
party be liable for any special, indirect, incidental or consequential damages.

8. Miscellaneous. This Agreement shall be governed by and construed in accordance with the laws of
the State of California without reference to conflict of law principles thereof. Any claim arising
out of or related to this Agreement must be brought exclusively in the state or federal courts
located in San Diego County, California, and each party hereby consent to the jurisdiction thereof.
In any action to enforce this Agreement the prevailing party will be entitled to costs and
attorneys' fees. This Agreement constitutes the entire agreement between the parties with respect to
the subject matter hereof and supersedes all prior discussions, documents, agreements and prior
course of dealing, and shall not be effective until signed by both parties. This Agreement may not
be assigned by Tickets without MP3.com's written consent, which shall be promptly granted or denied
and not unreasonably withheld, except that Tickets may assign this Agreement without MP3.com's
consent if another entity acquires substantially all the assets of Tickets. The parties to this
Agreement are independent contractors, and no agency, partnership, joint venture or
employee-employer relationship is created by this Agreement. MP3.com intends to, and does, bind its
successors and assigns to the terms of this Agreement.

/s/ Greg Flores /s/ Adam Epstein - -----------------------------------
----------------------------------- Representative of MP3.com Representative of Tickets.com, Inc.

/s/ Greg Flores, VP Sales Adam Epstein, SVP Counsel - -----------------------------------
----------------------------------- Printed Name & Position Printed Name & Position

- ----------------------------------- ----------------------------------- Date Date
