<!-- page 1 -->
# CHANNEL PARTNER RESELLER AGREEMENT
| Field | Value |
|---|---|
| Document Type | Reseller Agreement |
| Agreement Date | 2018-04-25 |
| Parties | IPASS INC. ("iPass"); Pareteum Corporation ("Channel Partner") |
| Source | CUAD v1 / IpassInc_20181203_8-K_EX-99.1_11445874_EX-99.1_Reseller Agreement |

Exhibit 99.1 [***] = Certain confidential information contained in this document, marked by
brackets, is filed with the Securities and Exchange Commission pursuant to Rule 24b-2 of the
Securities Exchange Act of 1934, as amended.

CHANNEL PARTNER RESELLER AGREEMENT THIS CHANNEL PARTNER RESELLER AGREEMENT ("Agreement") is entered
into and agreed upon as of the Effective Date by and between IPASS INC., having a principal place of
business at 3800 Bridge Parkway, Redwood Shores, CA 94065 ("iPass"), and Pareteum Corporation,
having a principal business address at 100 Park Avenue, Suite 1600, New York City, New York 10017
("Channel Partner"). Capitalized terms used in this Agreement shall be defined as set forth herein.
This Agreement is comprised of the Terms and Conditions together with all Exhibits attached hereto.
The undersigned represent and warrant that they are authorized as representatives of the party on
whose behalf they are signing this Agreement and that they have read and agree to adhere to the
Terms and Conditions as well as the exhibits attached hereto and incorporated herein by reference.
IN WITNESS WHEREOF, the parties have executed this Agreement as of the Effective Date. Channel
Partner: iPass Inc.: By: /s/ Victor A. Bozzo By: /s/ Christine Gardner Victor A. Bozzo Christine
Gardner Printed Name Printed Name Chief Executive Officer VP Finance Title Title 4/24/2018
04/25/2018 Date Date

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 2 -->
TERMS AND CONDITIONS 1. APPOINTMENT OF CHANNEL PARTNER 1.1 General. iPass will make the Service
available to Channel Partner in exchange for the fees referenced in the Exhibits attached hereto and
incorporated herein by reference. Channel Partner may order Services using an iPass approved order
form available via the iPass Portal. Each order form must reference this Agreement and each order
form shall merge and incorporate the terms herein. Each order form is a separate and distinct
contractual obligation. 1.2 Grant of Authority. iPass grants to Channel Partner a nonexclusive,
terminable right to: (i) access and otherwise use the Licensed Software, and iPass Marks as provided
in Exhibit F solely in furtherance of this Agreement and not for other internal business purposes,
(ii) sell or re-license the Licensed Software, Documentation and Services to Business Entities and
End Users, and (iii) install and execute the Server Software on up to three (3) designated servers
and one backup server for Channel Partner and for each End User. Channel Partner accepts iPass as
the exclusive provider to Channel Partner for all services of the nature of the Services. In no
event may Channel Partner resell or otherwise provide the Service to any third party for purposes of
further "down channel" resale of the Services, absent iPass' notice and consent. The license granted
under this Section 1.2 does not include a license or other right to use the iPass domain name and
does not include the right to use the trademark or trade name of any iPass supplier or partner. 1.3
Software Delivery iPass will provide the Licensed Software to Channel Partner electronically via the
iPass Portal, an iPass FTP website or on-line app store. 1.4 Account and Password Information. iPass
will assign to Channel Partner a unique password and identification code used to access the Channel
Partner section of the iPass Portal. Channel Partner may not transfer or share this account
information with any third party. Channel Partner is solely responsible for assigning user names and
passwords ("Credentials") to End Users so that End Users may access the iPass Portal and for
imposing reasonable limitations on the disclosure of such Credentials. 2. CHANNEL PARTNER
RESPONSIBILITIES 2.1 General. Channel Partner will use its reasonable endeavours cooperate with
iPass and assist with the implementation of this Agreement and performance of the Services. Prior to
deployment of the Licensed Software in a production environment, Channel Partner agrees to implement
processes that will allow the Licensed Software to successfully report as specified in the
Documentation. If Channel Partner fails to implement such processes within a reasonable time
following iPass' request, iPass may elect to terminate the Agreement or Channel Partner's use of the
Licensed Software upon written notice to Channel Partner. In such an event, Channel Partner shall be
responsible for payment of all undisputed amounts due and owing to iPass under the Agreement. In
addition, Channel Partner agrees to ensure that prior to deployment of the Licensed Software in a
Business Entity production environment, each Business Entity implements processes that will allow
the Licensed Software to successfully report as specified in the Documentation. If Channel Partner's
Business Entity fails to implement such processes within a reasonable time following iPass' or
Channel Partner's request, iPass may elect to terminate the order for such Business Entity upon
written notice to Channel Partner. In such an event, Channel Partner shall be responsible for
payment of all undisputed amounts due and owing to iPass under the Agreement. 2.2 Acceptable Use
Policy. Channel Partner agrees that it will not (and will not permit Business Entities) to use the
Service in a manner contrary to the iPass acceptable use policy located at
http://www3.ipass.com/wp-content/uploads/2010/01/Acceptable-Use-Policy.pdf/ , and incorporated
herein by reference.

Page 2 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 3 -->
2.3 End User Realms. A realm is used to uniquely identify a user with a specific End User or group.
(An example would be example.com). Realms are created by iPass in cooperation with Channel Partner
and the relevant End User. Channel Partner does not own or control these realms by virtue of having
registered them with iPass or having paid any fees associated with such registration. Upon request
by Channel Partner or the End User, iPass may remove a realm from its system or re-assign a realm to
another Channel Partner. 2.4 End User Support. Channel Partner will provide technical and End User
support in accordance with Exhibit D. 2.5 End User Satisfaction. iPass may, upon reasonable notice
to Channel Partner, directly contact End Users for any reason pertaining to such End User's use of
the Service, subject to compliance with local privacy law. Should an End User communicate to Channel
Partner or to iPass its dissatisfaction regarding the Services or related matters, the notified
party shall promptly give notice to the other party, and iPass and Channel Partner shall work
together in good faith to resolve the issue to End User's reasonable satisfaction. If in iPass'
reasonable determination the issue is not resolved within thirty (30) days after Channel Partner's
receipt of notice of End User's dissatisfaction, iPass may, in addition to other remedies available
to iPass, revoke Channel Partner's appointment under Section 1.2 wholly or with respect to such End
User and may refer such End User to another iPass channel partner or provide services directly to
such End User without any liability to Channel Partner. 2.6 End User Agreements. Before making
available any Services to an End User, Channel Partner will enter into an End User Agreement that is
materially similar to the terms and conditions contained in Exhibit E. Channel Partner will enforce
each End User Agreement with at least the same degree of diligence used in enforcing similar
agreements pertaining Channel Partner's own services or products but in no event will Channel
Partner provide a standard of care in this regard that is less than commercially reasonable. Channel
Partner will not waive, amend, or agree to terms that would tend to negate or materially dilute the
sample terms provided in Exhibit E. Channel Partner shall promptly notify iPass of any material
breach of any End User Agreement and will cooperate with iPass and/or iPass suppliers in any legal
action to mitigate iPass' damages in the event of any such breach. iPass may, and may require
Channel Partner to suspend or terminate Services to an End User who breaches the terms of an End
User Agreement. Upon request, Channel Partner will provide iPass a copy of each End User Agreement
entered into by Channel Partner and End Users. A breach by an End User is deemed a breach by Channel
Partner. 2.7 TRAINING. iPass may provide training in use of the Services. Such training and the
applicable fees are indicated in Exhibit D. 3. SERVICE RATE PLAN 3.1 Fees. Channel Partner is solely
responsible for billing End Users, and paying iPass for all usage of the Services. Channel Partner
agrees to pay for usage of the Service on a monthly basis in accordance with the pricing set forth
in Exhibit C. iPass may change the pricing in Exhibit C upon notice to Channel Partner, such changes
to be effective within thirty (30) days after the date of such notice, such changes may include, by
way of example only, the application of end of life fees.

Page 3 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 4 -->
3.2 Payment. All payments hereunder will be in US Dollars and are due and payable within thirty (30)
days after the date of invoice. iPass may terminate or modify these payment terms with reasonable
notice, when, in its reasonable discretion, iPass believes that its payments may be at risk. All
rights of Channel Partner are expressly made conditional upon timely payment, without the right of
set off, of all amounts due by Channel Partner under the Agreement. Without limiting iPass' other
available rights and remedies, iPass reserves the right to suspend or to terminate any Services ten
(10) days after sending written notice of a payment that is thirty (30) or more days past due. iPass
may include on an invoice, and Channel Partner agrees to pay for: (i) any Services used within one
hundred eighty (180) days before the date of the invoice; and (ii) any corrections to amounts
invoiced within one hundred eighty (180) days after the date of the original invoice. If Channel
Partner reasonably disputes an invoiced amount, Channel Partner may: (a) withhold such amount from
Channel Partner's payment, provided that Channel Partner gives iPass written notice of the dispute
and the reason for such dispute within thirty (30) days after the date of invoice, and pays all
invoiced amounts not subject to such dispute by the due date; or (b) in the event that the invoiced
amount has already been paid in full, submit a claim to iPass within sixty (60) days following the
date of the original invoice. The parties will cause their authorized representatives to meet within
fifteen (15) days after Channel Partner's notice of dispute to negotiate in good faith to resolve
the dispute. If such representatives have not resolved the dispute within fifteen (15) days after
their first meeting, the parties will either decide mutually to continue negotiations or, if either
party does not desire to continue negotiations, each party may exercise its available remedies with
respect to the disputed amounts. To the extent a dispute resolution requires payment of disputed
amounts, Channel Partner shall pay such disputed amounts promptly after the dispute is resolved. 3.3
Late Fees. iPass reserves the right to charge interest of one and one-half percent (1.5%) per month
compounded for the entire overdue period or the maximum amount allowed by law if fees are not paid
by their due date. 3.4 Taxes. Channel Partner will pay all applicable transaction based taxes
including but not limited to sales, use, gross receipts, excise, value-added, duties and other taxes
and/or surcharges related to purchase of iPass Services and goods. As between iPass and Channel
Partner, Channel Partner will be responsible for self-assessing and remitting all transaction based
taxes unless otherwise invoiced by iPass. If Channel Partner is required by law in Channel Partner's
respective country to withhold taxes on payments made to iPass, then Channel Partner shall gross up
such payments by the amount of tax withheld. All prices are exclusive of tax. If required to do so
by law, iPass will charge sales or value added tax where registered. Otherwise, Channel Partner is
liable to self-assess or reverse charge applicable sales or value added tax. For tangible products
shipped overseas iPass will not be importer of record. Channel Partner will provide and make
available to iPass any resale certificates and other exemption certificates that are related to the
taxes that may be due as a result of this Agreement. Upon receipt of any such resale or exemption
certificate, iPass will exempt Channel Partner in accordance with the applicable law, effective on
the date iPass receives the certificate(s). 4. BRANDING 4.1 Branding. Subject to the license grant
in Section 1.2, Channel Partner agrees to incorporate and display the iPass trademarks and logos set
forth in Exhibit F, Exhibit F may be amended from time to time by iPass ("iPass Marks"), on all
Channel Partner web sites mentioning the Service, all help files relating to the Service and all
printed collateral referring to the Service. Channel Partner may reproduce and publicly display any
iPass web content as provided to Channel Partner by iPass on Channel Partner's web site. Channel
Partner will not modify the iPass Web Content without iPass prior written approval. Channel Partner
will have at a minimum one (1) web page describing the iPass Services. Channel Partner will follow
the iPass Branding usage guidelines which will be provided by iPass on the secure iPass Portal. Use
of the iPass Marks is subject to iPass' reasonable review and approval. Channel Partner shall state
at the first instance of each use of an iPass Mark that the iPass Mark is iPass' trademark and shall
include the symbols TM and ® as appropriate. Channel Partner shall not use any trademark, word,
symbol, letter, or design in combination with the iPass Marks in a manner that would create a
combination mark. Channel Partner shall not attempt to register the iPass Marks or adopt, use or
attempt to register any confusingly similar mark or web site domain names.

Page 4 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 5 -->
4.2 Client Software Branding. Upon request, iPass will provide Channel Partner co-branding space on
the Client Software interface in order to display a logo or trademark of Channel Partner or an End
User. The placement and size of any Channel Partner mark included on the Client Software interface,
if any, will be in iPass' sole discretion. Channel Partner may not remove, modify, or obscure the
iPass Mark and iPass branding on the Client Software without the prior consent of iPass. iPass will
supply Channel Partner with appropriate graphics for Client Software applications, web promotional
banners, and logos for print and web uses. 4.3 Information Updates. Channel Partner agrees to update
its information on the iPass Services on its website and in other materials at a minimum of once a
quarter to reflect current information on the iPass Services as such information is provided by
iPass. 4.4 Publicity and Channel Partner Lists. After the Effective Date and subject to approval
from the Channel Partner first, iPass may issue a press release announcing that Channel Partner is a
reseller of the iPass Service and announcing the existence of this Agreement. Channel Partner shall
mention the iPass name in all press releases related to the Services. Channel Partner consents to
(i) the use of its name and logo in iPass' Channel Partner lists, (ii) the use of its name in iPass'
quarterly earnings announcement, and (iii) on the iPass website in order to assist potential End
Users with locating an authorized iPass reseller. Channel Partners agrees to be a reference for
iPass, upon iPass' reasonable request. Channel Partner will not issue any press release or other
public communication related to this Agreement or Channel Partner's status as an iPass reseller
without prior approval of the content by iPass. Channel Partner shall give iPass a reasonable amount
of time to review and approve material distributed publicly. If iPass provides edits to content
about iPass products, services, technology or any other content related to the iPass business,
Channel Partner will incorporate those changes into the final document. 5. INTELLECTUAL PROPERTY 5.1
Channel Partner acknowledges that all iPass intellectual property referenced herein contains the
valuable trade secrets of iPass, and Channel Partner agrees not to cause or permit the reverse
engineering, translation, disassembly, or decompilation of the intellectual property, or otherwise
to attempt to derive the source code thereof, whether in whole or in part. Channel Partner will not
use, reproduce, modify, prepare derivative works of, distribute, sublicense, loan, sell, or
otherwise transfer any such iPass intellectual property except as expressly permitted herein. 5.2 As
between the parties, iPass and/or its suppliers will retain all title, copyright and other
proprietary and intellectual property rights in and to the Service, the Server Software and Licensed
Software, and any other technology, services, or materials that iPass may provide to Channel Partner
hereunder. All rights in and to the foregoing not expressly granted to Channel Partner in this
Agreement are reserved to iPass and its suppliers. In particular, but without limiting the
generality of the foregoing, no right to or license in the source code for the Licensed Software or
Server Software is granted hereunder. Channel Partner will not obfuscate, alter, or remove any
copyright, trademark, or other proprietary notice or legend on or in the Licensed Software or
Documentation and will include all such markings in all copies of such materials.

Page 5 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 6 -->
6. WARRANTY. 6.1 DISCLAIMER OF WARRANTY. iPASS AND ALL iPASS SUPPLIERS EXPRESSLY DISCLAIM ANY AND
ALL WARRANTIES, CONDITIONS, AND REPRESENTATIONS OF ANY KIND, WHETHER EXPRESS, IMPLIED OR
STATUTORY,INCLUDING ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NEITHER
iPASS NOR ANY iPASS SUPPLIER WILL BE LIABLE FOR ANY THIRD-PARTY NETWORK FAILURE. iPASS AND ITS
SUPPLIERS SPECIFICALLY DO NOT WARRANT THAT THE SERVICES WILL MEET CHANNEL PARTNER'S OR END USER
REQUIREMENTS, WILL BE UNINTERRUPTED, TIMELY, SECURE, ERROR FREE, AVAILABLE ON A SPECIFIED DATE OR
TIME OR WILL HAVE THE CAPACITY TO MEET CHANNEL PARTNER'S OR END USER DEMAND DURING SPECIFIC HOURS.
CHANNEL PARTNER ACKNOWLEDGES THAT IT HAS NOT ENTERED INTO THIS AGREEMENT IN RELIANCE UPON ANY
WARRANTY OR REPRESENTATION. 6.2 iPass Warranty of Title. iPass has requisite title, permits,
licenses and authority to grant Channel Partner the rights and licenses referenced herein. 6.3 No
Pass-Through Warranty. Channel Partner shall make no representations or warranties concerning the
Licensed Software or the Services on behalf of iPass or any iPass supplier. 6.4 Channel Partner
Warranty. Channel Partner agrees that the quality of its products and services to be provided in
connection with any of the iPass Marks will be substantially the same as the quality of such other
Channel Partner products and services and shall otherwise comport with industry standards and in the
event of breach of this Section 6.4, Channel Partner shall take prompt and urgent actions to
remediate the breach. 7. CONFIDENTIAL INFORMATION. 7.1 For purposes of this Section 7, the
"Disclosing Party" shall be the party which discloses Confidential Information and the "Receiving
Party" shall be the party that receives the Confidential Information. The following is not
considered Confidential Information: (i) information which the Receiving Party is authorized in
writing by the Disclosing Party to use without restriction; (ii) information rightfully in the
Receiving Party's possession or known to it without the duty of confidentiality prior to receipt of
such information from the Disclosing Party; (iii) information which is rightfully disclosed to the
Receiving Party by a third party, having proper possession of such information, without the duty of
confidentiality; (iv) information which properly enters the public domain; or (v) information which
is independently developed by the Receiving Party without reference to the Disclosing Party's
Confidential Information. 7.2 The Receiving Party shall use the Disclosing Party's Confidential
Information only for the purpose set forth in the Agreement, and shall cause its Users to keep
Confidential Information confidential, sharing it on a "need-to-know" basis only. The Receiving
Party may disclose Confidential Information in connection with a judicial or administrative
proceedings to the extent such disclosure is required under law or a court order, provided that the
Disclosing Party shall be given prompt written notice of such proceeding. Upon termination of this
Agreement or Disclosing Party's request, Receiving Party shall return and at Disclosing Party's
option, destroy any and all Confidential Information exchanged under this Agreement. 7.3 In addition
to any other remedies, the Disclosing Party shall be entitled to seek equitable relief. 7.4 For
Confidential Information pertaining to the Licensed Software, the obligations set forth in this
Section 7 are indefinite. For all other Confidential Information, such obligations shall continue
for five (5) years from the date of initial disclosure.

Page 6 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 7 -->
8. INDEMNIFICATION OBLIGATIONS. 8.1 By iPass. iPass agrees to indemnify Channel Partner or, at its
option, settle, any third party claims that the Licensed Software or Services provided under this
Agreement infringes a copyright, patent, trademark, trade secret or other intellectual property
right. If the Licensed Software or Service becomes, or in iPass' opinion is likely to become, the
subject of an infringement claim, iPass may, at its option and expense, either: (a) procure for
Channel Partner the right to continue using the affected Licensed Software or Service;(b) replace or
modify the Licensed Software or Service so that it becomes non-infringing; (c) accept return of the
Licensed Software; or (d) terminate the Services. iPass shall have no liability under this Section
8.1 if: (i) the allegation of infringement is a result of a modification of the Licensed Software or
Services; (ii) if the Licensed Software or Services is not being used in accordance with the
Documentation; (iii) if the Licensed Software is no longer supported by iPass; (iv) if the alleged
infringement could be avoided or otherwise eliminated by the use of an published Update; or (v) if
the alleged infringement is a result of use of the Licensed Software or Services with any non-iPass
supplied third party product or software. This indemnification does not include and/or apply to
Internet connectivity or Internet access services. 8.2 By Channel Partner. Channel Partner agrees to
indemnify iPass or, at its option, settle, any third party claims against iPass arising from or
relating to Channel Partner's: (a) infringement of a copyright, patent, trademark, trade secret or
other proprietary rights or rights of publicity or privacy; (b) violation of iPass' acceptable use
policy, or (c) a violation of this Agreement. 8.3 Mechanics of Indemnity. The above indemnification
obligations are contingent upon: (i) the indemnified party providing prompt written notice to the
other party of any such claims and assistance in the defense thereof; (ii) the party indemnifying
has sole right to control the defense or settlement of any such claim, provided that the settlement
does not require a payment or admission of liability on the part of the indemnified party; and (iii)
that indemnified party does not take any actions or refrain from taking actions that hinder the
defense or settlement process as reasonably directed by the party indemnifying the other party. 8.4
SECTION 8 STATES THE ENTIRE LIABILITY AND OBLIGATIONS OF THE PARTIES WITH RESPECT TO ANY ACTUAL OR
ALLEGED THIRD PARTY CLAIMS ARISING FROM OR RELATING TO THIS AGREEMENT. 9. LIMITATIONS OF LIABILITY.
9.1 DIRECT DAMAGES. EACH PARTY'S MAXIMUM LIABILITY FOR DAMAGES CAUSED BY ITS FAILURE TO PERFORM ITS
OBLIGATIONS UNDER THE AGREEMENT IS LIMITED TO: (A) PROVEN DIRECT DAMAGES FOR CLAIMS ARISING OUT OF
PERSONAL INJURY OR DEATH, OR DAMAGE TO TANGIBLE PROPERTY CAUSED BY THE PARTY'S NEGLIGENT OR WILLFUL
MISCONDUCT; AND (B) PROVEN DIRECT DAMAGES FOR ANY AND ALL CLAIMS ARISING FROM OR IN CONNECTION WITH
OR RELATING TO THIS AGREEMENT OR THE LICENSED SOFTWARE OR SERVICES, NOT TO EXCEED AN AMOUNT EQUAL TO
THE AMOUNT OF FEES ACTUALLY PAID BY CHANNEL PARTNER TO IPASS DURING THE SIX (6) MONTHS PRECEDING THE
FIRST EVENT GIVING RISE TO SUCH LIABILITY. ALL CLAIMS AGAINST THE PARTIES WILL BE AGGREGATED TO
DETERMINE SATISFACTION OF THIS LIMIT, AND MULTIPLE CLAIMS WILL NOT ENLARGE THE LIMIT. 9.2
CONSEQUENTIAL DAMAGES. NEITHER PARTY WILL BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT,
EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES ARISING OUT OF OR IN CONNECTION WITH THIS AGREEMENT OR
THE USE OF THE LICENSED SOFTWARE, THE SERVICES OR DOCUMENTATION, WHETHER FROM BREACH OF CONTRACT OR
WARRANTY, FROM NEGLIGENCE, STRICT LIABILITY OR OTHER CAUSE OF ACTION, EVEN IF SUCH PARTY HAS BEEN
ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

Page 7 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 8 -->
9.3 EXCLUSIONS. CHANNEL PARTNER'S PAYMENT OBLIGATIONS, LIABILITY FOR EARLY TERMINATION FEES OR
CHARGES, BREACHES OF CONFIDENTIALITY BY EITHER PARTY, MISAPPROPRIATION OF INTELLECTUAL PROPERTY
RIGHTS OF THE OTHER PARTY, AND THE PARTIES' INDEMNIFICATION OBLIGATIONS UNDER THIS AGREEMENT ARE
EXCLUDED FROM THESE LIMITATIONS OF LIABILITY. 10. TERM AND TERMINATION 10.1 Term. This Agreement
shall commence on the Effective Date and shall continue for a period of twelve (12) full calendar
months ("Initial Term"). The Agreement shall automatically renew for successive one (1) year terms
(each a "Renewal Term") unless either party provides the other party written notification of its
intent to terminate the Agreement no later than sixty (60) days prior to the end of the then
applicable term. Except in instances of termination of this Agreement in accordance with Sections
10.2 and 10.3 below, this Agreement shall continue, even if terminated, until the expiration of the
last Business Entity Term. 10.2 Termination for Breach. If either party materially breaches this
Agreement or terms or conditions within this Agreement, and such breach is not cured within thirty
(30) days after written notice is given to the breaching party, then the other party may, by giving
written notice to the breaching party, terminate this Agreement as of the end of such thirty (30)
day notice period or such later date as is specified in such notice of termination 10.3 Termination
in the Event of a Bankruptcy. If a party becomes insolvent or if bankruptcy or receivership
proceedings are initiated by or against a party to this Agreement other than for the purposes of
solvent reconstruction, the other party shall have the right to terminate this Agreement immediately
for cause. 10.4 Economic Hardship. If iPass provides evidence that this Agreement is directly
causing material financial losses ("Economic Hardship") to iPass, the Parties will work together to
address and remedy such Economic Hardship. Should the Parties fail to reach a mutually agreeable
solution within thirty (30) days after initial written notice to the Partner, iPass may terminate
this agreement with ten (10) business days' written notice. In the event of such termination,
Customer will only be liable for costs of current utilized subscriptions up to the time of the
termination of the agreement. 10.5 Effects of Termination. Upon termination for reasons other than
material breach by iPass, all fees and expenses (including but not limited to any minimum monthly
commitments) to be paid by Channel Partner to iPass shall become due and payable immediately. All
fees are non- cancellable and non-refundable. Termination of an order shall not terminate any other
order or this Agreement absent a proactive termination of this Agreement in accordance with the
applicable termination provisions herein. Upon expiration or termination of this Agreement, the
order forms and the all licenses granted in the Agreement will immediately terminate, Channel
Partner will immediately remove the Licensed Software and Documentation from its servers, return or
destroy all Licensed Software and Documentation in its possession, and each party will return or
destroy all copies of the other party's Confidential Information. Sections 3.4, 3.6, 6.1, 6.3, 7,
8.2, 8.3, 9, 12 and Exhibit A any terms of an Exhibit that should by its nature survive expiration
or termination of this Agreement will survive. 11. PRIVACY 11.1 Any information that iPass collects
from End Users, or that is made available by End Users to iPass hereunder, is subject to iPass'
privacy policy located at http://www.ipass.com/privacy-policy/. This policy is expressly
incorporated into and made a part of this Agreement. The Parties further agree that iPass may use
End User emails to directly contact End Users for service support and updates. This is limited to
providing assistance with service sign up, credential retrieval, troubleshooting network
connectivity or application use, informational updates about hotspot additions/changes or planned
outages (maintenance).

Page 8 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 9 -->
12. GENERAL TERMS 12.1 Neither party will be liable to the other for failure to fulfill its
obligations caused by circumstances beyond its reasonable control. Such circumstances will include
without limitation acts of God, strikes, lockouts, riots, terrorist attacks, acts of war, epidemics,
civil disturbance, fire, communication line failures, power failures, earthquakes, floods or other
natural disasters. In such event, the obligations of the parties (excluding payment obligations)
will be temporarily suspended to such extent reasonable under the circumstances. 12.2 The
relationship between the parties is that of independent contractors. 12.3 Channel Partner may not
assign the Agreement, the use of any Licensed Software or Services or its rights and obligations
under the Agreement without the prior written consent of iPass. Any such assignment is void. The
Agreement shall be binding on the parties and all of their respective successors and assigns. 12.4
Any notices required or permitted hereunder will be given to the attention of the Legal Department
at the address specified as the principal place of business of each company or at such other address
as the parties specify in writing. Notice will be deemed given: upon personal delivery; if sent by
confirmed facsimile, upon confirmation of receipt; if sent by overnight courier, upon receipt; or,
if sent by certified or registered mail, postage prepaid, three (3) days after the date of mailing.
Notwithstanding, all Business Entity notifications, including termination notifications, must be
submitted though the iPass Portal. 12.5 If any provision of the Agreement is held to be invalid,
illegal or unenforceable by any court or other competent tribunal then the remaining provisions of
the Agreement shall remain in full force and effect. 12.6 The laws of California shall govern the
construction and enforceability of the Agreement. The parties agree that any action arising under or
relating to the Agreement or the Licensed Software or Services shall lie within the exclusive
jurisdiction of the Courts located in San Mateo County, California, USA. The United Nations
Convention on Contracts for the International Sale of Goods will not apply to the Agreement. 12.7 A
person who is not a party to the Agreement has no rights to enforce any term of the Agreement but
this does not affect any right or remedy of a third party which exists or is available under
applicable law. 12.8 Channel Partner will comply with all applicable laws and regulations, including
privacy, data protection, and exportation, regarding its activities related to this Agreement. 12.9
Channel Partner may not export or re-export the Licensed Software, any part thereof, to any country,
person or entity subject to U.S. export restrictions. Channel Partner agrees not to export or
re-export the Licensed Software: (i) to any country to which the U.S. has embargoed or restricted
the export of goods or services, or to any national of any such country; (ii) wherever Channel
Partner knows or has reason to know that the Licensed Software will be utilized in the design,
development or production of nuclear, chemical or biological weapons; or (iii) to any entity who
Channel Partner knows or has reason to know has been prohibited from participating in U.S. export
transactions by any federal agency of the U.S. government.

Page 9 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 10 -->
12.10 Channel Partner represents that: (i) it is duly authorized to provide personal data to iPass;
(ii) iPass, its affiliates and its subcontractors can process such data, and (iii) iPass may
disclose such data to any affiliate and subcontractor for the purpose of: (a) providing Licensed
Software and Services under the Agreement; (b) administering the Agreement; and/or (c) providing
marketing and/or product information to Channel Partner through any medium including email. The
Parties further agree that iPass may use End User emails to directly contact End Users for service
support and updates. This is limited to providing assistance with service sign up, credential
retrieval, troubleshooting network connectivity or application use, informational updates about
hotspot additions/changes or planned outages (maintenance). 12.11 This Agreement constitutes the
entire agreement between the parties concerning the parties with regard to the Licensed Software and
Services provided hereunder. All purchase orders, prior agreements, proposals, representations and
other understandings whether oral or written, are superseded in their entirety by this Agreement and
any applicable order forms. A purchase order may not be used as an order form, and any pre-printed
terms on any Channel Partner generated purchase order shall not apply. No alteration or modification
of the Agreement will be valid unless made in writing and signed by the parties. In the event of a
conflict between the Agreement and any terms and conditions in any other order form, the terms of
this Agreement will control unless otherwise expressly stated. The person signing this Agreement
represents that he/she is duly authorized to bind the company to the terms and conditions herein.
12.12 Without limiting any of the terms and conditions contained herein, Channel Partner will make
available to iPass certain services in exchange for the fees and subject at all times to the terms
and conditions referenced in Exhibit G, as same may be updated and amended from time to time.

Page 10 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 11 -->
EXHIBIT A DEFINITIONS "Access Point" means Internet access points to which a User connects via the
Client Software. "Affiliate" means any entity which is controlled by, controls or is under common
control with Channel Partner. For the purposes of this definition, control shall mean ownership of
at least fifty percent (50%) of the outstanding voting equity interest. Channel Partner may appoint
an Affiliate to perform resale services hereunder with written consent of iPass and in accordance
with any iPass mandated contractual commitments and contractual documents. "Agreement" means this
Channel Partner Reseller Agreement, including the Exhibits attached hereto, and orders placed
pursuant to this Agreement. For clarity, each order constitutes a separate and distinct order for
iPass Software and/or Services, and thus each order constitutes a separate contractual commitment.
Each order incorporates the terms and conditions set forth herein. "Business Entity" means a
corporation, partnership, or enterprise that acquires Services from Channel Partner for use by its
employees and contractors. A Business Entity is not authorized to resell the Services to any third
parties. 11. "Business Entity Minimum Monthly Commitment" means, for each Business Entity, a minimum
monthly commitment of at least 250 Users, by Channel Partner for each Business Entity. iPass shall
invoice Channel Partner on a monthly basis, the agreed upon price for the Services as set forth
herein. If Channel Partner's total invoiced amount for the Services, for each Business Entity is
less than the amount for the number of Users for the Business Entity's Minimum Monthly Commitment,
iPass will invoice and Channel Partner will pay to iPass, the shortfall difference between the
actual amount paid by Channel Partner to iPass and the amount for the number of Users for the
Business Entity Minimum Monthly Commitment. "Business Entity Term" means, for each Business Entity,
a period beginning at the beginning of the Business Entity Implementation Period and ending no less
than twelve (12) months following the expiration of the Business Entity Implementation Period, as
indicated in the order placed by Channel Partner for such Business Entity. Every Business Entity
Term automatically renews for a period of no less than 12 months, unless otherwise agreed to in
writing between the parties. "Certified iPass Engineer" means an employee of Channel Partner who has
attended one RoamServer training session and successfully completed the following on-line training
modules: iPass Orientation, Product Training, Technology Training, and Competitive Training.
Successful completion means achieving a passing result on the on-line tests after each module.
"Certified Help Desk Agent" means an employee of Channel Partner who has attended one RoamServer
training session, one Help Desk training session, and one Broadband Support training session.
"Certified Trained Sales Personnel" means an employee of Channel Partner who has successfully
completed the following on-line training modules: iPass Orientation, Product Training, Technology
Training, Competitive Training, and Sales Training. Successful completion means achieving a passing
result on the on-line tests after each module. "Client Software" means the machine executable
version(s) of the client software code, including any Updates thereto, that iPass provides Channel
Partner hereunder to enable Channel Partner's End Users to use the Service. The Client Software
currently consists of iPass' Open Mobile software as well as the iPassConnect software.
"Confidential Information" means information maintained in confidence by a party, and which is
marked as such, or information whether written or oral that by its nature would be to a reasonable
person under the circumstances understood to be confidential or proprietary information of a party
including but not limited to iPass' Software, Documentation, and the parties' product development
and marketing plans, business methods and non-public financial and personnel dat "Device" means any
machine, computer, smartphone or similar User apparatus on which Channel Partner or a Business
Entity has installed the Client Software. "Documentation" means the standard published technical
user manuals provided by iPass.

Page 11 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 12 -->
"Effective Date" means the date of last signature on this Agreement. "Enabled Devices" mean any
device with the Channel Partner's app (iOS, Android, PC or Mac) which is enabled by Channel Partner
to access the iPass services and also registered and enabled, by the Channel Partner to access
Channel Partner's services. "End Users" or "User" means is any person who has an eligible subscriber
ID that allows them to access the iPass Services and iPass Network. "End User Agreement" means a
written agreement between Channel Partner and a Business Entity or an End User, containing terms and
conditions at least as protective of iPass and its suppliers as the terms and conditions set forth
in Exhibit E. "iPass Hosted Authentication Service" means a hosted, managed authentication service
available within the iPass Portal and hosted by iPass. "iPass Portal" means the secure website
accessible through http://www.ipass.com/ where Channel Partner may obtain information about iPass
Services, including invoice, billing, ordering and account information, and submit technical support
requests. "iPass Web Content" means the information and other materials/content provided to Channel
Partner to use in developing Channel Partner's web site(s) or web pages to explain, promote and
support the Service. "Licensed Software" "Software" means the Client Software and the Server
Software and any Updates to the Client Software and the Server Software (if any). "Mobile Network"
or "iPass Network" means iPass' multi-technology mobile access network which includes mobile
broadband, Wi-Fi and Ethernet services. The iPass Network is subject to change by iPass upon notice
to Partner, on condition that such changes do not materially degrade the network. The iPass Network
does not include certain Wi-Fi services that are subject to supplier enforced restrictions. In
addition, if any country is subject to a US embargo or other export restriction, it will not be
deemed included in the foregoing list, the iPass Network will not be available from such country,
and Customer agrees not to use the Licensed Software or the iPass Network in such country..
"Services" means the services and software provided by iPass as more fully described in Exhibit B
attached hereto which allow access to the iPass Network. "Term" means the duration of the Agreement.
"Update" means any bug fixes, patches or software updates for error corrections which iPass makes
available to Channel Partner under this Agreement.

Page 12 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 13 -->
EXHIBIT B IPASS SERVICES iPass Services - includes the following services: iPass Mobile Services are
delivered to End Users through a cloud-based platform (the "Platform") comprising software elements
on the mobile device and available over the Internet. iPass´ Platform gives control over the
definition and management of mobility services configured to a carrier's specific needs. This
architecture gives an End User choice in access services and serves as a bridge to future
functionality through use of extensible web services standards, while keeping the operational and
financial burden on carriers low by not requiring them to purchase, deploy and manage on-premises
infrastructure. iPass´ Platform is designed to provide Customer with reliability, flexibility,
network security, policy enforcement, consolidated billing and scalability. The technology consists
of the following principal components: i. Foundation Services. Provide the basic capabilities needed
for a cloud-based platform, including the ability to manage users (add, remove, or change rights),
authenticate users to access the platform, authorize access to particular functions, or track and
audit use of the platform. ii. Operational Services. Are built on top of the iPass Foundation
Services platform, enabling Customer to operate the various iPass´ market- facing offers, including
user profile/configuration management, network directory management, account management, order
management, usage management, support, billing and training. iii. Presentation Services. Impact how
information is presented to users of the Platform, usually through a web based portal. Presentation
Services include web presentation, data validation, access control (controlling who can see and
enter what), and web analytics. iv. Client Services. Provide the core update functionality within
the Platform, with the ability to update the iPass Client Software, configuration files, and network
registries associated with it, and to receive the data that the client collects. v. Curation
Services. Ability of iPass platform to collect information about Open Networks and be able to decode
the hotspot information and automate steps to connect to that Network. vi. High-Availability and
Scalable Authentication Architecture. iPass´ relationships with network service providers enables
iPass to provide connectivity through multiple networks in over 100 countries on the Platform. As a
result, the cloud-based Platform reduces the risk of service interruptions associated with depending
on only one service provider. Furthermore, iPass´ geographically distributed transaction centers act
as a unified and fault-tolerant system that provides scalable and highly-available user
authentication and quality management information collection. Each point in the authentication
process is designed with built-in redundancy and fail-over capabilities.

Page 13 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 14 -->
EXHIBIT C SERVICE FEES 1. Pricing. For each Business Entity where UTLD Pricing is elected, Channel
Partner shall pay the fees based on the elected Business Entity User Base Package designated by
Channel Partner for each order. The fees include the (i) use of the Mobility Management Services;
(ii) unlimited iPass network access (except for certain premium in-flight Wi-Fi Services); and (iii)
iPass Hosted Authentication Service. Additionally, no Business Entity Start Up Service Fees will be
applied to new Business Entities electing the ULTD Pricing option. The fees for ULTD Pricing are
defined in Table 1 below. The prices in Table 1 represent the transfer pricing from iPass to Channel
Partner for ULTD Pricing. No further discounts are applied to this pricing. TABLE 1

Business Entity Committed Users Monthly Fee/User Minimum Monthly Fee

[***] [***] [***]

[***] [***] [***]

[***] [***] [***]

[***] [***] [***]

[***] [***] [***]

[***] [***] [***]

[***] [***] [***]

[***] [***] [***]

[***] [***] [***]

[***] [***] [***]

[***] [***] [***]

[***] [***] [***]

[***] [***] [***]

2. Channel Partner shall be charged a maximum rate of [***] per User ("Special Pricing") for all
Business Entities signed up by Channel Partner during the first three (3) full calendar months
following the Effective Date ("Introductory Period"). The "Special Pricing" is contingent on a
minimum order size of [***] users. Following twelve months after the month, during the Introductory
Period, a Business Entity was signed, each Business Entity will be charged according to Table 1
above. By way of example and for clarity: For a Business Entity order placed in the first month
following the Effective Date and with [***] Users, Channel Partner would be invoiced at [***] per
User per month from the first month following the Business Entity order and twelve (12) months
thereafter. After the first twelve months, and thereafter, Channel Partner will be charged for [***]
Users at the rate of [***] per User per month, pursuant to Table 1 above.

Page 14 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 15 -->
EXHIBIT D CUSTOMIZED SERVICES AND SUPPORT 1. SOFTWARE INSTALLATION SUPPORT . iPass personnel will
work remotely with Channel Partner to assist the Channel Partner in the installation of the Server
Software on Channel Partner's systems. iPass will provide the services indicated in Table 1 below in
order to assist Channel Partner with implementation of Service for use by Channel Partner and End
Users. Table 1-Start Up Services Service Access to iPass' expanding global network ¨ Automatic
Phonebook updates ¨ Automatic Open Mobile updates ¨ RoamServer software updates ¨ Monthly Statement
and Call Detail Records (CDRs) ¨ Help desk and deployment materials ¨ Monitoring for authentication
failures ¨ Customized Open Mobile Client Software 1 Authentication realms (domains) 1 Technical
Training Curriculum 1 Web-based session Sales and Marketing Training Curriculum 1 Web-based session
Participation in open web conference training sessions scheduled by iPass ¨ Seats per year in open
regional training scheduled by iPass 4 Access to self-paced training materials on iPass training
portal ¨ 2. TECHNICAL SUPPORT 2.1 Definitions. Any capitalized terms used herein and not defined
below are defined in the Agreement. (a) "First Level Technical Support" means taking End User calls,
getting complete information from End Users regarding problems experienced by such End Users,
testing the End User name and password, eliminating common End User errors, checking the network
status page and escalating unresolved issues with written documentation detailing steps taken prior
to escalation. (b) "Second Level Technical Support" means providing assistance to First Level
Technical Support help desk for issues that cannot be resolved through First Level Technical
Support. (c) "Third Level Technical Support" means providing technical assistance to Channel
Partner's authorized Second Level Technical Support personnel for technical issues that cannot be
resolved by Second Level Technical Support. 2.2 First Level Technical Support and Second Level
Technical Support. Channel Partner or Business Entity will be responsible for providing its End
Users First Level Technical Support. Channel Partner will be responsible for providing End Users
Second Level Technical Support. Second Level Technical Support personnel who have received training
regarding the Service and the Software from iPass pursuant to Section 2 of the Agreement will be
authorized to contact the applicable Third Level Technical Support centers at iPass to resolve any
problems that cannot be resolved by First Level Technical Support or Second Level Technical Support.
Channel Partner may change its authorized contacts for Third Level Technical Support at any time
upon written notice to iPass so long as any new authorized contacts have completed the requisite
iPass training. 2.3 Third Level Technical Support. iPass will provide Channel Partner with Third
Level Technical Support in accordance with iPass standard procedures. iPass will only be obligated
to provide Third Level Technical Support for the Software if Channel Partner has installed all
Updates released by iPass which fix errors in the Software in accordance with Section 2.4 below.
Channel Partner must have its password and id available in order to access and submit a request,
absent which iPass will have no obligation to provide Channel Partner with Third Level Technical
Support.

Page 15 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 16 -->
2.4 Software Updates. iPass will notify Channel Partner regarding the availability of Updates and
make any applicable Updates available to Channel Partner free of charge through the iPass portal
and/or automatic downloads. Unless an Update has been delivered to Channel Partner as a patch to
correct an urgent problem (in which case distribution to End Users will be immediate upon receipt),
Channel Partner will distribute to its End Users all Updates within thirty (30) days of such Update
being made available to Channel Partner. Failure to implement Updates may subject Channel Partner to
various fees, including end of life fees, in iPass' sole discretion. Further iPass may implement end
of life fees upon reasonable notice to Channel Partner. 2.5 Requested Changes. Should Channel
Partner desire that any changes be made to the Software or implemented in the Service, Channel
Partner may submit a written request to iPass detailing the nature of the requested change. iPass
agrees to analyze such proposed changes in good faith and respond in writing detailing the
feasibility, expense, and anticipated schedule for implementing such change; provided that nothing
hereunder obligates iPass to agree to make such change. Should the parties so agree in writing,
iPass will make such change to the Software or the Service in accordance with the terms mutually
agreed upon by the parties. 3. TRAINING. iPass will perform training services as agreed upon by the
parties and in accordance with the terms of this Agreement. 4. SERVICE LEVELS AND ESCALATIONS 4.1
Additional Definitions. "Availability" means End Users having access to, full functionality and
usage of the service. "Service Levels" means the minimum service levels to be achieved by iPass in
relation to iPass' performance of its obligations as set out herein. "Severity Level" means the
impact of or nature of a problem as set forth herein. "Response" means the iPass' acknowledgment of
its receipt of a Trouble Report from Channel Partner. 4.2 iPass Support Services. iPass will provide
Help Desk to Help Desk support to Channel Partner on components of the iPass Service e.g. the iPass
Open Mobile Portal, Hosted Authentication Infrastructure. 4.3 Support Process The following support
process shall be followed by the Channel Partner HELPDESK to report or escalate issues to the iPass
Support Teams: a. Issue Identified to Customer Help Desk (i) The End User contacts the Channel
Partner Help Desk. (ii) Channel Partner Helpdesk follows troubleshooting guide and reviews
information in the iPass online knowledge base (help.ipass.com) and determines if internal resources
can resolve the issue. (iii) If internal resources cannot resolve the issue, then Channel Partner
Help Desk contacts iPass Customer Care via web-based support request. b. Entering a web-based
Support Request (i) Access the Portal via url: https://openmobile.ipass.com (ii) Enter your username
and password and click login. (iii) Access is available on the Dashboard tab. (iv) Click on the
"Manage Tickets" link. (v) On the "Cases" tab select the "Create New Case" button or dropdown link
(vi) Enter the appropriate information as required. Channel Partner Helpdesk shall provide call-back
details (contact name and phone number) in all web-based support requests.

Page 16 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 17 -->
c. Ticket Requirements At a minimum all Severity One and Severity Two problem reports shall contain
the following in order to expedite investigation and verification of the problem: (i) Username and
Description of observed behavior. (ii) Debug Logs if available. (iii) Steps to reproduce. (iv)
Operating environment (Operating system, language, software version, profile number and hardware, as
applicable.) (v) Dates / times of transaction failures. (vi) Name of network attempted. iPass may
request additional information for verification of a reported problem as necessary. d. Customer Care
Hotline For Severity One issues, iPass recommends that opening a web-based support request be
followed by a phone call to iPass at one of the following Severity One Customer Care numbers: Inside
the United States: +1-877-464-7277 Outside the United States: +1 650-232-4300 Dialing within Europe:
+44 20 7010 8344 Phone numbers are available 24 hours a day, 7 seven days a week. Please note that
in order to safeguard customers against unauthorized service activity, iPass will require that
callers authenticate their credentials via the web based ticketing system prior to any action by
iPass. All change requests MUST be in writing. In order to ensure that tickets are handled in order
of receipt, by priority, calls of a nature which are not Severity One will be ticketed and placed in
queue to be handled in order of receipt, by severity. 4.4 Service Levels (a) Support Request
Response - For each Severity Level, iPass shall provide the following response Service Levels: For
Channel Partner Helpdesk Support Requests submitted in accordance with the process defined herein.
Problem Severity Response Service Level Severity One Targeted Response Time: Issues will receive a
response from iPass within fifteen (15) minutes (1 hour on weekends and local public holidays) after
submitting a Severity One support case followed by a phone call to iPass. Please note Severity One
issues reported via a support case only will be responded to within 1 hour. Severity Two Targeted
Response Time: Issues will receive a response from iPass within 8 hours of receipt of the request
(except weekends and local public holidays.) Severity Three Targeted Response Time: Issues will
receive a response from iPass within 12 hours of receipt of the request (except weekends and local
public holidays.) (b) Problem Verification. iPass and Channel Partner will make reasonable efforts
to verify any reported problem as soon as it is reported as well as any follow-up information that
may be required. (c) Update Intervals. iPass will make reasonable efforts to keep Channel Partner's
Second Level Technical Support personnel informed of the latest status on any problem submitted. In
the event Channel Partner's Second Level Technical Support personnel requires more frequent updates,
then these will be discussed and mutually agreed upon and will depend on the severity and complexity
of the problem.

Page 17 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 18 -->
(d) Severity Reclassification. To ensure that severe problems receive highest priority, iPass may
modify a ticket submitted as Severity One issue if it clearly does not meet the criteria for
Severity One. 4.5 iPass Support Escalation Process (a) When to Escalate an Issue (i) If iPass fails
to respond within the prescribed service level response time, the Channel Partner Help Desk is
encouraged to escalate the issue to the Escalation Contact in the respective time zone (see
escalation contacts below.) (ii) If the iPass Customer Care Representative and the Channel Partner
Help Desk cannot agree on an action plan to resolve an issue (Severity One, Two or Three), then the
iPass Customer Care Representative and the Channel Partner Help Desk are encouraged to escalate the
issue to the Director of Customer Care. (iii) Once a plan has been agreed, iPass will work to
resolve the issue. If the Channel Partner Help Desk is not satisfied with the progress that is being
made to resolve an issue, they are encouraged to contact the Director of Customer Care. (b) How to
Escalate an Issue (i) All escalations should be in writing (to the e-mail address listed below) or
by phone followed up with a summary from Channel Partner 's Help Desk. (ii) Written documentation
should outline the original issue and progress to date. It should also include impact to the
customer and reason for the escalation. (c) Response to Escalation (i) The Director of Customer Care
will respond upon receipt to any escalations. (ii) Escalations will take priority over any issue of
the same severity level. Customer Care Escalation Contact Location/Time Zone London, UK (GMT)
Regional Contact Richard Sabbarton email rsabbarton@ipass.com Office Phone +44 20 7010 8319
Location/Time Zone Redwood Shores, US (PST) Regional Contact Saritha Padubidri email
spadubid@ipass.com Office Phone + 1 650 232 4127 Location/Time Zone Bangalore, IN (IST) Regional
Contact Sujith Varijakshan email svarijakshan@ipass.com Office Phone +91 80 41380976 ESCALATION
Manager - Director of Support Escalation Manager Alan Ridgewell email aridgewell@ipass.com Office
Phone +44 20 7010 8304

Page 18 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 19 -->
EXHIBIT E MINIMUM END USER TERMS Channel Partner when used herein has the same meaning as in the
Agreement. Channel Partner should change the word "Channel Partner" herein to its name when drafting
End User agreements. "You" referred to herein refers to the End User(s). iPass as referenced herein
shall mean iPass Inc. Capitalized terms used herein shall have the same meaning ascribed to them in
the Agreement. 1. By its very nature, the Internet contains offensive and/or harmful material, in
some cases under descriptions that have been mislabeled or are otherwise deceptive. Neither Channel
Partner, iPass nor their suppliers shall be responsible for any damages suffered by any person as a
result of obtaining Internet access. Access to the Internet is provided solely on an "AS IS" basis.
Neither Channel Partner, iPass, nor its suppliers warrant, nor do they assume responsibility for,
any consequences suffered by any person as a result of Internet access including, without
limitation, those suffered as a result of accessing Internet information and content, such as, by
way of example only, the possibility of contracting computer viruses, accessing information with
offensive, inaccurate or inappropriate content. Channel Partner, iPass and its suppliers exercise no
control whatsoever over the content of the information passing through their systems. 2. You agree
to be bound by the usage policies of iPass including, by way of example, its Privacy Policy. You
acknowledge and agree that iPass may disclose your usage data to Channel Partner and other third
parties as detailed in iPass' Privacy Policy (see http:www.ipass.com). You accept that certain uses
of your data are necessary to enable provision of the Services to you and accordingly that if you
withdraw your consent for iPass to use your data as is detailed in its Privacy Policy the supply of
the Service to you may have to be terminated. You acknowledge and agree that all End Users must
exercise their own due diligence before relying on any information available on the Internet, and
must determine that they have all necessary rights to copy, publish or otherwise distribute any such
information available on the Internet under copyright and other applicable laws. 3. NOTWITHSTANDING
ANYTHING ELSE IN THIS AGREEMENT, TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, SERVICES ARE
PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS, AND CHANNEL PARTNER, IPASS AND THEIR SUPPLIERS
DISCLAIM AND MAKE NO REPRESENTATIONS OR WARRANTIES AND THERE ARE NO CONDITIONS OF ANY KIND, EITHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF NON-INTERFERENCE,
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR USE, OR ARISING FROM COURSE OF DEALING OR USAGE
OF TRADE. YOU ASSUME ALL RESPONSIBILITY AND RISK FOR USE OF SERVICES. ANY STATEMENTS MADE IN ANY
PACKAGING, MANUALS, WRITTEN OR ELECTRONIC DOCUMENTS, OR BY ANY CHANNEL PARTNER OR IPASS EMPLOYEES,
REPRESENTATIVES, OR AGENTS, ARE PROVIDED FOR INFORMATIONAL PURPOSES ONLY AND NOT AS REPRESENTATIONS
OR WARRANTIES OF ANY KIND. CHANNEL PARTNER, IPASS AND THEIR SUPPLIERS DO NOT WARRANT THAT SERVICES
WILL BE UNINTERRUPTED, ERROR FREE, OR FREE FROM SERVICE DEGRADATION, OR THAT ANY INFORMATION,
SOFTWARE, OR OTHER MATERIAL ACCESSIBLE ON THE SERVICES ARE FREE FROM VIRUSES, WORMS, TROJAN HORSES,
OR OTHER CODE THAT MANIFESTS CONTAMINATING, INTERFERING, OR DESTRUCTIVE PROPERTIES. CHANNEL PARTNER,
IPASS AND THEIR SUUPLIERS CANNOT AND DO NOT GUARANTEE THE SECURITY OR INTEGRITY OF DATA TRANSMISSION
OR STORAGE, OR THAT VIRUSES, WORMS, TROJAN HORSES, OR OTHER CODE THAT MANIFESTS CONTAMINATING OR
DESTRUCTIVE PROPERTIES WILL BE DETECTED OR REMEDIATED BY SERVICES. SERVICES ARE ONLY AVAILABLE
WITHIN THE COVERAGE AREA OF THE IPASS NETWORK, WHICH IS SUBJECT TO CHANGE. YOU ACKNOWLEDGE THAT
SERVICES MAY BE TEMPORARILY UNAVAILABLE FOR MAINTENANCE, EQUIPMENT MODIFICATIONS, OR UPGRADES, AND
FOR OTHER REASONS WITHIN AND WITHOUT THE DIRECT CONTROL OF IPASS. 4. TO THE MAXIMUM EXTENT PERMITTED
BY APPLICABLE LAW, IN NO EVENT SHALL CHANNEL PARTNER, IPASS OR ITS SUPPLIERS BE LIABLE FOR ANY
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES, OR FOR INTERRUPTED COMMUNICATIONS, LOST DATA OR LOST
PROFITS, ARISING OUT OF OR IN CONNECTION WITH THE SERVICE.

Page 19 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 20 -->
5. You may not use the Services to take any actions or make any statements that, by way of example
only: (a) infringe on any third party's copyright, patent, trademark, trade secret or other
proprietary rights or rights of publicity or privacy; (b) violate any applicable law, statute,
ordinance or regulation (including without limitation those regarding export control); (c) are
defamatory, trade libelous or unlawfully threatening; (d) are pornographic or obscene; (e) violate
any laws regarding unfair competition, antidiscrimination or false advertising, (f) result in the
distribution of viruses, Trojan horses, worms, time bombs, cancelbots, chain letters or other
similar harmful or deleterious programming routines, or (g) result in the unauthorized entry to any
other machine accessible via the network. You may not use the Services to distribute any bulk
unsolicited emails or otherwise cause an excessive or disproportionate load on Channel Partner's,
iPass' or their suppliers' infrastructure. Any access to other networks connected to Channel
Partner's, iPass' and its suppliers' networks must comply with the rules appropriate for such
networks. Violation of the foregoing may result in termination of access. Given the current
regulatory and technical environment you should not have an expectation of privacy in your online
activities 6. iPass and its suppliers shall be deemed to be third-party beneficiaries of this
agreement, with the right to enforce the terms of this agreement. You agree that this Agreement is
expressly for the benefit of Channel Partner, iPass and its suppliers and may be enforced by them.
7. You may not resell or redistribute any of the Services to any third parties. 8. Subject to the
terms and conditions of this agreement, Channel Partner grants to you a royalty-free, non-exclusive,
non-transferable, limited license right exercisable solely during the term of this agreement to: (1)
reproduce, exactly as provided by Channel Partner, object code copies of the Client Software, as
needed for distribution to your End Users the iPass Software; and to install and use the iPass
Licensed Software. You acknowledge that the Licensed Software contains the valuable information of
iPass and its suppliers, and agree not to cause or permit the modification, reverse engineering,
translation, disassembly, or decompilation of, or otherwise to attempt to derive the source code of
such Licensed Software, whether in whole or in part (except to the extent permitted by applicable
law). You will not obfuscate, alter or remove any copyright, trademark or other proprietary notice
or legend on or in the Licensed Software and associated Documentation and will include all such
markings in all copies of such materials. 9. The Services may be suspended or terminated if you
breach these terms. Any breach of these terms by your End Users shall be deemed a breach by you. 10.
This Agreement shall terminate upon termination of the agreement between Channel Partner and iPass.

Page 20 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 21 -->
EXHIBIT F IPASS MARKS

iPass® iPass Open Mobile™ iPass Open Mobile Exchange™ iPass OMX™ iPass ULTD

Page 21 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
<!-- page 22 -->
EXHIBIT G PARATEUM SERVICES Subject to the terms and conditions below, Channel Partner (Pareteum
Corporation) will provide on a non-exclusive basis the following services to iPass for resale to
iPass' customers: Managed Services Platform and Global Cloud Mobility Platform (collectively, the
"Pareteum Services"). Channel Partner (Pareteum Corporation) and iPass shall mutually agree upon the
terms and conditions (which will include, without limitation, the scope and geography where the
Pareteum Services may be resold, fees and support service and related user terms) upon the earlier
to occur of: (i) iPass' first proposed resale of the Pareteum Services to one of its customers; or
(ii) within ninety (90) days from the Effective Date. Once the parties have mutually agreed upon the
foregoing terms and conditions, the parties will amend this Exhibit G to reflect the terms by which
iPass may resell the Pareteum Services.

Page 22 of 22 iPass Channel Partner Reseller Agreement 04.18.2018 iPass Confidential

[***] = Certain confidential information contained in this document, marked by brackets, is filed
with the Securities and Exchange Commission pursuant to Rule 24b- 2 of the Securities Exchange Act
of 1934, as amended.

Source: IPASS INC, 8-K, 12/3/2018
