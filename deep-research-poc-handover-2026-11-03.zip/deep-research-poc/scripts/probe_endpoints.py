"""Phase 0: probe each role's endpoint for the capabilities the harness depends on.

    python scripts/probe_endpoints.py            # every distinct (endpoint, model) among the roles
    python scripts/probe_endpoints.py researcher writer
    python scripts/probe_endpoints.py --list     # catalog ids matching gpt-oss / nemotron / gemma

Checks per model: (a) OpenAI `tools` param accepted and a tool call is emitted; (b) parallel tool
calls (two independent asks -> two tool_calls in one message); (c) JSON-mode structured output;
(d) p50 latency for a 2K-in / 300-out call; (e) rough concurrency (8 parallel calls). Roles that
share an endpoint and model are probed once (14 requests per model). Writes a markdown table to
docs/endpoints.md. Record the results in CLAUDE.md's model table if they differ.
"""
from __future__ import annotations

import json
import statistics
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from dr.llm import ROLE_DEFAULTS, endpoint_for, get_llm  # noqa: E402


def _tool_schema():
    from langchain_core.tools import StructuredTool
    from pydantic import BaseModel, Field

    class GrepArgs(BaseModel):
        pattern: str = Field(description="regex to search for")

    def grep(pattern: str) -> str:
        return f"ok:{pattern}"

    return [StructuredTool.from_function(func=grep, name="grep", description="search documents", args_schema=GrepArgs)]


def _err(e: Exception) -> str:
    """Short error label; API errors carry the status and message, never the key."""
    return f"error: {type(e).__name__}: {str(e)[:90]}"


def _log(msg: str) -> None:
    print(f"[probe {time.strftime('%H:%M:%S')}] {msg}", file=sys.stderr, flush=True)


def probe(role: str) -> dict:
    cfg = endpoint_for(role)
    out: dict = {"role": role, "model": cfg.model, "base_url": cfg.base_url}
    llm = get_llm(role)  # type: ignore[arg-type]
    tools = _tool_schema()

    # (a) tool calling
    _log(f"{cfg.model}: (a) tool call")
    try:
        r = llm.bind_tools(tools).invoke("Search the documents for the phrase 'Leverage Ratio' using the grep tool.")
        out["tools"] = bool(getattr(r, "tool_calls", None))
    except Exception as e:  # noqa: BLE001
        out["tools"] = _err(e)

    # (b) parallel tool calls
    _log(f"{cfg.model}: (b) parallel tool calls  [a={out['tools']}]")
    try:
        r = llm.bind_tools(tools).invoke(
            "Run TWO independent greps now, in this single turn: one for 'Leverage Ratio' and one for 'Applicable Margin'."
        )
        out["parallel_tools"] = len(getattr(r, "tool_calls", []) or [])
    except Exception as e:  # noqa: BLE001
        out["parallel_tools"] = _err(e)

    # (c) JSON output
    _log(f"{cfg.model}: (c) json  [b={out['parallel_tools']}]")
    try:
        r = llm.invoke('Return ONLY a JSON object {"clues": ["a","b"]} with two short strings. No prose.')
        content = r.content if isinstance(r.content, str) else str(r.content)
        s, e_ = content.find("{"), content.rfind("}")
        json.loads(content[s : e_ + 1])
        out["json"] = True
    except Exception as e:  # noqa: BLE001
        out["json"] = _err(e)

    # (d) latency
    _log(f"{cfg.model}: (d) latency x3  [c={out['json']}]")
    prompt = "Summarize in 150 words: " + ("lorem ipsum dolor sit amet " * 300)
    lat = []
    for _ in range(3):
        t0 = time.perf_counter()
        try:
            llm.invoke(prompt)
            lat.append(time.perf_counter() - t0)
        except Exception:  # noqa: BLE001
            lat.append(float("nan"))
    out["p50_s_2k_in"] = round(statistics.median(lat), 2)

    # (e) concurrency
    _log(f"{cfg.model}: (e) 8 parallel calls  [p50={out['p50_s_2k_in']}s]")

    def one(_):
        t0 = time.perf_counter()
        try:
            llm.invoke("Reply with the single word OK.")
            return time.perf_counter() - t0
        except Exception:  # noqa: BLE001
            return float("nan")

    with ThreadPoolExecutor(8) as ex:
        ts = list(ex.map(one, range(8)))
    out["parallel8_max_s"] = round(max(ts), 2)
    out["parallel8_failures"] = sum(1 for t in ts if t != t)  # NaN count
    _log(f"{cfg.model}: done  [parallel8 max={out['parallel8_max_s']}s failures={out['parallel8_failures']}]")
    return out


def list_catalog(patterns: tuple[str, ...] = ("gpt-oss", "nemotron", "gemma")) -> None:
    """Print catalog ids at the researcher's endpoint that match our model families, and whether
    each role's configured model id is actually in the catalog."""
    from openai import OpenAI

    cfg = endpoint_for("researcher")
    client = OpenAI(base_url=cfg.base_url, api_key=cfg.api_key)
    ids = sorted(m.id for m in client.models.list())
    hits = [i for i in ids if any(p in i.lower() for p in patterns)]
    print(f"{len(ids)} models at {cfg.base_url}; {len(hits)} match {patterns}:")
    for i in hits:
        print("  " + i)
    print("\nconfigured role -> model:")
    for role in sorted(set(ROLE_DEFAULTS)):
        m = endpoint_for(role).model
        print(f"  {role:<10} -> {m:<45} {'OK' if m in ids else 'NOT IN CATALOG'}")


def main(argv: list[str]) -> None:
    if "--list" in argv:
        list_catalog()
        return
    roles = [a for a in argv if not a.startswith("--")] or sorted(set(ROLE_DEFAULTS))
    groups: dict[tuple[str, str], list[str]] = {}   # (endpoint, model) -> roles; probe each once
    for r in roles:
        cfg = endpoint_for(r)
        groups.setdefault((cfg.base_url, cfg.model), []).append(r)
    rows = []
    for rs in groups.values():
        row = probe(rs[0])
        row["role"] = "/".join(rs)
        rows.append(row)
    cols = ["role", "model", "tools", "parallel_tools", "json", "p50_s_2k_in", "parallel8_max_s", "parallel8_failures", "base_url"]
    out_path = Path("docs/endpoints.md")
    table: dict[str, str] = {}   # model -> row; rows from earlier runs are kept unless re-probed
    if out_path.exists():
        for line in out_path.read_text(encoding="utf-8").splitlines():
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if line.startswith("| ") and len(cells) == len(cols) and cells[0] != "role":
                table[cells[1]] = line
    for r in rows:
        table[r["model"]] = "| " + " | ".join(str(r.get(c, "")) for c in cols) + " |"
    md = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols), *table.values()]
    out_path.parent.mkdir(exist_ok=True)
    out_path.write_text(
        "# Endpoint capability probe\n\n"
        f"Last run: {time.strftime('%Y-%m-%d %H:%M')}. One row per model; rows persist across runs.\n\n"
        + "\n".join(md) + "\n",
        encoding="utf-8",
    )
    print("\n".join(md))


if __name__ == "__main__":
    main(sys.argv[1:])
