<!-- page 1 -->
# TRANSPORTATION CONTRACT
| Field | Value |
|---|---|
| Document Type | Transportation Agreement |
| Agreement Date | 2000-01-03 |
| Parties | JSC NOC KazakhOil ("Company"); JSC Karakudukmunay ("Principal"); collectively referred to as "Parties" |
| Source | CUAD v1 / CHAPARRALRESOURCESINC_03_30_2000-EX-10.66-TRANSPORTATION CONTRACT |

Exhibit 10.66

TRANSPORTATION CONTRACT

Astana January 31, 2000

PREAMBLE

JSC NOC KazakhOil, hereinafter referred to as the "Company", in the person of Executive Marketing
Director Ms. A. M. Rakhimbekov, acting on the basis of the Power of Attorney (1) 1-13 dated January
3, 2000, on the one side and JSC Karakudukmunay, hereinafter referred to as the "Principal" in the
person of General Director Mr. N. D. Klinchev and Financial Director Mr. R. Moore, acting on the
basis of the Charter, on the other side, collectively referred to as the "Parties", have entered
into this Transportation Contract (the "Contract") and hereby agree as follows:

1. SUBJECT OF THE CONTRACT

1.1 The Company, at the expense and on the instructions of the Principal, shall arrange
transportation for export in batches to the far abroad of crude oil ("Commodity") belonging to the
Principal and shall provide such other services in connection therewith as are provided in this
Contract.

1.2 The volume of a batch of Commodity transported hereunder shall be determined in accordance with
the monthly schedules of transit and distribution of Kazakhstany oil.

2. DEFINITIONS AND INTERPRETATION

2.1 As used in the Contract, the following terms have the meanings indicated:

"Buyer" means STASCO in its capacity as Buyer under the Offtake Agreement and any other person in
its capacity as buyer under any Other Agreement.

"Commodity" is defined in item 1.1.

"Company" is defined in the Preamble to this Contract.

"Contract" is defined in the Preamble to this Contract.

"CPC Blend" means the blend of crude oil generally available at the CPC Terminal that complies with
minimum specifications agreed by the Principal and STASCO pursuant to the Offtake Agreement.

"CPC Pipeline" means the pipeline being constructed by the Caspian Pipeline Consortium from the
Tengiz field to Novorossiysk.

"CPC Pipeline Operational Date" means the last day of the month in which (i) the CPC Pipeline is
completed, (ii) the Karakuduk Field is so connected with the CPC Pipeline (via pipeline, rail link,
or otherwise) that Karakuduk Crude Oil can and will be evacuated to the CPC Terminal via the CPC
Pipeline, (iii) the CPC Pipeline commences pumping commercial quantities of crude oil as determined
by the Principal and STASCO pursuant to the Offtake Agreement, and (iv) if the CPC Pipeline is only
transporting Commodity on a blend (as opposed to batch) basis, the Principal and STASCO have agreed
on the specifications for CPC Blend pursuant to the Offtake Agreement.

"CPC Terminal" means the single buoy-mooring terminal being built by the Caspian Pipeline Consortium
near Novorossiysk.

"DAF" has the meaning given to "delivered at frontier" in the Incoterms 1990.

"Delivery Basis" means (i) during the "Principal Period", delivery of Commodity on terms of DAF
Adamovo, DAF Fenyeshlitke, DAF Budkovce, FOB sea-port Odessa, FOB sea-port Novorossiysk, or FOB
sea-port Ventspils, as applicable, and (ii) during the "Secondary Period", delivery of Commodity on
terms of FOB CPC Terminal, in each case in accordance with the route indicated in the monthly
delivery schedules of the Company.

"Delivery Date" for a batch of Commodity means the date of execution of the last acceptance-delivery
act/bill of lading for that batch of Commodity in accordance with item 4.1.vii.

"Delivery Month" means the period for delivery under the Offtake Agreement or the Other Agreement,
as applicable.

"Effective Date" means the date of actual execution of this Contract by the Parties.

"FOB" has the meaning given to "free on board" in the Incoterms 1990.

"Initial Term" means the period commencing on the Effective Date and concluding on the last day of
the month in which the fifth anniversary of the Offtake Agreement Effective Date falls.
<!-- page 2 -->
"Karakuduk Crude Oil" means Commodity produced from the Karakuduk Field or from such other field as
the Principal and the Company may agree.

"Karakuduk Field" means the Karakuduk oil field in the Mangistau Oblast of the Republic of
Kazakhstan as more particularly described in the Petroleum Contract and the License.

"Offtake Agreement" means that certain Crude Oil Sale and Purchase Agreement between the Principal
and STASCO dated 1 November 1999.

"Offtake Agreement Effective Date" means the "effective date" of and as defined in the Offtake
Agreement.

"Other Agreement" means any agreement other than the Offtake Agreement pursuant to which the
Principal sells Karakuduk Crude Oil.

"Parties" is defined in the Preamble to this Contract.

"Petroleum Contract" means that certain Agreement for Exploration, Development and Production of Oil
in Karakuduk Oil Field in Mangistau Oblast of the Republic of Kazakhstan between the Ministry of Oil
and Gas Industries of the Republic of Kazakhstan for and on behalf of the Government of the Republic
of Kazakhstan and the Principal.

"License" means License No. MG#249 (Oil) dated 25 June 1995 (as subsequently amended) granted to the
Principal by the Government of the Republic of Kazakhstan.

"Principal" is defined in the Preamble to this Contract.

"Principal Period" means the period from the Effective Date to the CPC Pipeline Operational Date.

"REBCO" means Commodity that satisfies the specifications of TU-39-1623-93 "Russian oil delivered
for export; Specifications" for export to the far abroad.

2

"Secondary Period" means the period from the CPC Pipeline Operational Date to the date of
termination of this Contract (inclusive).

"STASCO" means Shell Trading International Limited acting through its agent Shell International
Trading and Shipping Company Limited.

"Tenge" means official currency of the Republic of Kazakhstan.

2.2 In this Contract, unless the context otherwise requires:

i. Headings are used for convenience only and do not affect the interpretation of this Contract;

ii. any expression, which means individual, includes any company, Partnership, trust, joint venture,
association, corporation, or other corporate organization and vice versa;

iii. references to Articles and Sections, unless otherwise expressly provided in this Contract, are
references to articles and sections of this Contract;

iv. except as otherwise expressly provided, any reference to a document includes an amendment or
supplement to, or replacement or renovation of, that document;

v. a reference to any Party to this Agreement and to any other document includes that Party's legal
successors and assigns;

vi. words, which mean the singular, also include the plural and vice versa;

vii. the word "including" means "including without limitation";

viii. a "business day" means a day (other than a Saturday or a Sunday) on which banks are open for
ordinary banking business in London;

ix. "tonne" is a metric ton; and

x. a "year" means a calendar year, a "quarter" means a calendar quarter, and a "month" means a
calendar month.

3. QUALITY

3.1 Unless otherwise agreed by the Parties, the Principal shall at all times deliver to the Company
Karakuduk Commodity pursuant to this Contract. The Company shall ensure that (i) during the
Principal Period, the quality of Commodity delivered at the relevant delivery point shall be REBCO,
and (ii) during the Secondary Period, the quality of Commodity delivered at the CPC Terminal shall
be Karakuduk Commodity for segregated batch deliveries or shall be CPC Blend for deliveries for
which segregated batch delivery is not available.

4. OBLIGATIONS OF THE PARTIES

4.1 At all times during the term of this Contract, the Company shall:
<!-- page 3 -->
(i) Assist in obtaining required&sbsp;official export permissions (certificate of origin of the
Commodity at place the load output, customs declaration on Commodity output) for release of the
batch of Commodity being delivered from the customs territory of the Republic of Kazakhstan;

3

(ii) accept Karakuduk Commodity from the Principal at Metering Point 719 (PSP Samara of the Western
branch office of KazTransOil) and arrange its transportation for export in accordance with the
Delivery Basis;

(iii) execute all customs formalities to carry out transit transportation of the batch of Commodity
through the territory of Russian Federation and the countries of the C.I.S.;

(iv) procure sending of a route telegram to AK Transneft;

(v) procure delivery of the indicated Commodity to the Buyer on the Delivery Basis, less operating
losses in transportation of the Commodity, that are charged to the Principal's account;

(vi) procure berthing for the Buyer's tanker and delivery of the batch of Commodity to such tanker
through the Company's agents in the relevant port;

(vii) timely present to the Principal the Acts of acceptance-delivery of the Commodity (oil)/Bills
of Lading executed at the Delivery Basis. (During the Principal Period, Acts of acceptance-delivery
executed on the DAF basis (Adamovo, Fenyeshlitke or Budkovce) shall be presented in one copy, Bills
of Lading and sets of shipping documents attached to them executed on the FOB basis (Odessa,
Novorossiysk or Ventspils) shall be presented in the number of copies specified in the Buyer's
instructions, and during the Secondary Period, such documents as may be required at that time
executed on the FOB CPC Terminal basis shall be presented according to the list and in the number of
copies as it would be agreed between Principal, Company and CPC;

(viii) provide the Principal with information on the status of execution of this Contract;

(ix) on the Principal's request, prepare analyses of the Buyer's calculations of prices;

(x) cooperate with the Principal, to render, if possible, such assistance that can prove necessary
for the Principal to perform its obligations under the Offtake Agreement or any other contract with
the Buyer regarding Commodity; and

(xi) during the term of this Contract, observe all provisions of this Contract and other terms and
conditions agreed upon with the Principal.

4.2 At all times during the term of this Contract, the Principal shall:

(i) Deliver Karakuduk Commodity to the Company at Metering Point 719 (PSP Samara of the Western
branch office of KazTransOil) in the amount determined in accordance with item 1.2 of this
Agreement;

(ii) independently conclude contracts with the Buyer on selling Crude Oil for export and submit a
copy of each such contract with the Buyer to the Company 5 days before the beginning of the relevant
Delivery Month;

(iii) obtain, at its own expense, required official export permissions (certificate of origin of the
Commodity at place of the load output, customs declaration on Commodity output) for release of the
batch of Commodity being delivered from the customs territory of the Republic of Kazakstan and
deliver them before the 5th day of the Delivery Month;

(iv) if the Delivery Basis is DAF, provide the Company before the 5th day of the Delivery Month with
a copy of confirmation from AK Transneft on its readiness to accept the agreed batch of Commodity
from coordinators at the relevant directions;

4

(v) if the Delivery Basis is FOB, to provide the Company and the Company's agent in the relevant
port 5 days before the agreed upon loading&bbsp;period (Laycan) with the Buyer's instructions on
filling in the shipping documents, including name of the vessel, its characteristics, loading period
(Laycan), lay time and other necessary data;

(vi) make a 100% pre-payment for transportation of the batch of Commodity through the territory of
Russian Federation and the CIS countries, in accordance with the Payment Order of AK Transneft;

(vii) pay the additional expenses if the transport tariffs are increased, providing the Company
presents the appropriate documents;

(viii) reimburse the Company for the cost of execution of the customs declaration at the Energy
customs office of the RF in accordance with the Company's invoice;
<!-- page 4 -->
(ix) reimburse the Company for all expenses reasonably incurred in connection with the performance
by the Company of its obligations under this Contract within 30 (thirty) days of delivery to the
Principal of proper invoices and other supporting documents for such expenses;

(x) pay the Company's fee for the services rendered under Article 5 hereof, in accordance with the
invoice and tax invoice;

(xi) provide copies of all payment documents;

(xii) pay all transportation and other expense of KazTransOil on the territory of Kazakhstan under
its contract with KazTransOil;

(xiii) to make all necessary payments to the budget of the Republic of Kazakhstan related to excise
taxes, VAT and other obligatory payments to the budget in accordance with the tax legislation

(xiv) during the term of this Contract, observe all provisions of this Contract and other terms and
conditions agreed upon with the Company.

5. COMPANY'S FEE AND PAYMENT TERMS

5.1 The Principal shall pay the Company a fee of $1.00 (one dollar), inclusive of VAT, per one net
tonne of Commodity shipped pursuant to this Contract.

5.2 The Principal shall pay the commission fee for each delivered batch of Commodity to the
Company's account within 30 (thirty) banking days after the Delivery Date.

5.3 The payment shall be made in accordance with the invoice presented by the Company and the tax
invoice (original or a fax copy) in Tenge at the official exchange rate of the National Bank of the
Republic of Kazakhstan effective on the Delivery Date in accordance with item 4.1.vii.

6. PERIOD AND TERMS OF LOADING

6.1 Commodity will be shipped by the Company in batches during the period from the Effective Date
through the term of this Contract subject to (i) the Principal having the requisite supplies of
Commodity and (ii) the Principal having entered into the Offtake Agreement or another Agreement with
the Buyer.

5

6.2 The Company shall have a right to deliver Commodity to the Buyer with a permissible +/-5%
deviation from the number of batches of Commodity.

7. OWNERSHIP RIGHT AND RISK OF ACCIDENTAL LOSS

7.1 Ownership right and risk of loss with respect to all Commodity transported under this Contract,
shall remain with the Principal at all times prior to transfer of the ownership right and risk of
loss with respect to such Commodity to the Buyer in accordance with the Delivery Basis. At no time
shall the Company have the ownership right to any Commodity transported under this Contract.

7.2 At any time in accordance with reasonable requirements of the Principal, the Company shall
confirm the Principal's ownership rights to Commodity, transported under this Contract.

7.3 At any time the Principal may insure this Contract at his own expense, and the Company shall
render feasible assistance to the Principal in this case.

8. LIABILITY; INDEMNITY

8.1 The Parties shall be liable for non-execution and/or improper execution of their obligations
under this Agreement in accordance with the legislation of the Republic of Kazakstan.

8.2 In case if the Principal violates the conditions of this Contract, and such violation entails
infringement of the Off-take Agreement conditions by the Principal, then the Principal shall be
solely liable in front of the Purchaser for such violations. In addition, the Company shall not be
liable in front of the Principal or the Purchaser hereunder.

8.3 In case if violation by the Principal of the Off-take Agreement conditions takes place due to
infringement by the Company of its liabilities in front of the Principal under this Contract, the
Company shall be soley liable in front of the Principal for such losses resulting from such
violation , evidenced and supported by confirming documents ..

9. TERM OF THE CONTRACT

9.1 In accordance with items 9.3, 9.4, and 10.3, this Contract shall come into force on the
Effective Date, remain effective throughout the Initial Term, and be prolonged, or further extended
automatically for a period of 12
<!-- page 5 -->
months, each such extension commencing at the end of the last day of the Initial Term or the
relevant anniversary thereof, unless either Party serves written notice of termination on the other
Party at least 65 days prior to the end of the Initial Term, or any subsequent extension.

9.2 Any notice of termination served by any Party with violation of the period of notice required by
item 9.1 shall be invalid and of no effect whatsoever.

9.3 If the Company fails to perform within 30 days upon notice from the Principal on nonperformance
by the Company of any of its obligations under this Contract, and keeps non-performing it, then the
Principal may upon expiry of the indicated 30 day period, terminate this Contract, with obligatory
accounts settling.

6

9.4 If the Principal fails to perform within 30 days upon notice from the Company on nonperformance
by the Principal of any of its obligations under this Contract, and keeps non-performing it, then
the Company is entitled, upon expiry of such 30 day period, to terminate this Contract, with
obligatory accounts settling.

10. FORCE-MAJEURE

10.1 Except for the obligations to make any payment, required by this Contract (which shall not be
subject to relief under this item), a Party shall not be in breach of this Contract and liable to
the other Party for any failure to fulfil any obligation under this Contract to the extent any
fulfillment has been interfered with, hindered, delayed, or prevented by any circumstance
whatsoever, which is not reasonably within the control of and is unforeseeable by such Party and if
such Party exercised due diligence, including acts of God, fire, flood, freezing, landslides,
lightning, earthquakes, fire, storm, floods, washouts, and other natural disasters, wars (declared
or undeclared), insurrections, riots, civil disturbances, epidemics, quarantine restrictions,
blockade, embargo, strike, lockouts, labor disputes, or restrictions imposed by any government.

10.2 The Party affected by the indicated circumstances shall be excused from performance or accurate
performance, as the case may be, of such obligation for so long as such circumstance continues to
exist. The Party affected shall promptly, at any rate, within twenty-four (24) hours from the
receipt of information about the occurrence of such event must notify the other Party on the
occurrence of such circumstances and on the obligations affected.

10.3 If performance of the obligations by any Party under this Contract have been delayed for a
period of 3 months, the other Party shall be entitled to terminate this Contract thereafter by
giving notice to that effect to the Party claiming relief under Section 10, with obligatory accounts
settling.

10.4 No circumstance described in item 10.1 shall result in prolongation of the validity term of
this Contract.

11. SETTLEMENT OF DISPUTES AND APPLICABLE LAW

11.1 In the event of any disputes arousal under this Contract, the Parties shall exercise all
reasonable efforts to resolve them by negotiations.

11.2 In the event that resolution of the disputes by negotiations is impossible, they shall be
subject to court consideration at the defendant's location.

11.3 Effective legislation of the Republic of Kazakhstan shall apply to any relations of the Parties
arising out of this Contract.

12. MISCELLANEOUS TERMS AND CONDITIONS

12.1 Neither Party shall be entitled to assign any of its rights or duties hereunder to any third
parties without a written consent of the other Party thereto.

7

12.2 Any amendments or alterations to this Contract shall be considered valid only if executed in
writing and signed by the authorized representatives of the Company and the Principal. Usage of
facsimile communication for signing the above mentioned amendments and alterations shall be
acceptable.

12.3 From and after the Effective Date, all prior negotiations and correspondence pertinent to the
Contract shall have no legal force.

12.4 In all other matters not stipulated in this Contract, relations of the Parties shall be
governed by the legislation of the Republic of Kazakhstan in force.

12.5 The Parties shall guarantee observance of confidentiality in respect to any information and
documentation received hereunder; provided, that nothing in
<!-- page 6 -->
this item shall restrict either Party from disclosing details of or relating to this Contract
information (i) to any shareholder of such Party, (ii) to any creditor to such Party, (iii) to any
person considering to become a shareholder of or creditor to such Party, (iv) to the extent
necessary to comply with any laws or regulations applicable to such Party.

12.6 Any attachments to this Contract shall be an integral part hereof.

12.7 This Contract has been executed in 2 (two) original copies in both the Russian language and the
English language, one copy in each language for each of the Parties, in addition, the Russian text
of the Contract has priority.

13. REPRESENTATIONS

13.1 Each Party represents to the other Party that:

i. It is duly organized and validly existing under the laws of the jurisdiction of its incorporation
or registration and, if provided under such laws, in good standing;

ii. it has the power to sign and deliver this Contract and has undertaken all necessary measures to
authorize such signing, delivery and execution;

iii. such signing and delivery do not violate or conflict with any law applicable to it, any
provisions of its constitutional documents, any orders or judgements of any court or another agency
of government applicable to it or any of its assets or any contractual restrictions binding on or
affecting it or any of its assets;

iv. all governmental and other permits which are required to have been obtained by it with respect
to this Contract, have been obtained and have full legal force; and all conditions of any such
permits have been complied with; and

v obligations of such Party under this Contract constitute its legal, valid and binding obligations,
enforceable in accordance with its respective terms (subject to applicable bankruptcy,
re-organization, insolvency, moratorium or similar laws affecting creditors' rights generally and
subject, as to the enforceability, to equitable principles of general application (regardless of
whether enforcement on execution of this Contract is sought in a proceeding in equity or under
law)).

8

14. MISCELLANEOUS

14.1 This Contract constitutes the entire agreement of the Parties with respect to the subject
matter of this Contract and the Parties acknowledge that they do not enter into this Contract
regardless of any previous contacts between the Parties or their affiliates.

14.2 Any amendments or alterations to any of the terms of this Contract shall be effective unless
they are registered in writing and signed by or on behalf of each of the Parties; no waiver of any
provision hereof shall be effective unless it is in writing and signed by the Party, against which
such waiver is sought to be enforced.

14.3 Except as expressly provided herein, the rights, authorities and remedies, provided in this
Contract, are cumulative and not exclusive of any rights, authorities and remedies provided by the
law.

14.4 Except as expressly provided herein no delay or omission on the part of either Party in
exercising any rights, authorities or remedies, provided by law or under this Contract, nor any
indulgence granted by any Party to another Party, shall impair such rights, authorities or remedies,
or be construed as a waiver thereof; moreover, no single or partial exercise of any right, power or
remedy provided by law or under this Contract shall hinder other or further exercise thereof, as
well as exercise of any other right, power or remedy.

14.5 This Contract does not confer rights or remedies upon any person other than the Principal and
the Company.

15. LEGAL ADDRESSES AND PROPS OF THE PARTIES

COMPANY: PRINCIPAL

JSC NOC KazakhOil JSC Karakudukmunay 473000, Republic of Kazakhstan, Astana, 466200, Aktau,
Mangistau oblast 60, Republic avenue District 3, Building 82 Tel.: (3172) 280609, fax 327724 Tel.:
(3292) 513795, fax 518336 TRN 600700150675 TRN 430600001175

Bank props: Bank props: Tenge account (1) 000467052 AB Neftebank, Aktau in Akmola affiliate of Tenge
account (1) 609614 JSC "Almaty trade and finance bank", Astana IAT 195301730 IAT 192901705

/s/ Amangeldy Tlegenov &bbsp; /s/ Nikolai D. Klinchev
<!-- page 7 -->
- -------------------------------------------- ------------------------------- A.M. Rakhimbekov
Nikolai Klinchev

/s/ Richard J. Moore ------------------------------- Richard Moore

9
