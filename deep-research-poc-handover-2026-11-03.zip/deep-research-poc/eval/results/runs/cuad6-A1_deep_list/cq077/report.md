# Among the following 8 agreements, which contain a non-compete clause? For each, quote t...

*Question:* Among the following 8 agreements, which contain a non-compete clause? For each, quote the clause. Agreements: the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley (dated 2017-11-14); the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. (dated 2011-03-14); the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc (filed 2018-11-09); the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC (dated 2013-05-15); the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies (filed 2005-11-02); the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01); the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. (dated 2010-01-01); the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. (filed 2013-09-26).

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Identify agreements containing non-compete clauses

The Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley dated 2017-11-14 contains a non-compete clause in Section 8 Exclusivity stating "Talent represents and warrants that during the Term and in the Territories, Talent will not endorse or make any appearances or advertisements on behalf of any other product which is directly competitive to ESSI's products". [4cb98e07400203bf p.3] The Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. dated 2011-03-14 contains a non-compete clause in Section 11.3 stating "During the Term, except as otherwise provided in this Agreement, Network Affiliate and its affiliates agree not to engage or participate in any business, hold equity interests, directly or indirectly, in another entity, whether currently existing or hereafter created, or participate in any other joint venture that competes or would compete with any business that NCM is authorized to conduct in the Territory pursuant to this Agreement, whether or not NCM is actually conducting such business in a particular portion of the Territory". [23e65a3b8bc5cc9e p.25]

[GAP] Evidence for the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc filed 2018-11-09.

[GAP] Evidence for the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC dated 2013-05-15.

[GAP] Evidence for the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies filed 2005-11-02.

[GAP] Evidence for the Cooperation Agreement between e.l.f.

Beauty, Inc. and Marathon Partners Equity Management, LLC dated 2020-07-01. [uncited]

[GAP] Evidence for the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. dated 2010-01-01.

[GAP] Evidence for the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. filed 2013-09-26.

## Not established by the evidence

[GAP] No evidence was found for: Extract and quote the exact non-compete clause text from each agreement identified as containing one.

## Verification appendix

Claims: 10 · supported: 2 · partially: 0 · dropped: 0 · gaps: 8 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Quote non-compete clauses

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[4cb98e07400203bf p.3] |  |
| s1.2 | s1 | keep | 1.00 | e2→[23e65a3b8bc5cc9e p.25] |  |
| s1.3 | s1 | gap |  |  |  |
| s1.4 | s1 | gap |  |  |  |
| s1.5 | s1 | gap |  |  |  |
| s1.6 | s1 | gap |  |  |  |
| s1.7 | s1 | gap |  |  | no evidence cited |
| s1.8 | s1 | gap |  |  |  |
| s1.9 | s1 | gap |  |  |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [4cb98e07400203bf p.3 L105-107] keep (1.0): "8. Exclusivity. Talent represents and warrants that during the Term and in the Territories, Talent will not endorse or make any appearances or advertisements on behalf of any other product which is directly competitive to ESSI's products."
- e2 [23e65a3b8bc5cc9e p.25 L947-963] keep (1.0): "Section 11.3 Non-Competition and Non-Solicitation. (a) During the Term, except as otherwise provided in this Agreement, Network Affiliate and its affiliates agree not to engage or participate in any business, hold equity interests, directly…"
