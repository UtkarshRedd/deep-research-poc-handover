<!-- page 1 -->
# TALENT ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2013-01-01 |
| Parties | Tigrent Learning UK Limited ("Company"); Celebrity Speakers ("CSA"); Robbie Fowler ("Talent") |
| Source | CUAD v1 / LegacyEducationAllianceInc_20141110_8-K_EX-10.9_8828866_EX-10.9_Endorsement Agreement |

Exhibit 10.8 TALENT ENDORSEMENT AGREEMENT THIS SUPPLEMENTAL AGREEMENT is made as of this _____ day
of ______________ 2013 by and between Tigrent Learning UK Limited of Boston House, 69 — 75 Boston
Manor Road, Brentford, Middlesex, TW8 9.1J ("Company") and Celebrity Speakers of 90 High Street,
Burnham, Buckinghamshire, SL1 7JT ("CSA") agent for Robbie Fowler ("Talent") in his individual
capacity or his duly appointed Representative (collectively the "Parties"). WITNESSETH: WHEREAS, 1.
Talent is currently a well-known public figure; 2. Company has entered into an agreement dated 2nd
November 2012 with CSA ("Primary Agreement") to engage the services of the Talent to endorse the
Company's new property training course "Property Academy" ("Property Training Course") to be
launched in 2013 as specified in clause 5 of the schedule to the Primary Agreement. 3. Company is
engaged in developing, creating and providing educational training, products and materials related
to real estate, securities and options trading and investment, as well as general wealth building
and investing strategies, principles and motivation. 4. It is hereby acknowledged by the Parties
that the Company is desirous of acquiring the right and license to utilize Talent's name and brand,
likeness and image to endorse by way of advertisement, promotion, and sale of a new property
training brand ("Property Academy") to be launched by the Company and as defined in this Agreement
and Talent is willing to grant such right and license as herein below provided. NOW, THEREFORE, in
consideration of the mutual covenants set forth herein and for other good and valuable
consideration, it is agreed as follows: 1. DEFINITIONS The following meanings shall apply to this
agreement: 1. "Commencement Date" means: 1st January 2013. 2. "Materials" means: Power Point
Presentations, Marketing Collaterals, Banners, Workbooks, Flyers or any other physical item required
for the promotion and delivery of the Company's new Property Training Course "Property Academy". 3.
"Product" means: The products and materials the Company develops, creates or provides in connection
with its educational training, products and materials relating to the Property Training Course. 4.
"Property" means: Talents name, initials, facsimile signature, photograph, video or images, likeness
or other such pre-approved copy.

Source: LEGACY EDUCATION ALLIANCE, INC., 8-K, 11/10/2014
<!-- page 2 -->
5. "Property Training Course" means: the property training course developed or to be developed by
the Company to be called and marketed under the name/brand "Property Academy" or any other such name
as agreed by the Parties. 6. "Territory" means: United Kingdom. 7. "Term" means: 1.5t January 2013
to 315t December 2013 or until terminated under the provisions of this Agreement or the Primary
Agreement. 2. GRANT OF RIGHTS Subject to the terms and conditions and in consideration of the
payments set forth herein and in the Primary Agreement, CSA as disclosed agent for Talent grants to
Company from the Commencement Date the right and license during the Term of this Agreement in the
Territory to use the "Property" in connection with the advertisement, promotion, and sale of the
Property Training Course and the Product as well as the right to use such Property on the Product
and related packaging. The above license grant shall apply to all material objects of the Property,
in which the Property is fixed by any method now known or later developed, and from which the
Property can be perceived, reproduced, or otherwise communicated, either directly or with the aid of
a machine or device. The parties further understand and agree that Company hereby reserves the right
to display its copyright notice on advertisements, promotions or other materials as well as all
Product, no matter what form or media, containing the Property subject always to all and any
copyright or other interests of the Talent. CSA on behalf of Talent further grants and assigns to
Company the right to enforce applicable copyright and intellectual property laws against third party
infringers or malfeasors on Talent's behalf or in Talent's name. 2A. ADDITIONAL DUTIES AND PUBLIC
APPEARANCES In accordance with the Primary Agreement, the Talent agrees that during the Term, he
will make public appearances at the request of the Company, to include appearing at Company events
and/or participating in photo shoots as requested by Company, not to exceed more than four such
appearances or photo shoots per calendar year. Any public appearance and/or photo shoot must be
approved by the Talent prior to his agreement to attend, which shall not be unreasonably withheld
providing the Talent does not have any prior professional or other commitments and reasonable and
adequate notice is given and received by CSA on behalf of Talent. The parties agree that Company
will pay any necessary and reasonable travel and lodging expenses incurred by Talent in making such
requested appearances as per "part 1" of the Primary Agreement. 3. TERM This Agreement shall be
effective as of the date of execution by both parties. The period of license granted shall be for
the Term and shall extend for a period of twenty four (24) months or until terminated as per clause
8 herein. It is agreed that the Term may be extended upon mutual agreement between the parties.

2

Source: LEGACY EDUCATION ALLIANCE, INC., 8-K, 11/10/2014
<!-- page 3 -->
4. COMPENSATION In consideration for the licenses granted hereunder, Company agrees to pay to CSA as
follows: a. A [***]in the amount of [***]of Company's revenues from sales of the Property Training
Course and all Products after deductions for VAT, returns, refunds b. Company shall be responsible
for the tracking of sales of the Property Training Course and all Products containing the Property
and providing to CSA: i. A monthly list of the sales of Property Training Course and Product (with
supporting sales prices and reconciled reports). ii. Payment to CSA no later than thirty (30) days
after receipt of invoice from CSA. CSA shall submit invoice to the Company no later than thirty (30)
days after Company provides CSA with the list of the sales of Product (containing the Property with
such supporting information that may be required or requested to be disclosed). c. CSA shall have
the right to request an independent audit of the sales of the Product containing the Property which
the Company agrees to assist within a reasonable period of time of such request. 5. REVIEW OF
MATERIALS a. Talent shall have the right of approval in respect of all Product being proposed as any
part of the Property appearing or integrated into it and all proposed use of the Property (including
to whom the Property is distributed for sale if other than the general public) prior to public
release and distribution. b. All Materials or any part thereof shall be sent by the Company to CSA
for approval by Talent. c. Talent shall have seven (7) days following receipt of such Materials or
any part thereof displaying the intended use of the Property to review and for CSA to provide to
Company written approval for such use. d. In the event that Talent objects to the Products or any
part thereof and/or any proposed use of the Property, CSA on behalf of Talent shall submit to
Company, within seven (7) days following Company's official submission of materials, a written
request for revisions. Talent shall not make any request for unreasonable revisions and shall not
withhold consent for any proposed use of the Property unreasonably. e. In the event that Talent does
not provide either written approval of materials or a written request for revisions of such
materials containing a proposed use of the Property within ten (10) days following Company's
submission of such materials to Talent for review, such non-response shall automatically be deemed
to be an acceptance and approval of the proposed use of the Property.

3

Source: LEGACY EDUCATION ALLIANCE, INC., 8-K, 11/10/2014
<!-- page 4 -->
6. RESERVATION OF RIGHTS a. Subject to the terms of this Agreement, Talent shall retain all rights
in and to his name and in the Property, his right of publicity, and the endorsement and, whether
during the Term or any extension thereof, Talent shall not be prevented from using, permitting, or
licensing by whatever means ,others to use his name or endorsement in connection with the
advertisement, promotion, and sale of any product or service other than the Product or those that
are substantially similar to the Product, including but not limited to all real estate, securities
and/or options trading and investment educational trainings, products, materials. Company and Talent
agree that they shall take all necessary steps during the Term to protect the endorsement in
connection with the advertisement, promotion, and sale of the Product, subject always to the Company
bearing any costs or liabilities in taking such steps and fully indemnifying the Talent and his
agent in respect thereof. b. It is understood and agreed that Talent shall retain all copyright and
all other rights, title, and interest in the Property, including his likeness, name, and/or
trademarks, where applicable, except as licensed hereunder. c. Subject to the terms of this
Agreement and in particular 5 above, it is understood and agreed that Company shall retain all
right, title, and interest, including but not limited to all copyright interest, in and to the
Product and any advertising or marketing collateral and/or materials created utilizing the Property
under the license granted herein. The Company agrees to defend and fully indemnify the Talent and/or
his agents in respect of such rights retained by the Company. d. The parties agree to execute any
documents reasonably requested by the other party to affect any of the above provisions. The Company
agrees to defend and fully indemnify the Talent and/or his agents of any costs that may be incurred
in complying with this provision. 7. REPRESENTATIONS, WARRANTIES AND INDEMNITY a. Talent represents
and warrants that he has not granted nor will he grant to any other party any right, permission, or
license to use the Property in connection with the advertisement, sale, or promotion of the Product
or in connection with products that are identical or substantially similar to the Product. b. Talent
further represents and warrants to Company that he has the full right, power, and authority to grant
the Property herein. c. Talent further represents and warrants that he has not misrepresented or
concealed anything with respect to his background that may have a prejudicial effect on the value of
the endorsement, that he is in good health, and that he has not engaged nor will he engage during
the Term of this Agreement in any activity (criminal or otherwise) that could potentially have a
negative impact on the Product.

4

Source: LEGACY EDUCATION ALLIANCE, INC., 8-K, 11/10/2014
<!-- page 5 -->
d. Company agrees to defend, indemnify, and hold Talent harmless against all costs, expenses, and
losses (including reasonable attorney fees and costs) incurred through claims of third parties
against Talent based on the manufacture or sale of the Product including, but not limited to,
actions founded on product liability. e. Talent agrees to defend, indemnify, and hold Company, and
its officers, directors, agents, and employees, harmless against all costs, expenses, and losses
(including reasonable legal fees and costs) incurred through claims of third parties against Company
based on a breach by Talent of any representation and/or warranty made in this Agreement or with
respect to any third-party claims for infringement involving the use of the Property by Company. 8.
TERMINATION a. Except as provided in this Section 8, this Agreement shall terminate immediately upon
the earlier of (i) the Term of this Agreement or (ii) dissolving of Company and/or Company's
complete cessation of doing all business. b. Either party shall have the right to terminate this
Agreement immediately in the event that Talent or the Company does any of the following: i. Engages
in illegal, immoral, or criminal conduct resulting in a felony conviction; ii. Misrepresents or
conceals anything in their background that could be detrimental to the value of the endorsement
being made; iii. Engages in conduct contrary to the best interests of the other party; iv. Engages
in conduct that reasonably offends the sensitivities of a significant portion of the population; or
v. Engages in conduct that could bring the other party into public disrepute. c. Either party may
terminate this provision at any time during the Term, in the event either party is guilty of a
material breach of this Agreement, having been given notice of such breach and the breach not being
rectified within a reasonable period of time. 9. POST-TERMINATION RIGHTS a. Talent agrees that
Company shall, for a period of nine (9) months (Sell-Off Period) following the effective date of
termination, have the right to continue to sell Product bearing the Property and/or utilize
advertising materials and collateral bearing the Property. Such sales and use shall be made subject
to all the provisions of this Agreement and in particular clause 4 hereof. b. Upon the expiration or
termination of this Agreement, all rights granted to Company under this Agreement shall forthwith
terminate and immediately revert to Talent, and Company shall, following the completion of the
Sell-Off Period discontinue all use of and reference to the Property.

5

Source: LEGACY EDUCATION ALLIANCE, INC., 8-K, 11/10/2014
<!-- page 6 -->
10. RELATIONSHIP OF THE PARTIES Nothing contained in this Agreement shall be construed as
establishing a partnership, or a joint venture relationship between Talent and Company. 11. FORCE
MAJEURE Neither party will be liable for, or will be considered to be in breach of or default under
this Agreement on account of, any delay or failure to perform as required by this Agreement as a
result of any causes or conditions that are beyond such Party's reasonable control and that such
Party is unable to overcome through the exercise of commercially reasonable diligence. If any force
majeure event occurs, the affected Party will give prompt written notice to the other Party and will
use commercially reasonable efforts to minimize the impact of the event. 12. NOTICES Notice: Each
notice, request or demand given or required to be given pursuant to this Agreement shall be in
writing and shall deemed sufficiently given if both emailed and deposited in the United Kingdom
mail, registered First Class, postage pre-paid, and addressed to the address of the intended
recipient set forth below, or to such other address as may be specified in this Agreement or in
writing by the parties and receipt shall be deemed if sent by (i) email on the same day if sent on a
day open for business and (ii) post on the second day from posting, open for business. If to Company
Name: lain Edwards Address: Tigrent Learning UK Ltd Boston House 69 — 75 Boston Manor Road Brentford
Middlesex TW8 9.1.1 England Telephone: 02089 966700 Facsimile: 02089 966701 Email:
iainedwards@tiRrent.com If to CSA Name: Sharon Bowler Address: Celebrity Speakers Ltd 90 High Street
Burnham Buckinghamshire SL1 7JT England Telephone: 01628 601400 Facsimile: 01628 601401 Email:
Sharon@speakers.co.uk If to Talent Name: Robbie Fowler Address: c/o Celebrity Speakers Ltd — As
above

6

Source: LEGACY EDUCATION ALLIANCE, INC., 8-K, 11/10/2014
<!-- page 7 -->
13. JURISDICTION/DISPUTES This Agreement shall be deemed to have been made in England. This
Agreement shall be governed by the laws of England and Wales, and all actions brought hereunder
whether at law or in equity shall be brought in England. The parties hereby agree that any and all
claims arising from or in connection with the subject matter of this Agreement must be brought in
England before the County Court or High Court. 14. AGREEMENT BINDING ON SUCCESSORS The provisions of
the Agreement shall be binding upon and shall inure to the benefit of the Parties hereto, their
heirs, administrators, successors and assigns. 15. ASSIGNABILITY The Parties may not assign this
Agreement or the rights and obligations hereunder to any third party without the prior express
written approval of the other Party. 16. WAIVER No delay, failure or waiver by either party to
exercise any right or remedy under this Agreement, and no partial or single exercise, will operate
to limit, preclude, cancel, waive or otherwise affect such right or remedy, nor will any single or
partial exercise limit, preclude, impair or waive any further exercise of such right or remedy or
the exercise of any other right or remedy. 17. SEVERABILITY If any term, clause or provision hereof
is held invalid or unenforceable by a court of competent jurisdiction, such invalidity shall not
affect the validity or operation of any other term, clause or provision and such invalid term,
clause or provision shall be deemed to be severed from the Agreement. 18. SURVIVAL The parties'
rights and obligations under the Primary Agreement and Articles 4, 6, 7, 9, 10, 12, 13, 14, and 15
shall survive any expiration or earlier termination of this Agreement.

7

Source: LEGACY EDUCATION ALLIANCE, INC., 8-K, 11/10/2014
<!-- page 8 -->
19. HEADINGS All section and subsection headings contained in this Agreement are for convenience
only and shall not be deemed to constitute a part of this Agreement nor affect the meaning of same.
20. NO DRAFTER Both parties warrant and represent that each have had equal input in drafting this
Agreement and have had the opportunity to consult with independent legal counsel. 21. EXPENSES Bar
those covered in clause 1A, each party shall bear all expenses incidental to the performance of its
obligations under this Agreement. 22. SEPARATE COUNTERPARTS This Agreement may be executed in
several counterparts, each of which shall be an original but all of which together shall constitute
one and the same instrument. 23. ENTENT OF AGREEMENT This Agreement is subject to the terms of the
Primary Agreement and both agreements supersede any and all other agreements, either verbal or in
writing between the parties hereto with respect to the use of Talent's Property by Company, and
contains all of the covenants and agreements between the parties with respect to such use in any
manner whatsoever providing that the terms of the Primary Agreement shall remain effective at all
times and such terms shall take precedence in the event of any conflict between the terms. Each
party to this Agreement acknowledges that no representation, inducements, promises, or agreements,
verbally or otherwise, have been made by any party, or anyone acting on behalf of any party, which
are not embodied herein, and that no other agreement, statement, or promise not contained in this
Agreement shall be valid or binding on either party, other than as expressed in the Primary
Agreement and any other written agreement dated concurrent with or after this Agreement shall be
valid as between the signing parties thereto provided always such agreement does not override or
conflict with the terms of the Primary Agreement. IN WITNESS WHEREOF, the Parties hereto, intending
to be legally bound hereby, have each caused to be affixed hereto its or his/her hand and seal the
day indicated. COMPANY CSA on behalf of TALENT Tigrent Learning UK Limited lain Edwards (authorized
signatory) Sharon Bowler (authorized signatory) Date Date 8

Source: LEGACY EDUCATION ALLIANCE, INC., 8-K, 11/10/2014
