<!-- page 1 -->
# DEVELOPMENT AND OPTION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2019-11-20 |
| Parties | Harpoon Therapeutics, Inc. ("Harpoon"); AbbVie Biotechnology Ltd ("AbbVie") |
| Source | CUAD v1 / HarpoonTherapeuticsInc_20200312_10-K_EX-10.18_12051356_EX-10.18_Development Agreement |

Exhibit 10.18 Confidential EXECUTION COPY

CERTAIN CONFIDENTIAL INFORMATION CONTAINED IN THIS DOCUMENT, MARKED BY [***], HAS BEEN OMITTED
BECAUSE IT IS BOTH NOT MATERIAL AND WOULD BE COMPETITIVELY HARMFUL IF PUBLICLY DISCLOSED.

DEVELOPMENT AND OPTION AGREEMENT

between

HARPOON THERAPEUTICS, INC.

and

ABBVIE BIOTECHNOLOGY LTD

Dated as of November 20, 2019

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 2 -->
TABLE OF CONTENTS

ARTICLE 1 DEFINITIONS 1

ARTICLE 2 COLLABORATION MANAGEMENT

18

2.1 Joint Governance Committee. 18 2.2 General Provisions Applicable to the JGC. 19 2.3
Discontinuation of the JGC. 20 2.4 Interactions Between the JGC and Internal Teams. 20 2.5 CMC
Working Group. 21 2.6 Working Groups. 21 2.7 Expenses. 21

ARTICLE 3 DEVELOPMENT AND REGULATORY

21

3.1 Initial Development Plan and Activities. 21 3.2 AbbVie Option. 24 3.3 [***]. 25 3.4
Post-Exercise Development Activities. 26 3.5 Supply of Technology for Development Purposes. 27 3.6
Expenses and Invoicing. 27 3.7 Subcontracting. 28 3.8 Regulatory Matters. 28

ARTICLE 4 COMMERCIALIZATION 30

4.1 In General. 30 4.2 Commercialization Diligence. 30 4.3 Booking of Sales; Distribution. 31 4.4
Product Trademarks. 31 4.5 Commercial Supply of Licensed Compounds or Licensed Products. 31

ARTICLE 5 GRANT OF RIGHTS

33

5.1 Grants to AbbVie. 33 5.2 Grants to Harpoon. 34 5.3 Sublicenses. 34 5.4 Distributorships. 34 5.5
Co-Promotion Rights. 34 5.6 Retention of Rights. 34 5.7 Confirmatory Patent License. 35 5.8
Exclusivity with Respect to the Territory. 35 5.9 In-License Agreements. 35

ARTICLE 6 PAYMENTS AND RECORDS

36

6.1 Upfront Payment. 36 6.2 Development and Regulatory Milestones. 36 6.3 First Commercial Sales
Milestones. 37 6.4 Sales-Based Milestones. 37 6.5 Royalties. 38 6.6 Royalty Payments and Reports. 39
6.7 Mode of Payment; Offsets. 40 6.8 Withholding Taxes. 40

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 3 -->
6.9 Indirect Taxes. 40 6.10 Interest on Late Payments. 41 6.11 Audit. 41 6.12 Audit Dispute. 41 6.13
Confidentiality. 41 6.14 [***] 41 6.15 No Other Compensation. 42

ARTICLE 7 INTELLECTUAL PROPERTY

42

7.1 Ownership of Intellectual Property. 42 7.2 Maintenance and Prosecution of Patents. 43 7.3
Enforcement of Patents. 45 7.4 Infringement Claims by Third Parties. 48 7.5 Invalidity or
Unenforceability Defenses or Actions. 48 7.6 Product Trademarks. 49 7.7 International Nonproprietary
Name. 50 7.8 Inventor's Remuneration. 50 7.9 Common Interest. 50

ARTICLE 8 PHARMACOVIGILANCE AND SAFETY

50

8.1 Pharmacovigilance. 50 8.2 Global Safety Database. 50

ARTICLE 9 CONFIDENTIALITY AND NON- DISCLOSURE

51

9.1 Product Information. 51 9.2 Confidentiality Obligations. 51 9.3 Permitted Disclosures. 52 9.4
Use of Name. 53 9.5 Public Announcements. 53 9.6 Publications. 54 9.7 Return of Confidential
Information. 54 9.8 Survival. 54

ARTICLE 10 REPRESENTATIONS AND WARRANTIES

55

10.1 Mutual Representations and Warranties. 55 10.2 Additional Representations and Warranties of
Harpoon. 55 10.3 Covenants of Harpoon. 58 10.4 Covenants of AbbVie. 58 10.5 DISCLAIMER OF
WARRANTIES. 59

ARTICLE 11 INDEMNITY 60

11.1 Indemnification of Harpoon. 60 11.2 Indemnification of AbbVie. 60 11.3 Notice of Claim. 60 11.4
Control of Defense. 61 11.5 Special, Indirect, and Other Losses. 61 11.6 Insurance. 61

ARTICLE 12 TERM AND TERMINATION

62

12.1 Term. 62

- ii -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 4 -->
12.2 Termination for Material Breach. 62 12.3 Additional Termination Rights by AbbVie. 63 12.4
Termination for Insolvency. 63 12.5 Rights in Bankruptcy. 63 12.6 Termination in Entirety. 63 12.7
Reversion of Harpoon Products. 66 12.8 Termination of Terminated Territory. 67 12.9 Remedies. 67
12.10 Accrued Rights; Surviving Obligations. 67

ARTICLE 13 MISCELLANEOUS 68

13.1 Force Majeure. 68 13.2 Change in Control of Harpoon. 68 13.3 Export Control. 69 13.4
Assignment. 69 13.5 Severability. 70 13.6 Governing Law, Jurisdiction and Service. 70 13.7 Dispute
Resolution. 70 13.8 Notices. 71 13.9 Entire Agreement; Amendments. 72 13.10 English Language. 72
13.11 Equitable Relief. 72 13.12 Waiver and Non-Exclusion of Remedies. 72 13.13 No Benefit to Third
Parties. 72 13.14 Further Assurance. 73 13.15 Relationship of the Parties. 73 13.16 Performance by
Affiliates. 73 13.17 Counterparts; Facsimile Execution. 73 13.18 References. 73 13.19 Schedules. 73
13.20 Construction. 73 SCHEDULES Schedule 1.84 Initial Development Plan Schedule 1.99 Licensed
Compound Schedule 3.7 Pre-Approved Third Party Providers Schedule 10.2 Disclosure Schedules Schedule
10.2.1 Existing Patents Schedule 13.7.3 Arbitration

- iii -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020

DEVELOPMENT AND OPTION AGREEMENT
<!-- page 5 -->
This Development and Option Agreement (the "Agreement") is made and entered into effective as of
November 20, 2019 (the "Effective Date") by and between Harpoon Therapeutics, Inc., a Delaware
corporation ("Harpoon"), and AbbVie Biotechnology Ltd, a Bermuda corporation ("AbbVie"). Harpoon and
AbbVie are sometimes referred to herein individually as a "Party" and collectively as the "Parties."

RECITALS

WHEREAS, Harpoon Controls (as defined herein) certain intellectual property rights with respect to
the Licensed Compound (as defined herein) and Licensed Products (as defined herein) in the Territory
(as defined herein); and

WHEREAS, Harpoon wishes to grant an option to a license to AbbVie, and AbbVie wishes to take, such
option to a license under such intellectual property rights to develop and commercialize Licensed
Products in the Territory, in each case in accordance with the terms and conditions set forth below.

NOW, THEREFORE, in consideration of the premises and the mutual promises and conditions hereinafter
set forth, and other good and valuable consideration, the receipt and sufficiency of which are
hereby acknowledged, the Parties, intending to be legally bound, do hereby agree as follows:

ARTICLE 1 DEFINITIONS

Unless otherwise specifically provided herein, the following terms shall have the following
meanings:

1.1 "AbbVie" has the meaning set forth in the preamble hereto.

1.2 [***] has the meaning set forth in [***]

1.3 [***] has the meaning set forth in [***].

1.4 [***] has the meaning set forth in [***]

1.5 [***] has the meaning set forth in [***].

1.6 "AbbVie [***] Rights" has the meaning set forth in Section 5.9.2.

1.7 "AbbVie Indemnitees" has the meaning set forth in Section 11.2.

1.8 "AbbVie Know-How" means all Information that is (a) Controlled by AbbVie or any of its
Affiliates during the Term, (b) developed or acquired by AbbVie or any of its Affiliates during the
Term as a result of performance under this Agreement, (c) not generally known and (d) necessary or
reasonably useful for the Exploitation of the Licensed Compound or a Licensed Product, but excluding
any Joint Know-How or Information published in any AbbVie Patents or Joint Patents.

1.9 "AbbVie Patents" means all of the Patents that (a) are Controlled by AbbVie or any of its
Affiliates during the Term, (b) claim inventions made or conceived by or on behalf of AbbVie or any
of its Affiliates during the Term as a result of performance under this Agreement, and (c) are
necessary or reasonably useful (or, with respect to patent applications, would be necessary or
reasonably useful if such

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 6 -->
patent applications were to issue as patents) for the Exploitation of the Licensed Compound or a
Licensed Product, but excluding any Joint Patents.

1.10 "AbbVie Reversion IP" has the meaning set forth in Section 12.7.1.

1.11 "AbbVie Withholding Tax Action" has the meaning set forth in Section 6.8.2.

1.12 "Acceptance" means, with respect to a Drug Approval Application, receipt of written notice from
the applicable Regulatory Authority indicating that such Drug Approval Application has been accepted
for filing and further review.

1.13 "Accounting Standards" means, with respect to a Party, that such Party shall maintain records
and books of accounts in accordance with United States Generally Accepted Accounting Principles.

1.14 "Acquisition" means, with respect to a Party, a merger, acquisition (whether of all of the
stock or all or substantially all of the assets of a Person or any operating or business division of
a Person) or similar transaction by or with the Party, other than a Change in Control of the Party.

1.15 "Adverse Ruling" has the meaning set forth in Section 12.2.1.

1.16 "Affiliate" means, with respect to a Party, any Person that, directly or indirectly, through
one (1) or more intermediaries, controls, is controlled by or is under common control with such
Party. For purposes of this definition, "control" and, with correlative meanings, the terms
"controlled by" and "under common control with" means (a) the possession, directly or indirectly, of
the power to direct the management or policies of a Person, whether through the ownership of voting
securities, by contract relating to voting rights or corporate governance, or otherwise; or (b) the
ownership, directly or indirectly, of more than fifty percent (50%) of the voting securities or
other ownership interest of a Person (or, with respect to a limited partnership or other similar
entity, its general partner or controlling entity). The Parties acknowledge that in the case of
certain entities organized under the laws of certain countries outside of the United States, the
maximum percentage ownership permitted by law for a foreign investor may be less than fifty percent
(50%), and that in such case such lower percentage shall be substituted in the preceding sentence,
provided that such foreign investor has the power to direct the management or policies of such
entity.

1.17 "Agreement" has the meaning set forth in the preamble hereto.

1.18 "Alliance Manager" has the meaning set forth in Section 2.2.5.

1.19 "Applicable Law" means federal, state, local, national and supra-national laws, statutes,
rules, and regulations, including any rules, regulations, regulatory guidelines, or other
requirements of the Regulatory Authorities, major national securities exchanges or major securities
listing organizations, that may be in effect from time to time during the Term and applicable to a
particular activity or country or other jurisdiction hereunder.

1.20 "Audit Expert" has the meaning set forth in Section 6.12.

1.21 "Bankruptcy Code" has the meaning set forth in Section 12.5.1.

1.22 "BCMA" means that specific protein known as B-cell maturation antigen or tumor necrosis factor
receptor superfamily member 17 (TNFRSF17) or CD269 in addition to any other known aliases [***].

- 2 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 7 -->
1.23 "Biosimilar Application" has the meaning set forth in Section 7.3.3.

1.24 "Biosimilar Product" means, with respect to a particular Licensed Product in a particular
country, a biologic product that is (a) substantially similar to or interchangeable with such
Licensed Product, such that the application for a BLA for such biologic product submitted to the
applicable Regulatory Authority relies in whole or in part on a prior BLA granted to such Licensed
Product (including any application for such biological product submitted under Section 351(k) of the
PHSA or successor law, or other analogous Applicable Law, citing the Licensed Product as the
reference product), or (b) determined by the applicable Regulatory Authority to be interchangeable
with such Licensed Product, as set forth at 42 U.S.C. § 262(k)(4) or successor law, or other
analogous Applicable Law outside of the United States. A biological product licensed under the same
BLA as the Licensed Product will not constitute a Biosimilar Product.

1.25 "BLA" has the meaning set forth in the definition of "Drug Approval Application."

1.26 "Board of Directors" has the meaning set forth in the definition of "Change in Control."

1.27 "Breaching Party" has the meaning set forth in Section 12.2.1.

1.28 "Business Day" means a day other than a Saturday or Sunday on which banking institutions in New
York, New York are open for business.

1.29 "Calendar Quarter" means each successive period of three (3) calendar months commencing on
January 1, April 1, July 1 and October 1, except that the first Calendar Quarter of the Term shall
commence on the Effective Date and end on the day immediately prior to the first to occur of January
1, April 1, July 1 or October 1 after the Effective Date, and the last Calendar Quarter shall end on
the last day of the Term.

1.30 "Calendar Year" means each successive period of twelve (12) calendar months commencing on
January 1 and ending on December 31, except that the first Calendar Year of the Term shall commence
on the Effective Date and end on December 31 of the year in which the Effective Date occurs and the
last Calendar Year of the Term shall commence on January 1 of the year in which the Term ends and
end on the last day of the Term.

1.31 "Change in Control," with respect to a Party, shall be deemed to have occurred if any of the
following occurs after the Effective Date:

1.31.1 any "person" or "group" (as such terms are defined below) (a) is or becomes the "beneficial
owner" (as defined below), directly or indirectly, of shares of capital stock or other interests
(including partnership interests) of such Party then outstanding and normally entitled (without
regard to the occurrence of any contingency) to vote in the election of the directors, managers or
similar supervisory positions ("Voting Stock") of such Party representing fifty percent (50%) or
more of the total voting power of all outstanding classes of Voting Stock of such Party or (b) has
the power, directly or indirectly, to elect a majority of the members of the Party's board of
directors, or similar governing body ("Board of Directors"); excluding in each case (subclauses (a)
and (b)) [***]; or

1.31.2 such Party enters into a merger, consolidation or similar transaction with another Person
(whether or not such Party is the surviving entity) and as a result of such merger, consolidation or
similar transaction (a) the members of the Board of Directors of such Party immediately prior to
such transaction constitute less than a majority of the members of the Board of Directors of such
Party or such surviving Person immediately following such transaction or (b) the Persons that
beneficially owned, directly

- 3 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 8 -->
or indirectly, the shares of Voting Stock of such Party immediately prior to such transaction cease
to beneficially own, directly or indirectly, shares of Voting Stock of such Party representing at
least a majority of the total voting power of all outstanding classes of Voting Stock of the
surviving Person in substantially the same proportions as their ownership of Voting Stock of such
Party immediately prior to such transaction; or

1.31.3 such Party sells or transfers to any Third Party, in one (1) or more related transactions,
properties or assets representing all or substantially all of such Party's assets to which this
Agreement relates; or

1.31.4 the holders of capital stock of such Party approve a plan or proposal for the liquidation or
dissolution of such Party.

For the purpose of this definition of Change in Control, (a) "person" and "group" have the meanings
given such terms under Section 13(d) and 14(d) of the United States Securities Exchange Act of 1934
and the term "group" includes any group acting for the purpose of acquiring, holding or disposing of
securities within the meaning of Rule 13d-5(b)(1) under the said Act; (b) a "beneficial owner" shall
be determined in accordance with Rule 13d-3 under the aforesaid Act; and (c) the terms "beneficially
owned" and "beneficially own" shall have meanings correlative to that of "beneficial owner."

1.32 [***]

1.33 "Clinical Data" means [***] Information with respect to any Licensed Compound or Licensed
Product and made, collected, or otherwise generated under or in connection with Clinical Studies,
including any data (including raw data), reports, and results with respect thereto.

1.34 "Clinical Studies" means Phase 0, Phase I, Phase II, Phase III, and such other tests and
studies in human subjects that are required by Applicable Law, or otherwise recommended by the
Regulatory Authorities, to obtain or maintain Regulatory Approvals for a Licensed Product for one
(1) or more indications, including tests or studies that are intended to expand the Product Labeling
for such Licensed Product with respect to such indication.

1.35 "CMC" has the meaning set forth in the definition of "Initial Development Plan."

1.36 "CMC Working Group" has the meaning set forth in Section 2.5.

1.37 "Combination Product" means a Licensed Product that is: (a) sold in the form of a combination
product containing both a Licensed Compound and one (1) or more other therapeutically active
pharmaceutical or biologic products; or (b) sold in a form that contains (or is sold bundled with)
any (i) diagnostic product or (ii) other product that is administered separately from the Licensed
Product, in both cases (subclauses (a) and (b)) sold as a unit at a single price and excluding any
Delivery System.

1.38 "Commercialization" means any and all activities directed to the preparation for sale of,
offering for sale of, or sale of a Licensed Compound or Licensed Product, including activities
related to marketing, promoting, distributing, importing and exporting such Licensed Compound or
Licensed Product, and interacting with Regulatory Authorities regarding any of the foregoing. When
used as a verb, "to Commercialize" and "Commercializing" means to engage in Commercialization, and
"Commercialized" has a corresponding meaning.

1.39 "Commercially Reasonable Efforts" means with respect to [***].

- 4 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020

1.40 [***]
<!-- page 9 -->
1.41 "Competitor" means any Person that [***], or (b) that [***].

1.42 "Confidential Information" means any Information provided orally, visually, in writing or other
form by or on behalf of one (1) Party (or an Affiliate or representative of such Party) to the other
Party (or to an Affiliate or representative of such other Party) in connection with this Agreement,
whether prior to, on, or after the Effective Date, including Information relating to the terms of
this Agreement, the Licensed Compound or any Licensed Product (including the Regulatory
Documentation and regulatory data), any Exploitation of the Licensed Compound or any Licensed
Product, any know-how with respect thereto developed by or on behalf of the disclosing Party or its
Affiliates, or the scientific, regulatory or business affairs or other activities of either Party.
Notwithstanding the foregoing, (a) Joint Know-How shall be deemed to be the Confidential Information
of both Parties, and both Parties shall be deemed to be the receiving Party and the disclosing Party
with respect thereto, and (b) following the License Option Exercise Closing Date, all Regulatory
Documentation owned by AbbVie pursuant to Section 3.8.2 shall be deemed to be the Confidential
Information of AbbVie, and AbbVie shall be deemed to be the disclosing Party and Harpoon shall be
deemed to be the receiving Party with respect thereto. In addition, all information disclosed by
Harpoon to AbbVie under the Prior NDA shall be deemed to be Harpoon's Confidential Information
disclosed hereunder, and all information disclosed by AbbVie Inc. to Harpoon under the Prior NDA
shall be deemed to be AbbVie's Confidential Information disclosed hereunder.

- 5 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 10 -->
1.43 "Control" means, with respect to any item of Information, Regulatory Documentation, material,
Patent, or other property right, the possession of the right, whether directly or indirectly, and
whether by ownership, license or otherwise (other than by operation of the license and other grants
in Sections 5.1 or 5.2), to grant a license, sublicense or other right (including the right to
reference Regulatory Documentation) to or under such Information, Regulatory Documentation,
material, Patent, or other property right as provided for herein without violating the terms of any
agreement or other arrangement with any Third Party. "Controlled" has a corresponding meaning.

1.44 "CSR Notification Date" has the meaning set forth in Section 12.6.3(e).

1.45 "Default Notice" has the meaning set forth in Section 12.2.1.

1.46 "Delivery System" has the meaning set forth in the definition of "Net Sales."

1.47 "Development" means all activities related to pre-clinical and other non-clinical testing, test
method development and stability testing, toxicology, formulation, process development,
manufacturing scale-up, qualification and validation, quality assurance/quality control, Clinical
Studies, including Manufacturing in support thereof, statistical analysis and report writing, the
preparation and submission of Drug Approval Applications, regulatory affairs with respect to the
foregoing and all other activities necessary or reasonably useful or otherwise requested or required
by a Regulatory Authority as a condition or in support of obtaining or maintaining a Regulatory
Approval. When used as a verb, "Develop" means to engage in Development. For purposes of clarity,
Development shall include any submissions and activities required in support thereof, required by
Applicable Laws or a Regulatory Authority as a condition or in support of obtaining a pricing or
reimbursement approval for an approved Licensed Product.

1.48 "Development Report Review Deadline" means [***] following the initial delivery of any [***],
as applicable.

1.49 "Dispute" has the meaning set forth in Section 13.7.

1.50 "Distributor" has the meaning set forth in Section 5.4.

1.51 "Divestiture" means, with respect to a Party, (a) the divestiture [***] through [***] or [***]
with respect to [***] (for clarity, the [***] for any such divestiture), or (b) [***]. When used as
a verb, "Divest" and "Divested" means to cause a Divestiture.

1.52 "Dollars" or "$" means United States Dollars.

1.53 "Drug Approval Application" means a Biologics License Application (a "BLA") as defined in the
PHSA, or any corresponding foreign application in the Territory, including, with respect to the
European Union, a Marketing Authorization Application (a "MAA") filed with the EMA or with the
applicable Regulatory Authority of a country in Europe with respect to the mutual recognition or any
other national approval procedure.

- 6 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 11 -->
1.54 "[***]" means the [***] by Harpoon to AbbVie within [***] following Harpoon's receipt of
written notice from AbbVie pursuant to [***] prior to the date of AbbVie's receipt of the [***].

1.55 "Effective Date" means the effective date of this Agreement as set forth in the preamble
hereto.

1.56 "EMA" means the European Medicines Agency and any successor agency(ies) or authority having
substantially the same function.

1.57 "European Major Market" means each of [***].

1.58 "European Union" or "E.U." means the economic, scientific, and political organization of member
states known as the European Union, as its membership may be altered from time to time, and any
successor thereto.

1.59 "Existing Patents" has the meaning set forth in Section 10.2.1.

1.60 "Exploit," "Exploited" or "Exploitation" means to make, have made, import, export, use, sell,
or offer for sale, including to Develop, Commercialize, register, modify, enhance, improve,
Manufacture, have Manufactured, hold, or keep (whether for disposal or otherwise), formulate,
optimize, have used, export, transport, distribute, promote, market, have sold or otherwise dispose
of.

1.61 "FDA" means the United States Food and Drug Administration and any successor agency(ies) or
authority having substantially the same function.

1.62 "FFDCA" means the United States Federal Food, Drug, and Cosmetic Act, 21 U.S.C. § 301 et seq.,
as amended from time to time, together with any rules, regulations and requirements promulgated
thereunder (including all additions, supplements, extensions, and modifications thereto).

1.63 "Field" means all human and non-human diagnostic, prophylactic, and therapeutic uses.

1.64 "Final Development Report" means the final written data package delivered by Harpoon to AbbVie
in accordance with Section 3.1.3, after the completion of all activities under the Initial
Development Plan, including, for clarity, [***], and comprised of the [***]. The Final Development
Report shall include [***].

- 7 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 12 -->
1.65 "First Commercial Sale" means, with respect to a Licensed Product and a country, the first sale
for monetary value for use or consumption by the end user of such Licensed Product in such country
after Regulatory Approval for such Licensed Product has been obtained in such country. [***] shall
not be construed as a First Commercial Sale.

1.66 "Harpoon" has the meaning set forth in the preamble hereto.

1.67 "Harpoon In-License Agreement" means [***] agreement between Harpoon and a Third Party under
which AbbVie is granted a sublicense or other right under this Agreement as provided in Section 5.9.

1.68 "Harpoon Indemnitees" has the meaning set forth in Section 11.1.

1.69 "Harpoon Know-How" means all Information that is (a) Controlled by Harpoon or any of its
Affiliates as of the Effective Date or at any time during the Term, (b) not generally known and (c)
necessary or reasonably useful for the Exploitation of any Licensed Compound or any Licensed
Product, but excluding any Joint Know-How or Information published in any (i) Harpoon Patents or
(ii) Joint Patents.

1.70 "Harpoon Patents" means all of the Patents that are (a) Controlled by Harpoon or any of its
Affiliates as of the Effective Date or at any time during the Term and (b) necessary or reasonably
useful (or, with respect to Patent applications, would be necessary or reasonably useful if such
Patent applications were to issue as Patents) for the Exploitation of any Licensed Compound or any
Licensed Product, but excluding Joint Patents. The Harpoon Patents include the Existing Patents.

1.71 [***] has the meaning set forth in [***].

1.72 "Harpoon Reversion Products" has the meaning set forth in Section 12.6.1.

1.73 "HSR Act" means the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended.

1.74 "HSR Filing" has the meaning set forth in Section 3.2.4(b).

1.75 "In-Licensed Patents" has the meaning set forth in Section 10.2.3.

1.76 "IND" means an application filed with a Regulatory Authority for authorization to commence
Clinical Studies, including (a) an Investigational New Drug Application as defined in the FFDCA or
any successor application or procedure filed with the FDA, (b) any equivalent thereof in other
countries or regulatory jurisdictions, (e.g., a Clinical Trial Application (CTA) in the European
Union) and (c) all supplements, amendments, variations, extensions and renewals thereof that may be
filed with respect to the foregoing.

1.77 "Indemnification Claim Notice" has the meaning set forth in Section 11.3.

1.78 "Indemnified Party" has the meaning set forth in Section 11.3.

1.79 "Indication" means, with respect to a Licensed Product, a use to which such Licensed Product is
intended to be put for the treatment, prevention, mitigation, cure or diagnosis of a recognized
disease

- 8 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 13 -->
or condition, or of a manifestation of a recognized disease or condition, or for the relief of
symptoms associated with a recognized disease or condition, in each case for any size patient
population, which, if such Licensed Product is approved in the U.S., would be reflected in the
"Indications and Usage" section of labeling pursuant to 21 C.F.R. §201.57(c)(2) or, to the extent
applicable, any comparable labeling section outside the U.S., subject to the following: (a) subtypes
of the same disease or condition are not additional Indications for such Licensed Product; (b)
different symptom domains or domains of impairment of the same disease or condition are not
additional Indications for such Licensed Product; (c) the approved use of such Licensed Product for
such disease in different combinations or co-therapies of treatments are not additional Indications
for such Licensed Product (e.g., monotherapy vs. add-on or combination therapy with another agent in
the same disease); (d) treatment, prevention and cure of the same disease or the same disease
subtype with such Licensed Product are not additional Indications for such Licensed Product; (e) the
approved use of such Licensed Product for such disease in a different line of treatment or a
different temporal position in a treatment algorithm for the same disease or condition are not
additional Indications for such Licensed Product (e.g., first line vs. second line therapy in the
same disease or condition); and (f) treatment of the same disease or condition with such Licensed
Product in an expanded, modified or additional patient population are not additional Indications for
such Licensed Product.

1.80 "Indirect Taxes" has the meaning set forth in Section 6.9.

1.81 [***]

1.82 "Information" means all information of a technical, scientific, business and other nature,
including know-how, technology, means, methods, processes, practices, formulae, instructions,
skills, techniques, procedures, experiences, ideas, technical assistance, designs, drawings,
assembly procedures, computer programs, apparatuses, specifications, data, results and other
material, regulatory data, and other biological, chemical, pharmacological, toxicological,
pharmaceutical, physical and analytical, pre- clinical, clinical, safety, manufacturing and quality
control data and information, including study designs and protocols, reagents (including all
physical materials in connection with any of the foregoing such as plasmids, proteins, cell lines,
assays, materials generated in connection with any CMC activities and compounds) and biological
methodology; in each case (whether or not confidential, proprietary, patented or patentable, of
commercial advantage or not) in written, electronic or any other form now known or hereafter
developed.

1.83 "Initial Development Activities" means any and all Development activities set forth in the
Initial Development Plan to be performed by Harpoon (or, pursuant to Section 3.1.2, AbbVie) in order
to advance the Licensed Compound and Licensed Product to the point of readiness to commence [***]
(or to proceed directly to pivotal clinical trials, if applicable) and ultimately support the filing
of Drug Approval Applications and obtain Regulatory Approvals for a Licensed Product in the Field in
the Territory.

1.84 "Initial Development Plan" means a development plan for the Licensed Compounds and Licensed
Products setting forth (a) in reasonable detail all Development and regulatory activities to be
performed by Harpoon with respect to the Licensed Compounds and Licensed Products through completion
of the Phase I/IB Trial, including related activities as applicable (but, for clarity, except with
respect to [***]), (b) all Clinical Data and other Information required to be delivered to AbbVie
pursuant to Section 1.112 in order for AbbVie to determine whether to exercise the License Option,
and (c) all Information to be included in the Final Development Report (i.e. as a result of

- 9 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 14 -->
activities conducted after the delivery of the Opt-In Development Report), which Initial Development
Plan is attached as Schedule 1.84, as the same may be amended from time to time in accordance with
the terms hereof.

1.85 "Initiation" or "Initiate" means, with respect to a Clinical Study, the first dosing of the
first human subject in such Clinical Study.

1.86 "Intellectual Property" has the meaning set forth in Section 12.5.1.

1.87 "Joint Governance Committee" or "JGC" has the meaning set forth in Section 2.1.1.

1.88 "Joint Intellectual Property Rights" has the meaning set forth in Section 7.1.2.

1.89 "Joint Know-How" has the meaning set forth in Section 7.1.2.

1.90 "Joint Patents" has the meaning set forth in Section 7.1.2.

1.91 "Knowledge" means [***] of the [***] of a Party, or any personnel holding positions equivalent
to such job titles (but only to the extent such positions exist at such Party).

1.92 [***]

1.93 [***]

1.94 [***]

1.95 "License Option" has the meaning set forth in Section 3.2.3.

1.96 "License Option Exercise Closing Date" has the meaning set forth in Section 3.2.4.

1.97 "License Option Exercise Notice" has the meaning set forth in Section 3.2.3.

1.98 "License Option Period" has the meaning set forth in Section 3.2.3.

1.99 "Licensed Compound" means (a) the compound known as HPN217 (as described on Schedule 1.99),
[***].

1.100 "Licensed Product" means any product, or portion thereof, containing a Licensed Compound,
alone or in combination with one (1) or more other active ingredients, in any and all forms, in

- 10 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 15 -->
current and future formulations, dosages forms and strengths, and delivery modes, including any
improvements thereto. For clarity, Licensed Products that contain the same Licensed Compound
(whether or not with one or more active ingredients (if applicable)), but in a different
formulation, dosage form or delivery device, shall be considered the same Licensed Product for the
purposes of calculating milestone and royalty payments hereunder.

1.101 "Losses" has the meaning set forth in Section 11.1.

1.102 "MAA" has the meaning set forth in the definition of "Drug Approval Application."

1.103 "Major Market" means each of [***].

1.104 "Major Regulatory Filing" means major regulatory filings and documents (including INDs, Drug
Approval Applications, material labeling supplements, Regulatory Authority meeting requests, and
core data sheets).

1.105 "Manufacture" and "Manufacturing" means all activities related to the synthesis, making,
production, processing, purifying, formulating, filling, finishing, packaging, labeling, shipping,
and holding of the Licensed Compound, any Licensed Product, or any intermediate thereof, including
process development, process qualification and validation, scale-up, pre- clinical, clinical and
commercial production and analytic development, product characterization, stability testing, quality
assurance, and quality control.

1.106 "Manufacturing Process" has the meaning set forth in Section 4.6.1.

1.107 "Manufacturing Technology Transfer" has the meaning set forth in Section 4.6.1.

1.108 "Net Sales" means[***]

(a) [***]

(b) [***]

(c) [***]

(d) [***]

(e) [***]

(f) [***] of such Licensed Product and to the extent [***]

- 11 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 16 -->
[***], where for purposes of this Net Sales definition, [***] of such Licensed Product;

(g) [***]

(h) [***]

(i) [***]

(j) [***], but which [***].

[***]

In the event that a Licensed Product is sold in any country or other jurisdiction [***]

(i) [***].

- 12 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020

(ii) [***]
<!-- page 17 -->
(iii) [***]

(iv) [***].

1.109 "Non-Breaching Party" has the meaning set forth in Section 12.2.1.

1.110 [***]

1.111 "Opt-In Dataset" has the meaning set forth in the definition of "Opt-In Development Report."

1.112 "Opt-In Development Report" means the written data package delivered by Harpoon to AbbVie and
generated from the clinical dataset extracted from the [***] as it exists at the date that is [***]
(the "Opt-In Dataset" and such date the "Opt-In Development Report Dataset Cutoff Date"). The Opt-In
Dataset will arise from the conduct of the Initial Development Activities and will include
information available in the [***] as of the Opt-In Development Report Generation Date related to
[***]. In addition to the information and data set forth above based on the Opt-In Dataset, the
Opt-In Development Report will include[***].

- 13 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 18 -->
1.113 "Opt-In Development Report Dataset Cut-Off Date" has the meaning set forth in the definition
of "Opt-In Development Report."

1.114 "Other Product" means, with respect to a Combination Product, such other therapeutically
active pharmaceutical or biologic products referenced in Section 1.37(a) or such diagnostic or other
product referenced in Section 1.37(b), in each case other than the Licensed Compound.

1.115 "Owned Patents" has the meaning set forth in Section 10.2.3.

1.116 "Party" and "Parties" has the meaning set forth in the preamble hereto.

1.117 "Patents" means (a) all national, regional and international patents and patent applications,
including provisional patent applications, (b) all patent applications filed either from such
patents, patent applications or provisional applications or from an application claiming priority
from either of these, including divisionals, continuations, continuations-in-part, provisionals,
converted provisionals and continued prosecution applications, (c) any and all patents that have
issued or in the future issue from the foregoing patent applications ((a) and (b)), including
utility models, petty patents and design patents and certificates of invention, (d) any and all
extensions or restorations by existing or future extension or restoration mechanisms, including
revalidations, reissues, re-examinations and extensions (including any pediatric exclusivity and
other such exclusivities that are attached to patents, supplementary protection certificates and the
like) of the foregoing patents or patent applications ((a), (b), and (c)), and (e) any similar
rights, including so-called pipeline protection or any importation, revalidation, confirmation or
introduction patent or registration patent or patent of additions to any of such foregoing patent
applications and patents.

1.118 "Person" means an individual, sole proprietorship, partnership, limited partnership, limited
liability partnership, corporation, limited liability company, business trust, joint stock company,
trust, unincorporated association, joint venture or other similar entity or organization, including
a government or political subdivision, department or agency of a government.

1.119 "Phase 0" means an exploratory, first-in-human trial conducted in accordance with the FDA 2006
Guidance on Exploratory Investigational New Drug Studies (or the equivalent in any country or other
jurisdiction outside of the United States) and designed to expedite the development of therapeutic
or imaging agents by establishing very early on whether the agent behaves in human subjects as was
anticipated from pre-clinical studies.

1.120 "Phase I" means a human clinical trial of a Licensed Compound or Licensed Product, the
principal purpose of which is a preliminary determination of safety, tolerability, pharmacological
activity or pharmacokinetics in healthy individuals or patients or similar clinical study prescribed
by the Regulatory Authorities, including the trials referred to in 21 C.F.R. §312.21(a), as amended.

- 14 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 19 -->
1.121 "Phase I/IB Trial" means the Phase I or I/II study of a Licensed Compound or Licensed Product
incorporating dose escalation and cohort expansion studies as described in the Initial Development
Plan (as it may be amended from time to time in accordance with Section 3.1.1).

1.122 "Phase II" means a human clinical trial of a Licensed Compound or Licensed Product, the
principal purpose of which is a determination of safety and efficacy in the target patient
population, which is prospectively designed to generate sufficient data that may permit commencement
of pivotal clinical trials, or a similar clinical study prescribed by the Regulatory Authorities,
from time to time, pursuant to Applicable Law or otherwise, including the trials referred to in 21
C.F.R. §312.21(b), as amended.

1.123 "Phase III" means a human clinical trial of a Licensed Compound or Licensed Product on a
sufficient number of subjects in an indicated patient population that is designed to establish that
a Licensed Compound or Licensed Product is safe and efficacious for its intended use and to
determine the benefit/risk relationship, warnings, precautions, and adverse reactions that are
associated with such product in the dosage range to be prescribed, which trial is intended to
support marketing approval of such Licensed Compound or Licensed Product, including all tests and
studies that are required by the FDA from time to time, pursuant to Applicable Law or otherwise,
including the trials referred to in 21 C.F.R. §312.21(c), as amended.

1.124 "PHSA" means the United States Public Health Service Act, as amended from time to time.

1.125 "PMDA" means Japan's Pharmaceuticals and Medical Devices Agency and any successor agency(ies)
or authority having substantially the same function.

1.126 "Post CSR Option Period" has the meaning set forth in Section 12.6.3(e).

1.127 "Prior NDA" has the meaning set forth in Section 13.9.

1.128 "Product Information" has the meaning set forth in Section 9.1.

1.129 "Product Infringement" has the meaning set forth in Section 7.3.1.

1.130 "Product Labeling" means, with respect to a Licensed Product in a country or other
jurisdiction in the Territory, (a) the full prescribing information for such Licensed Product as
approved by the Regulatory Authority for such country or other jurisdiction, including any required
patient information, and (b) all labels and other written, printed, or graphic matter upon a
container, wrapper, or any package insert utilized with or for such Licensed Product in such country
or other jurisdiction.

1.131 "Product-Specific Claims" has the meaning set forth in Section 7.2.1(a).

1.132 "Product-Specific Patents" has the meaning set forth in Section 7.2.1(b).

1.133 "Product Trademarks" means the Trademark(s) to be used by AbbVie or its Affiliates or its or
their respective Sublicensees for the Development, Commercialization or Exploitation of Licensed
Products in the Territory and any registrations thereof or any pending applications relating thereto
in the Territory (excluding, in any event, any trademarks, service marks, names or logos that
include any corporate name or logo of the Parties or their Affiliates).

1.134 "Proposed Future In-Licensed Rights" has the meaning set forth in Section 5.9.

1.135 "Regulatory Approval" means, with respect to a country or other jurisdiction in the Territory,
all approvals (including Drug Approval Applications), licenses, registrations, or authorizations of

- 15 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 20 -->
any Regulatory Authority necessary to Commercialize a Licensed Compound or Licensed Product in such
country or other jurisdiction, including, where applicable, pricing or reimbursement approval in
such country or other jurisdiction.

1.136 "Regulatory Authority" means any applicable supra-national, federal, national, regional,
state, provincial, or local governmental or regulatory authority, agency, department, bureau,
commission, council, or other entities (e.g., the FDA, EMA and PMDA) regulating or otherwise
exercising authority with respect to activities contemplated in this Agreement, including the
Exploitation of the Licensed Compound or Licensed Products in the Territory.

1.137 "Regulatory Documentation" means all (a) applications (including all INDs and Drug Approval
Applications and other Major Regulatory Filings), registrations, licenses, authorizations, and
approvals (including Regulatory Approvals), (b) correspondence and reports submitted to or received
from Regulatory Authorities (including minutes and official contact reports relating to any
communications with any Regulatory Authority) and all supporting documents with respect thereto,
including all regulatory drug lists, advertising and promotion documents, adverse event files, and
complaint files, and (c) Clinical Data and data contained or relied upon in any of the foregoing, in
each case ((a), (b), and (c)) to the extent relating to a Licensed Compound or Licensed Product.

1.138 "Regulatory Exclusivity" means, with respect to any country or other jurisdiction in the
Territory, an additional market protection, other than Patent protection, granted by a Regulatory
Authority in such country or other jurisdiction which confers an exclusive Commercialization period
during which AbbVie or its Affiliates or Sublicensees has the exclusive right to market and sell,
and any unauthorized Third Party is prevented from marketing or selling, a Licensed Compound or
Licensed Product in such country or other jurisdiction.

1.139 "Royalty Term" means, with respect to each Licensed Product and each country or other
jurisdiction in the Territory, the period beginning on the date of the First Commercial Sale of such
Licensed Product in such country or other jurisdiction, and ending on the latest to occur of (a) the
expiration, invalidation or abandonment date of the last Harpoon Patent (i)[***] in such country or
other jurisdiction; or (ii) [***] in such country or other jurisdiction; (b) the expiration of
Regulatory Exclusivity in such country or other jurisdiction for such Licensed Product; or (c) the
[***] of the First Commercial Sale of such Licensed Product in such country or other jurisdiction.

1.140 "Segregate" means, with respect to a [***] relating to such [***] relating to the [***]
provided that, [***] in connection [***].

- 16 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 21 -->
1.141 "Senior Officer" means, with respect to Harpoon, its [***], and with respect to AbbVie, its
[***].

1.142 "Sublicensee" means a Person, other than an Affiliate or a Distributor, that is granted a
sublicense by AbbVie or its Affiliate under the grants in Section 5.1 as provided in Section 5.3 but
excluding any sublicense granted by AbbVie or its Affiliate as a result of settlement of patent
litigation with respect to a Biosimilar Product.

1.143 "Term" has the meaning set forth in Section 12.1.1.

1.144 "Terminated Territory" means each Major Market with respect to which this Agreement is
terminated by Harpoon pursuant to Section 12.2.2, each country with respect to which this Agreement
is terminated by AbbVie pursuant to Section 12.3, or if this Agreement is terminated in its
entirety, the entire Territory.

1.145 "Territory" means the entire world.

1.146 "Third Party" means any Person other than Harpoon, AbbVie and their respective Affiliates.

1.147 "Third Party Claims" has the meaning set forth in Section 11.1.

1.148 "Third Party Provider" has the meaning set forth in Section 3.7.

1.149 "Trademark" means any word, name, symbol, color, designation or device or any combination
thereof that functions as a source identifier, including any trademark, trade dress, brand mark,
service mark, trade name, brand name, logo, business symbol or domain name, whether or not
registered.

1.150 "United States" or "U.S." means the United States of America and its territories and
possessions (including the District of Columbia and Puerto Rico).

1.151 "Valid Claim" means (a) a claim of any [***] Patent whose validity, enforceability, or
patentability has not been rendered invalid by any of the following: (i) irretrievable lapse,
abandonment, revocation, dedication to the public, or disclaimer; or (ii) a holding, finding, or
decision of invalidity, unenforceability, or non-patentability by a court, governmental agency,
national or regional patent office, or other appropriate body that has competent jurisdiction, such
holding, finding, or decision being final and unappealable or unappealed within the time allowed for
appeal, or (b) a claim in a Patent application that is filed and prosecuted in good faith and no
more than [***] have lapsed from its earliest priority date. For clarity, (A) any claim in a Patent
application, for which more than [***] have lapsed from its earliest priority date, shall not be
considered a Valid Claim unless and until such claim is granted and meets the requirement of
subclause (a) and (B) a holding, finding, or decision being final and unappealable or not appealed
within the time allowed for appeal means a holding, finding, or decision from which no appeal (other
than a petition to the United States Supreme Court for a writ of certiorari or a similar appeal that
is subject to discretionary review) can be or has been taken.

1.152 "Voting Stock" has the meaning set forth in the definition of "Change in Control."

1.153 "Withholding Amount" has the meaning set forth in Section 6.8.1.

1.154 "Withholding Party" has the meaning set forth in Section 6.8.1.

- 17 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 22 -->
1.155 "Working Group" has the meaning set forth in Section 2.6.

ARTICLE 2 COLLABORATION MANAGEMENT

2.1 Joint Governance Committee.

2.1.1 Formation. Within [***] after the Effective Date, the Parties shall establish a joint
governance committee (the "Joint Governance Committee" or "JGC"). The JGC shall consist of [***]
representatives from each of the Parties, each with the requisite experience and seniority to enable
such person to make decisions on behalf of the Parties with respect to the issues falling within the
jurisdiction of the JGC. From time to time, each Party may substitute [***] or more of its
representatives to the JGC on written notice to the other Party. [***] shall select from its
representatives the chairperson for the JGC. From time to time, [***]

2.1.2 Specific Responsibilities. The JGC shall develop the strategies for and oversee the
Development related activities relating to the Licensed Compounds and the Licensed Products in
accordance with the Initial Development Plan, and shall serve as a forum for the coordination of
such activities. In particular, the JGC shall:

(a) oversee the Development activities performed pursuant to the Initial Development Plan;

(b) address issues that arise during the performance of the Initial Development Plan, [***]

(c) periodically (no less often than [***]) review and serve as a forum for discussing the Initial
Development Plan, and review and approve amendments thereto;

(d) review and serve as a forum for discussing Information (including all Clinical Data) arising out
of the Initial Development Plan;

(e) discuss any [***]

(f) prior to the License Option Exercise Closing Date, review and discuss regulatory activities and
strategies for Licensed Compounds and Licensed Products;

(g) discuss the scope of any [***] contemplated under Section 4.6.1;

(h) review the activities of the CMC Working Group or any other Working Group established by the
JGC, and resolve any disagreement between the designees of AbbVie and Harpoon on any Working Group;

(i) plan and oversee the conduct of activities set forth in Section 3.5;

- 18 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 23 -->
(j) discuss and agree upon the [***] named AbbVie personnel;

(k) establish secure access methods (such as secure databases) for each Party to access Confidential
Information; and

(l) perform such other functions as are set forth herein or as the Parties may mutually agree in
writing, except where in conflict with any provision of this Agreement.

2.2 General Provisions Applicable to the JGC.

2.2.1 Meetings and Minutes. The JGC shall meet [***], or as otherwise agreed to by the Parties, with
the location of such meetings alternating between locations designated by Harpoon and locations
designated by AbbVie. The Alliance Managers shall be permitted to attend any such JGC meetings. The
chairperson of the JGC shall be responsible for calling meetings on [***] notice. Each Party shall
make all proposals for agenda items and shall provide all appropriate information with respect to
such proposed items at least [***] in advance of the applicable meeting; provided that under exigent
circumstances requiring input by the JGC, a Party may provide its agenda items to the other Party
within a shorter period of time in advance of the meeting, or may propose that there not be a
specific agenda for a particular meeting, so long as the other Party consents to such later addition
of such agenda items or the absence of a specific agenda for such meeting. The chairperson of the
JGC shall prepare and circulate for review and approval of the Parties minutes of each meeting
within [***] after the meeting. The Parties shall agree on the minutes of each meeting promptly, but
in no event later than the next meeting of the JGC.

2.2.2 Procedural Rules. The JGC shall have the right to adopt such standing rules as shall be
necessary for its work, to the extent that such rules are not inconsistent with this Agreement. A
quorum of the JGC shall exist whenever there is present at a meeting [***] appointed by each Party,
each with the requisite experience and seniority to enable such person to make decisions on behalf
of the Party it represents with respect to the issues falling within the jurisdiction of the JGC.
Representatives of the Parties on the JGC may attend a meeting either in person or by telephone,
video conference or similar means in which each participant can hear what is said by, and be heard
by, the other participants. Representation by proxy shall be allowed. The JGC shall take action by
consensus of the representatives present at a meeting at which a quorum exists, with each Party
having a single vote irrespective of the number of representatives of such Party in attendance, or
by a written resolution signed by [***] appointed by each Party. Employees or consultants of either
Party that are not representatives of the Parties on the JGC may attend meetings of the JGC;
provided that such attendees (i) shall not vote or otherwise participate in the decision-making
process of the JGC, and (ii) are bound by obligations of confidentiality and non-disclosure
equivalent to those set forth in Article 9.

2.2.3 Dispute Resolution. If the JGC cannot, or does not, reach consensus on an issue, then the
dispute shall first be referred to the Senior Officers of the Parties, who shall confer in good
faith on the resolution of the issue. Any final decision mutually agreed to by the Senior Officers
shall be conclusive and binding on the Parties. If the Senior Officers are not able to agree on the
resolution of any such issue within [***] after such issue was first referred to them, then:

(a) prior to the License Option Exercise Closing Date, the Senior Officer of Harpoon will finally
and definitively resolve such dispute [***] provided that [***]

- 19 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 24 -->
[***] or (ii) [***] and

(b) [***] Notwithstanding the foregoing, AbbVie may not, following the License Option Exercise
Closing Date, use its final decision right to amend the Initial Development Plan in any way that
would require Harpoon to perform additional activities than was required under the Initial
Development Plan immediately prior to the License Option Exercise Closing Date, unless Harpoon
agrees to perform such additional activities and AbbVie solely bears any additional expense.

As used herein, a "Material Amendment" to the Initial Development Plan shall mean an amendment to
the Initial Development Plan that would [***].

2.2.4 Limitations on Authority. Each Party shall retain the rights, powers, and discretion granted
to it under this Agreement and no such rights, powers, or discretion shall be delegated to or vested
in the JGC unless such delegation or vesting of rights is expressly provided for in this Agreement
or the Parties expressly so agree in writing. The JGC shall not have the power to amend, modify, or
waive compliance with this Agreement, which may only be amended or modified as provided in Section
13.9 or compliance with which may only be waived as provided in Section 13.12.

2.2.5 Alliance Manager. Each Party shall appoint a person(s) who shall oversee contact between the
Parties for all matters between meetings of the JGC, and shall have such other responsibilities as
the Parties may agree in writing after the Effective Date (each, an "Alliance Manager"). Following
the disbandment of the JGC after the License Option Exercise Closing Date, the Alliance Managers
shall continue to act as a liaison between the Parties and shall be responsible for exchanging
Information provided for under the terms of this Agreement. Each Party may replace its Alliance
Manager at any time by notice in writing to the other Party. Following the License Option Exercise
Closing Date and until the First Commercial Sale of a Licensed Product in a Major Market, Alliance
Managers shall meet [***], or as otherwise agreed to by the Parties.

2.3 Discontinuation of the JGC. The JGC shall continue to exist until the first to occur of: (a) the
Parties mutually agreeing to disband the JGC; (b) in the event of AbbVie's exercise of its License
Option, upon the delivery of the Final Development Report pursuant to Section 3.1.3; and (c)
expiration of the License Option Period without AbbVie exercising the License Option. Additionally,
in the event of a Change in Control of Harpoon involving a Competitor, AbbVie shall have the right
at any time and for any reason, effective upon written notice, to disband the JGC in accordance with
Section 13.2.2. In the event that the JGC is disbanded pursuant to Section 13.2.2, (a) any
information, documents or reports that a Party is otherwise required to provide to the JGC pursuant
to this Agreement shall be provided directly to the other Party and (b) any matters delegated to the
JGC shall be made by mutual agreement of the Parties, subject to the dispute resolution provisions
of Section 2.2.3.

2.4 Interactions Between the JGC and Internal Teams. The Parties recognize that each Party possesses
an internal structure (including various committees, teams and review boards) that will

- 20 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 25 -->
be involved in administering such Party's activities under this Agreement. Nothing contained in this
Article shall prevent a Party from making routine day-to-day decisions relating to the conduct of
those activities for which it has a performance or other obligations hereunder, in each case in a
manner consistent with the then-current Initial Development Plan and the terms and conditions of
this Agreement.

2.5 CMC Working Group. Within [***] after the Effective Date, the Parties shall establish a CMC
working group (the "CMC Working Group"). The CMC Working Group shall consist of two (2)
representatives from each of the Parties, each with the requisite experience and seniority to enable
such person to make decisions on behalf of the Parties with respect to the issues falling within the
jurisdiction of the CMC Working Group. From time to time, each Party may substitute one (1) or more
of its representatives to the CMC Working Group on written notice to the other Party. In particular,
the CMC Working Group shall:

(a) review and approve [***] with respect thereto, and review and approve amendments thereto; and

(b) perform such other functions as are set forth herein or as the Parties may mutually agree in
writing, except where in conflict with any provision of this Agreement.

2.6 Working Groups. In addition to the CMC Working Group, from time to time, the JGC may establish
and delegate duties to sub-committees or directed teams (each, a "Working Group") on an "as-needed"
basis to oversee particular projects or activities (for example, joint project team, joint finance
group, and/or joint intellectual property group). Each such Working Group shall be constituted and
shall operate as the JGC determines; provided that each Working Group shall have equal
representation from each Party, unless otherwise mutually agreed. Working Groups may be established
on an ad hoc basis for purposes of a specific project or on such other basis as the JGC may
determine. Each Working Group and its activities shall be subject to the oversight, review and
approval of, and shall report to, the JGC. In no event shall the authority of the Working Group
exceed that specified for the JGC. All decisions of a Working Group shall be by consensus. Any
disagreement between the designees of AbbVie and Harpoon on a Working Group shall be referred to the
JGC for resolution.

2.7 Expenses. Each Party shall be responsible for all travel and related costs and expenses for its
members and other representatives to attend meetings of, and otherwise participate on, the JGC or
any Working Group.

ARTICLE 3 DEVELOPMENT AND REGULATORY

3.1 Initial Development Plan and Activities.

3.1.1 Initial Development Plan. Either Party, directly or through its representatives on the JGC,
may propose amendments to the Initial Development Plan from time to time as appropriate, including
in light of changed circumstances. Any and all such amendments shall be subject to approval by the
JGC as set forth in Section 2.1.2, subject to the dispute resolution procedures set forth in Section
2.2.3. Within [***] of the Effective Date, the Parties, through the CMC Working Group, shall jointly
develop an amendment to the Initial Development Plan to identify the [***] in accordance with the
parameters set forth in the Initial Development Plan attached hereto as Schedule 1.84. For clarity,
all [***].

- 21 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 26 -->
3.1.2 Initial Development Activities. Harpoon shall perform the activities set forth in the Initial
Development Plan in accordance with the timelines set forth therein, [***]. In the conduct of the
Initial Development Activities, Harpoon shall use commercially reasonable efforts to ensure that
clinical sites participating in the Phase I/IB Trial timely submit Clinical Data generated at such
site into the clinical database. If at any time AbbVie has a reasonable basis to believe that
Harpoon is in material breach of its obligation to perform any Initial Development Activities, then
AbbVie may so notify Harpoon in writing, specifying the basis for its belief, and the Parties shall
meet within [***] after such notice to discuss in good faith AbbVie's concerns. If Harpoon [***]
Notwithstanding the foregoing, if Harpoon [***], then Harpoon may seek resolution on the existence
of such material breach pursuant to Section 13.7; provided that (i) Harpoon's [***]. For clarity, if
the arbitrator determines that notwithstanding [***]. The Parties acknowledge and agree that in the
event AbbVie [***] Initial Development Activities in accordance with the Initial Development Plan.
If AbbVie so elects to [***] permitted under the terms and conditions of the applicable agreement,
Harpoon shall [***].

3.1.3 Certain Amendments to Initial Development Plan. Notwithstanding the role of the JGC in
connection with amendments to the Initial Development Plan pursuant to Section 2.1.2(c) and Section
2.2.3, [***]

- 22 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 27 -->
Alliance Manager). AbbVie shall have [***] in which to consider the proposed amendments and respond
to Harpoon, following which:

(a) if AbbVie notifies Harpoon in writing that it consents to the amendments proposed by Harpoon to
the Initial Development Plan, Harpoon may proceed to resubmit the clinical portion of the Initial
Development Plan (including the clinical protocol for the Phase I/IB Trial, as applicable) to the
FDA, [***];

(b) if AbbVie requests that Harpoon provide further information in connection with the proposed
amendments, Harpoon shall [***] provide such information and make available appropriate personnel to
respond to AbbVie's questions regarding the proposed amendments, and if AbbVie notifies Harpoon in
writing following receipt of such information that it consents to the amendments as proposed by
Harpoon to the Initial Development Plan, [***];

(c) if AbbVie notifies Harpoon that it does not consent to the proposed amendments (either before or
following a request for more information under Section 3.1.3(b)), then such amendment (i) shall be
[***], (ii) shall be referred [***] to a special meeting of the JGC (or such other discussion forum
as the Parties may mutually agree in writing) and (iii) shall be subject [***], provided that solely
with respect to amendment arising under this Section 3.1.3, (A) [***], and (B) [***]; and

(d) For clarity, if AbbVie provides no response to Harpoon's proposed amendments within the
foregoing three [***] period, then [***].

By way of example only, if Harpoon provides AbbVie with a proposed amended Initial Development Plan
on [***] respectively.

3.1.4 Final Development Report. Following AbbVie's exercise of the License Option, and within [***]
after the [***], Harpoon shall provide AbbVie with the Final Development Report. AbbVie shall have
the opportunity to review and inspect the Final Development Report and to reasonably ask questions
of Harpoon and receive timely answers from Harpoon related thereto. Following AbbVie's receipt of
the Final Development Report, AbbVie shall have [***] to provide notice to Harpoon identifying any
Information set forth in Section 1.64, which

- 23 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 28 -->
AbbVie believes in good faith is not included in the Final Development Report. Harpoon shall provide
AbbVie such Information [***].

3.2 AbbVie Option.

3.2.1 Opt-In Development Report. Within [***] following the [***], Harpoon shall provide AbbVie with
the Opt-In Development Report. AbbVie shall have the opportunity to review and inspect the Opt-In
Development Report and to reasonably ask questions of Harpoon (provided that such questions are
received by Harpoon prior to [***]) and receive timely answers from Harpoon related thereto until
the expiration of the Harpoon Option Period. If, prior to the Development Report Review Deadline,
AbbVie provides written notice to Harpoon reasonably requesting supplemental data or Information
that is in Harpoon's possession or reasonably available to Harpoon (and that, in each case, can be
provided without performing any additional research, studies or material scientific analysis, or
generating any additional data) and is reasonably necessary for AbbVie to assess the Opt-In
Development Report and make an informed decision about the exercise of the License Option (such
notice to provide reasonable detail regarding the basis for such request), then Harpoon shall
provide to AbbVie such requested supplemental data or Information within [***] of its receipt of
such notice (or such longer period as the Parties may mutually agree is necessary to obtain and
provide such supplemental data or Information) and the License Option Period shall be extended to
[***] following the date of delivery of such supplemental data or Information, provided that in no
event will the License Option Period be extended as a result of such request and additional
information and data to more than [***] following the date Harpoon first provides the Opt-In
Development Report to AbbVie under this Section 3.2.1.

3.2.2 [***]. AbbVie may, but shall not be obligated to, deliver to Harpoon a written notice
requesting an [***] at any time on or after the [***]; provided that [***] within any [***] period
prior to the date of AbbVie's receipt of the Opt-In Development Report, unless any additional
request for [***] is approved by the JGC, with Harpoon's consent not to be unreasonably withheld,
conditioned or delayed. Upon Harpoon's receipt of any such notice, Harpoon shall promptly, but in
any event within [***] of Harpoon's receipt of any such notice, [***]. AbbVie shall [***]. If, prior
to the Development Report Review Deadline, AbbVie provides written notice to Harpoon reasonably
requesting supplemental data or Information that is in Harpoon's possession or reasonably available
to Harpoon (and that, in each case, can be provided without performing any additional research,
studies or material scientific analysis, or generating any additional data) and is reasonably
necessary for AbbVie to make [***] (such notice to provide reasonable detail regarding the basis for
such request), then Harpoon shall provide to AbbVie such requested supplemental data or Information
within [***] of its receipt of such notice (or such longer period as the Parties may mutually agree
is necessary to obtain and provide such supplemental data or Information). For purposes of clarity,
[***] Opt-In Development Report and shall not trigger the [***] period set forth in Section 3.2.3
with respect to the License Option Period, unless [***] shall trigger the [***] period set forth in
Section 3.2.3. If AbbVie [***].

- 24 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 29 -->
3.2.3 License Option Exercise Notice. Upon the Effective Date, Harpoon hereby grants to AbbVie the
exclusive right, but not the obligation, to obtain the licenses set forth in Section 5.1.3 (the
"License Option"). AbbVie shall have the right to exercise its License Option by providing written
notice of such election to Harpoon ("License Option Exercise Notice") at any time on or after the
Effective Date and on or prior to the date that is [***] from AbbVie's receipt of the Opt-In
Development Report containing all items required pursuant to Section 1.112, as such period may be
extended pursuant to Section 3.2.1 (the "License Option Period"). If AbbVie does not provide a
License Option Exercise Notice within the License Option Period, then (a) Harpoon shall have no
further obligations to perform any Initial Development Activities, (b) AbbVie's License Option shall
expire, and this Agreement shall terminate in accordance with Section 12.1.1, and (c) AbbVie shall
have no further rights in connection with Licensed Compounds of the Licensed Products.

3.2.4 Exercise of the License Option.

(a) AbbVie shall be deemed to have entered into the licenses set forth in Section 5.1.3 on the later
of (i) Harpoon's receipt of the License Option Exercise Notice, or (ii) the expiration or earlier
termination of any waiting period (or any extension thereof) under the HSR Act in the U.S. (the date
of such receipt by Harpoon or the date of any such expiration or earlier termination, as applicable,
the "License Option Exercise Closing Date").

(b) If AbbVie provides the License Option Exercise Notice during the License Option Period, upon
AbbVie's request, the Parties shall work together in good faith to conduct an analysis of whether
any filings or notifications are or may be required to be filed under the HSR Act (the "HSR Filing")
or any similar applicable foreign law or regulation in connection with AbbVie's exercise of the
License Option. The Parties shall each, as soon as practicable after the date of Harpoon's receipt
of the License Option Exercise Notice, file or cause to be filed with the U.S. Federal Trade
Commission and the U.S. Department of Justice and any relevant foreign governmental authority any
such notifications. The Parties shall use their commercially reasonable efforts to respond promptly
to any requests for additional information made by such agencies. For the purposes of this Section
3.2.4(b), the commercially reasonable efforts of AbbVie shall not require AbbVie to agree to any
condition, prohibition, limitation or the like proposed by the U.S. Federal Trade Commission or
other government authority to dispose of or hold separate any material portion of the business or
assets of AbbVie or its Affiliates. The Parties shall equally share the filing fees in conducting
the HSR Filing, and each Party is responsible for the costs and expenses of its own legal and other
advice in preparing and conducting the HSR Filing.

3.3 [***] At any time following the earlier of [***]. For clarity, if AbbVie's [***] shall be solely
responsible for any cost or expense associated with such additional obligations, and for providing
[***] to enable [***] in connection with the Licensed Compounds and Licensed Products prior to
AbbVie's exercise of the License Option. AbbVie may elect to exercise its option to carry

- 25 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 30 -->
out [***]and prior to the expiration of the License Option Period.

3.3.2 Upon the date AbbVie provides the [***], AbbVie shall be deemed to have entered into the
license set forth in Section 5.1.2. AbbVie shall have the right, on a one-time only basis
following[***]. AbbVie shall have final decision making authority with respect to all [***].

3.3.1 If AbbVie [***] and does not subsequently exercise the License Option, then AbbVie shall
[***]. For clarity, (A) the foregoing license shall exclude [***], and notwithstanding anything in
this Agreement to the contrary, except as necessary for Harpoon to exercise its rights under the
foregoing subclause (a) or as required by the foregoing subclause (c), [***], and (B) the
requirement under the foregoing subclause (c) shall [***] following the termination of this
Agreement.

3.4 Post-Exercise Development Activities. Following the License Option Exercise Closing Date, except
for Harpoon's responsibilities in completing the Initial Development Activities and delivering the
Final Development Report, AbbVie shall have the sole right to Develop and Manufacture (and shall
control all aspects of Development and Manufacturing), including seeking Regulatory Approvals for,
Licensed Compounds and Licensed Products in the Field and in the Territory and, for clarity, Harpoon
and its Affiliates shall have no right to do so. Following the License Option Exercise Closing Date,
AbbVie shall use Commercially Reasonable Efforts to Develop and obtain Regulatory Approval for [***]
Licensed Product for [***] for use in [***] Major Market. AbbVie shall have the right to satisfy its
diligence obligations under this Section 3.4 through its Affiliates or Sublicensees. Except as set
forth in this Section 3.4, AbbVie shall have no other diligence obligations, express or implied,
with respect to the Development of the Licensed Compounds or Licensed Products in the Territory.
Following the License Option Exercise Closing Date and until the First Commercial Sale of a Licensed
Product in a Major Market, AbbVie will provide to Harpoon following disbandment of the JGC, [***]
reports within [***] after the end of each [***], in each case summarizing the key Development
activities undertaken and summarizing the results achieved with respect to the applicable Licensed
Compounds and Licensed Products in all Major Markets during such [***]. Prior to the disbandment of
the JGC, AbbVie shall provide the JGC

- 26 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 31 -->
with interim updates on such activities and results at its regularly scheduled meetings. For
clarity, if AbbVie [***], [***] and the Final Development Report), but AbbVie shall have final
decision making authority with respect to the conduct of such Initial Development Activities;
provided that in no event may AbbVie require Harpoon to conduct any Initial Development Activities,
or to incur any costs or expenses in association with performing such Initial Development Activities
following the License Option Exercise Closing Date, in excess of the activities set forth in the
Initial Development Plan in existence immediately prior to the License Option Exercise Closing Date.
AbbVie shall have the right, at AbbVie's sole election, to assume and complete some or all of such
Initial Development Activities at AbbVie's sole cost and expense, and such step in following the
License Option Exercise Closing Date shall not [***].

3.5 Supply of Technology for Development Purposes.

3.5.1 Immediately after the License Option Exercise Closing Date, Harpoon shall, and shall cause its
Affiliates to, without additional compensation, disclose and make available to AbbVie (which
obligation may be satisfied by granting personnel designated by AbbVie controlled access to an
electronic data room), in such form as maintained by Harpoon in the ordinary course of business,
Regulatory Documentation, Harpoon Know-How, Joint Know-How, and any other Information claimed or
covered by any Harpoon Patent or Joint Patent to the extent necessary or reasonably useful for
AbbVie's Exploitation of the Licensed Compound and thereafter until the completion of the Initial
Development Activities, promptly after the earlier of the development, making, conception, or
reduction to practice of such Regulatory Documentation, Harpoon Know-How, Joint Know- How, or other
Information.

3.5.2 Immediately after the License Option Exercise Closing Date, [***], and (b) Harpoon shall
provide AbbVie with all reasonable assistance required in order to transfer to AbbVie the Regulatory
Documentation, Harpoon Know-How, Joint Know-How, and other Information required to be produced
pursuant to Section 3.5.1 above, in each case in a timely manner, and shall reasonably assist AbbVie
with respect to the Exploitation of any Licensed Compound and any Licensed Products, in each case
subject to the limitations set forth in this Section 3.5.2. At AbbVie's request, Harpoon shall
execute a bill of sale conveying such inventory. Without prejudice to the generality of the
foregoing, if visits of Harpoon's representatives to AbbVie's facilities are reasonably requested by
AbbVie for purposes of transferring the Regulatory Documentation, Harpoon Know-How, Joint Know-How,
or other Information to AbbVie or for purposes of providing AbbVie the assistance referenced in the
preceding sentence, Harpoon shall send appropriate representatives to AbbVie's facilities. Harpoon
shall provide up to [***] and AbbVie shall [***] as mutually agreed by the Parties in writing.

3.6 Expenses and Invoicing. Except as expressly set forth in this Agreement, each Party shall bear
all costs and expenses associated with the Development activities for which such Party is
responsible under this Agreement and the Initial Development Plan; provided that (a) [***],
Harpoon's obligation to bear out of pocket costs shall be limited to [***] (the "[***]") and AbbVie
shall bear any out of pocket costs in

- 27 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 32 -->
[***], and (b) [***] AbbVie has the right to assume following determination of Harpoon material
breach pursuant to Section 3.1.2. To the extent that the costs of [***], Harpoon shall provide
notice to the CMC Working Group. [***]. To the extent consistent with Harpoon's obligations under
this Section 3.6, [***] If AbbVie assumes any Initial Development Activities in accordance with
Section 3.1.2, then AbbVie shall invoice Harpoon each [***] for all reasonable direct internal (i.e.
direct personnel costs) and documented, out- of-pocket costs associated with conducting such Initial
Development Activities [***], and, Harpoon shall pay such invoices within [***] of receipt thereof.

Subcontracting.

Each Party shall have the right to subcontract any of its Development activities to a Third Party (a
"Third Party Provider"); provided that, solely with respect of Third Party Providers performing
services that are critical or material to the Licensed Compound or Licensed Products (such as
contract research organizations and contract manufacturing organizations,) Harpoon must (a) [***]
(b) except with respect to Third Party Providers [***] and (c) obtain a written undertaking from the
Third Party Provider sufficient for Harpoon to comply with the applicable terms and conditions of
this Agreement, including the confidentiality provisions of Article 9.

3.8 Regulatory Matters.

3.8.1 Pre-Exercise Regulatory Activities. Prior to the License Option Exercise Closing Date, the
following shall apply:

(a) Harpoon shall have the sole right and responsibility to prepare, obtain and maintain all INDs
necessary to perform its obligations under the Initial Development Plan, and to conduct
communications with the applicable Regulatory Authorities with respect to such INDs[***] submission
to the applicable Regulatory Authorities. Harpoon shall provide [***].

(b) Subject to the immediately following sentence, Harpoon shall provide AbbVie with (i) access to
or copies of all material written or electronic correspondence (other than regulatory filings)
relating to the Development of Licensed Compounds or Licensed Products received by Harpoon or its
Affiliates from, or forwarded by Harpoon or its Affiliates to, the Regulatory Authorities in the
Territory, and (ii) if available, copies of meeting minutes and summaries of material meetings,
conferences, and discussions held by Harpoon or its Affiliates with the Regulatory Authorities in
the Territory, in each case

- 28 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 33 -->
((i) and (ii)) [***] of its receipt, forwarding or production of the foregoing, as applicable. If
such written or electronic correspondence received from any such Regulatory Authority relates to the
withdrawal, suspension, or revocation of a Regulatory Approval for a Licensed Product, the
prohibition or suspension of the supply of a Licensed Compound or Licensed Product, or the
initiation of any investigation, review, or inquiry by such Regulatory Authority concerning the
safety of a Licensed Compound or Licensed Product, Harpoon shall notify AbbVie and provide AbbVie
with copies of such written or electronic correspondence [***] after receipt of such correspondence.

(c) Harpoon shall provide AbbVie with prior written notice, to the extent Harpoon has advance
knowledge, of any scheduled material meeting, conference, or discussion with a Regulatory Authority
in the Territory relating to a Licensed Product, [***] after Harpoon or its Affiliates first receive
notice of the scheduling of such material meeting, conference, or discussion (or within such shorter
period as may be necessary in order to give AbbVie a reasonable opportunity to attend such material
meeting, conference, or discussion). [***]

(d) For clarity, all Information provided by Harpoon to AbbVie under this Section 3.8.1 shall be the
Confidential Information of Harpoon.

3.8.2 Post-Exercise Regulatory Activities. Effective on the License Option Exercise Closing Date,
the following shall apply:

(a) Promptly after the License Option Exercise Closing Date and upon a mutually agreed upon date,
but in any event no later than [***] after the License Option Exercise Closing Date, Harpoon shall
transition to AbbVie all INDs for Licensed Compounds and Licensed Products.

(b) As between the Parties, AbbVie, at its sole expense, shall have the sole right to prepare,
obtain, and maintain the Drug Approval Applications (including the setting of the overall regulatory
strategy therefor), other Regulatory Approvals and other regulatory submissions, and to conduct
communications with the Regulatory Authorities, for Licensed Compounds or Licensed Products in the
Territory (which shall include filings of or with respect to INDs and other filings or
communications with the Regulatory Authorities). Harpoon shall support AbbVie, as may be reasonably
necessary, in obtaining Regulatory Approvals for the Licensed Products, and in the activities in
support thereof, including providing necessary documents or other materials required by Applicable
Law to obtain Regulatory Approvals, in each case in accordance with the terms and conditions of this
Agreement and the Initial Development Plan.

(c) All Regulatory Documentation (including all Regulatory Approvals and Product Labeling)
specifically relating to the Licensed Compounds or Licensed Products with respect to the Territory
shall be owned by, and shall be the sole property and held in the name of, AbbVie or its designated
Affiliate, Sublicensee or designee. Harpoon shall duly execute and deliver, or cause to be duly
executed and delivered, such instruments and shall do and cause to be done such acts and things,
including the filing of such assignments, agreements, documents, and instruments, as may be
necessary under, or as AbbVie may reasonably request in connection with, or to carry out more
effectively the purpose of, or to better assure and confirm unto AbbVie its rights under, this
Section.

3.8.3 Recalls. AbbVie shall make every reasonable effort to notify Harpoon promptly (and in any
event no later than [***]) following its determination that any event, incident, or circumstance has
occurred that may result in the need for a recall, market suspension, or market withdrawal of a
Licensed Product in the Territory, and shall include in such notice the reasoning behind such
determination, and any supporting facts. AbbVie (or its Sublicensee) shall have the right to make
the final determination whether to voluntarily implement any such recall, market suspension, or
market withdrawal in the Territory. If a recall, market suspension, or market withdrawal is mandated
by a Regulatory Authority in

- 29 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 34 -->
the Territory, AbbVie (or its Sublicensee) shall initiate such a recall, market suspension, or
market withdrawal in compliance with Applicable Law. For all recalls, market suspensions or market
withdrawals undertaken pursuant to this Section 3.8.3, AbbVie (or its Sublicensee) shall be solely
responsible for the execution thereof, and Harpoon shall reasonably cooperate in all such recall
efforts, at AbbVie's expense.

3.8.4 Compliance. Each Party shall perform or cause to be performed, any and all of its Development
activities, including Initial Development Activities, in good scientific manner and in compliance
with all Applicable Law.

3.8.5 Records. Each of Harpoon and AbbVie shall, and shall use their commercially reasonable efforts
to ensure that its Third Party Providers shall, maintain records in sufficient detail and in good
scientific manner appropriate for patent and regulatory purposes, and in compliance with Applicable
Law, which shall be complete and accurate and shall properly reflect all work done and results
achieved in the performance of its Development activities which, following the Effective Date, shall
record only such activities and shall, to the extent reasonably practicable, not include or be
commingled with records of activities outside the scope of this Agreement. Such records shall be
retained by Harpoon or AbbVie, as the case may be, for [***], or for such longer period as may be
required by Applicable Law. Following the License Option Exercise Closing Date, upon AbbVie's
request, Harpoon shall provide to AbbVie copies of the records it has maintained pursuant to this
Section 3.8.5 which have not been provided or otherwise transferred to AbbVie pursuant to Section
3.5. AbbVie shall maintain such records and the information disclosed therein in confidence in
accordance with Article 9.

3.8.6 Following the License Option Exercise Closing Date, if AbbVie reasonably considers that it has
not been provided with all Information required to be provided under Section 3.5, or in connection
with any request by a Regulatory Authority or required under Applicable Law, AbbVie shall have the
right, [***], to inspect and copy all records of Harpoon maintained pursuant to Section 3.8.5. Prior
to the License Option Exercise Closing Date, AbbVie shall not have such right to inspect or copy
Harpoon's records, except to the extent required by Applicable Laws, or as reasonably necessary to
comply with a request by a Regulatory Authority. AbbVie shall maintain such records and the
information disclosed therein in confidence in accordance with Article 9.

ARTICLE 4 COMMERCIALIZATION

4.1 In General. Effective on the License Option Exercise Closing Date, AbbVie (itself or through its
Affiliates or Sublicensees) shall have the sole right to Commercialize Licensed Compounds and
Licensed Products in the Territory at its own cost and expense.

4.2 Commercialization Diligence. Following the License Option Exercise Closing Date, AbbVie shall
use Commercially Reasonable Efforts to Commercialize [***] Licensed Product in [***] Major Market
following receipt of Regulatory Approval therefor in such Major Market; provided that [***];
provided further that, for purposes of clarity, [***].

- 30 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 35 -->
[***] If at any time Harpoon has a reasonable basis to believe that AbbVie is in material breach of
its obligations under this Section 4.2, then Harpoon may so notify AbbVie, specifying the basis for
its belief, and the Parties shall meet within [***] after such notice to discuss in good faith
Harpoon's concerns.

4.3 Booking of Sales; Distribution. Effective on the License Option Exercise Closing Date, AbbVie
shall have the sole right to invoice and book sales, establish all terms of sale (including pricing
and discounts) and warehousing, and distribute the Licensed Products in the Territory and to perform
or cause to be performed all related services. AbbVie shall handle all returns, recalls, or
withdrawals, order processing, invoicing, collection, distribution, and inventory management with
respect to the Licensed Products in the Territory.

4.4 Product Trademarks. Effective on the License Option Exercise Closing Date, AbbVie shall have the
sole right to determine and own the Product Trademarks to be used with respect to the Exploitation
of the Licensed Products on a worldwide basis. Harpoon shall not, and shall not permit its
Affiliates to, attack, dispute, or contest the validity of or ownership of such Product Trademark
anywhere in the Territory or any registrations issued or issuing with respect thereto or use in
their respective businesses, any Trademark that is confusingly similar to, misleading or deceptive
with respect to or that dilutes any (or any part) of the Product Trademarks. Notwithstanding the
foregoing, to the extent required by Applicable Law in a country or other jurisdiction in the
Territory, the promotional materials, packaging, and Product Labeling for the Licensed Products used
by AbbVie and its Affiliates in connection with the Licensed Products in such country or other
jurisdiction shall contain (a) the corporate name of Harpoon (and to the extent required, Harpoon
grants AbbVie a license, with the right to sublicense, to use the same solely for such purpose), and
(b) the logo and corporate name of the manufacturer (if other than AbbVie or an Affiliate).

4.5 Commercial Supply of Licensed Compounds or Licensed Products.

4.5.1 Commercial Supply of Licensed Compounds or Licensed Products. Effective on the License Option
Exercise Closing Date, as between the Parties, AbbVie shall have the sole right, at its expense, to
Manufacture (or have Manufactured) and supply the Licensed Compound and Licensed Products for
commercial sale in the Territory by AbbVie and its Affiliates and Sublicensees.

4.5.2 Manufacturing Technology Transfer Upon AbbVie's Request. AbbVie shall have the right, at any
time [***] the License Option Exercise Closing Date, as applicable, to require Harpoon to effect a
one-time full transfer to AbbVie or its designee (which designee may be an Affiliate or a Third
Party manufacturer of Licensed Compound or Licensed Product) of all Harpoon Know-How specifically
relating to the then-current process for the Manufacture of the Licensed Compound and Licensed
Products, including process qualification and validation, quality assurance and quality control but
excluding [***] (the "Manufacturing Process") and to implement the Manufacturing Process at a
facility designated by AbbVie (such transfer and implementation, as more fully described in this
Section 4.5.2, the "Manufacturing Technology Transfer"). Harpoon shall provide, and shall use
commercially reasonable efforts to cause its Third Party manufacturers to provide (including by
using commercially reasonable efforts to negotiate contractual obligations for such Third Party
manufacturers to do so under agreements entered into following the Effective Date), all reasonable
assistance requested by AbbVie to enable AbbVie (or its Affiliate or designated Third Party
manufacturer, as applicable) to implement the Manufacturing Process at the facility designated by
AbbVie. If requested by AbbVie, such assistance shall include providing reasonable assistance to
AbbVie to facilitate AbbVie entering into agreements with applicable Third Party suppliers relating
to the Licensed Compound and Licensed Products. Without limitation

- 31 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 36 -->
to the foregoing, in connection with the Manufacturing Technology Transfer, Harpoon shall, and shall
use commercially reasonable efforts to cause its Third Party manufacturers (including by using
commercially reasonable efforts to negotiate contractual obligations for such Third Party
manufacturers to comply with the same obligations under agreements entered into following the
Effective Date) to:

(a) make available to AbbVie (or its Affiliate or designated Third Party manufacturer, as
applicable) from time to time as AbbVie may request, all [***]to use and practice the Manufacturing
Process;

(b) cause all appropriate [***] assist with the working up and use of the Manufacturing Process
[***];

(c) without limiting the generality of Section 4.5.2(b), cause all appropriate [***] employees and
representatives of Harpoon and its Affiliates and its Third Party manufacturers to meet with
employees or representatives of AbbVie (or its Affiliate or designated Third Party manufacturer, as
applicable) at the applicable manufacturing facility and make available all necessary equipment, at
mutually convenient times, to support and execute the transfer of all applicable analytical methods
and the validation thereof (including, all applicable Harpoon Know-How, methods, validation
documents and other documentation, materials and sufficient supplies of all primary and other
reference standards);

(d) take such steps as are necessary to assist in reasonable respects AbbVie (or its Affiliate or
designated Third Party manufacturer, as applicable) in obtaining any necessary licenses, permits or
approvals from Regulatory Authorities with respect to the Manufacture of the Licensed Compound and
Licensed Products at the applicable facilities; and

(e) provide such other assistance as AbbVie (or its Affiliate or designated Third Party
manufacturer, as applicable) may reasonably request to enable AbbVie (or its Affiliate or designated
Third Party manufacturer, as applicable) to use and practice the Manufacturing Process and otherwise
to Manufacture Licensed Compounds and Licensed Products.

Except to the extent that a Manufacturing Technology Transfer is requested in connection with a
breach of this Agreement, Harpoon's obligations to provide personnel and support under this Section
4.5.2 shall be limited to [***]. Thereafter, if requested by AbbVie, Harpoon shall use commercially
reasonable efforts to continue to perform such obligations; provided that AbbVie will reimburse
Harpoon for (i) [***]), and (ii) [***] For clarity,[***].

- 32 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 37 -->
4.5.3 Subsequent Manufacturing Technology Transfer. Without limiting the foregoing, if Harpoon makes
any invention, discovery, or improvement specifically relating to the Manufacture of a Licensed
Compound or a Licensed Product during the Term, Harpoon shall promptly disclose such invention,
discovery, or improvement to AbbVie, and shall, at AbbVie's request, perform technology transfer
with respect to such invention, discovery, or improvement in the same manner as provided in Section
4.5.2, provided that any such further technology transfer occurring (a) prior to the License Option
Exercise Closing Date shall be at Harpoon's sole expense and (b) after the License Option Exercise
Closing Date shall be at AbbVie's sole expense.

ARTICLE 5 GRANT OF RIGHTS

5.1 Grants to AbbVie.

5.1.1 Effective upon the date that AbbVie commences performing Initial Development Activities
pursuant to Section 3.1.2, Harpoon (on behalf of itself and its Affiliates) shall grant and hereby
grants AbbVie a co- exclusive (with Harpoon), royalty-free license, with the right to grant
sublicenses in accordance with Section 5.3, under the Harpoon Patents, the Harpoon Know-How, and
Harpoon's interests in the Joint Patents and the Joint Know-How, solely to the extent necessary for
AbbVie to conduct Initial Development Activities assumed by AbbVie in accordance with Section 3.1.2
(if any).

5.1.2 Upon the [***], Harpoon (on behalf of itself and its Affiliates) hereby grants to AbbVie a
co-exclusive (with Harpoon), royalty-free (subject to [***] [***]) license, with the right to grant
sublicenses in accordance with Section 5.3, under the Harpoon Patents, the Harpoon Know-How, and
Harpoon's interests in the Joint Patents and the Joint Know- How, to Develop and Manufacture the
Licensed Compounds and Licensed Products solely to the extent necessary for AbbVie to perform [***].
For clarity, with respect [***], AbbVie acknowledges and agrees that [***]. AbbVie further
acknowledges and agrees that no sublicense is granted to AbbVie under certain intellectual property
rights licensed from [***].

5.1.3 Upon the License Option Exercise Closing Date, Harpoon (on behalf of itself and its
Affiliates) hereby grants to AbbVie:

(a) an exclusive (including with regard to Harpoon and its Affiliates, except as provided in Section
5.6) license (or sublicense), with the right to grant sublicenses in accordance with Section 5.3,
under the Harpoon Patents, the Harpoon Know-How, and Harpoon's interests in the Joint Patents and
the Joint Know-How, to Exploit the Licensed Compounds and Licensed Products in the Field in the
Territory;

(b) an exclusive (including with regard to Harpoon and its Affiliates, except as provided in Section
5.6) license and right of reference, with the right to grant sublicenses and further rights of
reference in accordance with Section 5.3, under the Regulatory Approvals and any other Regulatory
Documentation that Harpoon or its Affiliates may Control with respect to the Licensed Compounds or
Licensed Products solely for purposes of Exploiting the Licensed Compounds and Licensed Products in
the Field in the Territory.

- 33 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 38 -->
(c) The grants set forth in this Section 5.1.3 will automatically come into full force and effect on
the License Option Exercise Closing Date without any further action required by either Party under
this Agreement.

5.2 Grants to Harpoon. Upon the Effective Date, AbbVie hereby grants to Harpoon a non-exclusive,
royalty-free license, without the right to grant sublicenses (other than to permitted subcontractors
of Harpoon in accordance with Section 3.7), under the AbbVie Patents, AbbVie Know-How, and AbbVie's
interests in the Joint Patents and the Joint Know-How, to Develop and Manufacture the Licensed
Compounds or Licensed Products in the Territory solely to the extent necessary for Harpoon to
perform its obligations as set forth in, and subject to, the Initial Development Plan.

5.3 Sublicenses. AbbVie shall have the right to grant sublicenses (or further rights of reference),
through multiple tiers of Sublicensees, under the licenses and rights of reference granted in
Sections 5.1.1, 5.1.2 and 5.1.3, to its Affiliates and other Persons; provided that any such
sublicenses shall be consistent with the terms and conditions of this Agreement and AbbVie shall
remain liable for its obligations under this Agreement and for the performance of all Sublicensees.
AbbVie shall provide Harpoon with a copy of any such sublicense agreement within [***] after the
execution thereof, which copy may be redacted with respect to information not pertinent to
compliance with this Agreement.

5.4 Distributorships. AbbVie shall have the right, in its sole discretion, to appoint its
Affiliates, and AbbVie and its Affiliates shall have the right, in their sole discretion, to appoint
any other Persons, in the Territory or in any country or other jurisdiction of the Territory, to
distribute, market, and sell the Licensed Products. Where AbbVie or its Affiliates appoints such a
Person and such Person is not an Affiliate of AbbVie and does not have rights to, and does not,
Manufacture any Licensed Product (except solely to package or label such Licensed Product purchased
in bulk form from AbbVie or its Affiliates), that Person shall be a "Distributor" for purposes of
this Agreement.

5.5 Co-Promotion Rights. For purposes of clarity, AbbVie and its Affiliates shall have the right, in
their sole discretion, to co-promote the Licensed Products with any other Person(s), or to appoint
one (1) or more Third Parties to promote the Licensed Products without AbbVie in all or any part of
the Territory.

5.6 Retention of Rights.

5.6.1 Notwithstanding the exclusive licenses granted to AbbVie pursuant to Section 5.1.3, Harpoon
retains the right to practice under the Harpoon Patents, the Harpoon Know-How, Harpoon's interests
in the Joint Patents and the Joint Know-How, Regulatory Approvals and any other Regulatory
Documentation (a) to perform (and to sublicense Third Parties to perform as permitted hereunder) its
obligations under this Agreement and (b) for any purpose outside the scope of the licenses and
rights granted pursuant to Sections 3.2.3 and 5.1, including to Exploit any products or services
other than Licensed Compounds or Licensed Products, subject to Section 5.8. Except as expressly
provided herein, Harpoon grants no other right or license, including any rights or licenses to the
Harpoon Patents, the Harpoon Know-How, Harpoon's interests in the Joint Patents and Joint Know-How,
the Regulatory Documentation or any other Patent or intellectual property rights not otherwise
expressly granted herein. For clarity, if AbbVie does not exercise its License Option, Harpoon
retains all rights under Harpoon's interests in the Joint Patents and the Joint Know-How, if any, to
Exploit the Licensed Compounds and Licensed Products in its sole discretion without duty to account
to AbbVie in connection with such use or Exploitation.

5.6.2 Except as expressly provided herein, AbbVie grants no other right or license, including any
rights or licenses to the AbbVie Patents, the AbbVie Know-How, the Regulatory Documentation, or any
other Patent or intellectual property rights not otherwise expressly granted herein.

5.7 Confirmatory Patent License. Harpoon shall if requested to do so by AbbVie immediately enter
into confirmatory license agreements consistent with this Agreement in the form or substantially the
form reasonably requested by AbbVie for purposes of recording the licenses granted under

- 34 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 39 -->
this Agreement with such patent offices in the Territory as AbbVie considers appropriate. Until the
execution of any such confirmatory licenses, so far as may be legally possible, Harpoon and AbbVie
shall have the same rights in respect of the Harpoon Patents and Joint Patents and be under the same
obligations to each other in all respects as if the said confirmatory licenses had been executed.

5.8 Exclusivity with Respect to the Territory.

5.8.1 Harpoon shall not, and shall cause its Affiliates not to (a) directly or indirectly, develop,
commercialize or otherwise exploit any Competing Product in any country or other jurisdiction in the
Territory, or (b) license, authorize, appoint, or otherwise enable any Third Party to directly or
indirectly, develop, commercialize or otherwise exploit any Competing Product in any country or
other jurisdiction in the Territory, except, in each case ((a) and (b)), as otherwise expressly
provided in this Agreement.

5.8.2 Notwithstanding the provisions of Section 5.8, if, during the Term, (a) Harpoon or any of its
Affiliates acquires, as the result of an Acquisition, rights to a Competing Product, such
Acquisition, and the development, manufacture or commercialization of such Competing Product
thereafter, shall not constitute a breach of Section 5.8 if Harpoon or such Affiliate, as
applicable, [***]; or (b) Harpoon undergoes a Change in Control and the relevant acquirer is either
then commercializing a Competing Product, or has in development any Competing Product, such Change
in Control, and the commercialization (or development and subsequent commercialization, if such
Competing Product receives Regulatory Approval) of such Competing Product by such relevant acquirer
or any of its Affiliates, shall not constitute a breach of Section 5.8; provided that such (x)
acquirer Segregates the Competing Product and (y) AbbVie shall have the right, in its sole and
absolute discretion, by written notice delivered to Harpoon (or its successor) at any time during
the [***] following the written notice contemplated by Section 13.2.1, to (i) terminate any or all
provisions of this Agreement providing for any delivery by AbbVie to Harpoon of Confidential
Information of AbbVie relating to activities contemplated by this Agreement, save only for (A)
Article 6, (B) information regarding sublicenses pursuant to Section 5.3, (C) information regarding
the prosecution, enforcement, defense, litigation, infringement and licensing of Patents pursuant to
(1) Sections 7.2.1, 7.2.3, 7.3.1, 7.3.5, 7.4, and 7.5.2, (2) solely with respect to Joint Patents,
Sections 7.2.2, 7.3.2, and 7.5.3, and (3) solely with respect to Joint Patents and Harpoon Patents,
Sections 7.3.4 and 7.5.1, (D) notice of any license pursuant to Section 5.9.2, (E) safety data
pursuant to Section 8.1, (F) proposed disclosures pursuant to Section 9.5, (G) communications under
Section 11.4 and (H) notices pursuant to Sections 11.3 and 13.1; and (ii) disband the JGC and
terminate its activities, in which case the provisions set forth in the last sentence of Section 2.3
shall apply.

5.9 In-License Agreements.

5.9.1 During the Term, neither Harpoon nor any of its Affiliates shall, [***], not to be
unreasonably withheld, conditioned or delayed, enter into any agreement with a Third Party related
to Information, Regulatory Documentation, materials, Patents, or other intellectual other property
rights [***].

5.9.2 Following the License Option Exercise Closing Date, if [***] owned or controlled by a Third
Party in a particular country or jurisdiction is necessary to Exploit a Licensed Compound or
Licensed Product, AbbVie shall have the first right, but not the obligation, to negotiate and enter
into an agreement with a Third Party in order to obtain a license or right under such Patent or
intellectual property right. If AbbVie elects (in a written communication submitted to Harpoon) not
to enter into any such agreement, Harpoon may enter into any such agreement. Notwithstanding the
foregoing, if a [***] owned or controlled by a Third Party is [***]

- 35 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 40 -->
[***], then [***] the costs associated with any such license to the Patent or other intellectual
property right of such Third Party ("AbbVie [***] Rights").

5.9.3 If Harpoon or any of its Affiliates, after the Effective Date, become a party to a license,
sublicense or other agreement for [***], or as permitted in Sections 5.9.1 or 5.9.2, then Harpoon
shall inform AbbVie and shall provide AbbVie with a copy of such license, sublicense, or other
agreement ("Proposed Future In-Licensed Rights"). If AbbVie notifies Harpoon in writing within [***]
after receipt of such copy that AbbVie wishes to receive a license or sublicense (as applicable)
under, and be subject to the rights and obligations of, the Proposed Future In-Licensed Rights as
they apply to AbbVie and this Agreement, then the Proposed Future In-Licensed Rights shall
automatically be included in the Harpoon Patents and/or Harpoon Know-How (as applicable) hereunder
and AbbVie agrees to abide by all applicable terms and conditions of such license, sublicense or
other agreement, as it relates to AbbVie and this Agreement, including payment of any financial
obligations based upon AbbVie's practice of such intellectual property rights. Effective on and
following the License Option Exercise Closing Date, AbbVie shall be solely responsible for payment
of any financial obligations under [***], and any license, sublicense or other agreement AbbVie
elects to enter into with a Third Party that grants rights to AbbVie in connection with the
Manufacture of a Licensed Compound or Licensed Product. Except as provided in this Section 5.9.3,
Harpoon shall be solely responsible for and shall bear any and all payments under any Harpoon
In-License Agreements, including any agreement between Harpoon and a Third Party entered prior to or
on the Effective Date. For the purpose of clarity, AbbVie shall not be responsible for [***], or (b)
[***] relating to the manufacture of any compound or product other than the Licensed Compounds and
Licensed Products.

ARTICLE 6 PAYMENTS AND RECORDS

6.1 Upfront Payment. No later than [***] following the Effective Date, AbbVie shall pay Harpoon an
upfront, non-refundable, non-creditable amount equal to Thirty Million Dollars ($30,000,000).

6.2 Development and Regulatory Milestones. In partial consideration of the rights granted by Harpoon
to AbbVie hereunder and subject to the terms and conditions set forth in this Agreement, AbbVie
shall pay to Harpoon a non-refundable milestone payment within [***] after the achievement of each
of the following milestones, calculated as follows:

6.2.1 upon the License Option Exercise Closing Date, Two Hundred Million Dollars ($200,000,000);

6.2.2 upon first Initiation of the Phase I/IB Trial under the Initial Development Plan for a
Licensed Compound in the U.S., Fifty Million Dollars ($50,000,000); provided that subject to Section
3.1.3, (a) if [***] [***], but [***], this milestone payment shall be [***], and (b) if such [***]
occurs on or after [***], this milestone payment shall be [***];

6.2.3 upon [***], [***];

- 36 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 41 -->
6.2.4 upon [***], [***]; and

6.2.5 upon [***] and [***], [***].

Each milestone payment in this Section 6.2 shall be payable only upon the first achievement of such
milestone and no amounts shall be due for subsequent or repeated achievements of such milestone,
whether for the same or a different Licensed Compound or Licensed Product. The maximum aggregate
amount payable by AbbVie pursuant to this Section 6.2 is [***].

6.3 First Commercial Sales Milestones. In partial consideration of the rights granted by Harpoon to
AbbVie hereunder and subject to the terms and conditions set forth in this Agreement, AbbVie shall
pay to Harpoon the following non-refundable milestone payments due within [***] after the
achievement of each of the following milestones, calculated as follows:

6.3.1 upon [***] Licensed Product, [***]; and

6.3.2 upon the First Commercial Sale for the first Licensed Product to achieve such [***], [***].

Each milestone payment in this Section 6.3 shall be payable only upon the first achievement of such
milestone and no amounts shall be due for subsequent or repeated achievements of such milestone,
whether for the same or a different Licensed Compound or Licensed Product. The maximum aggregate
amount payable by AbbVie pursuant to this Section 6.3 is [***].

6.4 Sales-Based Milestones. In partial consideration of the rights granted by Harpoon to AbbVie
hereunder and subject to the terms and conditions set forth in this Agreement, AbbVie shall pay to
Harpoon the following non- refundable milestone payments due within [***] after the end of the [***]
in which such milestone was achieved for the aggregate sales of all Licensed Products in the
Territory, calculated as follows:[***].

Each milestone payment in this Section 6.4 shall be payable only upon the first achievement of such
milestone in a [***], and no amounts shall be due for subsequent or repeated achievements of such
milestone in subsequent [***], whether for the same or a different Licensed Compound or Licensed
Product. The maximum aggregate amount payable by AbbVie pursuant to this Section is [***].

6.5 Royalties.

- 37 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 42 -->
6.5.1 Royalty Rates. As further consideration for the rights granted to AbbVie hereunder, subject to
Section 6.5.3, commencing upon the First Commercial Sale of a Licensed Product in the Territory, on
a Licensed Product- by-Licensed Product basis, AbbVie shall pay to Harpoon a royalty on Net Sales of
each Licensed Product in the Territory (excluding Net Sales of each Licensed Product in any country
or other jurisdiction in the Territory for which the Royalty Term for such Licensed Product in such
country or other jurisdiction has expired) during [***] at the following rates:

Net Sales in the Territory of each Licensed Product in a [***] Royalty Rate

For that portion of aggregate Net Sales of each Licensed Product[***] [***]

For that portion of aggregate Net Sales of each Licensed Product[***] [***]

For that portion of aggregate Net Sales of each Licensed Product[***] [***]

With respect to each Licensed Product in each country or other jurisdiction in the Territory, [***].

6.5.2 Royalty Term. AbbVie shall have no obligation to pay any royalty with respect to Net Sales of
any Licensed Product in any country or other jurisdiction after the Royalty Term for such Licensed
Product in such country or other jurisdiction has expired.

6.5.3 Reductions. Notwithstanding the foregoing:

(a) if in any country or other jurisdiction in the Territory during the Royalty Term for a Licensed
Product (i) there is [***], then for each such country or other jurisdiction, starting with the
[***] occurs, the royalties payable to Harpoon for the Net Sales of such Licensed Product in such
country or other jurisdiction shall be [***] set forth in Section 6.5.1; (ii) there [***], then for
each such country or other jurisdiction, starting with the [***], the royalties payable to Harpoon
for the Net Sales of such Licensed Product in such country or other jurisdiction shall be [***] set
forth in Section 6.5.1; and (iii) if for any [***] during the Royalty Term [***] in such country or
other jurisdiction during such [***], then the royalties due to Harpoon pursuant to this Section 6.5
in such country or other jurisdiction shall be [***] in each such [***]. For purposes herein, (A)
[***] (B) [***]

- 38 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 43 -->
[***] in each case ((A) and (B)) of the unit sales of such Licensed Product sold in that country or
other jurisdiction by AbbVie, its Affiliates and Sublicensees. Unless otherwise agreed by the
Parties, [***] sold during a [***] shall be as reported by [***] or any successor or any other
independent sales auditing firm reasonably agreed upon by the Parties;

(b) if AbbVie enters into an agreement with a Third Party in order to obtain a license or right
under [***] owned or controlled by such Third Party in a particular country or other jurisdiction
pursuant to Section 5.9.2, AbbVie shall be entitled to deduct from [***] hereunder with respect to a
Licensed Product for a particular country or other jurisdiction [***] of [***] paid to such Third
Party (excluding [***]) as consideration for the grant of the license or sublicense in connection
with such Licensed Product (and to the extent reasonably allocable to the Licensed Product, if such
Third Party agreement is also applicable to other programs or products of AbbVie) for such country
or other jurisdiction; provided that in no case shall such deduction reduce such [***] set forth in
[***] [***]. For clarity, no reduction shall apply in connection with payments made by AbbVie in
connection with any [***];

(c) [***] in a country or other jurisdiction in the Territory, then, for the purposes of calculating
the royalties payable with respect to such Licensed Product under Section 6.5.1, [***]; and

(d) if, and in such case from and after the date on which, a Licensed Product is Exploited in a
country or other jurisdiction and such Licensed Product is not either or both (i) [***] or (ii)
covered by (A) [***] Licensed Product in such country or other jurisdiction or (B) a [***] in such
country or other jurisdiction, then the royalty rate set forth in Section 6.5.1 with respect to such
country or other jurisdiction (for purposes of calculations under Section 6.5.1), shall be reduced
by [***];.

(e) In no event will the cumulative reductions under the foregoing Sections 6.5.3(a) through
6.5.3(d) reduce the [***] payable to Harpoon on any Licensed Product in any [***] by greater than
[***] of the amounts otherwise payable under Section 6.5.1 for such Licensed Product. Credits not
exhausted in any [***] may be carried into future [***], subject to the foregoing sentence.

6.6 Royalty Payments and Reports. AbbVie shall calculate all amounts payable to Harpoon pursuant to
Section 6.5 at the end of each [***], which amounts shall be converted to Dollars, in accordance
with Section 6.7. AbbVie shall pay to Harpoon the royalty amounts due with respect to a given [***]
within [***] after the end of such [***]. Each payment of royalties due to Harpoon shall be
accompanied by a statement of the amount of Net Sales of each Licensed Product in each country or
other jurisdiction the Territory during the applicable [***] (including such amounts expressed in
local currency and as converted to Dollars) and a calculation of the amount of royalty payment due
on such Net Sales for such [***], including the amount of any reductions pursuant to Section 6.5.3.

6.7 Mode of Payment; Offsets. All payments to either Party under this Agreement shall be made by
deposit of Dollars in the requisite amount to such bank account as the receiving Party may from

- 39 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 44 -->
time to time designate by notice to the paying Party. For the purpose of calculating any sums due
under, or otherwise reimbursable pursuant to, this Agreement (including the calculation of Net Sales
expressed in currencies other than Dollars), a Party shall convert any amount expressed in a foreign
currency into Dollar equivalents using its, its Affiliate's or Sublicensee's standard conversion
methodology consistent with Accounting Standards. [***].

6.8 Withholding Taxes.

6.8.1 Withholding Amounts. Where any sum due to be paid to either Party hereunder is subject to any
withholding or similar tax, the Parties shall use their commercially reasonable efforts to do all
such acts and things and to sign all such documents as will enable them to take advantage of any
applicable double taxation agreement or treaty. In the event there is no applicable double taxation
agreement or treaty, or if an applicable double taxation agreement or treaty reduces but does not
eliminate such withholding or similar tax, the payor shall remit such withholding or similar tax to
the appropriate government authority, deduct the amount paid from the amount due to payee and secure
and send to payee the best available evidence of the payment of such withholding or similar tax. Any
such amounts deducted by the payor in respect of such withholding or similar tax shall be treated as
having been paid by the payor for purposes of this Agreement. If withholding or similar taxes are
paid to a government authority, each Party will provide the other such assistance as is reasonably
required to obtain a refund of the withheld or similar taxes, or to obtain a credit with respect to
such taxes paid. In the event that a government authority retroactively determines that a payment
made by the paying Party to the receiving Party pursuant to this Agreement should have been subject
to withholding or similar (or to additional withholding or similar) taxes, and such paying Party
(the "Withholding Party") remits such withholding or similar taxes to the government authority,
including any interest and penalties that may be imposed thereon (together with the tax paid, the
"Withholding Amount"), the Withholding Party will have the right (a) to offset the Withholding
Amount against future payment obligations of the Withholding Party under this Agreement or (b) to
invoice the receiving Party for the Withholding Amount (which shall be payable by the receiving
Party within [***] of its receipt of such invoice), or to pursue reimbursement of the Withholding
Amount by any other available remedy.

6.8.2 Withholding Actions. Notwithstanding the foregoing, the Parties acknowledge and agree that if
AbbVie (or its assignee pursuant to Section 13.4) is required by Applicable Law to withhold taxes in
respect of any amount payable under this Agreement, and if such withholding obligation arises as a
result of any action taken by AbbVie or its Affiliate or successor or assignee, including without
limitation an assignment of this Agreement as permitted under Section 13.4 of this Agreement, a
change in tax residency of AbbVie, or payments arise or are deemed to arise through a branch of
AbbVie and such withholding taxes exceed the amount of withholding taxes that would have been
applicable if such action had not occurred (each an "AbbVie Withholding Tax Action"), then, any such
amount payable shall be increased to take into account such increased withholding taxes as may be
necessary so that, after making all required withholdings Harpoon (or its assignee pursuant to
Section 13.4) receives an amount equal to the sum it would have received had no such AbbVie
Withholding Tax Action occurred. Harpoon shall (a) use its commercially reasonable efforts to obtain
an exemption of such withheld amounts to the extent practicable under Applicable Law and (b)
cooperate with AbbVie to obtain a reduction or refund of such withheld amounts.

6.9 Indirect Taxes. Except as otherwise provided in this Agreement, all payments due under this
Agreement are exclusive of value added taxes, sales taxes, consumption taxes and other similar taxes
(the "Indirect Taxes"). Notwithstanding anything to the contrary in this Agreement, AbbVie shall be
responsible for any Indirect Taxes as well as any transfer, documentary, sales use, stamp,
registration, value added or other similar tax that is imposed with respect to the payments or the
related transfer of rights or other property pursuant to the terms of this Agreement. If the
Indirect Taxes originally paid or otherwise borne by the paying Party are in whole or in part
subsequently determined not to have been chargeable, all reasonably necessary steps will be taken by
the receiving Party to receive a refund of these undue Indirect Taxes from the

- 40 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 45 -->
applicable governmental authority or other fiscal authority and any amount of undue Indirect Taxes
repaid by such authority to the receiving Party will be transferred to the paying Party within [***]
of receipt.

6.10 Interest on Late Payments. If any payment due to either Party under this Agreement is not paid
when due, then such paying Party shall pay interest thereon (before and after any judgment) at [***]
such interest to run from the date on which payment of such sum became due until payment thereof in
full together with such interest; provided however that [***], then such interest [***], as adjusted
from time to time on the [***].

6.11 Audit. AbbVie shall, shall cause its Affiliates to, and shall use commercially reasonable
efforts to cause its Sublicensees to, keep complete and accurate books and records pertaining to Net
Sales of Licensed Products, in sufficient detail to calculate all amounts payable hereunder. At the
request of Harpoon, AbbVie shall permit an independent public accounting firm of nationally
recognized standing designated by Harpoon and reasonably acceptable to AbbVie, [***], to audit the
books and records maintained pursuant to this Section 6.11 to ensure the accuracy of all reports and
payments made hereunder, including any permitted deductions from Net Sales pursuant to Section
1.108. Such examinations may not (a) be conducted for any [***] [***] (b) be conducted more than
once in any [***] period or (c) be [***] (unless a previous audit revealed an underpayment with
respect to such [***]). The accounting firm shall disclose to Harpoon only whether the reports are
correct or not, and the specific details concerning any discrepancies. No other information shall be
shared. Except as provided below, the cost of this audit shall be borne by Harpoon, unless the audit
reveals a variance [***] from the reported amounts or [***], in which case AbbVie shall bear the
cost of the audit.

6.12 Audit Dispute. In the event of a dispute with respect to any audit under Section 6.11, Harpoon
and AbbVie shall work in good faith to resolve the disagreement. If the Parties are unable to reach
a mutually acceptable resolution of any such dispute within [***], the dispute shall be submitted
for resolution to a certified public accounting firm jointly selected by each Party's certified
public accountants or to such other Person as the Parties shall mutually agree (the "Audit Expert").
The decision of the Audit Expert shall be final and the costs of such determination as well as the
initial audit shall be borne between the Parties in such manner as the Audit Expert shall determine.
Not later than [***] after such decision and in accordance with such decision, AbbVie shall pay the
additional amounts or Harpoon shall reimburse the excess payments, as applicable.

6.13 Confidentiality. The receiving Party shall treat all information subject to review under this
Article 6 in accordance with the confidentiality provisions of Article 9 and the Parties shall cause
the Audit Expert to enter into a reasonably acceptable confidentiality agreement with AbbVie
obligating such firm to retain all such financial information in confidence pursuant to such
confidentiality agreement.

6.14 [***] The development and regulatory milestone payments, first commercial sales milestone
payments, sales-based milestone payments and royalties in Sections 6.2, 6.3 6.4, and 6.5 shall not
apply at the same rates to Development and Commercialization of Licensed Compounds or Licensed
Products [***] for eligibility to be treated for such disease, state, or condition with a Licensed
Compound or Licensed Product or for monitoring patients who are or have been treated with a Licensed
Compound or Licensed Product. In the event that a Licensed Compound or Licensed Product is Developed
for any such purposes, [***] for the sale of such Licensed Product that [***] of such Licensed
Product and [***], as applicable; provided that, for clarity, any such [***]

- 41 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 46 -->
[***] [***] under this Agreement with respect to Licensed Compounds or Licensed Products that are
[***].

6.15 No Other Compensation. Each Party hereby agrees that the terms of this Agreement fully define
all consideration, compensation and benefits, monetary or otherwise, to be paid, granted or
delivered by one Party to the other Party in connection with the transactions contemplated herein.
Neither Party previously has paid or entered into any other commitment to pay, whether orally or in
writing, any of the other Party's employees, directly or indirectly, any consideration, compensation
or benefits, monetary or otherwise, in connection with the transaction contemplated herein.

ARTICLE 7 INTELLECTUAL PROPERTY

7.1 Ownership of Intellectual Property.

7.1.1 Ownership of Technology. Subject to Section 3.8.2(c) and Section 7.1.2, as between the
Parties, each Party, or their respective Affiliates, shall own and retain all right, title, and
interest in and to any and all: (a) Information and inventions that are conceived, discovered,
developed, or otherwise made by or on behalf of such Party or its Affiliates (including
subcontractors thereof) under or in connection with this Agreement, whether or not patented or
patentable, and any and all Patents and other intellectual property rights with respect thereto,
except to the extent that any such Information or invention or any Patent or intellectual property
rights with respect thereto, is Joint Know-How or Joint Patents, and (b) other Information,
inventions, Patents, and other intellectual property rights that are owned or otherwise Controlled
(other than pursuant to the license grants set forth in Sections 5.1 and 5.2) by such Party or its
Affiliates.

7.1.2 Ownership of Joint Patents and Joint Know-How. Subject to Section 3.8.2(c), as between the
Parties, each Party, or their respective Affiliates, shall own an equal, undivided interest in and
to any and all (a) Information and inventions that are conceived, discovered, developed or otherwise
made jointly by or on behalf of Harpoon or its Affiliates (including subcontractors thereof), on the
one hand, and AbbVie or its Affiliates (including subcontractors thereof), on the other hand, in
connection with the work conducted under or in connection with this Agreement, in each case whether
or not patented or patentable (the "Joint Know-How"), and (b) Patents (the "Joint Patents") and
other intellectual property rights with respect to the Information and inventions described in
subclause (a) (together with Joint Know-How and Joint Patents, the "Joint Intellectual Property
Rights"). Each Party shall promptly disclose to the other Party in writing, and shall cause its
Affiliates, licensees and sublicensees to so disclose, the development, making, conception or
reduction to practice of any Joint Know-How or Joint Patents. Subject to the licenses and rights of
reference granted under Sections 5.1 and 5.2 and, in the case of Harpoon, its exclusivity
obligations hereunder, each Party shall have the right to Exploit the Joint Intellectual Property
Rights without a duty of seeking consent from or accounting to the other Party. Notwithstanding the
foregoing, with respect to (1) any [***], and (2) any [***].

7.1.3 United States Law. The determination of whether Information and inventions are conceived,
discovered, developed, or otherwise made by a Party for the purpose of allocating proprietary rights
(including Patent, copyright or other intellectual property rights) therein, shall, for purposes of
this Agreement, be made in accordance with Applicable Law in the United States.

- 42 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 47 -->
7.1.4 Assignments.

(a) Each Party shall cause all Persons who perform activities for such Party under this Agreement to
prospectively or be under an obligation to assign (or, if Applicable Law does not permit such Person
to agree to such assignment obligation despite such Party's using commercially reasonable efforts to
negotiate such assignment obligation, provide a license under) all of their rights in any
Information and inventions resulting therefrom to such Party, except where Applicable Law requires
otherwise and except in the case of governmental, not-for-profit and public institutions which have
standard policies against such an assignment (in which case a suitable license, or right to obtain
such a license, shall be obtained).

(b) Each Party will promptly disclose to the other Party in writing, the conception, discovery,
development or making of any Joint Know-How or Joint Patents by Persons who perform activities for
it under this Agreement. Each Party will execute and record assignments and other necessary
documents consistent with such ownership promptly upon request.

7.2 Maintenance and Prosecution of Patents.

7.2.1 Patent Prosecution and Maintenance of Harpoon Patents and Joint Patents.

(a) Subject to Section 7.2.1(b), Harpoon shall have the right, but not the obligation, through the
use of internal or outside counsel to prepare, file, prosecute, and maintain the Harpoon Patents and
Joint Patents worldwide, at Harpoon's sole cost and expense. Where a Harpoon Patent or Joint Patent
[***]. Harpoon shall [***] with regard to the preparation, filing, prosecution, and maintenance of
such Harpoon Patents or Joint Patents, including by providing AbbVie with a copy of material
communications to and from any patent authority in the Territory regarding such Harpoon Patents or
Joint Patents, and by providing AbbVie drafts of any material filings or responses to be made to
such patent authorities in the Territory sufficiently in advance of submitting such filings or
responses so as to allow for a reasonable opportunity for AbbVie to review and comment thereon.
Harpoon shall consider in good faith the requests and suggestions of AbbVie with respect to such
drafts and with respect to strategies for filing and prosecuting such Harpoon Patents or Joint
Patents in the Territory. Notwithstanding the foregoing, Harpoon shall promptly inform AbbVie of any
adversarial patent office proceeding or sua sponte filing, including a request for, or filing or
declaration of, any interference, opposition, or re-examination relating to a Harpoon Patent or
Joint Patent in the Territory. The Parties shall thereafter consult and cooperate to determine a
course of action with respect to any such proceeding in the Territory and Harpoon shall consider in
good faith all comments, requests and suggestions provided by AbbVie. [***] If Harpoon decides not
to prepare, file, prosecute, or maintain a Harpoon Patent or Joint Patent in a country or other
jurisdiction in the Territory, Harpoon shall provide reasonable prior written notice to AbbVie of
such intention (which notice shall, in any event, be given no later than [***] prior to the next
deadline for any action that may be taken with respect to such Harpoon Patent or Joint Patent in
such country or other jurisdiction), AbbVie shall thereupon have the option, in its sole discretion,
to assume the control and direction of the preparation, filing, prosecution, and maintenance of such
Harpoon Patent or Joint Patent at its expense in such country or other jurisdiction. Upon AbbVie's
written acceptance of such option, AbbVie shall assume the responsibility and control for the
preparation, filing, prosecution, and maintenance of such Harpoon Patent or Joint Patent. In such
event, Harpoon shall reasonably cooperate with AbbVie in such country or other jurisdiction as
provided under Section 7.2.3.

(b) On and after the License Option Exercise Closing Date with respect to a Licensed Compound or
Licensed Product, AbbVie shall have the responsibility for and control over the

- 43 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 48 -->
preparation, filing, prosecution, and maintenance of all Harpoon Patents that
[***]("Product-Specific Patents") and Joint Patents, at AbbVie's sole cost and expense. For clarity,
Product-Specific Patents shall not include [***], including any Patent that [***] as long as such
Harpoon Patent does not include any claim [***]. AbbVie shall keep Harpoon fully informed of all
material steps with regard to the preparation, filing, prosecution, and maintenance of
Product-Specific Patents or Joint Patents. If AbbVie decides not to prepare, file, prosecute, or
maintain a Product-Specific Patent or Joint Patent in a country or other jurisdiction in the
Territory, AbbVie shall provide reasonable prior written notice to Harpoon of such intention (which
notice shall, in any event, be given no later than [***] prior to the next deadline for any action
that may be taken with respect to such Product-Specific Patent or Joint Patent in such country or
other jurisdiction), and Harpoon shall thereupon have the option, in its sole discretion, to assume
the control and direction of the preparation, filing, prosecution, and maintenance of such
Product-Specific Patent or Joint Patent at its sole cost and expense in such country or other
jurisdiction. Upon Harpoon's written acceptance of such option, Harpoon shall assume the
responsibility and control for the preparation, filing, prosecution, and maintenance of such
specific Product-Specific Patent or Joint Patent. In such event, AbbVie shall reasonably cooperate
with Harpoon in such country or other jurisdiction as provided under Section 7.2.3.

7.2.2 Patent Prosecution and Maintenance of AbbVie Patents. AbbVie shall have the right, but not the
obligation, to prepare, file, prosecute, and maintain the AbbVie Patents worldwide, at AbbVie's sole
cost and expense.

7.2.3 Cooperation. The Parties agree to cooperate fully in the preparation, filing, prosecution, and
maintenance of the Harpoon Patents and Joint Patents in the Territory under this Agreement.
Cooperation shall include:

(a) without limiting any other rights and obligations of the Parties under this Agreement,
cooperating with respect to the timing, scope and filing of such Patents to preserve and enhance the
patent protection for Licensed Compounds and Licensed Products, including the manufacture and use
thereof;

(b) executing all papers and instruments, or requiring its employees or contractors to execute such
papers and instruments, so as to (i) effectuate the ownership of intellectual property set forth in
Section 7.1.1 and 7.1.2; (ii) enable the other Party to apply for and to prosecute Patent
applications in the Territory; and (iii) obtain and maintain any Patent extensions, supplementary
protection certificates, and the like with respect to the Harpoon Patents and Joint Patents in the
Territory, in each case ((i), (ii), and (iii)) to the extent provided for in this Agreement;

(c) consistent with this Agreement, assisting in any license registration processes with applicable
governmental authorities that may be available in the Territory for the protection of a Party's
interests in this Agreement; and

(d) promptly informing the other Party of any matters coming to such Party's attention that may
materially affect the preparation, filing, prosecution, or maintenance of any such Patents in the
Territory.

7.2.4 Patent Term Extension and Supplementary Protection Certificate. AbbVie shall be responsible
for making decisions regarding patent term extensions, including supplementary protection
certificates and any other extensions that are now or become available in the future, wherever
applicable, for AbbVie Patents, Joint Patents and Product- Specific Patents in any country or other
jurisdiction

- 44 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 49 -->
and for applying for any extension (including patent term extension and supplementary protection
certificate) with respect to such Patents in the Territory. Harpoon shall provide prompt and
reasonable assistance, as requested by AbbVie, including by taking such action as patent holder as
is required under any Applicable Law to obtain such extension. AbbVie shall pay all expenses in
regard to obtaining such extension in the Territory.

7.2.5 European Patents. On or after the License Option Exercise Closing Date, AbbVie shall have the
sole right to decide whether a Joint Patent or a Product-Specific Patent should be validated or
maintained as a Unitary Patent, whether and when such Patent should be opted out of or opted in to
the jurisdiction of the Unified Patent Court (UPC) (including withdrawal of an opt-out), as well as
any other issues concerning the jurisdiction of the UPC in connection with such Patent. Harpoon
shall, at AbbVie's cost and expense, cooperate with AbbVie and provide to AbbVie and submit to
authorities all necessary documents to effect such decision.

7.2.6 Patent Listings. With respect to each Licensed Product, AbbVie will have the sole right to
list Joint Patents and Product-Specific Patents with Regulatory Authorities or other agencies,
including as required or allowed under Applicable Law. AbbVie shall notify Harpoon in writing of any
Harpoon Patents that it intends to list with Regulatory Authorities related to the Licensed Products
and, prior to filing any such listing, consult with and consider in good faith the requests and
suggestions of Harpoon regarding the same.

7.3 Enforcement of Patents.

7.3.1 Enforcement of Harpoon Patents. Each Party shall promptly notify the other Party in writing of
any alleged or threatened infringement of the Product-Specific Patents by a Third Party in the
Territory of which such Party becomes aware based on the development, commercialization or
Exploitation of, or an application to market, a Licensed Product or a product containing a Licensed
Compound in the Territory (the "Product Infringement"). AbbVie shall have the sole right, but not
the obligation, to prosecute any Product Infringement involving any claims of Product-Specific
Patents at its sole expense and AbbVie shall retain control of the prosecution of such claim, suit
or proceeding. Harpoon shall have the right to join as a party to such claim, suit, or proceeding in
the Territory and participate with its own counsel at its own expense; provided that AbbVie shall
retain control of the prosecution of such claim, suit, or proceeding. During any such claim, suit,
or proceeding, AbbVie shall keep Harpoon reasonably informed of all material developments in
connection with such claim, suit or proceeding. If AbbVie does not take commercially reasonable
steps to prosecute (including settling) such a Product Infringement in a country or jurisdiction,
then (a) Harpoon may, but is not obligated to, prosecute the Product Infringement at its own expense
in such country or jurisdiction, and (b) if Harpoon prosecutes such Product Infringement and obtains
an injunction that prevents the sale of a Biosimilar Product by such Third Party in such country or
jurisdiction, AbbVie shall not be entitled to apply any royalty reductions pursuant to Section
6.5.3(a) that would otherwise apply as a result of the sale of such Biosimilar Product by such Third
Party after the period of such injunction.

7.3.2 Enforcement of AbbVie Patents and Joint Patents.

(a) Each Party shall promptly notify the other Party in writing of any alleged or threatened
infringement of the Harpoon Patents that are not Product-Specific Patents, AbbVie Patents or Joint
Patents by a Third Party in the Territory of which such Party becomes aware based on the
development, commercialization, Exploitation, or an application to market a Licensed Product or a
product containing a Licensed Compound in the Territory.

(b) Subject to Sections 7.3.3 and 7.3.4, Harpoon shall have the first right, but not the obligation,
to prosecute any such alleged or threatened infringement of Harpoon Patents that are not
Product-Specific Patents in the Territory at its sole expense and Harpoon shall retain control of
the

- 45 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 50 -->
prosecution of such claim, suit or proceeding. If Harpoon prosecutes any such infringement, AbbVie
shall have the right to join as a party to such claim, suit or proceeding in the Territory and
participate with its own counsel at its own expense; provided that Harpoon shall retain control of
the prosecution of such claim, suit or proceeding. During any such claim, suit, or proceeding,
Harpoon shall keep AbbVie reasonably informed of all material developments in connection with such
claim, suit or proceeding. If Harpoon does not take commercially reasonable steps to prosecute the
alleged or threatened infringement in the Territory with respect to such Harpoon Patents, then
solely following the License Option Exercise Closing Date, AbbVie may prosecute such infringement in
the Territory at its own expense, unless Harpoon reasonably believes that the prosecution of such
infringement by AbbVie would have a material adverse impact on Harpoon's global patent portfolio, or
upon the use or application of such Harpoon Patents in connection with other products and compounds
Controlled by Harpoon, its Affiliates or sublicensees. For clarity, this Section 7.3.2(b) is
inapplicable to any biosimilar patent litigation relating to any Licensed Compound or Licensed
Product as set forth in Sections 7.3.3 and 7.3.4.

(c) AbbVie shall have the sole right, but not the obligation, to prosecute any such infringement of
the AbbVie Patents in the Territory at its sole expense and AbbVie shall retain control of the
prosecution of such claim, suit or proceeding.

(d) AbbVie shall have the first right, but not the obligation, to prosecute any such infringement of
Joint Patents in the Territory at its sole expense and AbbVie shall retain control of the
prosecution of such claim, suit or proceeding. If AbbVie prosecutes any such infringement, Harpoon
shall have the right to join as a party to such claim, suit or proceeding in the Territory and
participate with its own counsel at its own expense; provided that AbbVie shall retain control of
the prosecution of such claim, suit or proceeding. During any such claim, suit, or proceeding,
AbbVie shall keep Harpoon reasonably informed of all material developments in connection with such
claim, suit or proceeding. If AbbVie does not take commercially reasonable steps to prosecute the
alleged or threatened infringement in the Territory with respect to such Joint Patents, then Harpoon
may prosecute such infringement in the Territory at its own expense.

7.3.3 Patent Exclusivity Listings. If either Party receives a copy of an application submitted to
the FDA under subsection (k) of Section 351 of the PHSA (a "Biosimilar Application") naming a
Licensed Product as a reference product or otherwise becomes aware that such a Biosimilar
Application has been filed (such as in an instance described in Section 351(l)(9)(C) of the PHSA),
such Party shall, within [***], notify the other Party so that the other Party may seek permission
to view the application and related confidential information from the filer of the Biosimilar
Application under Section 351(l)(1)(B)(iii) of the PHSA. If either Party receives any equivalent or
similar certification or notice in any other jurisdiction in the Territory, either Party shall,
within [***], notify and provide the other Party with copies of such communication. Regardless of
the Party that is the "reference product sponsor" for purposes of such Biosimilar Application, (a)
[***]; (b) AbbVie shall have the right to list any AbbVie Patents, Joint Patents, Product-Specific
Patents, and, upon the written consent of Harpoon, such consent not to be unreasonably withheld,
conditioned or delayed (taking into account, without limitation, the potential impact of such
consent on Harpoon's platform technology and/or other products undergoing development or
commercialization by Harpoon or its Third Party licensees and covered by such Harpoon Patents),
other Harpoon Patents, insofar as they cover the Biosimilar Product as required pursuant to Section
351(l) (3)(A), Section 351(l)(5)(b)(i)(II), or Section 351(l)(7) of the PHSA, to respond to any
communications with respect to such lists from the filer of the Biosimilar Application, and to
negotiate with the filer of the Biosimilar Application as to whether to utilize a different
mechanism for information exchange than that specified in Section 351(l) of the PHSA; and (c) [***]
shall have the sole right to identify such Patents or respond to communications under any equivalent
or similar listing in any other jurisdiction in the Territory. If required pursuant to Applicable
Law, [***] shall prepare such lists and make such responses at [***] Harpoon shall cooperate with
AbbVie's reasonable requests in connection therewith, including meeting any submission deadlines, in
each case, to the extent required or permitted by Applicable Law. AbbVie shall (A) reasonably
consult with [***]

- 46 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 51 -->
[***] to a Third Party as contemplated by this Section 7.3.3, and shall consider in good faith
Harpoon's advice, requests and suggestions with respect thereto, and (B) notify Harpoon of any such
lists or communications promptly after they are made.

7.3.4 Conduct of Biosimilar Patent Litigation Including Under the Biologics Price Competition and
Innovation Act. Notwithstanding anything to the contrary in this Section 7.3, AbbVie shall be
responsible for initiating and managing any biosimilar litigation relating to Licensed Compounds or
Licensed Products worldwide. AbbVie shall have the first right to bring an action for infringement
of the AbbVie Patents, Joint Patents, Product-Specific Patents and, upon the written consent of
Harpoon, such consent not to be unreasonably withheld, conditioned or delayed (taking into account,
without limitation, the potential impact of such consent on Harpoon's platform technology and/or
other products undergoing development or commercialization by Harpoon or its Third Party licensees
and covered by such Harpoon Patents), other Harpoon Patents, including as required under Section
351(l)(6) of the PHSA following the agreement on a list of patents for litigation under Section
351(l)(4) or exchange of Patent lists pursuant to Section 351(l)(5)(B) of such act, or as required
following any equivalent or similar certification or notice in any other jurisdiction. If Harpoon
decides pursuant to this Agreement not to allow AbbVie to include such other Harpoon Patents in a
litigation against a biosimilar applicant for a biosimilar product, Harpoon shall not assert such
Patent in any litigation against the same biosimilar applicant for the same biosimilar product
without written approval by AbbVie. The Parties' rights and obligations with respect to the
foregoing legal actions shall be as set forth in Sections 7.3.1 through 7.3.5; provided that within
[***] of reaching agreement on a list of Patents for litigation under Section 351(l)(4) or exchange
of Patent lists pursuant to Section 351(l) (5)(B), AbbVie shall notify Harpoon as to whether or not
it elects to prosecute such infringement. Either Party shall, within [***], notify and provide the
other Party with copies of any notice of commercial marketing provided by the filer of a Biosimilar
Application pursuant to Section 351(l)(8)(A) of the PHSA, or any equivalent or similar certification
or notice in any other jurisdiction. Thereafter, AbbVie shall have the first right to seek an
injunction or other remedies against such commercial marketing as permitted pursuant to Section
351(l)(8)(B) of the PHSA.

7.3.5 Cooperation. The Parties agree to cooperate fully in any infringement action pursuant to this
Section 7.3. Where a Party brings such an action in accordance with this Agreement, the other Party
shall, where necessary, furnish a power of attorney solely for such purpose or shall join in, or be
named as a necessary party to, such action. Unless otherwise set forth herein, the Party entitled to
bring any patent infringement litigation in accordance with this Section 7.3 shall have the right to
settle such claim; provided that neither Party shall have the right to settle any patent
infringement litigation under this Section 7.3 in a manner that imposes any costs or liability on,
or involves any admission by, the other Party, without the express written consent of such other
Party. The Party commencing the litigation shall provide the other Party with copies of all
pleadings and other documents filed with the court if doing so would not waive any privilege or
violate any court order or Applicable Law, and shall consider reasonable input from the other Party
during the course of the proceedings.

7.3.6 Recovery. Any recovery realized as a result of such litigation described in Section 7.3.1,
7.3.2, or 7.3.5 (whether by way of settlement or otherwise) shall be first, allocated to reimburse
the Parties for their costs and expenses in making such recovery (which amounts shall be allocated
pro rata if insufficient to cover the totality of such expenses). [***]

7.4 Infringement Claims by Third Parties. If the manufacture, sale, or use of a Licensed Compound or
Licensed Product in the Territory pursuant to this Agreement results in, or may result

- 47 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 52 -->
in, any claim, suit, or proceeding by a Third Party alleging patent infringement by AbbVie (or its
Affiliates or Sublicensees), AbbVie shall promptly notify Harpoon thereof in writing. Subject to
Section 11.2, AbbVie shall have the first right, but not the obligation, to defend and control the
defense of any such claim, suit, or proceeding at its own expense, using counsel of its own choice.
Harpoon may participate in any such claim, suit, or proceeding with counsel of its choice at its own
expense. The assumption of the defense of a claim that may be subject to Section 11.2 by either
AbbVie or Harpoon shall not be construed as an acknowledgment that Harpoon is liable to indemnify
any AbbVie Indemnitee in respect of such indemnity claim, nor shall it constitute a waiver by
Harpoon of any defenses it may assert against an AbbVie Indemnitee's claim for indemnification.
Without limitation of the foregoing, if AbbVie finds it necessary or desirable to join Harpoon as a
party to any such action, Harpoon shall, at AbbVie's expense, execute all papers and perform such
acts as shall be reasonably required. If AbbVie elects (in a written communication submitted to
Harpoon within a reasonable amount of time after notice of the alleged patent infringement) not to
defend or control the defense of, or otherwise fails to initiate and maintain the defense of, any
such claim, suit, or proceeding, within such time periods so that Harpoon is not prejudiced by any
delays, Harpoon may conduct and control the defense of any such claim, suit, or proceeding at its
own expense. Each Party shall keep the other Party reasonably informed of all material developments
in connection with any such claim, suit, or proceeding. [***] under this Section 7.4 shall be [***]

7.5 Invalidity or Unenforceability Defenses or Actions.

7.5.1 Notice. Each Party shall promptly notify the other Party in writing of any alleged or
threatened assertion of invalidity, unpatentability or unenforceability of any of the Harpoon
Patents, AbbVie Patents, or Joint Patents by a Third Party, in each case in the Territory and of
which such Party becomes aware.

7.5.2 Harpoon Patents.

(a) Subject to Section 7.5.2(b), Harpoon shall have the first right, but not the obligation, to
defend and control the defense of the validity, patentability and enforceability of the Harpoon
Patents at its own expense in the Territory. AbbVie may participate in any such claim, suit, or
proceeding in the Territory with counsel of its choice at its own expense; provided that Harpoon
shall retain control of the defense in such claim, suit, or proceeding. If Harpoon elects not to
defend or control the defense of such Harpoon Patents in a suit brought in the Territory, or
otherwise fails to initiate and maintain the defense of any such claim, suit, or proceeding, then
solely with respect to Product-Specific Patents included in the Harpoon Patents, and subject to
Section 7.5.2(b), AbbVie may request to conduct and control the defense of any such claim, suit, or
proceeding at its own expense, with Harpoon's consent not to be unreasonably withheld, conditioned
or delayed.

(b) On and after the License Option Exercise Closing Date, AbbVie shall have the responsibility for
and control over the defense of the validity, patentability and enforceability of Product-Specific
Patents at AbbVie's sole cost and expense. Harpoon may participate in any such claim, suit, or
proceeding in the Territory with counsel of its choice at its own expense; provided that AbbVie
shall retain control of the defense in such claim, suit, or proceeding. If AbbVie elects not to
defend or control the defense of such Product-Specific Patents in a suit brought in the Territory,
or otherwise fails to initiate and maintain

- 48 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 53 -->
the defense of any such claim, suit, or proceeding, then Harpoon may conduct and control the defense
of any such claim, suit, or proceeding at its own expense.

7.5.3 AbbVie Patents and Joint Patents.

(a) AbbVie shall have the sole right, but not the obligation, to defend and control the defense of
the validity and enforceability of the AbbVie Patents at its own expense in the Territory.

(b) The Party who is prosecuting the Joint Patents at the relevant time shall have the first right,
but not the obligation, to defend and control the defense of the validity and enforceability of the
Joint Patents at its own expense in the Territory. The other Party may participate in any such
claim, suit, or proceeding in the Territory related to the Joint Patents with counsel of its choice
at its own expense; provided that the Party who is prosecuting the Joint Patents at the relevant
time shall retain control of the defense in such claim, suit, or proceeding. If the Party who is
prosecuting the Joint Patents at the relevant time elects not to defend or control the defense of
the Joint Patents in a suit brought in the Territory, or otherwise fails to initiate and maintain
the defense of any such claim, suit, or proceeding, then the other Party may conduct and control the
defense of any such claim, suit, or proceeding, at its own expense.

7.5.4 Cooperation. Each Party shall assist and cooperate with the other Party as such other Party
may reasonably request from time to time in connection with its activities set forth in this Section
7.5, including by being joined as a party plaintiff in such action or proceeding, providing access
to relevant documents and other evidence, and making its employees available at reasonable business
hours. In connection with any such defense or claim or counterclaim, the controlling Party shall
consider in good faith any comments from the other Party and shall keep the other Party reasonably
informed of any steps taken, and shall provide copies of all documents filed, in connection with
such defense, claim, or counterclaim provided that doing so would not waive any privilege or violate
any court order or Applicable Law. In connection with the activities set forth in this Section 7.5,
each Party shall consult with the other as to the strategy for the defense of the Harpoon Patents
and Joint Patents. Neither Party shall have the right to settle any claim, suit, or proceeding under
this Section 7.5 in a manner that imposes any costs or liability on, or involves any admission by,
the other Party, without the express written consent of such other Party.

7.5.5 Relationship to Enforcement of Patents. Notwithstanding anything herein to the contrary, the
defense to any challenge of validity, enforceability or patentability of any of the Harpoon Patents,
AbbVie Patents, or Joint Patents that is raised in connection with or in response to an infringement
action or a biosimilar litigation shall be controlled by the Party who controls that infringement
action or biosimilar litigation, and such Party shall have the right to manage, resolve, settle or
dispose any such challenge according to Section 7.3, provided that (a) with respect to any Harpoon
Patents that are not Product- Specific Patents and are not involved in any biosimilar patent
litigation, where AbbVie is the controlling Party in connection with an infringement action, AbbVie
shall not resolve, settle or dispose of such action or litigation in any way that would admit
liability on the part of Harpoon, or materially impact the validity, scope or enforceability of such
Harpoon Patent, without Harpoon's prior written consent, not to be unreasonably withheld or delayed,
and (b) with respect to any Harpoon Patents for which Harpoon did not give its consent to include
within a biosimilar litigation, and Harpoon is the controlling Party in connection with an
infringement action involving such Patents, then Harpoon shall be the controlling Party in
connection with the defense to any challenge of validity, enforceability or patentability of such
Harpoon Patents, but shall reasonably consult with AbbVie in connection with any such defense, and
shall consider in good faith AbbVie's reasonable comments in relation thereto.

7.6 Product Trademarks. As between the Parties, AbbVie shall own all right, title, and interest to
the Product Trademarks in the Territory, and shall be responsible for the registration, prosecution,
maintenance and enforcement thereof. All costs and expenses of registering, prosecuting, maintaining
and enforcing the Product Trademarks shall be borne solely by AbbVie. Harpoon shall provide all
assistance and

- 49 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 54 -->
documents reasonably requested by AbbVie in support of its prosecution, registration, maintenance
and enforcement of the Product Trademarks.

7.7 International Nonproprietary Name. As between the Parties, AbbVie shall have the sole right and
responsibility to select the International Nonproprietary Name or other name or identifier for any
Licensed Compound or Licensed Product. AbbVie shall have the sole right and responsibility to apply
for submission to the World Health Organization for the International Nonproprietary Name, and
submission to the United States Adopted Names Council for the United States Adopted Name.

7.8 Inventor's Remuneration. Each Party shall be solely responsible for any remuneration that may be
due such Party's inventors under any applicable inventor remuneration laws.

7.9 Common Interest. All information exchanged between the Parties regarding the prosecution,
maintenance, enforcement and defense of Patents under this Article 7 will be deemed to be
Confidential Information of the disclosing Party. In addition, the Parties acknowledge and agree
that, with regard to such prosecution, maintenance, enforcement and defense, the interests of the
Parties as collaborators and Harpoon and licensee are to, for their mutual benefit, obtain patent
protection and plan patent defense against potential infringement activities by Third Parties, and
as such, are aligned and are legal in nature. The Parties agree and acknowledge that they have not
waived, and nothing in this Agreement constitutes a waiver of, any legal privilege concerning
Patents under this Article 7, including privilege under the common interest doctrine and similar or
related doctrines. Notwithstanding anything to the contrary in this Agreement, to the extent a Party
has a good faith belief that any information required to be disclosed by such Party to the other
Party under this Article 7 is protected by attorney-client privilege or any other applicable legal
privilege or immunity, such Party shall not be required to disclose such information and the Parties
shall in good faith cooperate to agree upon a procedure (which may include entering into a specific
common interest agreement, disclosing such information on a "for counsel eyes only" basis or similar
procedure) under which such information may be disclosed without waiving or breaching such privilege
or immunity.

ARTICLE 8 PHARMACOVIGILANCE AND SAFETY

8.1 Pharmacovigilance. Within [***] after the License Option Exercise Closing Date, the Parties
shall enter into an agreement to initiate a process for the exchange of adverse event safety data in
a mutually agreed format, including postmarketing spontaneous reports received by the Party or its
Affiliates in order to (a) with respect to AbbVie, monitor the safety of the Licensed Compound or
Licensed Product and to meet reporting requirements with any applicable Regulatory Authority and (b)
with respect to Harpoon, permit reasonable access to adverse event safety data for Licensed
Compounds or Licensed Products, in each case ((a) and (b)) at AbbVie's expense. Notwithstanding the
forgoing, if any adverse event safety data is received or otherwise generated by Harpoon following
the License Option Exercise Closing Date and prior to the execution of such agreement, Harpoon
shall, within [***] of receiving or otherwise generating such data, provide such data to AbbVie by
email to: [***].

8.2 Global Safety Database. Harpoon shall initially set up, hold and maintain (at its sole cost and
expense) the global safety database for Licensed Compounds and Licensed Products with respect to
safety data obtained in connection with the Initial Development Activities. Within [***] after the
License Option Exercise Closing Date, Harpoon shall transfer to AbbVie, in an electronic format
reasonably satisfactory to AbbVie, the complete contents of the safety database maintained by
Harpoon pursuant to the immediately foregoing sentence, and thereafter AbbVie shall set up, hold,
and maintain (at AbbVie's sole cost and expense) the global safety database for Licensed Compounds
or Licensed Products. Harpoon shall provide AbbVie with all information necessary or desirable for
AbbVie to comply with its pharmacovigilance responsibilities in the Territory, including, as
applicable, any adverse drug experiences, from pre-clinical or clinical laboratory, animal
toxicology and pharmacology studies, Clinical Studies, and commercial experiences

- 50 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 55 -->
with a Licensed Compound or Licensed Product, in each case in any form agreed upon between AbbVie
and Harpoon at the time of the request.

ARTICLE 9 CONFIDENTIALITY AND NON-DISCLOSURE

9.1 Product Information. Harpoon recognizes that by reason of AbbVie's status as an exclusive
optionee pursuant to the grants under Section 3.2.3, AbbVie has an interest in Harpoon maintaining
the confidentiality of certain information of Harpoon. Accordingly, following the License Option
Exercise Closing Date and for the remainder of the Term, Harpoon shall, and shall cause its
Affiliates and its and their respective officers, directors, employees, and agents to, keep
confidential, and not publish or otherwise disclose, and not use directly or indirectly for any
purpose other than to fulfill Harpoon's obligations hereunder any Information owned or otherwise
Controlled by Harpoon or any of its Affiliates specifically relating to any Licensed Compound or
Licensed Product, or the Exploitation of any of the foregoing (the "Product Information"); except to
the extent (a) the Product Information is in the public domain through no fault of Harpoon, its
Affiliates or any of its or their respective officers, directors, employees, or agents; (b) such
disclosure or use is expressly permitted under Section 9.3, or (c) such disclosure or use is
otherwise expressly permitted by the terms of this Agreement. Product Information shall not include
[***]. For purposes of Section 9.3, effective as of License Option Exercise Closing Date and for the
remainder of the Term, AbbVie shall be deemed to be the disclosing Party with respect to Product
Information under Section 9.3 and Harpoon shall be deemed to be the receiving Party with respect
thereto. For further clarification, (i) without limiting this Section 9.1, to the extent Product
Information is disclosed by Harpoon to AbbVie pursuant to this Agreement, such information shall,
subject to the other terms and conditions of this Article 9, also constitute Confidential
Information of Harpoon with respect to the use and disclosure of such Information by AbbVie, but
(ii) the disclosure by Harpoon to AbbVie of Product Information shall not cause such information to
cease to be subject to the provisions of this Section 9.1 with respect to the use and disclosure of
such Confidential Information by Harpoon. [***].

9.2 Confidentiality Obligations. At all times during the Term and for a period of [***] following
termination or expiration hereof in its entirety, each Party shall, and shall cause its officers,
directors, employees and agents to, keep confidential and not publish or otherwise disclose to a
Third Party and not use, directly or indirectly, for any purpose, any Confidential Information
furnished or otherwise made known to it, directly or indirectly, by the other Party, except to the
extent such disclosure or use is expressly permitted by the terms of this Agreement or is necessary
or reasonably useful for the performance of, or the exercise of such Party's rights under, this
Agreement. Notwithstanding the foregoing, to the extent the receiving Party can demonstrate by
documentation or other competent proof, the confidentiality and non-use obligations under this
Section 9.2 with respect to any Confidential Information shall not include any information that:

9.2.1 has been published by a Third Party or otherwise is or hereafter becomes part of the public
domain by public use, publication, general knowledge or the like through no wrongful act, fault or
negligence on the part of the receiving Party;

- 51 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 56 -->
9.2.2 has been in the receiving Party's possession prior to disclosure by the disclosing Party
without any obligation of confidentiality with respect to such information; provided that the
foregoing exception shall not apply with respect to Regulatory Documentation (excluding clinical
protocols) or Joint Know-How;

9.2.3 is subsequently received by the receiving Party from a Third Party without restriction and
without breach of any agreement between such Third Party and the disclosing Party;

9.2.4 is generally made available to Third Parties by the disclosing Party without restriction on
disclosure; or

9.2.5 has been independently developed by or for the receiving Party without reference to, or use or
disclosure of, the disclosing Party's Confidential Information; provided that the foregoing
exception shall not apply with respect to Regulatory Documentation (excluding clinical protocols) or
Joint Know-How.

Specific aspects or details of Confidential Information shall not be deemed to be within the public
domain or in the possession of the receiving Party merely because the Confidential Information is
embraced by more general information in the public domain or in the possession of the receiving
Party. Further, any combination of Confidential Information shall not be considered in the public
domain or in the possession of the receiving Party merely because individual elements of such
Confidential Information are in the public domain or in the possession of the receiving Party unless
the combination and its principles are in the public domain or in the possession of the receiving
Party.

9.3 Permitted Disclosures. Each Party may disclose Confidential Information to the extent that such
disclosure is:

9.3.1 in the reasonable opinion of the receiving Party's legal counsel, required to be disclosed
pursuant to law, regulation or a valid order of a court of competent jurisdiction or other
supra-national, federal, national, regional, state, provincial or local governmental body of
competent jurisdiction, (including by reason of filing with securities regulators, but subject to
Section 9.5); provided that the receiving Party shall first have given prompt written notice (and to
the extent possible, at least [***] notice) to the disclosing Party and given the disclosing Party a
reasonable opportunity to take whatever action it deems necessary to protect its Confidential
Information. In the event that no protective order or other remedy is obtained, or the disclosing
Party waives compliance with the terms of this Agreement, the receiving Party shall furnish only
that portion of Confidential Information which the receiving Party is advised by counsel is legally
required to be disclosed;

9.3.2 made by or on behalf of the receiving Party to the Regulatory Authorities as required in
connection with any filing, application or request for Regulatory Approval of a Licensed Product in
accordance with the terms of this Agreement; provided that reasonable measures shall be taken to
assure confidential treatment of such Confidential Information to the extent practicable and
consistent with Applicable Law;

9.3.3 made by or on behalf of the receiving Party to a patent authority as may be necessary or
reasonably useful for purposes of preparing, obtaining, defending or enforcing a Patent in
accordance with the terms of this Agreement; provided that reasonable measures shall be taken to
assure confidential treatment of such Confidential Information, to the extent such protection is
available;

9.3.4 made to its or its Affiliates' financial and legal advisors who have a need to know such
disclosing Party's Confidential Information and are either under professional codes of conduct
giving rise to expectations of confidentiality and non-use or under written agreements of
confidentiality and

- 52 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 57 -->
non-use, in each case, at least as restrictive as those set forth in this Agreement; provided that
the receiving Party shall remain responsible for any failure by such financial and legal advisors,
to treat such Confidential Information as required under this Article;

9.3.5 made by the receiving Party or its Affiliates to potential or actual investors or acquirers as
may be necessary in connection with their evaluation of such potential or actual investment or
acquisition; provided that such Persons shall be subject to obligations of confidentiality and
non-use with respect to such Confidential Information substantially similar to the obligations of
confidentiality and non-use of the receiving Party pursuant to this Article 9;

9.3.6 made by AbbVie or its Affiliates or Sublicensees to its or their advisors, consultants,
clinicians, vendors, service providers, contractors, existing or prospective collaboration partners,
licensees, sublicensees, or other Third Parties as may be necessary or useful in connection with the
Exploitation of the Licensed Compound, the Licensed Products, or otherwise in connection with the
performance of its obligations or exercise of its rights as contemplated by this Agreement; provided
that such Persons shall be subject to obligations of confidentiality and non-use with respect to
such Confidential Information substantially similar to the obligations of confidentiality and
non-use of AbbVie pursuant to this Article 9; or

9.3.7 made by Harpoon or its Affiliates after receiving advanced approval from AbbVie, to its or
their advisors, consultants, clinicians, vendors, service providers, contractors, or other Third
Parties as may be necessary or useful in connection with the performance of their obligations or
exercise of their rights as contemplated by this Agreement; provided that such Persons shall be
subject to obligations of confidentiality and non-use with respect to such Confidential Information
of AbbVie substantially similar to the obligations of confidentiality and non-use of Harpoon
pursuant to this Article 9; provided, further, that the advanced approval requirement set forth in
this Section 9.3.7 shall not apply to Third Party Providers approved by AbbVie pursuant to Section
3.7.

9.4 Use of Name. Except as expressly provided herein, neither Party shall mention or otherwise use
the name, logo, or Trademark of the other Party or any of its Affiliates (or any abbreviation or
adaptation thereof) in any publication, press release, marketing and promotional material, or other
form of publicity without the prior written approval of such other Party in each instance. The
restrictions imposed by this Section 9.4 shall not prohibit either Party from making any disclosure
identifying the other Party that, in the opinion of the disclosing Party's counsel, is required by
Applicable Law; provided that such Party shall submit the proposed disclosure identifying the other
Party in writing to the other Party as far in advance as reasonably practicable (and in no event
less than [***] prior to the anticipated date of disclosure) so as to provide a reasonable
opportunity to comment thereon.

9.5 Public Announcements. Neither Party shall issue any other public announcement, press release, or
other public disclosure regarding this Agreement or its subject matter without the other Party's
prior written consent, except for any such disclosure that is, in the opinion of the disclosing
Party's counsel, required by Applicable Law or the rules of a stock exchange on which the securities
of the disclosing Party are listed (or to which an application for listing has been submitted).
Notwithstanding the foregoing, Harpoon shall be free to issue any public announcement, press
release, or other public disclosure related to (a) [***], (b) [***], (c) [***], and (d) any
publication, presentation or disclosure that was permitted under Section 9.6, provided that any such
disclosure under (a) through (d) does not contain any Confidential Information of AbbVie. In the
event a Party is, in the opinion of its counsel, required by Applicable Law or

- 53 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 58 -->
the rules of a stock exchange on which its securities are listed (or to which an application for
listing has been submitted) to make such a public disclosure, such Party shall submit the proposed
disclosure in writing to the other Party as far in advance as reasonably practicable (and to the
extent possible, at least [***] prior to the anticipated date of disclosure) so as to provide a
reasonable opportunity to comment thereon. Notwithstanding the foregoing, AbbVie, its Sublicensees
and its and their respective Affiliates shall have the right to publicly disclose research,
development and commercial information (including with respect to regulatory matters) regarding the
Licensed Compound and Licensed Products, provided that any such disclosure does not contain any
Confidential Information of Harpoon.

9.6 Publications. The Parties acknowledge that scientific publications must be monitored to prevent
any adverse effect from premature publication of results of the activities contemplated hereunder.
Prior to the License Option Exercise Closing Date, if Harpoon intends to publish, present (including
presentation at any scientific meeting) or otherwise disclose Information related specifically to
the Exploitation of the Licensed Compound or Licensed Products, Harpoon shall provide AbbVie with
such proposed publication, presentation or disclosure at least [***] prior to the intended
publication date, provided that [***]. AbbVie will have the right to reasonably review and comment
to such publication, presentation or disclosure, and Harpoon shall in good faith consider any
comments made by AbbVie in such [***] period. If such publication, presentation or disclosure
contains Confidential Information of AbbVie, then upon AbbVie's request during such [***] period,
Harpoon shall delete any such information identified by AbbVie. If there is a dispute regarding
Harpoon's right to publish prior to the License Option Exercise Closing Date, such dispute shall be
escalated to the Senior Officers of each Party for resolution, provided that subject to the
foregoing sentence, Harpoon shall have the right to make a final decision with respect to such
publication. Following the License Option Exercise Closing Date, Harpoon shall not publish, present,
or otherwise disclose, and shall cause its Affiliates and Third Party Providers and its and their
employees and agents not to disclose any Product Information without the prior written consent of
AbbVie, except as required by Applicable Law.

9.7 Return of Confidential Information. Upon the effective date of the termination of this Agreement
for any reason, either Party may request in writing, and the other Party shall either, with respect
to Confidential Information (in the event of termination of this Agreement with respect to [***]
Terminated Territories but not in its entirety, solely to the extent relating specifically and
exclusively to such Terminated Territories) to which such other Party does not retain rights under
the surviving provisions of this Agreement: (a) as soon as reasonably practicable, destroy all
copies of such Confidential Information in the possession of the other Party and confirm such
destruction in writing to the requesting Party; or (b) as soon as reasonably practicable, deliver to
the requesting Party, at such other Party's expense, all copies of such Confidential Information in
the possession of such other Party; provided that such other Party shall be permitted to retain one
(1) copy of such Confidential Information for the sole purpose of performing any continuing
obligations or exercising any surviving rights hereunder, as required by Applicable Law, or for
litigation or archival purposes. Notwithstanding the foregoing, such other Party also shall be
permitted to retain such additional copies of or any computer records or files containing such
Confidential Information that have been created solely by such Party's automatic archiving and
back-up procedures, to the extent created and retained in a manner consistent with such other
Party's standard archiving and back-up procedures, but not for any other use or purpose.

9.8 Survival. All Confidential Information shall continue to be subject to the terms of this
Agreement for the period set forth in Section 9.2.

- 54 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020

ARTICLE 10 REPRESENTATIONS AND WARRANTIES
<!-- page 59 -->
10.1 Mutual Representations and Warranties. Harpoon and AbbVie each represents and warrants to the
other, as of the Effective Date, as follows:

10.1.1 Organization. It is a corporation duly incorporated, validly existing, and in good standing
under the laws of the jurisdiction of its incorporation, and has all requisite corporate power and
authority, to execute, deliver, and perform this Agreement.

10.1.2 Authorization. The execution and delivery of this Agreement and the performance by it of the
transactions contemplated hereby have been duly authorized by all necessary corporate action, and do
not violate (a) such Party's charter documents, bylaws, or other organizational documents, (b) in
any material respect, any agreement, instrument, or contractual obligation to which such Party is
bound, (c) any requirement of any Applicable Law, or (d) any order, writ, judgment, injunction,
decree, determination, or award of any court or governmental agency presently in effect applicable
to such Party.

10.1.3 Binding Agreement. This Agreement is a legal, valid, and binding obligation of such Party
enforceable against it in accordance with its terms and conditions, subject to the effects of
bankruptcy, insolvency, or other laws of general application affecting the enforcement of creditor
rights, judicial principles affecting the availability of specific performance, and general
principles of equity (whether enforceability is considered a proceeding at law or equity).

10.1.4 No Inconsistent Obligation. It is not under any obligation, contractual or otherwise, to any
Person that conflicts with or is inconsistent in any material respect with the terms of this
Agreement, or that would impede the diligent and complete fulfillment of its obligations hereunder.

10.1.5 No Misstatements or Omissions. The representations and warranties of such Party in this
Agreement, and the Information, documents and materials furnished to the other Party in response to
such Party's written requests for due diligence information prior to the Effective Date, do not,
taken as a whole, (a) contain any untrue statement of a material fact, or (b) omit to state any
material fact necessary to make the statements or facts contained therein, in light of the
circumstances under which they were made, not misleading.

10.2 Additional Representations and Warranties of Harpoon. Except as set forth on Schedule 10.2,
Harpoon further represents and warrants to AbbVie, as of the Effective Date, as follows:

10.2.1 All Harpoon Patents existing as of the Effective Date are listed on Schedule 10.2.1 (the
"Existing Patents"). To Harpoon's Knowledge, all Existing Patents existing as of the Effective Date
are subsisting and, to Harpoon's Knowledge, are not invalid or unenforceable, in whole or in part,
are being diligently prosecuted in the applicable patent offices in the Territory in accordance with
Applicable Law, and have been filed and maintained properly and correctly in all material aspect and
all applicable fees have been paid on or before the due date for payment.

10.2.2 There are no judgments, or settlements against, or amounts with respect thereto, owed by
Harpoon or any of its Affiliates relating to the Existing Patents, or the Harpoon Know-How. No claim
or litigation has been brought or threatened in writing or any other form by any Person alleging,
and Harpoon has no Knowledge of any claim, whether or not asserted, that the Existing Patents are
invalid or unenforceable. To Harpoon's Knowledge, the Development or Commercialization of the
Licensed Compounds or Licensed Products as contemplated herein, does not or will not violate,
infringe, misappropriate or otherwise conflict or interfere with, any Patent or other intellectual
property or proprietary right of any Third

- 55 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 60 -->
Party. To Harpoon's Knowledge, no Person is infringing or threatening to infringe or
misappropriating or threatening to misappropriate the Existing Patents or the Harpoon Know-How.

10.2.3 Harpoon is (a) the sole and exclusive owner of the entire right, title and interest in the
Existing Patents listed on Schedule 10.2.1, Part A (the "Owned Patents") and the Harpoon Know-How
and (b) the sole and exclusive licensee of the Existing Patents listed on Schedule 10.2.1, Part B
(the "In-Licensed Patents") which are subject to valid and enforceable in-license agreements, in
each case ((a) and (b)) free of any encumbrance, lien, or claim of ownership by any Third Party.
Harpoon is entitled to grant the licenses specified herein. The Owned Patents and In-Licensed
Patents represent all of the Existing Patents.

10.2.4 Harpoon has the right to use and license (or sublicense as the case may be) to AbbVie all
Information and Patents necessary to Develop, Manufacture and Commercialize the Licensed Compounds
and the Licensed Products as contemplated herein. The Harpoon Patents and Harpoon Know-How are not
and will not be subject to any license or other agreement to which Harpoon or any of its Affiliates
is a party other than a Harpoon In-License Agreement.

10.2.5 As of the Effective Date, none of Harpoon or its Affiliates and, to Harpoon's Knowledge, any
Third Party is in material breach of any Harpoon In-License Agreement.

10.2.6 True, complete, and correct copies of: (a) Harpoon In-License Agreements; and (b) all
material adverse information with respect to the safety and efficacy of the Licensed Compounds known
to Harpoon, in each case ((a) through (c)) have been provided or made available to AbbVie prior to
the Effective Date.

10.2.7 Harpoon and its Affiliates have generated, prepared, maintained, and retained all Regulatory
Documentation that is required to be maintained or retained pursuant to and in accordance with
Applicable Law, and all such information is in all material aspect true, complete and correct and
what it purports to be.

10.2.8 Each Person who has or has had any rights in or to any Owned Patents or any Harpoon Know-How,
including any current or former officer, employee, agent or consultant of Harpoon or any of its
Affiliates, has assigned and has executed an agreement assigning its entire right, title, and
interest in and to such Owned Patents and Harpoon Know-How to Harpoon. To Harpoon's Knowledge, no
current or former officer, employee, agent, or consultant of Harpoon or any of its Affiliates is in
material violation of any term of any assignment or other agreement regarding the protection of
Patents or other intellectual property or proprietary information of Harpoon or any Third Party
related to the Harpoon Patents, Harpoon Know-How, Licensed Compounds or Licensed Products.

10.2.9 All rights in all inventions and discoveries, made, developed, or conceived by any employee
or independent contractor of Harpoon or any of its Affiliates, and included in Harpoon Know-How or
that are the subject of one (1) or more Existing Patents have been assigned in writing to Harpoon or
such Affiliate.

10.2.10 Harpoon has obtained the right (including under any Patents and other intellectual property
rights) to use all material Information and other materials (including any formulations and
manufacturing processes and procedures) developed or delivered by any Third Party under any
agreements between Harpoon and any such Third Party that is necessary or reasonably useful for the
Development or Commercialization of Licensed Compounds, and Harpoon has the rights under each such
agreement to license and transfer such Information or other materials to AbbVie and its designees
and to grant AbbVie the right to use such Information or other materials in the Development or
Commercialization of the Licensed Compounds or the Licensed Products as set forth in this Agreement.

- 56 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 61 -->
10.2.11 Harpoon has made (and will make) available to AbbVie, as set forth in Section 3.5.1, all
Regulatory Documentation and Harpoon Know-How and all such Regulatory Documentation and Harpoon
Know-How are (and, if made available after the Effective Date, will be), to Harpoon's Knowledge,
true, complete, and correct. Neither Harpoon nor any of its Affiliates has any Knowledge of [***]
that has not been disclosed to AbbVie as of the Effective Date. [***] of a Licensed Product.

10.2.12 Neither Harpoon nor any of its Affiliates, nor any of its or their respective officers,
employees, or, to Harpoon's Knowledge, agents has made an untrue statement of material fact or
fraudulent statement to the FDA or any other Regulatory Authority with respect to the Development of
the Licensed Compounds or the Licensed Products, failed to disclose a material fact required to be
disclosed to the FDA or any other Regulatory Authority with respect to the Development of the
Licensed Compounds or the Licensed Products, or committed an act, made a statement, or failed to
make a statement with respect to the Development of the Licensed Compounds or the Licensed Products
that could reasonably be expected to provide a basis for the FDA to invoke its policy respecting
"Fraud, Untrue Statements of Material Facts, Bribery, and Illegal Gratuities", set forth in 56 Fed.
Reg. 46191 (September 10, 1991) and any amendments thereto or any analogous laws or policies in the
Territory.

10.2.13 There are no amounts that will be required to be paid to a Third Party as a result of the
Development or Commercialization of the Licensed Compounds or Licensed Products that arise out of
any agreement to which Harpoon or any of its Affiliates is a party.

10.2.14 Neither Harpoon nor any of its employees nor, to Harpoon's Knowledge, agents performing
hereunder, have ever been, are currently, or are the subject of a proceeding that could lead to it
or such employees or agents becoming, as applicable, a Debarred Entity or Debarred Individual, an
Excluded Entity or Excluded Individual or a Convicted Entity or Convicted Individual or added to the
FDA's Disqualified/Restricted List. If, during the Term, Harpoon, or any of its employees or agents
performing hereunder, become or are the subject of a proceeding that could lead to a Person
becoming, as applicable, a Debarred Entity or Debarred Individual, an Excluded Entity or Excluded
Individual or a Convicted Entity or Convicted Individual or added to the FDA's
Disqualified/Restricted List, Harpoon shall immediately notify AbbVie, and AbbVie shall have the
right, exercisable upon written notice given by AbbVie to terminate this Agreement. For purposes of
this Agreement, the following definitions shall apply:

(a) A "Debarred Individual" is an individual who has been debarred by the FDA pursuant to 21 U.S.C.
§335a (a) or (b) from providing services in any capacity to a Person that has an approved or pending
drug or biological product application.

(b) A "Debarred Entity" is a corporation, partnership or association that has been debarred by the
FDA pursuant to 21 U.S.C. §335a (a) or (b) from submitting or assisting in the submission of any
Drug Approval Application, or a subsidiary or affiliate of a Debarred Entity.

(c) An "Excluded Individual" or "Excluded Entity" is (A) an individual or entity, as applicable, who
has been excluded, debarred, suspended or is otherwise ineligible to participate in federal health
care programs such as Medicare or Medicaid by the Office of the Inspector General (OIG/HHS) of the
U.S. Department of Health and Human Services, or (B) is an individual or entity, as applicable, who
has been excluded, debarred, suspended or is otherwise ineligible to participate in federal
procurement and non-procurement programs, including those produced by the U.S. General Services
Administration (GSA).

- 57 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 62 -->
(d) A "Convicted Individual" or "Convicted Entity" is an individual or entity, as applicable, who
has been convicted of a criminal offense that falls within the ambit of 21 U.S.C. §335a (a) or 42
U.S.C. §1320a - 7(a), but has not yet been excluded, debarred, suspended or otherwise declared
ineligible.

(e) "FDA's Disqualified/Restricted List" is the list of clinical investigators restricted from
receiving investigational drugs, biologics, or devices if the FDA has determined that the
investigators have repeatedly or deliberately failed to comply with regulatory requirements for
studies or have submitted false Information to the study sponsor or the FDA..

10.2.15 The inventions claimed or covered by the Existing Patents (a) were not conceived,
discovered, developed, or otherwise made in connection with any research activities funded, in whole
or in part, by the federal government of the United States or any agency thereof, and (b) are not a
"subject invention" as that term is described in 35 U.S.C. Section 201(f).

10.3 Covenants of Harpoon. Harpoon covenants to AbbVie as follows:

10.3.1 During the Term, neither Harpoon nor any of its Affiliates shall encumber or diminish the
rights granted to AbbVie hereunder with respect to the Harpoon Patents, including by not (a)
committing any acts or knowingly permitting the occurrence of any omissions that would cause the
breach or termination of any Harpoon In-License Agreement, or (b) amending or otherwise modifying or
permitting to be amended or modified, any Harpoon In-License Agreement, where such amendment or
modification would adversely affect the rights granted to AbbVie hereunder. Harpoon shall promptly
provide AbbVie with notice of any alleged, threatened, or actual breach of any Harpoon In-License
Agreement.

10.3.2 At any time following the [***] and prior to the expiration of the Option Period (as[***]),
at AbbVie's request, Harpoon shall, at its sole cost and expense, exercise its option to acquire the
Commercial License [***] for Licensed Products pursuant to [***]. Harpoon shall exercise such
Commercial License promptly following written notice of such election by AbbVie to Harpoon. For
clarity, Harpoon shall not be responsible for any payment of any financial obligations resulting
from any agreement AbbVie elects to enter into with a Third Party in connection with the Manufacture
of a Licensed Compound or Licensed Product under [***].

10.3.3 Harpoon and its Affiliates will employ Persons with appropriate knowledge, expertise and
experience to conduct and to oversee the Initial Development Activities.

10.3.4 Harpoon shall have obtained from each of its Affiliates, sublicensees, employees and agents
who are participating in the Exploitation of the Licensed Compounds or Licensed Products or who
otherwise have access to any AbbVie Information or other Confidential Information of AbbVie in
connection with activities under this Agreement, rights to any and all Information that arises from
or relates to such participation and is necessary or reasonably useful for the Development or
Commercialization of Licensed Compounds or Licensed Products, in each case prior to the performance
of or participation in such activities, such that AbbVie shall, by virtue of this Agreement, receive
from Harpoon, without payments beyond those required by Article 6, the licenses and other rights
granted to AbbVie hereunder.

10.4 Covenants of AbbVie. AbbVie covenants to Harpoon as follows:

10.4.1 AbbVie shall have obtained from each of its Affiliates, Sublicensees, employees and agents
who are participating in the Exploitation of the Licensed Compounds or Licensed Products or who
otherwise have access to any Harpoon Information or other Confidential Information of Harpoon in
connection with activities under this Agreement, rights to any and all Information that arises from

- 58 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 63 -->
or relates to such participation or access and is necessary or reasonably useful for the Development
or Commercialization of Licensed Compounds or Licensed Products, in each case prior to the
performance of or participation in such activities, such that Harpoon shall, by virtue of this
Agreement, receive from AbbVie, without additional consideration, the licenses specified in Section
5.2.

10.5 DISCLAIMER OF WARRANTIES. EXCEPT FOR THE EXPRESS WARRANTIES SET FORTH HEREIN, NEITHER PARTY
MAKES ANY REPRESENTATIONS OR GRANTS ANY WARRANTIES, EXPRESS OR IMPLIED, EITHER IN FACT OR BY
OPERATION OF LAW, BY STATUTE OR OTHERWISE, AND EACH PARTY SPECIFICALLY DISCLAIMS ANY OTHER
WARRANTIES, WHETHER WRITTEN OR ORAL, OR EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF QUALITY,
MERCHANTABILITY, OR FITNESS FOR A PARTICULAR USE OR PURPOSE OR ANY WARRANTY AS TO THE VALIDITY OF
ANY PATENTS OR THE NON-INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHTS OF THIRD PARTIES.

ARTICLE 11 INDEMNITY

11.1 Indemnification of Harpoon. AbbVie shall indemnify Harpoon, its Affiliates and its and their
respective directors, officers, employees, and agents (the "Harpoon Indemnitees") and defend and
save each of them harmless, from and against any and all losses, damages, liabilities, penalties,
costs, taxes (including penalties and interest) and expenses (including reasonable attorneys' fees
and expenses) (collectively, "Losses") in connection with any and all suits, investigations, claims,
or demands of Third Parties (collectively, "Third Party Claims") incurred by or rendered against the
Harpoon Indemnitees arising from or occurring as a result of: [***]

11.2 Indemnification of AbbVie. Harpoon shall indemnify AbbVie, its Affiliates and its and their
respective directors, officers, employees, and agents (the "AbbVie Indemnitees"), and defend and
save each of them harmless, from and against any and all Losses in connection with any and all Third
Party Claims incurred by or rendered against the AbbVie Indemnitees arising from or occurring as a
result of: [***]

11.3 Notice of Claim. All indemnification claims in respect of a Party, its Affiliates, or their
respective directors, officers, employees and agents shall be made solely by such Party to this
Agreement (the "Indemnified Party"). The Indemnified Party shall give the indemnifying Party prompt
written notice (an "Indemnification Claim Notice") of any Losses or discovery of fact upon which
such Indemnified Party intends to base a request for indemnification under this Article 11, but in
no event shall the indemnifying Party be liable for any Losses to the extent resulting from any
delay in providing such notice. Each Indemnification Claim Notice must contain a description of the
claim and the nature and amount of such Loss (to the extent

- 59 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 64 -->
that the nature and amount of such Loss is known at such time). The Indemnified Party shall furnish
promptly to the indemnifying Party copies of all papers and official documents received in respect
of any Losses and Third Party Claims.

11.4 Control of Defense.

11.4.1 In General. Subject to the provisions of Sections 7.4 (if applicable), 7.5 and 7.6, at its
option, the indemnifying Party may assume the defense of any Third Party Claim by giving written
notice to the Indemnified Party within [***] after the indemnifying Party's receipt of an
Indemnification Claim Notice. The assumption of the defense of a Third Party Claim by the
indemnifying Party shall not be construed as an acknowledgment that the indemnifying Party is liable
to indemnify the Indemnified Party in respect of the Third Party Claim, nor shall it constitute a
waiver by the indemnifying Party of any defenses it may assert against the Indemnified Party's claim
for indemnification. Upon assuming the defense of a Third Party Claim, the indemnifying Party may
appoint as lead counsel in the defense of the Third Party Claim any legal counsel selected by the
indemnifying Party which shall be reasonably acceptable to the Indemnified Party. In the event the
indemnifying Party assumes the defense of a Third Party Claim, the Indemnified Party shall promptly
deliver to the indemnifying Party all original notices and documents (including court papers)
received by the Indemnified Party in connection with the Third Party Claim. Should the indemnifying
Party assume the defense of a Third Party Claim, except as provided in Section 11.4.2, the
indemnifying Party shall not be liable to the Indemnified Party for any legal expenses subsequently
incurred by such Indemnified Party in connection with the analysis, defense or settlement of the
Third Party Claim unless specifically requested in writing by the indemnifying Party. In the event
that it is ultimately determined that the indemnifying Party is not obligated to indemnify, defend
or hold harmless the Indemnified Party from and against the Third Party Claim, the Indemnified Party
shall reimburse the indemnifying Party for any Losses incurred by the indemnifying Party in its
defense of the Third Party Claim.

11.4.2 Right to Participate in Defense. Without limiting Section 11.4.1, any Indemnified Party shall
be entitled to participate in, but not control, the defense of such Third Party Claim and to employ
counsel of its choice for such purpose; provided that such employment shall be at the Indemnified
Party's own expense unless (a) the employment thereof, and the assumption by the indemnifying Party
of such expense, has been specifically authorized by the indemnifying Party in writing, (b) the
indemnifying Party has failed to assume the defense and employ counsel in accordance with Section
11.4.1 (in which case the Indemnified Party shall control the defense), or (c) the interests of the
Indemnified Party and the indemnifying Party with respect to such Third Party Claim are sufficiently
adverse to prohibit the representation by the same counsel of both Parties under Applicable Law,
ethical rules or equitable principles (in which case the Indemnifying Party shall control its
defense and the Indemnified Party shall control the defense of the Indemnified Party).

11.4.3 Settlement. With respect to any Losses relating solely to the payment of money damages in
connection with a Third Party Claim and that shall not result in the Indemnified Party's becoming
subject to injunctive or other relief, and as to which the indemnifying Party shall have
acknowledged in writing the obligation to indemnify the Indemnified Party hereunder, the
indemnifying Party shall have the sole right to consent to the entry of any judgment, enter into any
settlement or otherwise dispose of such Loss, on such terms as the indemnifying Party, in its sole
discretion, shall deem appropriate. With respect to all other Losses in connection with Third Party
Claims, where the indemnifying Party has assumed the defense of the Third Party Claim in accordance
with Section 11.4.1, the indemnifying Party shall have authority to consent to the entry of any
judgment, enter into any settlement or otherwise dispose of such Loss; provided that it obtains the
prior written consent of the Indemnified Party (which consent shall not be unreasonably withheld,
conditioned or delayed). If the indemnifying Party does not assume and conduct the defense of a
Third Party Claim as provided above, the Indemnified Party may defend against such Third Party
Claim. Regardless of whether the indemnifying Party chooses to defend or prosecute any Third Party
Claim, no Indemnified Party shall admit any liability with respect to, or settle, compromise or
dispose of, any Third Party Claim without

- 60 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 65 -->
the prior written consent of the indemnifying Party. The indemnifying Party shall not be liable for
any settlement, compromise or other disposition of a Loss by an Indemnified Party that is reached
without the written consent of the indemnifying Party.

11.4.4 Cooperation. Regardless of whether the indemnifying Party chooses to defend or prosecute any
Third Party Claim, the Indemnified Party shall, and shall cause each indemnitee to, cooperate in the
defense or prosecution thereof and shall furnish such records, information and testimony, provide
such witnesses and attend such conferences, discovery proceedings, hearings, trials and appeals as
may be reasonably requested in connection therewith. Such cooperation shall include access [***]
afforded to the indemnifying Party to, and reasonable retention by the Indemnified Party of, records
and information that are reasonably relevant to such Third Party Claim, and making Indemnified
Parties and other employees and agents available on a mutually convenient basis to provide
additional information and explanation of any material provided hereunder, and the indemnifying
Party shall reimburse the Indemnified Party for all its reasonable out-of-pocket expenses in
connection therewith, subject to refund if the Indemnifying Party is ultimately held not to be
obligated to indemnify the Indemnified Party.

11.4.5 Expenses. Except as provided above, the reasonable and verifiable costs and expenses,
including fees and disbursements of counsel, incurred by the Indemnified Party in connection with
any Third Party Claim shall be reimbursed on a [***] basis in arrears by the indemnifying Party,
without prejudice to the indemnifying Party's right to contest the Indemnified Party's right to
indemnification and subject to refund in the event the indemnifying Party is ultimately held not to
be obligated to indemnify the Indemnified Party.

11.5 Special, Indirect, and Other Losses. EXCEPT (A) FOR FRAUD, WILLFUL MISCONDUCT OR GROSS
NEGLIGENCE, (B) FOR A PARTY'S BREACH OF ITS OBLIGATIONS UNDER [ARTICLE 9 OR SECTION 5.8], (C) AS
PROVIDED UNDER [***] AND (D) TO THE EXTENT ANY SUCH DAMAGES ARE REQUIRED TO BE PAID TO A THIRD PARTY
AS PART OF A CLAIM FOR WHICH A PARTY PROVIDES INDEMNIFICATION UNDER THIS ARTICLE 11, NEITHER PARTY
NOR ANY OF ITS AFFILIATES SHALL BE LIABLE FOR INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, PUNITIVE OR
CONSEQUENTIAL DAMAGES, INCLUDING LOSS OF PROFITS OR BUSINESS INTERRUPTION, HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, TORT, NEGLIGENCE, BREACH OF STATUTORY DUTY OR OTHERWISE IN
CONNECTION WITH OR ARISING IN ANY WAY OUT OF THE TERMS OF THIS AGREEMENT OR THE TRANSACTIONS
CONTEMPLATED HEREBY OR THE USE OF THE LICENSED COMPOUNDS OR LICENSED PRODUCTS, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGES.

11.6 Insurance. Each Party shall obtain and carry in full force and effect the minimum insurance
requirements set forth herein. Such insurance (a) shall be primary insurance with respect to each
Party's own participation under this Agreement, (b) shall be issued by a recognized insurer rated by
A.M. Best "A-VII" (or its equivalent) or better, or an insurer pre- approved in writing by the other
Party, and (c) shall list the other Party as an additional insured under the General Liability
Policy.

11.6.1 Types and Minimum Limits. The types of insurance, and minimum limits shall be:

(a) Worker's Compensation with statutory limits in compliance with the Worker's Compensation laws of
the state or states in which the Party has employees in the United States (excluding Puerto Rico).

(b) Employer's Liability coverage with a minimum limit of [***] provided that a Party has employees
in the United States (excluding Puerto Rico).

- 61 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 66 -->
(c) General Liability Insurance with a minimum limit of [***] and [***] in the aggregate. General
Liability Insurance shall include Clinical Trial Insurance. The limits may be met with a combination
of primary and commercial umbrella insurance.

11.6.2 Certificates of Insurance. Upon request by a Party, the other Party shall provide
Certificates of Insurance evidencing compliance with this Section. The insurance policies shall be
under an occurrence form, but if only a claims-made form is available to a Party, then such Party
shall continue to maintain such insurance after the expiration or termination of this Agreement for
the longer of (a) a period of [***] following termination or expiration of this Agreement in its
entirety, or (b) with respect to a particular Party, [***] by a Party.

11.6.3 Self-Insurance. Notwithstanding the foregoing, AbbVie may self-insure, in whole or in part,
the insurance requirements described above.

ARTICLE 12 TERM AND TERMINATION

12.1 Term.

12.1.1 Term. This Agreement shall commence on the Effective Date and, unless earlier terminated in
accordance herewith, shall continue in force and effect until (a) the date of expiration of the last
Royalty Term for the last Licensed Product, or (b) the expiration of the License Option Period and
the failure of AbbVie to exercise the License Option (such period, the "Term").

12.1.2 Effect of Expiration of the Term. Following the expiration of the Term pursuant to clause (a)
(but not clause (b)) of Section 12.1.1, the grants in Section 5.1.3 shall become non-exclusive,
fully-paid, royalty-free and irrevocable.

12.2 Termination for Material Breach.

12.2.1 Material Breach. If either Party (the "Non-Breaching Party") believes that the other Party
(the "Breaching Party") has materially breached one (1) or more of its material obligations under
this Agreement, then the Non-Breaching Party may deliver notice of such material breach to the
Breaching Party (a "Default Notice"). If the Breaching Party does not dispute that it has committed
a material breach of one (1) or more of its material obligations under this Agreement, then if the
Breaching Party fails to cure such breach within ninety (90) days after receipt of the Default
Notice, or if such compliance cannot be fully achieved within such ninety- (90-) day period and the
Breaching Party has failed to commence compliance or has failed to use diligent efforts to achieve
full compliance as soon thereafter as is reasonably possible, the Non-Breaching Party may terminate
this Agreement upon written notice to the Breaching Party. If the Breaching Party disputes that it
has materially breached one (1) or more of its material obligations under this Agreement, the
dispute shall be resolved pursuant to Section 13.7. If, as a result of the application of such
dispute resolution procedures, the Breaching Party is determined to be in material breach of one (1)
or more of its material obligations under this Agreement (an "Adverse Ruling"), then if the
Breaching Party fails to complete the actions specified by the Adverse Ruling to cure such material
breach within [***] after such ruling, or if such compliance cannot be fully achieved within such
[***] period and the Breaching Party has failed to commence diligent efforts to achieve full
compliance as soon thereafter as is reasonably possible or as prescribed by the Arbitrator, then the
Non-Breaching Party may terminate this Agreement upon written notice to the Breaching Party.

12.2.2 Material Breach Related to Diligence in a Major Market. Notwithstanding Section 12.2.1, if
the material breach and failure to cure contemplated by Section 12.2.1 is

- 62 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 67 -->
with respect to AbbVie's Commercialization diligence obligations under Section 4.2 with respect to
any Major Market, [***].

12.2.3 Invocation of Material Breach. Notwithstanding the foregoing, the Parties agree that
termination pursuant to this Section 12.2 is a remedy to be invoked only if the breach is not (a)
cured in accordance with Section 12.2.1 (including the timeframes set forth therein), (b) remedied
through the payment of money damages determined in accordance with Section 13.7 or (c) adequately
remedied through a combination of (a) and (b).

12.3 Additional Termination Rights by AbbVie. AbbVie may terminate this Agreement in its entirety,
or on a country or other jurisdiction -by-country or other jurisdiction basis, for any or no reason,
upon ninety (90) days' prior written notice to Harpoon.

12.4 Termination for Insolvency. In the event that either Party (a) files for protection under
bankruptcy or insolvency laws, (b) makes an assignment for the benefit of creditors, (c) appoints or
suffers appointment of a receiver or trustee over substantially all of its property that is not
discharged within [***] after such filing, (d) is a party to any dissolution or liquidation, (e)
files a petition under any bankruptcy or insolvency act or has any such petition filed against it
that is not discharged within [***] of the filing thereof, or (f) admits in writing its inability
generally to meet its obligations as they fall due in the general course, then the other Party may
terminate this Agreement in its entirety effective immediately upon written notice to such Party.

12.5 Rights in Bankruptcy.

12.5.1 Applicability of 11 U.S.C. § 365(n). All rights and licenses (collectively, the "Intellectual
Property") granted under or pursuant to this Agreement, including all rights and licenses to use
improvements or enhancements developed during the Term, are intended to be, and shall otherwise be
deemed to be, for purposes of Section 365(n) of the United States Bankruptcy Code (the "Bankruptcy
Code") or any analogous provisions in any other country or jurisdiction, licenses of rights to
"intellectual property" as defined under Section 101(35A) of the Bankruptcy Code. The Parties agree
that the licensee of such Intellectual Property under this Agreement shall retain and may fully
exercise all of its rights and elections under the Bankruptcy Code, including Section 365(n) of the
Bankruptcy Code, or any analogous provisions in any other country or jurisdiction. All of the rights
granted to either Party under this Agreement shall be deemed to exist immediately before the
occurrence of any bankruptcy case in which the other Party is the debtor.

12.5.2 Rights of non-Debtor Party in Bankruptcy. If a bankruptcy proceeding is commenced by or
against either Party under the Bankruptcy Code or any analogous provisions in any other country or
jurisdiction, the non-debtor Party shall be entitled to a complete duplicate of (or complete access
to, as appropriate) any Intellectual Property and all embodiments of such Intellectual Property,
which, if not already in the non-debtor Party's possession, shall be delivered to the non- debtor
Party within [***] of such request; provided that the debtor Party is excused from its obligation to
deliver the Intellectual Property to the extent the debtor Party continues to perform all of its
obligations under this Agreement and the Agreement has not been rejected pursuant to the Bankruptcy
Code or any analogous provision in any other country or jurisdiction.

12.6 Termination in Entirety.

12.6.1 In the event of a termination of this Agreement in its entirety by AbbVie pursuant to Section
12.3, or by Harpoon pursuant to Section 12.2.1 or 12.4:

(a) all rights and licenses granted by Harpoon hereunder shall immediately terminate;

- 63 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020

(b) all rights and licenses granted by AbbVie hereunder shall immediately terminate;
<!-- page 68 -->
(c) subject to Section 12.10.2 and Section 12.7 (solely following the License Option Exercise
Closing Date), AbbVie shall cease any and all Exploitation of Licensed Compounds and Licensed
Products and transfer to Harpoon, or destroy (at Harpoon's sole election), copies of all data and
Information generated by AbbVie in connection with the Exploitation of Licensed Compounds or
Licensed Products, and all rights in such Licensed Compounds and Licensed Products shall revert back
to Harpoon; and

(d) if such termination occurs following the License Option Exercise Closing Date, Section 12.7
shall apply with respect to Licensed Compounds and Licensed Products that revert to Harpoon (the
"Harpoon Reversion Products").

12.6.2 If AbbVie terminates this Agreement in its entirety pursuant to Section 12.2.1 (subject to
Section 12.6.3 and Section 12.6.4) or 12.4:

(a) all rights and licenses granted by Harpoon hereunder shall immediately terminate, and AbbVie
shall have no further rights in connection with Licensed Compounds and Licensed Products; and

(b) all rights and licenses granted by AbbVie hereunder shall immediately terminate.

12.6.3 Prior to the exercise of the License Option, if AbbVie has the right to terminate this
Agreement in its entirety pursuant to Section 12.2.1 (i.e. by mutual agreement or as may be finally
determined by an Adverse Ruling), then within [***] following the expiration of the relevant cure
period, if any, AbbVie may, by written notice to Harpoon, and as its sole and exclusive remedy in
lieu of exercising its right under Section 12.2.1 with respect to such breach, elect to continue
this Agreement as modified by this Section 12.6.3, in which case, effective as of the date AbbVie
delivers notice of such election to Harpoon:

(a) [***]

(b) [***]

(c) [***]

(d) [***]

(e) [***]

(f) [***]

- 64 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 69 -->
(g) Following the License Exercise Option Closing Date, all provisions of this Agreement with
respect to AbbVie's rights and obligations following the exercise of the License Option shall apply,
provided that [***]; and

(h) If the Post CSR Option Period expires without AbbVie delivering a License Option Exercise
Notice, then all rights and licenses granted by Harpoon hereunder shall immediately terminate, and
AbbVie shall have no further rights in connection with Licensed Compounds and Licensed Products.

12.6.4 Following the License Option Exercise Closing Date, if AbbVie has the right to terminate this
Agreement in its entirety pursuant to Section 12.2.1 (i.e. by mutual agreement or as may be finally
determined by an Adverse Ruling), then within [***] following the expiration of the relevant cure
period, if any, AbbVie may, by written notice to Harpoon, and as its sole and exclusive remedy in
lieu of exercising its right under Section 12.2.1 with respect to such breach, elect to continue
this Agreement as modified by this Section 12.6.4, in which case, effective as of the date AbbVie
delivers notice of such election to Harpoon :

(a) [***]

(b) [***]

(c) [***]

(d) [***]

12.6.5 Following the License Option Exercise Closing Date, if AbbVie has the right to terminate this
Agreement in its entirety pursuant to Section 12.4, but elects to retain its rights and licenses
pursuant to Section 12.5:

(a) [***]

(b) [***]

(c) [***]

- 65 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 70 -->
(d) [***].

12.7 Reversion of Harpoon Products. Following the License Option Exercise Closing Date, if this
Agreement terminates in its entirety, except for termination by AbbVie pursuant to Section 12.2.1 or
Section 12.4, the following shall apply with respect to Harpoon Reversion Products.

12.7.1 At Harpoon's sole election by written notice to AbbVie, AbbVie shall grant, and hereby grants
to Harpoon, effective as of the effective date of termination, [***] (the "AbbVie Reversion IP");
provided that the foregoing license shall exclude (1) any license or other rights with respect to
any active ingredient that is not a Licensed Compound and (2) any license or other rights with
respect to any other Patents or Know-How owned or controlled by AbbVie or any of its Affiliates. The
foregoing license under the AbbVie Reversion IP shall be payable on a country-by-country basis and
[***] (applied mutatis mutandis to Harpoon) by Harpoon, its Affiliates or sublicensees of Harpoon
Reversion Products, beginning [***].

12.7.2 AbbVie shall [***], within a reasonable time following the effective date of termination,
[***] that was transferred by Harpoon to AbbVie with respect to each Harpoon Reversion Product.

12.7.3 At Harpoon's request, AbbVie shall [***] in connection with Harpoon Reversion Products prior
to reversion of such Harpoon Reversion Products.

12.7.4 AbbVie shall [***] pertaining to the applicable Harpoon Reversion Products in its possession
or Control.

12.7.5 With respect to any Licensed Product that becomes a Harpoon Reversion Product during any
period in which AbbVie is [***] for such Licensed Product, AbbVie shall [***]

- 66 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 71 -->
[***], provided that Harpoon [***] the foregoing obligations.

12.7.6 If a [***], AbbVie shall [***]. Additionally, upon any Licensed Compound or Licensed Product
becoming a Harpoon Reversion Product, AbbVie shall [***]

12.7.7 To the extent that AbbVie [***] for the Commercialization of a Harpoon Reversion Product
[***], Harpoon shall have the right to [***]. Harpoon shall exercise such right by written notice to
AbbVie within [***] after such Licensed Compound or Licensed Product becomes a Harpoon Reversion
Product.

12.7.8 AbbVie shall [***], as may be necessary under, or as Harpoon may reasonably request in
connection with Harpoon's rights under this Section 12.7.

12.8 Termination of Terminated Territory. In the event of a termination of this Agreement with
respect to a country or other jurisdiction by AbbVie pursuant to Section 12.3 or with respect to a
Terminated Territory by Harpoon pursuant to Section 12.2.2 (but not in the case of any termination
of this Agreement in its entirety), the term "Territory" shall be automatically amended to exclude
the Terminated Territory and all rights and licenses granted by Harpoon hereunder (a) shall
automatically be deemed to be amended to exclude, if applicable, the right to market, promote,
detail, distribute, import, sell, offer for sale, file any Drug Approval Application for, or seek
any Regulatory Approval for Licensed Compound or Licensed Products in such Terminated Territory, and
(b) shall otherwise survive and continue in effect in such Terminated Territory solely for the
purpose of furthering any Commercialization of the Licensed Compounds or Licensed Products in the
Territory other than the Terminated Territory or any Development or Manufacturing in support
thereof.

12.9 Remedies. Except as otherwise expressly provided herein, termination of this Agreement (either
in its entirety or with respect to one (1) or more country(ies) or other jurisdiction(s)) in
accordance with the provisions hereof shall not limit remedies that may otherwise be available in
law or equity.

12.10 Accrued Rights; Surviving Obligations.

12.10.1 Termination or expiration of this Agreement (either in its entirety or with respect to one
(1) or more country(ies) or other jurisdiction(s)) for any reason shall be without prejudice to any
rights that shall have accrued to the benefit of a Party prior to such termination or expiration.
Such termination or expiration shall not relieve a Party from obligations that are expressly
indicated to survive the termination or expiration of this Agreement. Without limiting the
foregoing, Sections 3.6 [***]; 3.8.5 (solely for the purposes, and in accordance with the time
periods, set forth therein); 4.6.1 (with respect to any amounts incurred prior to the effective date
of termination and subject to reimbursement by AbbVie); 6.2 through 6.6 (with respect to payments
for milestone events or Net Sales occurring prior to the effective date of termination); Sections
6.7 through 6.13; Sections 7.1.1 through 7.1.4 (with respect to Patents and Know-How conceived,
discovered, developed, or otherwise made prior to expiration or termination of this

- 67 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 72 -->
Agreement); Section 7.9 (with respect to information exchanged prior to the effective date of
termination); Sections 11.1 through 11.5; 12.1.2 and the grants referenced therein (with respect to
expiration, but not termination, of this Agreement), 12.5 through 12.8 (with respect to termination,
but not expiration, of this Agreement and in accordance with the time periods set forth therein),
12.10, 13.2, 13.3 through 13.13, and 13.15 through 13.20 of this Agreement shall survive the
termination or expiration of this Agreement for any reason (unless the reason is expressly limited
therein), and Articles 1 (to the extent used in other surviving provisions) and 9 of this Agreement
shall survive the termination or expiration of this Agreement for any reason. If this Agreement is
terminated with respect to the Terminated Territory but not in its entirety, then following such
termination the foregoing provisions of this Agreement shall remain in effect with respect to the
Terminated Territory (to the extent they would survive and apply in the event the Agreement expires
or is terminated in its entirety), and all provisions not surviving in accordance with the foregoing
shall terminate upon termination of this Agreement with respect to the Terminated Territory and be
of no further force and effect (and, for purposes of clarity, all provisions of this Agreement shall
remain in effect with respect to all countries in the Territory other than the Terminated
Territory).

12.10.2 If AbbVie terminates this Agreement with respect to a country or other jurisdiction, or in
its entirety pursuant to Section 12.3, AbbVie shall have the right for at least [***] and no more
than [***], which period shall be determined by Harpoon in its sole discretion, after the effective
date of such termination with respect to such country or other jurisdiction to sell or otherwise
dispose of all Licensed Compound or Licensed Product then in its inventory and any in-progress
inventory, in each case that is intended for sale or disposition in such country or other
jurisdiction, as though this Agreement had not terminated with respect to such country or other
jurisdiction, and such sale or disposition shall not constitute infringement of Harpoon's or its
Affiliates' Patent or other intellectual property or other proprietary rights. Within [***] from the
expiration from this period, AbbVie shall furnish Harpoon a statement showing the quantities of
Licensed Products then in AbbVie's inventory and any in- progress inventory. For purposes of
clarity, AbbVie shall continue to make payments thereon as provided in Article 6 (as if this
Agreement had not terminated with respect to such Major Market or country or other jurisdiction).

ARTICLE 13 MISCELLANEOUS

13.1 Force Majeure. Neither Party shall be held liable or responsible to the other Party or be
deemed to have defaulted under or breached this Agreement for failure or delay in fulfilling or
performing any term of this Agreement when such failure or delay is caused by or results from events
beyond the reasonable control of the non-performing Party, including fires, floods, earthquakes,
hurricanes, embargoes, shortages, epidemics, quarantines, war, acts of war (whether war be declared
or not), terrorist acts, insurrections, riots, civil commotion, acts of God or acts, omissions or
delays in acting by any governmental authority (except to the extent such delay results from the
breach by the non-performing Party or any of its Affiliates of any term or condition of this
Agreement). The non-performing Party shall notify the other Party of such force majeure within [***]
after such occurrence by giving written notice to the other Party stating the nature of the event,
its anticipated duration, and any action being taken to avoid or minimize its effect. The suspension
of performance shall be of no greater scope and no longer duration than is necessary and the
non-performing Party shall use commercially reasonable efforts to remedy its inability to perform.

13.2 Change in Control of Harpoon.

13.2.1 Harpoon (or its successor) shall provide AbbVie with written notice of any Change in Control
of Harpoon or Acquisition by Harpoon within [***] following the closing date of such transaction.

13.2.2 In the event of [***]

- 68 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 73 -->
13.3 Export Control. This Agreement is made subject to any restrictions concerning the export of
products or technical information from the United States or other countries that may be imposed on
the Parties from time to time. Each Party agrees that it will not export, directly or indirectly,
any technical information acquired from the other Party under this Agreement or any products using
such technical information to a location or in a manner that at the time of export requires an
export license or other governmental approval, without first obtaining the written consent to do so
from the appropriate agency or other governmental entity in accordance with Applicable Law.

13.4 Assignment.

13.4.1 Without the prior written consent of the other Party, such consent not to be unreasonably
withheld, conditioned, or delayed, neither Party shall sell, transfer, assign, delegate, pledge, or
otherwise dispose of, whether voluntarily, involuntarily, by operation of law or otherwise, this
Agreement or any of its rights or duties hereunder; provided that either Party may make such an
assignment without the other Party's consent to its Affiliate or to a successor, whether in a
merger, sale of stock, sale of assets or any other transaction, of the business to which this
Agreement relates. With respect to an assignment to an Affiliate, the assigning Party shall remain
responsible for the performance by such Affiliate of the rights and obligations hereunder. Any
attempted assignment or delegation in violation of this Section 13.4 shall be void and of no effect.
All validly assigned and delegated rights and obligations of the Parties hereunder shall be binding
upon and inure to the benefit of and be enforceable by and against the successors and permitted
assigns of Harpoon or AbbVie, as the case may be. The permitted assignee or transferee shall assume
all obligations of its assignor or transferor under this Agreement. Without limiting the foregoing,
the grant of rights set forth in this Agreement shall be binding upon any successor or permitted
assignee of Harpoon, and the obligations of AbbVie, including the payment obligations, shall run in
favor of any such successor or permitted assignee of Harpoon's benefits under this Agreement.

13.4.2 [***]

- 69 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 74 -->
13.5 Severability. If any provision of this Agreement is held to be illegal, invalid, or
unenforceable under any present or future law, and if the rights or obligations of either Party
under this Agreement will not be materially and adversely affected thereby, (a) such provision shall
be fully severable, (b) this Agreement shall be construed and enforced as if such illegal, invalid,
or unenforceable provision had never comprised a part hereof, (c) the remaining provisions of this
Agreement shall remain in full force and effect and shall not be affected by the illegal, invalid,
or unenforceable provision or by its severance herefrom, and (d) in lieu of such illegal, invalid,
or unenforceable provision, there shall be added automatically as a part of this Agreement a legal,
valid, and enforceable provision as similar in terms to such illegal, invalid, or unenforceable
provision as may be possible and reasonably acceptable to the Parties. To the fullest extent
permitted by Applicable Law, each Party hereby waives any provision of law that would render any
provision hereof illegal, invalid, or unenforceable in any respect.

13.6 Governing Law, Jurisdiction and Service.

13.6.1 Governing Law. This Agreement or the performance, enforcement, breach or termination hereof
shall be interpreted, governed by and construed in accordance with the laws of the State of
Delaware, United States, excluding any conflicts or choice of law rule or principle that might
otherwise refer construction or interpretation of this Agreement to the substantive law of another
jurisdiction; provided that all questions concerning (a) inventorship of Patents under this
Agreement shall be determined in accordance with Section 7.1.3 and (b) the construction or effect of
Patents shall be determined in accordance with the laws of the country or other jurisdiction in
which the particular Patent has been filed or granted, as the case may be. The Parties agree to
exclude the application to this Agreement of the United Nations Convention on Contracts for the
International Sale of Goods.

13.6.2 Service. Each Party further agrees that service of any process, summons, notice or document
by registered mail to its address set forth in Section 13.8.2 shall be effective service of process
for any action, suit, or proceeding brought against it under this Agreement in any such court.

13.7 Dispute Resolution. Except for disputes resolved by the procedures set forth in Sections 2.2.3,
3.1.2, 6.12 or 13.11, if a dispute arises between the Parties in connection with or relating to this
Agreement, including the determination of the scope or applicability of this Section 13.7 and the
agreement to arbitrate, or any document or instrument delivered in connection herewith (a
"Dispute"), it shall be resolved pursuant to this Section 13.7.

13.7.1 General. Any Dispute shall first be referred to the Senior Officers of the Parties, who shall
confer in good faith on the resolution of the issue. Any final decision mutually agreed to by the
Senior Officers shall be conclusive and binding on the Parties. If the Senior Officers are not able
to agree on the resolution of any such issue within [***] (or such other period of time as mutually
agreed by the Senior Officers) after such issue was first referred to them, then, except as
otherwise set forth in Section 13.7.2, either Party may, by written notice to the other Party, elect
to initiate an arbitration proceeding pursuant to the procedures set forth in Section 13.7.3, which
shall fully and finally settle the Dispute.

13.7.2 Intellectual Property Disputes. In the event that a Dispute arises with respect the validity,
enforceability, or patentability of any Patent, Trademark or other intellectual property rights, and
such Dispute cannot be resolved in accordance with Section 13.7.1, unless otherwise agreed by the
Parties in writing, such Dispute shall not be submitted to an arbitration proceeding in accordance
with Section 13.7.3 and instead, either Party may initiate litigation in a court of competent
jurisdiction, notwithstanding Section 13.6, in any country or other jurisdiction in which such
rights apply. In case of a Dispute between the Parties with respect to inventorship, the Parties
shall jointly select a patent attorney registered before the United States Patent and Trademark
Office and submit such Dispute to the mutually-selected patent attorney for resolution under the
United States patent law. The decision of such patent attorney with respect to inventorship shall be
final, and the Parties agree to be bound by the decision and share equally the expenses of such
patent attorney.

- 70 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 75 -->
13.7.3 Arbitration. Any arbitration proceeding under this Agreement shall take place pursuant to the
procedures set forth in Schedule 13.7.3.

13.7.4 Adverse Ruling. Any determination pursuant to this Section 13.7 that a Party is in material
breach of its material obligations hereunder shall specify a (nonexclusive) set of actions to be
taken to cure such material breach, if feasible.

13.7.5 Interim Relief. Notwithstanding anything herein to the contrary, nothing in this Section 13.7
shall preclude either Party from seeking interim or provisional relief, including a temporary
restraining order, preliminary injunction or other interim equitable relief concerning a Dispute, if
necessary to protect the interests of such Party. This Section shall be specifically enforceable.

13.8 Notices.

13.8.1 Notice Requirements. Any notice, request, demand, waiver, consent, approval, or other
communication permitted or required under this Agreement shall be in writing, shall refer
specifically to this Agreement and shall be deemed given only if (a) delivered by hand, (b) sent by
facsimile transmission (with transmission confirmed), or (c) by internationally recognized overnight
delivery service that maintains records of delivery, addressed to the Parties at their respective
addresses specified in Section 13.8.2 or to such other address as the Party to whom notice is to be
given may have provided to the other Party in accordance with this Section 13.8.1. Such notice shall
be deemed to have been given as of the date delivered by hand or transmitted by facsimile (with
transmission confirmed) or on the [***] (at the place of delivery) after deposit with an
internationally recognized overnight delivery service. Any notice delivered by facsimile shall be
confirmed by a hard copy delivered as soon as practicable thereafter. This Section 13.8.1 is not
intended to govern the day-to-day business communications necessary between the Parties in
performing their obligations under the terms of this Agreement.

13.8.2 Address for Notice.

If to AbbVie, to:

AbbVie Biotechnology LTD c/o Conyers, Dill & Pearman, Clarendon House, 2 Church Street, Hamilton HM
11 Bermuda with a copy (which shall not constitute notice) to:

AbbVie Inc. 1 North Waukegan Road North Chicago, Illinois 60064 United States Attention: [***]
Facsimile: [***] If to Harpoon, to: Harpoon Therapeutics, Inc. 131 Oyster Point Blvd, Suite 300
South San Francisco, CA 94080 Attention: [***]

- 71 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020

with a copy (which shall not constitute notice) to:
<!-- page 76 -->
Cooley LLP 3175 Hanover Street Palo Alto, CA 94304 Attention: [***] Email: [***]

13.9 Entire Agreement; Amendments. This Agreement, together with the Schedules attached hereto, sets
forth and constitutes the entire agreement and understanding between the Parties with respect to the
subject matter hereof and all prior agreements, understandings, promises, and representations,
whether written or oral, with respect thereto are superseded hereby (including that certain Mutual
Confidentiality Disclosure Agreement between the Parties or their respective Affiliates dated [***]
(the "Prior NDA"). The foregoing shall not be interpreted as a waiver of any remedies available to
either Party as a result of any breach, prior to the Effective Date, by the other Party (or its
Affiliates) of its obligations under the Prior NDA. Each Party confirms that it is not relying on
any representations or warranties of the other Party except as specifically set forth in this
Agreement. No amendment, modification, release, or discharge with respect to this Agreement shall be
binding upon the Parties unless in writing and duly executed by authorized representatives of both
Parties.

13.10 English Language. This Agreement shall be written and executed in, and all other
communications under or in connection with this Agreement shall be in, the English language. Any
translation into any other language shall not be an official version thereof, and in the event of
any conflict in interpretation between the English version and such translation, the English version
shall control.

13.11 Equitable Relief. Each Party acknowledges and agrees that the restrictions set forth in
Section 5.8 and Articles 7 and 9 are reasonable and necessary to protect the legitimate interests of
the other Party and that such other Party would not have entered into this Agreement in the absence
of such restrictions, and that any breach or threatened breach of any provision of such Section or
Articles may result in irreparable injury to such other Party for which there may be no adequate
remedy at law. In the event of a breach or threatened breach of any provision of such Section or
Articles, the non-breaching Party shall be authorized and entitled to seek from any court of
competent jurisdiction injunctive relief, whether preliminary or permanent, specific performance,
and an equitable accounting of all earnings, profits, and other benefits arising from such breach,
which rights shall be cumulative and in addition to any other rights or remedies to which such
non-breaching Party may be entitled in law or equity. Both Parties agree to waive any requirement
that the other (a) post a bond or other security as a condition for obtaining any such relief, and
(b) show irreparable harm, balancing of harms, consideration of the public interest, or inadequacy
of monetary damages as a remedy. Nothing in this Section 13.11 is intended, or should be construed,
to limit either Party's right to equitable relief or any other remedy for a breach of any other
provision of this Agreement.

13.12 Waiver and Non-Exclusion of Remedies. Any term or condition of this Agreement may be waived at
any time by the Party that is entitled to the benefit thereof, but no such waiver shall be effective
unless set forth in a written instrument duly executed by or on behalf of the Party waiving such
term or condition. The waiver by either Party hereto of any right hereunder or of the failure to
perform or of a breach by the other Party shall not be deemed a waiver of any other right hereunder
or of any other breach or failure by such other Party whether of a similar nature or otherwise. The
rights and remedies provided herein are cumulative and do not exclude any other right or remedy
provided by Applicable Law or otherwise available except as expressly set forth herein.

13.13 No Benefit to Third Parties. Except as provided in Article 11, covenants and agreements set
forth in this Agreement are for the sole benefit of the Parties hereto and their successors and
permitted assigns, and they shall not be construed as conferring any rights on any other Persons.

- 72 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 77 -->
13.14 Further Assurance. Each Party shall duly execute and deliver, or cause to be duly executed and
delivered, such further instruments and do and cause to be done such further acts and things,
including the filing of such assignments, agreements, documents, and instruments, as may be
necessary or as the other Party may reasonably request in connection with this Agreement or to carry
out more effectively the provisions and purposes hereof, or to better assure and confirm unto such
other Party its rights and remedies under this Agreement.

13.15 Relationship of the Parties. It is expressly agreed that Harpoon, on the one hand, and AbbVie,
on the other hand, shall be independent contractors and that the relationship between the Parties
shall not constitute a partnership, joint venture, or agency, including for all tax purposes.
Further, the Parties (and any successor, assignee, transferee, or Affiliate of a Party) shall not
treat or report the relationship between the Parties arising under this Agreement as a partnership
for United States tax purposes, without the prior written consent of the other Party unless required
by a final "determination" as defined in Section 1313 of the United States Internal Revenue Code of
1986, as amended. Neither Harpoon, on the one hand, nor AbbVie, on the other hand, shall have the
authority to make any statements, representations, or commitments of any kind, or to take any
action, which shall be binding on the other, without the prior written consent of the other Party to
do so. All persons employed by a Party shall be employees of such Party and not of the other Party
and all costs and obligations incurred by reason of any such employment shall be for the account and
expense of such Party.

13.16 Performance by Affiliates. AbbVie may use one (1) or more of its Affiliates to perform its
obligations and duties hereunder and such AbbVie Affiliates are expressly granted certain rights
herein; provided that each such Affiliate shall be bound by the corresponding obligations of AbbVie
and, subject to an assignment to such Affiliate pursuant to Section 13.4, AbbVie shall remain liable
hereunder for the prompt payment and performance of all their respective obligations hereunder.

13.17 Counterparts; Facsimile Execution. This Agreement may be executed in two (2) counterparts,
each of which shall be deemed an original, but all of which together shall constitute one (1) and
the same instrument. This Agreement may be executed by facsimile or electronically transmitted
signatures and such signatures shall be deemed to bind each Party hereto as if they were original
signatures.

13.18 References. Unless otherwise specified, (a) references in this Agreement to any Article,
Section or Schedule shall mean references to such Article, Section or Schedule of this Agreement,
(b) references in any Section to any clause are references to such clause of such Section, and (c)
references to any agreement, instrument, or other document in this Agreement refer to such
agreement, instrument, or other document as originally executed or, if subsequently amended,
replaced, or supplemented from time to time, as so amended, replaced, or supplemented and in effect
at the relevant time of reference thereto.

13.19 Schedules. In the event of any inconsistencies between this Agreement and any schedules or
other attachments hereto, the terms of this Agreement shall control.

13.20 Construction. Except where the context otherwise requires, wherever used, the singular shall
include the plural, the plural the singular, the use of any gender shall be applicable to all
genders and the word "or" is used in the inclusive sense (and/or). Whenever this Agreement refers to
a number of days, unless otherwise specified, such number refers to calendar days. The captions of
this Agreement are for convenience of reference only and in no way define, describe, extend, or
limit the scope or intent of this Agreement or the intent of any provision contained in this
Agreement. The term "including," "include," or "includes" as used herein shall mean "including, but
not limited to," and shall not limit the generality of any description preceding such term. The
language of this Agreement shall be deemed to be the language mutually chosen by the Parties and no
rule of strict construction shall be applied against either Party hereto. Each Party represents that
it has been represented by legal counsel in connection with this Agreement and acknowledges that it
has participated in the drafting hereof. In interpreting and applying the terms and provisions of
this

- 73 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 78 -->
Agreement, the Parties agree that no presumption will apply against the Party which drafted such
terms and provisions.

[SIGNATURE PAGE FOLLOWS]

- 74 -

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 79 -->
THIS AGREEMENT IS EXECUTED by the authorized representatives of the Parties as of the Effective
Date. HARPOON THERAPEUTICS, INC. ABBVIE BIOTECHNOLOGY LTD By: /s/ Gerald McMahon Name: Gerald
McMahon Title: President and CEO

By: /s/ Robert Michael Name: Robert Michael Title: Director

[SIGNATURE PAGE TO DEVELOPMENT AND OPTION AGREEMENT]

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 80 -->
Schedule 1.84

Initial Development Plan

[***]

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020

Schedule 1.99
<!-- page 81 -->
Licensed Compound

[***]

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
<!-- page 82 -->
Schedule 3.7

Pre-Approved Third Party Providers

[***]

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020

Schedule 10.2
<!-- page 83 -->
Disclosure Schedules

[***]

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020

Schedule 10.2.1
<!-- page 84 -->
Existing Patents [***]

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020

Schedule 13.7.3
<!-- page 85 -->
Arbitration

[***]

Source: HARPOON THERAPEUTICS, INC., 10-K, 3/12/2020
