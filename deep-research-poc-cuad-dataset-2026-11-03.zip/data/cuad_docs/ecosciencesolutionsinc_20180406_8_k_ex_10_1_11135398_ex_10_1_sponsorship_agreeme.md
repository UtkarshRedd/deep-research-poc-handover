<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 2018-04-01 |
| Parties | Fruit of Life Productions LLC ("Promoter"); Eco Science Solutions, Inc. ("Sponsor") |
| Source | CUAD v1 / EcoScienceSolutionsInc_20180406_8-K_EX-10.1_11135398_EX-10.1_Sponsorship Agreement |

SPONSORSHIP AGREEMENT This agreement (the "Agreement") is made effective this 1st day of April, 2018
("Effective Date") between Fruit of Life Productions LLC, ("Promoter") and Eco Science Solutions,
Inc.,("Sponsor"), 1135 Makawao Avenue, Suite 103-188, Makawao, Hawaii, 96768.

Contribution by Sponsor: In consideration for the right to sponsor the Kaya Fest and to be
acknowledged by Fruit of Life Productions LLC., as a Promoter of the event during the term of this
Agreement, Sponsor agrees to contract with Fruit of Life Productions LLC., for the amount of
$250,000.00 to be paid in full upon signing of this agreement.

Bank Wire Transformation Information See Attached Wire Instructions

Sponsorship Benefits for Presenting Partner Sponsor:

* Main Stage named after your brand * 4 10x10 on site vendor booths * 50 VIP Sponsor Passes / 50 GA
tickets for both days * 4 Parking passes * Opportunity to participate in after party * Banner
placement in venue (10) * Approved audio/video assets to be provided as promotional use for Herbo *
Name and phrase called out on stage between performers set * Your logo and a link from our website
to your website * Your logo on video wall * Your company name and logo as a presenting sponsor *
Banner at main entrance of venue * On stage banner placement * Logo in Backstage/VIP area * Mention
on social media * Logo on Step and Repeat * Logo on all promotional print

Terms and Termination: The term of this agreement will begin on April 1, 2018 and continue until
April 30, 2018 at 11:59pm.

Relationship of Parties: The parties are independent contractors with respect to one another.
Nothing in this Agreement shall create any association, joint venture, partnership or agency
relationship of any kind between the parties.

1

Source: ECO SCIENCE SOLUTIONS, INC., 8-K, 4/6/2018
<!-- page 2 -->
Intellectual Property: Fruit of Life Productions LLC is the sole owner of all right, title and
interest to all Kaya Fest information including Logo, tag lines, (Education before Recreation),
Trademarks, trade names and copyrighted information. Sponsor agrees that it will not use Kaya Fest
property in a manner that states or implies that Kaya Fest endorses Sponsor (or Sponsors products or
services) without written approval from Fruit of Life Productions LLC.

Idemnification: Sponsor shall indemnify and hold harmless, Fruit of Life Productions LLC, its
related entities, partners, agents, officers, directors, employees, attorneys, heirs, successors,
and assigns from against any and all claims, losses, damages, judgments, settlements, costs and
expenses (including reasonable attorney's fees and expenses), and liabilities of every kind incurred
as a result of: (i) any act or omission by Sponsor or its officers, directors, entities, employees,
agents; (ii) any use of Sponsor's name, logo, Website, or other information, products, or service
provided by Sponsor; and/or (iii) the inaccuracy or breach of any of the covenants, representations
and warranties made by Sponsor in this Agreement. (iv) any changes in company value or brand value.
The attendance and marketing reach estimates made in negotiations were made for the purposes of this
agreement are mere estimate and not be interpreted as guaranties. . Confidentiality Confidential
Information is all information that is marked such and all other information which a reasonable
person would consider to be confidential. Confidential Information shall include, but is not limited
to, information regarding the organization, its operations, programs, activities, financial
condition, strategies, timelines, corporate/programming roadmap, surprise performers/guest
appearances, event access information and membership or customer list. During the Term, each party
shall use and reproduce the other party's Confidential Information only for purposes of this
Agreement with written authorization by disclosing party, and only to the extent necessary for such
purpose. Each party shall restrict disclosure of the other party's Confidential Information to its
employees and agents with a reasonable need to know such Confidential Information, and shall not
disclose the other party's Confidential Information to any third party without the prior written
consent of the other party.

Cancellation: Kaya Fest shall not be liable to any Sponsor for losses arising out of, or the
inability to perform its obligations under the terms of this sponsorship proposal due to acts of
God, which include, that are not limited to, fire, flood, tornados, hurricanes, severe increments
weather, strikes, medical failure, or any other acts beyond the control of Kaya Fest. Exhibiting:
Sponsors are bound by the same terms and conditions, if exhibiting, as all other vendors of event.
Sponsors must have their own liability insurance with limits of one million dollars.

Banners: Sponsors are responsible for creating their own banners. Banners placement will be
determined by the Promoter. Sponsors are responsible for the hanging of their banners and removal
after the event. Banners must be responsibility secured and not have any dangerous edges/sticks that
may not cause harm if used inappropriately.

General Provisions: Warranties: Each party covenants, warrants and represents that it shall comply
with all laws and regulations applicable to this Agreement performance of its obligations, and that
it shall exercise due care and act in good faith at all times in the performance of its obligations
hereunder. The provisions of this section shall survive termination of this Agreement. This
agreement is not an attempt to give legal advice or constraints as it relates to Florida law and
Cannabis/Marijuana law in any jurisdiction. The Sponsor understands that they are free to seek legal
advice on the content of this agreement and applicable law from independent counsel. Binding effect:
This Agreement shall bind the parties, their respective heirs, personal representatives, successors
and assigns.

2

Source: ECO SCIENCE SOLUTIONS, INC., 8-K, 4/6/2018
<!-- page 3 -->
Governing Law: This Agreement shall be governed by and interpreted in accordance with the laws of
the State of Florida, without regard to its conflict-of-laws or choice-of law principles. In case of
a dispute, the parties agree to pursue Arbitration as the preferred method to seek a remedy and the
parties waive the right to a jury trial. Assignment: This Agreement, or the rights granted under it,
may not be assigned transferred or sublicense by either party without the express prior written
consent of the other party. Entire Agreement: This Agreement and its attachments constitute the
entire agreement between the parties and supersede all prior agreements, oral or written, relating
to the Sponsorship. This Agreement may only be admitted in a writing signed by both parties. The
agreement is confidential, and the parties agree not to file or record in public records. Notice:
All notices given under this Agreement shall be in writing, addressed to the parties at the
addresses set forth below, and shall be deemed to have the duly given when delivered when sent by
overnight courier, or certified mail (return receipt requested).

Fruit of Life Productions LLC (Promoter) Address: 16115 SW 117t h Ave. Suite 21-A Miami, Florida
33177

EcoScience Solutions, Inc. (Sponsor) Address: 1135 Makawao Avenue, Suite 103-188 Makawao, Hawaii
96768

The Sponsor agrees that upon acceptance, this agreement shall be deemed to form and binding contract
between the Sponsor and Promoter. The Sponsor agrees to abide by the terms set forth in the Terms
and Conditions of Sponsorship agreement.

All parties have executed this Agreement through their duly authorized representatives as of the
first date written below.

Sponsor: Eco Science Solutions, Inc.

By: /s/Jeffery Taylor Name: Jeffery Taylor Title: CEO Date: 4/01/2018

Promoter: Fruit of Life Productions LLC:

By:/s/Stella McLaughlan Name: Stella McLaughlan Title: Event Coordinator Date: 4/01/2018

3

Source: ECO SCIENCE SOLUTIONS, INC., 8-K, 4/6/2018
