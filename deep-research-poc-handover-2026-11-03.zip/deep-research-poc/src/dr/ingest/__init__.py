"""Ingest: load the already-parsed markdown + metadata into DocRecords.

load.py      directory of .md (+ optional meta.json sidecars) -> list[DocRecord]
metadata.py  parse the metadata block from the first ~2 pages (or extract with a small model)
pages.py     derive '<!-- page N -->' markers from the raw PDFs if the markdown lacks them
"""
