<!-- page 1 -->
# MARINE TRANSPORTATION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Transportation Agreement |
| Agreement Date | 2003-12-23 |
| Parties | Martin Operating Partnership L.P. ("Owner"); Midstream Fuel Service LLC ("Charterer") |
| Source | CUAD v1 / MARTINMIDSTREAMPARTNERSLP_01_23_2004-EX-10.3-TRANSPORTATION SERVICES AGREEMENT |

EXHIBIT 10.3

TRANSPORTATION SERVICES AGREEMENT

THIS MARINE TRANSPORTATION AGREEMENT (this "Agreement") is executed this 23rd day of December, 2003,
by and between Martin Operating Partnership L.P., a Delaware limited partnership ("Owner"), and
Midstream Fuel Service LLC, an Alabama limited liability company ("Charterer"), in order to evidence
the agreement of such parties with respect to Owner's provision of marine transportation services
with respect to #2 fuel oil and high sulfur diesel on board its marine vessels under the following
terms and conditions.

1. TERM; TERMINATION

The initial term of this Agreement shall be for 3 years (the "Initial Term") commencing on the date
first set forth above (the "Commencement Date") and ending on the 3rd anniversary of the
Commencement Date. This Agreement will automatically renew for successive one year terms (each a
"Renewal Term", and together with the Initial Term, the "Term"), unless either Charterer or Owner
elects not to renew this Agreement by providing the other party with written notice of such election
30 days prior to the expiration of the Initial Term or Renewal Term, as applicable, at which point
this Agreement will automatically terminate.

Within 30 days of the end of the Initial Term, and within 30 days of the end of each Renewal Term,
both parties hereto shall have the right renegotiate the fee specified below for the use of the
vessels. If no such agreement on such fee is reached by such parties by the commencement of a
Renewal Term, this Agreement shall automatically terminate.

Either party hereto shall have the right to terminate this Agreement in the event of a breach by the
other party of its obligations hereunder, subject to 10 days prior written notice of such breach
given by the non-breaching party to the breaching party and the opportunity for such breaching party
to cure such breach during such 10 day period. Upon any such termination, this Agreement shall
thereafter have no further force or effect except as to already accrued rights and obligations,
which shall continue until satisfied. 2. GENERAL TERMS

During the Term, Charterer agrees that Owner will be the sole and exclusive provider of marine
transportation services for #2 fuel oil and high sulfur diesel owned by Charterer or owned by others
and in transit for sale to Charterer so long as Owner has the required equipment available. Owner
shall at all times provide sufficient and proper equipment for Charterer's performance of such
transportation. Said equipment shall be manned, equipped, supplied and operated by Owner. The master
and crew of said vessels shall be fully qualified, experience and, where necessary, certified and
licensed. Owner agrees that said equipment shall be maintained in a seaworthy, staunch, tight and
suitable condition and, to the best of Owner's knowledge, in compliance with all applicable laws and
regulations.

In connection with its use of any vessel, Charterer will follow Owner's normal scheduling, loading
and offloading protocols established from time to time, subject to Owner's obligations set forth in
this Agreement.

1
<!-- page 2 -->
3. RATE

Charterer agrees to pay to Owner a fee of $______ per gallon of product transported. Owner will
invoice such fees to Charterer on a monthly basis and Charterer will pay such invoiced amounts
within 30 days of invoice date.

The fee stated above, unless otherwise adjusted by the parties pursuant to Section 1 above, shall be
adjusted annually (both upward and downward), by a factor equal to the amount of increase or
decrease, as the case may be, in the Consumer Price Index for the immediately proceeding month of
November, over the Consumer Price Index for November of the preceding year. For purposes hereof, the
term "Consumer Price Index" shall mean the "Consumer Price Index for Urban Wage Earners and Clerical
Workers (1967=100)" specified for "All Items. United States" compiled by the Bureau of Labor
Statistics of the United States Department of Labor (the "Index"). In the event the Consumer Price
Index shall be converted to a different standard reference base or otherwise revised, the
determination of the percentage change shall be made with the use of such conversion factor, formula
or table for converting the Consumer Price Index as may be published by the Bureau of Labor
Statistics or, if said Bureau shall not publish the same, then as shall be reasonably determined by
the parties. 4. LOAD AND DISCHARGE

The Load Port shall be FOB Refinery Offtake in the U.S. Gulf of Mexico. The Discharge Port shall be
at the Owner's terminals located at Venice, LA; Port Forrochon, LA; Berwick, LA; Intracoastal City,
LA; Cameron, LA; Sabine Pass, TX; Beaumont, TX; Galveston, TX; Houston, TX; Freeport, TX; Port
O'Connor, TX; and Harbor Island, TX. 5. TITLE TO PRODUCT

Title to all product handled shall remain at all times in the name of the Charterer. The Charterer
agrees not to tender for load any product injurious to the vessels or which product would render the
vessels unfit, after cleaning, for the proper storage of similar product. 6. ASSIGNMENT Neither
party shall assign this Agreement without the express written consent of the other party. 7. ENTIRE
AGREEMENT

This Agreement shall constitute the entire agreement concerning the subject hereof between the
parties superseding all previous agreements, negotiations and representations made prior or
contemporaneous to the date hereof. This Agreement shall be modified or amended only by written
agreement executed by both parties hereto. 8. GOVERNING LAW This Agreement shall be governed by and
construed in accordance with the laws of the State of Texas. 9. ADDITIONAL TERMS The "Additional
Terms" attached hereto as Exhibit A shall be deemed to be incorporated into this Agreement by this
reference.

2
<!-- page 3 -->
IN WITNESS WHEREOF, the parties have executed this Agreement as of the date first set forth above.

MARTIN OPERATING PARTNERSHIP L.P. By: Martin Operating GP LLC, Its General Partner By: Martin
Midstream Partners L.P., Its Sole Member By: Martin Midstream GP LLC, Its General Partner By: /s/
RUBEN S. MARTIN Ruben S. Martin Chief Executive Officer and President MIDSTREAM FUEL SERVICE LLC By:
Martin Resource Management Corporation, its Sole Member By: /s/ RUBEN S. MARTIN

Name: Ruben S. Martin Title: Chief Executive Officer and President

3
<!-- page 4 -->
EXHIBIT A

ADDITIONAL TERMS

These additional terms are deemed to be incorporated by reference into this Agreement.

1. INVOICING & PAYMENT. All monthly Owner invoices to Charterer for rates and cost items will be
paid by Charterer within 30 days of invoice date in accordance with Owner's normal payment
protocols, which will be specified in the applicable invoice. Each monthly invoice shall be itemized
to include charges by applicable vessel by day.

2. DEMISE OF CHARTER. The Master of an applicable vessel, although appointed by and in the employ of
Owner and subject to Owner's direction and control, shall observe the reasonable instructions of
Charterer in connection with Charterer's transportation needs under this Agreement; PROVIDED,
HOWEVER, THAT NOTHING IN THIS CLAUSE OR ELSEWHERE IN THIS AGREEMENT SHALL BE CONSTRUED AS CREATING A
DEMISE OF THE APPLICABLE VESSEL TO CHARTERER OR AS VESTING CHARTERER WITH ANY CONTROL OVER THE
PHYSICAL OPERATION OR NAVIGATION OF THE APPLICABLE VESSEL.

3. POLLUTION PREVENTION. Owner will, in the case of an escape or discharge of products or threat of
escape or discharge of same from the applicable vessel into the navigable waters of the United
States, promptly undertake such measures as are reasonably necessary or which may be required by
applicable laws, rules and regulations to mitigate the resultant pollution damage; provided,
however, that Charterer may at its option, and upon notice to Owner and on the conditions
hereinafter set forth, undertake such measures. Charterer shall keep Owner advised of any such
measures to be undertaken by it under such circumstances. Any of such measures actually undertaken
by Charterer shall be at Owner's expense (except to the extent that such escape or discharge was
caused or contributed to by Charterer). If Owner believes that any such measures undertaken by
Charterer should not be undertaken or should be discontinued, Owner may so notify Charterer and
thereafter Charterer, if it elects to continue such measures, shall do so at its own risk and
expense.

4. INDEMNITY. Owner covenants and agrees to fully defend, protect, indemnify and hold harmless
Charterer and its affiliates from and against each and every claim, demand, cause of action,
liability, damage, cost or expense (including, but not limited to, reasonable attorney's fees and
expenses incurred in the defense of Charterer), resulting from any damage to property or injury or
death to persons caused, directly or indirectly, by Owner's acts or omissions in connection with
Owner's provision of marine transportation services hereunder, except to the extent caused, directly
or indirectly, by the acts or omissions of Charterer.

Charterer covenants and agrees to fully defend, protect, indemnify and hold harmless Owner and its
affiliates from and against each and every claim, demand, cause of action, liability, damage, cost
or expense (including, but not limited to, reasonable attorney's fees and expenses incurred in the
defense of Owner), resulting from any damage to property or injury or death to persons caused,
directly or indirectly, by Charterer's acts or omissions in connection with Charterer's use of
marine transportation services hereunder, except to the extent caused, directly or indirectly, by
the acts or omissions of Owner.

The foregoing indemnities shall expressly exclude any liability for consequential, punitive, special
or similar damages, including, without limitation, lost profits.

5. COMPLIANCE WITH LAW; INSURANCE: During the Term of this Agreement, Owner shall comply in all
material respects with applicable laws, including, without limitation applicable environmental,
health, safety and financial responsibility laws, rules and regulations, applicable to the use of
the Vessel for bulk crude oil or finished lubricating products transportation. Owner covenants that
it will maintain at all times during the Term of this Agreement insurance coverage for sudden and
accidental pollution of $500,000,000.

4
<!-- page 5 -->
6. CHARTERER'S REPRESENTATIVES: Charterer's representatives may board any vessel used under this
Agreement at any convenient place to observe cargo-handling operations, to inspect logs and
certificates, and to confirm that Owner is fulfilling its obligations under this Agreement.

7. DRUG & ALCOHOL ABUSE POLICY: Owner warrants that it will maintain and enforce at all times during
the Term of this Agreement a drug and alcohol abuse policy applicable to the vessels which complies
in all material respects with the minimum standards promulgated by the U.S. Coast Guard.

8. CONDITION OF EQUIPMENT: Owner shall, before and at commencement of each voyage by any vessel
under this Agreement, exercise commercially reasonable efforts to ensure that such vessel is
seaworthy and in good operating condition, properly manned, equipped and supplied for the voyage, to
ensure that the pipes, pumps and coils tight, staunch, are in good operating condition and fit for
the voyage, and to ensure that the tanks and other spaces in which product is to be carried are in
good operating condition and fit for the carriage and preservation of the same. To the extent
required by applicable law, Owner will maintain at all times during the Term of this Agreement a
valid and subsisting certificate or other permit issued by the U.S. Coast Guard (or other
governmental bureau or department having jurisdiction) approving the applicable vessel for the
transportation and carriage of inflammable liquids.

9. SUBLET: Charterer shall not be permitted to sublet the use of any vessels to any third party.

10. FORCE MAJEURE: The vessels, their captains and Owner shall not, unless otherwise in this
Agreement expressly provided, be responsible for any loss or damage arising or resulting from: any
act, default or barratry of the captain, pilots, mariners, or other servants of Owner in the
navigation or management of such vessel; fire, unless caused by the personal design or neglect of
Owner; collision, stranding or peril, danger or accident of navigable waters; saving or attempting
to save life or property; wastage in weight or bulk, or any other loss or damage arising from
inherent defect, quality or vice of the cargo; any act or omission of Charterer, Owner, any other
shipper or any consignee of the cargo, their agents or representatives; insufficiency or inadequacy
of marks; explosion, bursting of boilers, breakage of shafts, or any latent defect in hull,
equipment or machinery; unseaworthiness of any vessel unless caused by want or due diligence on the
part of Owner to make such vessel seaworthy or to have it properly manned, equipped and supplied; or
from any other cause of whatsoever kind arising without the actual fault of Owner. And neither the
vessels, their captains or Owner, nor the Charterer, shall, unless otherwise in this Agreement
expressly provided, be responsible for any loss or damage or delay or failure in performing
hereunder arising or resulting from; act of God, act of war; act of public enemies, pirates or
assailing thieves; acts of terrorism; arrest or restraint of princes, rulers of people, or seizure
under legal process provided bond is promptly furnished to release such vessel or cargo; strike or
lockout or stoppage or restraint of labor from whatever cause, either partial or general, or riot or
civil commotion.

5
