<!-- page 1 -->
# MASTER SUPPLY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Supply Agreement |
| Agreement Date | 2019-11-01 |
| Parties | REYNOLDS CONSUMER PRODUCTS LLC ("Seller"); PACTIV LLC ("Buyer")("Party" and collectively at times as the "Parties") |
| Source | CUAD v1 / ReynoldsConsumerProductsInc_20191115_S-1_EX-10.18_11896469_EX-10.18_Supply Agreement |

Exhibit 10.18

MASTER SUPPLY AGREEMENT

MASTER SUPPLY AGREEMENT (the "Agreement") dated November 1, 2019 (the "Effective Date") between
REYNOLDS CONSUMER PRODUCTS LLC, a Delaware limited liability company with its headquarters at 1900
West Field Court, Lake Forest, IL 60045 ("Seller"), and PACTIV LLC, a Delaware limited liability
company with its headquarters at 1900 West Field Court, Lake Forest, IL 60045 ("Buyer"). Seller and
Buyer are referred to individually at times as a "Party" and collectively at times as the "Parties".

BACKGROUND

A. Seller sells various types of products used in the consumer and food service markets.

B. Buyer sells various types of products, including certain products of the type made by Seller, to
its customers.

C. The Parties are entering into this Agreement to establish the terms and conditions under which
Seller may agree to sell specific products to Buyer, and Buyer may agree to purchase specific
products from Seller for later resale by Buyer to its business customers.

AGREEMENT

1. Term. The "Term" of this Agreement will commence on the Effective Date and will end on the
earlier of: (a) the first anniversary of the expiration date of the last Purchase Schedule (as
defined in this next Section); (b) a termination date elected by a Party in a written notice
delivered to the other Party any time after the expiration of the last Purchase Schedule; or (c) a
termination date elected by a Party in a written notice delivered to the other Party as provided in
Subsection 11(d) of this Agreement. The rights and obligations of the Parties under this Agreement
will survive the expiration or earlier termination of this Agreement with respect to any (i)
products purchased and sold under this Agreement during the Term and products sold after the Term
for orders accepted during the Term; (ii) Confidential Information (as defined in Section 10 of this
Agreement) disclosed or received by a Party during the Term; (iii) breach of this Agreement by a
Party; (iv) any other statement, decision, act or omission of a Party concerning or related to this
Agreement; (v) any Dispute (as defined in Section 11 of this Agreement) between the Parties
concerning or related to this Agreement; (vi) products and other materials manufactured or
maintained by Seller in inventory for sale to Buyer that Buyer is obligated to purchase under a
Purchase Schedule; and (vii) any provision that expressly states that it will survive the expiration
or earlier termination of this Agreement.

2. Scope. This Agreement will apply to all products sold by Seller to Buyer, and all products
purchased by Buyer from Seller, during the Term unless the Parties expressly agree that this
Agreement will not apply to a particular type of transaction in a separate written document signed
by an officer of each Party. This Agreement will not require Seller to sell any type or quantity of
a product to Buyer, nor will this Agreement required Buyer to purchase any type or quantity of a
product from Seller, except as expressly provided by the Parties in a Purchase Schedule. The phrase
"Purchase Schedule" will mean a written supplement to this Agreement signed by an officer of each
Party which references this Agreement and which identities, among other terms and conditions, the
specific types and quantities of products that will be purchased and sold by the Parties on terms
and conditions in the schedule, the specifications for the identified products, the duration of the
commitment period during which the Parties will be obligated to purchase and sell the identified
products on the terms and conditions in the schedule, the prices of the identified products, any
mechanisms for adjusting the prices of the identified products over the commitment period, and the
facilities at which the identified products will be manufactured, stored and delivered by Seller.
The Parties may add terms and conditions to, and amend the terms and conditions of, this Agreement
in a Purchase Schedule, but any additional and amended terms and conditions in a Purchase Schedule
supplementing and modifying this Agreement will only apply the specific products identified in that
Purchase Schedule for its duration.

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 2 -->
3. Standard Operating Procedures. Over approximately the past eight years, the Parties have been
supplying select Products to one another for use in the operation of their respective businesses
within the United States of America, Canada and Mexico. The Parties developed and been following
certain standard operating procedures in connecting with, among other topics, forecasting,
production planning, ordering, delivering and resolving claims on the Products supplied to one
another (the "Current SOPs"). The Parties will be updating their respective business systems over
the next six months, and the updates to these business systems will require the Parties to modify
the Current SOPs. Once the Parties have completed the updates to the business systems and agreed on
the necessary modifications to the Current SOPs, the Parties will sign a written amendment to this
Agreement appending the updated standard operating procedures (the "Updated SOPs"). Until the
Parties have signed a written amendment appending the Updated SOPs, the parties will continue to
follow the Current SOPs. The Parties will comply with the applicable SOPs in connection with the
purchase and sale of products identified in a Purchase Schedule. The Parties may add terms and
conditions to, and amend the terms and conditions of, the SOP in a Purchase Schedule, but any
additional and amended terms and conditions in a Purchase Schedule supplementing and modifying the
SOP will only apply the specific products identified in that Purchase Schedule for its duration.

4. Order and Priority of Interpretation. In the event of any conflict, inconsistency or ambiguity
between two or more provisions in this Agreement, including the provisions in its Exhibits and
Purchase Schedules, the provisions in the documents will govern, supersede and control over one
another in the following order of priority: (1st) a Purchase Schedule with regards to the purchase
and sale of the specific products identified in that Purchase Schedule for its duration; (2nd) the
SOP; (3rd) any Exhibit to this Agreement but only with regards to specific subject matter of the
Exhibit; and (4t h) the main body of this Agreement prior to the signature page.

5. General Representations, Warranties and Covenants. A Party represents, warrant and covenants on
the Effective Date and at all times during the Term that: a. The Party is formed, registered,
licensed and operating its business in compliance with the laws of the United States of America, its
states and territories, and any districts, municipalities and other political subdivisions of the
foregoing ("Applicable Laws"). b. The Party is operating its business in compliance with a
commercially reasonable code of ethics adopted by such Party. c. The Party may enter into and
perform its obligations under this Agreement without being in conflict with, or in breach of, any
other agreement of the Party. d. The Party is solvent, is capable of paying its debts as and when
they become due and is paying its debts as and when due. e. The Party is not the subject of a
criminal investigation nor a defendant in any criminal indictment, petition, complaint or proceeding
that carries a potential sentence involving incarceration in excess of one year for any director or
executive officer of the Party involved in the alleged criminal misconduct or a fine in excess of
$100,000 USD.

A Party will promptly notify the other Party of any change in circumstance during the Term in which
the Party is no longer in compliance with the foregoing general representations, warranties and
covenants. An incident of actual, alleged or suspected non-compliance by a Party with a warranty
under this Section being investigated, contested or corrected in good faith by the Party and which,
regardless of outcome, will have no material adverse effect on the Party or its performance under
this Agreement or on the other Party, will not be considered a breach of this clause. An incident of
actual, alleged or suspected non-compliance by a Party of this Section or any other Section of this
Agreement will be grounds for the other Party to demand adequate assurances of performance as
provided by Section 2-609 of the Illinois Uniform Commercial Code. A Party will have ten (10) days
to provide adequate assurances of performance to the other Party in a form acceptable to the other
Party in its good faith discretion.

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 3 -->
6. Specific Product Warranties. Seller represents and warrants to Buyer that each product sold under
this Agreement will at the time of delivery to Buyer: a. Be in new, undamaged and unadulterated
condition free of any defects in design, materials and manufacture. Seller is not making any
representation or warranty under this clause with regards to the design of a product to the extent
the design constitutes, incorporates or otherwise embodies intellectual property that Buyer has
represented and warranted to Seller is owned by Buyer and which Buyer has licensed to Seller to
manufacture the product for Buyer. b. Have been manufactured and stored by Seller at a plant (and,
if applicable under a Purchase Schedule, a warehouse) of Seller approved in the applicable Purchase
Schedule prior to its delivery to Buyer. c. Has been manufactured, packaged, labelled, sold and
delivered by Seller, and may be sold by Buyer in interstate commerce, in compliance with Applicable
Laws, including without limitation with food safety regulations issued by the United States Food and
Drug Administration that are applicable to the product. Seller will not be in breach of this
warranty because an Applicable Law prohibits, restricts or imposes a charge on a product in a
district, municipality or other political subdivision of the United States of America or its states
or territories. d. Comply with the written specifications for the product identified in the
applicable Purchase Schedule. e. Be fit for the purpose of packaging, selling or use in consuming
food subject to qualifications and instructions on the use of the product in the written
specifications for the product identified in the applicable Purchase Schedule. f. Be conveyed by
Seller to Buyer with good and marketable title free and clear of all liens, encumbrances and claims
arising by, through or under Seller. g. Not infringe on any patent, trademark, copyright, trade
secret or other the intellectual property of any third-party registered or otherwise recognized and
enforceable under Applicable Law. Seller is not making any representation or warranty under this
clause with regards to the design of a product to the extent the design constitutes, incorporates or
otherwise embodies intellectual property that Buyer has represented and warranted to Seller is owned
by Buyer and which Buyer has licensed to Seller to manufacture the product for Buyer. h. Comply with
any additional representations and warranties of Seller regarding the product in the applicable
Purchase Schedule.

If a Buyer receives a product that fails to conform to these representations and warranties, the
sole remedies of Buyer for the breach of warranty will be to: (1) reject and return the
non-conforming product to Seller for a refund or credit, or a replacement conforming product, in the
manner and time period provided in the SOP; (2) obtain reimbursement from Seller for actual,
reasonable, substantiated out-of-pocket expenses incurred by Buyer in the recovery, return or
disposal of a non-conforming product that is the subject of a mandatory product recall required
under Applicable Laws or a voluntary withdrawal declared by Seller or approved by Seller (such
approval not to be unreasonably withheld, conditioned or delayed); and (3) obtain indemnification
from Seller for any Indemnified Claim arising from or related to the non-conforming product as
provided in Section 7.

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 4 -->
7. Indemnification. a. A claim that a Party (referred to at times in this Section as an
"Indemnifying Party") is required to defend and indemnify the other Party (referred to at times in
this Section as an "Indemnified Party") under this Agreement is referred to at times in this Section
as an "Indemnified Claim". Defense and indemnification under this Section will include, without
limitation, (1) paying or reimbursing the actual, reasonable, substantiated out-of-pocket expenses
incurred in connection with the investigation, defense and settlement of any civil, criminal or
administrative action, suit, arbitration, mediation, hearing, audit, investigation or other
proceeding threatened or commenced against an Indemnified Party on an Indemnified Claim (e.g., fees
and expenses of attorneys, accountants, auditors, investigators, consulting experts, testifying
experts and other consultants; fees and expenses of an arbitrator or mediator; filing fees and costs
imposed by any court, administrative agency or other tribunal; etc.), and (2) satisfying any
judgment, award, order, lien, levy, fine, penalty or other sanction imposed against an Indemnified
Party on an Indemnified Claim. b. Seller will defend and indemnify Buyer against: (1) any
third-party claim for personal injury, damage to tangible property or other loss to the extent
caused by any actual or alleged breach of this Agreement by Seller, including, without limitation,
any product supplied by Seller which fails to conform to the representations and warranties in this
Agreement; (2) any third-party claim for personal injury, damage to tangible property or other loss
to the extent caused by any actual or alleged negligence or other legally culpable misconduct of
Seller in the design, manufacture, storage, sale or delivery of any product sold by Seller under
this Agreement or in the performance of other obligation of Seller under this Agreement; (3) any
third-party claim for actual or alleged infringement of a product sold by Seller under this
Agreement or its design, manufacture, storage, packaging, sale or delivery by Seller under this
Agreement or in the performance of any other obligation of Seller under this Agreement (except to
the extent that the infringement is based on intellectual property that that Buyer has represented
and warranted to Seller that Buyer owns and that Buyer has licensed to Seller and that Seller has
used in compliance with the license terms in supplying the product); (4) the threat or imposition of
any fine, penalty or other sanction by a governmental authority on Buyer to the extent caused by any
actual or alleged violation by Seller of Applicable Law; or (5) any other matter that Seller has
agreed to defend and indemnify Buyer against under a Purchase Schedule. c. Buyer will defend and
indemnify Seller against: (1) any third-party claim for personal injury, damage to tangible property
or other loss to the extent caused by any actual or alleged breach of this Agreement by Buyer; (2)
any third-party claim for personal injury, damage to tangible property or other loss to the extent
caused by any actual or alleged negligence or other legally culpable misconduct of Buyer in the
purchase, storage, repackaging, resale or delivery of any product purchased from Seller under this
Agreement or in the performance of other obligation of Buyer under this Agreement; (3) any
third-party claim for actual or alleged infringement of a product sold by Seller under this
Agreement or its design, manufacture, storage, sale or delivery by Seller under this Agreement or in
the performance of any other obligation of Seller under this Agreement to the extent based on
intellectual property that that Buyer has represented and warranted to Seller that Buyer owns and
that Buyer has licensed to Seller and that Seller has used in compliance with the license term in
supplying the product; (4) the threat or imposition of any fine, penalty or other sanction by
governmental authority on Seller to the extent caused by any actual or alleged violation by Buyer of
Applicable Law; or (5) any other matter that Buyer has agreed to defend and indemnify Seller against
under a Purchase Schedule. d. As a condition of receiving defense and indemnification under this
Section for an Indemnified Claim, the Indemnified Party must: (1) notify and tender the defense of
an Indemnified Claim to the Indemnifying Party promptly after the Indemnified Party learns of the
Indemnified Claim; and

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 5 -->
(2) provide information and cooperation reasonably requested by the Indemnifying Party in the
investigation, defense, settlement and satisfaction of the Indemnified Claim. An Indemnifying Party
will reimburse the Indemnified Party of any reasonable, actual, substantiated out-of-pocket expense
incurred in providing the requested information or cooperation. e. If the Indemnifying Party accepts
the tender of defense of an Indemnified Claim, with or without reservation, the Indemnifying Party
will: (1) promptly notify the Indemnified Party of the acceptance of the tender of defense of the
Indemnified Claim. (2) control the investigation, defense, settlement and satisfaction of the
Indemnified Claim, including, without limitation, the selection of licensed, qualified and reputable
attorneys and expert witnesses and all decisions over settlement and litigation strategy. The
Indemnifying Party must act in good faith in exercising control over the investigation, defense,
settlement and satisfaction of the Indemnified Claim. (3) Provide information reasonably requested
by the Indemnified Party regarding the investigation, defense, settlement and satisfaction of the
Indemnified Claim f. An Indemnifying Party, acting in good faith, may settle an Indemnified Claim
for which it is responsible under this Agreement involving infringement on the intellectual property
of a third-party by: (1) obtaining a license from the third-party allowing the required use of its
intellectual property; (2) modifying a product, equipment or process in a manner which avoids
infringing on the intellectual property of the third-party; or (3) voluntarily withdrawing the
infringing product from the market and either refunding the amount paid by the Indemnified Party for
the infringing product or replacing the infringing product with a non-infringing product. g. The
Parties may disagree on whether a claim is an Indemnified Claim under this Agreement, which Party
should be considered the Indemnifying Party and Indemnified Party for an Indemnified Claim or
whether each Party is partially liable for an Indemnified Claim and how liability for such an
Indemnified Claim should be allocated between them. In these and other circumstances in which an
actual or potential conflict of interest exists or arises between the Parties with regards to an
alleged or agreed upon Indemnified Claim that would preclude their joint representation by a single
defense counsel, the Parties will endeavor in good faith to attempt to resolve the conflict. If the
Parties are able to resolve the actual or potential conflict of interest, the Parties will
memorialize the agreed upon resolution in a written joint defense agreement signed by officers of
each Party and their joint defense counsel. If the Parties are unable to resolve the actual or
potential conflict of interest, each Party may independently and separately investigate, defend,
settle and satisfy the claim subject to their right to pursue payment or reimbursement for costs
incurred in doing so from the other Party as provided in this Agreement.

8. Insurance. During the Term of this Agreement, each Party will maintain the following minimum
types and amounts of insurance coverage during the Term of this Agreement: a. Commercial General
Liability Insurance. Occurrence based coverage with a combined single limit of at least $10,000,000
per occurrence and in the aggregate for premises and operations; products and completed operations;
contractual liability coverage for indemnities of a Party contained within this Agreement; broad
form property damage (including completed operations); explosion, collapse and underground hazards;
and personal injury. Requires additional insured endorsement and waiver of subrogation endorsement.

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 6 -->
b. Automobile Liability Insurance. Occurrence based coverage with a combined single limit of at
least $10,000,000 per occurrence and in the aggregate for owned, non-owned, and hired automotive
equipment of the Party. Requires additional insured endorsement and waiver of subrogation
endorsement. c. Workers' Compensation Liability Insurance. Occurrence based coverage providing
benefits in the minimal amount required by Applicable Law for workplace and work related injuries
and illnesses to the employees of a Party, including, without limitation, Workers Compensation Acts
of applicable U.S. States, the U.S. Longshoremen's and Harbor Workers Compensation Act and the U.S.
Jones Act. Requires alternate employer endorsement and waiver of subrogation endorsement. d.
Employers' Liability Insurance. Occurrence based coverage with a limit of at least $10,000,000 per
occurrence or any greater limits set by Applicable Law workplace and work related injuries and
illnesses to the employees of a Party. Requires waiver of alternate employer endorsement. e.
Property Insurance. Coverage providing "all risk" property insurance at the replacement value of the
machinery, equipment, fixtures, tools, materials and other property of the Party. "All risk"
coverage will include, by way of example and not limitation, loss or damage resulting from
earthquakes, floods, wind, fire or other natural or weather-related phenomenon. Requires waiver of
subrogation endorsement.

All insurers of a Party on such policies must have at all times an A.M. Best financial rating of at
least "A-Minus VII". An insuring Party may satisfy the required minimum amounts of insurance through
a primary policy and one or more excess policies. All insurance of an insuring Party must be
"primary and non-contributory" with respect to any insurance that the other Party may maintain, but
only with respect to the negligence or other legal liability of the insuring Party.

An insuring Party must deliver the following written evidence of the required insurance coverage to
the other Party (Attention: Risk Management), or its designated insurance monitoring service, within
ten (10) of written request and at least thirty (30) days in advance of the expiration of a then
current policy term (if a declaration or endorsement is not available from an insurer at the time
requested or required, an insuring Party will provide them as soon as the declaration or endorsement
is available from the insurer): i. Certificate of insurance confirming that the required insurance
coverage and minimal limits are met for the extended, renewed or replacement policy term. ii.
Declaration pages of insurance policy (or a copy of the binder until the declaration pages are
available) confirming that the required insurance coverage and minimal limits are met for the
extended, renewed or replacement policy term. iii. Copies of additional insured endorsements
required for applicable policies in the name and for the benefit of: "[NAME OF OTHER PARTY], its
parent, subsidiaries and affiliates; any lessors of the foregoing and any mortgagees, deed of trust
beneficiaries and secured creditors of such lessors; and any successors and assignees of all of the
foregoing." iv. Copies of alternate employer endorsements and waiver of subrogation endorsements
required for applicable policies in the name and for the benefit of: ""[NAME OF OTHER PARTY], its
parent, subsidiaries and affiliates; any lessors of the foregoing and any mortgagees, deed of trust
beneficiaries and secured creditors of such lessors; and any successors and assignees of all of the
foregoing."

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 7 -->
A Party may maintain any level of deductible on required insurance coverage allowed by Applicable
Law. A Party may also self-insure any of the required insurance coverage, in whole or in part, if
allowed by Applicable Law during any period that the Party maintains a tangible net worth in excess
of $100 million USD and maintains a professionally managed and adequately reserved for and funded
self-insurance program.

9. Limitations on Liability. a. Disclaimer of Representations and Warranties. Each Party: (1)
disclaims all representations and warranties regarding its products, performance, supplied
information or business, whether oral or written, express or implied, arising by operation of law or
otherwise, including, without limitation, the implied warranty of merchantability and the implied
warranty of fitness for a particular purpose, other than those express representations and
warranties of the Party in this Agreement; (2) acknowledges that the Party has not relied on, and
will not rely on, any representations and warranties of the other Party regarding its products,
performance, supplied information or business, whether oral or written, express or implied, arising
by operation of law or otherwise, other than those express representations and warranties of the
other Party in this Agreement; and (3) waives any claim that the Party may have based, in whole or
in part, on any representations and warranties of the other Party regarding its products,
performance, supplied information or business, whether oral or written, express or implied, arising
by operation of law or otherwise, other than those express representations and warranties of the
other Party in this Agreement. Notwithstanding the foregoing, Buyer is entitled to rely on (i) the
descriptive information in transaction documents issued by either Party in the ordinary course of
business during the Term identifying the ordered Products (e.g., the type and quantity of ordered
products and scheduled date and location for delivery) and (ii) FDA guaranty letters and other
similar written assurances in Seller's standard forms certifying that a product complies with
Applicable Laws issued by Seller to Buyers and other U.S. customers in the ordinance course of
business during the Term. b. Exclusion of Indirect Damages; Waiver of Claim for Insured Damage or
Loss. A Party that breaches this Agreement will only be liable to the other Party for direct damages
arising from the breach. Each Party waives any right to recover consequential, incidental, indirect,
exemplary, punitive or any other types of indirect damages from the other Party for a breach of this
Agreement. Notwithstanding the preceding sentences, this Subsection will not limit the liability of
a Party for any amount or type of damages for: (1) the defense and indemnification of an Indemnified
Claim on which the Party is the Indemnifying Party; (2) infringement by the Party on the
intellectual property of the other Party; (3) the unauthorized disclosure or use by the Party of the
Confidential Information of the other Party; (4) payment or reimbursement of any amount expressly
required to be paid or reimbursed by the Party under a provision of this Agreement; or (5) the
intentional misconduct of the Party in violation of Applicable Laws. c. Force Majeure. A Party will
not be considered in breach of this Agreement or liable to the other Party for any interruption or
delay in performance under this Agreement to the extent caused by an event outside of the ability of
the performing Party to foresee and avoid with the exercise of commercially reasonable efforts (such
an event is referred to at times as an event of "Force Majeure"). Examples of events of Force
Majeure include, without limitation: natural disasters; war; acts of terrorism; government action;
accident; strikes, slowdowns and other labor disputes; shortages in or inability to obtain material,
equipment, transportation or labor; any breach, negligence, criminal misconduct or other act or
omission of any third-party; fire or other insured or uninsured casualty. A Party whose performance
is interrupted or delayed by an event of Force Majeure will be excused from the interruption or
delay in performance during the event of Force Majeure and for a commercially reasonable period of
additional time after the event of Force Majeure that the Party needs to recover from the event of
Force Majeure and restore performance. Notwithstanding the foregoing, a Party will only be excused
for an interruption or delay in performance under this Subsection for an event of Force Majeure only
if the Party (1) promptly notifies the other Party of the event of Force Majeure and provides
information reasonably requested by the other Party regarding the event of Force Majeure, the
efforts undertaken by the

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 8 -->
Party to foresee and avoid interruption or delay in its performance before the occurrence of the
event, to mitigate interruption or delay in performance during the event, and to recover from and
restore performance following the event; and (2) the Party exercises commercially reasonable efforts
to mitigate, recover from and restore performance following the event of Force Majeure. During, and
while recovering from and restoring performance following, an event of Force Majeure, Seller will
act in good faith in allocating its available manufacturing capacity to supply products to Buyer
under this Agreement and any products to other customers of Seller. If an event of Force Majeure
interrupts or delays Seller from supplying a product to Buyer under this Agreement in the quantities
and timetable required by Buyer, Buyer may cancel any unfilled orders for the product with Seller
and procure the required quantities of the product from one or more other sources until Seller has
recovered from and restored its ability to perform following the event of Force Majeure. If the
interruption or delay in the supply of a product to Buyer under this Agreement caused by an event of
Force Majeure has exceeded, or is reasonably likely to exceed, thirty (30) days, Buyer may enter
into longer term supply agreements or make other arrangements to procure the required quantities of
the product from one or more other sources for a duration and on terms acceptable to Buyer in its
good faith discretion. In such a circumstance, Buyer will not have to resume purchasing the product
from Seller under this Agreement until Seller has recovered from and restored its ability to perform
following the event of Force Majeure and the longer term agreements or other arrangements have
expired or Buyer is able to end them without liability. This Subsection will not excuse nor extend a
deadline by which a Party must pay an amount owed under this Agreement or Applicable Law or by which
a Party must exercise any right or remedy under this Agreement or Applicable Law.

10. Confidential Information and Other Intellectual Property. a. The Parties anticipate exchanging
Confidential Information (as defined in in the next Subsection) over the Term of this Agreement for
the purpose of negotiating and entering into Purchase Schedules and amendments to this Agreement,
transacting business with one in accordance with this Agreement and exercising their rights and
performing their obligations under this Agreement (collectively referred to as the "Authorized
Purpose"). b. The phrase "Confidential Information" means information meeting all of the following
criteria: 1) The information is a trade secret or other non-public, proprietary information owned by
a Party or its direct and indirect subsidiaries under Applicable Law (this Party is referred to at
times in this Section as the "Disclosing Party"); and 2) The other Party (referred to at times in
this Section as the "Receiving Party") requests such information from the Disclosing Party for the
Authorized Purpose during the Term (i.e., neither Party wants unsolicited Confidential Information
from the other Party); and 3) The Disclosing Party discloses such requested information to the
Receiving Party during the Term either labelled as "Confidential" or words of similar intent, or
describes the disclosed information in reasonable detail in a written notice to the Receiving Party
delivered, either at the time of disclosure or within five (5) days of disclosure. If a Disclosing
Party neglects to label or deliver timely written notice to the Receiving Party identifying the
disclosed information as confidential in nature, the disclosed information will only be treated as
Confidential Information under this Agreement if the Disclosing Party is able to demonstrate by
clear and convincing evidence that the Receiving Party knew that the disclosed information was a
trade secret or other non-public, proprietary information of the Disclosing Party at the time of
disclosure.

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 9 -->
The criteria in Clause (2) and Clause (3) will not apply to Confidential Information of a Disclosing
Party observed or heard by a Receiving Party in a plant, warehouse, facility or system of the
Disclosing Party. The existence and terms of this Agreement, and the existence, nature and extent of
the business relationship between the Parties, will be considered the Confidential Information of
each Party. c. The phrase "Confidential Information" also means the Know-How of a Disclosing Party
and its direct and indirect subsidiaries that a Receiving Party and its direct and indirect
subsidiaries learned of, acquired or otherwise used prior to the Effective Date. The phrase
"Know-How" means trade secret and other confidential, proprietary information of a Party or its
Affiliate concerning the manufacture, storage, packaging, marketing, sale and delivery of its
products. Examples of Know-How may be in the form of drawings, equipment specifications, formulae,
formulations, guidelines, manuals, methods, plans, policies, procedures, processes, properties and
applications of raw materials and products, tools, dies and molds. A Receiving Party and its direct
and indirect subsidiaries may continue to use the Know- How of the Disclosing Party and its direct
and indirect subsidiaries in the possession of the Receiving Party and its direct and indirect
subsidiaries as of the Effective Date for the Authorized Purpose and in connection with the
operation of the business of the Receiving Party and its direct and indirect subsidiaries. Nothing
in this Subsection or any other provisions of this Agreement will obligate a Party to disclose or
license the use of its Know-How of any kind and in any form arising, discovered, acquired or
developed after the Effective Date to the other Party. d. The phrase "Confidential Information" does
not include, and there will not be any duties of confidentiality or other restrictions under this
Agreement for, the following types of information: (1) Information which is or becomes available as
part of the public domain through any means other than as a result of a breach of this Agreement by
the Receiving Party; or (2) Information, other than Know-How received prior the Effective Date,
which is known to the Receiving Party before the disclosure of the same information by the
Disclosing Party; or (3) Information which is or becomes available to the Receiving Party from a
third-party who is not under any duty to preserve the confidentiality of such information; or (4)
Information which is furnished by the Disclosing Party to a third-party without imposing any duty on
the third-party to preserve the confidentiality of such information; or (5) Information which is
independently developed by the Receiving Party without the use of or reliance on any trade secret or
other non-public, proprietary information provided by the Disclosing Party as Confidential
Information under this Agreement or under any prior agreement between the Parties; or (6)
Information that ceases to be a trade secret or other non-public, proprietary information of the
Disclosing Party under applicable law through any means other than those enumerated above that does
not involve nor result from a breach of this Agreement by the Receiving Party. e. A Party may
request and disclose Confidential Information in any form or medium. Confidential Information may
include, without limitation, information concerning the assets, liabilities, financing, financial
statements, ownership, goods, services, customers, suppliers, marketing, manufacturing, equipment,
software, technology, supply chain, business strategies, plans, models, policies, methods,
processes, formulae, specifications, drawings, schematics, software and technical know-how of a
Disclosing Party. A Receiving Party will take all commercially reasonable actions required to
safeguard the Confidential Information of a Disclosing Party in the possession of such Receiving
Party against the unauthorized disclosure or use of the Confidential Information by other persons. A
Receiving Party will promptly notify the Disclosing Party if the Receiving Party learns of any
unauthorized disclosure or use of the Confidential Information of the Disclosing Party by any

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 10 -->
person. A Receiving Party will cooperate in good faith with the Disclosing Party to prevent any
unauthorized disclosure or use of the Confidential Information of the Disclosing Party by any
person. f. A Receiving Party will not disclose nor use the Confidential Information of a Disclosing
Party except as follows: (1) A Receiving Party may disclose Confidential Information of a Disclosing
Party on a "need to know" basis to the Representatives of the Receiving Party who require such
information for the Authorized Purpose and in order for the Receiving Party and its Affiliates to
comply with Applicable Laws, accounting standards and securities exchange requirements. Before
making such a disclosure, the Receiving Party will advise the Representatives of the confidential
nature of the information being shared and ensure that duties and restrictions are, or have been,
imposed on the Representatives receiving the Confidential Information similar to those imposed on
the Receiving Party under this Agreement. A Receiving Party will be liable for any breach of this
Agreement by its Representatives. An "Affiliate" of a Party means a legal entity that owns and
controls, or is owned and controlled by, or is under common ownership and control with, a Party
(other than the other Party or any of its direct and indirect subsidiaries), with ownership and
control of a legal entity being determined by the ownership of the majority voting interest in the
legal entity. A "Representative" means the Affiliates of a Party and the directors, officers,
managers, employees, accountants, attorneys, auditors and other agents and consultants of a Party
and its Affiliates. (2) A Receiving Party may disclose Confidential Information of a Disclosing
Party to a court, governmental entity or any other person in order for the Receiving Party and its
Affiliates to comply with Applicable Laws, accounting standards and securities exchange
requirements. If legally permissible and reasonably possible, a Receiving Party will notify the
Disclosing Party prior to disclosing its Confidential Information pursuant to this Section and
cooperate in good faith with any lawful efforts by the Disclosing Party to avoid or limit the
disclosure of its Confidential Information. A Receiving Party will not be obligated to incur any
liability, expense or risk in extending such cooperation to a Disclosing Party. Based on legal
advice of its attorney, a Receiving Party may disclose the Confidential Information of the
Disclosing Party by any deadline established under an Applicable Law, accounting standard and
securities exchange requirement. (3) A Receiving Party may disclose and use the Confidential
Information of a Disclosing Party to enforce or interpret this Agreement or any other agreement with
the Disclosing Party in any arbitration, court or other legal proceeding. A Receiving Party may
disclose and use this Confidential Information of a Disclosing Party to defend the Receiving Party
or its Affiliates or their respective Representatives in any arbitration, court or other legal
proceeding. In either circumstance, the Receiving Party will ensure that a protective order,
agreement or other mechanism is in place to preserve the confidentiality of the Confidential
Information. (4) A Receiving Party and its Representatives may disclose and use the Confidential
Information for any other purpose consented to by a Disclosing Party in a written notice signed by
an officer of the Disclosing Party delivered to the Receiving Party. g. In disclosing its
Confidential Information to a Receiving Party, a Disclosing Party represents, warrants and covenants
to the Receiving Party that: (1) The Disclosing Party owns and has the right to disclose and
authorize the use of Confidential Information as provided in this Agreement.

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 11 -->
(2) The Receiving Party and its Representatives may use the Confidential Information of the
Disclosing Party for the Authorized Purpose and other limited purposes provided in this Agreement.
(3) The Disclosing Party will indemnify, defend and hold harmless the Receiving Party and its
Representatives against any claim of a third-party that the disclosure and use of the Confidential
Information of the Disclosing Party as provided in this Agreement infringes on a patent, trademark,
copyright, trade secret or other intellectual property of the third-party registered in or otherwise
recognized and enforceable under Applicable Laws.

Except for the limited representations and warranties in this Section, a Disclosing Party disclaims
all other representations and warranties of any kind related to its Confidential Information,
whether express, implied or arising by operation of law, including the disclaimer, without
limitation, of any representation and warranties concerning merchantability, fitness for a
particular purpose, truth, accuracy or completeness. h. The rights and obligations of the Parties
under this Section with regards to disclosed Confidential Information will continue: (1) Until the
earlier of (i) sixty (60) months from the date of disclosure to a Receiving Party or (ii) the date
such information ceases to be considered Confidential Information under this Agreement, for
Confidential Information that is not a trade secret of a Disclosing Party under Applicable Law; and
(2) Until Confidential Information that is a trade secret of a Disclosing Party under Applicable Law
ceases to be a trade secret of the Disclosing Party under Applicable Law. i. A Receiving Party will
return or destroy all forms of Confidential Information of the Disclosing Party in the custody of
the Receiving Party and its Representatives within ten (10) days of receipt of a written request
from the Disclosing Party and after the expiration or earlier termination of this Agreement. This
will include, without limitation, all copies, records, documents and other information representing,
comprising, containing, referencing or created based on Confidential Information of the Disclosing
Party. Notwithstanding the foregoing, a Receiving Party and its Representatives may retain copies of
Confidential Information of the Disclosing Party which (x) the Receiving Party and its
Representatives are required to retain to comply with Applicable Laws, accounting standards and
security exchange requirements (but only for the duration and in the manner so required for this
limited purpose); or (y) have been archived in electronic form by the Receiving Party and its
Representatives and which would be unduly burdensome for the Receiving Party and its Representatives
to have to search for and delete the Confidential Information of the Disclosing Party. j. Except for
the limited right to disclose and use Confidential Information of a Disclosing Party for the
Authorized Purpose and other purposes provided in the this Section and except for any license of
intellectual property granted by a Disclosing Party to the Receiving Party in a Purchase Schedule,
this Agreement does not grant a Receiving Party or its Representatives any right, title, interest or
ownership in the Confidential Information of the Disclosing Party nor in any patent, trademark,
copyright or other intellectual property of the Disclosing Party. As between the Parties during the
Term, to be effective, the grant of any right, title, interest and ownership in and to any
Confidential Information of Party or in an patents, trademarks, copyrights and other intellectual
property of the Party must be in writing and signed by the chief executive officers of the Parties.
During the Term, a Party will not develop intellectual property for, on behalf of, or in
collaboration with, the other Party unless the Parties have entered into a Purchase Schedule or
other separate written agreement signed by an officer of each Party.

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 12 -->
11. Dispute Resolution. a. Negotiation. If a Party believes that the other Party has breached this
Agreement or if there is a dispute between the Parties over the interpretation of this Agreement (a
"Dispute"), the Parties will endeavor to resolve the Dispute through good faith negotiation for a
period of thirty (30) days after a Party notifies the other Party of the Dispute and before either
Party requests mediation or files litigation to resolve the Dispute. b. Mediation. If the Parties
have been unable to resolve a Dispute through good faith negotiation as provided in the prior
Subsection, a Party may request that the Parties attempt to resolve the Dispute through mediation by
notifying the other Party with a copy to JAMS. The Parties will attempt to select a mutually
acceptable JAMS mediator within ten (10) days of the notice requesting mediation. The mediation will
be held in Lake County or Cook County, Illinois within thirty (30) days of the notice requesting
mediation before a JAMS mediator and in compliance with JAMS mediation guidelines. Each party will
bear its own costs in preparing for and participating in the mediation and one-half of the fees and
expenses charged by JAMS for conducting the mediation. c. Litigation. If the Parties have been
unable to resolve a Dispute through mediation as provided in the prior Subsection, a Party may file
litigation against the other Party in a court of competent jurisdiction in the United States of
America. With respect to litigation involving only the Parties or their Affiliates, the Parties
irrevocably consent to the exclusive personal jurisdiction and venue of the U.S. federal and
Illinois state courts of competent subject matter jurisdiction located in Lake County, Illinois or
Cook County, Illinois and their respective higher courts of appeal for the limited purpose of
resolving a Dispute, and the Parties waive, to the fullest extent permitted by law, any defense of
inconvenient forum. The Parties waive any right to trial by jury as to any Disputes resolved through
litigation. Notwithstanding the foregoing, a Party may file litigation to resolve a Dispute without
undergoing either negotiation or mediation as provided in the prior Subsections for any Dispute
involving: (i) infringement on intellectual property; (ii) the unauthorized use or disclosure of
Confidential Information; or (iii) a request for a temporary restraining order, a preliminary or
permanent injunction or any other type of equitable relief. d. Remedies. Except as expressly limited
in the preceding Subsections and the other provisions in this Agreement, a Party may immediately
exercise any rights and remedies available to the Party under Applicable Law upon a breach of this
Agreement by the other Party. A Party will not suspend performance under or terminate this Agreement
or any accepted purchase order for a product being purchased and sold under this Agreement unless:
(1) the other Party is in material breach of this Agreement and has either refused to cure the
material breach or has failed to cure the material breach within thirty (30) day of its receipt of
written notice of the failure; and (2) the Parties have been unable to resolve the Dispute related
to the material breach through negotiation or mediation, or the breaching Party has refused or
failed to attempt to resolve the Dispute through negotiation or mediation, as provided in this
Section. Notwithstanding the foregoing, a Party may suspend performance or terminate this Agreement
or any accepted purchase order for a product being purchase and sold under this Agreement
immediately on written notice to the other Party, and without providing the other Party an
opportunity to cure the material breach or attempting to resolve a Dispute over the material breach
by negotiation or mediation as provided in this Section, for a material breach by the other Party
involving substantial harm to the reputation, goodwill and business of the non-breaching Party that
cannot reasonably be avoided or fully redressed by providing the other Party an opportunity to cure
the material breach. e. Late Fees and Collection Costs. If Buyer fails to pay Seller an amount owed
under this Agreement by the invoice due date, then Buyer will owe Seller: (i) the delinquent amount;
and (ii) a late payment fee equal to two percent (2%) of the delinquent amount for each full or
partial calendar month past the invoice due date that the delinquent amount remains unpaid. In
addition, if Seller has to file

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 13 -->
litigation to collect the amount owed and Seller prevails in the litigation, Buyer will reimburse
Seller for actual, reasonable, substantiated out-of-pocket expenses incurred by Seller in collecting
the delinquent amount and accrued late payment fees on the delinquent amount. Under no circumstance
will the late payment fee payable to Seller exceed the amount that a creditor may lawfully impose on
a debtor on a delinquent amount under Applicable Law.

12. Miscellaneous. a. Entire Agreement. This Agreement, including its appended Exhibits and Purchase
Schedules entered into during the Term, constitutes the entire agreement between the Parties with
respect to the sale of products by Seller to Buyer and the purchase of products by Buyer from
Seller. This Agreement supersedes all prior and simultaneous representations, discussions,
negotiations, letters, proposals, agreements and understandings, whether written or oral, with
respect to this subject matter. This Agreement will not be binding on either Party unless and until
signed by the chief executive officers of each Party. No handwritten or other addition, deletion or
other modification to the printed portions of this Agreement will be binding upon either Party to
this Agreement. b. Amendments. A Party may not amend nor supplement the terms and conditions in this
Agreement through the inclusion of additional or different terms and conditions in any quotation,
purchase order, invoice, bill of lading, letter, email or other document or communication. This
Section does not prevent the reliance on the descriptive information in transaction documents
identifying the ordered Products (e.g., the type and quantity of ordered products and scheduled date
and location for delivery). No amendment of this Agreement will be valid or effective unless made in
writing and signed and exchanged by the chief executive officers of the Parties. A Party may approve
or reject a request for an amendment in its sole and absolute discretion. c. Waiver. The failure of
either party to insist in any one or more instances upon strict performance of any of the provisions
of this Agreement or to take advantage of any of its rights shall not operate as a continuing waiver
of such rights. No right or obligation under this Agreement will be considered to have been waived
by a Party unless such waiver is in writing and is signed by an officer of the waiving Party and
delivered to the other Party. No consent to or waiver of a breach by either Party will constitute a
consent to, waiver of, or excuse for any other, different, or subsequent breach by such Party. d.
Governing Law. This Agreement and all claims or causes of action arising out of or related to this
Agreement shall be governed in all respects, including as to validity, interpretation and effect, by
the laws of the State of Illinois and the United States of America, without giving effect to its
principles or rules of conflict of laws. The United Nations Convention on Contracts for the
International Sale of Goods will not govern or otherwise be applicable to this Agreement. e.
Severability. If any term of provision of this Agreement, or the application thereof shall be found
invalid, void or unenforceable by any government or governmental organization having jurisdiction
over the subject matter, the remaining provisions, and any application thereof, shall nevertheless
continue in full force and effect. f. Assignment. This Agreement, its rights and obligations, is not
assignable or transferable by either Party, in whole or in part, except with the prior written
consent of the other Party, which consent will not be unreasonably withheld, conditioned or delayed.
Notwithstanding the foregoing, either Party may transfer and assign this Agreement to any of its
affiliates or in connection with any merger, consolidation or sale of assets without the other
Party's prior consent provided (a) that any such assignment will not result in the assigning Party
being released or discharged from any liability under this Agreement, and (b) the purchaser/assignee
will expressly assume all obligations of the assigning Party under this Agreement. The assigning
Party will provide the other Party with written

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 14 -->
notice of such assignment prior to or promptly following the effective date of such assignment. A
change of control shall be deemed an assignment requiring consent hereunder provided that any
transfer or assignment that results in Seller's and Buyer's current common parent, Reynolds Group
Holdings Limited, ceasing to control either party shall not require consent of the other party. The
restrictions in this Section will not preclude a Party for authorizing an Affiliate to purchase or
sell a product on behalf of a Party under this Agreement. Subject to the foregoing, all of the
terms, conditions and provisions of this Agreement shall be binding upon and shall inure to the
benefit of the successors and assignees of the respective Parties. g. Third Party Beneficiaries.
Except as otherwise provided in a Purchase Schedule, there are no intended third-party beneficiaries
of this Agreement. h. Good Faith and Cooperation. Except where this Agreement states that a Party
may expressly exercise a right or render a decision in its "sole and absolute discretion", a Party
will exercise its rights under this Agreement in its good faith business judgment. A Party will
perform its obligations under this Agreement in a commercially reasonable manner consistent with
industry practices and in compliance with Applicable Law. A Party will promptly take such actions,
provide such information and sign such documents as the other Party may reasonably request to obtain
the benefits and exercise the rights granted, and to perform the obligations imposed, under this
Agreement. i. Notices. Any notice required or permitted to be provided by a Party under this
Agreement will be made to the notice address of the receiving Party set forth below or to an
alternate notice address later designated by the receiving Party in accordance with this Subsection.
Notices will be effective upon actual receipt by the receiving Party. An emailed notice will be
effective against a receiving Party only if the Receiving Party acknowledge receipt of the emailed
notice in a return notice to the notifying Party. A receiving Party agrees to acknowledge receipt of
an email notice in good faith promptly following receipt. A Party may change its address for notice
by giving notice to the other party Pursuant to this Subsection.

Address for notice to Buyer:

Pactiv LLC 1900 West Field Court Lake Forest, IL 60045 Attn: John McGrath, Chief Executive Officer
Email: jmcgrath@pactiv.com

For any notice concerning default or termination, with a copy to:

Pactiv LLC 1900 West Field Court Lake Forest, IL 60045 Attn: Steven R. Karl, General Counsel Email:
skarl@pactiv.com

Address for notices to Seller:

Reynolds Consumer Products LLC 1900 W. Field Court Lake Forest, IL 60045 Attention: Lance Mitchell,
Chief Executive Officer Email: Lance.Mitchell@@ReynoldsBrands.com

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019

For any notice concerning default or termination, with a copy to:
<!-- page 15 -->
Reynolds Consumer Products LLC 1900 W. Field Court Lake Forest, IL 60045 Attention: David Watson,
General Counsel Email: David.Watson@ReynoldsBrands.com j. Independent Contractors. The relationship
of the Parties established by this Agreement is that of independent contractors, and nothing
contained in this Agreement shall be construed to: (a) give either Party the power to direct and
control the day-to-day activities of the other Party, (b) establish the Parties as partners, joint
ventures, co-owners or otherwise as participants in a joint or common undertaking, or (c) allow a
Party to bind the other Party in any manner or otherwise create or assume any obligation on behalf
of the other Party for any purpose whatsoever. A Party will not be considered an agent of the other
Party. k. Non-Exclusive Supply Relationship. Except as may be provided in a Purchase Schedule, the
Agreement is not evidence of, nor does it create, any form of exclusive supply relationship between
the Parties concerning the purchase and sale of products. Except as may be provided in a Purchase
Schedule and for the types and quantities of products in an accepted purchase order, nothing in the
Agreement obligates a Party to sell or purchase any specified volume, market share or other minimum
level of products during the Term. l. Construction. Unless the context otherwise requires, the
following rules of construction will be applied to in the interpretation of the Agreement: (1)
Headings are for convenience only and do not affect interpretation; (2) Singular includes the plural
and vice-versa; (3) Gender includes all genders; (4) If a word or phrase is defined, its other
grammatical forms have a corresponding meaning; (5) The meaning of general words is not limited by
specific examples introduced by "includes", "including" or "for example" or similar expressions; (6)
The word "person" includes an individual, corporation, company, trust, partnership, limited
partnership, unincorporated body, joint venture, consortium or other legal entity; (7) A reference
in any Purchase Schedule or Exhibit to an Article, Section, Subsection or Clause is a reference to
an Article, Section, Subsection or Clause in that Purchase Schedule or Exhibit unless otherwise
identified; (8) Reference to a Purchase Schedule or Exhibit is a reference to a Schedule, Exhibit
described, appended or otherwise identified in this Agreement; (9) A reference to conduct includes,
without limitation, an omission, statement or undertaking, whether or not in writing; (10) A
reference to a third-party is a reference to a person who is not a Party to this Agreement; (11)
Where a period of time is specified for the performance of any act and dates from a given day or the
day of an act or event, the period shall be exclusive of that date; and (12) the Parties agree that
the Agreement is the product of negotiation between sophisticated parties and individuals, all of
whom were or have been given the opportunity to be represented by counsel, and each of whom had an
opportunity to participate in, and did participate in, negotiation of the terms hereof. Accordingly,
the Parties acknowledge and agree that the Agreement is not a contract of adhesion and that
ambiguities in the Agreement, if any, shall not be construed strictly or in favor of or against
either Party, but rather shall be given a fair and reasonable construction. m. Execution. This
Agreement may be executed in any number of counterparts, each of which shall be deemed an original
as against the Party whose signature appears thereon, but all of which taken together shall
constitute but one and the same instrument. Acceptance of this Agreement may be made by e-mail, mail
or other commercially reasonable means showing the signatures of the chief executive officers of the
Parties.

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
<!-- page 16 -->
In witness whereof, Seller and Buyer have executed this Master Supply Agreement as of the Effective
Date. REYNOLDS CONSUMER PRODUCTS LLC, as Seller

By: //s// Lance Mitchell Lance Mitchell Chief Executive Officer

PACTIV LLC, as Buyer

By: //s// John McGrath John McGrath Chief Executive Officer

Source: REYNOLDS CONSUMER PRODUCTS INC., S-1, 11/15/2019
