<!-- page 1 -->
# STRATEGIC ALLIANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2011-12-27 |
| Parties | Sumitomo Mitsui Banking Corporation (“SMBC”); SMBCNikko Securities Inc. (“Nikko” and together with SMBC, “SMBC/Nikko”); Moelis & Company Holdings LP (“Moelis Holdings”); Moelis & Company Holdings GP LLC, (“Moelis General Partner”, and together with Moelis Holdings, the “MoelisEntities”); SMBC, Nikko, Moelis Holdings and Moelis General Partner (each a “party” and collectively referred to as the “parties") |
| Source | CUAD v1 / MOELIS_CO_03_24_2014-EX-10.19-STRATEGIC ALLIANCE AGREEMENT |

Exhibit 10.19 STRATEGIC ALLIANCE AGREEMENT

Among SUMITOMO MITSUI BANKING CORPORATION, SMBC NIKKO SECURITIES INC. And MOELIS & COMPANY HOLDINGS
LP, MOELIS & COMPANY HOLDINGS GP LLC Dated December 27, 2011
<!-- page 2 -->
TABLE OF CONTENTS ARTICLE I. CERTAIN DEFINITIONS; INTERPRETATION. 1.1 Certain Definitions 2 1.2
Interpretations 5 ARTICLE II. STRATEGIC ALLIANCE. 2.1 Strategic Alliance 6 2.2 Obligations of the
Parties 6 ARTICLE III. SCOPE. 3.1 Scope 6 3.2 Covered Businesses 6 3.3 Covered Regions 6 3.4
Japanese Companies 7 3.5 Client 7 3.6 Corporate Lending Business 7 ARTICLE IV. FEE ALLOCATION. 4.1
General Allocation 7 4.2 Certain Moelis Holdings Sell-side Assignments 7
<!-- page 3 -->
4.3 Target Transactions 8 4.4 Discretionary Fee Sharing 8 4.5 Primary Fee Allocation Criteria 8
ARTICLE V. NON-CIRCUMVENTION/NON-SOLICITATION. 5.1 Non-Circumvention 8 5.2 Non-Solicitation 8 5.3
Japan Office 9 i
<!-- page 4 -->
ARTICLE VI. SENIOR SPONSORSHIP; ALLIANCE REVIEW COMMITTEE. 6.1 Alliance Review Committee 9 ARTICLE
VII. TRAINING AND DEVELOPMENT. 7.1 Training and Development 9 7.2 Secondment Program 10 ARTICLE
VIII. ENGAGEMENTS. 8.1 Engagement Letters and other Agreements 10 8.2 Expenses 11 8.3 Conflict
Clearance 11 8.4 Compliance with Laws 11 ARTICLE IX. JOINT MARKETING. 9.1 Joint Marketing 11 ARTICLE
X. CONFIDENTIALITY.
<!-- page 5 -->
10.1 Confidentiality 11 ARTICLE XI. TERM 11.1 Term 12 11.2 Termination 13 11.3 Effect of Termination
13 ARTICLE XII. CERTAIN RIGHTS OF SMBC/NIKKO. 12.1 Advisory Board 14 12.2 Right of First Refusal 14
ii
<!-- page 6 -->
12.3 Moelis General Partner's Consent to Certain Transfers 15 12.4 Certain Transfer Matters 15 12.5
Amendments to the Moelis Holdings Agreement 17 12.6 Percentage Interest Limit 18 ARTICLE XIII.
REGISTRATION RIGHTS. 13.1 Registration 18 13.2 Piggyback Registration 19 13.3 Reduction of Size of
Underwritten Offering 20 13.4 Registration Procedures 21 13.5 Conditions to Offerings 23 13.6
Suspension Period 24 13.7 Market Stand-Off Agreement 25 13.8 Registration Expenses 26 13.9
Indemnification; Contribution 26 13.10 Rule 144 29 13.11 Transfer of Registration Rights 29 13.12
Termination of Registration Rights 29 ARTICLE XIV. REPRESENTATIONS AND WARRANTIES; CONDUCT OF
BUSINESS 14.1 Representations and Warranties of Moelis 29 14.2 Representations and Warranties of
SMBC/Nikko 30 14.3 Survival of Covenants, Representations and Warranties 30 ARTICLE XV.
<!-- page 7 -->
MISCELLANEOUS 15.1 Expenses; No Partnership or Joint Venture 31 15.2 Notice 31 15.3 Entire
Agreement; Amendment; Waivers; Counterparts 31 15.4 No Assignment 32 15.5 Obligation and
Responsibilities of SMBC/Nikko 32 15.6 Separability 32 15.7 Compliance with Laws 32 15.8 Governing
Laws; Jurisdiction 32 15.9 Effect on Prior Agreement 33 15.10 Good Faith Discussion; Further
Assurances 33 iii
<!-- page 8 -->
STRATEGIC ALLIANCE AGREEMENT This Strategic Alliance Agreement is entered into as of December 27,
2011 by and among Sumitomo Mitsui Banking Corporation ("SMBC"), a Japanese corporation with its head
office at 1-2, Marunouchi 1-chome, Chiyoda-ku, Tokyo 100-0006, Japan and its subsidiary SMBC Nikko
Securities Inc. ("Nikko" and together with SMBC, "SMBC/Nikko"), a Japanese corporation with its head
office at 3-1, Marunouchi 3-chome, Chiyoda-ku, Tokyo 100-8325, Japan, on the one hand, and Moelis &
Company Holdings LP ("Moelis Holdings"), a Delaware limited partnership with offices at 399 Park
Avenue, New York, NY 10022, United States, and Moelis & Company Holdings GP LLC, a Delaware limited
liability company with offices at 399 Park Avenue, New York, NY 10022, United States ("Moelis
General Partner", and together with Moelis Holdings, the "Moelis Entities"), on the other hand.
SMBC, Nikko, Moelis Holdings and Moelis General Partner are each referred to herein as a "party" and
collectively referred to as the "parties". W I T N E S S E T H: WHEREAS, on March 1, 2011,
SMBC/Nikko and Moelis Holdings entered into that certain Strategic Alliance Agreement (Phase I) with
respect to certain investment banking businesses in certain regions involving Japanese companies
(the "Prior Agreement"); WHEREAS, on the date hereof, SMBC entered into an Investment and
Subscription Agreement (as modified or amended, the "Subscription Agreement") with Moelis Holdings
and Moelis General Partner, pursuant to which SMBC has agreed to acquire 57,364 newly issued
Partnership Interests; WHEREAS, the parties wish to amend and restate the Prior Agreement to further
set forth the understanding of the parties with respect to certain investment banking businesses in
certain regions involving Japanese companies and to set forth certain agreements with respect to
certain transfer and registration rights relating to the Partnership Interests as of the Effective
Date; and WHEREAS, the execution and delivery of this Agreement is a condition to the closing of the
transactions contemplated by the Subscription Agreement. NOW, THEREFORE, in consideration of the
foregoing and the respective promises contained herein and for other good and valuable
consideration, the receipt and sufficiency of which are hereby acknowledged:
<!-- page 9 -->
ARTICLE I. CERTAIN DEFINITIONS; INTERPRETATION. 1.1 Certain Definitions. "Agreement" means this
Strategic Alliance Agreement, as amended or modified from time to time in accordance with Section
15.3, including all schedules and exhibits hereto. "Alliance Review Committee" has the meaning given
in Section 6.1. "Client" has the meaning given in Section 3.5. "Closing" means the Closing as
defined in the Side Letter. "Confidential Information" has the meaning given in Section 10.1.
"control" shall mean possession, directly or indirectly, of the power to direct or cause the
direction of the management and policies of an entity whether through ownership of voting
securities, by contract or otherwise, including the ability to elect the majority of the directors
or the members of a similar governing body of such entity. "Covered Businesses" has the meaning
given in Section 3.2. "Covered Regions" has the meaning given in Section 3.3. "Demand Notice" has
the meaning set forth in Section 13.1(a)(i). "Demand Registration" has the meaning set forth in
Section 13.1(a)(i). "Effective Date" has the meaning set forth Section 11.1. "Indemnified Party" has
the meaning set forth in Section 13.9(c). "Indemnified Persons" has the meaning set forth in Section
13.9(a). "Indemnifying Party" has the meaning set forth in Section 13.9(c). "Introduces" and
"Introduced" means that a party arranges or arranged an initial substantive meeting (in person or by
phone) between a senior decision maker at the Client and the other party. "IPO" means an initial
underwritten public offering and sale of Partnership Interests (or any securities of Moelis Holdings
or any successor entity into which Partnership Interests are converted, exchanged or redesignated)
for cash pursuant to an effective registration statement (other than on Form S-4 or S-8 or a
comparable form). 2
<!-- page 10 -->
"Issuer FWP" has the meaning assigned to "issuer free writing prospectus" in Rule 433 under the
Securities Act. "Japanese Companies" has the meaning given in Section 3.4. "Japanese Competitors"
means any Japanese financial institution that engages in an investment banking business or any other
Covered Business in Japan or outside Japan. "KM" means Mr. Ken Moelis and any entity or person
controlled by or affiliated with Mr. Moelis, including Moelis Manager, any family trust or
otherwise, through which Mr. Ken Moelis holds his Partnership Interests. "Losses" has the meaning
set forth in Section 13.9(a). "Main-Advisor Party" has the meaning set forth in Section 8.4. "Major
Japanese Competitors" means the following entities together with any ultimate parents controlling
such entities: Mitsubishi UFJ Financial Group, Inc., Mizuho Financial Group, Inc., Nomura Holdings,
Inc., Daiwa Securities Group Inc., Sumitomo Mitsui Trust Holdings, Inc., Resona Holdings, Inc.,
Shinsei Bank, Limited., Orix Corporation, any of their respective subsidiaries as of the date of
this Agreement that substantially engages in an investment banking business or any other Covered
Business in Japan, and any respective successors of any of the entities set forth herein. "Minimum
Aggregate Fees" has the meaning given in Section 4.3. "Moelis Competitor" means any business
enterprise that is engaged in, or owns or controls a significant interest in any entity that, in
either case, is engaged, primarily or in any substantial manner in, investment banking activities or
any other business activities that Moelis Holdings and/or its affiliates are engaged in primarily or
in any substantial manner; provided, however, that no private equity fund, sovereign wealth fund or
merchant bank shall be deemed a "Moelis Competitor". "Moelis Entities" has the meaning set forth in
the preamble to this Agreement. "Moelis General Partner" has the meaning set forth in the preamble
to this Agreement. "Moelis Holdings" has the meaning set forth in the preamble to this Agreement.
"Moelis Holdings Agreement" means that certain Limited Partnership Agreement of Moelis Holdings,
dated as of July 1, 2011 (as amended). "Moelis Manager" means Moelis & Company Manager LLC, a
Delaware limited liability company. "Nikko" has the meaning set forth in the preamble to this
Agreement. "Nikko Affiliate" has the meaning set forth in Section 10.1. 3
<!-- page 11 -->
"Non-Japanese Competitors" means the following entities together with any ultimate parents
controlling such entities: Evercore Partners Inc., Hawkpoint Partners Limited, Perella Weinberg
Partners LP, Sagent Advisors Inc., DC Advisory Partners Limited and Stifel Financial Corp. (which,
for the avoidance of doubt, includes Stifel Nicolaus Weisel (f/k/a Thomas Weisel)). "Partnership
Interests" means limited partnership interests and any securities of Moelis Holdings or any
successor entity into which Partnership Interests are converted, exchanged or redesignated,
including in connection with any recapitalization of Moelis Holdings for the purpose of conducting
the IPO. "party" or "parties" has the meaning set forth in the preamble to this Agreement.
"Piggyback Registration" has the meaning set forth in Section 13.2. "Prior Agreement" has the
meaning set forth in the recitals to this Agreement. "Prospectus" means the prospectus (including
any preliminary prospectus and any final prospectus) included in any Registration Statement, as
amended or supplemented by any free writing prospectus, whether or not required to be filed with the
SEC, prospectus supplement with respect to the terms of the offering of any portion of the
Registrable Securities covered by the Registration Statement and by all other amendments and
supplements to the prospectus, and all material incorporated by reference in such prospectus.
"Registrable Securities" means all SMBC Units beneficially owned by the SMBC Unit-Holders at any
time, and any securities of Moelis Holdings or any successor entity into which the SMBC Units are
converted, exchanged or redesignated, including in connection with any recapitalization of Moelis
Holdings for the purpose of conducting the IPO; provided, however, that an SMBC Unit shall cease to
be a Registrable Security when (i) it has been effectively registered under the Securities Act and
disposed of in accordance with the Registration Statement covering it, or (ii) it is distributed to
the public pursuant to Rule 144. "Registration Statement" means any registration statement of Moelis
Holdings that covers Registrable Securities pursuant to the provisions of this Agreement, including
the prospectus, amendments and supplements to such registration statement, including pre- and post-
effective amendments, and all exhibits and all material incorporated by reference in such
registration statement. "Representative" means, with respect to any person, such person's, or such
person's subsidiaries', directors, officers, employees, accountants, investment bankers, commercial
bank lenders, attorneys and other advisors or representatives (including the employees or attorneys
of such accountants, investment bankers or attorneys). "Rule 144" means Rule 144 promulgated under
the Securities Act or any similar rule or regulation hereafter adopted by the Securities and
Exchange Commission having substantially the same effect as such rule. 4
<!-- page 12 -->
"Side Letter" means the letter from Moelis General Partner and Moelis Holdings to SMBC, re
Investment in Moelis & Company Holdings LP, dated the date hereof. "SMBC" has the meaning set forth
in the preamble to this Agreement. "SMBC Affiliate" has the meaning set forth in Section 10.1. "SMBC
Competitor" means (i) any of the Japanese Competitors, (ii) each of the Non-Japanese Competitors,
(iii) any entity that is controlled by any Japanese Competitor or any Non-Japanese Competitor and
that engages in an investment banking business or any other Covered Business and (iv) any entity
that is under common control with or controls any Major Japanese Competitor and that engages in an
investment banking business or any other Covered Business. "SMBC Units" means all Partnership
Interests, including Common Units, held by an SMBC Unit-Holder, which shall include all Partnership
Interests acquired pursuant to the Subscription Agreement or thereafter. "SMBC Unit-Holders" has the
meaning set forth in Section 13.1(a)(i). "Securities Act" means the Securities Act of 1933, as
amended. "SMB C/Nikko" has the meaning set forth in the preamble to this Agreement. "Strategic
Alliance" means the rights and obligations of the parties set forth in ARTICLE II to XII of this
Agreement. "Sub-Advisor Party" has the meaning set forth in Section 8.4. "Subscription Agreement"
has the meaning set forth in the recitals to this Agreement. "Suspension Period" has the meaning set
forth in Section 13.6. "Underwritten Offering" means a public offering of securities registered
under the Securities Act in which an underwriter, placement agent or other intermediary participates
in the distribution of such securities. 1.2 Interpretations. (a) Capitalized terms used without
definition herein shall have the respective meanings given to such terms in the Moelis Holdings
Agreement. 5
<!-- page 13 -->
ARTICLE II. STRATEGIC ALLIANCE. 2.1 Strategic Alliance. SMBC/Nikko and Moelis Holdings wish to
continue their Strategic Alliance with respect to certain investment banking business in certain
regions involving Japanese Companies as set forth herein, and will continue to offer the other the
same quality or level of services that were offered under the Prior Agreement. SMBC/Nikko and Moelis
Holdings will help the other continue the growth of the other party's investment banking business.
2.2 Obligations of the Parties. Each of the parties acknowledge and agree that each other party may,
and at the reasonable request from another party, shall, cause one or more of such party's
affiliates to act on behalf of such party in the performance of its duties or exercise of its rights
under this Agreement. ARTICLE III. SCOPE. 3.1 Scope. Subject to the terms and conditions set forth
in this Agreement and to the extent permitted by pre-existing arrangements of either party,
SMBC/Nikko, on the one hand, and Moelis Holdings, on the other hand, shall use their commercially
reasonable best efforts to work together on Covered Businesses involving Japanese Companies where
all principal parties involved are located within Covered Regions. The Strategic Alliance shall
continue to be non-exclusive. 3.2 Covered Businesses. "Covered Businesses" shall mean M&A advisory,
restructuring advisory (such as advising on recapitalization and restructuring transactions),
capital markets advisory (including agency private placements), risk advisory (such as advising on
investing, structuring, managing, restructuring and divesting risk exposures and complex assets
classes) and merchant banking businesses (such as principal investment) to the extent the applicable
target transaction requirement set forth in Section 4.3 of this Agreement is satisfied, but
specifically excludes (unless the parties mutually agree to include a specific transaction) (i)
underwritten offerings and bank or similar committed financings, (ii) purely domestic Japanese
transactions such as transactions solely between/among companies organized or headquartered in Japan
(including any transactions of or by subsidiaries or affiliates of such companies located throughout
the world conducted as part of any such transaction), (iii) any transactions introduced to a party
by a person or entity (other than a principal party to the transaction) not affiliated with such
party and (iv) transactions where a party, its subsidiary or controlled affiliate is a principal
party. 3.3 Covered Regions. "Covered Regions" shall mean Japan, North America, Europe, the Middle
East and North Africa, Australia, Hong Kong and China. For the avoidance of doubt, the definition of
Covered Regions does not prohibit the parties from 6

discussing or working together on Covered Businesses in regions outside the Covered Regions, such as
non-Japan/Hong Kong/China Asia. 3.4 Japanese Companies. "Japanese Companies" shall mean (i)
companies organized or headquartered in Japan and their subsidiaries and controlled affiliates
outside Japan, (ii) subsidiaries and controlled affiliates organized or headquartered in Japan of
parent companies in the Covered Regions other than Japan and (iii) Japanese governmental and
quasi-governmental entities and affiliates. 3.5 Client. A "Client" is (i) with respect to
SMBC/Nikko, a Japanese Company or any other person or entity within Covered Regions that SMBC/Nikko
Introduces to Moelis Holdings pursuant to this Agreement and (ii) with respect to Moelis Holdings, a
Japanese Company or any other person or entity within Covered Regions that Moelis Holdings
Introduces to SMBC/Nikko pursuant to this Agreement. 3.6 Corporate Lending Business. SMBC/Nikko and
Moelis Holdings will continue to work together in good faith to seek ways to expand the Strategic
Alliance to cover corporate lending opportunities where Moelis Holdings sources corporate lending
opportunities for SMBC/Nikko to Moelis Holdings' clients and works with SMBC/Nikko to provide
SMBC/Nikko clients and relationships access to Moelis Holdings capabilities in Covered Businesses.
The parties may enter into additional agreements and/or addenda to this Agreement designed to
elaborate upon and clarify the arrangements contemplated by this Section 3.6. ARTICLE IV. FEE
ALLOCATION. 4.1 General Allocation. The parties agree to share fees 50%/50% on assignments within
the scope of this Agreement set forth in Section 3.1 where SMBC or Nikko, on the one hand, and
Moelis Holdings, on the other hand, are jointly retained as co-advisors by a Client for such
assignments, except as otherwise mutually agreed with respect to a specific matter by the parties.
The parties agree that the parties will generally seek to be jointly retained as co-advisors by a
Client on assignments within the scope of this Agreement. 4.2 Certain Moelis Holdings Sell-side
Assignments. In the case of M&A sell-side assignments originated by Moelis Holdings within the scope
of this Agreement set forth in Section 3.1 for which SMBC or Nikko does not serve (together with
Moelis Holdings) as a co-advisor to the seller, if SMBC or Nikko introduces the actual buyer, and
neither SMBC nor Nikko obtains a mandate to serve as an advisor to such buyer in connection with
such acquisition, Moelis Holdings will pay SMBC/Nikko an introduction fee equal to 15% of the sale
transaction fee paid to Moelis Holdings. There will be no other sharing of fees received from the
seller between Moelis Holdings and SMB C/Nikko on any such assignments. 7
<!-- page 14 -->
<!-- page 15 -->
4.3 Target Transactions. The Strategic Alliance will target transactions on which both parties work
together as co-advisors to a Client on the terms and conditions set forth in Section 3.1 with
minimum aggregate fees (the "Minimum Aggregate Fees") of: (1) M&A advisory, $3 million, (2)
restructuring advisory, $2 million and (3) capital markets advisory and risk advisory, $1 million.
4.4 Discretionary Fee Sharing. One or more senior representatives of Moelis Holdings or SMBC/Nikko,
as the case may be, will consider on a case by case basis if requested by a senior representative of
the other party, discretionary fee sharing when Moelis Holdings or SMBC/Nikko, as the case may be,
provides demonstrable value. 4.5 Primary Fee Allocation Criteria. The parties may mutually agree on
a fee allocation different from the foregoing allocations in good faith based on, among other
things, the following criteria: (a) Whether one or both parties have an important relationship that
is crucial to securing an assignment (b) Resource contribution (c) Product expertise (d) Industry
expertise (e) Transaction size (f) Resource constraints ARTICLE V.
NON-CIRCUMVENTION/NON-SOLICITATION. 5.1 Non-Circumvention. Subject to pre-existing arrangements of
either party, each party agrees not to circumvent this Agreement and to act in good faith in the
spirit of the Strategic Alliance. Each party shall ensure that its controlled affiliates comply with
the terms and conditions of this Agreement. 5.2 Non-Solicitation. Each of SMBC/Nikko and Moelis
Holdings agrees not to solicit or hire any employee of the other party during the term of this
Agreement and for a period of 12 months thereafter; provided, however, that the foregoing
restriction shall not apply to general solicitations to the public that are not specifically
directed to employees of other party (or employment of applicants to such solicitations). Each of
SMBC/Nikko and Moelis Holdings agrees, during the term of this Agreement (except pursuant to this
Agreement) and for a period of 12 months thereafter, not to solicit any Client Introduced by the
other party in connection with an assignment on Covered 8
<!-- page 16 -->
Businesses involving Japanese Companies where all principal parties involved are located within
Covered Regions. Notwithstanding the foregoing, this provision shall not prevent any party from
soliciting or otherwise contacting any Client (i) for any purpose other than working on or obtaining
an assignment on Covered Businesses involving Japanese Companies in Covered Regions where all
principal parties involved are located within Covered Regions or (ii) with whom such party (or its
employees or consultants) has had a pre-existing relationship, including, but not limited to, a
pre-existing contractual or business relationship, prior to the Introduction of such Client in
connection with an assignment covered by this Agreement. 5.3 Japan Office. Moelis Holdings agrees
not to open an office in Japan conducting Covered Businesses during the term of this Agreement.
ARTICLE VI. SENIOR SPONSORSHIP; ALLIANCE REVIEW COMMITTEE. 6.1 Alliance Review Committee. As soon as
reasonably practicable following the Effective Date, SMBC/Nikko and Moelis Holdings shall form a six
person committee comprised of two senior executives from each of SMBC, Nikko and Moelis Holdings to
review and discuss the progress of the Strategic Alliance (the "Alliance Review Committee"). Each
party shall notify the other parties if it replaces either of its designees to the Alliance Review
Committee. The Alliance Review Committee will meet annually and will have the authority to recommend
changes to the Strategic Alliance or this Agreement if deemed appropriate. For the avoidance of
doubt, the recommendations of the Alliance Review Committee will not be binding upon any party
unless and until this Agreement is amended or modified pursuant to Section 15.3. ARTICLE VII.
TRAINING AND DEVELOPMENT. 7.1 Training and Development. During the term of this Agreement, Moelis
Holdings shall offer certain full-time analysts and associates of SMBC/Nikko, or employees with
similar responsibilities, the opportunity to participate annually in Moelis Holdings' training
program for newly hired full-time analysts and associates, to the extent that Moelis Holdings' holds
such a program. SMBC/Nikko shall reimburse Moelis Holdings for all out-of-pocket and allocated
expenses incurred by Moelis Holdings in connection with SMBC/Nikko employees' attending the Moelis
Holdings training program. 9
<!-- page 17 -->
7.2 Secondment Program. (a) During the term of this Agreement, SMBC/Nikko shall second 3 or 4
bankers to Moelis Holdings' New York office and second 2 or 3 bankers to Moelis Holdings' London
office as local staff of Moelis Holdings. Moelis Holdings shall use its commercially reasonable best
efforts to second a banker to SMBC/Nikko's Tokyo office as local staff of SMBC/Nikko. All secondees
shall be investment bankers that serve in a position with responsibilities typically associated with
an Associate or a Vice President at a major international investment bank, except as otherwise
agreed between SMB C/Nikko and Moelis Holdings. (b) Each party shall be responsible for all
out-of-pocket and allocated expenses incurred by its employees who are seconded. A party's
secondee(s) must be reasonably acceptable to the other parties and shall agree to be subject to any
policies and procedures, including without limitation, relating to confidential and proprietary
information and securities and other trading activity limitations, that the party accepting such
secondee may determine are necessary and/or appropriate. (c) SMBC/Nikko and Moelis Holdings will
from time to time during the term of this Agreement, review and discuss the secondment program and
such additions and changes the parties consider appropriate to further the Strategic Alliance.
ARTICLE VIII. ENGAGEMENTS. 8.1 Engagement Letters and other Agreements. (a) Parties. Where the
parties are executing an assignment together pursuant to this Agreement, it is anticipated that
generally both parties (or one of their respective affiliates) will sign the engagement letter (and,
where necessary, other relevant agreements) with the relevant Client in connection with the
assignment. In certain limited circumstances mutually agreed upon by the parties, one party may sign
the engagement letter with the Client and then such party would also sign an agreement with the
other party or parties for such party or parties to provide services to the Client and receive
compensation, indemnification and other protections after receiving the written consent of such
Client. (b) Rights and Obligations. The engagement letters will (unless otherwise agreed) include a
provision to the effect that: "The rights and obligations of SMBC, Nikko and Moelis Holdings are the
several rights and obligations of SMBC, Nikko and Moelis Holdings and that each of SMBC, Nikko or
Moelis Holdings shall not be liable or responsible for the actions or omissions of the others." (c)
Payment. The engagement letters will (unless otherwise agreed) provide that payments would be made
to either SMBC/Nikko or Moelis Holdings and SMBC/Nikko and Moelis Holdings will split the fees
pursuant to this Agreement. 10
<!-- page 18 -->
8.2 Expenses. If only one party is engaged for an assignment, such party will submit expenses of the
other parties for reimbursement by the Client. If there is an expense cap or any other expense
reimbursement reduction, the parties will (unless otherwise agreed) bear the cost of such
unreimbursed expenses in the same proportion as the parties agreed to split the fees from such
assignment. 8.3 Conflict Clearance. Each party shall have its own separate conflict identification,
business selection and client vetting procedures. The parties will cooperate to identify and resolve
potential conflict issues. 8.4 Compliance with Laws. In the case where one party executes an
engagement letter with a Client (the "Main-Advisor Party") and the Main-Advisor Party appoints and
retains the other party or parties as a sub-advisor (the "Sub-Advisor Party"), each of the
Main-Advisor Party and the Sub-Advisor Party shall comply in all material respects with all
applicable laws or regulations, including the UK Bribery Act 2010, the US Foreign Corrupt Practices
Act of 1977 and any other similar anti-bribery act in its execution and performance of its services
for the Covered Businesses for such Client. If either of the Main-Advisor Party or Sub-Advisor Party
breaches its obligations set forth in this Section 8.4, the non- breaching party shall have the
right to immediately terminate its sub-advisor agreement or any other similar agreement entered into
with respect to the Covered Businesses for such Client by providing a written notice to the
breaching party that specifically identifies how the breaching party has breached this Section 8.4.
ARTICLE IX. JOINT MARKETING. 9.1 Joint Marketing. The parties shall establish a joint marketing
effort for the Strategic Alliance. Among other things, the parties shall agree upon a joint press
release and communication strategy for announcing the Strategic Alliance and certain joint marketing
materials which either party may use in marketing to Clients. ARTICLE X. CONFIDENTIALITY. 10.1
Confidentiality. The parties each agree to keep confidential all non-public information disclosed by
another party or a Client or prospective Client or a representative thereof in connection with the
Strategic Alliance (including this Agreement) ("Confidential Information"), (i) except to
subsidiaries, affiliates or their professional advisors (and provided that the Party shall cause the
recipient to assume and perform the confidentiality obligations equivalent to those imposed on such
party under this Agreement and shall be responsible for breach of such obligations by such
recipient) and (ii) except as required by judicial process or such party's regulatory authorities,
and 11
<!-- page 19 -->
to use such information only for purposes of the Strategic Alliance (including this Agreement);
provided, however, that Confidential Information shall not include (i) information that is already
in the receiving party's possession when it is received and not subject to a confidentiality
agreement or other obligation of confidentiality to the disclosing party, (ii) information
separately obtained by the receiving party from a third party that is not known or should not
reasonably be known to the person receiving such information to be bound by a confidentiality
agreement or other obligation of confidentiality to the disclosing party and (iii) information
independently developed by the receiving party without any use of Confidential Information. In the
event that any disclosure of Confidential Information is required by judicial process or such
party's regulatory authorities, the party required to make such disclosure shall, to the extent
commercially practicable and legally permissible, consult with the party that provided such
Confidential Information prior to making any such disclosure. Nothing in this section shall restrict
the receiving party's ability to make any legally required disclosures of Confidential Information
to bank examiners or other supervisory authorities having jurisdiction over the receiving party.
Each of Moelis Holdings and SMBC/Nikko shall also ask the other if it has internally cleared the
receipt of non-public information regarding a Client or prospective Client before the party
providing such information delivers any such information to the receiving party. Due to Japanese
firewall restrictions, (i) SMBC will not disclose Confidential Information relating to its Clients
to Nikko (ii) Nikko will not disclose Confidential Information relating to its Clients to SMBC and
(iii) Moelis Holdings shall not disclose Confidential Information relating to a Client received from
SMBC or any of its affiliates (excluding Nikko and any person that would be an affiliate of Nikko if
Nikko were not an affiliate of SMBC) (an "SMBC Affiliate") to Nikko or its affiliates (excluding
SMBC and any person that would be an affiliate of SMBC if Nikko were not an affiliate of SMBC) (a
"Nikko Affiliate") or Confidential Information relating to a Client received from Nikko or any Nikko
Affiliate to SMBC or any SMBC Affiliate, without first obtaining such Client's consent to such
disclosure. This Section 10.1 shall terminate with respect to Confidential Information relating to a
(prospective) Client, two years following receipt of such information, and with respect to any other
Confidential Information, two years following the termination of this Agreement. ARTICLE XI. TERM
11.1 Term. This Agreement shall be effective as of January 1, 2012 (the "Effective Date"), provided,
however, that, ARTICLE XII and ARTICLE XIII shall not be effective until after the Closing. The
initial term of this Agreement shall begin on the Effective Date and continue for three (3) years,
subject to the prior termination rights provided below. At the end of such initial term, and any
renewed term, as applicable, this Agreement shall automatically renew for an additional one (1) year
term, unless a party provides written notice to the other parties at least six (6) months prior to
the end of the 12
<!-- page 20 -->
initial term. At any time during a renewed term, this Agreement may be terminated by any party on
six (6) months prior notice that it wishes to terminate the Agreement. 11.2 Termination. This
Agreement may be terminated as follows: (a) effective immediately upon mutual agreement of each of
the parties; (b) immediately by a non-breaching party, if either SMBC or Nikko, on the one hand, or
Moelis Holdings, on the other hand, shall materially breach the terms and conditions of this
Agreement, and such breach is continuing after written notice has been given by the non- breaching
party to the breaching party that specifically identifies how the breaching party has breached this
Agreement, and a reasonable period of time has elapsed in which to cure such breach, which period
shall not be less than ninety (90) calendar days from the date that such breaching parties receive
such notice; (c) immediately upon the bankruptcy, insolvency, or making of the assignment for the
benefit of creditors by a party; unless such termination is waived by the parties in writing not
subject to any of the foregoing proceedings; (d) by any party if the SMBC Unit-Holders cease to hold
any Partnership Interests as a result of sale or transfer pursuant to Section 12.4 of this Agreement
or Section 8.4 of the Moelis Holdings Agreement, such termination to be effective six (6) months
following the date on which the other parties receive written notice of such party's election to
terminate this Agreement; and (e) immediately by Moelis Holdings if the Closing has not occurred by
March 1, 2012 or such later date if the Closing is delayed pursuant to the terms of the Subscription
Agreement. 11.3 Effect of Termination. In the event of the termination of this Agreement, no party
shall have any liability to any other party in respect of this Agreement except for any liabilities
relating to any breach or any payment obligation hereunder and arising prior to such termination;
provided, that, Sections 5.2 (Non-Solicitation) and 8.2 (Expenses) and ARTICLE X (Confidentiality),
XII (Certain Transfer Rights of SMBC/Nikko) (other than Section 12.6, after the SMBC Unit-Holders no
longer hold any Partnership Interests), XIII (Registration Rights) and XV (Miscellaneous) shall
survive any expiration or termination of this Agreement; provided, however, if Moelis Holdings
terminates this agreement pursuant to Section 11.2(b) due to a material breach by either SMBC or
Nikko, or if this Agreement is terminated pursuant to Section 11.2(c) due to the bankruptcy,
insolvency or making of the assignment for the benefit of creditors by either SMBC or Nikko, ARTICLE
XII (Certain Transfer Rights of SMBC/Nikko) and XIII (Registration Rights) shall not survive such
termination; provided, further, that, if this Agreement is terminated prior to the Closing, XII
(Certain Transfer Rights of SMB C/Nikko), XIII (Registration Rights) shall not survive such
termination. 13
<!-- page 21 -->
ARTICLE XII. CERTAIN RIGHTS OF SMBC/NIKKO. 12.1 Advisory Board. During the term of the Strategic
Alliance, SMBC/Nikko shall have the right to appoint one person to serve as a member of the Advisory
Board of Moelis Holdings. 12.2 Right of First Refusal. (a) Prior to the IPO and during the term of
the Strategic Alliance, SMBC shall have the right of first refusal to purchase all (but not less
than all) Additional Units that Moelis Holdings proposes to issue to an SMBC Competitor, including
(x) in a proposed issuance that is excepted from Section 3.4.2 of the Moelis Holdings Agreement as
an issuance to a Strategic Investor, and (y) in a proposed issuance that is subject to Section 3.4.2
of the Moelis Holdings Agreement, to the extent that the Partners do not exercise in full their
right of first refusal thereunder. The above rights are in addition to the pro rata right of first
refusal granted to all Partners with respect to issuances of Additional Units in Section 3.4.2 of
the Moelis Holdings Agreement. (b) In the event Moelis Holdings proposes to undertake an issuance of
Additional Units to which clause (x) of Section 12.2(a) applies, it shall give SMBC written notice
of its intention describing the price and terms upon which Moelis Holdings proposes to issue the
same. SMBC shall have ten (10) days from the date of delivery of any such notice to agree to
purchase all, but not less than all, of such Additional Units, for the price and upon the terms
specified in the notice, by delivering written notice to Moelis Holdings. Following the expiration
of such 10-day period, Moelis Holdings shall have one hundred and eighty- (180-) days to sell or
enter into an agreement to sell the Additional Units with respect to which SMBC's right of first
refusal was not exercised, at a price and upon terms no more favorable to the purchasers of such
securities than specified in Moelis Holdings' notice. In the event Moelis Holdings has not sold the
Additional Units or entered into an agreement to sell the Additional Units within such one hundred
and eighty- (180-) day period, Moelis Holdings shall not thereafter issue or sell any Additional
Units without first complying again with this Section 12.2. (c) In the event Moelis Holdings
proposes to undertake any issuance of Additional Units to which clause (y) of Section 12.2(a)
applies, SMBC shall specify in its notice delivered to Moelis Holdings pursuant to Section 3.4.2(b)
of the Moelis Holdings Agreement, in addition to whether or not it elects to purchase its pro rata
portion of such Additional Units, whether or not it shall exercise its right of first refusal to
purchase all (but not less than all) of the Additional Units that other Partners do not purchase
pursuant to their right of first refusal under Section 3.4.2 of the Moelis Holdings Agreement. (d)
The right of first refusal granted hereunder may not be assigned or transferred, except that such
right is assignable by SMBC to any of its respective Wholly-Owned Subsidiaries. 14
<!-- page 22 -->
12.3 Moelis General Partner's Consent to Certain Transfers. (a) Prior to the IPO and during the term
of the Strategic Alliance, Moelis General Partner shall not consent to a sale or transfer by a
Partner of its Partnership Interests to an SMBC Competitor unless the Moelis General Partner caused
the Partner proposing to sell or transfer its Partnership Interests to provide SMBC with a right to
purchase, on the same terms and conditions, including price, all (but not less than all) of the
Partnership Interests that such Partner proposes to sell or transfer to an SMBC Competitor. (b) In
the event a Partner proposes to undertake a sale or transfer of Partnership Interests to which the
foregoing right applies, and Moelis General Partner must consent to the sale or transfer, Moelis
General Partner shall require that Partner to give SMBC written notice of its intention to sell or
transfer Partnership Interests to an SMBC Competitor describing the price and terms upon which such
Partner proposes to sell or transfer its Partnership Interests. SMBC shall have ten (10) days from
the date of delivery of any such notice to agree to purchase all, but not less than all, of such
Partnership Interests, for the price and upon the terms specified in the notice, by delivering
written notice to such Partner and Moelis Holdings. (c) Following the expiration of such 10-day
period, the Partner proposing to sell or transfer Partnership Interests shall have one hundred and
eighty- (180-) days to sell or transfer, or enter into an agreement to sell or transfer the
Partnership Interests with respect to which SMBC 's right under Section 12.3(a) was not exercised,
at a price and upon terms no more favorable to the purchasers of such securities than specified in
the Partner's notice. In the event the Partner has not sold or transferred the Partnership
Interests, or entered into an agreement to sell or transfer the Partnership Interests, within such
one hundred and eighty- (180-) day period, Moelis General Partner shall not consent to the Partner's
selling or transferring its Partnership Interests to an SMBC Competitor thereafter without first
requiring the Partner to comply again with this Section 12.3. (d) The rights granted under this
Section 12.3 may not be assigned or transferred, except that such right is assignable by SMBC to any
of its respective Wholly-Owned Subsidiaries. (e) Nothing in this Section 12.3 shall affect the power
of Moelis General Partner to withhold consent to any transfer of Partnership Interests in its sole
discretion to the extent authorized under Section 8.1 of the Moelis Holdings Agreement. 12.4 Certain
Transfer Matters. (a) During the term of the Strategic Alliance, if KM sells all or a portion of
KM's Partnership Interests, the SMBC Unit-Holders may sell a pro rata portion of the SMBC Units
without regard to any timing or transfer restrictions imposed by this Agreement or the Moelis
Holdings Agreement, except that such sale or transfer may not be to a Moelis Competitor. In the
event KM proposes to undertake a sale or 15
<!-- page 23 -->
transfer of KM's Partnership Interests to which the foregoing right applies, KM shall give written
notice to SMBC and Moelis General Partner at least ten (10) days in advance of such sale or
transfer, describing the percent of KM's Partnership Interest being sold or transferred. KM shall
give written notice to SMBC and Moelis General Partner within five (5) days of any cancellation or
postponement of such sale. When an SMBC Unit- Holder elects to sell or transfer the SMBC Units
pursuant to its rights granted under this Section 12.4(a), the SMBC Unit-Holder shall provide Moelis
General Partner with a notice stating its intent to sell or transfer the SMBC Units pursuant to this
Section 12.4(a). Within ten (10) days of receiving such notice from an SMBC Unit-Holder, Moelis
General Partner shall deliver to such SMBC Unit-Holder its consent for the proposed sale or
transfer, unless the proposed sale or transfer is to a Moelis Competitor. For the avoidance of
doubt, if the transaction is subject to (i) a Drag- Along Right or a Tag-Along Right, and such right
was exercised, the SMBC Unit-Holders shall be deemed to have sold its pro rata portion of its
Partnership Interests with respect to such transaction and shall not have any additional rights
under this Section 12.4(a) or (ii) Section 13.2 of this Agreement, and an SMBC Unit-Holder exercised
its right thereunder, such SMBC Unit-Holder shall be deemed to have sold its pro rata portion of its
Partnership Interests with respect to such transaction and shall not have any additional rights
under this Section 12.4(a). The above right shall be in addition to the Drag-Along Right and the
Tag-Along Right with respect to transfers by Moelis General Partner set forth in Sections 8.4.1 and
8.4.2, respectively, of the Moelis Holdings Agreement. (b) During the term of the Strategic
Alliance, and after the first anniversary of Moelis Holdings' commencing a public registered share
sale program for managing directors and other employees of Moelis Holdings or its affiliates, the
SMBC Unit-Holders may sell or transfer Partnership Interests pursuant to such public registered
share sale program for any given period in an amount equal to (i) the number of Partnership
Interests that can be sold pursuant to the program in such period multiplied by (ii) a fraction
whose numerator is the number of Partnership Interests the SMBC Unit-Holders have elected to sell in
such program during such period and whose denominator is the total number of Partnership Interests
the SMBC Unit-Holders have elected to sell plus the number of Partnership Interests all other
persons have elected to sell in such program during such period (whether such Partnership Interests
are held as outstanding common stock of a successor or parent company of Moelis Holdings or as
interests in an affiliate of such public company) (for example, if 50 Partnership Interests can be
sold during the period, the SMBC Unit-Holders has elected to sell 400 Partnership Interests and all
persons other than the SMBC Unit-Holders have elected to sell 1,600 Partnership Interests, then the
SMBC Unit-Holders may sell 10 Partnership Interests and the other persons may sell 40 Partnership
Interests); provided, that, (1) the SMBC Unit-Holders shall be subject to the same conditions and
terms as the other participants in the program; (2) such right under this Section 12.4(b) shall not
apply to sales Moelis Holdings may permit certain of its managing directors and other employees to
make under Rule 144 or otherwise; and (3) if both Section 12.4(a) and Section 12.4(b) apply to a
sale or transfer of Partnership Interests, an SMBC Unit-Holder may sell the higher of the amount
under Section 12.4(a) or Section 12.4(b). If such public registered share sale program as set forth
in this Section 12.4(b) is established, Moelis Holding will provide the SMBC Unit-Holders with a
monthly report which provides the number of Partnership Interests being 16

sold in such share sale program during the relevant month and the outstanding number of Partnership
Interests that are left in the public sale registered sale program as of the end of the relevant
month. (c) After the termination of the Strategic Alliance: (i) prior to the IPO, Moelis General
Partner shall not unreasonably withhold its consent to an SMBC Unit-Holder's transferring all or a
portion of the SMBC Units to any other person who is not a Moelis Competitor; and (ii) following the
IPO, the SMBC Unit-Holders may freely transfer the SMBC Units, subject to applicable securities
laws. (d) Following the third anniversary of the Closing, whether or not during the term of the
Strategic Alliance, the SMBC Unit- Holders may sell up to 9,231 SMBC Units (i) prior to the IPO,
with the consent of Moelis General Partner (which consent may not be unreasonably withheld),
provided such sale is not to a Moelis Competitor, or (ii) following the IPO, without restriction,
subject only to applicable securities laws. (e) During the term of the Strategic Alliance and prior
to the IPO, Moelis Holdings shall notify SMBC in advance of publicly announcing the sale or issuance
of any interests in Moelis Holdings (other than Management Units) to a Strategic Investor, provided,
that Moelis Holdings shall notify SMBC in advance only to the extent and in such manner as it is
permissible under any confidentiality agreement entered into in connection with such sale or
issuance. 12.5 Amendments to the Moelis Holdings Agreement. Without the prior written consent of
SMBC (which consent shall not be unreasonably withheld, delayed or conditioned), Moelis General
Partner shall not enter into any side letter or agreement (other than the Vesting Agreement of any
Management Partner) with any Limited Partner in respect of the issuance or holding of any class or
type of interests in the Partnership that (i) modifies the limited liability of the SMBC
Unit-Holders, (ii) materially and adversely affects in a disproportionate manner the interest of the
SMBC Unit-Holders in Net Income, Net Loss or Available Assets, (iii) increases the Capital
Contributions required to be made by the SMBC Unit-Holders, (iv) modifies the SMBC Unit-Holders'
Drag-Along Rights or Tag-Along Rights under the Moelis Holdings Agreement, or (v) materially and
adversely affects in a disproportionate manner the interest of the SMBC Unit-Holders in the
distributions, regardless of whether such side letter or agreement is entered into by such Limited
Partner in its capacity as such, and regardless of whether SMBC is entitled to participate or does
participate in such issuance of or otherwise holds any such interests; provided, however, the
foregoing consent of SMBC shall not be required if the side letter or agreement affects Management
Units in a substantially similar manner. 17
<!-- page 24 -->
12.6 Percentage Interest Limit. Notwithstanding anything to the contrary in this Agreement or the
Moelis Holdings Agreement, none of SMBC, Moelis Holdings or any of their controlled affiliates shall
take any action, including with respect to the acquisition of any Partnership Interests pursuant to
the exercise of any right under this Agreement or the Moelis Holdings Agreement, that would
reasonably be expected to (i) cause SMBC, or any of its affiliates, to require approval of the Board
of Governors of the Federal Reserve System under Section 4 of the U.S. Bank Holding Company Act of
1956, as amended (including Regulation Y promulgated thereunder), or otherwise, to acquire or retain
any interest in Moelis Holdings or (ii) cause Moelis Holdings to be deemed to be or presumed to be
"controlled" by SMBC, or any of its affiliates, for purposes of the U.S. Bank Holding Company Act of
1956, as amended (including Regulation Y promulgated thereunder). SMBC and Moelis Holdings shall
cooperate with each other and use their reasonable best efforts to avoid any of the events in the
preceding sentence by taking any and all actions necessary, including, without limitation, in
connection with any restructuring to facilitate the IPO, which shall include, among other things,
issuing a new class or series of Partnership Interests or alternative economic interests to SMBC, or
its affiliates, as applicable. Notwithstanding anything to the contrary in this Section 12.6,
nothing shall prevent SMBC, or its affiliates, from seeking a noncontrol determination from the
staff of the Board of Governors of the Federal Reserve System with respect to any action that would
otherwise be prohibited by this Section 12.6, and, after receiving a noncontrol determination,
taking such action, including acquiring additional Partnership Interests. ARTICLE XIII. REGISTRATION
RIGHTS. 13.1 Registration. (a) (i) Following the IPO and the termination of the Strategic Alliance,
SMBC shall have the right to demand that Moelis Holdings register the sale of all, but not less than
all, of the Registrable Securities held by SMBC and its affiliates (together the "SMBC
Unit-Holders") under the Securities Act (the "Demand Notice"), provided, however, SMBC shall not be
permitted to deliver the Demand Notice within (i) 180 days of the IPO or (ii) 60 days of any public
offering and sale of Partnership Interests (and/or any securities of Moelis Holdings or any
successor entity into which Partnership Interests are converted, exchanged or redesignated) for cash
pursuant to an effective registration statement (other than on Form S-4 or S-8 or a comparable
form), and subject to the terms of any agreement entered into by Moelis Holdings, SMBC or Nikko
pursuant to Section 13.7. Within 60 days after Moelis Holdings receives a written notice to register
the Registrable Securities, Moelis Holdings will 18
<!-- page 25 -->
file a Registration Statement, on an appropriate form, to register the sale of the Registrable
Securities, which Registration Statement will (if specified in the SMBC Unit-Holders' notice)
contemplate the ability of the SMBC Unit-Holders to effect an Underwritten Offering (the "Demand
Registration"). The Demand Notice shall specify the intended method of distribution of the
Registrable Securities. Subject to Section 13.2, Moelis Holdings may include in any registration
effected pursuant to this Section 13.1 any securities for its own account or for the account of
holders (other than the SMBC Unit-Holders) of Partnership Interests; provided, that, Moelis Holdings
shall pay a portion of all expenses of Moelis Holdings (including those set forth in Section 13.8)
in connection with any such registration, in proportion to the aggregate selling price of all
securities so included in any such registration. (ii) Moelis Holdings will use its commercially
reasonable efforts (i) to cause any Registration Statement to be declared effective (unless it
becomes effective automatically upon filing) as promptly as practicable after the filing thereof
with the SEC and (ii) to keep such Registration Statement current and effective for a period of 90
days, or such shorter time necessary for the completion of the sale of Registrable Securities
registered thereon. Moelis Holdings further agrees to use its commercially reasonable efforts to
supplement or make amendments to such Registration Statement as may be necessary to keep such
Registration Statement effective for the period referred to in clause (ii) above, including (A) to
respond to the comments of the SEC, if any, (B) as may be required by the registration form utilized
by Moelis Holdings for such Registration Statement or by the instructions to such registration form,
(C) as may be required by the Securities Act, or (D) as may reasonably be requested in writing by
the SMBC Unit-Holders or any underwriter and acceptable to Moelis Holdings. Moelis Holdings agrees
to furnish to the SMBC Unit-Holders copies of any such supplement or amendment no later than the
time it is first used or filed with the SEC. (b) If the Demand Notice specifies that the Registrable
Securities will be sold in an Underwritten Offering, the parties shall mutually agree on the lead
underwriter and any additional underwriters. (c) Any registration initiated pursuant to Section
13.1(a) shall not count as a Demand Registration (i) unless and until the Registration Statement
with respect to the Registrable Securities has become effective and remained effective for a period
of 90 days or, if a shorter time, until all of the Registrable Securities have been sold, or (ii) if
the conditions to closing specified in the underwriting agreement, if any, entered into in
connection with such registration are not satisfied or waived, other than by reason of a failure on
the part of the SMBC Unit-Holders. 13.2 Piggyback Registration. If Moelis Holdings proposes to file
a registration statement under the Securities Act (other than non- participating, non-convertible
debt or 19
<!-- page 26 -->
equity securities or securities to be issued pursuant to a registration statement on Form S-4 or S-8
or any comparable form) for its own account or for the account of a holder (other than the SMBC
Unit-Holders) of Partnership Interests, including in connection with the IPO and where SMB C/Nikko
(including an SMBC Unit-Holder) has the right to sell any or all SMBC Units under this Agreement,
then Moelis Holdings shall give written notice of such proposed filing to the SMBC Unit-Holders as
soon as commercially practicable but in no event less than (i) 20 days before the anticipated filing
date or (ii) if Moelis Holdings determines to conduct a registration less than 20 days before the
anticipated filing date, then on the date Moelis Holdings determines to proceed with such
registration (a "Piggyback Registration"). If Moelis Holdings proposes to file the registration
statement before the termination of the Strategic Alliance, the written notice to the SMBC
Unit-Holders shall include the number of Partnership Interests to be sold by KM and the percentage
of the total Partnership Interests held by KM represented by that number. Within 10 days after
delivery of any such notice by Moelis Holdings, or such shorter period as Moelis Holdings specifies
in such notice if Moelis Holdings determines to conduct a registration less than 10 days before the
anticipated filing date, the SMBC Unit-Holders may request in writing that Moelis Holdings include
any Registrable Securities held by the SMBC Unit-Holders in the proposed registration. The request
by the SMBC Unit-Holders shall specify the number of Registrable Securities proposed to be included
in the registration. Moelis Holdings will then, subject to Section 13.3, include such requested
Registrable Securities in the proposed registration; provided, however, that if Moelis Holdings
proposes to file the registration statement before the termination of the Strategic Alliance, the
percentage of all Registrable Securities that may be included in the proposed registration may not
exceed the percentage of KM's total Partnership Interests to be sold in the proposed registration,
as stated in the notice by Moelis Holdings. The SMBC Unit-Holders may not withdraw any request for a
Piggyback Registration involving an Underwritten Offering after the preliminary prospectuses for the
proposed offering have been printed, or any "road show" has begun, or Moelis Holdings has made any
public announcement with the consent of the SMBC Unit-Holders that assumes the participation of the
SMBC Unit-Holders in the proposed offering, or in any event less than 24 hours before the pricing of
such offering. The SMBC Unit-Holders shall have no right to select the underwriters in an
Underwritten Offering in connection with a Piggyback Registration. Notwithstanding anything to the
contrary in this Section 13.2, Moelis Holdings may, at any time at its sole option, choose not to
proceed with the proposed registration that gives rise to the Piggyback Registration. 13.3 Reduction
of Size of Underwritten Offering. Notwithstanding anything to the contrary contained herein, if the
lead underwriter or underwriters in an Underwritten Offering pursuant to Section 13.1 or Section
13.2 advise Moelis Holdings that, in their good faith judgment, the number of Partnership Interests
(including any Registrable Securities) that Moelis Holdings, the SMBC Unit-Holders and any other
persons intend to include in any Registration Statement exceeds the number that can be sold in the
offering in light of marketing factors or because the sale of a greater number would adversely
affect the price of the Partnership Interests to be sold, then the number of Partnership Interests
to be included in the Registration Statement for the account of Moelis Holdings, the SMBC
Unit-Holders and any other persons will be reduced to the 20
<!-- page 27 -->
extent necessary to reduce the total number of securities to be included in any such Registration
Statement to the number recommended by the lead underwriter or underwriters, in accordance with the
following priorities: (a) in the case of a Demand Registration pursuant to Section 13.1, priority
will be (i) first, all Registrable Securities included in the Registration Statement, (ii) second,
any Partnership Interests proposed to be offered by Moelis Holdings for its own account (iii) third,
pro rata among any other holders of Partnership Interests requested to be registered pursuant to a
contractual right, and (iv) fourth, pro rata among any other holders of Partnership Interests
requested to be registered; (b) in the case of a registration statement initiated by Moelis Holdings
for its own account that gives rise to a Piggyback Registration pursuant to Section 13.2, priority
will be (i) first, Partnership Interests proposed to be offered by Moelis Holdings for its own
account, (ii) second, pro rata among all holders of Partnership Interests requested to be registered
pursuant to a contractual right and (iii) third, pro rata among any other holders of Partnership
Interests requested to be registered; and (c) in the case of a registration statement initiated by
Moelis Holdings for the account of holders (other than the SMBC Unit- Holders) of Partnership
Interests, pursuant to registration rights afforded to such holders by contract, that gives rise to
a Piggyback Registration pursuant to Section 13.2, priority will be (i) first, pro rata among the
holders of Partnership Interests for whose account the registration statement was initiated, (ii)
second, Partnership Interests offered by Moelis Holdings for its own account, (iii) third, pro rata
among any other holders of Partnership Interests requested to be registered pursuant to a
contractual right and (iv) fourth, pro rata among any other holders of Partnership Interests
requested to be registered. 13.4 Registration Procedures. Subject to the provisions of Section 13.1
or Section 13.2, in connection with the registration of the sale of Registrable Securities pursuant
to the Demand Registration or a Piggyback Registration hereunder, Moelis Holdings will: (a) furnish
to the SMBC Unit-Holders without charge, no later than the time of filing of a Registration
Statement, copies of such Registration Statement, and thereafter such number of copies of such
Registration Statement, each amendment and supplement thereto (in each case including all exhibits
thereto, including each preliminary prospectus), copies of any and all transmittal letters or other
correspondence with the SEC relating to such Registration Statement and such other documents in such
quantities as the SMBC Unit-Holders may reasonably request from time to time, for as long as Moelis
Holdings is required to cause the Registration Statement to remain current, in order to facilitate
the disposition of the Registrable Securities; (b) provide the SMBC Unit-Holders and their
Representatives with the opportunity to participate in the preparation of the Registration Statement
and the related Prospectus; 21
<!-- page 28 -->
(c) use its commercially reasonable efforts to register or qualify the Partnership Interests being
sold under such other securities or "blue sky" laws of such jurisdictions as the SMBC Unit-Holders
reasonably request and do any and all other acts and things as may be reasonably necessary or
advisable to enable the SMBC Unit-Holders to consummate the disposition of the Registrable
Securities in such jurisdictions; provided, however, that Moelis Holdings shall in no event be
required to (w) qualify generally to do business in any jurisdiction where it is not then so
qualified, (x) subject itself to taxation in any jurisdiction where it is not otherwise then so
subject, (y) take any action that would subject it to service of process in suits other than those
arising out of the offer and sale of the securities covered by the Registration Statement or (z)
consent to general service of process in any jurisdiction where it is not then so subject; (d)
notify the SMBC Unit-Holders and the lead underwriter or underwriters, if any, at any time when a
Prospectus relating to Registrable Securities is required to be delivered under the Securities Act,
of the occurrence of any event as a result of which the Registration Statement, the Prospectus
included in a Registration Statement or any amendment or supplement thereto relating to Registrable
Securities contains an untrue statement of a material fact or omits to state any material fact
required to be stated therein or necessary to make the statements therein, in the light of the
circumstances under which they were made, not misleading, and Moelis Holdings will use its
commercially reasonable efforts to prepare and file with the SEC a supplement or amendment to such
Prospectus and Registration Statement (and comply fully with the applicable provisions of Rules 424,
430A and 430B under the Securities Act in a timely manner) so that, as thereafter delivered to the
purchasers of the Registrable Securities, such Prospectus and Registration Statement will not
contain an untrue statement of a material fact or omit to state any material fact required to be
stated therein or necessary to make the statements therein, in the light of the circumstances under
which they were made, not misleading; (e) advise the lead underwriter or underwriters, if any, and
the SMBC Unit-Holders promptly and, if requested by such persons, confirm such advice in writing, of
the issuance by the SEC of any stop order suspending the effectiveness of the Registration Statement
under the Securities Act or of the suspension by any state securities commission of the
qualification of the Registrable Securities for offering or sale in any jurisdiction, or the
initiation of any proceeding for any of the preceding purposes. If at any time the SEC issues any
stop order suspending the effectiveness of the Registration Statement, or any state securities
commission or other regulatory authority issues an order suspending the qualification or exemption
from qualification of the Registrable Securities under state securities or "blue sky" laws, Moelis
Holdings shall use its commercially reasonable efforts to obtain the withdrawal or lifting of such
order as promptly as practicable; (f) use its commercially reasonable efforts to cause the
Registrable Securities to be registered with or approved by such other governmental authorities as
may be necessary by virtue of the business and operations of Moelis Holdings to enable the SMBC
Unit-Holders to consummate the disposition of the Registrable Securities; provided, however, that
Moelis Holdings shall in no event be required to (w) qualify 22
<!-- page 29 -->
generally to do business in any jurisdiction where it is not then so qualified, (x) subject itself
to taxation in any jurisdiction where it is not otherwise then so subject, (y) take any action that
would subject it to service of process in suits other than those arising out of the offer and sale
of the securities covered by the Registration Statement or (z) consent to general service of process
in any jurisdiction where it is not then so subject; (g) if requested by the SMBC Unit-Holders or
the underwriter or underwriters, if any, promptly include in any Registration Statement or
Prospectus, pursuant to a supplement or post-effective amendment if necessary, such information as
the SMBC Unit-Holders and the underwriter or underwriters, if any, may reasonably request to have
included therein, including information relating to the "Plan of Distribution" of the Registrable
Securities, information about the number of Registrable Securities being sold to the underwriter or
underwriters, the purchase price being paid therefor and any other terms of the offering of the
Registrable Securities to be sold in such offering, and make all required filings of such Prospectus
supplement or post-effective amendment as soon as practicable after Moelis Holdings is notified of
the matters to be included in such Prospectus supplement or post-effective amendment; (h) for the
period beginning a reasonable time before the filing of the Registration Statement and for as long
as Moelis Holdings is required to cause the Registration Statement to remain current under Section
13.1(a)(ii), and except to the extent prohibited by applicable law and subject to entering into
customary confidentiality agreements, after reasonable advance notice, make available for inspection
by the SMBC Unit- Holders, any underwriter participating in any disposition of the Registrable
Securities, and any Representative for the SMBC Unit-Holders or such underwriter, during business
hours and at the location designated by Moelis Holdings, any financial and other records and
corporate documents of Moelis Holdings as will be reasonably necessary to enable them to conduct
reasonable and customary due diligence with respect to Moelis Holdings and the related Registration
Statement and Prospectus, provided, however, that records, documents and information obtained
hereunder will be used by such inspecting person only to conduct such due diligence; and (i)
together with any other holder of Partnership Interests proposing to include securities in any
Underwritten Offering, enter into a reasonable and customary written agreement with the underwriter
or underwriters, if any, in such form and containing such provisions as are reasonable and customary
in the securities business for such an arrangement between underwriters and companies of Moelis
Holding's size and investment stature. 13.5 Conditions to Offerings. The obligations of Moelis
Holdings to take the actions contemplated by Sections 13.1, 13.2 and 13.4 with respect to an
offering of Registrable Securities will be subject to the following conditions: (a) Moelis Holdings
may require each SMBC Unit-Holder to furnish to Moelis Holdings such information regarding such SMBC
Unit-Holder, the Registrable Securities or the distribution of such Registrable Securities as Moelis
Holdings may from time to time request, in each case to the extent reasonably required by the
Securities Act 23
<!-- page 30 -->
and the rules and regulations promulgated thereunder, or under state securities or "blue sky" laws;
and (b) If an offering of Registrable Securities is an Underwritten Offering, each SMBC Unit-Holder
must: (A) agree to sell its Registrable Securities on the basis provided in any underwriting
agreement approved by Moelis Holdings in accordance with Section 13.4(i), (B) complete and execute,
as applicable, all customary questionnaires, powers of attorney, underwriting agreements, lock-up
agreements consistent with Section 13.7 and other documents customarily required under the terms of
such underwriting agreement and (iii) agree to make customary representations and warranties
(including as to due organization and good standing, corporate power and authority, due approval, no
conflicts and ownership and transfer of Registrable Securities, and as to accuracy and completeness
of those statements made in the applicable Registration Statement, Prospectus or other document in
reliance upon and in conformity with written information furnished to Moelis Holdings or the
underwriter or underwriters by such SMBC Unit-Holder) and covenants in such underwriting agreement.
13.6 Suspension Period. (a) Notwithstanding anything to the contrary contained in this Agreement,
Moelis Holdings shall be entitled, by providing prior written notice to the SMBC Unit-Holders, to
postpone the filing or effectiveness or suspend the use of any Registration Statement pursuant to
Section 13.1 for a reasonable period of time not to exceed 60 days in succession or 120 days in any
365-day period (or a longer period of time with the prior written consent of SMBC, which consent
shall not be unreasonably withheld) (a "Suspension Period") if (A) Moelis Holdings determines in
good faith that effecting the registration (or permitting sales under an effective registration)
would reasonably be expected to adversely affect an offering of securities of Moelis Holdings, (B)
Moelis Holdings is in possession of material non-public information and deems it advisable not to
disclose such information in a Registration Statement, or (C) due to a pending or contemplated
financing, acquisition, disposition, corporate reorganization, merger, public offering of securities
or other similar transaction or other material event or circumstance involving Moelis Holdings or
its securities. Moelis Holdings will notify the SMBC Unit-Holders promptly upon the termination of
the Suspension Period. Upon notice by Moelis Holdings to the SMBC Unit-Holders of any determination
to commence a Suspension Period, the SMBC Unit-Holders shall, except as required by applicable law,
including any disclosure obligations under Section 13 of the Exchange Act, keep the fact of any such
Suspension Period strictly confidential, and during any Suspension Period, promptly halt any offer,
sale (including sales pursuant to Rule 144), trading or transfer of any Partnership Interests for
the duration of the Suspension Period until Moelis Holdings has provided notice that the Suspension
Period has been terminated. (b) If Moelis Holdings suspends the use of a Registration Statement
pursuant to Section 13.6(a), the holders of Registrable Securities shall receive an extension of the
registration period under Section 13.1(a)(ii) and 13.1(c) equal to the number of days of the
suspension. 24
<!-- page 31 -->
(c) The SMBC Unit-Holders agrees that, upon receipt of any notice from Moelis Holdings of the
occurrence of any event of the kind described in Section 13.4(d) or Section 13.4(e) or a condition
described in Section 13.6(a), each SMBC Unit-Holder will forthwith discontinue disposition of
Registrable Securities pursuant to the Registration Statement covering the sale of Registrable
Securities until the SMBC Unit-Holders receive copies of the supplemented or amended Prospectus
contemplated by Section 13.4(d) or Section 13.6(d) or notice from Moelis Holdings of the termination
of the stop order or Suspension Period. (d) After the expiration of any Suspension Period and
without any further request from a holder of Partnership Interests, Moelis Holdings shall use its
commercially reasonably efforts to prepare a Registration Statement, or post-effective amendment or
supplement to the Registration Statement or Prospectus or any document incorporated therein by
reference, or file any other required document so that, as thereafter delivered to purchasers of the
Registrable Securities included therein, the Prospectus will not include a material misstatement or
omission or be not effective and useable for the sale of Registrable Securities. 13.7 Market
Stand-Off Agreement. (a) In connection with any Underwritten Offering that is the IPO, or any
Underwritten Offering in which the SMBC Unit-Holders are selling Registrable Securities pursuant to
Sections 13.1 or 13.2, each SMBC Unit-Holder agrees that, during the period of duration (up to 180
days, subject to customary extensions as may be required by the underwriter or underwriters up to a
maximum of 214 days) specified by Moelis Holdings and the underwriter or underwriters of Registrable
Securities, following the date of the final prospectus or other offering document distributed in
connection with the Underwritten Offering, it shall not, to the extent requested by Moelis Holdings
and such underwriter or underwriters, directly or indirectly, sell, offer to sell, contract to sell
(including any short sale or other hedging transaction), grant any option to purchase or otherwise
transfer any Registrable Securities held by it at any time during such period except for such
Registrable Securities as shall be included in such registration. Notwithstanding the foregoing, the
obligations described in this Section 13.7(a) shall not apply (i) to a registration relating solely
to employee benefit plans on Form S-1 or Form S-8, (ii) to a registration relating solely to an
acquisition or similar transaction on Form S-4 or (iii) unless all holders then holding more than 3%
of the issued and outstanding Partnership Interests (and/or any securities of Moelis Holdings or any
successor entity into which the Partnership Interests are converted, exchanged or redesignated) with
a contractual obligation enforceable by Moelis Holdings or its affiliates to do so and all of the
then-current executive officers and directors (if applicable) of Moelis Holdings enter into similar
agreements. (b) In order to enforce the foregoing covenant, Moelis Holdings may impose stop-transfer
instructions with respect to the Registrable Securities of each SMBC Unit-Holder until the end of
such period. 25
<!-- page 32 -->
13.8 Registration Expenses. All fees and expenses incident to Moelis Holding's performance of or
compliance with the obligations of this ARTICLE XIII, including all fees and expenses incurred in
complying with securities or "blue sky" laws, printing expenses, messenger and delivery expenses of
Moelis Holdings, any registration or filing fees payable under any federal or state securities or
"blue sky" laws, the fees and expenses incurred in connection with any listing or quoting of the
securities to be registered on any national securities exchange or automated quotation system, fees
of the Financial Industry Regulatory Authority, fees and disbursements of counsel for Moelis
Holdings, its independent registered certified public accounting firm and any other public
accountants who are required to deliver comfort letters (including the expenses required by or
incident to such performance), fees of transfer agents and registrars, costs of insurance, and the
fees and expenses of other persons retained by Moelis Holdings, will be borne by Moelis Holdings;
provided, however; that the SMBC Unit-Holders shall pay all reasonable out-of-pocket expenses of
Moelis Holdings (including, for the avoidance of doubt, all the fees set forth above in this
section) in connection with the Demand Registration subject to Moelis Holdings' obligations set
forth in Section 13.1(a)(i). The SMBC Unit-Holders will bear and pay any fees and expenses of SMBC
or its affiliates or their Representatives, including their counsel, and any underwriting discounts,
fees and commissions and any transfer taxes applicable to Registrable Securities offered for its
account pursuant to any Registration Statement. 13.9 Indemnification; Contribution. (a) In
connection with any registration of Registrable Securities, Moelis Holdings will indemnify, defend
and hold harmless each SMBC Unit-Holder, its affiliates, directors, officers and SMBC Unit-Holders
and each person who controls SMBC Unit-Holder within the meaning of either Section 15 of the
Securities Act or Section 20 of the Exchange Act (collectively, the "Indemnified Persons") from and
against any and all direct losses, claims, damages, liabilities, obligations, costs and expenses
(including, without limitation, as a result of any notices, actions, suits, proceedings, claims,
demands, assessments, judgments, awards, costs, penalties, taxes and reasonable expenses, including
reasonable attorneys' and other professionals' fees and disbursements, but excluding any
consequential damages) (collectively "Losses") caused by (i) any untrue or alleged untrue statement
of material fact contained in any part of any Registration Statement or any Prospectus, including
any amendment or supplement thereto, used in connection with the Registrable Securities or any
Issuer FWP or (ii) any omission or alleged omission to state therein a material fact required to be
stated therein or necessary to make the statements therein (in the case of a Prospectus, in the
light of the circumstances under which they were made) not misleading; provided, however, that
Moelis Holdings will not be required to indemnify any Indemnified Person for any Losses resulting
from any such untrue statement or omission if such untrue statement or omission was made in reliance
on and in conformity with information with respect to any Indemnified Person furnished to Moelis
Holdings in writing by, or on behalf of, any of the SMBC Unit-Holders expressly for use therein. (b)
In connection with any Registration Statement, Prospectus or Issuer FWP, each SMBC Unit-Holder,
jointly and severally, will indemnify, defend and 26

hold harmless Moelis Holdings, its directors, its officers and each person, if any, who controls
Moelis Holdings (within the meaning of either Section 15 of the Securities Act or Section 20 of the
Exchange Act) to the same extent as the foregoing indemnity from Moelis Holdings to each SMBC
Unit-Holder, but only with respect to information furnished to Moelis Holdings in writing by, or on
behalf of, any SMBC Unit-Holder or any Indemnified Persons expressly for use in such Registration
Statement, Prospectus or Issuer FWP; and provided, further, however, that in no event shall the
liability for indemnity of any SMBC Unit-Holder under this Section 13.9(b) exceed the dollar amount
of the proceeds (net of any underwriting discount or commission or other selling expenses) received
by such SMBC Unit-Holder from the sale of the Registrable Securities giving rise to such
indemnification. (c) In case any claim, action or proceeding (including any governmental
investigation) is instituted involving any person in respect of which indemnity may be sought
pursuant to Section 13.9(a) or 13.9(b), such person (the "Indemnified Party") will promptly, but in
any event within 10 Business Days, notify the person against whom such indemnity may be sought (the
"Indemnifying Party") in writing, and the Indemnifying Party shall have the right to participate in,
and to the extent the Indemnifying Party so desires, to assume the defense thereof with counsel
reasonably satisfactory to the Indemnified Party; provided, that the failure of any Indemnified
Party to give notice within the time limit provided herein shall not relieve the Indemnifying Party
of its obligations under Section 13.9(a) or 13.9(b), except to the extent that the Indemnifying
Party is actually and materially prejudiced by such failure to give notice. In any such claim,
action or proceeding where the Indemnifying Party has assumed the defense thereof, the Indemnified
Party shall have the right, but not the obligation, to participate in any such defense and to retain
its own counsel, but the fees and expenses of such counsel will be at the expense of such
Indemnified Party unless the Indemnified Party and the Indemnified Party have been advised by
counsel that representation of both parties by the same counsel would be inappropriate due to actual
or potential conflicting interests between them. It is understood that the Indemnifying Party will
not, in connection with any claim, action or proceeding or related claims, actions or proceedings in
the same jurisdiction, be liable for the reasonable fees and expenses of more than one separate firm
of attorneys (in addition to any local counsel) at any time for all such Indemnified Parties and
that all such reasonable fees and expenses will be reimbursed as they are incurred. In the case of
the retention of any such separate firm for the Indemnified Parties, such firm will be designated in
writing by the Indemnified Parties. No Indemnified Party will, without the prior written consent of
the Indemnifying Party, settle, compromise or offer to settle or compromise any pending or
threatened proceeding in respect of which any Indemnified Party is seeking indemnity hereunder. The
Indemnifying Party will not be liable for any settlement of any claim, action or proceeding effected
without its written consent, but if such claim, action or proceeding is settled with such consent or
if there has been a final judgment for the plaintiff, the Indemnifying Party agrees to indemnify the
Indemnified Party from and against any Loss by reason of such settlement or judgment. No
Indemnifying Party will, without the prior written consent of the Indemnified Party, settle,
compromise or offer to settle or compromise any pending or threatened proceeding in respect of which
any Indemnified Party is seeking indemnity hereunder, unless such settlement includes (i) an 27
<!-- page 33 -->
unconditional release of such Indemnified Party from all liability in connection with such
proceeding, (ii) no finding or admission of any violation of law or any violation of the rights of
any person by the Indemnified Party or any of its Affiliates can be made as the result of such
action, and (iii) the sole relief (if any) provided is monetary damages that are reimbursed in full
by the Indemnifying Party. (d) If the indemnification provided for in this Section 13.9 from the
Indemnifying Party is unavailable to an Indemnified Party hereunder or is insufficient in respect of
any Losses referred to in this Section 13.9, then the Indemnifying Party, in lieu of indemnifying
such Indemnified Party, will contribute to the amount paid or payable by such Indemnified Party as a
result of such Losses (i) in such proportion as is appropriate to reflect the relative fault of the
Indemnifying Party and Indemnified Party in connection with the actions that resulted in such
Losses, as well as any other relevant equitable considerations, or (ii) if the allocation provided
by clause (i) is not permitted by applicable law, in such proportion as is appropriate to reflect
not only the relative fault referred to in clause (i) but also the relative benefit of Moelis
Holdings, on the one hand, and each SMBC Unit-Holder, on the other, in connection with the
statements or omissions that resulted in such Losses, as well as any other relevant equitable
considerations; provided, however, that in no event shall a SMBC Unit-Holder be required by this
Section 13.9(d) to contribute an aggregate amount in excess of the dollar amount of proceeds (net of
underwriting discounts and commissions and other selling expenses) received by such SMBC Unit-Holder
from the sale of Registrable Securities giving rise to such contribution. The relative fault of such
Indemnifying Party and Indemnified Party will be determined by reference to, among other things,
whether any action in question, including any untrue or alleged untrue statement of a material fact
or omission or alleged omission to state a material fact, has been taken by, or relates to
information supplied by, such Indemnifying Party or Indemnified Party, and the parties' relative
intent, knowledge, access to information and opportunity to correct or prevent such action. The
amount paid or payable by a party as a result of the Losses referred to above will be deemed to
include, subject to the limitations set forth in Section 13.9(c), any reasonable out of pocket legal
or other out of pocket fees or expenses reasonably incurred by such party in connection with any
investigation or proceeding. (e) The parties agree that it would not be just and equitable if
contribution pursuant to Section 13.9(d) were determined by pro rata allocation or by any other
method of allocation that does not take into account the equitable considerations referred to in
Section 13.9(d). No person guilty of "fraudulent misrepresentation" (within the meaning of Section
11(f) of the Securities Act) will be entitled to contribution from any person who was not guilty of
such fraudulent misrepresentation. Notwithstanding the provisions of this Section 13.9(e), a SMBC
Unit-Holder shall not be required to contribute, in the aggregate, any amount in excess of the
amount by which the net proceeds received by such SMBC Unit-Holder from the sale of the Registrable
Securities exceeds the amount of any damages which such SMBC Unit-Holder has otherwise been required
to pay by reason of such untrue or alleged untrue statement or omission or alleged omission. 28
<!-- page 34 -->
(f) If indemnification is available under this Section 13.9, the Indemnifying Party will indemnify
each Indemnified Party to the fullest extent permissible under applicable law provided in Sections
13.9(a) and 13.9(b) without regard to the relative fault of said Indemnifying Party or Indemnified
Party or any other equitable consideration provided for in Section 13.9(d) or 13.9(e). The
obligations of Moelis Holdings under this Section 13.9 shall be in addition to any liability that
Moelis Holdings may otherwise have to any Indemnified Person. (g) Notwithstanding anything to the
contrary in this Agreement, each of the Indemnified Parties has relied on this Section 13.9, is an
express third party beneficiary of this Section 13.9 and is entitled to enforce the obligations of
the applicable Indemnified Parties under this Section 13.9 directly against such Indemnified Parties
to the full extent thereof. 13.10 Rule 144. For so long as Moelis Holdings is subject to the
requirements of Section 13, 14 or 15(d) of the Securities Act, Moelis Holdings agrees that it will
use its reasonable best efforts to (i) make and keep public information available, as those terms
are understood and defined in Rule 144 and (ii) file the reports required to be filed by it under
the Securities Act and the Exchange Act. 13.11 Transfer of Registration Rights. The rights to cause
Moelis Holdings to register securities granted to the SMBC Unit-Holders under this ARTICLE XIII may
be assigned by the SMBC Unit-Holders with the consent of Moelis Holdings, except that the SMBC
Unit-Holders may assign such rights to their Wholly-Owned Subsidiaries without the consent of Moelis
Holdings. 13.12 Termination of Registration Rights. The registration rights contained in Section
13.1 shall automatically terminate when the SMBC Unit-Holders collectively hold Registrable
Securities in an amount less than (i) 1% of the issued and outstanding Partnership Interests (and/or
any securities of Moelis Holdings or any successor entity into which the Partnership Interests are
converted, exchanged or redesignated) and (ii) the average weekly reported volume of trading in
Partnership Interests (and/or any securities of Moelis Holdings or any successor entity into which
the SMBC Units are converted, exchanged or redesignated) on all national securities exchanges and/or
reported through the automated quotation system of a registered securities association for the four
calendar weeks preceding the date on which such determination is made. ARTICLE XIV.

REPRESENTATIONS AND WARRANTIES; CONDUCT OF BUSINESS 14.1 Representations and Warranties of Moelis.
Moelis Holdings and Moelis General Partner each represent and warrant to SMBC/Nikko that: (a)
Organization. Moelis General Partner has been duly formed and is validly existing as a limited
liability company under the Delaware Limited Liability 29
<!-- page 35 -->
Company Act. Moelis Holdings has been duly formed and is validly existing as a limited partnership
under the Delaware Revised Uniform Limited Partnership Act. (b) Power, Authority, Etc. Each of
Moelis Holdings and Moelis General Partner has all requisite power and authority to enter into this
Agreement and to consummate the transactions contemplated herein. The execution, delivery and
performance of this Agreement do not require any further consent of any third party or governmental
authority. This Agreement has been duly authorized, executed and delivered by Moelis Holdings and
Moelis General Partner and, when duly executed and delivered by the other parties hereto, will be
the valid and binding obligation of Moelis Holdings and Moelis General Partner, enforceable in
accordance with its terms, except (a) as may be limited by or subject to any bankruptcy, insolvency,
reorganization, moratorium or other similar laws affecting creditors' rights generally and (b) that
the remedies of specific performance, injunction and other forms of equitable relief may not be
available because they are subject to certain tests of equity jurisdiction, equitable defenses and
the discretion of the court before which any proceeding therefor may be brought. (c) Other. Each of
the representations and warranties set out in Exhibit A of this Agreement are true and correct on
the date hereof. 14.2 Representations and Warranties of SMBC/Nikko. SMBC and Nikko each represent
and warrant to Moelis Holdings and Moelis General Partner that: (a) Organization. SMBC and Nikko
have been duly formed and are validly existing as corporations under the laws of Japan. (b) Power,
Authority, Etc. SMBC and Nikko have all requisite power and authority to enter into this Agreement
and to consummate the transactions contemplated herein. The execution, delivery and performance of
this Agreement by SMBC and Nikko does not require any further consent of any third party or
governmental authority. This Agreement has been duly authorized, executed and delivered by each of
SMBC and Nikko and, when duly executed and delivered by the other parties hereto, will be the valid
and binding obligation of SMBC and Nikko, enforceable in accordance with its terms, except (a) as
may be limited by or subject to any bankruptcy, insolvency, reorganization, moratorium or other
similar laws affecting creditors' rights generally and (b) that the remedies of specific
performance, injunction and other forms of equitable relief may not be available because they are
subject to certain tests of equity jurisdiction, equitable defenses and the discretion of the court
before which any proceeding therefor may be brought. 14.3 Survival of Covenants, Representations and
Warranties. Each of the covenants, representations and warranties of the parties in this Agreement
and the Subscription Agreement shall survive the Closing through and including the date thirty (30)
days following the receipt by SMBC/Nikko of the audited financial statements of Moelis Holdings as
of and for the year ended December 31, 2012. 30
<!-- page 36 -->
ARTICLE XV. MISCELLANEOUS 15.1 Expenses; No Partnership or Joint Venture. Each party will bear its
own legal, marketing, travel and other expenses in connection with the Strategic Alliance. No party
is the partner, joint venture partner or agent of any other party with power to bind any other party
contractually. This Agreement and the Strategic Alliance represent an agreement to cooperate and not
a partnership or joint venture agreement. No party owes any other party a fiduciary duty by virtue
of this Agreement or the operation of the Strategic Alliance. 15.2 Notice. Notice under this
Agreement must be in writing and may be delivered by mail, overnight delivery service or email as
follows: If to SMBC: 2-3, Otemachi 1-chome Chiyoda-ku, Tokyo 100-0004 Attention: Toshihiro Horiuchi,
Senior Vice President, Securities Business Planning Dept., Planning Dept., Investment Banking Unit.
Email address: horiuchi_toshihiro@ck.smbc.co.jp If to Nikko: Shin-Marunouchi Building 18F, 5-1,
Marunouchi 1-chome, Chiyoda-ku, Tokyo 100-6518 Attention: Masami Hagiwara, Head of Mergers &
Acquisitions Administration Email address: hagiwara_masami@smbcnikko.co.jp If to Moelis Holdings:
Moelis & Company Holdings LP 399 Park Avenue, 5th Floor New York, NY 10022 Attention: Kate Pilcher
Ciafone, Senior Vice President Email address: kate.ciafone@moelis.com, with a copy to: Attention:
Osamu Watanabe, General Counsel Email address: osamu.watanabe@moelis.com 15.3 Entire Agreement;
Amendment; Waivers; Counterparts. This Agreement and the Subscription Agreement (as modified by any
letter agreement between the parties entered into on the date hereof), incorporates the entire
understanding of the parties and supersedes all previous agreements with respect to the subject
matter hereof. No 31
<!-- page 37 -->
amendment or modification of this Agreement shall be effective unless it is made in writing and
signed by each of the parties. No waiver, expressed or implied, by any party of a breach by another
party of this Agreement, or of any terms and provisions of this Agreement, shall constitute a waiver
of any subsequent such breaches or of future enforcement of any such terms or provisions. This
Agreement may be executed in three or more counterparts, each of which shall be deemed an original,
but all of which shall constitute one and the same agreement. 15.4 No Assignment. This Agreement may
not be assigned by any party without the written consent of the other parties, except to a
subsidiary or controlled affiliate of such party which succeeds such party's conduct of Covered
Businesses. 15.5 Obligation and Responsibilities of SMBC/Nikko. SMBC and Nikko shall be severally
and not jointly responsible for any obligation or responsibilities incurred or assumed by SMB
C/Nikko hereunder. 15.6 Separability. In case one or more of the provisions contained in this
Agreement are for any reason held to be invalid, illegal or unenforceable in any respect under any
such law or regulation, the invalidity, illegality, or unenforceability will not affect any other
provisions of this Agreement, which will be construed as if contained in this Agreement, and each
illegal, invalid or unenforceable provision will be construed as broadly as may be possible so that
the original intent of the parties is given effect to the greatest extent possible. 15.7 Compliance
with Laws. Each of the parties shall execute and perform this Agreement in compliance with all
applicable laws or regulations. Notwithstanding the foregoing, a party shall not be obligated to
take any action that violates, infringes or conflicts with or prohibited from taking any action
required to be in compliance with any applicable laws or regulations. 15.8 Governing Laws;
Jurisdiction. This Agreement shall be governed by, and construed in accordance with, the laws of the
State of New York without regard to principles of conflict of laws. The parties irrevocably and
unconditionally submit to the exclusive jurisdiction of any state or Federal court sitting in
Manhattan, New York over any suit, action or proceeding arising out of or relating to this
Agreement. The parties hereby agree that service of any process, summons, notice or document by U.S.
registered mail addressed to such party at the address above shall be effective service of process
for any action, suit or proceeding brought in any such court. The parties irrevocably and
unconditionally waive any objection to the laying of venue of any such suit, action or proceeding
brought in any such court and any claim that any such suit, action or proceeding brought in such a
court has been brought in an inconvenient forum. Each party waives any right to trial by jury with
respect to any proceeding arising out of this Agreement. Notwithstanding the foregoing, any matter
relating to the SMBC Unit-Holders' rights or obligations as Limited Partners of Moelis Holdings
shall be subject to Sections 10.4 and 10.10 of the Moelis Holdings Agreement and not to this Section
15.8. 32
<!-- page 38 -->
15.9 Effect on Prior Agreement. Commencing as of the Effective Date, the rights and obligations of
the parties shall be determined pursuant to this Agreement and the Prior Agreement shall be of no
further effect; provided, that, any fees and expenses due to a party outstanding thereunder shall be
deemed to be outstanding under this Agreement. 15.10 Good Faith Discussion; Further Assurances.
Should there be any dispute or disagreement with respect to any matters not set forth in this
Agreement, the parties will discuss in good faith to resolve such dispute or disagreement. Each
party shall use its reasonable efforts to cooperate with the other party if necessary for compliance
with laws and regulations applicable to such other party in relation to the SMBC Unit- Holders'
holding of SMBC Units or transactions or matters contemplated under the Subscription Agreement, the
Side Letter, this Agreement and the Moelis Holdings Agreement. [signature page follows] 33

IN WITNESS WHEREOF, the parties have caused this Agreement to be executed and delivered on the date
first written above. SUMITOMO MITSUI BANKING CORPORATION

By:

Name: Takeshi Kunibe

Title: President

SMBC NIKKO SECURITIES INC.

By:

Name: Eiji Watanabe

Title: President & CEO

MOELIS & COMPANY HOLDINGS LP

By: Moelis & Company Holdings GP LLC

Its: General Partner

By:

Name: Kenneth D. Moelis

Title: Chief Executive Officer

MOELIS & COMPANY HOLDINGS GP LLC

By:

Name: Kenneth D. Moelis

Title: Chief Executive Officer
<!-- page 39 -->
[Signature Page to the Strategic Alliance Agreement]

Exhibit A Representations and Warranties of the Moelis Entities In addition to the representations
and warranties set forth in the Subscription Agreement, and except as specifically set forth in the
Disclosure Schedule delivered to SMBC/Nikko simultaneously with the execution hereof (the "Moelis
Disclosure Schedule"), Moelis Holdings and Moelis General Partner represent and warrant to
SMBC/Nikko that: (a) Organization and Authority. Each of the Moelis Entities has all requisite
corporate or other entity power and authority to own or lease all of its properties and assets and
to carry on its business as it is now being conducted and is duly licensed or qualified to do
business in each jurisdiction in which the nature of the business conducted by it or the character
or location of the properties and assets owned or leased by it makes such licensing or qualification
necessary, other than any failure to be so licensed or qualified that would not reasonably be
expected to have a material adverse effect on the Moelis Entities and their controlled affiliates,
taken as a whole. (b) Moelis Holdings Agreement. The Moelis Holdings Agreement has been duly
authorized, executed and delivered by Moelis General Partner and is a valid and legally binding
agreement of Moelis General Partner, enforceable against it in accordance with its terms, except (i)
as the enforceability thereof may be limited by bankruptcy, insolvency, reorganization or other
similar applicable laws affecting the enforcement of creditors' rights generally and (ii) that the
remedies of specific performance, injunction and other forms of equitable relief may not be
available because they are subject to certain tests of equity jurisdiction, equitable defenses and
the discretion of the court before which any proceeding therefor may be brought. The Moelis Holdings
Agreement attached as Tab 5 of the Subscription Agreement is a true, correct and complete copy of
the Moelis Holdings Agreement as currently in effect. (c) Affiliates. Each controlled affiliate of
Moelis Holdings is duly organized, validly existing and in good standing under the laws of the
jurisdiction of its incorporation or formation and has all requisite corporate or other entity power
and authority to own or lease all of its properties and assets and to carry on its business as it is
now being conducted and is duly licensed or qualified to do business in each jurisdiction in which
the nature of the business conducted by it or the character or location of the properties and assets
owned or leased by it makes such licensing or qualification necessary, other than any failure to be
in good standing or to be so licensed or qualified that would not reasonably be expected to have a
material adverse effect on the Moelis Entities and their controlled affiliates, taken as a whole.
All the issued and outstanding shares of capital stock or other partnership, equity or ownership
interests of such controlled affiliates have been duly authorized and validly
<!-- page 40 -->
issued, are fully paid and nonassessable with no personal liability attaching to the ownership
thereof (except as provided for in the governing documents of such controlled affiliate), have been
issued in compliance with all applicable securities laws, and were not issued in violation of any
preemptive rights or other right to subscribe for or purchase securities. Except as set
<!-- page 41 -->
forth in the Moelis Disclosure Schedule, Moelis Holdings owns, directly or indirectly, all of the
issued and outstanding equity interests of each of its controlled affiliates, free and clear of all
liens or encumbrances. (d) Capitalization. (1) The Moelis Disclosure Schedule sets forth a true and
complete list of the number, class and series of each issued and outstanding class and series of
Partnership Interests as of the date of this Agreement. (2) All of the issued and outstanding
Partnership Interests have been duly authorized and validly issued and are fully paid and
nonassessable, and have been issued in compliance with all applicable securities laws, and were not
issued in violation of any preemptive rights or other rights to subscribe for or purchase
securities. (3) Except with respect to employees of Moelis Holdings or its controlled affiliates and
except as set forth in the Moelis Holdings Agreement, none of Moelis Holdings or any of its
controlled affiliates has or is bound by any outstanding subscriptions, options, warrants, calls,
commitments or agreements of any character calling for the purchase or issuance of, or securities or
options, warrants or rights convertible or exercisable into or exchangeable for, any Partnership
Interests or other equity or synthetic ownership interests of Moelis Holdings or any controlled
affiliate, or any securities representing or contractual right granting the right (i) to purchase or
otherwise receive any equity interest in Moelis Holdings or any controlled affiliate (including any
rights plan or agreement) or (ii) to receive any periodic or other distribution on net income or net
loss or upon the liquidation and winding up of Moelis Holdings or any controlled affiliate. (4) (a)
Except as set forth in the Moelis Disclosure Schedule, as of the date of this Agreement, there are
no, written or oral, side letter, contract, memorandum of understanding and any other agreements
entered into between any of Moelis Entities on one hand and any Limited Partner of Moelis Holdings
on the other hand in respect to of the issuance or holding of any class or type of interest in
Moelis Holdings, regardless of whether such side letter, written contract, memorandum of
understanding and any other agreements are entered into by such Limited Partner in its capacity as
such, except for any vesting agreements, employment agreements, offer letters or similar agreements
entered into between the Moelis Entities and employees of Moelis Holdings or its controlled
affiliates; and (b) as of the date of this Agreement, no preferential voting or economic right
granted to any Limited Partner of Moelis Holdings pursuant to any Representation (d) Transaction
Agreements (as defined in the Moelis Disclosure Schedule) would reasonably be expected to
significantly and adversely affect any voting or economic right of the SMBC Unit-Holders under the
Moelis Holdings Agreement, the Subscription Agreement, the Side Letter or this Agreement (as
applicable), other than as a result of dilution in accordance with the Moelis Holdings Agreement
from the issuance of additional Management Units pursuant to such Representation (d) Transaction
Agreements. (5) The Moelis Disclosure Schedule sets forth a schedule of SMBC's pro forma ownership
of Moelis Holdings, as of the date of this Agreement, after giving effect to the transactions
contemplated by the Subscription Agreement and the methodology for calculating such pro forma
ownership as described in such schedule. (e) Partnership Interests. The issuance of Partnership
Interests to SMBC pursuant to the Subscription Agreement has been duly authorized by all necessary
action on the part of Moelis Holdings. When issued, delivered and sold against receipt of A-2
<!-- page 42 -->
the consideration therefor as provided in the Subscription Agreement, such Partnership Interests
will be validly issued, fully paid and nonassessable and without any personal liability attaching to
the ownership thereof (except as provided for in the Moelis Holdings Agreement), will not be issued
in violation of or subject to preemptive rights of any other unitholder of Moelis Holdings and will
not result in the violation or triggering of any price-based antidilution adjustments under any
agreement to which Moelis Holdings is a party. The issuance of Partnership Interests to SMBC
qualifies as an issuance of "Additional Units" to a "Strategic Investor" under Section 3.4.1 of the
Moelis Holdings Agreement for which existing Common Partners will not have the right of first
refusal as provided therein. (f) No Conflicts. Neither the execution and delivery by the Moelis
Entities of the Strategic Alliance Agreement or the Subscription Agreement, nor the consummation of
the transactions contemplated thereby, nor compliance by the Moelis Entities with any of the
provisions thereof, will violate any applicable law or regulation or violate, conflict with, or
result in a breach of any provision of, or constitute a default (or an event which, with notice or
lapse of time or both, would constitute a default) under, or result in the termination of, or result
in the loss of any benefit or creation of any right on the part of any third party under, or
accelerate the performance required by, or result in a right of termination or acceleration of, or
result in the creation of any lien or encumbrance upon any of the material properties or assets of
any of the Moelis Entities or any of their controlled affiliates under any of the terms, conditions
or provisions of (i) their respective organizational documents or (ii) any note, bond, mortgage,
indenture, deed of trust, license, lease, agreement or other instrument or obligation to which any
of the Moelis Entities or any of their controlled affiliates is a party or by which it may be bound,
or to which any of the Moelis Entities or any of their controlled affiliates or any of the
properties or assets of any of the Moelis Entities or any of their controlled affiliates may be
subject, except as would not reasonably be expected to have a material adverse effect on the Moelis
Entities and their controlled affiliates, taken as a whole. (g) Consents. No consents or approvals
of or prior filings or registrations with any governmental authority or with any third party are
necessary in connection with the execution and delivery by the Moelis Entities of the Strategic
Alliance Agreement, the Subscription Agreement or the Side Letter, or the consummation of the
transactions contemplated thereby. (h) Financial Statements. The Moelis Entities have previously
made available to SMBC/Nikko true and correct copies of (i) the consolidated balance sheets of
Moelis Holdings as of December 31 for the fiscal years 2007 through 2010, inclusive, and the related
consolidated statements of income, changes in total capital and of cash flows for the fiscal years
then ended, in each case accompanied by the audit report of Deloitte and Touche LLP, independent
public accountants with respect to Moelis Holdings and (ii) the September 30, 2011 unaudited
consolidated balance sheet of Moelis Holdings and the related unaudited consolidated statements of
income, changes in total capital and of cash flows for the nine-month period then ended (including
the related notes, where applicable) (each of the above, the "Financial Statements"). The Financial
Statements have been prepared from, are in accordance with and accurately reflect in all A-3
<!-- page 43 -->
material respects, the books and records of Moelis Holdings and its controlled affiliates, have been
prepared in all material respects in accordance with United States generally accepted accounting
principles applied on a consistent basis during the periods involved (except as may be stated in the
notes thereto), are true and complete and fairly present in all material respects the consolidated
financial position and the consolidated results of operations and cash flows (and changes in
financial position, if any) of Moelis Holdings and its controlled affiliates as of the times and for
the periods referred to therein (subject, in the case of unaudited statements, to normally recurring
year-end audit adjustments which are not material either individually or in the aggregate). (i)
Business Plan. All estimates and pro forma financial information contained in the business plan
included in the Moelis Disclosure Schedule, as of the date of the business plan were prepared in
good faith by the Moelis Entities. (j) Properties and Leases. Moelis Holdings and its controlled
affiliates have good and marketable title to all material properties and assets, real and personal,
tangible or intangible, owned by them, in each case free from liens or encumbrances that would
materially affect the value thereof or interfere with the use made or to be made thereof by them in
any material respect. Moelis Holdings and its controlled affiliates own or lease all material
properties as are necessary to their operations as now conducted. (k) Taxes. The Moelis Entities and
their controlled affiliates have filed, or joined in the filing of, all material tax returns
required to be filed by or with respect to them prior to the date of this Agreement, and to the best
knowledge of the Moelis Entities all such tax returns are true, accurate and complete in all
material respects and all material amounts of taxes shown to be due in such tax returns have been
paid, collected or withheld, as the case may be. With respect to any completed taxable period for
which such tax returns have not yet been filed, or for which taxes are not yet due or owing, the
Moelis Entities and their controlled affiliates have made due and sufficient current accruals for
any such taxes on their respective balance sheets in accordance with United States generally
accepted accounting principles. To the best knowledge of the Moelis Entities, there are no material
claims or assessments pending against the Moelis Entities or their controlled affiliates for any
alleged deficiency in any tax, and the Moelis Entities and their controlled affiliates have not been
notified of any material proposed tax claims or assessments against the Moelis Entities or their
controlled affiliates. (l) No Undisclosed Liabilities. As of the date of this Agreement, neither
Moelis Holdings nor any of its controlled affiliates has any liabilities or obligations of any
nature (absolute, accrued, contingent or otherwise) except for (i) liabilities or obligations
disclosed in the Financial Statements and current liabilities that have arisen since the date
thereof in the ordinary and usual course of business and consistent with past practice, (ii)
liabilities or obligations arising under contracts entered into by Moelis Holdings and/or its
controlled affiliates prior to the date hereof, or (iii) liabilities or obligations that would not
reasonably be expected to have a material adverse effect on Moelis Holdings and its controlled
affiliates, taken as a whole. A-4
<!-- page 44 -->
(m) Employment Agreements. Each managing director of Moelis Holdings or any of its controlled
affiliates, as applicable, has entered into either an offer letter, agreement or term sheet setting
forth the terms of such managing director's employment and vesting of Management Units granted to
such managing director in connection with his or her employment. The forms of vesting agreements for
the Management Units provided by Moelis Holdings to SMBC/Nikko, taken as a whole, are representative
of the vesting agreements entered into by Moelis Holdings or each controlled affiliate, as
applicable, with respect to the grant of Management Unit; except for differences that would not
reasonably be expected to have a material adverse effect on the Moelis Entities and their controlled
affiliates, taken as a whole, or the SMBC Unit- Holders' Partnership Interests. (n) Litigation. None
of the Moelis Entities or any of their controlled affiliates is a party to any, and there are no
pending or, to the Moelis Entities' knowledge, threatened, material legal, administrative, arbitral
or other proceedings, claims, actions or governmental or regulatory investigations (i) of any nature
against the Moelis Entities or any controlled affiliate except as would not reasonably be expected
to have a material adverse effect on the Moelis Entities and their controlled affiliates, taken as a
whole, or (ii) challenging the validity or propriety of the transactions contemplated by the
Subscription Agreement. There is no material injunction, order, judgment, decree or regulatory
restriction imposed upon the Moelis Entities, any controlled affiliate or any of their assets,
except for regulatory restrictions of general application. (o) Compliance with Laws. Each of the
Moelis Entities and each of their controlled affiliates have all permits, licenses, franchises,
authorizations, orders and approvals of, and have made all filings, applications and registrations
with, all governmental authorities that are required in order to permit them to own or lease their
properties and assets and to carry on their businesses as they are now being conducted other than
any failure that would not reasonably be expected to have a material adverse effect on the Moelis
Entities and their controlled affiliates, taken as a whole. Except as would not be reasonably
expected to have a material adverse effect on the Moelis Entities and their controlled affiliates,
taken as a whole, each of the Moelis Entities and their controlled affiliates has complied with, and
is not in default or violation of, and none of them is given notice of any violation or threat of
violation of, to the knowledge of the Moelis Entities, under investigation with respect to or, to
the knowledge of the Moelis Entities, has been threatened to be charged with, any applicable law,
statute, ordinance, license, rule, regulation, policy or guideline, order, demand, writ, injunction,
decree or judgment of any governmental authority. Except as would not be reasonably expected to have
a material adverse effect on the Moelis Entities and their controlled affiliates, taken as a whole,
and except for statutory or regulatory restrictions of general application, no governmental
authority has placed any restriction on the business or properties of the Moelis Entities or any of
their controlled affiliates. (p) Risk Management. The Moelis Entities and their controlled
affiliates have in place risk management policies and procedures, of the type and in the form that
the Moelis Entities and their controlled affiliates believe, in good faith, are sufficient in scope
and operation to protect against risks of the type and in the form A-5
<!-- page 45 -->
expected to be used by persons of similar size and in similar lines of business as such Moelis
Entity or controlled affiliate. (q) Insurance. The Moelis Entities and their controlled affiliates
maintain insurance underwritten by insurers of recognized financial responsibility, of the types and
in the amounts that the Moelis Entities and their controlled affiliates believe, in good faith, are
adequate for their respective businesses, all of which insurance is in full force and effect. (r)
Permanent Disability. To the knowledge of the Moelis Entities, (i) KM has not (A) suffered and is
not currently suffering any physical or mental incapacity or disability, total or partial, that
would constitute or would reasonably be expected to result in a Key Man Event (as such term is
defined in the Moelis Holdings Agreement) or (B) been absent from work for three or more consecutive
months at any time since the inception of the Moelis Entities and (ii) no other circumstance or
condition exists that would constitute or would reasonably be expected to result in a Key Man Event.
Since the inception of the Moelis Entities, no Key Man Event has occurred. (s) Affiliate Party
Transactions. Except as set forth in the Moelis Disclosure Schedule and except for agreements
related to employment, (i) any material transactions between any of the Moelis Entities, on the one
hand and the Management Partners of any of the Moelis Entities or any of their affiliates (other
than any of the Moelis Entities and any controlled affiliate), on the other hand are on terms and
conditions as favorable to each of the Moelis Entities as would have been obtainable by it in a
comparable arm's-length transaction with an unrelated third party. (t) No Guarantee of Performance.
None of the Moelis Entities or any of their controlled affiliates has guaranteed the future
performance or results of, or is liable in connection with, on behalf of, or for, any obligation of
(i) any pooled investment vehicle, open-end investment company, closed-end investment company, unit
investment trust or business development company or other private or public fund (except, general
partner liability to the extent imposed by applicable law) or (ii) any Person to which any of the
Moelis Entities or any of their controlled affiliates provides investment management or investment
advisory services, including any sub-advisory services, pursuant to an investment advisory contract.
(u) Effect of Agreement. None of this Agreement, the Subscription Agreement or any other agreement
entered into in connection therewith is subject to the disclosure rights under, or grant other
Limited Partners rights pursuant to, Section 10.19 of the Moelis Holdings Agreement. A-6
