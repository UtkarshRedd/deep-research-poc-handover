<!-- page 1 -->
# Intellectual Property Agreement
| Field | Value |
|---|---|
| Document Type | IP Agreement |
| Agreement Date | 2020-05-12 |
| Parties | Marv Enterprises, LLC ("Marv"); Premier Biomedical, Inc. ("Premier"); Technology Health, Inc. ("THI"); (Each shall be referred to as a “Party” and collectively as the “Parties.”) |
| Source | CUAD v1 / PREMIERBIOMEDICALINC_05_14_2020-EX-10.2-INTELLECTUAL PROPERTY AGREEMENT |

Exhibit 10.2 INTELLECTUAL PROPERTY AGREEMENT This Intellectual Property Agreement (this "Agreement")
is entered into on May 12, 2020 ("Effective Date"), concerning the pursuits set forth herein for the
collective development, implementation and commercialization of a potential treatment for the
COVID-19 virus and its effects on the human body (collectively referred to herein as the "Joint
Venture") by and between: Marv Enterprises, LLC, a Limited Liability Company organized under the
laws of the Commonwealth of Pennsylvania ("Marv"), Premier Biomedical, Inc. (OTC Pink: BIEI), a
Nevada corporation ("Premier"), Technology Health, Inc. (OTC Pink: HALB), a Colorado corporation
f/k/a Halberd Corporation ("THI"), Each shall be referred to as a "Party" and collectively as the
"Parties." RECITALS: WHEREAS, Marv is a single member LLC with Dr. Mitchell Felder as the sole
member. WHEREAS, Premier is publicly traded on the Pink Sheets, trading symbol BIEI. WHEREAS, THI is
publicly traded on the Pink Sheets, trading symbol HALB. WHEREAS, Marv is owner of U.S. Patent
9,216,386 and U.S. Patent 8,758,287 collectively referred to as the "Issued Patents". WHEREAS,
Premier has an Exclusive License to the Issued Patents via an Agreement executed by Marv and Premier
on May 12, 2010 ("2010 Agreement"). WHEREAS, Marv has subsequently filed numerous patent
applications on subject matter related to the Issued Patents which are listed in Appendix A.
WHEREAS, Marv and Premier expanded Premier's Exclusive License to include all the Applications
listed in Appendix A via a Third Addendum to the 2010 Agreement executed by Marv and Premier on the
Effective Date ("2020 Agreement"). WHEREAS, Marv has filed US provisional patent applications
specifically related to methods of treatment for Covid-19 as starred in Appendix A (Covid-19
Applications) to which Premier has an exclusive license via the 2020 Agreement. WHEREAS, this
Agreement contemplates the development of a methodology for the extracorporeal treatment of a
patient's body fluid to treat Covid-19 (Field of Covid-19 Treatment). WHEREAS, the Parties are
desirous of collaborating for the creation and distribution of products designed in the Field of
Covid-19 Treatment (Covid-19 Licensed Products) WHEREAS, THI is desirous of exclusively licensing
the Applications listed in Appendix A; WHEREAS, Premier is willing to assign its rights in the 2010
Agreement/2020 Agreement; WHEREAS, Marv in this Agreement gives its written consent for Premier to
assign its rights in the 2010 Agreement/2020 Agreement to THI; NOW, THEREFORE, for good and adequate
consideration, the receipt of which is hereby acknowledged, the Parties covenant, promise and agree
as follows: 1
<!-- page 2 -->
AGREEMENT 1. RECITALS. The Recitals are hereby incorporated herein by this reference, as if fully
restated herein. 2. LICENSING. To the extent that terms in the 2010 Agreement/2020 Agreement are not
contradicted or revised here, the terms as stated in 2010 Agreement/2020 Agreement remain in full
effect, are controlling, and apply to THI licensing of the Applications in Appendix A and the
Licensed Products derived therefrom. (a) License - THI is granted the following rights to the
Applications in Appendix A and the Licensed Products derived therefrom: Scope. The licenses granted
herein are exclusive worldwide licenses to: 1. make, have made, use, lease, sell and import Licensed
Products for the legal purposes of researching, developing, manufacturing, assembling, distributing,
and selling the Licensed Products; 2. make, have made, use and import machines, tools, materials and
other instrumentalities, insofar as such machines, tools, materials and other instrumentalities are
involved in or incidental to the research, development, manufacture, testing or repair of Licensed
Products which are or have been made, used, leased, owned, sold or imported by the Licensee; and 3.
convey to any customer of the Licensee, with respect to any Licensed Product which is sold or leased
to such customer, rights to use and resell such Licensed Product as sold or leased by Licensee
(whether or not as part of a larger combination); provided, however, that no rights may be conveyed
to customers with respect to any Invention which is directed to (i) a combination of such Licensed
Product (as sold or leased) with any other product, (ii) a method or process which is other than the
inherent use of such Licensed Product itself (as sold or leased), or (iii) a method or process
involving the use of a Licensed Product to manufacture (including associated testing) any other
product. 4. Licenses granted herein are solely for products in the form sold by the Licensee and are
not to be construed either (i) as consent by the Marv to any act which may be performed by the
Licensee, except to the extent impacted by a patent licensed herein to the Licensee, or (ii) to
include licenses to contributorily infringe or induce infringement under U.S. law or a foreign
equivalent thereof. 5. The grant of each license hereunder includes the right to grant sublicenses
to Related Companies for so long as it remains a Related Companies. Any such sublicense may be made
effective retroactively, but not prior to the effective date hereof, nor prior to the sublicensee's
becoming a Related Company. (b) Reports and Payments - For the above exclusive licensing rights, THI
will pay for various costs associated with this Agreement. The costs listed below are to be
hereinafter referred to as the "License Fee", to be paid by and through THI. The use of the License
Fee is further broken down below: 1. $20,000, payable to Marv Enterprises, LLC or as it directs,
which has already been paid into the account of Marv Enterprises, LLC at the Lynch Law Group 2. The
total sum of non-paid invoices (estimated to be approximately $80,000) payable to Marv Enterprises,
LLC, previously owed by Premier to Marv up until the effective date of this Agreement, payable in
total by no later than July 20, 2020. 3. Reports. a . Within thirty (30) days after the end of each
quarterly period ending on March 31st, June 30th, September 30th, or December 31st, commencing with
the one-year anniversary of the effective date of this Agreement, THI shall furnish to Marv a
statement certified by a responsible official of the Licensee showing in a manner acceptable to
Marv: i. all Licensed Products which were sold, leased or put into use during such quarterly period
by THI or any of its Related Companies, the gross sales received for the Licensed Products, and the
Fair Market Values of such Licensed Products; ii. all services performed by THI or any of its
Related Companies that directly or indirectly used Licensed Product, the gross sales received by the
services, and the Fair Market Value of such services; 2
<!-- page 3 -->
iii. the amount of royalty payable thereon, and iv. if no Licensed Product has been so sold, leased
or put into use or if no services have been performed, the statement shall show that fact. b. Within
such thirty (30) days, THI shall pay in United States dollars to Marv at PO Box 1332, Hermitage, PA
16148, or other address provided by Marv, the royalties payable in accordance with such statement.
Any conversion to United States dollars shall be at the prevailing rate for bank cable transfers as
quoted for the last day of such quarterly period by leading United States banks in New York City
dealing in the foreign exchange market. c. Overdue payments hereunder shall be subject to a late
payment charge calculated at an annual rate of three percent (3%) over the prime rate or successive
prime rates (as posted in New York City) during delinquency. If the amount of such charge exceeds
the maximum permitted by law, such charge shall be reduced to such maximum. (c) THI further agrees
to pay Intellectual Property Prosecution and Costs Applications in Appendix A directly to Marv. 1.
Costs. THI shall reimburse Marv for all IP Costs incurred on behalf of THI, as well as pre-paid IP
Costs incurred prior to the Effective Date of this Agreement, including the costs of provisional and
non-provisional applications that are filed to preserve Intellectual Property. Reimbursement for
pre-paid IP Costs shall be in accordance with 2 (b) 2 above. 2. Extension of Application. By written
notice to Marv and at least ninety (90) days before the non-extendable due date for the filing of a
national phase application of an Application, THI shall elect those countries or authorities in
which it desires to file a patent application based on the Application. Intellectual Property rights
in an unelected country shall revert to Marv. 3. Notice to Licensee. Before payment of any IP Cost,
Marv shall notify THI for a time period being the lesser of (i) at least sixty (60) days before the
IP Cost is due or (ii) as soon as is practicable after receiving knowledge of the IP Cost. The
notice will identify (i) the Application or Patent, (ii) the country, (iii) the reason for the IP
Cost, and (iv) the Due Date for payment. THI shall then affirm or deny payment. Affirmation of
payment must be received by Marv within fourteen (14) days of the mailing date of the notice or the
THI shall be deemed to have denied payment. a. If THI affirms a payment, THI shall reimburse Marv
for all IP Costs arising from the payment and shall then retain its license for the Application or
Patent in that country. b. If THI denies payment, THI shall have no obligation to pay IP Costs
associated with the Application or Patent in that country, but the license and all associated rights
for that Application or Patent shall revert to Marv. 4. Reimbursement by Licensee. THI shall prepay
Marv for any affirmed IP Cost before payment is to be made by Marv. Marv shall have no duty to pay
an IP Cost, whether affirmed or not affirmed, for which Marv does not receive prepayment. If THI
does not pay Marv by the Due Date, the Application or Patent shall revert to Marv as if THI had
denied payment under section 2(c)3. 5. Reversion of License. If a reversion occurs under this
Article, the license in that country in which reversion has occurred will be terminated, and THI
shall have no further right in the Application or Patent for that country. The right shall revert to
Marv who will then have the right to pursue protection for the reverted Application or Patent. Marv
has no further duty to THI for a reverted Application or Patent. 6. Applications. Defines as all
applications of the United States and foreign countries, including Patent Cooperation Treaty
applications that claim priority to the Applications listed in Appendix A, including any
non-provisional applications, continuations, continuations-in-part, divisions, reissues,
re-examinations or extensions thereof; and all applications including those applications filed in
the United States or applications filed under the Patent Cooperation Treaty on subject matter
directly related to the Applications in Appendix A whether or not priority to said applications was
claimed. (d) Royalty Payments. 1. Royalty payments are payable from THI to Marv Enterprises, LLC and
will be in the amount of 5% of the Fair Market Value of: a. Licensed Product that is sold, leased or
put into use by the THI or any Related Companies in the preceding calendar quarter; and b. any
service performed by THI or any Related Companies that directly or indirectly uses Licensed Product.
3
<!-- page 4 -->
2. This License does not include a minimum annual royalty payable by THI to Marv. 3. Fair Market
Value" means, with respect to any Licensed Product sold, leased or put into use, the Selling Price
actually obtained in an arm's length transaction for a product comprising a Licensed Product in the
form in which the product is sold, whether or not assembled and without excluding any components or
subassemblies thereof which are included in such Selling Price. "Selling price" shall exclude: usual
trade discounts actually allowed to unaffiliated persons or entities such as packing costs, costs of
transportation and transportation insurance, and import, export, excise, sales and value added
taxes, and custom duties. 4. In addition to the 5% amount calculated pursuant to the preceding
paragraph, there shall be an identical 5% amount to be paid from THI, per Premier's consideration,
to certain shareholders of Premier, as identified by Premier, as of a record date to be determined
in the future, on an annual basis, commencing on the one-year anniversary of this Agreement until a
total amount of $40,000,000 has been paid to Premier. This royalty is separate and distinct from the
royalty obligation to Marv as stated in 2(d)1. (e) If THI does not make the obligatory payments as
stated in 2(b) by the dates stated, the Exclusive License will revert back to Premier. 3. JOINT
VENTURE (a) Premier and THI will jointly cooperate in developing Covid-19 Licensed Products, to be
memorialized by them in a Technology Acquisition and Financing Agreement. For the joint venture the
following payments will be made by and through THI: 1. $750,000, payable to THI in total by no later
than June 20 , 2020. The payment will be for developing fluorescently-conjugated antibodies in the
Field of Covid-19 Treatments. 2. $1,150,000, payable to THI in total by no later than July 30, 2020.
The payment will be for development of laser technology in the Field of Covid-19 Treatments. 3.
$500,000 payable to a subsidiary of THI to be formed in the United Kingdom, for research and
development to be performed in the United Kingdom, by and at the direction of Mohammed Zulfiquar
and/or Datatechnics Inc. as invoiced by Mohammed Zulfiquar and/or Datatechnics Inc., for expenses
and at an hourly rate to Mohammed Zulfiquar and his designees. (b). Premier may partner with other
organizations as needed to effectuate the development of technology in the Field of Covid-19
Treatments. (c) Marv will have no direct role in the development of technology in the Field of
Covid-19 Treatment or in the Joint Venture. Marv, through its sole member Dr. Mitchell Felder, may
from time to time be consulted regarding the development of technology in the Field of Covid-19
Treatment. This consultation will be done solely at Marv's discretion. (d) Premier and THI may
execute separate agreements further outlining the conditions of the Joint Venture to effectuate the
development of technology in the Field of Covid-19 Treatment. (e) If THI does not make the
obligatory payments as stated in 3(a) by the dates stated, the Exclusive License will revert back to
Premier, provided, however, that in such event, THI would still be entitled to a proportionate
interest in any Covid-19 Licensed Products, such portion being equal to a fraction, the numerator of
which shall be the actual amount paid and the denominator of which shall be $2,000,000. 4. NO
BROKERAGE FEE. Each Party hereby represents and warrants that there has been no agreement which
might cause any other person to become entitled to a finder's fee, a broker's fee or a commission as
a result of the transactions contemplated hereunder. 5. REQUIREMENT. The Parties agree that Marv
and/or Mitchell S. Felder shall have no obligation and/or involvement in any capital raising
activities for THI or Premier at any time and for any reason. Further, the 150,000,000 (one hundred
and fifty million) stock warrants previously ceded to Mitchell S. Felder by Halberd/THI shall not be
eliminated, cancelled, or altered in any way, and for any reason, unless specifically directed at
the request of Mitchell S. Felder. 6. NONEXCLUSIVE ENGAGEMENT; EXTENT OF SERVICES. The Parties agree
that the relationship contemplated by this Agreement is a nonexclusive engagement/venture and that
each Party now renders and may continue to render consulting services and/or sell or provide
products to other companies that may or may not conduct activities similar to those of each other
Party. 4
<!-- page 5 -->
7. CONFIDENTIALITY. Each Party agrees to hold in confidence confidential information acquired in the
course of this relationship with the other Parties and their associates. Each Party agrees to
refrain from, either during period of this Agreement or at any other time thereafter, disclosing,
using or disseminating such confidential information, for its or another's benefit, in any way
acquired in the course of any association arising out of this Agreement. For purposes of this
Agreement, confidential information shall include contacts and introductions to third parties and
information relating thereto. Confidential information, knowledge or data of a Party and/or its
affiliates shall not include any information which is or becomes generally available to the public
other than as a result of a disclosure by such Party or its representatives. Confidential
information should further include: all information (in whatever form and whether or not marked or
otherwise identified as confidential), including financial statements, business plans or records,
concepts, marketing studies, projections, sales or pricing information, customer or supplier
information, agreements with third parties, Intellectual Property (as defined below) or other data
provided by or on behalf of the Disclosing Party to the Recipient and (ii) all notes, analyses,
compilations, studies, interpretations or other material prepared by the Recipient or its
Representatives which contain or reflect or are based upon, in whole or in part, information
furnished by the Disclosing Party pursuant to this Agreement. "Confidential Information" does not
include information which (a) is obtained by the Recipient from a third party who is not known to
Recipient to be prohibited from transmitting such information to the Recipient, or (b) was already
in the Recipient's possession prior to its entry into this Agreement and which is not subject to any
restrictions which would prohibit its disclosure to the Recipient in connection with the parties'
evaluation of the Transaction or (c) is or becomes generally available to the public other than as a
result of a breach of any confidentiality restrictions to the Recipient. "Intellectual Property"
shall mean any Confidential Information proprietary to the Disclosing Party and any trademark,
service mark, trade name, invention, improvement, discovery, patent, patent application, trade
secret, copyright, copyrightable work, trade dress, mask work, computer program or any other type of
proprietary intellectual property to which the Disclosing party claims any rights, including any
registrations or applications for registration or renewals of any of the foregoing, and all copies
and tangible embodiments of the foregoing in whatever form or medium. Confidential information shall
also mean any information not generally made available or known to the public and shall include,
without limitation, all ideas, inventions, software, documentation, flowcharts, diagrams,
improvements, discoveries, research and development, know how, formulas, compositions, manufacturing
and production processes and techniques, technical data, designs, drawings, plans, specifications,
and all other information or material within the definition of a "trade secret" as set forth in the
Uniform Trade Secret Act, or which either party otherwise reasonably considers proprietary. Copies;
Return of Confidential Information. The parties may copy or otherwise reproduce any written
Confidential Information; provided, however, that all such Confidential Information and copies
thereof shall be promptly returned to the Disclosing Party or, at the option of the Disclosing
Party, destroyed, upon the Disclosing Party's request, such destruction to be certified in writing.
8. VENUE. This Agreement and the rights of the Parties hereunder shall be governed by and construed
in accordance with the laws of the Commonwealth of Pennsylvania including all matters of
construction, validity, performance, and enforcement and without giving effect to the principles of
conflict of laws. Venue for any action brought under this Agreement shall be in the appropriate
court in Mercer County, Pennsylvania. 9. MATERIALITY. The Parties agree and stipulate that each and
every term and condition contained in this Agreement is material, and that each and every term and
condition may be reasonably accomplished within the time limitations, and in the manner set forth in
this Agreement. The Parties agree and stipulate that time is of the essence with respect to
compliance with each and every item set forth in this Agreement. 10. AMENDMENTS/BINDING. This
Agreement may not be amended or modified except by written agreement subscribed by all of the
Parties to be charged with such modification. This Agreement shall be binding upon and shall inure
to the benefit of the Parties hereto and their respective partners, employees, agents, servants,
heirs, administrators, executors, successors, representatives and assigns. 11. ENTIRE AGREEMENT.
This Agreement, along with the exhibits hereto, sets forth the entire agreement and understanding of
the Parties hereto and supersedes any and all prior arrangements and understandings related to the
subject matter hereof except for as specifically stated in this Agreement with regards to the 2010
Agreement and the 2020 Agreement and licensing rights. No understanding, promise, inducement,
statement of intention, representation, warranty, covenant or condition, written or oral, express or
implied, whether by statute or otherwise, has been made by any Party hereto which is not embodied in
this Agreement or the written statements, certificates, or other documents delivered pursuant hereto
or in connection with the transactions contemplated hereby, and no Party hereto shall be bound by or
liable for any alleged understanding, promise, inducement, statement, representation, warranty,
covenant or condition not so set forth. 12. COUNTERPARTS. This Agreement may be executed in one or
more counterparts, each of which when executed and delivered shall be an original, and all of which
when executed shall constitute one and the same instrument. 13. EXPENSES ASSOCIATED WITH THIS
AGREEMENT. Marv shall be reimbursed in full for the cost(s) of all legal expenses associated with
this agreement by THI. [remainder of page intentionally left blank; signature page to follow]

5
<!-- page 6 -->
IN WITNESS WHEREOF, the Parties hereto, agreeing to be bound hereby, execute this Agreement upon the
date first set forth above. Premier Biomedical, Inc.: /s/ William Hartman Date__________ By: William
Hartman, CEO Technology Health, Inc.: /s/ James Christopher LeDoux Date___________ By: CEO Marv
Enterprises, LLC: /s/ Mitchell Felder Date__________ By: Mitchell Felder

6
