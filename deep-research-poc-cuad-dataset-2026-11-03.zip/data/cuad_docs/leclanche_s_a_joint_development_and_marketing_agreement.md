<!-- page 1 -->
# JOINT DEVELOPMENT AND MARKETING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Marketing Agreement |
| Agreement Date | 2014-04-06 |
| Parties | LECLANCHÉ S.A. ("Leclanché"); OAK RIDGE ENERGY TECHNOLOGIES INC ("Oak Ridge"); (each a "Party"” and together "Parties") |
| Source | CUAD v1 / LECLANCHÉ S.A. - JOINT DEVELOPMENT AND MARKETING AGREEMENT |

JOINT DEVELOPMENT AND MARKETING AGREEMENT

BETWEEN

LECLANCHÉ SA

AND

OAK RIDGE ENERGY TECHNOLOGIES, INC.

1

1. 1.1.

1.2.

1.3.
<!-- page 2 -->
This AGREEMENT is made on April 6, 2014, ("Effective Date" between:

LECLANCHÉ S.A., being a company organized and existing under the laws of Switzerland, having its
registered office at Avenue des Sports 42, 1400 Yverdon-les-Bains, Switzerland ("Leclanché"), and

OAK RIDGE ENERGY TECHNOLOGIES INC, being a company organized and existing under the laws of United
States of America, having its registered office at 751 North Drive, Suite 9, Melbourne, FL 32934,
United States ("Oak Ridge"),

each a "Party"" and together "Parties".

WHEREAS Oak Ridge focuses on the licensing, further development, manufacturing and marketing of
products incorporating thin film battery technologies.

WHEREAS Leclanché has developed and markets lithium-ion titanate cells using a proprietary
technology and process and also designs and develops customized battery systems for OEM and other
customers;

WHEREAS Leclanché is interested in marketing its products and services in the United States;

WHEREAS Oak Ridge is keen to develop its business and has the capability to market and support
Leclanché market entry into the United States and is committed to allocate specific resources to
provide such services;

WHEREAS both Parties wish to collaborate together to better evaluate the opportunities in the United
States, assess how best to address these and generally support each other's business efforts in
furtherance of supporting their respective customers based in North America;

NOW THEREFORE it is agreed as follows:

Definitions The term "Affiliate" as used herein with respect to a party means any partnership, joint
venture, corporation of other form of enterprise that directly or indirectly controls, is controlled
by or is under common control with such entity or person. For purposes hereof, "control" means the
possession, directly or indirectly, of the power to direct or cause the direction of the management
and policies of a person or entity, whether through the ownership of voting securities, by contract
or otherwise.

The term "Subsidiary" as used herein with respect to a party means any partnership, joint venture,
corporation of other form of enterprise that is directly or indirectly controlled by such entity or
person. For purposes hereof, "control" means the possession, directly or indirectly, of the power to
direct or cause the direction of the management and policies of a person or entity, whether through
the ownership of voting securities, by contract or otherwise.

2

"Confidential Information" means all information in relation to this Agreement in

1.3.

a)

b)

2. 2.1.

a)

b)

c)

d) e) f)

g)
<!-- page 3 -->
"Confidential Information" means all information in relation to this Agreement in whatever form that
is disclosed by the Parties to each other and shall include without limitation information disclosed
orally or in writing or in any other form, tangible or intangible, and whether furnished prior to,
on or after the date of this Agreement, that is described as or provided under circumstances that
would reasonably indicate that it is confidential, proprietary or a trade secret, including, but not
limited to, information relating to Leclanché's technology, intellectual property, financial or
business plans, affairs, methodologies, financial statements or projections, internal management
tools and systems, products and product development plans, released or unreleased hardware or
software products, sales and marketing plans and materials, clients, contacts and contracts, all
files, books, records, documents, specifications, schematics, employee suggestions, papers,
drawings, models, sketches of any kind or description, including electronic data recorded or
retrieved by any means now in existence or at any time hereinafter developed. Confidential
Information shall also include documents transferred to Oak Ridge that are prepared by or on behalf
of Leclanché incorporating Confidential Information received from a third party, which is itself
required to be treated as confidential. Confidential Information shall not include information or
data which was or becomes:

generally available to the public, other than as a result of a breach of this undertaking;

available to the recipient Party on a non confidential basis from a source other than the disclosing
Party or its advisers, provided that such source is not, insofar as the recipient Party is aware,
bound by any obligations of confidentiality in respect of such information or data;

Market Evaluation - Phase 1 The Parties shall work together to better evaluate the market
opportunities in the United States. A joint team shall be constituted, chaired by Anil Srivastava, a
Board member of Oak Ridge, to undertake this study which shall be completed by May 31, 2014. The
objectives of the study will be to:

build a picture of the key market participants, in particular key customer groups, solution
integrators, BMS providers, EPC contractors etc., identify what alliances could /should be formed to
enhance the joint offering; identify target business applications where the Leclanché technology
could be deployed; gather market information on pricing points and value add opportunities; build
economic business cases for key business applications; identify what certification processes need to
be undertaken before products and services can be marketed in the United States, what the timelines
are and what the estimated costs might be;

3

segregate opportunities by product groups (cells, home systems, industrial

g)

h)

i)

j)

2.2.

2.3.

3. 3.1.

4. 4.1.

4.2.

5. 5.1.

5.2.

5.3.

5.4.

5.5.

5.6.
<!-- page 4 -->
segregate opportunities by product groups (cells, home systems, industrial systems, project related
applications, e.g. frequency regulation); the structure that would be required to address the market
in an effective manner; what element of the product assembly could be undertaken by Oak Ridge at its
facility in Melbourne; how the trading relationship between the Parties should be structured i.e.
whether Oak Ridge will be an agent or reseller and how this will be remunerated.

The output from Phase 1 shall be a market entry plan, that shall be presented to the management of
both Parties. The Parties shall decide on further steps based on the marked entry plan.

Regular update calls will be organized by Oak Ridge and meetings shall be held in Melbourne,
Florida.

Costs The costs of Mr Srivastava shall be borne by Oak Ridge. Otherwise each Party bears its own
costs for Phase 1

Leclanché's Products and Services The Products offered by Leclanché are set out in Annex I. Pricing
will be determined after Phase 1 is completed.

The Services offered by Leclanché include the customized design and development of battery systems
to meet specific customer requirements. These Services are typically provided by Leclanché's
Portable Business Unit. Examples of such Services are set out in Annex II. Oak Ridge
Responsibilities Oak Ridge shall be responsible for developing the sales and marketing for the
Products and Services;

Oak Ridge shall dedicate sales and marketing personnel to develop the market;

Oak Ridge shall identify commercial opportunities and work with Leclanché to qualify these
opportunities and prepare bids and quotations as necessary;

Oak Ridge shall participate at fairs and events and generally undertake all promotional activities
that are required in order to promote the product; Oak Ridge shall maintain a regular watch on
market developments and shall share this with Leclanché on a regular basis;

Oak Ridge shall maintain a first level technical support capability to

4

5.7.

6. 6.1.

6.2.

6.3.

6.4.

6.5.

6.6.

7. 7.1.

7.2.

7.3.

8. 8.1.

8.2.

9. 9.1.
<!-- page 5 -->
address customer requirements and deal with any field issues expeditiously;

Oak Ridge shall arrange product liability and warranty insurance.

Leclanché Responsibilities Leclanché shall supply the Products and Services;

Leclanché shall provide training and documentation;

Leclanché shall work with Oak Ridge to examine what elements of the Products and Services can be
supplied locally by Oak Ridge (e.g. assembly of pre- designed modules);

Leclanché shall generally support the commercial efforts of Oak Ridge in furtherance of the
promotion and sales of the Products and Services;

Leclanché shall define the warranty conditions for the Products and Services and work with Oak Ridge
to provide the information necessary to secure product liability and warranty insurance cover.

Leclanché shall assist Oak Ridge in preparing and submitting commercial bids.

Exclusivity Where Oak Ridge has identified a specific market opportunity which has been qualified
together with Leclanché pursuant to 5.3 above, the Parties shall undertake to work exclusively with
each other on such opportunities;

Otherwise there is no exclusivity expressed or implied by either Party.

The Parties shall nonetheless share information as is reasonably necessary to ensure that there is
no confusion in the market how customer requirements are addressed. If conflicts were to arise, the
Parties shall use their reasonable efforts to resolve any such conflicts in a manner that benefits
the end customer.

Pricing Pricing for standard Products shall be defined after Phase 1 has been completed. Pricing for
more complex projects shall be determined on a case by case basis.

Pricing for Services shall be quoted on a case by case basis depending on the customer
specification.

Payment Terms In certain cases, Leclanché may request progress payments, including some element paid
at the time of order. In the absence of a specific payment schedule, all payment terms are 30 days
net from date of invoice.

5

10. 10.1.

11. 11.1.

12. 12.1.

13. 13.1.

14. 14.1.
<!-- page 6 -->
Intellectual Property Each party's intellectual property ("IP") in existence as of the Effective
Date shall remain such Party's property. Where appropriate and to the extent required, each party
undertakes to grant a royalty free license to the other Party solely for the design and development
of product(s) under this Agreement. There is no intended or implied transfer of either Party's
Intellectual Property to the other.

Confidentiality The Parties shall keep strictly secret and confidential any and all confidential
information relating to each other's business and/or to the contents of this Agreement and shall
not, in any manner whatsoever, disclose or permit any of its agents, representatives, employees,
attorneys, accountants or advisors to disclose any confidential information to any person or entity
whatsoever without the prior written consent of the other Party. The Parties shall take all
necessary steps to safeguard the secrecy and confidentiality of all confidential information and all
materials and to ensure that such confidential information and material obtained in connection with
this Agreement is disclosed only to authorized persons who need to know such information for the
purpose of performing their duties on behalf of the company.

Non Solicitation The Parties are independent companies, and neither of them or anyone employed by
them shall be deemed to be the employee, agent or legal agent of the other. Both Parties agree that
during the Term of this Agreement and for a period of two (2) years following the termination, both
Parties will not (i) solicit, encourage, or take any other action, which is intended, directly or
indirectly, to induce any employee to terminate his or her employment with a Party; or (ii)
interfere in any manner with the contractual or employment relationship between the Parties and any
their employees.

Assignment Neither Party may assign, delegate, or transfer this Agreement or any of its rights or
duties hereunder, without the prior written consent of the other Party. Any attempted assignment or
delegation in violation of this section shall be void. The provisions of this Agreement shall be
binding upon and inure to the benefit of the Parties, their successors and permitted assigns.

Force Majeure It is agreed that neither Party shall be liable for any delay or failure to perform
its obligations hereunder in whole or in part when such delay or non- performance results from
causes beyond such Party's control, including, but not limited to, fires, strikes, insurrections,
riots, embargoes, shortages of motor vehicles, delays in transportation, inability to obtain

6

14.2.

15. 15.1.

16. 16.1.

17. 17.1.

18. 18.1.

19. 19.1.
<!-- page 7 -->
supplies of raw materials, or governmental requirements or regulations ("Force Majeure Event").

In the event of the occurrence of a Force Majeure Event, the Party unable to perform will, i)
promptly notify the other Party, ii) provide an estimate of the duration of the delay, iii) use its
bests efforts to resume performance as quickly as possible, and iv) suspend performance only for the
period of time as is necessary as a result of the Force Majeure event. Notwithstanding the above,
neither Party is relieved of any liability for any delay or failure to perform its defense
obligations with respect to third Party intellectual property rights. The Party not delayed may act,
in its sole discretion, to terminate the affected order, or any part of the order, or suspend this
Agreement in whole or in part, for the duration of the delaying cause.

Amendment No change, amendment or modification of any provision of this Agreement shall be valid
unless set forth in a written instrument signed by the Parties.

Construction In the event that any provision of this Agreement conflicts with the law under which
this Agreement is to be construed, or if any such provision is held invalid by a court with
jurisdiction over a Party to this Agreement, such provision shall be deemed to be restated to
reflect as nearly as possible the original intentions of the Parties in accordance with applicable
law, and the remainder of this Agreement shall remain in full force and effect.

Severability If any of the provisions or clauses of this Agreement shall be or become void or be
held invalid, all other provisions shall remain in full force and effect and the void or invalid
provisions shall be forthwith replaced by other provisions to be agreed by the parties valid in form
and substance and which shall accomplish as nearly as possible the purpose and intent of the void or
invalid provisions in due course.

Announcements No announcements of this Agreement or any subsequent Agreement may be made by one
Party without the consent of the other, save if required to do so for legal or regulatory reasons,
in which case the Party initiating the announcement shall use reasonable efforts to obtain the
comments (if any) of the other, but for avoidance of doubt nothing in this provisions shall inhibit
the disclosing party from complying with its legal or regulatory obligations as it sees fit. In the
event that one party is required to make an announcement without the knowledge of the other, it
shall promptly send a copy of the announcement to the other party for information purposes.

No Waiver No waiver by either Party of any right or of a breach of any binding

7

20. 20.1.

21. 21.1.
<!-- page 8 -->
a)

b)

provision of this Agreement shall constitute a waiver of any other right or breach of any other
provision, nor shall it be deemed to be a general waiver of such provision by such Party or to
sanction any subsequent breach thereof by any other Party

Notice Any notice, approval, request, authorization, direction, or other communication under this
Agreement shall be given in writing, directed to the addresses of the Parties set forth above, and
shall be deemed to have been delivered and given for all purposes: (a) on the delivery date if
delivered personally to the Party to whom the same is directed; (b) one (1) business day after
deposit with a commercial overnight carrier with written verification of receipt; or (c) five (5)
business days after the mailing date whether or not actually received, if sent by registered or
recorded delivery post or any other means of rapid mail delivery for which a receipt is available to
the Contact at the address of the Party to whom the same is directed.

Notices shall be addressed as follows:

Attn: Chief Executive Leclanché SA Avenue des Sports, 42 Yverdon-les-Bains, CH 1400 Switzerland

Attn: Chief Executive Oak Ridge Energy Technologies Inc., 751 North Drive, Suite 9, Melbourne, FL
32934, United States

Standstill The Parties acknowledge that both companies are publicly quoted companies and may before
and/or during the course of this Agreement be in receipt of nonpublic information (including any
Confidential Information) (together, "Non Public Information") and agree to comply with all relevant
laws and regulations applicable to market trading during the term of this Agreement and for a period
of 12 months thereafter, and in particular agrees not to:

directly nor indirectly engage in any transactions on any exchange, regulated market or
over-the-counter in (i) any securities issued by the Leclanché or any affiliated company or (ii) any
derivative products the price of which is derived in whole or in substantial part from any such
securities;

divulge directly or indirectly any Non Public Information to any third party without the written
consent of Leclanché and if it is

8

22. 22.1.

a) b)

c)

22.2.

22.3.

22.4.

22.5.

23. 23.1.

23.2.
<!-- page 9 -->
authorized to make such disclosure, shall impose standstill obligations on that third party
consistent with this provision.

Term and Termination Subject to Article 22.2, this Agreement shall remain in force for an Initial
Period of 1 year, which may be renewed by mutual consent for such period as the Parties may agree
("Term"), unless it is terminated earlier in accordance with this Agreement or for any of the
following reasons:

if one Party is in default with its performance under this Agreement; in case of insolvency or
bankruptcy of either Party, or in case of a change of control of one of the Parties; breach of any
of the provisions of this Agreement by either Party that remains unremedied for a period of 30 days;

In the event that after Phase 1, the Parties conclude that it would not be economically viable to
enter the US market as envisaged, this Agreement shall terminate forthwith and the Parties shall use
reasonable efforts to assess whether to proceed with an alternative agreement or not.

If the Agreement is terminated, the Parties shall endeavour to ensure that assets contributed by
each Party shall, so far as possible, be transferred back to that Party.

In the event of termination of this Agreement, neither Party shall have any obligation to continue
the activities set forth herein, and all obligations and rights of the Parties shall terminate, with
the exception of provision of Articles 9-21, and Article 23 of this Agreement, which shall survive
expiration or termination.

Notwithstanding the above, termination of the Agreement will not have any effect on the rights and
obligations of the Parties in respect of the assignment secured and or any RFQ at any stage of
processing.

Governing Law and Jurisdiction This Agreement shall be governed by and construed in accordance with
Swiss law. The conflict of law rules and the United Nations Convention on Contracts for the
International Sale of Goods do not apply.

The Parties irrevocably agree that the courts of the city of Zurich have exclusive jurisdiction to
settle any dispute or claim that arises out of or in connection with this Agreement.

9
<!-- page 10 -->
IN WITNESS WHEREOF the parties hereto have executed this Agreement as of the dates written below.

For Oak Ridge Energy Technologies Inc For Leclanché SA

______________________________ Mr Craig Nelson Deputy CEO

/s/ Eric Wilkinson Mr Eric Wilkinson Deputy CEO

10

Annex I
<!-- page 11 -->
LECLANCHÉ PRODUCTS

11

12
<!-- page 12 -->
- - -
<!-- page 13 -->
Annex II LECLANCHÉ SERVICES

Leclanché's Portable Business designs customized battery systems for original equipment
manufacturers and other industrial / commercial customers. It focuses on three main markets:

military medical equipment ruggerdized industrial equipment

Examples of products that have ben developed for its customers include:

13
