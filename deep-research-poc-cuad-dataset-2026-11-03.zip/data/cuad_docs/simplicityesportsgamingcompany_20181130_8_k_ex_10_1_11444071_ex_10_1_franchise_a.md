<!-- page 1 -->
# MASTER FRANCHISE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Franchise Agreement |
| Agreement Date | 2018-11-20 |
| Parties | Smaaash Entertainment Private Limited ("Franchisor"); I-AM Capital Acquisition Company ("Franchise") |
| Source | CUAD v1 / SimplicityEsportsGamingCompany_20181130_8-K_EX-10.1_11444071_EX-10.1_Franchise Agreement |

Exhibit 10.1 MASTER FRANCHISE AGREEMENT This Master Franchise Agreement ("Agreement") is made and
entered into on the 20t h day of November, 2018 (the "Effective Date") at Mumbai, by and between
Smaaash Entertainment Private Limited, an Indian company, with its address at Trade View, Level 2,
Kamala Mills, Lower Parel, Mumbai 400013, India ("Franchisor") and I-AM Capital Acquisition Company,
a company incorporated in the United States of America, with an address at 1345 Avenue of the
Americas, 11th floor, New York, 10105 ("Franchisee"). RECITALS A. WHEREAS, Franchisor operates
entertainment centers and gaming arcades throughout India as well as at the Mall of the Americas in
Minneapolis Minnesota where Franchisor, through its virtual reality and sports simulation technology
and proprietary gamification technologies provides sport and recreational activities/services; and
B. WHEREAS, Franchisee is [•] (add the business of the Franchisee); and C. WHEREAS, Franchisor
desires to appoint Franchisee, and Franchisee desires to be so appointed, to act as Franchisor's
exclusive Franchisee in the territories of North America and South America ("Territory") in the
manner set out in this Agreement, for setting up, managing and operating entertainment centres and
gaming arcades involving virtual reality, sports simulation technology and proprietary gamification
technologies to provide sport and recreational activities/services to the public ("Smaaash
Centres"), upon the terms and subject to the conditions hereinafter provided. NOW, THEREFORE, the
parties agree as follows: 1. Grant of Franchise 1.1 Rights granted to the Franchisee. Subject to
Section 1.2, Franchisor hereby grants to Franchisee the exclusive right, (a) to establish and
operate Smaaash Centres in the Territory, (b) to sub-license the right to establish and operate
Smaaash Centres to third party franchisees in and for the Territory, (c) a license to use the
products and other services developed by Franchisor with respect to the Smaaash Centres (including a
right to authorise the use of products and services developed by the Franchisor by third party
franchisees), in the Territory, and (d) to identify third party franchisees for the Smaaash Centres
in the Territory. The rights granted herein include the limited license to use the Trademarks of the
Franchisor (the details of which are morefully set out in Exhibit A), as set out in Section 3 of
this Agreement, for the purposes of establishing and operating the Smaaash Centres in the Territory.
It is clarified that if third party franchisees shall be establishing and operating Smaaash Centres
in the manner contemplated under this Agreement, then the Franchisee shall ensure that such third
party franchisees complies with all the obligations and duties of the Franchisee, as recorded under
this Agreement, and to this extent, Franchisee may enter into relevant agreements with such third
party franchisees. 1.2 Notwithstanding the right granted to the Franchisee in Section 1.1, the
Franchisor and its affiliates shall retain the right on the terms and conditions that the Franchisor
may deem fit and without granting any rights therein to the Franchisee, (i) to own, acquire,
establish and / or operate, and to a grant a license to third parties to establish and operate
Smaaash Centres at any location outside the Territory, and (ii) to own, acquire, establish and / or
operate, and to grant a license to third parties to establish and operate, gaming and entertainment
centres under other proprietary marks or other systems, whether such centres are the same, similar
or different from the Smaaash Centres, at any location within or outside the Territory. 1.3 This
arrangement has been entered into by the parties on an arms'length basis. All commercials between
the parties in relation to the transactions contemplated under this Agreement, if not specifically
provided in this Agreement, shall be agreed mutually between the parties. 1.4 Additional
Considerations (a) Pricing. Franchisor and Franchisee shall agree upon and decide the locations at
which the Smaaash Centres shall be set up within the Territory. The Franchisee shall not be entitled
to set up any new Smaaash Centres without consulting with, and obtaining the prior written consent
of Smaaash. (b) The prices of the products and services offered in each of the Smaaash Centres shall
be decided mutually among the parties. Any revision to the agreed fees, including any discounts or
prizes or other promotional measures shall require the prior written consent from Franchisor.

Source: SIMPLICITY ESPORTS & GAMING CO, 8-K, 11/30/2018
<!-- page 2 -->
(c) Franchisee or the third party franchisee, as the case may be, shall be entitled to receive the
revenue generated from each of the Smaaash Centres. If third party franchisees are operating the
Smaaash Centres, then the Franchisee shall be entitled to receive, (i) 5% (five percent) of the
capital expenditure as agreed among the parties for the particular Smaaash Centre as sign -on fees
or upfront advance, and (ii) 5% (five percent) fee or commission of the revenue generated by such
third party franchisees from the Smaash Centres on an annual basis. 1.5 Operation of Smaaash
Centres. Franchisee or third party sub -franchisees shall be under an obligation to set up at least
6 (six) Smaaash Centres during the first Contract Year or any other time period as may be provided
by Franchisor. The Smaaash Centres shall be established and operated in the Territory using the
assumed trade name 'Smaaash'or any other trade name that the Franchisor may designate. Franchisee
shall maintain good customer relations in accordance with prudent and reasonable business practices.
Franchisee shall perform its obligations hereunder without using subcontractors, sub-distributors,
independent sales representatives, agents, Franchisee's affiliates or other non-employees ("Third
Parties") to perform the obligations of Franchisee under this Agreement except to the contrary
specifically stated in this Agreement or unless they have been approved, in writing, in advance, by
Franchisor, such approval not to be unreasonably withheld. 2. Term The term of this Agreement shall
commence as of the Effective Date and shall continue until terminated as hereinafter provided (the
"Term"). Each calendar year during the Term is sometimes hereinafter referred to as a "Contract
Year." 3. Grant of License in the Trademarks 3.1 License. Subject to the terms of this Agreement
(including all obligations to first obtain Franchisor's written approval), Franchisor hereby grants
to Franchisee the right to use the Trademarks (the details of which are set out in Exhibit A to this
Agreement) (including sub-licensing this right to third party franchisees with the approval of
Franchisor), on a royalty-free basis, for the purpose of operating and promoting the Smaaash Centres
in the Territory. Franchisee is, in particular entitled to: (a) offer, market and/or distribute any
products and services in connection with the Smaaash Centres under the Trademarks; and

Source: SIMPLICITY ESPORTS & GAMING CO, 8-K, 11/30/2018
<!-- page 3 -->
b) use the Trademarks on business stationery and/or in advertising in connection with the
advertising, promotion and distribution of Smaaash Centres in the Territory. 3.2 Exclusivity of
License. Except as provided in the next sentence, the license granted herein shall be exclusive.
"Exclusivity" shall mean that Franchisor shall not grant any further licenses to third parties in
the Trademarks for use in connection with Smaaash Centres in the Territory, and the Franchisee shall
not enter into any arrangement or agreement with any third parties for establishing or operating any
gaming and entertainment centres identical or similar to Smaaash Centres, in the Territory except as
otherwise provided in this Agreement; provided, however, that Franchisor may continue to use the
Trademarks in the Territory in connection with the operation of Franchisor's entertainment centers
already set up as of the Effective Date in the Territory. The restriction contained in this
Agreement shall apply on the parties throughout the Term. 3.3 Form of Use. Unless otherwise provided
herein or agreed by the parties in writing, Franchisee shall use the Trademarks that are registered
in the Territory in their registered form. 4. Compliance with Law Franchisee shall ensure that the
Smaaash Centres shall be set up, established, operated, managed, advertised, marketed, promoted,
publicized and otherwise exploited, in accordance with all applicable laws and regulations in the
Territory, including without limitation, all customs requirements and country of origin regulations.
5. Marketing and Promotional Activities 5.1 Best Efforts. (a) Franchisee shall exercise its best
efforts to effectively market, promote, and publicise the Smaaash Centres throughout the Territory.
Franchisee shall also be obligated to identify suitable locations to set up the Smaaash Centres.
Franchisee shall comply with, and ensure that the third party sub-franchisees comply with the
standards prescribed by Franchisor (as provided in the operating manuals which shall be shared by
Franchisor with Franchisee) with respect to the services, products and operations of the Smaaash
Centres and shall operate the Smaaash Centres in strict conformity with such standards and
specifications as Franchisor may from time to time prescribe to Franchisee. Franchisee shall refrain
from deviating from such standards and specifications without Franchisor's prior written consent and
from otherwise operating in any manner which reflects adversely on the Trademarks and Smaaash
Centres. (b) Unless otherwise agreed by Franchisor in writing, throughout the Term, Franchisee shall
maintain, and shall ensure that the third party sub -franchisees maintain an organizational
structure or local management reasonably necessary to adequately support the advertising, marketing
and promotion of the Smaaash Centres and the services and products offered by Smaaash Centres
throughout the Territory. The third party sub -franchisees shall also be responsible for all
employee related compliances as per the relevant applicable laws. Towards this purpose, Franchisee
shall appoint a qualified chief operating officer, in consultation with Franchisor, to undertake and
manage the obligations of Franchisee as set out in this Agreement. Franchisor shall also be entitled
to designate and appoint personnel from its managerial team to assist and train the personnel and
staff of the Franchisee or any other third party sub - franchisee in setting up the Smaaash Centres,
and further provide technical and design knowledge to the third party sub - franchisees. 5.2
Promotional Material and Products. Franchisee shall submit to Franchisor, for Franchisor's prior
written approval, samples of all advertising and promotional materials that Franchisee desires to
use to promote Smaaash Centres, including without limitation, print and online advertising designs,
trade show display materials, press releases and interviews for publication in any media
("Promotional Material"). Franchisee shall modify any disapproved Promotional Material to satisfy
Franchisor's reasonable objections so that it is acceptable to Franchisor. Franchisor shall provide
Franchisee with the creative elements of any Promotional Materials that Franchisor creates or
acquires for use in connection with the advertising and sale of Products outside the Territory. 6.
Intellectual Property 6.1 Ownership. (a) Franchisor is the sole owner of any and all intellectual
property rights relating to the Smaaash Centres and their products and services existing as of the
Effective Date, including, but not limited to, the Trademarks and all the goodwill relating thereto
(the "Franchisor Property"). Franchisee, or any third party franchisee, by reason of this Agreement,
has not and shall not acquire any right, title, interest or claim of ownership in any of the
Franchisor Property in the Territory or elsewhere, except to the extent provided under the license
granted under Sections 1 and 3 of this Agreement.

Source: SIMPLICITY ESPORTS & GAMING CO, 8-K, 11/30/2018
<!-- page 4 -->
(b) Franchisee acknowledges that, (i) Franchisor is the sole and exclusive owner of all right, title
and interest in any Franchisor Property; (ii) nothing contained in this Agreement shall give to
Franchisee any right, title or interest in any Franchisor Property; and (iii) Franchisee's use of
the Franchisor Property, and any associated goodwill, shall inure only to the benefit of Franchisor
and shall be deemed to be solely the property of Franchisor should this Agreement be terminated for
any reason. 6.2 Registration and Cooperation. Franchisee shall not, directly or indirectly, seek or
obtain any new registration for Franchisor Property (including without limitation, any colorable
imitations, translations, or transliterations thereof), anywhere in the world without Franchisor's
prior written consent. If Franchisee has obtained or obtains in the future, in any country, any
right, title or interest in any Franchisor Property notwithstanding the previous sentence (including
any colorable imitations, translations, or transliterations thereof), Franchisee will be deemed to
have so acted as an agent and for the benefit of Franchisor for the limited purpose of obtaining
such registrations and assigning them to Franchisor. Franchisee shall execute, for no additional
consideration, any and all documents deemed necessary by Franchisor or its attorneys to be necessary
to transfer such right, title or interest to Franchisor. 6.3 No Challenges. Franchisee shall not do
anything or suffer anything to be done which may adversely affect any rights of Franchisor in and to
any Franchisor Property, or any registrations thereof or which, directly or indirectly, may reduce
or dilute the value or distinctiveness of such Franchisor Property, in particular the Trademarks, or
disparage or detract from Franchisor's reputation. Franchisee shall not challenge, directly or
indirectly, Franchisor's interest in, or the validity of, any Franchisor Property, or any
application for registration or trademark registration thereof or any rights of Franchisor therein.
The provisions of this Section 6.3 shall survive the termination of this Agreement. 7. Third Party
Infringements; Attacks on Use of the Trademarks; Cooperation 7.1 Third Party Infringements. (a)
Mutual Information. Each of the parties shall inform the other without undue delay when such party
becomes aware of any infringements of any of the Franchisor Property in the Territory. (b)
Initiation of Action. Any actions against infringers of any of the Franchisor Property, whether or
not such actions involve litigation (including any actions taken to oppose a third party application
to register an infringing trademark or a cancellation action against a third party's infringing
trademark registration), shall be exclusively reserved to Franchisor, unless otherwise agreed by
Franchisor in writing. Notwithstanding the foregoing, Franchisor shall be under no obligation to
initiate any such action. If requested by Franchisor, Franchisee shall support Franchisor, at
Franchisor's expense, in any such proceedings and, if requested by Franchisor, Franchisee shall
promptly provide Franchisor with any relevant documentation in Franchisee's possession. 7.2 Attacks
on the Use of the Franchisor Property. Each of the parties shall inform the other if it becomes
aware of a claim by a third party that the use of any of any of the Franchisor Property infringes on
the rights of such third party. If requested by Franchisor, Franchisee shall support Franchisor, at
Franchisor's expense, in connection with Franchisor's defense against any such third party claims.
Unless otherwise agreed by Franchisor in writing, Franchisor shall take the lead in any defense
against a third party action, whether brought against Franchisor and/or Franchisee. The decision
whether or not a defense is appropriate shall be in Franchisor's sole discretion. Franchisee shall
not settle any third party claims against it regarding its use of any of the Franchisor Property
without the prior written consent of Franchisor. 7.3 Indemnity. The Franchisee shall indemnify and
hold the Franchisor, its affiliates and their respective agents and employees harmless from all
claims, actions, suits, damages, costs and expenses in relation to or arising out of the breach of
any representations, warranties, covenants and obligations of the Franchisee as set out in this
Agreement. The indemnification rights of the Franchisor shall be without prejudice to, and
independent of any other rights and remedies that the Franchisor may have at law or in equity,
including the right to seek specific performance, injunctive relief or restitution, none of which
rights or remedies shall be affected or diminished thereby. The provisions of this Section 7.3 shall
survive the termination of this Agreement. 8. Termination 8.1 Termination by Mutual Agreement. This
Agreement may be terminated at any time upon the mutual written agreement of the parties.

Source: SIMPLICITY ESPORTS & GAMING CO, 8-K, 11/30/2018
<!-- page 5 -->
8.2 Termination by Franchisor with Notice. Franchisor may terminate this Agreement upon thirty (30)
days written notice to Franchisee upon the occurrence of any of the following: (a) Franchisee fails
to make any payment required under or in connection with this Agreement; (b) Franchisee ceases to
operate or otherwise abandon the Smaaash Centres without the consent of Franchisor, or otherwise
forfeit the right to do or transact business in the Territory; (c) Franchisee fails to use its best
efforts to market and promote Smaaash Centres and the services and products offered by Smaaash
Centres within the Territory and such failure is not cured within thirty (30) days of Franchisor's
notification to Franchisee of such failure. 8.3 Termination for Cause. This Agreement may be
terminated by either party for "Cause" without the need of providing a notice period prior to such
termination becoming effective. "Cause" shall exist if circumstances occur which, taking into
consideration the substance and purpose of this Agreement, would make it unreasonable for one or
both of the parties to continue the contractual relationship and the other party fails to cure the
cause (assuming that such cause is susceptible to cure) within thirty (30) days after the date of
receipt of a corresponding written notice ("Remedy Notice"). If such cause by its nature is not
curable, then no such Remedy Notice is required. Without limiting the generality of the foregoing, a
party may terminate this Agreement for "Cause"if: (a) the other party to this Agreement is in breach
of one or more of its material obligations; or (b) the other party to this Agreement becomes
insolvent, generally cannot pay its obligations when due or otherwise suffers a substantial
deterioration of its financial situation, or if insolvency/bankruptcy proceedings are initiated
against such party or such party initiates any dissolution or liquidation of its business and/or
assets. 8.4 Effects of Termination. (a) Upon the termination of this Agreement, any indebtedness of
Franchisee to Franchisor shall become immediately due and payable. Franchisee shall immediately
cease to operate the Smaaash Centres and shall not thereafter, directly or indirectly, represent to
the public or hold itself out as a franchisee of Franchisor. Franchisor shall have the right to
suspend the performance of any of their obligations under this Agreement. Franchisor shall have the
right to provide the rights and license granted herein to Franchisee to any other third party entity
that Franchisor may deem fit. (b) All benefits which may accrue by reason of the activities of
Franchisee hereunder shall be deemed transferred automatically to Franchisor, and all licenses and
other rights granted to Franchisee hereunder shall immediately cease. Unless otherwise agreed by
Franchisor in writing, Franchisee shall immediately discontinue the advertising and marketing of
Smaaash Centres and the products and services offered by Smaaash Centres. (c) Each of the parties
shall continue to maintain in confidence any and all confidential information received from the
other party. At Franchisor's election, Franchisor may purchase from Franchisee any materials used by
Franchisee for the advertising, marketing, promotion, publicizing or other exploitation of Smaaash
Centres and the products and services offered by the Smaaash Centres, including all Promotional
Materials, Franchisor Property, or any other materials which contain any of the Trademarks. (d) The
termination of this Agreement for any reason shall not affect obligations accrued prior to the
effective date of such termination of this Agreement or any obligations which, either expressly or
from the context of this Agreement, are intended to survive the termination of this Agreement. 9.
Notices and Other Communications All reports, approvals, requests, demands, notices and other
communications (collectively "Communications") required or permitted by this Agreement shall be in
writing and signed by a duly authorized officer of or such other individual designated in writing by
a party. Communications will be duly given if delivered personally, if mailed (by registered mail,
return receipt requested) or if delivered by nationally-recognized courier or mail service which
requires the addressee to acknowledge, in writing, the receipt thereof, to the party concerned at
the following addresses (or at any other address as a party may specify by notice in writing to the
other): If to Franchisor: Smaaash Entertainment Private Limited Trade View, Level 2 Kamala Mills
Lower Parel, Mumbai 400013, India Attention: Mr. Vishwanath Kotian If to Franchisee: 1345 Avenue of
the Americas, 11th floor New York, NY 101015, USA Attention: Mr. Suhel Kanuga

Source: SIMPLICITY ESPORTS & GAMING CO, 8-K, 11/30/2018
<!-- page 6 -->
10. Miscellaneous 10.1 Entire Agreement. This Agreement contains the entire understanding and
agreement between the parties with respect to its subject matter, supersedes all prior oral or
written understandings and agreements relating thereto and may not be modified, discharged or
terminated, nor may any of the provisions hereof be waived, orally. 10.2 Right to inspect and
request information. During the Term, Franchisor shall have the right to conduct audits of
Franchisee with respect to the Smaaash Centres, and inspect the Smaaash Centres, after providing a
written notice of 5 (five) days. Franchisee shall be under an obligation to provide any information
as may be requested by Franchisor with respect to the Smaaash Centres, including the books of
accounts and other relevant documents or records maintained in relation to the Smaaash Centres. 10.3
Insurance. During the Term, Franchisee shall maintain policies of insurance as may be requested by
Franchisor, subject to applicable law, in relation to the Smaaash Centres. 10.4 Representations and
warranties. Each of the parties represents and warrants to the other party that, (i) the Agreement
constitutes a valid, legal and binding obligation of such party and is enforceable against such
party in accordance with its terms, (ii) it has the power and authority to execute the Agreement and
perform all its terms, and (iii) the execution and performance of this Agreement shall not violate
any charter documents of such party, contravene any provisions of law as applicable to such party
(including any order, decree, injunction of any competent court) or conflict with the provisions of
any material agreement or contract executed by such party. The provisions of this Section 10.4 shall
survive the termination of this Agreement. 10.5 Governing Law. (a) The parties hereto have expressly
agreed that this Agreement shall be governed by, and construed in accordance with, the laws of the
State of New York, applicable to contracts executed and fully to be performed therein, to the
exclusion of any other applicable body of governing law. (b) Except as hereafter provided, the
parties hereby consent to the jurisdiction of the New York State Supreme Court, County of New York
or in the United States District Court for the Southern District of New York to resolve any dispute
arising under this Agreement. (c) In the event of any litigation or other action arising out of this
Agreement, the court shall award to the substantially prevailing party all reasonable costs and
expenses including reasonable attorney's fees. 10.6 WAIVER OF JURY. THE PARTIES HEREBY WAIVE ANY
RIGHT TO TRIAL BY JURY IN ANY PROCEEDING ARISING OUT OF OR RELATING TO THIS AGREEMENT OR ANY OF THE
TRANSACTIONS CONTEMPLATED UNDER THIS AGREEMENT, WHETHER NOW OR EXISTING OR HEREAFTER ARISING, AND
WHETHER SOUNDING IN CONTRACT, TORT OR OTHERWISE. THE PARTIES AGREE THAT ANY OF THEM MAY FILE A COPY
OF THIS SECTION WITH ANY COURT AS WRITTEN EVIDENCE OF THE KNOWING, VOLUNTARY AND BARGAINED FOR
AGREEMENT AMONG THE PARTIES IRREVOCABLY TO WAIVE THE TRIAL BY JURY COURT, AND THAT ANY PROCEEDINGS
WHATSOEVER BETWEEN THEM RELATING TO THIS AGREEMENT SHALL INSTEAD BE TRIED IN A COURT OF COMPETENT
JURISDICTION BY A JUDGE SITTING WITHOUT A JURY. 10.7 Force Majeure. The parties will not be liable
to each other for any failure or delay in performance, other than failure to make timely payments
due under this Agreement, if it is because of earthquake, flood, fire, acts of God, civil unrest,
terrorism, acts of any governmental authority or any other reason beyond the reasonable control of
either or both of the parties ("Force Majeure"). However, either party may terminate this Agreement
by and upon notice to the other if the other is unable to perform any of its material obligations
for a period of thirty (30) days by reason of a Force Majeure. 10.8 No Joint Venture. Nothing herein
is intended to constitute the parties as partners or as joint venturers, or either as agent of the
other, and neither party may obligate or bind the other. 10.9 Headings, Definitions and other
particulars. Headings and titles of sections and/or paragraphs are for convenience only. The
definitions in this Agreement shall apply equally to both the singular and plural forms of the terms
defined. Whenever the context may require, any pronoun shall include the corresponding masculine,
feminine and neuter forms. The use of "including" in this Agreement shall be construed as
illustrative.

Source: SIMPLICITY ESPORTS & GAMING CO, 8-K, 11/30/2018
<!-- page 7 -->
10.10 Amendment. This Agreement shall, from the Effective Date, bind the parties to the terms herein
and cannot be amended without the consent of the parties. Further, this Agreement cannot be
terminated by any party except in accordance with Clause 8 of this Agreement. 10.11 Assignment. The
Franchisor shall be entitled to assign, transfer, encumber or dispose of any of its rights and or
obligations under this Agreement, including to an affiliate, without the prior written consent of
the Franchisee. The Franchisee shall not be entitled to assign, transfer, encumber or dispose of any
of its rights and or obligations under this Agreement, including to an affiliate, without the prior
written consent of the Franchisor. 10.12 Expenses. The Franchisee shall bear all the costs and
expenses in relation to the execution of this Agreement and the consummation of all the transactions
hereunder. 10.13 Counterparts. This Agreement may be executed in two (2) or more counterparts, each
of which shall be deemed an original, but all of which shall constitute one and the same instrument.
The delivery of signed counterparts by facsimile transmission or electronic mail in "portable
document format" (".pdf") shall be as effective as signing and delivering the document in person.

Source: SIMPLICITY ESPORTS & GAMING CO, 8-K, 11/30/2018
<!-- page 8 -->
IN WITNESS WHEREOF, the parties hereto have duly executed this Agreement the day and year first
above written. SMAAASH ENTERTAINMENT PRIVATE LIMITED By: /s/ Shripal Morakhia Name: Shripal Morakhia
Title: I-AM CAPITAL ACQUISITION COMPANY By: /s/ F. Jacob Cherian Name: F. Jacob Cherian Title: Chief
Executive Officer (exhibits follow)

Source: SIMPLICITY ESPORTS & GAMING CO, 8-K, 11/30/2018
<!-- page 9 -->
Exhibit A Trademarks Separately annexed

Source: SIMPLICITY ESPORTS & GAMING CO, 8-K, 11/30/2018
