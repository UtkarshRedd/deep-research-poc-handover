"""Provenance gate (PLAN Phase 7): near-duplicate documents count as ONE source.

Conformed copies, re-filed exhibits and forwarded drafts look like independent corroboration to a
model ("evidence laundering", EMNLP 2026). Documents are fingerprinted with MinHash over word
n-gram shingles; documents whose estimated Jaccard similarity reaches NEAR_DUP_THRESHOLD are
joined into a cluster (union-find). A claim's `source_clusters` is the number of distinct
clusters among the documents it cites; two citations from one cluster are one source.

Pure Python, deterministic (fixed hash seeds), no model calls. Signatures are computed lazily per
document and cached on the workspace, so verification only pays for the documents a report cites.
`cluster_all` fingerprints a whole workspace with LSH banding for corpus statistics.
"""
from __future__ import annotations

import random
import re
import zlib
from collections import defaultdict

from ..config import DEFAULT, Config
from ..workspace import Workspace

_PRIME = (1 << 61) - 1
_TOKEN_RE = re.compile(r"[a-z0-9]+")


def _perms(k: int, seed: int = 42) -> list[tuple[int, int]]:
    rnd = random.Random(seed)
    return [(rnd.randrange(1, _PRIME - 1), rnd.randrange(0, _PRIME - 1)) for _ in range(k)]


def shingles(text: str, n: int) -> set[int]:
    toks = _TOKEN_RE.findall(text.lower())
    if len(toks) < n:
        return {zlib.crc32(" ".join(toks).encode("utf-8"))} if toks else set()
    return {zlib.crc32(" ".join(toks[i : i + n]).encode("utf-8")) for i in range(len(toks) - n + 1)}


def minhash(shingle_set: set[int], perms: list[tuple[int, int]]) -> tuple[int, ...]:
    if not shingle_set:
        return tuple(_PRIME for _ in perms)
    sig = []
    for a, b in perms:
        sig.append(min((a * x + b) % _PRIME for x in shingle_set))
    return tuple(sig)


def similarity(s1: tuple[int, ...], s2: tuple[int, ...]) -> float:
    return sum(1 for a, b in zip(s1, s2) if a == b) / len(s1)


def signature(ws: Workspace, doc_id: str, config: Config = DEFAULT) -> tuple[int, ...]:
    cache = ws.__dict__.setdefault("_minhash_cache", {})
    key = (doc_id, config.verify.SHINGLE_N, config.verify.MINHASH_PERMS)
    if key not in cache:
        text = "\n".join(ln for ln in ws.lines(doc_id) if not ws._page_re.match(ln))
        cache[key] = minhash(shingles(text, config.verify.SHINGLE_N), _perms(config.verify.MINHASH_PERMS))
    return cache[key]


def _parties(ws: Workspace, doc_id: str) -> frozenset[str]:
    return frozenset(" ".join(p.lower().split()) for p in ws.manifest[doc_id].parties if p.strip())


def same_source(ws: Workspace, a: str, b: str, sim: float, config: Config = DEFAULT) -> bool:
    """Two documents are one source when their text is almost identical, or when it is very
    similar AND they name the same parties (a conformed copy); templated agreements between
    different parties share boilerplate but are distinct sources."""
    v = config.verify
    if sim >= v.NEAR_DUP_THRESHOLD:
        return True
    pa, pb = _parties(ws, a), _parties(ws, b)
    return bool(pa) and pa == pb and sim >= v.NEAR_DUP_SAME_PARTIES_THRESHOLD


class _UnionFind:
    def __init__(self, items):
        self.parent = {x: x for x in items}

    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[max(ra, rb)] = min(ra, rb)


def clusters_for(ws: Workspace, doc_ids: list[str], config: Config = DEFAULT) -> dict[str, str]:
    """doc_id -> cluster id (the smallest doc_id in the cluster) for the given documents, by
    pairwise MinHash similarity. Meant for the handful of documents a report cites."""
    ids = sorted({d for d in doc_ids if d in ws.manifest})
    sigs = {d: signature(ws, d, config) for d in ids}
    uf = _UnionFind(ids)
    for i, a in enumerate(ids):
        for b in ids[i + 1 :]:
            if same_source(ws, a, b, similarity(sigs[a], sigs[b]), config):
                uf.union(a, b)
    return {d: uf.find(d) for d in ids}


def cluster_all(ws: Workspace, config: Config = DEFAULT, bands: int = 16) -> dict[str, str]:
    """Whole-workspace clustering with LSH banding (candidate pairs share a band bucket), then
    exact signature comparison. For corpus statistics and tests; not on the query path."""
    ids = ws.doc_ids()
    sigs = {d: signature(ws, d, config) for d in ids}
    k = config.verify.MINHASH_PERMS
    rows = max(1, k // bands)
    buckets: dict[tuple[int, tuple[int, ...]], list[str]] = defaultdict(list)
    for d in ids:
        s = sigs[d]
        for b in range(bands):
            buckets[(b, s[b * rows : (b + 1) * rows])].append(d)
    uf = _UnionFind(ids)
    seen: set[tuple[str, str]] = set()
    for members in buckets.values():
        if len(members) < 2:
            continue
        for i, a in enumerate(members):
            for b in members[i + 1 :]:
                pair = (a, b) if a < b else (b, a)
                if pair in seen:
                    continue
                seen.add(pair)
                if same_source(ws, a, b, similarity(sigs[a], sigs[b]), config):
                    uf.union(a, b)
    return {d: uf.find(d) for d in ids}


def source_clusters(cited_doc_ids: list[str], clusters: dict[str, str]) -> int:
    return len({clusters.get(d, d) for d in cited_doc_ids})
