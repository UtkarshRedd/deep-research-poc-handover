"""Tier-2 verification (PLAN Phase 7): grouped, model-based support check of claims against their
cited evidence IN CONTEXT. Tier 1 proves the quote exists on the cited page; tier 2 asks whether
the quote actually supports the sentence written from it (numbers, dates, parties, conditions).

Rules (CLAUDE.md invariant 5):
  * tier 2 never overrides a tier-1 drop: dropped claims are not sent, and stay dropped;
  * gaps are not sent (nothing to check);
  * flagged claims (tier-1 truncate, relocated or multi-source) are ALWAYS checked; clean
    (keep) claims are sampled at TIER2_SAMPLE_RATE_CLEAN, deterministically by claim id;
  * claims are checked in groups of TIER2_GROUP_SIZE (DeepFact: grouping cuts cost ~4x for a few
    points of accuracy) with one JSON call per group; a failed call leaves `skipped`;
  * an `unsupported` verdict flags the claim in the report (it is not silently kept) and fails the
    hallucination gate; `partially` is flagged as partially supported.

The verifier sees, per claim: the claim text, each cited quote, and TIER2_CONTEXT_LINES of the
source document around the quote with line numbers. No tools, no whole documents.
"""
from __future__ import annotations

import time
import zlib
from typing import Any, Literal

from langchain_core.messages import HumanMessage
from pydantic import BaseModel, Field

from ..config import DEFAULT, Config
from ..evidence import EvidenceBank
from ..models import Claim, Report, VerifyResult
from ..prompts import load
from ..structured import ModelCaller
from ..trace import Trace
from ..workspace import Workspace


class Verdict(BaseModel):
    claim_id: str
    verdict: Literal["supported", "partially", "unsupported"] = "supported"
    reason: str = ""


class Tier2JSON(BaseModel):
    verdicts: list[Verdict] = Field(default_factory=list)


def select_claims(report: Report, results: list[VerifyResult], config: Config = DEFAULT) -> list[Claim]:
    """Flagged claims always; clean ones sampled deterministically; drops and gaps never."""
    by_id = {r.claim_id: r for r in results}
    rate = config.verify.TIER2_SAMPLE_RATE_CLEAN
    chosen: list[Claim] = []
    for c in report.claims:
        r = by_id.get(c.claim_id)
        if r is None or r.tier1 in ("drop", "gap") or not c.evidence_ids:
            continue
        flagged = r.tier1 == "truncate" or bool(r.note) or len(c.evidence_ids) > 1
        sampled = rate > 0 and (zlib.crc32(c.claim_id.encode()) % 1000) < rate * 1000
        if flagged or sampled:
            chosen.append(c)
    return chosen


def group_claims(claims: list[Claim], size: int) -> list[list[Claim]]:
    groups: list[list[Claim]] = []
    cur: list[Claim] = []
    cur_section = None
    for c in claims:
        if cur and (len(cur) >= size or c.section_id != cur_section):
            groups.append(cur)
            cur = []
        cur.append(c)
        cur_section = c.section_id
    if cur:
        groups.append(cur)
    return groups


def render_group(ws: Workspace, bank: EvidenceBank, claims: list[Claim], config: Config = DEFAULT) -> str:
    pad = config.verify.TIER2_CONTEXT_LINES
    out: list[str] = []
    for c in claims:
        out.append(f"[{c.claim_id}] CLAIM: {c.text}")
        for eid in c.evidence_ids:
            it = bank.get(eid)
            if it is None:
                out.append(f"  EVIDENCE {eid}: (unknown id)")
                continue
            pg = f" p.{it.page}" if it.page else ""
            out.append(f'  EVIDENCE {eid} ({it.doc_id}{pg} L{it.start_line}-{it.end_line}): "{it.quote[:600]}"')
            lines = ws.lines(it.doc_id)
            s, e = max(1, it.start_line - pad), min(len(lines), it.end_line + pad)
            ctx = "\n".join(f"    {i}| {lines[i - 1][:240]}" for i in range(s, e + 1) if lines[i - 1].strip())
            out.append(f"  CONTEXT L{s}-{e}:\n{ctx}")
        out.append("")
    return "\n".join(out)


def verify_tier2(ws: Workspace, bank: EvidenceBank, report: Report, results: list[VerifyResult],
                 llm: Any | None = None, config: Config = DEFAULT, trace: Trace | None = None,
                 deadline_ts: float | None = None) -> list[VerifyResult]:
    """Mutates `results` in place (tier2 + note) and returns them."""
    if not config.verify.TIER2_ENABLED:
        return results
    if llm is None:
        from ..llm import get_llm

        llm = get_llm("verifier")
    t0 = time.perf_counter()
    caller = ModelCaller(llm, trace, "verify", "verifier", deadline_ts=deadline_ts, config=config)
    chosen = select_claims(report, results, config)
    by_id = {r.claim_id: r for r in results}
    n_checked = n_unsupported = n_partial = n_failed = 0
    for group in group_claims(chosen, config.verify.TIER2_GROUP_SIZE):
        if deadline_ts is not None and time.time() >= deadline_ts:
            break
        got = caller.json([HumanMessage(content=load("verifier_tier2", claims=render_group(ws, bank, group, config)))], Tier2JSON)
        if got is None:
            n_failed += len(group)
            continue
        verdicts = {v.claim_id: v for v in got.verdicts}
        for c in group:
            v = verdicts.get(c.claim_id)
            r = by_id[c.claim_id]
            if v is None:
                n_failed += 1
                continue
            r.tier2 = v.verdict
            n_checked += 1
            if v.verdict != "supported":
                n_unsupported += v.verdict == "unsupported"
                n_partial += v.verdict == "partially"
                reason = f"tier 2 {v.verdict}: {v.reason[:160]}"
                r.note = f"{r.note}; {reason}" if r.note else reason
    if trace:
        trace.stage("verify_tier2", "end", n_selected=len(chosen), n_checked=n_checked, n_unsupported=n_unsupported,
                    n_partial=n_partial, n_failed=n_failed, ms=int((time.perf_counter() - t0) * 1000))
    return results


# --------------------------------------------------------------------------- seeded self-check


def seeded_check(ws: Workspace, bank: EvidenceBank, llm: Any, config: Config = DEFAULT, n: int = 10) -> dict:
    """Plant wrong claims next to true ones and measure what tier 2 flags (PLAN Phase 7 acceptance:
    >= 80 % of planted errors flagged). Perturbs numbers, dates or negates the quote; uses the
    bank's own items so every claim has real tier-1-valid evidence."""
    items = [it for it in bank.all() if it.tier1_status != "drop"][:n]
    good_claims: list[Claim] = []
    bad_claims: list[Claim] = []
    truth: dict[str, bool] = {}
    for i, it in enumerate(items):
        q = " ".join(it.quote.split())
        good = Claim(claim_id=f"t.{i + 1}", section_id="t", text=q[:300], evidence_ids=[it.id])
        bad = Claim(claim_id=f"f.{i + 1}", section_id="f", text=_perturb(q)[:300], evidence_ids=[it.id])
        good_claims.append(good)
        bad_claims.append(bad)
        truth[good.claim_id], truth[bad.claim_id] = True, False
    claims = good_claims + bad_claims      # grouped by section: true claims, then planted ones
    report = Report(question="seeded tier-2 check", title="seeded", sections=[], claims=claims)
    results = [VerifyResult(claim_id=c.claim_id, tier1="keep", tier1_score=1.0) for c in claims]
    from dataclasses import replace

    cfg = replace(config, verify=replace(config.verify, TIER2_SAMPLE_RATE_CLEAN=1.0, TIER2_ENABLED=True))
    verify_tier2(ws, bank, report, results, llm=llm, config=cfg)
    by = {r.claim_id: r for r in results}
    planted = [c for c in claims if not truth[c.claim_id]]
    true_ones = [c for c in claims if truth[c.claim_id]]
    flagged = sum(1 for c in planted if by[c.claim_id].tier2 in ("unsupported", "partially"))
    false_flags = sum(1 for c in true_ones if by[c.claim_id].tier2 in ("unsupported", "partially"))
    return {"planted": len(planted), "flagged": flagged, "flag_rate": flagged / len(planted) if planted else None,
            "true": len(true_ones), "false_flags": false_flags,
            "skipped": sum(1 for r in results if r.tier2 == "skipped"),
            "details": [(c.claim_id, c.text[:80], by[c.claim_id].tier2) for c in claims]}


def _perturb(text: str) -> str:
    """Plant a substantive error: change a ratio, percentage, amount, date or day count (never a
    section number such as "Section 7.1"); else negate the first modal verb; else prepend 'not'."""
    import re

    def bump(m: re.Match) -> str:
        s = m.group(0)
        try:
            v = float(s.replace(",", ""))
        except ValueError:
            return s
        v2 = v * 2 + 1 if v < 100 else v + 1000
        return f"{v2:,.2f}" if "." in s else f"{int(v2):,}" if "," in s else str(int(v2))

    # substantive values first: ratios, percentages, dollar amounts, ISO dates, day counts
    for pat in (r"\d+\.\d+(?=\s*to\s*1)", r"\d+(?:\.\d+)?(?=\s*%)", r"(?<=\$)\d[\d,]*(?:\.\d+)?",
                r"(?<=\d{4}-\d{2}-)\d{2}", r"\d+(?=\s*\(?\w*\)?\s*days)"):
        new, n = re.subn(pat, bump, text, count=1)
        if n:
            return new
    # any other number that is not a section/clause label
    cleaned = re.sub(r"(?:Section|Article|Clause|§)\s*\d+(?:\.\d+)*|^\s*\d+(?:\.\d+)*\s", lambda m: " " * len(m.group(0)), text)
    m = re.search(r"\d[\d,]*(?:\.\d+)?", cleaned)
    if m:
        return text[: m.start()] + bump(m) + text[m.end():]
    for a, b in (("shall not", "shall"), ("shall", "shall not"), ("may not", "may"), ("may", "may not"),
                 ("must", "must not"), ("will", "will not"), ("is ", "is not "), ("are ", "are not ")):
        if a in text:
            return text.replace(a, b, 1)
    return "It is not the case that " + text[0].lower() + text[1:]
