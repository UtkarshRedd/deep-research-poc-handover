# Which jurisdiction's law governs the Services Agreement between [ * * * ] and TELCOSTAR...

*Question:* Which jurisdiction's law governs the Services Agreement between [ * * * ] and TELCOSTAR PTE, LTD. (dated 2019-10-01)?

## Identify governing law clause

The Services Agreement contains an express choice-of-law provision designating the domestic laws of the State of Israel. [cbfaa94a72b9d4aa p.8] The clause states: "Governing Law. [uncited] This Agreement and any claim, controversy or dispute arising out of or related to this Agreement, any of the transactions contemplated hereby and/or the interpretation and enforcement of the rights and duties of the Parties, whether arising in contract, tort, equity or otherwise, shall be governed by and construed in accordance with the domestic laws of the State of Israel (including in respect of the statute of limitations or other limitations period applicable to any such claim, controversy or dispute), without giving effect to any choice or conflict of law provision or rule (whether of the State of Israel or any other jurisdiction) that would cause the application of the laws of any jurisdiction other than the State of Israel." [cbfaa94a72b9d4aa p.8]

## Identify parties and date

This Services Agreement is entered into on October 1, 2019 and is made effective as of November 1, 2019. [cbfaa94a72b9d4aa p.1] The parties to the Agreement are [ * * * ] (the "Provider") and TELCOSTAR PTE, LTD., a company organized and existing under the laws of Singapore. [cbfaa94a72b9d4aa p.1] Ability Computer & Software Industries Ltd, a company organized and existing under the laws of the State of Israel, is also a party as a Recipient. [cbfaa94a72b9d4aa p.1]

## Verification appendix

Claims: 6 · supported: 5 · partially: 0 · dropped: 0 · gaps: 1 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[cbfaa94a72b9d4aa p.8] |  |
| s1.2 | s1 | gap |  |  | no evidence cited |
| s1.3 | s1 | keep | 1.00 | e1→[cbfaa94a72b9d4aa p.8] |  |
| s2.1 | s2 | keep | 1.00 | e2→[cbfaa94a72b9d4aa p.1] |  |
| s2.2 | s2 | keep | 1.00 | e2→[cbfaa94a72b9d4aa p.1] |  |
| s2.3 | s2 | keep | 1.00 | e2→[cbfaa94a72b9d4aa p.1] |  |

### Evidence

- e1 [cbfaa94a72b9d4aa p.8 L257-264] keep (1.0): "Governing Law. This Agreement and any claim, controversy or dispute arising out of or related to this Agreement, any of the transactions contemplated hereby and/or the interpretation and enforcement of the rights and duties of the Parties, …"
- e2 [cbfaa94a72b9d4aa p.1 L12-17] keep (1.0): "This Services Agreement (this "Agreement") is entered into on October 1, 2019 and is made effective as of November 1, 2019 (the "Effective Date"), by and between [ * * * ] (the "Provider"), and TELCOSTAR PTE, LTD., a company organized and e…"
