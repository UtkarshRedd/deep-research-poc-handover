<!-- page 1 -->
# Franchise Agreement
| Field | Value |
|---|---|
| Document Type | Franchise Agreement |
| SEC Filing Date | 1998-06-05 |
| Parties | BW-3 FRANCHISE SYSTEMS, INC. ("Franchisor", "we" or "us"); Franchisee ("you") |
| Source | CUAD v1 / BUFFALOWILDWINGSINC_06_05_1998-EX-10.3-FRANCHISE AGREEMENT |

BW-3 FRANCHISE SYSTEMS, INC. FRANCHISE AGREEMENT

TABLE OF CONTENTS

ARTICLE PAGE - ------- ---- I. APPOINTMENT AND FRANCHISE FEE. . . . . . . . . . . . . . . . . . . .
.1 II. TERM AND RENEWAL . . . . . . . . . . . . . . . . . . . . . . . . . . .3 III. RESTAURANT AND
LOCATION. . . . . . . . . . . . . . . . . . . . . . . .4 IV. TRAINING . . . . . . . . . . . . . . .
. . . . . . . . . . . . . . . .5 V. PROPRIETARY MARKS. . . . . . . . . . . . . . . . . . . . . . . .
. . .6 VI. CONFIDENTIAL MANUALS . . . . . . . . . . . . . . . . . . . . . . . . .7 VII. CONFIDENTIAL
INFORMATION . . . . . . . . . . . . . . . . . . . . . . .7 VIII. MODIFICATION OF THE SYSTEM . . . .
. . . . . . . . . . . . . . . . . .8 IX. ADVERTISING. . . . . . . . . . . . . . . . . . . . . . . .
. . . . . .8 X. CONTINUING FEE . . . . . . . . . . . . . . . . . . . . . . . . . . . 10 XI.
ACCOUNTING AND RECORDS . . . . . . . . . . . . . . . . . . . . . . . 12 XII. STANDARDS OF QUALITY
AND PERFORMANCE . . . . . . . . . . . . . . . . 13 XIII. OPERATIONS ASSISTANCE. . . . . . . . . . .
. . . . . . . . . . . . . 17 XIV. INSURANCE. . . . . . . . . . . . . . . . . . . . . . . . . . . . .
. 18 XV. COVENANTS. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 19 XVI. DEFAULT AND
TERMINATION. . . . . . . . . . . . . . . . . . . . . . . 20 XVII. RIGHTS AND DUTIES OF PARTIES UPON
EXPIRATION OR TERMINATION. . . . . . . . . . . . . . . . . . . . . . . . . . . . . 23 XVIII.
TRANSFERABILITY OF INTEREST. . . . . . . . . . . . . . . . . . . . . 24 XIX. YOUR DEATH OR
INCAPACITY . . . . . . . . . . . . . . . . . . . . . . 26 XX. RIGHT OF FIRST REFUSAL . . . . . . . .
. . . . . . . . . . . . . . . 26 XXI. OPERATION IN THE EVENT OF ABSENCE, DISABILITY OR DEATH . . . .
. . . 26 XXII. INDEPENDENT CONTRACTOR AND INDEMNIFICATION . . . . . . . . . . . . . 27 XXIII.
MISCELLANEOUS. . . . . . . . . . . . . . . . . . . . . . . . . . . . 27 XXIV. APPLICABLE LAW . . . .
. . . . . . . . . . . . . . . . . . . . . . . 29 XXV. DISPUTE RESOLUTION . . . . . . . . . . . . . .
. . . . . . . . . . . 29 XXVI. OWNER AGREEMENT. . . . . . . . . . . . . . . . . . . . . . . . . . .
31 XXVII. ACKNOWLEDGEMENTS . . . . . . . . . . . . . . . . . . . . . . . . . . 31

EXHIBITS:

A. OWNER AGREEMENT B. DESCRIPTION OF DESIGNATED AREA C. LEASE ADDENDUM

i

bw-3 FRANCHISE SYSTEMS, INC.

FRANCHISE AGREEMENT

This Franchise Agreement ("Agreement") made this _____ day of ________, 19____, by and between bw-3
FRANCHISE SYSTEMS, INC. an Ohio corporation which has its principal place of business at 1919
Interchange Tower, 600 South Highway 169, Minneapolis, Minnesota 55426 ("we" or "us"), and
__________________________
________________________________________________________________________________
________________________________________________________________________________ _______________
("you"). If you are a corporation, partnership or limited liability company, certain provisions of
the Agreement also apply to your owners and will be noted.

BACKGROUND:

A. Our parent company has developed a unique system ("System") for establishing and operating
restaurants which use the service mark "BUFFALO WILD WINGS" and which feature chicken wings,
sandwiches, and other products and beverages, which are all prepared according to specified recipes
and procedures ("Menu Items"), some of which use proprietary mixes ("Trade Secret Food Products"),
and has granted to us the right to sublicense the System to others.

B. The distinguishing characteristics of the System include, without limitation, distinctive
exterior and interior layout, design and color scheme, signage, decorations, furnishings and
materials, special recipes, formulae, menus and food and beverage designations, Confidential
Manuals, food and beverage storage, preparation service and delivery procedures and techniques,
operating procedures for sanitation and maintenance, and methods and techniques for inventory and
cost controls, record keeping and reporting, purchasing, sales promotion and advertising, Trade
Secret Food Products, all of which may be

changed, improved and further developed from time to time.
<!-- page 2 -->
C. Our parent company is the owner of the trade names, service marks and trademarks "BUFFALO WILD
WINGS", "bw-3" and other logos and commercial symbols, and such other trade names, service marks,
and trademarks as are now designated (and may later be designated by us in writing) as part of the
System ("Marks").

D. We grant franchises to qualified candidates for the operation of "Buffalo Wild Wings" Restaurants
offering the Menu Items and utilizing the System and Marks. You desire to operate a Buffalo Wild
Wings Restaurant using the System and Marks and have applied for a franchise, which application has
been approved by us in reliance upon all of the representations you have made.

E. You understand and acknowledge the importance of our high and uniform standards of quality and
service and the necessity of operating the Buffalo Wild Wings business in conformity with our
standards and specifications.

AGREEMENTS:

We and you agree as follows:

I. APPOINTMENT AND FRANCHISE FEE

A. Subject to the provisions stated below, we hereby grant you a license to use the "Buffalo Wild
Wings" Marks and System, and you undertake the obligation to operate a Buffalo Wild Wings restaurant
facility featuring the Menu Items and providing sit-down, carry-out and other restaurant services
("Franchised

1

Restaurant"), and to use the Marks solely in connection with the System, as it is currently
established, and as it may be changed, improved and further developed from time to time, at one (1)
location only, such location to be: 1)
____________________________________________________________________________
___________________________________________________________________________, or 2) at a location to
be designated, as provided in Paragraph III within the area described on EXHIBIT B. When a location
has been designated and approved by you and us, it will become part of Paragraph I.A.1., as if
originally incorporated in that Paragraph. You shall not relocate your Franchised Restaurant without
our prior written approval.

B. You receive a Designated Area within which we and our affiliates shall not operate or grant to
anyone else a franchise to operate a Buffalo Wild Wings or bw-3 Restaurant so long as this Agreement
is in force and effect. The Designated Area is described in writing and on a map attached to the
Agreement as EXHIBIT B and is made a part of the Agreement. You do not have any right to sublicense
or subfranchise others within or outside of the Designated Area and do not have the right to operate
more than one (1) Franchised Restaurant within the Designated Area.

C. You acknowledge and agree that we have the right, in our sole discretion, to grant other
franchises outside of the Designated Area as we deem appropriate. Although we will not operate a
Buffalo Wild Wings or bw-3 business within the Designated Area, we reserve the right, both within
and outside of the Designated Area, to offer and sell at special events (at our option, if you elect
not to participate in such events) or at wholesale, through channels of distribution distinct from
those of a Franchised Restaurant, products and services which comprise, or may in the future
comprise a part of the System, which products may be resold at retail to the general public by such
entities. Further, you acknowledge that certain locations within the Designated Area are by their
nature unique and separate in character from sites generally developed as Franchised Restaurants. As
a result, you agree that the following locations ("Special Sites") are excluded from the Designated
Area and we shall have the right to develop (by direct ownership or franchising) such locations: 1)
public transportation facilities, including airports, train stations and bus stations; 2) military
bases; 3) sports facilities, including race tracks; and 4) amusement and/or theme parks.

D. We and our affiliated companies shall not engage in catering and delivery services and activities
in the Designated Area. You shall not engage in catering and delivery services and activities
outside of the Designated Area. We shall have no obligation to enforce similar covenants against any
other System franchisee. Other System franchisees shall be deemed third party beneficiaries of such.
You shall not offer for sale any Menu Items or Proprietary Products by means of Internet/World Wide
Web programming or advertising. We reserve the right to market and sell Menu Items and Trade Secret
Food Products on the Internet/World Wide Web.

E. You pay us a nonrefundable Initial Franchise Fee of ________________ _______________________
Dollars ($________) which is payable in full on the date of this Agreement. The Initial Franchise
Fee has been fully earned upon receipt and is nonrefundable in consideration of the expenses
incurred by us in granting this franchise and for the lost or deferred opportunity to franchise
others.

F. You acknowledge that because complete and detailed uniformity under many varying conditions may
not be possible or practical, we specifically reserve the right, at our sole discretion, to vary
standards for any System franchisee based upon the peculiarities of the particular site or
circumstance, density of population, business potential, population of trade area, existing business
practices or any other condition which we deem to be of importance to the successful operation of
such franchisee's business. You shall not be entitled to require us to grant to you a like or
similar variation.
<!-- page 3 -->
G. In consideration of our agreement not to grant another franchise in the area described in
Paragraph I.C., you at all times shall use your best efforts to promote and increase the sales and
service of Menu

2

Items and to effect the widest and best possible distribution throughout the Designated Area,
soliciting and servicing all potential customers and accounts for Buffalo Wild Wings food products
and services.

II. TERM AND RENEWAL

A. The term of this Agreement is for ten (10) years commencing on the date of this Agreement, unless
terminated as provided by this Agreement.

B. You have the right to renew the franchise for two (2) successive terms equal to five (5) years
each, providing you meet all of the following conditions:

1. You have, during the entire term, complied with all the provisions of the Agreement;

2. The premises of the Franchised Restaurant meet our then-current standards for Buffalo Wild Wings
restaurants and you are able to maintain possession of the Franchised Restaurant. Before the
expiration date of this Agreement you must bring the Franchised Restaurant into full compliance with
the specifications and standards then applicable for new or renewing Buffalo Wild Wings businesses
and present us with evidence satisfactory that you have the right to remain in possession of the
Franchised Restaurant premises for the duration of the renewal term. In the event you are unable to
maintain possession of the premises of the Franchised Restaurant or if the premises do not meet our
then-current standards, you may secure substitute premises approved by us and provided that you have
furnished, stocked and equipped such premises to bring the Franchised Restaurant at its substituted
premises into full compliance with the then-current specifications and standards before the
expiration date of this Agreement;

3. You have given us written notice of your desire to renew at least six (6) months but not more
than twelve (12) months prior to the end of the term;

4. You have satisfied all of your monetary obligations to us and our affiliates and have timely met
these obligations throughout the term of this Agreement;

5. You have executed for the renewal term our then-current form of Franchise Agreement (with
appropriate modifications to reflect the fact that the agreement relates to the grant of a renewal
franchise), which shall supersede in all respects this Agreement, and the terms of which may differ
from the terms of this Agreement, including, without limitation, a different percentage Continuing
Fee and advertising contribution; provided, however, that the percentage Continuing Fee shall not
exceed seven percent (7%) during any renewal period. You will not be required to pay the
then-current initial franchise fee or its equivalent;

6. You have complied with our then-current qualification and training requirements; and

7. You have executed a general release, in a form prescribed by us, of all claims against us and our
affiliates, and respective officers, directors, agents, shareholders and employees.

C. Within ninety (90) days of our receipt of your notice to renew, we will furnish you with written
notice of: (i) reasons which could cause us not to grant a renewal to you including but not limited
to any deficiencies which require correction and a schedule for correction by you; and (ii) our
then-current requirements relating to the image, appearance, decoration, furnishing, equipping and
stocking of Buffalo Wild Wings businesses, and a schedule for effecting upgrading or modifications
in order to bring the Franchised Restaurant in compliance, as a condition of renewal. Renewal of the
franchise shall be conditioned upon your compliance with such requirements and continued compliance
with all the terms and conditions of this Agreement up to the date of termination of the initial
term.

3

D. We shall give you written notice of our election not to renew the franchise at least three (3)
months prior to the expiration of the initial or first renewal term of this Agreement.

III. RESTAURANT AND LOCATION

A. You shall operate the Franchised Restaurant only at the location specified in Paragraph I of this
Agreement. If the lease for the site of the Franchised Restaurant expires or terminates for reasons
other than your breach, or if the site is destroyed, condemned or otherwise rendered unusable, or as
otherwise may be agreed upon in writing by us and you, we will grant permission for relocation of
the Franchised Restaurant within your Designated Area at a location and site acceptable to us. Any
such relocation shall be at your sole expense and we shall have the right to charge you for any and
all reasonable costs incurred by us, and a reasonable fee for our services, in connection with any
such relocation of the Franchised Restaurant.
<!-- page 4 -->
B. You shall be responsible for purchasing or leasing a suitable site for the Franchised Restaurant.
Prior to the acquisition by lease or purchase of any site for the premises of the Franchised
Restaurant, you shall submit a description of the proposed site to us, together with a letter of
intent or other evidence satisfactory to us which confirms your favorable prospects for obtaining
the proposed site. We shall provide you written notice of approval or disapproval of the proposed
site within fifteen (15) business days after receiving your written proposal. Our approval is not a
determination or warranty that the proposed site will be a profitable location for the Franchised
Restaurant.

C. After receiving our written approval of the location of the Franchised Restaurant as provided in
Paragraph III.B. above, you shall, subject to our prior approval of terms, execute a lease (if the
premises are to be leased) or a binding agreement to purchase the site. All leases pertaining to the
Franchised Restaurant premises must contain an Addendum in the form of EXHIBIT C attached hereto, or
contain terms and conditions substantially similar to those contained in EXHIBIT C that we approve.
You shall provide us with a copy of the executed lease for the Franchised Restaurant within five (5)
days of its execution, and prior to its execution, provide us with a copy for our approval. A copy
of the executed Addendum must also be provided to us.

D. You shall promptly after obtaining possession of the site for the Franchised Restaurant: (i)
retain the services of an architect and a contractor each of whom has been approved by us; (ii) have
prepared and submitted for our approval a site survey and basic architectural plans and
specifications (not for construction) consistent with our general atmosphere, image, color scheme
and ambience requirements as set forth from time to time in the Manuals for a Buffalo Wild Wings
restaurant (including requirements for dimensions, exterior design, materials, interior design and
layout, equipment, fixtures, furniture, signs and decorating); (iii) obtain all required zoning
changes, building, utility, health, sanitation, liquor and sign permits and licenses and any other
required permits and licenses; (iv) purchase or lease equipment, fixtures, furniture and signs as
provided herein; (v) complete the construction and/or remodeling, equipment, fixtures, furniture and
sign installation and decorating of the Franchised Restaurant in full and strict compliance with
plans and specifications therefore approved by us and all applicable ordinances, building codes and
permit requirements; (vi) obtain all customary contractors' sworn statements and partial and final
waivers of lien for construction, remodeling, decorating and installation services; and (vii)
otherwise complete development of and have the Franchised Restaurant ready to open and commence the
conduct of its business in accordance with Paragraph XII of this Agreement. Our approval of your
site survey and architectural plans is not a representation or warranty of any type.

E. You shall be required to periodically make reasonable capital expenditures to remodel, modernize
and redecorate the premises of the Franchised Restaurant so that the Franchised Restaurant will
reflect the then-image intended to be portrayed by Buffalo Wild Wings businesses. All remodeling,
modernization, or redecoration of the premises of the Franchised Restaurant must be done in
accordance with the standards and specifications as prescribed by us from time to time and with our
prior written approval. All replacements must

4

conform to our then-current quality standards and specifications and must be approved in writing.
Your total expenditures during the term of the Franchise Agreement for such remodeling, modernizing
and redecorating will not exceed ONE HUNDRED THOUSAND Dollars ($100,000.00) adjusted for inflation
from the date of this Agreement. Maintenance of the premises of the Franchised Restaurant and
modifying or replacing equipment may exceed this amount, and maintenance costs and equipment costs
may not be credited to remodeling, modernization or redecoration expenditures.

IV. TRAINING

A. Before you commence operations, we shall make initial training available to you. At least three
(3) persons designated by you and approved by us must attend and successfully complete the training
to our satisfaction. The training will be at least three (3) weeks in duration and will be conducted
at either our Cincinnati, or Columbus, Ohio training facilities or at such other place as we may
designate. The training program covers material aspects of the operation of a Buffalo Wild Wings
business, including financial controls, general bookkeeping procedures, food preparation, service
and operational techniques, familiarization with recipes and cooking procedures, marketing and
advertising techniques, sanitation and maintenance procedures, deployment of labor, and maintenance
of quality standards. We reserve the right to provide less training if you have one or more
Franchised Restaurants in operation. All expenses incurred by you and your employees in attending
the program, including without limitation, travel costs, room and board expenses, and the employee
compensation shall be your sole responsibility.

B. We will, from time to time upon your written request, make available, at your expense, training
for additional managers designated by you and approved by us. Such training shall take place at our
Cincinnati, or Columbus, Ohio training facilities or such other place as we may designate. You
acknowledge that the time period within which we provide additional training will be subject to
available openings in our regular training program with preference being given to initial training
for new franchisees.

C. We will schedule the opening of your Franchised Restaurant. For one (1) week prior to and one (1)
week concurrent with the commencement of operations of the Franchised Restaurant, we will furnish to
you, at your
<!-- page 5 -->
Restaurant and at our expense, one (1) or more of our representatives for the purpose of training
your employees and management team in the operation of a Franchised Restaurant. During this period,
the representatives will assist in establishing and standardizing procedures and techniques
essential to the operation of a Buffalo Wild Wings business. If you request additional assistance
from us in order to facilitate the opening of the Franchised Restaurant, and if, we, in our
discretion, deem it necessary, feasible and appropriate to comply with the request, you will
reimburse us for our expenses in providing such additional assistance, which may include our
then-current service fee. You agree that during the week preceding the opening, you will have four
(4) full days during which the Restaurant is fully operational and will host two (2) opening
parties.

D. If we determine, in our sole discretion, that you or your manager is unable to satisfactorily
complete the required training program, you will have thirty (30) days to provide an alternate
person to complete the training program at your sole expense. At least three (3) persons actively
involved in the management and operation of the Franchised Restaurant must successfully complete the
training program. If you fail to provide three (3) persons who can complete the training program, we
will have the right to terminate this Agreement and you will not be entitled to a refund of any
portion of the franchise fees paid.

E. From time to time we may provide and if we do, may require that previously-trained and
experienced franchisees, their managers and/or employees attend and successfully complete refresher
training programs or seminars to be conducted at our training facility or at such other place as we
shall designate. Attendance at such refresher training programs or seminars will be at your sole
expense, provided, however, that attendance will not be required at more than two (2) such programs
in any calendar year.

5

V. PROPRIETARY MARKS

A. You acknowledge that our parent company is the owner of all right, title and interest together
with all the goodwill of the Marks and has licensed the use of such Marks to us with the right to
sublicense others. You further acknowledge that your right to use the Marks is derived solely from
this Agreement and is limited to the conduct of business by you pursuant to and in compliance with
this Agreement and all applicable standards, specifications, and operating procedures prescribed by
us from time to time during the term of the Agreement. Any unauthorized use of the Marks by you is a
breach of this Agreement and an infringement of the rights of us in and to the Marks. You
acknowledge that your usage of the Marks and any goodwill established by your use of the Marks shall
inure to the exclusive benefit of us and our affiliate, and that this Agreement does not confer any
goodwill or other interests in the Marks upon you. Any developments and improvements by you relating
to the Marks or the System shall be our sole property. You will not, at any time during the term of
this Agreement or after its termination or expiration, contest the validity or ownership of any of
the Marks or assist any other person in contesting the validity or ownership of the Marks. All
provisions of this Agreement applicable to the Marks apply to any and all additional trademarks,
service marks, and commercial symbols authorized for use by and licensed to you by us after the date
of this Agreement.

B. You will not use any Mark or portion of any Mark as part of a corporate or trade name, or with
any prefix, suffix, or other modifying words, terms, designs, or symbols, or in any modified form.
You will not use any Mark in connection with the sale of any unauthorized product or service or in
any other manner not expressly authorized in writing by us. You shall give such notices of trademark
and service mark registrations as we specify and to obtain such fictitious or assumed name
registrations as may be required under applicable law. Your use of any of the Marks on the
Internet/World Wide Web (including any Home Page) or any other medium must have our prior written
approval. We reserve the right to prohibit your use of the Marks on the Internet.

C. You will promptly notify us of any claim, demand or cause of action based upon or arising from
any attempt by any other person, firm or corporation to use the Marks or any colorable imitation of
the Marks. You shall also notify us of any action, claim or demand against you relating to the Marks
within ten (10) days after you receive notice of said action, claim or demand. Upon receipt of
timely notice of an action, claim or demand against you relating to the Marks, we and our affiliate
shall have the sole right and duty to defend any such action. We and our affiliate will have the
exclusive right to contest or bring action against any third party regarding the third party's use
of any of the Marks and will exercise such right in our and our affiliate's sole discretion. In any
defense or prosecution of any litigation relating to the Marks or components of the System
undertaken by us, you shall cooperate in all respects with us and our affiliate and execute any and
all documents and take all actions as may be desirable or necessary in the opinion of our counsel,
to carry out such defense or prosecution. Both parties shall make every effort consistent with the
foregoing to protect, maintain, and promote the Marks as identifying the System and only the System.

D. If, in our sole discretion, it becomes advisable at any time, for us to modify or discontinue use
of any Mark, and/or use one or more additional or substitute trade names, trademarks, service marks,
or other commercial symbols, either systemwide or with respect to use by any selected franchisee,
you will comply with our directions within a reasonable time after notice to you. We will have no
liability or obligation whatsoever with respect to your modification or discontinuance of any Mark.

E. In order to preserve the validity and integrity of the Marks and
<!-- page 6 -->
copyrighted material licensed to you and to assure that you are properly employing the same in the
operation of your Franchised Restaurant, we and our agents have the right of entry and inspection of
your premises and operating procedures at all reasonable times. We will have the right to observe
the manner in which you are rendering your services and conducting your operations, to confer with
your employees and customers, and to select Menu Items, ingredients, food and

6

non-food products, beverages, and other items, products, delivery vehicles, products and supplies
for test of content and evaluation purposes to make certain that the Menu Items, ingredients, food
and non-food products, beverages and other items, products, delivery vehicles, materials and
supplies are satisfactory and meet our quality control provisions and performance standards.

VI. CONFIDENTIAL MANUALS

A. We will loan to you during the term of the franchise one (1) copy of our Confidential Operations
Manual and other confidential manuals and written materials (all of which are collectively referred
to herein as the "Manuals") containing reasonable, mandatory and suggested specifications,
standards, operating procedures and rules prescribed from time to time by us for Buffalo Wild Wings
businesses and information relative to your other obligations. You will not at any time, without our
prior written consent, copy, duplicate, record or otherwise reproduce the Manuals in whole or in
part or otherwise make the same available to any person. Any authorized duplication or copying of
any of the Manuals shall be performed by us at your expense. We have the right to add to and
otherwise modify, combine, or replace the Manuals from time to time to reflect changes in the
specifications, standards, operating procedures and rules prescribed by us for Buffalo Wild Wings
businesses, provided that no such addition or modification shall alter your fundamental status and
rights under this Franchise Agreement.

B. The Manuals shall at all times remain our sole property and shall promptly be returned upon the
expiration or termination of this Agreement.

C. The Manuals contain our proprietary information which you shall keep confidential both during the
term of the franchise and subsequent to the expiration and/or termination of the franchise. You will
at all times insure that your copy of the Manuals are available at the Franchised Restaurant
premises in a current and up-to-date manner. At all times that the Manuals are not in use by
authorized personnel, you will maintain the Manuals in a locked receptacle at the premises of the
Franchised Restaurant, and will only grant authorized personnel, as defined in the Manuals, access
to the key or lock combination of such receptacle. In the event of any dispute as to the contents of
the Manuals, the terms of the master copy of the Manuals maintained by us at our home office will be
controlling.

VII. CONFIDENTIAL INFORMATION

A. You acknowledge that your entire knowledge of the operation of a Buffalo Wild Wings business,
including, without limitation, the method of preparation of Menu Items and other food products, and
other specifications, recipes, standards and operating procedures of a Buffalo Wild Wings business
is derived from information disclosed to you by us and that such information is proprietary,
confidential and our trade secret. You will maintain the absolute confidentiality of all such
information during and after the term of the franchise and you will not use any such information in
any other business or in any manner not specifically authorized or approved in writing by us.

B. You will divulge such confidential information only to the extent and only to such of your
employees as must have access to it in order to operate the Franchised Restaurant. Any and all
information, knowledge and know-how, including, without limitation, drawings, materials, equipment,
techniques, restaurant systems, product formulae, recipes and other data which we designate as
confidential will be deemed confidential for purposes of this Agreement, except information: 1)
which you can demonstrate lawfully came to your attention prior to disclosure thereof by us, or 2)
which, at the time of disclosure by us to you, had lawfully become a part of the public domain,
through publication or communication by others, or 3) which, after disclosure to you by us, lawfully
becomes a part of the public domain, through publication or communication by others.

7

C. Due to the special and unique nature of our confidential information, Marks and Manuals, you
acknowledge that we will be entitled to immediate equitable remedies, including but not limited to,
restraining orders and injunctive relief in order to safeguard our proprietary, confidential,
unique, and special information and you acknowledge that money damages alone would be an
insufficient remedy with which to compensate us for any breach of the terms of Paragraph V, VI and
VII of this Agreement. All of your employees having access to our confidential and proprietary
information and all of your shareholders, directors, officers, partners and/or members will be
required to execute non-disclosure agreements in the form acceptable to us.

VIII. MODIFICATION OF THE SYSTEM

You acknowledge that from time to time we may change or modify the System presently identified by
the Marks, including, without limitation, the adoption and use of new or modified trade names,
trademarks, service marks or copyrighted
<!-- page 7 -->
materials, new Menu Items, new products, new equipment or new techniques. You will accept, use and
display for the purpose of this Agreement any such changes in the System, as if they were part of
this Agreement at the time of execution. You will make such expenditures as are reasonably required
by such changes or modifications in the System. Except as directed by us, you will not change,
modify or alter the System in any way.

IX. ADVERTISING

Recognizing the value of advertising and the importance of the standardization of advertising and
promotion to the furtherance of the goodwill and the public image of Buffalo Wild Wings businesses,
you agree:

A. Before using any promotional and advertising materials, you will submit to us or our designated
agency, for our prior approval, all information pertaining to promotional materials and advertising
initiated by you, including, but not limited to, newspapers, radio and television advertising,
Internet or any other medium, specialty and novelty items, signs, boxes, napkins, bags and wrapping
papers. In the event written disapproval of any such advertising and promotional material has not
been given by us to you within twenty (20) days from the date such information has been received by
us, the materials will be deemed approved. Your failure to conform with these provisions and
subsequent nonaction by us to require you to cure or remedy any such failure and default will not be
deemed a waiver of future or additional failures and defaults by you under this provision and/or any
other provision of this Agreement. The submission of advertising information to us for our approval
will not affect your right to determine the prices at which you sell your products and/or services.

B. You will contribute to the Buffalo Wild Wings Advertising and Development Fund ("Fund") (which
may be one of several regional Funds, if we elect to establish separate Funds to serve various
regions in which multiple franchisees are located) an amount equal to three percent (3%) of your
Gross Sales, as defined in Paragraph X. Your required payments to the Fund will be made on or before
the fifteenth day of the month for the preceding month. These contributions may be withdrawn from
your bank account as provided in Paragraph X. We will use such funds to conduct local, regional or
national advertising. Such payments shall be made in addition to and exclusive of any sums that you
may be required to spend on system or grand opening advertising and promotion. The Fund shall be
maintained and administered by us or our designee, as follows:

1. We will oversee all advertising programs and have sole discretion over the creative concepts,
materials and media used in such programs including the placement and allocation. We will use the
Fund to conduct national advertising, and/or, if regional Funds are developed, to conduct regional
or local advertising on your behalf, at our sole discretion. We may also use such funds to conduct
advertising in your local advertising market. However, we cannot and do not ensure that any
particular franchisee will benefit directly or pro rata from the placement of advertising.

8

2. For each of our company-owned and affiliate-owned Restaurants (except Special Sites identified in
Paragraph I.C.) offering products and services similar to the Franchised Restaurant we will make
contributions to the Fund or to regional Funds equivalent to the contributions required of
Franchised Restaurants within the System or, if applicable, region in which the company-owned or
affiliate-owned store is located.

3. We will administer and control the Fund and we will have the absolute and unilateral right to
determine how, when and where the monies in the Fund will be spent. This includes the right to use
Fund monies for (1) the creation, development and production of advertising and promotional
materials, (2) any marketing or related research and development, and (3) advertising and marketing
expenses, including without limitation, the absolute right to purchase and pay for product and food
research and development, advertising materials, production costs, brochures, ad slicks, radio, film
and television commercials, videotapes, newspaper, magazine and other print advertising, direct mail
pieces, photographer costs, photographs, pictures, designs, services provided by advertising
agencies, public relations firms or other marketing, research or consulting firms or agencies,
market research and marketing surveys, menu design and graphics, customer incentive programs,
sponsorships, marketing meetings and sales incentives, development of Home Pages on the Internet,
Internet access provider costs, Internet/World Wide Web programming and advertising, subscriptions
to industry newsletters or magazines, marketing or industry studies, books and research materials,
administrative costs and salaries for marketing support personnel. All sums paid by you to the Fund
will be maintained in a separate account from our other funds and shall not be used to defray any of
our general operating expenses, except for such reasonable administrative costs and overhead, if
any, as we may incur in activities reasonably related to the administration or direction of the Fund
and advertising programs including, without limitation, costs incurred in collecting and accounting
for assessments for the Fund.

4. It is our intent that all contributions to the Fund will be expended for advertising and
promotional purposes during our fiscal year within which contributions are made. Any monies not
expended in the fiscal year in which they were contributed will be applied and used for Fund
expenses in the following year.

5. Although we intend the Fund to be of perpetual duration, we have the right to terminate the Fund.
We will not terminate the Fund, however, until all monies in the Fund have been expended for
advertising and promotional purposes.
<!-- page 8 -->
6. An unaudited accounting of Fund contributions and expenditures will be prepared annually and will
be made available to you upon request. At our option, any such annual accounting may include an
audit of the contributions and expenditures of the Fund prepared by an independent certified public
accountant selected by us and prepared at the expense of the Fund.

7. Once you make contributions to the Fund, all such monies will be used as required by this
Paragraph IX and will not be returned to you. C. In addition to your contributions to the Fund, you
may be required to spend up to two percent (2%) of your Gross Sales on approved local advertising.
We may direct that your local advertising expenditures be made either individually or to a local
advertising group as described below.

1. We shall have the right to designate local advertising markets and you will participate in
cooperative advertising and marketing programs in your designated local advertising market as
described in this Paragraph. Each Buffalo Wild Wings and bw-3 Restaurant (except Special Sites
identified in Paragraph I.C.) within the designated local advertising area shall be a member of the
local advertising group and each member shall have one vote on all matters requiring a vote. We
reserve the right to designate the Bylaws which will govern the operation of local advertising
groups.

9

2. If we direct you to spend your advertising funds locally, all such expenditures will be made
directly by you or the local advertising group, subject to approval and direction by us or our
designated advertising agency. You acknowledge that we may direct local advertising to be spent
according to a seasonally adjusted schedule; however, such expenditures shall not exceed two percent
(2%) of your annual Gross Sales. You shall furnish to us an accurate accounting of all expenditures
on local advertising and promotion.

3. You will submit documentation of your advertising expenditures at such times and in such form as
we designate. If you fail to make any required advertising expenditures, we have the right to
require you to contribute the amount of any deficiency to the Fund to be used by us for general
advertising and promotion.

D. We may require you to expend up to FIVE THOUSAND Dollars ($5,000) on newspaper, direct mail or
advertising through other media prior to your opening and during your initial ninety (90) days of
operation of the Franchised Restaurant. We retain the right to collect such funds directly from you
and expend the funds on your behalf. Such advertising and promotion will be designated as "Grand
Opening" advertising and promotion and will be conducted in accordance with the specifications set
forth in the Manuals.

E. You must carry and offer for sale to your customers a representative supply of trademarked
clothing. We may, from time to time, develop and market special promotional items which will be made
available to you at our cost plus a reasonable mark up and you will maintain a representative
inventory of such promotional items to meet public demand. You will have the right to purchase
alternative promotional items provided that such alternative goods conform to the specifications and
quality standards established by us. You will, on an annual basis, participate in a minimum of fifty
percent (50%) of the promotional programs introduced by us from time to time. You will participate
in the specific promotional programs designated by us.

F. You will maintain a business phone and advertise continuously in the classified or Yellow Pages
of a local telephone directory approved by us or such other directories under the listing
"Restaurant", or such other listings as deemed appropriate by us using mats of the type and size
approved in advance by us. We reserve the right to require you to advertise in more than one local
telephone directory. When more than one (1) Buffalo Wild Wings and/or bw-3 restaurant serves a
metropolitan area, classified advertisements shall list all such restaurants operating within the
distribution area of the classified directories, and you shall contribute your equal share in the
cost of such advertisement.

G. You will not use in advertising or any other form of promotion, or in any manner any of the marks
without the appropriate -Registered Trademark- registration mark or the designations TM or SM where
applicable.

X. CONTINUING FEE

A. You will pay us without offset, credit or deduction of any nature, so long as this Agreement is
in effect, a monthly Continuing Fee equal to five percent (5%) of the Gross Sales derived from the
Franchised Restaurant. The Continuing Fee will be paid monthly in the manner specified below or as
otherwise prescribed in the Manuals.

1. We must receive from you within five (5) days after the end of each month, a correct statement of
your Gross Sales for the preceding fiscal month as determined by us on a form approved by us and
signed by you. Each monthly statement of Gross Sales shall be accompanied by the Continuing Fee
payment based on the Gross Sales reported in the statement so submitted. You will make available to
us all original books and records that we may deem necessary to ascertain your Gross Sales for
reasonable inspection at reasonable times.

10

2. The term "Gross Sales", as used in this Agreement, means and
<!-- page 9 -->
includes the total amount of all revenue from the sale of services, products and merchandise and all
income of every kind and nature related to the Franchised Restaurant whether or not sold or
performed at or from the Franchised Restaurant and the proceeds from all games, cover charges,
service, license, use and similar fees collected by the Franchised Restaurant. Gross sales do not
include any sales tax, use tax, or service taxes collected and paid to the appropriate taxing
authority.

B. Prior to the opening of your Restaurant (and thereafter as requested by us), you shall execute
and deliver to us, our bank(s) and your bank, as necessary, all forms and documents that we may
request to permit us to debit your account, either by check, via electronic funds transfer or other
means or such alternative methods as we may designate ("Payment Methods"). You must comply with all
procedures specified by us from time to time to take such actions as we may request to assist in
utilizing any of the Payment Methods. We may use the Payment Methods to collect the amount of each
month's Continuing Fee, Advertising Contributions, and any other amounts due to us or our affiliates
under this Agreement or otherwise. The Continuing Fee shall be withdrawn from your designated bank
account by electronic fund transfer on the fifth of each month for the previous month, or if the
fifth falls on a weekend or bank holiday, then on the next business day. Advertising Contributions
will be withdrawn on the fifteenth of each month or on the next business day. Payments for
commissary purchases will be debited one business day after products are delivered to the
Restaurant. We will determine your Gross Sales by means of the approved information system, or if we
are unable to do so, you shall report your Gross Sales in writing on or before the fifth day of the
month for the preceding month. You shall notify us at least twenty (20) days before closing or
changing the account against which such debits are to be made. If such account is closed or ceases
to be used, you shall immediately provide all documents and information necessary to permit us to
debit the amounts due from an alternative account. You acknowledge that these requirements are only
a method to facilitate prompt and timely payment of amounts due and shall not affect any obligation
or liability for amounts owed. If for any reason your account cannot be electronically debited, you
shall submit payments by check (certified or cashier's check if requested by us) on or before the
dates when due. You shall indemnify, defend and hold us harmless from and against all claims,
damages, losses, costs and expenses resulting from any dishonored debit against your account,
regardless whether resulting from the act or omission of you or your bank; provided that you shall
not be obligated to indemnify us for any dishonored debit caused by our negligence or mistake.

C. All Continuing Fees, Advertising Contributions, amounts due for purchases by you from us and our
affiliates, and other amounts which you owe us or our affiliates shall bear interest after due date
at the highest applicable legal rate for open account business credit, not to exceed one and
one-half percent (1.5%) per month. You acknowledge that this Paragraph does not constitute agreement
by us or our affiliates to accept such payments after same are due or a commitment by us to extend
credit to, or otherwise finance your operation of, the Franchised Restaurant. Further, you
acknowledge that your failure to pay all amounts when due shall constitute grounds for termination
of this Agreement, as provided in Paragraph XVI hereof, notwithstanding the provisions of this
Paragraph.

D. Notwithstanding any designation by you, we have the sole discretion to apply any payments by you
to any past due indebtedness of yours for Continuing Fees, Advertising Contributions, purchases from
us and our affiliates, interest or any other indebtedness. Further, if you are delinquent in the
payment of any fees or indebtedness we have the right to require you to prepay estimated Continuing
Fees and Advertising Contributions.

XI. ACCOUNTING AND RECORDS

A. You will maintain during the term of this Agreement, and preserve for the time period specified
by us, full, complete, and accurate books, records, and accounts in accordance with the standard
accounting

11

system prescribed by us from time to time in writing. You will retain for a period of three (3)
years all books and records related to the Franchised Restaurant, including without limitation,
sales checks, purchase orders, invoices, payroll records, customer lists, check stubs, sales tax
records and returns, cash receipts and disbursement journals and general ledgers. If a computerized
accounting system is developed by us for use throughout the franchise System, you will at your
expense implement and utilize such a system according to the standards and procedures established by
us.

B. You will supply to us on or before the twenty-eighth (28th) day after the end of each fiscal
quarter, in the form approved by us, an activity report and a detailed profit and loss statement,
balance sheet and statement of cash flow for the last preceding fiscal quarter. Additionally, you
will, at your expense, submit to us within ninety (90) days after the end of each fiscal year during
the term of this Agreement, a detailed profit and loss statement and statement of cash flow for such
fiscal year and a balance sheet as of the last day of such fiscal year, prepared on an accrual basis
including all adjustments necessary for fair presentation of the financial statements. Such
financial statements must be certified to be true and correct by you and be reviewed by an
independent certified public account.

C. You will submit to us such other periodic reports, forms and records as specified, and in the
manner and at the time as specified in the Manuals or as we otherwise require in writing from time
to time.

D. You will record all sales on electronic cash registers approved by
<!-- page 10 -->
us or on such other types of cash registers as may be designated by us in the Manuals or otherwise
in writing. We reserve the right to designate the information system used in your Franchised
Restaurant including the computer hardware, software, other equipment and enhancements. At such time
as we designate the approved information system, you will have one hundred eighty (180) days in
which to install and commence using the approved information system. In connection with the approved
information system, you agree to the following:

1. You understand that you will be required to acquire the right to use the information system,
obtain peripheral equipment and accessories and arrange for required maintenance and support
services, all at your cost.

2. We shall have the right at all times to access the information system and to retrieve, analyze,
download and use all software, data and files stored or used on the information system. We may
access the information system in the Franchised Restaurant or from other locations. You shall store
all data and information on the information system that we designate from time to time.

3. All modifications and enhancements made to the approved information system shall be our property
(or the appropriate vendor if we so designate), without regard to the source of the modification or
enhancement. You agree to execute any documents, in the form provided by us, that we determine are
necessary to reflect such ownership.

4. Upon expiration or termination of this Agreement, you shall allow our employees or agents to
remove the required software from the information system, shall immediately return to us the
software, each component thereof, any data generated by the use thereof, all documentation for the
software and other materials or information that relate to or reveal the software and its operation.
You shall immediately destroy any and all back-up or other copies of the software or parts thereof,
and any data generated by the use of the software (other than financial information relating solely
to you).

5. You acknowledge and agree that there will be fees payable by you in connection with the
installation, use, support, maintenance, and periodic enhancements of the approved information
system. These fees will include but are not necessarily limited to an on-site installation and
support fee,

12

software support fees and software maintenance fees. These fees will be payable to us or a vendor
designated by us and may be increased from time to time.

6. You will be required to execute a software license agreement setting forth in more detail your
rights and obligations in connection with your use of the approved information system.

You agree that we have the right to use your data as part of our earnings claim in our Franchise
Offering Circular.

E. We or our designated agents have the right at all reasonable times to examine and copy, at our
expense, your books, records, and tax returns. We also have the right, at any time, to have an
independent audit made of your books and records at our expense. If an inspection reveals that any
payments due to us have been understated in any report to us, then you will immediately pay to us
the amount understated upon demand, in addition to interest from the date such amount was due until
paid, at the maximum rate permitted by law not to exceed one and half percent (1.5%) per month. If
an inspection discloses an understatement in any report of two percent (2%) or more, you will also
reimburse us for any and all costs and expenses connected with the inspection (including, without
limitation, reasonable accounting and attorneys' fees), and we will thereafter have the right to
require you to submit annual financial statements, prepared in accordance with generally accepted
accounting principles, audited by an independent certified public accountant. The foregoing remedies
shall be in addition to any other remedies we may have.

F. You acknowledge that nothing contained in this Agreement constitutes our agreement to accept any
payments after they are due or a commitment by us to extend credit to or otherwise finance your
operation of the Franchised Restaurant. Further, you acknowledge that your failure to pay all
amounts when due constitutes a material default of, and grounds for, termination of this Agreement.

XII. STANDARDS OF QUALITY AND PERFORMANCE

In order to promote and protect the value of the Marks and the System, and to insure optimum quality
control as to products and services provided and sold in Franchised Restaurants, you acknowledge and
agree that substantial uniformity must be maintained in the quality, type and standard of Franchised
Restaurant, and in their facilities, products, services and operations. Therefore, you will comply
with all requirements described in this Agreement, the Manuals and other written policies supplied
by us. Mandatory specifications, standards, operating procedures and rules prescribed from time to
time by us in the Manuals or otherwise communicated to you in writing, shall constitute provisions
of this Agreement as if fully set forth herein. All references herein to this Agreement shall
include all such mandatory specifications, standards and operating procedures and rules.

A. You will commence operation of your Franchised Restaurant within nine (9) months of the execution
of this Agreement or as otherwise required or approved in writing by us. Before opening, you will
have procured all necessary licenses, permits, and approvals, including, but not limited to, liquor
and construction permits; hired and trained personnel, made all leasehold
<!-- page 11 -->
improvements, and acquired initial inventory. At the time of opening you must have a minimum of
Fifty Thousand Dollars ($50,000) in immediately accessible working capital funds to be used solely
to defray the costs of operating the Restaurant for the initial several months. If for any reason
you fail to commence operation within the nine (9) month period, we may terminate this Agreement
immediately upon delivery of written notice of termination to you.

B. You will maintain the condition and appearance of the premises of the Franchised Restaurant
consistent with our quality controls and standards. You will effect reasonable maintenance of the
Franchised Restaurant as is from time to time required to maintain or improve the appearance and
efficient operation of the Franchised Restaurant, including but not limited to replacement of worn
out or obsolete fixtures and signs, repair of the exterior and interior of the premises of the
Franchised Restaurant, and purchasing and installation of new or

13

modified equipment. If at any time in our judgment the general state of repair or the appearance of
the premises of the Franchised Restaurant or its equipment, fixtures, signs or decor does not meet
our quality control and standards therefor, we will notify you, specifying the action to be taken by
you to correct such deficiency. If you fail or refuse to initiate a bona fide program to complete
any required maintenance, within thirty (30) days after receipt of such notice, we will have the
right, but not the obligation, in addition to all other remedies, to enter upon the premises of the
Franchised Restaurant and effect such repairs, painting, maintenance or replacements of equipment,
fixtures or signs on your behalf and you shall pay the entire costs thereof on demand.

C. You will not make any material alterations to the premises of the Franchised Restaurant make any
material replacements of or alterations to the equipment, fixtures or signs of the Franchised
Restaurant without our prior written approval.

D. The Franchised Restaurant may be used solely for the purpose of conducting a Buffalo Wild Wings
Franchised Restaurant. The operating entity (corporation, partnership or limited liability company)
will be dedicated solely to the operation of your Franchised Restaurant(s) and will not hold any
interest in, operate or manage any other business of any kind without our prior written approval.

E. We have developed and own proprietary sauces for use in preparing chicken wings, the weck kaiser
roll and other menu items and specially prepared pocket pizza mix and "Buffalo Breath Chili" mix
("Trade Secret Food Products"). In order to protect our trade secrets and to monitor the
manufacture, packaging, processing and sale of Trade Secret Food Products, we will (i) manufacture,
supply, and sell Trade Secret Food Products to our franchisees; (ii) disclose the formulae for and
methods for preparation of the Trade Secret Food Products to a limited number of suppliers who may
be authorized by us to manufacture Trade Secret Food Products to our precise specifications and sell
Trade Secret Food Products to our franchisees; and/or (iii) disclose the formulae for and methods
for preparation of the pocket pizza mix and the Buffalo Breath Chili mix to you who will be
authorized by us to manufacture them to our precise specifications for sale only at the location of
the Franchised Restaurant specified herein, unless otherwise approved by us. Under no circumstances
will we disclose the formulae for and methods of preparation of any of our proprietary sauces to
you. You acknowledge that you may be required to purchase Trade Secret Food Products (and other
products whose consistency and quality is key to the success of the System) from us or a limited
number of suppliers so authorized by us and will be required to use Trade Secret Food Products as
designated by us.

F. You will offer for sale and sell at the Franchised Restaurant all Menu Items, other food and
beverage products and other products that we from time to time require and shall not offer for sale
or sell at the Franchised Restaurant or the premises which you occupy any unapproved products or
menu items or use such premises for any purpose other than the operation of a Franchised Restaurant
in full compliance with this Agreement. You will offer all Menu Items on a menu specified by us.

G. In order to ensure that all Menu Items produced by you meet our high standards of taste, texture,
appearance and freshness, and in order to protect our goodwill and Marks, all Menu Items and other
food products shall be prepared only by properly trained personnel strictly in accordance with our
recipes, cooking techniques and processes, and the Manuals, and shall be sold only at retail to
customers in conformity with our marketing plan and concept. You acknowledge that such recipes,
cooking techniques and processes are integral to the System and failure to adhere to such recipes,
cooking techniques and processes shall be detrimental to the System and Marks.

H. From time to time, we will provide you with a list of approved manufacturers, suppliers and
distributors ("Approved Suppliers List") and approved inventory products, fixtures, furniture,
equipment, signs, stationery, supplies, and other items or services necessary to operate the
Franchised Restaurant ("Approved Supplies List"). The list will specify the manufacturer, supplier
and distributor and the inventory products,

14

fixtures, furniture, equipment, signs, stationery, supplies and services which we have approved to
be carried or used in the System. We may revise the Approved Suppliers List and Approved Supplies
List from time to time in our sole
<!-- page 12 -->
discretion and such lists shall be submitted to you as we deem advisable. If you propose to offer
for sale at the Franchised Restaurant any brand of product, or to use in the operation of the
Franchised Restaurant any brand of food ingredient or other material or supply which is not then
approved by us as meeting its minimum specifications and quality standards, or to purchase any
product from a supplier that is not then designated by us as an approved supplier, you must first
notify us and shall upon our request submit samples and such other information as we require for
examination and/or testing or to otherwise determine whether such product, material or supply, or
such proposed supplier meets its specifications and quality standards. We may charge you a fee in
connection with such examination and/or testing which will not exceed the reasonable cost of the
inspection and evaluation and the actual cost of the test. In some cases we may refuse to consider
an alternate supplier of certain items. We reserve the right to re-inspect the facilities and
products of any supplier of an approved item and to revoke its approval of any item or supplier
which fails to continue to meet any of our criteria.

I. All inventory, products and materials, and other items and supplies used in the operation of the
Franchised Restaurant which are not specifically required to be purchased in accordance with our
Approved Supplies List and Approved Suppliers List must conform to the specifications and quality
standards established by us from time to time.

J. You will fully comply with all mandatory specifications, standards, operating procedures and
rules as in effect from time to time relating to:

1. The safety, maintenance, cleanliness, sanitation, function and appearance of the Franchised
Restaurant premises and its equipment, fixtures, decor and signs and maintenance and service
agreements therefor;

2. Training, dress, general appearance and demeanor of Franchised Restaurant employees;

3. Type, quality, taste, portion control and uniformity, and manner of preparation, packaging,
displays and sale of all Menu Items, beverages and other food items sold by the Franchised
Restaurant and of all food, beverages and other products used in the preparation and packaging
thereof;

4. The promotion and sale of novelty items bearing the Marks, such as cups, T-shirts and related
merchandise and accessories;

5. Hours during which the Franchised Restaurant will be open for business;

6. Advertising and promotional programs;

7. Use and retention of standard forms;

8. Our recipes;

9. Use and illumination of signs, posters, displays, menu boards and similar items;

10. Your identification as the owner of the Franchised Restaurant;

11. The handling of customer complaints; and

12. Any other standard, specification or procedure designated by us.

15

K. You will secure and maintain in force all required licenses, including liquor licenses, permits
and certificates relating to the operation of the Franchised Restaurant and will operate the
Franchised Restaurant in full compliance with all applicable laws, ordinances and regulations,
including without limitation all government regulations relating to occupational hazards and health,
dispensing of food products, consumer protection, trade regulation, worker's compensation,
unemployment insurance and withholding and payment of Federal and State income taxes and social
security taxes and sales, use and property taxes.

L. You will refrain from any merchandising, advertising or promotional practice which is unethical
or may be injurious to our business and/or the business of other Franchised Restaurants or to the
goodwill associated with the Marks or System.

M. In the operation of the Franchised Restaurant you will use only displays, trays, boxes, bags,
wrapping paper, labels, forms and other paper and plastic products imprinted with the Marks and
colors as prescribed from time to time by us.

N. You acknowledge that the Franchised Restaurant shall at all times maintain an inventory of
ingredients, food and beverage products and other products, materials and supplies that will permit
operation of the Franchised Restaurant at maximum capacity.

O. The Franchised Restaurant shall at all times be under your direct, on-premises supervision,
unless, upon sixty (60) days prior written notice and approval by us you designate a trained and
competent employee to act as full-time general manager. Your designation of a general manager shall
be subject to our prior written approval, and shall further be subject to the designated general
manager successfully completing our training course. All costs for the attendance of the designated
general manager at our training
<!-- page 13 -->
course shall be at your cost, except as set forth in Section IV(A). We will have the right at any
time to revoke our approval of a designated manager. The use of a general manager will in no way
relieve you of your obligations to observe, perform and comply with this Agreement and the Manuals
and to insure that the Franchised Restaurant is properly managed and operated or the responsibility
for the on-site, day to day operation of the Franchised Restaurant. You will employ a sufficient
number of competent and trained employees to insure efficient service to your customers.

P. You will not install or maintain on the premises of the Franchised Restaurant any newspaper
racks, video games, jukeboxes, gaming machines, gum machines, games, rides, vending machines, pool
tables, automated teller machines, or other similar devices without our written approval. The income
derived from any approved machines will be included in gross sales for purposes of your Continuing
Fee and advertising contribution.

Q. You will timely pay all of your obligations and liabilities due to us, our parent, bw-3, Inc.,
our affiliates and other suppliers, lessors and creditors.

R. You will notify us in writing within five (5) days of the commencement of any action, suit, or
proceeding, and of the issuance of any order, writ, injunction, award or decree of any court,
agency, or other governmental instrumentality, which may adversely affect the operation or financial
condition of the Franchised Restaurant.

S. We reserve the right to require you to offer delivery service to customers located within a
reasonable radius of the Franchised Restaurant. As of the date of this Agreement, such delivery
service is at your option. If the Franchised Restaurant offers delivery service to customers located
within its Designated Area, in order to maintain the quality of all food products, the Franchised
Restaurant will not offer delivery service to any customer whose order cannot be delivered within a
reasonable time from when such order is placed, in

16

accordance with our standards. You will charge the same price for products offered by the Franchised
Restaurant whether delivered or sold over the counter in the Franchised Restaurant, plus a
reasonable delivery charge.

XIII. OPERATIONS ASSISTANCE

A. We may from time to time advise or offer guidance to you relative to prices for the food and
other products offered for sale by the Franchised Restaurant that in our judgment constitute good
business practice. Such guidance will be based on our experience in operating and franchising
Restaurants and an analysis of the costs of such products and prices charged for competitive
products. You will not be obligated to accept any such advice or guidance and shall have the sole
right to determine the prices to be charged from time to time by the Franchised Restaurant and no
such advice or guidance shall be deemed or construed to impose upon you any obligation to charge any
fixed, minimum or maximum prices for any product offered for sale by the Franchised Restaurant. We
may from time to time establish promotional practices which you are required to follow such as "free
refill," "buy one and get one free" or similar practices.

B. Before the opening of the Franchised Restaurant we will provide you with the following:

1. A comprehensive list of established sources of equipment, foods, supplies and containers
necessary for the operation of the Franchised Restaurant and provide specifications for such
products;

2. Coordination of product distribution for local, regional and national suppliers; and

3. Regulation of quality standards and products in conformance throughout the network of Franchised
Restaurants.

C. We may furnish you with such assistance in connection with the operation of the Franchised
Restaurant as we reasonably determined to be necessary from time to time. Operations assistance may
consist of advice and guidance with respect to:

1. Proper utilization of procedures to be utilized by the Franchised Restaurant regarding the
service and sale of all Menu Items and other food and beverage items, and related items and
materials as approved by us;

2. Additional products and services authorized for sale by Franchised Restaurants;

3. Purchase of ingredients and other food and beverage items, materials and supplies;

4. The institution of proper administrative, bookkeeping, accounting, inventory control, supervisory
and general operating procedures for the effective operation of the Franchised Restaurant; and

5. Advertising and promotional programs.

D. We will make periodic visits to the Franchised Restaurant for the purposes of consultation,
assistance, and guidance in all aspects of the operation and management of the Franchised Restaurant
as we reasonably determine
<!-- page 14 -->
to be necessary from time to time. We or our representatives who visit the Franchised Restaurant
will prepare, for the benefit of both us and you, written reports with respect to such visits
outlining any suggested changes or improvements in the operations of the Franchised Restaurant and
detailing any defaults in such operations which become evident as a result of any such visit, and a
copy of each such written report shall be provided to both us and you. We will advise you of
problems arising out of the operation of the Franchised

17

Restaurant as disclosed by reports submitted to us by you or by inspections conducted by us of the
Franchised Restaurant.

E. We will provide to you the specifications, Approved Suppliers Lists, Approved Supplies Lists,
training and Manuals at various times between the execution of this Agreement and the opening of the
Franchised Restaurant.

F. In the event you request additional operational assistance or services, we have the right to
condition the rendering of such services upon the payment of a per diem fee and all of our expenses
incurred in rendering the services.

XIV. INSURANCE

A. You will procure at your expense and maintain in full force and effect during the term of this
Agreement, an insurance policy or policies protecting you, us and our designated affiliates, and
their officers, directors, partners and employees against any loss, liability, personal injury,
death, or property damage or expense whatsoever arising or occurring upon or in connection with the
Franchised Restaurant, as we may reasonably require for our own and your protection. We will be
named an additional insured in such policy or policies.

B. The policy or policies shall be written by an insurance company satisfactory to us in accordance
with standards and specifications set forth in the Manuals or otherwise in writing, and shall
include, at a minimum (except as different coverages and policy limits may reasonably be specified
for all franchisees from time to time by us in the Manuals or otherwise in writing) the following:

1. All risks coverage insurance on the Franchised Restaurant and all fixtures, equipment, supplies
and other property used in the operation of the Franchised Restaurant, for full repair and
replacement value of the machinery, equipment, improvements and betterments, without any applicable
co-insurance clause, except that an appropriate deductible clause shall be permitted.

2. Worker's compensation and employer's liability insurance as well as such other insurance as may
be required by statute or rule of the state in which the Franchised Restaurant is located and
operated.

3. Comprehensive general liability insurance and product liability insurance with minimum limits of
ONE MILLION Dollars ($1,000,000) combined single limit including the following coverages:
contractual liability; personal injury; products/completed operation; and tenant's fire legal
liability; insuring against all claims, suits, obligations, liabilities and damages, including
attorneys' fees, based upon or arising out of actual or alleged personal injuries or property damage
resulting from, or occurring in the course of, or on or about or otherwise relating to the
Franchised Restaurant, provided that the required amounts herein may be modified from time to time
by us to reflect inflation or future experience with claims.

4. If you offer delivery service or utilize motor vehicles for any other purpose in the operation of
the Franchised Restaurant, automobile liability insurance, including owned, hired and non-owned
vehicle coverage, with a combined single limit of at least ONE MILLION Dollars ($1,000,000).

5. Such insurance and types of coverage as may be required by the terms of any lease for the
Franchised Restaurant, or as may be required from time to time by us.

6. Liquor liability coverage in a minimum amount of ONE MILLION Dollars ($1,000,000) or such other
amount as may be specified by us.

18

C. The insurance afforded by the policy or policies respecting liability shall not be limited in any
way by reason of any insurance which may be maintained by us. The insurance coverage must commence
as of the date the location of the Franchised Restaurant has been secured. You agree to deliver to
us prior to opening and periodically at any time upon our request, proper certificate evidencing the
existence of the insurance coverage which names us as a named insured. Such certificate shall state
that said policy or policies will not be canceled or altered without at least twenty (20) days prior
written notice to us and shall reflect proof of payment of premiums. Maintenance of such insurance
and the performance by you of the obligations under this Paragraph will not relieve you of liability
under the indemnity provision set forth in this Agreement. Minimum limits as required above may be
modified from time to time, as conditions require, by written notice to you and we may require you
to provide periodic proof of payment of premiums.

D. If you, for any reason, do not procure and maintain such insurance
<!-- page 15 -->
coverage as required by this Agreement, we have the right and authority (without, however, any
obligation to do so) immediately to procure such insurance coverage and to charge same to you, which
charges, together with a reasonable fee for expenses incurred by us in connection with such
procurement, shall be payable by you immediately upon notice.

XV. COVENANTS

A. Unless otherwise specified, the term "you" as used in this Paragraph XV shall include,
collectively and individually, all officers, directors, managers, and holders of a beneficial
interest of your securities, and of any corporation directly or indirectly controlling you, if you
are a corporation, the general and limited partners (including any corporation and the officers,
directors, and holders of a beneficial interest of your securities, of a corporation which controls,
directly or indirectly, any general or limited partner), if you are a partnership, and all members
if you are a limited liability company.

B. You covenant that during the term of this Agreement, except as otherwise approved in writing by
us, you (if you are an individual), a shareholder of a beneficial interest of ten percent (10%) or
more of your securities (if you are a corporation), a general partner of yours (if you are a
partnership), a member (if you are a limited liability company) or your full-time manager approved
by us shall devote full time, energy and best efforts to the management and operation of the
Franchised Restaurant. At all times during the term of this Agreement, the on-site day to day
management and operation of the Franchised Restaurant shall be conducted by someone who has been
approved by us and who has satisfactorily completed our training program.

C. You covenant that during the term of this Agreement, except as otherwise approved in writing by
us, you will not, either directly or indirectly, for yourself, or through, on behalf of, or in
conjunction with any person, persons, partnership, corporation or company:

1. Divert or attempt to divert any business or customer of the Franchised Restaurant to any
competitor, by direct or indirect inducement or otherwise, or do or perform, directly or indirectly,
any other act injurious or prejudicial to the goodwill associated with the Marks or the System.

2. Employ or seek to employ any person who is at that time employed by us, our affiliates, or by any
other franchisee of ours, or otherwise directly or indirectly induce or seek to induce such person
to leave his or her employment thereat.

3. Directly or indirectly, for yourself or through, on behalf of, or in conjunction with any person
or entity, own, manage, operate, maintain, engage in, consult with or have any interest in: a) any
restaurant business, b) any prepared food business, or c) any other business which sells or offers
to dispense prepared food products the same as or similar to the type sold in the System.

19

D. You specifically acknowledge that, pursuant to this Agreement, you will receive valuable training
and confidential information, including, without limitation, information regarding our promotional,
operational, sales and marketing methods and techniques and the System. Accordingly, you covenant
that, except as otherwise approved in writing by us, you will not, for a period of two (2) years
after the expiration or termination of this Agreement, regardless of the cause of termination, or
within two (2) years of the sale of the Franchised Restaurant or any interest in you, either
directly or indirectly, for yourself, or through, on behalf of, or in conjunction with any person or
entity, own, manage, operate, maintain, engage in, consult with or have any interest in: i) any
restaurant business, ii) any prepared food business, or iii) any other business which sells or
offers to dispense prepared food products the same as or similar to the type sold in the System:

1. At the premises of the former Franchised Restaurant;

2. Within a radius of ten (10) miles of the former Franchised Restaurant; or

3. Within a radius of ten (10) miles of the location of any other business using the System, whether
franchised or owned by us or our affiliates.

E. You will not, at any time during or after the term of this Agreement, divulge to any person,
partnership, corporation or any other entity any information, trade secrets, the ingredients,
recipes, cooking techniques and processes, used in the Trade Secret Food Products, and other food
and beverage products and Menu Items used in the System or any information stated in the Manuals.

F. The parties agree that each of the foregoing covenants shall be construed as independent of any
other covenant or provision of this Agreement. If all or any portion of a covenant in this Paragraph
XV is held unreasonable or unenforceable by a court or agency having valid jurisdiction in an
unappealed final decision to which we are a party, you will be bound by any lesser covenant subsumed
within the terms of such covenant that imposes the maximum duty permitted by law, as if the
resulting covenant were separately stated in and made a part of this Paragraph XV.

G. You understand and acknowledge that we have the right, in our sole discretion, to reduce the
scope of any covenant set forth in Paragraphs XV.C. and XV.D. in this Agreement, or any portion
thereof, without your consent,
<!-- page 16 -->
effective immediately upon receipt by you of written notice thereof, and you shall comply forthwith
with any covenant as so modified, which shall be fully enforceable notwithstanding the provisions of
Paragraph XXVI hereof.

H. We have the right to require all of your current and future shareholders, directors, officers,
partners, members, managers and all personnel performing managerial or supervisory functions and all
personnel receiving training from us to execute similar covenants in a form satisfactory to us.

XVI. DEFAULT AND TERMINATION

A. If you are in substantial compliance with this Agreement and we materially breach this Agreement
and fail to cure such breach within a reasonable time after written notice thereof is delivered to
us, you may terminate this Agreement. "Reasonable time," as used herein, shall be construed as
allowing us at least thirty (30) days within which to commence curing any such material breach. Such
termination shall be effective thirty (30) days after delivery to us of written notice that such
breach has not been cured and you elect to terminate this Agreement. An attempted termination of
this Agreement by you except as provided in this Paragraph shall be deemed a termination without
cause and a breach of this Agreement.

20

B. This Agreement shall terminate automatically upon delivery of written notice of termination to
you, if you or any shareholder, officer, partner, member or manager:

1. Fails to satisfactorily complete the training program, including the opportunity to provide an
alternate manager, as provided in Paragraph IV of this Agreement;

2. Has made any material misrepresentation or omission in your application for the franchise;

3. Is convicted of or pleads no contest to a felony or other crime or offense that is likely to
adversely affect your reputation, the Franchised Restaurant, or the goodwill associated with the
Marks or System;

4. Makes any unauthorized use, disclosure or duplication of any portion of the Manuals or duplicates
or discloses or makes any unauthorized use of any trade secret or confidential information provided
to you by us;

5. Abandons or fails or refuses to actively operate the Franchised Restaurant for more than five (5)
days in any twelve (12) month period or for more than two (2) consecutive business days in any
twelve (12) month period, unless the Franchised Restaurant has been closed for a purpose approved by
us or due to force majeure, or fails to relocate to approved premises within an approved period of
time following expiration or termination of the lease for the premises of the Franchised Restaurant;

6. Surrenders or transfers control of the operation of the Franchised Restaurant, makes an
unauthorized direct or indirect assignment of the franchise or an ownership interest in you or fails
or refuses to assign the franchise or the interest in you of a deceased or disabled controlling
owner thereof as herein required;

7. Submits to us on five (5) or more separate occasions at any time during the term of this
Agreement or on two (2) or more separate occasions during any twelve (12) month period any reports
or other data, information or supporting records which understate by more than two percent (2%) the
Continuing Fees for any period of, or periods aggregating, three (3) or more months, and you are
unable to demonstrate that such understatements resulted from inadvertent error;

8. Commits any affirmative act of insolvency, or files any petition or action of insolvency, or for
appointment of a receiver or trustee, or makes any assignment for the benefit of creditors, or fails
to vacate or dismiss within sixty (60) days after filing any such proceedings commenced against you
by a third party;

9. Materially misuses or makes an unauthorized use of any Marks or commits any act which can
reasonably be expected to materially impair the goodwill associated with any Marks;

10. Materially misuses or makes an unauthorized use of our Proprietary Software Program;

11. Fails on three (3) or more separate occasions within any period of twelve (12) consecutive
months or eight (8) or more separate occasions at any time during the term of this Agreement to
submit when due reports or other information or supporting records, to pay when due the Continuing
Fees, advertising contributions, amounts due for purchases from us and our affiliates or other
payments due to us and our affiliates, or otherwise fails to comply with this Agreement, whether or
not such failures to comply are corrected;

21

12. Continues after written notice from us and/or any governmental authority to violate any health,
safety or sanitation law, ordinance or regulation or operates the Franchised Restaurant in a manner
that presents a health or safety hazard to your customers or the public;
<!-- page 17 -->
13. Fails to commence operations within nine (9) months after execution of this Agreement, or as
otherwise required or approved in writing by us; or

14. Defaults under the lease, if any, for the Franchised Restaurant.

C. This Agreement shall terminate at our sole option without further action by us or notice to you
if you or your owner:

1. Fails or refuses to make payments of any amounts due to us or our affiliates for Continuing Fees,
advertising contributions, purchases from us or our affiliates or any other amounts due to us or our
affiliates, and does not correct such failure or refusal within ten (10) days after written notice
of such failure is delivered to you;

2. Fails or refuses to comply with any other provision of this Agreement, or any mandatory
specification, standard or operating procedure prescribed in the Manuals or otherwise in writing,
and does not correct such failure within thirty (30) days (or provide proof acceptable to us that
you have made all reasonable efforts to correct such failure and will continue to make all
reasonable efforts to cure until a cure is effected if such failure cannot reasonably be corrected
within thirty (30) days) after written notice of such failure to comply is delivered to you.

3. Fails to devote your best efforts to adequately represent the Franchised Restaurant in your
Designated Area through your sales and service efforts and does not correct such failure within
thirty (30) days (or provide proof acceptable to us that you have made all reasonable efforts to
correct such failure and will continue to make all reasonable efforts to cure until a cure is
effected if such failure cannot reasonably be corrected within thirty (30) days) after written
notice of such failure to comply is delivered to you.

D. To the extent that the provisions of this Agreement provide for periods of notice less than those
required by applicable law, or provide for termination, cancellation, non-renewal or the like other
than in accordance with applicable law, such provisions shall, to the extent such are not in
accordance with applicable law, not be effective, and we will comply with applicable law in
connection with each of these matters.

E. In addition to our right to terminate this Agreement, and not in lieu of such right or any other
rights against you, we, in the event that you have not cured a default under this Agreement within
the twenty (20) days after receipt of a written notice to cure from us, may, at our option, enter
upon the premises of the Franchised Restaurant and exercise complete authority with respect to the
operation of the Franchised Restaurant until such time as we determine that your default has been
cured and that there is compliance with the requirements of this Agreement. You specifically
acknowledge that our designated representative may take over, control, and operate the Franchised
Restaurant, and that you will pay us a service fee of not less than TWO HUNDRED Dollars ($200) per
day plus all travel expenses, room and board and other expenses reasonably incurred by such
representative so long as it shall be required by the representative to enforce compliance herewith.
You further acknowledge that if, as herein provided, we temporarily operate for you the Franchised
Restaurant, you will indemnify, defend and hold us harmless and any representative of ours who may
act hereunder, from any and all claims arising from the operation of the Franchised Restaurant,
including without limitation, acts and omissions of us or our representatives.

22

XVII. RIGHTS AND DUTIES OF PARTIES UPON EXPIRATION OR TERMINATION

Upon termination or expiration, this Agreement and all rights granted hereunder to you will
forthwith terminate, and:

A. You will immediately cease to operate the Franchised Restaurant under this Agreement, and shall
not thereafter, directly or indirectly, represent to the public or hold yourself out as a present or
former franchisee of ours.

B. Upon our demand, you will assign to us your interest in any lease then in effect for the
Franchised Restaurant premises.

C. You will immediately and permanently cease to use, by advertising or in any manner whatsoever,
any confidential methods, procedures, and techniques associated with the System; the Marks and
distinctive forms, slogans, signs, symbols, logos, or devices associated with the System. In
particular, you will cease to use, without limitation, all signs, advertising materials, stationery,
forms, and any other articles which display the Marks associated with the System.

D. You will take such action as may be necessary to cancel or assign to us or our designee, at our
option, any assumed name rights or equivalent registration filed with state, city, or county
authorities which contains the name "Buffalo Wild Wings," "bw-3" or any Mark, and you will furnish
us with evidence satisfactory to us of compliance with this obligation within thirty (30) days after
termination or expiration of this Agreement.

E. You will, in the event you continue to operate or subsequently begin to operate any other
business, not use any reproduction, counterfeit, copy or colorable imitation of the Marks either in
connection with such other business or the promotion thereof, which is likely to cause confusion,
mistake or deception, or which is likely to dilute our exclusive rights in and to the Marks
<!-- page 18 -->
and will not utilize any designation of origin or description or representation which falsely
suggests or represents an association or connection with us so as to constitute unfair competition.
You will make such modifications or alterations to the premises of the Franchised Restaurant
(including, without limitation, the changing of the telephone number) immediately upon termination
or expiration of this Agreement as may be necessary to prevent any association between us or the
System and any business thereon subsequently operated by you or others, and will make such specific
additional changes thereto as we may reasonably request for that purpose, including, without
limitation, removal of all distinctive physical and structural features identifying the System. In
the event you fail or refuse to comply with the requirements of this Paragraph XVII, we have the
right to enter upon the premises where your Franchised Restaurant was conducted, without being
guilty of trespass or any other tort, for the purpose of making or causing to be made such changes
as may be required at your expense, which expense you will pay upon demand.

F. You will promptly pay all sums owing to us and our affiliates. In the event of termination for
any default, such sums will include all damages, costs, and expenses, including reasonable
attorneys' fees, incurred by us as a result of the default.

G. You will pay to us all damages, costs and expenses, including reasonable attorneys' fees,
incurred by us in obtaining injunctive or other relief for the enforcement of any provisions of this
Agreement.

H. You will immediately return to us at your cost all Manuals, our Proprietary Software Program,
customer lists, records, files, instructions, brochures, agreements, disclosure statements, and any
and all other materials provided by us to you relating to the operation of the Franchised Restaurant
(all of which are acknowledged to be our property).

23

I. We will have the right, title and interest to any sign or sign faces bearing the Marks. You
hereby acknowledge our right to access the premises of the Franchised Restaurant if we elect to take
possession of any sign or sign faces bearing the Marks.

J. You hereby acknowledge that all telephone numbers used in the operation of the Franchised
Restaurant constitute assets of the Franchised Restaurant; and upon termination or expiration of
this Agreement you will assign to us or our designee, all right, title, and interest in and to your
telephone numbers and will notify the telephone company and all listing agencies of the termination
or expiration of your right to use any telephone number and any regular, classified or other
telephone directory listing associated with the Marks and to authorize a transfer of same to or at
our direction.

K. We will have the right (but not the duty), to be exercised by notice of intent to do so within
sixty (60) days after termination or expiration, to purchase for cash any or all assets of the
Franchised Restaurant, including leasehold improvements, equipment, supplies, and other inventory,
advertising materials, and all items bearing the Marks, at your cost or fair market value, whichever
is less. You acknowledge that, pursuant to Paragraph XVII.I. of this Agreement, all signs and sign
faces bearing the Marks are specifically excluded from this provision as such signs and sign faces
are deemed to be our property. If the parties cannot agree on fair market value within a reasonable
time, the determination of fair market value shall be determined by an appraiser selected by us and
you. If you and we cannot agree on a single appraiser, each party shall select one appraiser, who
together will select a third appraiser and the fair market value will be the average of the three
(3) independent appraisers. Each party will pay their own appraiser and the cost of the third
appraiser will be shared equally by the parties. If we elect to exercise any option to purchase as
herein provided, we have the right to set off all amounts due from you under this Agreement, if any,
against any payment therefor.

L. You will comply with the covenants contained in Paragraph XV of this Agreement.

XVIII. TRANSFERABILITY OF INTEREST

A. This Agreement and all rights hereunder can be assigned and transferred by us and, if so, shall
be binding upon and inure to the benefit of our successors and assigns.

B. This Agreement, and your rights and obligations under it, are and shall remain personal to you.
The term "Transfer" shall mean any sale, assignment, gift, pledge, mortgage or any other
encumbrance, transfer by bankruptcy, transfer by judicial order, merger, consolidation, share
exchange, transfer by operation of law or otherwise, whether direct or indirect, voluntary or
involuntary, of this Agreement or any interest in it, or any rights or obligations arising under it,
or of any material portion of your assets, or of any interest in you. You (and your shareholders,
partners and members) will not directly or indirectly make a Transfer without our prior written
consent. We will not withhold our consent to a Transfer, subject to all of the following conditions
being satisfied:

1. You are in full compliance with this Agreement, you have no uncured defaults, all your fees,
debts and financial obligations to us, our affiliates and the Fund are current, and you are current
in your required local advertising expenditures;

2. You execute a written agreement in a form satisfactory to us in which you and your owners
covenant to observe all applicable post-term obligations and covenants contained in this Agreement;
<!-- page 19 -->
3. The proposed transferee enters into a written agreement in a form satisfactory to us assuming and
agreeing to discharge all of your obligations and covenants under this Agreement for the remainder
of its term or, at our option, execute our then-current standard form of franchise agreement (which

24

may provide for different fees, advertising requirements, duration, and other rights and obligations
from those provided in this Agreement);

4. The proposed transferee agrees in writing to perform such maintenance, remodeling and
re-equipping of the Restaurant that we determine necessary to bring the Restaurant in compliance
with our then-current standards;

5. Prior to the date of the proposed Transfer, the proposed transferee's management team
successfully completes such training and instruction as we deem necessary;

6. We are satisfied that the proposed transferee (and if the proposed transferee is an entity, all
holders of any interest in such entity) meets all of the requirements for our new franchisees
applicable on the date we receive notice of the proposed transfer and including, but not limited to,
good reputation and character, business experience, restaurant management experience, and financial
strength and liquidity;

7. You and all holders of an interest in you execute a general release, in the form prescribed by
us, releasing, to the fullest extent permitted by law, all claims that you or any of your investors
may have against us and our affiliates, including our and their respective shareholders, officers,
directors and employees, in both their individual and corporate capacities;

8. You pay us a transfer fee equal to one-half (1/2) of the then-current Initial Franchise Fee; and

9. We waive our right of first refusal under Paragraph XX.

C. Application for our consent to a transfer and tender of the right of first refusal provided for
in Paragraph XX, will be accompanied by the documents (including a copy of the proposed purchase or
other transfer agreement) or other information required by us. Any agreement used in connection with
a transfer including a lease or management agreement, shall be subject to our prior written
approval.

D. In the event you are a corporation, partnership, limited liability company or other entity, any
transfer of stock (or other form of ownership interest) constituting a controlling interest in you
will be subject to the consent, right of first refusal, transfer fee and all other applicable
provisions of this Agreement. For purposes of this Paragraph XVIII, any change in the percentage you
owned, directly or indirectly, by any person or entity who directly or indirectly owns an interest
in you (including any addition or deletion of any such person or entity) which results in a change
in forty-nine percent (49%) or more of your ownership or any series of changes in the percentage you
owned, directly or indirectly, by any such person or entity (including any addition or deletion of
any such person or entity) which results within a period of three (3) years in any change in
forty-nine percent (49%) or more of your ownership shall be deemed a transfer of a controlling
interest in you. Any individual transfer of an interest less than a controlling interest in you or
the Franchised Restaurant must have our prior written consent, which will not be unreasonably
withheld, but will not be subject to our right of first refusal or the payment of the transfer fee.
You will however, reimburse us for its out-of-pocket expenses incurred in approving the transfers
including our attorneys' fees. Any person who acquires any interest in you, this Agreement or the
Franchised Restaurant must execute the Owner Agreement attached as EXHIBIT A to this Agreement.

E. You will not, without our prior written consent, place in, on or upon the location of the
Franchised Restaurant, or in any communication media, any form of advertising, or list with any
business, real estate broker, agent, or attorney any information relating to the sale of the
Franchised Restaurant or the rights granted hereunder.

25

XIX. YOUR DEATH OR INCAPACITY

A. In the event of your death or incapacity, or the death or incapacity of any partner, any
shareholder owning fifty percent (50%) or more of your capital stock, or any Member who owns a
majority interest in a limited liability company, the heirs, beneficiaries, devisees, or legal
representatives of said individual, partner or shareholders shall, within one hundred eighty (180)
days of such event:

1. Apply to us for the right to continue to operate the franchise for the duration of the term of
this Agreement and any renewals hereof, which right shall be granted upon the fulfillment of all of
the conditions set forth in Paragraph XVIII. of this Agreement (except that no transfer fee shall be
required); or

2. Sell, assign, transfer, or convey your interest in compliance with the provisions of Paragraphs
XVIII and XX of this Agreement; provided,
<!-- page 20 -->
however, in the event a proper and timely application for the right to continue to operate has been
made and rejected, the one hundred eighty (180) days to sell, assign, transfer or convey shall be
computed from the date of said rejection. For purposes of this Paragraph, our silence on an
application made pursuant to Paragraph XIX.A.1. through the one hundred and eighty (180) days
following the event of death or incapacity shall be deemed a rejection made on the last day of such
period.

B. In the event of the death or incapacity of an individual franchisee, or any partner or
shareholder of you which is a partnership or corporation, where the aforesaid provisions of
Paragraph XVIII have not been fulfilled within the time provided, all rights licensed to you under
this Agreement shall, at our option, terminate forthwith and we will have the option to purchase the
assets of the Franchised Restaurant in accordance with Paragraph XVII.K. herein.

XX. RIGHT OF FIRST REFUSAL

If you or your owners propose to sell the Franchised Restaurant (or its assets) or a controlling
interest in the ownership of you as defined in Paragraph XVIII, you or your owners will obtain and
deliver a bona fide, executed written offer to purchase same to us, which shall, for a period of
thirty (30) days from the date of delivery of such offer to us, have the right, exercisable by
written notice to you or your owners, to purchase the Franchised Restaurant, (its assets) or an
ownership interest in you for the price and on the terms and conditions contained in such offer,
provided that we may substitute cash for any form of payment proposed in such offer. If we do not
exercise this right of first refusal, you may accept the offer, subject to our prior written
approval, as provided in Paragraph XVIII hereof, provided that if such offer is not so accepted
within six (6) months of the date thereof, we will again have the right of first refusal herein
described.

XXI. OPERATION IN THE EVENT OF ABSENCE, DISABILITY OR DEATH

In order to prevent any interruption of the Franchised Restaurant which would cause harm to the
Franchised Restaurant and thereby depreciate the value thereof, you authorize us, in the event that
you are absent or incapacitated by reason of illness or death and are not, therefore, in our sole
judgment, able to operate the Franchised Restaurant, to operate the Franchised Restaurant for so
long as we deem necessary and practical, and without waiver of any other rights or remedies we may
have under this Agreement. Provided, however, that we shall not be obligated to so operate the
Franchised Restaurant. All monies from the operation of the business during such period of operation
by us shall be kept in a separate account and the expenses of the Franchised Restaurant, including
reasonable compensation and expenses for our representative, shall be charged to said account. If,
as herein provided, we temporarily operate for you the Franchised Restaurant, you will indemnify and
hold us harmless and any representative of ours who may act hereunder, from any and all claims
arising from

26

the operation of the Franchised Restaurant, including, without limitation, our acts and omissions
and acts and omissions of our representatives.

XXII. INDEPENDENT CONTRACTOR AND INDEMNIFICATION

A. This Agreement does not make, appoint or constitute you as our agent, legal representative, joint
venturer, partner, employee, or servant for any purpose whatsoever. You cannot represent to third
parties that you are our agent and it is understood between the parties that you will be an
independent contractor who is in no way authorized to make any contract, agreement, warranty or
representation on our behalf, or to create any obligation, express or implied, on our behalf. As an
independent entrepreneur, you are solely responsible for the control, management and day-to-day
operation of the Franchised Restaurant, including but not limited to, such matters as determining
the prices at which you will offer and sell approved products and services, hiring and discharging
your employees and setting and paying wages and benefits of your employees and that we will have no
power, responsibility or liability with respect to such pricing, hiring, discharging, setting and
paying of wages or related matters. All standards of quality and performance, including those listed
in Paragraph XII, are established to promote and protect the value of the Marks and the System and
to insure optimum quality control as to products and services. You alone are responsible for the
food production and preparation at the Franchised Restaurant.

B. You will prominently display, by posting of a sign within public view, on or in the premises of
the Franchised Restaurant, a statement that clearly indicates that the Franchised Restaurant is
independently owned and operated by you as a franchisee and not as an agent.

C. You agree to indemnify, defend and hold us and our affiliates harmless from and against any and
all claims, losses, damages and liabilities, however caused, arising directly or indirectly from, as
a result of, or in connection with, the use and operation of the Franchised Restaurant, as well as
the costs, including attorneys' fees, of defending against them (hereinafter are "Franchise
Claims"). Franchise Claims include, but are not limited to, those arising from any death, personal
injury or property damage (whether caused wholly or in part through our active or passive
negligence), latent, or other defects in the Franchised Restaurant, or your employment practices. In
the event a Franchise Claim is made against us, we reserve the right in our sole discretion to
select our own legal counsel to represent our interests and you will reimburse us for our attorneys'
fees immediately upon our request as they are incurred.
<!-- page 21 -->
XXIII. MISCELLANEOUS

A. Our failure to exercise any power reserved to us hereunder, or to insist upon strict compliance
by you with any obligation or condition hereunder, and any custom or practice of the parties in
variance with the terms hereof, shall not constitute a waiver of our right to demand exact
compliance with the terms hereof. Our waiver of any default by you shall not be binding unless in
writing and executed by us and shall not affect or impair our right with respect to any subsequent
default of the same or of a different nature.

B. Any and all notices required or permitted under this Agreement shall be in writing and shall be
personally delivered, mailed by certified mail, return receipt requested, or sent overnight courier
to the respective parties at the following addresses unless and until a different address has been
designated by written notice to the other party:

Notices to Us: bw-3 FRANCHISE SYSTEMS, INC. 1919 Interchange Tower 600 South Highway 169
Minneapolis, Minnesota 55426

27

Copy to Mary Beth Brody, Esq. Fredrikson & Byron, P.A. 1100 International Centre 900 Second Avenue
South Minneapolis, MN 55402

Notices to You: At the address specified on Page 1 of this Agreement.

Copy to: -------------------------------

-------------------------------

-------------------------------

Any notice by certified mail shall be deemed to have been given at the date and time of mailing. If
you fail to provide us with written notice of alleged breach of this Agreement or any other legal
claims within one (1) year from the date that you have knowledge of or becomes aware of such breach
or grounds for claim, then the alleged breach or claim shall be deemed waived.

C. In the event either party brings an action to enforce the terms of this Agreement or to enjoin
the violation of any of its terms and prevails, such party shall be entitled to recover all
litigation costs including attorneys' fees.

D. This Agreement and the Exhibits attached shall be construed together and constitute the entire,
full and complete agreement between the parties concerning the subject matter hereof, and supersede
all prior agreements. No other representation has induced you to execute this Agreement, and there
are no representations, inducements, promises, or agreements, oral or otherwise, between the parties
not embodied herein, which are of any force or effect with reference to this Agreement or otherwise.
No amendment, change or variance from this Agreement shall be binding on either party unless
executed in writing, signed by both parties.

E. Each Paragraph, part, term and/or provision of this Agreement shall be considered severable, and
if, for any reason, any Paragraph, part, term and/or provision herein is determined to be invalid
and contrary to, or in conflict with any existing or future law or regulation, such shall not impair
the operation of or affect the remaining portions, sections, parts, terms and/or provisions of this
Agreement, and the latter will continue to be given full force and effect and bind the parties
hereto; and said invalid sections, parts, terms and/or provisions shall be reformed to most nearly
implement the intentions of the parties hereto or, if reformation is not possible, be deemed not
part of this Agreement; provided, however, that if we determine that said finding of illegality
adversely affects the basic consideration of this Agreement, we may, at our option, terminate this
Agreement. Anything to the contrary herein notwithstanding, nothing in this Agreement is intended,
nor shall be deemed, to confer upon any person or legal entity other than you and us and such of
their respective successors and assigns as may be contemplated by this Agreement, any rights or
remedies under or by reason of this Agreement.

XXIV. APPLICABLE LAW

A. THIS AGREEMENT TAKES EFFECT UPON ITS ACCEPTANCE AND EXECUTION BY US, AND SHALL BE INTERPRETED AND
CONSTRUED UNDER THE LAWS OF THE STATE IN WHICH THE FRANCHISED RESTAURANT IS LOCATED, EXCEPT TO THE
EXTENT GOVERNED BY THE UNITED STATES TRADEMARK ACT OF 1946 (LANHAM ACT, 15, U.S.C. SECTIONS 1051 ET
SEQ). YOU AGREE THAT ANY DISPUTES BETWEEN YOU AND US, bw-3, INC. OR OUR OTHER AFFILIATES SHALL ALSO
BE CONSTRUED UNDER THE LAWS OF THE STATE IN WHICH THE FRANCHISED RESTAURANT IS LOCATED.

28

B. ANY ACTION SOUGHT TO BE BROUGHT BY EITHER PARTY OR ANY ACTION BROUGHT BY YOU AGAINST OUR PARENT
OR OTHER AFFILIATE, SHALL BE BROUGHT IN THE UNITED STATES DISTRICT COURT OR THE STATE DISTRICT COURT
IN THE STATE IN WHICH
<!-- page 22 -->
OUR COMPANY HEADQUARTERS ARE LOCATED. AS OF THE DATE OF THIS AGREEMENT, THE LOCATION IS HENNEPIN
COUNTY, MINNESOTA. THE PARTIES DO HEREBY WAIVE ALL QUESTIONS OF PERSONAL JURISDICTION OR VENUE FOR
THE PURPOSES OF CARRYING OUT THIS PROVISION.

C. NO RIGHT OR REMEDY CONFERRED UPON OR RESERVED TO US OR YOU BY THIS AGREEMENT IS INTENDED TO BE,
NOR SHALL BE DEEMED, EXCLUSIVE OF ANY OTHER RIGHT OR REMEDY HEREIN OR BY LAW OR EQUITY PROVIDED OR
PERMITTED, BUT EACH SHALL BE CUMULATIVE OF EVERY OTHER RIGHT OR REMEDY.

D. NOTHING HEREIN CONTAINED SHALL BAR OUR RIGHT TO OBTAIN INJUNCTIVE RELIEF AGAINST THREATENED
CONDUCT THAT WILL CAUSE US LOSS OR DAMAGES, UNDER THE USUAL EQUITY RULES, INCLUDING THE APPLICABLE
RULES FOR OBTAINING RESTRAINING ORDERS AND PRELIMINARY INJUNCTIONS.

XXV. DISPUTE RESOLUTION

A. The parties have entered into this Agreement in good faith and in the belief that it is mutually
advantageous to them. It is with that same spirit of cooperation that they pledge to attempt to
resolve any dispute amicably without the necessity of litigation. Accordingly, they agree that
except as set forth below, if any dispute arises between them relating to this Agreement that prior
to the commencement of any legal action to interpret or enforce this Agreement, they will first use
the procedures specified in this Section.

B. The party seeking to initiate the procedure shall give written notice to the other party,
describing in general terms the nature of the dispute, the claim for relief and identifying one or
more individuals with authority to settle the dispute on such party's behalf. The party receiving
such notice shall have ten (10) business days within which to designate by written notice one or
more individuals with authority to settle the dispute on such party's behalf.

C. The authorized individuals shall be entitled to make such investigation of the dispute as they
deem appropriate, but agree to meet promptly, and in no event later than thirty (30) days from the
date of the initial written notice, to discuss resolution of the dispute. The authorized individuals
shall meet at such times and places and with such frequency as they may agree. If the dispute has
not been resolved within thirty (30) days from the date of their initial meeting, the parties shall
cease direct negotiations and shall submit the dispute to mediation in accordance with the following
procedure.

D. The authorized individuals shall have five (5) business days from the date they cease direct
negotiations to submit to each other a written list of acceptable qualified mediators not affiliated
with any of the parties. Within five (5) days from the date of receipt of such list, the authorized
individuals shall rank the mediators in numerical order of preference and exchange such rankings. If
one or more names are on both lists, the highest ranking person shall be designated as the mediator.
If no mediator has been selected under this procedure, the parties agree jointly to request the
local administrative judge of the County in which our corporate headquarters are situated to supply
within ten (10) business days a list of potential qualified mediators. Within five (5) business days
of receipt of the list, the parties shall again rank the proposed mediators in numerical order of
preference and shall simultaneously exchange such lists and shall select as the mediator the
individual

29

receiving the highest combined ranking. If such mediator is not available to serve, they shall
proceed to contact the mediator who was next highest in ranking until they are able to select a
mediator.

E. In consultation with the mediator selected, the parties shall promptly designate a mutually
convenient time and place for the mediation, and unless circumstances require otherwise, such time
is to be not later than forty-five (45) days after selection of the mediator. In the event any party
to this Agreement has substantial need for information in the possession of another party to this
Agreement in order to prepare for the mediation, all parties shall attempt in good faith to agree on
procedures for the expeditious exchange of such information, with the help of the mediator if
required. At least seven (7) days prior to the first scheduled session of the mediation, each party
shall deliver to the mediator and to the other party a concise written summary of its views on the
matter in dispute, and such other matters required by the mediator. The mediator may also request
that a confidential issue paper be submitted to him by each party.

F. In the mediation, each party shall be represented by an authorized individual and may be
represented by counsel. In addition, each party may, with permission of the mediator, bring such
additional persons as are needed to respond to questions, contribute information and participate in
the negotiations.

G. The mediator shall determine the format for the meetings, designed to assure that both the
mediator and the authorized individuals have an opportunity to hear an oral presentation of each
party's views on the matter in dispute, and that the authorized parties attempt to negotiate a
resolution of the matter in dispute, with or without the assistance of counsel or others, but with
the assistance of the mediator. To this end, the mediator is authorized to conduct both joint
meetings and separate private caucuses with the parties. The mediation session shall be private. The
mediator will keep confidential all information learned in private caucus with any party unless
specifically
<!-- page 23 -->
authorized by such party to make disclosure of the information to the other party. The parties agree
to sign a document agreeing that the mediator shall be governed by the provisions of the local Rules
of Civil Procedure and such other rules as the mediator shall prescribe. The parties commit to
participate in the proceedings in good faith with the intention of resolving the dispute, if at all
possible.

H. The parties agree to participate in the mediation procedure to its conclusion. The mediation
shall be terminated (i) by the execution of a settlement agreement by the parties, (ii) by a
declaration of the mediator that the mediation is terminated, or (iii) by a written declaration of a
party to the effect that the mediation process is terminated at the conclusion of one full day's
mediation session. Even if the mediation is terminated without a resolution of the dispute, the
parties agree not to terminate negotiations and not to commence any legal action or seek other
remedies prior to the expiration of five (5) days following the mediation. The fees and expenses of
the mediator shall be shared equally by the parties. The mediator shall be disqualified as a
witness, consultant, expert or counsel for any party with respect to the dispute and any related
matters.

I. Mediation is a compromise negotiation for purposes of the Federal and State Rules of Evidence and
constitutes privileged communication. The entire mediation process is confidential, and no
stenographic, visual or audio record shall be made. All conduct, statements, promises, offers, views
and opinions, whether oral or written, made in the course of the mediation by any party, by their
agents, employees, representatives or other invitees and by the mediator are confidential and shall,
in addition and where appropriate, be deemed to be privileged. Such conduct, statements, promises,
offers, views and opinions shall not be discoverable or admissible for any purposes, including
impeachment, in any litigation or other proceeding involving the parties, and shall not be disclosed
to anyone not an agent, employee, expert, witness, or representative of any of the parties; provided
however, that evidence otherwise discoverable or admissible is not excluded from discovery or
admission as a result of its use in the mediation.

30

J. Nothing herein contained shall bar our right to seek and obtain temporary injunctive relief from
a court of competent jurisdiction in accordance with applicable law against any conduct or
threatened conduct by you which could impair the goodwill associated with the Marks.

K. The parties (and their respective owners) agree to waive, to the fullest extent permitted by law,
the right to or claim for any punitive or exemplary damages against the other and agree that in the
event of a dispute between them, each will be limited to the recovery of actual damages sustained.

XXVI. OWNER AGREEMENT

The franchisee ("you") includes all persons who succeed to the interest of the original franchisee
by permitted transfer or operation of law and shall be deemed to include not only the individual or
entity described in the introductory paragraph of this Agreement but shall also include all partners
if you are a partnership, all shareholders if you are a corporation and all members if you are a
limited liability company. By their signatures hereto, all of your officers, partners, members and
managers acknowledge and accept the duties and obligations imposed upon each of them, individually,
by the terms of this Agreement. All partners, all shareholders, or all members, as the case may be,
and your restaurant manager must execute the Owner Agreement attached as EXHIBIT A and made a part
hereof.

XXVII. ACKNOWLEDGEMENTS

A. You acknowledge that the success of the business venture contemplated to be undertaken by you by
virtue of this Agreement is speculative and depends, to a large extent, upon your ability as an
independent businessperson, and your participation in the daily affairs of the business as well as
other factors. We do not make any representation or warranty, express or implied, as to the
potential success of the business venture contemplated hereby.

B. You acknowledge that other of our franchisees have been or will be granted franchises at
different times and in different situations, and further acknowledges that the provisions of such
franchises may vary substantially from those contained in this Agreement.

C. You represent and acknowledge that you have received, read and understood this Agreement and our
Uniform Franchise Offering Circular, and that we have fully and adequately explained the provisions
of each to your satisfaction, and that we have accorded you ample time and opportunity to consult
with advisors of your own choosing about the potential benefits and risks of entering into this
Agreement.

D. You and each agent signing on your behalf acknowledge that the officers, partners, members and/or
managers who are signing this Agreement on your behalf are authorized to execute the Agreement and
bind you to its terms.

31

E. It is contemplated that the parties may execute this Agreement on different dates. The date of
execution and the commencement of the term of this Agreement shall take place on the date this
Agreement is executed by us.
<!-- page 24 -->
IN WITNESS WHEREOF, the parties hereto, intending to be legally bound hereby, have duly executed and
delivered this Agreement in duplicate the day and year first above written.

FRANCHISOR:

ATTEST: BW-3 FRANCHISE SYSTEMS, INC.

By - ------------------------------ ------------------------------------------ Witness Its
----------------------------------------

FRANCHISEE:

ATTEST: --------------------------------------------

By - ------------------------------ ------------------------------------------ Witness Its
----------------------------------------

ATTEST:

By - ------------------------------ ------------------------------------------ Witness Its
----------------------------------------

32

EXHIBIT A

BUFFALO WILD WINGS OWNER AGREEMENT

As a condition to the granting by bw-3 Franchise Systems, Inc. ("we" or "us") of an Area Development
Agreement and/or one or more Franchise Agreements executed (collectively the "Agreements") providing
certain rights relating to Buffalo Wild Wings Restaurants (the "Restaurants") to
________________________ ________________ ("Franchisee"), each of the undersigned individuals
("you"), who constitute each beneficial holder of an interest in the Franchisee, covenants and
agrees to be bound by the terms and restrictions of this Agreement ("Agreement"):

1. ACKNOWLEDGMENTS. Each of you, jointly and severally, represents and warrants to us:

A. That you are the holders of all equity, voting and other interests in Franchisee and/or all
options, warrants and rights to acquire an interest in Franchisee and that the address and telephone
number set forth next to your name below are accurate and complete and you will immediately advise
us of any change in the information and we may use or distribute the same as required by law,
including in our Uniform Franchise Offering Circular;

B. That Franchisee is a corporation, limited liability company or partnership, duly organized,
validly existing and in good standing under the laws of the State of ____________________, and that
Franchisee is qualified to do business in the state where the Restaurant(s) are to be located;

C. It is a condition to the granting of the franchise to Franchisee that you enter into this
Agreement and we have entered into the Agreements in reliance upon your agreement to do so, and will
continue to do so;

D. That, as Franchisee's owners, you have received adequate consideration to support your execution
of this Agreement.

2. CONFIDENTIALITY AND NON-COMPETITION AGREEMENTS.

A. IN TERM COVENANT NOT-TO-COMPETE. Each of you agrees that during the period Franchisee operates
any Buffalo Wild Wings and/or bw-3 Restaurants, or has any beneficial interest therein, or holds any
rights to develop one or more such Restaurants (including all renewal periods) you shall not
directly or indirectly on your own account or as an employee, consultant, partner, officer,
director, shareholder or member of any person, firm, entity, partnership, corporation or company,
own, operate, lease franchise, engage in, be connected with, have any interest in, or assist any
person or entity engaged in: 1) any restaurant business, 2) any prepared food business, or 3) any
other business which sells prepared food products the same or similar as the type sold in our
System.

B. POST TERM COVENANT NOT-TO-COMPETE. Each of you agrees that
<!-- page 25 -->
for a two-year period after Franchisee ceases to have any interest in any Restaurants or any rights
to develop Restaurants, regardless of the reasons such interest ceases or terminates, you will not
directly or indirectly on your own account or as an employee, consultant, partner, officer,
director, shareholder or member of any person, firm, entity, partnership, corporation or company,
own operate, lease franchise, engage in, be connected with, have any interest in, or assist any
person or entity engaged in: 1) any restaurant business, 2) any prepared food business, or 3) any
other business which sells prepared food products the same or similar as the type sold in our
System; which is located at or within a ten (10) mile radius of your former Franchised Restaurant or
any Buffalo Wild Wings or bw-3 Restaurant.

33

C. APPROPRIATION AND DISCLOSURE OF INFORMATION. Except as permitted under the Agreements, you will
not at any time use, copy or duplicate the System or any aspect thereof, or any of our trade
secrets, recipes, methods of operation, processes, formulas, advertising, marketing, designs, plans,
software, programs, know-how or other proprietary ideas or information, nor will you convey,
divulge, make available or communicate such information to any third party or assist others in
using, copying or duplicating any of the foregoing.

D. INFRINGEMENT; VALIDITY OF MARKS AND COPYRIGHTS; REGISTRATIONS. You will not at any time commit
any act that would infringe upon or impair the value of the System or the Marks, nor will you engage
in any business or market any product or service under a name, mark, or design that is confusingly
or deceptively similar to any of the Marks. You agree that you will not, at any time directly or
indirectly challenge or contest the validity of, or take any action to jeopardize our rights in or
ownership of, any of the Marks or any registration of a Mark or any copyrighted work. If you violate
this provision, we shall be entitled to all equitable, monetary, punitive and any other relief that
may be available under applicable law, as well as the recovery of all costs, expenses and attorneys'
fees incurred by us as a result of such violation.

E. SOLICITATION OF EMPLOYEES. You agree that from and after the date hereof, you will not solicit,
entice, induce to leave employment or hire directly or indirectly, any person who has been employed
by us or by our affiliates or franchisees within the previous twelve (12) month period.

F. TRADE SECRETS AND CONFIDENTIAL INFORMATION. You understand and agree that we have disclosed or
may disclose to you certain confidential or proprietary information and trade secrets. Except as
necessary in connection with the operation of the Restaurant and as approved by us, you shall not,
at any time (during or after term), regardless of the cause of termination, directly or indirectly,
use for your own benefit or communicate or divulge to, or use for the benefit of any other person or
entity, any trade secrets, confidential information, knowledge or know-how concerning the recipes,
food products, advertising, marketing, designs, plans, software, programs or methods of operation of
the Restaurant or the System. You shall disclose to your employees only such confidential,
proprietary or trade secret information as is necessary to operate your business hereunder and then
only while this Agreement is in effect. Any and all information, knowledge, or know-how, including
without limitation, drawings, materials, equipment, marketing, recipes and other data, that we
designate under the Agreements as secret or confidential shall be deemed secret and confidential for
purposes of this Agreement.

G. REASONABLENESS OF SCOPE AND DURATION. You agree that the covenants and agreements contained in
Section 2 are, taken as a whole, reasonable with respect to the activities covered and their
geographic scope and duration, and no party shall raise any issue of the reasonableness of the
areas, activities or duration of any such covenants in any proceeding to enforce any such covenants.
Each of you acknowledge and agree that you have other skills and resources and that the restrictions
contained in this Section will not hinder your activities or ability to make a living either under
the Agreement or in general.

H. ENFORCEABILITY. Each of you agree that we may not be adequately compensated by damages for a
breach of any of the covenants and agreements contained herein, and that we shall, in addition to
all other remedies, be entitled to injunctive relief and specific performance. The covenants and
agreements contained in this Section 2 shall be construed as separate covenants and agreements, and
if any court shall finally determine that the restraints provided for in any such covenants and
agreements are too broad as to the area, activity or time covered, said area, activity or time
covered may be reduced to whatever extent the court deems reasonable, and such covenants and
agreements shall be enforced as to such reduced area, activity or time. To the extent required by
the laws of the state in which the Restaurant is located, the duration or the geographic areas
included within the foregoing covenants, or both, shall be deemed amended in accordance with Section
2.

34

3. GUARANTY.

A. GUARANTY. Each of you personally and unconditionally guaranty to us and to our parent and other
affiliates, as well as any of their successors or assigns, the punctual payment when due of all
sums, indebtedness and liabilities of every kind and nature that Franchisee may now or in the future
owe to any of us (including interest, and all attorneys' fees, costs and expenses incurred by any of
us in collection).
<!-- page 26 -->
B. COVENANTS AND ACKNOWLEDGMENTS. Each of you covenant and agree that: (1) liability under this
guaranty shall be joint and several; (2) that this is a guaranty of payment and not of collection
and you shall render any payment required under the Agreements or this guaranty upon demand; (3)
this guaranty shall extend to all amounts you may now or in the future owe to any of us, whether
pursuant to the Agreements, another agreement with us or otherwise; (4) your liability under this
guaranty shall not be contingent or conditioned upon pursuit by us of any remedies against
Franchisee or any of you; (5) your liability hereunder shall not be diminished, relieved, or
otherwise affected by any extension of time, credit, or other indulgence or waiver that we may from
time to time grant to Franchisee or to any of you, including, without limitation, the acceptance of
partial payment or performance, the compromise or release of any claims, the release of any other
guarantor, or our consent to any transfer or assignment of the franchise or any interest therein and
expressly reserve all rights that we may have against you.

C. TERM OF GUARANTY. This guaranty and your obligations under it shall continue in effect so long as
you operate any Buffalo Wild Wing Restaurant or hold any beneficial interest therein and for a one
(1) year period thereafter. Further, this guaranty shall be extended during any period in which (1)
any of us is involved in any judicial or administrative process with Franchisee or any of you (i) to
collect any amounts owed us by you, or (ii) to enforce the terms of this guaranty, or (2) any
bankruptcy or similar proceeding involving Franchisee or any of you. Your obligations under this
guaranty shall remain in full force and effect without regard to, and shall not be released,
discharged or in any way modified or affected by, any circumstance or condition of Franchisee
(whether or not you shall have any knowledge or notice thereof), including, without limitation,
bankruptcy, insolvency, reorganization, composition, liquidation or similar proceeding or any action
taken by any trustee or receiver or by any court in any such proceeding.

D. WAIVERS. Each of you waives notice of demand, notice of protest, nonpayment or default, and all
other notices to which Franchisee or you may be entitled, and all suretyship and guarantor's
defenses generally and any and all other notices and legal or equitable defenses to which you may be
entitled. You waive all exemptions to which you may now or hereafter be entitled under the laws of
this or any other state or of the United States. You waive any right that you may have to require
that an action be brought against Franchisee or any other payments and claims for reimbursement or
subrogation that you may have against Franchisee arising as a result of your execution and
performance of this guaranty.

E. ASSIGNMENT. This guaranty is personal to you and the obligations and duties imposed in it may not
be delegated or assigned; provided, this guaranty shall be binding upon your successors, assigns,
estates and personal representatives. This guaranty shall inure to our benefit, and the benefit of
our affiliates, successors and assigns.

F. ENFORCEMENT. If any one or more provisions in this guaranty shall for any reason be held to be
invalid, illegal, or unenforceable in any respect, such invalidity, illegality or unenforceability
shall not affect any other provision hereof and this guaranty shall be construed to bind you to the
maximum extent permitted by law that is subsumed within the terms of such provision as though it
were separately articulated herein.

35

4. COVENANT NOT TO TRANSFER INTERESTS. The Agreements, and your rights and obligations under them,
are and shall remain personal to you. Any proposed transfer by you (regardless of the form of
transfer) shall be subject to the same terms and conditions contained in the Franchise Agreement. As
used herein, the term "Transfer" shall mean any sale, assignment, gift, pledge, mortgage or any
other encumbrance, transfer by bankruptcy, transfer by judicial order, merger, consolidation, share
exchange, transfer by operation of law or otherwise, whether direct or indirect, voluntary or
involuntary, of the Agreements or any interest in any of them or any rights or obligations arising
under them, or of any material portion of the business assets, or of any interest in the Franchisee.
Each of you agree and covenant that you will not at any time during which Franchisee is a Buffalo
Wild Wings/bw-3 franchisee and/or developer, directly or indirectly, voluntarily or involuntarily,
make any Transfer, unless you first obtain our written approval in compliance with the same
provisions applicable to a transfer by you as set forth in the Agreements. You shall cause all stock
certificates (or other documents evidencing an interest or right to acquire an interest) issued by
Franchisee to bear a legend indicating that such stock (or other documents) is subject to the
restrictions provided for in the applicable Agreement.

5. MISCELLANEOUS.

A. CAPITALIZED TERMS. For purposes of this Agreement, all capitalized terms shall have the same
meaning as those terms are defined in the Franchise Agreement.

B. DISPUTES. Disputes under this Agreement shall be resolved in the same manner as provided under
the Franchise Agreement. You expressly acknowledge that the provisions of the Franchise Agreement
pertaining to mediation, venue, applicable law, time periods and limitations govern any disputes
between us and you.

IN WITNESS WHEREOF, each of you have signed this Agreement on the date set forth opposite your
signature.

Signature: Date: -------------------------- -------------------

Name: ------------------------------- Address: ----------------------------

- ------------------------------------

- ------------------------------------ Percentage Interest: ----------

Signature: Date: -------------------------- ------------------- Name:
------------------------------- Address: ----------------------------

- ------------------------------------

- ------------------------------------ Percentage Interest: ----------

Signature: Date: -------------------------- ------------------- Name:
------------------------------- Address: ----------------------------

- ------------------------------------
<!-- page 27 -->
- ------------------------------------ Percentage Interest: ---------- Signature: Date:
-------------------------- -------------------

36

Name: ------------------------------- Address: ----------------------------

- ------------------------------------

- ------------------------------------ Percentage Interest: ----------

Signature: Date: -------------------------- ------------------- Name:
------------------------------- Address: ----------------------------

- ------------------------------------

- ------------------------------------ Percentage Interest: ----------

TO BE COMPLETED IF MANAGER IS NOT AN OWNER.

I represent and acknowledge that I am the Manager of a Restaurant and that I agree to be bound by
the provisions of Section 2 of this Agreement.

MANAGER

Signature: Date: -------------------------- ------------------- Name:
------------------------------- Address: ----------------------------

- ------------------------------------

- ------------------------------------

37

EXHIBIT B

DESCRIPTION OF DESIGNATED AREA
<!-- page 28 -->
FRANCHISOR: FRANCHISEE:

BW-3 FRANCHISE SYSTEMS, INC. ------------------------------------

By By ---------------------------------- ----------------------------------

Its Its ----------------------------- ------------------------------

By ----------------------------------

Its ------------------------------

38

EXHIBIT C ADDENDUM TO LEASE

THIS ADDENDUM TO LEASE, dated ______________, 199__, is entered into by and between
_______________________("Lessor"), and __________________________ ("Lessee").

RECITALS:

A. The parties hereto have entered into a certain Lease Agreement, dated _____________, 199__, and
pertaining to the premises located at _________ __________________________________ (the "Lease").

B. Lessor acknowledges that Lessee intends to operate a Restaurant from the leased premises (the
"Premises") pursuant to a Franchise Agreement (the "Franchise Agreement") with bw-3 Franchise
Systems, Inc. ("bw-3") under the name "Buffalo Wild Wings" or other name designated by bw-3
("Franchised Restaurant").

C. The parties now desire to amend the Lease in accordance with the terms and conditions contained
herein.

AGREEMENT:

NOW, THEREFORE, it is hereby mutually covenanted and agreed between Lessor and Lessee as follows:

1. REMODELING AND DECOR. Lessor agrees that Lessee shall have the right to remodel, equip, paint and
decorate the interior of the Premises and to display such proprietary marks and signs on the
interior and exterior of the Premises as Lessee is reasonably required to do pursuant to the
Franchise Agreement and any successor Franchise Agreement under which Lessee may operate a
Franchised Restaurant on the Premises.

2. ASSIGNMENT. Lessee shall have the right to assign all of its right, title and interest in the
Lease to bw-3 or any affiliate of bw-3 at any time during the term of the Lease, including any
extensions or renewals thereof, without first obtaining Lessor's consent. However, no assignment
shall be effective until such time as bw-3 or its designated affiliate gives Lessor written notice
of its acceptance of such assignment, and nothing contained herein or in any other document shall
constitute bw-3 or its designated affiliate a party to the Lease, or guarantor thereof, and shall
not create any liability or obligation of bw-3 or any affiliate of bw-3 unless and until the Lease
is assigned to, and accepted in writing by, bw-3 or its designated affiliate. In the event of an
assignment, Lessee shall remain liable under the terms of the Lease.

3. DEFAULT AND NOTICE.

(a) In the event there is a default or violation by Lessee under the terms of the Lease, Lessor
shall give Lessee and bw-3 written notice of such default or violation within a reasonable time
after Lessor receives knowledge of its occurrence. bw-3 will notify Lessor whether it intends to
cure the default and take an automatic assignment of Lessee's interest as provided in Paragraph
4(a). bw-3 will have an additional fifteen (15) days in which to cure the default or violation.

(b) All notices to bw-3 shall be sent by registered or certified mail, postage prepaid, to the
following address:

bw-3 Franchise Systems, Inc. 1919 Interchange Tower 600 South Highway 169 Minneapolis, MN 55426

39
<!-- page 29 -->
Attention: Chief Financial Officer bw-3 may change its address for receiving notices by giving
Lessor written notice of such new address. Lessor agrees that it will notify both Lessee and bw-3 of
any change in Lessor's mailing address to which notices should be sent.

4. TERMINATION OR EXPIRATION.

(a) Upon the expiration or termination of either the Lease or the Franchise Agreement, bw-3 will, at
its option, have the right (but not the requirement) to take an automatic assignment of Lessee's
interest.

(b) Upon the expiration or termination of either the Lease or the Franchise Agreement, Landlord will
cooperate with and assist us in gaining possession of premises and if bw-3 does not elect to take an
assignment of the Lessee's interest, Lessor will allow bw-3 to enter the Premises, without being
guilty of trespass and without incurring any liability to Lessor, to remove all signs, awnings, and
all other items identifying the Premises as a Franchised Restaurant and to make such other
modifications (such as repainting) as are reasonably necessary to protect the bw-3 marks and system,
and to distinguish the Premises from Franchised Restaurants. In the event bw-3 exercises its option
to purchase assets of Lessee, Lessor shall permit bw-3 to remove all such assets being purchased by
bw-3.

5. CONSIDERATION; NO LIABILITY.

(a) Lessor hereby acknowledges that the provisions of this Addendum to Lease are required pursuant
to the Franchise Agreement under which Lessee plans to operate its business and the Lessee would not
lease the Premises without this Addendum.

(b) Lessor further acknowledges that Lessee is not an agent or employee of bw-3 and the Lessee has
no authority or power to act for, or to create any liability on behalf of, or to in any way bind
bw-3 or any affiliate of bw-3, and that Lessor has entered into this Addendum to Lease with full
understanding that it creates no duties, obligations or liabilities of or against bw-3 or any
affiliate of bw-3.

6. SALES REPORTS. If requested by bw-3, Lessor will provide bw-3 with whatever information Lessor
has regarding Lessee's sales from the Restaurant.

7. AMENDMENTS. No amendment or variation of the terms of this Addendum to the Lease shall be valid
unless made in writing and signed by the parties hereto.

8. REAFFIRMATION OF LEASE. Except as amended or modified herein, all of the terms, conditions and
covenants of the Lease shall remain in full force and effect and are incorporated herein by
reference and made a part hereof as though copied herein in full.

9. BENEFICIARY. Lessor and Lessee expressly agree that bw-3 is a third party beneficiary of this
Addendum.

40

IN TESTIMONY WHEREOF, witness the signatures of the parties hereto as of the day, month and year
first written above.

------------------------------------------

By: ----------------------------------- Title: ----------------------------------- ("Lessor")

------------------------------------------

By: ----------------------------------- Title: ----------------------------------- ("Lessee")

41
