<!-- page 1 -->
# MASTER SERVICES AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2018-09-24 |
| Parties | Clear Capital ("Company"); Radial Spark, LLC ("Contractor") |
| Source | CUAD v1 / MERITLIFEINSURANCECO_06_19_2020-EX-10.(XIV)-MASTER SERVICES AGREEMENT |

Exhibit 10(xiv)

MASTER SERVICES AGREEMENT Between RadialSpark, LLC and Clear Capital Page 1 of 10
<!-- page 2 -->
THIS MASTER SERVICES AGREEMENT ("Agreement"), dated as of 09/24/2018 (the "Effective Date"), is
between Clear Capital (the "Company") and RadialSpark, LLC (the "Contractor"). WHEREAS, Company
desires from time to time to retain Contractor to perform certain management consulting services for
Company; and WHEREAS, Contractor desires to perform such management consulting services for Company;
NOW THEREFORE, in consideration of the foregoing premises, and the mutual covenants and agreements
set forth herein, the parties hereto agree as follows: 1. PURPOSE OF ENGAGEMENT. (a) Company agrees
to retain Contractor to perform the consulting services for Company, on a task by task basis (the
"Services"), and Contractor agrees to furnish the Services on the terms and subject to the
conditions set forth in this Agreement. During the term of this Agreement, Company and Contractor
will develop and agree upon statements of work defining the Services and work product to be provided
by Contractor, Contractor's compensation, additional terms and conditions, if any, applicable to a
particular engagement and such other details as the parties deem appropriate (each a "Statement of
Work"). A Statement of Work may provide specifications for deliverables to be provided thereunder
(the "Specifications"). Statements of Work that are from time to time agreed upon shall reference
this Agreement, and shall be executed by the parties and attached hereto and shall form a part
hereof. In all instances of a conflict, between the provisions of this Agreement and the specific
provisions set forth in a Statement of Work, the provisions of this Agreement shall control. (b)
Contractor shall provide sufficient qualified personnel to perform the Services in a professional
and workmanlike manner in accordance with industry standards. A Statement of Work may designate
certain individuals as "Key Personnel" for an engagement, and the parties subsequently may agree in
writing that additional individuals are Key Personnel for such engagement. If there are Key
Personnel for an engagement, Contractor shall provide the Services through those personnel and such
additional personnel of Contractor as Contractor may from time to time determine to be required for
the performance of the Services. Company shall have the right to interview and approve such
additional personnel at Company's request. If one or more Key Personnel terminate their employment
with Contractor or otherwise become

Page 2 of 10
<!-- page 3 -->
unavailable to work on an engagement for reasons beyond Contractor's reasonable control, Contractor
may provide the Services through other personnel with comparable training and experience. If Company
becomes dissatisfied with any of Contractor's personnel providing the Services, Company may notify
Contractor of the details of its dissatisfaction, and the parties shall cooperate to remedy the
problem as soon as possible. If Company reasonably requests, Contractor shall reassign the
individual who is the subject of Company's dissatisfaction and replace that person with other
personnel in accordance with this Agreement. (c) Unless otherwise provided in a Statement of Work,
Contractor shall provide the Services at Contractor's facility. Contractor shall provide computing
equipment consistent with the Services to be provided under the Statement of Work. When services are
provided at a Company facility, Company shall provide workspace and other facilities such as
computer support consistent with the requirements of the Services to be provided under the Statement
of Work. Contractor shall cause its personnel at Company's facility to comply with Company's (i)
safety and security rules and other rules applicable to those working in the facility, and (ii)
Company's policies concerning access to and security of any Company computer system to which
Contractor may have access; provided, that Company has provided Contractor with copies of such rules
and policies or has advised Contractor of the existence of such rules and policies. (d) Company may
request changes that affect the scope or duration of the Services relating to any Statement of Work,
including changes in the Specifications and changes in the deliverables to be delivered. Company
acknowledges that any change in Specifications may result in changes to estimated fees and estimated
timeline for creation of deliverables. Company also may request a change in the Schedule without
changing the scope of the Services relating to the applicable Statement of Work. In either case, the
parties shall negotiate in good faith a reasonable and equitable adjustment in the applicable fees,
Schedule and Specifications. Contractor shall continue work pursuant to the existing Statement of
Work, and shall not be bound by any change requested by Company, until such change has been accepted
in writing by Contractor. (e) The obligations of Company in connection with a particular engagement
shall be set forth in the applicable Statement of Work. Company agrees to perform such obligations
in accordance with, and subject to, such Statement of Work. Company acknowledges that when a
Statement of Work provides that Company's personnel are to work with Contractor's personnel in
connection with an engagement, Company's failure to assign Company personnel having skills
commensurate with their role with respect to such engagement could adversely affect Contractor's
ability to provide the Services.

Page 3 of 10
<!-- page 4 -->
(f) To the extent Contractor provides any third party materials and products Contractor acknowledges
that it shall be solely responsible for ensuring the functionality and specifications of such third
party materials and products used in performing Services under this Agreement. 2. TERM. The term of
this Agreement shall begin on the date hereof and shall continue until terminated by either party
pursuant to Paragraph 6 hereof. 3. CONTRACTOR'S COMPENSATION. (a) During the term of this Agreement,
Company agrees to compensate Contractor as set forth in each Statement of Work. Contractor will be
compensated on a time and materials. In addition, Company shall reimburse Contractor its actual
out-of-pocket expenses as reasonably incurred by Contractor in connection with its performance of
the Services as negotiated in each Statement of Work. (b) Contractor shall bill Company as set forth
in the relevant Statement of Work. Each invoice submitted by Contractor will provide supporting
detail for the Services invoiced, including, to the extent applicable to a particular engagement,
the dates of Services and hours worked at the applicable rate by Statement of Work. Invoices shall
also include receipts or other supporting detail concerning related expenses within the billing
cycle. Contractor reserves the right to change rates with 30 days notice to Company. (c) All fees,
charges and other amounts payable to Contractor hereunder do not include any sales, use, excise,
value added or other applicable taxes, tariffs or duties, payment of which shall be the sole
responsibility of Company (excluding any applicable taxes based on Contractor's net income or taxes
arising from the independent contractor relationship between Contractor and its personnel). In the
event that such taxes, tariffs or duties are assessed against Contractor, Company shall reimburse
Contractor for any such amounts paid by Contractor or provide Contractor with valid tax exemption
certificates with respect thereto. 4. OWNERSHIP OF MATERIALS RELATED TO SERVICES; ACCEPTANCE. (a)
The parties agree that all drawings, documents, designs, models, inventions, computer programs,
computer systems, data, computer documentation and other tangible materials authored or prepared by
Contractor for Company as the work product required by a Statement of Work (collectively, the
"Works"), are the property of Company to the extent that such Works were created by Contractor for
Company over a time period for which Company has been invoiced and said invoice has been paid.
Contractor agrees to render, at Company's sole cost

Page 4 of 10
<!-- page 5 -->
and expense, all reasonably required assistance to Company to protect the rights herein above
described, including executing other documents as requested by Company. (b) Company acknowledges
that Contractor provides consulting and development services to other clients, and agrees that
nothing in this Agreement shall be deemed or construed to prevent Contractor from delivering on such
business. In particular, Company agrees that, notwithstanding anything to the contrary set forth
herein: (i) as part of Contractor's provision of the Services hereunder, Contractor may utilize its
own proprietary works of authorship, that have not been created specifically for Company, including
without limitation software, methodologies, tools, specifications, drawings, sketches, models,
samples, records and documentation, as well as copyrights, trademarks, servicemarks, ideas,
concepts, know-how, techniques, knowledge or data, which have been originated, developed or
purchased by Contractor or by third parties under contract to Contractor, and, (ii) Contractor's
Information and Contractor's administrative communications and records relating to the Services
shall not be deemed to be Works and are and shall remain the sole and exclusive property of
Contractor and Company shall not resell or make use of said property in any other manner other than
in connection with the software Company receives under this Agreement. (c) To the extent that
Contractor incorporates any of Contractor's Information into the Works, Contractor hereby grants to
Company a royalty-free, non- exclusive perpetual license (including the right to grant a sublicense)
to use, copy, modify, create, derivative version, publicly perform and publicly display such
Contractor's Information in connection with Company's business operations. (d) Consultant agrees
that after Company pays Contractor in full, or after the termination of this agreement, Company may
make any changes or additions to the software Consultant created for Company under this Agreement,
which Company in Company's discretion may consider necessary, and Company may engage others to make
any such changes or additions, without further payments to Consultant. 5. CONTRACTOR'S
REPRESENTATIONS AND WARRANTIES AND WARRANTY DISCLAIMER. (a) Contractor represents and warrants to
Company that Contractor's performance of the Services called for by this Agreement, to its
knowledge, does not and shall not violate any applicable law, rule, or regulation;

Page 5 of 10
<!-- page 6 -->
(b) Contractor represents and warrants to Company that Contractor has full authority and sufficient
rights, except for rights respecting programs, data and materials provided by Company or identified
by Contractor as furnished to Company by third-party vendors, to grant and convey the rights granted
to Company under Paragraph 4 hereof; (c) Contractor represents and warrants that the Works provided
hereunder, including any Contractor Information and any third party products do not infringe any
trade secret, trademark, copyright, patent or other proprietary right of any other third party. (d)
Contractor covenants that it will not offer or pay any bribes (including any offer to provide
improper gifts or entertainment) to secure or retain a business advantage (for the benefit of
Contractor or for the benefit of Company) at any time during the term of this agreement.
Specifically, Contractor agrees that it will not offer or pay any bribes to any person (including,
in particular, to any government official) in connection with any aspect of the performance of
services under this agreement. Contractor also covenants that at all times during the term of this
agreement that it will maintain internal policies and procedures that are reasonably designed to
ensure that Contractor's employees and representatives will not offer to pay or pay bribes (or offer
or provide improper gifts or entertainment) to any person in connection with Contractor's
performance under this agreement. Contractor also covenants that it will provide suitable training
to its employees and representatives during the term of this agreement about Contractor's
anti-corruption policies and procedures. Contractor represents and warrants to Company that
Contractor has not offered or paid any bribes (or offered or provided any improper gifts and
entertainment) to secure business under this agreement or otherwise in connection with the
performance of its obligations under this agreement. Notwithstanding any other provision of this
agreement, if Contractor offers or pays a bribe or provides improper gifts or entertainment to any
government official or to any other person in connection with the performance of Contractor's
obligations under this agreement, Company shall be entitled to elect to terminate this agreement
effective immediately upon providing to Contractor written notice of such termination, in which case
Company shall have no obligation to pay any fees or other consideration to Contractor under this
agreement or otherwise. (e) THE EXPRESS WARRANTIES IN THIS AGREEMENT SHALL BE IN LIEU OF ALL OTHER
WARRANTIES, EXPRESS OR IMPLIED, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE.

Page 6 of 10
<!-- page 7 -->
6. TERMINATION. (a) At any time that there is no uncompleted Statement of Work outstanding, either
party may terminate this Agreement for any or no reason upon fifteen (15) days advance notice to the
other. (b) In addition, either party may terminate this Agreement or any outstanding Statement of
Work, upon fifteen (15) days written notice to the other party, in the event such other party
breaches a material term of this Agreement or any Statement of Work and such breach remains uncured
at the end of such fifteen (15) day period. Upon any such termination, Contractor will be paid all
fees and expenses that have been incurred or earned in connection with the performance of the
Services through the effective date of such termination. Contractor shall provide to Company, and
hereby assigns to Company, all right, title and interest to any Works in progress. 7. LIMITATIONS OF
LIABILITY; INDEMNIFICATION OF CONTRACTOR. (a) EXCEPT WITH RESPECT TO CONTRACTOR'S OBLIGATIONS
PURSUANT TO PARAGRAPH 9 HEREOF, CONTRACTOR'S MAXIMUM LIABILITY TO COMPANY ARISING FOR ANY REASON
RELATING TO CONTRACTOR'S PERFORMANCE OF SERVICES UNDER A STATEMENT OF WORK SHALL BE LIMITED TO THE
AMOUNT OF FEES PAID TO CONTRACTOR FOR THE PERFORMANCE OF SUCH SERVICES. COMPANYS' MAXIMUM LIABILITY
TO CONTRACTOR FOR ANY REASON ARISING OUT OF THIS AGREEMENT SHALL BE LIMITED TO THE AMOUNT OF FEES
PAID TO CONTRACTOR. (b) NEITHER PARTY SHALL HAVE ANY LIABILITY TO THE OTHER PARTY FOR ANY LOST
PROFITS OR SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES, EVEN IF SUCH PARTY HAS BEEN
ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. (c) IN ANY SUIT ARISING FROM THIS AGREEMENT EACH PARTY
SHALL BE RESPONSIBLE FOR ITS OWN ATTORNEYS FEES. COMPANY AND CONTRACTOR HEREBY WAIVE ANY CLAIM TO
AWARD OF ATTORNEYS FEES IN SUCH A SUIT. 8. CONFIDENTIAL INFORMATION. "Confidential Information"
means all documents, software, reports, data, records, forms, conversations and other materials
obtained by Contractor from Company in the course of performing any Services (including, but not
limited to, Company records and information). Notwithstanding the foregoing, Confidential
Information does not include information which: (i) is or becomes publicly known through no wrongful
act of Contractor; or (ii) is independently developed by Contractor without benefit of Company's

Page 7 of 10
<!-- page 8 -->
Confidential Information. Contractor shall not use or disclose to any person, firm or entity any
Confidential Information without Company's express, prior written permission; provided, however,
that notwithstanding the foregoing, Contractor may disclose Confidential Information to the extent
that it is required to be disclosed pursuant to a statutory or regulatory provision or court order.
9. INDEPENDENT CONTRACTOR. Contractor is performing the Services as an independent contractor and
not as an employee of Company and none of Contractor's personnel shall be entitled to receive any
compensation, benefits or other incidents of employment from Company. Subject to Section 3(c),
Contractor shall be responsible for all taxes and other expenses arising from the employment or
independent contractor relationship between Contractor and its personnel and the rendition of
Services hereunder by such personnel to Company. Nothing in this Agreement shall be deemed to
constitute a partnership or joint venture between Company and Contractor, nor shall anything in this
Agreement be deemed to constitute Contractor or Company the agent of the other. Neither Contractor
nor Company shall be or become liable or bound by any representation, act or omission whatsoever of
the other. 10. NONASSIGNABILITY. Neither party shall assign, transfer, or subcontract this Agreement
or any of its obligations hereunder without the other party's express, prior written consent, which
will not be unreasonably withheld. 11. SEVERABILITY; GOVERNING LAW. In the event that any term or
provision of this Agreement shall be held to be invalid, void or unenforceable, then the remainder
of this Agreement shall not be affected, impaired or invalidated, and each such term and provision
of this Agreement shall be valid and enforceable to the fullest extent permitted by law. This
Agreement shall be governed by and construed in accordance with the laws of the Arizona, without
regard to the conflict of laws provisions thereof. (c) In the event of termination under either
section 6(a) or 6(b) of this agreement, Contractor shall be paid all fees and expenses that have
been incurred or earned in connection with the performance of the Services through the effective
date of such termination. Upon receipt of final payment Contractor shall provide to Company, and
will assigns to Company, all right, title and interest to any Works in progress. 12. INTEGRATION.
This Agreement, including The Mutual Non-Disclosure Agreement and, any Statements of Work entered
into pursuant hereto, constitutes the entire agreement of the parties hereto with respect to its
subject matter and supersedes all prior and contemporaneous representations, proposals, discussions,
and communications, whether oral or in writing. This

Page 8 of 10
<!-- page 9 -->
Agreement may be modified only in writing and shall be enforceable in accordance with its terms when
signed by each of the parties hereto. 13. NON-SOLICITATION OF EMPLOYEES. Neither party shall, during
the term of this Agreement and for one (1) year after its termination, solicit for hire as an
employee, consultant or otherwise any of the other party's personnel who have had direct involvement
with the Services, without such other party's express written consent, which shall not be
unreasonably withheld. 14. INSURANCE. Throughout the term of this Agreement, Contractor shall
maintain workers compensation insurance in the amount required by statute, comprehensive general
liability insurance with coverage of at least one million dollars ($1,000,000) and professional
errors and omissions insurance for bodily injury, property damage or other losses with coverage of
at least one million dollars ($1,000,000), in connection with the provision of Services by
Contractor pursuant to the terms of this Agreement. At Company's request, Contractor shall provide
Company with certificates or other acceptable evidence of insurance or self-insurance evidencing the
above coverage and shall provide Company with prompt written notice of any material change. 15.
Force Majeure. Except for payment obligations hereunder, nonperformance by either party shall be
excused to the extent that performance is rendered impossible by strike, acts of God, governmental
acts or restrictions, failure of suppliers, or any other reason where failure to perform is beyond
the control of the nonperforming party. 16. Counterparts. This Agreement may be signed in any number
of counterparts, each of which shall be an original, with the same effect as if the signatures
thereto and hereto were upon the same instrument. 17. Entire Agreement. This Agreement constitutes
the complete and exclusive agreement between Company and Consultant concerning the work on this
project, and it supersedes all other prior agreements, proposals, and representations, whether
stated orally or in writing. 18. Severability. If any provision of this Agreement is invalid,
illegal, or unenforceable, the remainder of this Agreement will remain in full force and effect. 19.
Arbitration. Except as otherwise specified below, all actions, disputes, claims and controversies
under common law, statutory law or in equity of any type or nature whatsoever, whether arising
before or after the date of this Agreement, and whether directly or indirectly

Page 9 of 10
<!-- page 10 -->
relating to: (a) this Agreement and/or any amendments and addenda hereto, or the breach, invalidity
or termination hereof; (b) any previous or subsequent agreement between the parties; and/or (c) any
other relationship, transaction or dealing between the parties (collectively the "Disputes"), will
be subject to and resolved by binding arbitration pursuant to the Arbitration Rules of U.S.
Arbitration & Mediation, (www.usam.com). Any award or order rendered by the arbitrator may be
confirmed as a judgment or order in any state or federal court of competent jurisdiction, which
includes within the federal judicial district of the residence of the party against whom such award
or order was entered. IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be
executed by their duly authorized representatives as of the Effective Date. /s/ Michael Rockford /s/
John Marcum for RadialSpark, LLC for Clear Capital

Page 10 of 10
