<!-- page 1 -->
# SERVICE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 1998-01-01 |
| Parties | Fidelity Investments Institutional Operations Company, Inc. ("FIIOC"); New York Life Insurance and Annuity Corporation ("Company") |
| Source | CUAD v1 / NYLIACVARIABLEANNUITYSEPARATEACCOUNTIII_04_10_2020-EX-99.8.KK-SERVICE AGREEMENT |

Exhibit (8)(k)(k)

SERVICE AGREEMENT

This Agreement is entered into and effective as of the 1st day of January, 1998, by and between
FIDELITY INVESTMENTS INSTITUTIONAL OPERATIONS COMPANY, INC. ("FIIOC") and NEW YORK LIFE INSURANCE
AND ANNUITY CORPORATION ("Company").

WHEREAS, FIIOC provides transfer agency and other services to Fidelity's Variable Insurance Products
Fund, Variable Insurance Products Fund II and Variable Insurance Products Fund III (collectively
"Funds"); and

WHEREAS, the services provided by FIIOC on behalf of the Funds include responding to inquiries about
the Funds including the provision of information about the Funds' investment objectives, investment
policies, portfolio holdings, etc.; and

WHEREAS, Company holds shares of the Funds in order to fund certain variable annuity contracts,
group annuity contracts, and/or variable life insurance policies, the beneficial interests in which
are held by individuals, plan trustees, or others who look to Company to provide information about
the Funds similar to the information provided by FIIOC; and

WHEREAS, the Company and one or more of the Funds have entered into one or more Participation
Agreements, under which the Company agrees not to provide information about the Funds except for
information provided by the Funds or their designees; and

WHEREAS, FIIOC and Company desire that Company be able to respond to inquiries about the Funds from
individual variable annuity owners, participants in group annuity contracts issued by the Company,
and owners and participants under variable life insurance policies issued by the Company, and
prospective customers for any of the above; and

WHEREAS, FIIOC and Company recognize that Company's efforts in responding to customer inquiries will
reduce the burden that such inquiries would place on FIIOC should such inquiries be directed to
FIIOC.

NOW, THEREFORE, the parties do agree as follows:

1. Information to be Provided to Company. FIIOC agrees to provide to Company, on a periodic basis,
directly or through a designee, information about the Funds' investment objectives, investment
policies, portfolio holdings, performance, etc. The content and format of such information shall be
as FIIOC, in its sole discretion, shall choose. FIIOC may change the format and/or content of such
informational reports, and the frequency with which such information is provided. For purposes of
Section 4.2 of each of the Company's Participation Agreement(s) with the Funds, FIIOC represents
that it is the designee of the Funds, and Company may therefore use the information provided by
FIIOC without seeking additional permission from the Funds.

2. Use of Information by Company. Company may use the information provided by FIIOC in
communications to individuals, plan trustees, or others who have legal title or beneficial interest
in the annuity or life insurance products issued by Company, or representatives of any of these
parties, and to prospective purchasers of such products or beneficial interests thereunder. If such
information is contained as part of larger pieces of sales literature, advertising, etc., such
pieces shall be furnished for review to the Funds in accordance with the terms of the Company's
Participation Agreements with the Funds. Nothing herein shall give the Company the right to expand
upon, alter the appearance of, or otherwise alter the information provided by FIIOC. Company
acknowledges that the information provided it by FIIOC may
<!-- page 2 -->
need to be supplemented with additional qualifying information, regulatory disclaimers, or other
information before it may be conveyed to persons outside the Company.

3. Compensation to Company. In recognition of the fact that Company will respond to inquiries that
otherwise would be handled by FIIOC, FIIOC agrees to pay Company a quarterly fee computed as
follows:

At the close of each calendar quarter, FIIOC will determine the Average Daily Assets held in the
Funds by the Company. Average Daily Assets shall be the sum of the daily assets for each calendar
day in the quarter divided by the number of calendar days in the quarter. The Average Daily Assets
shall be multiplied by [ ] ([ ] basis points) and that sum shall be divided by four. The resulting
number shall be the quarterly fee for that quarter, which shall be paid to Company during the
following month.

Should any Participation Agreement(s) between Company and any Fund(s) be terminated effective before
the last day of a quarter, Company shall be entitled to a fee for that portion of the quarter during
which the Participation Agreement was still in effect, unless such termination is due to misconduct
on the part of the Company. For such a stub quarter, Average Daily Assets shall be the sum of the
daily assets for each calendar day in the quarter through and including the date of termination of
the Participation Agreement(s), divided by the number of calendar days in that quarter for which the
Participation Agreement was in effect. Such Average Daily Assets shall be multiplied by [ ] ([ ]
basis points) and that number shall be multiplied by the number of days in such quarter that the
Participation Agreement was in effect, then divided by three hundred sixty-five. The resulting
number shall be the quarterly fee for the stub quarter, which shall be paid to Company during the
following month.

Notwithstanding the foregoing, compensation for each calendar quarter will not exceed [ ].

4. Termination. This Agreement may be terminated by Company at any time upon written notice to
FIIOC. FIIOC may terminate this Agreement at any time upon ninety (90) days' written notice to
Company. FIIOC may terminate this Agreement immediately upon written notice to Company (1) if
required by any applicable law or regulation, (2) if so required by action of the Fund(s) Board of
Trustees, or (3) if Company engages in any material breach of this Agreement. This Agreement shall
terminate immediately and automatically upon the termination of Company's Participation Agreement(s)
with the Funds, and in such event no notice need be given hereunder.

5. Applicable Law. This Agreement shall be construed and the provisions hereof interpreted under and
in accordance with the laws of the Commonwealth of Massachusetts.

6. Assignment. This Agreement may not be assigned without the written consent of the other party,
which consent shall not be unreasonably withheld, except that it shall be assigned automatically to
any successor to FIIOC as the Funds' transfer agent, and any such successor shall be bound by the
terms of this Agreement.

IN WITNESS WHEREOF, the parties have set their hands as of the date first written above.

FIDELITY INVESTMENTS INSTITUTIONAL OPERATIONS COMPANY, INC.

By:

NEW YORK LIFE INSURANCE AND ANNUITY CORPORATION By:

Name:

Title:
