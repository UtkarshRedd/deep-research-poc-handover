<!-- page 1 -->
# Wireless Content License Agreement Number 12965
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2007-02-19 |
| Parties | Fox Mobile Entertainment, Inc. ("Fox"); Glu Mobile Inc. ("Licensee") |
| Source | CUAD v1 / GluMobileInc_20070319_S-1A_EX-10.09_436630_EX-10.09_Content License Agreement4 |

AMENDMENT NO. 3

Dated as of February 19, 2007

Reference is hereby made to that certain fully executed Wireless Content License Agreement Number
12965 dated as of December 16, 2004, as amended November 11, 2005 and March 27, 2006 (the
"Agreement"), between Fox Mobile Entertainment, Inc. ("Fox"), as Administrator for Twentieth Century
Fox Film Corporation, and Glu Mobile Inc. ("Licensee").

The parties agree to modify the Agreement as follows:

1. EXTENSION OF TERM: The first paragraph of Section 4 of the Agreement is hereby deleted in its
entirety and replaced with the following:

"TERM: The rights granted hereunder shall be effective as of the Effective Date and shall expire on
December 31, 2006 (the "Term"); provided, however, that with respect to each Property, including
Robots, Kingdom of Heaven, Mr. and Mrs. Smith, In Her Shoes, Idiocracy (Oww My Balls) and Ice Age
II, all right and licenses granted herein will continue in full force and effect until March 31,
2008."

2. NOTICE PROVISION: The notice information for Licensee in Section 17(a) of the Agreement shall be
amended such that "Paul Zuzelo" is deleted and replaced with "General Counsel", and such that the
email address for Paul Zuzelo is deleted.

Except as herein expressly amended or by necessary implication modified by this Amendment, the
Agreement in all other respects is hereby ratified and shall continue in full force and effect.

By signing in the places indicated below, the parties hereto accept and agree to all of the terms
and conditions hereof. Glu Mobile Inc. ("Licensee") Fox Mobile Entertainment, Inc. ("Fox")

By: /s/ Albert A. Pimentel By: /s/ Jamie Samson

Name: Albert A. Pimentel Name: Jamie Samson Its: EVP and CFO Its: Senior Vice President Date: Date:

Source: GLU MOBILE INC, S-1/A, 3/19/2007
