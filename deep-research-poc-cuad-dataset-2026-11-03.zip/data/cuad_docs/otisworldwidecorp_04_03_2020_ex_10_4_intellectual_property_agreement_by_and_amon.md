<!-- page 1 -->
# INTELLECTUAL PROPERTY AGREEMENT
| Field | Value |
|---|---|
| Document Type | IP Agreement |
| Agreement Date | 2020-04-02 |
| Parties | United Technologies Corporation ("UTC"); Otis Worldwide Corporation ("Otis"); Carrier Global Corporation ("Carrier"); each a "Party", and together, the "Parties" |
| Source | CUAD v1 / OTISWORLDWIDECORP_04_03_2020-EX-10.4-INTELLECTUAL PROPERTY AGREEMENT by and among UNITED TECHNOLOGIES CORPORATION, OTIS WORLDWIDE CORPORATION and CARRIER ~1 |

Exhibit 10.4

EXECUTION VERSION

INTELLECTUAL PROPERTY AGREEMENT

by and among

UNITED TECHNOLOGIES CORPORATION,

OTIS WORLDWIDE CORPORATION

and

CARRIER GLOBAL CORPORATION

Dated as of April 2, 2020
<!-- page 2 -->
TABLE OF CONTENTS ARTICLE I DEFINITIONS 2 1.1 Defined Terms 2 ARTICLE II ASSIGNMENT OF SOLELY OWNED
INTELLECTUAL PROPERTY RIGHTS 7 2.1 Assigned Intellectual Property Rights 7 ARTICLE III LICENSING OF
INTELLECTUAL PROPERTY RIGHTS 8 3.1 Licensed Intellectual Property Rights 8 3.2 Reserved Intellectual
Property Rights 10 3.3 No Rescission 10 ARTICLE IV TRADEMARKS 10 4.1 Ownership of United
Technologies Trademarks 10 4.2 Use of United Technologies Trademarks 11 4.3 Special Trademark
Provisions. 12 ARTICLE V EXCLUDED AGREEMENTS 12 5.1 No Change to Excluded Agreements 12 ARTICLE VI
CONFIDENTIALITY 12 6.1 Received Information and Materials 12 6.2 Confidential Information 12 6.3
Obligations 13 6.4 Termination of UTC NDA 13 ARTICLE VII LIMITATIONS AND DISCLAIMERS 13 7.1
Subsequent Delivery of Intellectual Property Rights 13 7.2 No Additional Obligations 14 7.3
DISCLAIMER 14 7.4 Limitations of Liability 14 ARTICLE VIII GOVERNING LAW AND DISPUTE RESOLUTION 15
8.1 Governing Law 15 8.2 Alternative Dispute Resolution 15 8.3 Confidentiality 13 8.4 Equitable
Relief 13

i
<!-- page 3 -->
ARTICLE IX GENERAL PROVISIONS 16 9.1 Entire Agreement; Conflict Among Agreements 16 9.2 Assignment
and Change of Control; Successor and Assigns 16 9.3 Bankruptcy 17 9.4 Amendments and Waivers 17 9.5
Notice 18 9.6 Severability 18 9.7 Counterparts 18 9.8 Further Assurances 18 9.9 Interpretation 19

ii
<!-- page 4 -->
INTELLECTUAL PROPERTY AGREEMENT This INTELLECTUAL PROPERTY AGREEMENT (this "Agreement"), dated as of
April 2, 2020, is by and among United Technologies Corporation, a Delaware corporation ("UTC"), Otis
Worldwide Corporation, a Delaware corporation ("Otis"), and Carrier Global Corporation, a Delaware
corporation ("Carrier") (each, a "Party" and together, the "Parties"). RECITALS WHEREAS, UTC, Otis
and Carrier have entered into that certain Separation and Distribution Agreement, of even date
herewith (the "SDA"), pursuant to which UTC and its subsidiaries will undertake a series of
transactions following which UTC will separate into three independent, publicly traded companies:
(i) UTC, comprising Collins Aerospace and Pratt & Whitney, a systems supplier to the commercial
aerospace and defense industry, (ii) Otis, a manufacturer of people-moving products, such as
elevators, escalators and moving walkways, and (iii) Carrier, a provider of HVAC, refrigeration,
fire, security and building automation technologies; WHEREAS, pursuant to Section 2.10 of the SDA,
UTC, Otis and Carrier agreed to enter into this Agreement; WHEREAS, each of the Parties and their
respective affiliates are currently owners of, and in possession of, certain Intellectual Property
Rights (as defined herein), which Intellectual Property Rights may have been developed or acquired
by such Party independently, or jointly with either or both the other Parties, or assigned to it by
either or both of the other Parties prior to the date hereof; WHEREAS, a result of the corporate
relationship between each of the Parties, and not necessarily pursuant to a written agreement, prior
to the date hereof, each Party has had access to, and the right to use certain Intellectual Property
Rights of one or both of the other Parties as required for its business; WHEREAS, in connection with
the transactions contemplated by the SDA, the Parties wish to confirm their respective ownership of
certain Intellectual Property Rights (as defined herein), and with respect to certain other
Intellectual Property Rights transfer ownership thereof from an Assignor Party (as defined herein)
to an Assignee Party (as defined herein), and each Assignee Party wishes to receive ownership of
such Intellectual Property Rights; and WHEREAS, in connection with the transactions contemplated by
the SDA, the Parties wish to either grant, or confirm the prior grants of, certain rights and
licenses with respect to certain Intellectual Property Rights from each Licensor Party (as defined
herein) to a Licensee Party (as defined herein), and each Licensee Party wishes to receive such
license grants on the terms set forth herein. NOW, THEREFORE, in consideration of the mutual
promises hereinafter set forth and in the SDA (and other agreements entered into in connection with
the SDA), and other good and valuable consideration, the receipt and adequacy of which are hereby
acknowledged, and intending to be legally bound, the Parties hereby agree as follows:
<!-- page 5 -->
ARTICLE I

DEFINITIONS

1.1 Defined Terms. For the purposes of this Agreement, the following terms shall have the following
meanings. Capitalized terms used but not otherwise defined in this Article I or elsewhere in this
Agreement shall have the meaning ascribed to such terms in the SDA. For the avoidance of doubt, for
purposes of Section 2.1, Section 3.1, and Section 4.1, respectively, (a) any reference to an
Assignor Party, a Licensor Party, or a Party, respectively, shall be deemed to refer to other
relevant members of such Assignor Group, such Licensor Group, or such Party's Group, respectively
and (b) any obligation of an Assignor Party, a Licensor Party, or a Party, respectively, shall
include an obligation to cause such relevant members of such Assignor Group, such Licensor Group, or
such Party's Group, respectively, to satisfy such obligation; in each case, as the context requires.
"AAA Rules" shall have the meaning defined in Section 8.2.2. "Affiliate" shall mean, for the purpose
of this Agreement and notwithstanding its meaning in the SDA, with respect to a Party, another
member of the Party Group to which the Party belongs. "Agreement" shall have the meaning defined in
the preamble. "Assigned Intellectual Property Rights" shall have the meaning defined in Section
2.1.1. "Assignee Group" shall mean one of the UTC Group, the Otis Group, or the Carrier Group of
which an Assignee Party is a member. "Assignee Party" shall mean the Party, as the context requires,
other than the Assignor Party, to whom Intellectual Property Rights are assigned from the Assignor
Party pursuant to the terms hereof. "Assignor Group" shall mean one of the UTC Group, the Otis
Group, or the Carrier Group of which the Assignor Party is a member. "Assignor Party" shall mean one
of the Parties, as the context requires, in its capacity as an assignor of Intellectual Property
Rights to another Party pursuant to the terms hereof. "Carrier" shall have the meaning defined in
the preamble. "Confidential Information" shall have the meaning defined in Section 6.2.
"Contemplated to be Used" shall mean that there are contemporaneous books or records, whether in
hard copy or electronic or digital format (including emails, databases and other file formats)
evidencing a specific, good faith intention of future use, created in the ordinary course of
business consistent with past practice.

2
<!-- page 6 -->
"Copyrights" shall mean copyrights and other equivalent rights in copyrightable subject matter in
works of authorship (including software), and including all registrations and applications therefor,
and all renewals, extensions, restorations and reversions thereof. "Dispute" shall have the meaning
defined in Section 8.2. "Excluded Agreement" shall mean (a) each Negotiated Agreement and (b) each
Third Party Agreement; provided that, notwithstanding the foregoing, and without limitation, for the
purposes of this Agreement, an Excluded Agreement shall not include any IWA or any work performed,
without an express written agreement, by a member of an Assignor Group or a Licensor Group as
Performer for a member of an Assignee Group or a Licensee Group as Requester, respectively, or vice
versa. A non-inclusive (and not necessarily representative) listing of Excluded Agreements is
provided in Schedule 5.0. "Exploit" shall mean, with respect to a particular item of Intellectual
Property Rights, to do all things with such Intellectual Property Rights (subject to Article VI),
including (a) to make, have made, use (including for development), import, offer for sale, and sell
any product or service under any Patents within such Intellectual Property Rights; (b) to copy,
display, perform, create derivative works based upon, and distribute any works under, any Copyrights
within such Intellectual Property Rights; and (c) to use Trade Secrets and other confidential or
proprietary information within such Intellectual Property Rights. For the avoidance of doubt, a
right to Exploit in any manner a particular item of Intellectual Property Rights does not include
the right to Exploit in any manner any other Intellectual Property Rights, including any separate
background Intellectual Property Rights from or with which the item was created or derived, or which
is necessary or desirable for a particular use of the item. "Funded" or "Funding" by an entity shall
mean paid for by that entity through one or more cash contributions. For the purposes of this
definition, U.S. Government funds or the funds of any other third party or entity shall not be
considered. "Future Affiliate Provision" shall mean a term or provision of any agreement governing
Intellectual Property Rights as between or among the Parties that was negotiated and entered into on
arm's-length terms at any time prior to the Effective Time between or among members of different
Party Groups (a) pursuant to which a licensor Party grants or purports to grant to the Party or
Parties licensed under such agreement a license to the Intellectual Property Rights of any future
Affiliate (including in the case of UTC, Raytheon Company) of the licensor Party, (b) imposing or
purporting to impose any non-compete or other similar limitation on the business of any future
Affiliate (including in the case of UTC, the business of Raytheon Company) of a Party, in favor of
another Party or Parties, or (c) requiring or purporting to require the payment to a licensor Party
of any incremental royalty or other charge on the business or products of any future Affiliate
(including in the case of UTC, Raytheon Company) of the Party that is the licensee under such
agreement, except to the extent that such future Affiliate avails itself of the license to which
such royalty pertains. Each Party agrees that to the extent such Party is the beneficiary of a
Future Affiliate Provision, such Party hereby waives and disclaims, and will not seek to enforce or
claim the benefit of, such Future Affiliate Provision, such waiver, disclaimer and covenant being
for the sole benefit of the other Parties, their Party Groups, and their future Affiliates.

3
<!-- page 7 -->
"Intellectual Property Rights" shall mean any and all intellectual property and industrial property
rights throughout the world, whether registered or unregistered, including intellectual property and
industrial property rights protected or represented by, arising under, or associated with (a)
Patents; (b) Copyrights; (c) Trade Secrets; and (d) any other similar or equivalent intellectual
property or proprietary rights anywhere in the world; provided, however, that Trademarks are
expressly excluded from the definition of Intellectual Property Rights. "Invention Disclosure" shall
mean a written description of an invention, or potential invention, submitted to any member of a
Party Group for review for patenting. "IWA" shall mean, as of a relevant date, the contractual terms
and conditions prescribed for inter-entity work authorizations by Section 43 of the United
Technologies Corporate Policy Manual or a predecessor thereof as of the relevant date, including the
terms and conditions governing Intellectual Property Rights therein. "Licensed Intellectual Property
Rights" shall have the meaning defined in Section 3.1.1. "Licensed Patents" shall mean with respect
to a particular Licensor Group and Licensee Group, the Patents owned or freely licensable by the
Licensor Group, that absent a license of the scope granted to the Licensee Group pursuant to Section
3.1 hereof, would be infringed by the operation of the business of the Licensee Group (including the
making, selling, offering for sale, using or importing of the products or services of the Licensee
Group). In addition, for the purpose of the forgoing determination as to whether a Patent is
infringed as of the Effective Time, a Patent that issues after the Effective Time to the extent
based upon a Patent Application or Invention Disclosure in existence before the Effective Time,
shall be deemed to have been in existence from the date immediately prior to the Effective Time.
"Licensee Group" shall mean one of the UTC Group, the Otis Group, or the Carrier Group of which the
Licensee Party is a member. "Licensee Group Field" shall mean the field of the business of the
applicable Licensee Group, including the manufacture, sale, support and service of products, and the
provision of services, of one or more members of the applicable Licensee Group, as of the Effective
Time and the natural extension thereof. "Licensee Party" shall mean one of the Parties, as the
context requires, other than the Licensor Party, to whom Licensed Intellectual Property Rights are
granted from the Licensor Party pursuant to the terms hereof. "Licensor Group" shall mean one of the
UTC Group, the Otis Group, or the Carrier Group of which the Licensor Party is a member. "Licensor
Party" shall mean one of the Parties, as the context requires, in its capacity as a grantor of
Licensed Intellectual Property Rights to another Party pursuant to the terms hereof. "Negotiated
Agreement" shall mean any agreement governing Intellectual Property Rights as between or among the
Parties that was negotiated and entered into on arm's-length terms at any time prior to the
Effective Time between or among members of different Party

4
<!-- page 8 -->
Groups, including any and all such agreements identified in Schedule 5.0; provided that,
notwithstanding the foregoing, and without limitation, for the purposes of this Agreement, a
Negotiated Agreement shall not include any (i) IWA, (ii) work performed, without an express written
agreement, by any member of a Party Group as Performer for another member or members of a Party
Group as Requester or (iii) agreement between or among members of different Party Groups to the
extent including a Future Affiliate Provision. "Otis" shall have the meaning defined in the
preamble. "Party" and "Parties" shall have the meaning defined in the preamble to this Agreement.
"Party Group" shall mean each of the UTC Group, the Otis Group, and the Carrier Group. "Patent"
shall means any issued patent, including any utility patent, design patent, utility model, and
inventor's certificate, or any like governmental grant or registration for the protection of
inventions, including any patent granted by the United States Patent and Trademark Office (the
"USPTO"), the European Patent Office (the "EPO") or any foreign equivalent thereof, including any
issued patent that is continuation, divisional, continuation-in-part, extension, confirmation,
reissue, reexamination, renewal, correction or substitution of an issued patent. In addition, unless
the context otherwise requires, the term Patent shall include any Patent Application. "Patent
Application" means any application for a Patent, including any provisional or PCT or similar
application, before an applicable governmental office anywhere in the world, including the USPTO and
the EPO. "Performer" shall mean, with respect to services, an entity meeting at least one of the
following two conditions: (a) the entity is a "Performer," as defined in an IWA issued to the entity
by the "Requester" defined in the IWA, with respect to the services, and/or (b) the entity performed
the services at the request of a Requester as part of a joint project with the Requester, with
respect to which no IWA was expressly issued nor any Negotiated Agreement entered with the
Requester, and the entity received Funding from the Requester for the services (which Funded the
services in full, or in full jointly with the Performer but with no contribution from any other
entity) and delivered results of the services to the Requester. "Performer Background IPR" shall
mean, with respect to services performed by the Performer at the request of the Requester, all
Intellectual Property Rights held by Performer at the time of such services, other than Performer
Foreground-Delivered IPR and Performer Foreground-Undelivered IPR, that would be necessary to
Exploit Performer Foreground-Delivered IPR. "Performer Foreground-Delivered IPR" shall mean, with
respect to services performed by the Performer at the request of the Requester, all Intellectual
Property Rights that were conceived or created by the Performer in the course of such performance,
directly or by a Performer Service Provider, and delivered to the Requester.

5
<!-- page 9 -->
"Performer Foreground-Undelivered IPR" shall mean, with respect to services performed by the
Performer at the request of the Requester, all Intellectual Property Rights that were conceived or
created by the Performer in the course of such performance, directly or by a Performer Service
Provider, and not delivered to the Requester. "Performer Service Provider" shall mean, with respect
to services performed by the Performer at the request of the Requester, any Affiliate (other than
the Requester), supplier, service provider, or other Person performing any aspect of the services on
behalf of the Performer. "Person" shall mean an individual, partnership, corporation, limited
liability company, joint venture, association or other form of business organization (whether or not
regarded as a legal entity under applicable law), trust or other entity or organization. "Received
Information and Materials" shall have the meaning defined in Section 6.1. "Requester" shall mean,
with respect to services, an entity meeting at least one of the following two conditions: (a) the
entity is a "Requester," as defined in an IWA issued by the entity to the "Performer" defined in
such IWA, with respect to the services, and/or (b) the entity requested the services from the
Performer as part of a joint project with the Performer, with respect to which no IWA was expressly
issued nor any Negotiated Agreement entered with the Performer, and the entity Funded the services
(in full independently, or in full jointly with the Performer but with no contribution from any
other entity) and received delivery of results of the services from the Performer. "Requester
Foreground IPR" shall mean, with respect to services requested by the Requester from the Performer,
all Intellectual Property Rights conceived or created by the Requester, directly or by a Requester
Service Provider, in connection with such services. "Requester Service Provider" shall mean, with
respect to services performed by the Performer at the request of the Requester, any Affiliate (other
than the Performer), supplier, service provider, or other Person performing any aspect of the
Requester's obligations in connection with such services. "SDA" shall have the meaning defined in
the recitals. "Third Party Agreement" shall mean any Agreement, entered into at any time prior to
the Effective Time, between or among (a) a third party, on the one hand, and (b) any member or
members of the Party Groups, including any and all such agreements identified in Schedule 5.0;
provided that, notwithstanding the foregoing, and without limitation, for the purposes of this
Agreement, a Third Party Agreement shall not include any agreement between or among members of
different Party Groups to the extent including a Future Affiliate Provision. "Trade Secrets" shall
mean rights in information or know how, regardless of form, including ideas, inventions, designs,
drawings, specifications, product configurations, prototypes, models, improvements, technical data
and other data, databases, formulae, algorithms and mathematical embodiments, laboratory notebooks,
pricing and cost information, plans, proposals, processes, procedures, schematics, manufacturing
techniques, business methods,

6
<!-- page 10 -->
customer lists and supplier lists, and Invention Disclosures, that (a) derives economic value,
actual or potential, from not being, and is not, generally known or readily ascertainable by proper
means and (b) is the subject of efforts that are reasonable under the circumstances to maintain the
confidentiality or secrecy thereof. "Trademarks" shall mean trademark rights, whether registered or
unregistered, including in trademarks, service marks, trade names, brand names, certification marks,
collective marks, Internet domain names and registrations, logos, slogans, symbols, trade dress and
designs, and including all registrations, renewals, and applications for registration of the
foregoing. "United Technologies Trademarks" shall mean all Trademarks to the extent consisting of or
containing "UTC," "United Technologies Corporation," "United Technologies," "UTX," the UTC Icon,
"ACE," "Achieving Competitive Excellence," all ACE logos, "ESP," "Employee Scholar Program," all ESP
logos, "ITC360," all ITC360 logos, and any variations or derivatives of any of the foregoing, and
any Trademarks that are confusingly similar thereto. "UTC" shall have the meaning defined in the
preamble. "UTC Icon" shall mean the symbol, also known as the UTC gear logo, identified as the "UTC
Icon" in the UTC "Corporate Identity Guidelines - Brand Basics" document attached as Schedule 4.1.1,
regardless of color or size, and any variant thereof. "UTC NDA" shall have the meaning defined in
Section 6.4. ARTICLE II

ASSIGNMENT OF SOLELY OWNED INTELLECTUAL PROPERTY RIGHTS

2.1 Assigned Intellectual Property Rights

2.1.1 Assignments by an Assignor Party. Subject to Section 3.2, each Assignor Party, on behalf of
itself and the other members of the Assignor Group, hereby irrevocably assigns to the applicable
Assignee Party, and agrees to irrevocably assign to the applicable Assignee Party, all of its and
the other members of the Assignor Group's rights, title and interest in and to any and all
Intellectual Property Rights owned by the Assignor Party or another member of the Assignor Group
that meets one or more of the following descriptions: (a) the Intellectual Property Rights are
Requester Foreground IPR conceived or created in the course of services concerning which the
Assignee Party or another member of the Assignee Group was the Requester, and the Assignor Party or
another member of the Assignor Group was the Performer; or (b) the Intellectual Property Rights are
Performer Foreground-Delivered IPR conceived or created in the course of services concerning which
the Assignee Party or another member of the Assignee Group was the Requester, and the Assignor Party
or another member of the Assignor Group was the Performer; or

7
<!-- page 11 -->
(c) the Intellectual Property Rights are Performer Foreground-Undelivered IPR conceived or created
in the course of services concerning which the Assignor Party or another member of the Assignor
Group was the Requester, and the Assignee Party or another member of the Assignee Group was the
Performer (collectively, "Assigned Intellectual Property Rights"). ARTICLE III

LICENSING OF INTELLECTUAL PROPERTY RIGHTS

3.1 Licensed Intellectual Property Rights 3.1.1 License Grants by a Licensor Party. Subject to
Section 3.2, a Licensor Party, on behalf of itself and the other members of the Licensor Group, and
solely to the extent the Licensor Party or another member of the Licensor Group has the right to do
so, hereby grants and agrees to grant to the applicable Licensee Party and the other members of the
Licensee Group, subject to the field restriction of Section 3.1.2, a royalty-free, nonexclusive,
perpetual, irrevocable, fully paid-up, worldwide right and license, with the right to sublicense as
provided in Section 3.1.3, to Exploit Intellectual Property Rights that are owned by the Licensor
Party or another member of the Licensor Group immediately following the assignments pursuant to
Article II and meet one or more of the following descriptions with respect to the relevant Licensee
Party: (a) the Intellectual Property Rights are rights under Licensed Patents or other Intellectual
Property Rights that, in each case, as of the Effective Time, are either (A) used in connection
with, or necessary for the ongoing conduct of, the current business of the Licensee Party or another
member of the Licensee Group, or (B) Contemplated to be Used in the business of the Licensee Party,
or another member of the Licensee Group, in the Licensee Group Field; provided, however, that the
license granted in this Section 3.1.1(a) does not apply to the Intellectual Property Rights received
under or otherwise governed by an Excluded Agreement; and/or (b) the Intellectual Property Rights
are embodied in an invention, or proposed invention, that is both (i) described in a Patent or
Invention Disclosure held by the Licensor Party or another member of the Licensor Group and (ii)
conceived by at least one inventor who, at the time of conception, was employed by a member of the
Licensee Group, a non-inclusive list of which inventions and proposed inventions are provided in
Schedule 3.1.1(b), provided, however, that the license granted in this Section 3.1.1(b) does not
apply to an invention conceived under or otherwise governed by an Excluded Agreement; and/or (c) the
Intellectual Property Rights are subject to an assignment to the Licensor Party in Section 2.1.1(b)
concerning Performer Foreground-Delivered IPR conceived or created in the course of services
concerning which the Licensor Party or another member of the Licensor Group was the Requester and
the Licensee Party or another member of the Licensee Group was the Performer; and/or

8
<!-- page 12 -->
(d) the Intellectual Property Rights are Performer Background IPR or Patent rights of the Licensor
Party or another member of the Licensor Group and is necessary for the Licensee Party or another
member of the Licensee Party to Exploit the Performer Foreground-Delivered IPR in the Licensee Group
Field, provided, however, that the license granted in this Section 3.1.1(d) applies only to the
extent necessary for the Licensee Party or another member of the Licensee Group to Exploit the
Performer Foreground-Delivered IPR in the Licensee Group Field. (collectively, "Licensed
Intellectual Property Rights"). 3.1.2 Field Restriction. The licenses granted in Section 3.1.1 are
limited to, and a Licensee Party and the other members of the Licensee Group will have the right to
Exploit, only the Licensed Intellectual Property Rights within the Licensee Group Field, except for
the purposes of research and development at a stage encompassed within U.S. Department of Defense
Technology Readiness Levels 1-6 or NASA Technology Readiness Levels 1-6; provided that (a) such
research is not intended for use outside the Licensee Group Field, and (b) in the course of research
conducted for a third party outside the Licensee Group Field, neither the Licensee Party nor any
member of the Licensee Group (nor any of their respective officers, directors, employees,
contractors, agents or sublicensees) shall disclose such Intellectual Property Rights to the third
party. 3.1.3 Sublicense of Licensed Intellectual Property Rights. A Licensee Party or another member
of the Licensee Group may sublicense its rights in Licensed Intellectual Property Rights hereunder,
solely in support of its respective businesses (and not independent of its current or future
products and related services). In all cases in which the exercise of sublicense rights hereunder
reasonably requires disclosure of Licensed Intellectual Property Rights to a third party, the
applicable member of the Licensee Group will disclose such Licensed Intellectual Property Rights (a)
solely on a "need to know" basis, (b) provided that the Person to receive Licensed Intellectual
Property Rights first agrees in writing to terms of confidentiality and non-use at least as
restrictive as those provided in this Agreement, and (c) provided that the Licensee Party ensures
the performance of, and accepts joint and several responsibility for the performance by each of the
sublicensees of, the obligations of the Licensee Party and the other members of the Licensee Group
under this Agreement. 3.1.4 Improvements. Each of the licenses granted in Section 3.1.1, subject to
the restrictions of Section 3.1.2 and Section 3.1.3, includes the right of a Licensee Party and
other members of the Licensee Group to make improvements to such Licensed Intellectual Property
Rights. Neither a Licensor Party nor any member of the Licensor Group will have any rights to any
such improvements, and as between a Licensee Party and a Licensor Party, the Licensee Party or
applicable member of the Licensee Group will own all such improvements made by the Licensee Party or
such member of the Licensee Group to Licensed Intellectual Property Rights. 3.1.5 No Implied
Licenses. To the extent Intellectual Property Rights of a Party or member of a Party Group are not
expressly granted in this Agreement, they are hereby expressly reserved to the Party or member of
the Party Group. Without limiting the generality of the immediately preceding sentence, no express
grant by a Licensor Party in this Agreement of

9
<!-- page 13 -->
license rights in certain Intellectual Property Rights shall be construed as implying the grant of
any rights by the Licensor Party or another member of the Licensor Group in any other Intellectual
Property Rights held by the Licensor Party or another member of the Licensor Group. 3.2 Reserved
Intellectual Property Rights. Specific reservations shall apply to certain Intellectual Property
Rights as set forth in Schedule 3.2. 3.3 No Rescission. The provisions of this Agreement, including
the license rights provided in this Article III, shall not be terminable or revocable for any
reason. In the event of any breach of this Agreement, the sole remedy of the non-breaching Party
will be to seek monetary damages or equitable relief, including specific performance, as provided in
Article VII, that does not involve a rescission or termination of any of the provisions of this
Agreement (including the license rights provided in this Article III), and each Party irrevocably
waives the right to seek any termination or rescission of any such provisions or rights. ARTICLE IV

TRADEMARKS

4.1 Ownership of United Technologies Trademarks. 4.1.1 Notwithstanding any other provision of this
Agreement to the contrary, as between UTC, on the one hand, and Otis, Carrier and other members of
the Otis Group and the Carrier Group, on the other, all rights in and to the United Technologies
Trademarks, including all goodwill appurtenant thereto, are owned and shall be owned solely and
exclusively by UTC. Without limiting the foregoing, and subject to Section 4.2, Otis and Carrier, on
behalf of themselves and the other members of, respectively, the Otis Group and the Carrier Group,
hereby irrevocably assign to UTC, and agree and promise to assign to UTC, (a) any and all rights,
title and interest in and to the United Technologies Trademarks, including all goodwill appurtenant
thereto held by them and the other members of the Otis Group and the Carrier Group, and (b) any and
all registrations and applications for registration of Trademarks consisting of or containing any of
the United Technologies Trademarks, anywhere in the world, to which Otis, Carrier or another member
of the Otis Group or the Carrier Group holds a legal or equitable interest as of the Effective Time.
Without limitation, the foregoing assignment and promise of assignment includes the right to sue and
recover damages for past and future infringements of the United Technologies Trademarks and to bring
any proceeding in the United States Patent and Trademark Office or any equivalent agency or
governing body in any other country for cancellation, opposition, or other proceeding in connection
with the United Technologies Trademarks. Except as expressly stated in Section 4.2, none of Otis,
Carrier or any other member of the Otis Group or the Carrier Group shall have any right, title or
interest in or to any of the United Technologies Trademarks, and any and all use of the United
Technologies Trademarks, whether or not authorized pursuant to Section 4.2, shall inure solely and
exclusively to UTC for all purposes.

10
<!-- page 14 -->
4.1.2 Otis and Carrier, on behalf of themselves and the other members of, respectively, the Otis
Group and the Carrier Group, agree and promise to assist UTC and the other members of the UTC Group,
at UTC's request, in UTC's discretion and at UTC's cost, in applying for, registering, maintaining,
renewing, demonstrating use of, recording UTC's and the other members of the UTC Group's rights in,
and otherwise perfecting, and defending and enforcing against third party infringers, the rights of
UTC and the other members of the UTC Group in the United Technologies Trademarks and all goodwill
associated therewith, including executing, verifying, acknowledging and delivering any and all
documents, including any instruments of transfer and recordable assignments, and confirmations of
use, and performing such other acts deemed necessary in the reasonable opinion of UTC. 4.1.3 Otis
and Carrier, on behalf of themselves and the other members of, respectively, the Otis Group and the
Carrier Group, agree and promise not to (a) challenge in any jurisdiction or venue the right or
title of UTC or any other members of the UTC Group in and to any United Technologies Trademark, or
the validity or enforceability of any United Technologies Trademark or any registration thereof, or
(b) register or renew, attempt to register or renew, or assist a Person other than UTC or a member
of the UTC Group in registering or renewing, any United Technologies Trademark. 4.2 Use of United
Technologies Trademarks 4.2.1 Except as expressly provided in this Section 4.2, after the Effective
Time, none of Otis, Carrier or any other members of the Otis Group or the Carrier Group shall use,
or have the right to use, any of the United Technologies Trademarks. 4.2.2 Without limitation, Otis
and Carrier as promptly as reasonably practicable (but in any case within six (6) months of the
Effective Time) shall cause each member of, respectively, the Otis Group and the Carrier Group
having a corporate name that includes any of the United Technologies Trademarks to apply to change
its corporate name to a name that does not include any of the United Technologies Trademarks,
including, within six (6) months of the Effective Time, by making any legal filings in each relevant
jurisdiction necessary to effect such change worldwide. 4.2.3 UTC, on behalf of itself and the other
members of the UTC Group, hereby grants to Otis, Carrier and the other members of the Otis Group and
the Carrier Group a limited, non-exclusive, non-transferable, personal and nonsublicensable right to
continue temporarily to use, following the Effective Time, any United Technologies Trademark it is
using immediately prior to the Effective Time, solely to the extent of such pre- Separation use and
in accordance with product quality standards and programs in place at the respective member of the
Otis Group or the Carrier Group immediately prior to the Effective Time, and strictly in accordance
with this Section 4.2.3; provided that Otis and Carrier shall, and shall cause each of its
respective Affiliates (including, after the Effective Time, the members of, respectively, the Otis
Group and the Carrier Group) (a) not to hold itself out as having any affiliation with UTC or any
member of the UTC Group (except to the extent a third party may infer such affiliation merely due to
the limited use of the United Technologies Trademarks as contemplated herein), and (b) to use
diligent efforts to eliminate use of the United Technologies Trademarks. In any event, as soon as
practicable after the Effective Time, and in any event within three (3) years thereafter, Otis and

11
<!-- page 15 -->
Carrier shall, and shall cause each of its respective Affiliates (including, after the Effective
Time, the members of, respectively, the Otis Group and the Carrier Group), and any of its licensees
or its respective Affiliates' licensees, to (a) cease and discontinue use of all United Technologies
Trademarks, and (b) complete the removal of the United Technologies Trademarks from all of their
respective products, signage, vehicles, properties, technical information, stationery and
promotional or other marketing materials and other assets of Otis, Carrier and the other members of
the Otis Group and the Carrier Group. Except for the limited, temporary license granted in this
Section 4.2.3, neither UTC nor any other member of the UTC Group grants any right or license
hereunder, express or implied, to use any United Technologies Trademarks. 4.3 Special Trademark
Provisions. Special provisions concerning Trademarks are provided in Schedule 4.3. ARTICLE V

EXCLUDED AGREEMENTS

5.1 No Change to Excluded Agreements. The Parties do not intend by this Agreement to amend or
otherwise change the Intellectual Property Rights or other provisions of any Excluded Agreement.
Intellectual Property Rights provided, received or created pursuant to an Excluded Agreement will
not constitute Licensed Intellectual Property Rights, and, with respect to the applicable parties
thereto, will continue to be subject to any licenses, permissions or restrictions granted or imposed
in the respective Excluded Agreement in accordance with its terms. ARTICLE VI

CONFIDENTIALITY

6.1 Received Information and Materials. The Parties acknowledge that members of each Party Group
currently are in possession of information and materials f members of the other two Party Groups,
which may include designs, drawings, specifications, technical data and other data, databases,
formulae, algorithms and mathematical embodiments, plans, software, proposals, processes,
procedures, manufacturing techniques, and business methods, and some of which may be included in the
Licensed Intellectual Property Rights. With respect to a receiving Party, such information will be
referred to individually or collectively as "Received Information and Materials," provided that
Received Information and Materials will not include information disclosed under any Excluded
Agreement. 6.2 Confidential Information. All Received Information and Materials that are identified
as or are of the type generally considered as confidential or proprietary or that have historically
been subject to reasonable confidentiality and proprietary protections, and any communications or
information provided after the Effective Time pursuant to this Agreement among members of the
different Party Groups, will be deemed confidential and proprietary information of the Person that
provided it, unless the information (a) is or becomes generally available to the public other than
as a result of a disclosure in breach of this Agreement; (b) is rightfully available to or known by
the receiving Party prior to receipt by the receiving Party

12
<!-- page 16 -->
without any obligation of confidentiality; (c) is received by the receiving Party from a third
party, provided that the third party is not known by the receiving Party, after reasonable inquiry,
to be in breach of any obligation of confidentiality; or (d) was independently developed by the
receiving Party, without violating any contractual or legal obligation ("Confidential Information").
6.3 Obligations. With respect to Confidential Information in its possession, custody or control, a
receiving member of a Party Group will: (a) hold all Confidential Information in confidence, using
the same degree of care such receiving member uses to protect its own confidential information of a
similar nature, but in no event less than a reasonable degree of care, including sharing
Confidential Information internally only on a "need to know" basis, (b) not disclose Confidential
Information to any third party, other than as permitted with respect to Licensed Intellectual
Property Rights pursuant to Section 3.1.3, and (c) use Confidential Information only to the extent
authorized. 6.4 Termination of UTC NDA. Upon the Effective Time, (a) the Amended and Restated
Nondisclosure Agreement, by and between United Technologies Companies, dated July 26, 2012 (the "UTC
NDA"), will terminate as among UTC and the other members of the UTC Group, Otis and the other
members of the Otis Group, and Carrier and the other members of the Carrier Group, (b) the
information disclosed under the UTC NDA (i) will be deemed Received Information and Materials and
Confidential Information under this Agreement, and (ii) will be licensed hereunder for use by UTC
and the other members of the UTC Group, Otis and the other members of the Otis Group, Carrier and
the other members of the Carrier Group, solely to the extent it is Licensed Intellectual Property
Rights granted to UTC and the other members of the UTC Group, Otis and the other members of the Otis
Group or Carrier and the other members of the Carrier Group, respectively, and (c) notwithstanding
paragraph 3 of the UTC NDA, such information disclosed thereunder will continue to be protected for
as long as it remains Confidential Information. ARTICLE VII

LIMITATIONS AND DISCLAIMERS

7.1 Subsequent Delivery of Intellectual Property Rights. 7.1.1 For a period of six (6) months after
the Effective Time, upon written request by an Assignee Party or a Licensee Party, and solely to the
extent the Assignor Party or another member of the Assignor Group or the Licensor Party or another
member of the Licensor Group, respectively, has the right to do so, the Assignor Party or the
Licensor Party, respectively, shall use commercially reasonable efforts to provide (and to cause
other members of the Assignor Group or the Licensor Group, respectively, to provide) to the
requesting Assignee Party or the Licensee Party, respectively, copies of tangible embodiments of the
Assigned Intellectual Property Rights and the Licensed Intellectual Property Rights, respectively,
in the possession of a member of the Assignor Group or the Licensor Group, respectively, and not in
the possession of a member of the Assignee Group or the Licensee Group, respectively, upon the
Effective Time, to the extent that both (a) such Assigned Intellectual Property Rights or such
Licensed Intellectual Property Rights, respectively, are necessary for the ongoing conduct of the
current

13
<!-- page 17 -->
business of the requesting Assignee Party or another member of the Assignee Group or the requesting
Licensee Party or another member of the Licensee Group, respectively, or was in use in such business
as of the Effective Time, and (b) such tangible embodiments are reasonably necessary for the use of
such Assigned Intellectual Property Rights or such Licensed Intellectual Property Rights,
respectively, identified in Section 7.1.1(a). 7.2 No Additional Obligations. Except as expressly
provided in this Agreement, this Agreement does not create any obligation on the part of any of the
Parties to provide or create any of the following with respect to the Intellectual Property Rights
owned, transferred, granted or licensed under this Agreement: (a) explanations, corrections,
revisions, improvements, upgrades, technical assistance, maintenance, installation, debugging, or
any other support; or (b) tangible embodiments, documents, information, software, data or any other
items, deliverables or services. 7.3 DISCLAIMER. EXCEPT AS EXPRESSLY PROVIDED IN THIS AGREEMENT, THE
SDA OR ANY OTHER ANCILLARY AGREEMENT, (A) EACH OF THE PARTIES CONVEYS INTELLECTUAL PROPERTY RIGHTS
UNDER THIS AGREEMENT SOLELY ON AN "AS IS," "WHERE IS" AND "WITH ALL FAULTS" BASIS, AND (B) NONE OF
THE PARTIES MAKES, AND EACH HEREBY EXPRESSLY DISCLAIMS, ANY REPRESENTATIONS OR WARRANTIES OF ANY
KIND WITH RESPECT TO SUCH INTELLECTUAL PROPERTY RIGHTS, WHETHER EXPRESS OR IMPLIED, INCLUDING ANY
REPRESENTATION OR WARRANTY WITH RESPECT TO MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
COMPLETENESS OR SUFFICIENCY, OR EXPORTABILITY, OR WITH RESPECT TO THE VALIDITY, SCOPE,
ENFORCEABILITY OR NONINFRINGEMENT OF ANY OF SUCH INTELLECTUAL PROPERTY RIGHTS. FOR AVOIDANCE OF
DOUBT, THE REPRESENTATIONS AND WARRANTIES PROVIDED IN THE SDA ARE NOT AFFECTED BY THIS DISCLAIMER.
7.4 Limitations of Liability. Except in connection with a Party's willful and intentional breach of
this Agreement or fraud, in no event shall any Party or its Affiliates, under any circumstances, be
liable or obligated in any manner to another Party or its Affiliates for any consequential, special,
incidental, exemplary, indirect, punitive or similar damages, or for any loss of future revenue,
profits or income, or for any diminution in value damages measured as a multiple of earnings,
revenue or any other performance metric arising out of or relating to this Agreement or the
transactions contemplated in this Agreement, even if such Party or its Affiliate is informed in
advance of the possibility of such damages occurring and regardless of whether or not the damages
were foreseeable and regardless of the theory or cause of action upon which any damages might be
based. This limitation is separate and independent of any other remedy limitations and shall not
fail if any such other limitation fails. The foregoing shall not be deemed to modify or limit any
rights or remedies to the extent arising under the SDA, any other Ancillary Agreement or any
Excluded Agreement.

14

ARTICLE VIII

GOVERNING LAW AND DISPUTE RESOLUTION
<!-- page 18 -->
8.1 Governing Law. This Agreement shall be governed by, and construed and enforced in accordance
with, the laws of the State of Delaware, without regard to any conflict or choice-of-law provision
or rule (whether of the State of Delaware or any other jurisdiction) that would cause the
application of the laws of any jurisdiction other than the State of Delaware. 8.2 Alternative
Dispute Resolution. Any dispute, controversy or claim between or among the Parties (whether sounding
in contract, tort, or otherwise) arising out of or resulting from this Agreement, including the
meaning of its provisions or the performance of any such provisions by a Party, its breach,
termination, invalidity or otherwise (each, a "Dispute") will be resolved in accordance with the
procedures specified in this Article VIII, which will be the sole and exclusive procedure for the
resolution of any such Dispute. 8.2.1 Negotiations. The Parties will attempt in good faith to
resolve any Dispute promptly by negotiations among executives of the Parties who have authority to
settle the Dispute. The disputing Party will give the other Party or Parties, as applicable, written
notice of the Dispute. Within twenty (20) days after receipt of said notice, the receiving Party or
Parties will submit to the other a written response. The notice and response will include: (a) a
statement of each Party's position and a summary of the evidence and arguments supporting that
position, and (b) the name and title of the executive who will represent that Party. The executives
will meet at a mutually acceptable time and place within thirty (30) days of the date of the
disputing Party's notice and thereafter as often as they reasonably deem necessary to exchange
relevant information and to attempt to resolve the Dispute. 8.2.2 Arbitration. If a Dispute has not
been resolved within sixty (60) days of the date of the disputing Party's notice, any Party desiring
a non-negotiated resolution shall refer the Dispute to binding arbitration pursuant to the
then-current commercial arbitration rules and supplementary procedures of commercial arbitration of
the American Arbitration Association (the "AAA Rules"). The arbitral tribunal shall be composed of a
single arbitrator appointed in accordance with the AAA Rules in any matter in which an injunction,
specific performance or other equitable relief is not requested and the value of the relief any
Party seeks (whether by claim or counterclaim) does not exceed three million United States dollars
(US $3,000,000). In all other matters, including any matter in which an injunction, specific
performance or other equitable relief is requested, the arbitral tribunal shall be composed of a
panel of three (3) arbitrators appointed in accordance with the AAA Rules. The arbitration shall
take place in New York, New York. Each Party will bear its own expenses (including attorneys' fees),
and the Parties will share equally the compensation and expenses of the arbitrators and the
arbitration. Any arbitration award will be final and shall be enforceable in any court of competent
jurisdiction. 8.3 Confidentiality. All negotiations, and all statements made and documents provided
or exchanged in connection with an arbitration under Section 8.2.2 will be confidential. Except with
the prior written consent of the other Party or Parties in the Dispute, as applicable, none of the
Parties will disclose the existence or content of the Dispute, or the results of any

15
<!-- page 19 -->
dispute resolution process, to third parties other than (a) as may be required by law or legal
process after having provided the other Party or Parties with notice thereof and the opportunity to
seek a protective order over such information, or (b) to outside counsel and tax, financial, and
accounting professionals in connection with the Dispute. 8.4 Equitable Relief. The Parties
acknowledge and agree that monetary damages (even if available) may not be an adequate remedy in the
event that a Party does not perform the provisions of this Agreement in accordance with their
specified terms or otherwise breaches any provisions of this Agreement. Accordingly, and
notwithstanding any other provision of this Agreement, any Party will be entitled to seek from the
arbitrator or arbitration tribunal, and the arbitrator or arbitration tribunal will be empowered to
grant, an injunction, specific performance or other equitable relief (whether preliminary,
permanent, temporary, conservatory or otherwise, and including temporary restraining orders) to
prevent such breaches of this Agreement and to enforce specifically the terms hereof, in addition to
any other remedy to which such Party is entitled at law or in equity. The Party alleging the breach
shall not be required to provide any bond or other security in connection with any such award, but
the Parties reserve all rights to otherwise contest the propriety of any award of injunctive relief.
In addition, and notwithstanding any other provision of this Agreement, any Party will be entitled
to seek in a court of competent jurisdiction an injunction, specific performance or other equitable
relief to prevent breaches of this Agreement pending an arbitration under Section 8.2.2. ARTICLE IX

GENERAL PROVISIONS

9.1 Entire Agreement; Conflict Among Agreements. This Agreement, together with the SDA, the other
Ancillary Agreements and the Exhibits and Schedules hereto and thereto, constitute the entire
agreement among the Parties with respect to the subject matter of this Agreement and supersede any
prior discussion, correspondence, negotiation, proposed term sheet, agreement, understanding or
arrangement with respect to such subject matter, and there are no agreements, understandings,
representations or warranties among the Parties other than those set forth or referred to in this
Agreement with respect to such subject matter. In the event of any conflict between the provisions
of this Agreement and the provisions of the SDA or any other Ancillary Agreement, the provisions of
this Agreement shall control, provided, however, that (a) in the event of a conflict between the
provisions of this Agreement and the provisions of the Transition Services Agreement, the
conflicting provisions of the Transition Services Agreement shall control over the conflicting
provisions of this Agreement, and (b) nothing in this Agreement limits any of the representations,
warranties or indemnity obligations under the SDA or any other Ancillary Agreement. In the event of
any conflict between the provisions of this Agreement and any agreement that was entered into at any
time prior to the Effective Time between or among members of different Party Groups that is not an
Excluded Agreement, the conflicting provisions of this Agreement shall control. 9.2 Assignment and
Change of Control; Successor and Assigns 9.2.1 No Party may directly or indirectly sell, assign or
otherwise transfer (whether by asset or stock sale, merger, reorganization or otherwise) any or all
of its rights or

16
<!-- page 20 -->
delegate any or all of its obligations under this Agreement without the express prior written
consent of the other Parties, except as follows: (a) Otis or Carrier may (i) freely sell, assign or
otherwise transfer, in whole or from time to time in part, Assigned Intellectual Property Rights
assigned to it hereunder; and (ii) sell, assign or otherwise transfer, in whole or from time to time
in part, its rights and obligations under this Agreement (A) to any Affiliate of Otis or Carrier,
respectively, (B) to any financing entity, in connection with the grant of a revocable security
interest necessary for financing, or (C) to a Person acquiring (whether by asset or stock sale,
merger, reorganization or otherwise) all or substantially all of the relevant business of Otis or
Carrier, respectively, that agrees to be bound by the terms and conditions of this Agreement; but
any such transfer or assignment will not relieve Otis or Carrier, respectively, of any of its
obligations hereunder. (b) UTC may (i) freely sell, assign or otherwise transfer, in whole or from
time to time in part, Assigned Intellectual Property Rights assigned to it hereunder; and (ii) sell,
assign or otherwise transfer, in whole or from time to time in part, its rights under this Agreement
(A) to any member of the UTC Group, (B) to any financing entity, in connection with the grant of a
revocable security interest necessary for financing, or (C) to a Person acquiring (whether by asset
or stock sale, merger, reorganization or otherwise) all or substantially all of the relevant
business of UTC that agrees to be bound by the terms and conditions of this Agreement; but any such
transfer or assignment will not relieve UTC of any of its obligations hereunder. 9.2.2 Any purported
sale, assignment or other transfer in contravention of this Section 9.2 shall be null and void.
9.2.3 Subject to Section 9.2.1 and Section 9.2.2, this Agreement shall be binding upon and inure to
the benefit of the Parties and their respective successors, assigns and transferees. 9.3 Bankruptcy.
All licenses granted under this Agreement will be deemed licenses of rights to intellectual property
for purposes of Section 365(n) of the United States Bankruptcy Code and a licensee under this
Agreement will retain and may fully exercise all of its rights and elections under the United States
Bankruptcy Code. 9.4 Amendments and Waivers. This Agreement may not be modified or amended, except
by an instrument or instruments in writing signed by the Party against whom enforcement of any such
modification or amendment is sought. Any Party to this Agreement may, only by an instrument in
writing, waive compliance by the other Parties with any term or provision of this Agreement on the
part of such other Parties to this Agreement to be performed or complied with. The waiver by any
Party to this Agreement of a breach of any term or provision of this Agreement shall not be
construed as a waiver of any subsequent breach. No failure or delay by any Party in exercising any
right or privilege hereunder shall operate as a waiver thereof, nor shall any single or partial
exercise thereof preclude any other or further exercise thereof or the exercise of any other right,
power or privilege. Subject to Section 3.3, the rights and remedies herein provided shall be
cumulative and not exclusive of any rights or remedies provided by law.

17
<!-- page 21 -->
9.5 Notice. All notices or other communications required or permitted hereunder by a Party shall be
in writing to the other Parties at the address provided below (or at such other address as such
Party may designate by notice pursuant to this Section 9.5), and shall be deemed given or delivered
(a) when delivered personally against written receipt, (b) if sent by registered or certified mail,
return receipt requested, postage prepaid, when received, and (c) when delivered by a nationally
recognized overnight courier service, prepaid: To UTC: United Technologies Corporation 10 Farm
Springs Farmington, CT 06302 Attention: Chief Intellectual Property Counsel To Otis: Otis Worldwide
Corporation One Carrier Place Farmington, CT 06032 Attention: Chief Intellectual Property Counsel To
Carrier: Carrier Global Corporation 13995 Pasteur Boulevard Palm Beach Gardens, FL 33418 Attention:
Chief Intellectual Property Counsel

9.6 Severability. If any term, provision, covenant or restriction of this Agreement is held by a
court of competent jurisdiction or other authority to be invalid, void or unenforceable, the
remainder of the terms, provisions, covenants and restrictions of this Agreement shall remain in
full force and effect and shall in no way be affected, impaired or invalidated so long as the
economic or legal substance of the transactions contemplated hereby is not affected in any manner
materially adverse to any Party hereto. Upon such a determination, the Parties shall negotiate in
good faith to modify this Agreement so as to effect the original intent of the Parties as closely as
possible in a mutually acceptable manner in order that the transactions contemplated hereby be
consummated as originally contemplated to the fullest extent possible. 9.7 Counterparts. This
Agreement may be executed in one or more counterparts, and by the different Parties in separate
counterparts, each of which when executed shall be deemed to be an original but all of which taken
together shall constitute one and the same agreement. Delivery of an executed counterpart of a
signature page to this Agreement by electronic means shall be as effective as delivery of a manually
executed counterpart of this Agreement. 9.8 Further Assurances. Each Party agrees, upon written
request of another Party, to do all acts and execute, deliver and perform all additional documents,
instruments and agreements, which may be reasonably required to implement the provisions and
purposes of this

18
<!-- page 22 -->
Agreement; provided, however, that, except as expressly set forth in this Agreement, nothing in this
Agreement shall be construed as obligating a Party or its Affiliates to deliver any additional
Intellectual Property Rights, or any tangible embodiments of any Intellectual Property Rights, to
another Party or its Affiliates. 9.9 Interpretation. For the purposes of this Agreement, (a) words
in the singular shall be held to include the plural and vice versa, and words of one gender shall be
held to include the other gender as the context requires; (b) references to the terms Article,
Section, paragraph, Exhibit and Schedule are references to the Articles, Sections, paragraphs,
Exhibits and Schedules to this Agreement, unless otherwise specified; (c) any capitalized terms used
in any Exhibit or Schedule but not otherwise defined therein shall have the meaning as defined in
this Agreement; (d) the terms "hereof," "herein," "hereby," "hereto" and derivative or similar words
refer to this entire Agreement, including the Schedules and Exhibits hereto, and not to any
particular provision thereof; (e) references to "$" shall mean U.S. dollars; (f) the word
"including" and words of similar import when used in this Agreement shall mean "including without
limitation," unless otherwise specified; (g) the word "or" shall not be exclusive; (h) references to
"written" or "in writing" include in electronic form; (i) provisions shall apply, when appropriate,
to successive events and transactions; (j) the Parties have each participated in the negotiation and
drafting of this Agreement and if an ambiguity or question of interpretation should arise, this
Agreement shall be construed as if drafted jointly by the Parties and no presumption or burden of
proof shall arise favoring or burdening any Party by virtue of the authorship of any of the
provisions in this Agreement; (k) references to any statute shall be deemed to refer to such statute
as amended through the date hereof; (l) references to any Contract are to that Contract as amended,
modified or supplemented from time to time in accordance with the terms hereof and thereof; (m)
references to an Affiliate of a Party mean current and future Affiliates of such Party; (n) a
reference to any Person includes such Person's successors and permitted assigns; (o) any reference
to "days" shall mean calendar days, unless Business Days are expressly specified; and (p) when
calculating the period of time before which, within which or following which any act is to be done
or step taken pursuant to this Agreement, the date that is the reference date in calculating such
period shall be excluded and if the last day of such period is not a Business Day, the period shall
end on the next succeeding Business Day. [REMAINDER OF PAGE INTENTIONALLY LEFT BLANK] [SIGNATURE
PAGE FOLLOWS]

19
<!-- page 23 -->
IN WITNESS WHEREOF, this Agreement has been signed by or on behalf of each of the Parties as of the
day first above written. UNITED TECHNOLOGIES CORPORATION By: /s/ Michael R. Dumais Name: Michael R.
Dumais Title: Executive Vice President, Operations & Strategy OTIS WORLDWIDE CORPORATION

By: /s/ Michael P. Ryan Name: Michael P. Ryan Title: Vice President, Controller CARRIER GLOBAL
CORPORATION By: /s/ Kyle Crockett Name: Kyle Crockett Title: Vice President, Controller

20
