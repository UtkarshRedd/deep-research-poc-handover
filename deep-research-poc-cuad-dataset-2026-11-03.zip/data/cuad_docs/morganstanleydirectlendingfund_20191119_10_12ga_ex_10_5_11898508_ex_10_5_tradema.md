<!-- page 1 -->
# TRADEMARK LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| SEC Filing Date | 2019-11-19 |
| Parties | Morgan Stanley Investment Management Inc. ("Licensor"); Morgan Stanley Direct Lending Fund ("Licensee") |
| Source | CUAD v1 / MorganStanleyDirectLendingFund_20191119_10-12GA_EX-10.5_11898508_EX-10.5_Trademark License Agreement |

Exhibit 10.5 TRADEMARK LICENSE AGREEMENT This TRADEMARK LICENSE AGREEMENT (the "Agreement") is
effective as of the [·] day of [·], 2019 ("Effective Date") between Morgan Stanley Investment
Management Inc. ("Licensor"), and Morgan Stanley Direct Lending Fund, a Delaware corporation
("Licensee"). WHEREAS, Licensor is the owner of all rights to the trademark "Morgan Stanley" and the
"Morgan Stanley" design (collectively, the "Brand"); WHEREAS, Licensee is a closed-end investment
company that has elected to be treated as a business development company under the Investment
Company Act of 1940, as amended (together with the rules promulgated thereunder) (the "Licensee
Business"); WHEREAS, in connection with Licensee's public filings, requests for information from
state and federal regulators, offering materials and advertising materials, and press releases,
Licensee desires to state in such materials that investment advisory services are being provided by
Licensor (or an affiliate thereof) to Licensee (collectively, the "Permitted Activity"); and
WHEREAS, Licensor is willing to permit Licensee to use the Brand for the Permitted Activity, subject
to the terms and conditions herein. NOW, THEREFORE, in consideration of the premises and the mutual
promises and covenants contained herein and for other good and valuable consideration, the receipt
and sufficiency of which is hereby acknowledged, the parties agree as follows: 1. Grant of Rights;
Sublicensing. Section 1.1. License Grant. Subject to the terms and conditions herein, Licensor
hereby grants to Licensee a non-exclusive, non- transferable, and (subject to Section 1.2 hereof)
non-sublicensable license for the use of the Brand solely for the Permitted Activity. Section 1.2.
Sublicensing. Licensee may sublicense its rights under Section 1.1 solely to a current or future
wholly owned subsidiary of Licensee, and then only with the prior written consent of Licensor (which
shall not be unreasonably withheld), provided that any such sublicense shall terminate
automatically, with no need for written notice to the sublicensee, if (a) such entity ceases to be a
wholly owned subsidiary of Licensee, (b) this Agreement terminates for any reason or (c) such
sublicensee materially breaches its sublicense in a manner that harms the Brand and does not cure
the same within 15 days after notice from Licensor or Licensee. Licensee shall notify Licensor
promptly after becoming aware that any sublicensee has breached its sublicense and shall ensure that
all sublicenses provide (i) for the foregoing termination rights of Licensor and (ii) obligations
for sublicensee with respect to the Brand that are consistent with those of Licensee herein. Any act
or omission by a sublicensee that would breach this Agreement if committed by Licensee shall
constitute a breach of this Agreement by Licensee. 2. Ownership. Licensee acknowledges and agrees
that, as between the parties, Licensor is the sole owner of all right, title and interest in and to
the Brand. Licensee agrees not to do anything inconsistent with such ownership, including (i) filing
to register any trademark or service mark containing the Brand or (ii) directly or indirectly
challenging, contesting or otherwise

Source: MORGAN STANLEY DIRECT LENDING FUND, 10-12G/A, 11/19/2019
<!-- page 2 -->
disputing the validity, enforceability or Licensor's ownership of the Brand (and the associated
goodwill), including without limitation, in any claim, allegation, action, demand, proceeding or
suit ("Action") regarding enforcement of this Agreement or involving any third party. The parties
intend that any and all goodwill in the Brand arising from Licensee's or any applicable
sublicensees' Permitted Activity shall inure solely to the benefit of Licensor. Notwithstanding the
foregoing, in the event that Licensee or any sublicensee is deemed to own any rights in the Brand,
Licensee hereby irrevocably assigns (or shall cause such sublicensees to assign), without further
consideration, such rights to Licensor together with all goodwill associated therewith. 3. Use of
the Permitted Activity. Section 3.1. Quality Control. Licensee's Permitted Activity shall be in a
manner consistent with Licensor's high standards of and reputation for quality, and in accordance
with good trademark practice wherever any of the same are used. Licensee shall not take any action
that could reasonably be expected to harm the Brand or the goodwill associated therewith. Licensee
shall use with the Brand any applicable trademark notices as may be requested by Licensor or
required under applicable laws, regulations, stock exchange and other rules ("Laws") and reputable
industry practice. Section 3.2. Prior Written Approval. Prior to using the Brand in any manner,
Licensee shall submit all proposed uses to Licensor for prior written approval. Section 3.3.
Compliance with Laws. Licensee shall, at its sole expense, comply at all times with all applicable
Laws and reputable industry practice pertaining to the Licensee Business and Permitted Activity. 4.
Termination. Section 4.1. Term. The term of this Agreement commences on the Effective Date and
continues in perpetuity, unless termination occurs pursuant to Sections 4.2 through 4.4. Section
4.2. Termination for Convenience. Licensor reserves the right to terminate this Agreement
immediately upon written notice for any reason, including if the usage of the Brand is not in
compliance with the standards and policies. Section 4.3. Termination for Breach. If either party
materially breaches one or more of its obligations hereunder, the other party may terminate this
Agreement, effective upon written notice, if the breaching party does not cure such breach within 15
days after written notice thereof (or any mutually agreed extension). Licensor may terminate this
Agreement immediately, effective upon written notice, if (i) Licensee attempts to violate Section 8
or (ii) a sublicensee materially breaches its sublicense in a manner that harms the Brand, and (a)
such sublicensee does not cure the same within 15 days after notice from Licensor or Licensee or (b)
Licensee does not terminate such sublicense within 15 days after notice from Licensor. Section 4.4.
Termination of Advisory Agreement. This Agreement shall terminate automatically without notice and
immediately (a) if MS Capital Partners Adviser Inc. or another affiliate of Licensor is no longer
acting as the investment adviser (any such entity, the "Advisor") to Licensee under the Investment
Advisory Agreement, dated as of [·], 201[9] (as the same may 2

Source: MORGAN STANLEY DIRECT LENDING FUND, 10-12G/A, 11/19/2019
<!-- page 3 -->
be amended, modified or otherwise restated, the "Investment Advisory Agreement"), or a similar
agreement, or (b) the Advisor is no longer an affiliate of Licensor. Further, Licensor may terminate
this Agreement, effective upon written notice, at any time after 30 days from the date that Licensee
notifies Licensor that the Investment Advisory Agreement has terminated or is not being renewed. The
term "affiliate" as used herein shall have the meaning given to such term in the Investment Advisory
Agreement. Section 4.5. Effect of Termination; Survival. Upon termination of this Agreement for any
reason, (a) Licensee shall immediately, except as required by applicable Law, (i) cease all use of
the Permitted Activity; and (b) the parties shall cooperate so as to best preserve the value of the
Brand. Section 2, this Section 4.5, and Sections 6.2, 6.3, 7 and 9 shall survive termination of this
Agreement. 5. Infringement. Licensee shall notify Licensor promptly after it becomes aware of any
actual or threatened infringement, imitation, dilution, misappropriation or other unauthorized use
or conduct in derogation ("Infringement") of the Brand. Licensor shall have the sole right to bring
any Action to remedy the foregoing, and Licensee shall cooperate with Licensor in same, at
Licensor's expense. 6. Representations and Warranties; Limitations. Section 6.1. Each party
represents and warrants to the other party that: (a) This Agreement is a legal, valid and binding
obligation of the warranting party, enforceable against such party in accordance with its terms,
subject to the effect of any applicable bankruptcy, insolvency, reorganization, moratorium or
similar laws affecting creditors' rights and remedies generally, and subject, as to enforceability,
to the effect of general principles of equity (regardless of whether enforcement is considered in a
proceeding at law or in equity); (b) The warranting party is not subject to any judgment, order,
injunction, decree or award that would interfere with its performance of any of its obligations
hereunder; and (c) The warranting party has full power and authority to enter into and perform its
obligations under this Agreement in accordance with its terms. Section 6.2. EXCEPT AS EXPRESSLY SET
FORTH IN SECTION 6.1, LICENSOR MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, WITH
RESPECT TO THIS AGREEMENT AND THE BRAND, AND EXPRESSLY DISCLAIMS ALL SUCH REPRESENTATIONS AND
WARRANTIES, INCLUDING ANY WITH RESPECT TO TITLE, NON-INFRINGEMENT, MERCHANTABILITY, VALUE,
RELIABILITY OR FITNESS FOR USE. LICENSEE'S USE OF THE PERMITTED ACTIVITY IS SOLELY ON AN "AS-IS"
BASIS. Section 6.3. EXCEPT WITH RESPECT TO LICENSEE'S INDEMNIFICATION OBLIGATIONS UNDER SECTION 7,
NEITHER PARTY WILL BE LIABLE TO THE OTHER PARTY FOR SPECIAL, INDIRECT, CONSEQUENTIAL, EXEMPLARY,
PUNITIVE OR INCIDENTAL DAMAGES (INCLUDING LOST PROFITS OR GOODWILL, BUSINESS 3

Source: MORGAN STANLEY DIRECT LENDING FUND, 10-12G/A, 11/19/2019
<!-- page 4 -->
INTERRUPTION AND THE LIKE) RELATING TO THIS AGREEMENT, EVEN IF IT HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES. 7. Indemnification. Section 7.1. Indemnity by Licensee. Licensee will
defend at its expense, indemnify and hold harmless Licensor and its affiliates and its and their
respective directors, officers, employees, shareholders, investors, agents and representatives from
any losses, liabilities, obligations, damages, awards, settlements, judgments, fees, costs or
expenses (including reasonable attorneys' fees and costs of suit) arising out of or relating to any
third-party Action against any of them that arises out of or relates to (i) any breach by Licensee
of this Agreement or its warranties, representations, covenants and undertakings hereunder, (ii)
Licensee's operation of the Licensee Business or (iii) any claim that Licensee's use of the Brand,
other than as explicitly authorized by this Agreement, Infringes the rights of a third party.
Section 7.2. Indemnification Procedure. Licensor will promptly notify Licensee in writing of any
indemnified claim and promptly as practicable tender its defense to Licensee. Any delay in such
notice or tender will not relieve Licensee from its obligations to the extent it is not prejudiced
thereby. Licensor will cooperate with Licensee at Licensee's expense in the defense of any
indemnified claim. Licensee may not settle any indemnified claim without Licensor's prior written
consent in Licensor's sole discretion. Licensor may participate in its defense of an indemnified
claim with counsel of its own choice at its own expense. 8. Assignments. Licensee may not assign,
transfer, pledge, mortgage or otherwise encumber this Agreement or its right to use the Brand (or
assume this Agreement in bankruptcy), in whole or in part, without the prior written consent of
Licensor in its sole discretion, except for an assignment outside of bankruptcy to a successor
organization that is solely the result of a name change by Licensee. For the avoidance of doubt, a
merger, change of control, reorganization or sale of all or substantially all of the stock of
Licensee shall be deemed an "assignment" requiring the above consent, regardless of whether Licensee
is the surviving entity or whether such transaction constitutes an assignment under applicable law.
Licensee acknowledges that its identity is a material condition that induced Licensor to enter into
this Agreement. Any attempted action in violation of the foregoing shall be null and void ab initio
and of no force or effect, and shall result in immediate termination of this Agreement. In the event
of a permitted assignment hereunder, this Agreement shall be binding upon and inure to the benefit
of the parties and their respective permitted assigns. 9. Miscellaneous. Section 9.1. Notice. Any
notices herein shall be deemed to have been duly given if (i) delivered or delivered by facsimile,
when received, (ii) sent by U.S. Express Mail or recognized overnight courier, on the following
business day or (iii) delivered by electronic mail, when received: 4

Source: MORGAN STANLEY DIRECT LENDING FUND, 10-12G/A, 11/19/2019
<!-- page 5 -->
LICENSOR: Morgan Stanley Investment Management Inc. 1585 Broadway New York, NY 10036 Attention: [·]
Facsimile: [·] Email: [·]

LICENSEE: Morgan Stanley Direct Lending Fund 1585 Broadway New York, NY 10036 Attention: [·]
Facsimile: [·] Email: [·] Section 9.2. Integration. This Agreement contains the entire agreement
among the parties with respect to the subject matter hereof, and supersedes all prior and
contemporaneous agreements and understandings (including, without limitation, any prior agreements
between Licensee and Licensor), with respect thereto. Section 9.3. Amendments. Neither this
Agreement, nor any terms hereof, may be amended except in an instrument in writing executed by the
parties. Section 9.4. Governing Law. THIS AGREEMENT SHALL BE GOVERNED BY, AND CONSTRUED AND
INTERPRETED IN ACCORDANCE WITH, THE LAW OF THE STATE OF NEW YORK. EACH OF THE PARTIES IRREVOCABLY
AND UNCONDITIONALLY SUBMITS TO THE EXCLUSIVE JURISDICTION OF THE STATE AND FEDERAL COURTS LOCATED IN
NEW YORK CITY FOR THE PURPOSE OF ANY ACTION RELATING TO OR ARISING OUT OF THIS AGREEMENT. Section
9.5. Waiver of Jury Trial. EACH PARTY HEREBY IRREVOCABLY AND UNCONDITIONALLY WAIVES TO THE FULLEST
EXTENT PERMITTED BY APPLICABLE LAW, ANY RIGHT SUCH PARTY MAY HAVE TO A TRIAL BY JURY IN RESPECT TO
ANY ACTION RELATING TO OR ARISING OUT OF THIS AGREEMENT. LICENSEE AGREES THAT LICENSOR WOULD BE
IRREPARABLY HARMED BY ANY BREACH OF THIS AGREEMENT BY LICENSEE THAT HARMS THE BRAND, AND THAT
LICENSOR MAY (IN ADDITION TO ITS OTHER RIGHTS AND REMEDIES HEREIN) SEEK TEMPORARY, PRELIMINARY OR
PERMANENT INJUNCTIVE RELIEF (INCLUDING SPECIFIC PERFORMANCE) TO ENJOIN OR PREVENT ANY SUCH BREACH,
WITHOUT POSTING BOND OR OTHER SECURITY. Section 9.6. No Waiver; Cumulative Remedies. No failure or
delay by a party to exercise any right hereunder, in whole or in part, shall operate as a waiver
thereof. The parties' rights and remedies herein are cumulative and not exclusive of any other
rights and remedies provided by applicable Law. Section 9.7. Costs and Expenses. Each party shall
bear its own costs and expenses (including the fees and disbursements of counsel) incurred in
connection with the negotiations and preparation of this Agreement. Section 9.8. Section Headings.
The section headings in this Agreement are for convenience only and shall not affect its
interpretation. This Agreement shall be construed as if it were drafted jointly by the parties. 5

Source: MORGAN STANLEY DIRECT LENDING FUND, 10-12G/A, 11/19/2019
<!-- page 6 -->
Section 9.9. Counterparts. This Agreement may be executed in counterparts. PDF or facsimile
signatures shall serve as originals to bind the parties to the Agreement. Section 9.10.
Severability. Any provision of this Agreement that is held to be invalid or unenforceable shall not
invalidate or render unenforceable any other provision hereof. [REMAINDER OF PAGE INTENTIONALLY LEFT
BLANK] 6

Source: MORGAN STANLEY DIRECT LENDING FUND, 10-12G/A, 11/19/2019
<!-- page 7 -->
IN WITNESS WHEREOF, each of the parties has executed this Agreement as of the date first written
above. MORGAN STANLEY DIRECT LENDING FUND a Delaware corporation By: Name: Title: MORGAN STANLEY
INVESTMENT MANAGEMENT INC. a Delaware corporation By: Name: Title: [Signature Page to Trademark
License Agreement]

Source: MORGAN STANLEY DIRECT LENDING FUND, 10-12G/A, 11/19/2019
