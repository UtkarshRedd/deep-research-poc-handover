"""Approach 2 (and the loop reused by Approach 1): a single ReAct researcher over the
workspace tools, as a LangGraph state machine.

    START -> prepare -> model -> tools -> (prepare | constrained | force | finalize) -> END

* prepare      appends the per-turn WIDTH message (prompts/width_turn.md). W&D: a user-turn
               instruction beats a system-prompt one; the schedule is wide -> narrow.
* model        one chat call with the tool set bound (<= 6 tools, small-model rule).
* tools        validates every tool call against its pydantic schema, runs the search tools in
               parallel, add_evidence sequentially and submit last (so same-turn evidence
               counts); enforces the call budget and the minimum-calls floor; short-circuits
               exact repeats; offloads oversized results; elides the oldest tool results when
               the transcript outgrows RESEARCH_MAX_CONTEXT_TOKENS (lossy safety net only:
               evidence lives in the bank, never in the transcript).
* constrained  after MALFORMED_TURNS_MAX consecutive all-malformed turns: ask for ONE tool call
               as a bare JSON object with no tools bound; one repair retry; then stall.
* force        budget / deadline / repeated text-only turns: one last call with only `submit`
               bound. If the model still does not submit, the Finding is built from the bank
               with confidence "low" and an explicit "no answer was submitted" note.
* finalize     schema-validated Finding; the run also traces stage start/end.

Every model call and tool call is traced (dr.trace). Whole documents never enter context:
the tools cap their own output and offload above OFFLOAD_TOKENS.
"""
from __future__ import annotations

import json
import math
import re
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Annotated, Any, TypedDict

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage, ToolMessage
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from pydantic import ValidationError

from ..config import DEFAULT, Config
from ..evidence import EvidenceBank
from ..llm import ScriptExhausted
from ..models import Finding
from ..prompts import load, load_sections
from ..structured import invoke_with_backoff
from ..tools import manifest as _manifest
from ..tools.offload import estimate_tokens, maybe_offload
from ..tools.read import ReadTracker
from ..tools.registry import SubmitArgs, ToolSpec, as_langchain_tools, build_specs
from ..trace import Trace
from ..workspace import Workspace

A2_TOOLS = ["grep", "read", "outline", "list_docs", "add_evidence", "submit"]
A1_TOOLS = ["search", "page_results", "grep", "read", "add_evidence", "submit"]   # outline/list_docs folded into the opening observation
SEARCH_TOOLS = {"grep", "read", "outline", "list_docs", "search", "page_results"}
ELIDED_PREFIX = "(elided:"
_CONFIDENCE = {"high", "medium", "low"}
_CITE_RE = re.compile(r"\[(e\d+(?:\s*,\s*e\d+)*)\]")


# --------------------------------------------------------------------------- context / state


@dataclass
class ResearchContext:
    ws: Workspace
    bank: EvidenceBank
    tracker: ReadTracker
    trace: Trace | None = None               # default: <workspace>/trace.jsonl
    config: Config = DEFAULT
    opening_observation: str | None = None   # from the first move (Approach 1)
    scoped_doc_ids: list[str] | None = None  # fan-out researchers get a batch (Approach 3)
    created_by: str = "researcher"
    tool_names: list[str] | None = None      # default A2_TOOLS (Approach 1 swaps in search/page_results)
    deadline_ts: float | None = None         # absolute; default now + stages.RESEARCH
    llm: Any | None = None                   # injected chat model (tests); default get_llm("researcher")
    bm25: Any | None = None                  # BM25Index for search/page_results (Approach 1)
    run_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])


class LoopState(TypedDict, total=False):
    messages: Annotated[list[BaseMessage], add_messages]
    turn: int
    calls_used: int          # tool calls that consumed budget (everything except submit)
    malformed_turns: int     # consecutive turns in which every call was malformed
    no_tool_turns: int       # consecutive turns with no tool call at all
    model_errors: int        # failed model calls so far (transient endpoint errors cost a turn, not the run)
    last_had_calls: bool
    submission: dict | None  # validated submit args once accepted
    done: str | None         # submitted | forced_submit | max_calls | deadline | no_tool_calls | stalled | model_error
    finding: dict | None


@dataclass
class ResearchRun:
    finding: Finding
    done: str
    turns: int
    calls_used: int
    elapsed_ms: int
    state: dict = field(repr=False)


# --------------------------------------------------------------------------- the loop


class ResearchLoop:
    def __init__(self, ctx: ResearchContext):
        self.ctx = ctx
        self.cfg = ctx.config
        self.ws = ctx.ws
        self.bank = ctx.bank
        self._owns_trace = ctx.trace is None
        self.trace = ctx.trace or Trace(ctx.ws.root / "trace.jsonl", ctx.run_id)
        self.tool_names = list(ctx.tool_names or A2_TOOLS)
        self.specs = self._scoped(
            build_specs(ctx.ws, ctx.bank, ctx.tracker, created_by=ctx.created_by, config=self.cfg, bm25=ctx.bm25)
        )
        lc_tools = as_langchain_tools(
            ctx.ws, ctx.bank, ctx.tracker, names=self.tool_names, created_by=ctx.created_by, config=self.cfg,
            bm25=ctx.bm25,
        )
        self.llm = ctx.llm if ctx.llm is not None else self._default_llm()
        self.llm_tools = self._bind(self.llm, lc_tools)
        self.llm_submit = self._bind(self.llm, [t for t in lc_tools if t.name == "submit"])
        self.model_name = (
            getattr(self.llm, "model_name", None) or getattr(self.llm, "model", None) or type(self.llm).__name__
        )
        self.t0 = time.time()
        self.deadline_ts = ctx.deadline_ts if ctx.deadline_ts is not None else self.t0 + self.cfg.stages.RESEARCH
        self.budget_s = max(1.0, self.deadline_ts - self.t0)
        self.seen_calls: set[str] = set()
        self.phase_hints = load_sections("width_phase_hints")
        self.force_reasons = load_sections("force_reasons")
        self.question = ""
        self.sub_question: str | None = None
        self.graph = self._build()

    # ------------------------------------------------------------------ public

    def run(self, question: str, sub_question: str | None = None) -> ResearchRun:
        self.question, self.sub_question = question, sub_question
        a = self.cfg.agents
        scoped = self.ctx.scoped_doc_ids
        n_docs = len(scoped) if scoped else len(self.ws.manifest)
        rows, total = _manifest.list_docs(self.ws, doc_ids=scoped, config=self.cfg)
        help_sections = load_sections("tool_help")
        system = load(
            "researcher",
            n_docs=n_docs,
            manifest_preview=_manifest.render(rows, total),
            opening_observation=self.ctx.opening_observation or "",
            tool_help="\n".join(help_sections[n] for n in self.tool_names if n in help_sections),
            min_calls=a.RESEARCH_MIN_CALLS,
        )
        task_sections = load_sections("research_task")
        block = task_sections["sub_question"].format(sub_question=sub_question) if sub_question else ""
        task = task_sections["task"].format(question=question, sub_question_block=block)
        self.trace.stage(
            "research", "start", run_id=self.ctx.run_id, question=question[:200], sub_question=sub_question,
            n_docs=n_docs, tools=self.tool_names, model=self.model_name, budget_s=round(self.budget_s, 1),
        )
        init: LoopState = {
            "messages": [SystemMessage(content=system), HumanMessage(content=task)],
            "turn": 0, "calls_used": 0, "malformed_turns": 0, "no_tool_turns": 0, "model_errors": 0,
            "last_had_calls": False, "submission": None, "done": None, "finding": None,
        }
        limit = (a.RESEARCH_MAX_CALLS + a.MALFORMED_TURNS_MAX + a.NO_TOOL_TURNS_MAX + a.MODEL_ERRORS_MAX + 4) * 4 + 10
        final = self.graph.invoke(init, config={"recursion_limit": limit})
        finding = Finding(**final["finding"])
        elapsed = int((time.time() - self.t0) * 1000)
        self.trace.stage(
            "research", "end", done=final["done"], turns=final["turn"], calls_used=final["calls_used"],
            n_evidence=self._n_evidence(), elapsed_ms=elapsed, not_in_corpus=finding.not_in_corpus,
        )
        if self._owns_trace:
            self.trace.close()
        return ResearchRun(
            finding=finding, done=final["done"], turns=final["turn"], calls_used=final["calls_used"],
            elapsed_ms=elapsed, state=dict(final),
        )

    # ------------------------------------------------------------------ graph

    def _build(self):
        g = StateGraph(LoopState)
        g.add_node("prepare", self._prepare)
        g.add_node("model", self._model)
        g.add_node("tools", self._tools)
        g.add_node("constrained", self._constrained)
        g.add_node("force", self._force)
        g.add_node("finalize", self._finalize)
        routes = {"prepare": "prepare", "constrained": "constrained", "force": "force", "finalize": "finalize"}
        g.add_conditional_edges(START, self._route_next, routes)
        g.add_edge("prepare", "model")
        g.add_conditional_edges("model", self._after_model, {"tools": "tools", **routes})
        g.add_conditional_edges("tools", self._route_next, routes)
        g.add_conditional_edges("constrained", self._after_constrained, {"tools": "tools", "finalize": "finalize"})
        g.add_edge("force", "finalize")
        g.add_edge("finalize", END)
        return g.compile()

    def _route_next(self, state: LoopState) -> str:
        if state.get("submission") or state.get("done"):
            return "finalize"
        a = self.cfg.agents
        if (
            state["calls_used"] >= a.RESEARCH_MAX_CALLS
            or self._time_up()
            or state["no_tool_turns"] >= a.NO_TOOL_TURNS_MAX
        ):
            return "force"
        if state["malformed_turns"] >= a.MALFORMED_TURNS_MAX:
            return "constrained"
        return "prepare"

    def _after_model(self, state: LoopState) -> str:
        if state.get("done"):
            return "finalize"
        return "tools" if state.get("last_had_calls") else self._route_next(state)

    def _after_constrained(self, state: LoopState) -> str:
        return "finalize" if state.get("done") else "tools"

    # ------------------------------------------------------------------ nodes

    def _prepare(self, state: LoopState) -> dict:
        a = self.cfg.agents
        turn = state["turn"] + 1
        calls = state["calls_used"]
        phase = self._phase(calls)
        width = a.WIDTH_SCHEDULE[{"early": 0, "mid": 1, "late": 2}[phase]]
        remaining = self.deadline_ts - time.time()
        hint = ""
        if remaining < 0.35 * self.budget_s:
            hint = self.phase_hints["deadline"].format(remaining_s=max(0, int(remaining)))
        msg = load(
            "width_turn", turn=turn, calls_used=calls, max_calls=a.RESEARCH_MAX_CALLS,
            min_calls=a.RESEARCH_MIN_CALLS, n_evidence=self._n_evidence(), phase_hint=self.phase_hints[phase],
            width=width, deadline_hint=hint,
        )
        return {"turn": turn, "messages": [HumanMessage(content=msg)]}

    def _model(self, state: LoopState) -> dict:
        ai = self._invoke(self.llm_tools, state["messages"])
        if ai is None:
            n = state.get("model_errors", 0) + 1
            if n >= self.cfg.agents.MODEL_ERRORS_MAX:
                return {"done": "model_error", "model_errors": n}
            return {"model_errors": n, "last_had_calls": False}   # retry: the next turn re-sends the transcript
        calls = list(ai.tool_calls or [])
        for c in calls:
            if not c.get("id"):
                c["id"] = _new_call_id()
        invalid = list(getattr(ai, "invalid_tool_calls", None) or [])
        if calls or invalid:
            return {"messages": [ai], "last_had_calls": True, "no_tool_turns": 0}
        n = state["no_tool_turns"] + 1
        out: list[BaseMessage] = [ai]
        if n < self.cfg.agents.NO_TOOL_TURNS_MAX:
            out.append(HumanMessage(content=load("nudge_no_tools")))
        return {"messages": out, "last_had_calls": False, "no_tool_turns": n}

    def _tools(self, state: LoopState) -> dict:
        a = self.cfg.agents
        ai = _last_ai(state["messages"])
        calls = list(ai.tool_calls or []) if ai is not None else []
        invalid = list(getattr(ai, "invalid_tool_calls", None) or []) if ai is not None else []
        out: list[BaseMessage] = []
        calls_used = state["calls_used"]

        # 1. unparseable calls (the client could not even decode the arguments)
        for ic in invalid:
            out.append(_tool_msg(ic.get("name") or "unknown", ic.get("id") or _new_call_id(),
                                 f"INVALID TOOL CALL: {ic.get('error') or 'unparseable arguments'}. Fix it and call again."))

        # 2. schema validation
        runnable: list[tuple[dict, dict]] = []
        for c in calls:
            name = c.get("name") or "?"
            spec = self.specs.get(name) if name in self.tool_names else None
            if spec is None:
                out.append(_tool_msg(name, c["id"], f"UNKNOWN TOOL {name!r}. Available tools: {', '.join(self.tool_names)}."))
                continue
            try:
                args = spec.args_schema.model_validate(c.get("args") or {}).model_dump()
            except ValidationError as e:
                out.append(_tool_msg(name, c["id"], f"INVALID ARGUMENTS for {name}: {_short_validation_error(e)}. Fix the arguments and call again."))
                continue
            runnable.append((c, args))

        # 3. budget: submit is free, everything else consumes a call
        search = [(c, x) for c, x in runnable if c["name"] not in ("submit", "add_evidence")]
        adds = [(c, x) for c, x in runnable if c["name"] == "add_evidence"]
        submits = [(c, x) for c, x in runnable if c["name"] == "submit"]
        budget_left = max(0, a.RESEARCH_MAX_CALLS - calls_used)
        allowed, denied = (search + adds)[:budget_left], (search + adds)[budget_left:]
        for c, _ in denied:
            out.append(_tool_msg(c["name"], c["id"],
                                 f"NOT EXECUTED: the tool-call budget ({a.RESEARCH_MAX_CALLS} calls) is exhausted. Call submit now."))
        allowed_search = [x for x in allowed if x[0]["name"] != "add_evidence"]
        allowed_adds = [x for x in allowed if x[0]["name"] == "add_evidence"]
        if allowed_search:  # read-only tools run in parallel
            with ThreadPoolExecutor(max_workers=min(8, len(allowed_search))) as ex:
                results = list(ex.map(lambda ca: self._execute(ca[0]["name"], ca[1]), allowed_search))
            for (c, _), text in zip(allowed_search, results):
                out.append(_tool_msg(c["name"], c["id"], text))
        for c, args in allowed_adds:  # bank writes run sequentially
            out.append(_tool_msg("add_evidence", c["id"], self._execute("add_evidence", args)))
        calls_used += len(allowed)

        # 4. submit last, so evidence saved in the same turn counts
        submission = None
        for c, args in submits:
            text, accepted = self._try_submit(args, calls_used, floor=True)
            out.append(_tool_msg("submit", c["id"], text))
            if accepted and submission is None:
                submission = args

        all_malformed = bool(calls or invalid) and not runnable
        malformed_turns = state["malformed_turns"] + 1 if all_malformed else 0
        done = state.get("done")
        if malformed_turns > a.MALFORMED_TURNS_MAX:
            done = "stalled"
        out += self._compact(state["messages"], out)
        return {"messages": out, "calls_used": calls_used, "malformed_turns": malformed_turns,
                "submission": submission, "done": done, "no_tool_turns": 0}

    def _constrained(self, state: LoopState) -> dict:
        sections = load_sections("constrained_call")
        schemas = "\n".join(f"- {n}: {_compact_schema(self.specs[n].args_schema)}" for n in self.tool_names)
        ask = HumanMessage(content=sections["ask"].format(error=_last_tool_error(state["messages"]), tool_schemas=schemas))
        history = list(state["messages"]) + [ask]
        new: list[BaseMessage] = [ask]
        for attempt in range(2):
            ai = self._invoke(self.llm, history)
            if ai is None:
                return {"messages": new, "done": "model_error"}
            if ai.tool_calls:  # the model used the tools protocol after all: accept it
                for c in ai.tool_calls:
                    c["id"] = c.get("id") or _new_call_id()
                new.append(ai)
                return {"messages": new, "last_had_calls": True}
            text = ai.content if isinstance(ai.content, str) else str(ai.content)
            obj = _extract_json(text)
            if obj and isinstance(obj.get("tool"), str):
                synth = AIMessage(content=text, tool_calls=[
                    {"name": obj["tool"], "args": obj.get("args") or {}, "id": _new_call_id(), "type": "tool_call"}
                ])
                new.append(synth)
                return {"messages": new, "last_had_calls": True}
            new.append(ai)
            if attempt == 0:
                repair = HumanMessage(content=sections["repair"].format())
                new.append(repair)
                history = history + [ai, repair]
        return {"messages": new, "done": "stalled"}

    def _force(self, state: LoopState) -> dict:
        a = self.cfg.agents
        calls = state["calls_used"]
        if calls >= a.RESEARCH_MAX_CALLS:
            reason = "max_calls"
        elif self._time_up():
            reason = "deadline"
        elif state["no_tool_turns"] >= a.NO_TOOL_TURNS_MAX:
            reason = "no_tool_calls"
        else:
            reason = "forced"
        over = time.time() - self.deadline_ts
        if self.llm_submit is None or over > a.FORCE_SUBMIT_GRACE_S:
            self.trace.event("force_skip", stage="research", reason=reason, over_deadline_s=round(over, 1))
            return {"done": reason}
        ids = [it.id for it in self._mine()]
        reason_text = self.force_reasons.get(reason, self.force_reasons["forced"]).format(max_calls=a.RESEARCH_MAX_CALLS)
        prompt = HumanMessage(content=load("force_submit", reason=reason_text,
                                           evidence_ids=", ".join(ids) if ids else "(none saved)"))
        ai = self._invoke(self.llm_submit, list(state["messages"]) + [prompt])
        if ai is None:
            return {"messages": [prompt], "done": reason}
        out: list[BaseMessage] = [prompt, ai]
        submission = None
        for c in ai.tool_calls or []:
            c["id"] = c.get("id") or _new_call_id()
            if c.get("name") != "submit":
                out.append(_tool_msg(c.get("name") or "?", c["id"], "NOT EXECUTED: only submit is allowed now."))
                continue
            try:
                args = SubmitArgs.model_validate(c.get("args") or {}).model_dump()
            except ValidationError as e:
                out.append(_tool_msg("submit", c["id"], f"INVALID ARGUMENTS for submit: {_short_validation_error(e)}."))
                continue
            if not args["evidence_ids"] and not args["not_in_corpus"]:
                # forced and empty-handed: a low-confidence "not established" beats a failed hand-off
                args = {**args, "confidence": "low",
                        "answer": "[No evidence could be saved before the budget ran out.] " + args["answer"]}
            text, ok = self._try_submit(args, calls, floor=False)
            if not ok and not args["evidence_ids"]:
                text, ok = "SUBMITTED (no evidence; low confidence)", True
            out.append(_tool_msg("submit", c["id"], text))
            if ok and submission is None:
                submission = args
        return {"messages": out, "submission": submission, "done": "forced_submit" if submission else reason}

    def _finalize(self, state: LoopState) -> dict:
        done = state.get("done") or ("submitted" if state.get("submission") else "unknown")
        return {"done": done, "finding": self._build_finding(state, done).model_dump()}

    # ------------------------------------------------------------------ helpers

    def _invoke(self, llm, messages: list[BaseMessage]) -> AIMessage | None:
        t0 = time.perf_counter()

        def _waited(attempt: int, wait: float) -> None:
            self.trace.event("rate_limit_wait", stage="research", role="researcher", attempt=attempt, wait_s=round(wait, 1))

        try:
            ai = invoke_with_backoff(llm, messages, {}, self.cfg, self.deadline_ts, _waited)
        except ScriptExhausted:
            raise
        except Exception as e:  # noqa: BLE001 - endpoint failure after the client's own retries; never silent
            self.trace.event("model_error", stage="research", role="researcher", model=self.model_name,
                             error=f"{type(e).__name__}: {e}"[:300], ms=int((time.perf_counter() - t0) * 1000))
            return None
        ms = int((time.perf_counter() - t0) * 1000)
        usage = getattr(ai, "usage_metadata", None) or {}
        self.trace.model_call("research", "researcher", self.model_name,
                              usage.get("input_tokens"), usage.get("output_tokens"), ms)
        return ai

    def _execute(self, name: str, args: dict) -> str:
        spec = self.specs[name]
        key = None
        if name in SEARCH_TOOLS:
            key = name + "|" + json.dumps(args, sort_keys=True, default=str)
            if key in self.seen_calls:
                self.trace.event("tool_repeat", stage="research", tool=name,
                                 args_preview=json.dumps(args, default=str)[:120])
                return f"(repeat) You already made this exact {name} call; its result is above. Make a different call."
        t0 = time.perf_counter()
        try:
            text = spec.fn(**args)
        except Exception as e:  # noqa: BLE001 - a tool bug must not kill the agent's turn
            text = f"TOOL ERROR in {name}: {type(e).__name__}: {e}"
        ms = int((time.perf_counter() - t0) * 1000)
        text, path = maybe_offload(self.ws, name, text, self.cfg)
        self.trace.tool_call("research", name, args, len(text), ms)
        if path is not None:
            self.trace.event("tool_offload", stage="research", tool=name, path=path.name)
        if key:
            self.seen_calls.add(key)
        return text

    def _try_submit(self, args: dict, calls_used: int, floor: bool) -> tuple[str, bool]:
        a = self.cfg.agents
        text = self.specs["submit"].fn(**args)  # "SUBMITTED" or "REJECTED: ..."
        accepted = text == "SUBMITTED"
        if accepted and floor and calls_used < a.RESEARCH_MIN_CALLS:
            text = load("nudge_min_calls", calls_used=calls_used, min_calls=a.RESEARCH_MIN_CALLS)
            accepted = False
        self.trace.event("submit", stage="research", accepted=accepted, n_ids=len(args.get("evidence_ids") or []),
                         not_in_corpus=bool(args.get("not_in_corpus")), calls_used=calls_used)
        return text, accepted

    def _build_finding(self, state: LoopState, done: str) -> Finding:
        sub = state.get("submission")
        if sub:
            ids = [e for e in sub["evidence_ids"] if self.bank.get(e)]
            conf = sub.get("confidence") if sub.get("confidence") in _CONFIDENCE else "medium"
            return Finding(
                sub_question=sub.get("sub_question") or self.sub_question or self.question,
                answer=sub["answer"], evidence_ids=ids, confidence=conf,
                not_in_corpus=bool(sub.get("not_in_corpus")), calls_used=state["calls_used"],
            )
        ids = [it.id for it in self._mine()]
        cited = (": " + " ".join(f"[{i}]" for i in ids)) if ids else ""
        answer = (f"No answer was submitted (research stopped: {done}). "
                  f"{len(ids)} evidence item(s) were saved{cited}. Treat this finding as incomplete.")
        return Finding(sub_question=self.sub_question or self.question, answer=answer, evidence_ids=ids,
                       confidence="low", not_in_corpus=False, calls_used=state["calls_used"])

    def _compact(self, messages: list[BaseMessage], new: list[BaseMessage]) -> list[BaseMessage]:
        cap = self.cfg.agents.RESEARCH_MAX_CONTEXT_TOKENS
        total = sum(_msg_tokens(m) for m in messages) + sum(_msg_tokens(m) for m in new)
        if total <= cap:
            return []
        reps: list[BaseMessage] = []
        for m in messages:
            if total <= cap:
                break
            if isinstance(m, ToolMessage) and m.id and not str(m.content).startswith(ELIDED_PREFIX):
                stub = (f"{ELIDED_PREFIX} earlier {m.name or 'tool'} result removed to save context; "
                        "any evidence from it is already in the bank)")
                total -= _msg_tokens(m) - estimate_tokens(stub)
                reps.append(ToolMessage(content=stub, tool_call_id=m.tool_call_id, name=m.name, id=m.id))
                self.trace.event("compaction", stage="research", tool=m.name, chars=len(str(m.content)))
        return reps

    def _phase(self, calls: int) -> str:
        a = self.cfg.agents
        remaining = self.deadline_ts - time.time()
        if calls >= 0.7 * a.RESEARCH_MAX_CALLS or remaining < 0.35 * self.budget_s:
            return "late"
        if calls < max(1, math.ceil(a.RESEARCH_MIN_CALLS / 2)):
            return "early"
        return "mid"

    def _time_up(self) -> bool:
        return time.time() >= self.deadline_ts

    def _mine(self):
        return [it for it in self.bank.all() if it.created_by == self.ctx.created_by]

    def _n_evidence(self) -> int:
        return len(self._mine())

    def _default_llm(self):
        from ..llm import get_llm

        return get_llm("researcher")

    def _bind(self, llm, tools):
        if not tools:
            return None
        kw: dict = {}
        if self.ctx.llm is None:
            from ..llm import endpoint_for

            if not endpoint_for("researcher").supports_parallel_tools:
                kw["parallel_tool_calls"] = False  # only sent when the probe said the endpoint needs it
        return llm.bind_tools(tools, **kw)

    def _scoped(self, specs: dict[str, ToolSpec]) -> dict[str, ToolSpec]:
        """Approach 3 contract: a researcher with `scoped_doc_ids` cannot touch other documents."""
        ids = self.ctx.scoped_doc_ids
        if not ids:
            return specs
        allowed = set(ids)

        def guard(fn):
            def wrapped(**kw):
                if kw.get("doc_id") not in allowed:
                    return f"REJECTED: {kw.get('doc_id')!r} is outside this researcher's document scope."
                return fn(**kw)
            return wrapped

        grep_fn, list_fn = specs["grep"].fn, specs["list_docs"].fn

        def grep_scoped(pattern, doc_ids=None, max_matches=None):
            scope = [d for d in (doc_ids or ids) if d in allowed]
            if doc_ids and not scope:
                return "REJECTED: doc_ids are outside this researcher's document scope."
            return grep_fn(pattern=pattern, doc_ids=scope, max_matches=max_matches)

        def list_scoped(doc_ids=None, doc_type=None, date_from=None, date_to=None, party_contains=None):
            scope = [d for d in (doc_ids or ids) if d in allowed] or list(ids)
            return list_fn(doc_ids=scope, doc_type=doc_type, date_from=date_from, date_to=date_to,
                           party_contains=party_contains)

        out = dict(specs)
        out["grep"] = specs["grep"].model_copy(update={"fn": grep_scoped})
        out["list_docs"] = specs["list_docs"].model_copy(update={"fn": list_scoped})
        for n in ("read", "outline", "add_evidence"):
            out[n] = specs[n].model_copy(update={"fn": guard(specs[n].fn)})
        return out


# --------------------------------------------------------------------------- public API


def run_researcher(ctx: ResearchContext, question: str, sub_question: str | None = None) -> Finding:
    """Run the single-agent loop and return a schema-validated Finding."""
    return ResearchLoop(ctx).run(question, sub_question).finding


def render_finding(finding: Finding, bank: EvidenceBank) -> str:
    """Short cited answer for notebooks and the minimal answer path: `[e3]` -> `[doc_id p.N]`
    plus the quoted evidence. The Finding itself keeps the internal ids."""

    def _cite(m: re.Match) -> str:
        ids = [x.strip() for x in m.group(1).split(",")]
        return " ".join(bank.citation_for(i) if bank.get(i) else f"[{i}: unknown]" for i in ids)

    lines = [
        f"Q: {finding.sub_question}",
        f"A: {_CITE_RE.sub(_cite, finding.answer)}",
        f"(confidence: {finding.confidence}; tool calls: {finding.calls_used}"
        + ("; NOT IN CORPUS" if finding.not_in_corpus else "") + ")",
    ]
    if finding.evidence_ids:
        lines.append("Evidence:")
        for eid in finding.evidence_ids:
            it = bank.get(eid)
            if it is None:
                continue
            pg = f" p.{it.page}" if it.page else ""
            lines.append(f'  {eid} {it.doc_id}{pg} L{it.start_line}-{it.end_line}: "{it.quote}"'
                         + (f" ({it.note})" if it.note else ""))
    return "\n".join(lines)


# --------------------------------------------------------------------------- small helpers


def _new_call_id() -> str:
    return f"call_{uuid.uuid4().hex[:8]}"


def _tool_msg(name: str, call_id: str, text: str) -> ToolMessage:
    return ToolMessage(content=text, tool_call_id=call_id, name=name)


def _last_ai(messages: list[BaseMessage]) -> AIMessage | None:
    for m in reversed(messages):
        if isinstance(m, AIMessage):
            return m
    return None


def _last_tool_error(messages: list[BaseMessage]) -> str:
    for m in reversed(messages):
        if isinstance(m, ToolMessage) and str(m.content).startswith(("INVALID", "UNKNOWN")):
            return str(m.content)[:300]
    return "unknown"


def _msg_tokens(m: BaseMessage) -> int:
    n = estimate_tokens(str(m.content))
    if isinstance(m, AIMessage) and m.tool_calls:
        n += estimate_tokens(json.dumps(m.tool_calls, default=str))
    return n


def _short_validation_error(e: ValidationError) -> str:
    bits = []
    for err in e.errors()[:3]:
        loc = ".".join(str(x) for x in err.get("loc", ())) or "args"
        bits.append(f"{loc}: {err.get('msg')}")
    return "; ".join(bits)


def _compact_schema(model) -> str:
    schema = model.model_json_schema()
    req = set(schema.get("required", []))
    parts = []
    for k, v in schema.get("properties", {}).items():
        t = v.get("type") or "/".join(x.get("type", "?") for x in v.get("anyOf", [])) or "any"
        parts.append(f"{k}{'' if k in req else '?'}: {t}")
    return "{" + ", ".join(parts) + "}"


def _extract_json(text: str) -> dict | None:
    s, e = text.find("{"), text.rfind("}")
    if s < 0 or e <= s:
        return None
    try:
        obj = json.loads(text[s : e + 1])
    except json.JSONDecodeError:
        return None
    return obj if isinstance(obj, dict) else None
