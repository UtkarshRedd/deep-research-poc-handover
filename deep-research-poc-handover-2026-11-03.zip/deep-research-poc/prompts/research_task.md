## task
Research task: {question}
{sub_question_block}
Answer only from the documents in scope. Save a verbatim quote with `add_evidence` for every fact
you rely on, then call `submit`. Begin with several independent `grep` calls for different clues.
## sub_question
Your assigned sub-question (answer ONLY this part of the task): {sub_question}
