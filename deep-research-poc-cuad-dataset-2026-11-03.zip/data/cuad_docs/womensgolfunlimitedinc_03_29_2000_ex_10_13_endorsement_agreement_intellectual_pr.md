<!-- page 1 -->
# Intellectual Property Rights Confidentiality and Non-Use Obligations Agreement
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| SEC Filing Date | 2000-03-29 |
| Parties | SQUARE TWO GOLF INC. ("Company"); KATHY WHITWORTH ("Professional") |
| Source | CUAD v1 / WOMENSGOLFUNLIMITEDINC_03_29_2000-EX-10.13-ENDORSEMENT AGREEMENT - Intellectual Property Rights                 Confidentiality and Non-Use Obligations Agreement |

-8- 9

EXECUTION COPY

11.6. COUNTERPARTS. This Agreement may be executed in two or more counterparts, each of which shall
be deemed an original, but all of which together shall constitute one and the same instrument.

11.7. INTELLECTUAL PROPERTY RIGHTS, CONFIDENTIALITY AND NON-USE. The Professional acknowledges her
obligations under the provisions of the Intellectual Property Rights Confidentiality and Non-Use
Obligations Agreement attached hereto as "Exhibit A" and made a part hereof by this reference. The
rights and obligations of the parties set forth in Exhibit A shall survive the termination or
expiration of this endorsement agreement, regardless of cause or circumstances of the termination or
expiration.

IN WITNESS WHEREOF, the parties have executed this Agreement as of the date first above written.

SQUARE TWO GOLF, INC.

By: /s/DOUGLAS A. BUFFINGTON --------------------------------- Douglas A. Buffington President

PROFESSIONAL

/s/ KATHY WHITWORTH ------------------------------ Kathy Whitworth

-9- 10

EXECUTION COPY

EXHIBIT A

Intellectual Property Rights Confidentiality and Non-Use Obligations Agreement

This Agreement by and between SQUARE TWO GOLF INC., a New Jersey corporation (the "Company") and
KATHY WHITWORTH, an individual residing at 302 La Mancha Court, Santa Fe, New Mexico 87501 (the
"Recipient"), is part of the Endorsement Agreement of the parties. In consideration of and as an
inducement for the Company entering into said Endorsement Agreement with Recipient:

(a) Recipient acknowledges and agrees that communications for the purpose of proposing to work for
or working for the Company have in the past or will entail the disclosure, observation and display
to Recipient of information and materials of the Company that are proprietary, confidential and
trade secret, which include, but are not limited to, golf equipment marketing plans, research,
development and designs, computer software, screens, user interfaces, systems designs and
documentation, processes, methods, fees, charges, know-how and any result from the work performed by
Recipient or the Company, new discoveries, Intellectual Property (as defined below) and improvements
to the Company's products made for or on behalf of the Company (all of which, singly and
collectively, "Information").

With regard to such Information, whether or not labeled or specified as confidential, proprietary or
trade secret, Recipient agrees:

(i) to use the Information solely for the purpose of making proposals to or working under contracts
with the Company; and

(ii) not to disclose or transfer the Information to others without the Company's written permission.

(b) Recipient will not be prevented from using or disclosing Information:

(i) which Recipient can demonstrate, by written records, was known to it before the disclosure or
display of the Information by the Company to Recipient; or

(ii) which is now, or becomes in the future, public knowledge other than by breach of this Agreement
or the endorsement agreement by Recipient, its employees or agents; or

(iii) that is lawfully obtained by Recipient from a source independent of the Company, which source
was lawfully in possession of the Information and which source had the unrestricted right to
disclose or display the Information to the Recipient; or

(iv) that is required by legal process to be disclosed, provided that Recipient will timely inform
the Company of the requirement for disclosure, will permit the Company to attempt, by appropriate
legal means, to limit such disclosure and will itself
<!-- page 2 -->
A-1

11

EXECUTION COPY

use appropriate efforts to limit the disclosure and maintain confidentiality to the extent possible.

(c) The confidentiality and non-use obligations of Recipient will remain in effect after all work
for the Company has been completed.

(d) All Information, including any copies thereof, in any media, in the possession or control of
Recipient and Information embodied or included in any software or data files loaded or stored on
computers in the possession or control of Recipient, its agents or employees, shall be removed and
returned to the Company upon demand, but no later than the completion of work for the Company.

(e) Recipient agrees that she will not copy the Information in whole or in part or use all or any
part of the Information to reverse engineer, duplicate the function, sequence or organization of the
Information for any purpose without the prior written permission of the Company.

(f) Recipient further acknowledges and agrees that all new discoveries, inventions, improvements,
processes, formulae, designs, drawings, training materials, original works of authorship, photos,
video tapes, electronic images, documentation, trademarks and copyrights (the "Intellectual
Property"), that may be developed, conceived, or made by Recipient, alone or jointly with others
during her work for the Company, shall be the exclusive property of the Company and shall be deemed
a work for hire. Recipient hereby assigns and agrees to assign all Recipient's rights in any
Intellectual Property to the Company. Recipient hereby grants to the Company power of attorney for
the purpose of assigning all Recipient's rights in Intellectual Property to the Company for the
purposes of filings, registrations and other formalities deemed necessary by the Company to
prosecute, protect, perfect or exploit its ownership and interests in Intellectual Property.
Recipient further agrees to execute, acknowledge and deliver any documentation, instruments,
specifications or disclosures necessary to assign, prosecute, protect, perfect or exploit the
Company ownership of Intellectual Property.

(g) Recipient acknowledges and agrees that the Company possesses valuable know-how, proprietary,
confidential and trade secret Information that has been procured or developed by the Company at
great expense and that its unauthorized disclosure would result in substantial damages to the
Company that may not be adequately compensated by monetary relief. Accordingly, Recipient hereby
consents to the jurisdiction of the Federal and County Courts in Essex County, New Jersey and agrees
that the Company may seek temporary restraining orders against it or other extraordinary relief
necessary to protect the Information.

A-2
