<!-- page 1 -->
# Strategic Alliance Agreement
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2018-01-10 |
| Parties | Bravatek Solutions, Inc. ("Bravatek"); Fazync LLC ("Fazync") |
| Source | CUAD v1 / INTELLIGENTHIGHWAYSOLUTIONS,INC_01_18_2018-EX-10.1-Strategic Alliance Agreement |

Strategic Alliance Agreement This agreement is made and entered into this 10th day of January, 2018
by and between Bravatek Solutions, Inc., a corporation organized under the laws of the State of
Colorado, ("Bravatek"), with an address at 2028 E. Ben White Blvd., Unit #240-2835, Austin, Texas
78741 and Fazync LLC, a limited liability company organized under the laws of the State of Colorado
with an address at 2376 Gold River Drive, Rancho Cordova, CA 95670 ("Fazync"). Fazync is a wholly
owned subsidiary of publicly traded company Intelligent Highway Solutions, Inc., ("IHSI"), a Nevada
corporation. Whereas, Bravatek is a corporation, which has technical expertise in security-related
software, tools and systems/services (including telecom services) to support, deploy and test its
current and potential customers' most critical initiatives. Whereas, Fazync is a company engaged in
the business of providing energy-saving solutions and capabilities to the Critical
Infrastructure/Key Resources arena. Whereas, the parties desire to enter into a business
relationship which will designate Bravatek as the project based business partnership channel for
governmental and non-governmental departments / agencies / units for the purpose of promoting Fazync
relevant capabilities, products and/or service solutions. Now therefore, the parties mutually agree
to enter into a strategic alliance under the following terms and conditions: 1) Duties of Bravatek
Bravatek agrees to serve as a non-exclusive project sales lead finder for Fazync. In this capacity,
Bravatek will use its best efforts to provide the following services to Fazync a. Promote, market
and introduce the Products to prospective clients in the government space nationwide. b. Provide a
quarterly Pipeline or project information leads report to Fazync a monthly basis which contains a
3-month rolling forecast of potential sales. c. Follow-up on on-going project leads that Fazync
actively engaged with or believes is appropriate. d. Provide Fazync with any promotional materials,
technical papers, white papers, proposals, etc. prior to publication or delivery to prospective
clients.
<!-- page 2 -->
2) Duties of Fazync Fazync agrees to use its best efforts to promote and support project lead
finding and after-sales support of Bravatek by: a. Listing Bravatek in all appropriate sales and
marketing materials as a non-exclusive alliance partner (with focus of government customers) b.
Provide timely responses to both technical and administrative questions posed by Bravatek. c.
Promote Bravatek's product and service offerings whenever possible. d. Aid Bravatek in the writing
of any technical/marketing/sales documents when requested and participate in mutually-agreed upon
sales calls. e. Provide Bravatek with co-branded marketing material that can be emailed or handed to
prospective clients.

3) Obligations of the Parties Bravatek and Fazync agree to jointly: a. Develop and implement a joint
Product Solution and Application Strategy whereby targeted markets/potential client-
types/applications are mutually agreed upon; b. Support each other in all agreed-upon technical,
marketing and promotional efforts; c. Develop a joint strategy for developing new
product/services/capabilities to mutually benefit both parties; d. Utilize each other as Preferred
Vendors for services whenever possible upon mutual agreement. 4) Compensation When custom Products
are designed, developed and to be delivered to Bravatek-identified perspective clients, the parties
shall agree to a proposed sales price for use during the project in writing prior to the
commencement of each project.
<!-- page 3 -->
For any Product or Solution sold to any perspective clients introduced by Bravatek registered with
Fazync via email to IHSI's CEO, Devon Jones, and delivered through Bravatek or a Fazync -designated
distribution affiliate(s) or sales channel(s), Bravatek will receive a lead-finder fee, to be
mutually discussed and finally decided by Fazync at the range of minimum of 10% to maximum of 20% of
project revenue, with an exact fee to be depending upon the overall project sales margin and cost of
development and delivery of each project, payable NET 30 days after each client payment on delivered
products received at Fazync bank account. 5) Confidentiality "Confidential information" shall mean
any and all technical and non-technical information, documents and materials related to client
projects of party and products, services and business of each of the parties. Fazync and Bravatek
agree to maintain in strict confidence and not to disclose or disseminate, or to use for any
purposes other than performance of the projects, the Confidential Information disclosed. The
obligation of non-disclosure shall not apply to the following: a. Information at or after such time
that is publicly available through no fault of either party b. Information at or after such time
that is disclosed to either party by a third party entitled to disclose such information c.
Information which is required by law to be disclosed to federal, state or local authorities. 6) Term
of Confidentiality For a period of five (5) years after termination of this Agreement, the parties
shall treat as confidential all information and take every reasonable precaution and use all
reasonable efforts to prevent the unauthorized disclosure of the same. The parties agree to take all
steps reasonably necessary and appropriate to ensure that their employees, agents, and/or assistants
treat all information as confidential and to ensure that such employees, agents, and/or assistants
are familiar with and abide by the terms of this Agreement. 7) Term The term of this Agreement is
twelve (12) months from the date hereof, and will be automatically renewed for one (1) additional
twelve month period unless either party shall notify the other in writing of its intention not to
renew. Such notice must be given ninety (90) days prior to expiration of the original term. This
Agreement may also be terminated by either party upon ninety (90) days written notice.
<!-- page 4 -->
8) Notices Any notices required under this Agreement shall be delivered to: Bravatek Technologies,
Inc. 2028 E. Ben White Blvd. Unit #240-2835 Austin, Texas 78741 Fazync, Inc. 2376 Gold River dr.
Ranch Cordova, CA 95670 9) Governing Law This Agreement is entered into in the State of Texas and
shall be interpreted according to the laws of the State of Texas. 10) Indemnification Fazync shall
indemnify Bravatek, its directors, officers and employees, for any and all damages, costs, expenses,
and other liabilities, including reasonable attorney's fees and court costs incurred in connection
with any third-party claim, action or proceeding arising from the negligence or intentional
misconduct of Fazync or breach of Fazync of any of its obligations under this Agreement. Bravatek
shall indemnify Fazync, its directors, officers and employees, for any and all damages, costs,
expenses, and other liabilities, including reasonable attorney's fees and court costs, incurred in
connection with any third-party claim, action or proceeding arising from the negligence or
intentional misconduct of Bravatek or breach of Bravatek of any of its obligations under this
Agreement. 11) Modifications No changes or modifications of this Agreement or any of its terms shall
be deemed effective unless in writing and executed by the parties hereto. 12) Assignment This
Agreement shall not be assignable by either party without the prior written consent of the other
party. 13) Entire Agreement This Agreement represents the complete and entire understanding between
the parties regarding the subject matter hereof and supersedes all prior negotiations,
representations, or agreements, either written or oral, regarding this subject matter.
<!-- page 5 -->
<!-- page 6 -->
This Agreement shall not be considered accepted, approved or otherwise effective until signed by the
appropriate parties. Bravatek Technologies, Inc. Fazync LLC By: By: Name: Thomas A. Cellucci Name:
Devon Jones Title: CEO Title: Manager Date: January 10, 2018 Date: January 10, 2018
