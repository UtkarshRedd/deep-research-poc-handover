<!-- page 1 -->
# Lender Consent — Corvallis Foods Group
| Field | Value |
|---|---|
| Document Type | Consent |
| Effective Date | 2025-09-03 |
| Parties | Corvallis Foods Group LLC; Pacific Commerce Bank |
| Facility ID | FAC-2025-0108 |
| Version | Consent |

THIS CONSENT (this "Consent") is entered into as of 2025-09-03 among Corvallis Foods Group LLC (the "Borrower"), the Required Lenders and Pacific Commerce Bank, as Administrative Agent, under the Credit Agreement dated as of 2025-04-01 (the "Credit Agreement"; facility FAC-2025-0108).

## Recitals
WHEREAS, the Borrower proposes to sell the Eugene distribution center for cash consideration of not less than $12,500,000 (the "Specified Disposition"), which would exceed the annual threshold under Section 7.6 of the Credit Agreement;
<!-- page 2 -->
## Section 1 — Consent
The Required Lenders hereby consent to the Specified Disposition, provided that it is consummated on or before 2025-12-31 and that 100% of the Net Cash Proceeds are applied to prepay the Term Loans within five (5) Business Days of receipt.
## Section 2 — Limited Effect
This Consent is limited to the Specified Disposition and does not constitute a consent to any other transaction or a waiver of any other provision of the Credit Agreement.
<!-- page 3 -->
## Section 3 — Miscellaneous
The Borrower represents that no Default has occurred and is continuing. The Credit Agreement remains in full force and effect. This Consent is a Loan Document.
This Consent shall be governed by the laws of the State of California. Notices shall be given in the manner set forth in Section 10.1 of the Credit Agreement.
Corvallis Foods Group LLC, as Borrower — By: /s/ Authorized Signatory
Pacific Commerce Bank, as Administrative Agent — By: /s/ Authorized Signatory
