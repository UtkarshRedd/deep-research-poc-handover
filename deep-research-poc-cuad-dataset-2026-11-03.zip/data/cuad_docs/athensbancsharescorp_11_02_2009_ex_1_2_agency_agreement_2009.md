<!-- page 1 -->
# AGENCY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Agency Agreement |
| SEC Filing Date | 2009-11-02 |
| Parties | Athens Bancshares Corporation (the "Company"); Athens Federal Community Bank (the "Bank"); Keefe, bruyette & Woods, Inc. (the "Agent") |
| Source | CUAD v1 / ATHENSBANCSHARESCORP_11_02_2009-EX-1.2-AGENCY AGREEMENT , 2009 |

Exhibit 1.2

ATHENS BANCSHARES CORPORATION up to Shares (subject to increase up to shares) COMMON SHARES ($.01
Par Value) Subscription Price $10.00 Per Share AGENCY AGREEMENT , 2009

Keefe, Bruyette & Woods, Inc. Investment Banking 10 South Wacker Drive, Suite 3400 Chicago, Illinois
60606

Ladies and Gentlemen:

Athens Bancshares Corporation, a Tennessee corporation (the "Company"), and Athens Federal Community
Bank, a federal savings bank located in Athens, Tennessee (the "Bank") (references to the "Bank"
include the Bank in mutual or stock form as indicated by the context), the deposit accounts of which
are insured by the Federal Deposit Insurance Corporation ("FDIC"), hereby confirm their agreement
with Keefe, Bruyette & Woods, Inc. (the "Agent") as follows:

Section 1. The Offering. The Bank, in accordance with its plan of conversion adopted by its Board of
Directors (the "Plan"), intends to convert from a federally-chartered mutual savings bank to a
federal stock savings bank (the "Conversion"), and issue all of its issued and outstanding capital
stock to the Company. The Conversion will be accomplished pursuant to federal law and the rules and
regulations of the Office of Thrift Supervision (the "OTS"). Pursuant to the Plan, the Company will
offer and sell up to shares (subject to increase up to shares) of its common stock, $.01 par value
per share (the "Shares" or "Common Shares"), in a subscription offering (the "Subscription
Offering") to (1) depositors of the Bank with Qualifying Deposits (as defined in the Plan) as of
March 31, 2008 ("Eligible Account Holders"), (2) the employee stock ownership plan established by
either the Bank or the Company (the "ESOP"), (3) depositors of the Bank with Qualifying Deposits as
of September 30, 2009 ("Supplemental Eligible Account Holders"), and (4) other depositor and
borrower members of the Bank as defined in the Plan. Subject to the prior subscription rights of the
above-listed parties, the Company may offer for sale in a community offering (the "Community
Offering" and when referred to together with or subsequent to the Subscription Offering, the
"Subscription and Community Offering") the Shares not subscribed for or ordered in the Subscription
Offering to members of the general public to whom a copy of the Prospectus (as hereinafter defined)
is delivered with a preference given first to natural persons who are residents of Blount, Bradley,
Hamilton, Knox, Loudon, McMinn, Meras, Monroe and Polk Counties in Tennessee. It is anticipated that
shares not subscribed for in the Subscription and Community Offering may be offered to certain
members of the general public on a best efforts basis through a selected dealers agreement (the
"Syndicated Community Offering") (the Subscription Offering, Community Offering and Syndicated
Community Offering are collectively referred to as the "Offering"). It is acknowledged that the
purchase of Shares in the Offering is subject to the maximum and minimum purchase limitations as
described in the Plan and that the Company may reject, in whole or in part, any orders received in
the Community Offering or Syndicated Community Offering.

In connection with the Conversion and pursuant to the terms of the Plan as described in the
Prospectus, immediately following the consummation of the Conversion, subject to the approval of the
Bank's depositors and compliance with certain conditions as may be imposed by regulatory
authorities, the Company will contribute $100,000 and 100,000 shares of Common Stock to the Athens
Federal Foundation (the "Foundation") such shares hereinafter being referred to as the ("Foundation
Shares").
<!-- page 2 -->
The Company has filed with the Securities and Exchange Commission (the "Commission") a registration
statement on Form S-1 (File No. 333- ) (the "Registration Statement"), containing a prospectus
relating to the Offering, for the registration of the Shares under the Securities Act of 1933 (the
"1933 Act"), and has filed such amendments thereof and such amended prospectuses as may have been
required to the date hereof. The term "Registration Statement" shall include any documents
incorporated by reference therein and all financial schedules and exhibits thereto, as amended,
including post-effective amendments. The prospectus, as amended, on file with the Commission at the
time the Registration Statement initially became effective is hereinafter called the "Prospectus,"
except that if any Prospectus is filed by the Company pursuant to Rule 424(b) or (c) of the rules
and regulations of the Commission under the 1933 Act (the "1933 Act Regulations") differing from the
prospectus on file at the time the Registration Statement initially became effective, the term
"Prospectus" shall refer to the prospectus filed pursuant to Rule 424(b) or (c) from and after the
time said prospectus is filed with the Commission.

In accordance with Title 12, Part 563b of the Code of Federal Regulations (the "Conversion
Regulations"), the Bank has filed with the OTS an Application For Conversion on Form AC (the "Form
AC"), including the Prospectus and the Conversion Valuation Appraisal Report prepared by Keller &
Company, Inc. (the "Appraisal") and has filed such amendments thereto as may have been required by
the OTS. The Form AC has been approved by the OTS and the related Prospectus has been authorized for
use by the OTS. In addition, the Company has filed with the OTS its Application H-(e)l-S (the
"Holding Company Application") to become a savings and loan holding company under the Home Owners'
Loan Act, as amended ("HOLA") and the regulations promulgated thereunder (the "Control Act
Regulations").

Section 2. Retention and Compensation of Agent. Subject to the terms and conditions herein set
forth, the Company and the Bank hereby appoint the Agent as their exclusive financial advisor and
marketing agent (i) to utilize its best efforts to solicit subscriptions for Common Shares and to
advise and assist the Company and the Bank with respect to the Company's sale of the Shares in the
Offering and (ii) to participate in the Offering in the areas of market making and in syndicate
formation (if necessary).

On the basis of the representations, warranties, and agreements herein contained, but subject to the
terms and conditions herein set forth, the Agent accepts such appointment and agrees to consult with
and advise the Company and the Bank as to the matters set forth in the letter agreement, dated June
9, 2009, between the Bank and the Agent (a copy of which is attached hereto as Exhibit A) (the
"Engagement Letter"). It is acknowledged by the Company and the Bank that the Agent shall not be
required to purchase any Shares or be obligated to take any action which is inconsistent with all
applicable laws, regulations, decisions or orders.

The obligations of the Agent pursuant to this Agreement shall terminate upon termination of the
Offering, but in no event later than 45 days after the completion of the Subscription Offering (the
"End Date"). All fees or expenses due to the Agent but unpaid will be payable to the Agent in next
day funds at the earlier of the Closing Date (as hereinafter defined) or the End Date. In the event
the Offering is extended beyond the End Date, the Company and the Agent may agree to renew this
Agreement under mutually acceptable terms.

In the event the Company is unable to sell a minimum of Shares within the period herein provided,
this Agreement shall terminate and the Company shall refund to any persons who have subscribed for
any of the Shares the full amount which it may have received from them plus accrued interest, as set
forth in the Prospectus; and none of the parties to this Agreement shall have any obligation to the
other parties hereunder, except as set forth in this Section 2 and in Sections 7, 9 and 10 hereof.
In the event the Offering is terminated for any reason not attributable to the action or inaction of
the Agent, the Agent shall be paid the fees due to the date of such termination pursuant to
subparagraphs (a) and (d) below.

2
<!-- page 3 -->
The Agent shall receive the following compensation for its services hereunder:

(a) A management fee of $30,000 payable in four consecutive monthly installments of $7,500 each
commencing with the execution of the Engagement Letter. This fee shall be deemed to have been earned
when due and shall be non-refundable.

(b) A success fee upon completion of the Offering of 1.125% of the aggregate purchase price of the
Common Shares sold in the Subscription Offering and Community Offering excluding shares purchased by
the Bank's officers, directors, or employees (or members of their immediate family), any ESOP,
tax-qualified or stock-based compensation plans (except IRAs) or similar plan created by the Bank or
the Company for some or all of its directors or employees, or contributed to any charitable
foundation established by the Bank in connection with the Conversion. In no event shall the success
fee paid for the sale of Common Stock in the Subscription and Community Offering be less than
$200,000. The management fee will be applied against the first success fee.

(c) If any of the Common Shares remain available after the Subscription Offering, at the request of
the Company, the Agent will seek to form a syndicate of registered broker-dealers ("Selected
Dealers") to assist in the sale of such Common Shares on a best efforts basis, subject to the terms
and conditions set forth in the selected dealers agreement. The Agent will endeavor to distribute
the Common Shares among the Selected Dealers in a fashion which best meets the distribution
objectives of the Bank and the Plan. The Agent will be paid a fee not to exceed 5.5% of the
aggregate Purchase Price of the Shares sold in the Syndicated Community Offering. The Agent will
pass onto the Selected Dealers who assist in the Syndicated Community Offering an amount competitive
with gross underwriting discounts charged at such time for comparable amounts of stock sold at a
comparable price per share in a similar market environment. Fees with respect to purchases effected
with the assistance of Selected Dealers other than the Agent shall be transmitted by the Agent to
such Selected Dealers. The decision to utilize Selected Dealers will be made by the Company upon
consultation with the Agent.

(d) The Company and the Bank shall reimburse the Agent for reasonable out-of-pocket expenses,
including costs of travel, meals and lodging, photocopying, telephone, facsimile and couriers. The
Company and the Bank will reimburse the Agent for the fees and expenses of the Agent's counsel which
will not exceed $50,000. The Company will bear the expenses of the Offering customarily borne by
issuers including, without limitation, regulatory filing fees, SEC, "Blue Sky," and FINRA filing and
registration fees; the fees of the Company's accountants, attorneys, appraiser, transfer agent and
registrar, printing, mailing and marketing and syndicate expenses associated with the conversion;
and the fees set forth under this Section 2; and any fees for Blue Sky legal work.

Full payment of the Agent's actual and accountable expenses, advisory fees and compensation shall be
made in next day funds on the earlier of the Closing Date or a determination by the Bank to
terminate or abandon the Offering. The payment of such expenses assume no unusual circumstances or
delays, or a re-solicitation in connection with the subscription and community offering. The Company
and the Bank acknowledge that such expense cap may be increased by mutual consent, including in the
event of a material delay in the Offering which would require an update of the financial information
in tabular form to reflect a period later than that set forth in the original filing.

Section 3. Sale and Delivery of Shares. If all conditions precedent to the consummation of the
Conversion, including without limitation, the sale of all Shares required by the Plan to be sold,
are satisfied, the Company agrees to issue, or have issued, the Shares sold in the Offering and to
release for delivery certificates for such Shares on the Closing Date against payment to the Company
by any means authorized by the Plan; provided, however, that no funds shall be released to the
Company until the conditions specified in Section 8 hereof shall have been complied with to the
reasonable satisfaction of the Agent and its counsel. The release of Shares against payment therefor
shall be made on a date and at a place acceptable to the Company, the Bank and the Agent.
Certificates for shares shall be delivered

3
<!-- page 4 -->
directly to the purchasers in accordance with their directions. The date upon which the Company
shall release or deliver the shares sold in the Offering, in accordance with the terms herein, is
called the "Closing Date."

Section 4. Representations and Warranties of the Company and the Bank. The Company and the Bank
jointly and severally represent and warrant to and agree with the Agent as follows:

(a) The Registration Statement which was prepared by the Company and the Bank and filed with the
Commission has been declared effective by the Commission, no stop order has been issued with respect
thereto and no proceedings therefor have been initiated or, to the knowledge of the Company or the
Bank, threatened by the Commission. At the time the Registration Statement, including the Prospectus
contained therein (including any amendment or supplement), became effective, at the Applicable Time
(as defined in Section 4(c) hereof) and at the Closing Date, the Registration Statement complied and
will comply in all material respects with the requirements of the 1933 Act and the 1933 Act
Regulations and the Registration Statement, including the Prospectus contained therein (including
any amendment or supplement thereto), and any information regarding the Company contained in Sales
Information (as such term is defined in Section 9(a) hereof) authorized by the Company for use in
connection with the Offering, did not contain an untrue statement of a material fact or omit to
state a material fact required to be stated therein or necessary to make the statements therein, in
light of the circumstances under which they were made, not misleading, and at the time any Rule 424
(b) or (c) Prospectus is filed with the Commission and at the Closing Date referred to in Section 2
hereof, the Prospectus (including any amendment or supplement thereto) and any information regarding
the Company contained in Sales Information (as such term is defined in Section 9(a) hereof)
authorized by the Company for use in connection with the Offering will contain all statements that
are required to be stated therein in accordance with the 1933 Act and the 1933 Act Regulations and
will not contain an untrue statement of a material fact or omit to state a material fact necessary
in order to make the statements therein, in light of the circumstances under which they were made,
not misleading; provided, however, that the representations and warranties in this Section 4(a)
shall not apply to statements or omissions made in reliance upon and in conformity with written
information furnished to the Company by the Agent or its counsel expressly regarding the Agent for
use in the Prospectus under the caption "The Conversion and Stock Offering — Marketing Arrangements"
or statements in or omissions from any Sales Information or information filed pursuant to state
securities or blue sky laws or regulations regarding the Agent.

(b) At the time of filing the Registration Statement relating to the offering of the Shares and at
the date hereof, the Company was not, and is not, an ineligible issuer, as defined in Rule 405 of
the 1933 Act Regulations. At the time of the filing of the Registration Statement and at the time of
the use of any issuer free writing prospectus, as defined in Rule 433(h) of the 1933 Act
Regulations, the Company met the conditions required by Rules 164 and 433 of the 1933 Act
Regulations for the use of a free writing prospectus. If required to be filed, the Company has filed
any issuer free writing prospectus related to the offered Shares at the time it is required to be
filed under Rule 433 of the 1933 Act Regulations and, if not required to be filed, will retain such
free writing prospectus in the Company's records pursuant to Rule 433(g) of the 1933 Act Regulations
and if any issuer free writing prospectus is used after the date hereof in connection with the
offering of the Shares the Company will file or retain such free writing prospectus as required by
Rule 433 of the 1933 Act Regulations.

(c) As of the Applicable Time, neither (i) the Issuer-Represented General Free Writing
Prospectus(es) issued at or prior to the Applicable Time and the Statutory Prospectus, all
considered together (collectively, the "General Disclosure Package"), nor (ii) any individual
Issuer-Represented Limited-Use Free Writing Prospectus, when considered together with the General
Disclosure Package, included any untrue statement of a material fact or omitted to state any
material fact necessary in order to make the statements therein, in the light of the circumstances
under which they were made, not misleading. The preceding sentence does not apply to statements in
or omissions from any Prospectus included in the Registration Statement relating to the offered
Securities or any Issuer-Represented Free

4
<!-- page 5 -->
Writing Prospectus based upon and in conformity with written information furnished to the Company by
the Agent specifically for use therein. As used in this paragraph and elsewhere in this Agreement:

1. "Applicable Time" means each and every date when a potential purchaser submitted a subscription
or otherwise committed to purchase Securities.

2. "Statutory Prospectus", as of any time, means the Prospectus relating to the offered Shares that
is included in the Registration Statement relating to the offered Shares immediately prior to the
Applicable Time, including any document incorporated by reference therein.

3. "Issuer-Represented Free Writing Prospectus" means any "issuer free writing prospectus," as
defined in Rule 433(h) of the 1933 Act Regulations, relating to the offered Shares in the form filed
or required or, if not required to be filed, in the form retained in the Company's records pursuant
to Rule 433(g) under the 1933 Act Regulations. The term does not include any writing exempted from
the definition of prospectus pursuant to clause (a) of Section 2(a)(10) of the 1933 Act, without
regard to Rule 172 or Rule 173 of the 1933 Act Regulations.

4. "Issuer-Represented General Free Writing Prospectus" means any Issuer-Represented Free Writing
Prospectus that is intended for general distribution to prospective investors.

5. "Issuer-Represented Limited-Use Free Writing Prospectus" means any Issuer-Represented Free
Writing Prospectus that is not an Issuer- Represented General Free Writing Prospectus. The term
Issuer-Represented Limited-Use Free Writing Prospectus also includes any "bona fide electronic road
show," as defined in Rule 433 of the 1933 Act Regulations, that is made available without
restriction pursuant to Rule 433(d)(8)(ii) of the 1933 Act Regulations or otherwise, even though not
required to be filed with the Commission.

6. "Permitted Free Writing Prospectus" means any free writing prospectus as defined in Rule 405 of
the 1933 Act Regulations that is consented to by the Company, the Bank and the Agent.

(d) Each Issuer-Represented Free Writing Prospectus, as of its date of first use and at all
subsequent times through the completion of the Offering and sale of the offered Shares or until any
earlier date that the Company notified or notifies the Agent (as described in the next sentence),
did not, does not and will not include any information that conflicted, conflicts or will conflict
with the information contained in the Registration Statement, including any document incorporated by
reference therein that has not been superseded or modified. If at any time following the date of
first use of an Issuer-Represented Free Writing Prospectus there occurred or occurs an event or
development as a result of which such Issuer-Represented Free Writing Prospectus conflicted or would
conflict with the information contained in the Registration Statement relating to the offered Shares
or included or would include an untrue statement of a material fact or omitted or would omit to
state a material fact necessary in order to make the statements therein, in the light of the
circumstances prevailing at that subsequent time, not misleading, the Company has notified or will
notify promptly the Agent so that any use of such Issuer-Represented Free-Writing Prospectus may
cease until it is amended or supplemented and the Company has promptly amended or will promptly
amend or supplement such Issuer-Represented Free Writing Prospectus to eliminate or correct such
conflict, untrue statement or omission. The foregoing two sentences do not apply to statements in or
omissions from any Issuer-Represented Free Writing Prospectus based upon and in conformity with
written information furnished to the Company by the Agent specifically for use therein.

(e) The Form AC, which was prepared by the Company and the Bank and filed with the OTS, has been
approved by the OTS and the related Prospectus and proxy statement to be delivered to members of the
Bank have been authorized for use by the OTS and the Form AC complied in all material respects with
the Conversion Regulations. No order has been issued by the OTS or the FDIC preventing or

5
<!-- page 6 -->
suspending the use of the Prospectus or the proxy statement, and no action by or before any such
government entity to revoke any approval, authorization or order of effectiveness related to the
Offering is pending or threatened. At the time of the approval of the Form AC, including the
Prospectus (including any amendment or supplement thereto) by the OTS and at all times subsequent
thereto until the Closing Date, the Form AC, including the Prospectus (including any amendment or
supplement thereto), will comply in all material respects with the Conversion Regulations, except to
the extent waived or otherwise approved by the OTS. The Form AC, including the Prospectus (including
any amendment or supplement thereto), does not include any untrue statement of a material fact or
omit to state a material fact required to be stated therein or necessary to make the statements
therein, in light of the circumstances under which they were made, not misleading; provided,
however, that the representations and warranties in this Section 4(e) shall not apply to statements
or omissions made in reliance upon and in conformity with written information furnished to the
Company by the Agent or its counsel expressly regarding the Agent for use in the Prospectus
contained in the Form AC under the caption "The Conversion and Stock Offering — Marketing
Arrangements."

(f) The Company has filed the Holding Company Application with the OTS and the Holding Company
Application is accurate and truthful. The Company has received written notice from the OTS of its
approval of the acquisition of the Bank, such approval remains in full force and effect and no order
has been issued by the OTS suspending or revoking such approval and no proceedings therefor have
been initiated or threatened by the OTS. At the date of such approval, the Holding Company
Application complied in all material respects with the applicable provisions of HOLA and the
regulations promulgated thereunder.

(g) The Company and the Bank have filed the Prospectus and any supplemental sales literature with
the Commission and the OTS. The Prospectus and all supplemental sales literature, as of the date the
Registration Statement became effective and on the Closing Date referred to in Section 2, complied
and will comply in all material respects with the applicable requirements of the 1933 Act
Regulations and, at or prior to the time of their first use, will have received all required
authorizations of the OTS and Commission for use in final form. No approval of any other regulatory
or supervisory or other public authority is required in connection with the distribution of the
Prospectus and any supplemental sales literature that has not been obtained and a copy of which has
been delivered to the Agent. The Company and the Bank have not distributed any offering material in
connection with the Offering except for the Prospectus and any supplemental sales material that has
been filed with the Registration Statement and the Form AC and authorized for use by the Commission
and the OTS. The information contained in the supplemental sales material filed as an exhibit to
both the Registration Statement and the Form AC does not conflict with information contained in the
Registration Statement and the Prospectus.

(h) The Plan has been adopted by the Boards of Directors of the Company and the Bank and, at the
Closing Date, will have been approved by the members of the Bank, and the offer and sale of the
Shares will have been conducted in all material respects in accordance with the Plan, the Conversion
Regulations except to the extent waived or otherwise approved by the OTS, and all other applicable
laws, regulations, decisions and orders, including all terms, conditions, requirements and
provisions precedent to the Offering imposed upon the Company and the Bank by the OTS, the
Commission, or any other regulatory authority and in the manner described in the Prospectus. To the
best knowledge of the Company and the Bank, no person has sought to obtain review of the final
action of the OTS in approving the Conversion pursuant to the HOLA or any other statute or
regulation.

(i) The Bank has been duly organized and is validly existing as a federally-chartered savings bank
in mutual form of organization and upon completion of the Conversion will become a duly organized
and validly existing federally-chartered savings bank in permanent capital stock form of
organization, in both instances duly authorized to conduct its business and own its property as
described in the Registration Statement and the Prospectus; the Bank has obtained all licenses,
permits and other governmental authorizations currently required for the conduct of its business,
except those that individually or in the

6
<!-- page 7 -->
aggregate would not materially adversely affect the financial condition, results of operations or
business of the Company and the Bank, taken as a whole; all such licenses, permits and governmental
authorizations are in full force and effect, and the Bank is in compliance with all material laws,
rules, regulations and orders applicable to the operation of its business, except where failure to
be in compliance would not materially adversely affect the financial condition, results of
operations or business of the Company and the Bank, taken as a whole; the Bank is duly qualified as
a foreign corporation to transact business and is in good standing in each jurisdiction in which its
ownership of property or leasing of property or the conduct of its business requires such
qualification, unless the failure to be so qualified in one or more of such jurisdictions would not
have a material adverse effect on the financial condition, results of operations or business of the
Bank ("Material Adverse Effect"). The Bank does not own equity securities or any equity interest in
any other business enterprise except as described in the Prospectus or as would not be material to
the operations of the Bank. Upon completion of the sale by the Company of the Shares contemplated by
the Prospectus, (i) all of the outstanding capital stock of the Bank will be duly authorized,
validly issued and fully paid and non-assessable and owned directly by the Company free and clear of
any security interest, mortgage, pledge, lien, encumbrances or legal or equitable claim and (ii) the
Company will have no direct subsidiaries other than the Bank and no indirect subsidiaries other than
Southland Finance, Inc., Ti-Serv, Inc. and Valley Title Services, LLC (the "Subsidiaries"). The
Conversion will be effected in all material respects in accordance with all applicable statutes,
regulations, decisions and orders; and, except with respect to the filing of certain post-sale,
post-Conversion reports, and documents in compliance with the 1933 Act Regulations, the Conversion
Regulations or letters of approval, at the Closing Date, all terms, conditions, requirements and
provisions with respect to the Conversion imposed by the Commission, the OTS and the FDIC, if any,
will have been complied with by the Company and the Bank in all material respects or appropriate
waivers will have been obtained and all applicable notice and waiting periods will have been
satisfied, waived or elapsed.

(j) The Company is duly organized, validly existing and in good standing as a corporation under the
laws of the State of Tennessee with full corporate power and authority to own, lease and operate its
properties and to conduct its business as described in the Registration Statement and the
Prospectus, and, at the Closing Date, the Company will be qualified to do business as a foreign
corporation in each jurisdiction in which the conduct of its business requires such qualification,
except where the failure to so qualify would not have a Material Adverse Effect on the financial
condition, results of operations or business of the Company. At the Closing Date, the Company will
have obtained all licenses, permits and other governmental authorizations currently required for the
conduct of its business except those that individually or in the aggregate would not materially
adversely affect the financial condition, results of operations or business of the Company and the
Bank, taken as a whole; all such licenses, permits and governmental authorizations will be in full
force and effect, and the Company will be in all material respects complying with all laws, rules,
regulations and orders applicable to the operation of its business. There are no outstanding
warrants or options to purchase any securities of the Company.

(k) The Subsidiaries are each duly organized, validly existing and in good standing as a corporation
under the laws of the State of Tennessee with full corporate power and authority to own, lease and
operate its properties and to conduct their businesses as described in the Registration Statement
and the Prospectus, and are duly qualified to do business as foreign corporations and are in good
standing in each jurisdiction in which the conduct of its business requires such qualification,
except where the failure to so qualify would not have a Material Adverse Effect on the financial
condition, results of operations or business of the Company and the Bank, taken as a whole. The
activities of the Subsidiaries are permissible to subsidiaries of federal savings banks. The
Subsidiaries have each obtained all licenses, permits and other governmental authorizations
currently required for the conduct of its business except those that individually or in the
aggregate would not materially adversely affect the financial condition, results of operations or
business of the Company and the Bank, taken as a whole; all such licenses, permits and governmental
authorizations will be in full force and effect, and the Subsidiaries are in all material respects
complying with all laws, rules, regulations and orders applicable to the operation of their
respective business. All of the issued and outstanding capital stock of the Subsidiaries have been
duly

7
<!-- page 8 -->
authorized and validly issued, is fully paid and non-assessable and owned by the Bank directly, free
and clear of any security interest, mortgage, pledge, lien, encumbrance or legal or equitable claim.

(l) The Bank is a member of the Federal Home Loan Bank of Cincinnati ("FHLB-Cincinnati"). The
deposit accounts of the Bank are insured by the FDIC up to the applicable limits, and no proceedings
for the termination or revocation of such insurance are pending or, to the best knowledge of the
Company or the Bank, threatened. The Bank is a "qualified thrift lender" within the meaning of 12
U.S.C. §l467a(m).

(m) The Bank and the Company have good and marketable title to all real property and good title to
all other assets material to the business of the Company and the Bank, taken as a whole, and to
those properties and assets described in the Registration Statement and Prospectus as owned by them,
free and clear of all liens, charges, encumbrances or restrictions, except such as are described in
the Registration Statement and Prospectus, or are not material to the business of the Company and
the Bank, taken as a whole; and all of the leases and subleases material to the business of the
Company and the Bank, taken as a whole, under which, the Company or the Bank hold properties,
including those described in the Registration Statement and Prospectus, are in full force and
effect.

(n) The Company has received an opinion of its special counsel, Kilpatrick Stockton LLP, with
respect to the federal income tax consequences of the Conversion and an opinion of its tax advisor,
Hazlett, Lewis & Bieter, PLLC, with respect to the Tennessee income tax consequences of the
Conversion; all material aspects of such opinions are accurately summarized in the Registration
Statement and the Prospectus. The Company and the Bank represent and warrant that the facts upon
which such opinions are based are truthful, accurate and complete. Neither the Company nor the Bank
will take any action inconsistent therewith.

(o) Each of the Company and the Bank has all such power, authority, authorizations, approvals and
orders as may be required to enter into this Agreement, to carry out the provisions and conditions
hereof and to issue and sell the Shares to be sold by the Company as provided herein and as
described in the Prospectus, subject to approval or confirmation by the OTS of the final appraisal
of the Bank. The execution, delivery and performance of this Agreement and the consummation of the
transactions herein contemplated have been duly and validly authorized by all necessary corporate
action on the part of the Bank and the Company. This Agreement has been validly executed and
delivered by the Company and the Bank and is the valid, legal and binding agreement of the Company
and the Bank enforceable in accordance with its terms (except as the enforceability thereof may be
limited by bankruptcy, insolvency, moratorium, reorganization or similar laws relating to or
affecting the enforcement of creditors' rights generally or the rights of creditors of savings and
loan holding companies, the accounts of whose subsidiaries are insured by the FDIC, or by general
equity principles, regardless of whether such enforceability is considered in a proceeding in equity
or at law, and except to the extent, if any, that the provisions of Sections 9 and 10 hereof may be
unenforceable as against public policy).

(p) Neither the Company nor the Bank is in violation of any directive received from the OTS, the
FDIC, or any other agency to make any material change in the method of conducting its business so as
to comply in all material respects with all applicable statutes and regulations (including, without
limitation, regulations, decisions, directives and orders of the OTS and the FDIC) and, except as
may be set forth in the Registration Statement, the General Disclosure Package and the Prospectus,
there is no suit or proceeding or charge or action before or by any court, regulatory authority or
governmental agency or body, pending or threatened, which might materially and adversely affect the
Offering, as described in the Registration Statement and the Prospectus or which might result in any
material adverse change in the financial condition, results of operations or business of the Company
and the Bank, taken as a whole, or which would materially affect their properties and assets.

8
<!-- page 9 -->
(q) The consolidated financial statements, schedules and notes related thereto which are included in
the General Disclosure Package and the Prospectus fairly present the balance sheet, income
statement, statement of changes in equity capital and statement of cash flows of the Bank and the
Subsidiaries on a consolidated basis at the respective dates indicated and for the respective
periods covered thereby and comply as to form in all material respects with the applicable
accounting requirements of the 1933 Act Regulations and Title 12 of the Code of Federal Regulations.
Such consolidated financial statements, schedules and notes related thereto have been prepared in
accordance with generally accepted accounting principles ("GAAP") consistently applied through the
periods involved, present fairly in all material respects the information required to be stated
therein and are consistent with the most recent financial statements and other reports filed by the
Bank with the OTS, except that accounting principles employed in such regulatory filings conform to
the requirements of the OTS and not necessarily to GAAP. The other financial, statistical and pro
forma information and related notes included in the Prospectus present fairly the information shown
therein on a basis consistent with the audited and unaudited consolidated financial statements of
the Bank included in the Prospectus, and as to the pro forma adjustments, the adjustments made
therein have been properly applied on the basis described therein.

(r) Since the respective dates as of which information is given in the Registration Statement
including the Prospectus: (i) there has not been any material adverse change, financial or
otherwise, in the condition of the Company and the Bank and their subsidiaries, considered as one
enterprise, or in the earnings, capital, properties or business of the Company and the Bank and
their subsidiaries, whether or not arising in the ordinary course of business; (ii) there has not
been any material increase in the long-term debt of the Bank or in the principal amount of the
Bank's assets which are classified by the Bank as impaired, substandard, doubtful or loss or in
loans past due 90 days or more or real estate acquired by foreclosure, by deed-in-lieu of
foreclosure or deemed in-substance foreclosure or any material decrease in equity capital or total
assets of the Bank; nor has the Company or the Bank issued any securities (other than in connection
with the incorporation of the Company) or incurred any liability or obligation for borrowing other
than in the ordinary course of business; (iii) there have not been any material transactions entered
into by the Company or the Bank; (iv) there has not been any material adverse change in the
aggregate dollar amount (on a consolidated basis with the Bank) of the Company's deposits or its net
worth; (v) there has been no material adverse change in the Company's or the Bank's relationship
with its insurance carriers, including, without limitation, cancellation or other termination of the
Company's or the Bank's fidelity bond or any other type of insurance coverage; (vi) except as
disclosed in the General Disclosure Package and the Prospectus, there has been no material change in
management of the Company or the Bank; (vii) neither the Company nor the Bank has sustained any
material loss or interference with its respective business or properties from fire, flood,
windstorm, earthquake, accident or other calamity, whether or not covered by insurance; (viii)
neither the Company nor the Bank has defaulted in the payment of principal or interest on any
outstanding debt obligations; (ix) the capitalization, liabilities, assets, properties and business
of the Company and the Bank conform in all material respects to the descriptions thereof contained
in the General Disclosure Package and the Prospectus; and (x) neither the Company nor the Bank has
any material contingent liabilities, except as set forth in the Prospectus.

(s) Neither the Company nor the Bank is (i) in violation of their respective charters or bylaws (and
the Bank will not be in violation of its charter or bylaws in stock form upon completion of the
Conversion), or (ii) in default in the performance or observance of any obligation, agreement,
covenant, or condition contained in any material contract, lease, loan agreement, indenture or other
instrument to which it is a party or by which it or any of its property may be bound. The execution
and delivery of this Agreement and the consummation of the transactions herein contemplated will
not: (i) conflict with or constitute a breach of, or default under, or result in the creation of any
lien, charge or encumbrance upon any of the assets of the Company or the Bank pursuant to the
respective charters or bylaws of the Company or the Bank or any contract, lease or other instrument
in which the Company or the Bank has a beneficial interest, or any applicable law, rule, regulation
or order; (ii) violate any authorization, approval, judgment, decree, order, statute, rule or
regulation applicable to the Company or the Bank, except for

9
<!-- page 10 -->
such violations which would not have a Material Adverse Effect on the financial condition and
results of operations of the Company and the Bank on a consolidated basis; or (iii) result in the
creation of any material lien, charge or encumbrance upon any property of the Company or the Bank.

(t) All documents made available to or delivered or to be made available to or delivered by the
Company and the Bank or their representatives in connection with the issuance and sale of the
Shares, including records of account holders and depositors of the Bank, or in connection with the
Agent's exercise of due diligence, except for those documents which were prepared by parties other
than the Company or the Bank or their representatives, to the best knowledge of the Company and the
Bank, were on the dates on which they were delivered, or will be on the dates on which they are to
be delivered, true, complete and correct in all material respects.

(u) No default exists, and no event has occurred which with notice or lapse of time, or both, would
constitute a default on the part of the Company or the Bank in the due performance and observance of
any term, covenant or condition of any indenture, mortgage, deed of trust, note, bank loan or credit
agreement or any other instrument or agreement to which the Company or the Bank is a party or by
which any of them or any of their property is bound or affected, except such defaults which would
not have a material adverse affect on the financial condition or results of operations of the
Company and the Bank, taken as a whole; such agreements are in full force and effect and are the
legal, valid and binding agreements of the applicable party and the other parties thereto,
enforceable in accordance with their terms, except as the enforcement thereof may be limited by
bankruptcy, insolvency, reorganization or similar laws affecting the rights of creditors generally
and subject to general principles of equity; and no other party to any such agreements has
instituted or, to the best knowledge of the Company or the Bank, threatened any action or proceeding
wherein the Company or the Bank would or might be alleged to be in default thereunder, where such
action or proceeding, if determined adversely to the Company or the Bank, would have a Material
Adverse Effect on the financial condition, results of operations, or business of the Company or the
Bank, taken as a whole. There are no contracts or documents that are required to be filed as
exhibits to the Registration Statement or described in the Registration Statement, the Prospectus,
or any Permitted Free Writing Prospectus which are not so filed or described as required, and such
contracts and documents as are summarized in the Registration Statement, the Prospectus, and any
Permitted Free Writing Prospectus are fairly summarized therein in all material respects. No party
has sent or received any notice indicating the termination of or intention to terminate any of the
contracts or agreements referred to or described in the Registration Statement, the Prospectus, or
any Permitted Free Writing Prospectus, or filed as an exhibit to the Registration Statement, and, to
the knowledge of the Company and the Bank, no such termination has been threatened by any party to
any such contract or agreement.

(v) Upon consummation of the Conversion, the authorized, issued and outstanding equity capital of
the Company will be within the range set forth in the General Disclosure Package and the Prospectus
under the caption "Capitalization," and no Shares have been or will be issued and outstanding prior
to the Closing Date; the Shares will have been duly and validly authorized for issuance and, when
issued and delivered by the Company pursuant to the Plan against payment of the consideration
calculated as set forth in the Plan and in the Prospectus, will be duly and validly issued, fully
paid and non-assessable, except for shares purchased by the ESOP with funds borrowed from the
Company to the extent payment therefor in cash has not been received by the Company; except to the
extent that subscription rights and priorities pursuant thereto exist pursuant to the Plan, no
preemptive rights exist with respect to the Shares; and the terms and provisions of the Shares will
conform in all material respects to the description thereof contained in the Registration Statement
and the Prospectus. The Shares have been approved for listing on the Nasdaq Capital Market, subject
to issuance. Upon the issuance of the Shares, good title to the Shares will be transferred from the
Company to the purchasers thereof against payment therefor, subject to such claims as may be
asserted against the purchasers thereof by third-party claimants.

(w) No approval of any regulatory or supervisory or other public authority is required in connection
with the execution and delivery of this Agreement or the issuance of the Shares, except for the

10
<!-- page 11 -->
approval of the Commission and the OTS, and any necessary qualification, notification, registration
or exemption under the securities or blue sky laws of the various states in which the Shares are to
be offered, and except as may be required under the rules and regulations of the Financial Industry
Regulatory Authority ("FINRA")

(x) Hazlett, Lewis & Bieter, PLLC, which has certified the audited financial statements and
schedules of the Bank included in the Prospectus, has advised the Company and the Bank in writing
that they are, with respect to the Company and the Bank, independent registered public accountants
within the applicable rules of the Public Company Accounting Oversight Board (United States).

(y) Keller & Company, Inc., which has prepared the Valuation Appraisal Report (as amended or
supplemented, if so amended or supplemented) of the Bank, has advised the Bank in writing that it is
independent of the Company and the Bank within the meaning of the Conversion Regulations.

(z) The Company and the Bank have timely filed or extended all required federal, state and local tax
returns; the Company and the Bank have paid all taxes that have become due and payable in respect of
such returns, except where permitted to be extended, have made adequate reserves for similar future
tax liabilities and no deficiency has been asserted with respect thereto by any taxing authority.
The Company and the Bank have no knowledge of any tax deficiency which has been or might be assessed
against either of them which, if the subject of an unfavorable decision, ruling or finding, could
have, individually or in the aggregate with other tax deficiencies, a Material Adverse Effect. All
material tax liabilities have been adequately provided for in the financial statements of the
Company and the Bank in accordance with GAAP. There are no transfer taxes or other similar fees or
charges under Federal law or the laws of any state, or any political subdivision thereof, required
to be paid in connection with the execution and delivery of this Agreement by the Company or with
the issuance or sale by the Company of the Shares.

(aa) The Company and the Bank are in compliance in all material respects with the applicable
financial record-keeping and reporting requirements of the Currency and Foreign Transactions
Reporting Act of 1970, as amended, and the regulations and rules thereunder.

(bb) To the knowledge of the Company and the Bank, none of the Company, the Bank or the employees of
the Company or the Bank has made any payment of funds of the Company or the Bank as a loan for the
purchase of the Shares or made any other payment of funds prohibited by law, and no funds have been
set aside to be used for any payment prohibited by law.

(cc) Neither the Company nor the Bank has: (i) issued any securities within the last 18 months
(except for notes to evidence bank loans and reverse repurchase agreements or other liabilities in
the ordinary course of business or as described in the Prospectus); (ii) had any material dealings
within the 12 months prior to the date hereof with any member of the FINRA, or any person related to
or associated with such member, other than discussions and meetings relating to the proposed
Offering and routine purchases and sales of United States government and agency and other securities
in the ordinary course of business; (iii) entered into a financial or management consulting
agreement except as contemplated hereunder; and (iv) engaged any intermediary between the Agent and
the Company or the Bank in connection with the offering of the Shares, and no person is being
compensated in any manner for such service. Appropriate arrangements have been made for placing the
funds received from subscriptions for Shares in a special interest-bearing account with the Bank
until all Shares are sold and paid for, with provision for refund to the purchasers in the event
that the Offering is not completed for whatever reason or for delivery to the Company if all Shares
are sold.

(dd) The Company and the Bank have not relied upon the Agent or its legal counsel for any legal, tax
or accounting advice in connection with the Conversion.

11
<!-- page 12 -->
(ee) The records used by the Company and the Bank to determine the identities of Eligible Account
Holders, Supplemental Eligible Account Holders and Other Members are accurate and complete in all
material respects.

(ff) The Company is not required to be registered under the Investment Company Act of 1940, as
amended.

(gg) Neither the Company nor the Bank or any properties owned or operated by the Company or the
Bank, is in violation of or liable under any Environmental Law (as defined below), except for such
violations or liabilities that, individually or in the aggregate, would not have a Material Adverse
Effect on the financial condition, results of operations or business of the Company and the Bank,
taken as a whole. There are no actions, suits or proceedings, or demands, claims, notices or
investigations (including, without limitation, notices, demand letters or requests for information
from any environmental agency) instituted or pending or, to the knowledge of the Company or the
Bank, threatened relating to the liability of any property owned or operated by the Company or the
Bank under any Environmental Law. For purposes of this subsection, the term "Environmental Law"
means any federal, state, local or foreign law, statute, ordinance, rule, regulation, code, license,
permit, authorization, approval, consent, order, judgment, decree, injunction or agreement with any
regulatory authority relating to (i) the protection, preservation or restoration of the environment
(including, without limitation, air, water, vapor, surface water, groundwater, drinking water
supply, surface soil, subsurface soil, plant and animal life or any other natural resource), and/or
(ii) the use, storage, recycling, treatment, generation, transportation, processing, handling,
labeling, production, release or disposal of any substance presently listed, defined, designated or
classified as hazardous, toxic, radioactive or dangerous, or otherwise regulated, whether by type or
by quantity, including any material containing any such substance as a component.

(hh) The Company has filed a registration statement to register for the Common Shares under Section
12(b) of the Securities Exchange Act of 1934, as amended (the "1934 Act").

(ii) The Company and its subsidiaries maintain a system of internal accounting controls sufficient
to provide reasonable assurance that (A) transactions are executed in accordance with management's
general or specific authorizations, (B) transactions are recorded as necessary to permit preparation
of financial statements in conformity with generally accepted accounting principles and to maintain
accountability for assets, (C) access to assets is permitted only in accordance with management's
general or specific authorization, and (D) the recorded accounts or assets is compared with the
existing assets at reasonable intervals and appropriate action is taken with respect thereto. The
books, records and accounts and systems of internal accounting control of the Company and its
subsidiaries comply in all material respects with the requirements of Section 13 (b)(2) of the 1934
Act. The Company has established and maintains "disclosure controls and procedures" (as defined in
Rule 13a-15(e) under the 1934 Act) that are effective in ensuring that the information it will be
required to disclose in the reports it files or submits under the 1934 Act is accumulated and
communicated to the Company's management (including the Company's chief executive officer and chief
financial officer) in a timely manner and recorded, processed, summarized and reported within the
periods specified in the Commission's rules and forms. To the knowledge of the Company and the Bank,
and the Audit Committee of the Board of Directors have been advised of: (A) any significant
deficiencies and material weaknesses in the design or operation of internal control over financial
reporting which could adversely affect Company's and the Bank's ability to record, process,
summarize, and report financial data; and (B) any fraud, whether or not material, that involves
management or other employees who have a significant role in the Company's or the Bank's internal
accounting controls.

(jj) All of the loans represented as assets of the Company or the Bank in the Prospectus meet or are
exempt from all requirements of federal, state and local law pertaining to lending, including,
without limitation, truth in lending (including the requirements of Regulation Z and 12 C.F.R. Part
226), real estate settlement procedures, consumer credit protection, equal credit opportunity and
all disclosure laws

12
<!-- page 13 -->
applicable to such loans, except for violations which, if asserted, would not have a Material
Adverse Effect on the financial condition, results of operations, or business of the Company and the
Bank, taken as a whole.

(kk) To the Company's and the Bank's knowledge, there are no affiliations or associations between
any member of the FINRA and any of the Company's or the Bank's officers, directors or 5% or greater
securityholders, except as set forth in the Registration Statement and the Prospectus.

(ll) The Company has taken all actions necessary to obtain at Closing a Blue Sky Memorandum from
Kilpatrick Stockton LLP.

(mm) Any certificates signed by an officer of the Company or the Bank pursuant to the conditions of
this Agreement and delivered to the Agent or their counsel that refers to this Agreement shall be
deemed to be a representation and warranty by the Company or the Bank, as the case may be, to the
Agent as to the matters covered thereby with the same effect as if such representation and warranty
were set forth herein.

(nn) The Company and the Bank carry, or are covered by, insurance in such amounts and covering such
risks at they deem reasonably adequate for the conduct of their respective businesses and the value
of their respective properties.

(oo) Subsequent to the date the Registration Statement is declared effective by the Commission and
prior to the Closing Date, except as otherwise may be indicated or contemplated in the Registration
Statement, neither the Company nor the Bank has or will have issued any securities or incurred any
liability or obligation, direct or contingent, for borrowed money, except borrowings from the same
or similar sources indicated in the Prospectus in the ordinary course of its business.

(pp) All Sales Information (as defined in Section 9(a)) used by the Company in connection with the
Conversion that is required by the OTS and the Commission to be filed has been filed with and
approved by the OTS and the Commission.

(qq) The statistical and market related data contained in any Permitted Free Writing Prospectus, the
Prospectus and the Registration Statement are based on or derived from sources which the Company and
the Bank believe were reliable and accurate at the time they were filed with the Commission. No
forward-looking statement (within the meaning of Section 27A of the 1933 Act and Section 21E of the
1934 Act) contained in the Registration Statement, the Prospectus, or any Permitted Free Writing
Prospectus has been made or reaffirmed without a reasonable basis or has been disclosed other than
in good faith.

(rr) Except for the Bank's profit sharing/401(k) plan, neither the Company nor the Bank maintains
any other "pension plan," as defined in the Employee Retirement Income Security Act of 1974, as
amended ("ERISA"). In addition, (A) the employee benefit plans, including employee welfare benefit
plans, of the Company or the Bank (the "Employee Plans") have been operated in compliance with the
applicable provisions of ERISA, the Internal Revenue Code of 1986, as amended (the "Code"), all
regulations, rulings and announcements promulgated or issued thereunder and all other applicable
laws and governmental regulations, (B) no reportable event under Section 4043(c) of ERISA has
occurred with respect to any Employee Plan of the Company or the Bank for which the reporting
requirements have not been waived by the Pension Benefit Guaranty Corporation, (C) no prohibited
transaction under Section 406 of ERISA, for which an exemption does not apply, has occurred with
respect to any Employee Plan of the Company or the Bank and (D) all Employee Plans that are group
health plans have been operated in compliance with the group health plan continuation coverage
requirements of Section 4980B of the Code, except to the extent such noncompliance, reportable event
or prohibited transaction would not have, individually or in the aggregate, a Material Adverse
Effect. There are no pending or, to the knowledge of

13
<!-- page 14 -->
the Company and the Bank, threatened, claims by or on behalf of any Employee Plan, by any employee
or beneficiary covered under any such Employee Plan or by any governmental authority, or otherwise
involving such Employee Plans or any of their respective fiduciaries (other than for routine claims
for benefits).

Section 5. Representations and Warranties of the Agent. The Agent represents and warrants to the
Company and the Bank as follows:

(a) The Agent is a corporation and is validly existing in good standing under the laws of the State
of New York with full power and authority to provide the services to be furnished to the Company and
the Bank hereunder.

(b) The execution and delivery of this Agreement and the consummation of the transactions
contemplated hereby have been duly and validly authorized by all necessary action on the part of the
Agent, and this Agreement has been duly and validly executed and delivered by the Agent and is a
legal, valid and binding agreement of the Agent, enforceable in accordance with its terms, except as
the legality, validity, binding nature and enforceability thereof may be limited by (i) bankruptcy,
insolvency, moratorium, reorganization, conservatorship, receivership or other similar laws relating
to or affecting the enforcement of creditors' rights generally, and (ii) general equity principles
regardless of whether such enforceability is considered in a proceeding in equity or at law.

(c) Each of the Agent and its employees, agents and representatives who shall perform any of the
services hereunder shall be duly authorized and empowered, and shall have all licenses, approvals
and permits necessary to perform such services; and the Agent is a registered selling agent in each
of the jurisdictions in which the Shares are to be offered by the Company in reliance upon the Agent
as a registered selling agent as set forth in the blue sky memorandum prepared with respect to the
Offering.

(d) The execution and delivery of this Agreement by the Agent, the consummation of the transactions
contemplated hereby and compliance with the terms and provisions hereof will not conflict with, or
result in a breach of, any of the terms, provisions or conditions of, or constitute a default (or an
event which with notice or lapse of time or both would constitute a default) under, the Articles of
Incorporation or Bylaws of the Agent or any agreement, indenture or other instrument to which the
Agent is a party or by which it or its property is bound.

(e) No approval of any regulatory or supervisory or other public authority is required in connection
with the Agent's execution and delivery of this Agreement, except as may have been received.

(f) There is no suit or proceeding or charge or action before or by any court, regulatory authority
or government agency or body or, to the knowledge of the Agent, pending or threatened, which might
materially adversely affect the Agent's performance under this Agreement.

Section 6. Covenants of the Company and the Bank. The Company and the Bank hereby jointly and
severally covenant and agree with the Agent as follows:

(a) The Company will not, at any time after the date the Registration Statement is declared
effective, file any amendment or supplement to the Registration Statement without providing the
Agent and its counsel an opportunity to review such amendment or supplement or file any amendment or
supplement to which amendment or supplement the Agent or its counsel shall reasonably object.

(b) If at any time following issuance of an Issuer-Represented Free Writing Prospectus there
occurred or occurs an event or development as a result of which such Issuer Represented Free Writing
Prospectus conflicted or would conflict with the information contained in the Registration Statement
or included or would include an untrue statement of a material fact or omitted or would omit to
state a

14
<!-- page 15 -->
material fact necessary in order to make the statements therein, in light of the circumstances
prevailing at the subsequent time, not misleading, the Company has notified or will notify promptly
the Agent so that any use of such Issuer-Represented Free Writing Prospectus may cease until it is
amended or supplemented and the Company has promptly amended or will promptly amend or supplement
such Issuer-Represented Free Writing Prospectus to eliminate or correct such conflict, untrue
statement or omission; provided, however, that this covenant shall not apply to any statements or
omissions made in reliance upon and in conformity with information furnished in writing to the
Company by the Agent expressly for use therein.

(c) The Company and the Bank represent and agree that, unless it obtains the prior consent of the
Agent, and the Agent represents and agrees that, unless it obtains the prior consent of the Company
or the Bank, it has not made and will not make any offer relating to the offered Shares that would
constitute an "issuer free writing prospectus" as defined in Rule 433 of the 1933 Act Regulations,
or that would constitute a "free writing prospectus," as defined in Rule 405 of the 1933 Act
Regulations, required to be filed with the Commission. Any such free writing prospectus consented to
by the Company, the Bank and the Agent is hereinafter referred to as a "Permitted Free Writing
Prospectus." The Company and the Bank represent that it has treated or agrees that it will treat
each Permitted Free Writing Prospectus as an "issuer free writing prospectus," as defined in Rule
433 of the 1933 Act Regulations, and has complied and will comply with the requirements of Rule 433
of the 1933 Act Regulations applicable to any Permitted Free Writing Prospectus, including timely
Commission filing where required, legending and record keeping. The Company and the Bank need not
treat any communication as a free writing prospectus if it is exempt from the definition of
prospectus pursuant to Clause (a) of Section 2(a)(10) of the 1933 Act without regard to Rule 172 or
173 of the 1933 Act Regulations.

(d) The Bank will not, at any time after the Form AC is approved by the OTS, file any amendment or
supplement to such Form AC without providing the Agent and its counsel an opportunity to review such
amendment or supplement or file any amendment or supplement to which amendment or supplement the
Agent or its counsel shall reasonably object.

(e) The Company will not, at any time after the Holding Company Application is approved by the OTS,
file any amendment or supplement to such Holding Company Application without providing the Agent and
its counsel an opportunity to review the non-confidential portions of such amendment or supplement
or file any amendment or supplement to which amendment or supplement the Agent or its counsel shall
reasonably object.

(f) The Company and the Bank will use their best efforts to cause any post-effective amendment to
the Registration Statement to be declared effective by the Commission and any post-effective
amendment to the Form AC or the Holding Company Application to be approved by the OTS and will
immediately upon receipt of any information concerning the events listed below notify the Agent: (i)
when the Registration Statement, as amended, has become effective; (ii) when the Form AC or the
Holding Company Application, as amended, has been approved by the OTS; (iii) of any comments from
the Commission, the OTS or any other governmental entity with respect to the Conversion contemplated
by this Agreement; (iv) of the request by the Commission, the OTS or any other governmental entity
for any amendment or supplement to the Registration Statement, the Form AC, Holding Company
Application or for additional information; (v) of the issuance by the Commission, the OTS or any
other governmental entity of any order or other action suspending the Conversion or the use of the
Registration Statement or the Prospectus or any other filing of the Company or the Bank under the
Conversion Regulations, or other applicable law, or the threat of any such action; (vi) of the
issuance by the Commission, the OTS or any authority of any stop order suspending the effectiveness
of the Registration Statement or of the initiation or threat of initiation or threat of any
proceedings for that purpose; or (vii) of the occurrence of any event mentioned in paragraph (h)
below. The Company and the Bank will make every reasonable effort (i) to prevent the issuance by the
Commission, the OTS or any other state

15
<!-- page 16 -->
authority of any such order and, (ii) if any such order shall at any time be issued, to obtain the
lifting thereof at the earliest possible time.

(g) The Company and the Bank will deliver to the Agent and to its counsel two conformed copies of
the Registration Statement, the Form AC or the Holding Company Application, as originally filed and
of each amendment or supplement thereto, including all exhibits. Further, the Company and the Bank
will deliver such additional copies of the foregoing documents to counsel to the Agent as may be
required for any FINRA filings.

(h) The Company and the Bank will furnish to the Agent, from time to time during the period when the
Prospectus (or any later prospectus related to this offering) is required to be delivered under the
1933 Act or the 1934 Act, such number of copies of such Prospectus (as amended or supplemented) as
the Agent may reasonably request for the purposes contemplated by the 1933 Act, the 1933 Act
Regulations, the 1934 Act or the rules and regulations promulgated under the 1934 Act (the "1934 Act
Regulations"). The Company authorizes the Agent to use the Prospectus (as amended or supplemented,
if amended or supplemented) in any lawful manner contemplated by the Plan in connection with the
sale of the Shares by the Agent.

(i) The Company and the Bank will comply with any and all material terms, conditions, requirements
and provisions with respect to the Offering imposed by the Commission, the OTS or the Conversion
Regulations, and by the 1933 Act, the 1933 Act Regulations, the 1934 Act and the 1934 Act
Regulations to be complied with prior to or subsequent to the Closing Date and when the Prospectus
is required to be delivered, and during such time period the Company and the Bank will comply, at
their own expense, with all material requirements imposed upon them by the Commission, the OTS or
the Conversion Regulations, and by the 1933 Act, the 1933 Act Regulations, the 1934 Act and the 1934
Act Regulations, including, without limitation, Rule 10b-5 under the 1934 Act, in each case as from
time to time in force, so far as necessary to permit the continuance of sales or dealing in the
Common Shares during such period in accordance with the provisions hereof and the Prospectus. The
Company will comply with all undertakings contained in the Registration Statement.

(j) If, at any time during the period when the Prospectus is required to be delivered, any event
relating to or affecting the Company or the Bank shall occur, as a result of which it is necessary
or appropriate, in the opinion of counsel for the Company or in the reasonable opinion of the
Agent's counsel, to amend or supplement the Registration Statement or Prospectus in order to make
the Registration Statement or Prospectus not misleading in light of the circumstances existing at
the time the Prospectus is delivered to a purchaser, the Company will immediately so inform the
Agent and prepare and file, at its own expense, with the Commission and the OTS, and furnish to the
Agent a reasonable number of copies, of an amendment or amendments of, or a supplement or
supplements to, the Registration Statement or Prospectus (in form and substance reasonably
satisfactory to the Agent and its counsel after a reasonable time for review) which will amend or
supplement the Registration Statement or Prospectus so that as amended or supplemented it will not
contain an untrue statement of a material fact or omit to state a material fact necessary in order
to make the statements therein, in light of the circumstances existing at the time the Prospectus is
delivered to a purchaser, not misleading. For the purpose of this Agreement, the Company will timely
furnish to the Agent such information with respect to itself and the Bank as the Agent may from time
to time reasonably request.

(k) The Company and the Bank will take all necessary actions in cooperating with the Agent and
furnish to whomever the Agent may direct such information as may be required to qualify or register
the Shares for offering and sale by it or to exempt such Shares from registration, or to exempt the
Company as a broker-dealer and its officers, directors and employees as broker-dealers or agents
under the applicable securities or blue sky laws of such jurisdictions in which the Shares are
required under the Conversion Regulations to be sold or as the Agent and the Company may reasonably
agree upon; provided, however, that the Company shall not be obligated to file any general consent
to service of

16
<!-- page 17 -->
process, to qualify to do business in any jurisdiction in which it is not so qualified, or to
register its directors or officers as brokers, dealers, salesmen or agents in any jurisdiction. In
each jurisdiction where any of the Shares shall have been qualified or registered as above provided,
the Company will make and file such statements and reports in each fiscal period as are or may be
required by the laws of such jurisdiction.

(l) The liquidation account for the benefit of Eligible Account Holders and Supplemental Eligible
Account Holders will be duly established and maintained in accordance with the requirements of the
Conversion Regulations, and such Eligible Account Holders and Supplemental Eligible Account Holders
who continue to maintain their savings accounts in the Bank will have an inchoate interest in their
pro rata portion of the liquidation account, which shall have a priority superior to that of the
holders of the Common Stock in the event of a complete liquidation of the Bank.

(m) The Company and the Bank will not sell or issue, contract to sell or otherwise dispose of, for a
period of 90 days after the Closing Date, without the Agent's prior written consent, any of their
shares of their common stock, other than the Common Shares or other than in connection with any plan
or arrangement described in the Prospectus.

(n) The Company will register its common stock under Section 12(b) of the 1934 Act. The Company
shall maintain the effectiveness of such registration for not less than three years from the time of
effectiveness or such shorter period as may be required by the OTS.

(o) During the period during which the Common Shares are registered under the 1934 Act or for three
years from the date hereof, whichever period is greater, the Company will furnish to its
shareholders as soon as practicable after the end of each fiscal year an annual report of the
Company (including a consolidated balance sheet and statements of consolidated income, shareholders'
equity and cash flows of the Company and its subsidiaries as at the end of and for such year,
certified by independent public accountants in accordance with Regulation S-X under the 1933 Act and
the 1934 Act) and make available as soon as practicable after the end of each of the first three
quarters of each fiscal year (beginning with the first fiscal quarter ending after the effective
time of the Registration Statement) financial information of the Company and its subsidiaries for
such quarter in reasonable detail.

(p) During the period of three years from the date hereof, the Company will furnish to the Agent:
(i) as soon as practicable after such information is publicly available, a copy of each report of
the Company furnished to or filed with the Commission under the 1934 Act or any national securities
exchange or system on which any class of securities of the Company is listed or quoted (including,
but not limited to, reports on Forms 10-K, 10-Q and 8-K and all proxy statements and annual reports
to stockholders), (ii) a copy of each other non-confidential report of the Company mailed to its
shareholders or filed with the Commission, the OTS or any other supervisory or regulatory authority
or any national securities exchange or system on which any class of securities of the Company is
listed or quoted, each press release and material news items and additional documents and
information with respect to the Company or the Bank as the Agent may reasonably request; and (iii)
from time to time, such other nonconfidential information concerning the Company or the Bank as the
Agent may reasonably request.

(q) The Company and the Bank will use the net proceeds from the sale of the Shares in the manner set
forth in the Prospectus under the caption "Use of Proceeds."

(r) Other than as permitted by the Conversion Regulations, the HOLA, the 1933 Act, the 1933 Act
Regulations and the rules and regulations and the laws of any state in which the Shares are
registered or qualified for sale or exempt from registration, the Company will not distribute any
prospectus, offering circular or other offering material in connection with the offer and sale of
the Shares.

17
<!-- page 18 -->
(s) The Company will make generally available to its security holders as soon as practicable, but
not later than 60 days after the close of the period covered thereby, an earnings statement (in form
complying with the provisions of Rule 158 of the 1933 Act Regulations) covering a twelve-month
period beginning not later than the first day of the Company's fiscal quarter next following the
effective date (as defined in such Rule 158) of the Registration Statement.

(t) The Company will use its best efforts to obtain and maintain a listing of the Common Shares on
the Nasdaq Capital Market on or prior to the Closing Date.

(u) The Bank will maintain appropriate arrangements for depositing all funds received from persons
mailing or delivering subscriptions for or orders to purchase Shares in the Offering with the Bank
or another financial institution whose deposits are insured by the FDIC, on an interest- bearing
basis at the rate described in the Prospectus until the Closing Date and satisfaction of all
conditions precedent to the release of the Company's or the Bank's obligation to refund payments
received from persons subscribing for or ordering Shares in the Offering in accordance with the Plan
and as described in the Prospectus or until refunds of such funds have been made to the persons
entitled thereto or withdrawal authorizations canceled in accordance with the Plan and as described
in the Prospectus. The Bank will maintain such records of all funds received to permit the funds of
each subscriber to be separately insured by the FDIC (to the maximum extent allowable) and to enable
the Bank to make the appropriate refunds of such funds in the event that such refunds are required
to be made in accordance with the Plan and as described in the Prospectus.

(v) The Company will report the use of proceeds of the Offering in accordance with Rule 463 under
the 1933 Act.

(w) The Company will promptly take all necessary action to register as savings and loan holding
company under the HOLA.

(x) The Company and the Bank will take such actions and furnish such information as are reasonably
requested by the Agent in order for the Agent to ensure compliance with the FINRA Rule 2790.

(y) Neither the Company nor the Bank, will amend the Plan without notifying the Agent and the
Agent's counsel prior thereto.

(z) The Company shall assist the Agent, if necessary, in connection with the allocation of the
Shares in the event of an oversubscription and shall provide the Agent with any information
necessary to assist the Company in allocating the Shares in such event and such information shall be
accurate and reliable in all material respects.

(aa) Prior to the Closing Date, the Company will inform the Agent of any event or circumstances of
which it is aware as a result of which the Registration Statement and/or Prospectus, as then amended
or supplemented, would contain an untrue statement of a material fact or omit to state a material
fact necessary in order to make the statements therein not misleading.

(bb) The Company will not deliver the Shares until the Company and the Bank have satisfied or caused
to be satisfied each condition set forth in Section 8 hereof, unless such condition is waived in
writing by the Agent.

(cc) Subsequent to the date the Registration Statement is declared effective by the Commission and
prior to the Closing Date, except as otherwise may be indicated or contemplated therein or set forth
in an amendment or supplement thereto, neither the Company nor the Bank will have: (i) issued any
securities or incurred any liability or obligation, direct or contingent, for borrowed money, except

18
<!-- page 19 -->
borrowings from the same or similar sources indicated in the Prospectus in the ordinary course of
its business, or (ii) entered into any transaction which is material in light of the business and
properties of the Company and the Bank, taken as a whole.

(dd) The Company shall use its best efforts to ensure that the Foundation submits, within the time
frames required by applicable law, a request to the Internal Revenue Service to be recognized as a
tax-exempt organization under Section 501(c)(3) of the Internal Revenue Code, as amended. The
Company will not take any action which will result in the possible loss of the Foundation's tax
exempt status.

(ee) Until the Closing Date, the Company and the Bank will conduct their businesses in compliance in
all material respects with all applicable federal and state laws, rules, regulations, decisions,
directives and orders, including all decisions, directives and orders of the Commission, the FDIC
and the OTS.

(ff) The Company and the Bank shall comply in all material respects with any and all terms,
conditions, requirements and provisions with respect to the Offering imposed by the OTS, the
Conversion Regulations, the Commission, the 1933 Act and the 1933 Act Regulations, the 1934 Act and
the 1934 Act Regulations to be complied with subsequent to the Closing Date. The Company will comply
with all provisions of all undertakings contained in the Registration Statement.

(gg) The facts and representations provided to Kilpatrick Stockton LLP by the Bank and the Company
and upon which Kilpatrick Stockton LLP will base its opinion under Section 8(c)(1) are and will be
truthful, accurate and complete.

(hh) The Company and the Bank will not distribute any offering material in connection with the
Offering except for the Prospectus and any supplemental sales material that has been filed with the
Registration Statement and the Form AC and authorized for use by the Commission and the OTS. The
information contained in any supplemental sales material (in addition to the supplemental sales
material filed as an exhibit to the Registration Statement and the Form AC) shall not conflict with
the information contained in the Registration Statement and the Prospectus.

(ii) The Company will comply with all applicable provisions of the Sarbanes-Oxley Act of 2002 and
all applicable rules, regulations, guidelines and interpretations promulgated thereunder by the
Commission.

Section 7. Payment of Expenses. Whether or not the Conversion is completed or the sale of the Shares
by the Company is consummated, the Company and the Bank jointly and severally agree to pay or
reimburse the Agent for: (a) all filing fees in connection with all filings related to the
Conversion with the FINRA; (b) any stock issue or transfer taxes which may be payable with respect
to the sale of the Shares; (c) subject to Section 2(d), all expenses of the Conversion, including
but not limited to the Agent's attorneys' fees and expenses, blue sky fees, transfer agent,
registrar and other agent charges, fees relating to auditing and accounting or other advisors and
costs of printing all documents necessary in connection with the Offering. In the event the Company
is unable to sell the minimum number of shares necessary to complete the Conversion or the
Conversion is terminated or otherwise abandoned, the Company and the Bank shall promptly reimburse
the Agent in accordance with Section 2(d) hereof.

In the event that the Agent incurs any expenses on behalf of the Company or the Bank that are
customarily borne by the issuer, the Company and the Bank will pay or reimburse the Agent for such
expenses regardless of whether the Offering is successfully completed, and such reimbursements will
not be included in the expense limitations set forth in Section 2(d) hereof. The Company and the
Bank acknowledge, however, that such limitations may be increased by the mutual consent of the Bank
and Agent in the event of delay in the Offering requiring the Agent to utilize a Syndicated
Community Offering, a delay as a result of circumstances requiring material additional work by Agent
or its counsel

19
<!-- page 20 -->
or an update of the financial information in tabular form contained in the Prospectus for a period
later than [December 31, 2009] . Not later than two days prior to the Closing Date, the Agent will
provide the Company with an accounting of all reimbursable expenses to be paid at the Closing in
next day funds. In the event the Bank determines to abandon or terminate the Conversion prior to
Closing, payment of such expenses shall be made in next day funds on the date such determination is
made.

Section 8. Conditions to the Agent's Obligations. The obligations of the Agent hereunder, as to the
Shares to be delivered at the Closing Date, are subject, to the extent not waived in writing by the
Agent, to the condition that all representations and warranties of the Company and the Bank, herein
are, at and as of the commencement of the Offering and at and as of the Closing Date, true and
correct in all material respects, the condition that the Company and the Bank shall have performed
all of its obligations hereunder to be performed on or before such dates, and to the following
further conditions:

(a) At the Closing Date, the Company and the Bank shall have conducted the Conversion in all
material respects in accordance with the Plan, the Conversion Regulations, the applicable laws of
Tennessee, and all other applicable laws, regulations, decisions and orders, including all terms,
conditions, requirements and provisions precedent to the Conversion imposed upon them by the OTS.

(b) The Registration Statement shall have been declared effective by the Commission and the Form AC
and Holding Company Application shall have been approved by the OTS not later than 5:30 p.m. on the
date of this Agreement, or with the Agent's consent at a later time and date; and at the Closing
Date, no stop order suspending the effectiveness of the Registration Statement shall have been
issued under the 1933 Act or proceedings therefore initiated or threatened by the Commission or any
state authority, and no order or other action suspending the authorization of the Prospectus or the
consummation of the Conversion shall have been issued or proceedings therefore initiated or, to the
Company's or the Bank's knowledge, threatened by the Commission, the OTS, the FDIC or any other
state authority.

(c) At the Closing Date, the Agent shall have received:

(1) The favorable opinion, dated as of the Closing Date and addressed to the Agent and for its
benefit, of Kilpatrick Stockton LLP special counsel for the Company and the Bank in form and
substance to the effect that:

(i) The Company has been duly incorporated and is validly existing as a corporation under the laws
of the State of Tennessee.

(ii) The Company has corporate power and authority to own, lease and operate its properties and to
conduct its business as described in the Form AC, the Registration Statement, the Prospectus and the
General Disclosure Package.

(iii) The Bank is a validly existing federally-chartered savings bank in mutual form and immediately
following the completion of the Conversion will be a validly-existing federally-chartered savings
bank in stock form and, in both instances duly authorized to conduct its business and own its
property as described in the Registration Statement and the Prospectus. All of the outstanding
capital stock of the Bank, upon completion of the Conversion, will be duly authorized and, upon
payment therefor, validly issued, fully-paid and non-assessable and will be owned by the Company,
free and clear of any liens, encumbrances, claims or other restrictions.

(iv) The Bank is a member of the FHLB-Cincinnati. The deposit accounts of the Bank are insured by
the FDIC up to the maximum amount allowed under law and no proceedings for the termination or
revocation of such insurance are pending or threatened. The description of the liquidation account
as set forth in the Prospectus under the caption "The Conversion and Stock Offering — Effects of

20
<!-- page 21 -->
Conversion to Stock Form — Liquidation Account," to the extent that such information constitutes
matters of law and legal conclusions, has been reviewed by such counsel and is accurately described
in all material respects.

(v) The only subsidiaries of the Bank are Southland Finance, Inc., Ti-Serv, Inc. and Valley Title
Services, LLC. The operations of the Subsidiaries are not material to financial condition, results
of operations, capital, properties or business prospects of the Company and the Bank, taken as a
whole. The Subsidiaries have been duly organized and are validly existing as corporations in good
standing under the laws of Tennessee, have full corporate power and authority to own, lease and
operate their properties and to conduct their respective businesses as described in the Registration
Statement and Prospectus, and are duly qualified as foreign corporations to transact business and
are in good standing in each jurisdiction in which such qualification is required, whether by reason
of the ownership or leasing of property or the conduct of business, except where the failure to so
qualify would not have a Material Adverse Effect. Each Subsidiary has obtained all licenses, permits
and other governmental authorizations required for the conduct of their businesses and all such
licenses, permits and other governmental authorizations are in full force and effect and the
Subsidiaries are in all material respects complying therewith; the activities of the Subsidiaries
are permitted to subsidiaries of a federally chartered savings bank by the rules, regulations and
practices of the Federal Deposit Insurance Corporation ("FDIC") and the OTS in the case of the Bank;
all of the issued and outstanding capital stock of each Subsidiary has been duly authorized and
validly issued, is fully paid and non-assessable and is owned by the Bank, free and clear of any
security interest, mortgage, pledge, lien, encumbrance or legal or equitable claim; and there are no
warrants, options or rights of any kind to acquire shares of capital stock of any Subsidiary.

(vi) The Foundation has been duly organized and is validly existing as a non-stock corporation in
good standing under the laws of the State of Delaware with corporate power and authority to conduct
its business as described in the Prospectus; to the knowledge of Company and the Agent, all
approvals required to establish the Foundation and to contribute the Foundation Shares thereto have
been obtained as described in the Prospectus; except as specifically disclosed in the Prospectus and
the Proxy Statement, there are no agreements and/or understandings, written or oral or otherwise,
between any of the Company, the Agent and the Foundation with respect to the control, directly or
indirectly, over the voting and the acquisition or disposition of the shares of Common Stock to be
contributed by the Company to the Foundation; the Foundation Shares to be issued to the Foundation
in accordance with the Plan and as described in the Prospectus will have been duly and validly
authorized for issuance and, when issued and contributed by the Company pursuant to the Plan, will
be duly authorized and validly issued and fully paid and non-assessable. Upon issuance of the
Foundation Shares, good title to the Foundation Shares will be transferred from the Company to the
Foundation, subject to such claims as may be asserted against the Foundation by third-party
claimants.

(vii) The authorized equity capital of the Company consists of shares of common stock and shares of
preferred stock. Immediately following the consummation of the Offering and the issuance of the
Foundation Shares to the Foundation, the authorized, issued and outstanding Common Shares of the
Company will be within the range set forth in the Prospectus under the caption "Capitalization," and
no shares of capital stock of the Company have been issued prior to the Closing Date; at the time of
the Offering, the Common Shares subscribed for pursuant to the Conversion will have been duly and
validly authorized for issuance, and when issued and delivered by the Company pursuant to the Plan
against payment of the consideration calculated as set forth in the Plan and Prospectus, will be
duly and validly issued and fully paid and non-assessable, except for shares purchased by the ESOP
with funds borrowed from the Company and shares issued and contributed to the Foundation by the
Company to the extent payment therefor in cash has not been received by the Company; except to the
extent that subscription rights and priorities pursuant thereto exist pursuant to the Plan, the
issuance of the Shares is not subject to preemptive rights (other than subscription rights as
provided in the Plan) and the terms and provisions of the Shares conform in all material respects to
the description thereof contained in the

21
<!-- page 22 -->
Prospectus. The Shares will not, when issued, be subject to any liens, charges, encumbrances or
other claims created by the Company.

(viii) The Company and the Bank have full corporate power and authority to enter into this Agreement
and to consummate the transactions contemplated thereby and by the Plan. The execution and delivery
of this Agreement and the consummation of the Offering, including the establishment of the
Foundation and the issuance of shares to the Foundation, have been duly and validly authorized by
all necessary action on the part of the Company and the Bank; and this Agreement is a valid and
binding obligation of the Company and the Bank, enforceable against the Company and the Bank, in
accordance with its terms, except as the enforceability thereof may be limited by (i) bankruptcy,
insolvency, reorganization, moratorium, conservatorship, receivership or other similar laws now or
hereafter in effect relating to or affecting the enforcement of creditors' rights generally or the
rights of creditors of federally chartered savings institutions or holding companies as applicable,
(ii) general equitable principles, (iii) laws relating to the safety and soundness of insured
depository institutions, and (iv) applicable law or public policy with respect to the
indemnification and/or contribution provisions contained herein and except that no opinion need be
expressed as to the effect or availability of equitable remedies or injunctive relief (regardless of
whether such enforceability is considered in a proceeding in equity or at law).

(ix) The Form AC and the Holding Company Application have been approved by the OTS, the Prospectus
has been authorized for use by the OTS, and the acquisition by the Company of all of the issued and
outstanding capital stock of the Bank has been approved by the OTS and no action has been taken, and
none is pending or threatened, to revoke any such authorization or approval.

(x) To such counsel's knowledge, the OTS's approval or non-objection of the Plan remains in full
force and effect; each of the Form AC, the Holding Company Application, and Plan comply in all
material respects with the regulations of the OTS (other than the financial statements, notes to
financial statements, stock valuation information and other financial, tabular and statistical data
included therein, as to which no opinion need be rendered). Such counsel has been advised by the OTS
staff and Commission staff that no order has been issued by any other state authority, to prevent
the Conversion or the offer, sale or issuance of the Shares, or to suspend the Offering or the use
of the Prospectus, and no action for such purposes has been instituted or, to the knowledge of such
counsel, threatened by the OTS, the Commission or any other state authority; and, to the knowledge
of such counsel, no person has sought to obtain regulatory or judicial review of the final action of
the OTS approving the Plan, the Form AC, the Holding Company Application or the Prospectus or to
otherwise prevent the Conversion or the offer, sale or issuance of the Shares.

(xi) The Plan has been duly adopted by the required vote of the directors of the Company and the
Bank and by the required vote of the Bank's members.

(xii) Subject to the satisfaction of the conditions to the OTS's approval of the Conversion and the
Holding Company Application, no further approval, registration, authorization, consent or other
order of any federal regulatory agency is required in connection with the execution and delivery of
this Agreement, the consummation of the Conversion and the issuance of the Shares, including the
issuance of shares to the Foundation, except as may be required under the securities or blue sky
laws of various jurisdictions (as to which no opinion need be rendered) and except as may be
required under the rules and regulations of the FINRA (as to which no opinion need be rendered).

(xiii) The Registration Statement is effective under the 1933 Act; and any required filing of the
Prospectus and any Permitted Free Writing Prospectus pursuant to Rule 424(b) or Rule 433 has been
made within the time period required by Rule 424(b) or Rule 433; and no stop order suspending the
effectiveness has been issued under the 1933 Act or proceedings therefor initiated or, to such
counsel's Actual Knowledge, threatened by the Commission.

22
<!-- page 23 -->
(xiv) At the time the Form AC, including the Prospectus contained therein, was approved by the OTS,
the Form AC, including the Prospectus contained therein, complied as to form in all material
respects with the requirements of the Conversion Regulations except as waived or otherwise approved
by the OTS (other than the financial statements, the notes thereto, and other tabular, financial,
statistical and appraisal data included therein, as to which no opinion need be rendered).

(xv) At the time the Holding Company Application was approved by the OTS, the Holding Company
Application complied as to from in all material respects with the requirements and the rules and
regulations of the OTS (except as waived or otherwise approved by the OTS, and other than the
financial statement, the notes thereto, and other tabular, financial, statistical and appraisal data
included therein, as to which no opinion need be rendered).

(xvi) At the time that the Registration Statement became effective, (i) the Registration Statement
(as amended or supplemented, if so amended or supplemented) (other than the financial statements,
the notes thereto, and other tabular, financial, statistical and appraisal data included therein, as
to which no opinion need be rendered), complied as to form in all material respects with the
requirements of the 1933 Act and the 1933 Act Regulations, and (ii) the Prospectus (other than the
financial statements, the notes thereto, and other tabular, financial, statistical and appraisal
data included therein, as to which no opinion need be rendered) complied as to form in all material
respects with the requirements of the 1933 Act and the 1933 Act Regulations.

(xvii) The terms and provisions of the shares of common stock of the Company conform, in all
material respects, to the description thereof contained in the Registration Statement, the General
Disclosure Package and Prospectus, and the form of certificate used to evidence the Shares complies
with applicable laws.

(xviii) There are no legal or governmental proceedings pending or threatened (i) asserting the
invalidity of this Agreement, (ii) seeking to prevent the Conversion or the offer, sale or issuance
of the Shares, including the establishment of the Foundation and the issuance of shares thereto, or
(iii) which are required to be disclosed in the Registration Statement and Prospectus, other than
those disclosed therein.

(xix) Neither the Company nor the Bank are required to be registered as an investment company under
the Investment Company Act of 1940.

(xx) Neither the Company nor the Bank is in violation of any directive from the OTS or the FDIC to
make any material change in the method of conducting its respective business.

(xxi) There are no material contracts, indentures, mortgages, loan agreements, notes, leases or
other instruments required to be described or referred to in the Form AC, the Registration
Statement, the General Disclosure Package or the Prospectus or required to be filed as exhibits
thereto other than those described or referred to therein or filed as exhibits thereto in the Form
AC, the Registration Statement, the General Disclosure Package or the Prospectus. The description in
the Form AC, the Registration Statement, the General Disclosure Package and the Prospectus of such
documents and exhibits is accurate in all material respects and fairly presents the information
required to be shown.

(xxii) Except as waived or otherwise approved by the OTS, the Plan complies in all material respects
with all applicable federal law, rules, regulations, decisions and orders including, but not limited
to, the Conversion Regulations; the Conversion, including the establishment of the Foundation and
the issuance of shares thereto, has been effected by the Company's and the Bank in all material
respects in accordance with the Conversion Regulations and the OTS approvals issued thereunder; no
order has been issued by the OTS, the Commission, the FDIC, or any state authority to suspend the
Offering or the use of the Prospectus, and no action for such purposes has been instituted or
threatened by the OTS, the Commission, the FDIC, or any other state authority and, to such counsel's
Actual

23
<!-- page 24 -->
Knowledge, no person has sought to obtain regulatory or judicial review of the final action of the
OTS approving the Plan, the Form AC, the Holding Company Application or the Prospectus.

(xxiii) The Company, and the Bank have obtained all licenses, permits and other governmental
authorizations currently required for the conduct of their businesses as described in the
Registration Statement, and all such licenses, permits and other governmental authorizations are in
full force and effect, and the Company and the Bank are in all material respects complying
therewith.

(xxiv) Neither the Company nor the Bank is in violation of its Charter and Bylaws or in default or
violation of any obligation, agreement, covenant or condition contained in any contract, indenture,
mortgage, loan agreement, note, lease or other instrument to which it is a party or by which it or
its property may be bound, except for such defaults or violations which would not have a material
adverse impact on the financial condition or results of operations of the Company and the Bank on a
consolidated basis; the execution and delivery of this Agreement, the incurrence of the obligations
herein set forth and the consummation of the transactions contemplated herein will not, in any
material respect, conflict with or constitute a breach of, or default under, or result in the
creation or imposition of any lien, charge or encumbrance upon any property or assets of the Company
or the Bank pursuant to any material contract, indenture, mortgage, loan agreement, note, lease or
other instrument to which the Company or the Bank is a party or by which any of them may be bound,
or to which any of the property or assets of the Company or the Bank are subject; and such action
will not result in any violation of the provisions of the Charter or Bylaws of the Company or the
Bank, or result, in any material respect, in any violation of any applicable federal or state law,
act, regulation (except that no opinion with respect to the securities and blue sky laws of various
jurisdictions or the rules or regulations of the FINRA need be rendered) or order or court order,
writ, injunction or decree.

(xxv) The Company's Charter and Bylaws comply in all material respects with the laws of the State of
Tennessee. The Bank's Charter and Bylaws each comply in all material respects with the laws of the
United States of America.

(xxvi) The information in the Prospectus under the captions "Regulation and Supervision," "Federal
and State Taxation," "The Conversion and Stock Offering," "Restrictions on the Acquisition of Athens
Bancshares Corporation and Athens Federal Community Bank," "Description of Athens Bancshares
Corporation Capital Stock" and "Athens Federal Foundation," to the extent that such information
constitutes matters of law, summaries of legal matters, documents or proceedings, or legal
conclusions, has been reviewed by such counsel and is accurate in all material respects. The
description of the Offering process in the Prospectus under the caption "The Conversion and Stock
Offering" to the extent that such information constitutes matters of law, summaries of legal
matters, documents or proceedings, or legal conclusions, has been reviewed by such counsel and
fairly describes such process in all material respects. The descriptions in the Prospectus of
statutes or regulations are accurate summaries and fairly present, in all material respects, the
information required to be shown. The information under the caption "The Conversion and Stock
Offering — Material Income Tax Consequences" has been reviewed by such counsel and fairly describes
the federal and state tax opinions rendered by them and Hazlett, Lewis & Bieter, PLLC, respectively,
to the Company and the Bank with respect to such matters.

In addition, such counsel shall state that during the preparation of the Form AC, the Holding
Company Application, the Registration Statement, the Prospectus and the General Disclosure Package,
they participated in conferences with certain officers of, the independent public and internal
accountants for, and other representatives of, the Company and the Bank, at which conferences the
contents of the Form AC, the Holding Company Application, the Registration Statement, the Prospectus
and the General Disclosure Package and related matters were discussed and, while such counsel have
not confirmed the accuracy or completeness of or otherwise verified the information contained in the
Form AC, the Holding Company Application, the Registration Statement or the Prospectus or the
General Disclosure Package and do not assume any responsibility for such information, based upon
such conferences and a review of

24
<!-- page 25 -->
documents deemed relevant for the purpose of rendering their opinion (relying as to materiality as
to factual matters on certificates of officers and other factual representations by the Company),
nothing has come to their attention that would lead them to believe that the Form AC, the Holding
Company Application, the Registration Statement, the Prospectus, the General Disclosure Package or
any amendment or supplement thereto as of the Applicable Time (other than the financial statements,
the notes thereto, and other tabular, financial, statistical and appraisal data included therein as
to which no view need be rendered) contained an untrue statement of a material fact or omitted to
state a material fact required to be stated therein or necessary to make the statements therein, in
light of the circumstances under which they were made, not misleading.

In giving such opinion, such counsel may rely as to all matters of fact on certificates of officers
or directors of the Company and the Bank and certificates of public officials. Such counsel's
opinion shall be limited to matters governed by federal laws and by the laws of Tennessee and with
respect to enforceablity, New York law, and may add other qualifications and explanations on the
basis of this opinion as may be reasonably acceptable to the Agent.

(d) A Blue Sky Memorandum from Kilpatrick Stockton LLP relating to the Offering, including Agent's
participation therein, and should be furnished to the Agent with a copy thereof addressed to Agent
or upon which Kilpatrick Stockton LLP shall state the Agent may rely. The Blue Sky Memorandum will
relate to the necessity of obtaining or confirming exemptions, qualifications or the registration of
the Shares under applicable state securities law.

(e) At the Closing Date, the Agent shall receive a certificate of the Chief Executive Officer and
the Chief Financial Officer of the Company in form and substance reasonably satisfactory to the
Agent's Counsel, dated as of such Closing Date, to the effect that: (i) they have carefully examined
the Prospectus and, in their opinion, at the time the Prospectus became authorized for final use,
the Prospectus did not contain any untrue statement of a material fact or omit to state a material
fact necessary in order to make the statements therein, in light of the circumstances under which
they were made, not misleading; (ii) since the date the Prospectus became authorized for final use,
no event has occurred which should have been set forth in an amendment or supplement to the
Prospectus which has not been so set forth, including specifically, but without limitation, any
material adverse change in the condition, financial or otherwise, or in the earnings, capital,
properties or business of the Company or the Bank and the conditions set forth in this Section 8
have been satisfied; (iii) since the respective dates as of which information is given in the
Registration Statement, the General Disclosure Package and the Prospectus, there has been no
material adverse change in the condition, financial or otherwise, or in the earnings, capital,
properties or business of the Company or the Bank independently, or of the Company and the Bank
considered as one enterprise, whether or not arising in the ordinary course of business; (iv) the
representations and warranties in Section 4 are true and correct with the same force and effect as
though expressly made at and as of the Closing Date; (v) the Company has complied in all material
respects with all agreements and satisfied all conditions on their part to be performed or satisfied
at or prior to the Closing Date and will comply in all material respects with all obligations to be
satisfied by them after the Closing Date; (vi) no stop order suspending the effectiveness of the
Registration Statement has been initiated or, to the best knowledge of the Company or the Bank,
threatened by the Commission or any state authority; (vii) no order suspending the Conversion, the
Offering or the effectiveness of the Prospectus has been issued and no proceedings for that purpose
are pending or, to the best knowledge of the Company or the Bank, threatened by the OTS, the
Commission, the FDIC, or any state authority; and (viii) to the best knowledge of the Company or the
Bank, no person has sought to obtain review of the final action of the OTS approving the Conversion.

(f) Neither the Company or the Bank shall have sustained, since the date of the latest financial
statements included in the Registration Statement, the General Disclosure Package and Prospectus,
any material loss or interference with its business from fire, explosion, flood or other calamity,
whether or not covered by insurance, or from any labor dispute or court or governmental action,
order or decree,

25
<!-- page 26 -->
otherwise than as set forth in the Registration Statement and the Prospectus, and since the
respective dates as of which information is given in the Registration Statement and the Prospectus,
there shall not have been any Material Adverse Effect on the financial condition, results of
operations, or business of the Company or the Bank that is in the Agent's reasonable judgment
sufficiently material and adverse as to make it impracticable or inadvisable to proceed with the
Offering or the delivery of the Shares on the terms and in the manner contemplated in the
Prospectus.

(g) Prior to and at the Closing Date: (i) in the reasonable opinion of the Agent, there shall have
been no material adverse change in the financial condition, results of operations or business of the
Company and the Bank considered as one enterprise, from that as of the latest dates as of which such
condition is set forth in the Prospectus, other than transactions referred to or contemplated
therein; (ii) neither the Company nor the Bank shall have received from the OTS or the FDIC any
direction (oral or written) to make any material change in the method of conducting their business
with which it has not complied (which direction, if any, shall have been disclosed to the Agent) or
which materially and adversely would affect the financial condition, results of operations or
business of the Company and the Bank taken as a whole; (iii) neither the Company or the Bank shall
have been in default (nor shall an event have occurred which, with notice or lapse of time or both,
would constitute a default) under any provision of any agreement or instrument relating to any
outstanding indebtedness; (iv) no action, suit or proceeding, at law or in equity or before or by
any federal or state commission, board or other administrative agency, not disclosed in the
Prospectus, shall be pending or, to the knowledge of the Company or the Bank, threatened against the
Company or the Bank or affecting any of their properties wherein an unfavorable decision, ruling or
finding would materially and adversely affect the financial condition, results of operations or
business of the Company and the Bank taken as a whole; and (v) the Shares shall have been qualified
or registered for offering and sale or exempted therefrom under the securities or blue sky laws of
the jurisdictions as the Agent shall have reasonably requested and as agreed to by the Company and
the Bank.

(h) Concurrently with the execution of this Agreement, the Agent shall receive a letter from
Hazlett, Lewis & Bieter, PLLC, dated as of the date hereof and addressed to the Agent: (i)
confirming that Hazlett, Lewis & Bieter, PLLC is a firm of independent registered public accountants
within the applicable rules of the Public Company Accounting Oversight Board (United States) and
stating in effect that in its opinion the consolidated financial statements and related notes of the
Company as of December 31, 2008, and for each of the years in the three-year period ended December
31, 2008, and covered by their opinion included therein, and any other more recent unaudited
financial statements included in the Prospectus comply as to form in all material respects with the
applicable accounting requirements and related published rules and regulations of the OTS and the
1933 Act; (ii) stating in effect that, on the basis of certain agreed upon procedures (but not an
audit in accordance with standards of the Public Company Accounting Oversight Board (United States))
consisting of a reading of the latest available consolidated financial statements of the Company
prepared by the Company, a reading of the minutes of the meetings of the Board of Directors,
Executive Committee and Audit Committee of the Company and the Bank and consultations with officers
of the Company and the Bank responsible for financial and accounting matters, nothing came to their
attention which caused them to believe that:

(A) audited consolidated financial statements and any unaudited interim financial statements
included in the Prospectus are not in conformity with the 1933 Act, applicable accounting
requirements of the OTS and accounting principles generally accepted in the United States of America
applied on a basis substantially consistent with that of the audited consolidated financial
statements included in the Prospectus; or

(B) during the period from the date of the latest financial statements included in the Prospectus to
a specified date not more than three business days prior to the date of the Prospectus, except as
has been described in the Prospectus, there was any increase in borrowings of the Company, other
than normal deposit fluctuations for the Bank; or (C) there was any decrease in the net assets of
the Company

26
<!-- page 27 -->
at the date of such letter as compared with amounts shown in the latest balance sheet included in
the Prospectus; and (iii) stating that, in addition to the audit referred to in their opinion
included in the Prospectus and the performance of the procedures referred to in clause (ii) of this
subsection (h), they have compared with the general accounting records of the Company, which are
subject to the internal controls of the Company, the accounting system and other data prepared by
the Company, directly from such accounting records, to the extent specified in such letter, such
amounts and/or percentages set forth in the Prospectus as the Agent may reasonably request; and they
have found such amounts and percentages to be in agreement therewith (subject to rounding).

(i) At the Closing Date, the Agent shall receive a letter dated the Closing Date, addressed to the
Agent, confirming the statements made by Hazlett, Lewis & Bieter, PLLC in the letter delivered by it
pursuant to subsection (g) of this Section 8, the "specified date" referred to in clause (i) of
subsection (h) to be a date specified in the letter required by this subsection (h) which for
purposes of such letter shall not be more than three business days prior to the Closing Date.

(j) At the Closing Date, the Company shall receive a letter from Keller & Company, Inc., dated the
Closing Date (i) confirming that said firm is independent of the Company and the Bank and is
experienced and expert in the area of corporate appraisals within the meaning of Title 12 of the
Code of Federal Regulations, Section 563b.200(b), (ii) stating in effect that the Appraisal prepared
by such firm complies in all material respects with the applicable requirements of Title 12 of the
Code of Federal Regulations, and (iii) further stating that its opinion of the aggregate pro forma
market value of the Company including the Bank, as most recently updated, remains in effect.

(k) At or prior to the Closing Date, the Agent shall receive: (i) a copy of the letters from the OTS
approving the Form AC, the Holding Company Application and authorizing the use of the Prospectus and
the establishment of the Foundation, including the issuance of shares thereto; (ii) a copy of the
orders from the Commission declaring the Registration Statement and the Exchange Act Registration
Statement effective; (iii) a certificate from the OTS evidencing the valid existence of the Company
and the Bank; (iv) a certificate from the FDIC evidencing the Bank's insurance of accounts; (v) a
certificate from the FHLB-Cincinnati evidencing the Bank's membership therein; and (vi) a certified
copy of the Bank's Charter and Bylaws.

(l) Subsequent to the date hereof, there shall not have occurred any of the following; (i) a
suspension or limitation in trading in securities generally on the New York Stock Exchange (the
"NYSE") or in the over-the-counter market, or quotations halted generally on The Nasdaq Stock
Market, or minimum or maximum prices for trading have been fixed, or maximum ranges for prices for
securities have been required by either of such exchanges or the Nasdaq Stock Market or by order of
the Commission or any other governmental authority; (ii) a general moratorium on the operations of
commercial banks, or federal savings and loan associations or a general moratorium on the withdrawal
of deposits from commercial banks or federal savings and loan associations declared by federal or
state authorities; (iii) the engagement by the United States in hostilities which have resulted in
the declaration, on or after the date hereof, of a national emergency or war; or (iv) a material
decline in the price of equity or debt securities if the effect of such a declaration or decline, in
the Agent's reasonable judgment, makes it impracticable or inadvisable to proceed with the Offering
or the delivery of the Shares on the terms and in the manner contemplated in the Registration
Statement and the Prospectus.

(m) At or prior to the Closing Date, counsel to the Agent shall have been furnished with such
documents and opinions as they may reasonably require for the purpose of enabling them to pass upon
the sale of the Shares as herein contemplated and related proceedings or in order to evidence the
occurrence or completeness of any of the representations or warranties, or the fulfillment of any of
the conditions, herein contained; and all proceedings taken by the Company and the Bank in
connection with the sale of the Shares as herein contemplated shall be satisfactory in form and
substance to the Agent and its counsel.

27
<!-- page 28 -->
(n) All such opinions, certificates, letters and documents will be in compliance with the provisions
hereof only if they are reasonably satisfactory in form and substance to the Agent and to counsel
for the Agent. Any certificate signed by an officer of the Company or the Bank and delivered to the
Agent or to counsel for the Agent shall be deemed a representation and warranty by the Company or
the Bank, as the case may be, to the Agent as to the statements made therein.

Section 9. Indemnification.

(a) The Company and the Bank jointly and severally agree to indemnify and hold harmless the Agent,
its officers and directors, employees and agents, and each person, if any, who controls the Agent
within the meaning of Section 15 of the 1933 Act or Section 20(a) of the 1934 Act, against any and
all loss, liability, claim, damage or expense whatsoever (including, but not limited to, settlement
expenses), joint or several, that the Agent or any of them may suffer or to which the Agent and any
such persons may become subject under all applicable federal or state laws or otherwise, and to
promptly reimburse the Agent and any such persons upon written demand for any expense (including all
fees and disbursements of counsel) incurred by the Agent or any of them in connection with
investigating, preparing or defending any actions, proceedings or claims (whether commenced or
threatened) to the extent such losses, claims, damages, liabilities or actions: (i) arise out of or
are based upon any untrue statement or alleged untrue statement of a material fact contained in the
Registration Statement (or any amendment or supplement thereto), the General Disclosure Package, any
Issuer-Represented Limited-Use Free Writing Prospectus, preliminary or final Prospectus (or any
amendment or supplement thereto), the Form AC (or any amendment or supplement thereto), the Holding
Company Application (or any amendment or supplement thereto) or any instrument or document executed
by the Company or the Bank or based upon written information supplied by the Company filed in any
state or jurisdiction to register or qualify any or all of the Shares or to claim an exemption
therefrom or provided to any state or jurisdiction to exempt the Company or the Bank as a
broker-dealer or its officers, directors and employees as broker-dealers or agents, under the
securities laws thereof (collectively, the "Blue Sky Application"), or any document, advertisement,
oral statement or communication ("Sales Information") prepared, made or executed by or on behalf of
the Company or the Bank with its consent and based upon written or oral information furnished by or
on behalf of the Company or the Bank, whether or not filed in any jurisdiction, in order to qualify
or register the Shares or to claim an exemption therefrom under the securities laws thereof; (ii)
arise out of or are based upon the omission or alleged omission to state in any of the foregoing
documents or information a material fact required to be stated therein or necessary to make the
statements therein, in light of the circumstances under which they were made, not misleading; or
(iii) arise from any theory of liability whatsoever relating to or arising from or based upon the
Registration Statement (or any amendment or supplement thereto), preliminary or final Prospectus (or
any amendment or supplement thereto), the General Disclosure Package, any Issuer-Represented
Limited-Use Free Writing Prospectus, the Form AC (or any amendment or supplement thereto) the
Holding Company Application (or any amendment or supplement thereto), any Blue Sky Application or
Sales Information or other documentation distributed in connection with the Conversion; provided,
however, that no indemnification is required under this paragraph (a) to the extent such losses,
claims, damages, liabilities or actions arise out of or are based upon any untrue material statement
or alleged untrue material statement in, or material omission or alleged material omission from, the
Registration Statement (or any amendment or supplement thereto), preliminary or final Prospectus (or
any amendment or supplement thereto), the General Disclosure Package, any Issuer- Represented
Limited-Use Free Writing Prospectus, the Form AC, the Holding Company Application, any Blue Sky
Application or Sales Information made in reliance upon and in conformity with information furnished
in writing to the Company, by the Agent or its counsel regarding the Agent, and provided, that it is
agreed and understood that the only information furnished in writing to the Company, by the Agent
regarding the Agent is set forth in the Prospectus under the caption "The Conversion and Stock
Offering — Marketing Arrangements"; and, provided further, that such indemnification shall be
limited to the extent prohibited by the Commission, the OTS, the FDIC and the Board of Governors of
the Federal Reserve System.

28
<!-- page 29 -->
(b) The Agent agrees to indemnify and hold harmless the Company and the Bank, their directors and
officers and each person, if any, who controls the Company or the Bank within the meaning of Section
15 of the 1933 Act or Section 20(a) of the 1934 Act against any and all loss, liability, claim,
damage or expense whatsoever (including but not limited to settlement expenses), joint or several,
which they, or any of them, may suffer or to which they, or any of them may become subject under all
applicable federal and state laws or otherwise, and to promptly reimburse the Company, the Bank, and
any such persons upon written demand for any expenses (including reasonable fees and disbursements
of counsel) incurred by them, or any of them, in connection with investigating, preparing or
defending any actions, proceedings or claims (whether commenced or threatened) to the extent such
losses, claims, damages, liabilities or actions: (i) arise out of or are based upon any untrue
statement or alleged untrue statement of a material fact contained in the Registration Statement (or
any amendment or supplement thereto), the Form AC (or any amendment or supplement thereto), the
Holding Company Application, the preliminary or final Prospectus (or any amendment or supplement
thereto), any Blue Sky Application or Sales Information, (ii) are based upon the omission or alleged
omission to state in any of the foregoing documents a material fact required to be stated therein or
necessary to make the statements therein, in the light of the circumstances under which they were
made, not misleading, or (iii) arise from any theory of liability whatsoever relating to or arising
from or based upon the Registration Statement (or any amendment or supplement thereto), preliminary
or final Prospectus (or any amendment or supplement thereto), the Form AC (or any amendment or
supplement thereto), the Holding Company Application, or any Blue Sky Application or Sales
Information or other documentation distributed in connection with the Offering; provided, however,
that the Agent's obligations under this Section 9(b) shall exist only if and only to the extent that
such untrue statement or alleged untrue statement was made in, or such material fact or alleged
material fact was omitted from, the Registration Statement (or any amendment or supplement thereto),
the preliminary or final Prospectus (or any amendment or supplement thereto), the Form AC (or any
amendment or supplement thereto), the Holding Company Application, any Blue Sky Application or Sales
Information in reliance upon and in conformity with information furnished in writing to the Company
or the Bank, by the Agent or its counsel regarding the Agent, and provided, that it is agreed and
understood that the only information furnished in writing to the Company or the Bank, by the Agent
regarding the Agent is set forth in the Prospectus under the caption "The Conversion and Stock
Offering — Marketing Arrangements."

(c) Each indemnified party shall give prompt written notice to each indemnifying party of any
action, proceeding, claim (whether commenced or threatened), or suit instituted against it in
respect of which indemnity may be sought hereunder, but failure to so notify an indemnifying party
shall not relieve it from any liability which it may have on account of this Section 9 or otherwise.
An indemnifying party may participate at its own expense in the defense of such action. In addition,
if it so elects within a reasonable time after receipt of such notice, an indemnifying party,
jointly with any other indemnifying parties receiving such notice, may assume defense of such action
with counsel chosen by it and approved by the indemnified parties that are defendants in such
action, unless such indemnified parties reasonably object to such assumption on the ground that
there may be legal defenses available to them that are different from or in addition to those
available to such indemnifying party. If an indemnifying party assumes the defense of such action,
the indemnifying parties shall not be liable for any fees and expenses of counsel for the
indemnified parties incurred thereafter in connection with such action, proceeding or claim, other
than reasonable costs of investigation. In no event shall the indemnifying parties be liable for the
fees and expenses of more than one separate firm of attorneys (and any special counsel that said
firm may retain) for each indemnified party in connection with any one action, proceeding or claim
or separate but similar or related actions, proceedings or claims in the same jurisdiction arising
out of the same general allegations or circumstances.

Section 10. Contribution. In order to provide for just and equitable contribution in circumstances
in which the indemnification provided for in Section 9 is due in accordance with its terms but is
for any reason held by a court to be unavailable from the Company, the Bank or the Agent, the
Company, the Bank and the Agent shall contribute to the aggregate losses, claims, damages and
liabilities

29
<!-- page 30 -->
(including any investigation, legal and other expenses incurred in connection with, and any amount
paid in settlement of, any action, suit or proceeding, but after deducting any contribution received
by the Company, the Bank or the Agent from persons other than the other parties thereto, who may
also be liable for contribution) in such proportion so that the Agent is responsible for that
portion represented by the percentage that the fees paid to the Agent pursuant to Section 2 of this
Agreement (not including expenses) bears to the gross proceeds received by the Company from the sale
of the Shares in the Offering, and the Company and the Bank shall be responsible for the balance.
If, however, the allocation provided above is not permitted by applicable law, then each
indemnifying party shall contribute to such amount paid or payable by such indemnified party in such
proportion as is appropriate to reflect not only such relative fault of the Company and the Bank on
the one hand and the Agent on the other in connection with the statements or omissions which
resulted in such losses, claims, damages or liabilities (or actions, proceedings or claims in
respect thereto), but also the relative benefits received by the Company and the Bank on the one
hand and the Agent on the other from the Offering (before deducting expenses). The relative fault
shall be determined by reference to, among other things, whether the untrue or alleged untrue
statement of a material fact or the omission or alleged omission to state a material fact relates to
information supplied by the Company and the Bank on the one hand or the Agent on the other and the
parties' relative intent, good faith, knowledge, access to information and opportunity to correct or
prevent such statement or omission. The Company, the Bank and the Agent agree that it would not be
just and equitable if contribution pursuant to this Section 10 were determined by pro-rata
allocation or by any other method of allocation which does not take into account the equitable
considerations referred to above in this Section 10. The amount paid or payable by an indemnified
party as a result of the losses, claims, damages or liabilities (or actions, proceedings or claims
in respect thereof) referred to above in this Section 10 shall be deemed to include any legal or
other expenses reasonably incurred by such indemnified party in connection with investigating or
defending any such action, proceeding or claim. It is expressly agreed that the Agent shall not be
liable for any loss, liability, claim, damage or expense or be required to contribute any amount
pursuant to Section 9(b) or this Section 10 which in the aggregate exceeds the amount paid
(excluding reimbursable expenses) to the Agent under this Agreement. It is understood that the above
stated limitation on the Agent's liability is essential to the Agent and that the Agent would not
have entered into this Agreement if such limitation had not been agreed to by the parties to this
Agreement. No person found guilty of any fraudulent misrepresentation (within the meaning of Section
11(f) of the 1933 Act) shall be entitled to contribution from any person who was not found guilty of
such fraudulent misrepresentation. The obligations of the Company, the Bank and the Agent under this
Section 10 and under Section 9 shall be in addition to any liability which the Company and the Agent
may otherwise have. For purposes of this Section 10, each of the Agent's, the Company's or the
Bank's officers and directors and each person, if any, who controls the Agent or the Company or the
Bank within the meaning of the 1933 Act and the 1934 Act shall have the same rights to contribution
as the Agent on the one hand, or, the Company or the Bank on the other hand. Any party entitled to
contribution, promptly after receipt of notice of commencement of any action, suit, claim or
proceeding against such party in respect of which a claim for contribution may be made against
another party under this Section 10, will notify such party from whom contribution may be sought,
but the omission to so notify such party shall not relieve the party from whom contribution may be
sought from any other obligation it may have hereunder or otherwise than under this Section 10.

Section 11. Survival of Agreements, Representations and Indemnities. The respective indemnities of
the Company, the Bank and the Agent, the representations and warranties and other statements of the
Company, the Bank and the Agent set forth in or made pursuant to this Agreement and the provisions
relating to contribution shall remain in full force and effect, regardless of any termination or
cancellation of this Agreement or any investigation made by or on behalf of the Agent, the Company,
the Bank or any controlling person referred to in Section 9 hereof, and shall survive the
termination of this Agreement and the issuance of the Shares, and any successor or assign of the
Agent, the Company and the Bank, and any such controlling person shall be entitled to the benefit of
the respective agreements, indemnities, warranties and representations.

30
<!-- page 31 -->
Section 12. Termination. The Agent may terminate this Agreement by giving the notice indicated below
in this Section 12 at any time after this Agreement becomes effective as follows:

(a) If any domestic or international event or act or occurrence has materially disrupted the United
States securities markets such as to make it, in the Agent's reasonable opinion, impracticable to
proceed with the offering of the Shares; or if trading on the NYSE shall have suspended (except that
this shall not apply to the imposition of NYSE trading collars imposed on program trading); or if
the United States shall have become involved in a war or major hostilities; or if a general banking
moratorium has been declared by a state or federal authority which has a material effect on the
Company on a consolidated basis; or if a moratorium in foreign exchange trading by major
international banks or persons has been declared; or if there shall have been a material adverse
change in the financial condition, results of operations or business of the Bank, or if the Bank
shall have sustained a material or substantial loss by fire, flood, accident, hurricane, earthquake,
theft, sabotage or other calamity or malicious act, whether or not said loss shall have been
insured; or if there shall have been a material adverse change in the financial condition, results
of operations or business of the Bank.

(b) In the event the Company fails to sell the required minimum number of the Shares by the date
when such sales must be completed, in accordance with the provisions of the Plan or as required by
the Conversion Regulations, and applicable law, this Agreement shall terminate upon refund by the
Company to each person who has subscribed for or ordered any of the Shares the full amount which it
may have received from such person, together with interest as provided in the Prospectus, and no
party to this Agreement shall have any obligation to the other hereunder, except as set forth in
Sections 2(a) and (d), 7, 9 and 10 hereof.

(c) If any of the conditions specified in Section 8 shall not have been fulfilled when and as
required by this Agreement, unless waived in writing, or by the Closing Date, this Agreement and all
of the Agent's obligations hereunder may be cancelled by the Agent by notifying the Company of such
cancellation in writing or by telegram at any time at or prior to the Closing Date, and any such
cancellation shall be without liability of any party to any other party except as otherwise provided
in Sections 2(a), 2(d), 7, 9 and 10 hereof.

(d) If the Agent elects to terminate this Agreement as provided in this Section, the Company and the
Bank shall be notified promptly by telephone or telegram, confirmed by letter.

The Company or the Bank may terminate this Agreement in the event the Agent is in material breach of
the representations and warranties or covenants contained in Section 5 and such breach has not been
cured after the Company or the Bank has provided the Agent with notice of such breach.

This Agreement may also be terminated by mutual written consent of the parties hereto.

Section 13. Notices. All communications hereunder, except as herein otherwise specifically provided,
shall be mailed in writing and if sent to the Agent shall be mailed, delivered or telegraphed and
confirmed to Keefe, Bruyette & Woods, Inc., Investment Banking, 10 South Wacker Drive, Suite 3400,
Chicago, Illinois 60606, Attention: Harold T. Hanley, III, Managing Director (with a copy to Silver,
Freedman & Taff, L.L.P, 3299 K Street, N.W., Suite 100, Washington, D.C. 20007, Attn: Martin L.
Meyrowitz, P.C.) and, if sent to the Company or the Bank, shall be mailed, delivered or telegraphed
and confirmed to the Company at 106 Washington Avenue, P.O. Box 869, Athens, Tennessee, 37371-0869,
Attn: Jeff Cunningham, President and Chief Executive Officer (with a copy to Kilpatrick Stockton
LLP, 607 14th Street, N.W., Suite 900, Washington, D.C., 2005, Attn: Victor L. Cangelosi, Esq.).

Section 14. Parties. The Company and the Bank shall be entitled to act and rely on any request,
notice, consent, waiver or agreement purportedly given on behalf of the Agent when the same shall
have been given by the undersigned. The Agent shall be entitled to act and rely on any request,
notice, consent,

31
<!-- page 32 -->
waiver or agreement purportedly given on behalf of the Company or the Bank, when the same shall have
been given by the undersigned or any other officer of the Company or the Bank. This Agreement shall
inure solely to the benefit of, and shall be binding upon, the Agent, the Company, the Bank and
their respective successors and assigns, and no other person shall have or be construed to have any
legal or equitable right, remedy or claim under or in respect of or by virtue of this Agreement or
any provision herein contained. It is understood and agreed that this Agreement is the exclusive
agreement among the parties hereto, and supersedes any prior agreement among the parties and may not
be varied except in writing signed by all the parties.

Section 15. Closing. The closing for the sale of the Shares shall take place on the Closing Date at
such location as mutually agreed upon by the Agent and the Company and the Bank. At the closing, the
Company and the Bank shall deliver to the Agent in next day funds the commissions, fees and expenses
due and owing to the Agent as set forth in Sections 2 and 7 hereof and the opinions and certificates
required hereby and other documents deemed reasonably necessary by the Agent shall be executed and
delivered to effect the sale of the Shares as contemplated hereby and pursuant to the terms of the
Prospectus.

Section 16. Partial Invalidity. In the event that any term, provision or covenant herein or the
application thereof to any circumstance or situation shall be invalid or unenforceable, in whole or
in part, the remainder hereof and the application of said term, provision or covenant to any other
circumstances or situation shall not be affected thereby, and each term, provision or covenant
herein shall be valid and enforceable to the full extent permitted by law.

Section 17. Construction. This Agreement shall be construed in accordance with the laws of the State
of New York without regard to principles of conflicts of law.

Section 18. Counterparts. This Agreement may be executed in separate counterparts, each of which so
executed and delivered shall be an original, but all of which together shall constitute but one and
the same instrument.

Section 19. Entire Agreement. This Agreement, including schedules and exhibits hereto, which are
integral parts hereof and incorporated as though set forth in full, constitutes the entire agreement
between the parties pertaining to the subject matter hereof superseding any and all prior or
contemporaneous oral or prior written agreements, proposals, letters of intent and understandings,
and cannot be modified, changed, waived or terminated except by a writing which expressly states
that it is an amendment, modification or waiver, refers to this Agreement and is signed by the party
to be charged. No course of conduct or dealing shall be construed to modify, amend or otherwise
affect any of the provisions hereof.

Section 20. Waiver of Trial by Jury. Each of the Agent and the Company and the Bank waive all rights
to trial by jury in any action, proceeding, claim or counterclaim (whether based on contract, tort
or otherwise) related to or arising out of this Agreement.

32
<!-- page 33 -->
If the foregoing correctly sets forth the arrangement among the Company, the Bank and the Agent,
please indicate acceptance thereof in the space provided below for that purpose, whereupon this
letter and the Agent's acceptance shall constitute a binding agreement.

Accepted as of the date first above written

33

Very truly yours, ATHENS FEDERAL COMMUNITY BANK ATHENS BANCSHARES CORPORATION By Its Authorized
Representative By Its Authorized Representative:

Jeff Cunningham Jeff Cunningham President and Chief Executive Officer President and Chief Executive
Officer

KEEFE, BRUYETTE & WOODS, INC. By its Authorized Representative

Harold T. Hanley, III, Managing Director Managing Director
