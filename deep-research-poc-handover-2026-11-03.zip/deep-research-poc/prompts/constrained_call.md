## ask
Your recent tool calls were malformed and could not run. Last error: {error}

Reply with ONLY one JSON object and nothing else, choosing ONE tool to call next:
{{"tool": "<tool name>", "args": {{...}}}}

Available tools (argument: type; ? marks optional):
{tool_schemas}
## repair
That was not a valid JSON object. Reply again with ONLY the JSON object, no prose, no code fence:
{{"tool": "<tool name>", "args": {{...}}}}
