<!-- page 1 -->
# Limited Waiver — Tolland Precision Components
| Field | Value |
|---|---|
| Document Type | Waiver |
| Effective Date | 2026-02-10 |
| Parties | Tolland Precision Components Corp.; Northgate Capital Bank |
| Facility ID | FAC-2025-0193 |
| Version | Limited Waiver |

THIS LIMITED WAIVER (this "Waiver") is entered into as of 2026-02-10 among Tolland Precision Components Corp. (the "Borrower"), the Required Lenders and Northgate Capital Bank, as Administrative Agent, under the Credit Agreement dated as of 2025-06-18 (as amended, the "Credit Agreement"; facility FAC-2025-0193).

## Recitals
WHEREAS, the Borrower has advised the Administrative Agent that the Leverage Ratio as of the fiscal quarter ended 2025-12-31 was 3.21 to 1.00, exceeding the maximum of 3.00 to 1.00 permitted under Section 7.1 of the Credit Agreement (the "Specified Default");
WHEREAS, the Borrower has requested that the Required Lenders waive the Specified Default, and the Required Lenders are willing to do so on the terms set forth herein;
<!-- page 2 -->
## Section 1 — Limited Waiver
Subject to Section 2, the Required Lenders hereby waive the Specified Default solely for the fiscal quarter ended 2025-12-31. This Waiver does not amend Section 7.1 of the Credit Agreement, which continues to require a Leverage Ratio not exceeding 3.00 to 1.00 for each subsequent fiscal quarter.
## Section 2 — Conditions
This Waiver is effective upon the Administrative Agent's receipt of (a) counterparts executed by the Borrower and the Required Lenders and (b) a waiver fee of $40,000 for the ratable account of the consenting Lenders.
The Borrower shall deliver to the Administrative Agent, within ten (10) Business Days after the date hereof, a thirteen-week cash flow forecast and shall deliver an updated forecast on the first Business Day of each month thereafter until the Leverage Ratio is in compliance for two consecutive fiscal quarters.
<!-- page 3 -->
## Section 3 — Reservation of Rights; Effect
Except as expressly set forth herein, the Lenders reserve all rights and remedies under the Loan Documents. Nothing herein constitutes a waiver of any other Default or a course of dealing.
Except as expressly waived hereby, the Credit Agreement remains in full force and effect. This Waiver is a Loan Document.
This Waiver shall be governed by the laws of the State of New York. Notices shall be given in the manner set forth in Section 10.1 of the Credit Agreement.
Tolland Precision Components Corp., as Borrower — By: /s/ Authorized Signatory
Northgate Capital Bank, as Administrative Agent — By: /s/ Authorized Signatory
