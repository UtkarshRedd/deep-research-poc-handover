# Which jurisdiction's law governs the Manufacturing Agreement between Electrameccanica V...

*Question:* Which jurisdiction's law governs the Manufacturing Agreement between Electrameccanica Vehicles Corp and Chongqing Zongshen Automobile Industry Co., LTD.?

## Identify governing law clause

Section 10.4 of the Manufacturing Agreement states that the agreement shall be governed by and construed under the laws of Hong Kong without regard to choice of laws principles. [269a8f624fe50e76 p.16] The clause further specifies that all disputes shall be referred to and finally resolved by the Hong Kong International Arbitration Centre under the UNCITRAL Arbitration Rules, with the place of arbitration being Hong Kong. [269a8f624fe50e76 p.16]

## Not established by the evidence

[GAP] No evidence was found for: Establish which jurisdiction's law is specified as governing the agreement based on the identified clause.

## Verification appendix

Claims: 3 · supported: 2 · partially: 0 · dropped: 0 · gaps: 1 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Determine governing jurisdiction

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[269a8f624fe50e76 p.16] |  |
| s1.2 | s1 | keep | 1.00 | e1→[269a8f624fe50e76 p.16] |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [269a8f624fe50e76 p.16 L443-449] keep (1.0): "10.4 Arbitration and Governing Law All disputes arising out of or in connection with this contract, or in respect of any defined legal relationship associated therewith or derived therefrom, shall be referred to and finally resolved by admi…"
