<!-- page 1 -->
# TRANSPORTATION SERVICE AGREEMENT Contract Identification FT18150
| Field | Value |
|---|---|
| Document Type | Transportation Agreement |
| Agreement Date | 2015-12-14 |
| Parties | Great Lakes Gas Transmission Limited Partnership ("Transporter"); ANR PIPELINE COMPANY ("Shipper") |
| Source | CUAD v1 / TcPipelinesLp_20160226_10-K_EX-99.12_9454048_EX-99.12_Transportation Agreement |

QuickLinks -- Click here to rapidly navigate through this document

Exhibit 99.12

TRANSPORTATION SERVICE AGREEMENT Contract Identification FT18150

This Transportation Service Agreement (Agreement) is entered into by Great Lakes Gas Transmission
Limited Partnership (Transporter) and ANR PIPELINE COMPANY (Shipper).

WHEREAS, Shipper has requested Transporter to transport Gas on its behalf and Transporter represents
that it is willing to transport Gas under the terms and conditions of this Agreement.

NOW, THEREFORE, Transporter and Shipper agree that the terms below constitute the transportation
service to be provided and the rights and obligations of Shipper and Transporter.

1. EFFECTIVE DATE: November 01, 2016

2. CONTRACT IDENTIFICATION: FT18150

3. RATE SCHEDULE: FT

4. SHIPPER TYPE: Interstate Pl

5. STATE/PROVINCE OF INCORPORATION: Delaware

6. TERM: November 01, 2014 to October 31, 2017

7. EFFECT ON PREVIOUS CONTRACTS:

This Agreement supersedes, cancels and terminates, as of the effective date stated above, the
following contract(s): Service Agreement dated November 01, 2015 with Contract Identification
FT18150.

8. MAXIMUM DAILY QUANTITY (Dth/Day): 101,300

Please see Appendix A for further detail.

9. RATES:

Unless Shipper and Transporter have agreed to a rate other than the maximum rate, rates shall be
Transporter's maximum rates and charges plus all applicable surcharges in effect from time to time
under the applicable Rate Schedule (as stated above) on file with the Commission unless otherwise
agreed to by the parties in writing. Provisions governing a Rate other than the maximum shall be set
forth in this Paragraph 9 and/or on Appendix B hereto.

10. POINTS OF RECEIPT AND DELIVERY:

The primary receipt and delivery points are set forth on Appendix A.

11. RELEASED CAPACITY:

N/A

12. INCORPORATION OF TARIFF INTO AGREEMENT:

This Agreement shall incorporate and in all respects be subject to the "General Terms and
Conditions" and the applicable Rate Schedule (as stated above) set forth in Transporter's FERC Gas
Tariff, Third Revised Volume No. 1, as may be revised from time to time. Transporter may file and
seek Commission approval under Section 4 of the Natural Gas Act (NGA) at any time and from time to
time to change any rates, charges or provisions set forth in the applicable Rate Schedule (as stated
above) and the "General Terms and Conditions" in Transporter's FERC Gas Tariff, Third Revised Volume
No. 1, and Transporter shall have the right to place such changes in effect in accordance with the
NGA, and this Agreement shall be deemed to include such changes and any such changes

Source: TC PIPELINES LP, 10-K, 2/26/2016
<!-- page 2 -->
which become effective by operation of law and Commission Order, without prejudice to Shipper's
right to protest the same.

13. MISCELLANEOUS:

No waiver by either party to this Agreement of any one or more defaults by the other in the
performance of this Agreement shall operate or be construed as a waiver of any continuing or future
default(s), whether of a like or a different character.

Any controversy between the parties arising under this Agreement and not resolved by the parties
shall be determined in accordance with the laws of the State of Michigan.

14. OTHER PROVISIONS:

It is agreed that no personal liability whatsoever shall attach to, be imposed on or otherwise be
incurred by any Partner, agent, management official or employee of the Transporter or any director,
officer or employee of any of the foregoing, for any obligation of the Transporter arising under
this Agreement or for any claim based on such obligation and that the sole recourse of Shipper under
this Agreement is limited to assets of the Transporter.

Upon termination of this Agreement, Shipper's and Transporter's obligations to each other arising
under this Agreement, prior to the date of termination, remain in effect and are not being
terminated by any provision of this Agreement.

15. NOTICES AND COMMUNICATIONS:

All notices and communications with respect to this Agreement shall be in writing by mail, e-mail,
or fax, or other means as agreed to by the parties, and sent to the addresses stated below or to any
other such address(es) as may be designated in writing by mail, e-mail, or fax, or other means
similarly agreed to:

ADMINISTRATIVE MATTERS Great Lakes Gas Transmission Limited Partnership Commercial Services 700
Louisiana St., Suite 700 Houston, TX 77002-2700

ANR PIPELINE COMPANY 700 Louisiana St., Suite 700 Houston, TX 77002-2700 Attn: AGREED TO BY:

GREAT LAKES GAS TRANSMISSION LIMITED PARTNERSHIP By: Great Lakes Gas Transmission Company

ANR PIPELINE COMPANY

/s/ STEVEN D. JASKOLSKI

Steven D. Jaskolski Director, Commercial Services

/s/ JOSEPH E. POLLARD

Joseph E. Pollard Director, Long Term Marketing

Dated: December 14, 2015 Dated: December 14, 2015

Source: TC PIPELINES LP, 10-K, 2/26/2016

APPENDIX A

Contract Identification FT18150
<!-- page 3 -->
Date: November 01, 2016 Supersedes Appendix Dated: November 01, 2015

Shipper: ANR PIPELINE COMPANY

Maximum Daily Quantity (Dth/Day) per Location:

Begin Date End Date Point(s) of Primary Receipt Point(s) of Primary Delivery MDQ

Maximum Allowable Operating Pressure (MAOP)

11/01/2014 03/31/2015 SOUTH CHESTER 101,300 974 11/01/2014 03/31/2015 DEWARD 101,300 974 04/01/2015
10/31/2015 SOUTH CHESTER 0 974 11/01/2015 03/31/2016 SOUTH CHESTER 101,300 974 11/01/2015 03/31/2016
DEWARD 101,300 974 04/01/2016 10/31/2016 SOUTH CHESTER 0 974 11/01/2016 03/31/2017 SOUTH CHESTER
101,300 974 11/01/2016 03/31/2017 DEWARD 101,300 974 04/01/2017 10/31/2017 SOUTH CHESTER 0 974
11/01/2014 03/31/2015 FARWELL 101,300 974 04/01/2015 10/31/2015 FARWELL 0 974 11/01/2015 03/31/2016
FARWELL 101,300 974 04/01/2016 10/31/2016 FARWELL 0 974 11/01/2016 03/31/2017 FARWELL 101,300 974
04/01/2017 10/31/2017 FARWELL 0 974

Source: TC PIPELINES LP, 10-K, 2/26/2016
<!-- page 4 -->
QuickLinks

Exhibit 99.12

TRANSPORTATION SERVICE AGREEMENT Contract Identification FT18150 APPENDIX A Contract Identification
FT18150

Source: TC PIPELINES LP, 10-K, 2/26/2016
