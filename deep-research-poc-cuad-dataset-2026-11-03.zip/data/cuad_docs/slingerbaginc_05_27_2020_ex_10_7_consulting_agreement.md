<!-- page 1 -->
# CONSULTING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Consulting Agreement |
| SEC Filing Date | 2020-05-27 |
| Parties | Slinger Bag Inc. (the "Company"); Aitan Zacharin ( the "Consultant") |
| Source | CUAD v1 / SLINGERBAGINC_05_27_2020-EX-10.7-CONSULTING AGREEMENT |

Exhibit 10.7 CONSULTING AGREEMENT THIS AGREEMENT made this 30th day of April (the "Effective Date")
between Slinger Bag Inc., a Nevada company (the "Company") and Aitan Zacharin, an individual
residing in Bet Shemesh, Israel (the "Consultant") A. The Company is engaging Consultant as a
consultant in respect of investor relations, corporate structure, public relations and commercial
development. B. The Company and the Consultant wish to formally record the terms and conditions of
such engagement. C. Each of the Company and the Consultant has agreed to the terms and conditions
set forth in this Agreement, as evidenced by their respective execution hereof. NOW THEREFORE THIS
AGREEMENT WITNESSES that, in consideration of the premises and the mutual covenants and agreements
herein contained, the parties hereto covenant and agree as follows: ARTICLE 1 CONTRACT FOR SERVICES
1.1 Engagement of Consultant. The Company hereby agrees to engage the Consultant in accordance with
the terms and provisions hereof. (a) Term. Unless terminated earlier in accordance with the
provisions hereof, this Agreement will commence on the Effective Date and will continue for a period
of three (3) years therefrom (the "Term"). (b) Service. The Consultant agrees to faithfully,
honestly and diligently serve the Company and to devote the time, attention efforts to further the
business interests of the Company and utilize his professional skills and care during the Term. 1.2
Duties : The Consultant's services hereunder will be provided on the basis of the following terms
and conditions: (a) The Consultant will report directly to the chief executive officer and/or other
officers of the Company; (b) The Consultant will be responsible for advising on and facilitating the
Company's investor relations, corporate structure and governance, public relations and commercial
development activities and supervising, liaising and instructing outside service providers, in each
case, subject to any applicable law and to instructions provided by the officers of the Company from
time to time.
<!-- page 2 -->
2 (c) The Consultant will faithfully, honestly and diligently serve the Company and cooperate with
the Company and utilize maximum professional skill and care to ensure that all services rendered
hereunder are to the satisfaction of the Company, acting reasonably, and the Consultant will provide
any other services not specifically mentioned herein, but which by reason of the Consultant's
capability, the Consultant knows or ought to know to be necessary to ensure that the best interests
of the Company are maintained. (d) The Consultant will assume, obey, implement and execute such
duties, directions, responsibilities, procedures, policies and lawful orders as may be determined or
given from time to time by the Company. (e) The Consultant will report the results of his duties
hereunder to the Company as it may request from time to time. Article 2 COMPENSATION 2.1
Remuneration. (a) The Consultant's monthly base consulting fee shall be three thousand two hundred
fifty United States dollars ($3,250 (together with any increases thereto as hereinafter provided,
the "Base Consulting Fee") through 19 August 2020. Commencing on 20 August 2020, Consultant's Base
Consulting Fee shall be increased to $8,500 per calendar month. The Base Consulting Fee shall be
payable in accordance with the Company's normal payroll procedures in effect from time to time. All
subsequent monthly payments of Base Consulting Fee shall be paid within the first five days of the
following calendar month. The Base Consulting Fee may be increased by the Board from time to time
during the Term, but shall be reviewed by the Board at least annually (b) The Company shall also
issue Consultant as soon as reasonably practicable warrants to purchase 1,250,000 shares of common
stock in the form attached hereto as Annex A. The Company agrees to bear all costs and fees to be
charged by the Company's transfer agent in respect of such shares. (c) The Consultant shall be
eligible to participate in benefit plans currently and hereafter maintained by the Company of
general applicability to other consultants of the Company. Subject to the following sentence, the
Consultant will be entitled to receive up to a one-time bonus of 1,500,000 shares of common stock of
the Company promptly after the value of the Company's outstanding stock equals $100 million dollars.
(d) In addition to the foregoing, the Company will grant the Consultant additional compensation in
the form of cash or shares in cases of extraordinary contribution by him to the benefit of the
Company as the Board of Directors of the Company will decide.

3
<!-- page 3 -->
2.2 Incentive Plans. The Consultant will be entitled to participate in any bonus plan or incentive
compensation plans (including, without limitation, equity or option plans) for consultants or
outside service-providers adopted by the Company. The Consultant's bonus payment level will be set
at a minimum of 25% of the annual gross Base Consulting Fee. It is agreed that any such plans will
be retroactive to the Effective Date.

2.3 Expenses. The Consultant will be reimbursed by the Company for all reasonable business expenses
incurred by the Consultant in connection with his duties. This includes, but is not limited to,
payments of expenses incurred when traveling abroad and others. In this connection, the Consultant
will be issued, as soon as practicable, a Company credit card that the Consultant will use to pay
for any and all expenses that pertain to the Company.

ARTICLE 3 CONFIDENTIALITY AND NON-COMPETITION 3.1 Maintenance of Confidential Information. (a) The
Consultant acknowledges that, in the course of performing his obligations hereunder, the Consultant
will, either directly or indirectly, have access to and be entrusted with confidential information
(whether oral, written or by inspection) relating to the Company or its respective affiliates,
associates or customers (the "Confidential Information"). (b) The Consultant acknowledges that the
Company's Confidential Information constitutes a proprietary right, which the Company is entitled to
protect. Accordingly, the Consultant covenants and agrees that, as long as he works for the Company,
the Consultant will keep in strict confidence the Company's Confidential Information and will not,
without prior written consent of the Company, disclose, use or otherwise disseminate the Company's
Confidential Information, directly or indirectly, to any third party. (c) The Consultant agrees
that, upon termination of his services for the Company, he will immediately surrender to the Company
all Company Confidential Information then in his possession or under his control. 3.2 Exceptions.
The general prohibition contained in Section 4.1 against the unauthorized disclosure, use or
dissemination of the Company's Confidential Information will not apply in respect of any Company
Confidential Information that: (a) is available to the public generally; (b) becomes part of the
public domain through no fault of the Consultant; (c) is already in the lawful possession of the
Consultant at the time of receipt of the Company's Confidential Information; or (d) is compelled by
applicable law or regulation to be disclosed, provided that the Consultant gives the Company prompt
written notice of such requirement prior to such disclosure and provides commercially reasonable
assistance at the request and expense of the Company, in obtaining an order protecting the Company's
Confidential Information from public disclosure.
<!-- page 4 -->
4 ARTICLE 4 TERMINATION 4.1 Termination of Engagement. The Consultant's engagement may be terminated
only as follows: (a) Termination by the Company (i) For Cause. The Company may terminate the
Consultant's engagement for Cause. (ii) Without Cause. The Company may terminate Consultant's
engagement at any time by giving Consultant 60 days prior written Notice of the termination. In such
case, 100% of the Consultant's unvested stock and, if applicable, option or warrant compensation of
any nature will vest without any further action required on the part of the Consultant or the
Company and the Company will deliver to the order of the Consultant promptly upon receipt of a
written demand of the Consultant such shares of common stock or options at its sole expense as
become due to Consultant hereunder. The Consultant's right to receive compensation whether in cash
or securities shall survive any termination of this Agreement Without Cause. (b) Termination by the
Consultant (i) For Good Reason. The Consultant may terminate the Consultant's engagement with the
Company for Good Reason. (ii) Without Good Reason. The Consultant may voluntarily terminate the
Consultant's engagement with the Company at any time by giving the Company 120 days prior written
Notice of the termination. (c) Termination Upon Death or Disability (i) Death. The Consultant's
engagement shall terminate upon the Consultant's death. (ii) Disability. The Company may terminate
the Consultant's engagement upon the Consultant's Disability. (d) For the purpose of this Article 3,
"Cause" means: (i) Breach of Agreement. Consultant's material breach of Consultant's obligations of
this Agreement, not cured after 30 days' Notice from the Company.
<!-- page 5 -->
5 (ii) Gross Negligence. Consultant's gross negligence in the performance of Consultant's duties.
(iii) Crimes and Dishonesty. Consultant's conviction of or plea guilty to any crime involving,
dishonesty, fraud or moral turpitude. (iv) In the event of termination of this agreement for Cause,
the Company may terminate the Consultant's engagement after 30 days' Notice. (e) For the purpose of
this Article 5, "Good Reason" means: (i) Breach of Agreement. The Company's material breach of this
Agreement, which breach has not been cured by the Company within 30 days after receipt of written
notice specifying, in reasonable detail, the nature of such breach or failure from Consultant. (ii)
Non Payment. The failure of the Company to pay any amount due to Consultant hereunder, which failure
persists for 30 days after written notice of such failure has been received by the Company. (iii)
Change of Responsibilities/Compensation. Any material reduction in Consultant's title or a material
reduction in Consultant's duties or responsibilities or any material adverse change in Consultant's
Base Consulting Fee or any material adverse change in Consultant's benefits. (f) It is agreed that
in the event of termination of this agreement if the Company decides that the Consultant's services
are not needed during the termination period, the Company will continue to be responsible for paying
cash and equity compensation as defined in Article 2 of this Agreement for the entire termination
period. Neither the Company, nor the Consultant will be entitled to any notice or payment in excess
of that specified in this Article 5. (g) Upon the termination (whether for cause, disability, death,
without cause, or by way of change of control), the Company shall pay to Consultant on the date
required under applicable law: (i) any accrued but unpaid Base Consulting Fee for services rendered
as of the date of termination, (ii) (if applicable) any accrued but unpaid vacation pay, and (iii)
the business expenses reasonably incurred by the Consultant up to the date of termination or
resignation and properly reimbursable, in each case less any applicable deductions or withholdings
required by law. Section 4.2 Termination for Cause, Disability or Death (a) In the event that this
Agreement and the Consultant's engagement with the Company is terminated for Cause, the Company
shall provide the Consultant written notice thereof and Consultant or Consultants surviving next of
kin shall be entitled only to the amounts specified in Section 3.1. plus all vested common shares
and, if applicable options and warrants.
<!-- page 6 -->
6 (b) In the event of the Consultants service terminates by reason of the Consultants disability or
death, the accrued salary may be paid, and options and warrants may be exercised by the by the
Consultant or the Consultant's legal representatives, executors or assigns, as the case may be, for
a period of one (1) year from the date of death or disability. Section 4.3 Termination without Cause
In the event this Agreement and the Consultant's engagement with the Company is terminated by the
Company without Cause (other than for death or Disability or in connection with a change of
control), then in addition to the amounts specified in Section 4.1 and subject to the Consultant's
execution and non-revocation of a separation agreement containing a general release and waiver of
liability against the Company and anyone connected with it in form acceptable to the Company, the
Consultant shall be entitled to receive, and the Company shall pay the Consultant, two (2) years
Base Consulting Fee (less statutory deductions and withholdings) in a single lump sum, paid in full
within 30 days of termination. Further, Consultant shall be entitled to all vested common shares
and, if applicable, options and warrants with vesting continuing for 12 months following termination
as applicable. ARTICLE 5 MUTUAL REPRESENTATIONS 5.1 The Consultant represents and warrants to the
Company that the execution and delivery of this Agreement and the fulfilment of the terms hereof (a)
will not constitute a default under or conflict with any agreement or other instrument to which he
is a party or by which he is bound; and (b) do not require the consent of any person or entity. 5.2
The Company represents and warrants to the Consultant that this Agreement has been duly authorized,
executed and delivered by the Company and that the fulfilment of the terms hereof (a) will not
constitute a default under or conflict with any agreement of other instrument to which it is a party
or by which it is bound; and (b) do not require the consent of any person of entity. 5.3 Each party
hereto warrants and represents to the other that this Agreement constitutes the valid and binding
obligation of such party enforceable against such party in accordance with its terms subject to
applicable bankruptcy, insolvency, moratorium and similar laws affecting creditors' rights
generally, and subject, as to enforceability, to general principles of equity (regardless if
enforcement is sought in proceeding in equity or at law).
<!-- page 7 -->
7 ARTICLE 6 NOTICES 6.1 Notices. All notices required or allowed to be given under this Agreement
must be made either personally by delivery to or by facsimile transmission to the address as
hereinafter set forth or to such other address as may be designated from time to time by such party
in writing: (a) in the case of the Company, to: Slinger Bag Inc. To be provided under separate cover
within three days after the date hereof; in the event that Consultant does not receive notice of
address within such period, then Consultant shall be entitled to send any notice to any email
address of the Company known to Consultant and the sending of any such notice shall constitute
receipt of notice whether the Company receives such notice or not. (b) and in the case of the
Consultant, to the Consultant's last residence address known to the Company or aitan@gcanrx.com. 6.2
Change of Address. Any party may, from time to time, change its address for service hereunder by
written notice to the other party in the manner aforesaid. ARTICLE 7 GENERAL 7.1 Further Assurances.
Each party hereto will promptly and duly execute and deliver to the other party such further
documents and assurances and take such further action as such other party may from time to time
reasonably request in order to more effectively carry out the intent and purpose of this Agreement
and to establish and protect the rights and remedies created or intended to be created hereby. 7.2
Waiver. No provision hereof will be deemed waived and no breach excused, unless such waiver or
consent excusing the breach is made in writing and signed by the party to be charged with such
waiver or consent. A waiver by a party of any provision of this Agreement will not be construed as a
waiver of a further breach of the same provision. 7.3 Amendments in Writing. No amendment,
modification or rescission of this Agreement will be effective unless set forth in writing and
signed by the parties hereto.
<!-- page 8 -->
8 7.4 Assignment. Except as herein expressly provided, the respective rights and obligations of the
Consultant and the Company under this Agreement will not be assignable by either party without the
written consent of the other party and will, subject to the foregoing, inure to the benefit of and
be binding upon the Consultant and the Company and their permitted successors or assigns. Nothing
herein expressed or implied is intended to confer on any person other than the parties hereto any
rights, remedies, obligations or liabilities under or by reason of this Agreement. For the avoidance
of doubt, it is agreed that in the event that the Company participates in a merger, acquisition,
restructuring, reorganization or other transaction in which the Company is merged into, sold to or
otherwise becomes part of or owned by another company or entity, this Agreement will remain in force
and be binding on any such successor, surviving or acquiring company or entity. 7.5 The Company
acknowledges and agrees that the Consultant may submit to the Company invoices from a company that
employs him in lieu of invoices on his name. The Consultant confirms that any such invoice will
replace his own invoice and he agrees that his fees will be paid by the Company to third parties
provided that it is done as per his instructions to the Company. 7.6 Severability. In the event that
any provision contained in this Agreement is declared invalid, illegal or unenforceable by a court
or other lawful authority of competent jurisdiction, such provision will be deemed not to affect or
impair the validity or enforceability of any other provision of this Agreement, which will continue
to have full force and effect. 7.7 Headings. The headings in this Agreement are inserted for
convenience of reference only and will not affect the construction or interpretation of this
Agreement. 7.8 Number and Gender. Wherever the singular or masculine or neuter is used in this
Agreement, the same will be construed as meaning the plural or feminine or a body politic or
corporate and vice versa where the context so requires. 7.9 Time. Time is of the essence in this
Agreement. 7.10 Governing Law. This Agreement will be construed and interpreted in accordance with
the laws of the State of New York without reference to its conflicts of laws principles or the
conflicts of laws principles of any other jurisdiction, and each of the parties hereto expressly
attorns to the jurisdiction of the courts of the State of New York. The sole and exclusive place of
jurisdiction in any matter arising out of or in connection with this Agreement will be the
applicable New York state or federal court. 7.11 This Agreement (including all Annexes thereto)
constitutes the entire agreement between the Parties with respect to the subject matter thereof and
supersedes all prior agreements, understandings and negotiations, both written and oral, between the
Parties with respect to this matter. IN WITNESS WHEREOF, the parties hereto have executed this
Agreement effective as of the date and year first above written. Slinger Bag Inc. By: Title: Agreed
and accepted: Aitan Zacharin
<!-- page 9 -->
9 Annex A THIS WARRANT AND THE SHARES ISSUABLE HEREUNDER HAVE NOT BEEN REGISTERED UNDER THE
SECURITIES ACT OF 1933, AS AMENDED (THE "ACT"), OR THE SECURITIES LAWS OF ANY STATE AND, EXCEPT AND
PURSUANT TO THE PROVISIONS OF ARTICLE 4 BELOW, MAY NOT BE OFFERED, SOLD OR OTHERWISE TRANSFERRED,
PLEDGED OR HYPOTHECATED UNLESS AND UNTIL REGISTERED UNDER SAID ACT AND APPLICABLE STATE SECURITIES
LAW OR, IN THE OPINION OF LEGAL COUNSEL IN FORM AND SUBSTANCE SATISFACTORY TO THE ISSUER OF THESE
SECURITIES, SUCH OFFER, SALE OR TRANSFER, PLEDGE OR HYPOTHECATION IS EXEMPT FROM REGISTRATION.
WARRANT TO PURCHASE COMMON STOCK Company: Slinger Bag Inc. Holder: Aitan Zacharin Shares: 1,250,000
shares of the Company's common stock. Class of Stock: common shares of stock of the Company Exercise
Price per share: par value Issue Date: 30 April 2020 Term: See Section 4.1 THIS WARRANT CERTIFIES
THAT, for value received as consideration pursuant to that certain amended and restated service
agreement dated 30 April 2020 (the "Service Agreement") and for other good and valuable
consideration the sufficiency of which is hereby acknowledged, Holder is entitled to receive the
Shares in the form of fully paid and nonassessable shares of the Company at the Exercise Price, all
as set forth herein, subject to the provisions and upon the terms and conditions set forth in this
Warrant. ARTICLE 1. EXERCISE. 1.1 Method of Exercise. Payment. (a) Cash Exercise. The purchase
rights represented by this Warrant may be exercised by the Holder, in whole or in part, by the
surrender of this Warrant (with the notice of exercise form attached hereto as Appendix 1 duly
executed) at the principal office of the Company, and by the payment to the Company, by certified,
cashier's or other check acceptable to the Company or by wire transfer to an account designated by
the Company, of an amount equal to the aggregate Exercise Price of the Shares being purchased.
<!-- page 10 -->
10 (b) Net Issue Exercise. In lieu of exercising this Warrant, the Holder may elect to receive
Shares equal to the value of this Warrant (or the portion thereof being canceled) by surrender of
this Warrant at the principal office of the Company together with notice of such election, in which
event the Company shall issue to the Holder a number of Warrant Shares computed using the following
formula: Y (A-B) X = ——————— A Where: X = the number of Shares to be issued to the Holder. Y = the
number of the Shares being exercised on the date of determination. A = the fair market value of one
Share on the date of determination. B = the per share Exercise Price (as adjusted to the date of
such calculation). (c) Fair Market Value. For purposes of this Article 1, the per share fair market
value of the Warrant Shares shall mean:
<!-- page 11 -->
11 (i) If the Company's Common Stock is publicly traded, the per share fair market value of the
Warrant Shares shall be the average of the closing prices of the Common Stock as quoted on the
Over-the-Counter Bulletin Board, or the principal exchange on which the Common Stock is listed, in
each case for the fifteen trading days ending five trading days prior to the date of determination
of fair market value; (ii) If the Company's Common Stock is not so publicly traded, the per share
fair market value of the Warrant Shares shall be such fair market value as is determined in good
faith by the Board of Directors of the Company after taking into consideration factors it deems
appropriate, including, without limitation, recent sale and offer prices of the capital stock of the
Company in private transactions negotiated at arm's length. 1.2 Delivery of Certificate and New
Warrant. Promptly after Holder first exercises this Warrant, the Company shall deliver to Holder
certificates for or other evidence (reasonably acceptable to the Holder) of the Shares received and,
if this Warrant has not been fully exercised and has not expired, a new Warrant representing the
Shares not so received. 1.3 Replacement of Warrants. On receipt of evidence reasonably satisfactory
to the Company of the loss, theft, destruction or mutilation of this Warrant and, in the case of
loss, theft or destruction, on delivery of an indemnity agreement reasonably satisfactory in form
and amount to the Company or, in the case of mutilation, on surrender and cancellation of this
Warrant, the Company shall execute and deliver, in lieu of this Warrant, a new warrant of like
tenor. ARTICLE 2. ADJUSTMENTS TO THE SHARES. 2.1 Stock Dividends, Splits, Combinations, Etc. If the
Company declares or pays a dividend on the Shares payable in Common Stock, or other securities, then
upon exercise of this Warrant, for each Share acquired, Holder shall receive, without cost to
Holder, the total number and kind of securities to which Holder would have been entitled had Holder
owned the Shares of record as of the date the dividend occurred. If the Company subdivides the
Shares by reclassification or otherwise into a greater number of shares or takes any other action
which increases the amount of stock into which the Shares are convertible, the number of shares
purchasable hereunder shall be proportionately increased and the Exercise Price shall remain the
same. If the outstanding shares of the Company are combined or consolidated, by reclassification or
otherwise, into a lesser number of shares, the Exercise Price shall be proportionately increased and
the number of Shares shall be proportionately decreased. 2.2 Reclassification, Exchange or
Substitution, Etc. Upon any reclassification, exchange, substitution, or other event that results in
a change of the number and/or class of the securities issuable upon exercise or net exercise of this
Warrant, Holder shall be entitled to receive, upon exercise or net exercise of this Warrant, the
number and kind of securities and property that Holder would have received for the Shares if this
Warrant had been exercised immediately before such reclassification, exchange, substitution, or
other event. The Company or its successor shall promptly issue to Holder an amendment to this
Warrant setting forth the number and kind of such new securities or other property issuable upon
exercise or net exercise of this Warrant as a result of such reclassification, exchange,
substitution or other event that results in a change of the number and/or class of securities
issuable upon exercise or net exercise of this Warrant.
<!-- page 12 -->
12 2.3 Merger or Consolidation. Upon any capital reorganization of the Company's capital stock
(other than a subdivision, combination, reclassification or exchange of shares provided for
elsewhere in this Section 2) or a merger or consolidation of the Company with or into another
corporation, then as a part of such reorganization, merger or consolidation, provision shall be made
so that the Holder shall thereafter be entitled to receive upon the exercise of this Warrant, the
number and kind of securities and property of the Company, or of the successor corporation resulting
from such reorganization, merger or consolidation, to which that Holder would have received for the
Shares if this Warrant had been exercised immediately before such reorganization, merger or
consolidation. 2.4 Fractional Shares. No fractional Shares shall be issuable upon exercise or net
exercise of this Warrant and the number of Shares to be issued shall be rounded up to the nearest
whole Share. ARTICLE 3. COVENANTS OF THE COMPANY. 3.1 Notice of Certain Events. If the Company
proposes at any time (a) to declare any dividend or distribution upon any of its stock, whether in
cash, property, stock, or other securities and whether or not a regular cash dividend; (b) to effect
any reclassification or recapitalization of any of its stock; or (c) to merge or consolidate with or
into any other corporation, or sell, lease, license, or convey all or substantially all of its
assets, or to liquidate, dissolve or wind up, then, in connection with each such event, the Company
shall give Holder: (1) at least three (3) days prior written notice of the date on which a record
will be taken for such dividend, distribution, or subscription rights (and specifying the date on
which the holders of Common Stock will be entitled thereto) or for determining rights to vote, if
any, in respect of the matters referred to in (a) above; and (2) in the case of the matters referred
to in (b) and (c) above at least three (3) days prior written notice of the date when the same will
take place (and specifying the date on which the holders of Common Stock will be entitled to
exchange their Common Stock for securities or other property deliverable upon the occurrence of such
event). 3.2 No Stockholder Rights or Liabilities. Except as provided in this Warrant, the Holder
will not have any rights as a stockholder of the Company until the exercise of this Warrant. Absent
an affirmative action by the Holder to purchase the Shares, the Holder shall not have any liability
as a stockholder of the Company. 3.3 Closing of Books. The Company will at no time close its
transfer books against the transfer of this Warrant or of any Shares issued or issuable upon the
exercise of this Warrant in any manner which interferes with the timely exercise of this Warrant.
ARTICLE 4. MISCELLANEOUS. 4.1 Term. This Warrant is exercisable in whole or in part at any time and
from time to time on or before the earlier of 5:00 pm GMT on the tenth (10th) anniversary of the
Issue Date. 4.2 Legends. This Warrant and the Shares (and the securities issuable, directly or
indirectly, upon conversion of the Shares, if any) shall be imprinted with a legend in substantially
the following form: THIS WARRANT AND THE SHARES ISSUABLE HEREUNDER HAVE NOT BEEN REGISTERED UNDER
THE SECURITIES ACT OF 1933, AS AMENDED (THE "ACT"), OR THE SECURITIES LAWS OF ANY STATE AND MAY NOT
BE OFFERED, SOLD OR OTHERWISE TRANSFERRED, PLEDGED OR HYPOTHECATED UNLESS AND UNTIL REGISTERED UNDER
SAID ACT AND APPLICABLE STATE SECURITIES LAW OR, IN THE OPINION OF LEGAL COUNSEL IN FORM AND
SUBSTANCE SATISFACTORY TO THE ISSUER OF THESE SECURITIES, SUCH OFFER, SALE OR TRANSFER, PLEDGE OR
HYPOTHECATION IS EXEMPT FROM REGISTRATION.
<!-- page 13 -->
13 4.3 Transfers. This Warrant and the Shares issuable upon exercise of this Warrant (and the
securities issuable, directly or indirectly, upon conversion of the Shares, if any) may not be
transferred or assigned in whole or in part without compliance with applicable federal and state
securities laws by the transferor and the transferee (including, without limitation, the delivery of
investment representation letters and legal opinions reasonably satisfactory to the Company, as
reasonably requested by the Company). After compliance with all restrictions on transfer set forth
in this Section 4.3, and within a reasonable time after the Company's receipt of an executed
assignment agreement, the transfer shall be recorded on the books of the Company upon the surrender
of this Warrant, properly endorsed, to the Company at its principal offices, and the payment to the
Company of all transfer taxes and other governmental charges imposed on such transfer. In the event
of a partial transfer, the Company shall issue to the new holders one or more appropriate new
warrants. 4.4 Notices. All notices and other communications from the Company to the Holder, or vice
versa, shall be deemed delivered and effective when given personally or mailed by first-class
registered or certified mail, postage prepaid, at such address as may have been furnished to the
Company or the Holder, as the case may (or on the first business day after transmission by
facsimile) be, in writing by the Company or such Holder from time to time. Effective upon receipt of
the fully executed Warrant, all notices to the Holder shall be addressed as set forth on the
signature page hereto until the Company receives notice of a change of address in connection with a
transfer or otherwise. Notice to the Company shall be addressed as set forth on the signature page
hereto until the Holder receives notice of a change in address. 4.5 Waiver. This Warrant and any
term hereof may be changed, waived, discharged or terminated only by an instrument in writing signed
by the party against which enforcement of such change, waiver, discharge or termination is sought.
4.6 Counterparts. This Warrant may be executed in counterparts, all of which together shall
constitute one and the same agreement. 4.7 Governing Law. This Warrant shall be governed by and
construed in accordance with the laws of the State of New York, without giving effect to its
principles regarding conflicts of law. Please indicate your acceptance of these terms by
countersigning where indicated below. Slinger Bag Inc. Name: Title: Agreed and accepted: Aitan
Zacharin
<!-- page 14 -->
14 Appendix 1 SLINGER BAG INC. EXERCISE NOTICE Reference is made to the Warrant Agreement dated 30
April 2020 between Slinger Bag Inc. (the "Company") and Aitan Zacharin (the "Warrant Agreement"). In
accordance with and pursuant to the Warrant Agreement, the undersigned hereby elects to exercise the
Warrant to purchase shares of common stock of the Company as set forth below. Capitalized terms used
but not defined herein have the meanings assigned to such terms in the Warrant Agreement. Date of
Exercise: __________________________________________________ Number of shares of ordinary/common (or
its equivalent) stock to be purchased:________________________________ Please issue shares of common
stock in the following name and to the following address: Issue to:
_________________________________________ Address: _________________________________________
Telephone Number: ________________________________ Email address: _________________________________
Holder: __________________________________________ By: Title:
