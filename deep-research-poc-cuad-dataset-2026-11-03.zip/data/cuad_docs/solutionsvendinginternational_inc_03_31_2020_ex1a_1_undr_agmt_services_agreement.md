<!-- page 1 -->
# Services Agreement
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2019-08-19 |
| Parties | StartEngine Crowdfunding, Inc. ("Company"); Solutions Vending International, Inc ("Customer", "you") |
| Source | CUAD v1 / SOLUTIONSVENDINGINTERNATIONAL,INC_03_31_2020-EX1A-1 UNDR AGMT-SERVICES AGREEMENT |

Exhibit 1.2 SERVICES AGREEMENT This Services Agreement ("Services Agreement" or "Agreement") is
entered into as of the date noted below (the "Effective Date") between StartEngine Crowdfunding,
Inc., a Delaware corporation ("Company"), and Solutions Vending International, Inc a ___ DE
corporation ("Customer" or "you"). 1. Services Company agrees to make available to Customer the
ability to present information with respect to its securities offering (the "Offering") to Users,
and to permit Users to create and manage online accounts, view information regarding the Customer,
indicate interest in the Offering, and to subscribe to the Offering by signing a subscription
agreement or similar instrument and transmitting payment instructions (together, the "Services"). A
"User" means a natural person, corporation or other entity that has established an account on the
Company's website. 2. Fees and expenses a) Generally In exchange for the Services, you shall pay the
Company the then applicable fees and expenses set out below. The Company reserves the right to
change the applicable charges and to institute new charges and fees at the end of the Initial Term
(as defined below) or then current renewal term, upon 30 days prior notice to you. If you believe
that the Company has billed you incorrectly, you must contact Company no later than 60 days after
the closing date on the first billing statement in which the error or problem appeared, in order to
receive an adjustment or credit. Inquiries should be directed to contact@startengine.com. b) Monthly
Fees and Billing The Company will bill you monthly for the Services. You authorize the Company to
instruct Prime Trust or any escrow agent used by Company to deduct such fees, debts and any other
amounts liabilities incurred under this Service Agreement, prior to releasing any amounts due to you
or to any other person (including another escrow agent) from escrow. Amounts which remain unpaid for
30 days are subject to a finance charge of 1.5% per month on any outstanding balance, or the maximum
permitted by law, whichever is lower, plus all expenses of collection and may result in immediate
termination of Service. You shall be responsible for all taxes associated with Services other than
U.S. taxes based on the Company's net income. c) Transaction Fees Company's transaction fees depend
on the method of payment (e.g. ACH-US or WIRE-US). ACH transaction: $1 Wire: $15 d) AML Fees AML
fees are charged per User per initial transaction. AML: $2 AML UK: $5
<!-- page 2 -->
e) Reimbursable expenses You shall reimburse the Company for the following expenses: (i) All credit
card charges charged to the Company by its third-party credit card processor. (ii) All transaction
fees charged to the Company or its affiliates by its third-party transaction processor. (iii) Escrow
agent fees charged to the Company or its affiliates by third-party escrow agents. (iv) Return fees
as set out in Section 4 (Returns, Reversals, Disputes and Reserves) below. Credit cards: average is
3.5% (varies because it is a combination of fixed and a percentage charged by the credit card
vendor) 2. Customer Representations and Warranties Customer represents and warrants to the Company
that then executed and delivered by Customer, this Service Agreement will constitute the legal,
valid, and binding obligation of Customer, enforceable in accordance with its terms. 4. Returns and
Reversals a) Returns and Reversals User transactions debited from bank accounts via ACH are subject
to returns (e.g., non-sufficient funds) and reversals from chargebacks (e.g., unauthorized activity)
per the Electronic Fund Transfer Act (15 U.S.C. 1693 et seq. as may be amended), Regulation E, and
NACHA guidelines (collectively, such returns and reversals are "Reversals"). The Company will work
to protect Customer and the receiving Users from unwarranted Reversals; however, Customer
acknowledges and agrees that: i) Customer is liable for all User Activity and Reversals associated
with User Activity; ii) If Company's agent receives a Reversal, the Company may in its sole
discretion charge Customer the full amount of the Reversal ("Reversed Payment") plus an additional
$7 reversal fee ("Reversal Fee" and collectively the "Reversal Liability"); iii) The Company has
sole discretion to determine who is at fault and liable for the Reversed Payment and Reversal Fee;
iv) Customer authorizes the Company to take any of the following actions (in any particular order):
(i) collect the unpaid portion of the Reversal Liability from funds sent to your third party escrow
account; (ii) debit your bank account in the amount of the unpaid portion of the Reversal Liability;
(iv) engage in collection efforts to recover the unpaid portion of the Reversal Liability and/or (v)
take legal action or any other action under this Service Agreement. 5. Term and Survival a) Subject
to earlier termination as provided below, this Service Agreement is for the total duration of the
Company's Offering (the "Initial Term") unless either party requests termination at least 30 days
prior to the end of the then-current term.
<!-- page 3 -->
b) Additionally, either party may terminate this Service Agreement in the event: i) The other
party's material breach that remains not cured and continues for a period of (A) in the case of a
failure involving the payment of any undisputed amount due hereunder, 15 days and (B) in the case of
any other failure, 30 days after the non performing party receives notice from the terminating party
specifying such failure; ii) Any statement, representation or warranty of the other party is untrue
or misleading in any material respect or omits material information; iii) The other party (A)
voluntarily or involuntarily is subject to bankruptcy proceedings, (B) applies for or consents to
the appointment of a receiver, trustee, custodian, sequestrator, or similar official, (C) makes a
general assignment to creditors, (D) commences winding down or liquidation of its business affairs,
(E) otherwise takes corporate action for the purpose of effecting any of the foregoing, or (F)
ceases operating in the normal course of business; iv) If any change to, enactment of, or change in
interpretation or enforcement of any law occurs that would have a material adverse effect upon a
party's ability to perform its obligations under this Service Agreement or a party's costs/revenues
with respect to the services under this Service Agreement; v) Upon direction to a party from any
regulatory authority or National Automated Clearing House Association to cease or materially limit
the exercise or performance of such party's rights or obligations under this Service Agreement; vi)
If there shall have occurred a material adverse change in the financial condition of the other
party; or vii) Upon a force majeure event that materially prevents or impedes a party from
performing its obligations hereunder for a period of more than 10 business days. StartEngine
Crowdfunding, Inc. Customer: By: /s/ Dawn Dickson, By:Dawn Dickson, CEO and Founder Date: 08/19/2019
/s/ Howard Marks Howard Marks CEO
