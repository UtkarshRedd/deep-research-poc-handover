<!-- page 1 -->
# JOINT VENTURE CONTRACT
| Field | Value |
|---|---|
| Document Type | Joint Venture Agreement |
| Agreement Date | 2002-11-08 |
| Parties | Baoding Fengfan Group Limited Liability Company ("Party A"); Valence Technology, Inc. ("Party B") |
| Source | CUAD v1 / VALENCETECHNOLOGYINC_02_14_2003-EX-10-JOINT VENTURE CONTRACT |

EXHIBIT 10.3

JOINT VENTURE CONTRACT

CHAPTER 1 GENERAL PROVISIONS

In accordance with the Law of the People's Republic of China on Joint Ventures Using Chinese and
Foreign Investment (the "Joint Venture Law") and other relevant Chinese laws and regulations,
Fengfan Group Limited Liability Company and Valence Technology Inc., in accordance with the
principle of equality and mutual benefit and through friendly consultations, agree to jointly invest
to establish a joint venture enterprise in Baoding City, Hebei Province of the People's Republic of
China.

CHAPTER 2 PARTIES TO THIS CONTRACT

Article 1 Parties to this Joint Venture Contract

1. Baoding Fengfan Group Limited Liability Company (hereinafter referred to as Party A), established
and existing under the laws of the People's Republic of China ("PRC"), registered with the No.
1306001000338 Business License in China.

Legal address: 8 Fuchang Road, Baoding City, Hebei Province, PRC

Legal Representative of Party A:

Name: Mengli Chen

Position: CHAIRMAN AND GENERAL MANAGER

Nationality: Chinese

2. Valence Technology, Inc., (hereinafter referred to as Party B), established and existing under
the laws of the State of Delaware in the United States of America ("USA").

Registered address: 301 Conestoga Way, Henderson, Nevada 89015, USA

Legal Representative of Party B:

Name: Stephan B. Godevais

Position: CHAIRMAN AND CEO

Nationality: United States of America

3. Each of the Parties hereby represents and warrants to the other Party that, as of the date hereof
and as of the Effective Date:

Page 1

(1) such Party is duly organized, validly existing and in good standing under the laws of the place
of its establishment or incorporation;

(2) such Party has all requisite power and approval required to enter into this Contract and, upon
the Effective Date, will have all requisite power and approval to perform fully each and every one
of its obligations hereunder;

(3) such Party has taken all internal and corporate actions necessary to authorize it to enter into
this Contract and its representative whose signature is affixed hereto is fully authorized to sign
this Contract and to bind such Party thereby;

(4) upon the Effective Date, this Contract shall be legally binding on such Party;

(5) neither the signature of this Contract nor the performance of its obligations hereunder will
conflict with, or result in a breach of, or constitute a default under, any provision of the
Articles of Association (in the case of Party A) or the Certificate of Incorporation or By-Laws (in
the case of Party B) of such Party, or any law, regulation, rule, authorization or approval of any
government agency or body, or of any contract or agreement, to which such Party is a party or
subject;

(6) no lawsuit, arbitration, other legal or administrative proceeding, or governmental investigation
is pending, or to the best of such Party's knowledge threatened, against such Party that would
affect in any way its ability to enter into or perform this Contract; and

(7) all documents, statements and information of or derived from any
<!-- page 2 -->
governmental body of China in the possession of such Party relating to the transactions contemplated
by this Contract which may have a material adverse effect on such Party's ability to fully perform
its obligations hereunder, or which if disclosed to the other Party, would have a material effect on
the other Party' willingness to enter into this Contract, have been disclosed to the other Party,
and no document previously provided by such Party to the other Party contains any untrue statement
of material fact or omits to state any material fact necessary in order to make the statements
contained therein not misleading.

CHAPTER 3 DEFINITIONS

Unless otherwise provided herein, the following words and terms used in this Contract shall have the
meanings set forth below:

Article 2

"Affiliate" means, in relation to Party A, any enterprise or other entity which, directly or
indirectly, controls, or is controlled by, Party A; the term "control" meaning ownership of fifty
percent (50%) or more of the registered capital or voting stock or the power to appoint the general
manager, factory chief or other principal person in charge of an enterprise or other entity.

Page 2

"Affiliate" means, in relation to Party B, any company which, through ownership of voting stock or
otherwise, directly or indirectly, is controlled by, under common control with, or in control of,
Party B; the term "control" meaning ownership of fifty percent (50%) or more of the voting stock or
the power to appoint or elect a majority of the directors or the power to direct the management of a
company.

Article 3

"Articles of Association" means the Articles of Association of the Joint Venture Company signed by
Party A and Party B simultaneously with this Contract in Baoding, People's Republic of China.

Article 4

"Board of Directors" means the board of directors of the Joint Venture Company.

Article 5

"Business License" means the business license of the Joint Venture Company issued by the State
Administration for Industry and Commerce or the competent local Administration for Industry and
Commerce.

Article 6

"CEO" means the general manager of the Joint Venture Company. "Deputy CEO" means the deputy general
manager of the Joint Venture Company.

Article 7

" China" or "PRC" means the People's Republic of China.

Article 8

"Company Establishment Date" means the date of issuance of the Business License.

Article 9

"Contract Term" means the term of this Contract as set forth in Chapter 18, including any extension
thereof.

Article 10

"Effective Date" means the effective date of this Contract, which shall be the date on which this
Contract and the Articles of Association have been approved by the Examination and Approval
Authority.

Page 3

Article 11

"Examination and Approval Authority" means the Ministry of Foreign Trade and Economic Co-operation
or other foreign trade and economic department with authority to approve this Contract and the
Articles of Association.

Article 12

"Plant" means [definition to be added].

Article 13
<!-- page 3 -->
"Joint Venture Company" means [FengFan - Valence Battery Company, Ltd.], the Sino-foreign equity
joint venture limited liability company formed by Party A and Party B pursuant to this Contract.

Article 14

"Joint Venture Products" means technologically advanced batteries, including but not limited to
lithium phosphate batteries, lithium cobalt oxide batteries and lithium manganese oxide batteries.

Article 15

"Management Personnel" means the Joint Venture Company's CEO, Deputy CEO, Chief Financial Officer
and other management personnel who report directly to the CEO.

Article 16

"Renminbi" or "RMB" means the lawful currency of China.

Article 17

"Site" means [definition to be added].

Article 18

"Contract for Technology Investment" means the contract for investment of technology in the form of
technology license and services, signed by Party B and Party A simultaneously with the signature of
this Contract, and which shall be ratified by the Board of Directors of the Joint Venture Company
following its establishment, pursuant to which Party B will license to the Joint Venture Company the
right to use the proprietary technology (including patented technology), related documentation and
operational know-how, and provide technologically advanced management support and technical
assistance for the production of the Joint Venture Products, which contract is attached hereto as
Appendix 2.

Page 4

Article 19

"Third Party" means any natural person, legal person or other organisation or entity other than the
Parties to this Contract or the Joint Venture Company

Article 20

"Three Funds" means the Joint Venture Company's reserve fund, expansion fund and employee bonus and
welfare fund as stipulated in the Joint Venture Regulations.

Article 21

"United States Dollars" or "US$" means the lawful currency of the United States of America.

Article 22

"Working Personnel" means all employees and staff of the Joint Venture Company other than the
Management Personnel.

CHAPTER 4 ESTABLISHMENT AND LEGAL FORM OF THE JOINT VENTURE COMPANY

Article 23

The Parties hereby agree to establish the Joint Venture Company in accordance with the laws and
regulations of the PRC.

Article 24

Name of Joint Venture Company in Chinese characters: [**[VALENCE IN CHINESE] ********]

Joint Venture Company in English: [FENGFAN - VALENCE BATTERY COMPANY, LTD.]

Legal address of Joint Venture Company: [Baoding City High and New Technology Zone, Baoding City,
Hebei Province, the People's Republic of China.]

Article 25

The Joint Venture Company shall be an enterprise legal person under the laws of China. The
activities of the Joint Venture Company shall be governed by the laws, decrees, rules and
regulations of China, and its lawful rights and interests shall be protected by the laws, decrees,
rules and regulations of China.

Page 5

Article 26
<!-- page 4 -->
The organization form of the Joint Venture Company is a limited liability company. The liability of
each Party to the Joint Venture Company shall be limited to contributing the full amount of its
share of the Joint Venture Company's registered capital. Unless otherwise provided pursuant to a
written agreement signed by a Party and a creditor of the Joint Venture Company, creditors of the
Joint Venture Company and other claimants against the Joint Venture Company shall have recourse only
to the assets of the Joint Venture Company and shall not have rights to seek compensation, damages
or other remedies from any of the Parties. Subject to the foregoing, the Parties shall share the
Joint Venture Company's profits, and bear the losses and risks arising from their investments in the
Joint Venture Company, in proportion to their respective shares of the Joint Venture Company's
registered capital.

CHAPTER 5 THE PURPOSE, SCOPE AND SCALE OF PRODUCTION AND BUSINESS

Article 27

The purpose of the Joint Venture Company is to use advanced technology and scientific management
techniques to produce and sell the Joint Venture Products, to improve the quality and increase the
value and competitiveness of such products, to develop and introduce new products and to obtain
satisfactory economic benefits for the Parties.

Article 28

The Joint Venture Company's scope of business shall be the design, manufacture and sale of
technologically advanced batteries, including but not limited to lithium iron magnesium phosphate
batteries, lithium cobalt oxide batteries and lithium manganese oxide batteries.

Article 29

The goal is to produce one hundred million (100,000,000) watt-hours per year with target annual
sales of Sixty Million United States Dollars (US$60,000,000). The Board of Directors will determine
the Joint Venture Company's actual production levels based on relevant market and operating
conditions.

CHAPTER 6 TOTAL AMOUNT OF INVESTMENT AND REGISTERED CAPITAL

Article 30

The Joint Venture Company's total amount of investment shall be Twenty-Nine Million Nine Hundred
Thousand United States Dollars (US$29,900,000).

Page 6

Article 31

The Joint Venture Company's registered capital shall be Twenty-Nine Million Nine Hundred Thousand
United States Dollars (US$29,900,000), including:

Party A's contribution to the registered capital of the Joint Venture Company shall be Fourteen
Million Six Hundred Fifty-One Thousand United States Dollars (US$14,651,000), representing a
forty-nine percent (49%) share of the Joint Venture Company's registered capital. Party B's
contribution to the registered capital of the Joint Venture Company shall be Fifteen Million Two
Hundred Forty Nine Thousand United States Dollars (US$15,249,000), representing a fifty-one percent
(51%) share of the Joint Venture Company's registered capital.

Article 32 The Method of Investment

Party A's total contribution (US$14,651,000) to the registered capital shall be invested as cash.
US$7,000,000 of this contribution is used for the Joint Venture Company's initial purchase of
foreign equipment from Party B and the remainder is used for purchase of foreign and domestic

equipment, and land use rights and construction of workshops in China. (If the contribution is in
RMB, it shall be converted using the median rate for buying and selling for foreign currency
announced by the People's Bank of China on the date of investment).

Party B's total contribution (US$15,249,000) to the registered capital shall be invested as follows:

(1) use of technology in accordance with the Contract for Technology Investment, which is attached
hereto as Appendix 2, which the parties agree to be valued at US$5,900,000; and

(2) production equipment, in accordance with the Contract for Equipment Investment and Purchase (
Appendix 3 hereto), which equipment the parties agree to be valued at US$9,349,000.

(If any part of the contribution is in RMB, the investment shall be converted using the median rate
for buying and selling for foreign currency announced by the People's Bank of China on the date of
investment).

Article 33

The Joint Venture Company's registered capital shall be contributed according to both Parties'
proportion of investment. The detailed method, quantity and timing
<!-- page 5 -->
of the contributions are shown in Appendix 1.

Page 7

Article 34

No Party shall be obligated to make any contribution to the Joint Venture Company's registered
capital if any of the following conditions have not been satisfied or waived in writing by both
parties:

(1) this Contract and the Articles of Association have been signed by both Parties, and approved by
the Examination and Approval Authority without altering their terms and conditions, unless each
Party has been notified in advance of and consented in writing to such alterations ;

(2) the Business License has been issued without altering the Joint Venture Company's business scope
as set forth in Article28, unless each Party has been notified in advance of and consented in
writing to such alteration;

(3) signature by the parties thereto of all the Contract for Technology Investment, the forms of
which are annexed to this Contract and, where required by law, approval or registration of such
contracts by the relevant government approval authority without altering their terms and conditions,
unless each Party has been notified in advance of and consented in writing to such alterations; and

(4) [the Parties have taken those steps necessary for the identification and securing of an
operating site suitable for the JV Company's purposes].

Article 35

Each time a Party makes a contribution to the Joint Venture Company's registered capital, a Chinese
registered accountant appointed by the Board of Directors shall promptly verify the contribution and
issue a capital verification report to the Joint Venture Company. Within sixty (60) days from
receipt of the capital verification report, the Joint Venture Company shall issue an investment
certificate to such Party in the form prescribed by the Joint Venture Regulations, signed by the
Chairman and the Vice-Chairman of the Board and chopped with the Joint Venture Company's chop. Each
investment certificate shall indicate the amount of the capital contribution and the date on which
such contribution was made, and a copy shall be submitted to the Examination and Approval Authority
for the record. The CEO shall maintain a file of all capital verification reports and copies of all
investment certificates that have been issued to the Parties.

Article 36

Any increase in the registered capital of the Joint Venture Company shall require the written
consent of each Party and the unanimous approval of the Board of Directors. All increases in
registered capital must be approved by the Examination and Approval Authority in accordance with
relevant law.

Page 8

Article 37

Unless it obtains written consent of the other Party and approval of the Examination and Approval
Authority, no party to this Contract can transfer all or part of its interest in the registered
capital of the Joint Venture Company to a Third Party. Each Party agrees promptly to take all
actions and to sign all documents, and to cause its appointees on the Board of Directors promptly to
take all actions and sign all documents, that are legally required to effect a transfer of
registered capital for which the foregoing consent has been obtained. Upon receipt of approval from
the Examination and Approval Authority, the Joint Venture Company shall register the change in
ownership with the competent Administration for Industry and Commerce.

Article 38

If there is a difference between the total amount of investment and the registered capital or if the
Joint Venture Company needs working capital, the Joint Venture Company and, if entrusted by the
Joint Venture Company, either party to this Contract may negotiate to obtain loans from banks or
other authorized lenders. Such loans may be secured by the guarantee, mortgage and pledge of the
Joint Venture Company. Any loans provided by the parties to the Joint Venture Company or any
guarantees or securities provided by the parties to secure loans to the Joint Venture Company shall
only be provided by both parties and shall be provided in proportion to each party's interest in the
Joint Venture Company.

Article 39
<!-- page 6 -->
No Party shall mortgage, pledge or otherwise encumber all or any part of its share of the Joint
Venture Company's registered capital without the prior written consent of the other Party.

CHAPTER 7 RESPONSIBILITIES OF EACH PARTY

Article 40

Responsibilities of Party A

In addition to its other obligations under this Contract, Party A shall have the following
responsibilities:

o Handle all applications to the relevant Examination and Approval Authority in China, register and
obtain the Business License necessary for the establishment of the Joint Venture Company. Party A
shall provide Party B with copies of all such approvals and licenses and all notices, letters and
other correspondence submitted to or received from the Examination and Approval Authority, the
competent Administration for Industry and Commerce and other Chinese government departments in
respect of the Company.

Page 9

o Assist the Joint Venture Company, upon request, in processing the application for the right to the
use of a site to the authority in charge of the land.

o Assist the Joint Venture Company, upon request, in organizing the design and construction of the
premises and other facilities of the Joint Venture Company.

o Assist the Joint Venture Company, upon request, in processing import customs declarations for the
machinery and equipment which is provided as investment or purchased in accordance with this
Contract, and arranging the transportation of the same within the Chinese territory.

o Assist the Joint Venture Company, upon request, in contacting providers and arranging fundamental
facilities such as water, electricity, transportation etc.

o Assist the Joint Venture Company, upon request, in applying for all licenses and permits required
for the operation of the Joint Venture Company's business.

o Assist the Joint Venture Company, upon request, in applying for all possible preferential tax
treatment and other preferential treatment.

o Assist the Joint Venture Company, upon request, in recruiting Chinese management personnel,
technical personnel, workers and other required personnel.

o Assist the Joint Venture Company, upon request, in obtaining all necessary entry visas, work
permits, residence permits and other necessary help for personnel working at the Joint Venture
Company.

o Assist the Joint Venture Company, upon request, in obtaining and maintaining a Foreign Exchange
Registration Certificate;

o Implementing its obligations, if any, stated in the Schedule of Capital Contributions, the
Contract for Investment of Technology, the Contract for Equipment Investment and Purchase, and the
Contract for Export Sales, which documents are attached hereto as Appendices 1 to 4

o Be responsible for handling other matters entrusted by the Joint Venture Company.

Article 41

Responsibilities of Party B

In addition to its other obligations under this Contract, Party B shall have the following
responsibilities:

o Upon request by the Joint Venture Company, handle the purchase of equipment, machinery, tools and
other materials entrusted by the Joint Venture Company.

Page 10

o Providing necessary technical personnel to the Joint Venture Company for installing and testing
equipment, and being responsible for assisting with the operation of the equipment.

o Training the management personnel, technical personnel and operation workers of the Joint Venture
Company in accordance with the provisions

of the Contract for Technology Investment.
<!-- page 7 -->
o Implementing its obligations stated in the Schedule of Capital Contributions, the Contract for
Investment of Technology, the Contract for Equipment Investment and Purchase, and the Contract for
Export Sales, which documents are attached hereto as Appendices 1 to 4.

o Be responsible for handling other matters entrusted by the Joint Venture Company.

CHAPTER 8 TECHNOLOGY

Article 42

Party A and Party B shall sign the Contract for Technology Investment simultaneously with the
signature of this Contract, and pursuant to the Contract for Technology Investment shall license to
the Joint Venture Company the right to utilize proprietary technology (including patented
technology), related documentation and know-how for the production of the Joint Venture Products.
The Contract for Technology Investment is attached hereto as Appendix 2.

The technology license fee of Five Million Nine Hundred Thousand United States Dollars
(US$5,900,000) shall be deemed to be paid by the Joint Venture Company and shall constitute part of
Party B's contribution to the registered capital of the Joint Venture Company in accordance with
Article 32 of this Contract. The Contract for Technology Investment shall be signed by the Parties
simultaneously with the signing of this Joint Venture Contract and shall come into effect upon its
approval by the Examination and Approval Authority. The Board of Directors shall ratify the Contract
for Technology Investment at the first meeting of the Board of Directors.

Party B and the Joint Venture Company shall comply with the provisions of the Contract for
Technology Investment, and Party B further warrants that the technology provided in accordance with
the Contract for Technology Investment is complete, correct, effective and can fulfil the
technological goals set forth in the Contract for Technology Investment.

Article 43

Party B will provide to the Joint Venture Company new inventions, creations and technology related
to the Lithium Iron Magnesium Phosphate powder manufacture and battery manufacture and Bellcore
battery configuration at no additional charge. The Joint Venture Company may manufacture products
using such new inventions, creations and technology on the same terms as other batteries are
manufactured, under the Contract for Technology Investment. Improvements for all other batteries may
be licensed to the Joint Venture Company on terms to be agreed by the Party B and the Joint Venture
Company.

Article 44

Page 11

Party A and Party B shall sign the Contract for Technology Investment simultaneously with the
signature of this Contract, and pursuant to the Technical Service Contract shall provide technical
services to the Joint Venture Company, which shall reimburse to Party B the direct expenses incurred
in China for those Party B personnel rendering such services. The form of the Contract for
Technology Investment is attached hereto as Appendix 2.

Article 45

The parties to this Contract agree that the technology, documentation and know-how provided under
the Contract for Technology Investment and the technical services provided under the Contract for
Technology Investment are provided for the use of the Joint Venture Company. Party A hereby
undertakes to Party B and the Joint Venture Company that:

(1) Party A and its Affiliates shall not at any time during or after the Contract Term use such
technology and know-how except for the purpose of marketing and selling batteries produced by the
Joint Venture Company;

(2) In respect of such technology and know-how, Party A and its Affiliates shall comply with the
confidentiality obligations set forth in Chapter 17 of this Contact; and

(3) Breach of this Article by Party A shall be deemed to be a material breach of this Contract.

Article 46

Party B and its Affiliates guarantee that following the Effective Date of this Contract, it will not
further transfer to any Third Party: i) the proprietary technology for production of Powder (as
defined below) to be made into Batteries (as defined below) or ii) the proprietary technology for
production of Batteries that use the Bellcore configuration. Party B also guarantees that any new
inventions and improvements in the proprietary technology for production of Batteries shall be
provided to the Joint Venture Company at no fee, excepting reimbursement of any direct travel or
communication costs required for the
<!-- page 8 -->
provision of such technology, consistent with the terms of the Contract for Technology Investment.

In this Article, "Powder" shall mean the Cathode Active Materials (defined below) required for the
fabrication of the Batteries. In this paragraph, "Batteries" shall mean and include any aggregate of
components or compositions of matter primarily adapted for storing or providing electrical energy
and which include a positive and negative electrode, at least one of which shall include materials
made from Cathode Active Materials, and the other shall include a carbonaceous anode material.
"Cathode Active Material(s)" shall mean Lithium Cobalt Oxide, Lithium Manganese Dioxide, Lithium
Nickel Oxide, Lithium Nickel Cobalt Oxide, Lithium Manganese Oxide Spinel and Lithium Iron Magnesium
Phosphate, and Lithium Phosphate material.

Page 12

Article 47

Until such time that the Joint Venture Company is capable of providing cost-effective, high quality
Powder that satisfies all technical specifications identified by Party B, the Parties agree that
either Party B or the Joint Venture Company shall have the right to purchase Powder from a Third
Party. In no circumstances shall the Joint Venture Company offer the Powder for sale to Third
Parties.

Both Party A and Party B agree that they will not compete with the Joint Venture Company or with
each other utilizing knowledge or expertise or production capabilities gained from the Joint Venture
Company or gained from the Parties' respective technology contributions thereof.

CHAPTER 9 SALE OF PRODUCTS AND USE OF TRADEMARK

Article 48

The Joint Venture Company may sell the Joint Venture Products in the domestic and overseas markets,
and may entrust Third Party's to sell the Joint Venture Products with approval from the Board of
Directors.

Article 49

It is the intention of the parties that no less than 50% of the Joint Venture Products should be
sold overseas.

Article 50

Each Party retains all ownership to its trademarks, service marks, logos, trade names, and similar
designations identified in Exhibit B of the Contract for Technology Investment and any other such
marks which such Party may from time to time designate in writing, and the other Party and the Joint
Venture Company will neither register or use, directly or indirectly, any mark that is identical or
confusingly similar to Valence's marks or any translations or transliterations thereof, anywhere in
the world. Notwithstanding the foregoing, the Joint Venture Company may register its own trademarks,
service marks, logos and trade names, and it may use the marks owned by a Party without
compensation, provided that the use is in accordance with terms of a written trademark license
contract signed with that Party.

CHAPTER 10 THE BOARD OF DIRECTORS

Article 51

The date of registration of the Joint Venture Company shall be the date of the establishment of the
board of directors of the Joint Venture Contract.

Page 13

Article 52

The Board of Directors shall comprise seven (7) directors, three (3) of whom shall be appointed by
Party A and four (4) of whom shall be appointed by Party B. The chairman of the board shall be
appointed by Party A, and its vice-chairman by Party B.

Article 53

Directors shall be appointed for a term of four (4) years, provided that the Party who has appointed
a director may remove that director and appoint a replacement at any time. A director may serve
consecutive terms if reappointed by the Party that originally appointed him/her. If a seat on the
Board of Directors is vacated by the retirement, resignation, disability or death of a director or
by the removal of such director by the Party who originally appointed him/her, the Party who
originally appointed such director shall appoint a successor to serve out such director's term. At
the time this Contract is signed and each time a director is appointed or replaced, each Party shall
notify the other Party in writing of the names of its appointees or replacements.
<!-- page 9 -->
Article 54

The Board of Directors shall be the highest authority of the Joint Venture Company. It shall decide
all matters of major importance to the Joint Venture Company. The following matters shall require
the unanimous assent of all the directors:

o Amendment of the Articles of Association;

o Termination and dissolution of the Joint Venture Company;

o Merger of the Joint Venture Company with another organization;

o Major investment by the Joint Venture Company;

o Distribution of profit of the Joint Venture Company;

o The recruitment and dismissal of the Senior Management Personnel of the Joint Venture Company;

o Transfer of a part of all of either Party's interest in the registered capital of the Joint
Venture Company;

o Increase and decrease of the Joint Venture Company's registered capital; and

o The examination and approval of the annual financial report of the Joint Venture Company.

Article 55

Except for the matters stipulated in the above article, all other matters shall be decided by the
assent of a majority of the directors present in person or by proxy at a duly convened meeting of
the board of

Page 14

directors, provided however that at least one member of the Board of Directors nominated by each
Party assents to such decision of the Board

If a vote on any resolution (other than resolutions requiring unanimous assent) results in a failure
to obtain an affirmative vote, then the directors promptly shall endeavour to resolve the matter
through further consultations. Any director shall have the right to call a meeting for a second vote
on the matter after seven (7)days has elapsed from the first vote. If the second vote also results
in a failure to obtain an affirmative vote, then the Chairman and Vice-Chairman of the Board shall
jointly refer the matter to the highest executive officer of each Party within seven (7) days from
the second vote, and they shall endeavour to agree on a resolution of the matter, which resolution
shall be binding upon the Board of Directors and the Joint Venture Company. If the highest executive
officers of each Party are unable to resolve the matter within thirty (30) days from the date of
receipt of the referral from the Chairman and Vice-Chairman of the Board, the resolution shall be
deemed not to have been passed by the Board of Directors.

If the non-passage under this Article 55 of a resolution concerning management or financial matters
results in a material adverse effect on the economic benefits derived by one or both Parties from
their respective investments in the Joint Venture Company, then a Party whose benefits are adversely
and materially affected may terminate this Contract.

Article 56

Party A shall designate a director to serve as Chairman of the Board and Party B shall designate
another director to serve as Vice-Chairman of the Board. The Chairman of the Board shall be the
legal representative of the Joint Venture Company, but shall have only the authority delegated to
him/her by the Board of Directors, and no individual member of the Board of Directors shall
contractually or otherwise bind the Joint Venture Company without the prior written authorization of
the Board of Directors. The Party appointing the Chairman of the Board shall be responsible for all
losses and liabilities that the Joint Venture Company may incur as a result of the Chairman of the
Board exceeding the scope of authority stipulated in this Contract. Whenever the Chairman of the
Board is unable to perform his responsibilities for any reason, he shall authorise the Vice-Chairman
of the Board to represent him. If the Vice-Chairman is not available, the Chairman of the Board
shall authorise another director to represent him/her.

Article 57

The Joint Venture Company shall indemnify each director against all claims and liabilities incurred
by reason of his being a director of the Joint Venture Company, provided that the director's acts or
omissions giving rise to such claim or liability did not constitute intentional misconduct or gross
negligence or a violation of criminal laws.

Article 58

The first meeting of the Board of Directors shall be held within one (1) month from the Company
Establishment Date. Thereafter, the Board of Directors shall hold at least one (1) regular meeting
in each calendar year. Upon the written
<!-- page 10 -->
request of two (2) or more of the directors of the Joint Venture

Page 15

Company specifying the matters to be discussed, the Chairman of the Board shall within thirty (30)
days of receipt thereof convene an interim meeting of the Board of Directors. Meetings shall be held
at the registered address of the Joint Venture Company or such other address in China or abroad as
may be agreed by the Chairman of the Board and the Vice-Chairman of the Board. The Chairman of the
Board shall set the agenda for Board meetings after consultation with the Vice-Chairman of the Board
and the Chairman shall be responsible for convening and presiding over such meetings. Board meetings
may be attended by directors in person or by telephone, video conference or by proxy.

Article 59

Five (5) directors present in person or by proxy shall constitute a quorum for all meetings of the
Board of Directors. If at any properly convened meeting, no quorum is constituted because less than
five (5) directors are present in person or by proxy, then the Chairman of the Board may call
another meeting with seven (7) days notice to each director. All directors receiving notice of such
second meeting shall be deemed to be present at such meeting.

Article 60

If a director is unable to attend a Board of Directors meeting, he may issue a proxy and entrust a
representative to attend the meeting on his behalf. The representative so entrusted shall have the
same rights and powers as the director who entrusted him. One person may represent more than one
director by proxy.

Article 61

The Board of Directors will cause complete and accurate minutes (in both English and Chinese) to be
kept of all Board meetings. The Chinese and English text of all resolutions to be adopted by the
Board of Directors at Board meetings shall be agreed by the directors at the Board meeting and
recorded by the secretary appointed for the meeting, and those members approving the resolutions
shall sign such records. Draft minutes of all meetings of the Board of Directors shall be
distributed to all the directors as soon as practicable after each meeting but not later than thirty
(30) days from the date of such meeting. The final minutes shall be completed by the Chairman and
the Vice-Chairman and distributed to each director and each Party not later than sixty (60) days
after the relevant meeting. The Joint Venture Company shall maintain a file of all Board meeting
minutes and make the same freely available to the Parties and their authorized representatives.

Article 62

The Board of Directors may adopt any resolution without a meeting if all of the directors then
holding office consent in writing to such action. Such written consent may be signed by the
directors in different counterparts, shall be filed with the minutes of the Board of Directors
proceedings and shall have the same force and effect as a unanimous vote of the directors present at
a duly constituted meeting of the Board.

Page 16

Article 63

Directors shall serve without any remuneration, but all reasonable costs incurred by the directors
in attending Board meetings (including but not limited to travel expenses) shall be borne by the
Joint Venture Company.

CHAPTER 11 BUSINESS MANAGEMENT ORGANISATION

Article 64

The Joint Venture Company shall establish a business management organization to be in change of the
day-today operation and management of the Joint Venture Company.

Article 65

The Joint Venture Company's business management organization shall be under the leadership of a CEO,
who shall report directly to the Board of Directors. In addition to the CEO, the Joint Venture
Company shall have a Deputy CEO, Chief Financial Officer, Director of Sales, Director of Human
Resources, Director of Manufacturing, and Director of Research and Development (together with the
CEO, the "Senior Management Personnel"). The CEO shall be in charge of the day-to-day operation and
management of the Joint Venture Company. The Deputy CEO shall assist the CEO in his work and shall
report to the CEO. Other department directors shall report directly to the CEO.

Article 66
<!-- page 11 -->
The CEO shall be nominated by Party B, and the Deputy CEO shall be nominated by Party A The Chief
Financial Officer shall be nominated by Party A, and an Assistant Financial Officer may be nominated
by Party B. The Chief Financial Officer must consult with the Assistant Financial Officer, if any,
on all important financial matters. Each officer nominated by a party or parties in accordance with
this paragraph shall be appointed by the Board of Directors. The other Management Personnel shall be
nominated by the CEO and appointed by the Board of Directors. The Board may dismiss any Management
Personnel. All replacements for any of the Management Personnel, whether by reason of the
retirement, resignation, disability or death of a manager or of the removal of a manager by the
Board of Directors or by the Party which nominated him, shall be nominated and appointed in the same
manner as the original appointee. Other details of management shall be decided by the CEO.

Article 67

The CEO shall be in charge of the day-to-day operation and management of the Joint Venture Company
and shall carry out all matters entrusted by the Board of Directors. The Deputy CEO shall assist the
CEO in his work and shall report to the CEO.

Page 17

Article 68

The CEO, Deputy CEO and all other Management Personnel shall perform their duties on a full-time
basis and shall not concurrently serve as a manager, an employee or a consultant of any other
company or enterprise, nor shall they serve as a director of, or hold any interest in, any company
or enterprise that competes with the Joint Venture Company.

Article 69

The Joint Venture Company's basic departmental structure and other management positions reporting
directly to the CEO shall be approved by the Board of Directors based on proposals formulated by the
CEO. The details of the Joint Venture Company's organizational structure and all other employment
positions shall be determined by the CEO.

Article 70

Both Chinese and English shall be used concurrently as the management languages of the Joint Venture
Company.

Article 71

In case of graft or serious dereliction of duty on the part of the CEO, Deputy CEO and other
management personnel of the Joint Venture Company, the Board of Directors shall have the power to
dismiss such individuals at any time pursuant to the provisions of relevant PRC law.

CHAPTER 12 SITE FOR JOINT VENTURE COMPANY

Article 72

Party A confirms that it will procure for use of the Joint Venture Company a site to be further
identified and agreed by the Parties. The site shall be in the Baoding High Technology Development
Zone, shall have granted land use rights, and shall have utilities that may be directly connected by
the Joint Venture Company at the site.

The Parties shall further agree on the size and standards of the building to be constructed to meet
the Joint Venture Company's operating needs.

CHAPTER 13 PURCHASE OF EQUIPMENT AND MATERIALS

Article 73

Page 18

The Joint Venture Company has the right to purchase equipment, machinery, raw materials, etc.
required for the Joint Venture Company's production and operations. In its purchase of required
equipment, instruments, raw materials, fuel, parts, and means of transportation etc., the Joint
Venture Company shall give first priority to purchase of same in China where relevant purchase terms
conditions are the same or more favorable.

Article 74

The Joint Venture Company may entrust Party A or Party B to purchase the items listed in the above
article. Any party so entrusted shall use its best endeavors to accomplish the purpose of the
entrustment. The price shall be fair and reasonable. The party so entrusted shall follow the
internationally accepted procedures to purchase materials when their quantity is large. The other
party and the Joint Venture Company shall supervise the action of purchasing.
<!-- page 12 -->
Article 75

A list of equipment that the Joint Venture Company intends to import as Party B's capital
contribution and as purchase from Party B for the commencement of the Joint Venture Company's
production and operations is set forth as Appendix 3 to this Contract.

CHAPTER 14 LABOR MANAGEMENT

Article 76

Matters relating to the recruitment, wages, insurance, welfare, dismissal of the staff and workers
of the Joint Venture Company shall be handled in accordance with the LABOR LAW OF THE PEOPLE'S
REPUBLIC OF CHINA and the REGULATIONS OF THE PEOPLE'S REPUBLIC OF CHINA ON LABOR MANAGEMENT IN
FOREIGN INVESTMENT ENTERPRISES and related PRC regulations. The Joint Venture Company's internal
labor policies shall be established pursuant to relevant PRC laws and regulations, and approved by
the Board of Directors.

Article 77

The Joint Venture Company shall adopt a labor contract system. The wages, welfare, labor insurance
and other rights and obligations of working personnel and Management Personnel shall be regulated
through individual or group labor contracts.

Article 78

Expatriate management personnel and Chinese management personnel in the same position shall receive
equivalent salary and benefits.

Article 79

Employees will be selected according to their professional qualifications, language abilities,
individual characteristics and working experience. The specific number and qualifications of the
Working Personnel shall be determined by the CEO in accordance with the operating needs of the

Page 19

Joint Venture Company. All employees hired by the Joint Venture Company must complete satisfactorily
a six-month probationary period of employment before they will be considered regular employees of
the Joint Venture Company.

Article 80

Except as provided in Article 78, expatriate personnel and Chinese personnel in the same position
shall be treated equally and without discrimination.

Article 81

Working Personnel shall have the right to establish a labor union in accordance with the LABOR UNION
LAW OF THE PEOPLE'S REPUBLIC OF CHINA and develop activities pursuant to related regulations. In
accordance with relevant PRC regulations, the Joint Venture Company shall allot each month two
percent (2%) of the total amount of the real wages received by the Joint Venture Company staff and
workers for payment into a labor union fund, such payment to be an expense of the Joint Venture
Company. The labor union may use these funds in accordance with the relevant control measures for
labor union funds formulated by the All China Federation of Labor Unions.

CHAPTER 15 FINANCIAL AFFAIRS AND ACCOUNTING

Article 82

The Chief Financial Officer and Assistant Financial Officer of the Joint Venture Company, under the
leadership of the CEO, shall be responsible for the financial management of the Joint Venture
Company. The CEO, the Chief Financial Officer and Assistant Financial Officer shall prepare the
Joint Venture Company's accounting system and procedures in accordance with the relevant PRC laws
and regulations, and submit the same to the Board of Directors for adoption.

Article 83

The Joint Venture Company shall adopt Renminbi as its bookkeeping base currency, but may also adopt
United States Dollars or other foreign currencies as supplementary bookkeeping currencies. The debit
and credit method, as well as the accrual basis of accounting, shall be adopted as the methods and
principles for keeping accounts.

Article 84

The Joint Venture Company shall adopt the calendar year as its fiscal year. The Joint Venture
Company's first fiscal year shall commence on the date that the Joint Venture Company receives a
business license and shall end on the immediately succeeding December 31.

Article 85

All accounting records, vouchers, books and statements of the Joint Venture Company must be made and
kept in Chinese. All financial statements and reports
<!-- page 13 -->
of the Joint Venture Company shall also be made and kept in English.

Page 20

Article 86

For the purpose of preparing the Joint Venture Company's accounts and statements, calculation of
profits to be distributed to the Parties, and for any other purposes where it may be necessary to
effect a currency conversion, such conversion shall be made using the median rate for buying and
selling for such currency announced by the People's Bank of China on the date of actual receipt or
payment by the Joint Venture Company.

Article 87

The Parties shall have full and equal access to the Joint Venture Company's accounts, which shall be
kept at the legal address of the Joint Venture Company. In addition, each Party at its own expense
and upon advance notice to the Joint Venture Company may appoint an accountant (which may be either
an accountant registered abroad or registered in China), to audit the accounts of the Joint Venture
Company on behalf of such Party. Reasonable access to the Joint Venture Company's financial records
shall be given to such auditor and such auditor shall keep confidential all documents under his
auditing.

Article 88

The Joint Venture Company shall furnish to the Parties unaudited financial reports on a monthly and
quarterly basis so that they may continuously be informed about the Joint Venture Company's
financial performance.

Article 89

An accountant registered in China and independent of any Party shall be engaged by and at the
expense of the Joint Venture Company as its auditor to examine and verify the Joint Venture
Company's annual financial statements and report. The Joint Venture Company shall submit to the
Parties an annual statement of final accounts (including the audited profit and loss statement and
the balance sheet for the fiscal year) after the end of the fiscal year, together with the audit
report of the Chinese registered accountant.

Article 90

The Joint Venture Company shall separately open foreign exchange accounts and Renminbi accounts at
banks within China approved by the State Administration of Exchange Control. Following approval by
the State Administration of Exchange Control, the Joint Venture Company may also open foreign
exchange bank accounts outside China. The Joint Venture Company shall apply for and maintain a
Foreign Exchange Registration Certificate in accordance with applicable legal requirements. The
Joint Venture Company shall abide by the regulations of the PRC concerning foreign exchange control
and handle foreign exchange transaction pursuant to such regulations.

Article 91

After the payment of income taxes by the Joint Venture Company, the Board of Directors will
determine the annual allocations to each of the Three Funds from the after-tax net profits. The sum

Page 21

of the allocations to the Three Funds for any fiscal year shall be determined by the Board and shall
not exceed ten percent (10%) of the after-tax profit for that year so as to ensure the Joint Venture
Company's smooth operation.

Article 92

The distribution of the Joint Venture Company's after-tax profits to the Parties shall be carried
out according to related laws and the Joint Venture Company's actual conditions. The Board of
Directors shall once every year by a formally adopted resolution decide the amount of after-tax
profit of the Joint Venture Company (after allocations to the Three Funds) to be retained in the
Joint Venture Company for expanding its production and operations and the amount to be distributed
to the Parties in proportion to their respective shares of the Joint Venture Company's registered
capital. All remittances of profits and other payments out of China to Party B shall be made to a
foreign bank account designated by Party B in United States Dollars or other freely convertible
foreign currencies in accordance with the foreign exchange regulations of China.

CHAPTER 16 TAXATION AND INSURANCE

Article 93

The Joint Venture Company shall pay all taxes and duties required under the national and local laws
and regulations of China. The Joint Venture Company's Chinese and expatriate personnel shall pay
individual income tax in accordance with the INDIVIDUAL INCOME TAX LAW OF THE PEOPLE'S REPUBLIC OF
CHINA.
<!-- page 14 -->
Article 94

The Joint Venture Company, at its own expense, shall take out and maintain at all times during the
Contract Term with insurance companies insurance against loss or damage by fire, natural disasters
and other risks of types and in amounts as may be recommended by the CEO and decided by the Board of
Directors. The property, transport and other items of insurance of the Joint Venture Company will be
denominated in Chinese and foreign currencies, as appropriate.

Article 95

The Joint Venture Company shall take out the required insurance from an insurance company or
organization permitted by Chinese laws and regulations to provide such insurance.

CHAPTER 17 CONFIDENTIALITY

Article 96

Prior to and during the Contract Term, each Party has disclosed or may disclose to the other Party,
including without limitation through technology transfer or license agreements, confidential and
proprietary information and materials concerning their respective businesses, financial condition,
proprietary technology, research and development, and other confidential matters. Furthermore,

Page 22

during the Contract Term, the Parties may obtain such confidential and proprietary information
concerning the Joint Venture Company and the Joint Venture Company may obtain such confidential and
proprietary information of the Parties. Each of the Parties and the Joint Venture Company receiving
all such information as aforesaid (hereinafter referred to "Confidential Information") shall, during
the Contract Term, or during the term of the Joint Venture Company and for two (2) years after the
early termination or dissolution of the Joint Venture Company prior to the expiration of the
Contract Term:

(1) maintain the confidentiality of such Confidential Information; and

(2) not disclose it to any person or entity, except to their respective employees who need to know
such Confidential Information to perform their work responsibilities.

The above provisions shall not apply to Confidential Information that:

(1) can be proved to have been known by the receiving party by written records made prior to
disclosure by the disclosing party;

(2) is or becomes public knowledge otherwise than through the receiving party's breach of this
Contract;

(3) was obtained by the receiving party from a Third Party having no obligation of confidentiality
with respect to such Confidential Information; or

(4) is required by order of any competent court or governmental authority to be disclosed.

Each Party shall advise its directors, senior staff, and other employees receiving such Confidential
Information of the existence of and the importance of complying with the obligations set forth in
this Article.

Article 97

If required by any Party, the Joint Venture Company shall execute a separate secrecy agreement with
provisions similar to those set out above with respect to Confidential Information obtained by the
Joint Venture Company from such Party or its Affiliates.

Article 98

Each of the Parties and the Joint Venture Company shall formulate rules and regulations to cause its
directors, senior staff and other employees, and those of their Affiliates, also to comply with the
confidentiality obligations set forth in this Chapter 17. All directors, managers and other
employees of the Joint Venture Company shall be required to sign a confidentiality undertaking in a
form acceptable to all Parties.

Page 23

Article 99

If any Party or the Joint Venture Company breaches the provisions of this Chapter 17, it shall be
liable for damages accrued to the other Party or the
<!-- page 15 -->
Joint Venture Company as a result of such breach. The payment of damages shall be without prejudice
to any other rights or remedies accrued at the date of such breach.

Article 100

This Chapter 17 and the obligations and benefits hereunder shall survive the expiration or early
termination of this Contract and shall remain in effect for the periods stated herein,
notwithstanding the dissolution or liquidation of the Joint Venture Company.

CHAPTER 18 ENVIRONMENTAL PROTECTION AND COMPLIANCE

Article 101

Party B warrants that to the best of its knowledge those products that are properly manufactured
pursuant to the terms of the Contract for Technology Investment and other written instructions from
Party B shall comply with those relevant PRC environmental laws and regulations existing and in
effect as of the date of the Parties' signature of this Contract.

Article 102

Following the establishment of the Joint Venture Company, if PRC environmental laws and regulations
are amended such that the rights or interests of the Joint Venture Company or either Party's
interest therein are affected, then the Parties shall discuss in good faith regarding a suitable
approach to address such regulatory change, consistent with Article 119 hereto.

CHAPTER 19 CONTRACT TERM

Article 103

The Contract Term shall extend for a period of fifty (50) years. The date that the Business License
is issued is the Establishment Date of the Joint Venture Company. Upon the agreement of all Parties
and the unanimous consent of the Board of Directors, an application to extend the Contract Term may
be made to the Examination and Approval Authority no less than six (6) months prior to the
expiration of the Contract Term.

Page 24

CHAPTER 20 TERMINATION AND LIQUIDATION

Article 104

Each Party shall have the right to terminate this Contract prior to the expiration of the Contract
Term by written notice to the other Party if any of the following events occur:

(1) in the event that either party fails to make its capital contribution, in whole or in part,
within [90] days of the due date, or in the event that any of the conditions precedent set forth in
Article 34 of this Contract have not been satisfied or waived within [120] days of the date on which
this Contract is signed by the parties;

(2) the other Party materially breaches this Contract or materially violates the Articles of
Association, and such breach or violation is not cured within sixty (60) days of written notice to
the breaching/violating Party;

(3) the Joint Venture Company or the other Party becomes bankrupt, or is the subject of proceedings
for liquidation or dissolution, or ceases to carry on business, or becomes unable to pay its debts
as they come due;

(4) the other Party transfers all or any part of its share of the Joint Venture Company's registered
capital in violation of the provisions of this Contract;

(5) any government authority having authority over any Party requires any provision of this Contract
or the Articles of Association to be revised in such a way as to cause significant adverse
consequences to the Joint Venture Company or any Party;

(6) the conditions or consequences of Force Majeure prevail with the result of a major impairment to
the functioning of the Joint Venture Company for a period in excess of six (6) months and the
Parties have been unable to find an equitable solution; or

(7) the Parties cannot implement the economic adjustment described in Article 119.

Article 105

If any Party gives notice to terminate this Contract pursuant to Article 104, the Parties shall
endeavour to resolve the problem through negotiation and agreement. If, within thirty (30) days of
receipt of such notice, the Parties have not agreed in writing to continue this Contract, then each
Party and the directors appointed by each Party shall be deemed to have agreed to terminate
<!-- page 16 -->
this Contract and dissolve the Joint Venture Company. An application for the same shall forthwith be
submitted to the Examination and Approval Authority.

Article 106

Following an application to dissolve the Joint Venture Company pursuant to Article 105, the Board of
Directors shall forthwith appoint a liquidation committee which shall have the power to represent
the Joint Venture Company in all legal matters. The liquidation committee shall value and liquidate

Page 25

the Joint Venture Company's assets in accordance with the applicable Chinese laws and regulations
and the principles set forth herein.

Article 107

The liquidation committee shall be made up of three (3) members, of whom one (1) member shall be
nominated by Party A and two (2) members shall be nominated by Party B. Members of the liquidation
committee may, but need not be, directors or senior employees of the Joint Venture Company. The
liquidation committee may engage a lawyer and an accountant registered in China to assist the
liquidation committee. When permitted by Chinese law, any Party may also appoint professional
advisors to assist the liquidation committee. The Board of Directors shall report the formation of
the liquidation committee to the department in charge of the Joint Venture Company.

Article 108

The liquidation committee shall conduct a thorough examination of the Joint Venture Company's assets
and liabilities, on the basis of which it shall develop a liquidation plan, which, if approved by
the Board of Directors, shall be executed under the liquidation committee's supervision.

Article 109

In developing and executing the liquidation plan, the liquidation committee shall use every effort
to obtain the highest possible price for the Joint Venture Company's assets and, subject to
compliance with PRC foreign exchange control regulations, sell such assets for United States Dollars
or other freely convertible foreign currencies.

Article 110

The liquidation expenses, including remuneration to members and the lawyers and accountants
assisting the liquidation committee, shall be paid out of the Joint Venture Company's assets in
priority to the claims of other creditors.

Article 111

After the liquidation and division of the Joint Venture Company's assets and the settlement of all
of its outstanding debts, the balance shall be paid over to the Parties in proportion to their
respective shares of the registered capital of the Joint Venture Company.

Article 112

On completion of all liquidation work, the liquidation committee shall provide a liquidation
completion report approved by the Board of Directors to the Examination and Approval Authority, hand
in the Joint Venture Company's business license to the original registration authority and complete
all other formalities for nullifying the Joint Venture Company's registration. Party B shall have a
right to obtain copies of all of the Joint Venture Company's accounting books and other documents at
their own expense but the originals thereof shall be left in the care of Party A.

Page 26

CHAPTER 21 BREACH OF CONTRACT

Article 113

In the event that a breach of contract committed by a Party to this Contract results in the non-
performance of or inability to perform this Contract or its appendices fully, the liabilities
arising from the breach of this contract or its Appendices shall be borne by the Party in breach. In
the event that a breach of contract is committed by more than one Party, each such Party shall bear
its individual share of the liabilities arising from the breach of contract.

CHAPTER 22 FORCE MAJEURE

Article 114

"Force Majeure" shall mean all events which were unforeseeable at the time this Contract was signed,
the occurrence and consequences of which cannot be avoided or overcome, and which arise after the
Effective Date and prevent total or
<!-- page 17 -->
partial performance by any Party./ Such events shall include earthquakes, typhoons, flood, fire, war
and any other instances which cannot be foreseen, avoided or overcome, including instances which are
accepted as force majeure in general international commercial practice.

Article 115

If an event of Force Majeure occurs, a Party's obligations under this Contract affected by such an
event shall be suspended during the period of delay caused by the Force Majeure and shall be
automatically extended, without penalty, for a period equal to such suspension. The Party claiming
Force Majeure shall promptly inform the other Party in writing and shall furnish within fifteen (15)
days thereafter sufficient evidence of the occurrence and duration of such Force Majeure. The Party
claiming Force Majeure shall also use all reasonable endeavours to terminate the Force Majeure. In
the event of Force Majeure, the Parties shall immediately consult with each other in order to find
an equitable solution and shall use all reasonable endeavours to minimize the consequences of such
Force Majeure.

CHAPTER 23 SETTLEMENT OF DISPUTES

Article 116

In the event a dispute arises in connection with the interpretation or implementation of this
Contract, the Parties shall attempt in the first instance to resolve such dispute through friendly
consultations. If the dispute is not resolved through consultations within sixty (60) days after one
Party has served a written notice on the other Party requesting the commencement of consultations,
then any Party may refer the dispute to arbitration in Singapore under the auspices of the Singapore
International Arbitration Centre in accordance with the rules of that Centre for the time being in
force and the provisions of Article 117 of this Contract.

Page 27

Article 117

There shall be three (3) arbitrators, one (1) of whom shall be appointed by Party A, one (1) of whom
shall be appointed by Party B, and one (1) of whom shall be appointed by the arbitration tribunal.
The arbitration award shall be final and binding on the Parties. When any dispute occurs and when
any dispute is under arbitration, except for the matters under dispute, the Parties shall continue
to exercise their other respective rights and fulfil their other respective obligations under this
Contract. In any arbitration proceeding, any legal proceeding to enforce any arbitration award and
in any legal action between the Parties pursuant to or relating to this Contract, each Party
expressly waives the defense of sovereign immunity and any other defence based on the fact or
allegation that it is an agency or instrumentality of a sovereign state.

CHAPTER 24 APPLICABLE LAW

Article 118

The formation, validity, interpretation and implementation of this Contract, and any disputes
arising under this Contract, shall be governed by the published laws of the People's Republic of
China. If there is no published law in China governing a particular matter relating to this
Contract, reference shall be made to general international commercial practices.

Article 119

If one Party's economic benefits are adversely and materially affected by the promulgation of any
new laws, rules or regulations of China or the amendment or interpretation of any existing laws,
rules or regulations of China after the Effective Date of this Contract, the Parties shall promptly
consult with each other and use their best endeavours to implement any adjustments necessary to
maintain each Party's economic benefits derived from this Contract on a basis no less favourable
than the economic benefits it would have derived if such laws, rules or regulations had not been
promulgated or amended or so interpreted. If it is not possible to implement such adjustments, a
Party may terminate this Contract pursuant to Chapter 20 of this Contract.

CHAPTER 25 MISCELLANEOUS PROVISIONS

Article 120

To the extent permitted by Chinese law, failure or delay on the part of any Party hereto to exercise
a right under this Contract and the Appendices hereto shall not operate as a waiver thereof; nor
shall any single or partial exercise of a right preclude any other future exercise thereof.

Article 121

Except as otherwise provided herein, this Contract may not be assigned in whole or in part by any
Party without the prior written consent of the other Party and the approval of the Examination and
Approval Authority.

Page 28
<!-- page 18 -->
Article 122

This Contract is made for the benefit of Party A and Party B and their respective lawful successors
and assignees and is legally binding on them. This Contract may not be amended orally, and any
amendment hereto must be agreed to in a written instrument signed by all of the Parties and approved
by the Examination and Approval Authority before taking effect.

Article 123

Subject to the provisions of Article 118 hereof, the invalidity of any provision of this Contract
shall not affect the validity of any other provision of this Contract.

Article 124

This Contract is written and signed in the Chinese language in six (6) originals and in the English
language in six (6) originals. Both language versions shall be equally valid and in the event of any
discrepancy between the two versions, the wording in dispute shall be interpreted in accordance with
the purpose of this Contract.

Article 125

This Contract and the Appendices hereto constitute the entire agreement between the Parties with
respect to the subject matter of this Contract and supersede all prior discussions, negotiations and
agreements between them with respect to the subject matter of this Contract. In the event of any
conflict between the terms and provisions of this Contract and the Articles of Association, the
terms and provisions of this Contract shall prevail.

Article 126

This Contract shall take effect after it is approved by the Examination and Approval Authority.

Article 127

Any notice or written communication provided for in this Contract from one Party to the other Party
or to the Joint Venture Company shall be made in writing in Chinese and English and may be sent
telegram, telex or facsimile transmission, or by courier service delivered letter or by post. Any
communication sent by facsimile transmission or e-mail shall be confirmed by courier service
delivered letter or by post. The date of receipt of a notice or communication hereunder shall be
deemed to be fourteen (14) days after the letter is given to the courier service or postal service,
or one (1) working day after sending in the case of facsimile or e-mail, provided it is evidenced by
a confirmation receipt and the confirmation letter is sent by courier delivered letter or post. All
notices and communications shall be sent to the appropriate address set forth below, until the same
is changed by notice given in writing to the other Party.

PARTY A:

Fengfan Group Limited Liability Company 8 Fu Chang Road,

Page 29

Baoding City, Hebei Province, People's Republic of China

Facsimile No: (0312) 3236562 Telephone No: (0312) 322 5931 E-mail:

Representative: Chen Mengli

PARTY B:

Valence Technology, Inc. 301 Conestoga Way Henderson Nevada 89015 U.S.A.

Facsimile No: (702) 558-1310 Telephone No: (702) 558-1073 Attention: General Counsel

E-mail:

THE JOINT VENTURE COMPANY:

Fengfan-Valence Battery Company, Ltd.Baoding City High and New Technology Development Zone, Baoding
City, Hebei Province People's Republic of China
<!-- page 19 -->
Attention: CEO

E-mail:

Article 128

The Appendices hereto listed below are made an integral part of this Contract and are equally
binding with these the provisions of this Contract:

Appendix 1 Schedule for Capital Contributions

Appendix 2 Contract for Technology Investment

Appendix 3 Contract for Equipment Investment and Purchase

Appendix 4 Export Sales Contract

Page 30

IN WITNESS WHEREOF, the duly authorized representative of each Party has signed this Contract in
Baoding, People's Republic of China on November 8, 2002.

FENGFAN GROUP LIMITED VALENCE TECHNOLOGY, INC. LIABILITY COMPANY

By: /S/ CHEN MENGLI By: /S/ DEEPAK SWAMY ----------------------------
--------------------------------

Name: CHEN MENGLI Name: DEEPAK SWAMY

Title: CHAIRMAN OF THE BOARD Title: VICE PRESIDENT OF LICENSING OPERATIONS

Nationality: P.R. CHINA Nationality: AMERICAN

Page 31
