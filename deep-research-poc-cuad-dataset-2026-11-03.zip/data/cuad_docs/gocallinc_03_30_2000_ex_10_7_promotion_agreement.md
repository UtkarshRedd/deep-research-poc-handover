<!-- page 1 -->
# Promotion Agreement
| Field | Value |
|---|---|
| Document Type | Promotion Agreement |
| Agreement Date | 1999-03-12 |
| Parties | Go Call, Inc. ("Go Call"); PageMaster Corporation |
| Source | CUAD v1 / GOCALLINC_03_30_2000-EX-10.7-Promotion Agreement |

Promotion Agreement Between PageMaster Corporation and Go Call, Inc.

AGREEMENT ---------

This Promotion Agreement (herein "Agreement") dated March 12,1999, by and between Go Call, Inc.
(herein "Go Call") located at 15 Queen Street East, Cambridge Ontario, Canada N3C2A7 and PageMaster
Corporation located at 100 E. Thousand Oaks Blvd. Suite 297, Thousand Oaks, CA 91360, shall set
forth the Terms and conditions pursuant to which Go Call and PageMaster Corporation shall create a
promotion as more fully described below.

WHEREAS, Go Call seeks to increase its sales and website activity; and WHEREAS. PageMaster
Corporation seeks to promote the contracting of paging service to clients; NOW THEREFORE, Go Call
and PageMaster Corporation in consideration of the mutual obligations set forth herein and other
good and valuable consideration, the receipt and sufficiency of which the parties acknowledge,
hereby agree as follows:

1. Description of the Promotion ----------------------------

PageMaster Corporation in conjunction with Go Call, shall offer free new Motorola "Wordline
Alphanumeric" (or equal) pagers with no activation fee to all customers responding to this promotion
who purchase twelve (12) months of numeric paging and airtime products and services from PageMaster
Corporation ("Purchase Customers").

2. Consumer Cost Description -------------------------

Each Purchase Customer will be required to purchase twelve months of local numeric airtime at a rate
of $10.33 per month through a designated nationwide airtime provider, prepaid in advance. The
purchased airtime shall be non-refundable to the consumer. Additionally, Purchase Customers will be
required to pay for shipping and handling costs and applicable sales taxes based on their locations.

3. Term ----

This promotion shall begin on June 1,1999 and shall terminate June 1, 2000 (herein "Term") This term
shall be extended for a 1 year period provided 3000 pagers per month are distributed to Purchase
customers.

4. Responsibilities of PageMaster Corporation ------------------------------------------

PageMaster Corporation shall be responsible for providing the following:

a. For Purchase Customers to participate in the promotion, PageMaster Corporation shall establish
and maintain a toll-free telephone number for this promotion beginning June 1,1999 and continuing
until September 1, 2000 unless otherwise requested by Go Call and agreed upon by PageMaster
Corporation.

b. PageMaster Corporation shall provide a minimum of 100,000 up to 500,000 pagers for the
fulfillment of this promotion to all Purchase Customers who prepay their annual airtime.

c. PageMaster Corporation shall be responsible for all fulfillment obligations of this promotion
relating to paging services, including, but not limited to, timely delivery of pagers, paging
services, defective goods handling, subcontracting, deadlines, and handling of consumer and
regulatory inquiries and complaints.

d. PageMaster Corporation will contract with a nationwide airtime service provider to fulfill and to
ship Purchasing Customer orders direct to the Purchase Customers to fulfill this promotion in a
timely manner. PageMaster Corporation has chosen for the purpose of this promotion, MetroCall Inc.
to provide pager and airtime services where the nationwide airtime service provider has the
facilities and the requisite governmental authority to provide such services. All Purchase Customers
shall become customers of the nationwide airtime service provider. The nationwide airtime service
provider shall be allowed to market additional pagers arid enhanced services to all Purchase
Customers, and to charge for over-calls with respect to any account with a Purchase Customer. The
nationwide airtime service provider shall be able to discontinue or terminate service to any
Purchase Customer in accordance with the terms of the contract between the nationwide airtime
service provider and the Purchase Customer. Notwithstanding the foregoing, PageMaster Corporation
shall remain solely responsible for the fulfillment of all services and obligations set forth in
this Agreement.

e. PageMaster Corporation shall not engage in the same or similar promotion with any other On-Line
Casinos from June 1, 1999 through June 1, 2000.
<!-- page 2 -->
f. PageMaster Corporation will provide at no charge programming software that will allow Go Call to
broadcast any and all messages of 125 characters or less to all Go Call consumers who have redeemed
pagers on this promotion.

5. Responsibilities of Go Call ---------------------------

a. Go Call shall prepare and distribute at its own expense, all advertising materials to be used for
this promotion.

b. Go Call, shall submit in advance, all artwork and advertising to PageMaster Corporation for
approval as provided in Paragraph 8.

c. Go Call shall not engage in the same or similar promotions during the Term of this Agreement with
any other entity providing paging services, equipment or other related products and services.

6. Payment Made As Deposit On Pagers ---------------------------------

Upon the execution of this Agreement, Go Call shall forward to PageMaster Corporation a deposit in
the sum of $100,000.00 to secure the availability of 100,000 pagers to all Purchase Customers who
prepay their annual airtime for this promotion. The deposit is non-refundable except as follows:

a. PageMaster Corporation shall refund to Go Call, $1.00 per pager on all pagers delivered to
Purchase Customers pursuant to this promotion (net return) up to the maximum refund of $100,000.00.

b. On the last day of each month, the refund of Go Call's portion of the deposit shall be calculated
by PageMaster Corporation for the &bbsp; prior month and will be forwarded to Go Call by check,
along with an extended accounting of all pagers and customers until September 1, 2000, unless
otherwise instructed by Go Call. Go Call, upon ten (10) days written notice, shall have the right to
examine the books and records of PageMaster Corporation to verify the sales resulting from this
promotion. Such examination shall be made at the regular place of business of PageMaster Corporation
where such books and records are maintained during normal business hours and shall be conducted at
Go Call's expense by a certified public accountant or other Go Call executive so designated by Go
Call.

7. Co-Op Marketing Funds ---------------------

PageMaster Corporation shall pay to Go Call, Co-Op Marketing funds for the promotion. PageMaster
Corporation will pay Go Call $3.00 per pager (beginning with pager # 1) and 5% of all airtime
renewal revenue for each pager redeemed for this promotion consistent with the terms of paragraph 6b
of this Agreement.

8. Representation and Warranties -----------------------------

PageMaster Corporation warrants and represents that it has a license to advertise and use the
trademarks, logos, etc. of Motorola, Inc., PageMaster Promotions and such other third parties as may
be necessary to advertise this promotion. At least sixty (60) days prior to the commencement of the
promotion, PageMaster Corporation in its sole discretion shall have the unconditional right to
approve the accuracy of the description of the pager promotion and use of corporate logos and
photographs and descriptions of products and services provided by designated airtime carriers or any
third parties participating in the promotion; in the event of disapproval, Go Call shall not proceed
with the promotion until the revised artwork or presentation is subsequently approved by PageMaster
Corporation in writing. Upon termination or expiration of this Agreement, Go Call agrees not to use
or advertise any trademarks, logos or other property rights of PageMaster Corporation or any third
parties participating in the promotion. Any advertising, artwork, presentation, or other promotional
activities (collectively "Advertising") concerning the pager Promotion not pre-approved in writing
by PageMaster Corporation shall be deemed to be unauthorized by PageMaster Corporation and shall
constitute a breach of this Agreement. In addition to the duty to indemnify PageMaster Corporation
as provided in Paragraph 9 hereof, Go Call shall also have the duty to indemnify Motorola, Inc. or
any affiliated entity from and against any and all claims, expense, suits or demands arising from
such unauthorized Advertising by Go Call, or its agent, affiliate, licensee, franchisee or any other
third party.

9. Indemnity ---------

Each party shall indemnify and hold harmless the other from any loss or damages, including
reasonable attorneys' fees incurred by the other because of claims, suits or demands based on
personal injury, death or property damage or third party claims, suits or demands of any kind to the
extent such loss or damage is caused by or results from the negligent or willful acts or omissions
of the other or its employees or agents, including but not limited to the unauthorized use of the
trademark, logos, or other property of third parties without the consent and approval of PageMaster
Corporation. PageMaster Corporation's participation in the promotion does not constitute an
endorsement of the products or services of Go Call nor does Go Call's participation in the promotion
constitute an endorsement of PageMaster Corporations or any third party's products or services.
<!-- page 3 -->
10. Force Majeure -------------

Neither party will be responsible for any delay or failure in performance of any part of&bbsp;this
Agreement to the extent that such delay or failure is caused by any event beyond its control, which
may include, but not be limited to, fire, flood, explosion, war, strike, embargo, government
requirement, civil or military authority, and acts of God ("Conditions"). If any such Condition
occurs, the party delayed or unable to perform shall promptly give notice to the other party and, if
such Condition remains at the end of thirty (30) days thereafter, the party affected by the other
party's delay or inability to perform may elect to terminate or suspend this Agreement or part
thereof, and resume performance of this Agreement once the Condition ceases, with an option for the
affected party to extend the period of this Agreement up to the length of time the Condition
endured. PageMaster Corporation make no warranties, either express or implied, concerning the pagers
or the transmission of pages by the airtime service provider, including warranties of
merchantability or fitness for particular purpose. The parties agree that

PageMaster Corporation shall not be liable for service interruptions in the telecommunications
industry, capacity constraints or related problems, or for any act or omission of any other entity
furnishing products or services to PageMaster Corporation. PageMaster Corporations' liability shall
in no event exceed an amount equivalent to the amounts received by PageMaster Corporation hereunder.

11. Choice Of Law -------------

This Agreement will be governed by and construed in accordance with the laws of the State of
California, exclusive of conflicts of law principles, and will, to the maximum extent practicable,
be deemed to call for performance in Los Angeles County, California. Los Angeles County, California
shall be the sole and exclusive venue for any litigation or dispute resolution relating to or
arising out of the Agreement. To seek or receive indemnification hereunder (i) the party seeking
indemnification must have properly notified the other party of any claim or litigation of which it
is aware to which the indemnification relates; and the party seeking indemnification must have
afforded the other the opportunity to participate in any compromise, settlement, litigation or other
resolution or disposition of such claim or litigation.

12. Dispute Resolution ------------------

a. The parties desire to resolve disputes arising out of this Agreement without litigation.
Accordingly, except for an action seeking a temporary restraining order or injunction related to the
purposes of this Agreement, or a suit to compel compliance with this dispute resolution process, the
parties agree to use the following alternative dispute resolution procedure as their sole remedy
with respect to any controversy or claim arising out of or relating to this Agreement or its breach.

b. At the written request of a party, each party shall appoint a knowledgeable, responsible
representative to meet and negotiate in good faith to resolve any dispute arising under this
Agreement. The parties intend that these negotiations be conducted by non-lawyer, business
representatives. The discussions shall be left to the discretion of the representatives. Upon
agreement, the representatives may utilize other alternative dispute resolution procedures such as
mediation to assist in the negotiations. Discussions and correspondence among the representatives
for purposes of these negotiations shall be treated as confidential information developed for
purposes of settlement, exempt from discovery and production, which shall not be admissible in the
arbitration described below or in any lawsuit without the concurrence of all parties. Documents
identified in or provided with such communications, which are not prepared for purposes of the
negotiations, are not so exempted and may, if otherwise admissible, be admitted in evidence in the
arbitration or lawsuit.

c. If the negotiations do not resolve the dispute within sixty (60) days of the initial written
request, the dispute shall be submitted to binding arbitration by a single arbitrator pursuant to
the Commercial Arbitration Rules of the American Arbitration Association. A party may demand such
arbitration in accordance with the procedures set out in those rules. Discovery shall be controlled
by the arbitrator and shall be permitted to the extent set out in this Section. Each party may
submit in writing to a party, and that party shall so respond, to a maximum of any combination of
thirty-five (35) (none of which may have subparts) of the following: interrogatories, demands to
produce documents and requests for admission. Each party is also entitled to take the oral
deposition of one (1) individual of another party. Additional discovery may be permitted upon mutual
agreement of the parties. The arbitration hearing shall be commenced within sixty (60) days of the
demand for arbitration and the arbitration shall be held in Los Angeles, CA. The arbitrator shall
control the scheduling so as to process the matter expeditiously. The

parties may submit written briefs. The arbitrator shall rule on
<!-- page 4 -->
the dispute by issuing a written opinion within thirty (30) days after the close of hearings. The
times specified in this paragraph may be extended upon mutual agreement of the parties or by the
arbitrator upon a showing of good cause. Judgment upon the award rendered by the arbitrator may be
entered in any court having jurisdiction.

d. Each party shall bear its own cost of these procedures. A party seeking discovery shall reimburse
the responding party the cost of production of the documents (to include search time and
reproduction time costs). The parties shall equally share the fees of the arbitration and the
arbitrator.

13. Notices -------

Any notice or demand given to either party under the Terms of this Agreement or pursuant to statute
shall be in writing and shall be given or made by telegram, facsimile transmission, certified or
registered mail, express mail or other overnight delivery service or hand delivery, proper postage
or other charges prepaid and addressed or directed to the respective parties as follows:

PAGEMASTER CORPORATION 100 E. Thousand Oaks Blvd. Suite 297 Thousand Oaks, CA 91360 ATTN: Marc
Resnick, CEO

GO CALL, INC. 15 Queen Street East Cambridge Ontario, Canada N3C2A7 ATTN: Ian Smith, President

Such notice or demand shall be deemed to have been given or made when actually received or
seventy-two (72) hours after being sent, whichever occurs first. The address for notice set out
above may be changed at any time by giving thirty (30) days prior written notice in the manner
above.

14. Agreement Expiration --------------------

Unless this Agreement is signed by an authorized representative of Go Call and a signed copy
delivered in person by mail or facsimile and personally received by an authorized representative of
PageMaster Corporation by 12:01 p.m. PST, on or before March 26, 1999, this Agreement shall be
deemed terminated and shall be of no further force or effect and the parties shall have no liability
to one another. At PageMaster Corporation's option, an additional agreement(s) may be prepared to
further negotiate this or similar promotions with Go Call.

15. Entire Agreement ----------------

This Agreement represents the entire agreement and understanding of the parties hereto with respect
to its subject matter hereof, and supersedes all previous representations, understandings or
agreements between the parties hereto. No waiver, modification or cancellation of any term or
condition of this Agreement shall be effective unless executed in writing by the party charged
therewith.

16. Nonwaiver ---------

Either parties failure to enforce any of the provisions of this Agreement shall in no way be deemed
to affect the validity of this Agreement.

17. Counterparts ------------

This Agreement may be executed in duplicate counterparts, all of which together shall constitute a
single instrument, and each of which shall be deemed an original of this Agreement for all purposes.

18. Successors and Assigns ----------------------

This Agreement shall be binding upon, and shall inure to the benefit of the successors, heirs,
administrators, trustees and assigns of the parties.

19. Confidentiality ---------------

The parties acknowledge that preparation for and execution of the promotion necessitates the
exchange of confidential and proprietary information relating and belonging to the parties to this
Agreement, as well as to other third parties integral to the promotion, including, without
limitation, the pager manufacturer and the airtime supplier (herein "Information"). Each party
agrees (1) to review, examine, inspect, obtain or utilize the information only for the purpose of
this promotion, (2) to otherwise hold such Information strictly confidential, (3) to prevent the
disclosure of such Information to nonessential third parties without a "need to know", and (4) to
insure that each party's employees, agents and representatives and those of any integral third party
understand and are bound by the confidentiality obligations of this Agreement. Each party shall
indemnify the other party with respect to any loss or damage arising from the unauthorized
disclosure or use of the Information by their respective employees, agents and representatives, or
by those of any third
<!-- page 5 -->
party to whom such Information was disclosed. The agreements contained in this Paragraph shall
survive the expiration, or termination of this Agreement. The panics hereby agree that subsequent to
the expiration or termination of this Agreement, each party consents to the other party's use of its
name only in connection with advertising to their respective trade or industry.

IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be executed as of the date set
forth below.

GO CALL, Inc.

Dated: 3/13/99 By: /s/ Michael Ruge ------------------- &sbsp; ---------------------------- Michael
Ruge

PAGEMASTER CORPORATION

Dated: 3/13/99 By: /s/ Marc B. Resnick ------------------- ---------------------------- Marc B.
Resnick CE0
