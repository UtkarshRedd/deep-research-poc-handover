<!-- page 1 -->
# NON-COMPETITION AGREEMENT AMENDMENT NO. 1
| Field | Value |
|---|---|
| Document Type | Non-Compete / Non-Solicit Agreement |
| Agreement Date | 2017-08-16 |
| Parties | VIVINT SOLAR, INC. (together with its successors and permitted assigns, “VivintSolar”); VIVINT, INC. (together with its successors and permitted assigns “Vivint”) Vivint Solar and Vivint (individually as a “Party”, and collectively as the “Parties”) |
| Source | CUAD v1 / VIVINT SOLAR, INC. - NON-COMPETITION AGREEMENT |

Exhibit 10.1 NON-COMPETITION AGREEMENT AMENDMENT NO. 1 This NON-COMPETITION AGREEMENT AMENDMENT NO.
1 (this "Amendment") is entered into as of August 16, 2017, by and between VIVINT SOLAR, INC., a
Delaware corporation (together with its successors and permitted assigns, "Vivint Solar"), and
VIVINT, INC., a Utah corporation (together with its successors and permitted assigns "Vivint"). Each
of Vivint Solar and Vivint may also be referred to herein individually as a "Party", and
collectively as the "Parties". RECITALS

WHEREAS, Vivint Solar and Vivint are affiliate business entities, under the common control and
ownership of 313 Acquisition, LLC, a Delaware limited liability company.

WHEREAS, the Parties had entered into a Non-Competition Agreement dated September 30, 2014, by and
between the Parties (collectively, the "Non-Competition Agreement") to set out certain restrictive
covenants of each Party.

WHEREAS, the Parties wish to amend the existing obligations under the Non-Competition Agreement.

WHEREAS, the Parties also desire to extend the term of the non-solicitation obligations under the
Non-Competition Agreement.

AGREEMENT

NOW, THEREFORE, in consideration of the mutual covenants, agreements and conditions set forth
herein, and for other good and valuable consideration, the receipt and sufficiency of which are
hereby acknowledged, the Parties agree as follows:

1. Definitions. Any capitalized term used but not defined in this Amendment will have the meaning
set forth for that term in the Non-Competition Agreement or the Master Framework Agreement, dated
September 30, 2016, by and between the Parties (the "Master Framework Agreement").

2. Non-Competition. Section 2 of the Non-Competition Agreement shall be deleted in its entirety and
the other provisions of the Non-Competition Agreement that relate to such Section 2, including,
without limitation, Sections 5 and 6, shall be amended hereby to delete the applicable references,
and provisions solely applicable to, Section 2, mutatis mutandis. 3. Non-Solicitation. Section 4 of
the Non-Competition Agreement is hereby deleted in its entirety and replaced with the following:

"Term. This Agreement will become effective on the Effective Date, and will continue until the
expiration of the "Sales Term" as that term is defined in the Sales Dealer Agreement dated as of
August 16, 2017 between Vivint and Vivint Solar Developer, LLC (the "Term")." 4. Continuation. This
Amendment will apply and be effective only with respect to the provisions of the Non- Competition
Agreement specifically referred to herein. Except as otherwise set forth in this Amendment, the
Non-Competition Agreement will continue in full force and effect in accordance with its terms.

1
<!-- page 2 -->
5. Master Framework Agreement. This Amendment is governed by the Master Framework Agreement,
including, without limitation, the provisions of Sections 4 (Confidentiality) and 6 (Miscellaneous)
of the Master Framework Agreement.

[SIGNATURE PAGES FOLLOW]

2
<!-- page 3 -->
IN WITNESS WHEREOF, the Parties have executed this Non-Competition Agreement Amendment No. 1 as of
the date first written above.

VIVINT SOLAR: VIVINT SOLAR, INC., a Delaware corporation By: /s/ David Bywater Name: David Bywater
Title: Chief Executive Officer

[SIGNATURE PAGES CONTINUE ON FOLLOWING PAGE]

[SIGNATURE PAGE]
<!-- page 4 -->
VIVINT: VIVINT, INC., a Utah corporation By: /s/ Alex J. Dunn Name: Alex J. Dunn Title: President

[SIGNATURE PAGE]
