<!-- page 1 -->
# MANUFACTURING AND SUPPLY AGREEMENT (DA-9801 Licensed Products)
| Field | Value |
|---|---|
| Document Type | Manufacturing Agreement |
| Agreement Date | 2018-09-28 |
| Parties | Dong-A ST Co., Ltd. ("Dong-A"); NeuroBo Pharmaceuticals, Inc. ("NeuroBo") |
| Source | CUAD v1 / NeuroboPharmaceuticalsInc_20190903_S-4_EX-10.36_11802165_EX-10.36_Manufacturing Agreement_ Supply Agreement |

Exhibit 10.36 [Pursuant to Item 601(b)(10) of Regulation S-K, certain confidential portions of this
exhibit have been omitted by means of marking such portions with asterisks as the identified
confidential portions (i) are not material and (ii) would be competitively harmful if publicly
disclosed.] MANUFACTURING AND SUPPLY AGREEMENT (DA-9801 Licensed Products) Between DONG-A ST CO.,
LTD. And NEUROBO PHARMACEUTICALS, INC. Dated: September 28, 2018

Source: NEUROBO PHARMACEUTICALS, INC., S-4, 9/3/2019
<!-- page 2 -->
MANUFACTURING AND SUPPLY AGREEMENT (DA-9801 Licensed Products) This MANUFACTURING AND SUPPLY
AGREEMENT (this "Agreement") is made and entered into as of September 28, 2018 ("Effective Date") by
and between: Dong-A ST Co., Ltd., a corporation duly incorporated under the laws of the Republic of
Korea, having its principal place of business at 64 Cheonho-daero, Dongdaemun-gu, Seoul 02587,
Republic of Korea ("Dong-A") and NeuroBo Pharmaceuticals, Inc., a corporation duly incorporated
under the laws of the State of Delaware, having its principal place of business at 177 Huntington
Avenue, Suite 1700, Boston, MA 02115, U.S.A. ("NeuroBo"). RECITALS WHEREAS, Dong-A and NeuroBo
entered into the License Agreement (DA-9801) dated January 18, 2018, as amended by the Amendment to
License Agreement (DA-9801) dated April 18, 2018 (the "License Agreement") whereby Dong-A granted to
NeuroBo an exclusive license under the Licensed Technology in the Field and in the Territory, to
make, use, offer to sell, sell and import the Licensed Products (as defined by the License
Agreement); WHEREAS, NeuroBo wishes that Dong-A manufacture and supply to NeuroBo the entire
requirement of the Licensed Products and their matching placebo for the purpose of research and
development of the Licensed Products, including the use in phase III clinical trials to be conducted
by NeuroBo for the purpose of obtaining the NDA in the Territory, pursuant to the License Agreement;
WHEREAS, NeuroBo wishes that Dong-A supply to NeuroBo the Licensed Products and their matching
placebo already manufactured by Dong-A as of the Effective Date in compliance with the Korea Good
Manufacturing Practices promulgated by the Governmental Authority in the Republic of Korea (the
"KGMP") and the Licensed Products and/or their matching placebo to be manufactured by Dong-A after
the Effective Date in compliance with the KGMP; and WHEREAS, Dong-A agrees (i) to supply to NeuroBo
the Licensed Products and their matching placebo already manufactured by Dong-A as of the Effective
Date in compliance with the KGMP, and (ii) to manufacture and supply to NeuroBo the Licensed
Products and their matching placebo in compliance with the KGMP, and NeuroBo agrees to purchase from
Dong-A, the Licensed Products and/or their matching placebo for research and development, on the
terms and conditions hereinafter set forth. NOW, THEREFORE, in consideration of the foregoing
premises and the mutual covenants contained herein and other good and valuable consideration, the
receipt and sufficiency of which are hereby acknowledged, Dong-A and NeuroBo mutually agree as
follows: 1. DEFINITIONS Unless otherwise defined in this Agreement, the capitalized terms utilized
herein shall have 1

Source: NEUROBO PHARMACEUTICALS, INC., S-4, 9/3/2019
<!-- page 3 -->
the same meanings as defined in the License Agreement. 2. MANUFACTURE AND SUPPLY 2.1 Subject to the
provisions hereof, Dong-A shall (i) supply to NeuroBo the Licensed Products and their matching
placebo already manufactured by Dong-A as of the Effective Date in compliance with the KGMP, and
(ii) manufacture in compliance with the KGMP and in conformity with the specifications separately
agreed upon between the Parties and attached hereto as Exhibit A (the "Product Specifications") and
supply to NeuroBo the Licensed Products and/or their matching placebo, and NeuroBo shall purchase
from Dong-A the entire requirement of the Licensed Products and/or their matching placebo for
research and development of the Licensed Products under the License Agreement. 2.2 NeuroBo shall
manufacture, or have manufactured, and supply to Dong-A the active pharmaceutical ingredients (API),
which are necessary to manufacture the Licensed Products, in the quantity and in conformity with the
specifications separately agreed upon between the Parties and attached hereto as Exhibit C (the "API
Specifications") as may be amended by the Parties's agreement in writing from time to time. 2.3
NeuroBo shall, at its costs and expenses, deliver the API to the place designated by Dong-A no later
than [***] days prior to the requested delivery date for the Licensed Products and/or their matching
placebo in accordance with the Firm Order. 2.4 Within [***] days after receipt of the API from
NeuroBo, Dong-A shall perform quality control test (the "API Test") in accordance with the methods
of the API Test on such API for acceptance (the "API Test Methods"), which shall be separately
agreed in writing by and between the Parties and attached hereto as Exhibit D") as may be amended by
the Parties's agreement in writing from time to time. NeuroBo shall provide Dong-A with all
available information and technical assistance necessary for Dong-A to perform the API Test
expeditiously. If the API Test indicates that the API is deficient in quantity or does not meet the
API Specifications, Dong-A shall notify NeuroBo thereof in writing within the [***]-day period
together with results of the API Test. If the quantity is deficient, NeuroBo shall, as soon as
commercially reasonable, ship, or have shipped, the sufficient amount of additional API to cover the
deficiency. If the API does not meet the API Specifications, NeuroBo shall retrieve the API at its
own expense and replace the API at no additional cost to Dong-A. 2.5 Upon [***] days' notice and at
time mutually agreed upon by the Parties during Dong-A's normal business hours, but no more
frequently than [***] every year during the term of this Agreement, NeuroBo may, at its cost and
expense, inspect Dong-A's manufacturing facilities where the Licensed Products are manufactured.
Within [***] days after the completion of the inspection, NeuroBo shall provide a written report
detailing the results of such audit to Dong-A. In case of any inspection by any Governmental
Authority of Dong-A's manufacturing facilities where the Licensed Products are manufactured, NeuroBo
shall promptly provide Dong-A with a notice of the inspection and all notices, correspondence and
related documents received from or sent to the applicable Governmental Authority. Dong-A shall
permit such Governmental Authority to inspect the facilities to the fullest extent permitted by Laws
and shall make its [***] and cooperate with the Governmental Authority in conducting the inspection.
NeuroBo shall provide 2

such assistance as reasonably requested by Dong-A for the preparation of and during such inspection
and furnish Dong-A with copies of all reports and notices received as a result of any such
inspection. NeuroBo agrees that Dong-A shall not be obligated to correct any deficiencies documented
by the Governmental Authority as a result of any such inspection. NeuroBo further agrees that it
shall not hold Dong-A responsible nor shall bring any claims or actions against Dong-A for any such
deficiencies and/or costs or damages NeuroBo may incur resulting therefrom. Upon request of Dong-A,
the Parties may discuss in good faith a plan for NeuroBo to assist in correcting such deficiencies
and the terms and conditions for implementing the corrective actions under such plan. 2.6 The
Parties acknowledge and agree that prior to commercialization of the Licensed Products by NeuroBo,
its Affiliates and/or sublicensees, the Parties shall, in good faith, negotiate the terms and
conditions for, including, without limitation, the supply price, and enter into a definitive
non-exclusive supply agreement pursuant to which Dong-A shall supply to NeuroBo the Licensed
Products for the commercialization by NeuroBo, its Affiliates and/or sublicensees of the Licensed
Products in the Field in the Territory pursuant to the License Agreement. 2.7 In case NeuroBo
requests Dong-A to conduct any additional activities, including testing (e.g. AMV, PV),
documentation (e.g. CMC packaging), which NeuroBo requires for obtaining the NDA for the Licensed
Product in the Territory, the Parties shall, in good faith, negotiate the terms and conditions,
including, without limitation, the costs and expenses for conducting such additional testing
activities of the Licensed Products and/or their matching placebo. For any such activities, NeuroBo
shall pay to Dong-A [***] ([***]%) of the fees as agreed by the Parties within [***] days prior to
conducting such activities by Dong-A, and shall pay the balance due within [***] days after delivery
by Dong-A to NeuroBo of the deliverables as agreed by the Parties. 3. ORDERING AND DELIVERY 3.1
NeuroBo shall submit to Dong-A an order for the Licensed Products and/or their matching placebo no
later than [***] days prior to the requested delivery date thereof. For each order, NeuroBo shall be
obligated to order the Licensed Products and/or their matching placebo in [***] tablets. NeuroBo
acknowledges and agrees that certain quantity of the Licensed Products and/or their matching placebo
from each batch ordered shall be retained by Dong-A for use in the stability tests and as retention
samples, and NeuroBo shall order the Licensed Products and/or their matching placebo in
consideration of such quantity to be retained by Dong-A. Each order shall specify at least (i) the
quantity of the Licensed Products and/or their matching placebo, (ii) the specifications of the
Licensed Products and/or their matching placebo, including the specifics of packaging, (iii) the
expected delivery date for the API, (iv) the requested delivery date for the Licensed Products
and/or their matching placebo, (v) the shipment terms for the Licensed Products and/or their
matching placebo and (vi) the supply price for the Licensed Products and/or their matching placebo.
Upon receipt of the order from NeuroBo, Dong-A shall promptly acknowledge the receipt of such order.
No order shall be binding upon the Parties until agreed in writing by Dong-A and NeuroBo; provided,
however, that such agreement shall not be unreasonably withheld or delayed. Upon such agreement, the
order shall be deemed to be the "Firm Order" which shall be binding and may only be revised by
agreement of the Parties in writing. Dong-A shall deliver the Licensed Products and/or their
matching placebo to NeuroBo in accordance with the Firm 3

Source: NEUROBO PHARMACEUTICALS, INC., S-4, 9/3/2019
<!-- page 4 -->
Order on the shipment terms of [***] manufacturing facility of Dong-A (ICC Incoterms 2010),
including the delivery date and place set forth therein, within the later of (i) [***] days after
the date of the Firm Order and (ii) [***] days after the date of acceptance by Dong-A of the API.
3.2 Dong-A shall supply NeuroBo with the Licensed Products and/or their matching placebo together
with a certificate of analysis, as described in the Product Specifications, for each batch of the
Licensed Products and/or their matching placebo shipped hereunder certifying that such batch of the
Licensed Products and/or their matching placebo meets the Product Specifications. 3.3 Within [***]
days after receipt of the Licensed Products and/or their matching placebo hereunder, NeuroBo may, in
its discretion, perform a quality control test (the "Product Test") in accordance with the methods
of the test on such Licensed Products and/or their matching placebo for acceptance (the "Product
Test Methods"), which shall be separately agreed in writing by and between Dong-A and NeuroBo and
attached hereto as Exhibit B, as may be amended by the Parties' agreement in writing from time to
time. Dong-A shall provide NeuroBo with all available information and technical assistance necessary
for NeuroBo to perform the Product Test expeditiously. If the Product Test indicates that the
Licensed Products and/or their matching placebo is deficient in quantity or does not meet the
Product Specifications, NeuroBo shall notify Dong-A thereof in writing within the [***]-day period
together with results of the Product Test. If the quantity is deficient, Dong-A shall immediately
ship the sufficient amount of additional Licensed Products and/or their matching placebo to cover
the deficiency. If Dong-A does not agree that the Licensed Products and/or their matching placebo
does not meet the Product Specifications, the Parties shall refer their disagreement for decision by
an independent testing laboratory agreed by the Parties. The decision by the independent testing
laboratory shall be conclusive and binding on both Parties, and the losing Party shall bear the
costs of the independent testing laboratory. If Dong-A agrees that the Licensed Products and/or
their matching placebo does not meet the Product Specifications, or if the decision by the testing
laboratory confirms that the Licensed Products and/or their matching placebo does not meet the
Product Specifications, (i) Dong-A shall arrange for the return from NeuroBo of the Licensed
Products and/or their matching placebo at Dong-A's expense, and (ii) without waiting for the return,
Dong-A shall promptly replace the Licensed Products and/or their matching placebo at no additional
cost to NeuroBo. 4. TERMS AND CONDITIONS OF SALE 4.1 The terms and conditions of sale and purchase
of the Licensed Products and/or their matching placebo between Dong-A and NeuroBo shall be set forth
in each Firm Order. 4.2 The supply prices for the Licensed Products and their matching placebo shall
be specified in Schedule 4.2. 4.3 Upon agreement by the Parties of the Firm Order, Dong-A shall
issue to NeuroBo an invoice in Korean Won for each shipment of the Licensed Products and/or their
matching placebo based on the Firm Order. Unless otherwise agreed in writing by Dong-A, NeuroBo
shall pay the invoiced supply price (i) in Korean Won (KRW) or (ii) in United States Dollars (USD)
which amount shall correspond the invoiced amount converted from KRW to USD at the exchange rate of
the payment date, no later than [***] days prior to the shipment date by way of wire transfer 4

Source: NEUROBO PHARMACEUTICALS, INC., S-4, 9/3/2019
<!-- page 5 -->
to Dong-A. NeuroBo shall be responsible for and pay all wire transfer fees incurred in the
Territory. If Dong-A does not receive payment of any sum due to it on or before the due date, [***]
interest shall thereafter accrue on the sum due to until the date of payment at the [***] rate of
[***] percent ([***]%) over the then-current prime rate quoted by Citibank in New York, New York or
the maximum rate allowable by New York law, whichever is lower. 4.4 Dong-A shall not be responsible
for any taxes levied on account of the payments under this Agreement. In the event that any taxes
are required to be paid on account of any payment hereunder, NeuroBo shall pay all such taxes. 4.5
In performing its obligations under this Agreement, NeuroBo shall, and shall cause its Affiliates
and sublicensees to, comply with all applicable laws, including any applicable anti-corruption or
anti-bribery laws or regulation, of any governmental authority with jurisdiction over the activities
performed by NeuroBo or its Affiliates or sublicensees in furtherance of such obligations. 5. TERM
AND TERMINATION 5.1 This Agreement shall commence on the Effective Date and, unless earlier
terminated, shall continue in full force and effect for a period of [***] years thereafter. 5.2 This
Agreement shall automatically terminate in case the License Agreement is terminated for any reason
specified therein. 5.3 A Party may terminate this Agreement by notice to the other Party if the
other Party is in material breach of any provision of this Agreement, and (a) the breaching Party
has not cured the breach within [***] days after receiving notice from the terminating Party; or (b)
if the breach cannot reasonably be cured within the [***]-day period, the breaching Party has not
started to remedy the breach within the [***]-day period and diligently endeavored to cure the
breach within a reasonable time thereafter. 5.4 Either Party may terminate this Agreement
immediately upon notice to the other Party in the event that (a) the other Party is the subject of a
petition for bankruptcy, reorganization, or arrangement, whether voluntary or involuntary, and the
same is not dismissed within thirty (30) days thereof, (b) a receiver or trustee is appointed for
all or a substantial portion of the assets of the other Party, or (c) the other Party makes an
assignment for the benefit of its creditors. 5.6 The termination or expiration of this Agreement, in
whole or in part, shall be without prejudice to the right of either Dong-A and NeuroBo to receive
all payments accrued and unpaid at the effective date of such termination or expiration, without
prejudice to the remedy of either Dong-A and NeuroBo in respect to any previous breach of any of the
representations, warranties, covenants or obligations herein contained and without prejudice to any
other provisions hereof which expressly or necessarily call for performance after such termination
or expiration. 5

Source: NEUROBO PHARMACEUTICALS, INC., S-4, 9/3/2019
<!-- page 6 -->
6. GOVERNING LAW The laws of the State of New York (without giving effect to its conflicts of law
principles) govern all matters arising out of or relating to this Agreement and all of the
transactions it contemplates, including without limitation, its validity, interpretation,
construction, performance, and enforcement. 7. NOTICES All notices, consents, and approvals under
this Agreement must be delivered in writing by courier, electronic facsimile (fax), or certified or
registered mail, (postage prepaid and return receipt requested) to the other Party; and shall be
effective upon receipt or three (3) business days after being deposited in the mail, whichever
occurs sooner. Notices to the Parties shall be sent to the addresses set forth at the beginning of
this Agreement. Notice of change of address shall be given in the same manner as other
communications. 8. INCORPORATION BY REFERENCE Articles or Sections 8.2 (Limitation of Liability), 9
(Indemnification), 12.2 (Force Majeure), 12.3 (Assignment), 12.4 (Severability), 12.6 (Remedies),
12.8 (Submission to Jurisdiction/Waiver of Jury Trial), 12.9 (Independent Contractor/No Agency),
12.10 (Entire Agreement) of the License Agreement shall be deemed to be incorporated herein by
reference as it is set forth in this Agreement <Signature page follows.> 6

Source: NEUROBO PHARMACEUTICALS, INC., S-4, 9/3/2019
<!-- page 7 -->
IN WITNESS WHEREOF, the Parties hereto have duly executed this Agreement as of the Effective Date.
DONG-A ST CO., LTD. By: /s/ Daesik Eom Daesik Eom, Chairman and CEO NEUROBO PHARMACEUTICALS, INC.
By: /s/ John L. Brooks, III John L. Brooks III, President & CEO 7

Exhibit A Product Specifications

Test Analytical Method Specification Requirements [***] [***] [***]

[***] [***] [***][***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] Schedule 1-1

Source: NEUROBO PHARMACEUTICALS, INC., S-4, 9/3/2019
<!-- page 8 -->
Exhibit B Product Test Methods [***] Schedule 1-2

Source: NEUROBO PHARMACEUTICALS, INC., S-4, 9/3/2019
<!-- page 9 -->
Exhibit C API Specifications

Test Analytical Method Specification Requirements [***] [***] [***]

[***] [***] [***][***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***]
[***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] [***] Schedule 1-3

Exhibit D API Test Methods [***] Schedule 1-4

Source: NEUROBO PHARMACEUTICALS, INC., S-4, 9/3/2019
<!-- page 10 -->
Schedule 4.2 Supply Price [***] Schedule 1-5

Source: NEUROBO PHARMACEUTICALS, INC., S-4, 9/3/2019
