<!-- page 1 -->
# HOSTING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Hosting Agreement |
| SEC Filing Date | 2000-03-22 |
| Parties | eGain Communications Corporation ("eGain"); Eliance Corporation ("Customer") |
| Source | CUAD v1 / WEBHELPCOMINC_03_22_2000-EX-10.8-HOSTING AGREEMENT |

Exhibit 10.8

eGAIN COMMUNICATIONS CORPORATION

HOSTING AGREEMENT

1. Hosting Agreement. This Agreement (including its Exhibit A and all other documents referenced
herein) is entered into by eGain Communications Corporation ("eGain") and Eliance Corporation
("Customer") for the purpose of providing Customer with Web-based access to eGain's software
specified in Exhibit A, including any updates, upgrades or revisions provided under this Agreement
("Software"), and certain other services relating to the processing of and response to online
inquiries and messages ("Online Messages") received by Customer from its customers and other users
of Customer's Web site ("Users").

2. Provision of Services. eGain will provide Customer with access, maintenance and related hosting
services ("Hosting Services") to the Software installed on eGain's servers and other equipment (the
"eGain System"). Customer agrees, as reasonably requested by eGain, to provide eGain with access to
Customer's premises and equipment and to otherwise cooperate with eGain in performing the services.
During the term of this Agreement, Customer may obtain information ("Reports") regarding Customer's
use of the Software and the quantity and handling of Online Messages routed to the eGain System by
accessing the eGain System through a password-protected Web site made available by eGain. Customer
shall be responsible for maintaining the confidentiality of such passwords and shall permit only
authorized employees of Customer to access the eGain System. The Hosting Services, and the hosting
fees specified in Exhibit A, do not include any deployment, training or other consulting or
professional services which, if applicable, will be specified in a Statement of Work, signed by both
parties, and incorporated herein by this reference.

2.1 Customer Support. eGain will provide live telephone support to Customer 24-hours-a-day,
seven-days-a-week by a trained eGain customer support representative.

3. Customer's Responsibilities. Customer agrees that it shall be responsible for providing and
maintaining its own Internet access and all necessary telecommunications equipment, software and
other materials ("Customer Equipment") at Customer's location necessary for accessing the Software
and the eGain System through the Internet. Customer agrees to notify eGain of any changes in the
Customer Equipment, including any system configuration changes or any hardware or software upgrades,
which may affect the Hosting Services provided hereunder. The eGain System is only to be used for
lawful purposes. Customer agrees not to transmit, re-transmit or store materials on or through the
eGain System or the Software that are harmful to the eGain System or Software, or in violation of
any applicable laws or regulations, including without limitation laws relating to infringement of
intellectual property and proprietary rights of others. To the extent that certain components of the
Software may be downloaded to Customer's or User's computer as a result of accessing the Software as
part of the Hosting Services, eGain grants Customers a non-exclusive, non-transferable, limited
license, with right to sublicense solely to Users, to use such Software only in connection with the
Hosting Services. Neither Customer nor Users are otherwise permitted to use the Software, nor will
Customer or Users disassemble, decompile or otherwise attempt to discern the source code of such
Software. Customer agrees that, except as expressly set forth in this Section and in Section 11, it
will not rent, lease, sublicense, re-sell, time-share or otherwise assign to any third party this
Agreement or any of Customer's rights or licenses to access the Software or the eGain System, nor
shall Customer use, or authorize others to use, the Software, Hosting Services or the eGain System
to operate a service bureau. Notwithstanding the preceding sentence, Customer shall be permitted to
provide access to the eGain System to its employees and agents located worldwide.

4. Proprietary Rights. Except for the limited access right granted to Customer in this Agreement,
all right, title and interest in and to the Software (including any and all modifications as a
result of any implementation services rendered) and the eGain System are and shall remain the
exclusive property of eGain and its licensors. eGain acknowledges and agrees that the Online
Messages are the property of Customer and that eGain has only a limited right to use the Online
Messages as set forth in the following sentence. Notwithstanding the foregoing, eGain may access and
disclose the Online Messages solely as necessary to provide the Hosting Services, to operate and
maintain its systems, to comply with applicable laws and government orders and requests, and to
protect itself and its customers.

5. Pricing and Payment. Customer agrees to pay the fees and other charges for the Hosting Services
and other services provided under this Agreement as specified in Exhibit A of this Agreement.
CUSTOMER AGREES TO PAY FOR HOSTING SERVICES ON OR BEFORE THE FIRST DAY OF THE MONTH IN WHICH THE
HOSTING SERVICES ARE PROVIDED, except that, with respect to Additional Fees (as defined in Exhibit
A), eGain will invoice Customer for such Fees in the month after the month in which such fees accrue
as provided in Exhibit A. All amounts payable hereunder are exclusive of any and all taxes, and
Customer is responsible for payment of such taxes (excluding taxes based on eGain's net income). All
prices are stated, and Customer shall pay, in United States dollars. Payment received by eGain after
the due date shall be subject to a late fee equal to one and one-half percent (1.5%) per month, or,
if less, the maximum amount allowed by applicable law. At the end of the initial one-year term of
this Agreement and any subsequent one-year terms, eGain may adjust the monthly fee payable under
this Agreement by providing Customer written notice of such adjustment at least sixty (60) days
prior to the beginning of the new term.

6. Limited Warranties; Disclaimer of Warranties.
<!-- page 2 -->
6.1 eGain warrants and represents to Customer that (i) the Software will perform substantially in
accordance with the documentation, if any, provided by eGain to Customer, and (ii) the Hosting
Services will be performed in a professional and workmanlike manner and in accordance with Section
2. In the event of Downtime (as defined in this Section 6.1 below), as Customer's sole and exclusive
remedy and eGain's sole and exclusive liability, the monthly fee payable for the Hosting Services
shall be reduced as follows:

a) For the first sixty (60) minutes of Downtime during Normal Business Hours or the first four (4)
hours of Downtime outside of Normal Business Hours ("Initial Downtime"), eGain will credit
Customer's account for one (1) day of service.

b) For each eight (8) hour period of Downtime per day in addition to the Initial Downtime, eGain
will credit Customer's account for one (1) additional day of service.

For the purposes of this Agreement, "Downtime" shall mean any interruption in the availability of
Hosting Services to Customer (excluding scheduled interruptions of which Customer is notified 48
hours in advanced), only if such interruption is due either to: 1) an error in the Software, or 2)
failure of the eGain System (but not including problems associated with Internet connectivity).
Downtime begins upon Customer notification to eGain of the interruption, either

eGAIN COMMUNICATIONS CORPORATION

HOSTING AGREEMENT

by speaking directly with an eGain customer service representative or recording a voice mail message
in the eGain customer service voice mail box, and continues until the availability of the Hosting
Services is restored to the Customer. For purposes of this Agreement, "Normal Business Hours" shall
mean between the hours of 6:00 a.m to 6:00 p.m. Pacific time, Monday through Friday excluding
national holidays.

In the event of a breach (other than Downtime) of the warranty set forth in Section 6.1(i) above,
Customer's sole and exclusive remedy, and eGain's sole and exclusive liability shall be, at eGain's
option, repair or replacement of the Software.

THE FOREGOING CONSTITUTES CUSTOMER'S SOLE AND EXCLUSIVE REMEDY, AND eGAIN'S ENTIRE LIABILITY, FOR
DOWNTIME AND FOR BREACH OF THE HOSTING SERVICES WARRANTY PROVIDED IN THIS SECTION 6.1.

6.2 eGain represents and warrants that, prior to, during and after the calendar year 2000 A.D., the
Software and the eGain System will process, calculate, manipulate, sort, store and transfer date
data without material error or material performance degradation, including without limitation date
data which represents or references different centuries or more than one century (such
representation and warranty being referred to as "Year 2000 Compliant"). In the event that the
Software or eGain System is not Year 2000 Compliant, Customer's sole and exclusive remedy and
eGain's sole and exclusive liability shall be for eGain, at no additional cost to Customer, to
promptly modify the Software or the eGain System so that the Software or eGain System is Year 2000
Compliant. The foregoing warranty is conditioned upon the Customer using the Software and/or the
eGain System in accordance with its applicable Documentation, and on other software, hardware,
network and systems (other than the Software and the eGain System) with which the Software and/or
the eGain System interface or interoperate also being Year 2000 Compliant.

6.3 EXCEPT AS PROVIDED IN SECTIONS 6.1-6.2, (A) THE HOSTING SERVICES ARE PROVIDED, AND THE SOFTWARE
AND THE eGAIN SYSTEM ARE MADE AVAILABLE, BY eGAIN TO CUSTOMER "AS IS," AND (B) eGAIN AND ITS
SUPPLIERS MAKE NO WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, REGARDING THE HOSTING SERVICES,
THE SOFTWARE OR THE eGAIN SYSTEM, AND SPECIFICALLY DISCLAIM THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND AGAINST INFRINGEMENT, TO THE MAXIMUM EXTENT POSSIBLE BY LAW.

6.4 Without limiting the express warranties set forth in this Agreement, eGain does not warrant that
the Software, the eGain System or the Hosting Services will meet Customer's requirements (except as
provided in Section 6.1) or that Customer's access to and use of the Software, the eGain System or
the Hosting Services will be uninterrupted or free of errors or omissions. eGain cannot and does not
guarantee the privacy, security, authenticity and non-corruption of any information transmitted
through, or stored in any system connected to, the Internet. eGain will use commercially reasonable
efforts to adequately maintain, and upgrade as necessary, the eGain System to provide the Hosting
Services to its customers. However, except as expressly set forth herein, eGain shall not be
responsible for any delays, errors, failures to perform, or disruptions in the Hosting Services
caused by or resulting from any act, omission or condition beyond eGain's reasonable control.

7. Limitation of liability. EXCLUDING LIABILITY FOR INFRINGEMENT CLAIMS AS DISCUSSED IN SECTION 9 OF
THIS AGREEMENT, IN NO EVENT SHALL eGAIN BE LIABLE TO CUSTOMER FOR CONSEQUENTIAL, EXEMPLARY,
INDIRECT, SPECIAL OR INCIDENTAL DAMAGES (INCLUDING, WITHOUT LIMITATION, LOST PROFITS), OR BE LIABLE
TO ANY THIRD PARTY FOR ANY DAMAGES WHATSOEVER, EVEN IF eGAIN HAS BEEN ADVISED OF THE POSSIBILITY OF
SUCH DAMAGES. eGain's entire liability under this Agreement for any damages from any cause
whatsoever, regardless of form or action, whether in contract, negligence or otherwise, shall in no
event exceed an amount equal to the price paid for the Services out of which the claim arose.
<!-- page 3 -->
8. Confidential Information. Each party agrees to keep confidential and to use only for purposes of
performing (or as otherwise permitted under) this Agreement, any proprietary or confidential
information of the other party disclosed pursuant to this Agreement which is marked as confidential
or which would reasonably be considered of a confidential nature. The obligation of confidentiality
shall not apply to information which is publicly available through authorized disclosure, is known
by the receiving party at the time of disclosure as evidenced in writing, is rightfully obtained
from a third party who has the right to disclose it, or which is required by law, government order
or request to be disclosed. Upon any termination of this Agreement, each party shall return to the
other party all confidential information of the other party, and all copies thereof, in the
possession, custody or control of the party unless otherwise expressly provided in this Agreement.

9. Indemnification. Subject to the limitations set forth in this Section 9, eGain will defend any
third-party suit or action against Customer to the extent such suit or action is based on a claim
that the Software or the eGain System infringes any valid United States patent, copyright, trade
secret or other proprietary right, and eGain will pay those damages and costs finally awarded
against Customer in any monetary settlement of such suit or action which are specifically
attributable to such claim. These obligations do not include any claims to the extent they are based
on use of the Software or eGain System in violation of this Agreement or in combination with any
other software or hardware, or any modification to the Software or eGain System pursuant to
Customer's specifications. If any portion of the Software or eGain System becomes, or in eGain's
opinion is likely to become, the subject of a claim of infringement, then eGain may, at its option
and expense, (a) procure for Customer the right to continue using such Software or the eGain System,
or (b) replace or modify the Software or the eGain System so that it becomes non-infringing. The
indemnity obligations set forth in this Section 9 are contingent upon: (i) Customer giving prompt
written notice to the eGain of any such claim(s); (ii) eGain having sole control of the defense or
settlement of the claim; and (iii) at eGain's request and expense, Customer cooperating in the
investigation and defense of such claim(s). THE FOREGOING STATES eGAIN'S ENTIRE LIABILITY FOR
INFRINGEMENT CLAIMS.

10. Term and Termination.

10.1 Term and Termination. This Agreement shall continue in effect from the Effective Date for a one
(1) year period, unless earlier terminated as set forth below, and thereafter shall renew
automatically for successive one (1) year periods unless either party gives the other party at least
thirty (30) days prior written notice of its intent not to renew the Agreement. In addition, either
party may terminate this Agreement by giving to the other party written notice

eGAIN COMMUNICATIONS CORPORATION

HOSTING AGREEMENT

of such termination upon the other party's material breach of any material term (subject to the
other party's right to cure within thirty (30) days after receipt of such notice), the other party's
insolvency, or the institution of any bankruptcy or similar proceedings by or against the other
party.

10.2 Effect of Termination. Upon any termination of this Agreement, eGain shall immediately cease
providing all Hosting Services, and Customer shall no longer have access to the Software or the
eGain System. Except in the event of termination for Customer's breach, eGain shall provide Customer
with an electronic copy of the final Reports (covering the month just prior to termination of this
Agreement). eGain shall be entitled to retain a copy (whether electronic or otherwise) of the Online
Messages and the Reports for its records and internal purposes and shall not disclose such Online
Messages or Reports to any third party except as permitted under Section 4. Within fifteen (15) days
of any termination of this Agreement, Customer shall pay to eGain all unpaid fees accrued prior to
termination. Sections 4, 5 (as to amounts accrued but unpaid), 7, 8, 10.2 and 12 and Exhibit A (as
to amounts accrued but unpaid) shall survive any expiration or termination of this Agreement.

11. Customer References. Customer agrees that, during the term of this Agreement, eGain may
reference Customer in eGain's customer listings and may place Customer's name and logo on eGain's
Web site and in collateral marketing materials relating to eGain's products and services. Customer
hereby grants eGain a right to use Customer's trademarks (name and logo only) designated by Customer
for such limited uses, subject to Customer's trademark/logo usage guidelines, if any, provided by
Customer to eGain. With these limited exceptions, eGain agrees that it may not use Customer's name,
logo or any other trademarks (including in any press releases, customer "case studies," and the
like) without Customer's prior consent.

12. Miscellaneous. This Agreement, including Exhibit A and any other exhibits hereto, constitutes
the entire agreement of the parties, and supersedes any prior or contemporaneous agreements between
the parties, with respect to the subject of this Agreement. Except as otherwise expressly provided
herein, this Agreement may be modified only by a writing signed by an authorized representative of
each party. This Agreement shall be governed by and construed in accordance with the laws of the
State of California exclusive of its conflict of laws principles. Notices under this Agreement shall
be in writing, addressed to the party at its last-provided address, and shall be deemed given when
delivered personally, or by e-mail (with confirmation of receipt) or conventional mail (registered
or certified, postage prepaid with return receipt requested). Nothing contained in this Agreement is
intended or is to be construed to constitute eGain and Customer as partners or joint venturers or
<!-- page 4 -->
either party as an agent of the other. If any provision of this Agreement shall be declared invalid,
illegal or unenforceable, all remaining provisions shall continue in full force and effect. All
waivers of any rights or breach hereunder must be in writing to be effective, and no failure to
enforce any right or provision shall be deemed to be a waiver of the same or other right or
provision on that or any other occasion. Neither party may assign or otherwise transfer its rights
and/or obligations under this Agreement without the prior written consent of the other party.
Notwithstanding the foregoing, no consent shall be required for an assignment of this Agreement made
pursuant to a merger, consolidation, or the acquisition of all or substantially all of the business
and assets of a party. This Agreement will bind and inure to the benefit of the parties and their
successors and permitted assigns.

Each party agrees to the terms and conditions contained in this Agreement.

Customer: Eliance Corporation

Name:/s/ Title: ___________________________ _________

Signature:______________________ Date:__________

eGain Communications Corporation:

Name:/s/ Title: ___________________________ _________

Signature:______________________ Date:__________
