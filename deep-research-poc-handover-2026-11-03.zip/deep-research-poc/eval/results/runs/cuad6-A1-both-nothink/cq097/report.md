# What non-compete clause does the Exclusive Distributor Agreement between WATER NOW, INC...

*Question:* What non-compete clause does the Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc. (dated 2019-11-12) contain? Quote the clause and cite its page.

## Locate the Exclusive Distributor Agreement

The Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc. dated 2019-11-12 is present in the fixed set. [c3ea62bed0707060 p.1] The agreement is made and entered into as of the 12th day of November, 2019, by and among WATER NOW, INC., Hydraspin USA, Inc., and BESTEV MANAGEMENT, LLC. [c3ea62bed0707060 p.1]

[GAP] The non-compete clause is not present in the provided evidence.

## Identify the non-compete clause

The Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc. dated 2019-11-12 contains a noncircumvention provision rather than a traditional non-compete clause. [c3ea62bed0707060 p.4] Section 2.3 Noncircumvention states: "2.3 Noncircumvention. [uncited] Hydraspin certifies, stipulates, and agrees that the Hydraspin will deal exclusively with and through the Distributor in relation to the distribution of the Products in the Territory. [uncited] Hydraspin will not in any way or in any capacity, either directly or indirectly (including without limitation acting by, with or through one or more Persons in which the Hydraspin has an interest and/or with whom Hydraspin has a relationship): except pursuant to an agreement with the Distributor, (a) contact, approach or negotiate with any Customer outside of the Distributor, or (b) contact,…". [c3ea62bed0707060 p.4]

[GAP] The full text of subsection (b) and any subsequent subsections of Section 2.3 is missing from the evidence.

## Cite the page number

The Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc. dated 2019-11-12 does not contain a non-compete clause. [c3ea62bed0707060 p.3] Section 2.1 on page 3 establishes an exclusivity appointment rather than a non-compete obligation. [c3ea62bed0707060 p.3]

[GAP] The non-compete clause is not present in the provided evidence.

## Verification appendix

Claims: 11 · supported: 6 · partially: 0 · dropped: 0 · gaps: 5 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e3→[c3ea62bed0707060 p.1] |  |
| s1.2 | s1 | keep | 1.00 | e3→[c3ea62bed0707060 p.1] |  |
| s1.3 | s1 | gap |  |  |  |
| s2.1 | s2 | keep | 1.00 | e1→[c3ea62bed0707060 p.4] |  |
| s2.2 | s2 | gap |  |  | no evidence cited |
| s2.3 | s2 | gap |  |  | no evidence cited |
| s2.4 | s2 | keep | 1.00 | e1→[c3ea62bed0707060 p.4] |  |
| s2.5 | s2 | gap |  |  |  |
| s3.1 | s3 | keep | 1.00 | e2→[c3ea62bed0707060 p.3] |  |
| s3.2 | s3 | keep | 1.00 | e2→[c3ea62bed0707060 p.3] |  |
| s3.3 | s3 | gap |  |  |  |

### Evidence

- e1 [c3ea62bed0707060 p.4 L129-141] keep (1.0): "2.3 Noncircumvention. Hydraspin certifies, stipulates, and agrees that the Hydraspin will deal exclusively with and through the Distributor in relation to the distribution of the Products in the Territory. Hydraspin will not in any way or i…"
- e2 [c3ea62bed0707060 p.3 L107-120] keep (1.0): "2.1 Exclusivity and Territory. Hydraspin hereby appoints Distributor, and Distributor hereby accepts appointment, as Hydraspin's exclusive distributor of the Products in the Territory during the term of this Agreement, subject to the terms …"
- e3 [c3ea62bed0707060 p.1 L10-14] keep (1.0): "THIS EXCLUSIVE DISTRIBUTOR AGREEMENT (this "Agreement") is made and entered into as of the 12th day of November, 2019 (the "Effective Date"), by and among WATER NOW, INC., a Texas corporation ("Water Now"), Hydraspin USA, Inc., a Texas corp…"
