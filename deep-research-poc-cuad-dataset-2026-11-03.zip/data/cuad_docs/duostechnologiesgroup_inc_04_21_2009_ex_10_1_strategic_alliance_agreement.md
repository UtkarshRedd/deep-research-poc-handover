<!-- page 1 -->
# Strategic Alliance Agreement
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2009-04-15 |
| Parties | System Associates, Inc. ("ISA"); Rubicon Software Group plc ("Rubicon") |
| Source | CUAD v1 / DUOSTECHNOLOGIESGROUP,INC_04_21_2009-EX-10.1-STRATEGIC ALLIANCE AGREEMENT |

Exhibit 10.1 STRATEGIC ALLIANCE AGREEMENT This Strategic Alliance Agreement (this "Agreement"),
effective as of 15 April, 2009 (the "Effective Date"), is by and between Information System
Associates, Inc., a Florida Corporation whose registered office is 1151 Southwest 30th Street, Suite
E, Palm City FL, 34990 ("ISA") and Rubicon Software Group plc, a company registered under the laws
of England and Wales (Registered Company No. 5701810) whose registered office is Rubicon House,
Guildford Road, West End, Surrey GU24 9PW ("Rubicon"). Background WHEREAS, Rubicon desires to engage
ISA as Rubicon's exclusive agent in the United States for the purposes of reselling Rubicon's
software and services; WHEREAS, ISA desires to engage Rubicon as its software development partner
and to provide various consulting services in Europe; and WHEREAS, ISA and Rubicon desire to enter
into this Agreement for the purpose of granting ISA the right to distribute such products and
services and Rubicon to supply such services. NOW, THEREFORE, the parties hereto, intending to be
legally bound, hereby agree as hereinafter set forth. 1. DEFINITIONS. 1.1 Confidential Information
shall mean all non-public information of a Party, which is disclosed to the other Party hereunder,
including, without limitation, trade secrets, technical information, business information, sales
information, marketing information, customer-buying patterns, algorithms, customer and potential
customer lists and identities, product sales plans, sublicense agreements, inventions, developments,
discoveries, software, know-how, methods, techniques, formulae, data, processes and other trade
secrets and proprietary ideas, whether or not protectable under patent, trademark, copyright or
other areas of law, and any other information marked as "proprietary" or "confidential" at the time
of disclosure. Notwithstanding the foregoing, "Confidential Information" shall not include any
information that (a) was or has become publicly available without restriction through no fault of
the receiving Party or its employees or agents; (b) is received without restriction from a third
party that, to the best knowledge of the receiving Party, did not have an obligation of
confidentiality to the disclosing Party; (c) was rightfully in possession of the receiving Party
without restriction prior to its disclosure by the other Party; or (d) was independently developed
by employees of the receiving Party that had no knowledge of or access to such information, as
evidenced by written records of the receiving Party. 1.2 Contract Services shall mean various
software development and implementation services to be provided by Rubicon as described in one or
more Statement(s) of Work ("SOW") that reference this Agreement in a form substantially similar to
that set forth in Exhibit A. 1.3 Day Rate shall mean the daily rate at which Rubicon will provide
services to ISA or ISA Clients. The Day Rate for each type of service provided will be as per the
rate card set out in Exhibit C, such rates to be subject to annual review by the Parties on the
anniversary of this Agreement provided that such rates may be reviewed on an ad hoc basis at any
time should the Parties become aware of specific information which impacts on the validity or
feasibility of the Day Rate. 1.4 Commission Rate shall mean the commission rate which will be used
to calculate any amount which Rubicon will pay to ISA after the provision of Rubicon Offerings to
ISA Clients as set forth in Exhibit D, such rates to be subject to annual review by the Parties on
the anniversary of this Agreement provided that such rates may be reviewed on an ad hoc basis at any
time should the Parties become aware of specific information which impacts on the validity or
feasibility of the Commission Rate. 1.5 Documentation shall mean the printed and/or electronic
materials relating to the Rubicon Offerings, including, but not limited to, user's manuals and
technical manuals as may be provided by Rubicon to ISA. 1.6 Due Diligence Services shall have the
meaning set forth in Section 3.3, below. 1.7 End User shall mean a party that obtains a license to
use the Rubicon Offerings from ISA or a customer of ISA under the terms and conditions set forth
herein. 1.8 Intellectual Property shall mean any and all trade secrets, patents, copyrights,
trademarks, service marks, trade names, domain names, trade dress, URLs, brand features, know-how
and similar rights of any type under the laws of any applicable governmental authority, including,
without limitation, all applications and registrations relating to any of the foregoing.. 1.9 ISA
Client shall mean: (i) an entity to which Rubicon provides services pursuant to Section 3, below;
and (ii) an entity that ISA has consulted with before or during the Term regarding the provision of
goods or services. 1.10 Notice shall have the meaning ascribed thereto in Section 11.5. 1.11 Parties
shall mean ISA and Rubicon. 1.12 Rubicon Offerings shall mean (i) the software programs described in
Exhibit B, (as may be updated from time to time) in object code format, and including all
corrections, updates, modifications and enhancements to such software that may be provided to ISA by
Rubicon from time to time; and (ii) software development services. 1.13 Term shall have the meaning
ascribed thereto in Section 6.1. 1.14 Share Subscription Agreement shall mean the agreement in the
agreed form between ISA and Rubicon whereby ISA shall subscribe for shares in Rubicon. 2. ISA
RESELLER SERVICES.
<!-- page 2 -->
2.1 Rubicon hereby grants to ISA during the Term (as defined below) and subject to the exclusions
described in 2.4 below an exclusive, non-transferable license in the United States to market, sell,
use, display, perform, sublicense and distribute the Rubicon Offerings, the Documentation and,
subject to Section 2.2, any upgrades thereto, subject to the conditions set forth in this Agreement.
As used in this Section 2.1, the terms "market," "sale," "sell," "distribute," and "sublicense"
shall mean the sale of a license having a term of at least one year to an End User pursuant to which
the End User may use, perform and display the Rubicon Offerings and the Documentation. This license
is granted to ISA for the marketing, sale and distribution of the Rubicon Offerings and the
Documentation to End Users for their internal use only. 2.2 Rubicon hereby grants to ISA during the
Term and subject to the exclusions described in 2.4 below an exclusive, non-transferable license in
the United States to grant licenses to use, display, perform and distribute the Rubicon Offerings
and the Documentation to other resellers, including, but not limited to, distributors, Original
Equipment Manufacturers, system integrators and Value-Added Resellers, for further sale and
distribution to End Users for their use as described above, subject to the conditions set forth in
this Agreement. 2.3 The license grants described in Sections 2.1 and 2.2 shall include all upgrades
to the Rubicon Offerings and the Documentation. Rubicon shall promptly notify ISA of each such
upgrade to the Rubicon Offering and the Documentation which will be available to ISA under this
Agreement. 2.4 The exclusive licenses described in Sections 2.1 and 2.2 shall not include customer
agreements, sales of Rubicon Offerings and/or Documentation which arise through customer marketing
and distribution arrangements which are in place between Rubicon and third parties at the date
hereof. Rubicon agrees not to enter into any additional agreement to sell Rubicon Offerings or
Documentation or additional distribution arrangements with third parties in the United States from
the date hereof without the prior written approval of ISA, which approval shall not be unreasonably
withheld. 3. RUBICON SERVICES. 3.1 Subject to the terms and conditions of this Agreement, Rubicon
shall provide the Contract Services, as agreed between ISA to Rubicon in the relevant SOW, to ISA's
reasonable satisfaction. The Contract Services shall be performed at the facilities and location
reasonably designated by ISA (with appropriate agreements in place to ensure reasonable
reimbursement to Rubicon of out-of-pocket expenses). Upon written request of ISA, Rubicon shall
provide biweekly written reports describing the progress made in performing the Contract Services
since the preceding report, and the progress expected to be made in the next succeeding period. 3.2
ISA may, at any time, request reasonable additions, deletions, or revisions in the Contract Services
by delivering a change order to Rubicon. Upon receipt of a change order from ISA, Rubicon shall
notify ISA of any price revisions which are associated with the change order and if ISA agree to the
revised charges, the parties shall proceed with the Contract Services as revised. All such Contract
Services shall be executed under the terms and conditions of this Agreement and the applicable SOW
(as revised by the change order). If any change order causes an increase or decrease in the cost of
the Services to be performed or scheduled completion date or expenses incurred or to be incurred by
Rubicon, an equitable adjustment will be made by mutual agreement. 3.3 From time to time and as
agreed between ISA and Rubicon, Rubicon shall provide due diligence services regarding the software
and other technology issues of potential merger and acquisition, joint venture or other strategic
partner companies (a "Target Company") that may be identified by ISA (the "Due Diligence Services").
In connection with any such Due Diligence Services, Rubicon agrees that it shall abide by the
reasonable terms of any third party confidentiality agreement that may be entered into by ISA with
any such Target Company on the same terms as are applicable to ISA. Rubicon's fees for such due
diligence services (the "Due Diligence Fees") shall be at agreed upon rates which shall not exceed
the Day Rate. ISA agrees to reimburse Rubicon upon provision of valid receipts for Rubicon's
reasonable out-of-pocket expenses incurred in the provision of the Due Diligence Services. 4.
COMMERCIAL TERMS. 4.1 ISA Fees. In consideration of the services set forth in Section 2, ISA will
sell or market the Rubicon Offerings at pre agreed list prices, and shall receive a commission on
the gross revenues paid for the Rubicon Offerings less VAT if applicable of the Commission Rate;
provided, however, that in the event that Rubicon proposes to charge at other than the Day Rate for
the software development the Parties shall use all reasonable endeavours to agree an equitable
adjustment to the Commission Rate. 4.2 Rubicon Fees. 4.2.1 In consideration of the Contract
Services, Rubicon will receive payment as set forth in an SOW of its undisputed invoices (or its pro
rata share) that it has submitted to ISA immediately following receipt of payment by ISA from the
ISA Client. 4.2.2 In consideration of the Due Diligence Services, ISA shall pay to Rubicon the Due
Diligence Fees within 30 days of receipt from Rubicon of an invoice and any previously requested
supporting documentation, including time charges. 4.2.3 In addition to the payments set forth in
sections 4.2.1 and 4.2.2, above, ISA will pay Rubicon 30% of ISA's profits (defined as gross
revenues less costs directly incurred in the generation of such revenues) on projects for which
Rubicon has provided Contract Services after ISA has recouped any directly attributable start-up
costs with respect to such project up to a cumulative maximum of £100,000 of such costs associated
with all such projects from the date of this agreement. 4.3 Target Revenues. ISA confirms that its
current intention is to try and procure that Rubicon's total gross revenues less VAT if applicable
relating to the provision of services to ISA Clients or to clients referred to Rubicon by ISA will
exceed £1million per annum. The Parties acknowledge that any failure by ISA to procure such revenues
for Rubicon will not constitute a breach of this Agreement and ISA will have no liability for any
such failure or otherwise in connection with this clause 4.3. 4.4 Payment terms. Each party shall
account to the other on a monthly basis in respect of all sales and revenue received, and payments
shall be made within 30 days of receipt of a properly valid invoice. 4.5 Audits. Each Party shall
retain the financial records relating to all payments owed and/or paid under this Agreement for a
period of six years from the date such payment obligation arose. 4.6 Purchase of Rubicon Shares.
This Agreement is conditional upon ISA and Rubicon entering into the Share Subscription Agreement.
<!-- page 3 -->
5. INTELLECTUAL PROPERTY. 5.1 ISA's Intellectual Property. As between ISA and Rubicon, all right,
title and interest in and to Intellectual Property which is created by or provided by ISA,
including, without limitation, as they may be part of or incorporated into any Contract Service or
otherwise used by Rubicon, all goodwill associated therewith and the copyright and all other
Intellectual Property rights inherent in or appurtenant to the foregoing are and shall be and shall
remain the sole property of ISA. Rubicon acknowledges that neither it nor any other persons or
entities will by virtue of this Agreement acquire any ownership interest in the Intellectual
Property of ISA, or the Intellectual Property rights inherent in or appurtenant to any of the
foregoing, or any associated goodwill and that its rights thereunder are strictly limited to those
specifically granted in this Agreement. Rubicon shall not contest ownership by ISA of any of the
foregoing. No right, license, release or other right is granted by implication, estoppel or
otherwise by ISA to Rubicon or any of Rubicon's affiliates except for the rights and licenses
expressly granted under this Agreement. Except for the rights and licenses expressly granted under
this Agreement, ISA reserves all rights to the Intellectual Property of ISA, including, without
limitation, translation rights, rights of modification and rights to source code. 5.2
Works-for-hire. 5.2.1 As regards Intellectual Property created by Rubicon, Rubicon acknowledges and
agrees that those Works, as defined below, shall belong exclusively to ISA subject to payment in
accordance with clause 4.2. Works means, collectively, any work product (of any type), software,
developments, processes, improvements, and all works of authorship, in whole or in part, whether
patentable or not and whether copyrightable or not created as services provided directly to ISA or
on behalf of ISA by Rubicon, which (i) are conceived or made by Rubicon, its employees, contractors,
consultants or agents during the Term and relate directly to the business in which ISA and
Rubicon(during the Term by ISA) are, had been or were proposing to be engaged in; or (ii) are
conceived or made by Rubicon, its employees, contractors, consultants or agents during or after the
Term and are made through the use of any ISA Confidential Information, or which result from any work
performed by Rubicon, its employees, contractors, consultants or agents for ISA. It is agreed that
the terms under which Rubicon agrees to work with ISA, including the Day Rate, reflect and will
reflect any value or potential value of Intellectual Property created by Rubicon on behalf of ISA.
5.2.2 Rubicon shall make full and prompt disclosure to ISA of all Works as they are made (whether or
not conceived or made jointly with others). To the extent copyrightable, all Works shall be deemed
to be "works for hire" and ISA shall be deemed to be the author thereof under the U.S. Copyright
Act. With respect to Works that do not constitute "works for hire," Rubicon, its employees,
contractors, consultants and agents do hereby assign to ISA or its designee all of their respective
right, title and interest in and to such Works and all related patents, patent applications,
copyrights and copyright applications and does hereby agree that these obligations are binding upon
their respective assigns, executors, administrators and other legal representatives. Rubicon, its
employees, contractors, consultants and agents do hereby waive all claims to moral rights to the
Works. During the Term and continuing thereafter, Rubicon does hereby agree to take all such further
reasonable actions on its own behalf and with respect to its employees, contractors, consultants and
agents, including without limitation, the execution and delivery of copyright applications, patent
applications, declarations, oaths, formal assignments, assignments of priority rights, and powers of
attorney, which ISA may deem necessary or desirable in order to protect its rights and interests in
and to the Works. If ISA is unable, after reasonable effort, to secure any necessary signature on
any such documents, any executive officer of ISA shall be entitled as agent and attorney-in-fact to
execute such documents. 5.3 Rubicon's Intellectual Property. As between ISA and Rubicon, all right,
title and interest in and to the Rubicon Offerings and, subject to the provisions of Section 5.2,
any other Intellectual Property of Rubicon, including, without limitation, as used by Rubicon or ISA
hereunder, all goodwill associated therewith and the copyright and all other Intellectual Property
rights inherent in or appurtenant to the foregoing are and shall be the sole property of Rubicon.
ISA acknowledges that, except as otherwise set forth herein, neither it nor any other persons or
entities will by virtue of this Agreement acquire any ownership interest in such Intellectual
Property, or the Intellectual Property rights inherent in or appurtenant to any of the foregoing, or
any associated goodwill and that its rights thereunder are strictly limited to those specifically
granted in this Agreement. ISA shall not contest ownership by Rubicon of any of the foregoing. No
license, release or other right is granted by implication, estoppel or otherwise by Rubicon to ISA
or any of ISA's affiliates except for the rights and licenses expressly granted under this
Agreement. Except for the rights and licenses expressly granted herein, Rubicon reserves all rights
to the Rubicon Service Offerings, including, without limitation, translation rights, rights of
modification and rights to source code. 6. TERM AND TERMINATION; WITHDRAWAL. 6.1 Term. Unless
terminated sooner, the term of this Agreement shall begin on the Effective Date and continue for
three (3) years thereafter (the "Initial Term") and shall automatically renew for additional one (1)
year terms on the terms and conditions set forth herein (each a "Renewal Term" and collectively, the
"Term") unless either party gives the other Party Notice of its intention to terminate this
Agreement ninety (90) days before the end of the Initial Term or Renewal Term, if any. 6.2
Termination. 6.2.1 For Cause. Either Party may serve Notice to the other Party to terminate this
Agreement immediately in the event any material breach of a material provision of this Agreement by
such other Party remains uncured 30 days in the case of a breach of a payment obligation, or 45 days
for all other material breaches, after notice of such breach was received by such other Party. 6.2.2
For Bankruptcy. Either Party may terminate this Agreement immediately upon Notice to the other Party
in the event the other Party (a) permanently ceases operations, (b) becomes or is declared insolvent
or bankrupt, (c) is the subject of any proceeding related to its liquidation or insolvency (whether
voluntary or involuntary) that is not dismissed within 90 calendar days or (d) makes an assignment
for the benefit of creditors. 6.2.3 For Contesting Intellectual Property Rights. Either Party may
terminate this Agreement upon ten Business Day's Notice to the other Party in the event the other
Party contests or challenges to a material degree any of the other Party's Intellectual Property
rights referred to in Sections 5.1, and 5.3, respectively. 7. NON-COMPETITION. 7.1 During the period
beginning on the Effective Date and ending on the later of (i) the end of the Initial Term and (ii)
the date falling two years after completion of the most recent services provided by Rubicon under
clause 7 (the "Non-Competition Period") and in the ISA Geographic Area, as defined below, Rubicon
agrees not to in any capacity, engage or have a financial interest in any ISA Competing Business, as
defined below, or provide managerial, supervisory, administrative, or financial services relating to
any ISA Competing Business, including making available any information or funding to any such ISA
Competing Business. Further, during the Non-Competition Period, Rubicon shall not solicit any
<!-- page 4 -->
employee of ISA or any employee of any ISA Client. If a court determines that the foregoing
restrictions are too broad or otherwise unreasonable under applicable law, including with respect to
time or space, the court is hereby requested and authorized by the Parties to revise the foregoing
restrictions to include the maximum restrictions allowable under applicable law. Rubicon
acknowledges, however, that the Parties have negotiated this Section and that the time limitations,
the limitation on activities and the geographic limitations are reasonable in light of the
circumstances pertaining to ISA and this transaction. "ISA Competing Business" means any person or
entity of any type whatsoever engaged in the business of providing data centre audit and data centre
optimization services. "ISA Geographic Area" means worldwide. 7.2 During the period beginning on the
Effective Date and ending on the later of (i) the end of the Initial Term and (ii) the date falling
two years after completion of the most recent services provided by Rubicon under clause 7 (the
"Non-Competition Period") and in the Rubicon Geographic Area, as defined below, ISA agrees not to in
any capacity, engage or have a financial interest in any Rubicon Competing Business, as defined
below, or provide managerial, supervisory, administrative, or financial services relating to any
Rubicon Competing Business, including making available any information or funding to any such
Rubicon Competing Business. Further, during the Non-Competition Period, ISA shall not solicit any
employee of Rubicon or any employee of any Rubicon Client. If a court determines that the foregoing
restrictions are too broad or otherwise unreasonable under applicable law, including with respect to
time or space, the court is hereby requested and authorized by the Parties to revise the foregoing
restrictions to include the maximum restrictions allowable under applicable law. ISA acknowledges,
however, that the Parties have negotiated this Section and that the time limitations, the limitation
on activities and the geographic limitations are reasonable in light of the circumstances pertaining
to Rubicon and this transaction. "Rubicon Competing Business" means any person or entity of any type
whatsoever engaged in the business of providing software development services for clients. "Rubicon
Geographic Area" means Europe. 7.3 In the event that ISA wishes to carry out any software
development work of any nature during the Non-Competition Period, it will notify Rubicon of the same
and allow Rubicon the opportunity to pitch for such work. 8. CONFIDENTIALITY. 8.1 Confidentiality
Obligations. Except as permitted elsewhere under this Agreement, each Party agrees (a) to take
Reasonable Steps (as defined below) to receive and maintain the Confidential Information of the
other Party in confidence, (b) to take Reasonable Steps (as defined below) not to disclose such
Confidential Information to any third parties other than with the written consent of the disclosing
Party and (c) to promptly notify the other Party upon learning of any law, rule, regulation or court
order that purports to compel disclosure of any Confidential Information of the other Party and to
reasonably cooperate with the other Party in the exercise of the other Party's right to protect the
confidentiality of such Confidential Information, including, but not limited to, seeking to dispute
the cause of such disclosure and/or to receive confidential treatment for the Confidential
Information disclosed as a result of such cause. Neither Party shall use all or any part of the
Confidential Information of the other Party for any purpose other than to perform its obligations,
or the exercise of such Party's rights and licenses, under this Agreement. Each Party shall (i)
limit access to any Confidential Information of the other Party received by it to its employees,
contractors, consultants and agents who have a need-to-know in connection with the performance of
such Party's obligations, or the exercise of such Party's rights, under this Agreement; and (ii)
advise such employees, contractors, consultants and agents of the confidential nature thereof and of
the obligations set forth in this Agreement and similarly bind them in writing. Each Party shall be
responsible for any breaches of the obligations of confidentiality and restricted use set forth
herein by any employee, contractor, consultant or agent to whom such Party disclosed any
Confidential Information of the other Party. As used herein, "Reasonable Steps" means using at least
the same degree of care that the receiving Party uses to protect its own Confidential Information,
and, in any event, no less than reasonable care. 8.2 Exclusions. Nothing contained herein shall
prevent a Party from disclosing Confidential Information pursuant to any applicable law or by a
governmental order, decree, regulation, rule, process or court order; provided, however, that such
Party complies with the notice provisions of Section 8.1(c) to the extent permissible under
applicable laws, rules, regulations or court orders. Such disclosure shall not of itself alter the
status of such information hereunder for all other purposes as Confidential Information. 8.3
Provisions of this Agreement. Each Party agrees that the provisions of this Agreement shall be
treated as Confidential Information and that no reference shall be made thereto without the prior
written consent of the other Party (which consent shall not be unreasonably withheld) except (a) to
its accountants, banks, financing sources, lawyers and other professional advisors, provided that
such parties undertake in writing (or are otherwise bound by rules of professional conduct) to keep
such information strictly confidential, (b) in connection with the enforcement of this Agreement,
(c) in connection with a merger, acquisition or proposed merger or acquisition, or (d) pursuant to
joint press releases prepared in good faith or (e) as permitted under Section 8.2. The Parties will
consult with each other, in advance, with regard to the terms of all proposed press releases, public
announcements and other public statements with respect to the transactions contemplated hereby. 8.4
Termination. Upon termination of this Agreement, all Confidential Information shall be returned to
the disclosing Party or destroyed unless otherwise specified or permitted elsewhere under this
Agreement or as otherwise mutually agreed upon by the Parties. The confidentiality obligations
contained in this Section 8 shall survive termination of this Agreement for a period of three years.
8.5 Injunction. Each Party acknowledges and agrees that the provisions of this Section 8 are
reasonable and necessary to protect the other Party's interests in its Confidential Information,
that any breach of the provisions of this Section 8 may result in irreparable harm to such other
Party, and in such event the exact amount of damages is now and will be difficult to ascertain and
the remedies at law for any such failure would not be reasonable or adequate. Accordingly, in the
event of any breach or threatened breach of the provisions of this Section 8 by a Party hereto, the
other Party, in addition to any other relief available to it at law, in equity or otherwise, shall
be entitled to seek temporary and permanent injunctive relief restraining the breaching Party from
engaging in and/or continuing such conduct, without the necessity of proving actual damages or
posting a bond or other security. Further, the prevailing Party in any such injunctive action shall
be entitled to payment from the other Party of the reasonable attorneys' fees and costs incurred in
such proceeding. 9. REPRESENTATIONS AND WARRANTIES. 9.1 By ISA. ISA hereby represents, covenants and
warrants to Rubicon that: 9.1.1 It has the corporate power to enter into this Agreement; 9.1.2 It
has the right to perform its obligations this Agreement; 9.1.3 When executed and delivered by it,
this Agreement will constitute a legal, valid and binding obligation of it, enforceable against it
in accordance with this Agreement's provisions;
<!-- page 5 -->
9.1.4 ISA shall perform all services required to be performed by ISA under this Agreement in a
professional manner and all ISA personnel assigned to provide such services shall be duly qualified
to provide such services; and 9.1.5 While at Rubicon's facilities, all ISA employees, contractors,
consultants and agents shall observe and follow Rubicon's reasonable work rules, policies and
standards as the same are communicated to ISA or such persons in writing, including, without
limitation, those rules, policies and standards of Rubicon relating to security of and access to its
facilities and to its telephone systems, electronic mail systems and computer systems. ISA shall
cooperate with Rubicon in promptly removing from the Rubicon premises any of such persons who
violates any of the foregoing work rules, policies or standards of Rubicon. 9.2 By Rubicon. Rubicon
hereby represents, covenants and warrants to ISA that: 9.2.1 It has the corporate power to enter
into this Agreement; 9.2.2 It has the right to perform its obligations this Agreement; 9.2.3 When
executed and delivered by it, this Agreement will constitute a legal, valid and binding obligation
of it, enforceable against it in accordance with this Agreement's provisions; 9.2.4 Rubicon shall
perform all services required to be performed by Rubicon under this Agreement in a professional
manner and all Rubicon personnel assigned to provide such services shall be duly qualified to
provide such services; and 9.2.5 While at ISA's facilities, all Rubicon employees, contractors,
consultants and agents shall observe and follow ISA's reasonable work rules, policies and standards
as the same are communicated to Rubicon or such persons in writing, including, without limitation,
those rules, policies and standards of ISA relating to security of and access to its facilities and
to its telephone systems, electronic mail systems and computer systems. Rubicon shall cooperate with
ISA in promptly removing from the ISA premises any of such persons who violates any of the foregoing
work rules, policies or standards of ISA. 10. DISCLAIMER OF WARRANTY, LIMITATION OF LIABILITY AND
INDEMNIFICATION. 10.1 Disclaimer of Warranties. EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, ISA
AND RUBICON HEREBY DISCLAIM ALL WARRANTIES, EXPRESS, IMPLIED OR STATUTORY, WITH RESPECT TO ANY AND
ALL ISA AND RUBICON SERVICES RESPECTIVELY, INCLUDING BUT NOT LIMITED TO ANY IMPLIED WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. 10.2 Limitation of
Liability. EXCEPT IN CONNECTION WITH A BREACH BY EITHER PARTY OF SECTION 8, NEITHER PARTY WILL BE
LIABLE FOR ANY SPECIAL, INDIRECT, CONSEQUENTIAL, EXEMPLARY, PUNITIVE OR INCIDENTAL DAMAGES ARISING
OUT OF OR RELATED TO THIS AGREEMENT, HOWEVER CAUSED AND UNDER ANY THEORY OF LIABILITY (INCLUDING
NEGLIGENCE), EVEN IF SUCH PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. ISA SHALL NOT
BE LIABLE FOR ANY LOSS OF DATA, OR ANY INTERRUPTION OF OR DELAY IN PROVIDING THE SERVICES. EXCEPT IN
CONNECTION WITH A BREACH BY EITHER PARTY OF SECTION 8, EACH PARTY'S LIABILITY FOR DAMAGES HEREUNDER
(OTHER THAN IN RESPECT OF ANY CLAIM FOR MONIES DUE) SHALL NOT EXCEED £200,000. 10.3 Indemnification
by Rubicon. Rubicon shall indemnify and hold harmless ISA and its officers, directors, employees and
agents from and against any and all losses, claims, damages, liabilities, obligations, judgments,
awards, costs, expenses (including reasonable attorneys' fees) and disbursements, including without
limitation, the costs, expenses and disbursements, as and when incurred, of preparing or defending
any action, suit, proceeding or investigation asserted by a third party ("Losses"), caused by, based
upon, arising out of or in connection with a claim by a third party that the Rubicon Offerings
infringe a 3rd party's exiting intellectual property rights or due to the gross negligence,
recklessness or intentional misconduct on the part of Rubicon or its affiliates or its officers,
directors, employees, agents, consultants or users. 10.4 Indemnification by ISA. ISA shall indemnify
and hold harmless Rubicon and its officers, directors, employees and agents from and against any and
all losses, claims, damages, liabilities, obligations, judgments, awards, costs, expenses (including
reasonable attorneys' fees) and disbursements, including without limitation, the costs, expenses and
disbursements, as and when incurred, of preparing or defending any action, suit, proceeding or
investigation asserted by a third party ("Losses"), caused by, based upon, arising out of or in
connection with ISA's role in the provision of the Rubicon Offerings or the gross negligence,
recklessness or intentional misconduct on the part of ISA or its affiliates or its officers,
directors, employees, agents, consultants or users. 10.5 Indemnitee Obligations. Each person seeking
to be reimbursed, indemnified, defended and/or held harmless under Sections 10.3 or 10.4 (each, an
"Indemnitee") shall (a) provide the Party obliged to indemnify such Indemnitee with prompt written
notice of any claim, suit, demand or other action for which such Indemnitee seeks to be reimbursed,
indemnified, defended or held harmless (each, a "Claim"), which notice shall include a reasonable
identification of the alleged facts giving rise to such Claim; (b) grant such Party reasonable
authority and control over the defense and settlement of any such Claim; and (c) reasonably
cooperate with such Party and its agents in defense of any such Claim, at such Party's cost. Each
Indemnitee shall have the right to participate in the defense of any Claim for which such Indemnitee
seeks to be reimbursed, indemnified, defended or held harmless, by using attorneys of such
Indemnitee's choice, at such Indemnitee's expense. Notwithstanding anything to the contrary herein,
any settlement of a Claim for which any Indemnitee seeks to be reimbursed, indemnified, defended or
held harmless under this Section 10 shall be subject to the prior written approval of such
Indemnitee, such approval not to be unreasonably withheld, conditioned or delayed. 10.6 Essential
Part of Bargain. The Parties acknowledge that the disclaimers and limitations set forth in this
Section 10 are an essential element of this Agreement between the Parties and that the Parties would
not have entered into this Agreement without such disclaimers and limitations. 11. MISCELLANEOUS.
11.1 Governing Law and Jurisdiction. This Agreement shall be governed by and interpreted under the
laws of the State of Florida, USA,. The state and federal courts in the jurisdiction in which Palm
City, Florida is located shall have non- exclusive jurisdiction for the purposes of adjudicating any
controversy or claim between the parties concerning any breach or alleged breach of this Agreement
or performance or nonperformance of any obligation under this Agreement, save that the parties agree
that any dispute or claim concerning either clause 8 Confidentiality or clause 5 Intellectual
Property may be raised in any appropriate jurisdiction where the breach or alleged breach has
occurred.
<!-- page 6 -->
11.2 No Assignment. Neither Party shall transfer, assign or cede any rights or delegate any
obligations hereunder, in whole or in part, whether voluntarily or by operation of law, without the
prior written consent of the other Party, which consent may be withheld at the other Party's
reasonable business discretion; provided, however, that in connection with a merger, sale or
transfer of substantially all of the assets or stock of one of the Parties that Party may provide
for the assignee to be bound by the terms hereof. This Agreement shall inure to the benefit of, and
shall be binding upon, the Parties and their respective successors and permitted assigns. 11.3 Good
Faith. The Parties undertake to act in good faith, consistent with their respective rights and
obligations set forth in this Agreement. 11.4 Independent Contractors. In connection with this
Agreement, each Party is an independent contractor. This Agreement does not, and shall not be
construed to, create an employer-employee, agency, joint venture or partnership relationship between
the Parties. Neither Party shall have any authority to act for or to bind the other Party in any
way, to alter any of the provisions of any of the other Party's standard forms of invoices, sales
agreements, warranties or otherwise, to warrant or to execute agreements on behalf of the other, or
to represent that it is in any way responsible for the acts, debts, liabilities or omissions of the
other Party. 11.5 Notices. All notices, reports, payments and other communications required or
permitted to be given under this Agreement (each, a "Notice") shall be in writing and shall be given
either by personal delivery against a signed receipt, by express delivery using an internationally
recognized express courier, or by email (with confirmation of receipt). All Notices shall be
properly addressed as follows, or to such other addresses as may be specified in a Notice given
hereunder: If to ISA: with a copy to: Attn: Joseph Coschera Attn: Daniel J. Dugan, Esq.

1151 SW 30th St., Spector Gadon & Rosen, P.C.

Palm City, Florida 34990 1635 Market St., 7th Floor

joe_coschera@isa-inc.net Phila., PA 19103 ddugan@lawsgr.com If to Rubicon: with a copy to: Attn:
Alistair Hancock Attn: Andrew Kirby Rubicon House Rubicon House Guildford Road Guildford Road West
End, Surrey GU24 9PW West End, Surrey, GU24 9PW A Notice shall be deemed to be effective upon
personal delivery or, if sent via overnight delivery, upon receipt thereof. A Notice sent via email
is deemed effective on the same day (or if such day is not a Business Day, then on the next
succeeding Business Day) if the confirmation that such email was received by the other Party is
received before 5:00 p.m. prevailing Eastern time and on the next day (or if such day is not a
Business Day, then on the next succeeding Business Day) if the confirmation that such email was
received by the other Party is received on or after 5:00 p.m. prevailing Eastern time. 11.6
Amendment or Modification. No subsequent amendment, modification or waiver of any of the provisions
of this Agreement shall be effective unless in writing and signed by the Parties. 11.7 Entire
Agreement. This Agreement sets out the entire agreement between the Parties with respect to the
subject matter of this Agreement and supersedes all prior agreements, proposals, arrangements and
communications, whether oral or written, with respect to the subject matter hereof. 11.8
Severability. If any provision of this Agreement is held by a tribunal of competent jurisdiction to
be illegal, invalid, or otherwise unenforceable in any relevant jurisdiction, then to the fullest
extent permitted by law (a) the same shall not affect the other provisions of this Agreement, (b)
such provision shall be deemed modified to the extent necessary in the tribunal's opinion to render
such provision enforceable, and the rights and obligations of the Parties shall be construed and
enforced accordingly, preserving to the fullest extent the intent and agreements of the Parties set
forth herein and (c) such finding of invalidity, illegality or unenforceability shall not affect the
validity, legality or enforceability of such provision in any other relevant jurisdiction. 11.9 No
Waiver. Failure to enforce any provision of this Agreement is not a waiver of future enforcement of
that or any other provision. No provision of this Agreement will be deemed waived and no breach
excused unless such waiver or excuse is in writing and signed by the Party against whom enforcement
of such waiver or excuse is sought. 11.10 Survival. Sections 5, 7, 8, 10 and 11; any payment
obligations of the Parties hereunder accrued prior to the date of termination; and any other
provision herein expressly surviving termination or necessary to interpret the rights and
obligations of the Parties in connection with the termination of this Agreement will survive the
termination of this Agreement. 11.11 No Third Party Beneficiaries. Except as set forth in Sections
10.3 and 10.4, nothing in this Agreement is intended to confer benefits, rights or remedies unto any
person or entity other than the Parties and their permitted successors and assigns. Without limiting
the generality of the foregoing, the clients, customers, shareholders or End Users shall not be
deemed to be third party beneficiaries of this Agreement or have any other contractual relationship
with ISA by reason of this Agreement. 11.12 Captions and Construction. The headings appearing at the
beginning of the Sections contained in this Agreement have been inserted for identification and
reference purposes only and shall not be used to determine the construction or interpretation of
this Agreement. The nomenclature of the defined terms in this Agreement shall only be used for the
construction of this Agreement, and are not to be used for any other purpose, including, but not
limited to, interpretation for accounting purposes. The parties acknowledge that both ISA and
Rubicon participated in the drafting of this Agreement and agree that any rule of law or legal
decision that may or would require interpretation of any alleged ambiguities in this Agreement
against the party that drafted it has no application and is expressly waived. 11.13 Further
Assurances. Each Party shall perform such acts, execute and deliver such instruments and documents,
and do all such other things as may be reasonably necessary to accomplish the transactions
contemplated in this Agreement.
<!-- page 7 -->
11.14 Language. This Agreement is in the English language only, which language shall be controlling
in all respects, and all versions hereof in any other language hereof shall be for accommodation
only and shall not be binding upon the Parties. All communications and notices to be made or given
pursuant to this Agreement shall be in the English language. All words used in this Agreement will
be construed to be of such gender or number as the circumstances require. Unless otherwise expressly
provided, the word "including" does not limit the preceding word or terms. 11.15 Force Majeure.
Neither Party shall be held to be in breach of this Agreement by reason of a force majeure event,
including, but not limited to, act of God, delay in transportation, fire, flood, earthquake, storm,
war, act of a public enemy, civil commotion or any law, rule, regulation, order or other action by
any public authority or any other matter reasonably beyond a Party's control (a "Force Majeure
Event"). To the extent failure to perform is caused by such a force majeure event, such Party shall
be excused from performance hereunder so long as such event continues to prevent such performance,
and provided the non-performing Party takes all reasonable steps to resume full performance. 11.16
Compliance with Laws. Each Party shall comply with all prevailing laws, rules and regulations and
obtain all necessary approvals, consents and permits required by the applicable agencies of the
government of the jurisdictions that apply to its activities or obligations under this Agreement.
11.17 Public Announcements. Any public announcement or similar publicity with respect to this
Agreement or the transactions contemplated hereby shall be issued only after consultation with the
other party hereto regarding the content of any such announcement or publicity. The parties
recognize that, as publicly traded companies, such consultations will be constrained by applicable
requirements relating to the disclosure of material information on the part of such party under
applicable securities laws. 11.18 Execution in Counterparts, Facsimiles. This Agreement may be
executed in one or more counterparts, each of which shall be deemed an original and all of which
together shall constitute one and the same instrument. This Agreement shall become binding when any
one or more counterparts hereof, individually or taken together, bear the signatures of both Parties
hereto. For the purposes hereof, a facsimile copy of this Agreement, including the signature pages
hereto, shall be deemed an original. IN WITNESS WHEREOF, the Parties to this Agreement by their duly
authorized representatives have executed this Agreement as of the date first written above.
Information Systems Associates, Inc. Rubicon Software Group plc By: /s/ Joseph P. Coschera By /s/
Alistair C. Hancock: Name: Joseph P. Coschera Name: Alistair C. Hancock Title: President and CEO
Title: CEO
