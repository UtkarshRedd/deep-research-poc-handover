<!-- page 1 -->
# STRATEGIC' ALLIANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2012-08-16 |
| Parties | Lightbridge Corporation ("Lightbridge"); Lloyds Register FNMA ("Lloyds"); "Lloyds" and together with "Lightbridge" ("Parties") |
| Source | CUAD v1 / LIGHTBRIDGECORP_11_23_2015-EX-10.26-STRATEGIC ALLIANCE AGREEMENT |

Exhibit 10.26

STRATEGIC ALLIANCE AGREEMENT

This STRATEGIC' ALLIANCE AGREEMENT (including the exhibits and schedules hereto, this "Agreement")
is made and entered into this 16 day of August. 2012 (the "Effective Date") by and between
Lightbridge Corporation, a Nevada Corporation ("Lightbridge"), and Lloyds Register FNMA, acting
through its office in Abu Dhabi ("Lloyds" and. together with Lightbridge. the "Parties").

BACKGROUND

Lightbridge and Lloyds believe that, by cooperatively combining their considerable experience,
expertise and financial and market resources, they can increase the volume of business they can
conduct in in the area of nuclear consulting and strategic advisory services in the United Arab
Emirates. Accordingly, in consideration of the foregoing and of the mutual representations,
warranties, covenants and agreements contained in this Agreement and of other good and valuable
consideration, the receipt and sufficiency of which are hereby acknowledged, the Parties, intending
to be legally bound by this Agreement, agree as follows:

ARTICLE I DEFINITIONS

As used in this Agreement:

"Affiliate" shall mean, with respect to any referenced Person, any other Person that directly or
indirectly, through one or more intermediaries, controls, is controlled by or is under common
control with such referenced Person.

"Business Day" shall mean any day other than a Saturday, a Sunday or a day on which commercial banks
in New York or London are generally authorized or required to close.

"Confidential Information" shall mean, as to any Party as a Recipient, (a) all non-public written,
graphic, oral, electromagnetic or other information (including technical, financial and business
information regarding models, market studies, business plans. clients' names, reports, plans.
projections, data or any other information) relating to the business, strategy, prospects or plans
of the other Party or any of the other Party's Affiliates and (b) any reproductions, copies, notes,
analyses, work papers. compilations, studies, interpretations or any other document or information
derived from any of the foregoing.

"Project" shall mean any undertaking involving the provision of nuclear consulting or strategic
advisory services to any entity in the United Arab Emirates.

"Government Authority" shall mean any national, federal, provincial, state, prefectural or municipal
governmental tribunal or organization, or any political subdivision. instrumentality. Ministry,
department, legislative body, agency, court, tribunal, authority, corporation, commission or other
body or entity of, or under the direct or indirect control of, any of the foregoing, including any
central bank or other fiscal, monetary or other authority.

- 1 -
<!-- page 2 -->
"Law" shall mean any law, statute, ordinance, act, legislation, bill, enactment, policy, treaty,
international agreement, ordinance, judgment, injunction, award, decree, rule, regulation,
interpretation, determination, requirement, writ or order of, or any term of any license or permit
issued by, any Government Authority.

"Person" shall mean any individual, corporation, partnership, limited liability company, joint
venture, association, trust, unincorporated organization or other entity.

"Recipient" shall mean each Party. whenever it has received or is receiving Confidential Information
directly or indirectly from the other Party or any of its Affiliates.

ARTICLE II GENERAL SCOPE; RELATIONSHIP OF THE PARTIES

Section 2.1 General Scope. During the term of this Agreement, the Parties shall actively seek
attractive Projects and, in pursuit of any potential Project, shall promote the Lightbridge-Lloyds
strategic alliance whenever given the opportunity to do so. Each Party shall present to the other
Party every potential Project which such Party desires to pursue.

Section 2.2 Relationship of Parties. With respect to any Project, regardless of which Party
identified such Project, the Parties agree that Lloyds shall act as prime contractor on any Project
and that Lightbridge shall have a right of first refusal to participate in such Project as a sub-
contractor to Lloyds, and shall be entitled to perform such work which would generate up to
twenty-five percent (25%) of the total fees payable to Lloyds as general contractor under the
Project.

Section 2.3 Identification of Projects. Upon identification of a Project, the Parties shall jointly
prepare a proposed plan for the acquisition and execution of the Project, which shall include a
detailed forecasted budget therefore. Upon the award of a prime contract regarding a Project to
Lloyds, the Parties shall attempt in good faith to negotiate and enter into a subcontract agreement
whereby the scope of Lightbridge's services on the Project, and compensation to Lightbridge
therefore, shall be specified.

Section 2.4 No Commitment. Notwithstanding anything to the contrary, the Parties understand and
agree that each Party shall have the right, at all times and in their sole and absolute discretion,
to pursue or not pursue or continue with or not continue with a Project and that neither Party shall
have any obligation or liability to the other Party arising out of or relating to a decision not to
pursue a Project for any reason. Each Party agrees that it shall not pursue any damages against the
other Party or any of its Affiliates arising out of or relating to a decision by such Party or any
of its Affiliates not to pursue or continue with a Project, regardless of' the reason for such
decision.

ARTICLE III COMPLIANCE WITH LAWS

Each Party shall, and shall cause its Affiliates to. at all times, comply in all respects with all
applicable Laws in connection with the transactions contemplated by this Agreement. Without limiting
the generality of the foregoing, each Party (the "Relevant Party") shall not, and shall cause its
Affiliates not to, do or cause to be done any of the following in connection with the transactions
contemplated by this Agreement: (a) directly or indirectly through any other Person. pay, offer to
pay, promise to pay, or authorize the payment of any monies or anything of value to any official or
employee of any Government Authority or any political party or candidate for political office for
the purpose of illegally or improperly inducing or rewarding any action by such official, employee
or candidate favorable to the Relevant Party or any of its Affiliate or (b) take any other action
that, if taken by a Person subject to United States law, would violate the United States Foreign
Corrupt Practices Act. Each Party acknowledges and agrees that is familiar with the United States
Foreign Corrupt Practices Act.

- 2 -
<!-- page 3 -->
ARTICLE IV CONFIDENTIALITY

Section 4.1 Obligation to Maintain and Protect Confidentiality. The Recipient agrees that it shall
receive, protect and maintain the Confidential Information in the strictest confidence. The
Recipient agrees to keep all of the Confidential Information confidential, not to use that
Confidential Information other than for the purpose of this Agreement and not to disclose the same
to any Person other than in accordance with this Agreement without the prior written consent of the
Party from whom such Confidential Information was received, unless:

(a) the Recipient is required to make the disclosure by Law or under any administrative guideline or
directive (whether or not having the force of Law) the observance of which, if not having the force
of Law, is in accordance with the practice of responsible persons similarly situated;

(b) the disclosure is necessary for the purpose of obtaining any consent, authorization, approval or
license from any Government Authority with respect to the transactions effected pursuant to this
Agreement;

(c) it is necessary that the disclosure be made to any taxation or fiscal authority;

(d) the disclosure is made in accordance with Section 4.3 to the officers, employees, or agents of
the Recipient, or to the professional advisors of the Recipient for the purpose of obtaining
professional advice in relation to this Agreement or any matter the subject thereof or otherwise for
the purpose of consulting those professional advisors;

(e) the disclosure is necessary or desirable in relation to any procedure for discovery of documents
and any proceedings before any court, tribunal (including any arbitral tribunal) or regulatory body;
or

In respect of any Confidential Information to be disclosed by the Recipient pursuant to the
exceptions referred to in this Section 4.1, the Recipient must, prior to such disclosure, notify the
Party from whom the Confidential Information was received of the need or intention to disclose.

Section 4.2 Exceptions to Confidentiality. The confidentiality provisions contained in this
Agreement do not apply to information or details of the Confidential Information which:

- 3 -
<!-- page 4 -->
(a) are part of the public domain at the time acquired by the Recipient;

(b) are not acquired by the Recipient. either directly or indirectly, from the disclosing Party or
its Affiliates;

(c) are made known to the Recipient by a Person who did not acquire knowledge of the information or
of the details, either directly or indirectly, under an obligation of confidentiality or has an
independent right to disclose same;

(d) after being made known to the Recipient, becomes part of the public domain through no fault of
the Recipient or of any Person to which the Recipient has disclosed details of the Confidential
Information; or

(e) the Recipient can establish were in its possession prior to the date of disclosure of such
details by the disclosing Party.

Section 4.3 Disclosure to Affiliates; Safekeeping. The Recipient agrees that prior to disclosure of
Confidential Information to any Affiliate, it will inform the Affiliate of the confidential nature
of the Confidential Information and require such Affiliate to treat the Confidential Information as
confidential according to this Agreement as if such Affiliate were a Recipient. The Recipient shall,
and shall cause each of its Affiliate to, use its best endeavors to procure and ensure at all times
the safe and confidential storage of Confidential Information in their possession or control.
Without limiting the foregoing, the Recipient shall, and shall cause its Affiliate to, safeguard the
Confidential Information to the same extent as if it were information of or pertaining to the
Recipient. and the Recipient acknowledges that the release, publication or dissemination of the
Confidential Information could be harmful to a Project or a Party.

Section 4.4 Return of Confidential Information. The Recipient agrees that upon the written request
of the disclosing Party it will promptly (a) return all Confidential Information and any and all
copies thereof to the disclosing Party and shall require each of its Affiliate to do likewise or (b)
destroy the same and deliver a certificate of destruction to the disclosing Party.

Section 4.5 Survival of Confidentiality Obligations. This Article IV shall survive termination of
this Agreement.

ARTICLE V EVENTS OF DEFAULT; TERM AND TERMINATION

Section 5.1 Events of Default. Each of the following events constitutes an event of default (an
"Event of Default") by a Party (the "Defaulting Party") under this Agreement:

5.1.1 the Defaulting Party fails to perform in any material respect any obligation under this
Agreement. or any representation or warranty made by the Defaulting Party in this Agreement is
untrue in any material respect, and such failure is not cured within 30 days after the
non-Defaulting Party notifies the Defaulting Party of such failure; or

- 4 -
<!-- page 5 -->
5.1.2 the Defaulting Party:

(a) files a petition or otherwise commences, or authorizes or acquiesces in the commencement of. a
proceeding or cause under any bankruptcy, winding up, liquidation. insolvency, receivership or
similar law for the protection of creditors or has such a petition filed or proceeding commenced
against it. which, in the case of an involuntary petition or proceeding, remains undismissed and
unstayed for 90 days; or

(b) is otherwise adjudicated insolvent or unable to pay its debts as they become due, otherwise
makes an assignment for the benefit of its creditors or is dissolved or otherwise terminated.

Section 5.2 Remedies. Upon the occurrence and during the continuation of any Event of Default, the
non-Defaulting Party may immediately terminate this Agreement by giving notice to the Defaulting
Party. The non-Defaulting Party's remedy set forth in the immediately preceding sentence is not
intended to be exclusive and is in addition to, and may be exercised concurrently with, any other
right or remedy that may otherwise be available to the Non-Defaulting Party at law or in equity.
Without limiting the foregoing and for the avoidance of doubt, the Non-Defaulting Party may recover
damages against the Defaulting Party even if this Agreement is terminated (including damages arising
out of such termination).

Section 5.3 Term and Termination. This Agreement is effective on the Effective Date and shah
continue in effect until the earlier of (a) the fifth (5t h) anniversary of the Effective Date, and
(b) termination by either Party for any reason upon thirty (30) days' written notice to the other
Party; provided, however, that no Party shall be able to terminate this Agreement so long as such
Party is a Defaulting Party under this Agreement. The occurrence of the Termination Date shall not
relieve either Party of any unfulfilled obligation or undischarged liability of such Party relating
to the period prior to the Termination Date.

ARTICLE VI NOTICE

Section 6.1 Notices. All notices, consents, demands or other communications (collectively, the
"Notices") made pursuant to this Agreement shall be in writing, in the English language and signed
and correctly dated by the Party sending same. All Notices shall he delivered personally (by courier
or otherwise) or by facsimile to the receiving Party at the address given below:

If to Lightbridge With copy to: Addressed to: Lightbridge Corporation Pillsbury Winthrop Shaw
Pittman LLP 1600 Tysons Boulevard 2300 N Street, NW Tysons Corner, VA 22102 Washington, DC 20037
Attn: James D. Guerra Attn: Louis A. Bevilacqua Tel.: 571-730-1200 Tel.: 202-663-8158

- 5 -
<!-- page 6 -->
If to Lloyds With copy to: Addressed to: Energy Area Business Manager Global Nuclear Director
Lloyd's Register, EMEA Lloyd's Register Festival Office Tower, Suite 2001 71 Fenchurch Street Dubai
Festival City London Al Rebat Street EC3M 4BS Ras Al Khor, Deira United Kingdom Dubai Tel: +44 20
7423 1677 United Arab Emirates Tel.: +971 4 701 4236

Section 6.2 Effective Date of Notices. Any Notice delivered personally shall be deemed to have been
given on the date it is so delivered, or upon attempted delivery if acceptance of delivery is
refused, and any notice delivered by facsimile transmission shall be deemed to have been given on
the first Business Day it is received (or on the first Business Day after it is received, if
received on other than a Business Day). Notice given in any other manner shall be deemed to have
been given on the first Business Day it is received (or on the first Business Day after it is
received, if received on other than a Business Day).

Section 6.3 Change of Address for Notices. A Party may change the address to which Notices hereunder
are to be sent to it by giving Notice of such change of address in the manner provided in Section
11.1.

ARTICLE VII MISCELLANEOUS

Section 7.1 No Partnership; No Agency. Nothing contained in this Agreement shall be construed so as
to create a partnership, joint venture or common enterprise between the Parties. Neither Party shall
be liable for the debts or obligations of the other Party. Each Party shall limit its activities
pursuant to the terms of this Agreement to that of the functions and related services expressly set
forth herein. Without limiting the foregoing, neither Party is authorized to assume or create any
obligation, liability, or responsibility, expressed or implied, on behalf of or in the name of the
other Party or any of its Affiliates or to bind the other Party or any of its Affiliates in any
manner whatsoever, and neither Party shall hold itself out as an agent or legal representative of
the other Party or any of its Affiliates.

Section 7.2 Governing Law. The terms of this Agreement shall be governed by and construed in
accordance with the laws of England.

- 6 -
<!-- page 7 -->
Amendment and Modifications. This Agreement may be amended, modified or supplemented at any time by
the Parties but only pursuant to an instrument in writing signed by both of them.

Section 7.4 Binding Effect. This Agreement shall be binding upon and inure to the benefit of the
Parties and their respective successors and permitted assigns.

Section 7.5 Assignment. No Party may assign this Agreement without the prior written consent of the
other Party.

Section 7.6 Entire Agreement. This Agreement, together with that certain Non-Circumvention and
Confidentiality Agreement, dated December 16, 2011, between Lightbridge and Lloyd's Register Group
Services Limited, contains the entire Agreement of the Parties with respect to the transactions
contemplated hereby and supersedes all prior understandings and agreements of the Parties with
respect to the subject matter hereof.

Section 7.7 Severability. If any provision of this Agreement is held invalid or unenforceable. all
other provisions will not be affected. With respect to the provision held invalid or unenforceable,
the Parties will amend this Agreement as necessary to effect the original intent of the parties to
this Agreement as closely as possible.

Section 7.8 No Third-Party Beneficiaries. Nothing in this Agreement, expressed or implied, is
intended to confer any rights or remedies under or by reason of this Agreement on any Person other
than the Parties and their respective successors and permitted assigns, nor is anything in this
Agreement intended to relieve or discharge any obligation of any third person to any Party or give
any third person any right of subrogation or action against any Party.

Section 7.9 Execution in Counterparts. This Agreement may be executed in any number of counterparts
and by different Parties in separate counterparts, each of which when so executed and delivered
shall be deemed to be an original and all of which taken together shall constitute but one and the
same instrument. Delivery of an executed counterpart of the signature page of this Agreement by
facsimile transmission shall he equally as effective as delivery of a manually executed counterpart
of this Agreement.

Section 7.10 Expenses. Each of the Parties shall pay its own costs incurred in connection with the
negotiation, preparation and execution of this Agreement.

[THE REST OF THIS PAGE IS LEFT INTENTIONALLY BLANK]

- 7 -
<!-- page 8 -->
IN WITNESS WHEREOF, the Parties hereto have caused this Agreement to be duly executed as of the day
and year first above written.

Lightbridge Corporation By:/s/ James D. Guerra Name: James D. Guerra Title: COO

Lloyds Register EMEZ By:/s/ N.D.A.M. Nooren Name: N.D.A.M. Nooren Title: AREA Business Manager -
Energy MEAA

- 8 -
