<!-- page 1 -->
# AGENCY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Agency Agreement |
| SEC Filing Date | 1996-08-01 |
| Parties | (AFSALA Bancorp, Inc. (the "Company"); Amsterdam Federal Savings and Loan Association ("Association"); Savings Association Insurance Fund ("SAIF"); Federal Deposit Insurance Corporation ("FDIC"); Capital Resources, Inc. ("Capital Resources")) |
| Source | CUAD v1 / AFSALABANCORPINC_08_01_1996-EX-1.1-AGENCY AGREEMENT |

Exhibit 1.1

1,265,000 Shares (subject to increase up to 1,454,750 shares in the event of an oversubscription)

AFSALA BANCORP, INC. (a Delaware corporation)

COMMON STOCK ($0.10 Par Value Per Share)

Subscription Price: $10.00 Per Share

AGENCY AGREEMENT

____________, 1996

Capital Resources, Inc. 1701 K Street, N.W. Suite 700 Washington, D.C. 20006

Ladies and Gentlemen:

AFSALA Bancorp, Inc. (the "Company") and Amsterdam Federal Savings and Loan Association, a federally
chartered mutual savings and loan association ("Association"), with its deposit accounts insured by
the Savings Association Insurance Fund ("SAIF") administered by the Federal Deposit Insurance
Corporation ("FDIC"), hereby confirm their agreement with Capital Resources, Inc. ("Capital
Resources") as follows:

SECTION 1. The Offering. The Association, in accordance with and pursuant to its plan of conversion
adopted by the Board of Directors of the Association (the "Plan"), intends to be converted from a
federally-chartered mutual savings and loan association to a federally-chartered stock savings bank
and will sell all of its issued and outstanding stock to the Company. The Company will offer and
sell its common stock (the "Common Stock") in a subscription offering ("Subscription Offering") to
(1) tax qualified employee benefit plans of the Association, (2) depositors of the Association as of
March 31, 1995 ("Eligible Account Holders"), (3) depositors of the Association as of June 30, 1996
("Supplemental Eligible Account Holders"), (4) certain other deposit account holders and borrower
members of the Association ("Other Members") and (5) to its employees, officers and directors,
pursuant to rights to subscribe for shares of Common Stock (the "Shares"). Subject to the prior
subscription rights of the above-listed parties, the Company may offer for sale in a public offering
(the "Public Offering," and when referred to together with the Subscription Offering, the
"Subscription and Public Offerings") conducted after the Subscription Offering, the Shares not so
subscribed for or ordered in the Subscription Offering to the general public (all such offerees
being referred to in the aggregate as "Eligible Offerees"). Shares may also be sold in the Public
Offering by a selling group of broker-dealers organized and managed by Capital Resources. It is
acknowledged that the purchase of Shares in the Subscription and Public Offerings is subject to
maximum and minimum purchase limitations as described in the Plan and that the Company may reject in
whole or in part any subscriptions received from subscribers in the Public Offering.

The Company and the Association desire to retain Capital Resources to assist the Company with its
sale of the Shares in the Subscription and Public Offerings. By and through this Agreement, the
Company and the Association confirm the retention of Capital Resources to assist the Company and the
Association during the Subscription and Public Offerings.

The Company has filed with the Securities and Exchange Commission (the "Commission") a registration
statement on Form S-l (File No. 333-6399) containing an offering prospectus relating to the
Subscription and Public Offerings for the registration of the Shares under the Securities Act of
1933, as amended (the "1933 Act"), and has filed such amendments thereto, if any, and such amended
prospectuses as may have been required to the date hereof (the "Registration Statement"). The
prospectus, as amended, included in the Registration Statement at the time it initially becomes
effective, is hereinafter called the "Offering Prospectus", except that if any prospectus is filed
by the Company pursuant to Rule 424(b) or (c) of the rules and regulations of the Commission under
the 1933 Act (the "1933 Act Regulations") differing from the offering prospectus included in the
Registration Statement at the time it initially becomes effective, the term "Offering Prospectus"
shall refer to the offering prospectus filed pursuant to Rule 424(b) or (c) from and after the time
said offering prospectus is filed with or mailed to the Commission for filing.

In accordance with Title 12, Part 563b of the Code of Federal Regulations (the "Conversion
Regulations"), the Association has filed with the Office of Thrift Supervision (the "OTS") an
Application for Approval of Conversion on Form AC (the "Conversion Application") including the
Offering
<!-- page 2 -->
Prospectus and has filed such amendments thereto, if any, as may have been required by the OTS. The
Conversion Application has been approved by the OTS. The Company has filed with the OTS its
application on Form H-(e)lS (the "Holding Company Application") to acquire the Association under the
Home Owners' Loan Act, as amended (12 U.S.C. ss. 1467a) ("HOLA").

SECTION 2. Retention of Capital Resources; Compensation; Sale and Delivery of the Shares. Subject to
the terms and conditions herein set forth, the Company and the Association hereby appoint Capital
Resources as their agent to advise and assist the Company and the Association with the Company's
sale of the Shares in the Subscription and Public Offerings.

On the basis of the representations, warranties, and agreements herein contained, but subject to the
terms and conditions herein set forth, Capital Resources accepts such appointment and agrees to
consult with and advise the Company and the Association as to matters relating to the Conversion and
the Subscription and Public Offerings. It is acknowledged by the Company and the Association that
Capital Resources shall not be required to purchase any Shares and shall not be obligated to take
any action which is inconsistent with any applicable laws, regulations, decisions or orders. If
requested by the Company or the Association, Capital Resources also may assemble and manage a
selling group of broker dealers which are members of the National Association of Securities Dealers,
Inc. (the "NASD") to participate in the solicitation of purchase orders for Shares under a selected
dealers' agreement ("Selected Dealers' Agreement"). The obligations of Capital Resources pursuant to
this Agreement shall terminate upon the completion or termination or abandonment of the Plan by the
Company or the Association or upon termination of the Subscription and Public Offerings, or if the
terms of the Conversion are substantially amended so as to materially and adversely change the role
of Capital Resources, but in no event later than 45 days after the completion of the Subscription
and Public Offerings (the "End Date"). All fees due to Capital Resources but unpaid will be payable
to Capital Resources in next day funds at the earlier of the Closing Date (as hereinafter defined)
or the End Date. In the event the Subscription and Public Offerings are extended beyond the End
Date, the Company, the

-2-

Association and Capital Resources may mutually agree to renew this Agreement under mutually
acceptable terms.

In the event the Company is unable to sell a minimum of 935,000 Shares within the period herein
provided, this Agreement shall terminate, and the Company shall refund to any persons who have
subscribed for any of the Shares, the full amount which it may have received from them plus accrued
interest as set forth in the Offering Prospectus; and none of the parties to this Agreement shall
have any obligation to the other parties hereunder, except as set forth in this Section 2 and in
Sections 7, 9 and 10 hereof.

In the event the closing does not occur, the Conversion is terminated or otherwise abandoned, or the
terms of the Conversion are substantially amended so as to materially and adversely change the role
of Capital Resources, Capital Resources shall be reimbursed for all reasonable legal fees and
out-of-pocket expenses for rendering financial advice to the Association concerning the structure of
the Conversion, preparing a market and financial analysis, performing due diligence and assisting in
the preparation of the Application for Conversion and the Registration Statement, which shall be
paid upon such termination, abandonment or amendment or within five days of such event.

If all conditions precedent to the consummation of the Conversion, including, without limitation,
the sale of all Shares required by the Plan to be sold, are satisfied, the Company agrees to issue
or have issued the Shares sold in the Subscription and Public Offerings and to release for delivery
certificates for such Shares on the Closing Date (as hereinafter defined) against payment to the
Company by any means authorized by the Plan, provided, however, that no certificates shall be
released for such shares until the conditions specified in Section 7 hereof shall have been complied
with to the reasonable satisfaction of Capital Resources and its counsel. The release of Shares
against payment therefor shall be made on a date and at a time and place acceptable to the Company,
the Association and Capital Resources. The date upon which the Company shall release or deliver the
Shares sold in the Subscription and Public Offerings, in accordance with the terms hereof, is herein
called the "Closing Date."

Capital Resources shall receive the following compensation for its services hereunder:

(a) (i) a marketing fee in the amount of (x) two percent (2.0%) of the aggregate dollar amount of
all Shares sold in the Subscription and Public Offerings, excluding sales made through broker
assisted purchases or by other NASD member firms participating in the Subscription and Public
Offerings pursuant to the Selected Dealers' Agreement, if any (for which Capital Resources'
compensation shall be pursuant to sub-paragraph (ii)) and excluding shares sold to the Association's
Employee Stock Ownership Plan, directors, officers or employees and any member of such person's
immediate family (defined to include children, spouse, parents, grandparents and grandchildren);

(ii) a management fee in the amount of one percent and one-half (1.5%) of the aggregate dollar
amount of Shares sold through broker assisted purchases or through selected dealers, if any.
<!-- page 3 -->
(b) Capital Resources shall be reimbursed for all reasonable out-of-pocket expenses, including, but
not limited to, legal fees, travel, communications and postage, incurred by it whether or not the
Conversion is successfully completed as set forth in Section 7 hereof. Capital Resources shall be
reimbursed promptly for all out-of-pocket expenses upon receipt by the Company or the Association of
a monthly itemized bill summarizing such expenses since the date of the last bill, if any, to the
date

-3-

of the current bill.

In the event other broker-dealers are assembled and managed by Capital Resources under a selling
syndicate to participate in the Public Offering pursuant to the Selected Dealers' Agreement or
participate in the Public Offering as assisting brokers, the Company and the Association will be
directly responsible for the payment of selected dealers' commissions to such participating firms or
assisting brokers' commissions up to a maximum of four percent (4%) and four percent (4%),
respectively, of the amount of stock sold by such firms. Capital Resources' fees are limited to
those stated in subparagraph (a) above and all other brokers will be paid fees based upon the
capacity in which they are acting in the particular stock sale.

All subscription funds received by Capital Resources (and if by check shall be made payable to the
Company) or by other NASD registered broker-dealers soliciting subscriptions (if any) shall be
transmitted (either by U.S. Mail or similar type of transmittal) to the Company by noon of the
following business day.

SECTION 3. Offering Prospectus; Subscription and Public Offerings. The Shares are to be initially
offered in the Subscription and Public Offerings at the Purchase Price as set forth on the cover
page of the Offering Prospectus.

SECTION 4. Representations and Warranties. The Company and the Association jointly and severally
represent and warrant to Capital Resources as follows:

(a) The Registration Statement was declared effective by the Commission on __________, 1996. At the
time the Registration Statement, including the Offering Prospectus contained therein (including any
amendment or supplement thereto), became effective, the Registration Statement complied in all
material respects with the requirements of the 1933 Act and the 1933 Act Regulations and the
Registration Statement, including the Offering Prospectus contained therein (including any amendment
or supplement thereto), any Blue Sky Application or any Sales Information (as such terms are defined
previously herein or in Section 8 hereof) authorized by the Company or the Association for use in
connection with the Subscription and Public Offerings did not contain an untrue statement of a
material fact or omit to state a material fact required to be stated therein or necessary to make
the statements therein, in light of the circumstances under which they were made, not misleading,
and at the time any Rule 424(b) or (c) Offering Prospectus was filed with or mailed to the
Commission for filing and at the Closing Date referred to in Section 2, the Registration Statement
including the Offering Prospectus contained therein (including any amendment or supplement thereto),
any Blue Sky Application or any Sales Information (as such terms are defined previously herein or in
Section 8 hereof) authorized by the Company or the Association for use in connection with the
Subscription and Public Offerings will not contain an untrue statement of a material fact or omit to
state a material fact necessary in order to make the statements therein, in the light of the
circumstances under which they were made, not misleading; provided, however, that the
representations and warranties in this Section 4(a) shall not apply to statements in or omissions
from such Registration Statement or Offering Prospectus made in reliance upon and in conformity with
written information furnished to the Company or the Association by Capital Resources expressly
regarding Capital Resources for use under the caption "The Conversion-Marketing Arrangements."

(b) The Conversion Application, including the Offering Prospectus, was approved by the OTS on
__________, 1996. At the time of the approval of the Conversion Application, including

-4-

the Offering Prospectus, by the OTS (including any amendment or supplement thereto) and at all times
subsequent thereto until the Closing Date, the Conversion Application, including the Offering
Prospectus, will comply in all material respects with the Conversion Regulations and any other rules
and regulations of the OTS. The Conversion Application, including the Offering Prospectus (including
any amendment or supplement thereto), does not include any untrue statement of a material fact or
omit to state any material fact required to be stated therein or necessary to make the statements
therein, in light of the circumstances under which they were made, not misleading; provided,
however, that representations or warranties in this Section 4(b) shall not apply to statements or
omissions made in reliance upon and in conformity with written information furnished to the
Association by Capital Resources expressly regarding Capital Resources for use in the Offering
Prospectus contained in the Conversion Application under the caption "The Conversion- Marketing
Arrangements."
<!-- page 4 -->
(c) The Company has filed with the OTS the Holding Company Application and will have received, as of
the Closing Date, approval of its acquisition of the Association from the OTS.

(d) No order has been issued by the OTS, the Commission, the FDIC (and hereinafter reference to the
FDIC shall include the SAIF), or to the best knowledge of the Company or the Association any State
regulatory or Blue Sky authority, preventing or suspending the use of the Offering Prospectus and no
action by or before any such government entity to revoke any approval, authorization or order of
effectiveness related to the Conversion is, to the best knowledge of the Association or the Company,
pending or threatened.

(e) At the Closing Date referred to in Section 2, the Plan will have been adopted by the Board of
Directors of both the Company and the Association, the Company and the Association will have
completed all conditions precedent to the Conversion and the offer and sale of the Shares will have
been conducted in accordance with the Plan, the Conversion Regulations and all other applicable
laws, regulations, decisions and orders, including all terms, conditions, requirements and
provisions precedent to the Conversion imposed upon the Company or the Association by the OTS, the
Commission or any other regulatory authority and in the manner described in the Offering Prospectus.
At the Closing Date, no person will have sought to obtain review of the final action of the OTS, to
the knowledge of the Company or the Association, in approving the Plan or in approving the
Conversion or the Company's application to acquire all of the capital stock and control of the
Association pursuant to the HOLA or any other statute or regulation.

(f) The Association is now a duly organized and validly existing federally-chartered savings and
loan association in mutual form of organization and upon the Conversion will become a duly organized
and validly existing federally-chartered savings bank in capital stock form of organization, in both
instances duly authorized to conduct its business and own its property as described in the
Registration Statement and the Offering Prospectus; the Company and the Association have obtained
all material licenses, permits and other governmental authorizations currently required for the
conduct of their respective businesses; all such licenses, permits and governmental authorizations
are in full force and effect, and the Company and the Association are in all material respects
complying with all laws, rules, regulations and orders applicable to the operation of their
businesses; and the Association is in good standing under the laws of the United States and is duly
qualified as a foreign corporation to transact business and is in good standing in each jurisdiction
in which its ownership of property or leasing of properties or the conduct of its business requires
such qualification, unless the failure to be so qualified in one or more of such jurisdictions would
not have a material adverse effect on the condition, financial or otherwise, or the business,
operations or income of the Association. The Association does not own

-5-

equity securities or any equity interest in any other business enterprise except as described in the
Offering Prospectus. Upon the completion of the Conversion of the Association pursuant to the Plan
to a federally-chartered stock savings bank, (i) all of the authorized and outstanding capital stock
of the Association will be owned by the Company, and (ii) the Company will have no direct
subsidiaries other than the Association. The Conversion will have been effected in all material
respects in accordance with all applicable statutes, regulations, decisions and orders; and except
with respect to the filing of certain post-sale, post-conversion reports and documents in compliance
with the 1933 Act Regulations or the OTS's resolutions or letters of approval. All terms,
conditions, requirements and provisions with respect to the Conversion imposed by the Commission,
the OTS and the FDIC, if any, will have been complied with by the Company and the Association in all
material respects or appropriate waivers will have been obtained and all material notice and waiting
periods will have been satisfied, waived or elapsed.

(g) The Company has been duly incorporated and is validly existing as a corporation in good standing
under the laws of the State of Delaware with corporate power and authority to own, lease and operate
its properties and to conduct its business as described in the Registration Statement and the
Offering Prospectus, and the Company is qualified to do business as a foreign corporation in any
jurisdiction in which the conduct of its business requires such qualification, except where the
failure to so qualify would not have a material adverse effect on the business of the Company.

(h) The Association is a member of the Federal Home Loan Bank of New York ("FHLBNY"); and the
deposit accounts of the Association are insured by the FDIC up to the applicable limits. Upon
consummation of the Conversion, the liquidation account for the benefit of Eligible Account Holders
and Supplemental Eligible Account Holders will be duly established in accordance with the
requirements of the Conversion Regulations.

(i) The Company and the Association have good and marketable title to all assets owned by them which
are material to the business of the Company and the Association and to those assets described in the
Registration Statement and Offering Prospectus as owned by them, free and clear of all liens,
charges, encumbrances or restrictions, except such as are described in the Registration Statement
and Offering Prospectus or are not materially significant or important in relation to the business
of the Company and the Association; and all of the leases and subleases material to the business of
the Company and the Association under which the Company or the Association holds properties,
including those described in the Registration Statement and Offering Prospectus,

are in full force and effect.
<!-- page 5 -->
(j) The Association has received an opinion of its counsel, Malizia, Spidi, Sloane & Fisch, P.C.,
with respect to the federal income tax consequences of the Conversion of the Association from mutual
to stock form, the acquisition of the capital stock of the Association by the Company, the sale of
the Shares, and the reorganization of the Association as described in the Registration Statement and
the Offering Prospectus and an opinion from KPMG Peat Marwick, LLP ("KPMG") with respect to the
State income tax consequences of the proposed transaction; all material aspects of the opinions of
Silver Freedman & Taff, L.L.P. and KPMG are accurately summarized in the Offering Prospectus; and
the facts and representations upon which such opinions are based are truthful, accurate and
complete, and neither the Association nor the Company will take any action inconsistent therewith.

(k) The Company and the Association have all such power, authority, authorizations, approvals and
orders as may be required to enter into this Agreement, to carry out the provisions and conditions
hereof and to issue and sell the Capital Stock of the Association to the Company and Shares to be
sold by the Company as provided herein and as described in the Offering Prospectus. The

-6-

consummation of the Conversion, the execution, delivery and performance of this Agreement and the
consummation of the transactions herein contemplated have been duly and validly authorized by all
necessary corporate action on the part of the Company and the Association and this Agreement has
been validly executed and delivered by the Company and the Association and is the valid, legal and
binding agreement of the Company and the Association enforceable in accordance with its terms
(except as the enforceability thereof may be limited by bankruptcy, insolvency, moratorium,
reorganization or similar laws relating to or affecting the enforcement of creditors' rights
generally or the rights of creditors of savings and loan holding companies, the accounts of whose
subsidiaries are insured by the FDIC or by general equity principles regardless of whether such
enforceability is considered in a proceeding in equity or at law, and except to the extent, if any,
that the provisions of Sections 9 and 10 hereof may be unenforceable as against public policy).

(l) The Company and the Association are not in violation of any directive which has been delivered
to the Company or the Association or of which management of the Company or the Association has
actual knowledge from the OTS, the Commission, the FDIC or any other agency to make any material
change in the method of conducting their businesses so as to comply in all material respects with
all applicable statutes and regulations (including, without limitation, regulations, decisions,
directives and orders of the OTS, the Commission and the FDIC) and except as set forth in the
Registration Statement and the Offering Prospectus there is no suit or proceeding or, to the
knowledge of the Company or the Association, charge, investigation or action before or by any court,
regulatory authority or governmental agency or body, pending or, to the knowledge of the Company or
the Association, threatened, which might materially and adversely affect the Conversion, the
performance of this Agreement or the consummation of the transactions contemplated in the Plan and
as described in the Registration Statement or which might result in any material adverse change in
the condition (financial or otherwise), earnings, capital, properties, business affairs or business
prospects of the Company or the Association or which would materially affect their properties and
assets.

(m) The financial statements which are included in the Registration Statement and which are part of
the Offering Prospectus fairly present the financial condition, results of operations, retained
earnings and cash flows of the Association at the respective dates thereof and for the respective
periods covered thereby, and comply as to form in all material respects with the applicable
accounting requirements of Title 12 of the Code of Federal Regulations and generally accepted
accounting principles ("GAAP") (including those requiring the recording of certain assets at their
current market value). Such financial statements have been prepared in accordance with generally
accepted accounting principles consistently applied through the periods involved, present fairly in
all material respects the information required to be stated therein and are consistent with the most
recent financial statements and other reports filed by the Association with the OTS and the FDIC,
except that accounting principles employed in such filings conform to requirements of such
authorities and not necessarily to generally accepted accounting principles. The other financial,
statistical and pro forma information and related notes included in the Offering Prospectus present
fairly the information shown therein on a basis consistent with the audited and unaudited financial
statements, if any, of the Association included in the Offering Prospectus, and as to the pro forma
adjustments, the adjustments made therein have been properly applied on the basis described therein.

(n) Since the respective dates as of which information is given in the Registration Statement and
the Offering Prospectus, except as may otherwise be stated therein: (i) there has not been any
material adverse change, financial or otherwise, in the condition of the Company or the Association,
or of the Company and the Association considered as one enterprise, or in the earnings, capital,

-7-
<!-- page 6 -->
properties, business affairs or business prospects of the Company or the Association, whether or not
arising in the ordinary course of business, (ii) there has not been (A) an increase of greater than
$500,000 in the long term debt of the Association or (B) an increase of $100,000 or more in loans
past due 90 days or more or (C) an increase of $100,000 or more in real estate acquired by
foreclosure or (D) a decrease of $50,000 or more in the allowance for loan losses or (E) any
decrease in total retained earnings or (F) a decrease in net income from January 1, 1996 to date
when compared to the like period in 1995 or (G) any change in total assets of the Association in an
amount greater than $2,000,000 or (H) any other material change which would require an amendment to
the Offering Prospectus; (iii) the Association has not issued any securities or incurred any
liability or obligation for borrowing other than in the ordinary course of business; (iv) there have
not been any material transactions entered into by the Company or the Association, except with
respect to those transactions entered into in the ordinary course of business; and (v) the
capitalization, liabilities, assets, properties and business of the Company and the Association
conform in all material respects to the descriptions thereof contained in the Offering Prospectus,
and neither the Company nor the Association have any material liabilities of any kind, contingent or
otherwise, except as set forth in the Offering Prospectus.

(o) As of the date hereof and as of the Closing Date, neither the Company nor the Association is in
violation of its certificate of incorporation or charter, respectively, or its bylaws (and the
Association will not be in violation of its charter or bylaws in capital stock form as of the
Closing Date) or in default in the performance or observance of any material obligation, agreement,
covenant, or condition contained in any contract, lease, loan agreement, indenture or other
instrument to which it is a party or by which it, or any of its property may be bound which would
result in a material adverse change in the condition (financial or otherwise), earnings, capital,
properties, business affairs or business prospects of the Company or Association or which would
materially affect their properties or assets. The consummation of the transactions herein
contemplated will not (i) conflict with or constitute a breach of, or default under, the certificate
of incorporation and bylaws of the Company, the charter and bylaws of the Association (in either
mutual or capital stock form), or any material contract, lease or other instrument to which the
Company or the Association has a beneficial interest, or any applicable law, rule, regulation or
order; (ii) violate any authorization, approval, judgment, decree, order, statute, rule or
regulation applicable to the Company or the Association; or (iii) with the exception of the
Liquidation Account established in the Conversion, result in the creation of any material lien,
charge or encumbrance upon any property of the Company or the Association.

(p) No default exists, and no event has occurred which with notice or lapse of time, or both, would
constitute a default on the part of the Company or the Association, in the due performance and
observance of any term, covenant or condition of any indenture, mortgage, deed of trust, note, bank
loan or credit agreement or any other instrument or agreement to which the Company or the
Association is a party or by which any of them or any of their property is bound or affected in any
respect which, in any such cases, is material to the Company or the Association; such agreements are
in full force and effect; and no other party to any such agreements has instituted or, to the best
knowledge of the Company or the Association, threatened any action or proceeding wherein the Company
or the Association would or might be alleged to be in default thereunder.

(q) Upon consummation of the Conversion, the authorized, issued and outstanding equity capital of
the Company will be within the range set forth in the Registration Statement under the caption
"Capitalization," and no shares of Common Stock have been or will be issued and outstanding prior to
the Closing Date referred to in Section 2; the Shares will have been duly and validly authorized for
issuance and, when issued and delivered by the Company pursuant to the Plan against payment of the

-8-

consideration calculated as set forth in the Plan and in the Offering Prospectus, will be duly and
validly issued and fully paid and non-assessable; the issuance of the Shares will not violate any
preemptive rights; and the terms and provisions of the Shares will conform in all material respects
to the description thereof contained in the Registration Statement and the Offering Prospectus. Upon
the issuance of the Shares, good title to the Shares will be transferred from the Company to the
purchasers thereof against payment therefor, subject to such claims as may be asserted against the
purchasers thereof by third party claimants.

(r) No approval of any regulatory or supervisory or other public authority is required in connection
with the execution and delivery of this Agreement or the issuance of the Shares, except for the
approval of the OTS, the Commission and any necessary qualification or registration under the
securities or blue sky laws of the various states in which the Shares are to be offered and as may
be required under the regulations-of the National Association of Securities Dealers, Inc. ("NASD")
and the National Association of Securities Dealers Automated Quotation ("NASDAQ") National Market.

(s) KPMG, which has certified the financial statements of the Association included in the
Registration Statement, are with respect to the Company and the Association independent public
accountants within the meaning of the Code of Professional Ethics of the American Institute of
Certified Public Accountants and Title 12 of the Code of Federal Regulations, Section 571.2(c)(3)
and the 1933 Act and the 1933 Act Regulations.
<!-- page 7 -->
(t) The Company and the Association have (subject to all properly obtained extensions) timely filed
all required federal and state tax returns, have paid all taxes that have become due and payable in
respect of such returns, have made adequate reserves for similar future tax liabilities and no
deficiency has been asserted with respect thereto by any taxing authority.

(u) Appropriate arrangements have been made for placing the funds received from subscriptions for
Shares in special interest-bearing accounts with the Association until all Shares are sold and paid
for, with provision for refund to the purchasers in the event that the Conversion is not completed
for whatever reason or for delivery to the Company if all Shares are sold.

(v) The Company and the Association are in compliance in all material respects with the applicable
financial record keeping and reporting requirements of the Currency and Foreign Transactions
Reporting Act of 1970, as amended, and the regulations and rules thereunder.

(w) To the knowledge of the Company and the Association, none of the Company, the Association nor
employees of the Company or the Association have made any payment of funds of the Company or the
Association as a loan to any person for the purchase of the Shares.

(x) Prior to the Conversion, the Association was not authorized to issue shares of capital stock and
neither the Company nor the Association has: (i) issued any securities within the last 18 months
(except for notes to evidence other bank loans and reverse repurchase agreements or other
liabilities); (ii) had any material dealings within the twelve months prior to the date hereof with
any member of the NASD, or any person related to or associated with such member, other than
discussions and meetings relating to the proposed Subscription and Public Offerings and routine
purchases and sales of U.S. government and agency securities and other investment securities; (iii)
entered into a financial or management consulting agreement except as contemplated hereunder; and
(iv) engaged any intermediary between Capital Resources and the Company and the Association in
connection with the offering of Common Stock, and no person is being compensated in any manner for
such service.

-9-

(y) The Association has no subsidiaries.

Any certificates signed by an officer of the Company or the Association and delivered to Capital
Resources or its counsel that refer to this Agreement shall be deemed to be a representation and
warranty by the Company or the Association to Capital Resources as to the matters covered thereby
with the same effect as if such representation and warranty were set forth herein.

SECTION 5. Capital Resources represents and warrants to the Company and the Association that:

(a) Capital Resources is a corporation and is validly existing in good standing under the laws of
the District of Columbia with full power and authority to provide the services to be furnished to
the Company and the Association hereunder.

(b) The execution and delivery of this Agreement and the consummation of the transactions
contemplated hereby have been duly and validly authorized by all necessary action on the part of
Capital Resources, and this Agreement has been duly and validly executed and delivered by Capital
Resources and is the legal, valid and binding agreement of Capital Resources, enforceable in
accordance with its terms.

(c) Each of Capital Resources and its employees, agents and representatives who shall perform any of
the services hereunder shall be duly authorized and empowered, and shall have all licenses,
approvals and permits necessary, to perform such services and Capital Resources is a registered
selling agent in the jurisdictions listed in Exhibit A hereto and will remain registered in such
jurisdictions in which the Company is relying on such registration for the sale of the Shares, until
the Conversion is consummated or terminated.

(d) The execution and delivery of this Agreement by Capital Resources, the consummation of the
transactions contemplated hereby and compliance with the terms and provisions hereof will not
conflict with, or result in a breach of, any of the terms, provisions or conditions of, or
constitute a default (or event which with notice or lapse of time or both would constitute a
default) under, the certificate of incorporation of Capital Resources or any agreement, indenture or
other instrument to which Capital Resources is a party or by which its property is bound, or law or
regulation by which Capital Resources is bound.

(e) Funds received by Capital Resources to purchase Common Stock will be handled in accordance with
Rule 15c2-4 under the Securities Exchange Act of 1934, as amended.

SECTION 6. Covenants of the Company and Association. The Company and the Association hereby jointly
and severally covenant with Capital Resources as follows:

(a) The Company has filed the Registration Statement with the Commission. The Company will not, at
any time after the date the Registration
<!-- page 8 -->
Statement is declared effective, file any amendment or supplement to the Registration Statement
without providing Capital Resources and its counsel an opportunity to review such amendment or file
any amendment or supplement to which amendment Capital Resources or its counsel shall reasonably
object.

(b) The Association has filed the Conversion Application with the OTS. The

-10-

Association will not, at any time after the date the Conversion Application is approved, file any
amendment or supplement to the Conversion Application without providing Capital Resources and its
counsel an opportunity to review such amendment or supplement or file any amendment or supplement to
which amendment or supplement Capital Resources or its counsel shall reasonably object.

(c) The Company and the Association will use their best efforts to cause any post-effective
amendment to the Registration Statement to be declared effective by the Commission and any
post-effective amendment to the Conversion Application to be approved by the OTS and will
immediately upon receipt of any information concerning the events listed below notify Capital
Resources and promptly confirm the notice in writing: (i) when the Registration Statement, as
amended, has become effective; (ii) when the Conversion Application, as amended, has been approved
by the OTS; (iii) of the receipt of any comments from the Commission, the OTS or the FDIC or any
other governmental entity with respect to the Conversion or the transactions contemplated by this
Agreement; (iv) of the request by the Commission, the OTS or the FDIC or any other governmental
entity for any amendment or supplement to the Registration Statement or for additional information;
(v) of the issuance by the Commission, the OTS, the FDIC or any other governmental entity of any
order or other action suspending the Subscription or Public Offerings or the use of the Registration
Statement or the Offering Prospectus or any other filing of the Company and the Association under
the Conversion Regulations or other applicable law, or the threat of any such action; (vi) the
issuance by the Commission, the OTS or the FDIC, or any other state authority, of any stop order
suspending the effectiveness of the Registration Statement or of the initiation or threat of
initiation or threat of any proceedings for that purpose; or (vii) of the occurrence of any event
mentioned in paragraph (h) below. The Company and the Association will make every reasonable effort
to prevent the issuance by the Commission, the OTS or the FDIC, or any other state authority of any
such order and, if any such order shall at any time be issued, to obtain the lifting thereof at the
earliest possible time.

(d) The Company and the Association will provide Capital Resources and its counsel notice of its
intention to file, and reasonable time to review prior to filing any amendment or supplement to the
Conversion Application or the Holding Company Application and will not file any such amendment or
supplement to which Capital Resources shall reasonably object or which shall be reasonably
disapproved by its counsel.

(e) The Company and the Association will deliver to Capital Resources and to its counsel two
conformed copies of each of the following documents, with all exhibits: the Conversion Application
and the Holding Company Application, as originally filed and of each amendment or supplement
thereto, and the Registration Statement, as originally filed and each amendment thereto. Further,
the Company and the Association will deliver such additional copies of the foregoing documents to
counsel for Capital Resources as may be required for any NASD and blue sky filings. In addition, the
Company and the Association will also deliver to Capital Resources such number of copies of the
Offering Prospectus, as amended or supplemented, as Capital Resources may reasonably request.

(f) The Company will furnish to Capital Resources, from time to time during the period when the
Offering Prospectus (or any later prospectus related to this Offering) is required to be delivered
under the 1933 Act or the Securities Exchange Act of 1934 (the "1934 Act"), such number of copies of
such prospectus (as amended or supplemented) as Capital Resources may reasonably request for the
purposes contemplated by the 1933 Act or the 1934 Act or the respective applicable rules and
regulations of the Commission thereunder. The Company authorizes Capital Resources to use the
Offering Prospectus (as amended or supplemented, if amended or supplemented) for any lawful manner
in

-11-

connection with the sale of the Shares by Capital Resources.

(g) The Company and the Association will comply in all material respects with any and all terms,
conditions, requirements and provisions with respect to the Conversion and the transactions
contemplated thereby imposed by the Commission, by applicable state law and regulations, and by the
1933 Act, the 1934 Act and the rules and regulations of the Commission promulgated under such
statutes, to be complied with prior to or subsequent to the Closing Date and when the Offering
Prospectus is required to be delivered, the Company and the Association will comply in all material
respects, at their own expense, with all requirements imposed upon them by the OTS, the Conversion
Regulations, the FDIC, the Commission, by applicable state law and regulations and by the 1933 Act,
the 1934 Act and the rules and regulations of the Commission promulgated under such statutes,
including, without limitation, Rule
<!-- page 9 -->
10b-6 under the 1934 Act, in each case as from time to time in force, so far as necessary to permit
the continuance of sales or dealing in shares of Common Stock during such period in accordance with
the provisions hereof and the Offering Prospectus.

(h) If, at any time during the period when the Offering Prospectus relating to the Shares is
required to be delivered, any event relating to or affecting the Company or the Association shall
occur, as a result of which it is necessary or appropriate, in the reasonable opinion of counsel for
the Company and the Association or in the reasonable opinion of Capital Resources' counsel, to amend
or supplement the Registration Statement or Offering Prospectus in order to make the Registration
Statement or Offering Prospectus not misleading in light of the circumstances existing at the time
it is delivered to a purchaser, the Company and the Association will, at their expense, forthwith
prepare, file with the Commission and the OTS and furnish to Capital Resources a reasonable number
of copies of any amendment or amendments of, or a supplement or supplements to, the Registration
Statement or Offering Prospectus (in form and substance reasonably satisfactory to Capital Resources
and its counsel after a reasonable time for review) which will amend or supplement the Registration
Statement or Offering Prospectus so that as amended or supplemented it will not contain an untrue
statement of a material fact or omit to state a material fact necessary in order to make the
statements therein, in light of the circumstances existing at the time the Offering Prospectus
reasonably is delivered to a purchaser, not misleading. For the purpose of this Agreement, the
Company and the Association each will timely furnish to Capital Resources such information with
respect to itself as Capital Resources may from time to time request.

(i) The Company and the Association will take all necessary actions, in cooperation with Capital
Resources, and furnish to whomever Capital Resources may direct, such information as may be required
to qualify or register the Shares for offering and sale by the Company under the applicable
securities or blue sky laws of such jurisdictions in which the shares are required under the
Conversion Regulations to be sold or as Capital Resources may reasonably designate and as reasonably
agreed to by the Association; provided, however, that the Company shall not be obligated to file any
general consent to service of process or to qualify to do business in any jurisdiction in which it
is not so qualified. In each jurisdiction where any of the Shares shall have been qualified or
registered as above provided, the Company will make and file such statements and reports in each
fiscal period as are or may be required by the laws of such jurisdiction.

(j) The liquidation account for the benefit of account holders with account balances of $50 or more
as of the applicable record dates will be duly established and maintained in accordance with the
requirements of the OTS, and such Eligible Account Holders and Supplemental Eligible Account Holders
who continue to maintain their savings accounts in the Association will have an inchoate interest

-12-

in their pro rata portion of the liquidation account which shall have a priority superior to that of
the holders of shares of Common Stock in the event of a complete liquidation of the Association.

(k) The Company and the Association will not sell or issue, contract to sell or otherwise dispose
of, for a period of 180 days after the date hereof, without Capital Resources' prior written
consent, any shares of Common Stock other than in connection with any plan or arrangement described
in the Offering Prospectus.

(l) The Company shall register its Common Stock under Section 12(g) of the 1934 Act concurrent with
the stock offering pursuant to the Plan and shall request that such registration be effective upon
completion of the Conversion. The Company shall maintain the effectiveness of such registration for
not less than three years or such shorter period as permitted by the OTS.

(m) During the period during which the Company's common stock is registered under the 1934 Act or
for three years from the date hereof, whichever period is greater, the Company will furnish to its
stockholders as soon as practicable after the end of each fiscal year an annual report (including a
balance sheet and statements of income, stockholders' equity and changes in financial position or
cash flow statement of the Company as at the end of and for such year, certified by independent
public accountants and prepared in accordance with Regulation S-X under the 1934 Act).

(n) During the period of three years from the date hereof, the Company will furnish to Capital
Resources: (i) a copy of each report of the Company furnished to or filed with the Commission under
the 1934 Act or any national securities exchange or system on which any class of securities of the
Company is listed or quoted (including but not limited to, reports on Form 10-K, 10-Q and 8-K and
all proxy statements and annual reports to stockholders), a copy of each report of the Company
mailed to its stockholders or filed with the Commission or the OTS or any other supervisory or
regulatory authority or any national securities exchange or system on which any class of securities
of the Company is listed or quoted, each press release and material news items and additional public
documents and information with respect to the Company or the Association as Capital Resources may
reasonably request, and (ii) from time to time, such other publicly available information concerning
the Company and the Association as Capital Resources may reasonably request.

(o) The Company and the Association will use the net
<!-- page 10 -->
proceeds from the sale of the Shares in the manner set forth in the Offering Prospectus under the
caption "Use of Proceeds."

(p) Other than as permitted by the Conversion Regulations, the 1933 Act, the 1933 Act Regulations
and the laws of any state in which the Shares are qualified for sale, neither the Company nor the
Association will distribute any prospectus, offering circular or other offering material in
connection with the offer and sale of the Shares.

(q) The Company will make generally available to its security holders as soon as practicable, but
not later than 90 days after the close of the period an earnings statement (in form complying with
the provisions of Rule 158 under the 1933 Act) covering a twelve-month period beginning not later
than the first day of the Company's fiscal quarter next following the effective date (as defined in
said Rule 158) of the Registration Statement.

(r) The Company will file with the Commission such reports on Form SR as may be required pursuant to
Rule 463 under the 1933 Act.

-13-

(s) The Company will obtain approval for and maintain quotation of the shares on the NASDAQ National
Market effective on or prior to the Closing Date.

(t) The Association will maintain appropriate arrangements for depositing all funds received from
persons mailing subscriptions for or orders to purchase Shares in the Subscription and Public
Offerings on an interest-bearing basis at the rate described in the Offering Prospectus until the
Closing Date and satisfaction of all conditions precedent to the release of the Association's
obligation to refund payments received from persons subscribing for or ordering Shares in the
Subscription and Public Offerings in accordance with the Plan as described in the Offering
Prospectus or until refunds of such funds have been made to the persons entitled thereto or
withdrawal authorizations canceled in accordance with the Plan and as described in the Offering
Prospectus. The Association will maintain such records of all funds received to permit the funds of
each subscriber to be separately insured by the FDIC (to the maximum extent allowable) and to enable
the Association to make the appropriate refunds of such funds in the event that such refunds are
required to be made in accordance with the Plan and as described in the Offering Prospectus.

(u) The Company will promptly register as a savings and loan holding company under the HOLA.

(v) The Company and the Association will take such actions and furnish such information as are
reasonably requested by Capital Resources in order for Capital Resources to ensure compliance with
the "Interpretation of the Board of Governors of the NASD on Free Riding and Withholding."

(w) The Company will conduct its businesses in compliance in all material respects with all
applicable federal and state laws, rules, regulations, decisions, directives and orders, including
all decisions, directives and orders of the Commission, the OTS and the FDIC.

(x) The Association will not amend the Plan of Conversion without Capital Resources' prior written
consent in any manner that, in the reasonable opinion of Capital Resources, would materially and
adversely affect the sale of the Shares or the terms of this Agreement.

(y) The Company shall advise Capital Resources, if necessary, as to the allocation of the Shares in
the event of an oversubscription and shall provide Capital Resources with any information necessary
to assist Capital Resources in allocating the Shares in such event and such information shall be
accurate and reliable.

SECTION 7. Payment of Expenses. Whether or not this Agreement becomes effective, the Conversion is
completed or the sale of the Shares by the Company is consummated, the Company and Association
jointly and severally agree to pay directly for or to reimburse Capital Resources for (to the extent
that such expenses have been reasonably incurred by Capital Resources) (a) all filing fees and
expenses incurred in connection with the qualification or registration of the Shares for offer and
sale by the Company under the securities or blue sky laws of any jurisdictions Capital Resources and
the Company may agree upon pursuant to subsection (i) of Section 6 above, including counsel fees
paid or incurred by the Company, the Association or Capital Resources in connection with such
qualification or registration or exemption from qualification or registration; (b) all filing fees
in connection with all filings with the NASD; (c) any stock issue or transfer taxes which may be
payable with respect to the sale of the Shares to purchasers in the Conversion; (d) reasonable and
necessary expenses of the Conversion,

-14-

including but not limited to, attorneys' fees, transfer agent, registrar and other agent charges,
fees relating to auditing and accounting or other advisors and costs of printing all documents
necessary in connection with the Conversion;
<!-- page 11 -->
and (e) out-of-pocket expenses incurred by Capital Resources in connection with the Conversion or
any of the transactions contemplated hereby, including, without limitation, the fees of its
attorneys, and reasonable communication and travel expenses.

SECTION 8. Conditions to Capital Resources' Obligations. Capital Resources' obligations hereunder,
as to the Shares to be delivered at the Closing Date, are subject to the condition that all
representations and warranties and other statements of the Company and the Association herein are,
at and as of the commencement of the Subscription and Public Offerings and at and as of the Closing
Date, true and correct in all material respects, the condition that the Company and the Association
shall have performed in all material respects all of their obligations hereunder to be performed on
or before such dates, and to the following further conditions:

(a) At the Closing Date, the Company and the Association will have completed the conditions
precedent to, and shall have conducted the Conversion in all material respects in accordance with,
the Plan, the Conversion Regulations and all other applicable laws, regulations, decisions and
orders, including all terms, conditions, requirements and provisions precedent to the Conversion
imposed upon them by the OTS.

(b) The Registration Statement shall have been declared effective by the Commission and the
Conversion Application approved by the OTS not later than 5:30 p.m. (eastern time) on the date of
this Agreement, or with Capital Resources' consent at a later time and date; and at the Closing Date
no stop order suspending the effectiveness of the Registration Statement shall have been issued
under the 1933 Act or proceedings therefore initiated or threatened by the Commission or any state
authority, and no order or other action suspending the authorization of the Offering Prospectus or
the consummation of the Conversion shall have been issued or proceedings therefore initiated or, to
the Company's or Association's knowledge, threatened by the Commission, the OTS, the FDIC or any
state authority.

(c) At the Closing Date, Capital Resources shall have received:

(1) The favorable opinion, dated as of the Closing Date addressed to Capital Resources and for its
benefit, of Malizia, Spidi, Sloane & Fisch, P.C., counsel for the Company and the Association dated
the Closing Date, addressed to Capital Resources and in form and substance to the effect that:

(i) The Company has been duly incorporated and is validly existing as a corporation in good standing
under the laws of the State of Delaware.

(ii) The Company has corporate power and authority to own, lease and operate its properties and to
conduct its business as described in the Registration Statement and the Offering Prospectus; and the
Company is qualified to do business as a foreign corporation in New York, to the best of such
counsel's knowledge based on the conferences and document review specified in item (xiii) below, the
only state in which it is doing business.

(iii) The Association was a duly organized and is a validly existing federally-chartered savings and
loan association in mutual form of organization and upon the Conversion will become a duly organized
and validly existing federally-chartered savings bank in capital stock form of organization, in

-15-

both instances duly authorized to conduct its business and own its property as described in the
Registration Statement; and the Association is in good standing under the laws of the United States
and is duly qualified as a foreign corporation to transact business and is in good standing in each
jurisdiction in which its ownership of property or leasing of properties or the conduct of its
business requires such qualification unless the failure to be so qualified in one or more such
jurisdictions would not have a material adverse effect on the condition, financial or otherwise, or
the business, operations or income or business prospects of the Association. The activities of the
Association as described in the Offering Prospectus, insofar as they are material to the operations
and financial condition of the Association, are permitted by the rules, regulations and resolutions
and practices of the OTS or the FDIC and any other federal or state authorities.

(iv) The Association is a member of the FHLBNY, and the deposit accounts of the Association are
insured by the FDIC up to the maximum amount allowed under law and to the best of such counsel's
knowledge no proceedings for the termination or revocation of such insurance are pending or
threatened; and the description of the liquidation account as set forth in the Registration
Statement and the Offering Prospectus under the caption "The Conversion - Effects of Conversion to
Stock Form on Depositors and Borrowers of the Bank - Liquidation Account" has been reviewed by such
counsel and is accurate in all material respects.

(v) Upon consummation of the Conversion, the authorized, issued and outstanding capital stock of the
Company will be as set forth in the Registration Statement and the Offering Prospectus under the
caption "Capitalization," and no shares of Common Stock have been issued prior to the Closing Date;
at the time of the Conversion, the Shares subscribed for pursuant to the Offerings will have been
duly and validly authorized for issuance, and when issued and delivered by the Company pursuant to
the Plan against payment of
<!-- page 12 -->
the consideration calculated as set forth in the Plan, will be duly and validly issued and fully
paid and non-assessable; and the issuance of the Shares is not subject to preemptive rights.

(vi) The issuance and sale of the common stock of the Association to the Company have been duly and
validly authorized by all necessary corporate action on the part of the Company and the Association
and, upon payment therefor in accordance with the terms of the Plan of Conversion, will be duly and
validly issued, fully paid and non-assessable and will be owned of record by the Company, free and
clear of any mortgage, pledge, lien, encumbrance or claim (legal or equitable).

(vii) The execution and delivery of this Agreement and the consummation of the transactions
contemplated hereby have been duly and validly authorized by all necessary action on the part of the
Company and the Association; and this Agreement is a valid and binding obligation of the Company and
the Association, enforceable in accordance with its terms (except as the enforceability thereof may
be limited by bankruptcy, insolvency, moratorium, reorganization or similar laws relating to or
affecting the enforcement of creditors' rights generally or the rights of creditors of savings
associations or savings and loan holding companies, the accounts of whose subsidiaries are insured
by the FDIC or by general equity principles, regardless of whether such enforceability is considered
in a proceeding in equity or at law, and except to the extent, if any, that the provisions of
Sections 9 and 10 hereof may be unenforceable as against public policy).

(viii) The Plan has been duly adopted by the required vote of the Directors of the Company and the
Association and members of the Association.

-16-

(ix) Subject to the satisfaction of the conditions to the OTS's approval of the Conversion and the
Company's application to acquire the Association, no further approval, registration, authorization,
consent or other order of any regulatory agency, public board or body is required in connection with
the execution and delivery of this Agreement, the issuance of the Shares and the consummation of the
Conversion, except as may be required under the regulations of the NASD and the NASDAQ National
Market. The Conversion has been consummated in all material respects in accordance with all
applicable provisions of the HOLA, the Conversion Regulations, Federal and State law and all
applicable rules and regulations promulgated thereunder.

(x) The Conversion Application including the Offering Prospectus as filed with the OTS was complete
in all material respects and has been approved by the OTS. The OTS has issued its order of approval
under the savings and loan holding company provisions of the HOLA, and the purchase by the Company
of all of the issued and outstanding capital stock of the Association has been authorized by the OTS
and no action has been taken, or to counsel's knowledge is pending or threatened, to revoke any such
authorization or approval.

(xi) The Registration Statement is effective under the 1933 Act and no stop order suspending the
effectiveness has been issued under the 1933 Act or proceedings therefor initiated or, to counsel's
knowledge, threatened by the Commission.

(xii) At the time the Conversion Application, including the Offering Prospectus contained therein,
was approved, the Conversion Application including the Offering Prospectus contained therein (as
amended or supplemented, if so amended or supplemented) complied as to form in all material respects
with the requirements of all applicable federal laws and the rules, regulations, decisions and
orders of the OTS (except as to the financial statements, other financial data and stock valuation
information included therein as to which such counsel need express no opinion); to the best of such
counsel's knowledge, based on conferences with management of and the independent accountants for the
Company and the Association, and on such investigation of the corporate records of the Company and
the Association as such counsel conducted in connection with the preparation of the Registration
Statement and the Conversion Application, all material documents and exhibits required to be filed
with the Conversion Application (as amended or supplemented, if so amended or supplemented) have
been so filed. The description in the Conversion Application and the Offering Prospectus contained
therein of such documents and exhibits is accurate in all material respects and fairly presents the
information required to be shown.

(xiii) At the time that the Registration Statement became effective, (i) the Registration Statement
(as amended or supplemented if so amended or supplemented) (other than the financial statements and
other financial and statistical data and stock valuation information included therein, as to which
no opinion need be rendered), complied as to form in all material respects with the requirements of
the 1933 Act and the 1933 Act Regulations and (ii) the Offering Prospectus (other than the financial
statements and other financial and statistical data and the stock valuation information included
therein, as to which no opinion need be rendered) complied as to form in all material respects with
the requirements of the 1933 Act, the 1933 Act Regulations, Conversion Regulations and Federal and
State law (other than state blue sky law as to which we express no opinion). To the best of such
counsel's knowledge based on the conferences and document review specified in item (xiii) above, all
material documents and exhibits required to be filed with the Registration Statement (as amended or
supplemented, if so amended or supplemented) have been so filed. The description in the Registration
Statement and the Offering Prospectus of such documents and exhibits is accurate in all

material respects and fairly

-17-
<!-- page 13 -->
presents the information required to be shown. To the best of such counsel's knowledge, no person
has sought to obtain regulatory or judicial review of the final action of the OTS approving the
Conversion Application or in approving the Holding Company Application.

(xiv) During the course of such counsel's representation of the Company and the Association, nothing
has come to such counsel's attention that caused it to believe that (i) the Company and the
Association have not conducted the Conversion, in all material respects, in accordance with all
applicable requirements of the Plan and applicable law, and (ii) the Plan, the Conversion
Application, the Registration Statement and the Offering Prospectus (other than the financial
statements and other financial and statistical data and the stock valuation information included
therein as to which no opinion need be rendered) do not comply in all material respects with all
applicable laws, rules, regulations, decisions and orders including, but not limited to, the
Conversion Regulations, the HOLA, the 1933 Act and 1933 Act Regulations and all other applicable
laws, regulations, decisions and orders, including all applicable terms, conditions, requirements
and provisions precedent to the Conversion imposed upon it by the OTS, the Commission and the FDIC,
if any.

(xv) The terms and provisions of the Common Stock of the Company conform to the description thereof
contained in the Registration Statement and the Offering Prospectus, and the form of certificates
used to evidence the Shares are in due and proper form.

(xvi) To the best knowledge of such counsel, there are no legal or governmental proceedings pending
or threatened which are required to be disclosed in the Registration Statement and the Offering
Prospectus, other than those disclosed therein, and all pending legal and governmental proceedings
to which the Company or the Association is a party or of which any of their property is the subject
which are not described in the Registration Statement and the Offering Prospectus, including
ordinary routine litigation incidental to the business, are, considered in the aggregate, not
material; provided that for this purpose, any litigation or governmental proceeding is not
considered to be "threatened" unless the potential litigant or governmental authority has manifested
to the management of the Company or the Association, or to such counsel, a present intention to
initiate such litigation or proceeding.

(xvii) To the best knowledge of such counsel, the Company and the Association have obtained all
licenses, permits and other governmental authorizations required for the conduct of their respective
businesses, except where the failure to have such licenses, permits or authorizations would not have
a material adverse effect on the business, operations or income or business prospects of the Company
and the Association, and all such licenses, permits and other governmental authorizations are in
full force and effect, and the Company and the Association are in all material respects complying
therewith.

(xviii) Neither the Company nor the Association is in contravention of its certificate of
incorporation or its charter, respectively, or its bylaws (and the Association will not be in
contravention of its charter or bylaws in stock form upon consummation of the Conversion) or, to the
best knowledge of such counsel, in contravention of any obligation, agreement, covenant or condition
contained in any material contract, indenture, mortgage, loan agreement, note, lease or other
instrument to which it is a party or by which it or its property may be bound which contravention
would be material to the business of the Company and the Association considered as one enterprise;
the execution and delivery of this Agreement by the Company and the Association, the incurring of
the obligations herein set forth and the consummation of the transactions contemplated herein have
been duly authorized by all necessary

-18-

corporate action of the Company and the Association, and, to the best knowledge of such counsel,
will not constitute a material breach of, or default under, or result in the creation or imposition
of any material lien, charge or encumbrance upon any property or assets of the Company or the
Association which are material to their business considered as one enterprise, pursuant to any
contract, indenture, mortgage, loan agreement, note, lease or other instrument to which the Company
or the Association is a party or by which any of them may be bound, or to which any of the property
or assets of the Company or the Association is subject. In addition, such action will not result in
any contravention of the provisions of the certificate of incorporation or bylaws of the Company or
the Association or any applicable law, act, regulation or order or court order, writ, injunction or
decree. The charter of the Association in stock form has been approved by the OTS.

(xix) To the best knowledge of such counsel, the Company and the Association have good and
marketable title to all properties and assets described in the Registration Statement as owned by
them, free and clear of all liens, charges, encumbrances or restrictions, except such as are
described in the Registration Statement or are not material in relation to the business of the
Company and the Association considered as one enterprise; and to the best of such counsel's
knowledge, all of the leases and subleases material to the business of the Company and the
Association under which the Company and the
<!-- page 14 -->
Association hold properties, as described in the Registration Statement, are in full force and
effect.

(xx) The Company and the Association are not in violation of any directive from the OTS or the FDIC
to make any material change in the method of conducting their business and the Company and the
Association have conducted and are conducting their business so as to comply in all material
respects with all applicable statutes and regulations (including, without limitation, regulations,
decisions, directives and orders of the OTS and the FDIC).

(xxi) The information in the Registration Statement and Offering Prospectus under the captions
"Regulation," "Certain Restrictions on Acquisitions of the Company," "The Conversion," "Description
of Capital Stock" and the information in response to Items 7(d)(l), 7(f), 7(g) and 7(i) of the Form
PS of the Conversion Regulations, to the extent that it constitutes matters of law, summaries of
legal matters, documents or proceedings, or legal conclusions, has been reviewed by such counsel and
is correct in all material respects (except as to the financial statements and other financial data
included therein as to which such counsel need express no opinion).

In rendering such opinion, such counsel may rely (A) as to matters involving the application of laws
of any jurisdiction other than the United States, to the extent such counsel deems proper and
specified in such opinion satisfactory to Capital Resources, upon the opinion of other counsel of
good standing (providing that such counsel states that Capital Resources is justified in relying
upon such specified opinion or opinions), and (B) as to matters of fact, to the extent such counsel
deems proper, on certificates of responsible officers of the Company and the Association and public
officials (but not on conclusions of law which may be set forth in said certificates); provided
copies of any such opinion(s) or certificates are delivered pursuant hereto or to Capital Resources
together with the opinion to be rendered hereunder by special counsel to the Company and the
Association. Such counsel may assume that any agreement is the valid and binding obligation of any
parties to such agreement other than the Company or the Association.

(2) The letter of Malizia, Spidi, Sloane & Fisch, P.C., counsel for the Company and the Association
addressed to Capital Resources, dated the Closing Date, in form and substance to the effect that:

-19-

During the preparation of the Conversion Application, the Registration Statement and the Offering
Prospectus, such counsel participated in conferences with management of, and the independent public
accountants for the Company and the Association. Based upon such conferences and a review of
corporate records of the Company and the Association as such counsel conducted in connection with
the preparation of the Registration Statement and Conversion Application, nothing has come to their
attention that would lead them to believe that the Conversion Application, the Registration
Statement, the Offering Prospectus, or any amendment or supplement thereto (other than the financial
statements and other financial and statistical data and stock valuation information included
therein, as to which such counsel need express no view), contained an untrue statement of a material
fact or omitted to state a material fact required to be stated therein or necessary to make the
statements therein, in light of the circumstances under which they were made, not misleading.

(3) The favorable opinion, dated as of the Closing Date, of Serchuk & Zelermyer, LLP, Capital
Resources' counsel, with respect to such matters as Capital Resources may reasonably require. Such
opinion may rely upon the opinions of counsel to the Company and the Association, and as to matters
of fact, upon certificates of officers and directors of the Company and the Association delivered
pursuant hereto or as such counsel shall reasonably request.

(d) At the Closing Date, counsel to Capital Resources shall have been furnished with such documents
and opinions as they may reasonably require for the purpose of enabling them to render the opinion
as herein contemplated and related proceedings or in order to evidence the occurrence or
completeness of any of the representations or warranties, or the fulfillment of any of the
conditions, herein contained.

(e) At the Closing Date, Capital Resources shall receive a certificate of the Chief Executive
Officer and the Chief Financial Officer of the Company and of the Chief Executive Officer and Chief
Financial Officer of the Association, dated as of such Closing Date, to the effect that: (i) they
have carefully examined the Offering Prospectus and, in their opinion, at the time the Offering
Prospectus became authorized for final use, the Offering Prospectus did not contain an untrue
statement of a material fact or omit to state a material fact necessary in order to make the
statements therein, in light of the circumstances under which they were made, not misleading; (ii)
since the date the Offering Prospectus became authorized for final use, in their opinion no event
has occurred which should have been set forth in an amendment or supplement to the Offering
Prospectus which has not been so set forth, including specifically, but without limitation, any
material adverse change in the condition, financial or otherwise, or in the earnings, capital,
properties, business prospects or business affairs of the Company or the Association, and the
conditions set forth in this Section 8 have been satisfied; (iii) since the respective dates as of
which information is given in the Registration Statement and the Offering Prospectus, there has been
no material adverse change in the condition, financial or otherwise, or in the earnings, capital,
properties, business affairs or business prospects of the Company or the Association,
<!-- page 15 -->
independently, or of the Company and the Association considered as one enterprise, whether or not
arising in the ordinary course of business; (iv) to the best knowledge of such officers the
representations and warranties in Section 4 are true and correct with the same force and effect as
though expressly made at and as of the Closing Date; (v) the Company and the Association have
complied with all material agreements and satisfied, in all material respects at or prior to the
Closing Date, all obligations required to be met by such date and will in all material respects
comply with all obligations to be satisfied by them after Conversion; (vi) no stop order suspending
the effectiveness of the Registration Statement has been initiated or, to the best knowledge of the
Company or Association, threatened by the Commission or any state authority; (vii) no order
suspending the Subscription or Public Offerings, the Conversion, the

-20-

acquisition of all of the shares of the Association by the Company or the effectiveness of the
Offering Prospectus has been issued and to the best knowledge of the Company or Association, no
proceedings for that purpose have been initiated or threatened by the OTS, the Commission, the FDIC,
or any state authority; and (viii) to the best of their knowledge, no person has sought to obtain
review of the final action of the OTS approving the Plan.

(f) Prior to and at the Closing Date: (i) in the reasonable opinion of Capital Resources, there
shall have been no material adverse change in the condition, financial or otherwise, or in the
earnings, or the business affairs or business prospects of the Company or the Association
independently, or of the Company or the Association, considered as one enterprise, since the latest
dates as of which such condition is set forth in the Offering Prospectus, except as referred to
therein; (ii) there shall have been no material transaction entered into by the Company or the
Association from the latest date as of which the financial condition of the Company or the
Association is set forth in the Offering Prospectus other than transactions referred to or
contemplated therein; (iii) the Company or the Association shall not have received from the OTS or
the FDIC any direction (oral or written) to make any material change in the method of conducting
their business with which it has not complied (which direction, if any, shall have been disclosed to
Capital Resources) and which would reasonably be expected to have a material and adverse effect on
the business, operations or financial condition or income of the Company or the Association taken as
a whole; (iv) neither the Company nor the Association shall have been in default (nor shall an event
have occurred which, with notice or lapse of time or both, would constitute a default) under any
provision of and agreement or instrument relating to any material outstanding indebtedness; (v) no
action, suit or proceedings, at law or in equity or before or by any federal or state commission,
board or other administrative agency, shall be pending, or, to the knowledge of the Company or the
Association, threatened against the Company or the Association or affecting any of their properties
wherein an unfavorable decision, ruling or finding would reasonably be expected to have a material
and adverse effect on the business, operations, financial condition or income of the Company or the
Association, taken as a whole; and (vi) the Shares have been qualified or registered for offering
and sale under the securities or blue sky laws of the jurisdictions as Capital Resources shall have
requested and as agreed to by the Company.

(g) Concurrently with the execution of this Agreement, Capital Resources shall receive a letter from
KPMG, dated the date hereof and addressed to Capital Resources: (i) confirming that KPMG is a firm
of independent public accountants within the meaning of the 1933 Act and the 1933 Act Regulations
and 12 C.F.R. ss. 571.2(c)(3) and no information concerning its relationship with or interests in
the Company and the Association is required to be disclosed in the Offering Prospectus by the
Conversion Regulations or Item 10 of the Registration Statement, and stating in effect that in
KPMG's opinion the financial statements of the Association as are included in the Offering
Prospectus comply as to form in all material respects with the applicable accounting requirements of
the 1933 Act and the related published rules and regulations of the Commission thereunder and the
Conversion Regulations and generally accepted accounting principles; (ii) stating in effect that, on
the basis of certain agreed upon procedures (but not an audit examination in accordance with
generally accepted auditing standards) consisting of a reading of the latest available unaudited
interim financial statements of the Association prepared by the Association, a reading of the
minutes of the meetings of the Board of Directors and members of the Association and consultations
with officers of the Association responsible for financial and accounting matters, nothing came to
their attention which caused them to believe that: (A) such unaudited financial statements are not
in conformity with generally accepted accounting principles applied on a basis substantially
consistent with that of the audited financial statements included in the Offering Prospectus; or (B)
during the period from the date of the latest financial statements included in the

-21-

Offering Prospectus to a specified date not more than five business days prior to the date hereof,
there has been (1) an increase of greater than $500,000 in the long term debt of the Association or
(2) an increase of $100,000 or more in loans past due 90 days or more as of the last day of the
month immediately prior to such specified date or (3) an increase of $100,000 or more in real estate
acquired by foreclosure or (4) a decrease of $50,000 or more in the allowance for loan losses or (5)
any decrease in total retained earnings or (6) a decrease
<!-- page 16 -->
in net income when compared to the like period in 1995 or (7) any change in total assets of the
Association in an amount greater than $2,000,000 excluding proceeds from stock subscriptions; and
(iii) stating that, in addition to the audit examination referred to in its opinion included in the
Offering Prospectus and the performance of the procedures referred to in clause (ii) of this
subsection (g), they have compared with the general accounting records of the Company and/or the
Association, as applicable, which are subject to the internal controls of the Company and/or the
Association, as applicable, accounting system and other data prepared by the Company and/or the
Association, as applicable, directly from such accounting records, to the extent specified in such
letter, such amounts and/or percentages set forth in the Offering Prospectus as Capital Resources
may reasonably request; and they have found such amounts and percentages to be in agreement
therewith (subject to rounding).

(h) At the Closing Date, Capital Resources shall receive a letter from KPMG, dated the Closing Date,
addressed to Capital Resources, confirming the statements made by its letter delivered by it
pursuant to subsection (g) of this Section 8, except that the "specified date" referred to in clause
(ii)(B) thereof to be a date specified in such letter, which shall not be more than three business
days prior to the Closing Date.

(i) The Company and the Association shall not have sustained since the date of the latest audited
financial statements included in the Registration Statement and Offering Prospectus any loss or
interference with its business from fire, explosion, flood or other calamity, whether or not covered
by insurance, or from any labor dispute or court or governmental action, order or decree, otherwise
than as set forth or contemplated in the Registration Statement and Offering Prospectus, and since
the respective dates as of which information is given in the Registration Statement and Offering
Prospectus, there shall not have been any material change in the long term debt of the Company or
the Association other than debt incurred in relation to the purchase of Shares by the Company's
Tax-Qualified Employee Plans, or any change, or any development involving a prospective change, in
or affecting the general affairs, management, financial position, stockholders' equity or results of
operations of the Company or the Association, otherwise than as set forth or contemplated in the
Registration Statement and Offering Prospectus, the effect of which, in any such case described
above, is in Capital Resources' reasonable judgment sufficiently material and adverse as to make it
impracticable or inadvisable to proceed with the Subscription or Public Offerings or the delivery of
the Shares on the terms and in the manner contemplated in the Offering Prospectus.

(j) At or prior to the Closing Date, Capital Resources shall receive (i) a copy of the letter from
the OTS authorizing the use of the Offering Prospectus, (ii) a copy of the order from the Commission
declaring the Registration Statement effective, (iii) a copy of a certificate from the OTS
evidencing the good standing of the Association, (iv) certificates of good standing from the States
of Delaware and New York evidencing the good standing of the Company and from the State of New York
evidencing that the Company is duly qualified to do business and in good standing in New York and
(v) a copy of the letter from the OTS approving the Company's Holding Company Application.

(k) As soon as available after the Closing Date, Capital Resources shall receive a

-22-

certified copy of the Association's stock charter.

(1) Subsequent to the date hereof, there shall not have occurred any of the following: (i) a
suspension or limitation in trading in securities generally on the New York Stock Exchange or
American Stock Exchange or in the over-the-counter market, or quotations halted generally on the
NASDAQ National Market, or minimum or maximum prices for trading being fixed, or maximum ranges for
prices for securities being required by either of such exchanges or the NASD or by order of the
Commission or any other governmental authority; (ii) a general moratorium on the operations of
commercial banks or federal savings banks or general moratorium on the withdrawal of deposits from
commercial banks or federal savings banks declared by either federal or state authorities; (iii) the
engagement by the United States in hostilities which have resulted in the declaration, on or after
the date hereof, of a national emergency or war; or (iv) a material decline in the price of equity
or debt securities if, as to clauses (iii) or (iv), the effect of such hostilities or decline, in
Capital Resources' reasonable judgment, makes it impracticable or inadvisable to proceed with the
Subscription or Public Offerings or the delivery of the Shares on the terms and in the manner
contemplated in the Registration Statement and the Offering Prospectus.

All such opinions, certifications, letters and documents shall be in compliance with the provisions
hereof only if they are, in the reasonable opinion of Capital Resources and its counsel,
satisfactory to Capital Resources and its counsel. Any certificates signed by an officer or director
of the Company or the Association and delivered to Capital Resources or its counsel shall be deemed
a representation and warranty by the Company or the Association to Capital Resources as to the
statements made therein.

If any of the conditions specified in this Section shall not have been fulfilled when and as
required by this Agreement, this Agreement and all of Capital Resources' obligations hereunder may
be canceled by Capital Resources by notifying the Association of such cancellation in writing or by
telegram at any time at or prior to the Closing Date, and any such cancellation shall be without
liability of any party to any other party except as otherwise provided in Sections 2, 7, 9 and 10
hereof. Notwithstanding the above, if this
<!-- page 17 -->
Agreement is canceled pursuant to this paragraph, the Company and the Association jointly and
severally agree to reimburse Capital Resources for all out-of-pocket expenses, (including without
limitation the fees and expenses of Capital Resources' counsel) reasonably incurred by Capital
Resources and Capital Resources' counsel at its normal rates, in connection with the preparation of
the Registration Statement and the Offering Prospectus, and in contemplation of the proposed
Subscription or Public Offerings to the extent provided for in Sections 2 and 7 hereof.

SECTION 9. Indemnification.

(a) The Company and the Association jointly and severally agree to indemnify and hold harmless
Capital Resources, its officers, directors, agents and employees and each person, if any, who
controls or is under common control with Capital Resources within the meaning of Section 15 of the
1933 Act or Section 20(a) of the 1934 Act, against any and all loss, liability, claim, damage or
expense whatsoever (including but not limited to settlement expenses), joint or several, that
Capital Resources or any of them may suffer or to which Capital Resources and any such persons upon
written demand for any expenses (including fees and disbursements of counsel) incurred by Capital
Resources or any of them in connection with investigating, preparing or defending any actions,
proceedings or claims (whether commenced or threatened) to the extent such losses, claims, damages,
liabilities or actions (i) arise out of or are based upon any untrue statement or alleged untrue
statement of a material

-23-

fact contained in the Registration Statement (or any amendment or supplement thereto), preliminary
or final Offering Prospectus (or any amendment or supplement thereto), the Conversion Application or
any Blue Sky application or other instrument or document of the Company or the Association or based
upon written information supplied by the Company or the Association filed in any state or
jurisdiction to register or qualify any or all of the Shares or the subscription rights applicable
thereto under the securities laws thereof (collectively, the "Blue Sky Application"), or any
application or other document, advertisement, oral statement, or communication ("Sales Information")
prepared, made or executed by or on behalf of the Company with its consent or based upon written or
oral information furnished by or on behalf of the Company or the Association, whether or not filed
in any jurisdiction in order to qualify or register the Shares under the securities laws thereof;
(ii) arise out of or are based upon the omission or alleged omission to state in any of the
foregoing documents or information, a material fact required to be stated therein or necessary to
make the statements therein, in light of the circumstances under which they were made, not
misleading; or, (iii) arise from any theory of liability whatsoever relating to or arising from or
based upon the Registration Statement (or any amendment or supplement thereto), preliminary or final
Offering Prospectus (or any amendment or supplement thereto), the Conversion Application, any Blue
Sky Application or Sales Information or other documentation distributed in connection with the
Conversion; provided, however, that no indemnification is required under this paragraph (a) to the
extent such losses, claims, damages, liabilities or actions arise out of or are based upon any
untrue material statements or alleged untrue material statements in, or material omission or alleged
material omission from, the Registration Statement (or any amendment or supplement thereto), the
Conversion Application, any Blue Sky Application, the preliminary or final Offering Prospectus (or
any amendment or supplement thereto), or Sales Information made in reliance upon and in conformity
with written information furnished to the Company or the Association by Capital Resources regarding
Capital Resources expressly for use under the caption "The Conversion - Marketing Arrangements" in
the Offering Prospectus nor is indemnification required for material oral misstatements made by
Capital Resources, which are not based upon information provided by the Association or the Company
orally or in writing or based on information contained in the Registration Statement (or any
amendment or supplement thereto), preliminary or final Offering Prospectus (or any amendment or
supplement thereto), the Conversion Application, any Blue Sky Application or Sales Information
distributed in connection with the Conversion.

(b) Capital Resources agrees to indemnify and hold harmless the Company and the Association, their
directors and officers, agents, servants and employees and each person, if any, who controls the
Company or the Association within the meaning of Section 15 of the 1933 Act or Section 20(a) of the
1934 Act against any and all loss, liability, claim, damage or expense whatsoever (including but not
limited to settlement expenses), joint or several which they, or any of them, may suffer or to which
they, or any of them, may become subject under all applicable federal and state laws or otherwise,
and to promptly reimburse the Company, the Association and any such persons upon written demand for
any expenses (including fees and disbursements of counsel) incurred by them, or any of them, in
connection with investigating, preparing or defending any actions, proceedings or claims (whether
commenced or threatened) to the extent such losses, claims, damages, liabilities or actions arise
out of or are based upon any untrue statement or alleged untrue statement of a material fact
contained in the Registration Statement (or any amendment of supplement thereto), or the preliminary
or final Offering Prospectus (or any amendment or supplement thereto), or the Conversion Application
or any Blue Sky Application or Sales Information or are based upon the omission or alleged omission
to state in any of the foregoing documents a material fact required to be stated therein or
necessary to make the statements therein, in the light of the circumstances under which they were
made, not misleading; provided, however, that Capital Resources obligations under this Section 9(b)
shall exist only if and only to the

-24-
<!-- page 18 -->
extent that such untrue statement or alleged untrue statement was made in, or such material fact or
alleged material fact was omitted from, the Registration Statement (or any amendment or supplement
thereto), the preliminary or final Offering Prospectus (or any amendment or supplement thereto), or
the Conversion Application, any Blue Sky Application or Sales Information in reliance upon and in
conformity with written information furnished to the Company or the Association by Capital Resources
regarding Capital Resources expressly for use under the caption "The Conversion - Marketing
Arrangements" in the Offering Prospectus or in the event of oral misstatements made by Capital
Resources, which are not based upon information provided by the Association or the Company orally or
in writing or based on information contained in the Registration Statement (or any amendment or
supplement thereto), preliminary or final Offering Prospectus (or any amendment or supplement
thereto), the Conversion Application, any Blue Sky Application or Sales Information distributed in
connection with the Conversion.

(c) Each indemnified party shall give prompt written notice to each indemnifying party of any
action, proceeding, claim (whether commenced or threatened), or suit instituted against it in
respect of which indemnity may be sought hereunder, but failure to so notify an indemnifying party
shall not relieve it from any liability which it may have on account of this Section 9 or otherwise.
An indemnifying party may participate at its own expense in the defense of such action. In addition,
if it so elects within a reasonable time after receipt of such notice, an indemnifying party,
jointly with any other indemnifying parties receiving such notice, may assume defense of such action
with counsel chosen by it and approved by the indemnified parties that are defendants in such
action, unless such indemnified parties reasonably object to such assumption on the ground that
there may be legal defenses available to them that are different from or in addition to those
available to such indemnifying party. If an indemnifying party assumes the defense of such action,
the indemnifying parties shall not be liable for any fees and expenses of counsel for the
indemnified parties incurred thereafter in connection with such action, proceeding or claim, other
than reasonable costs of investigation. In no event shall the indemnifying parties be liable for the
fees and expenses of more than one separate firm of attorneys (and any special counsel that said
firm may retain) for all indemnified parties in connection with any one action, proceeding or claim
or separate but similar or related actions, proceedings or claims in the same jurisdiction arising
out of the same general allegations or circumstances.

(d) The agreements contained in this Section 9 and in Section 10 hereof and the representations and
warranties of the Company and the Association set forth in this Agreement shall remain operative and
in full force and effect regardless of: (i) any investigation made by or on behalf of Capital
Resources or its officers, directors or controlling persons, agents or employees or by or on behalf
of the Company or the Association or any officers, directors or controlling persons, agents or
employees of the Company or the Association or any controlling person, director or officer of the
Company or the Association; (ii) delivery of and payment hereunder for the Shares; or (iii) any
termination of this Agreement.

(e) No indemnification by the Association under Section 9(a) hereof nor contribution under Section
10 hereof shall be effective if the same shall be deemed to be in violation of any law, rule or
regulation applicable to the Association including, without limitation, Section 23A of the Federal
Reserve Act. If the indemnification or contribution by the Association is not effective pursuant to
the preceding sentence, then the indemnification by Capital Resources pursuant to Section 9(b) shall
be given only to the Company, its directors and officers, agents, servants and employees and not to
the Association, its directors and officers, agents, servants and employees and the Association
shall not be entitled to any contribution from Capital Resources pursuant to Section 10.

-25-

SECTION 10. Contribution. In order to provide for just and equitable contribution in circumstances
in which the indemnification provided for in Section 9 is due in accordance with its terms but is
for any reason unavailable as a result of Section 9(e) or held by a court to be unavailable from the
Company, the Association or Capital Resources, the Company, the Association and Capital Resources
shall contribute to the aggregate losses, claims, damages and liabilities (including any
investigation, legal and other expenses incurred in connection with, and any amount paid in
settlement of any action, suit or proceeding of any claims asserted, but after deducting any
contribution received by the Company or the Association or Capital Resources from persons other than
the other party thereto, who may also be liable for contribution) in such proportion so that Capital
Resources is responsible for that portion represented by the percentage that the fees paid to
Capital Resources pursuant to Section 2 of this Agreement (not including expenses) bears to the
gross proceeds received by the Company from the sale of the Shares in the Subscription and Public
Offerings and the Company and the Association shall be responsible for the balance. If, however, the
allocation provided above is not permitted by applicable law or if the indemnified party failed to
give the notice required under Section 9 above, then each indemnifying party shall contribute to
such amount paid or payable by such indemnified party in such proportion as is appropriate to
reflect not only such relative fault of the Company and the Association on the one hand and Capital
Resources on the other
<!-- page 19 -->
in connection with the statements or omissions which resulted in such losses, claims, damages or
liabilities (or actions, proceedings or claims in respect thereof), but also the relative benefits
received by the Company and Association on the one hand and Capital Resources on the other from the
offering as well as any other relevant equitable considerations. The relative benefits received by
the Company and the Association on the one hand and Capital Resources on the other shall be deemed
to be in the same proportion as the total gross proceeds from the Subscription and Public Offerings
(before deducting expenses) received by the Company bear to the total fees (not including expenses)
received by Capital Resources. The relative fault shall be determined by reference to, among other
things, whether the untrue or alleged untrue statement of a material fact or the omission or alleged
omission to state a material fact relates to information supplied by the Company and/or the
Association on the one hand or Capital Resources on the other and the parties' relative intent, good
faith, knowledge, access to information and opportunity to correct or prevent such statement or
omission. The Company, the Association and Capital Resources agree that it would not be just and
equitable if contribution pursuant to this Section 10 were determined by pro rata allocation or by
any other method of allocation which does not take account of the equitable considerations referred
to above in this Section 10. The amount paid or payable by an indemnified party as a result of the
losses, claims, damages or liabilities (or action, proceedings or claims in respect thereof)
referred to above in this Section 10 shall be deemed to include any legal or other expenses
reasonably incurred by such indemnified party in connection with investigating or defending any such
action, proceeding or claim. It is expressly agreed that Capital Resources shall not be liable for
any loss, liability, claim, damage or expense or be required to contribute any amount which in the
aggregate exceeds the amount paid (excluding reimbursable expenses) to Capital Resources under this
Agreement. It is understood that the above-stated limitation on Capital Resources' liability is
essential to Capital Resources and that Capital Resources relied upon such limitation and would not
have entered into this Agreement if such limitation had not been agreed to by the parties to this
Agreement. No person found guilty of any fraudulent misrepresentation (within the meaning of Section
11(f) of the 1933 Act) shall be entitled to contribution from any person who was not found guilty of
such fraudulent misrepresentation. The obligations of the Company and the Association under this
Section 10 and under Section 9 shall be in addition to any liability which the Company and the
Association may otherwise have. For purposes of this Section 10, each of Capital Resources', the
Company's or the Association's officers and directors and each person, if any, who controls Capital
Resources or the Company or the Association within the meaning of the 1933 Act and the 1934 Act
shall have the same rights to contribution as the Company and the Association.

-26-

Any party entitled to contribution, promptly after receipt of notice of commencement of any action,
suit, claim or proceeding against such party in respect of which a claim for contribution may be
made against another party under this Section 10, will notify such party from whom contribution may
be sought, but the omission to so notify such party shall not relieve the party from whom
contribution may be sought from any other obligation it may have hereunder or otherwise than under
this Section 10.

SECTION 11. Survival of Agreements, Representations and Indemnities. The respective indemnities of
the Company, the Association and Capital Resources and the representations and warranties and other
statements of the Company and the Association set forth in or made pursuant to this Agreement shall
remain in full force and effect, regardless of any termination or cancellation of this Agreement or
any investigation made by or on behalf of Capital Resources, the Company, the Association or any
indemnified person referred to in Section 9 hereof, and shall survive the issuance of the Shares,
and any legal representative, successor or assign of Capital Resources, the Association, and any
such indemnified person shall be entitled to the benefit of the respective agreements, indemnities,
warranties and representations.

SECTION 12. Termination. Capital Resources may terminate this Agreement by giving the notice
indicated below in this Section at any time after this Agreement becomes effective as follows:

(a) In the event the Company fails to sell all of the Shares within the period specified, and in
accordance with the provisions of the Plan or as required by the Conversion Regulations and
applicable law, this Agreement shall terminate upon refund by the Association to each person who has
subscribed for or ordered any of the Shares the full amount which it may have received from such
person, together with interest as provided in the Offering Prospectus, and no party to this
Agreement shall have any obligation to the other hereunder, except for payment by the Association
and/or the Company as set forth in Sections 2, 7, 9 and 10 hereof.

(b) If any of the conditions specified in Section 8 shall not have been fulfilled when and as
required by this Agreement, or by the Closing Date, or waived in writing by Capital Resources, this
Agreement and all of Capital Resources obligations hereunder may be canceled by Capital Resources by
notifying the Association of such cancellation in writing or by telegram at any time at or prior to
the Closing Date, and, any such cancellation shall be without Liability of any party to any other
party except as otherwise provided in Sections 2, 7, 9 and 10 hereof.

(c) If Capital Resources elects to terminate this Agreement as provided in this section, the Company
and the Association shall be notified as provided in Section 13 hereof, promptly by Capital
Resources by telephone or telegram, confirmed by letter.
<!-- page 20 -->
SECTION 13. Notices. All communications hereunder, except as herein otherwise specifically provided,
shall be mailed in writing and if sent to Capital Resources shall be mailed, delivered or
telegraphed and confirmed to Capital Resources, Inc.,1701 K Street, N.W., Suite 700, Washington,
D.C. 20006 Attention: Catherine Kozlow Rochester (with a copy to Serchuk & Zelermyer, LLP, 81 Main
Street, White Plains, NY 10601, Attention: Clifford S. Weber, Esq.) and, if sent to the Company and
the Association, shall be mailed, delivered or telegraphed and confirmed to the Company and the
Association at 161 Church Street, Amsterdam, New York, 12010, (Attention: John M. Lisicki (with a
copy to Malizia, Spidi, Sloane & Fisch, P.C., 1301 K Street, N.W., Suite 700 East Washington, D.C.
20005, Attention: John J. Spidi, Esq.)

-27-

SECTION 14. Parties. The Company and the Association shall be entitled to act and rely on any
request, notice, consent, waiver or agreement purportedly given on behalf of Capital Resources when
the same shall have been given by the undersigned. Capital Resources shall be entitled to act and
rely on any request, notice, consent, waiver or agreement purportedly given on behalf or the Company
or the Association, when the same shall have been given by the undersigned or any other officer of
the Company or the Association. This Agreement shall inure solely to the benefit of, and shall be
binding upon, Capital Resources and the Company, the Association and the controlling persons
referred to in Section 9 hereof, and their respective successors, legal representatives and assigns,
and no other person shall have or be construed to have any legal or equitable right, remedy or claim
under or in respect of or by virtue of this Agreement or any provision herein contained.

SECTION 15. Closing. The closing for the sale of the Shares shall take place on the Closing Date at
the offices of Capital Resources or such other location as mutually agreed upon by Capital
Resources, the Company and the Association. At the closing, the Association shall deliver to Capital
Resources in next day funds the commissions, fees and expenses due and owing to Capital Resources as
set forth in Sections 2 and 7 hereof and the opinions and certificates required hereby and other
documents deemed reasonably necessary by Capital Resources shall be executed and delivered to effect
the sale of the Shares as contemplated hereby and pursuant to the terms of the Offering Prospectus.

SECTION 16. Partial Invalidity. In the event that any term, provision or covenant herein or the
application thereof to any circumstances or situation shall be invalid or unenforceable, in whole or
in part, the remainder hereof and the application of said term, provision or covenant to any other
circumstance or situation shall not be affected thereby, and each term, provision or covenant herein
shall be valid and enforceable to the full extent permitted by law.

SECTION 17. Construction. This Agreement shall be construed in accordance with the laws of the
District of Columbia.

SECTION 18. Counterparts. This Agreement may be executed in separate counterparts, each of which so
executed and delivered shall be an original, but all of which together shall constitute but one and
the same instrument.

Time shall be of the essence of this Agreement.

-28-

If the foregoing correctly sets forth the arrangement among the Company, the Association and Capital
Resources, please indicate acceptance thereof in the space provided below for that purpose,
whereupon this letter and Capital Resources' acceptance shall constitute a binding agreement.

Very truly yours,

AFSALA BANCORP, INC.

By: ________________________________ John M. Lisicki, President and Chief Executive Officer

AMSTERDAM FEDERAL SAVINGS AND LOAN ASSOCIATION

By: ________________________________ John M. Lisicki, President and Chief Executive Officer

Accepted as of the date first above written.

CAPITAL RESOURCES, INC.
<!-- page 21 -->
By: _____________________________________ Catherine K. Rochester, President

-29-
