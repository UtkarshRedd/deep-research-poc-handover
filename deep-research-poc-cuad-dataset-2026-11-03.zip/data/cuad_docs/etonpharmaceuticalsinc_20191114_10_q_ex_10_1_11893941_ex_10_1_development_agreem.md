<!-- page 1 -->
# EXCLUSIVE LICENSE AND PRODUCT DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2019-06-12 |
| Parties | Eton Pharmaceuticals, Inc. (“ETON”); Aucta Pharmaceuticals, Inc.(“Aucta”) |
| Source | CUAD v1 / EtonPharmaceuticalsInc_20191114_10-Q_EX-10.1_11893941_EX-10.1_Development Agreement |

Exhibit 10.1 Certain information identified by bracketed asterisks ([ * * * ]) has been omitted from
this exhibit because it is both not material and would be competitively harmful if publicly
disclosed. EXCLUSIVE LICENSE AND PRODUCT DEVELOPMENT AGREEMENT THIS EXCLUSIVE LICENSE AND PRODUCT
DEVELOPMENT AGREEMENT (this "Agreement") is entered into as of June 12, 2019 (the "Execution Date")
by and between Eton Pharmaceuticals, Inc., a Delaware corporation with offices at 21925 W. Field
Pkwy, Suite 235, Deer Park, Illinois, USA ("ETON"), and Aucta Pharmaceuticals, Inc., a Delaware
corporation with offices at 71 Suttons Lane, Piscataway, NJ 08854 ("Aucta") . RECITALS WHEREAS, ETON
is engaged in the business of licensing, developing, marketing, distributing and selling
pharmaceutical drug products; WHEREAS, Aucta is engaged in the business of developing pharmaceutical
drug products, including the Products (later defined); WHEREAS, ETON desires to obtain an exclusive
license to the Products, the Dossiers (later defined), and Aucta Background Intellectual Property
(later defined) for Marketing the Products in the Territory, and Aucta is willing to grant such an
exclusive license to ETON under the terms and conditions set forth herein; WHEREAS, ETON will pay
Aucta certain milestone, royalty and licensing payments based on the sale of Products in the
Territory under the terms and conditions set forth herein; and WHEREAS, the parties hereto agree
that, unless otherwise stated, the terms herein shall not be effective unless and until the
Effective Date (later defined) occurs. NOW, THEREFORE, in consideration of the foregoing premises
and the representations, warranties, covenants and agreements herein contained and other good and
valuable consideration, the receipt and sufficiency of which are hereby acknowledged, ETON and
Aucta, intending to be legally bound, hereby agree as follows: 1. DEFINITIONS. For the purposes of
this Agreement, the following terms whether used in singular or plural form shall have the meanings
as defined below: 1.1 "Affiliates" means, with respect to a Party or any Third Party, any
corporation, firm, partnership or other entity that controls, is controlled by or is under common
control with such entity. For the purposes of this definition, "control" means the ownership of at
least 50% of the voting share capital of an entity or any other comparable equity or ownership
interest. 1.2 "ANDA Litigation" shall have the meaning ascribed to the term in Section 7.5.2 of this
Agreement.

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 2 -->
CONFIDENTIAL 1.3 "Applicable Law" means the applicable laws, rules, regulations, guidelines and
requirements of any Governmental Entity related to the development, registration, manufacture,
importation, commercialization of the Products in the Territory, the manufacture in and export from
the Territory of Manufacture, or any obligation under, or related to, this Agreement, including
those obligations applicable to the Dossiers. 1.4 "Aucta Background Intellectual Property" means any
and all patents and trademarks, patent and trademark applications or other patent and trademark
rights, copyrights, inventions, know-how, trade secrets, proprietary knowledge, data, formulations,
product specifications and other information owned, licensed to or controlled by Aucta relating to
the Products, including but not limited to use, manufacture, and packaging thereof. 1.5 "Aucta
Indemnified Parties" shall have the meaning ascribed to the term in Section 13.2 of this Agreement.
1.6 "Breaching Party" shall have the meaning ascribed to the term in Section 11.2 of this Agreement.
1.7 "Business Day" means any day, other than Saturday, Sunday or other day on which commercial banks
are authorized or required to close in New York, New York or Rome, Italy. 1.8 "Calendar Quarter"
means a three (3) consecutive month period ending on March 31, June 30, September 30 or December 31.
1.9 "Claim" includes a claim, notice, demand, action, proceeding, litigation, prosecution,
arbitration, investigation, judgment, award, damage, loss, cost, expense or liability however
arising, whether present, unascertained, immediate, future or contingent, whether based in contract,
tort or statute and whether involving a Third Party or a Party or otherwise. 1.10 "Confidential
Information" shall have the meaning ascribed to the term in Section 9.2 of this Agreement. 1.11
"Dossiers" means the New Drug Applications pursuant to 21 U.S.C. §355(b)(1)-(2), and all amendments
and supplements thereof, for the Products as set forth in Exhibit A. 1.12 "Effective Date" shall
have the meaning ascribed to the term in Section 11.1 of this Agreement. 1.13 "ETON Indemnified
Parties" shall have the meaning ascribed to the term in Section 13.1 of this Agreement. 1.14 "FDA"
means the United States Food and Drug Administration and all divisions under its direct control or
any successor organizations. 1.15 "Force Majeure Events" shall have the meaning ascribed to such
term in Section 15.2 of this Agreement. 2

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 3 -->
CONFIDENTIAL 1.16 "GMP" means current good manufacturing practices as defined by the FDA. 1.17
"Governmental Entity" means any arbitrator, court, judicial, legislative, administrative, or
regulatory agency, commission, department, board, or bureau or body or other government authority or
instrumentality or any Person or entity exercising executive, legislative, judicial, regulatory, or
administrative functions of or pertaining to government, whether foreign or domestic, whether
federal, state, provincial, municipal, or other. 1.18 "Gross Sales" shall have the meaning ascribed
to the term in Section 1.26. 1.19 "Indemnitee" shall have the meaning ascribed to the term in
Section 13.3.1 of this Agreement. 1.20 "Indemnitor" shall have the meaning ascribed to the term in
Section 13.3.1 of this Agreement. 1.21 "Infringement Notification Date" shall have the meaning
ascribed to the term in Section 7.4 of this Agreement. 1.22 "Intellectual Rights Suit" shall have
the meaning ascribed to the term in Section 7.4 of this Agreement. 1.23 "Losses" means all losses,
costs, damages, judgments, settlements, interest, fees or expenses including, without limitation,
all reasonable attorneys' fees, experts' or consultants' fees, expenses and costs. 1.24 "Market" or
"Marketing" shall have the meaning ascribed to the term in Section 2.1 of this Agreement. 1.25 "NDC"
means a national drug code as issued by the FDA. 1.26 "Net Sales" means, with respect to each
Product sold in the Territory, the aggregate gross sales amount invoiced by ETON or any sublicensee
or other party authorized by ETON to wholesale or distribute the Products on an arms-length basis to
Third Parties in the Territory ("Gross Sales"), less (as applicable) the following ETON expenses as
accrued and adjusted for amounts actually taken, consistent with ETON'S standard accounting
practices in accordance with GAAP: (a) amounts refunded or credited for returned, damaged, outdated,
short-dated or defective goods, and bad debts, and (b) all of the following: (i) taxes, duties and
other governmental charges related to the production, use or sale of the Products (including,
including without limitation the brand manufacturer's tax imposed pursuant to the Patient Protection
and Affordable Care Act (Pub. L. No. 111-148) as amended or replaced, but not including taxes
assessed against the income derived from such sale); (ii) trade, quantity and cash discounts,
allowances, retroactive price adjustments, credit incentive payments, chargebacks, patient support
programs, and rebates (including governmental rebates or other price reductions provided, based on
sales by ETON to any Governmental Entity or regulatory authority in respect of state or federal
Medicare, Medicaid, government pricing or similar programs;); and (iii) any costs incurred in
connection with or arising out of compliance with any Risk Evaluation and Mitigation Strategies
approved by the FDA and (iv) any expenses associated with serialization of the Products.
Distribution of Licensed Products for clinical trials or as samples will not be deemed a "Net Sale"
under this definition. 3

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 4 -->
CONFIDENTIAL 1.27 "Party" or "Parties" means ETON or Aucta, as applicable. 1.28 "Payment Period"
shall have the meaning ascribed to the term in Section 6.3.7 of this Agreement. 1.29 "Person" means
any individual, partnership (general or limited), association, corporation, limited liability
company, joint venture, trust, estate, limited liability partnership, unincorporated organization,
government (or any agency or political subdivision thereof) or other legal person or organization.
1.30 "Pharmacovigilance Agreement" shall have the meaning ascribed to the term in Section 3.4 of
this Agreement. 1.31 "Product" or "Products" means a product or products set forth in Exhibit A for
Marketing by or for ETON in the Territory (and covered or intended to be covered by a Dossier) and
manufactured and supplied by Aucta (or a Third Party as permitted by this Agreement) to ETON in
fully packaged and labeled form and ready for commercialization by ETON. 1.32 "Recall Event" shall
have the meaning ascribed to that term in Section 3.4 of this Agreement. 1.33 "Sale Representatives
FTE" shall have the meaning ascribed to the term in Section 5.4 of this Agreement. 1.34
"Specification" shall mean, for a particular Product, the specifications, methods and processes of
the product, as set forth in the applicable Dossier for that Product. 1.35 "Taxes" means taxes,
duties, fees, premiums, assessments, imposts, levies and other charges of any kind whatsoever
imposed by any Governmental Entity, including all interest, penalties, fines, additions to tax or
other additional amounts imposed by any Governmental Entity in respect thereof, and including those
levied on, or measured by, or referred to as, income, gross receipts, profits, capital, transfer,
land transfer, sales, goods and services, harmonized sales, use, value-added, excise, stamp,
withholding, business, franchising, property, development, occupancy, employer health, payroll,
employment, health, social services, education and social security taxes, all surtaxes, all customs
duties and import and export taxes, countervail and anti-dumping, all license, franchise and
registration fees and all employment insurance, health insurance and government pension plan
premiums or contributions. 1.36 "Term" shall have the meaning ascribed to this term in Section 11.1
of this Agreement. 4

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 5 -->
CONFIDENTIAL 1.37 "Territory" shall mean the fifty states of the United States of America, the
District of Columbia, the Commonwealth of Puerto Rico, Guam, American Samoa, the U.S. Virgin Islands
and all territories and possessions of the United States of America and United States military
bases. 1.38 "Territory of Manufacture" means the country where the Products is made. 1.39 "Third
Party" means any Person other than ETON, Aucta or their respective Affiliates. 1.40 "Transfer Taxes"
shall have the meaning ascribed to this term in Section 10 of this Agreement. 2. GRANT OF RIGHTS 2.1
Aucta, for itself and its Affiliates, hereby grants to ETON in accordance with the terms and
conditions of this Agreement, an exclusive (even as to and against Aucta in the Territory) right and
license, including the right to sublicense, to the Products (or any components thereof), Dossiers,
and all current and future Aucta Background Intellectual Property that is owned or controlled by
Aucta or its Affiliates for ETON to develop, manufacture, import, use, promote, distribute, market,
advertise, offer for sale or sell (collectively, "Market") the Products in and for the Territory.
For avoidance of doubt, Aucta and its Affiliates shall retain all rights to the Products outside the
Territory, and Aucta shall remain at all times the owner of all Products, Dossier and Aucta
Background Intellectual Property worldwide including the Territory. 2.2 ETON, for itself and its
Affiliates, hereby grants to Aucta in accordance with the terms and conditions of this Agreement, a
right and license, to its trademark, including to its name and logo, that is owned or controlled by
ETON or its Affiliates for Aucta (or its authorized Third Party) to make the packs, labels, and
leaflets for the Products for sale in the Territory. For avoidance of doubt, ETON and its Affiliates
shall remain the owner of its trademarks. 3. PRODUCT DEVELOPMENT AND REGISTRATION 3.1 Development
and Registration Responsibilities. 3.1.1 At its sole cost and expense, Aucta shall be responsible
and liable for all development and manufacturing activities required for the filing and approval of
the Dossiers for the Products in and for the Territory, including without limitation all costs and
management of any required pre-approval and post-approval clinical or other studies. 3.1.2 At its
sole cost and expense, Aucta shall be responsible and liable for all regulatory activities required
for the filing and approval of the Dossiers for the Products in and for the Territory. 3.1.3 Aucta
shall provide to ETON all regulatory and compliance-related documents and correspondence with the
FDA within five (5) Business Days after submission or receipt of such documents or correspondence
with the FDA relating to the Products or Dossiers for the Products, including without limitation any
oral (notes thereof) and written correspondence with FDA relating to the Products or Dossiers and
any compliance-related oral (notes thereof) or written correspondence with FDA relating to the
Product(s)' manufacturing facility(ies)' status or deficiencies. 5

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 6 -->
CONFIDENTIAL 3.1.4 ETON will provide commercially reasonable support on regulatory activities, when
requested by Aucta and necessary for approval. 3.2 Registration Maintenance and Regulatory
Responsibilities. 3.2.1 Aucta shall hold the approved Dossiers in its name and be responsible for
their maintenance. Aucta will take all actions with the FDA, including paying all fees and
conducting all communications with FDA or other Governmental Entities as required by Applicable Law
in respect of the Dossiers, including without limitation payment of fees owed under the Prescription
Drug User Fee Act, Annual Branded Prescription Drug Fees assessed under Section 9008 of the Patient
Protection and Affordable Care Act (ACA), Public Law 111-148 (124 Stat. 119 (2010)), as amended by
Section 1404 of the Health Care and Education Reconciliation Act of 2010 (HCERA), Public Law 111-152
(124 Stat. 1029 (2010)), or any successor laws, and preparing and filing all required reports
(including adverse drug experience reports) with the appropriate Governmental Entity. 3.3 ETON's NDC
Numbers. Aucta and its Affiliates shall not sell any products under ETON's or its Affiliates' names
or NDC numbers. 3.4 Medical Inquires, Product Complaints and Recalls. ETON, Aucta and a designated
third-party contract manufacturer shall share in the responsibility for responding to any medical
inquiries or complaints about any Products or addressing any circumstances that may result in a
potential recall, market withdrawal, inventory retrieval, or similar action ("Recall Event") as set
forth in the Pharmacovigilance Agreement attached hereto as Exhibit B (the "Pharmacovigilance
Agreement") and to be entered into by the Parties and the contract manufacturer as soon as
practicable. 3.5 Competitive Products. During the Term of this Agreement, and for a period of two
(2) years thereafter, Aucta shall not research, develop, manufacture, file, sell, market, or
distribute more than two products containing the active ingredient Lamotrigine; nor will Aucta
directly or indirectly assist any other Person or entity in carrying or any such activities. [ * * *
] 4. MANUFACTURE AND SUPPLY 4.1 ETON shall enter into a commercial supply agreement with a contract
manufacturing organization and Aucta shall enter into a commercial supply agreement with an active
pharmaceutical ingredient supplier within ninety (90) days from the Execution Date unless otherwise
agreed to by the parties in writing. 4.2 If the terms of Aucta's commercial supply agreement with
the active pharmaceutical ingredient supplier in Section 4.1 is assignable to ETON, ETON may assume
the aforementioned agreement by providing written notice to Aucta, and Aucta will have seven (7)
days from receipt of the notice to assign the aforementioned agreement to ETON. 6

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 7 -->
CONFIDENTIAL 5. SALES, MARKETING AND DISTRIBUTION 5.1 ETON shall be solely responsible for the
Marketing of the Products and shall have sole and exclusive right to make all Marketing decisions
for the Product in the Territory, including without limitation to pricing, contracting,
sub-licensing, co-promoting, or any contract promotion activities. 5.2 ETON shall use commercially
reasonable efforts to Market the Products in the Territory during the Term of this Agreement. 5.3
ETON shall have the sole and exclusive right to determine all terms and conditions of sale of the
Products to its or its prospective consumers. 5.4 [ * * * ] 6. MILESTONES AND OTHER PAYMENTS 6.1
Licensing Fees. ETON shall pay to Aucta licensing fees of up to an amount of five million dollars
($5,000,000) based on the following payment schedule: (a) An amount of two million dollars
($2,000,000) within five (5) days of the Effective Date of this Agreement. (b) An amount of two
million dollars ($2,000,000) within thirty (30) days after the first commercial sales of Product. [
* * * ] (c) An amount of one million dollars ($1,000,000) within thirty (30) days after the issuance
and listing of a patent in the Orange Book for the Product and its Dossier, only if that patent is
listed prior to the submission of an ANDA referencing the Product and its Dossier as the reference
product. 6.2 Commercial Milestones. ETON shall pay to Aucta a total sum amount of up to eighteen
million dollars ($18,000,000) based on Net Sales of a Product (on a Product by Product basis) after
the achievement of the following one-time milestones for each Product: (a) An amount of one million
dollars ($1,000,000) upon Net Sales first exceeding an amount of ten million dollars ($10,000,000)
in a calendar year to be paid within sixty (60) days after the calendar year end. (b) An amount of
two million dollars ($2,000,000) upon Net Sales first exceeding an amount of twenty million dollars
($20,000,000) in a calendar year to be paid within sixty (60) days after the calendar year end. (c)
An amount of five million dollars ($5,000,000) upon Net Sales first exceeding an amount of fifty
million dollars ($50,000,000) in a calendar year to be paid within sixty (60) days after the
calendar year end. 7

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 8 -->
CONFIDENTIAL (d) An amount of ten million dollars ($10,000,000) upon Net Sales first exceeding an
amount of one hundred million dollars ($100,000,000) in a calendar year to be paid within sixty (60)
days after the calendar year end. 6.3 Royalty. 6.3.1 ETON shall pay to Aucta a royalty payment of [
* * * ] of Net Sales of the Products. 6.3.2 [ * * * ] 6.3.3 If the amount of royalty payment under
Section 6.3.1 is less than the amount of royalty payment under Section 6.3.2, then ETON shall pay
Aucta the difference between royalty payments in Sections 6.3.1 and 6.3.2 within sixty (60) days of
the calendar year end, but in no event shall the difference paid be greater than the minimum amount
in Section 6.3.2. 6.3.4 For payments under Section 6.3, ETON shall pay Aucta royalty payments under
Section 6.3.1 or 6.3.2 only, but not under both sections concurrently. 6.3.5 If ETON is unable or
limited in its ability to sell the Products due to supply chain (e.g., manufacturing, API, etc.) or
regulatory issues, that extend for a period of thirty (30) days or more, the minimum royalty payment
under Section 6.3.2 shall be adjusted to prorate the annual minimum to account for the period of
inability to supply; provided, however, that the minimum royalty payment shall be paid if the
inability or limitation of sales by ETON is directly and solely due to ETON's gross negligence or
willful misconduct. 6.3.6 [ * * * ] 6.3.7 Within thirty (30) days following the end of each Calendar
Quarter following the first commercial sale of the Product in the Territory, including the first and
last payment period which may be of a shorter duration (each, a "Payment Period"), ETON shall: (a)
compute and report to Aucta in a mutually acceptable format the Net Sales for each Product sold in
the Territory during the Payment Period, and (b) pay to Aucta the appropriate royalty payment under
Section 6.3 within thirty (30) days of the delivery of the report. 6.4 [ * * * ] 6.5 Interim and
Final True-Ups. During the Term, on an annual basis, following the first (1st) calendar year from
launch of Product and on a Product-by-Product basis, ETON shall perform an interim "true-up"
reconciliation and shall provide Aucta with a written report of such outlining the deductions
specified in the definition of Net Sales. The reconciliation shall be based on actual cash paid or
credits issued or accrued in accordance with GAAP and company practices consistently applied,
including any amounts irrevocably committed but not yet paid at the end of the preceding calendar
year. If the foregoing reconciliation report shows either an underpayment or an overpayment between
the Parties, the Party owing payment to the other Party shall pay the amount of the difference to
the other Party within thirty (30) days after the date of delivery of such report. In addition,
within twenty-five (25) months after the termination or expiration of the Term and on a
Product-by-Product basis, ETON shall perform a final "true-up" reconciliation and shall provide
Aucta with a written report of such outlining the deductions specified in the definition of Net
Sales. If the foregoing reconciliation report shows either an underpayment or an overpayment between
the Parties, the Party owing payment to the other Party shall pay the amount of the difference to
the other Party within thirty (30) days after the date of delivery of such report. 8

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 9 -->
CONFIDENTIAL 6.6 Taxes. Each Party shall be responsible for and shall pay all Taxes payable on any
income earned or received by it during the Term. Where required by law, ETON shall have the right to
withhold applicable Taxes from any payments to be made hereunder by ETON to Aucta. Any Tax, duty or
other levy paid or required to be withheld by ETON on account of any payments payable to Aucta under
this Agreement shall be deducted from the amount of payments due to Aucta. ETON shall secure and
promptly send to Aucta proof of such Taxes, duties or other levies withheld and paid by ETON for the
benefit of Aucta. Each Party agrees to cooperate with the other Party in claiming exemptions from
such deductions or withholdings under any agreement or treaty from time to time in effect. 6.7
Audits. Each Party shall permit an independent certified public accounting firm selected by the
auditing Party and reasonably acceptable to the non-auditing Party, that has agreed to be bound by a
confidentiality agreement reasonably acceptable to the Parties, to have access, during normal
business hours and upon reasonable prior notice (not more often than once in any calendar year), to
those books and records maintained by the non-auditing Party necessary for the auditing Party to
verify the accuracy of the non-auditing Party's calculations under this Section 6 and/or cost of
Product(s) for any period ending not more than two (2) years prior to the date of such request,
subject to any limitations in scope necessary to comply with Applicable Law, Third Party
confidentiality restrictions, or maintain legal privilege, including but not limited to Third Party
pricing information. All such information shall be retained on a confidential basis by the
accounting firm, and such accounting firm's use of such information shall be limited to the
aforementioned verification. Unless otherwise agreed to by the Parties in writing, the accounting
firm shall not be paid on a contingency or similar basis. 6.8 Accounting. ETON and Aucta shall
calculate and record calculations under this Section 6 and with respect to Product(s) cost in
accordance with U.S. GAAP, and shall maintain all books and records related thereto in accordance
with standard cost accounting policies and practices, in accordance with U.S. GAAP for the Term plus
an additional three (3) years thereafter. 7. PATENT PROSECUTION AND LITIGATION 7.1 At its sole cost
and expense, Aucta shall be solely responsible and liable for any litigation in connection with the
Product's development, and the Aucta Background Intellectual Property other than ANDA Litigation
covered below in Section 7.5. 7.2 At its sole cost and expense, ETON shall be solely responsible and
liable for any non-patent litigation in connection with its sales and marketing activities. 9

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 10 -->
CONFIDENTIAL 7.3 Patent Prosecution. Each Party shall be responsible, at its own expense, for filing
and prosecuting such patent applications, as it deems appropriate, and for paying maintenance fees
on any patents issuing therefrom, for the Term, with respect to intellectual property owned by it
that relate to or are used in connection with the manufacture, sale or use of the Product.
Notwithstanding anything herein to the contrary, and in the event that that the Aucta Background
Intellectual Property includes patent(s) and or patent application(s), Aucta, at its sole cost and
expense, shall maintain and protect the Aucta Background Intellectual Property and continue to
prosecute and maintain its patents included in the Aucta Background Intellectual Property and shall
keep ETON advised of material actions relative to the same. Should Aucta contemplate abandoning or
otherwise forfeiting any patent/patent applications or patent rights in the Aucta Background
Intellectual Property, Aucta shall notify ETON in advance of such contemplation. In such an event,
ETON may pursue maintaining such patent(s) or filing and prosecuting such patent applications
relating to the Products, at its own cost and expense, and shall obtain from Aucta rights and
licenses to those patents and patent applications with the same scope as that in Section 2.1. Aucta
shall maintain the confidentiality of any trade secrets included in the Aucta Background
Intellectual Property. Each Party shall promptly render all necessary assistance reasonably
requested by the other Party, at the requesting Party's expense, in applying for and prosecuting
patent applications based on intellectual property owned by such other Party pursuant to this
Agreement. 7.4 Notice of Infringement. If either Party shall learn of (a) any claim or assertion
that the manufacture, use or marketing of the Product under this Agreement, or any other action
taken by either party in performance of its obligations hereunder infringes, misappropriates or
otherwise violates the intellectual property rights of any Third Party, or (b) the actual or
threatened infringement, misappropriation or other violation by any Third Party of the intellectual
property rights of any party that are the subject of this Agreement ("Intellectual Rights Suits"),
then the Party becoming so informed shall as soon as reasonably practicable, but in all events
within three (3) Business Days thereafter (the "Infringement Notification Date"), notify the other
Party of such claim or assertion, or actual or threatened infringement, misappropriation or other
violation. 7.5 Intellectual Rights Suit. 7.5.1 Other than an ANDA Litigation covered below in
Section 7.5.2, Aucta shall at its sole cost and expense be solely responsible and liable for and
assume the direction and control of any Intellectual Rights Suit and the defense of claims arising
therefrom, including, without limitation, the selection of legal counsel; provided, however, that
Aucta shall keep ETON apprised of material developments. ETON shall fully cooperate with Aucta in
the defense of any such Intellectual Rights Suit (regardless of which Party is a named party to such
suit), including joining as a party to the suit, and shall be consulted by Aucta in connection with
the settlement of any such Intellectual Rights Suit. Except as otherwise set forth in this
Agreement, Aucta shall be responsible for all reasonable attorneys' fees and costs, settlement
amounts and/or awarded damages incurred by Aucta or by ETON at the request of Aucta or with Aucta's
approval in connection with the defense of Intellectual Rights Suit covered by this Section 7.5.1
provided such is directly related to this Agreement. 10

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 11 -->
CONFIDENTIAL 7.5.2 If the Intellectual Rights Suit relates to the submission to the FDA of an
Abbreviated New Drug Application with a Paragraph IV certification to a patent or patents listed in
the Orange Book in connection with the Product's Dossier ("ANDA Litigation"), then Aucta in
consultation and coordination with ETON shall jointly control the ANDA Litigation(s) and the defense
of claims arising therefrom, including, without limitation, the selection of legal counsel;
provided, however, that in the event of a disagreement about the conduct of the litigation or
selection of counsel that is not resolved through good faith negotiation, Aucta shall have the right
to make any final decisions. Aucta and ETON shall share equally the costs of litigating any ANDA
Litigation and each party shall fully cooperate with the other in any such ANDA Litigation
(regardless of which Party is a named party to such suit), including joining as a party to the suit,
if necessary. No settlement shall be made of an ANDA Litigation without the consent of both Parties,
such consent not to be unreasonably withheld. 7.5.3 The Parties agree that they will not, whether in
the context of the Intellectual Rights Suit, ANDA Litigation or otherwise related thereto, without
the prior written consent of the other Party enter into any agreement or arrangement with any Third
Party which in any way compromises, relinquishes, waives, or otherwise affects, in whole or in part,
the rights of the other Party under this Agreement or in respect of the Product, including, without
limitation, any patent rights related to the Product. 7.6 Sections 7.1, 7.2 and 7.5 shall survive
termination or expiration of this Agreement. 8. INSURANCE At all times from the first commercial
sale of any Product(s) or after the Effective Date through the date which is five (5) years after
the final sale of such Product(s), the Parties will maintain general liability insurance in amounts
that are reasonable and customary in the pharmaceutical industry, provided in no event shall the
general liability insurance amounts be less than five million dollars ($5,000,000) per occurrence
and ten million dollars ($10,000,000) in the aggregate limit of liability per year. The Parties
shall provide written proof of such insurance to each other upon request. 9. CONFIDENTIAL
INFORMATION; PUBLICITY 9.1 Confidential Information. Each Party agrees that it shall not, without
the prior written consent of the other Party, (i) disclose to any Person such other Party's
Confidential Information (as defined below), except to those of its and its Affiliates' employees or
representatives who need to know such information for the purpose of exploiting its rights or
fulfilling its obligations under this Agreement (and then only to the extent that such persons are
under an obligation to maintain the confidentiality of the Confidential Information), or (ii) use
any of such other Party's Confidential Information for any reason other than as contemplated by this
Agreement. If a Party has been advised by legal counsel that disclosure of Confidential Information
of the other Party is required to be made under Applicable Law (including to the FDA or pursuant to
the requirements of a national securities exchange or another similar regulatory body on which it's
or any of its Affiliates stock trades) or pursuant to documents subpoena, civil investigative
demand, interrogatories, requests for information, or other similar process, the Party required to
disclose the Confidential Information shall (to the extent legally permitted) provide the other
Party with prompt written notice of such request or demands or other similar process so that such
other Party may seek an appropriate protective order or waive the disclosing Party's compliance with
the provisions of this Section. In the absence of a protective order or waiver or other remedy, the
Party required to disclose the other Party's Confidential Information may disclose only that portion
of the Confidential Information that its legal counsel advises it is legally required to disclose,
provided that it exercises its commercially reasonable efforts to preserve the confidentiality of
such other Party's Confidential Information, at such other Party's expense, including by cooperating
with such other Party to obtain an appropriate protective order or other reliable assurance that
confidential treatment will be accorded the Confidential Information. Confidential Information shall
remain the sole property of the disclosing Party and all Confidential Information furnished in
written form (and all copies thereof) shall be promptly returned to the disclosing Party or
destroyed by the receiving Party at the disclosing Party's request; provided, however, that the
receiving Party may retain copies of such Confidential Information as necessary for its compliance
obligations under Applicable Laws and any archival purposes, subject to the ongoing obligation to
maintain the confidentiality of such information. This Section 9.1 shall survive termination or
expiration of this Agreement and continue in effect thereafter for a period of five (5) years. 11

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 12 -->
CONFIDENTIAL 9.2 Definition of Confidential Information. The term "Confidential Information" as used
in this Agreement means all confidential information relating to the Parties' business and
operation, this Agreement's term sheet, this Agreement and its terms, or other technical, business
or financial information provided by the Parties as contemplated by this Agreement. The term
"Confidential Information" does not include information that (A) becomes generally available to the
public other than as a result of disclosure by the receiving Party, (B) becomes available to the
receiving Party on a non-confidential basis from a source other than the disclosing Party, provided
that such source is not known by the receiving Party to be bound by a confidentiality agreement with
the disclosing Party, (C) was previously known by the receiving Party as evidenced by the receiving
Party's written records, or (D) was independently developed by the receiving Party without use of or
reliance on the Confidential Information. 9.3 Public Announcement. Neither ETON, Aucta nor any of
their respective Affiliates shall issue any press release or make any public announcement with
respect to this Agreement and the transactions contemplated hereby without obtaining the prior
written consent of the other Party, except as may be required by Applicable Law or stock exchange
rules on which a Party or its Affiliates stock trades. 10. TRANSFER TAXES All transfer, sales, value
added, stamp duty and similar Taxes ("Transfer Taxes") payable to the U.S. government in connection
with the transaction contemplated hereby will be borne by ETON and all Transfer Taxes payable to an
ex-U.S. government in connection with the transaction contemplated hereby will be borne by Aucta. 12

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 13 -->
CONFIDENTIAL 11. TERM AND TERMINATION 11.1 Term. The term of this Agreement shall automatically
become effective upon the occurrence of (i) ETON executing a commercial supply agreement with a
contract manufacturing organization within forty-five (45) days of the Execution Date, provided that
ETON has exercised best efforts to execute such agreement and the failure to execute is solely
caused by the refusal or inability of the proposed manufacturing organization to sign a reasonable
agreement; and (ii) acceptance for review of the Dossier or marketing application for [ * * * ] by
the FDA no later than September 2, 2019 (such date, the "Effective Date") and shall end upon the
termination or expiration of the Agreement as set forth in Section 11 (the "Term"). For avoidance of
doubt, all rights conferred to ETON under this Agreement for the purpose of allowing ETON to Market
the Product in the Territory shall continue until a Party terminates this Agreement. Aucta should
continue to receive 15% of Net Sales Royalty for as long as ETON is selling the Product(s) in the
Territory, unless otherwise agreed to under this Agreement. The obligations of ETON to consummate
the transactions contemplated by this Agreement shall be subject to the fulfillment or ETON's waiver
of the occurrence of the Effective Date. 11.2 Termination for Breach. The Agreement may be
terminated by either Party by written notice to the other at any time if the other Party (the
"Breaching Party") is in material breach or default of any of its obligations hereunder or any of
its representations or warranties as follows: (i) the terminating Party shall send a written notice
of the material breach or material default to the Breaching Party and (ii) the termination shall
become effective a) thirty (30) days after sending notice of the breach if the breach is non-payment
of amounts due hereunder, such as milestone, minimum royalty or royalties amounts and b) sixty (60)
days after sending notice of the breach for all other breaches unless the Breaching Party has cured
any such material breach or material default prior to the expiration of the thirty (30) or sixty
(60) day period as the case may be; or if for non- payment breaches such material default or
material breach is not capable of being cured within such sixty (60) day period and the Breaching
Party has commenced activities reasonably expected to cure such material breach or material default
within such sixty (60) day period and thereafter uses diligent efforts to complete the cure as soon
as practicable, but in no event shall such period exceed ninety (90) days. 11.3 Termination for
Bankruptcy. Either Party may immediately terminate the Agreement in whole or in part if the other
Party: (a) makes an assignment for the benefit of creditors, admits in writing its inability to pay
debts as they mature, or ceases operating in the normal course of business; (b) has a receiver or
trustee appointed by a court over the Party or any substantial part of the Party's assets; (c)
becomes insolvent or is unable to pay its debts as they become due; (d) authorizes, applies for or
consents to the appointment of a trustee or liquidator of all or a substantial part of its assets or
has proceedings seeking such an appointment commenced against it which are not terminated within
ninety (90) days of such commencement; (e) has any substantial part of its property subjected to any
levy, seizure, assignment or sale for, or by any creditor or governmental agency without said levy,
seizure, assignment or sale being lifted, released, reversed or satisfied within ten (10) days; (f)
files a voluntary petition under any chapters of the United States Bankruptcy Code or any other
insolvency law or an involuntary proceeding has been commenced by any Party against the Party under
any one of the chapters of the United States Bankruptcy Code or any other insolvency law and (A) the
proceeding has been pending for at least sixty (60) days; or (B) the Party has consented, either
expressly or by operation of law, to the entry of an order for relief; or (C) the Party has been
decreed or adjudged a debtor or equivalent. 13

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 14 -->
CONFIDENTIAL 11.4 Termination Other than for Breach or Insolvency. (a) ETON has the right to
terminate this Agreement at any time at its sole discretion if the Dossier or marketing application
for the Product is not approved by December 31, 2020 or at a later time if agreed to in writing by
the Parties. (b) ETON has the right to terminate this Agreement after approval of the Dossier or
marketing application for the Product (or added new product), at its sole discretion, upon providing
one hundred eighty (180) days' written notice to Aucta. (c) If Aucta terminates under Section 11.2
or 11.3, or if ETON terminates under Section 11.4(b), ETON shall continue to market the Products as
before notice of termination, receive revenue and pay associated costs for selling the Product(s)
during any notice period. After termination is effective and Aucta assumes control of the Product,
ETON will provide, to the extent practicable, transition services to Aucta to include assistance
with Product distribution, processing of rebates, drug safety, etc. at Aucta's cost for such
services, for a reasonable period of time as mutually determined by the Parties but not to exceed
one hundred eighty (180) days following termination so that Aucta can get its own such services in
place. The Parties shall determine the rate for such additional transition services as may be
required. The objective of this clause is to provide reasonable assurance that a termination does
not disrupt the supply of Product)s) to the market if possible and both parties shall work in good
faith to try and avoid any disruption in the marketing or supply of Products during termination and
transfer of Products sales back to Aucta. 11.5 Effect of Termination or Expiration: Surviving
Obligations. 11.5.1 If this Agreement is terminated by ETON (i) under Section 11.3, in addition to
any remedies that ETON is entitled to, then (a) Aucta shall transfer ownership of the Dossiers to an
Aucta shareholder-controlled entity to enable ETON to continue to commercialize the Products in the
Territory; or (ii) under Section 11.4(a) and (b), in addition to any remedies that ETON is entitled
to, then (a) Aucta may keep all the payments under Section 6 paid by ETON up to the point of
termination, (b) all rights of Aucta granted to ETON shall revert to Aucta, and (c) ETON shall
request consent from the contract manufacturing organization (if necessary) that the commercial
supply agreement with the contract manufacturing organization be assigned to Aucta. 11.5.2 If this
Agreement is terminated by Aucta under Section 11.2 or 11.3, then (a) ETON shall have the right to,
and Aucta shall hereby grant ETON a license to, Market or otherwise dispose of any existing
inventory of any Products then in ETON's possession subject to paying all Royalties and other
amounts due hereunder for such sales, (b) Aucta may keep all the payments under Section 6 paid by
ETON up to the point of termination and for ETON's disposal of remaining inventory and Aucta is free
to commercialize or relicense the Product with no further obligations owed to ETON, (c) ETON shall
refrain from holding itself out as Aucta's distributor, in particular, eliminate any reference to
the Product and Aucta from its business, trade style and promotional material, and (d) ETON shall
transfer all rights, licenses within thirty (30) days of termination. 14

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 15 -->
CONFIDENTIAL 11.5.3 This Section 11.5 shall survive termination or expiration of this Agreement. 12.
REPRESENTATIONS AND WARRANTIES 12.1 ETON Representations and Warranties. ETON represents and
warrants to Aucta that: 12.1.1 it has the corporate power and authority to enter into this Agreement
and to consummate the transactions contemplated hereby; 12.1.2 neither the execution and delivery of
this Agreement by it, nor its performance hereunder, conflicts with or will result in any violation
or breach of, or constitutes (with or without due notice or lapse of time or both) a default under
any of the terms or conditions of any note, indenture, license, agreement or other instrument or
obligation to which it is a party or by which it or any of its properties or assets may be bound; or
to its best knowledge, violates any Applicable Law; 12.1.3 this Agreement is a legal, valid and
binding agreement of ETON, enforceable in accordance with its terms, subject to applicable
bankruptcy, insolvency, reorganization, moratorium, fraudulent transfer and other similar laws
affecting creditors' rights generally from time to time in effect and to general principles of
equity (including concepts of materiality, reasonableness, good faith and fair dealing), regardless
of whether considered in a proceeding in equity or at law; and 12.1.4 it has not been debarred, is
not subject to debarment, and will not use, in any capacity in connection with the obligations to be
performed under this Agreement, any person who has been debarred pursuant to Section 306 of the
United States Food, Drug and Cosmetic Act; 12.1.5 there is no Claim, suit, investigation, action or
proceeding pending or threatened against ETON before any court, governmental agency, or arbitration
panel which may in any way materially adversely affect the performance of its obligations hereunder
or transaction contemplated by this Agreement; 12.1.6 it has not and will not enter into any
contract or any other transaction with any Third Party or Affiliate that conflicts with or derogates
from its undertakings hereunder; 12.1.7 it has and will at all times during Term have requisite
expertise, experience, personnel, equipment and skill to perform its obligations hereunder; and
12.1.8 it has obtained or will maintain to the extent necessary for its performance of activities
with respect to the Products under this Agreement all required licenses, authorizations, and
approvals required by federal, state, or local governmental authorities, including the FDA and any
other applicable regulatory agency to the extent it is selling, supplying, manufacture, export and
supply each Product for the Territory and in accordance with this Agreement 15

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 16 -->
CONFIDENTIAL 12.1.9 it will not make nor will it promise to make any payment in violation of the U.
S. Foreign Corrupt Practices Act or similar applicable local, federal or national law. 12.2 Aucta
Representation and Warranties. Aucta represents and warrants to ETON that: 12.2.1 it has the
corporate power and authority to enter into this Agreement and to consummate the transactions
contemplated hereby; 12.2.2 neither the execution and delivery of this Agreement by it, nor its
performance hereunder, conflicts with or will result in any violation or breach of, or constitutes
(with or without due notice or lapse of time or both) a default under any of the terms or conditions
of any note, indenture, license, agreement or other instrument or obligation to which it is a Party
or by which it or any of its properties or assets may be bound; or to its best knowledge, violates
any Applicable Law; 12.2.3 this Agreement is a legal, valid and binding agreement of Aucta,
enforceable in accordance with its terms, subject to applicable bankruptcy, insolvency,
reorganization, moratorium, fraudulent transfer and other similar laws affecting creditors' rights
generally from time to time in effect and to general principles of equity (including concepts of
materiality, reasonableness, good faith and fair dealing), regardless of whether considered in a
proceeding in equity or at law; 12.2.4 it has not been debarred, is not subject to debarment, and
will not use, in any capacity in connection with the obligations to be performed under this
Agreement, any person who has been debarred pursuant to Section 306 of the United States Food, Drug
and Cosmetic Act; 12.2.5 there is no Claim, suit, investigation, action or proceeding pending or
threatened against Aucta before any court, governmental agency, or arbitration panel which may in
any way materially adversely affect the performance of its obligations hereunder or transaction
contemplated by this Agreement; 12.2.6 it will not divest, sell, fail to maintain or otherwise
dispose of any Dossier related to Products during the Term of this Agreement; 12.2.7 it has not and
will not enter into any contract or any other transaction with any Third Party or Affiliate that
conflicts with or derogates from its undertakings hereunder; 12.2.8 it has and will at all times
during Term have requisite expertise, experience, personnel, equipment and skill to perform its
obligations hereunder; 12.2.9 it has the unencumbered right to Products, Dossiers for the Products
and Aucta Background Intellectual Property and the right, power and authority to grant a license to
ETON hereunder; 16

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 17 -->
CONFIDENTIAL 12.2.10 it will not make nor will it promise to make any payment in violation of the U.
S. Foreign Corrupt Practices Act or similar applicable local, federal or national law; 12.2.11 it
has obtained and will maintain all required licenses, authorizations, and approvals required by
federal, state, or local governmental authorities, including the FDA and any other applicable
regulatory agency to manufacture, export and supply each Product for the Territory and in accordance
with this Agreement; 12.2.12 all Product supplied to ETON by Aucta or its contract manufacturer
shall: (i) meet the applicable Specifications at the time of shipment; (ii) meet regulatory
requirements of any relevant regulatory authority in the Territory and Territory of Manufacture;
(iii) be manufactured, packaged, tested, stored and shipped in accordance with applicable GMP, the
Dossier, Applicable Law and this Agreement; (iv) not be adulterated or misbranded under the U. S.
Food, Drug and Cosmetic Act or any other relevant laws and regulations as amended from time to time;
and (v) be produced, packaged, tested and stored in facilities that have been approved by applicable
regulatory authorities to the extent required by Applicable Laws; 12.2.13 Aucta has not been
informed of any proceeding or similar action pending or threatened in writing seeking the
revocation, suspension or amendment of any Dossiers for reasons related to safety or efficacy;
12.2.14 The FDA has not requested or demanded in writing that Aucta discontinue any Dossiers for
reasons related to safety or efficacy; 12.2.15 Aucta has not been informed of any pending or
threatened in writing product liability claims relating to any Product; and 12.2.16 Aucta has not
been informed of any pending or threatened in writing Claims alleging infringement of a Third
Party's intellectual property rights relating to any Dossiers or the use, manufacture, import,
distribution, sale or offer for sale of any Product. 12.3 Survival of Representations and
Warranties. Other than the representations of Sections 12.1.5, 12.2.13, 12.2.14, 12.2.15 and
12.2.16, which are made as of the date of execution of this Agreement, all representations and
warranties of ETON and Aucta contained herein or made pursuant hereto shall be ongoing during the
Term and for a period of twelve (12) months thereafter. In the event of any breach of the
representations and warranties set forth herein, the applicable Party shall immediately notify the
other Party of such breach. 13. INDEMNIFICATION 13.1 Aucta's Indemnification Obligations. Aucta
shall indemnify, defend and hold ETON and its owners, officers, directors, Affiliates, and employees
(collectively, "ETON Indemnified Parties") harmless from and against any and all Losses arising out
of or resulting from any Third Party Claims made or suits brought against ETON Indemnified Parties
which arise or result from (i) Aucta's material breach of any of its representations, warranties or
covenants set forth in this Agreement, or any of its obligations hereunder; (ii) Aucta's
manufacture, registration, handling, storage, use, transportation of any Product on or after the
Effective Date, including, without limitation, any Claim for personal injury or death, to the extent
such Third Party Claims arise from the period of time commencing on or after the Effective Date and
to the extent such is not attributable to ETON's breach of this Agreement or any Applicable Laws; or
(iii) Aucta's negligence or willful misconduct with regard to the Products to the extent such is not
attributable to ETON's breach of this Agreement or any Applicable Laws. 17

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 18 -->
CONFIDENTIAL 13.2 ETON's Indemnification Obligations. ETON shall indemnify, defend and hold Aucta
and its officers, directors, and employees (collectively, "Aucta Indemnified Parties") harmless from
and against any and all Losses arising out of or resulting from any Third Party Claims made or suits
brought against Aucta Indemnified Parties which arise or result from (i) ETON's material breach of
any of its representations, warranties or covenants set forth in this Agreement, or any of its
obligations hereunder; (ii) ETON's marketing, distribution, or sale of any Product on or after the
Effective Date, including, without limitation, any Claim for personal injury or death, to the extent
such Third Party Claims arise from the period time commencing on or after the Effective Date and to
the extent such is not attributable to Aucta's breach of this Agreement or any Applicable Law; or
(iii) ETON's negligence or willful misconduct with regard to the Products to the extent such is not
attributable to Aucta's breach of this Agreement or any Applicable Laws. 13.3 Indemnification
Procedure. 13.3.1 Notice of the matter which may give rise to such Claim shall be given in writing
by the indemnitee (the "Indemnitee") to the Party against whom indemnification may be sought (the
"Indemnitor") as soon as reasonably practicable after such Indemnitee becomes aware of such Claim;
provided, however, that the failure to notify the Indemnitor shall not relieve it from any liability
that it may have to the Indemnitee otherwise unless the Indemnitor demonstrates that the defense of
the underlying Claim has been materially prejudiced by such failure to provide timely notice. Such
notice shall request indemnification and describe the potential Losses and Claim giving rise to the
request for indemnification, and provide, to the extent known and in reasonable detail, relevant
details thereof. If the Indemnitor fails to give Indemnitee notice of its intention to defend any
such Claim as provided in this Section 13.3.1. the Indemnitee involved shall have the right to
assume the defense thereof with counsel of its choice, at the Indemnitor's expense, and defend,
settle or otherwise dispose of such Claim with the consent of the Indemnitor, not to be unreasonably
withheld or delayed. 13.3.2 In the event the Indemnitor elects to assume the defense of a Claim, the
Indemnitee of the Claim in question and any successor thereto shall permit Indemnitor's counsel and
independent auditors, to the extent relevant, reasonable access to its books and records and
otherwise fully cooperate with the Indemnitor in connection with such Claim; provided, however, that
(i) the Indemnitee shall have the right fully to participate in such defense at its own expense;
(ii) the Indemnitor's counsel and independent auditors shall not disclose any Confidential
Information of the Indemnitee to the Indemnitor without the Indemnitee's consent; (iii) access shall
only be given to the books and records that are relevant to the Claim or Losses at issue. The
defense by the Indemnitor of any such actions shall not be deemed a waiver by the Indemnitee of its
right to assert a Claim with respect to the responsibility of the Indemnitor with respect to the
Claim or Losses in question. The Indemnitor shall not have the right to settle or compromise any
Claim against the Indemnitee (that the Indemnitor has defended pursuant to this Section 13.3.2)
without the consent of the Indemnitee which shall not be unreasonably withheld or delayed. No
Indemnitee shall pay or voluntarily permit the determination of any Losses which is subject to any
such Claim while the Indemnitor is negotiating the settlement thereof or contesting the matter,
except with the prior written consent of the Indemnitor, which consent shall not be unreasonably
withheld or delayed. 18

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 19 -->
CONFIDENTIAL 13.3.3 This Section 13 shall survive termination or expiration of this Agreement. 14.
LIMITATION OF LIABILITY 14.1 NOTWITHSTANDING ANYTHING TO THE CONTRARY HEREIN, NEITHER PARTY SHALL BE
LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL OR EXEMPLARY DAMAGES, WHETHER
FORESEEABLE OR NOT, THAT ARE IN ANY WAY RELATED TO THIS AGREEMENT. 15. MISCELLANEOUS 15.1 Governing
Law; English Language. This Agreement shall be governed, interpreted and construed in accordance
with the substantive laws of the Delaware, in the country of the United State of America, without
regard to its conflict of laws principles. To the extent that it may otherwise by applicable, the
Parties hereby expressly agree to unconditionally waive and exclude from the operation of this
Agreement the United Nations Convention on Contracts for the International Sale of Goods, concluded
at Vienna, on 11 April 1980, as amended and as may be amended further from time to time. This
Agreement has been negotiated and drafted by the Parties in the English language. Any translation
into any other language shall not be an official version thereof. In the event any translation of
this Agreement is prepared for convenience or for any other purpose, the provisions of the English
version shall prevail. 15.2 Force Majeure. Neither Party shall be liable for non-performance or
delay in the fulfillment of its obligations when any such non- performance or delay shall be
occasioned by any unforeseeable cause beyond the reasonable control of Aucta or ETON, as the case
may be, including without limitation, acts of God, fire, flood, earthquakes, explosions, sabotage,
strikes or labor disturbances, civil commotion, riots, military invasions, war, terrorism, failure
of utilities, failure of carriers, or any acts, restraints, requisitions, tariffs, regulations, or
directives issues by a Governmental Entity ("Force Majeure Events"). In the event either Party is
prevented from discharging its obligations hereunder on account of a Force Majeure Event, such Party
shall notify the other forthwith and shall nevertheless make every endeavor in good faith to
discharge its said obligations even if in a partial or compromised manner. If either Party is unable
to perform its obligations hereunder as a result of a Force Majeure Event for a period of thirty
(30) days or greater, then the other Party shall have the right, following sixty (60) days' notice
to the other Party to terminate the Agreement if the Force Majeure Event still exists following such
sixty (60) day notice period. In the event Force Majeure Event impacts the manufacture or supply of
Products, the annual minimums required under 6.3.2 shall be suspended for the period of the Force
Majeure and the annual minimum adjusted to prorate the annual minimum to account for the period of
Force Majeure suspension (e.g. one month Force Majeure reduces annual minimum by 1/12). 19

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 20 -->
CONFIDENTIAL 15.3 Notices. All notices and other communications required or permitted to be given or
made pursuant to this Agreement shall be in writing signed by the sender and shall be deemed duly
given (a) on the date delivered, if personally delivered, (b) on the date sent by telecopier with
automatic confirmation by the transmitting machine showing the proper number of pages were
transmitted without error, (c) on the Business Day after being sent by Federal Express or another
recognized overnight mail service which utilizes a written form of receipt for next day or next
Business Day delivery or (d) three (3) Business Days after mailing, if mailed by U.S.
postage-prepaid certified or registered mail, return receipt requested, in each case addressed to
the applicable Party at the address set forth below; provided that a Party may change its address
for receiving notice by the proper giving of notice hereunder: If to ETON, to: ETON Pharmaceuticals,
Inc. 21925 W. Field Pkwy, Suite 235 Deer Park, Illinois, USA Attention: CEO With a copy (which shall
not constitute notice) to: ETON Pharmaceuticals, Inc. 21925 W. Field Pkwy, Suite 235 Deer Park,
Illinois, USA Attention: Legal if to Aucta, to: Aucta Pharmaceuticals, Inc. 71 Suttons Lane
Piscataway, NJ 08854 Attention: CEO 15.4 Relationship of Parties. The status of the Parties under
this Agreement shall be that of independent contractors, without the authority to act on behalf of
or bind each other. Nothing in this Agreement shall be construed as establishing a partnership or
joint venture relationship between the Parties hereto. No Party shall have the right to enter into
any agreements on behalf of the other Party, nor shall it represent to any person that it has such
right or authority. All persons employed by a Party shall be employees of such Party and not of the
other Party and all costs and obligations incurred by reason of any such employment shall be for the
account and expense of such Party. 20

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 21 -->
CONFIDENTIAL 15.5 Entire Agreement; Amendment. This Agreement (and all Exhibits attached hereto)
supersedes all prior discussions and agreements among the Parties with respect to the subject matter
hereof and contains the sole and entire agreement among the Parties hereto with respect to the
subject matter hereof. This Agreement may not be amended or modified except in writing executed by
the duly authorized representatives of the Parties. 15.6 No Third-Party Beneficiaries. This
Agreement is not intended to confer upon any Person other than the Parties hereto any rights or
remedies hereunder. 15.7 Severability. Should any part or provision of this Agreement be held
unenforceable or in conflict with Applicable Law, the invalid or unenforceable part or provision
shall, provided that it does not affect the essence of this Agreement, be replaced with a revision
which accomplishes, to the greatest extent possible, the original commercial purpose of such part or
provision in a valid and enforceable manner, and the balance of this Agreement shall remain in full
force and effect and binding upon the Parties hereto. 15.8 Assignment. The terms and provisions
hereof shall inure to the benefit of, and be binding upon the Parties and their respective
successors and permitted assigns. The Parties shall not assign, encumber or otherwise transfer this
Agreement or any part of it to any Third Party, without the prior written consent of the other
Party. Notwithstanding the foregoing, each Party may assign the rights and obligations under this
Agreement in whole, without consent of the other Party, to a Third Party or Affiliate in connection
with the transfer or sale of all or substantially all of its business or in the event of a merger,
consolidation or change in control provided that the assignee assumes in writing and becomes
directly obligated to the other Party to perform all of the obligations of assignor under this
Agreement. 15.9 Waiver. No waiver of a breach or default hereunder shall be considered valid unless
in writing and signed by the Party giving such waiver, and no such waiver shall be deemed a waiver
of any subsequent breach or default of the same or similar nature. 15.10 Survival. Any provision
which by its terms is intended to survive the termination or expiration of this Agreement will
survive the termination or expiration of this Agreement and remain in full force and effect
thereafter. 15.11 Counterparts; PDF. This Agreement may be executed in two (2) or more counterparts,
each of which shall be deemed an original but all of which, taken together, shall constitute one and
the same instrument. PDF and facsimile signatures shall constitute original signatures. The Parties
agree that the electronic signatures appearing on this Agreement are the same as handwritten
signatures for the purposes of validity, enforceability and admissibility pursuant to the Electronic
Signatures in Global and National Commerce (ESIGN) Act of 2000, and Uniform Electronic Transactions
Act (UETA) model law, or similar applicable laws. [SIGNATURE PAGE FOLLOWS] 21

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 22 -->
CONFIDENTIAL IN WITNESS WHEREOF, the Parties hereto have executed this Agreement as of the date
first above written, to be effective upon the Effective Date. ETON PHARMACEUTICALS, INC. By: Name:
Title: AUCTA PHARMACEUTICALS, INC. By: Name: Title:

Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
<!-- page 23 -->
Source: ETON PHARMACEUTICALS, INC., 10-Q, 11/14/2019
