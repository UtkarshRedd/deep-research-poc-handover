<!-- page 1 -->
# Cooperation Agreement
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2020-07-01 |
| Parties | e.l.f. Beauty, Inc. ("Company", "Party"); Marathon Partners Equity Management, LLC ("Marathon Partners", "Party", collectively with Marathon Partners L.P., Marathon Focus Fund L.P., Marathon Partners LUX Fund, L.P., Cibelli Research & Management, LLC, and Mario Cibelli, the "Marathon Parties"); Marathon Partners L.P. ("Party", collectively with Marathon Partners Equity Management, LLC, Marathon Focus Fund L.P.,Marathon Partners LUX Fund, L.P., Cibelli Research & Management, LLC, and Mario Cibelli, the "Marathon Parties"); Marathon Focus Fund L.P. ("Party", collectively with Marathon Partners Equity Management, LLC, Marathon Partners L.P., Marathon Partners LUX Fund, L.P., Cibelli Research & Management, LLC, and Mario Cibelli, the "Marathon Parties"); Marathon Partners LUX Fund, L.P. ("Party", collectively with Marathon Partners Equity Management, LLC, Marathon Partners L.P., Marathon Focus Fund L.P., Cibelli Research & Management, LLC, and Mario Cibelli, the "Marathon Parties"); Cibelli Research & Management, LLC ("Party", collectively with Marathon Partners Equity Management, LLC, Marathon Partners L.P., Marathon Focus Fund L.P., Marathon Partners LUX Fund, L.P., and Mario Cibelli, the "Marathon Parties"); Mario Cibelli ("Party", collectively with Marathon Partners Equity Management, LLC, Marathon Partners L.P., Marathon Focus Fund L.P., Marathon Partners LUX Fund, L.P., and Cibelli Research & Management, LLC, the "Marathon Parties") |
| Source | CUAD v1 / ELFBEAUTY,INC_07_02_2020-EX-10.1-COOPERATION AGREEMENT |

Exhibit 10.1

COOPERATION AGREEMENT

This Cooperation Agreement ("Agreement") is entered into as of July 1, 2020, by and between e.l.f.
Beauty, Inc., a Delaware corporation (the "Company"), and Marathon Partners Equity Management, LLC
("Marathon Partners"), Marathon Partners L.P., Marathon Focus Fund L.P., Marathon Partners LUX Fund,
L.P., Cibelli Research & Management, LLC and Mario Cibelli (collectively, the "Marathon Parties")
(each of the Company, on the one hand, and the Marathon Parties, on the other hand, a "Party" to
this Agreement, and collectively, the "Parties").

RECITALS

WHEREAS, the Marathon Parties have voting power or sole dispositive power or otherwise have
beneficial ownership of 2,585,000 shares of the common stock, par value $0.01 per share, of the
Company (the "Common Stock") as of the date of this Agreement;

WHEREAS, Marathon Partners submitted a letter to the Company on May 28, 2020 (the "Nomination
Notice") nominating a slate of director candidates to be elected to the Board of Directors of the
Company (the "Board") at the Company's 2020 Annual Meeting of Shareholders (the "2020 Annual
Meeting"); and

WHEREAS, as of the date of this Agreement, the Company and the Marathon Parties have determined to
come to an agreement with respect to certain matters set forth below.

NOW, THEREFORE, in consideration of the foregoing premises and the mutual covenants and agreements
contained herein, and for other good and valuable consideration, the receipt and sufficiency of
which are acknowledged, the Parties to this Agreement, intending to be legally bound, agree as
follows:

1. Board Nomination; Certain Information; Other Board and Company Actions.

(a) Lori Keith (the "New Director") has provided the Company with (i) fully completed and executed
copies of the Company's standard director & officer questionnaire, representation and agreement
letter, and other reasonable and customary director onboarding documentation, including (A) all
information reasonably requested by the Company that is required to be disclosed for directors,
candidates for directors, and their affiliates and representatives in a proxy statement or other
filings under applicable law or regulation or stock exchange rules or listing standards, in each
case, relating to their appointment, nomination or election as a director of the Company and (B)
information reasonably requested by the Company in connection with assessing eligibility,
independence and other criteria applicable to directors or satisfying compliance and legal or
regulatory obligations, in each case, relating to their appointment, nomination or election as a
director of the Company and required by the Company in connection with the appointment or election
of new members of the Board, (ii) an executed consent of the New Director to be named in any proxy
statement or other filings under applicable law or stock exchange rules or listing standards and to
serve as a Class III Director and (iii) a written representation that the New Director, if elected
as a director of the Company, would be in compliance, and will comply with, all applicable
confidentiality, corporate governance, conflict of interest, Regulation FD, code of conduct and
ethics, stock ownership and trading policies and guidelines, and other policies of the Company
applicable to members of the Board (collectively, the "Information"), and has cooperated with a
background check.

(b) Based on the Information, the Nominating and Corporate Governance Committee (the "Nominating
Committee") of the Board and the Board have determined that the New Director may serve as an
"independent" director of the Company in accordance with the rules and listing standards of the New
York Stock Exchange ("NYSE") and applicable rules and regulations of the U.S. Securities and
Exchange Commission (the "SEC").

(c) As promptly as practicable, but in no event later than two business days following the execution
of this Agreement, the Nominating Committee and the Board shall take all necessary action to (i)
increase the size of the Board from eight to nine directors, with such new Board seat to be in Class
III, (ii) appoint the New Director as a Class III director on the Board and (iii) appoint the New
Director to the Nominating Committee.
<!-- page 2 -->
(d) Immediately following the execution of this Agreement by the Parties, the Marathon Parties shall
send a letter to the Secretary of the Company irrevocably withdrawing (i) the Nomination Notice,
and, accordingly, (ii) their nomination of Mario Cibelli, Dhiren Fonseca and Beth Birnbaum (the
"Nominations") for election to the Board as Class I directors at the 2020 Annual Meeting and (iii)
the Marathon Parties' demand letter pursuant to Section 220 of the Delaware General Corporation Law,
dated April 12, 2019.

(e) The Board shall take all necessary action to include in the proposals to be voted on at the 2020
Annual Meeting (i) a "say-on-pay" proposal of the Company and (ii) a vote as to the frequency at
which "say-on-pay" proposals will be presented to and voted on by the stockholders at future annual
meetings of the Company, which shall include a recommendation by the Board that stockholders vote
"FOR" annual "say-on-pay" proposals.

(f) The Board shall take all necessary action to amend Section 3.1(a) of the 2016 Equity Incentive
Award Plan of the Company (the "2016 Incentive Plan") to reduce the maximum automatic annual
percentage increase of shares of Common Stock reserved for issuance under the 2016 Incentive Plan
from 4% to 2%. During the Support Period (as defined below), the Board shall not (i) adopt a new
equity incentive award plan or otherwise seek to amend the 2016 Incentive Plan to increase the Share
Limit (as defined in the 2016 Incentive Plan) or (ii) issue Awards (as defined in the 2016 Incentive
Plan) in excess of the Share Limit (as defined in the 2016 Incentive Plan).

(g) The New Director (or any Replacement (as defined below)), in addition to all current directors,
will (A) comply with all policies, procedures, codes, rules, standards and guidelines applicable to
members of the Board and (B) keep confidential all Company confidential information and not disclose
to any third parties (including the Marathon Parties) discussions or matters considered in meetings
of the Board or Board committees.

(h) Annual grants of equity awards to executive officers of the Company in 2021 will take place
during the open trading window following the Company's fourth quarter earnings call in 2021. The
proxy statement for the 2020 Annual Meeting shall include language describing the obligation of the
Company set forth in this Section 1(h).

(i) Nothing in this Agreement shall be deemed to abridge or limit the fiduciary duties of any member
of the Board under Delaware law.

(j) The New Director (or any Replacement (as defined below)) may attend as a non-voting observer any
meeting(s) of the Compensation Committee of the Board (the "Compensation Committee") held following
the date of this Agreement and during the Support Period, and shall receive a copy of any materials
disseminated to Compensation Committee members in connection with such meeting(s).

2. Representations of the Marathon Parties. The Marathon Parties represent and warrant to the
Company as of the date hereof as follows:

(a) The Marathon Parties are the beneficial owners of 2,585,000 shares of Common Stock, such shares
of Common Stock constitute all of the Common Stock beneficially owned by the Marathon Parties, and
(i) the Marathon Parties' interests in the Common Stock and debt or other securities of the Company
is as set forth on Exhibit A, (ii) except as set forth on Exhibit A, the Marathon Parties do not
currently have, and do not currently have any right to acquire, any interest in any other securities
of the Company (or any rights, options or other securities convertible into or exercisable or
exchangeable (whether or not convertible, exercisable or exchangeable immediately or only after the
passage of time or the occurrence of a specified event) for such securities or any obligations
measured by the price or value of any securities of the Company or any of its controlled Affiliates,
including any swaps, puts, calls, appreciation rights or other derivative arrangements designed to
produce economic benefits and risks that correspond to the ownership of Common Stock, whether or not
any of the foregoing would give rise to beneficial ownership, and whether or not to be settled by
delivery of Common Stock, payment of cash or by other consideration, and without regard to any short
position under any such contract or arrangement) (collectively, "Securities of the Company") and
(iii) the Marathon Parties will not, directly or indirectly, compensate or agree to compensate the
New Director for her service as a director of the Company with any cash, securities (including any
rights or options convertible into or exercisable for or exchangeable into securities or any profit
sharing agreement or arrangement), or other form of compensation. The terms

2
<!-- page 3 -->
"beneficially owns" and "beneficial ownership" for all purposes under this Agreement shall have the
meanings set forth in Rule 13d-3 promulgated by the SEC under the Securities Exchange Act of 1934,
as amended (the "Exchange Act"). As used in this Agreement, the terms "Affiliate" and "Associate"
shall have the respective meanings set forth in Rule 12b-2 promulgated by the SEC under the Exchange
Act.

(b) The Marathon Parties have no agreements, understandings or undertakings with any third party to
share or delegate disposition or voting control over any of the securities set forth on Exhibit A,
or to transfer, hypothecate or lend any of the securities set forth on Exhibit A.

(c) Each of the Marathon Parties represents and warrants to the Company as of the date hereof that
it has the power and authority to execute and deliver this Agreement. This Agreement (i) has been
duly and validly authorized by each of the Marathon Parties, and constitutes a legal, valid and
binding obligation of each of the Marathon Parties, enforceable against each of the Marathon Parties
in accordance with its terms except as may be limited by bankruptcy, insolvency or similar laws
affecting creditors' rights and general equitable principles, (ii) does not require the approval of
any investor in or member of the Marathon Parties and (iii) does not violate any law, order of any
court or any governmental agency or regulation or the charter or any organizational document of the
Marathon Parties, or conflict with, result in a breach of or constitute a default under any
agreement or instrument by which the Marathon Parties or any of their respective assets is bound.

3. Representations of the Company. The Company represents and warrants to the Marathon Parties as of
the date hereof that it has the corporate power and authority to execute and deliver this Agreement.
This Agreement (i) has been duly and validly authorized by the Company and constitutes a legal,
valid and binding obligation of the Company, enforceable against the Company in accordance with its
terms except as may be limited by bankruptcy, insolvency or similar laws affecting creditors' rights
and general equitable principles and (ii) does not violate any law, order of any court or any agency
or regulation or the Company's Certificate of Incorporation or the Amended and Restated Bylaws of
the Company (the "Bylaws"), or conflict with, result in a breach of or constitute a default under
any agreement or instrument by which the Company or any of its assets or the assets of its
subsidiaries are bound. The Company further represents and warrants to the Marathon Parties as of
the date hereof that since March 2, 2019 it has not granted any performance equity awards to any
named executive officers other than those disclosed or referenced by the Company in its Forms 4
filed with the SEC in June 2020.

4. Support Period Covenants.

(a) During the period commencing on the date hereof and ending at 11:59 pm New York Time on the date
that is thirty (30) days prior to expiration of the advance notice period for the submission by
stockholders of director nominations for consideration at the Company's 2021 Annual Meeting of
Stockholders (the "2021 Annual Meeting") as determined by applicable law and set forth in the Bylaws
(such period, as modified, if applicable, in Section 4(b) below, the "Support Period"), the Marathon
Parties shall appear in person or by proxy for quorum purposes at the 2020 Annual Meeting and any
other meeting of stockholders of the Company, including any adjournment or postponement thereof, to
vote all of the shares of Common Stock beneficially owned by the Marathon Parties on the record date
for such meeting (i) in favor of all persons nominated by the Board to serve as directors of the
Company and against any stockholder nominated candidate not endorsed by the Board, (ii) to ratify
the appointment of the Company's independent registered public accounting firm, (iii) in accordance
with the Board's recommendation with respect to the Company's "say-on-pay" proposal and compensation
plans and any amendments thereto and (iv) in favor of any other proposals recommended by the Board,
provided, that with respect to any extraordinary matter, including any merger, acquisition,
recapitalization, restructuring, financing, disposition, distribution, spin-off, asset sale, joint
venture or other business combination involving the Company or its subsidiaries which requires a
vote of the Company's stockholders, the Marathon Parties shall have the right to vote the shares of
Common Stock beneficially owned by the Marathon Parties in their sole discretion. The Marathon
Parties shall provide written evidence of such vote to the Company no later than ten (10) business
days prior to the 2020 Annual Meeting.

(b) Notwithstanding the foregoing, if either:

3
<!-- page 4 -->
(i) at any time between the date of this Agreement and the date that is thirty (30) days prior to
the expiration of the advance notice period for the submission by stockholders of director
nominations for consideration at the 2021 Annual Meeting as determined by applicable law and set
forth in the Bylaws (such date, the "2021 Annual Meeting Nomination Window Date"), the Marathon
Parties do not meet the Minimum Ownership Threshold (as defined below), or

(ii) as of the 2021 Annual Meeting Nomination Window Date, all of the following conditions have been
met:

a. if the New Director or her Replacement is a director on the Board as of the 2021 Annual Meeting
Nomination Window Date, the New Director or her Replacement (as applicable) is a member of the
Nominating Committee as of such date,

b. between the date of this Agreement and the 2021 Annual Meeting Nomination Window Date, Tarang
Amin has not entered into a voting agreement or similar agreement that would subject any Securities
of the Company beneficially owned by Mr. Amin to any arrangement or agreement with respect to the
voting thereof with any other person that is a holder of any Securities of the Company and that is
not affiliated with Mr. Amin or his estate planning, or that would give Mr. Amin the power to vote
or direct the voting of any Securities of the Company beneficially owned by any other person that is
not affiliated with Mr. Amin or his estate planning,

c. between the date of this Agreement and the 2021 Annual Meeting Nomination Window Date, the
Company has not issued shares of Common Stock (and/or Securities of the Company convertible into, or
exercisable for, shares of Common Stock) in any transaction that represents more than 20% of the
issued and outstanding shares of Common Stock (including any Securities of the Company convertible
into, or exercisable for, shares of Common Stock) immediately prior to such issuance,

d. the Company has confirmed that the proxy statement for the 2021 Annual Meeting shall include
language describing the obligation of the Company set forth in Section 1(h) above as relates to
annual grants of equity awards to executive officers of the Company in 2022, and

e. the Company has confirmed that any director(s) or officer(s) of the Company who beneficially
owned 3% or more of the issued and outstanding shares of Common Stock as of the record date for the
2020 Annual Meeting voted all such shares at the 2020 Annual Meeting in favor of annual "say-on-pay"
proposal frequency at future annual meetings of the Company,

then, for all purposes under this Agreement, the Support Period shall not expire on the 2021 Annual
Meeting Nomination Window Date, and instead the Support Period shall automatically be extended until
11:59 pm New York Time on the date that is thirty (30) days prior to expiration of the advance
notice period for the submission by stockholders of director nominations for consideration at the
Company's 2022 Annual Meeting of Stockholders as determined by applicable law and set forth in the
Bylaws for all purposes under this Agreement, and the Marathon Parties shall be required to (x)
appear in person or by proxy at the 2021 Annual Meeting or any other meeting of stockholders of the
Company held on or after the 2021 Annual Meeting Nomination Window Date and prior to the end of the
Support Period, (y) vote any of the shares of Common Stock beneficially owned by the Marathon
Parties in accordance with Section 4(a)(i), (ii), (iii) and (iv) at any meeting of stockholders of
the Company held on or after the 2021 Annual Meeting Nomination Window Date and prior to the end of
the Support Period, provided, however, that in the event that Institutional Shareholder Services
Inc. ("ISS") recommends otherwise with respect to the Company's "say-on-pay" proposal or any
proposal relating to any compensation plan submitted for shareholder approval at the 2021 Annual
Meeting, including any amendments thereto, each of the Marathon Parties will be permitted to vote in
accordance with the ISS

4
<!-- page 5 -->
recommendation in its discretion, and (z) provide written evidence of such vote by the Marathon
Parties at any meeting of stockholders of the Company held on or after the 2021 Annual Meeting
Nomination Window Date and prior to the end of the Support Period (including the 2021 Annual
Meeting) no later than ten (10) business days prior to any such meeting (including the 2021 Annual
Meeting). As used herein, the "Minimum Ownership Threshold" shall mean beneficial ownership equal to
or greater than 2.0% of the issued and outstanding shares of Common Stock. The Marathon Parties
shall provide notice to the Company within two business days following the date on which the
Marathon Parties no longer meet the Minimum Ownership Threshold.

(c) If at any time during the Support Period (x) the New Director is unable to serve out her term as
a Class III Director on the Board for any reason, and (y) as of such time, the Marathon Parties have
maintained since the date of this Agreement the Minimum Ownership Threshold and the Marathon Parties
have provided evidence of such ownership, together with a certification of such ownership, to the
Company, then the Marathon Parties and the Company shall negotiate in good faith to propose a
mutually-agreed upon replacement director (the "Replacement") to be appointed to the Board to serve
as her successor for the remainder of her current term as a Class III Director in accordance with
the Bylaws, provided such Replacement (i) qualifies as "independent" pursuant to the rules and
listing standards of the NYSE and applicable SEC rules and regulations, (ii) has provided the
Company with the Information, (iii) has cooperated with a background check and (iv) has executed all
documents required to be executed by directors of the Company. The Replacement shall be promptly
appointed to the Board and at least one standing committee of the Board, subject to the approval by
each of the Nominating Committee and the Board, after conducting a good faith customary due
diligence process and consistent with the Board's fiduciary duties.

5. Standstill Covenants.

(a) Except as otherwise contemplated in Section 4 of this Agreement, at all times during the Support
Period, the Marathon Parties shall not, and shall cause their Affiliates and Associates and their
and such Affiliates' and Associates' respective equity owners (including members and limited
partners), directors, officers, managers and employees not to, and will direct their consultants,
agents, representatives, attorneys and advisors (to the extent directly or indirectly acting on
behalf of the Marathon Parties) (collectively, the "Marathon Party Representatives") not to,
directly or indirectly, in any manner, alone or in concert with others:

(i) make, engage, solicit, or in any way participate in any "solicitation" of proxies (as such term
under the Exchange Act) or consents to vote, or knowingly advise, encourage or influence any person
or entity with respect to the voting of any Securities of the Company or become a "participant" in
any contested "solicitation" for the election of directors with respect to the Company (as such
terms are defined or used under the Exchange Act) (other than a "solicitation" or acting as a
"participant" in support of all of the nominees recommended by the Board at any stockholder
meeting);

(ii) propose or otherwise solicit stockholders of the Company for the approval of one or more
stockholder proposals (whether made pursuant to Rule 14a-8 under the Exchange Act or otherwise) or
call, attempt to call or solicit consents to call a special meeting of stockholders of the Company;

(iii) agree or propose to grant any proxies with respect to, or deposit any Securities of the
Company in a voting trust or similar arrangement or subject any Securities of the Company to any
arrangement or agreement with respect to the voting thereof, except as expressly set forth in
Section 4 of this Agreement;

(iv) take any action to form, join, encourage, influence or in any way participate in any
partnership, limited partnership, syndicate or other group (as such term is contemplated in Rule
13d-5 promulgated under the Exchange Act) with respect to the Securities of the Company (other than
a group formed with an Affiliate of the Marathon Parties) or otherwise act in concert with any
person or entity for the purpose of circumventing the provisions or purposes of this Agreement;

(v) purchase or otherwise acquire, or offer, seek, propose or agree to acquire, ownership (including
beneficial ownership) of the Securities of the Company, any direct or indirect rights or options to

5
<!-- page 6 -->
acquire any such Securities of the Company, any derivative securities or contracts or instruments in
any way related to the price of shares or value of Common Stock, any other securities of the
Company, or any assets or liabilities of the Company, provided that the Marathon Parties and their
Affiliates, in the aggregate, may acquire beneficial ownership of up to 12.5% of the Company's
outstanding shares of Common Stock;

(vi) other than in open-market transactions where the identity of the purchaser is not known and in
underwritten widely dispersed public offerings, sell, offer or agree to sell, directly or
indirectly, through swap or hedging transactions or otherwise, the Securities of the Company or any
rights decoupled from the underlying Securities of the Company held by the Marathon Parties or any
of their Affiliates or Associates to any person or entity not (A) a party to this Agreement, (B) a
member of the Board or (C) an officer of the Company (any person or entity not set forth in clauses
(A)-(C) shall be referred to as a "Third Party"), that would knowingly result in such Third Party,
together with its Affiliates and Associates, owning, controlling or otherwise having any beneficial
or other ownership interest in the aggregate of more than 4.9% of the shares of Common Stock
outstanding at such time, other than Schedule 13G filers that are mutual funds, pension funds, index
funds or investment fund managers with no known history of activism or known plans to engage in
activism, except in a transaction approved in advance by the Board;

(vii) effect or seek to effect, offer or propose to effect, cause or participate in, or knowingly
assist or facilitate any other person or entity to effect or seek, offer or propose to effect or
participate in, any tender or exchange offer, merger, consolidation, division, acquisition, scheme,
arrangement, business combination, recapitalization, reorganization, sale or acquisition of material
assets, liquidation, dissolution or other extraordinary transaction involving the Company or any of
its subsidiaries or joint ventures or any of their respective securities (each, an "Extraordinary
Transaction"), or make any public statement with respect to an Extraordinary Transaction; provided,
however, that nothing in this Agreement shall prevent the Marathon Parties from making a public
statement about how they intend to vote and the reasons therefor with respect to any Extraordinary
Transaction to which any executive officer or director of the Company is a party (other than
customary support agreements) and that requires a vote of the Company's stockholders; provided
further, that this clause shall not preclude the tender by the Marathon Parties or any of their
Affiliates or Associates of any Securities of the Company into any tender or exchange offer which
has been approved and recommended to stockholders of the Company by the Board;

(viii) (A) seek or solicit support for (whether publicly or privately) any written consent of
stockholders of the Company, (B) seek representation on, or nominate any candidate to, the Board,
except as set forth in Section 1 of this Agreement, (C) seek the removal of any member of the Board,
(D) conduct a referendum of stockholders, (E) institute any litigation against the Company, its
directors or its officers other than to (1) enforce the provisions of this Agreement and (2) make
counterclaims with respect to any proceeding initiated by, or on behalf of, the Company against the
Marathon Parties, or (F) make a request for any stockholder list or other Company books and records,
whether pursuant to Section 220 of the Delaware General Corporation Law or otherwise;

(ix) knowingly encourage, advise or influence any other person or assist any Third Party in so
encouraging, assisting or influencing any person or entity with respect to the giving or withholding
of any proxy vote at the 2020 Annual Meeting or the 2021 Annual Meeting (including any "vote no" or
"withhold vote" or similar campaign);

(x) take any action in support of or make any proposal or request that constitutes: (A) advising,
controlling, changing or influencing the Board or management of the Company, including any plans or
proposals to change the number or term of directors or to fill any vacancies on the Board or
unfilled newly-created directorships; (B) any material change in the capitalization, stock
repurchase programs and practices or dividend policy of the Company; (C) any other material change
in the Company's management, business or corporate structure, including, without limitation, its
capital allocation, expense structure, business operations or strategies or its management or other
personnel; (D) seeking to have the Company waive or make amendments or modifications to the
Company's Certificate of Incorporation or the Bylaws, or other actions that may impede or facilitate
the acquisition of control of the Company by any person or entity;

6
<!-- page 7 -->
(E) causing a class of Securities of the Company to be delisted from, or to cease to be authorized
to be quoted on, any securities exchange; or (F) causing a class of Securities of the Company to
become eligible for termination of registration pursuant to Section 12(g)(4) of the Exchange Act;

(xi) otherwise act in concert with any person or entity to seek to control or direct the management,
Board (or any individual members thereof), stockholders or policies of the Company;

(xii) take any action that would require the Marathon Parties or any of their Affiliates or
Associates to file a statement of beneficial ownership report on Schedule 13D or any amendment
thereto with the SEC, other than solely as a result of the purchase or sale by the Marathon Parties
of Securities of the Company set forth on Exhibit A;

(xiii) make any public disclosure, announcement or statement regarding any intent, purpose, plan or
proposal with respect to the Board, the Company, its management, policies or affairs, any Securities
of the Company or assets of the Company or this Agreement;

(xiv) enter into substantive discussions, negotiations, agreements or understandings with any Third
Party with respect to the foregoing, or solicit, assist, prompt, induce or attempt to induce any
Third Party to take any action or make any statement with respect to any of the foregoing, or
otherwise take or cause any action or make any statement inconsistent with any of the foregoing; or

(xv) request, directly or indirectly, any amendment or waiver of this Section 5(a).

(b) Notwithstanding anything contained in this Agreement to the contrary:

(i) Nothing in this Section 5(a) shall prohibit or restrict the Marathon Parties from taking any
action necessary to comply with any law, rule or regulation or any action required by any
governmental or regulatory authority or stock exchange that has jurisdiction over the Marathon
Parties or any of their Affiliates or Associates. The provisions of this Section 5(a) shall also not
prevent the Marathon Parties from freely voting their Shares (except as otherwise provided in this
Agreement) or taking any actions except as specifically contemplated in this Agreement.

(ii) The Marathon Parties shall be responsible for any breach of this Section 5(a) by any of their
Affiliates or Associates or any Marathon Party Representatives.

6. Mutual Non-Disparagement; No Public Statements.

(a) Subject to applicable law, the Company, on the one hand, and each of the Marathon Parties on the
other hand, covenants and agrees that, during the Support Period or if earlier, until such time as
the other Party or any of its or her officers, directors, employees, subsidiaries, Affiliates,
Associates, agents, attorneys or other representatives (collectively, the "Representatives") shall
have breached this section, neither it nor any of its respective Representatives acting, directly or
indirectly, at its direction or on its behalf, shall in any way publicly (including by any
communication with other investors or prospective investors in the Company where such communications
could reasonably be expected to be made public or trigger a public disclosure obligation, with
securities analysts or any member of traditional or digital media) criticize, disparage, call into
disrepute or otherwise defame or slander the other Party or such other Party's Representatives
(including any current officer or director of a Party or a Party's subsidiaries who no longer serves
in such capacity at any time following the execution of this Agreement), or any of their businesses,
products or services, in any manner that would reasonably be expected to damage the business or
reputation of such other Party.

(b) During the Support Period and except for the filing or amendment of a statement of beneficial
ownership report on Schedule 13D in relation to the purchase or sale of Common Stock, neither the
Marathon Parties nor any of their Representatives, acting at the direction of, or on behalf of, the
Marathon Parties shall make any public statement relating to the Company nor take any action which
would reasonably be expected to require any public filing

7
<!-- page 8 -->
related to the Company without prior written approval from the Company; provided, however, that
nothing in this Agreement shall prevent the Marathon Parties from making a public statement about
how they intend to vote and the reasons therefor with respect to any Extraordinary Transaction to
which any executive officer or director of the Company is a party (other than customary support
agreements) and that requires a vote of the Company's stockholders.

(c) Each Party shall be responsible for any breach of this Section 6 by any of their respective
Representatives.

(d) During the Support Period, so long as the Marathon Parties have maintained since the date of
this Agreement the Minimum Ownership Threshold, (i) management of the Company (together with the
Company's Lead Independent Director, should such director elect to participate) will hold a
customary investor conference call, for up to 45 minutes, with Mr. Cibelli and other representatives
of the Marathon Parties following each of the Company's quarterly and annual earnings calls, and
(ii) promptly following such call, the Lead Independent Director of the Company (together with any
other independent directors of the Company selected by the Lead Independent Director to attend such
meeting) will participate in a call with Mr. Cibelli and other representatives of the Marathon
Parties without management of the Company present for up to 15 minutes (the calls in (i) and (ii),
"Quarterly Investor Conference Calls"). The Marathon Parties shall provide the Company with a
detailed agenda of discussion topics for the portion of the Quarterly Investor Conference Call with
the Lead Independent Director no later than three business days prior to the date of such Quarterly
Investor Conference Call. Should the Marathon Parties forgo a Quarterly Investor Conference Call,
any unused minutes from such relinquished Quarterly Investor Conference Call shall carry over to the
Quarterly Investor Conference Call being held the following quarter; provided, however, for the
avoidance of doubt, any unused minutes from a Quarterly Investor Conference Call shall not carry
over more than one successive quarter.

(e) Between the date of this Agreement and the 2021 Annual Meeting Nomination Window Date, no
Marathon Party or any of their Representatives will contact or communicate with the Company or any
of its Representatives (including any member of the Board) in any way or through any media other
than at a Quarterly Investor Conference Call, in connection with arranging any such Quarterly
Investor Conference Call or in connection with the Marathon Party's specific rights and obligations
under this Agreement. Any communications from any Marathon Party or any of their Representatives in
connection with arranging any such Quarterly Investor Conference Call or in connection with the
Marathon Party's rights and obligations under this Agreement must be directed to the Parties in
accordance with the notice provisions in Section 8(l), and no Marathon Party or any of their
Representatives will contact or communicate with the Company or any of its Representatives
(including any member of the Board) in any other manner unless agreed to in writing by the Company.

(f) In the event that the Support Period is automatically extended pursuant to Section 4(b), then,
following the 2021 Annual Meeting Nomination Window Date, the Marathon Parties agree that any and
all contacts and communications regarding the Company, as well as any request by any of the Marathon
Parties or any of the Marathon Party Representatives to contact, communicate or meet with the
Company or any of its Representatives (including any member of the Board), shall be directed solely
to the Company's General Counsel. Any such communications from any of the Marathon Parties or any of
the Marathon Party Representatives in connection with arranging any Quarterly Investor Conference
Call or in connection with the Marathon Parties' rights and obligations under this Agreement shall
be directed solely to the Company's General Counsel.

7. Press Release. The Parties agree that the Company shall issue a press release (the "Press
Release") in substantially the form attached hereto as Exhibit B promptly following the execution
and delivery of this Agreement by the Parties.

8. Miscellaneous.

(a) Specific Enforcement; Special Remedy. Each of the Parties agrees that the other Party would be
irreparably injured in the event that any provision of the Agreement is breached or not performed.
Accordingly, it is agreed that each Party shall be entitled to temporary and permanent injunctive
relief with respect to each and any breach or purported repudiation of this Agreement by the other
and to specifically enforce strict adherence to this Agreement and the terms and provisions hereof
against the other in any action instituted in a court of competent

8
<!-- page 9 -->
jurisdiction, in addition to any other remedy which such aggrieved Party may be entitled to obtain.
Moreover, in the event of the breach of any of the provisions of this Agreement, timeliness in
obtaining relief is of the essence.

(b) Amendments; Waiver. Neither this Agreement nor any term hereof may be changed, waived,
discharged or terminated orally or in writing, except that any term of this Agreement may be amended
by a writing signed by the Parties, and the observance of any such term may be waived (either
generally or in a particular instance and either retroactively or prospectively) solely in a writing
signed by the Party against whom such waiver is to be asserted. No delay on the part of either Party
in exercising any right, power or privilege hereunder shall operate as a waiver thereof, nor shall
any waiver on the part of either Party of any right, power or privilege hereunder operate as a
waiver of any other right, power or privilege hereunder, nor shall any single or partial exercise of
any right, power or privilege hereunder, preclude any other or further exercise thereof or the
exercise of any other right, power or privilege hereunder.

(c) Successors and Assigns. This Agreement shall inure to the benefit of and be binding upon the
successors and assigns of each of the parties. This Agreement may not be assigned without the prior
written consent of the other Party hereto.

(d) No Third-Party Beneficiaries. Nothing expressed or mentioned in this Agreement is intended or
shall be construed to give any person or entity, other than the Parties and their respective
successors and assigns, any legal or equitable right, remedy or claim under or in respect of this
Agreement and any conditions and provisions hereof being intended to be and being for the sole and
exclusive benefit of the parties hereto and their respective successors and assigns, and for the
benefit of no other person or entity.

(e) Counterparts. This Agreement may be executed in any number of counterparts and by the Parties in
separate counterparts (including by facsimile signature, Docusign or other form of electronic
signature), each of which when so executed shall be deemed to be an original and all of which taken
together shall constitute one and the same agreement. This Agreement may be executed and delivered
by the Parties electronically, including by electronic mail, .pdf, Docusign, or other means of
electronic delivery.

(f) Headings. The headings in this Agreement are for convenience of reference only and shall not
limit or otherwise affect the meaning hereof.

(g) Governing Law; Choice of Venue.

(i) This Agreement shall be governed by and construed in accordance with the internal laws of the
State of Delaware applicable to agreements made and to be performed within that state, without
giving effect to any law or principals of law that would result in the application of the laws of
any other jurisdiction.

(ii) Each Party (A) consents to submit itself to the personal jurisdiction of the Court of Chancery
or other federal or state courts of the State of Delaware in the event any dispute arises out of
this Agreement or the transactions contemplated by this Agreement, (B) agrees that it shall not
attempt to deny or defeat such personal jurisdiction by motion or other request for leave from any
such court, (C) agrees that it shall not bring any action relating to this Agreement or the
transactions contemplated by this Agreement in any court other than the Court of Chancery or other
federal or state courts of the State of Delaware, and each Party irrevocably waives the right to
trial by jury and (D) irrevocably consents to service of process by a reputable overnight mail
delivery service, signature requested, to the address of such Party's principal place of business or
as otherwise provided by applicable law.

(h) Reimbursement. The Company shall reimburse the Marathon Parties for their reasonable
out-of-pocket expenses, including the reasonable fees and expenses of counsel, incurred in
connection with their engagement with the Company, the Nominations and the negotiation of, and all
matters arising under this Agreement; provided, however, that such reimbursement shall not exceed
$250,000.

9
<!-- page 10 -->
(i) Severability. If at any time subsequent to the date hereof, any provision of this Agreement
shall be held by any court of competent jurisdiction to be illegal, void or unenforceable, such
provision shall be of no force and effect, but the illegality or unenforceability of such provision
shall have no effect upon the legality or enforceability of any other provision in this Agreement.

(j) Interpretation and Construction. Each of the Parties acknowledges that it has been represented
by counsel of its choice throughout all negotiations that have preceded the execution of this
Agreement, and that it has executed the same with the advice of said independent counsel. Each Party
and its counsel cooperated and participated in the drafting and preparation of this Agreement and
the documents referred to herein, and any and all drafts relating thereto exchanged among the
parties shall be deemed the work product of all of the parties and may not be construed against any
Party by reason of its drafting or preparation. Accordingly, any rule of law or any legal decision
that would require interpretation of any ambiguities in this Agreement against any Party that
drafted or prepared it is of no application and is hereby expressly waived by each Party, and any
controversy over interpretations of this Agreement shall be decided without regards to events of
drafting or preparation. For purposes of this Agreement, the term "including" shall be deemed to be
followed by the words "without limitation."

(k) Entire Agreement. This Agreement contains the entire understanding of the Parties with respect
to the subject matter hereof.

(l) Notices. Any notices, consents, determinations, waivers or other communications required or
permitted to be given under the terms of this Agreement must be in writing and will be deemed to
have been delivered: (i) upon receipt, when delivered personally; (ii) upon receipt, when sent by
e-mail to the e-mail address for a Party set forth below; and (iii) one (1) business day after
deposit with a nationally recognized overnight delivery service, in each case properly addressed to
the Party to receive the same. The addresses for such communications shall be:

If to the Company or the Board:

e.l.f. Beauty, Inc. 570 10th Street Oakland, CA 94607 Attention: General Counsel Email: ***

with a copy (which shall not constitute notice) to:

Latham & Watkins LLP 140 Scott Drive Menlo Park, CA 94025 Attention: Tad Freese and Josh Dubofsky
E-mail: Tad.Freese@lw.com and Josh.Dubofsky@lw.com

If to the Marathon Parties:

Marathon Partners Equity Management, LLC Attention: Mario Cibelli Email: ***

with a copy (which shall not constitute notice) to:

Olshan Frome Wolosky LLP 1325 Avenue of the Americas New York, NY 10019 Attention: Andrew Freedman
E-mail: AFreedman@olshanlaw.com

10
<!-- page 11 -->
(m) Termination. Unless earlier terminated as provided in this Agreement, upon the expiration of the
Support Period, this Agreement shall immediately and automatically terminate in its entirety and no
Party shall have any further rights or obligations under this Agreement; provided, however, (i) that
this Section 8 shall survive any such termination and (ii) no Party shall be released from any
breach of this Agreement that occurred prior to the termination of this Agreement.

[Signature Pages Follow]

11
<!-- page 12 -->
IN WITNESS WHEREOF, each of the parties hereto has executed this Agreement, or caused the same to be
executed by its duly authorized representative as of the date first above written.

E.L.F. BEAUTY, INC.

By: /s/ Scott Milsten Name: Scott Milsten Title: General Counsel

[Signature Page to Cooperation Agreement]

Marathon Partners Equity Management, LLC
<!-- page 13 -->
By: /s/ Mario D. Cibell Name: Mario D. Cibelli Title: Managing Member

Marathon Partners L.P.

By: Marathon Partners Equity Management, LLC, its General Partner

By: /s/ Mario D. Cibell Name: Mario D. Cibelli Title: Managing Member

Marathon Focus Fund L.P.

By: Cibelli Research & Management, LLC, its General Partner

By: /s/ Mario D. Cibell Name: Mario D. Cibelli Title: Managing Member

Marathon Partners LUX Fund, L.P.

By: Cibelli Research & Management, LLC, its General Partner

By: /s/ Mario D. Cibell Name: Mario D. Cibelli Title: Managing Member

Cibelli Research & Management, LLC

By: /s/ Mario D. Cibell Name: Mario D. Cibelli Title: Managing Member

By: /s/ Mario D. Cibell Name: Mario D. Cibelli

[Signature Page to Cooperation Agreement]
