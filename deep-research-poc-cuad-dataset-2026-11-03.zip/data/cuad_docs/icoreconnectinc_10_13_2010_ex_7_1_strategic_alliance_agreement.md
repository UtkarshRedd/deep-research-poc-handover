<!-- page 1 -->
# Strategic Alliance Agreement
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2010-07-15 |
| Parties | IMedicor, Inc ("IMedicor"); USA Managed Care Organization ("USA MCO") |
| Source | CUAD v1 / ICORECONNECTINC_10_13_2010-EX-7.1-Strategic Alliance Agreement |

Exhibit 7.1 Strategic Alliance Agreement

THIS AGREEMENT is made this 15 th day of July, 2010 ("Effective Date") by and between IMedicor, Inc,
a Nevada Corporation whose address is 523 Avalon Gardens Drive, Nanuet, New York 10954, USA
("IMedicor") and USA Managed Care Organization (USA MCO) A Texas Corporation whose address is 916
South Capital of Texas highway, Austin Texas.

WITNESSETH: WHEREAS, iMedicor is a secure, HIPAA compliant online portal that creates a virtual
healthcare community amongst physicians and other medical professionals for the purpose of real-time
Health Information Exchange. Physicians are provided with a secure HIPPA compliant transport
account(s), similar to e-mail with attachments, that enable them to share patient specific personal
health information with other participating physicians. iMedicor also provides the ability to create
social communities for the purpose of peer collaboration and the extension of referral networks.
iMedicor's portal also provides physicians with an extensive catalogue of Continuing Medical
Education (CME), skill development and product specific educational resources;

WHEREAS, USA MCO represents a network of physicians through which USA MCO provides products and
services for the medical industry that: generate additional revenue Streams; provide cost savings,
streamline workflow; help patients save time, money and doctors achieve better outcomes; and assist
physicians and medical practices to find ways to enhance patient satisfaction;

WHEREAS, both parties are interested in forming a strategic and marketing alliance beneficial to
both organizations.

NOW, THEREFORE, for other good and valuable consideration, the receipt and sufficiency of which are
hereby acknowledged, the parties agree as follows:

1. OBLIGATIONS OF THE PARTIES ●Initiate a multi tiered marketing approach, by mutual consent of both
parties, to integrate the iMedicor HIPAA Compliant transport network as a communications network
throughout the USA MCO user base, ●The overall project would also include the ClearLobby
pharmaceutical and medical device marketing platform and other value added services as mutually
agreed into the future, as a Phase II activity. ●A phased in approach for each of the components
listed above with the first being the introduction of the core iMedicor, HIPAA compliant
communication / transport system into the USA MCO network.
<!-- page 2 -->
●The integrated service will generate revenue sharing opportunities for both companies. ●USA MCO
will allow access to their network to distribute promotional and educational material highlighting
the value proposition of the iMedicor / USA MCO alliance. ●Access will only be through, and
controlled by USA MCO ●Communication will be, but not limited to e-mail promotion, direct mail, bill
stuffers, web site, newsletter or any other normal communication between USA MCO and their network
of physicians and other healthcare providers upon mutual consent of both parties ●All material must
be approved by USA MCO prior to any distribution to the USA MCO network. ●Once a physician or other
healthcare provider enrolls in iMedicor they will become part of the regular internal iMedicor
communications system. ●Every physician that enrolls in iMedicor, including those physicians or
other qualified registrants into the iMedicor network that are invited into USA MCO physician
communities, through the efforts of USA MCO will be tagged as originating from that source (the USA
MCO network). ●Monthly reports detailing revenue generated through subscriptions, ClearLobby or
other methods will be detailed in the monthly reports. ●All revenue sharing will be reconciled
monthly and funds distributed by the 20th of each month by wire transfer for all net collected
revenues for the previous month (net of returns and refunds, if any). ●IMedicor will make its
records available for audit purposes at any time by USA MCO during regular business hours at the
headquarters of iMedicor. ●USA MCO will not be responsible for any direct sales of the iMedicor
communications system; USA MCO will not handle any customer service issues. All such activity will
be referred to iMedicor. ●Initially iMedicor will provide the three main attributes of the iMedicor
network to the USA MCO provider base, physicians and other healthcare providers. ●Those attributes
are: oA HIPAA compliant transport system for digital / electronic records and images, oBuild and
create community, patient-specific peer collaboration and expansion of referral networks, oAccess to
educational resources, certified, skill level and product / device specific. ●

2. COMPENSATION ●IMedicor will charge a subscription fee to participating USA MCO providers. The
suggested monthly subscription would be $19.95 per month per subscriber. USA MCO would receive one
third of the monthly subscription price, per month, per subscriber (approximately $6.65). All
revenue sharing opportunities will be calculated for all parties after any credit card or other
third party processing fees are deducted from the gross sale. ●USA MCO will be responsible for the
marketing and initial / ongoing communication to their network highlighting the features of
iMedicor, the value proposition, and their support of the project. This will not be a direct sales
requirement for USA MCO, but only an agreement to provide access to the USA MCO user base ●Within 30
days of the execution of this agreement both companies agree to finalize a marketing plan that would
detail they promotional activity to the USA MCO network, promotional deliverables, frequency of
communication with the USA MCO network and other activities normally found in a strategic marketing
plan ●Both companies agree to publish a press release, upon mutual agreement of content, in regard
to the execution of this agreement and periodic updates of the success of this Strategic Alliance
●It is understood that iMedicor is a public company and is obligated to make certain SEC required
filings that from time to time will include mention of the Strategic Alliance between iMedicor and
USA MCO ●IMedicor shall provide access to the iMedicor system, training and customer support as
required. ●USA MCO will have the option to take all or part of its revenue share in equity up to a
maximum of 4.9% ownership in iMedicor on a fully diluted basis. For the purposes of this proposal,
fully diluted means all issued and outstanding stock warrants priced at 15 times the average 5 day
closing price at the day previous to reconciliation of revenues, which will be the 20th of the month
for the prior calendar month.
<!-- page 3 -->
●The iMedicor bookkeeping system will detail the payment option prior to releasing any funds or
commitment of stock in order for USA MCO to determine how payment is to be reconciled. It is
anticipated that said report will be available by the 15th of the month for previous activity,
returned to iMedicor by the 19th in order to effect a timely disbursement of funds and or stock ●It
is understood that the issuance of stock certificates can take up to four weeks but the issue date
will be the 20th of the month of reconcile. ●Equity payout will be priced at the average 10 day
trading day closing from the day previous to the monthly reconciliation. ●IMedicor will provide a
warrant to purchase 2 million shares of common stock to USA MCO to offset any up-front marketing
expense incurred by USA MCO in this project. The value of the Warrants will be determined by the
average 10 day closing price of iMedicor stock eliminating the two lowest days and the two highest
days for the period as of the day before the actual execution of the final agreement. ●The Warrants
will be issued as a non-cash-transaction upon exercise of the Warrant, and, USA MCO will have up to
five years from the date of issuance to exe4cute. USA MCO will also have the option to purchase the
Warrant for the face value if it deemed the purchase option to be more favorable to the cashless
transaction. ●In addition to the subscription fees, iMedicor would offer a 17% revenue share (cash
payout only) through revenues generated with its ClearLobby program. Clearlobby represents the
Pharma / Medical Device marketing division inside iMedicor that will expose physicians and other
providers within the USA MCO provider network to new products and services in a non-invasive, opt-in
manner. ClearLobby will be the Phase II part of the relationship. ●iMedicor will inform USA MCO of
all ClearLobby activity as new products and services are introduced into the system ●IMedicor will,
from time to time make available upgrade services to its members. In this event, USA MCO will
receive a revenue share to be determined on a case by case basis. 3. TERM This Agreement shall
commence on the Effective Date of this Agreement and shall remain in effect for a period of 5 years
("Initial Term"). Thereafter, this Agreement shall be renewed automatically on a five (5) year
basis, unless one party notifies the other of its desire to terminate this Agreement at least sixty
90 days prior to the expiration of the Initial Term or then current renewal term, as applicable, or
unless a new Agreement is signed between the USA MCO and IMedicor which will then invalidate this
Agreement.

In such an instance, all compensation will continue for a extended period of five years from the
date of termination for all subscriptions tagged as USA MCO.
<!-- page 4 -->
4. INTELLECTUAL PROPERTY Each party shall exclusively own its respective trademarks and service
marks, copyrights, trade secrets, and patents (collectively, the "Intellectual Property") and will
not have any claim or right to the other party's Intellectual Property by virtue of this Agreement
or the performance of services hereunder. Neither party will take any action or make any claim to
any Intellectual Property belonging to the other party, whether during the Term of this Agreement or
thereafter.

5. TERMINATION

A. Termination Without Cause. Both parties may terminate this Agreement upon ninety ("90") days
written notice to the other party at the address stated in this Agreement as per section 3 above.

B. Both parties shall have the right to include this Agreement as an asset of their Company.

C. Upon termination of this Agreement for any reason whatsoever, both parties shall have the right
to remove any references to the other party from any of its materials and/or websites as well as be
authorized to notify their customers of said termination without penalty and/or recourse by the
other party if only if said notification contains no disparaging or disrespectful comments
concerning the other party.

6. REPRESENTATIONS AND WARRANTIES

A. Each party represents and warrants that it has the right, title, interest and authority to enter
into this Agreement and to fully perform its obligations hereunder, and that the rights granted
hereunder shall not violate the rights of any third party. Each party represents and warrants that
its conduct hereunder shall conform to all applicable federal, state and local law and regulation.

B. Both parties will not have liability for any damages other than direct damages. Both parties DO
NOT MAKE ANY WARRANTY REGARDING THE QUALITY OF ITS SERVICES. Both parties DO NOT MAKE ANY WARRANTY
THAT ALL ERRORS OR FAILURES IN ITS WEBSITES WILL BE CORRECTED. Both parties EXPRESSLY DISCLAIM ALL
WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. BEYOND THE WARRANTIES CONTAINED
IN THIS PARAGRAPH, Both parties DO NOT WARRANT THAT their SITES ARE ERROR-FREE OR THAT OPERATION OF
their SITES WILL BE SECURE OR UNINTERRUPTED. THESE LIMITATIONS SHALL SURVIVE AND APPLY
NOTWITHSTANDING THE VALIDITY OF THE LIMITED REMEDIES PROVIDED FOR IN THIS AGREEMENT.
<!-- page 5 -->
7. INDEMNITY Notwithstanding anything to the contrary herein, USA MCO shall indemnify, defend and
hold harmless IMedicor, its officers, directors, shareholders, employees, parent and affiliate
entities, agents and representatives, against all damages, claims, liabilities, losses and other
expenses, including without limitation, reasonable attorney fees and costs, whether or not a lawsuit
or other proceedings is filed, that in any way arise out of or related to: (a) any claim against
IMedicor arising out of any breach of any covenants, warranties, representations and agreements made
by USA MCO to any third party and/or (b) USA MCO's material breach of any provision of this
Agreement; (c) the grossly negligent or willful acts or omissions of USA MCO; and/or (d) any claim
by any party based on USA MCO's Products failing to operate and/or function in any manner so
advertised by USA MCO and/or its agents. In the event that USA MCO fails to promptly indemnify and
defend such claims and/or pay expenses as provided above, IMedicor shall have the right to defend
itself and USA MCO shall reimburse IMedicor for all of its reasonable attorneys' fees, costs and
damages incurred in settling or defending such claims within sixty (60) days of IMedicor' request
for same.

Notwithstanding anything to the contrary herein, IMedicor shall indemnify, defend and hold harmless
USA MCO, its officers, directors, shareholders, employees, parent and affiliate entities, agents and
representatives, against all damages, claims, liabilities, losses and other expenses, including
without limitation, reasonable attorney fees and costs, whether or not a lawsuit or other
proceedings is filed, that in any way arise out of or related to: (a) any claim against USA MCO
arising out of any breach of any covenants, warranties, representations and agreements made by
IMedicor to any third party and/or (b) IMedicor material breach of any provision of this Agreement;
(c) the grossly negligent or willful acts or omissions of IMedicor; and/or (d) any claim by any
party based on IMedicor Products failing to operate and/or function in any manner so advertised by
IMedicor and/or its agents. In the event that IMedicor fails to promptly indemnify and defend such
claims and/or pay expenses as provided above, USA MCO shall have the right to defend itself and
IMedicor shall reimburse USA MCO for all of its reasonable attorneys' fees, costs and damages
incurred in settling or defending such claims within sixty (60) days of USA MCO' request for same.

8. NO JOINT VENTURE Nothing in the Agreement shall be deemed to constitute, create, give effect to
or otherwise recognize a partnership, joint venture or formal business entity of any kind; and the
rights and obligations of the Parties shall be limited to those expressly set forth herein. No Party
is granted any right or authority to assume or create any obligation or responsibility, express or
implied, on behalf of, or in the name of, another Party or to bind another in any matter or thing
whatsoever.

9. CONFIDENTIALITY

A. "Confidential Information" as used in this Agreement shall mean any and all technical and
non-technical information including but not limited to patent, copyright, trade secret, and
proprietary information, techniques, sketches, drawings, models, inventions, know-how, processes,
apparatus, equipment, algorithms, software programs, software source documents, and formulae related
to the current, future, and proposed products and services of IMedicor and its affiliates, and
includes, without limitation, IMedicor and its affiliates information concerning research,
experimental work, development, design details and specifications, engineering, financial
information, procurement requirements, purchasing, manufacturing, USA MCO lists, business forecasts,
sales and merchandising, and marketing plans and information. "Confidential Information" also
includes proprietary and/or confidential information of any third party that may disclose such
information to USA MCO in the course of IMedicor' business. All Confidential Information disclosed
both orally and in writing by the disclosing party ("Discloser") will be considered Confidential
Information by the receiving party ("Recipient") and subject to terms of this Agreement, even if
such information is not conspicuously designated as "Confidential" or even when provided orally and
not identified as confidential at the time of disclosure.
<!-- page 6 -->
B. All Confidential Information disclosed both orally and in writing by either party will be
considered Confidential Information by USA MCO and subject to terms of this Agreement, even if such
information is not conspicuously designated as "Confidential" or even when provided orally and not
identified as confidential at the time of disclosure.

C. USA MCO acknowledges that Discloser has over many years devoted substantial time, effort and
resources to developing Discloser's trade secrets and its other confidential and proprietary
information, as well as Discloser's relationships with USA MCOs, suppliers, employees and others
doing business with Discloser; that such relationships, trade secrets and other information are
vital to the successful conduct of Discloser' business in the future; that Discloser, in the
furtherance of its business, is providing Recipient with the opportunity and support necessary to
them to establish personal and professional relationships with USA MCOs, suppliers, employees and
others having business relationships with Discloser and is affording Recipient access to Discloser'
trade secrets and other confidential and proprietary information; that because of the opportunities
and support so provided to Recipient and because of Recipient's access to Discloser' confidential
information and trade secrets, Recipient would be in a unique position to divert business from
Discloser and to commit irreparable damage to Discloser were Recipient to be allowed to compete with
Discloser or to commit any of the other acts prohibited by this Section 9 of the Agreement; that the
enforcement of the restrictive covenants against Recipient would not impose any undue burden upon
Recipient; that none of the restrictive covenants is unreasonable as to period or geographic area;
and that the ability to enforce the restrictive covenants against Recipient is a material inducement
to the decision of Discloser to consummate this Agreement

D. Recipient hereby agrees that it will not make use of, disseminate, or in any way disclose any
Confidential Information of Discloser to any person, firm, or business, except to the extent
necessary for negotiations, discussions, and consultations with personnel and/or authorized
representatives of Discloser, any purpose of Discloser authorized by this Agreement and any purpose
Discloser may hereafter authorize in writing. Recipient hereby also agrees that it will use the
Confidential Information disclosed by Recipient for informational purposes only. Recipient hereby
further agrees that it shall not use the Confidential Information of Recipient in the production
and/or the providing of any products and/or services now or in anytime in the future.

E. Recipient agrees that it shall treat all Confidential Information of Recipient with the same
degree of care as it accords to its own Confidential Information, and Recipient represents that it
exercises reasonable care to protect its own Confidential Information.

F. Recipient hereby agrees that it shall disclose Confidential Information of Discloser only to
those of its officer(s), manager(s), and/or employee(s) who need to know such information and
certifies that such officer(s), manager(s), and/or employee(s) have previously agreed, either as a
condition of employment or in order to obtain the Confidential Information, to be bound by terms and
conditions substantially similar to those of this Agreement.

G. Recipient will immediately give notice to Recipient of any unauthorized use or disclosure of the
Confidential Information. Recipient agrees to assist Recipient in remedying any such unauthorized
use or disclosure of the Confidential Information.

H. Upon the request of Discloser and/or termination of this Agreement, the Recipient will promptly
return all confidential information furnished hereunder and all copies thereof.

I. Remedies. In the event of a breach or a threatened breach of any of the Provisions and/or
Covenants set forth in this Section 9 of the Agreement above (the ''Covenants''), Discloser will, in
addition to the remedies provided by law, have: (a) the right and remedy to have the Covenants
specifically enforced by any court having equity jurisdiction, it being acknowledged and agreed that
any material breach of any of the Covenants will cause irreparable injury to Discloser and that
money damages will not provide an adequate remedy to Discloser; and

(b) the right and remedy to require a person to account for and pay over to Discloser all
compensation, profits, moneys, accruals, increments or other benefits (collectively the
''Benefits'') derived or received by Recipient as a result of any transactions constituting a breach
of any of the Covenants, and Recipient hereby agrees to account for and pay over the Benefits to
Discloser.

J. The obligations of the parties set forth in this paragraph 9 of this Agreement shall survive the
termination of this Agreement.
<!-- page 7 -->
10. PUBLICITY The Parties agree that all publicity and public announcements concerning the formation
and existence of this Agreement shall be jointly planned and coordinated by and among the Parties.
Neither party shall disclose any of the specific terms of this Agreement to any third party without
the prior written consent of the other party, which consent shall not be withheld unreasonably.
Notwithstanding the foregoing, any party may disclose information concerning this Agreement as
required by the rules, orders, regulations, subpoenas or directives of a court, government or
governmental agency, after giving prior notice to the other party.

11. EFFECT OF TERMINATION Upon termination or expiration of this Agreement, all rights granted to
the USA MCO and IMedicor shall forthwith revert to the granting party.

12. FORCE MAJEURE Neither party will be liable for, or will be considered to be in breach of or
default under this Agreement on account of, any delay or failure to perform as required by this
Agreement as a result of any causes or conditions that are beyond such Party's reasonable control
and that such Party is unable to overcome through the exercise of commercially reasonable diligence.
If any force majeure event occurs, the affected Party will give prompt written notice to the other
Party and will use commercially reasonable efforts to minimize the impact of the event.

13. NOTICES

A. Any notice required to be given pursuant to this Agreement shall be in writing and mailed by
certified or registered mail, return receipt requested or delivered by a national overnight express
service.

For IMedicor: Fred Zolla, CEO IMedicor, Inc. 523 Avalon Gardens Drive Nanuet, New York 10954 For the
USA MCO: George Bogle, CEO / President USA MCO Solutions Corp, 916 South Capital of Texas Highway
Austin, TX 78746

Either party may change the address or entity to which notice or payment is to be sent by written
notice to the other party pursuant to the provisions of this paragraph.
<!-- page 8 -->
14. JURISDICTION DISPUTES

A. This Agreement shall be governed by the internal laws State of New York.

B. All disputes hereunder shall be resolved in the applicable state or federal courts in County of
Rockland in the State of New York. The parties consent to the jurisdiction of such courts, agree to
accept service of process by mail, and waive any jurisdictional or venue defenses otherwise
available.

15. AGREEMENT BINDING ON SUCCESSORS This Agreement shall be binding upon and shall inure to the
benefit of the parties hereto, their heirs, administrators, successors and assigns.

16. WAIVER No waiver by either party of any default shall be deemed as a waiver of any prior or
subsequent default of the same or other provisions of this Agreement.

17. SEVERABILITY If any provision hereof is held invalid or unenforceable by a court of competent
jurisdiction, such invalidity shall not affect the validity or operation of any other provision and
such invalid provision shall be deemed to be severed from the Agreement.

18. ASSIGNABILITY The license granted hereunder is specific to the USA MCO and may not be assigned
by any act of the USA MCO or by operation of law unless with the written consent of IMedicor.

19. INTEGRATION This Agreement constitutes the entire understanding of the parties, and revokes and
supersedes all prior Agreements between the parties and is intended as a final expression of their
Agreement. It shall not be modified or amended except in a writing signed by the parties hereto and
specifically referring to this Agreement. This Agreement shall take precedence over any other
documents which may be in conflict therewith.
<!-- page 9 -->
IN WITNESS WHEREOF, the parties hereto, intending to be legally bound hereby, have each executed
this agreement on the day indicated. USA MCO IMedicor, Inc. By: /s/George Bogle By: /s/Fred Zolla
George Bogle, CEO / President Fred Zolla, CEO
