# When does the Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONA...

*Question:* When does the Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONAL TEST SYSTEMS, INC. (filed 2000-07-26) expire, according to its term clause?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Locate Distributor Agreement and term clause

The Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONAL TEST SYSTEMS, INC. filed 2000-07-26 defines the Initial Distribution Period as April 15, 2000 through October 15, 2000. [ce581d56506a6a52 p.1] The agreement states that this period covers 6 months from the Effective Date. [ce581d56506a6a52 p.1] The Effective Date is defined as the earlier of the date Comware orders and pays for a minimum of $22,710 worth of Products, in any combination, or April 15, 2000. [ce581d56506a6a52 p.1]

[GAP] The evidence does not state whether the agreement expires at the end of the Initial Distribution Period or whether it contains a renewal or extension provision.

## Not established by the evidence

[GAP] No evidence was found for: Extract the expiration date stated in the term clause

## Verification appendix

Claims: 5 · supported: 3 · partially: 0 · dropped: 0 · gaps: 2 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Determine expiration date

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[ce581d56506a6a52 p.1] |  |
| s1.2 | s1 | keep | 1.00 | e1→[ce581d56506a6a52 p.1] |  |
| s1.3 | s1 | keep | 1.00 | e1→[ce581d56506a6a52 p.1] |  |
| s1.4 | s1 | gap |  |  |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [ce581d56506a6a52 p.1 L23-36] keep (1.0): "2. DEFINITIONS:

INITIAL DISTRIBUTION PERIOD: April 15, 2000 through October 15, 2000 (6 Months from the Effective Date)

PRODUCTS: The CircuiTest 2000S In-Circuit Test System

The CircuiTest 2100 Scanner Expansion

EXCLUSIVE TERRITORIES: T…"
