<!-- page 1 -->
# EXHIBIT 'B
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2020-03-26 |
| Parties | Kubient, Inc. ("Kubient"); The Associated Press ("Customer") |
| Source | CUAD v1 / KUBIENT,INC_07_02_2020-EX-10.14-MASTER SERVICES AGREEMENT_Part2 |

EXHIBIT 'B' This Exhibit B is entered into as of the 26th day of March 2020 by and between Kubient,
Inc. ("Kubient"), and The Associated Press ("Customer"). This Exhibit is hereby incorporated into
and made a part of the Master Services Agreement (the "Agreement") between the Parties (Effective
Date: February 5, 2020). NATURE OF ENGAGEMENT: Customer has retained Kubient to help increase
revenue from its consumer offerings, including but not limited to its websites, apps, videos, and
podcasts. SERVICES: Kubient shall provide to Customer advertising and related business revenue
consultation with respect to the AP News site, AP News mobile app, AP DNE sites and widgets. This
includes all categories identified in the threshold table in Schedule 1 to Exhibit B. REVENUE
SHARE/FEE: Commencing on March 1, 2020 and thereafter, the Parties shall share revenue generated
from Customer's consumer offerings, including but not limited to its content, technology, traffic,
data, websites, apps, videos and podcasts, without offset and regardless of which Party is
responsible for securing such revenue, as per the attached Schedule 1. RECONCILIATION/PAYMENT TERMS:
The Parties agree to reconcile revenue numbers and the revenue share calculations no later than 10
days following the end of each calendar month during which the Services were rendered. Subject to
the doctrine of sequential liability, payment shall be made to the appropriate Party net 30 days
from the end of the calendar month. NON-CIRCUMVENT: As part of the Services provided under the
Agreement and any applicable exhibits, Kubient will be working with and introducing certain
third-party advertisers, sponsors, agencies, media buyers, service providers, vendors, publishers,
affiliates and/or media partners (collectively "Third-Party") with whom Customer does not have a
pre-existing relationship. During the Term and any renewal terms of the Agreement, and for a period
of one (1) year following the expiration or earlier termination thereof, Customer agrees not to work
with, directly or indirectly, any Third-Party that Customer comes to know through disclosure by
Kubient as part of the Services, without the express written consent of Kubient and compensation to
Kubient under the applicable exhibit and/or schedule. Provided however, this provision shall not
apply in the event Customer can establish, in writing, that it had a preexisting working
relationship with such Third-Party prior to the Agreement and without Kubient's assistance. Customer
acknowledges that this provision is reasonable and necessary for the protection of Kubient and that
Kubient will be irrevocably damaged if such covenant is not specifically enforced. Customer further
agrees that Kubient will be entitled to seek injunctive relief for the purpose of restraining
Customer from violating this covenant (and no bond or other security shall be required in connection
therewith) in addition to any other relief to which Kubient may be entitled under the Agreement.
NON-SOLICITATION: During the Term and any renewal terms of the Agreement, and for a period of one
(1) year following the expiration or earlier termination thereof, Customer shall not, without
Kubient's prior written consent, directly or indirectly (i) solicit or encourage any person to leave
the employment or other service of Kubient; or (ii) hire, on behalf of Customer or any other person
or entity, any person who has left the employment of Kubient within the one (1) year period
following the termination or end of that person's employment. During the Term and any renewal terms
of the Agreement, and for a period of one (1) year following the expiration or earlier termination
thereof, Customer shall not, whether for its own account or for the account of any other person or
entity, interfere with the relationship of Kubient with, or endeavor to entice away from Kubient,
any person or entity who was or is a an employee or Third-Party of Kubient. CONFLICTING TERMS: The
Schedule 1 shall supersede the flat fee and Initial Revenue Share set forth in Exhibit A. The
payment term provision above shall supersede the payment term provision set forth in Exhibit A. IN
WITNESS WHEREOF, the parties hereto have caused this Exhibit A to be executed by their duly
authorized representatives as of the 26th day of March, 2020. Kubient Signature: By: /s/ Paul
Roberts Its: President Date: 3/27/2020 Customer Signature: By: /s/ Ted Mendelsohn Its: VP,
Commercial Mkts Date: 3/27/2020
<!-- page 2 -->
SCHEDULE 1 TO EXHIBIT 'B' This Schedule 1 to Exhibit B ("Schedule 1") is entered into as of the 26th
day of March, 2020 by and between Kubient, Inc. ("Kubient"), and The Associated Press ("Customer").
This Schedule 1 is hereby incorporated into and made a part of Exhibit B to the Master Services
Agreement between the Parties (Effective Date: February 5, 2020). Monthly Revenue* Below Threshold
Above Threshold Type Threshold Customer Kubient Customer Kubient Programmatic/Display $ 300,000.00
90% 10%** 50% 50% Video $ 30,000.00 100% 0 % 50% 50% Direct Deals*** Undertone 100% 0 % 50% 50%
Native**** $ 100,000.00 100% 0 % 50% 50% Data/Newsletter $ - 0 % 0 % 50% 50% Podcasts $ - 0 % 0 %
50% 50% Other $ - 0 % 0 % 50% 50% *All "Revenue" calculations shall refer to gross revenue actually
received by the collecting party less client credits and allowances for returns, but without any
deduction or offset for costs incurred by either Party, except for "Direct Deals". For "Direct
Deals", "Revenue" shall refer to Net Revenue, defined as gross revenue actually received by the
collecting party less client credits and allowances for returns and less any agreed upon costs
incurred by either Party in support of a "Direct Deal" for such things as production, photography,
video, content creation and/or media buying (i.e. Nativo). Programmatic/Display refers to revenue
generated by the following clients and any additional clients that AP adds during the term: Google
Adexchange, Index Exchange, OpenX, Smaata, Rhythm One; Rubicon; TripleLift; Amazon; DistrictM;
AppNexus; Xandr; Media.net; Criteo; Sovm; Saamba; AOL Marketplace **Kubient "Below Threshold"
monthly compensation shall act as a guaranteed draw against any Kubient "Above Threshold" monthly
compensation generated from any/all Types of "Revenue". This compensation shall expire on September
1, 2020, such that Kubient shall not be entitled to or receive after the month of August. ***"Direct
Deals" shall refer to any sort of sponsorship or customized off-platform opportunity (e.g., via AP's
native or social media channels) introduced by Kubient. Kubient shall have no right to or interest
in "Revenue" generated from Direct Deals with Regions Bank, Undertone, or Healthgrades. Kubient
shall have no right to or interest in "Revenue" generated from Nativo, except for new "Direct Deals"
introduced by Kubient that generate Net Revenue. ****"Native" ad-based revenue is generated by
Taboola. Kubient shall have no right to or interest in any "Above Threshold" Native ad- based
revenue generated by Taboola. ACKNOWLEDGEMENT: Customer acknowledges and agrees that the above
calculations are based on its own revenue reports and present a fair, reasonable and accurate
representation of its monthly average digital revenue. IN WITNESS WHEREOF, the parties hereto have
caused this Exhibit B to be executed by their duly authorized representatives as of the 26th day of
March, 2020. Kubient Signature: By: /s/ Paul Roberts Its: President Date: 3/27/2020 Customer
Signature: By: /s/ Ted Mendelsohn Its: VP, Commercial Mkts Date: 3/27/2020
