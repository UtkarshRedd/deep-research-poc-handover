<!-- page 1 -->
# STRATEGIC ALLIANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2016-02-17 |
| Parties | EDGE Communication Solutions, LLC ("EDGE"); FRE Networks, Inc. ("FTE", "Subcontractor") |
| Source | CUAD v1 / FTENETWORKS,INC_02_18_2016-EX-99.4-STRATEGIC ALLIANCE AGREEMENT |

Exhibit 99.4 STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" THIS STRATEGIC ALLIANCE AGREEMENT (the
"Agreement"), made effective this 17t h day of February 2016, through February 16, 2019 (the
"Initial Term") is entered into by and between EDGE Communications Solutions, LLC, with its
principal place of business at 6505 Windcrest Drive, Suite 200, Plano, TX 75024 (hereinafter
referred to as "EDGE"), and FTE Networks, Inc. with its principal place of business at 999
Vanderbilt Beach Road, Suite 601, Naples, FL 34108 (hereinafter referred to as "FTE" or
"Subcontractor") sets forth the terms and conditions by which FTE will supply labor, materials,
equipment, supervision and/or services for FTE's scope of work. FTE's work shall be identified in a
purchase order, which if issued, will be issued subject to the terms of this Agreement ("Purchase
Order"). Each Purchase Order, taken together with the terms and conditions of this Agreement, shall
constitute a separate agreement between the parties and shall be considered independent of any other
agreements between the parties that incorporate the terms and conditions of the Agreement. FTE
agrees to perform its scope of work, in accordance with the terms and conditions of this in
accordance with the terms and conditions of the respective issued Purchase Order(s). The Work, as
defined below, is a portion of the services to be provided by for a communications service provider
Mediacom, LLC (the "Customer"). 1. TERMS A. This Agreement shall remain in effect for the duration
of the Initial Term, unless earlier terminated pursuant to the provision entitled "Termination of
Agreement". After the Initial Term, this Agreement shall continue on a month to month basis until
terminated by either party upon thirty (30) days prior written notice to the other setting forth the
effective date of such termination. The termination of any Purchase Order shall not affect the
obligations of either party to the other party pursuant to any other Purchase Order or to this
Agreement. The termination of this Agreement shall terminate the obligations of either party to the
other party pursuant to any Purchase Order and those obligations pursuant to this Agreement, except
as to obligations that are identified herein or in a terminated Purchase Order as surviving
termination. B. Should the Agreement expire during the period of performance, all remaining Work of
each Purchase Order will be completed under the terms of the Agreement then in effect on the date of
award for each respective Purchase Order, unless modified in writing by mutual consent of the
parties. C. Prior to performing or providing the labor, materials, equipment and services required
to complete the work described in a Purchase Order, if any, (the "Work"), Subcontractor must have a
properly executed Agreement with EDGE, complied with all terms and conditions therein, including
have submitted the required proofs of insurance. EDGE shall receive authorization from the Customer
to approve Subcontractor as an approved vendor and to approve the Work terms and conditions of this
Agreement if required to do so under Edge's contract with the Customer.

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 1
<!-- page 2 -->
2. SCOPE OF WORK A. Subcontractor shall perform work for EDGE referred to as "Route Feasibility &
Site Acquisition," "Materials Management," "OSP Construction," and "Other Work" as outlined in the
attached Exhibits A, B, C and D and as described and set forth in Purchase Orders. B. Descriptions
of the Work to be performed by Subcontractor for EDGE shall be listed in a Purchase Order. EDGE
engages Subcontractor to furnish the Work described in the Purchase Order. All Work under any
Purchase Order shall be performed in a professional manner and in accordance with the applicable
specifications and drawings. Purchase Orders, shall be issued and administered as set forth in
Section 3 below. C. Unless otherwise provided in the Purchase Order, the Contractor shall provide
and pay for materials, and other facilities and services necessary for proper execution and
completion of the Work, whether temporary or permanent and whether or not incorporated or to be
incorporated in the Work. 3. DISBURSEMENT OF PURCHASE ORDER A. Issuance of Work under this Agreement
may be made from time to time by the issuance of Purchase Orders to Subcontractor. Purchase Orders,
if any, shall reference and incorporate the terms and conditions of the Agreement which shall apply
to all Work performed under the Purchase Order. B. Nonexclusive Rights. This Agreement is an
as-ordered agreement between EDGE and Subcontractor, anticipating the potential but not promised
issuance of Purchase Orders for specific work in amounts in excess of $20MM. 4. COMPENSATION &
PAYMENTS A. All Work shall be performed on the basis of certain agreed upon prices specified in the
related Exhibit or individual Purchase Order once accepted by Subcontractor. B. Payment. EDGE shall
pay Subcontractor for Work completed in accordance with the related Exhibit or individual Purchase
Order once accepted by Subcontractor. C. This Agreement shall not be construed as a "Pay When Paid"
contract. EDGE's obligation to pay Subcontractor under this Agreement shall not be predicated upon
the Customer approving or paying EDGE for the Work. D. Release and Waiver of Liens. Subcontractor
will pay for all services, equipment, material and labor used under this Agreement and will keep
EDGE' and Customer's property and work sites free of all claims or liens.

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 2
<!-- page 3 -->
(1) If Subcontractor fails to make payments to subcontractors, materialmen, or suppliers, of any
tier, including but not limited to suppliers of labor, material, equipment or services or to union
benefits funds (hereinafter "Lower-tier Subcontractors"), its employees or laborers in the
performance of the Work, EDGE shall have the right to deduct or temporarily withhold out of payments
due or to become due to Subcontractor, reasonable amounts to satisfy any claims, bonds, or liens
against the Work site, to issue joint checks to (i) Subcontractor and (ii) its Lower-tier
Subcontractors, employees or laborers, and any potential bond or lien claimant, as applicable, or to
pay such claimant(s) to protect EDGE from any and all loss, damage and expense (including attorneys'
fees) arising out of or related to a claim or lien by such claimant (2) Subcontractor agrees to
indemnify and defend EDGE from and against any lien claims and to discharge any lien or furnish an
indemnity bond equal to the lien amount (or any greater amount required by law) within ten (10) days
notice from EDGE of the presence of any lien. E. Acceptance of any payment by Subcontractor shall
not constitute a waiver of claims by Subcontractor except those previously made in writing and
identified by Subcontractor as settled at the time of final invoice. 5. INDEPENDENT SUBCONTRACTOR
RELATIONSHIP Nothing in this Agreement shall cause Subcontractor in any way to be construed as a
partner or joint venture with, or an employee of, EDGE in connection with or arising from
Subcontractor's rendering of Work to EDGE pursuant to this Agreement. EDGE retains Subcontractor
only for the purposes and to the extent as set forth in this Agreement, and Subcontractor's relation
to EDGE during the term of this Agreement shall be that of an independent contractor and nothing
herein shall create or imply any other or different relationship. Subcontractor acknowledges that:
(a) nothing herein constitutes the exercise by EDGE of control or direction over the manner or
method by which Subcontractor will perform the Work, (b) Subcontractor is solely responsible for the
withholding and payment of all federal, state and local income, social security and unemployment
taxes, salaries, and other payments required to be made by it from funds received from EDGE
hereunder, and (c) that EDGE is not required to and will not provide any worker's compensation or
other insurance coverage of any nature, or any other unemployment, medical, dental, welfare or
pension benefits to Subcontractor or any of its employees, associates or subcontractors. In
addition, Subcontractor shall exercise full control of and supervision over its employees.
Subcontractor acknowledges that its personnel (if any) performing Work are agents, employees or
subcontractors of Subcontractor and are not employees or agents of EDGE. 6. SUBCONTRACTING A.
Subcontractor shall be permitted to subcontract any part of the Work without the prior written
notification and consent of EDGE. However, Subcontractor will follow subcontracting requirements and
processes of EDGE and provide joint access to subcontractor database and information concerning
quality control. All Work performed by a Lower-tier Subcontractor shall be deemed Work performed by
Subcontractor. Subcontractor agrees not to hire any Lower-tier Subcontractor to whose employment
EDGE reasonably objects.

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 3
<!-- page 4 -->
B. If the Work of any Lower-tier Subcontractor is unsatisfactory or unnecessarily delayed, or the
Lower-tier Subcontractor violates any of the provisions of this Agreement, EDGE may request
Subcontractor to terminate such Lower-tier Subcontractor and Subcontractor shall immediately
terminate the agreement with its Lower-tier Subcontractors without any liability to EDGE whatsoever.
Additionally, Subcontractor shall, at its cost, properly complete the Work within the required time
or arrange for a capable subcontractor, approved by EDGE, to do so. 7. MODIFICATIONS AND CHANGES TO
THE SCOPE OF WORK A. EDGE and Subcontractor, without invalidating this Agreement, may agree to
changes in the Work consisting of additions, deletions, or modifications ("Change Order"), pursuant
to a completed written change order documented by the parties. Such Change Order shall set forth any
changes to the applicable Purchase Order and the price and time adjusted accordingly if any. In
connection with the Change Order, EDGE will issue to Subcontractor a subsequent Purchase Order
identifying any agreed upon change in the Work price and/or time. B. All modifications to the terms
of this Agreement shall be by written Amendment signed by both parties or otherwise documented by
the parties. 8. INSPECTION OF WORK As set forth in the Exhibit, EDGE shall have the opportunity to
review and inspect all elements of the Work in a reasonable manner. EDGE shall have the right to
require repair or replacement of any Work which is defective or not performed in accordance with the
Purchase Order or deviates from other requirements of this Agreement, provided Subcontractor shall
have until acceptance to complete such repair or replacement. Subcontractor shall be solely
responsible for all construction means, methods, techniques, procedures and safety and security
programs in connection with the performance of the Work. 9. INSURANCE A. Subcontractor shall obtain
at its own cost and expense and maintain the insurance in full force and effect during the term of
the Agreement as required herein. A copy of the (i) certificate(s) of insurance and (ii)
endorsements, acceptable to EDGE, shall be submitted to EDGE prior to commencement of any Work and
renewals or replacements of such certificates shall be so delivered at least 30 days prior to the
expiration or termination of each such policy. A copy of the insurance policies shall promptly be
made available to EDGE upon EDGE' request. Subcontractor expressly acknowledges while EDGE retains
the right to review the insurance provided by Subcontractor and' Lower-tier Subcontractors, EDGE is
not obligated to perform such review. In addition, EDGE exercise of such right is for EDGE' benefit
alone and shall confer no rights to Subcontractor or to any third party. EDGE's acceptance of or
failure to object to the submitted documents does not constitute approval of coverage that is not in
compliance with this Agreement or as acceptance or affirmation of the adequacy or applicability of
such insurance.

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 4
<!-- page 5 -->
(1) Commercial General Liability Insurance providing the limits of coverage written on an occurrence
basis, in no event less than $1,000,000 combined single limit and $2,000,000 in the aggregate for
personal and bodily injury and death arising therefrom and Broad Form property damage arising out of
any one occurrence in connection with the Work or any part thereof, which insurance shall include
coverage with the same minimum limits for contractual liability and completed operations liability.
General Liability and Umbrella/Excess Liability policies must have "per location or per project"
aggregates. (2) Motor Vehicle Insurance covering bodily injury, death of a person or property damage
arising out of the ownership, maintenance or use of any motor vehicles in an amount not less than
$1,000,000 combined single limit for personal and bodily injury and death. (3) Workers' Compensation
Insurance as required by state law where the Work is performed. Employer Liability insurance with
limits of at least $1,000,000 for each occurrence. (4) Umbrella/Excess Liability with limits of not
less than $5,000,000 in excess of all the above-referenced Commercial General Liability, Employer's
Liability and Business Auto Liability, except the following Subcontractor classifications will have
limits of not less than the following: HVAC $2,000,000, Landscaping and Fencing $1,000,000. Such
Umbrella/Excess Liability policies shall follow form to the terms and conditions of the underlying
coverages and shall include a drop down feature in the event any underlying limits are exhausted.
(5) EDGE and Mediacom, LLC shall be named as an additional insured. (6) All insurance must be
written on an "occurrence" basis. 10. TIME AND PROGRESS OF WORK A. Subcontractor shall commence Work
on the date(s) stipulated on each Purchase Order for each project. Subcontractor shall carry the
Work forward expeditiously according to the work schedule and with adequate forces to achieve final
completion of the Work identified on the Purchase Order. B. No extension of performance time for any
Work will be accepted without the consent of EDGE, which consent shall not be unreasonably withheld.
11. TERMINATION OF AGREEMENT A. RIGHT TO CURE/TERMINATION FOR SUBCONTRACTOR'S DEFAULT After fifteen
(15) days prior written notice to Subcontractor to cure, or additional time as may be reasonably
required by EDGE to cure the event of default, EDGE may terminate this Agreement, or any one or more
awarded Purchase Orders and take control of the Work for such terminated Purchase Orders, including
any or all materials for the Work, and may proceed with the completion of the Work as contemplated
by this Agreement by whatever method deemed expedient by EDGE upon the occurrence of any of the
following events, which shall be deemed events of a default by Subcontractor hereunder:

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 5
<!-- page 6 -->
1) Subcontractor fails to supply a sufficient number of skilled workers or suitable materials or
equipment for performance of the Work; 2) Subcontractor fails to make payments to its Lower-tier
Subcontractors or employees or laborers for labor, material or equipment; 3) Subcontractor
disregards laws, ordinances, rules, regulations or orders of any public authority; 4) Any Lower-tier
Subcontractor files a (i) notice of intention to file a construction or mechanic's lien, (ii)
mechanic's lien, or (iii) construction lien, and such filing is not removed by Subcontractor within
three (3) days after the period required by this Agreement; 5) Subcontractor makes a general
assignment for the benefit of its creditors, a receiver or liquidator shall be appointed for
Subcontractor or for any of its property, or Subcontractor or its creditors initiate bankruptcy
proceedings (11 U.S.C.A.) with respect to Subcontractor; or 6) Subcontractor otherwise violates any
provision of this Agreement. B. REMEDIES FOR SUBCONTRACTOR'S DEFAULT The cost of completion by EDGE
in the event of a termination based on the occurrence of any of the conditions specified in Section
11(A) above shall be deducted from the unpaid balance, if any, then due Subcontractor under the
Agreement. 12. SUSPENSION OF WORK EDGE shall have the right to suspend the Work in progress for a
reasonable time at the direction of Customer. Subcontractor shall resume performance of the Work at
EDGE' direction. Subcontractor may be entitled to additional compensation or damages as a
consequence of this suspension. 13. INDEMNIFICATION A. Subcontractor shall indemnify, defend and
hold harmless EDGE and Customer and both of their subsidiaries, directors, shareholders, partners,
principals (disclosed or undisclosed), employees, agents and representatives (hereinafter the
"Indemnitees") from and against any and all claims, demands, damages, actions, causes of action,
suits, losses, judgments, obligations, and any liabilities, costs and expenses, including but not
limited to, investigative and repair costs, attorney fees and costs, and consultant's fees and costs
(collective, "Claims") arising out of or in connection with the Work performed, materials furnished,
or services provided or omitted under this Agreement by Subcontractor or its agents

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 6
<!-- page 7 -->
B. These obligations to defend and indemnify shall not limit, or be limited by, the defense and/or
additional insured obligations of the Subcontractor's insurance carrier(s). C. The obligations of
this Section 13 shall survive termination of this Agreement. 14. DUE ORGANIZATION Subcontractor
certifies that it is duly organized, existing and in good standing under the laws of its state of
formation, and is duly qualified as necessary and is in good standing with respect to all
jurisdictions in which it is required to be so qualified to do business. 15. TAXES Fees are
inclusive of all taxes and similar assessments, levies and government-imposed obligations with
respect to income derived from Subcontractor's performance of the Work ("Taxes"). All Taxes shall be
the obligation of and be paid by Subcontractor. 16. PERMITS, COMPLIANCE WITH LAWS AND OTHER
AGREEMENTS Subcontractor shall obtain and maintain all licenses, permits or certificates
(collectively "Licenses") required by any applicable law in connection with Subcontractor's
performance of Work hereunder. Subcontractor represents and warrants to EDGE that Subcontractor's
performance of this Agreement will not violate any other employment, services, confidentiality,
consulting or other agreement to which Subcontractor is a party or by which it may be bound. 17.
WARRANTY A. Subcontractor warrants to EDGE that the Work will be performed with promptness and
diligence and shall be executed in a quality manner consistent with workmanship standards in the
particular trades involved. B. EDGE may accept any nonconforming Work instead of requiring its
removal and correction upon the condition that Subcontractor shall pay EDGE an appropriate amount
for damages and compensation as is mutually agreed upon by EDGE and Subcontractor. Warranty is not
waived under such conditions. C. If within one (1) year from the date of completion of Work
acceptance, or within one (1) year from the completion of all other work or services and acceptance
by EDGE (or within any longer materials warranty period as set forth above), any defects exists or
arise, then in each case upon receipt of notice of such defect, Subcontractor shall (unless EDGE
chooses another remedy) promptly cause such defect(s) to be repaired or remedied at Subcontractor's
sole cost and expense, including but not limited to the costs of transportation, uncovering,
removal, disposal, replacement, correction, installation and covering. Subcontractor shall commence
or cause the commencement of repairs immediately upon receipt of notice from EDGE and thereafter
diligently pursue same to completion or cause the same to be diligently pursued to completion. EDGE
shall have the right without prejudice to any other rights or remedies available to it, (i) to make
such repairs and offset the cost thereof against any amounts owed to be paid by EDGE to
Subcontractor or invoice Subcontractor therefore which invoice shall be paid net 30 days or (ii)
require Subcontractor to refund the price of the Work not meeting the warranties. Subcontractor will
extend the warranty period if Subcontractor has been grossly negligent in the performance of any
Work under this Agreement. Notwithstanding anything to the contrary contained in this Agreement,
Subcontractor shall not be liable or responsible for any defect in any materials used by
Subcontractor if such defect was not due to Subcontractor's acts or omissions.

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 7
<!-- page 8 -->
D. These warranties extend to the future performance of the materials and shall continue for the
longer of (a) the warranty period applicable to EDGE' sales to Customer of the material or of
products which incorporate the material, (b) one year after the material is accepted by EDGE or (c)
such greater period as may be specified elsewhere in this Agreement. Repaired and replacement
material shall be warranted as set forth above in this clause. 18. PROTECTION OF PERSONS AND
PROPERTY A. Subcontractor represents and warrants (i) that Subcontractor has experience in the type
of Work to be performed and in the occupational safety and health practices that are required for
that type of work; (ii) that Subcontractor's employees are properly trained and equipped to perform
the Work; (iii) that Subcontractor is aware of the risks inherent in performing such Work and
Subcontractor expressly assumes the risk of loss or injury that may result from the Work. B.
Subcontractor shall comply with all applicable laws (including, without limitation the Federal
Occupational Safety and Health Act, Hazardous Communication Requirements, and all applicable
environmental protection laws, rules, regulations and ordinances), ordinances, rules, regulations
and lawful orders of any public authority having jurisdiction for the safety of persons or property
or to protect them from damage, injury or loss. Subcontractor shall comply with all occupational
safety and health requirements, including such related publications (not included; but incorporated
herein by reference): · National Electrical Code Handbook, most recent edition. · Occupational
Safety and Health Administration Handbook. · National Electrical Safety Code, most recent edition. ·
All System pole attachment agreements. · Applicable utility practices of states named, General Order
#95 and General Order #128. C. Without limitation of the Subcontractor's obligations regarding
safety and protection, Subcontractor shall:

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 8
<!-- page 9 -->
1) Confine operations at the site to areas permitted by law, ordinances, permits, this Agreement and
the Purchase Orders; 2) erect and maintain, as required by existing conditions and performance of
the Work, safeguards for safety and protection, including posting danger signs and other warnings
against hazards, promulgating safety regulations and notifying owners and users of adjacent sites
and utilities; 3) not unreasonably encumber the site with materials or equipment or load or permit
any part of the construction or site to be loaded so as to endanger its safety; 4) not bring
hazardous materials onto the site without prior written authorization by EDGE; 5) exercise utmost
care and carry on its activities under supervision of properly qualified personnel, when use or
storage of explosives or other hazardous materials or equipment or unusual methods are necessary for
execution of the Work; and 6) dispose of any hazardous materials in accordance with applicable law.
D. Without limitation of Subcontractor's obligation under this Agreement, the Subcontractor shall
indemnify EDGE as identified in Section 13 for any Claims caused by hazardous materials. 19. CLEAN
UP Subcontractor shall at all times keep the Work premises free from accumulations of waste
material, rubbish, and any other debris resulting from the Work. On an ongoing basis as the Work
progresses, and at the completion of the Work, Subcontractor shall restore to essentially its former
condition, and to the satisfaction of EDGE, all aspects of the Work site and shall remove all waste
and excess materials, tools, and equipment resulting from or used in the Work and legally dispose
thereof. All costs and expenses of any type for cleanup, restoration, and removal noted above will
be borne by Subcontractor at no cost to EDGE. If Subcontractor fails in its duties under this
clause, EDGE may upon notice to Subcontractor perform the necessary clean up and deduct the costs
thereof from any amounts due or to become due to Subcontractor or invoice Subcontractor therefore,
which invoice shall be paid net 30 days. Manholes, cable vaults, and central office Work areas will
be cleared of all litter by Subcontractor on a daily basis where Work is being performed. 20. NOTICE
OF MATERIAL DEFECTS Subcontractor agrees to promptly notify EDGE upon learning of any material
defect, misstatement or omission in rendering any Work.

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 9
<!-- page 10 -->
21. WAIVER The waiver by either party of any breach of this Agreement by the other party in a
particular instance shall not operate as a waiver of subsequent breaches of the same or different
kind. The failure of either party to exercise any rights under this Agreement in a particular
instance shall not operate as a waiver of the party's right to exercise the same or different rights
in subsequent instances. 22. NOTICES A. Any written notice or demand which under the terms of this
Agreement or under any statute must or may be given or made by EDGE or Subcontractor shall be in
writing and addressed to the respective parties as stated in this Agreement. Notice shall be sent by
certified, registered or express mail, other overnight delivery service, or shall be hand delivered.
Written notice by facsimile shall satisfy the notice requirements of this Agreement where the
individual to whom the facsimile is addressed acknowledges receipt of such notice by return
facsimile or other means as provided in this Section. The addresses below may be changed at any time
by giving prior written notice as above provided. TO: TO: EDGE Communications Solutions, LLC FTE
Networks, Inc. Attn: Mark Miller, EVP - Operations Attn: General Counsel 6505 Windcrest Drive 999
Vanderbilt Beach Blvd Suite 200 Suite 601 Plano, TX 75024 Naples, FL 34108 Such notice shall be
deemed to have been given or made when actually received or seventy-two (72) hours after being sent
as specified above, whichever occurs first. 23. ASSIGNMENT Subcontractor shall not assign any right
or interest under this Agreement (excepting monies due, or to become due) or delegate or subcontract
any Work or other obligation to be performed or owed under this Agreement without prior consent of
EDGE. Notwithstanding, Subcontractor may delegate or assign Work under this Agreement to a
subsidiary operating entity. All Work performed by Subcontractor's Lower- tier Subcontractors shall
be deemed Work performed by Subcontractor. 24. BINDING EFFECT This Agreement shall bind and inure to
the benefit of the parties hereto and their respective heirs, legal representatives, successors and
permitted assigns.

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 10
<!-- page 11 -->
25. CHOICE OF LAW/FORUM The construction, interpretation, and performance of this Agreement and all
transactions under it shall be governed by the laws of the State of Texas, irrespective of its
conflict of law principles. Subcontractor and EDGE shall not be obligated to resolve by arbitration
any claim or dispute related to the Agreement. It is mandatory that any controversy or claim arising
out of or relating to the Agreement or the breach thereof shall be subject to the jurisdiction of
the State of Texas and the venue shall be exclusively in Collin County, Texas for resolution. 26.
TEXAS ALTERNATIVE DISPUTE RESOLUTION All claims, disputes and other matters in question arising out
of or relating to this subcontract with a breach thereof, except for claims which have been waived
by the making or acceptance of final payment, shall be decided by mediation or non-binding
arbitration pursuant to the Texas Arbitration Dispute Resolution Act, (Texas Practice and Remedies
Code, Chapter 154), and in accordance with the construction industry rules then in effect unless the
parties mutually agree otherwise. Each party shall pay its own legal and other costs relating to the
mediation or the non- binding arbitration regardless of the outcome of the mediation or the
non-binding arbitration. 27. LEGAL JURISDICTION/ VENUE The Parties: (a) consent to the exclusive
venue the State of Texas, Collin County, in any action arising out of or relating to this Agreement
including the jurisdiction and venue in connection with Paragraph 26 : TEXAS ALTERNATIVE DISPUTE
RESOLUTION ACT; (b) waive any objection they might have to jurisdiction or venue of such forums or
that the forum is inconvenient; and (c) agree not to bring any such action in any other jurisdiction
or venue to which either party might be entitled by domicile or otherwise. 28. ATTORNEY'S FEES In
the event that a dispute arises with respect to this Agreement, the party prevailing in such dispute
shall be entitled to recover all expenses, including, without limitation, reasonable attorneys' fees
and expenses, incurred in ascertaining such party's rights under this Agreement, whether or not it
was necessary for such party to institute suit. 29. NUMBER AND GENDER Whenever the singular number
is used in this Agreement and when required by the context, the same shall include the plural. The
masculine gender shall include the feminine and neuter genders, and the word "person" shall include
a corporation, firm, partnership, or other form of association.

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 11
<!-- page 12 -->
30. ENTIRE AGREEMENT; INCONSISTENCIES A. This Agreement shall incorporate the typed or written
provisions of EDGE' Purchase Orders issued pursuant to this Agreement and shall constitute the
entire agreement between the parties with respect to the subject matter of this Agreement and shall
not be modified or rescinded except by a writing signed by Subcontractor and EDGE. All references in
these terms and conditions to this Agreement or to Work, services, material, equipment, products,
software, or information furnished under, in performance of, pursuant to, or in contemplation of
this Agreement shall also apply to any Purchase Orders or Amendments issued pursuant to this
Agreement. All provisions on Subcontractor's forms shall be deemed deleted. Additional or different
terms inserted in this Agreement by Subcontractor, or deletions thereto, whether by alterations,
addenda, or otherwise, shall be of no force and effect, unless expressly consented to by EDGE in
writing. The provisions of this Agreement supersede all contemporaneous oral agreements and all
prior oral and written quotations, communications, agreements, and understandings of the parties
with respect to the subject matter of this Agreement. B. The documents referenced in this Agreement
are complementary, and what is called for by any one shall be as binding as if called for by all.
The intention of the Agreements, Exhibits, and Purchase Order (collectively "Contract Documents") is
to include all labor, materials, supervision, equipment, transportation and expense necessary for
the proper execution of the Work; performance by Subcontractor shall be required to the extent
consistent with the Contract Documents to produce the intended results. If a conflict or
inconsistency exists between the provisions of this Agreement, the pre-printed terms and conditions
on either side of the Purchase Order, any other document, the order of precedence to resolve the
conflict or inconsistency is as follows: (a) the Agreement; (b) Exhibits to the Agreement; (c)
Purchase Orders; and (d) drawings and specifications. In the event of an irreconcilable conflict,
discrepancy, error, or omission, the provision imposing the greater duty on Subcontractor shall
apply. Materials or work described in words that have a well-known technical or trade meaning shall
be held to refer to such recognized standards. 31. SEVERABILITY If any provision of this Agreement
is illegal or unenforceable, its invalidity shall not affect the other provision of this Agreement
that can be given effect without the invalid provision. If any provision of this Agreement does not
comply with any law, ordinance or regulation, such provision to the extent possible shall be
interpreted in such a manner to comply with such law, ordinance or regulation, or if such
interpretation is not possible, it shall be deemed to satisfy the minimum requirements thereof. All
provisions required by law shall be deemed incorporated herein by reference.

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 12
<!-- page 13 -->
32. AMENDMENT This Agreement may be amended or modified only by a written instrument executed by
both EDGE and Subcontractor. 33. RIGHT OF REPLACEMENT EDGE may, upon reasonable request, require
Subcontractor to replace any personnel, including a project manager, deployed by Subcontractor under
the terms of this Agreement. Subcontractor will replace any personnel promptly after request from
EDGE with an employee of Subcontractor reasonably acceptable to EDGE. 34. NON-SOLICITATION
Subcontractor, during the term of this Agreement and for a period of one year thereafter, shall not,
directly or indirectly, for itself or on behalf of or in conjunction with any other person,
partnership, corporation, business or organization, solicit, hire, contract with or engage the
employment of an employee of EDGE with whom Subcontractor or its personnel have contact as a result
of Subcontractor's performance of this Agreement, unless Subcontractor (i) obtains the written
consent of EDGE, as applicable, and (ii) pays EDGE as applicable a fee to be mutually agreed upon.
In the event Subcontractor directly employs or contracts with an employee of EDGE without the
consent of EDGE, Subcontractor shall pay as liquidated damages two times the then monthly salary of
the employee for a three-month period of time.

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 13
<!-- page 14 -->
35. DOCUMENT OWNERSHIP AND CONFIDENTIALITY AND USE OF INFORMATION Each party may make available
("Disclosing Party") to the other ("Receiving Party") access to certain information whether of a
technical, business or other nature, including without limitation trade secrets, know-how and
information relating to the technology, Customers, business plans, promotional and marketing
activities, finances and other business affairs of such Party (collectively, "Confidential
Information"). So long as and to the extent that Confidential Information is clearly and
identifiably marked "Confidential" or "Proprietary" (if in tangible form) or is not generally
available to the public from other sources, each Party shall safeguard such Confidential Information
in the manner in which it safeguards its own confidential information, and shall not disclose
Confidential Information to its employees, Lower-tier Subcontractors and agents, except to the
extent necessary to enable it to fulfill its obligations under this Agreement. The Parties
obligations set forth in this Section shall not apply with respect to any portion of the
Confidential Information that the Receiving Party can document by competent proof that such portion:
(a) was in public domain at the time it was communicated to the Receiving Party by the Disclosing
Party; (b) entered the public domain through no fault of the Receiving Party, subsequent to the time
it was communicated to the Receiving Party by the Disclosing Party; (c) was in Receiving Party's
possession free of any obligation of confidence at the time it was communicated to Receiving Party
by Disclosing Party; (d) was developed by employees or agents of Receiving Party independently of
and without reference to any information communicated to Receiving Party by Disclosing Party; or (e)
was communicated by Disclosing Party to an unaffiliated third party free of any obligation of
confidentiality. In addition, Receiving Party may disclose the Disclosing Party's Confidential
Information in response to a valid court order by a court or other governmental body, as otherwise
required by law. All Confidential Information furnished to the Receiving Party by the Disclosing
Party is the sole and exclusive property of the Disclosing Party or its suppliers or Customers. This
Paragraph shall survive termination of this Agreement. END OF DOCUMENT [SIGNATURES ON FOLLOWING
PAGE]

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 14
<!-- page 15 -->
IN WITNESS WHEREOF, EDGE AND FTE HAVE EXECUTED THIS AGREEMENT AS OF THE DATE FIRST ABOVE WRITTEN.
EDGE Communications Solutions, LLC FTE Networks, Inc. BY: /s/ Mark Miller BY: /s/ Carlie Ancor NAME:
Mark Miller NAME: Carlie Ancor TITLE: Executive Vice-President - Operations TITLE: Chief Technology
Officer

STRATEGIC ALLIANCE AGREEMENT "EDGE-FTE" Page 15
