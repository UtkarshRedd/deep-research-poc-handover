<!-- page 1 -->
# VIDEO-ON-DEMAND CONTENT LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2006-07-11 |
| Parties | Rogers Cable Communications Inc. ("Rogers"); EuroMedia Holdings Corp. ("Licensor") |
| Source | CUAD v1 / EuromediaHoldingsCorp_20070215_10SB12G_EX-10.B(01)_525118_EX-10.B(01)_Content License Agreement |

Exhibit 10.B.01 EXECUTION COPY

VIDEO-ON-DEMAND CONTENT LICENSE AGREEMENT between Rogers Cable Communications Inc. ("Rogers") and
EuroMedia Holdings Corp. ("Licensor") offering EurocinemaSM Video-on-Demand service made as of July
11 , 2006 (the "Effective Date") (the "Agreement")

1. RIGHTS GRANTED Licensor grants to Rogers the non-exclusive license and right to distribute and
exhibit in Canada (the "Territory") all entertainment programming to which Licensor owns or controls
the VOD distribution and exhibition rights in the Territory (collectively, "Licensed Programs") to
residential subscribers of Rogers' digital cable television service on a Video-on-Demand ("VOD")
basis. For clarity, the VOD service that Rogers provides to such subscribers shall hereinafter be
referred to as the "ROD Service". 2. LICENSED PROGRAMS. (a) Subject to Section 3, Licensor shall
forthwith provide to Rogers a comprehensive list (including title, length of program, license period
and availability date) of all currently available Licensed Programs. During the Term, Licensor shall
use best efforts to add newly available Licensed Programs to such list, and may periodically delete
Licensed Programs from such list; provided, however, that: (i) Licensor shall provide to Rogers at
least ninety (90) days prior notice of the availability date of any Licensed Program added to such
list during the Term; (ii) Licensor shall provide to Rogers at least sixty (60) days prior notice of
the deletion of any Licensed Program from such list; and (iii) Licensor shall be responsible for any
and all reasonable costs and/or losses incurred by Rogers as a result of any deletions from such
list during the Term. (b) Rogers reserves the right, in its sole discretion, to determine which
Licensed Programs to distribute and exhibit on the ROD Service and, without limiting the generality
of the foregoing, may decline to distribute or exhibit any Licensed Program that it determines, in
its sole discretion, is unsuitable for distribution or exhibition on the ROD Service. (c) Licensor
shall use commercial reasonable efforts to provide Rogers with Licensed Programs with closed
captioning. 3. AVAILABILITY DATE. (a) Subject to Section 3(b), the availability date for any
Licensed Program that is a feature-length motion picture or direct-to-video product shall be no
later than ninety (90) days following the date on which such Licensed Program is made available for
home video distribution within the U.S or the Territory.

Source: EUROMEDIA HOLDINGS CORP, 10SB12G, 2/15/2007
<!-- page 2 -->
(b) In the event that Licensor grants to another VOD or Pay-Per-View ("PPV") service provider in the
U.S. or the Territory the right to distribute or exhibit any Licensed Program on an earlier
availability date, then Licensor shall also grant to Rogers the right to distribute and exhibit such
Licensed Program on such earlier availability date, on the terms provided herein. (c) Licensor shall
not authorize the distribution or exhibition of any Licensed Program by any other means, including,
without limitation, television (other than PPV) and internet, for a period of ninety (90)
consecutive days following such Licensed Program's VOD availability date. 4. LICENSE PERIOD. During
the Term, Rogers shall have the non-exclusive right to distribute and exhibit each Licensed Program
on a VOD basis for a period of ninety (90) consecutive days, or such longer period as may be agreed
to by Rogers and Licensor (the "License Period"). 5. VIEWING PERIOD. The viewing period for each
Licensed Program shall be at least twenty-four (24) consecutive hours, or such longer period as may
be agreed to by Rogers and Licensor from time to time (the "Viewing Period"). Multiple viewings of
the Licensed Program shall be permitted during the Viewing Period for no additional fee and all such
viewings shall be considered a single exhibition of the Licensed Program for the purposes of
calculating License Fees hereunder. 6. LICENSE FEES. (a) Rogers shall pay to Licensor a fee (the
"License Fee"), which shall be equal to fifty (50)% of Retail Revenues. For the purposes of this
Agreement, "Retail Revenues" means the retail revenues actually received by Rogers for each
authorized exhibition of a Licensed Program on the ROD Service, less GST and applicable sales tax.
For greater certainty, Retail Revenues shall not include any fees payable to Rogers for: (i) the
purchase, rental or installation of a digital terminal; (ii) any basic or premium television
services; or (iii) digital cable access. (b) Notwithstanding Section 6(a) above, (i) Prior to
calculating License Fees, Rogers shall be entitled to deduct from Retail Revenues on a rolling
monthly basis during the Term ("Rogers Costs"): (A) the value of programming credits, rebates or
other retail price discounts provided to ROD Service subscribers in conjunction with a public
marketing or promotional initiative; -2-

Source: EUROMEDIA HOLDINGS CORP, 10SB12G, 2/15/2007
<!-- page 3 -->
(B) the value of refunds provided by Rogers to ROD Service subscribers for technical or other errors
during such month; (C) the percentage equal to Rogers' average year-to-end bad debt exposure
(including credit collection costs) for the then current calendar year in respect of all Rogers'
cable television subscribers (expressed as a percentage) (D) encoding costs incurred by Rogers, if
applicable, pursuant to Section 8 (a) ; and (E) closed captioning costs incurred by Rogers to comply
with Applicable Law. (ii) Rogers shall be entitled to deduct from License Fees on a rolling monthly
basis during the Term: (A) the marketing allowance pursuant to Section 12; (B) the Production Fund
Commitment pursuant to Section 13; and (C) copyright royalty payments pursuant to Section 17. (c)
Payment of License Fees shall be made in Canadian funds in arrears within thirty (30) days following
each calendar month during the Term in which Licensed Programs were exhibited hereunder and shall be
accompanied by a statement of account showing the calculation of the License Fees. (d) In the event
that Retail Revenues in a particular month are not sufficient to fully reimburse Rogers for the
Rogers Costs incurred in such month, Rogers shall be entitled to recover such amounts against Retail
Revenues generated by other Licensed Programs in subsequent months. (e) There shall be no minimum
License Fee or retail viewing fee with respect to any Licensed Program. Additionally, Rogers shall
not be required to pay any License Fees for VOD exhibitions of any Licensed Program occurring on or
off premises that are made for the purposes of quality assurance or testing. (f) Rogers shall be
entitled to withhold from License Fees applicable withholding taxes and to remit same to the
responsible taxing authorities, as required by Applicable Law. 7. TERM. The term of this Agreement
(the "Initial Term") shall commence as of the Effective Date and, unless earlier terminated in
accordance with this Agreement, shall terminate on June 30, 2010. At Rogers' option, this Agreement
shall renew for a subsequent term of two (2) years on the terms and conditions herein (the "Renewal
Term"). Notwithstanding the foregoing, if, at the expiry of this Agreement following the Initial
Term or the Renewal Term (if any), as applicable, Licensor and Rogers have not executed a new
agreement governing the VOD distribution and exhibition of Licensed Programs and Rogers (or its
permitted assigns) continues to distribute and exhibit Licensed Programs on the ROD Service
following such expiry, such continued distribution and exhibition shall be governed by the terms of
this Agreement in effect at the time of expiry, except that each of Licensor and Rogers shall have
the right, on sixty (60) days' prior written notice, to terminate this Agreement, as so extended.
For greater certainty, all references to "Term" in this Agreement shall include the Initial Term,
the Renewal Term (if any) and any period during which this Agreement continues following its expiry
in accordance with this Section. -3-

Source: EUROMEDIA HOLDINGS CORP, 10SB12G, 2/15/2007
<!-- page 4 -->
8. ENCODING AND DELIVERY OF LICENSED PROGRAMS. (a) Licensor shall, at its sole expense, encode each
Licensed Program selected for distribution and exhibition by Rogers hereunder and shall deliver such
fully encoded Licensed Program to Rogers on a DLT master tape, DVD-R disc or other master
pre-recorded format acceptable to Rogers (each, a "Master") at least thirty (30) days prior to the
availability date for such Licensed Program. Such Masters shall at all times remain the sole
property of Licensor and, within fifteen (15) days following the termination or expiration of this
Agreement, Rogers shall either return to Licensor all such Masters then in its possession, or issue
a certificate of erasure. (b) To the extent any Master delivered by Licensor hereunder is determined
by Rogers, in its sole discretion, acting reasonably, to be defective: (i) Licensor shall forthwith
provide Rogers with a replacement Master; and (ii) if Rogers is unable to distribute and/or exhibit
the Licensed Program on the availability date as a result of the defectiveness of any such Master,
the License Fee payable in respect of such Licensed Program shall be reduced by 10% for the balance
of the License Period. 9. TECHNICAL STANDARDS. In carrying out its obligations hereunder, Licensor
agrees to comply with Rogers' technical standards for materials, as specified by Rogers from time to
time. Licensor hereby acknowledges receipt of a copy of or website link to CableLabs technical
specifications. 10. MARKETING AND PROMOTION. (a) Licensor shall provide, at its sole expense and on
a timely basis, promotional materials and trailers for each Licensed Program selected for
distribution and exhibition by Rogers hereunder, for use by Rogers to advertise and promote the
availability of such Licensed Program on the ROD Service. Such promotional materials shall include,
but not be limited to: (i) a promotional poster image or related film content in an electronic
format; (ii) relevant metadata; (iii) trailer of Licensed Program in an encoded format; and (iv)
title and related data. -4-

Source: EUROMEDIA HOLDINGS CORP, 10SB12G, 2/15/2007
<!-- page 5 -->
(b) Licensor shall make available to Rogers, on a free trial basis and at no cost to Rogers, not
less than ten (10) Licensed Programs at all times during the Term (each, a "Promotional Program")
for distribution and exhibition on the ROD Service to promote the Licensed Programs and the ROD
Service. Licensor shall refresh the Promotional Programs at a frequency rate to be mutually agreed
upon in writing by Rogers and Licensor. (c) Licensor acknowledges and agrees that Rogers shall be
entitled to insert a minimum of four (4) minutes of promotional materials per thirty (30) minutes of
Promotional Programs. Rogers shall ensure that at least 75% of such promotional materials directly
or indirectly promotes the Licensed Programs. (d) Licensor shall use commercially reasonable efforts
to promote the ROD Service through Licensor's consumer-facing advertising and promotional mediums
within the Territory. Such mediums shall include, but not be limited to: (i) television; (ii) radio;
(iii) print; (iv) Internet; and (v) event-based marketing. Licensor will deliver accurate,
representative samples of all such advertising and promotions to Rogers at least five (5) business
days in advance for Rogers' prior review and approval. 11. GUI/EPG. Licensor, at its sole expense
and on a timely basis, shall provide complete, accurate and informative listing and descriptive
information in respect of each Licensed Program selected for distribution and exhibition by Rogers
hereunder (including, without limitation, synopsis, theme, rating, closed captioning and such other
information as may be appropriate or otherwise required by Rogers) to Rogers' graphic user interface
("GUI") or electronic programming guide provider ("EPG"), as the case may be, as designated by
Rogers from time to time. 12. MARKETING ALLOWANCE. In consideration for various services and
activities that Rogers performs for the benefit of Licensor during the Term, Licensor agrees to pay
to Rogers an amount which shall be equal to ten (10)% of License Fees, calculated on a rolling basis
during the Term and payable monthly. 13. PRODUCTION FUND. For so long as Rogers is required by
Applicable Law to contribute a percentage of its gross annual revenues from the ROD Service to an
independently-administered Canadian program production fund, Licensor shall reimburse Rogers for 50%
of the amount required to be remitted to such production fund by Rogers in respect of the exhibition
of Licensed Programs (the "Production Fund Commitment"). The Production Fund Commitment shall be
calculated monthly during the Term and shall be deducted as set out in Section 6 (b). -5-

Source: EUROMEDIA HOLDINGS CORP, 10SB12G, 2/15/2007
<!-- page 6 -->
14. REPRESENTATIONS AND WARRANTIES. (a) Each of Rogers and Licensor represents and warrants to the
other that it has the necessary power and authority to enter into this Agreement and to fully
perform its obligations hereunder. (b) Licensor represents, warrants and covenants to Rogers that:
(i) it is validly incorporated under the laws of The State of Florida, USA (ii) it has obtained, and
shall maintain throughout the Term, all necessary rights, clearances and authorizations to enter
into this Agreement and fully perform its obligations hereunder in compliance with Applicable Law
and, in particular, to permit Rogers to distribute and exhibit the Licensed Programs on a VOD basis
in the Territory; (iii) it has obtained, and shall maintain throughout the Term, all approvals
and/or ratings from provincial authorities necessary to distribute and exhibit each Licensed
Program, trailer and other promotional materials provided to Rogers hereunder; (iv) it unilaterally
owns or controls the VOD distribution and exhibition rights to all Licensed Programs within the
Territory; and (v) it has obtained, and shall maintain throughout the Term, all necessary rights to
any equipment and/or technology used to provide the encoding services hereunder and its use of such
services shall not violate the rights of any third party. 15. INDEMNIFICATION. (a) Licensor shall
indemnify Rogers and its affiliates from and against any and all claims, damages, liabilities, costs
and expenses (including, without limitation, reasonable legal fees) arising out of or caused by: (i)
any breach by Licensor of any material term of this Agreement; (ii) the content of any Licensed
Program, trailer and/or other promotional materials provided by Licensor to Rogers hereunder
(including, without limitation, any libelous, slanderous or obscene material, violations of
copyright, trade- mark rights or other intellectual property rights, personality right, right of
privacy or literary or dramatic right); and (iii) any encoding or other services provided by
Licensor hereunder. -6-

Source: EUROMEDIA HOLDINGS CORP, 10SB12G, 2/15/2007
<!-- page 7 -->
(b) Rogers shall indemnify Licensor and its affiliates from and against any and all claims, damages,
liabilities, costs and expenses (including, without limitation, reasonable legal fees) arising out
of or caused by: (i) any breach by Rogers of any material term of this Agreement; and (ii) any claim
by a Rogers customer, except a claim related to the content of any Licensed Program, trailer and/or
other promotional materials provided by Licensor to Rogers hereunder. (c) This Section shall survive
the termination or expiration of this Agreement. 16. LIMITATION OF LIABILITY. Except with respect to
any claim or liability arising from an infringement of any third party intellectual property right,
in no event shall either party be liable for any special, indirect, consequential, punitive or
incidental damages of any kind. This Section shall survive the termination or expiration of this
Agreement. 17. COPYRIGHT ROYALTY PAYMENTS. For so long as Rogers is required by Applicable Law to
pay copyright royalties relating to Licensed Programs hereunder, Licensor shall reimburse Rogers for
50% of any such royalties actually paid by Rogers, calculated on a rolling basis during the Term and
payable monthly. This Section shall survive the termination or expiration of this Agreement. 18.
ROGERS' TERMINATION RIGHTS. Notwithstanding any other provision of this Agreement, Rogers may
terminate this Agreement, at any time, upon sixty (60) days' prior written notice to Licensor. 19.
MUTUAL TERMINATION RIGHTS. Either Rogers or Licensor may, at its option and without prejudice to any
other remedies available to it, immediately terminate this Agreement by giving written notice
thereof to the other party for any one or more of the following causes: (a) the other party defaults
in the performance or observance of any of the material terms of this Agreement and such default
continues for a period of thirty (30) days after written notice thereof; (b) if, at any time, an
order is made or an effective resolution is passed for the winding-up, liquidation or dissolution of
the other party that is not immediately stayed by appeal; (c) if, at any time, the other party
consents to or makes a general assignment for the benefit of creditors, or makes a proposal under,
or takes advantage of, any insolvency, restructuring or reorganization legislation, or is declared
bankrupt, or if a liquidator, trustee in bankruptcy, custodian or receiver and manager or other
officer with similar powers is appointed of the other party or of all or substantially all of the
other party's property which is not immediately stayed by appeal; or -7-

Source: EUROMEDIA HOLDINGS CORP, 10SB12G, 2/15/2007
<!-- page 8 -->
(d) Rogers, or any person to whom Rogers has assigned, sold or transferred this Agreement, ceases to
offer the ROD Service. 20. EFFECT OF TERMINATION. If either party terminates this Agreement prior to
its expiration, Rogers shall be entitled to continue to distribute and exhibit all Licensed Programs
then being distributed and exhibited on the ROD Service, in each case, for a period of sixty (60)
days from the effective date of termination or the expiry of the relevant License Period, whichever
is earlier, and, in such event, Rogers shall continue to be bound by its payment obligations set
forth herein in respect of such Licensed Programs. This Section shall survive the termination of
this Agreement for a period of sixty (60) days. 21. MOST FAVOURED NATIONS. If Licensor enters, or
has entered, into an agreement or series of agreements (including side letters, understandings or
arrangements, whether oral or written, whether formal or informal, whether now or hereafter
effective, or whether on a long-term basis or short-term basis) with a third party for the
distribution and exhibition of Licensed Programs in the U.S. or the Territory on a VOD basis, or any
other basis that permits the downloading of such Licensed Programs and the subsequent viewing of
such Licensed Programs by a residential subscriber, on terms (including, without limitation, license
fees, copyright royalty payments, encoding fees and obligations, and marketing support) that are
more favourable than those contained in this Agreement, then Rogers has the right to incorporate, or
substitute, as the case may be, such term or terms into this Agreement, effective as of the date on
which such term or terms were accorded to the third party and for the balance of the period such
term or terms are applicable to such third party. Licensor shall provide to Rogers, no later than
February 28 in each year, a sworn statement of a senior officer of Licensor, or a certificate of the
auditors of Licensor, confirming that, during the immediately preceding calendar year, Licensor did
not enter into such an agreement or series of agreements or, if it did enter into such agreement(s),
confirming the effective date thereof and identifying the terms contained therein that are more
favourable than those contained in this Agreement. During the Term, and for a period of twelve (12)
months thereafter, Rogers (and its representatives) shall have the right, upon reasonable prior
written notice to Licensor, and during regular business hours, to inspect and/or audit Licensor's
books and records to confirm compliance with Licensor's obligations under this Section. This Section
shall survive the expiry or other termination of this Agreement for a period of twelve (12) months.
-8-

Source: EUROMEDIA HOLDINGS CORP, 10SB12G, 2/15/2007
<!-- page 9 -->
22. CONFIDENTIALITY AND OWNERSHIP. (a) Rogers and Licensor each agree to maintain the provisions of
this Agreement in the strictest confidence, except that the parties may disclose such terms to their
affiliates, their respective professional advisors and, in such event, to the extent necessary to:
(i) enforce their respective rights hereunder; (ii) comply with the valid order of an administrative
agency or court of competent jurisdiction, or with any Applicable Law; and (iii) comply with
contractual obligations owed to third parties; provided, however, that, in the case of any
disclosure pursuant to items (ii) or (iii) above, (A) the disclosing party shall notify the other
party as soon as practicable (and if possible prior to disclosure) and (B) any information so
disclosed shall be redacted to the greatest extent possible. (b) Each party agrees to use the other
party's confidential information solely for the purpose of fulfilling its obligations under this
Agreement, to hold the other party's confidential information in confidence and to protect the
confidentiality of such confidential information using the same degree of care as it uses to protect
its own confidential information of a like nature, which shall, in any event, be no less than a
degree of care consistent with industry standards. Notwithstanding the foregoing, the receiving
party may disclose confidential information to the extent required to comply with the valid order of
an administrative agency or court of competent jurisdiction, or with any Applicable Law (provided
that the receiving party shall notify the other party as soon as practicable (and if possible prior
to disclosure) and any information so disclosed shall be redacted to the greatest extent possible).
(c) Rogers shall own all data and information relating to Rogers' subscribers, including, without
limitation, all personal and demographic information, all information relating to an individual
subscriber's use of the ROD Service and all aggregate information relating to the use by Rogers'
subscribers of the ROD Service (collectively, "Rogers Subscriber Information"). Licensor
acknowledges that Rogers Subscriber Information constitutes valuable assets of Rogers and agrees to
hold all Rogers Subscriber Information strictly confidential in accordance with the provisions set
forth in Section 22(b) above. (d) This Section shall survive the termination or expiration of this
Agreement. 23. GOVERNING LAW. This Agreement shall be governed by laws of the Province of Ontario
and the federal laws of Canada applicable therein. The parties hereby attorn to the non-exclusive
jurisdiction of the courts of the Province of Ontario. This Section shall survive the termination or
expiration of this Agreement. 24. ASSIGNMENT. This Agreement may not be assigned, sold or
transferred without the prior written consent of the other party. Notwithstanding the foregoing,
Rogers may, without consent, assign its rights and obligations under this Agreement in whole or in
part to: (i) a person that directly or indirectly controls, is controlled by or is under common
control with Rogers; or (ii) a purchaser of all or substantially all of the assets used in
connection with the ROD Service. A change of control of Rogers shall not be considered an assignment
of this Agreement. Any purported assignment, sale, or transfer in contravention of this Section
shall be null and void. -9-

Source: EUROMEDIA HOLDINGS CORP, 10SB12G, 2/15/2007
<!-- page 10 -->
25. FORCE MAJEURE. Neither party shall be liable to the other for temporary failure to perform
hereunder, if such failure is caused by reason of an Act of God, tempest, satellite circuit failure,
labour dispute, strike, temporary or permanent breakdown of facilities, fire, flood, Applicable Law,
civil disturbance, or any other cause beyond the parties' respective control. In the event of any
force majeure which continues for a period of thirty (30) days or more, the party not immediately
affected by such force majeure event may, upon notice to the other party, terminate this Agreement.
26. NOTICES. Any notice, request, demand, consent or other communication (collectively a "Notice")
provided or permitted hereunder shall be in writing and given by personal delivery (against
receipt), or sent by registered mail (against receipt) postage prepaid, or transmitted by facsimile
(provided that a hard copy is immediately sent by registered mail), addressed to the other party for
which it is intended at its address below: To Rogers: Rogers Cable Communications Inc. 333 Bloor
Street East Toronto, Ontario M4W 1G9 Attention: Vice-President, General Manager, Television FAX:
(416) 935-4600 with a copy to: Rogers Communications Inc. 333 Bloor Street East Toronto, Ontario M4W
1G9 Attention: Vice-President, General Counsel FAX: (416) 935-3548 To Licensor: Sebastien Perioche
Eurocinema 1395 Brickell Ave., Suite 800, Miami, FL 33131, 305-529-6220 FAX: 305-529-6201

-10-

Source: EUROMEDIA HOLDINGS CORP, 10SB12G, 2/15/2007
<!-- page 11 -->
Any Notice given pursuant to this Agreement shall make specific reference to this Agreement. Any
Notice so given shall be deemed to have been received on the date on which it was delivered in
person, or transmitted, if delivered or transmitted on a day, other than a Saturday, on which the
Toronto-Dominion Bank in Toronto is open for business (a "Business Day") during normal business
hours of the recipient and, if not so delivered or transmitted, on the next Business Day or, if sent
by registered mail, on the fifth (5t h) Business Day thereafter; provided, however, that either
party may change its address and/or facsimile number for purposes of receipt of any such
communication by giving ten (10) days prior written notice of such change to the other party in the
manner prescribed above. 27. APPLICABLE LAW. This Agreement is subject to all laws, regulations,
license conditions and decisions of the Canadian Radio-television and Telecommunications Commission
("CRTC") municipal, provincial and federal governments or other authorities which are applicable to
Rogers and/or Licensor, and which are now in force or hereafter adopted ("Applicable Law"). In the
event that any such law, regulation or decision comes into force during the Term concerning the
subject matter of this Agreement, such that it prevents or diminishes either party's ability to
perform under this Agreement, the parties agree to enter into good faith negotiations to amend this
Agreement, where required, in order to remedy such diminution of or inability to perform. 28.
SET-OFF. Rogers shall be entitled to set off any sums owing to Licensor against any sums owing by
Licensor to Rogers hereunder. 29. LEGAL EFFECT. (a) Nothing herein contained shall be deemed to
create and the parties do not intend to create any relationships of partner, agent or joint venture
as between Rogers and Licensor. (b) Subject to Section 29(d) below, this Agreement constitutes a
binding agreement with respect to the matters set out herein and supersedes all prior agreements,
negotiations, representations and proposals, whether written or oral. There are no conditions,
covenants, representations or warranties, express or implied, statutory or otherwise relating to the
subject matter hereof except as herein expressly provided. -11-

Source: EUROMEDIA HOLDINGS CORP, 10SB12G, 2/15/2007
<!-- page 12 -->
(c) No amendment, waiver or modification of any provision of this Agreement shall be binding on a
party unless consented to in writing by such party. No waiver of any provision of this Agreement
shall constitute a waiver of any other provision, nor shall any waiver constitute a continuing
waiver unless otherwise expressly provided in writing. (d) This Agreement shall not become a valid
and binding contract unless and until each party has duly executed two (2) copies of this Agreement
and one fully executed copy of the Agreement has been delivered to, or received by, each party. For
greater certainty, there shall be no agreement between the parties with respect to the subject
matter of this Agreement, whether written or oral, express, implied or otherwise, until the parties
have complied with the execution and delivery requirements set forth in this Section 29(d),
notwithstanding any performance between the parties concerning the subject matter of this document.
To indicate your agreement to the foregoing, please sign and date the Agreement and return it by
fax, with an original by courier, to Rogers Cable Communications Inc., 333 Bloor Street East,
Toronto, Ontario, M4W 1G9, Attention: Vice-President, Strategy & Development. ROGERS CABLE
COMMUNICATIONS INC.

Per:

Name: Edward Rogers Title: President and CEO

Per:

Name: David Purdy Title: Vice-President, General Manager, Television ACCEPTED and AGREED TO this
______ day of ____________, 2006. Per:

Name: Sebastien Perioche Title: Chairman/CEO

-12-

Source: EUROMEDIA HOLDINGS CORP, 10SB12G, 2/15/2007
