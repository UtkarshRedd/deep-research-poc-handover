# TODO — approaches to explore after the three core approaches are measured

Each item: what it is, why it might help here, what to measure, and the evidence that
motivates it. Do not start these before Phase 6 of `PLAN.md` has numbers.

## 1. LangChain `deepagents` as the Approach 3 runtime

- **What:** `pip install deepagents` — a Claude-Code-style harness on LangGraph: `write_todos`
  planning, a virtual/real filesystem (`ls/read/write/edit/glob/grep`), a `task` tool that
  spawns context-isolated sub-agents, and middleware that offloads tool results > ~20K tokens
  to files (Jan 2026 release).
- **Why here:** it already implements the sub-agent contract, filesystem tools and offload we
  are hand-rolling in Phases 1, 2 and 5.
- **Risk:** the system prompt and tool protocol are tuned for Claude-class models; with
  GPT-OSS / Nemotron Nano the planning tool and `task` hand-offs may be unreliable.
- **Measure:** same golden set, variant `A3_deepagents` vs `A3_fanout`; malformed-call rate,
  hand-off failure rate, tokens, item recall on the coverage slice.
- **Refs:** LangChain Deep Agents docs; Open Deep Research repo (archived Aug 2026) for the
  clarify → brief → supervisor → researchers → compress → report shape.

## 2. AI harness engineering as a discipline (layered harness over a fixed model)

- **What:** treat the harness — tool design, context assembly, budgets, verification — as the
  primary lever, with the model held fixed. The 2026 evidence says this is where the points
  are for open/small models: FinanceHarness took Qwen3.6-27B from 25.3 → 32.4 with a layered
  harness (bounded loop, tiered tools, citation retrofitting, grounding review) and +0.4 from
  RL; Stateless Language Agents matched the best baseline with 84–93% fewer tokens by having
  the harness rebuild a fresh role-specific context per call; Scroll keeps tool payloads in a
  Python kernel / event log and lets only printed projections into context (lossy
  summarization at ingest collapsed its score 73.1 → 19.9).
- **Concrete experiments for us:**
  - **Per-call context assembly** (IterResearch / SLA style): researcher sees question +
    evolving evidence summary + last tool result only, not the full transcript. Expect fewer
    tokens and less drift on GPT-OSS. Variant `A2_markov`.
  - **Width scheduling**: per-turn user message setting parallel-call width (wide → narrow;
    W&D: −36% cost, −41% time, +2–8 pts on GPT-5). Measure on GPT-OSS.
  - **Tool-result projection**: large grep/read outputs held as files/variables; the model gets
    counts, previews, pointers (Scroll).
  - **Advisor pattern**: cheap executor (Nemotron Nano) consults GPT-OSS a bounded number of
    times (Anthropic advisor strategy: 2× accuracy at −85% cost for Haiku ↔ Opus). Variant
    `A2_advisor`.
  - **Harness-owned verification loop**: Sauron-style evidence receipts per claim; DeepFact
    grouped verification (5–10 claims per probe) — Phase 7 extension.
- **Measure:** cost per correct answer and tier-1 support rate per harness variant, model fixed.
- **Refs:** FinanceHarness (arXiv 2607.27853), Stateless Language Agents (arXiv 2610.07625),
  Scroll (arXiv 2608.21690), IterResearch (arXiv 2511.07327), W&D (arXiv 2602.07359),
  INDEXACT (arXiv 2610.07960), Anthropic "effective context engineering" and advisor posts.

## 3. Set-algebra / COUNT tools over an ephemeral inverted index (INDEXACT)

- **What:** `FILTER / INTERSECT / UNION / COUNT / RANK / TOPK` over per-query Lucene-style
  postings; text enters context only via `READ`. 73.5% on BrowseComp-Plus with a nano-class
  model, flat from 100K → 800K docs; ablations: counts vs booleans +12, state reuse +8.
- **Why here:** corpus-wide questions ("how many agreements mention X and Y") with small models.
- **Measure:** coverage slice item recall and tokens vs Approach 3 grid.

## 4. Local embedder and cross-encoder (if permitted)

- **What:** `sentence-transformers` bi-encoder for a per-query in-memory dense index alongside
  BM25 (true hybrid Approach 1) and a cross-encoder for the first-move rerank.
- **Why here:** no embedding endpoint today; ViDoRe V3 shows BM25-only is weak on visually rich
  PDF text (20.3 vs 59.8 nDCG@10) and a textual reranker is worth +13.2.
- **Measure:** paraphrase-heavy slice recall; first-move candidate recall.

## 5. Search-as-Code / query-language tools

- **What:** let the agent write a short retrieval script composing grep/BM25/filter/dedupe/
  rerank primitives in a sandbox, returning only the final hits (Perplexity Search as Code,
  Vespa's "agents should write YQL"; INDEXACT is the academic version). Vendor-reported
  ~85% fewer tokens.
- **Prereq:** sandboxed `bash`/Python decision (PLAN open decision 2).

## 6. Librarian-style offline curation per stable partition

- **What:** pre-build a navigable workspace (topic files, cross-doc syntheses, provenance
  links) per partition that is queried repeatedly (e.g., a relationship / product line).
- **Why not now:** the paper's gains come from RL; a prompted builder scored 0.28 (below flat
  retrieval); break-even ~31 queries per partition; no update mechanism.
- **Revisit when:** query logs show ≥ 30 queries/month on the same filter partition.
- **Ref:** arXiv 2610.22273.

## 7. Long-context router validation

- **What:** router sends small, holistic questions (evidence < ~100K tokens) to a single
  long-context pass. Unvalidated on a fixed corpus; break-even subset size is unknown.
- **Measure:** `LC_small` variant vs Approach 2 on the holistic slice; cost ratio.

## 8. Parallel rollouts + aggregator (deferred)

- **What:** K independent research runs merged by an aggregator agent (AggAgent +13–18 at K=8).
- **Why deferred:** General-AgentBench (Sept 2026) finds no consistent gains without a verifier
  that can pick the right candidate; revisit only after tier-2 verification exists.

## 9. Metadata-as-filters inside the workspace

- **What:** turn the extracted document metadata into structured filters the agent can use
  (`list_docs(doc_type=..., date_range=...)`) and into first-move clue hints (dates, parties).
- **Measure:** temporal/version slice accuracy; TIDE-style "which version governs this date"
  checks.

## 10. Self-correction round with leftover time (proposed 2026-11-02)

- **What:** today the pipeline is research -> write -> verify -> stop, and single-answer questions
  finish in 50-90 s of the 300 s budget. After verification the report carries explicit defect
  signals: `[GAP]` lines (sections with no evidence), tier-1 drops, tier-2 `unsupported` /
  `partially`, forced or low-confidence submits. If `deadline - now - RESERVE` is above a
  threshold (e.g. 60 s), turn each defect into a repair task ("find evidence for <gap>", "find
  the correct source for <dropped claim>", "confirm <term> is absent"), run them as scoped
  researcher units (the fan-out `run_units` machinery: small call budget, injected doc_ids =
  first-move candidates or the cited documents, deadline = remaining time), append to the same
  evidence bank, then redraft only the affected sections and re-verify. One round, bounded;
  the pre-correction report is kept if the rewrite fails or adds nothing.
- **Cheaper variant (pre-write gap round):** after the research submit, if the outline assignment
  leaves sections empty and time remains, run the repair tasks *before* drafting, so nothing is
  rewritten. The breadth branch's `gap_check` + gap round is already this shape; generalise it.
- **Why here:** the defect signals are deterministic (tier 1) or already paid for (tier 2), which
  is what makes a reflect-retry loop safe: Glean found unconstrained reflect loops "not yet
  reliable" and General-AgentBench found more turns do not help without a verifier; Harvey's
  loop ends with a completeness check; EvidenT triggers a search of other documents on
  zero-overlap passages; ScaffoldAgent gates outline revision on utility.
- **Where it plugs in:** `graph.py` node `correct` after `verify` (or before `write` for the
  pre-write variant); config `CORRECT_MIN_REMAINING_S`, `CORRECT_MAX_TASKS`, `CORRECT_CALLS_PER_TASK`,
  `CORRECT_ROUNDS_MAX = 1`; reuse `fanout.FanoutUnit` / `run_units` / `gap_check`; writer needs a
  "redraft these sections only" entry point (`draft_section` already drafts one section).
- **Measure:** judge pass, gap rate, tier-1 support and gate failures before vs after the round on
  the 12-question smoke set; extra wall-clock and tokens per question; how often the round fires
  and how often it changes the verdict. Variant flag `SELF_CORRECT` on any base variant
  (e.g. `A1_deep_list+fix`). Guard rails: never past the deadline; tier 1 still gates every new
  claim; a round that adds no evidence must leave the report untouched.

## 11. Contextual BM25: index document metadata with every chunk (proposed 2026-11-02)

- **What:** Anthropic's "contextual retrieval" prepends 50–100 words of document context to each
  chunk before indexing; the published gains hold for the BM25 side as well as the embedding
  side. We cannot run a model per chunk inside the 5-minute budget and have no embeddings, so
  do the deterministic version: when `BM25Index` builds a chunk (`dr/tools/bm25.py::chunk_document`),
  prepend the manifest's title, doc_type, date and party names to the INDEXED text only. Chunk
  bodies, snippets, line ranges and citations stay untouched, so tier 1 is unaffected.
- **Why here:** today a chunk is only its section heading plus body. A query like "Acme
  termination fee" finds "termination" chunks in every contract and relies on grep for the
  party; with metadata in the index the Acme contract's chunks rank first. Expected to lift
  first-move candidate recall and cut the agent's confirm-the-parties turns (the failure mode
  behind the `confirm document identity` rule in `prompts/researcher.md`).
- **Risk:** party names then match every chunk of a document, so a party-heavy query floods the
  1,000-deep list with one contract's boilerplate. Mitigations to compare: (a) title + type only;
  (b) metadata as a separate field with a lower weight (bm25s has no fields: emulate by adding the
  metadata tokens once, not per chunk, or by a per-doc prior added to chunk scores); (c) cap
  chunks per document in the first move's per-clue union. Also check `expand_query`: feedback
  terms must come from chunk bodies, not the prepended metadata, or expansion degenerates into
  party names.
- **Not tuning:** this is a structural change to what is indexed, not a k1/b sweep, so it does
  not raise the overfitting concern recorded in `docs/findings.md`.
- **Measure:** `A1_deep_list` vs a new variant `A1_ctx_bm25` on `data/golden/cuad_smoke.jsonl`,
  then the full CUAD set: first-move candidate recall, opened-or-cited recall, tool calls per
  question, tokens per correct answer. Keep if candidate recall rises without a drop in support
  rate. Unit test: a chunk of a doc whose title is "Services Agreement" ranks above a body-only
  match for the query "services agreement <party>" on `data/sample_docs`.
- **Refs:** Anthropic "Introducing Contextual Retrieval" (Sept 2024); RAPTOR considered and
  rejected (summary nodes are not quotable spans; ingest-time model calls do not fit the per-query
  ephemeral index) — see the discussion recorded with this entry.
