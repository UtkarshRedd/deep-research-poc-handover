<!-- page 1 -->
# JOINT FILING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| Agreement Date | 2020-03-27 |
| Parties | Shelby J. Butterfield ("Co-Trustee") |
| Source | CUAD v1 / NELNETINC_04_08_2020-EX-1-JOINT FILING AGREEMENT |

Exhibit 1

JOINT FILING AGREEMENT

The undersigned hereby agree to jointly prepare and file with the applicable regulatory authorities
this Schedule 13G or Schedule 13D and any future amendments thereto reporting each of the
undersigned's ownership of securities of the issuer named herein, and hereby affirm that such
Schedule 13G or Schedule 13D is being filed on behalf of each of the undersigned pursuant to and in
accordance with the provisions of Rule 13d-1(k) under the Securities Exchange Act of 1934. The
undersigned acknowledge that each shall be responsible for the timely filing of such amendments, and
for the completeness and accuracy of the information concerning her or it contained therein, but
shall not be responsible for the completeness and accuracy of the information concerning the other,
except to the extent that she or it knows or has reason to believe that such information is
inaccurate.

Dated: March 27, 2020.

/s/ Shelby J. Butterfield Shelby J. Butterfield

BUTTERFIELD FAMILY TRUST

By: /s/ Shelby J. Butterfield Shelby J. Butterfield Co-Trustee

1
