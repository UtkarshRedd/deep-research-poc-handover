<!-- page 1 -->
# INTELLECTUAL PROPERTY AGREEMENT
| Field | Value |
|---|---|
| Document Type | IP Agreement |
| Agreement Date | 2016-05-14 |
| Parties | WestRock Company ("Parent"); Ingevity Corporation ("SpinCo"); SpinCo and Parent (individually referred to herein as a “Party” and collectively as the “Parties”) |
| Source | CUAD v1 / INGEVITYCORP_05_16_2016-EX-10.5-INTELLECTUAL PROPERTY AGREEMENT |

Exhibit 10.5 INTELLECTUAL PROPERTY AGREEMENT This INTELLECTUAL PROPERTY AGREEMENT, dated as of May
14, 2016 (this "Agreement"), is by and between WestRock Company, a Delaware corporation ("Parent"),
and Ingevity Corporation, a Delaware corporation ("SpinCo"). Capitalized terms used herein and not
otherwise defined shall have the respective meanings assigned to them in Section 1 or the Separation
Agreement. SpinCo and Parent may be individually referred to herein as a "Party" and collectively as
the "Parties". R E C I T A L S WHEREAS, Parent and SpinCo have entered into that certain Separation
and Distribution Agreement, dated as of even date herewith, (the "Separation Agreement"); WHEREAS,
the Separation Agreement sets forth the principal corporate transactions required to effect the
Separation; WHEREAS, Parent and SpinCo desire to enter into this Agreement to set forth the terms
and conditions pertaining to the allocation of ownership and other rights associated with certain
Intellectual Property; and WHEREAS, this Agreement is deemed to be an Ancillary Agreement under the
Separation Agreement. NOW, THEREFORE, in consideration of the mutual agreements, provisions and
covenants contained in this Agreement, and for other good and valuable consideration, the receipt
and sufficiency of which are hereby acknowledged, the Parties, intending to be legally bound, hereby
agree as follows: 1. DEFINITIONS. For the purpose of this Agreement, the following terms shall have
the following meanings: 1.1 "Mill Recovery Technology/Intellectual Property" shall mean all
Technology, Software and Intellectual Property directed to mill-based recovery processes that
generate biorefinery materials. 1.2 "Common Information" shall mean that Information that is related
to, but not dedicated to, the SpinCo Assets, the SpinCo Liabilities, the SpinCo Business or the
Transferred Entities. 1.3 "Control" or "Controlled" means, with respect to Intellectual Property,
that SpinCo or a member of the SpinCo Group owns such Intellectual Property, in whole or in part,
and/or has the right to grant a license to Parent with respect to such Intellectual Property as set
forth herein and without incurring any financial or other obligations to any other Person, subject,
in each case, to the terms of any license or other agreement to which SpinCo or any of the SpinCo
Group is a party that relates to any such Intellectual Property.
<!-- page 2 -->
1.4 "Improvements" means any improvements, derivative works, enhancements, refinements, advances or
other modifications with respect to any Licensed SpinCo IP (whether or not patentable or reduced to
practice). 1.5 "Intellectual Property" shall mean all of the following whether arising under the
Laws of the United States or of any other foreign or multinational jurisdiction: (a) patents, patent
applications (including patents issued thereon) and statutory invention registrations, including
reissues, divisions, continuations, continuations in part, substitutions, renewals, extensions and
reexaminations of any of the foregoing, and all rights in any of the foregoing provided by
international treaties or conventions, (b) trademarks, service marks, trade names, service names,
trade dress, logos and other source or business identifiers, including all goodwill associated with
any of the foregoing, and any and all common law rights in and to any of the foregoing,
registrations and applications for registration of any of the foregoing, all rights in and to any of
the foregoing provided by international treaties or conventions, and all reissues, extensions and
renewals of any of the foregoing, (c) Internet domain names, accounts with Facebook, LinkedIn,
Twitter and similar social media platforms, registrations and related rights, (d) copyrightable
works, copyrights, moral rights, mask work rights, database rights and design rights, in each case,
other than Software, whether or not registered, and all registrations and applications for
registration of any of the foregoing, and all rights in and to any of the foregoing provided by
international treaties or conventions, (e) confidential and proprietary information, including trade
secrets, invention disclosures, processes and know-how and (f) any other intellectual property
rights, in each case, other than Software. The items listed in subsections (b) and (c) of this
Section 1.5 are referred to herein as "Trademark-Related IP". 1.6 "Licensed SpinCo IP" means (i) the
SpinCo Intellectual Property (excluding Trademark-Related IP), the SpinCo Software, and the SpinCo
Technology, and (ii) all rights, interests and claims of either Party or any of the members of its
Group as of the Effective Time with respect to Information that is exclusively related to the items
of the aforementioned clause (i), in each case subject to the limitations set forth herein, and to
the extent Controlled by SpinCo or any member of the SpinCo Group as of the Effective Time
(including as a result of the assignments made by this Agreement). Licensed SpinCo IP shall exclude
SpinCo Intellectual Property, SpinCo Software, SpinCo Technology, and Intellectual Property: (a)
directed to chemically activated carbon products or any processes for manufacturing chemically
activated carbon products (including, for the avoidance of doubt, activated carbon sheets); (b)
directed to ex-mill processes for purifying crude tall oil and for isolating, purifying and
derivatizing lignin from black liquor or any products created using any such processes; (c) licensed
to Alberdingk Boley, Inc. ("ABI"), except to the extent outside the "Field," as that term is defined
in the "License Agreement" dated February 3, 2006, by and between MeadWestvaco Corporation and ABI;
(d) owned by Purification Cellutions, LLC, a joint venture between MeadWestvaco Corporation and
Applied Ceramics, Inc.; (e) directed to any products utilizing specialty chemicals derived from
co-products of the kraft pulping process sold by SpinCo into the paper or packaging field or any
processes for manufacturing such products (including, for the avoidance of doubt, paper sizing); (f)
owned by a third party (including for these purposes any joint venture or partnership or similar
business entity of which SpinCo is a member or in which SpinCo has an ownership interest) and not
sublicensable to Parent or any member of the Parent Group by SpinCo or any member of the SpinCo
Group.

-2-
<!-- page 3 -->
1.7 "Other IP" shall mean all Intellectual Property, other than Registrable IP, that is owned by
either Party or any member of its Group as of the Effective Time. 1.8 "Parent Field" shall mean the
businesses (whether or not such businesses are or have been terminated, divested or discontinued)
conducted at any time prior to the Effective Time, or actively pursued at the Effective Time, by the
Parent or any member of the Parent Group, outside the SpinCo Field. 1.9 "Parent IP Liabilities"
means all Liabilities relating to, arising out of or resulting from exploitation by, or on behalf of
the Parent Group, of: (i) Intellectual Property, Software, Technology owned by Parent Group ("Parent
IP Assets"); (ii) the Information that is exclusively related to the items of the aforementioned
clause (i); and (iii) all Liabilities arising from the use by the Parent Group of Common
Information. 1.10 "Parent Name and Parent Marks" shall mean the names, marks, trade dress, logos,
monograms, domain names and other source or business identifiers of either Party or any member of
its Group using or containing "WestRock", "MeadWestvaco" or "RockTenn" or their ticker symbols
"WRK," "MWV," or "RKT", either alone or in combination with other words or elements, and all names,
marks, trade dress, logos, monograms, domain names and other source or business identifiers
confusingly similar to or embodying any of the foregoing either alone or in combination with other
words or elements, together with the goodwill associated with any of the foregoing. 1.11 "Permitted
Party" shall mean a third party (a) in which Parent or other member of the Parent Group has an
ownership interest of greater than fifteen percent (15%); (b) with respect to whom SpinCo has
provided its consent to be a sublicensee under the Licensed SpinCo IP, such consent not to be
unreasonably withheld; or (c) who conducts business, operations, or activities within the Parent
Field on behalf of Parent or other member of the Parent Group. 1.12 "Pre-applied Adhesive
Technology/Intellectual Property" shall mean all Technology, Software and Intellectual Property
relating to the methods and processes of applying adhesives to cellulose based materials (e.g.,
paper, paper board, liner board and corrugated materials) and packaging, including without
limitation, related machine and press manufacturing processes, and the use of such cellulose based
materials with adhesives applied thereon. Pre-applied Adhesive Technology/Intellectual Property does
not include (a) the chemical formulations of adhesives; (b) the chemical formulations of tackifying
resins, dilutents, and plasticizers used in such adhesives; or (c) any process Technology for making
adhesives. 1.13 "Registrable IP" shall mean all patents, patent applications, statutory invention
registrations, registered trademarks, registered service marks, trademark and service mark
applications, registered Internet domain names and copyright registrations. 1.14 "Software" shall
mean any and all (a) computer programs, including any and all software implementation of algorithms,
models and methodologies, whether in source code, object code, human readable form or other form,
(b) databases and compilations, including any and all data and collections of data, whether machine
readable or otherwise, (c) descriptions, flow charts and other work products used to design, plan,
organize and develop any of the

-3-
<!-- page 4 -->
foregoing, (d) screens, user interfaces, report formats, firmware, development tools, templates,
menus, buttons and icons and (e) documentation, including user manuals and other training
documentation, relating to any of the foregoing. 1.15 "SpinCo Field" shall mean the businesses
(whether or not such businesses are or have been terminated, divested or discontinued) conducted at
any time prior to the Effective Time, or actively pursued at the Effective Time, by SpinCo or any
member of its Group, outside the Parent Field. 1.16 "SpinCo Intellectual Property" shall mean (a)
the Registrable IP set forth on Schedule 1.16 and (b) all Other IP owned by, licensed by or to, or
sublicensed by or to either Party or any member of its Group as of the Effective Time that is
dedicated to the SpinCo Business, including any Other IP set forth on Schedule 1.16; provided,
however, that SpinCo Intellectual Property does not include any Registrable IP or Other IP that
comprises (i) Mill Recovery Technology/Intellectual Property, or (ii) Pre-applied Adhesives
Technology/Intellectual Property. 1.17 "SpinCo IP Assets" means all (i) SpinCo Intellectual
Property, SpinCo Software, SpinCo Technology, and SpinCo IP Contracts, and (ii) all rights,
interests and claims of either Party or any of the members of its Group as of the Effective Time
with respect to Information that is exclusively related to the items of the aforementioned clause
(i) or the SpinCo IP Liabilities. 1.18 "SpinCo IP Contracts" shall mean the following contracts and
agreements to which either Party or any member of its Group is a party or by which it or any member
of its Group or any of their respective Intellectual Property is bound, whether or not in writing;
provided, that SpinCo IP Contracts shall not include any contract or agreement that is expressly
contemplated to be retained by Parent or any member of the Parent Group from and after the Effective
Time pursuant to any provision of the Separation Agreement, this Agreement or any other Ancillary
Agreement: (a) any vendor contracts or agreements with a Third Party pursuant to which such Third
Party (i) grants or receives a license, permission or use right to Intellectual Property, any
covenant not to sue under any Intellectual Property, or access and use rights to information
technology (for example, software as a service agreements), or (ii) undertakes an obligation to
assign, or has a right to be assigned, Intellectual Property to or by either Party or any member of
its Group exclusively for use or in connection with the SpinCo Business as of the Effective Time;
(b) any contract or agreement pertaining primarily to Intellectual Property that is otherwise
expressly contemplated pursuant to this Agreement, the Separation Agreement or any of the Ancillary
Agreements to be assigned to, or be a contract or agreement in the name of, SpinCo or any member of
the SpinCo Group; and (c) any other contract or agreement exclusively related to the SpinCo IP
Assets.

-4-
<!-- page 5 -->
1.19 "SpinCo IP Liabilities" means all Liabilities relating to, arising out of or resulting from
exploitation by, or on behalf of the SpinCo Group, of: (i) the SpinCo Intellectual Property, SpinCo
Software, SpinCo Technology, and SpinCo IP Contracts; (ii) the Information that is exclusively
related to the items of the aforementioned clause (i); and (iii) all Liabilities arising from the
use by the SpinCo Group of Common Information. 1.20 "SpinCo Name and SpinCo Marks" shall mean the
names, marks, trade dress, logos, monograms, domain names and other source or business identifiers
of SpinCo or any member of its Group using or containing "Ingevity" or its symbol "NGVT", either
alone or in combination with other words or elements, and all names, marks, trade dress, logos,
monograms, domain names and other source or business identifiers confusingly similar to or embodying
any of the foregoing either alone or in combination with other words or elements, together with the
goodwill associated with any of the foregoing. 1.21 "SpinCo Software" shall mean all Software owned
or licensed by either Party or member of its Group dedicated for use in the SpinCo Business as of
the Effective Time; provided, however, that SpinCo Software does not include (i) any Software
directed to Mill Recovery Technology/Intellectual Property, or (ii) any Software directed to
Pre-applied Adhesive Technology/Intellectual Property. 1.22 "SpinCo Technology" shall mean all
Technology owned or licensed by either Party or any member of its Group dedicated for use in the
SpinCo Business as of the Effective Time; provided, however, that SpinCo Technology does not include
any Technology that is (i) Mill Recovery Technology/Intellectual Property, or (ii) Pre-applied
Adhesive Technology/Intellectual Property. 1.23 "Technology" shall mean all technology, designs,
formulae, algorithms, procedures, methods, discoveries, processes, techniques, ideas, know-how,
research and development, technical data, tools, materials, specifications, processes, inventions
(whether patentable or unpatentable and whether or not reduced to practice), apparatus, creations,
improvements, works of authorship in any media, confidential, proprietary or nonpublic information,
and other similar materials, and all recordings, graphs, drawings, reports, analyses and other
writings, and other tangible embodiments of the foregoing in any form whether or not listed herein,
in each case only to the extent in existence as of the Effective Time, and, other than Software. 2.
THE SEPARATION 2.1 Matters Governed Exclusively by this Agreement. This Agreement shall exclusively
govern the allocation of Assets and Liabilities that are comprised of Intellectual Property of the
Parent Group or the SpinCo Group. In the case of any conflict between the Separation Agreement and
this Agreement in relation to any matters addressed herein, this Agreement shall prevail.

-5-
<!-- page 6 -->
2.2 Transfer of Assets and Assumption of Liabilities. (a) On or prior to the Effective Time, but in
any case, prior to the Distribution, in accordance with the Plan of Reorganization: (i) Transfer and
Assignment of SpinCo IP Assets. Parent shall, and shall cause the applicable members of its Group
to, contribute, assign, transfer, convey and deliver to SpinCo, or to the applicable SpinCo
Designees, and SpinCo shall, and shall cause such SpinCo Designees to, accept from Parent and the
applicable members of the Parent Group, all of Parent's and such Parent Group member's respective
direct or indirect right, title and interest in and to all of the SpinCo IP Assets (it being
understood that if any SpinCo IP Asset shall be held by a Transferred Entity or a wholly owned
Subsidiary of a Transferred Entity, such SpinCo IP Asset may be assigned, transferred, conveyed and
delivered to SpinCo as a result of the transfer of all of the equity interests in such Transferred
Entity from Parent or the applicable members of the Parent Group to SpinCo or the applicable SpinCo
Designee); and (ii) Acceptance and Assumption of SpinCo IP Liabilities. SpinCo shall, and shall
cause the applicable SpinCo Designees to, accept, assume and agree faithfully to perform, discharge
and fulfill all the SpinCo IP Liabilities in accordance with their respective terms. SpinCo shall,
and shall cause such SpinCo Designees to, be responsible for all SpinCo IP Liabilities, regardless
of when or where such SpinCo IP Liabilities arose or arise, or whether the facts on which they are
based occurred prior to or subsequent to the Effective Time, regardless of where or against whom
such SpinCo IP Liabilities are asserted or determined (including any SpinCo IP Liabilities arising
out of claims made by Parent's or SpinCo's respective directors, officers, employees, agents,
Subsidiaries or Affiliates against any member of the Parent Group or the SpinCo Group) or whether
asserted or determined prior to the date hereof, and regardless of whether arising from or alleged
to arise from negligence, recklessness, violation of Law, fraud or misrepresentation by any member
of the Parent Group or the SpinCo Group, or any of their respective directors, officers, employees,
agents, Subsidiaries or Affiliates. 2.3 Approvals and Notifications. (a) Approvals and Notifications
for SpinCo IP Assets. To the extent that the transfer or assignment of any SpinCo IP Asset or the
assumption of any SpinCo IP Liability requires Approvals or Notifications, the Parties shall use
their commercially reasonable efforts to obtain or make such Approvals or Notifications as soon as
reasonably practicable; provided, however, that, except to the extent expressly provided in this
Agreement or as otherwise agreed in writing between Parent and SpinCo, neither Parent nor SpinCo
shall be obligated to contribute capital or pay any consideration in any form (including providing
any letter of credit, guaranty or other financial accommodation) to any Person in order to obtain or
make such Approvals or Notifications. (b) Delayed SpinCo Transfers. If and to the extent that the
valid, complete and perfected transfer or assignment to the SpinCo Group of any SpinCo IP Asset or
assumption by the SpinCo Group of any SpinCo IP Liability would be a violation of applicable Law or
require any Approvals or Notifications in connection with the Separation that has not been obtained
or made by the Effective Time, then, unless the Parties shall otherwise mutually agree

-6-
<!-- page 7 -->
in writing, the transfer or assignment to the SpinCo Group of such SpinCo IP Assets or the
assumption by the SpinCo Group of such SpinCo IP Liabilities, as the case may be, shall be
automatically deemed deferred and any such purported transfer, assignment or assumption shall be
null and void until such time as all legal impediments are removed or such Approvals or
Notifications have been obtained or made. Notwithstanding the foregoing, any such SpinCo IP Assets
or SpinCo IP Liabilities shall continue to constitute SpinCo IP Assets and SpinCo IP Liabilities for
all other purposes of this Agreement. (c) Treatment of Delayed SpinCo IP Assets and Delayed SpinCo
IP Liabilities. If any transfer or assignment of any SpinCo IP Asset (or a portion thereof) or any
assumption of any SpinCo IP Liability (or a portion thereof) intended to be transferred, assigned or
assumed hereunder, as the case may be, is not consummated on or prior to the Effective Time, whether
as a result of the provisions of Section 2.3(b) or for any other reason (any such SpinCo IP Asset
(or a portion thereof), a "Delayed SpinCo IP Asset" and any such SpinCo IP Liability (or a portion
thereof), a "Delayed SpinCo IP Liability"), then, insofar as reasonably possible and subject to
applicable Law, the member of the Parent Group retaining such Delayed SpinCo IP Asset or such
Delayed SpinCo IP Liability, as the case may be, shall thereafter hold such Delayed SpinCo IP Asset
or Delayed SpinCo IP Liability, as the case may be, for the use and benefit of the member of the
SpinCo Group entitled thereto (at the expense of the member of the SpinCo Group entitled thereto).
In addition, the member of the Parent Group retaining such Delayed SpinCo IP Asset or such Delayed
SpinCo IP Liability shall, insofar as reasonably possible and to the extent permitted by applicable
Law, treat such Delayed SpinCo IP Asset or Delayed SpinCo IP Liability in the ordinary course of
business in accordance with past practice and take such other actions as may be reasonably requested
by the member of the SpinCo Group to whom such Delayed SpinCo IP Asset is to be transferred or
assigned, or which will assume such Delayed SpinCo IP Liability, as the case may be, in order to
place such member of the SpinCo Group in a substantially similar position as if such Delayed SpinCo
IP Asset or Delayed SpinCo IP Liability had been transferred, assigned or assumed as contemplated
hereby and so that all the benefits and burdens relating to such Delayed SpinCo IP Asset or Delayed
SpinCo IP Liability, as the case may be, including use, non- abandonment, avoidance from
contribution to the public domain, risk of loss, potential for gain, and dominion, control and
command over such Delayed SpinCo IP Asset or Delayed SpinCo IP Liability, as the case may be, and
all costs and expenses related thereto, shall inure from and after the Effective Time to the SpinCo
Group. (d) Transfer of Delayed SpinCo IP Assets and Delayed SpinCo IP Liabilities. If and when the
Approvals or Notifications, the absence of which caused the deferral of transfer or assignment of
any Delayed SpinCo IP Asset or the deferral of assumption of any Delayed SpinCo IP Liability
pursuant to Section 2.3(b), are obtained or made, and, if and when any other legal or other
impediments for the transfer or assignment of any Delayed SpinCo IP Asset or the assumption of any
Delayed SpinCo IP Liability have been removed, the transfer or assignment of the applicable Delayed
SpinCo IP Asset or the assumption of the applicable Delayed SpinCo IP Liability, as the case may be,
shall be effected in accordance with the terms of this Agreement and/or the applicable Ancillary
Agreement as soon as reasonably practicable. (e) Costs for Delayed SpinCo IP Assets and Delayed
SpinCo IP Liabilities. Any member of the Parent Group retaining a Delayed SpinCo IP Asset or a
Delayed SpinCo IP Liability due to the deferral of the transfer or assignment of such Delayed SpinCo
IP Asset or the

-7-
<!-- page 8 -->
deferral of the assumption of such Delayed SpinCo IP Liability, as the case may be, shall not be
obligated, in connection with the foregoing, to expend any money unless the necessary funds are
advanced (or otherwise made available) by SpinCo or the member of the SpinCo Group entitled to the
Delayed SpinCo IP Asset or Delayed SpinCo IP Liability, other than reasonable out-of-pocket
expenses, attorneys' fees and recording or similar fees, all of which shall be promptly reimbursed
by SpinCo or the member of the SpinCo Group entitled to such Delayed SpinCo IP Asset or Delayed
SpinCo IP Liability. 2.4 Novation of SpinCo IP Liabilities. (a) Each of Parent and SpinCo, at the
request of the other, shall use its commercially reasonable efforts to obtain, or to cause to be
obtained, as soon as reasonably practicable, any consent, substitution, approval or amendment
required to novate or assign all SpinCo IP Liabilities and obtain in writing the unconditional
release of each member of the Parent Group that is a party to any such arrangements, so that, in any
such case, the members of the SpinCo Group shall be solely responsible for such SpinCo IP
Liabilities; provided, however, that, except as otherwise expressly provided in this Agreement or
any of the Ancillary Agreements, neither Parent nor SpinCo shall be obligated to contribute any
capital or pay any consideration in any form (including providing any letter of credit, guaranty or
other financial accommodation) to any third Person from whom any such consent, substitution,
approval, amendment or release is requested. (b) If Parent or SpinCo is unable to obtain, or to
cause to be obtained, any such required consent, substitution, approval, amendment or release as set
forth in Section 2.4(a) and the applicable member of the Parent Group continues to be bound by such
agreement, lease, license or other obligation or Liability (each, an "Unreleased SpinCo IP
Liability"), SpinCo shall, to the extent not prohibited by Law, as indemnitor, guarantor, agent or
subcontractor for such member of the Parent Group, as the case may be, (i) pay, perform and
discharge fully all the obligations or other Liabilities of such member of the Parent Group that
constitute Unreleased SpinCo IP Liabilities from and after the Effective Time and (ii) use its
commercially reasonable efforts to effect such payment, performance or discharge prior to any demand
for such payment, performance or discharge is permitted to be made by the obligee thereunder on any
member of the Parent Group. If and when any such consent, substitution, approval, amendment or
release shall be obtained or the Unreleased SpinCo IP Liabilities shall otherwise become assignable
or able to be novated, Parent shall promptly assign, or cause to be assigned, and SpinCo or the
applicable SpinCo Group member shall assume, such Unreleased SpinCo IP Liabilities without exchange
of further consideration. 2.5 Disclaimer of Representations and Warranties. EACH OF PARENT (ON
BEHALF OF ITSELF AND EACH MEMBER OF THE PARENT GROUP) AND SPINCO (ON BEHALF OF ITSELF AND EACH
MEMBER OF THE SPINCO GROUP) UNDERSTANDS AND AGREES THAT, EXCEPT AS EXPRESSLY SET FORTH HEREIN OR IN
THE SEPARATION AGREEMENT, NO PARTY TO THIS AGREEMENT OR OTHERWISE, IS REPRESENTING OR WARRANTING IN
ANY WAY AS TO THE ASSETS, BUSINESSES OR LIABILITIES TRANSFERRED OR ASSUMED AS CONTEMPLATED HEREBY OR
THEREBY, AS TO ANY CONSENTS OR APPROVALS REQUIRED IN CONNECTION THEREWITH, AS TO THE VALUE OR
FREEDOM FROM ANY SECURITY INTERESTS

-8-
<!-- page 9 -->
OF, OR ANY OTHER MATTER CONCERNING, ANY ASSETS OF SUCH PARTY, OR AS TO THE ABSENCE OF ANY DEFENSES
OR RIGHT OF SETOFF OR FREEDOM FROM COUNTERCLAIM WITH RESPECT TO ANY CLAIM OR OTHER ASSET, INCLUDING
ANY ACCOUNTS RECEIVABLE, OF ANY PARTY, OR AS TO THE LEGAL SUFFICIENCY OF ANY ASSIGNMENT, DOCUMENT OR
INSTRUMENT DELIVERED HEREUNDER TO CONVEY TITLE TO ANY ASSET OR THING OF VALUE UPON THE EXECUTION,
DELIVERY AND FILING HEREOF OR THEREOF. EXCEPT AS MAY EXPRESSLY BE SET FORTH HEREIN OR IN THE
SEPARATION AGREEMENT, ALL SUCH ASSETS ARE BEING TRANSFERRED ON AN "AS IS," "WHERE IS" BASIS AND THE
RESPECTIVE TRANSFEREES SHALL BEAR THE ECONOMIC AND LEGAL RISKS THAT (I) ANY CONVEYANCE WILL PROVE TO
BE INSUFFICIENT TO VEST IN THE TRANSFEREE GOOD AND MARKETABLE TITLE, FREE AND CLEAR OF ANY SECURITY
INTEREST, AND (II) ANY NECESSARY APPROVALS OR NOTIFICATIONS ARE NOT OBTAINED OR MADE OR THAT ANY
REQUIREMENTS OF LAWS OR JUDGMENTS ARE NOT COMPLIED WITH. 3. LICENSES 3.1 License Grant to Parent.
Subject to the terms and conditions of this Agreement, SpinCo hereby grants to each individual
member of the Parent Group, on behalf of itself and the other members of the SpinCo Group, and shall
cause the other members of the SpinCo Group to grant to each individual member of the Parent Group,
a non-exclusive, worldwide, perpetual, irrevocable, fully paid-up, royalty-free right and license,
for use in the Parent Field, to (i) use, reproduce, distribute, display, perform, make Improvements
and exploit the Licensed SpinCo IP, and (ii) make, have made, use, sell, offer to sell and import
any goods and services incorporating, embodying or utilizing the Licensed SpinCo IP. The foregoing
license shall be transferable or sublicensable by Parent Group solely to a Permitted Party, and,
subject to the restrictions herein, with any sale or transfer of a Parent business that utilizes the
Licensed SpinCo IP. Any such transfer or sublicense shall require the Permitted Party or, in the
case of a sale or transfer of a Parent business, the transferee, to agree pursuant to a written
agreement to maintain any trade secrets and Information included in the Licensed SpinCo IP in strict
confidence. Such agreement shall prohibit any further sublicensing or transfer of rights by the
Permitted Party, or, in the case of a sale or transfer of a Parent business, the transferee, or any
use of the Licensed SpinCo IP outside the scope of the license granted to Parent herein. Parent
shall remain responsible and liable for the Permitted Parties' exercise of any rights sublicensed
hereunder and any use of the Licensed SpinCo IP by such Permitted Party outside of the permitted
scope of the license. Parent shall enforce material breaches of the terms of any such sublicense of
rights and notify SpinCo of any material violation thereof by a Permitted Party. If Parent enters an
agreement to transfer the license granted to it under this Section 3.1 in connection with any sale
or transfer of a Parent business, then SpinCo and members of the SpinCo Group shall be made third
party beneficiaries under such transfer agreement to enforce breaches of the license. 3.2 License
Grant to SpinCo. Subject to the terms and conditions of this Agreement, Parent hereby grants to each
individual member of the SpinCo Group, on behalf of itself and the other members of the Parent
Group, and shall cause the other members of the Parent Group to grant to each individual member of
the SpinCo Group, a non-exclusive, worldwide, perpetual, irrevocable, fully paid-up, royalty-free
right and license, solely for use in the SpinCo Field, to (i)

-9-
<!-- page 10 -->
use, reproduce, distribute, display, perform, make improvements and exploit Intellectual Property
owned or controlled by Parent or a member of the Parent Group and currently used in the SpinCo
Business, and (ii) make, have made, use, sell, offer to sell and import any goods and services
incorporating, embodying or utilizing such Intellectual Property currently used in the SpinCo
Business. Such license shall be transferrable subject to the foregoing restriction with any sale or
transfer of a SpinCo business that utilizes such Intellectual Property, but, for the avoidance of
doubt, such license shall not otherwise be sublicensable or transferable. Any transfer by SpinCo or
a member of its Group shall require the transferee to agree pursuant to a written agreement to
maintain any trade secrets and Information included in the transferred Intellectual Property in
strict confidence. Such agreement shall prohibit any further transfer of rights by such party or any
use of the transferred Intellectual Property outside the scope of the license granted to SpinCo
herein. If SpinCo enters an agreement to transfer the license granted to it under this Section 3.2
in connection with any sale or transfer of a SpinCo business, then Parent and members of the Parent
Group shall be made third party beneficiaries under such transfer agreement to enforce breaches of
the license. 3.3 Neither Party shall make a trade secret of the other Party public or otherwise
destroy or impair the trade secret status of such trade secret without the express, advance, written
consent of the other Party. Any agreement by which a trade secret is transferred or sublicensed
shall be subject to the same confidentiality requirements as stated herein. 3.4 No Implied Rights.
As between the Parties, all right, title and interest in and to all Licensed SpinCo IP shall be
owned by SpinCo and the other members of the SpinCo Group, and Parent shall not acquire, and nothing
contained herein shall be construed as conferring, by implication, estoppel or otherwise, any
license or other right, title or interest in or to such Licensed SpinCo IP or any other Intellectual
Property owned by SpinCo or of any of its Group, except for the license granted to Parent pursuant
to Section 3.1. 3.5 Improvements. For the avoidance of doubt, as between the Parties, Parent shall
own all right, title and interest in and to any and all Improvements authored, developed, invented,
reduced to practice or otherwise created by Parent or any member of the Parent Group and all
Intellectual Property rights therein and thereto. 3.6 Enforcement of Licensed IP. (a) Control of
Enforcement IP Actions. Except as may otherwise be mutually agreed by the Parties, as between the
Parties, SpinCo shall have the right to enforce the Licensed SpinCo IP as follows: (i) SpinCo shall
have the right, but not the obligation (through itself and/or through its designee), to control the
initiation, conduct and, subject to this Section 3.6, settlement or other resolution, at its cost
and expense and in its sole discretion, of any enforcement claim, demand, action, suit or
proceeding, whether civil or criminal or in law or in equity (each, an "IP Action") relating to the
Licensed SpinCo IP, including the right to communicate any objection or other form of challenge to
any Third Party; and

-10-
<!-- page 11 -->
(ii) if SpinCo does not initiate such an IP Action itself or through its designee with respect to
infringement, misappropriation or other violation of any Licensed SpinCo IP within the Parent Field
by a Third Party within ninety (90) days after receipt of a written request from Parent to assume
control over the enforcement of such violation of such Licensed SpinCo IP inside the Parent Field,
then Parent shall have, with the prior consent of SpinCo, which will not be unreasonably withheld,
the right, but not the obligation, to bring and to control such IP Action (provided that if Parent
does not do so within thirty (30) days after the end of such original ninety (90) day-deadline, the
right to initiate and control an IP Action shall revert back to SpinCo and shall again be subject to
the terms set forth above). For avoidance of doubt, Parent shall not have any right to initiate any
IP Action with respect to infringement, misappropriation or other violation of any Licensed SpinCo
IP by a Third Party except within the Parent Field. (b) Enforcement Action Process. (i) The Party
initiating or otherwise controlling any enforcement IP Action hereunder (the "Enforcing Party"),
including the right to communicate any objection or other form of challenge to any Third Party,
shall, as between the Parties, have the right to select counsel for any IP Action initiated by it or
its designee pursuant to this Section 3.6. The Party that is not the Enforcing Party (the
"Non-Enforcing Party") shall, to the extent it is a necessary party to the IP Action (or is
otherwise reasonably requested by the enforcing Party), join the Enforcing Party (and/or, if
applicable, its designee(s)) at the Enforcing Party's expense and agree to be represented by counsel
for the Enforcing Party in any infringement or other IP Action commenced by the Enforcing Party (or
its designee) and shall, upon request of the Enforcing Party, execute such documents and perform
such other acts as may be reasonably required and requested by the Enforcing Party at the Enforcing
Party's expense in connection with such enforcement IP Action; provided, that the Non-Enforcing
Party shall have the right to engage, at its cost and expense, independent counsel of its choice to
advise such Non-Enforcing Party in connection with such assistance to the Enforcing Party. (ii) The
Non-Enforcing Party shall cooperate with, and provide reasonable assistance to, the Enforcing Party
(and its designees) in connection with any IP Action brought by the Enforcing Party (or its
designee) hereunder to the extent relating to the Licensed SpinCo IP, as may be reasonably requested
by the Enforcing Party, including by providing access to relevant documents and other evidence
(provided that the Parties shall enter into a joint defense agreement with respect to the common
interest privilege protecting such communications in a form reasonably acceptable to the Parties)
and making its employees available, subject to the other Party's reimbursement of any costs and
expenses incurred by the Non-Enforcing Party in providing such assistance. The Enforcing Party shall
keep the Non-Enforcing Party reasonably informed of any determinations or significant developments
in any IP Action initiated by it pursuant to this Section 3.6 and, if the Non-Enforcing Party is
SpinCo, then the Parent shall reasonably consult with the SpinCo and take into consideration input
provided to Parent by SpinCo to the extent reasonable and provided in a timely manner. (c)
Allocation of Costs and Recoveries. Unless otherwise mutually agreed by the Parties, (i) the costs
and expenses relating to any enforcement IP Action commenced pursuant to this Section 3.6 shall be
borne by the Enforcing Party; and (ii) any settlement payments or

-11-
<!-- page 12 -->
damages or other monetary awards ("Recoveries") recovered in any IP Action by the Enforcing Party,
itself or through its designee, pursuant to this Section 3.6, whether by judgment or settlement,
shall be allocated in the following order: (A) to reimburse the Enforcing Party for any costs and
expenses incurred by or on behalf of the Enforcing Party and/or its designee(s) with respect to such
IP Action, (B) to reimburse the Non-Enforcing Party for any costs and expenses incurred by such
Party with respect to such IP Action to the extent the Non-Enforcing Party participated in an IP
Action pursuant to this Section 3.6 (and has not already been reimbursed by the Enforcing Party),
including if it joins such IP Action (but excluding, for the avoidance of doubt, the cost of any
counsel employed by the Non-Enforcing Party), and (C) the remainder shall be allocated to the
Enforcing Party. (d) Settlement of Enforcement IP Action. The Enforcing Party shall not settle, or
enter into a voluntary consent judgment with respect to, any enforcement IP Action under this
Section 3.6 in a manner that would include any admissions of invalidity or unenforceability against
the Non-Enforcing Party, or wrongdoing by the Non-Enforcing Party or any of its Group, or imposes
any liability or payment or other obligation on the Non-Enforcing Party or any of its Group, without
the Non-Enforcing Party's written consent (such consent not to be unreasonably withheld, conditioned
or delayed) and in any event, without notifying the Non-Enforcing Party of any such proposed
settlement or voluntary consent judgment. For the avoidance of doubt, and without limiting the
foregoing, as between the Parties, the Enforcing Party shall have the sole and exclusive right to
settle, or enter into a voluntary consent judgment with respect to, any enforcement IP Action under
this Section 3.6. For the avoidance of doubt, Parent shall not settle or enter into a voluntary
consent judgment or enter into any other agreement that shall in any way impair the rights of SpinCo
with respect to its Intellectual Property outside the Parent Field without SpinCo's consent, which
may be withheld in its sole option. 3.7 Bankruptcy. In the event that this Agreement is terminated
or rejected by SpinCo, a member of the SpinCo Group or its receiver or trustee under applicable
bankruptcy laws due to such Party's bankruptcy, then all rights and licenses granted under or
pursuant to this Agreement by SpinCo to Parent are, and shall otherwise be deemed to be, for
purposes of Section 365(n) of the U.S. Bankruptcy Code (the "Code") and any similar laws in any
other country, licenses of rights to "intellectual property" as defined under the Code for purposes
of Section 365(n). The Parties agree that all intellectual property rights licensed hereunder,
including, without limitation, any patents or patent applications in any country of SpinCo or a
member of SpinCo Group covered by the license grants under this Agreement, are part of the
"intellectual property" as defined under the Code for purposes of Section 365(n) subject to the
protections afforded the non-terminating Party under Section 365(n) of the Code, and any similar law
or regulation in any other country. 3.8 Trademark Disclaimer. Neither Parent nor SpinCo nor any
member of the Parent Group or SpinCo Group grants any right or license to the other to use any
Parent Name or Parent Mark or SpinCo Name or SpinCo Mark in any manner including, without
limitation, use in commerce as a trade name, trademark or other designation of origin.
Notwithstanding the foregoing, it is understood that signage, letterhead, invoices, business cards,
promotional materials and similar items may reference the Parent Name or Parent Mark "MeadWestvaco"
and "MWV" in the same manner as used by SpinCo prior to the Effective Time, during a twelve-month
phase out period as SpinCo replaces such Parent Name and Parent Mark with the SpinCo Name and SpinCo
Mark.

-12-
<!-- page 13 -->
4. MUTUAL RELEASES; INDEMNIFICATION 4.1 Release of Pre-Distribution Claims. (a) SpinCo Release of
Parent. Except as provided in Sections 4.1(c) and 4.1(d), effective as of the Effective Time, SpinCo
does hereby, for itself and each other member of the SpinCo Group, and their respective successors
and assigns, and, to the extent permitted by Law, all Persons who at any time prior to the Effective
Time have been shareholders, directors, officers, agents or employees of any member of the SpinCo
Group (in each case, in their respective capacities as such), remise, release and forever discharge
(i) Parent and the members of the Parent Group, and their respective successors and assigns, and
(ii) all Persons who at any time prior to the Effective Time are or have been shareholders,
directors, officers, agents or employees of any member of the Parent Group (in each case, in their
respective capacities as such), and their respective heirs, executors, administrators, successors
and assigns, and (iii) all Persons who at any time prior to the Effective Time are or have been
shareholders, directors, officers, agents or employees of a Transferred Entity and who are not, as
of immediately following the Effective Time, directors, officers or employees of SpinCo or a member
of the SpinCo Group, in each case from (A) all SpinCo IP Liabilities and (B) all Liabilities arising
from or in connection with actions, inactions, events, omissions, conditions, facts or circumstances
occurring or existing prior to the Effective Time (whether or not such Liabilities cease being
contingent, mature, become known, are asserted or foreseen, or accrue, in each case before, at or
after the Effective Time), in each case to the extent relating to, arising out of or resulting from
the SpinCo IP Assets or the SpinCo IP Liabilities. (b) Parent Release of SpinCo. Except as provided
in Sections 4.1(c) and 4.1(d), effective as of the Effective Time, Parent does hereby, for itself
and each other member of the Parent Group, and their respective successors and assigns, and, to the
extent permitted by Law, all Persons who at any time prior to the Effective Time have been
shareholders, directors, officers, agents or employees of any member of the SpinCo Group (in each
case, in their respective capacities as such), remise, release and forever discharge (i) SpinCo and
the members of the SpinCo Group, and their respective successors and assigns, and (ii) all Persons
who at any time prior to the Effective Time are or have been shareholders, directors, officers,
agents or employees of any member of the SpinCo Group (in each case, in their respective capacities
as such), and their respective heirs, executors, administrators, successors and assigns, and (iii)
all Persons who at any time prior to the Effective Time are or have been shareholders, directors,
officers, agents or employees of a Transferred Entity and who are not, as of immediately following
the Effective Time, directors, officers or employees of SpinCo or a member of the SpinCo Group, in
each case from (A) all Parent IP Liabilities and (B) all Liabilities arising from or in connection
with actions, inactions, events, omissions, conditions, facts or circumstances occurring or existing
prior to the Effective Time (whether or not such Liabilities cease being contingent, mature, become
known, are asserted or foreseen, or accrue, in each case before, at or after the Effective Time), in
each case to the extent relating to, arising out of or resulting from the Parent IP Assets or the
Parent IP Liabilities.

-13-
<!-- page 14 -->
(c) Obligations Not Affected. Nothing contained in Section 4.1(a) or Section 4.1(b) shall impair any
right of any Person to enforce this Agreement. Nothing contained in Section 4.1(a) or Section 4.1(b)
shall release any Person from: (i) any Liability, contingent or otherwise, assumed, transferred,
assigned or allocated to the Group of which such Person is a member in accordance with, or any other
Liability of any member of any Group under, this Agreement; (ii) any Liability that the Parties may
have with respect to indemnification or contribution or other obligation pursuant to this Agreement
for claims brought against the Parties by third Persons, which Liability shall be governed by the
provisions of the Separation Agreement; or (iii) any Liability the release of which would result in
the release of any Person other than a Person released pursuant to this Section 4.1. In addition,
nothing contained in Section 4.1(a) or Section 4.1(b) shall release any member of the Parent Group
from honoring its existing obligations to indemnify any director, officer or employee of SpinCo who
was a director, officer or employee of any member of the Parent Group on or prior to the Effective
Time, to the extent such director, officer or employee becomes a named defendant in any Action (as
defined in the Separation Agreement) with respect to which such director, officer or employee was
entitled to such indemnification pursuant to such existing obligations; it being understood that, if
the underlying obligation giving rise to such Action is a SpinCo IP Liability, SpinCo shall
indemnify Parent for such Liability (including Parent's costs to indemnify the director, officer or
employee) in accordance with the provisions set forth in this Section 4. (d) No Claims. Neither
Parent nor SpinCo shall make, and shall not permit any member of the Parent Group or SpinCo Group,
as the case may be, to make, any claim or demand, or commence any Action asserting any claim or
demand, including any claim of contribution or any indemnification, against the other Party or any
other member of the Parent Group or SpinCo Group, as the case may be, or any other Person released
pursuant to Section 4.1(a) or Section 4.1(b), with respect to any Liabilities released pursuant to
Section 4.1(a) or Section 4.1(b). (e) Execution of Further Releases. At any time at or after the
Effective Time, at the request of either Party, the other Party shall cause each member of its
respective Group to execute and deliver releases reflecting the provisions of this Section 4.1. 4.2
Indemnification. Except as otherwise specifically set forth in this Agreement, to the fullest extent
permitted by Law, SpinCo shall, and shall cause the other members of the SpinCo Group to, indemnify,
defend and hold harmless the Parent Indemnitees from and against any and all Liabilities of the
Parent Indemnitees relating to, arising out of or resulting from, directly or indirectly, (a) any
SpinCo IP Liability, and (b) any failure of SpinCo, any other member of the SpinCo Group or any
other Person to pay, perform or otherwise promptly discharge any SpinCo IP Liabilities in accordance
with their terms, whether arising prior to, on or after the Effective Time. Except as otherwise
specifically set forth in this Agreement, to the fullest extent permitted by Law, Parent shall, and
shall cause the other members of the Parent

-14-
<!-- page 15 -->
Group to, indemnify, defend and hold harmless the SpinCo Indemnitees from and against any and all
Liabilities of the Parent Indemnitees relating to, arising out of or resulting from, directly or
indirectly, (a) any Parent IP Liability, and (b) any failure of Parent, any other member of the
Parent Group or any other Person to pay, perform or otherwise promptly discharge any Parent IP
Liabilities in accordance with their terms, whether arising prior to, on or after the Effective
Time. 4.3 Other Terms and Conditions Incorporated by Reference. Each Party acknowledges and agrees
that with respect to the indemnification obligations set forth in Section 4.2 above, the terms and
conditions of Section 4.4 (Indemnification Obligations Net of Insurance Proceeds and Other Amounts)
through Section 4.10 (Survival of Indemnities) of the Separation Agreement are hereby incorporated
by reference and shall apply to such indemnification obligations. 5. EXCHANGE OF INFORMATION;
CONFIDENTIALITY 5.1 Agreement for Transfer and Exchange of Information. (a) Each of Parent and
SpinCo, on behalf of itself and each member of its Group, acknowledges and agrees that, with respect
to Information that it will own as a result of the Separation, each is entitled to physical
possession of Information that exists in tangible and intangible form, including Software,
Technology, or electronic data that may exist on hard-drives, or other electronic storage means
("Tangible/Intangible Information"). Subject to subsections (i)-(iii) of this Section 5.1(a), each
Party agrees that prior to the date that is six (6) months after the Effective Time ("Delivery
Date"), it will deliver possession of any Tangible/Intangible Information of the other Party that is
in its possession or control to the other Party, without retaining any copies. (i) To the extent
that any Tangible/Intangible Information of SpinCo is in the possession of Parent, is comingled, and
separation is not commercially reasonable, Parent will make such Tangible/Intangible Information
available to SpinCo to separate at its own expense. If SpinCo chooses to separate such
Tangible/Intangible Information, then Parent will deliver possession to SpinCo of any such separated
Tangible/Intangible Information within one (1) month after such separation, without retaining any
copies. (ii) To the extent that any Tangible/Intangible Information of Parent is in the possession
of SpinCo, is comingled, and separation is not commercially reasonable, SpinCo shall, at its option,
(x) separate such comingled Tangible/Intangible Information at its own expense and deliver
possession to Parent of any such separated Tangible/Intangible Information by the Delivery Date,
without retaining any copies or (y) deliver possession of all of such comingled Tangible/Intangible
Information to Parent by the Delivery Date, without retaining any copies. (iii) To the extent Parent
is in possession of any comingled Tangible/Intangible Information, that is not separated by SpinCo
pursuant to Section 5.1(a)(i), then Parent shall be entitled to maintain possession of such
Tangible/Intangible Information, but (A) shall provide reasonable access to SpinCo upon SpinCo's
request, including the opportunity to make extracts or copies, and (B) Parent shall not use or
otherwise access that portion of the

-15-
<!-- page 16 -->
comingled Tangible/Intangible Information that is the property of SpinCo, and shall retain such
Tangible/Intangible Information in confidence as set forth in the Section 6.9 of the Separation
Agreement. To the extent practical, SpinCo shall be entitled to redact or obscure any of SpinCo's
Tangible/Intangible Information that is so retained by Parent. (b) Subject to the applicable
confidentiality obligations of the Separation Agreement, each of Parent and SpinCo, on behalf of
itself and each member of its Group, agrees to use commercially reasonable efforts to provide or
make available, or cause to be provided or made available, to the other Party and the members of
such other Party's Group, at any time before, on or after the Effective Time, as soon as reasonably
practicable after written request therefor, any Information (or a copy thereof) in the possession or
under the control of such Party or its Group which the requesting Party or its Group requests, in
good faith in order to evaluate or use such Information for commercial purposes within the Parent
Field or SpinCo Field, as appropriate, to the extent that (i) such Information relates to any SpinCo
IP Asset or SpinCo IP Liability, if SpinCo is the requesting Party; (ii) such Information is
necessary for Parent or any member of Parent Group to exercise its rights under the license granted
in Section 3.1 of this Agreement, if Parent is the requesting Party, (iii) such Information is
required by the requesting Party to comply with its obligations under this Agreement; or (iv) such
Information is required by the requesting Party to comply with any obligation imposed by any
Governmental Authority; provided, however, that, for any of the foregoing (i) - (iv), in the event
that the Party to whom the request has been made determines that any such provision of Information
could be detrimental to the Party providing the Information, violate any Law or agreement, or waive
any privilege available under applicable Law, including any attorney-client privilege, then the
Parties shall use commercially reasonable efforts to permit compliance with such obligations to the
extent and in a manner that avoids any such harm or consequence. The Party providing Information
pursuant to this Section 5.1(b) shall only be obligated to provide such Information in the form,
condition and format in which it then exists, and in no event shall such Party be required to
perform any improvement, modification, conversion, updating or reformatting of any such Information,
and nothing in this Section 5.1 shall expand the obligations of a Party under Section 5.4. 5.2
Ownership of Information. The provision of any Information pursuant to Section 5.1 shall not affect
the ownership of such Information (which shall be determined solely in accordance with the terms of
this Agreement, the Separation Agreement and the Ancillary Agreements), or constitute a grant of
rights in or to any such Information (such grant of rights, to the extent they exist, are expressly
addressed elsewhere in this Agreement). For the avoidance of doubt, no Party shall be required to
provide to the other Party any updates, improvements, or additions to any Intellectual Property that
it owns after the Effective Time. 5.3 Compensation for Providing Information. The Party requesting
Information pursuant to Section 5.1(b) above agrees to reimburse the other Party for the reasonable
costs, if any, of creating, gathering, copying, transporting and otherwise complying with the
request with respect to such Information (including any reasonable costs and expenses incurred in
any review of Information for purposes of protecting the Privileged Information of the providing
Party or in connection with the restoration of backup media for purposes of providing the requested
Information). Except as may be otherwise specifically provided elsewhere in this Agreement, the
Separation Agreement,

-16-
<!-- page 17 -->
any other Ancillary Agreement or any other agreement between the Parties, such costs shall be
computed in accordance with the providing Party's standard methodology and procedures. 5.4 Other
Rights and Obligations. The rights and obligations of the Parties under Section 6.4 (Record
Retention), Section 6.5 (Limitation of Liability), Section 6.6 (Other Agreements Providing for
Exchange of Information), Section 6.7 (Production of Witnesses; Records; Cooperation), Section 6.8
(Privileged Matters), Section 6.9 (Confidentiality), and Section 6.10 (Protective Arrangements) of
the Separation Agreement are hereby incorporated into this Section 5 as if fully set forth herein.
To the extent (a) Parent, or any member of the Parent Group, receives from SpinCo, or any member of
the SpinCo Group, or (b) SpinCo, or any member of the SpinCo Group receives from Parent, or any
member of the Parent Group, any Information that is trade secret under applicable law, the five (5)
year confidentiality period of Section 6.9(a) of the Separation Agreement with respect to such
Information shall be extended until such time as the received Information is no longer trade secret.
6. FURTHER ASSURANCES AND ADDITIONAL COVENANTS 6.1 Further Assurances. (a) In addition to the
actions specifically provided for elsewhere in this Agreement, each of the Parties shall use its
commercially reasonable efforts, prior to, on and after the Effective Time, to take, or cause to be
taken, all actions, and to do, or cause to be done, all things, reasonably necessary, proper or
advisable under applicable Laws, regulations and agreements to consummate and make effective the
transactions contemplated by this Agreement. (b) Without limiting the foregoing, prior to, on and
after the Effective Time, each Party hereto shall cooperate with the other Party, and without any
further consideration, but at the expense of the requesting Party, to execute and deliver, or use
its reasonable best efforts to cause to be executed and delivered, all instruments, including
instruments of conveyance, assignment and transfer, and to make all filings with, and to obtain all
Approvals or Notifications of, any Governmental Authority or any other Person under any permit,
license, agreement, indenture or other instrument (including any consents or Governmental
Approvals), and to take all such other actions as such Party may reasonably be requested to take by
the other Party from time to time, consistent with the terms of this Agreement, in order to
effectuate the provisions and purposes of this Agreement and the transfers of the SpinCo IP Assets
and the assignment and assumption of the SpinCo IP Liabilities and the other transactions
contemplated hereby and thereby. (c) On or prior to the Effective Time, Parent and SpinCo in their
respective capacities as direct and indirect shareholders of the members of their Groups, shall each
ratify any actions which are reasonably necessary or desirable to be taken by Parent, SpinCo or any
of the members of their respective Groups, as the case may be, to effectuate the transactions
contemplated by this Agreement. 7. TERMINATION 7.1 Termination. This Agreement may be terminated at
any time prior to the Effective Time by Parent, in its sole and absolute discretion, without the
approval or consent of

-17-
<!-- page 18 -->
any other Person, including SpinCo. After the Effective Time, this Agreement may not be terminated
except by an agreement in writing signed by a duly authorized officer of each of the Parties. 7.2
Effect of Termination. In the event of any termination of this Agreement prior to the Effective
Time, no Party (nor any of its directors, officers, employees or agents) shall have any Liability or
further obligation to the other Party by reason of this Agreement. 8. MISCELLANEOUS 8.1
Counterparts; Entire Agreement; Corporate Power. (a) This Agreement may be executed in one or more
counterparts, all of which shall be considered one and the same agreement, and shall become
effective when one or more counterparts have been signed by each of the Parties and delivered to the
other Party. (b) This Agreement and the Separation Agreement and the Exhibits, Schedules and
appendices hereto and thereto contain the entire agreement between the Parties with respect to the
subject matter hereof and supersede all previous agreements, negotiations, discussions, writings,
understandings, commitments and conversations with respect to such subject matter, and there are no
agreements or understandings between the Parties with respect to this Agreement. (c) Parent
represents on behalf of itself and each other member of the Parent Group, and SpinCo represents on
behalf of itself and each other member of the SpinCo Group, as follows: (i) each such Person has the
requisite corporate or other power and authority and has taken all corporate or other action
necessary in order to execute, deliver and perform this Agreement and to consummate the transactions
contemplated hereby; and (ii) this Agreement has been duly executed and delivered by it and
constitutes a valid and binding agreement of it enforceable in accordance with the terms thereof.
(d) Each Party acknowledges that it and each other Party may execute this Agreement by facsimile,
stamp or mechanical signature, and that delivery of an executed counterpart of a signature page to
this Agreement (whether executed by manual, stamp or mechanical signature) by facsimile or by email
in portable document format (PDF) shall be effective as delivery of such executed counterpart of
this Agreement. Each Party expressly adopts and confirms each such facsimile, stamp or mechanical
signature (regardless of whether delivered in person, by mail, by courier, by facsimile or by email
in portable document format (PDF)) made in its respective name as if it were a manual signature
delivered in person, agrees that it will not assert that any such signature or delivery is not
adequate to bind such Party to the same extent as if it were signed manually and delivered in person
and agrees that, at the reasonable request of the other Party at any time, it will as promptly as
reasonably practicable cause this Agreement to be manually executed (any such execution to be as of
the date of the initial date thereof) and delivered in person, by mail or by courier.

-18-
<!-- page 19 -->
8.2 Other Incorporated Miscellaneous Terms. The terms and conditions set forth in Section 10.2
(Governing Law) through Section 10.19 (Mutual Drafting) of the Separation Agreement are hereby
incorporated into this Section 8 as if fully set forth herein. [Remainder of page intentionally left
blank]

-19-
<!-- page 20 -->
IN WITNESS WHEREOF, the Parties have caused this Intellectual Property Agreement to be executed by
their duly authorized representatives. WESTROCK COMPANY By: /s/ Robert B. McIntosh Name: Robert B.
McIntosh Title: Executive Vice President, General Counsel INGEVITY CORPORATION By: /s/ D. Michael
Wilson Name: D. Michael Wilson Title: President and Chief Executive Officer
