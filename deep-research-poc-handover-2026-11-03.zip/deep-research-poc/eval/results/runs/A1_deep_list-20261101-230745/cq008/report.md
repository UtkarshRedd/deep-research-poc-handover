# Which jurisdiction's law governs the Co-Branding and Advertising Agreement between I-ES...

*Question:* Which jurisdiction's law governs the Co-Branding and Advertising Agreement between I-ESCROW, INC. and 2THEMART.COM, INC. (dated 1999-06-21)?

## Identify Governing Law Clause

The Co-Branding and Advertising Agreement between I-ESCROW, INC. and 2THEMART.COM, INC. dated 1999-06-21 is governed by the laws of the State of California. [70c514900ffaabe0 p.7] Section 12.1 states: "12.1 GOVERNING LAW. [uncited] This Agreement will be governed and construed in accordance with the laws of the State of California without giving effect to conflict of laws principles. [uncited] Both parties submit to personal jurisdiction in California and further agree that any cause of action arising under this Agreement shall be brought in a court in Orange County, California." [70c514900ffaabe0 p.7]

## Verify Contract Execution

The document titled "CO-BRANDING AND ADVERTISING AGREEMENT" is dated 1999-06-21. [70c514900ffaabe0 p.1] The parties to this agreement are I-ESCROW, INC. [uncited] ("i-Escrow") and 2THEMART.COM, INC. [uncited] ("2TheMart"). [70c514900ffaabe0 p.1]

[GAP] The governing law clause is not present in the provided evidence.

## Verification appendix

Claims: 9 · supported: 4 · partially: 0 · dropped: 0 · gaps: 5 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e2→[70c514900ffaabe0 p.7] |  |
| s1.2 | s1 | gap |  |  | no evidence cited |
| s1.3 | s1 | gap |  |  | no evidence cited |
| s1.4 | s1 | keep | 1.00 | e2→[70c514900ffaabe0 p.7] |  |
| s2.1 | s2 | keep | 1.00 | e1→[70c514900ffaabe0 p.1] |  |
| s2.2 | s2 | gap |  |  | no evidence cited |
| s2.3 | s2 | gap |  |  | no evidence cited |
| s2.4 | s2 | keep | 1.00 | e1→[70c514900ffaabe0 p.1] |  |
| s2.5 | s2 | gap |  |  |  |

### Evidence

- e1 [70c514900ffaabe0 p.1 L2-7] keep (1.0): "# CO-BRANDING AND ADVERTISING AGREEMENT | Field | Value | |---|---| | Document Type | Co-Branding Agreement | | Agreement Date | 1999-06-21 | | Parties | I-ESCROW, INC. ("i-Escrow" ); 2THEMART.COM, INC. ("2TheMart")"
- e2 [70c514900ffaabe0 p.7 L343-346] keep (1.0): "12.1 GOVERNING LAW. This Agreement will be governed and construed in accordance with the laws of the State of California without giving effect to conflict of laws principles. Both parties submit to personal jurisdiction in California and fu…"
