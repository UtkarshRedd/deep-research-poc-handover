<!-- page 1 -->
# JOINT FILING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| Agreement Date | 2020-05-11 |
| Parties | VESA EQUITY INVESTMENT S.À R.L.; EP INVESTMENT S.À R.L.; DANIEL KŘETÍNSKÝ |
| Source | CUAD v1 / MACY_S,INC_05_11_2020-EX-99.4-JOINT FILING AGREEMENT |

Exhibit 99.4 JOINT FILING AGREEMENT In accordance with Rule 13d-1(k)(1) promulgated under the
Securities Exchange Act of 1934, as amended, the undersigned hereby agree to the joint filing with
each of the Reporting Persons (as such term is defined in the Schedule 13D referred to below) on
behalf of each of them of a statement on Schedule 13D (including amendments thereto and statements
on Schedule 13G) with respect to the Common Stock, par value $0.01 per share of Macy's, Inc., a
corporation organized under the laws of the State of Delaware, and that this agreement may be
included as an exhibit to such joint filing. The undersigned acknowledge that each shall be
responsible for the timely filing of any amendments, and for the completeness and accuracy of the
information concerning the undersigned or contained herein and therein, but shall not be responsible
for the completeness and accuracy of the information concerning the others. IN WITNESS WHEREOF, the
undersigned hereby execute this agreement as of May 11, 2020. VESA EQUITY INVESTMENT S.À R.L. /s/
Marek Spurny By: Marek Spurny Title:Authorized Signatory /s/ Pascal Leclerc By: Pascal Leclerc
Title:Authorized Signatory EP INVESTMENT S.À R.L. /s/ Marek Spurny By: Marek Spurny Title:Authorized
Signatory /s/ Pascal Leclerc By: Pascal Leclerc Title:Authorized Signatory DANIEL KŘETÍNSKÝ /s/
Daniel Kretinsky By: Daniel Kretinsky
