"""Verification. Tier 1 (tier1.py) is deterministic n-gram alignment of each quote against
its cited page — EvidenT-style. Tier 2 (tier2.py, Phase 7) is a grouped agentic re-check.
Tier 2 never overrides a tier-1 drop.
"""
