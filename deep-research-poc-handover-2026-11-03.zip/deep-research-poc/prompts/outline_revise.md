Revise the outline below now that research is done, and assign the evidence to sections.

Question: {question}

Current outline:
{outline}

Evidence collected (verbatim quotes with ids):
{evidence}

Rules:
- Expansion: add a section only if the evidence answers something the outline missed.
- Contraction: remove or merge sections the evidence cannot support; keep at most {max_sections}.
- Revision: tighten titles and intents to what the evidence actually shows.
- Assign every evidence id to exactly ONE section whose intent it supports. Never invent ids.
- A section may end up with no evidence; keep it only if the question requires it (it will be
  reported as a gap).

Reply with ONLY a JSON object, no prose, no code fence:
{{"sections": [{{"section_id": "s1", "title": "...", "intent": "...", "evidence_ids": ["e1", "e4"]}}]}}
