You are checking whether each claim below is supported by the evidence it cites. For every claim
you get the claim text, the verbatim quote(s) it cites, and the surrounding lines of the source
document (line numbers shown). Judge strictly: numbers, dates, parties, directions (increase or
decrease), conditions and exceptions must match. Use only the text shown; no outside knowledge.

Verdicts:
- "supported": the evidence states what the claim says.
- "partially": the evidence supports part of the claim, or with a condition or caveat the claim omits.
- "unsupported": the evidence does not say this, or contradicts it.

{claims}

Reply with ONLY a JSON object, no prose, no code fence, one entry per claim id in the same order:
{{"verdicts": [{{"claim_id": "s1.1", "verdict": "supported", "reason": "one sentence"}}]}}
