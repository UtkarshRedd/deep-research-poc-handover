<!-- page 1 -->
# Strategic Alliance Agreement
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2006-06-14 |
| Parties | UTEK Corporation ("UTEK"); Manakoa Services Corporation ("MKOS") |
| Source | CUAD v1 / MANAKOASERVICESCORP_11_21_2007-EX-7.5-STRATEGIC ALLIANCE AGREEMENT |

Exhibit 7.5

STRATEGIC ALLIANCE AGREEMENT

This Strategic Alliance Agreement is made and entered into this 14 day of June 2006, by and between
UTEK Corporation ("UTEK"), a Delaware Corporation, 2109 Palm Avenue, Tampa, Florida 33605, and
Manakoa Services Corporation ("MKOS"), a Nevada Corporation, 7203 W Deschutes Avenue, Suite B,
Kennewick, Washington 99336.

WITNESSETH:

WHEREAS, MKOS desires to engage UTEK to provide the services as set forth in this Agreement, and

WHEREAS, UTEK is agreeable to provide these services.

NOW THEREFORE, in consideration of the mutual promise made in this Agreement, and for other good and
valuable consideration, the receipt and sufficiency of which is hereby acknowledged, the parties
hereto agree as follows:

I. SERVICES

A. To identify technology acquisition opportunities for MKOS from research universities and
government laboratories, while maintaining MKOS's confidentiality.

B. In conjunction with the Services, UTEK agrees to:

I. Make itself available at the offices of MKOS or at another mutually agreed upon place, during
normal business hours, for reasonable periods of time, subject to reasonable advance notice and
mutually convenient scheduling.

II. Make itself available for telephone conferences with the principal officer(s) of MKOS during
normal business hours.

C. MKOS will have 30-days from receipt of information to determine if they wish to go forward with
the technology license. UTEK, after 30 days, shall have the right to present the technology to other
clients.

D. MKOS acknowledges that the sources of technologies represented by UTEK are 3rd party research
institutions for which UTEK does not control whether the technology will be shown to other parties
by the licensor.

E. At MKOS's request and upon mutual agreement between MKOS and UTEK, UTEK will negotiate and seek
to acquire a license to the requested technology for subsequent sale to and acquisition by MKOS.

F. On a case-by-case basis, at MKOS's request and UTEK's sole discretion, UTEK will propose an
equity-financing plan for MKOS's consideration, to finance select technology acquisition
opportunities for MKOS.

G. MKOS will not seek to acquire any technologies presented to MKOS by UTEK from the technology
developer directly or indirectly for a period of 24 months following the termination of this
Strategic Alliance Agreement. - 1 -
<!-- page 2 -->
H. UTEK shall devote such time and efforts, as it deems commercially reasonable, under the
circumstances to the affairs of MKOS, as is commercially reasonable and adequate to render the
Services contemplated by this Agreement.

I. UTEK cannot guarantee results on behalf of MKOS, but shall pursue all reasonable avenues
available through its network of contacts. The acceptance and consumption of any transaction is
subject to acceptance of the terms and conditions by in its sole discretion.

J. MKOS will cooperate with UTEK and will promptly provide UTEK with all pertinent materials and
requested information in order for UTEK to perform its Services pursuant to this Agreement

II. INDEPENDENT CONTRACTOR

UTEK shall be, and in all respects be deemed to be, an independent contractor in the performance of
its duties hereunder.

A. MKOS shall be solely responsible for making all payments to and on behalf of its employees and
UTEK shall in no event be liable for any debts or other liabilities of MKOS.

B. UTEK shall not have or be deemed to have, fiduciary obligations or duties to, and shall be able
to pursue, conduct and carry on for its own account (or for the account of others) such activities,
ventures, businesses and other pursuits as UTEK in its sole, absolute and unfettered discretion, may
elect.

C. Notwithstanding the above, no activity, venture, business or other pursuit of UTEK, during the
term of this Agreement shall conflict with UTEK's obligations under this Agreement.

III. EXPENSES

It is expressly agreed and understood that each party shall be responsible for its own normal and
reasonable out-of-pocket expenses.

IV. COMPENSATION

A. In consideration for providing these Services, MKOS shall pay UTEK $120,000 in the form of
unregistered shares of common stock (923,077 shares) upon the execution of this Strategic Alliance
Agreement. 1/12th of the shares (76,923) shall vest each month during the term of this Agreement. In
lieu of payment of shares, MKOS shall have the option of paying UTEK $10,000 per month for the
Services described in this Agreement. If this Agreement is terminated any unvested shares will be
returned to MKOS.

B. In consideration for the services to be provided herein, MKOS agrees that it will remit the
agreed upon stock certificate or cash payment within five (5) days of both parties executing this
Agreement. If no consideration is received in the timeline, UTEK has the unilateral option to
terminate this Agreement.

C. MKOS agrees that UTEK shall be entitled to additional compensation as follows:

Technology Transfer: When a technology is shown to MKOS that MKOS wants to acquire, UTEK will seek
to acquire the license to a technology through one of its subsidiaries. UTEK will then seek to
provide a term sheet to MKOS outlining the consideration to be paid by MKOS for the acquisition of
this technology. If MKOS executes the term sheet, agreeing to the terms set forth, UTEK shall
transfer this subsidiary to MKOS in a stock for stock exchange under an "Agreement and Plan of
Acquisition." The consideration to be paid by MKOS to UTEK will be based upon a markup to the value
of the license and other assets in the subsidiary as determined by UTEK and agreed to by both
parties. - 2 -
<!-- page 3 -->
V. TERM AND TERMINATION

The term of the Agreement will be for 12 months unless terminated sooner. This Agreement may be
renewed upon mutual, written agreement of the parties. Either party may terminate this Agreement at
any time with 30 days written notice.

VI. LEGAL COMPLIANCE

MKOS agrees that it will put in place, if it has not already done so, policies and procedures
relating to and addressing, with the commercially reasonable intent to ensure compliance with,
applicable securities laws, rules and regulations, including, but not limited to:

A. Disclosure requirements regarding the required disclosure of the nature and terms of UTEK's
relationship with, including, but not limited to press releases, publications on its web site,
letters to investors and telephone or other personal communication with potential or current
investors.

B. No press releases or any other forms of communication to third parties, which mention both UTEK
and MKOS, shall be released without the prior written consent and approval of both UTEK and MKOS.

C. UTEK represents to MKOS that a) it has the experience as may be necessary to perform all the
required, b) all Services will be performed in a professional manner, and c) all individuals it
provides to perform the Services will be appropriately qualified and subject to appropriate
agreements concerning the protection of trade secrets and confidential information of which such
persons may have access to over the term of this Agreement.

D. Until termination of the engagement, MKOS will notify UTEK promptly of the occurrence of any
event, which might materially affect the condition (financial or otherwise), or prospects of MKOS.

VII. CONFIDENTIAL DATA

A. UTEK shall not divulge to others, any trade secret or confidential information, knowledge, or
data concerning or pertaining to the business and affairs of MKOS, obtained by UTEK as a result of
its engagement hereunder, unless authorized, in writing by MKOS. UTEK represents and warrants that
it has established appropriate internal procedures for protecting the trade secrets and confidential
information of, MKOS including, without limitation, restrictions on disclosure of such information
to employees and other persons who may be engaged in such information to employees and other persons
who may be engaged in rendering services to any person, firm or entity which may be a competitor of.

B. MKOS shall not divulge to others, any trade secret or confidential information, knowledge, or
data concerning or pertaining to the business and affairs of UTEK or confidential information
revealed by UTEK obtained as a result of its engagement hereunder, unless authorized, in writing, by
UTEK, and agreed to be bound by any confidentiality agreement entered into by UTEK with any third
party for the purpose of reviewing technology acquisition opportunities.

C. UTEK shall not be required in the performance of its duties to divulge to MKOS, or any officer,
director, agent or employee of MKOS, any secret or confidential information, knowledge, or data
concerning any other person, firm or entity (including, but not limited to, any such person, firm or
entity which may be a competitor or potential competitor of) which UTEK may have or be able to
obtain other than as a result of the relationship established by this Agreement. - 3 -
<!-- page 4 -->
VIII. OTHER MATERIAL TERMS AND CONDITIONS

A. INDEMNITY.

1. UTEK shall indemnify, defend and hold harmless MKOS from and against any and all losses incurred
by MKOS which arise out of or result from misrepresentation, breach of warranty or breach or non-
fulfillment of any covenant contained herein or Schedules annexed hereto or in any other documents
or instruments furnished by UTEK pursuant hereto or in connection with this Agreement.

2. MKOS shall indemnify, defend and hold harmless UTEK from and against any and all losses incurred
by UTEK which arise out of or result from misrepresentation, breach of warranty or breach or
non-fulfillment of any covenant contained herein or Schedules annexed hereto or in any other
documents or instruments furnished by MKOS pursuant hereto or in connection with this Agreement.

B. PROVISIONS. Neither termination nor completion of the assignment shall affect the provisions of
this Agreement, and the Indemnification Provisions that are incorporated herein, which shall remain
operative and in full force and effect.

C. SOLICITATION. MKOS agrees that for a twenty four months (24) following the execution of this
Agreement, MKOS shall not, without UTEK's prior written consent, directly or indirectly solicit for
employment any present employee of UTEK, or request, induce or advise any employee of UTEK to leave
the employ of UTEK. In turn, UTEK agrees that it will not directly or indirectly solicit any present
employee of MKOS.

D. ADDITIONAL INSTRUMENTS. Each of the parties shall from time to time, at the request of others,
execute, acknowledge and deliver to the other party any and all further instruments that may be
reasonably required to give full effect and force to the provisions of this Agreement.

E. ENTIRE AGREEMENT. Each of the parties hereby covenants that this Agreement, is intended to and
does contain and embody herein all of the understandings and agreements, both written or oral, of
the parties hereby with respect to the subject matter of this Agreement, and that there exists no
oral agreement or understanding expressed or implied liability, whereby the absolute, final and
unconditional character and nature of this Agreement shall be in any way invalidated, empowered or
affected. There are no representations, warranties or covenants other than those set forth herein.

F. ASSIGNMENTS. The benefits of the Agreement shall inure to the respective successors and assignees
of the parties and assigns and representatives, and the obligations and liabilities assumed in this
Agreement by the parties hereto shall be binding upon their respective successors and assigns;
provided that the rights and obligations of UTEK under this Agreement may not be assigned or
delegated without the prior written consent of MKOS and any such purported assignment shall be null
and void. Notwithstanding the foregoing, UTEK may assign this Agreement or any portion of its
Compensation as outlined herein to its subsidiaries in its sole discretion.

G. ORIGINALS. This Agreement may be executed in any number of counterparts, each of which so
executed shall be deemed an original and constitute one and the same agreement.

H. NOTICES. All notices that are required to be or may be sent pursuant to the provision of this
Agreement shall be sent by certified mail, return receipt requested, or by overnight package
delivery service to each of the parties at the addresses appearing herein, and shall count from the
date of mailing or the validated air bill.

I. MODIFICATION AND WAIVER. A modification or waiver of any of the provisions of this Agreement
shall be effective only if made in writing and executed with the same formality as this Agreement.
The failure of any party to insist upon strict performance of any of the provisions of this
Agreement shall not be construed as a waiver of any subsequent default of the same or similar nature
or of any other nature. - 4 -
<!-- page 5 -->
J. INJUNCTIVE RELIEF. Solely by virtue of their respective execution of this Agreement and in
consideration for the mutual covenants of each other, MKOS and UTEK hereby agree, consent and
acknowledge that, in the event of a breach of any material term of this Agreement, the non-breaching
party will be without adequate remedy-at-law and shall therefore, be entitled to immediately redress
any material breach of this Agreement by temporary or permanent injunctive or mandatory relief
obtained in an action or proceeding instituted in any court of competent jurisdiction without the
necessity of proving damages and without prejudice to any other remedies which the non-breaching
party may have at law or in equity.

K. ATTORNEY'S FEES. If any arbitration, litigation, action, suit, or other proceeding is instituted
to remedy, prevent or obtain relief from a breach of this Agreement, in relation to a breach of this
Agreement or pertaining to a declaration of rights under this Agreement, the prevailing party will
recover all such party's attorneys' fees incurred in each and every such action, suit or other
proceeding, including any and all appeals or petitions there from. As used in this Agreement,
attorneys' fees will be deemed to be the full and actual cost of any legal services actually
performed in connection with the matters involved, including those related to any appeal to the
enforcement of any judgment calculated on the basis of the usual fee charged by attorneys performing
such services.

L. INVESTMENT COMPANY STATUS. MKOS represents that it is not an investment company, registered or
unregistered.

APPROVED AND AGREED: UTEK Corporation Manakoa Services Corporation

By: /s/ Doug Schaedler By: /s/ Chris Outwater Doug Schaedler Chris Outwater Chief Operating Officer
President - 5 -
