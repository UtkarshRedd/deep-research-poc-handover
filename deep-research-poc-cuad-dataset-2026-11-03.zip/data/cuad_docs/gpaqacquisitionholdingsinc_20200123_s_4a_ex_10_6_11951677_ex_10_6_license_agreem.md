<!-- page 1 -->
# MEDIA LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| SEC Filing Date | 2020-01-23 |
| Parties | NATIONAL FOOTBALL MUSEUM, INC. d/b/a Pro Football Hall of Fame ("PFHOF"); HOF Village, LLC ("Village Media Company"); HOF Village, LLC ("HOFV") |
| Source | CUAD v1 / GpaqAcquisitionHoldingsInc_20200123_S-4A_EX-10.6_11951677_EX-10.6_License Agreement |

Exhibit 10.6 EXECUTION COPY MEDIA LICENSE AGREEMENT THIS MEDIA LICENSE AGREEMENT (this "Agreement")
is made and effective as of the date of the Closing (as defined in the Merger Agreement (as defined
below)) (the "Effective Date"), between NATIONAL FOOTBALL MUSEUM, INC., an Ohio non-profit
corporation, doing business as Pro Football Hall of Fame ("PFHOF"), HOF Village Media Group, LLC
(the "Village Media Company"), a Delaware limited liability company that is a wholly-owned
subsidiary of HOF Village, LLC, a Delaware limited liability company ("HOFV") and, solely for
purposes of Section 4.5, HOFV; each a "Party" and collectively, the "Parties". RECITALS A. In
connection with a Master Transaction Agreement dated December 11, 2018, as amended of even date
herewith and as it may be amended or otherwise modified from time to time (the "Master Transaction
Agreement"), by and among the Parties and certain other parties, as well as other agreements
referenced in the Master Transaction Agreement relating to the development of the Hall of Fame
Village Complex (the "Village"), the Parties have determined that it is appropriate and in the
Parties' best interests to enter into a media license agreement for the exploitation of certain
PFHOF assets by the Village Media Company and its Affiliates. B. The Parties further desire to
provide for the sharing of media-related opportunities between the Village Media Company and Hall of
Fame Media Group, LLC, an Ohio limited liability company and indirect wholly-owned subsidiary of
PFHOF (the "HOF Media Company"). AGREEMENT NOW THEREFORE, based upon the foregoing and other good
and valuable consideration, the receipt and sufficiency of which are hereby acknowledged (including
but not limited to consideration outlined in the Master Transaction Agreement), and intending to be
legally bound hereby, the Parties agree as follows: 1. DEFINITIONS 1.1 "Advisory Board" shall mean a
board of advisors to the Village Media Company and the HOF Media Company made up of four (4)
individuals - (i) the Chief Executive Officer of HOFV, (ii) the Chief Executive Officer of PFHOF,
(iii) the Chief Executive Officer of the Village Media Company and (iv) the Executive Director of
the HOF Media Company; provided, that if the Chief Executive Officer of the Village Media Company
and the Executive Director of the HOF Media Company are the same individual (as is expected as of
the Effective Date), then the fourth member of the Advisory Board shall be appointed by unanimous
agreement of the foregoing individuals. The Advisory Board's function shall be to facilitate the
consideration of opportunities presented to either or both of the Village Media Company and the HOF
Media Company.

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 2 -->
1.2 "Affiliate" with respect to the Village Media Company shall mean any of HOFV and any of the
following entities so long as it is directly or indirectly controlled by, or is under common
control, with HOFV: HOF Village Stadium, LLC; HOF Village Parking, LLC; HOF Village Land, LLC; HOF
Village Youth Fields, LLC; HOF Village Hotel I, LLC; HOF Village Sports Business, LLC; Youth Sports
Management, LLC; HOF Village Parking Management I, LLC; HOF Village Residences I, LLC; HOF Village
Center for Excellence, LLC; HOF Village Center for Performance, LLC; HOF Experience, LLC; and
JCIHOFV Financing, LLC. "Affiliate" with respect to PFHOF shall mean any entity that is directly or
indirectly controlled by, or is under common control with, PFHOF. For purposes of this definition,
"control" means an equity or income interest of fifty percent (50%) or more, or the possession of
the power, directly or indirectly, to direct or cause the direction of the management and policies
of the Affiliate, whether through the ownership of voting securities, by contract, or otherwise. 1.3
"Exploit" or "Exploitation" means to reproduce, distribute, digitally transmit, publish, publicly
perform or otherwise display via any and all means of video or audio-visual media, or means of
distribution except as set forth in this Agreement as to manner, frequency or duration of use
including, but not limited to: film, television, streaming, short-form streaming, social media,
SVOD, IVOD, pay per view, OTT, theatrical professional/non-professional productions, location based
entertainment, music, publishing, holographic mediums, projection mapping, haptic mediums, as well
as any marketing, advertising, and promotional activities thereof in any medium currently existing
or hereinafter created. 1.4 "Merger Agreement" means that certain Agreement and Plan of Merger,
dated September 16, 2019, by and among GPAQ Acquisition Holdings, Inc., a Delaware corporation,
Gordon Pointe Acquisition Corp, a Delaware corporation, GPAQ Acquiror Merger Sub, Inc., a Delaware
corporation, GPAQ Company Merger Sub, LLC, a Delaware limited liability company, HOFV, and HOF
Village Newco, LLC, a Delaware limited liability company. 1.5 "Person" means an individual,
corporation, partnership, association, limited liability company, joint venture, trust, estate,
joint stock company or other similar organization, government or political subdivision thereof, or
any other entity. 1.6 "PFHOF Works" shall mean the written, audio, visual, audiovisual, or
choreographic works currently or hereafter owned by or freely sub-licensable by PFHOF.

2

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 3 -->
2. GRANT OF RIGHTS 2.1 Subject to the terms of this Agreement (including, without limitation,
Sections 2.3, 2.4, 2.6 and 5 below), PFHOF hereby grants to the Village Media Company a worldwide,
non-exclusive, limited, non-sublicenseable and non-assignable (except to the extent set forth in
this Agreement) right and license to (a) Exploit the PFHOF Works and (b) edit, supplement or
otherwise adapt, incorporate or otherwise utilize, the PFHOF Works to create, produce and Exploit
new, original work(s) (each such work in this clause (b), a "HOFV Work"). For the avoidance of
doubt, after the termination or expiration of this Agreement, the Village Media Company and its
permitted licensees shall continue to have the right to fully exploit, use, and Exploit the HOFV
Works for the length of the term of the license granted by PFHOF in connection with such HOFV Work
pursuant to Section 2.3; provided that the length of the term of such license shall be a minimum of
five (5) years. Any HOFV Works created pursuant to this Agreement shall exclusively be owned by the
Village Media Company; provided, however, that, (i) PFHOF shall own all right, title, interest, and
copyright in and to the underlying PFHOF Work(s) as further set forth in Section 2.5 and (ii) the
Village Media Company's ownership is subject in all events to any Rights Restrictions and the terms
of the license (including the term of such license) granted by PFHOF in connection with such HOFV
Work pursuant to Section 2.3. 2.2 In addition to any rights set forth herein, PFHOF shall have the
right and license to Exploit HOFV Works, at no fee or charge to PFHOF or any of its Affiliates, for
educational, not-for-profit purposes aligned with the mission of PFHOF which usage shall not
diminish the value of the Village Media Company's or its Affiliates' Exploitation of such HOFV Work
in accordance with the terms of this Agreement. HOFV must preapprove any of PFHOF's proposed plans
to Exploit the HOFV Works, such approval not to be unreasonably withheld. 2.3 Notwithstanding
anything to the contrary in this Agreement, PFHOF shall have the right to approve (in its sole and
absolute discretion) any and all usage of, and Village Media Company's (and its Affiliates' and
permitted licensees') plans to Exploit, the PFHOF Works (including any inclusion of any PFHOF Work
in any HOFV Work and the term of such usage). Prior to any initial Exploitation of a PFHOF Work, the
Village Media Company, at its own expense, must furnish to the Advisory Board and PFHOF a written
notice ("Notice") which Notice will set forth the Village Media Company's proposal for Exploitation
of a PFHOF Work (whether by itself or as incorporated into a HOFV Work), which proposal shall at a
minimum specify the applicable PFHOF Work(s) to be Exploited by the Village Media Company, the
nature and location of the proposed Exploitation and a pro forma specifying the economics and
approximate time period related to such Exploitation. The Advisory Board shall, within fourteen (14)
days of its receipt of the Notice, make a recommendation to PFHOF to either approve or reject such
proposal as set forth in the Notice. PFHOF shall, within fourteen (14) days of its receipt of the
recommendation of the Advisory Board, either approve or reject the proposal as set forth in the
Notice. If PFHOF does not approve the proposal as set forth in the Notice within fourteen (14) days
of PFHOF's receipt of the recommendation of the Advisory Board, such proposal shall be deemed
rejected by PFHOF. In the event that a proposal is rejected (or deemed rejected) by PFHOF, PFHOF
shall, upon request from the Village Media Company, provide a written explanation (with reasonable
detail) outlining its reason for rejecting such proposal. Upon PFHOF's approval with respect to any
such proposal, the Village Media Company (and its Affiliates and permitted licensees) may Exploit
the applicable PFHOF Work(s) so long as such Exploitation is in conformance with the proposal as
approved by PFHOF (including any proposed sublicenses in accordance with Section 2.4).

3

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 4 -->
2.4 The Village Media Company shall have the right to sublicense (a) the production and creation of
the HOFV Works and (b) Exploitation of the PFHOF Works hereunder to any of its Affiliates; provided,
that, Village Media Company shall (x) cause such sublicenses to comply with all terms and conditions
of this Agreement and (y) not be relieved of any of its obligations under this Agreement as a result
of any such sublicense, and will be primarily responsible for any acts or omissions of such
sublicensees. 2.5 Notwithstanding anything to the contrary contained in this Agreement, as between
PFHOF (and its Affiliates), on the one hand, and the Village Media Company (and its Affiliates), on
the other hand, PFHOF shall own and control all right, title, interest, and copyright in and to the
PFHOF Works, including, without, limitation, any and all PFHOF Work(s) utilized by, or incorporated
in, any HOFV Work and all of its constituent elements, which shall include, without limitation, all
feeds recorded by or on behalf of PFHOF in connection with the production of such PFHOF Work, all
event footage contained therein and all information and data concerning such PFHOF Work, and all
derivatives of the foregoing (except for derivatives that constitute HOFV Works, which ownership
shall be retained by the Village Media Company). The Village Media Company agrees, on behalf of
itself and its Affiliates and their permitted sublicensees, that all uses by the Village Media
Company or any of its Affiliates or their respective permitted sublicensees of the PFHOF Work shall
inure to the benefit of PFHOF, and any right that may accrue to the Village Media Company, any of
its Affiliates or any of their respective permitted sublicensees related thereto and any goodwill
associated therewith are hereby granted and assigned to PFHOF or its designee. Notwithstanding the
foregoing, to the extent any HOFV Work incorporates any HOFV trademarks, service marks, or trade
dress ("HOFV Trademarks"), use of such HOFV Trademarks shall inure solely to HOFV's benefit. The
Village Media Company shall not, and shall cause its Affiliates and their respective permitted
sublicensees not to, whether during the Term or thereafter, challenge (a) the rights of PFHOF in and
to any PFHOF Work, (b) the validity of any PFHOF Work, (c) PFHOF's right to grant rights or licenses
relating to the PFHOF Works or (d) the validity, legality, or enforceability of this Agreement. 2.6
The Village Media Company acknowledges the existence of agreements in effect as of the Effective
Date between PFHOF and certain licensees and/or licensors of PFHOF Works that may restrict or
prohibit PFHOF from making certain PFHOF Works available for use or Exploitation under this
Agreement, including, without limitation that certain agreement effective as of June 25, 2013 among
NFL Enterprises LLC, PFHOF and PFHOF Enshrinees Events, Inc. d/b/a Pro Football Hall of Fame
Enterprisers (the "NFLN Agreement") (any and all such restrictions and prohibitions, collectively,
"Rights Restrictions") and that the Village Media Company's rights under this Agreement shall
subject and subordinate to any such Rights Restrictions for so long as such Rights Restrictions are
in effect. Without limiting the foregoing, in the event that the Village Media Company is prohibited
from pursing and launching an opportunity to create and Exploit an HOFV Work or use or Exploit an
existing PFHOF Work pursuant to Sections 2.7, 2.8 or 2.9 as a result of a Rights Restriction under
the terms of the NFLN Agreement, then the Parties shall negotiate in good faith a reasonable
decrease in the Annual Guarantee for the calendar year in which such opportunity is unavailable.

4

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 5 -->
2.7 PFHOF agrees not to grant licenses to create new PFHOF Works, except with respect to the
categories identified on Exhibit A, to any third party during the Term without first offering to the
Village Media Company the right of first refusal to create such PFHOF Works on equal terms, subject
to any Rights Restrictions. If PFHOF desires to offer a license to any third party or if it receives
any bona fide offer from a third party that it is willing to accept, it shall promptly communicate
such offer, including the specific terms and business plan relating to such offer, to the Village
Media Company and provide the Village Media Company with at least fourteen (14) days to exercise its
right of first refusal. If the Village Media Company elects to exercise its right of first refusal,
the terms of the offer shall apply, the applicable license shall be subject to the terms and
conditions of this Agreement and the Village Media Company shall pay to PFHOF a License Fee (as
defined below) for such license in accordance with this Agreement. If the Village Media Company does
not exercise its right of first refusal, PFHOF shall have the right to grant a license with respect
to such third party on the same terms originally provided to the Village Media Company. 2.8 PFHOF
agrees that during the Term, except with respect to the categories identified on Exhibit A, it will
not create new PFHOF Works without first granting the Village Media Company a right of first offer
to create such PFHOF Work, subject to any Rights Restrictions. If PFHOF desires to create new PFHOF
Works, it shall present a proposed business plan in writing to the Village Media Company. The
Village Media Company will have fourteen (14) days to review such business plan and elect to proceed
under the business plan. If the Village Media Company elects proceed under the business plan, then
creation of such PFHOF Work shall be subject to the terms and conditions of this Agreement and the
Village Media Company shall pay to PFHOF a License Fee in accordance with this Agreement for the
license to create the PFHOF Work. If the Village Media Company does not make such an election, then
PFHOF shall have the right to create such PFHOF Work itself. 2.9 PFHOF agrees that during the Term,
except with respect to the categories identified on Exhibit A, if PFHOF desires to either exploit
itself or license a third party to exploit an existing PFHOF Work, it shall first give the Village
Media Company a right of first offer to exclusively license such PFHOF Work, subject to any Rights
Restrictions. In such a case, PFHOF shall promptly notify the Village Media Company and provide the
Village Media Company with any bona fide third party offer to license such PFHOF Work that PFHOF is
willing to accept, including any specific terms and proposed business plan relating to such offer.
The Parties shall then negotiate in good faith an agreement to exclusively license the particular
PFHOF Work. If the Parties reach an agreement within thirty (30) days, then the applicable license
shall be subject to the terms and conditions of this Agreement and the Village Media Company shall
pay to PFHOF a License Fee for such license in accordance with this Agreement. If the Parties cannot
reach an agreement within thirty (30) days, then PFHOF shall have the right to exploit or license
the PFHOF Work itself.

5

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 6 -->
2.10 PFHOF represents and warrants to the Village Media Company that it is the exclusive owner of
the PFHOF Works or has the right to grant the licenses and other rights granted to the Village Media
Company hereunder, including the right to use the PFHOF Works as permitted herein and that, subject
to any Rights Restriction in effect on the Effective Date, PFHOF has secured any necessary releases
for any rights of publicity or privacy and can license such rights to the Village Media Company
hereunder. 2.11 PFHOF agrees to indemnify, defend, and hold harmless the Village Media Company, its
Affiliates, and their respective employees, officers, directors, agents, representatives, and
successors and assigns from and against any and all claims, demands, liabilities, losses, suits,
damages, costs (including, without limitation, costs of investigation), and expenses, including
reasonable attorneys' fees, arising out of or relating to (a) the Village Media Company's authorized
use of the PFHOF Works, as permitted by, and in accordance with, the terms of this Agreement, (b)
any breach by PFHOF of any warranty, representation, obligation, or agreement made under this
Agreement, or (c) PFHOF's use of the HOFV Works in breach of this Agreement, or any claim of
infringement of any intellectual property right arising out of the misuse or misappropriation of the
HOFV Works by PFHOF. 2.12 The Village Media Company represents and warrants to PFHOF that it is (a)
a limited liability company organized and in good standing under the laws of the State of Delaware
and (b) a wholly-owned subsidiary of HOFV. 2.13 The Village Media Company agrees to indemnify,
defend, and hold harmless PFHOF, its Affiliates, and their respective employees, officers,
directors, agents, representatives, and successors and assigns from and against any and all claims,
demands, liabilities, losses, suits, damages, costs (including, without limitation, costs of
investigation), and expenses, including reasonable attorneys' fees, arising out of or related to (a)
the Village Media Company's use of the PFHOF Works in breach of this Agreement, or any claim of
infringement of any intellectual property right arising out of the misuse or misappropriation of the
PFHOF Works, (b) any breach by the Village Media Company (or its sublicensees, if applicable) of any
warranty, representation, obligation, or agreement made under this Agreement, (c) the Exploitation
of any of the rights granted pursuant to the terms of this Agreement by the Village Media Company,
its Affiliates, licensees or sublicensees arising out of or relating to the Exploitation of any
PFHOF Works or HOFV Works (unless such liability arises solely from use of the PFHOF Works by the
Village Media Company in accordance with this Agreement), (d) PFHOF's authorized use of any HOFV
Works as permitted by, and in accordance with, the terms of this Agreement, (e) any advertising,
promotion or other similar materials that are inserted into any Exploitation of any PFHOF Work or
any HOFV Work (but excluding advertising or promotional announcements supplied by or on behalf of
PFHOF and excluding any claims arising solely from use of the PFHOF Works by the Village Media
Company in accordance with this Agreement)) or (f) any failure of the Village Media Company to
comply with applicable laws in connection with the rights and performance of its obligations under
this Agreement.

6

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 7 -->
2.14 Except for Section 3.5, nothing in this Agreement shall be construed as limiting in any way the
Village Media Company's ability to seek and exploit separate rights from any third party. 3.
OPERATION OF VILLAGE MEDIA COMPANY 3.1 The Chief Executive Officer of the Village Media Company (the
"CEO") shall be the Manager of the Village Media Company. 3.2 The Executive Producer of the Village
Media Company (the "EP") shall report to the CEO with input from the Chief Executive Officer of
PFHOF. To the extent that the Village Media Company and PFHOF work collaboratively on media
projects, the EP's services on such projects for the benefit of PFHOF shall be charged to PFHOF at
cost without markup. Performance objectives for the EP shall be determined by the CEO with input
from the Advisory Board. 3.3 In consultation with the CEO, the EP shall annually prepare a staffing
plan for the Village Media Company's operations and present such plan to the Advisory Board for
review. Staff employed by the Village Media Company may be used for projects solely for the benefit
of PFHOF or for projects that are collaboratively undertaken by both the Village Media Company and
PFHOF. The Advisory Board shall be informed to the extent Village Media Company staff are employed
on projects solely for the benefit of PFHOF or on projects that are collaboratively undertaken by
both the Village Media Company and PFHOF. In addition, (a) PFHOF shall bear its proportionate share
of the cost of such Village Media Company staff (at cost without markup) that work on such
collaborative projects and, to the extent such staff work 100% on a PFHOF project, PFHOF shall bear
all of the cost of such staff for such project (at cost without markup) and (b) the Village Media
Company shall bear its proportionate share of the cost of PFHOF staff (at cost without markup) that
work on such collaborative projects and, to the extent such staff work 100% on a Village Media
Company project, the Village Media Company bear all of the cost of such staff for such project (at
cost without markup). The EP shall ensure that, to the extent that PFHOF and the Village Media
Company share staff, that such sharing will not impact the ability of PFHOF or the Village Media
Company to meet their respective budget, creative goals, or sales/marketing goals for any year.

7

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 8 -->
3.4 The Advisory Board shall meet regularly to facilitate the Village Media Company's consideration
of media-related opportunities contemplated hereunder and to review proposed projects, budgets,
schedules, and creative concepts under consideration by the Village Media Company. 3.5 All
communication with the National Football League (the "NFL"), its 32 Member Clubs, NFL Legends and
Gold Jackets shall be made exclusively and directly through PFHOF. For the avoidance of doubt, PFHOF
has the exclusive and sole relationship with the NFL, its 32 Member Clubs, NFL Legends and Gold
Jackets for any and all PFHOF and HOFV activities; provided, however, that any communication
relating to any investment by the NFL in any Village Media Company project, may be made directly
through the President of PFHOF or the Chief Executive Officer of HOFV; and, provided further, that
the Village Media Company shall have the right to present opportunities related to any of the above
for approval by PFHOF. 4. TERM AND TERMINATION 4.1 Unless otherwise terminated as provided herein,
the term of this Agreement shall commence on the Effective Date and shall terminate on December 31,
2034 (such period, including as may be extended in accordance with the subsequent sentence, the
"Term"). Thereafter, the agreement shall automatically renew for successive five (5)-year terms,
unless either Party gives written notice to the other Party of intent not to renew at least six (6)
months prior to the expiration of the then-current Term. If either party elects not to renew the
Agreement and the other party wishes to continue the Agreement, the Parties shall attempt in good
faith to negotiate an amendment to the Agreement to renew the Term on such terms as may be
negotiated by the Parties. Such good faith negotiation shall continue until both Parties agree to
cease negotiations or until expiration of the Term. 4.2 After good faith consultation with the
Advisory Board, either Party shall have the right to terminate this Agreement at any time for an
uncured material breach by the other Party, including the non-payment of the Annual Guarantee,
license fees and staffing fees, provided that the non-breaching Party provides prior written notice
to the breaching Party, specifying the alleged material breach, and further provided that the
breaching Party shall have thirty (30) days after receipt of such notice to cure the material
breach, to the reasonable satisfaction of the non-breaching Party; provided, further, that if such
breach (other than a breach for non-payment) cannot be cured during such 30-day period, but the
allegedly breaching Party has commenced and is continuing good faith efforts to cure such breach
within such 30-day period, then the cure period shall be extended until the allegedly breaching
Party has stopped making good faith efforts to cure such breach, such extension not to exceed ninety
(90) days. 4.3 Either Party may terminate this Agreement immediately upon giving notice if the other
Party ceases to conduct its operations in the normal course of business, including the inability to
meet its obligations as they mature, or if any proceeding under the bankruptcy or insolvency laws is
brought by or against the other Party, or a receiver or custodian is appointed or applied for by the
other Party, or an assignment for the benefit of creditors or a transfer of all or substantially all
of its property is made by the other Party.

8

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 9 -->
4.4 In addition to and without limiting any other provision of this Agreement, if a Change of
Control occurs at any time during the Term, PFHOF shall have the right to terminate this Agreement
immediately upon giving notice of such termination to the Village Media Company. For purposes of
this Section 4.4, a "Change of Control" shall mean any transaction or series of related transactions
that results in (including by way of merger or consolidation), or that is in connection with, the
Village Media Company no longer being controlled (as defined in Section 1.2) by or under common
control (as defined in Section 1.2) with HOFV. 4.5 In addition to and without limiting any other
provision of this Agreement, in the event the Village Media Company or HOFV fails to pay the Annual
Guarantee to PFHOF in accordance with Section 5.1 and such failure is not cured within thirty (30)
days of notice thereof by PFHOF, then the rights of first offer granted to HOFV in Section 3.1 of
the First Amended and Restated License Agreement, dated as of September 16, 2019 between PFHOF and
HOFV (the "License Agreement") shall automatically and immediately terminate, regardless of whether
PFHOF elects not to terminate this Agreement in accordance Section 4.2. 4.6 Notwithstanding anything
to the contrary in this Agreement, this Agreement shall automatically and immediately terminate,
without any further action or notice to any Party, upon termination of the License Agreement. 4.7
Upon the expiration or termination of this Agreement as provided in this Section 4, the rights and
obligations of the Parties under this Agreement shall be terminated, except as provided herein. 5.
FEES 5.1 Subject to Section 2.6, the Village Media Company shall, or shall cause HOFV to, pay to
PFHOF a minimum guarantee of one million two hundred and fifty thousand dollars ($1,250,000) (the
"Annual Guarantee") each year during the Term; provided that the Parties acknowledge and agree that
after the first five (5) years of the Term, the Annual Guarantee shall increase by three percent
(3%) on a year-over-year basis (e.g., the Annual Guarantee shall increase to $1,287,500 for year six
(6) and to $1,326,125 for year seven (7)). The first Annual Guarantee payment shall be due and
payable on the Effective Date and thereafter shall be payable to PFHOF on each twelve (12) month
anniversary of the Closing Date during the Term.

9

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 10 -->
5.2 In consideration of any license granted to the Village Media Company hereunder, the Village
Media Company shall, or shall cause HOFV to, pay to PFHOF a license fee specific to the PFHOF
Work(s) licensed by PFHOF hereunder ("License Fee") pursuant to the rate for the applicable project
or opportunity as will be mutually agreed between the Parties for each opportunity; provided that
License Fees shall be debited first from the Annual Guarantee, which shall satisfy such License Fees
due and payable hereunder until the aggregate amount of the License Fees due and payable during such
calendar year exceeds the Annual Guarantee for such calendar year. For clarity, if for any calendar
year during the Term, the amount of License Fees for such calendar is (x) less than the amount of
the Annual Guarantee, the Village Media Company shall still be required to pay the Annual Guarantee
for such calendar year or (y) more than the Annual Guarantee, the Village Media Company shall be
required to pay all License Fees in excess of the Annual Guarantee for such calendar year. The
Parties acknowledge and agree that two hundred twenty five thousand dollars ($225,000) (the "Youth
Sports License Fee") shall be credited against the Annual Guarantee on the Closing Date and each
anniversary of the Closing Date during the Term for the license granted by PFHOF to Youth Sports
Management, LLC ("Youth Sports") pursuant to that certain branding license agreement to be entered
into on the Effective Date between PFHOF and Youth Sports for so long as such agreement remains in
effect; provided that after the first five (5) years of the Term, the Youth Sports License Fee shall
increase by three percent (3%) on a year-over year basis and thereafter, the aggregate amount of the
Youth Sports License Fee, after giving effect to such increase each year, shall be the amount
credited against the Annual Guarantee. 6. FORCE MAJEURE In the event either Party is unable to
comply fully with its obligations (other than payment obligations) under this Agreement due to an
event beyond the control of the Party whose performance is affected, including any legal
prohibition, court order, degree, regulation or requirement of any governmental entity having
jurisdiction, strikes, catastrophe, drought, shortage of water or other action of the elements,
temporary or permanent shutdown due to regulatory or other governmental actions, or Acts of God or
any other matters beyond its control, such Party shall while so affected be relieved to the extent
thus prevented from performing its obligations hereunder and such non-performance shall not, in and
of itself, be deemed to be a breach of this Agreement; provided that, in such event, the
non-performing Party takes all commercially reasonable measures to remove the disability and resume
full performance hereunder at the earliest possible date. 7. GENERAL PROVISIONS 7.1 Confidentiality
(a) "Confidential Information" means all forms of confidential information, including technical
information and business information, disclosed by one Party or its Affiliates (the "Disclosing
Party") to the other Party or its Affiliates (the "Receiving Party") during the Term in connection
with this Agreement, that is identified as confidential or is information that is of a nature that
is customarily regarded as confidential, whether disclosed in electronic, tangible, oral or visual
form; provided that oral or visual disclosures shall be deemed confidential only if they are
confirmed as confidential in writing by the Disclosing Party prior to or at the time of disclosure
or within thirty (30) days thereafter, or if the Receiving Party should reasonably know that such
visual or oral disclosures are intended to be confidential. Confidential Information shall not
include such information that: (i) as of the date of disclosure is known to the Receiving Party or
its Affiliates, as shown by written documentation; (ii) was independently developed by the Receiving
Party or its Affiliates without access to the Disclosing Party's Confidential Information; (iii) as
of the date of disclosure is in, or subsequently enters, the public domain, through no fault of the
Receiving Party; or (iv) as of the date of disclosure or thereafter is obtained from a third party
free from any obligation of confidentiality to the Disclosing Party.

10

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 11 -->
(b) Each Receiving Party agrees: (i) not to disclose, make public, or authorize any disclosure or
publication of such Confidential Information of the Disclosing Party except as expressly permitted
herein; (ii) to take reasonable measures to protect the confidentiality of the Disclosing Party's
Confidential Information exercising the same degree of care to preserve and safeguard the Disclosing
Party's Confidential Information as it uses to preserve and safeguard its own Confidential
Information, but in no event less than a reasonable degree of care; (iii) to restrict access to such
Confidential Information to only those officers, directors, or employees of the Receiving Party or
its Affiliates or representatives who have a need to know such Confidential Information and who are
bound by confidentiality obligations at least as restrictive as those contained in this Agreement;
and (iv) not to remove any confidential or proprietary markings or designations placed by the
Disclosing Party on such Confidential Information. The Receiving Party and its Affiliates shall not
use the Disclosing Party's Confidential Information for any purpose except as permitted by this
Agreement. (c) The confidentiality obligations contained herein shall not apply to the extent that
the Receiving Party is required to disclose the information by law, order, or regulation of a
governmental agency or a court of competent jurisdiction; provided that, in each such case, the
Receiving Party shall give written notice thereof to the Disclosing Party and sufficient opportunity
to prevent or limit any such disclosure or to request confidential treatment thereof; and provided
further, that the Receiving Party shall give reasonable assistance to the Disclosing Party to
preserve the information as confidential. (d) Upon termination of this Agreement, each Receiving
Party shall return to the Disclosing Party (or at the Disclosing Party's direction, destroy) all
Confidential Information of the Disclosing Party that is in the possession, custody, or control of
the Receiving Party. The Village Media Company shall be permitted to retain copies of PFHOF's
Confidential Information as necessary to allow the Village Media Company to exercise its
post-termination rights with respect to such information.

11

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 12 -->
(e) Each Party acknowledges that a breach or threatened breach of this Section 7.1 on its part shall
result in irreparable and incalculable damages to the other Party. Therefore, in addition to any
action by either Party for collection of damages resulting from the breach of this Agreement, such
Party shall also be entitled to immediate injunctive relief, restraining the other Party from
continued or threatened breach of this Agreement. Each Party further agrees that, upon a finding of
a breach of the terms of this Agreement on its part, such Party shall pay to the other Party the
costs and expenses, including attorneys' fees, which the other Party incurs in enforcing the terms
of this Agreement. 7.2 Notices. Any notice required or permitted by this Agreement will be in
writing and delivered as follows with notice deemed given as indicated: (i) by personal delivery
when delivered personally; (ii) by overnight courier upon written verification of receipt; (iii) by
telecopy or facsimile transmission upon acknowledgement of receipt of electronic transmission; or
(iv) by certified or registered mail, return receipt requested, upon verification of receipt. Notice
will be sent to the appropriate address set forth below or such other address as to which the
Parties have been notified hereunder. 7.3 Compliance with Laws and Regulations. Each of the Village
Media Company and PFHOF, as applicable, agrees to be in material compliance with all federal, state,
and local laws, ordinances, and regulations applicable to its respective operations and to obtain
and maintain all licenses and permits required by law necessary for each of their respective
operations. 7.4 Governing Law and Arbitration. (a) This Agreement will be governed in all respects
by the laws of the State of Ohio (without regard to conflicts of law provisions), as such laws are
applied to agreements entered into and to be performed entirely within the State of Ohio between
Ohio residents. (b) Any dispute between the Parties concerning the scope or interpretation of this
Agreement shall be submitted to binding arbitration in accordance with the Rules of Commercial
Arbitration of the American Arbitration Association in effect on the date that a dispute is
submitted to arbitration (the "Rules"). The arbitration shall be held in Canton, Ohio, and shall be
before a panel of three arbitrators, one chosen by each of the Parties and a third chosen by the two
arbitrators so chosen by the Parties. Not less than fifteen (15) days prior to the arbitration, each
Party shall submit to the other the documents and a list of witnesses it intends to interview or
call in the arbitration. The arbitrators shall apply the substantive law of the State of Ohio with
regard to any dispute that becomes the subject of arbitration, and the arbitrators will be so
instructed. The arbitrators shall issue a written opinion stating the findings of fact and the
conclusions of law upon which the decision is based. The decision of the arbitrators shall be final
and binding.

12

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 13 -->
(c) In any action, suit, proceeding, claim, or counterclaim brought to enforce this Agreement or any
of its provisions, the Party that prevails in any such action, suit, proceeding, claim, or
counterclaim (the "Prevailing Party") shall recover its costs, fees, and expenses, including, but
not limited to, the reasonable costs, fees, and expenses of attorneys and outside experts
(collectively, "Expenses"), from the other Party (the "Non-Prevailing Party"), and the court or
arbitration panel shall be so instructed to determine which Party is the Prevailing Party, to grant
the recovery of the Expenses incurred by the Prevailing Party, and to order the Non-Prevailing Party
to pay the Expenses of the Prevailing Party. 7.5 Assignment. The Village Media Company shall not,
directly or indirectly, assign, sublicense or otherwise transfer any of its rights or obligations
hereunder without the prior written consent of PFHOF. The transfer of ownership of the Village Media
Company pursuant to the Merger Agreement shall not require the consent of PFHOF. 7.6 Severability.
Should any provision of this Agreement be held by a court of competent jurisdiction to be illegal,
invalid, or unenforceable, the legality, validity, and enforceability of the remaining provisions of
this Agreement will not be affected or impaired thereby. 7.7 Waiver. The waiver by either Party of a
breach of any provision of this Agreement by the other Party will not operate or be construed as a
waiver of any other or subsequent breach by such other Party. 7.8 Authority. Each Party warrants and
represents that such Party's execution and delivery of this Agreement has been duly authorized by
proper corporate or limited liability company action and that this Agreement is a binding obligation
of such Party enforceable in accordance with its terms. 7.9 Independent Contracting Parties. The
Parties are independent contracting parties and nothing in this Agreement shall make either Party
the agent or legal representative of the other for any purpose whatsoever, nor does it grant either
Party the authority to assume or create any obligation on behalf of or in the name of the other.
Furthermore, the Parties shall remain separate and independent contracting parties and nothing in
this Agreement shall make either Party subject to a joint venture agreement or other mutual
arrangement between the Parties. 7.10 Entire Agreement. This Agreement constitutes the entire
agreement between the Parties relating to this subject matter and supersedes all prior or
contemporaneous oral or written agreements concerning such subject matter, including the Original
License Agreement. This Agreement may be changed only by mutual agreement of the Parties in writing.
7.11 Merger Agreement. Notwithstanding anything to the contrary in this Agreement, in the event that
the Closing (as such term is defined in the Merger Agreement) does not occur, this Agreement shall
be terminated and the provisions herein shall have no force or effect. [signature page follows]

13

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 14 -->
IN WITNESS WHEREOF, PFHOF, HOFV (solely for purposes of Section 4.5) and the Village Media Company
have caused this Agreement to be executed by their respective, duly authorized representatives,
effective as of the Effective Date. NATIONAL FOOTBALL MUSEUM, INC. By: C. David Baker President
Date: Address: 2121 George Halas Drive NW Canton, Ohio 44708 HOF VILLAGE MEDIA GROUP, LLC By: Name:
Title: Date: Address: 1826 Clearview Avenue NW Canton, Ohio 44708 [Media License Agreement]

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 15 -->
For the purpose of acknowledging and agreeing to the terms set forth in Section 4.5: HOF VILLAGE,
LLC By: Name: Title: Date: Address: 1826 Clearview Avenue NW Canton, Ohio 44708 [Media License
Agreement]

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 16 -->
Exhibit A Excluded Categories and Properties 1. Any PFHOF Works in, or Exploited in connection with,
the following Categories: · Health Care · Museums · Education · Sports Betting 2. Any programming or
content created or Exploited in support and furtherance of the PFHOF's mission. 3. The following
television properties that are subject to perpetual rights and existing and future media deals
(including any extensions, renewals or similar agreement in connection any existing agreement):
Properties and rights subject to agreements with NFL Enterprises LLC ("NFLN") and ESPN, Inc.
("ESPN") through September 1st 2021 (and any extension, renewal or similar agreement relating
thereto). · Enshrinement Ceremonies · Other Enshrinement Events reserved for NFLN o Gold Jacket Show
one hour (2019 - 2 hours co-copyright NFLN PFHOF) o Five One Hour Gold Jacket Contender Shows from
September to February around the Enshrinement Selection Process For the avoidance of doubt, nothing
in this Agreement shall grant Village Media Company or its Affiliates the right or license to (i)
any live (or near live) rights to Exploit any events or other content owned or controlled by PFHOF
(e.g., Enshrinement Ceremonies), or (ii) any programming or content in connection with or related to
any Enshrinement Ceremony or the Enshrinement selection process (e.g., selection meetings, voting,
debates or discussions prior to or during any selection meeting, presenter speeches, discussions or
events immediately after Enshrinement Ceremonies, etc.). 4. Any content or properties utilizing the
following trademarks: · Knock on the Door (Trademarked sold to social media company) · Hometown Hall
of Famer (Trademarked sold to sponsors)

Exhibit A-1

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 17 -->
5. The following movies: · Jim and Jill Kelly Movie 6. The autobiographical or biographical works
related to the following players with video rights: · Michael Strahan · John Madden · Troy Aikman 7.
The following television show concepts: · Hall of Fame City · Documentary One Years One Hundred
Yards of Character · Strong Youth Strong Communities · Centennial Spectacular · Centennial Gala 8.
Any digital live streaming rights, including without limitation, of the following properties: ·
State of the Hall · Super Bowl Luncheon · Salute to Greatness · Inspiration Project · The Mission ·
Heart of the Hall of Famer 9. Any licenses or sponsorships of video games granted to EA Sports (or
its successor) with respect to Madden NFL or any other EA Sports football game. Exhibit A-2

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
