<!-- page 1 -->
# Distributorship agreement
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| Agreement Date | 2018-03-29 |
| Parties | Signature Orthopaedics Pty Ltd; CPM Medical Consultants, LLC |
| Source | CUAD v1 / FuseMedicalInc_20190321_10-K_EX-10.43_11575454_EX-10.43_Distributor Agreement |

EXHIBIT 10.43 Dated 29/3/18

Distributorship agreement

between

Signature Orthopaedics Pty Ltd

And

CPM Medical Consultants LLC

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 2 -->
EXHIBIT 10.43 THIS AGREEMENT is dated

Parties

(1) Signature Orthopaedics Pty Ltd (ACN 106 702 416) , 7 Sirius Road, Lane Cove, NSW

(2) CPM Medical Consultants, LLC of 1565N. Central Expressway, Suite 200, Dallas, TX 75080.

Background

The Supplier wishes to appoint the Distributor as its non-exclusive distributor for the promotion
and sale of the Products within the Territory (both as defined below), and the Distributor wishes to
promote and sell the Products within the Territory on the terms of this agreement.

Agreed terms

1. Definitions and interpretation

1.1 The definitions and rules of interpretation in this clause apply in this agreement.

Business Day: a day (other than a Saturday, Sunday or public holiday in Australia) when banks in
Sydney are open for business.

Commencement Date: means the date of this agreement.

Control: the ability to direct the affairs of another person, whether by virtue of the ownership of
shares, contract or otherwise.

Inactive Territories means a country in which the Distributor has not sold or supplied the Product
during the Initial Term.

Initial Term has the meaning given to it in clause 12.1.

Products: As defined in Schedule 1 and includes any other products developed by the Supplier and
which the Supplier may permit the Distributor, by express notice in writing, to distribute in the
Territory.

Term: the term of this agreement, as determined in accordance with clause 11. Territory: means the
territory specified in Schedule 2.

Trade Marks: the trade mark registrations listed in Schedule 3 and any further trade marks that the
Supplier may permit, or procure permission for, the Distributor to use in the Territory in respect
of the Products by express notice in writing.

GST: goods and services tax chargeable under the Goods and Services Tax Act and any similar
replacement or additional tax or such other similar or analogous form of tax under the laws and
regulations in the Territory.

1

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 3 -->
Year: the period of 12 months from the Commencement Date and each consecutive period of 12 months
thereafter during the Term.

1.2 Clause, schedule and paragraph headings shall not affect the interpretation of this agreement.

1.3 A person includes a natural person, corporate or unincorporated body (whether or not having
separate legal personality).

1.4 The Schedules form part of this agreement and shall have effect as if set out in full in the
body of this agreement. Any reference to this agreement includes the Schedules.

1.5 A reference to a company shall include any company, corporation or other body corporate,
wherever and however incorporated or established.

1.6 Words in the singular shall include the plural and vice versa.

1.7 A reference to one gender shall include a reference to the other genders.

1.8 A reference to any party shall include that party's personal representatives, successors or
permitted assigns.

1.9 A reference to a statute, statutory provision or any subordinated legislation made under a
statute is a reference to such statute, provision or subordinated legislation as amended or
re-enacted from time to time, whether before or after the date of this agreement and in the case of
a reference to a statute is also to all subordinate legislation made under that statute whether
before or after the date of this agreement.

1.10 A reference to writing or written includes faxes and e-mail.

1.11 Documents in agreed form are documents in the form agreed by the parties and initialled by or
on behalf of them for identification.

1.12 Any reference to a legal term for any action, remedy, method of judicial proceeding, legal
document, legal status, court, official or any legal concept or thing shall, in respect of any
jurisdiction other than Australia, be deemed to include a reference to what most nearly approximates
to the Australian legal term in that jurisdiction.

1.13 A reference to a document is a reference to that document as varied or novated (in each case,
other than in breach of the provisions of this agreement) at any time.

1.14 References to clauses and schedules are to the clauses and schedules of this agreement.

2

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 4 -->
1.15 Any phrase introduced by the terms including, include, in particular or any similar expression
shall be construed as illustrative and shall not limit the sense of the words preceding those terms.

2. Appointment

2.1 The Supplier appoints the Distributor as its non-exclusive distributor to distribute the
Products in the Territory on the terms of this agreement.

2.2 Following the expiry of the Initial Term, the Supplier may amend the Territory to remove any
Inactive Territories.

2.3 Notwithstanding 2.1 and 2.2, the Supplier may sell or supply the Products to end users within
USA at anytime.

2.4 The Distributor shall not:

(a) represent itself as an agent of the Supplier for any purpose; or

(b) pledge the Supplier's credit; or

(c) give any condition or warranty on the Supplier's behalf except for any warranty or guarantee
which cannot be excluded under law; or

(d) make any representation on the Supplier's behalf; or

(e) commit the Supplier to any contracts; or

(f) act as the agent or the buying agent, for any person for any goods which are competitive with
the Product; or

(g) retain any monies of the Supplier except on a trustee or fiduciary basis; or

(h) knowingly make any false or misleading statement to any supplier or service provider, or to the
Distributor or its business, about the Products or the liability of the Supplier for the cost of any
goods or services supplied to the Distributor or its business; or

(i) incur any liability or assume any obligation on behalf of the Supplier; or

2.5 The Distributor shall not without the Supplier's prior written consent make any promises or
guarantees about the Products beyond those:

(a) agreed between the Distributor and the Supplier; and

(b) contained in any promotional material supplied by the Supplier.

3

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 5 -->
3. Distributor's undertakings

The Distributor undertakes and agrees with the Supplier that at all times during the Term it will:

(a) use all reasonable endeavours to promote the distribution and sale of the Products;

(b) not use any promotional or advertising material for the Products not approved by the Supplier,
such approval not be unreasonably withheld;

(c) provide Yearly non-binding sales forecasts;

(d) establish and maintain documented procedures for identifying the Products with a control number
for traceability and copies of those records and procedures must be made available to the Supplier
within thirty (30) days of request;

(e) provide regular reports on the sales activities within the Territory;

(f) employ a sufficient number of suitably qualified personnel to ensure the proper fulfilment of
the Distributor's obligations under this agreement;

(g) maintain, on its own account, an inventory of the Products at levels which are appropriate and
adequate for the Distributor to meet all customer delivery requirements for the Products throughout
the Territory;

(h) keep full and proper books of account and records clearly showing all enquiries, quotations,
transactions and proceedings relating to the Products;

(i) allow the Supplier, on reasonable notice, access to its accounts and records relating to the
sale or distribution of the Products for inspection but not more than once in each year. For
clarity, the Supplier will not be permitted access to any accounts or records which do not directly
relate to the sale or distribution of the Products;

(j) comply with any reasonable directives or instructions given by the Supplier for any promotional
activities, at the suppliers cost, concerning the nature, type, quality, characteristics, fitness
for purpose, suitability, use and description of the Products;

4. Supply of products

4.1 The parties acknowledge that:

(a) the Supplier is the manufacturer of the Products; and

4

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 6 -->
(b) the Supplier will have no obligation to separately supply the Products, except as otherwise
provided for in this Agreement.

4.2 Supplier's undertakings

The Supplier undertakes to:

(a) provide information and support that may reasonably be requested by the Distributor to enable it
to discharge its duties under this agreement properly and efficiently; and

(b) approve or reject any promotional information or material submitted by the Distributor within 28
days of receipt.

5. Prices and payment

5.1 The prices to be paid by the Distributor to the Supplier for the Products are to be the Price,
as set out in Schedule 4.

5.2 Any and all expenses, costs and charges incurred by the Distributor in the performance of its
obligations under this agreement will be paid by the Distributor, unless the Supplier has expressly
agreed in advance in writing to pay such expenses, costs and charges.

5.3 The Distributor must pay the full amount invoiced to it by the Supplier in USD$'s within thirty
(45) days of the date of invoice.

5.4 Neither party may withhold payment of any amount due to the other because of any set-off,
counter-claim, abatement, or other similar deduction.

6. GST and taxes (Only Applicable to Australian companies)

6.1 All sums payable under this agreement, or otherwise payable by any party to any other party
under this agreement are exclusive of any GST chargeable on the supplies for which such sums (or any
part of them) are the whole or part of the consideration for GST purposes.

6.2 Where, under this agreement, any party makes a supply to any other party (Recipient) for GST
purposes and GST is or becomes chargeable on that supply for which the supplying party is required
to account to the relevant tax authority, the Recipient shall, subject to the receipt of a valid GST
invoice, pay the supplying party (in addition to, and at the same time as, any other consideration
for that supply) the amount of such GST.

6.3 Where any party is required by this agreement to reimburse or indemnify any other party for any
cost or expense, that first party shall reimburse or indemnify the other party for the full amount
of the cost or expense, including any GST on that amount,

5

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 7 -->
except to the extent that the other party is entitled to credit or repayment for that GST from any
relevant tax authority.

6.4 All import taxes, charges, levies, assessments and other fees of any kind imposed on the
purchase or import of the Products shall be the responsibility of, and for the account of, the
Distributor.

7. Advertising and promotion

7.1 The Distributor shall:

(a) cooperate with the Supplier in relation to the promotion and advertisement of the Products;

(b) not make any written statement as to the quality or manufacture of the Products without the
prior written approval of the Supplier; and

(c) pays its own costs of advertising the Product except where there is any separate advertising
campaign which the Supplier and the Distributor have agreed to fund jointly in any agreed
proportion.

8. Anti-bribery compliance

8.1 The Distributor shall:

(a) comply with all applicable laws, statutes and regulations relating to anti-bribery and anti-
corruption; and

(b) not engage in any activity, practice or conduct which would constitute an offence.

9. Trade marks and intellectual property

9.1 The Supplier hereby grants to the Distributor the non-exclusive right, in the Territory, to use
the Trade Marks in the promotion, advertisement and sale of the Products, subject to, and for the
duration of, this agreement.

9.2 The Distributor may sell and/or distribute the Products using the Trade Marks in conjunction
with any trade marks owned or licensed by the Distributor.

9.3 All representations of the Trade Marks that the Distributor intends to use shall be submitted to
the Supplier for approval before use.

9.4 Within limiting this clause 12, the Distributor shall be entitled to add a label to the Products
it purchases to show that the products purchased are being distributed by the Distributor.

9.5 The Supplier represents and warrants that:

6

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 8 -->
(a) Trade Marks; and

(b) The Products, do not infringe any intellectual property rights of any third parties and the
Supplier agrees to indemnify and hold harmless the Distributor against any clauses by a third party
for infringement of intellectual property rights in relation to the Products or the Trade marks .

9.6 The Distributor shall not sub-license, transfer or otherwise deal with the rights of use of the
Trade Marks granted under this agreement.

9.7 The Distributor shall not do, or omit to do, anything in its use of the Trade Marks that could
adversely affect their validity or the goodwill of the Supplier.

9.8 The Distributor shall immediately enter into any document necessary for the recording,
registration or safeguarding of the Supplier's Trade Mark rights with the Supplier for the marketing
of the Products under the Trade Marks in a form satisfactory to the Supplier, at the suppliers cost.

9.9 Each party shall promptly give notice in writing to the other if it becomes aware of:

(a) any infringement or suspected infringement of the Trade Marks or any other intellectual property
rights relating to the Products within the Territory; or

(b) any claim that any Product or the manufacture, use, sale or other disposal of any Product within
the Territory, whether or not under the Trade Marks, infringes the rights of any third party,

9.10 In respect of any matter that falls within clause 9.9(a):

(a) the Supplier shall in its absolute discretion, decide what action to take in respect of the
matter (if any);

(b) the Supplier shall conduct and have sole control over any consequent action that it deems
necessary; and

(c) the Supplier shall pay all costs in relation to that action and shall be entitled to all damages
and other sums that may be paid or awarded as a result of that action.

9.11 In respect of any matter that falls within clause 9.9(b):

(a) the Supplier and the Distributor shall agree:

(i) what steps to take to prevent or terminate the infringement; and

(ii) the proportions in which they shall share the cost of those steps and any damages and other
sums which may be awarded to or against

7

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 9 -->
them, being agreed between the parties that the Supplier shall hold Distributor harmless against any
damages connected with any material or workmanship defect of the Products; and

(b) failing agreement between the parties, either party may take any action as it considers
necessary or appropriate, at its own expense, to defend the claim and shall be entitled to and
responsible for all damages and other sums that may be recovered or awarded against it as a result
of that action.

9.12 Each party shall, at the request and expense of the other, provide any reasonable assistance to
the other (including the use of its name in, or being joined as a party to, proceedings) with any
action to be taken by the other party under this clause 9, provided that that party is given such
indemnity as it may reasonably require against any losses, costs and expenses it may incur as a
result of or in connection with providing such assistance.

10. Product liability and insurance

10.1 Subject to the Distributor fulfilling all the conditions in this clause 10, the Supplier shall
indemnify the Distributor, defend and hold harmless against any liability incurred by the
Distributor in respect of damage to property, death or personal injury arising from any fault or
defect in the design of the Products and any reasonable costs, claims, demands and expenses,
including reasonable attorneys' fees, arising out of or in connection with that liability (Relevant
Claim), except to the extent the liability arises as a result of the wilful misconduct of the
Distributor. The Supplier shall add the distributor to their current insurance certificate.

10.2 The Distributor shall, within five days of a matter which may result in a Relevant Claim:

(a) give the Supplier written notice of the details of the matter;

(b) give the Supplier access to and allow copies to be taken of any materials, records or documents
as the Supplier may require to take action under clause 10.2(c);

(c) allow the Supplier the exclusive conduct of any proceedings and take any action that the
Supplier requires to defend or resist the matter, including using professional advisers nominated by
the Supplier; and

(d) not admit liability or settle the matter without the Supplier's written consent.

10.3 During the Term, the Supplier shall maintain product liability insurance with a reputable
insurer of no less than AU$10 million for any one occurrence for any and all liability (however
arising) for a claim that the Products are faulty or defective. The Supplier shall provide a copy of
the insurance policy to the Distributor on request.

8

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 10 -->
10.4 The Distributor undertakes to maintain appropriate, up-to-date and accurate records to enable
the immediate recall of any Products or batches of Products from the retail or wholesale markets.
These records shall include records of deliveries to customers (including batch numbers, delivery
date, name and address of customer, telephone number, fax number and e-mail address).

10.5 The Distributor shall, at the Supplier's cost, give any assistance that the Supplier shall
reasonably require to recall, as a matter of urgency, Products from the retail or wholesale market.

11. Duration and termination

11.1 This agreement begins on the Commencement Date and, subject to clause 11.2, shall continue for
an initial term of one (1) years (Initial Term) and indefinitely after that until terminated by
either party giving at least twelve (12) months' prior written notice to expire on or after the
expiry date of the initial term.

11.2 Without affecting any other rights that it may be entitled to, either party may give notice in
writing to the other terminating this agreement immediately if:

(a) the other party fails to pay any amount due under this agreement on the due date for payment and
remains in default not less than 14 days after being notified in writing to make such payment; or

(b) the other party commits a material breach of any material term of this agreement and (if such
breach is remediable) fails to remedy that breach within a period of 14 days of being notified in
writing to do so; or

(c) the other party repeatedly breaches any of the terms of this agreement in such a manner as to
reasonably justify the opinion that its conduct is inconsistent with it having the intention or
ability to give effect to the terms of this agreement; or

(d) the other party suspends, or threatens to suspend, payment of its debts or is unable to pay its
debts as they fall due or admits inability to pay its debts or (being a company) is deemed unable to
pay its debts within the meaning of the Corporations Act 2001 (Cth) OR (being a natural person) is
deemed either unable to pay its debts or as having no reasonable prospect of so doing, in either
case, within the meaning of the Corporations Act 2001 (Cth) OR (being a partnership) has any partner
to whom any of the foregoing apply: or

(e) the other party commences negotiations with all or any class of its creditors with a view to
rescheduling any of its debts, or makes a proposal for or enters into any compromise or arrangement
with its creditors other than for the sole purpose of a scheme for a solvent amalgamation of that
other party with one or more other companies or the solvent reconstruction of that other party; or

9

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 11 -->
(f) a petition is filed, a notice is given, a resolution is passed, or an order is made, for or in
connection with the winding up of that other party other than for the sole purpose of a scheme for a
solvent amalgamation of that other party with one or more other companies or the solvent
reconstruction of that other party: or

(g) an application is made to court, or an order is made, for the appointment of an administrator or
if a notice of intention to appoint an administrator is given or if an administrator is appointed
over the other party; or

(h) a person becomes entitled to appoint a receiver over the assets of the other party or a receiver
is appointed over the assets of the other party; or

(i) the other party, being an individual, is the subject of a bankruptcy petition or order; or

(j) a creditor or encumbrancer of the other party attaches or takes possession of, or a distress,
execution, sequestration or other such process is levied or enforced on or sued against, the whole
or any part of its assets and such attachment or process is not discharged within 14 days; or

(k) any event occurs, or proceeding is taken, with respect to the other party in any jurisdiction to
which it is subject that has an effect equivalent or similar to any of the events mentioned in
clause 11.2(d) to clause 11.2(j) (inclusive); or

(l) the other party suspends or ceases, or threatens to suspend or cease, to carry on all or a
substantial part of its business; or

(m) the other party, being an individual, dies or, by reason of illness or incapacity (whether
mental or physical), is incapable of managing his or her own affairs or becomes a patient under any
mental health legislation.

(n) Without affecting any other rights that it may be entitled to, the Supplier may give notice in
writing to the Distributor terminating this agreement immediately if the Distributor purports to
assign its rights or obligations under this agreement to an entity that is not (1) affiliated with,
(2) related to, or (3) sharing common ownership with the Distributor (a Permitted Assignee).

12. Effectsof termination

12.1 Termination of this agreement for any reason shall not affect any rights or liabilities accrued
at the date of termination.

10

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 12 -->
12.2 At the Supplier's option, on termination of this agreement:

(a) the Supplier may buy from the Distributor all or any stocks of Products for the current market
value for those Products. The Distributor must deliver such Products to the Supplier within 14 days
of receiving the Supplier's notice, and the Supplier must pay for the Products in full within 30
days of their delivery. The Supplier shall be responsible for the costs of packaging, insurance and
carriage of the Products; or

(b) the Distributor may dispose of the balance of the Products in its possession and account to the
Supplier for the Price for those Products; and

(c) subject to clause 12.2(b), the Distributor must cease using any intellectual property of the
Supplier or of another person that relates to the distributorship and the Distributor must sign any
instrument and do any other act that is necessary to achieve this purpose;

12.3 For the purposes of clause 12.2(a) the current market value in respect of Products shall be the
price that the Products are ordinarily supplied as at the date of termination of this agreement.

12.4 Subject to clause 12.2, all other rights and licences of the Distributor under this agreement
shall terminate on the termination date.

13. Confidentiality

13.1 Each party undertakes that it shall not at any time, disclose to any person any confidential
information concerning the business, affairs, customers, clients or suppliers of the other party or
of any member of the group of companies to which the other party belongs, except as provided by
clause 13.2.

13.2 Each party may disclose the other party's confidential information:

(a) to those of its employees, officers, representatives or advisers who need to know such
information for the purpose of carrying out the party's obligations under this agreement. Each party
shall ensure that its employees, officers, representatives or advisers to whom it discloses the
other party's confidential information comply with this clause 13; and

(b) as may be required by law, court order or any governmental or regulatory authority; provided,
however, that the other party reserves the right to challenge such disclosure under applicable law.
If such party elects to challenge the disclosure, no confidential information shall be disclosed
during the pendency of such challenge.

13.3 No party shall use any other party's confidential information for any purpose other than to
perform its obligations under this agreement.

11

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 13 -->
14. Entire agreement

14.1 This agreement (and any document referred to in it) constitutes the whole agreement between the
parties and supersedes all previous agreements between the parties relating to its subject matter.

14.2 Each party acknowledges that, in entering into this agreement (and any document referred to in
it), it has not relied on, and shall have no right or remedy in respect of, any statement,
representation, assurance or warranty (whether made negligently or innocently) other than as
expressly set out in this agreement. Each party agrees that its only liability in respect of those
representations and warranties that are set out in this agreement (whether made innocently or
negligently) shall be for breach of contract.

14.3 Nothing in this clause shall limit or exclude any liability for fraud.

15. Variation

No amendment or variation of this agreement shall be effective unless it is in writing and signed by
the parties (or their authorised representatives).

16. Assignment and other dealings prohibited

16.1 The Distributor shall not assign, transfer, mortgage, charge, declare a trust of or deal in any
other manner with this agreement or any of its rights and obligations under or arising out of this
agreement, or purport to do any of the same; provided, however, the Distributor may assign or
transfer this agreement to a Permitted Assignee without the consent of Supplier. The Distributor
shall not sub-contract or delegate in any manner any or all of its obligations under this agreement
to any third party or agent.

16.2 If the Distributor seeks the Supplier's consent to any proposed dealing under clause 16.1, the
Distributor must: -

(a) disclose fully in writing all material facts relating to the dealing

(b) comply fully with any conditions or requirements set down by the Supplier which attach to any
Suppliers consent that is given.

16.3 Each party that has rights under this agreement is acting on its own behalf and not for the
benefit of another person.

17. Freedom to contract

The parties declare that they each have the right, power and authority and have taken all action
necessary to execute and deliver and to exercise their rights and perform their obligations under
this agreement.

12

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 14 -->
18. Waiver

No failure or delay by a party to exercise any right or remedy provided under this agreement or by
law shall constitute a waiver of that or any other right or remedy, nor shall it preclude or
restrict the further exercise of that or any other right or remedy. No single or partial exercise of
such right or remedy shall preclude or restrict the further exercise of that or any other right or
remedy.

19. Severance

19.1 If any provision of this agreement (or part of any provision) is found by any court or other
authority of competent jurisdiction to be invalid, illegal or unenforceable, that provision or
part-provision shall, to the extent required, be deemed not to form part of this agreement, and the
validity and enforceability of the other provisions of this agreement shall not be affected.

19.2 If a provision of this agreement (or part of any provision) is found illegal, invalid or
unenforceable, the provision shall apply with the minimum modification necessary to make it legal,
valid and enforceable.

20. Notices

20.1 Any notice required to be given under this agreement, shall be in writing and shall be
delivered personally, by email, or sent by pre-paid first class post or recorded delivery or by
commercial courier, to each party required to receive the notice at its address as set out at the
beginning of this agreement or as otherwise specified by the relevant party by notice in writing to
each other party.

20.2 Any notice shall be deemed to have been duly received:

(a) if delivered personally, when left at the address and for the contact referred to in this
clause; or

(b) if sent by pre-paid first class post or recorded delivery, at 9.00 am on the second Business Day
after posting; or

(c) if delivered by commercial courier, on the date and at the time that the courier's delivery
receipt is signed; or

(d) if delivered by email, on the date and at the time such email is received by the recipient
whether such message is opened at that time.

Any notice given or received by a lawyer for a party to this agreement is deemed to be given or
received with the actual or ostensible authority of the lawyer.

The Supplier may at times by notice nominate an address for service of legal proceeding, whether in
Australia or in any other place. A nomination binds the

13

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 15 -->
parties but nothing prevents the Supplier from making further nomination in place of any earlier
nomination.

20.3 A notice given under this agreement shall not be validly given if sent by e-mail.

21. Third party rights

21.1 A person who is not a party to this agreement shall not have any rights under or in connection
with it by virtue of the Contracts

21.2 The rights of the parties to terminate, rescind or agree any variation, waiver or settlement
under this agreement are not subject to the consent of any person that is not a party to this
agreement.

22. No partnership or agency

Except as expressly provided, nothing in this agreement is intended to, or shall be deemed to,
establish any partnership or joint venture between the parties, constitute either party the agent of
the other, nor authorise a party to make or enter into any commitments for or on behalf of the other
party.

23. Counterparts

This agreement may be executed in any number of counterparts, each of which when executed and
delivered shall constitute an original of this agreement, but all the counterparts shall together
constitute the same agreement.

24. Governing law and jurisdiction

24.1 This agreement and any dispute or claim arising out of or in connection with it or its subject
matter or formation (including non-contractual disputes or claims) shall be governed by and
construed in accordance with Ohio law.

24.2 The parties irrevocably agree that the courts of Ohio shall have non-exclusive jurisdiction to
settle any dispute or claim that arises out of or in connection with this agreement or its subject
matter or formation (including non- contractual disputes or claims).

This agreement has been entered into on the date stated at the beginning of it.

14

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 16 -->
Schedule 1

AriaTM Hip Stem System

RemedyTM Hip Stem system

LogicalTM Hip Cup system

Signature BiPolar Head

Genius Total knee system

15

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 17 -->
Schedule 2 Territory

USA.

16

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 18 -->
Schedule 3 The Trade Marks

OriginTM, LogicalTM, AriaTM, RemedyTM, GeniusTM

17

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 19 -->
Schedule 4 Prices

Aria Stem $610

Origin Stem $610

Remedy Stem $610

Logical Cup $450

Logical Liner $210

Metal Head $240

Ceramic Head $340

BiPolar Head $250

PS / CR Femoral Component $550

Insert $340

Tibia Tray $440

Patella $70

18

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
<!-- page 20 -->
SIGNED by Signature Orthopaedics Pty Ltd (ACN 106 702 416) In accordance with section 127 of the
Corporations Act:

) ) ) ) )

Director/Secretary

Name (please print)

Director

Name (please print)

SIGNED by

CPM Medical LLC

) ) ) ) )

Director/Secretary

Name (please print)

Director

Name (please print)

19

Source: FUSE MEDICAL, INC., 10-K, 3/21/2019
