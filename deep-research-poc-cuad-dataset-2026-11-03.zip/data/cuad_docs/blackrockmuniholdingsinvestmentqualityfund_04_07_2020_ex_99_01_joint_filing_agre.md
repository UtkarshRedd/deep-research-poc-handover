<!-- page 1 -->
# JOINT FILING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| Agreement Date | 2020-04-07 |
| Parties | Bank of America Corporatino, Banc of America Preferred Funding Corporation |
| Source | CUAD v1 / BLACKROCKMUNIHOLDINGSINVESTMENTQUALITYFUND_04_07_2020-EX-99.01-JOINT FILING AGREEMENT |

JOINT FILING AGREEMENT

Pursuant to and in accordance with the Securities Exchange Act of 1934, as amended (the "Exchange
Act"), and the rules and regulations thereunder, each party hereto hereby agrees to the joint
filing, on behalf of each of them, of any filing required by such party under Section 13 or Section
16 of the Exchange Act or any rule or regulation thereunder (including any amendment, restatement,
supplement, and/or exhibit thereto) with the Securities and Exchange Commission (and, if such
security is registered on a national securities exchange, also with the exchange), and further
agrees to the filing, furnishing, and/or incorporation by reference of this agreement as an exhibit
thereto. This agreement shall remain in full force and effect until revoked by any party hereto in a
signed writing provided to each other party hereto, and then only with respect to such revoking
party.

IN WITNESS WHEREOF, each party hereto, being duly authorized, has caused this agreement to be
executed and effective as of the date set forth below.

Date: April 7, 2020 BANK OF AMERICA CORPORATION

By: Ally Pecarro Name: Ally Pecarro Title: Attorney-in-fact

BANC OF AMERICA PREFERRED FUNDING CORPORATION

By: Michael Jentis Name: Michael Jentis Title: Authorized Signatory
