"""read: a capped, line-numbered window of one document, with page annotations.

A ReadTracker remembers windows already shown to this agent and returns
`already_read=True` with no text on repeats (A-RAG: cut retrieved tokens ~10x).
"""
from __future__ import annotations

from ..config import DEFAULT, Config
from ..models import ReadResult
from ..workspace import Workspace


class ReadTracker:
    def __init__(self) -> None:
        self._seen: dict[str, list[tuple[int, int]]] = {}

    def covered(self, doc_id: str, start: int, end: int) -> bool:
        for s, e in self._seen.get(doc_id, []):
            if s <= start and end <= e:
                return True
        return False

    def add(self, doc_id: str, start: int, end: int) -> None:
        self._seen.setdefault(doc_id, []).append((start, end))

    def lines_read(self) -> int:
        return sum(e - s + 1 for v in self._seen.values() for s, e in v)

    def docs_read(self) -> list[str]:
        """doc_ids with at least one read window (feeds opened-or-cited recall in the eval)."""
        return list(self._seen)


def read(
    ws: Workspace,
    doc_id: str,
    start_line: int = 1,
    n_lines: int | None = None,
    tracker: ReadTracker | None = None,
    config: Config = DEFAULT,
) -> ReadResult:
    caps = config.tools
    n = caps.READ_DEFAULT_LINES if n_lines is None else max(1, min(n_lines, caps.READ_MAX_LINES))
    total = ws.line_count(doc_id)
    start = max(1, min(start_line, total))
    end = min(total, start + n - 1)
    if tracker is not None and tracker.covered(doc_id, start, end):
        return ReadResult(
            doc_id=doc_id, start_line=start, end_line=end, total_lines=total,
            page_start=ws.page_of(doc_id, start), page_end=ws.page_of(doc_id, end),
            text="", already_read=True,
            note="window already read earlier in this session; use your notes or read a different range",
        )
    lines = ws.lines(doc_id)[start - 1 : end]
    width = len(str(end))
    body = "\n".join(f"{i:>{width}}| {ln}" for i, ln in zip(range(start, end + 1), lines))
    if tracker is not None:
        tracker.add(doc_id, start, end)
    note = None
    if end < total:
        note = f"{total - end} more lines after {end}; read(doc_id, {end + 1}, n) to continue"
    return ReadResult(
        doc_id=doc_id, start_line=start, end_line=end, total_lines=total,
        page_start=ws.page_of(doc_id, start), page_end=ws.page_of(doc_id, end),
        text=body, note=note,
    )


def render(res: ReadResult) -> str:
    pg = ""
    if res.page_start is not None:
        pg = f" p.{res.page_start}" + (f"–{res.page_end}" if res.page_end != res.page_start else "")
    head = f"read {res.doc_id} lines {res.start_line}-{res.end_line}/{res.total_lines}{pg}"
    if res.already_read:
        return head + f"\n(already read) {res.note}"
    return head + "\n" + res.text + (f"\n({res.note})" if res.note else "")
