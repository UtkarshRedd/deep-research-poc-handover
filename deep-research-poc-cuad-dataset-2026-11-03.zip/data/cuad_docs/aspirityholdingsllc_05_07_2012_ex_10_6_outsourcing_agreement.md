<!-- page 1 -->
# OUTSOURCING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Outsourcing Agreement |
| SEC Filing Date | 2012-05-07 |
| Parties | Twin Cities Power Holdings, LLC ("Company"); Redwater LLC ("Contractor") |
| Source | CUAD v1 / ASPIRITYHOLDINGSLLC_05_07_2012-EX-10.6-OUTSOURCING AGREEMENT |

Exhibit 10.6

OUTSOURCING AGREEMENT dated as of , 2012 TWIN CITIES POWER HOLDINGS, LLC and REDWATER LLC

$50,000,000.00 Renewable Unsecured Subordinated Notes
<!-- page 2 -->
TABLE OF CONTENTS ARTICLE I DEFINITIONS 1 Section 1.01 Defined Terms 1
<!-- page 3 -->
Section 1.02 Accounting Terms 4 ARTICLE II APPOINTMENT OF THE AGENT AND RELATED AGREEMENTS 5 Section
2.01 Appointment; Exclusivity 5 Section 2.02 Scope of Agency 5 Section 2.03 Compensation to the
Contractor 6 Section 2.04 Brokers and Dealers 8 Section 2.05 The Contractor's Unrelated Activities 8
Section 2.06 Best Efforts; Independent Contractor 8 Section 2.07 Issuance and Payment 8 ARTICLE III
SERVICES; STANDARD OF CARE 8 Section 3.01 Services for the Notes 8 Section 3.02 Maintenance of Files
and Records 11 Section 3.03 Monthly Reports to the Company 12 ARTICLE IV REPRESENTATIONS AND
COVENANTS OF THE COMPANY 13 Section 4.01 Representations, Warranties and Agreements of the Company
13 Section 4.02 Covenants of the Company 20 ARTICLE V REPRESENTATIONS AND COVENANTS OF THE AGENT;
CONDITIONS 22 Section 5.01 Representations and Warranties of the Contractor 22 Section 5.02
Covenants of the Contractor 24 ARTICLE VI CONDITIONS 25 Section 6.01 Conditions of the Contractor's
Obligations 25 Section 6.02 Conditions of the Company's Obligations 31 ARTICLE VII INDEMNIFICATION
AND CONTRIBUTION 31
<!-- page 4 -->
Section 7.01 The Company's Indemnification of the Contractor 31 Section 7.02 The Contractor's
Indemnification of the Company 32 Section 7.08 Intellectual Property Infringement 35 Section 7.09
Confidentiality 35 ARTICLE VIII TERM AND TERMINATION 36 Section 8.01 Effective Date of this
Agreement 36 Section 8.02 Termination Prior to Initial Closing Date 36 Section 8.03 Notice of
Termination 37 Section 8.04 Termination After Initial Closing Date 37 Section 8.05 Termination
Without Termination of Offering 38 ARTICLE IX MISCELLANEOUS 38
<!-- page 5 -->
ii

Section 9.01 Survival 38 Section 9.02 Notices 38 Section 9.03 Successors and Assigns; Transfer 39
Section 9.04 Cumulative Remedies 39 Section 9.05 Attorneys' Fees 39 Section 9.06 Entire Agreement 39
Section 9.07 Choice of Law; Venue 39 Section 9.08 Rights to Investor Lists 39 Section 9.09 Waiver;
Subsequent Modification 40 Section 9.10 Severability 40 Section 9.11 Joint Preparation 40 Section
9.12 Captions 40 Section 9.13 Counterparts 40 Section 9.14 Third Party Contractors 40
<!-- page 6 -->
OUTSOURCING AGREEMENT This OUTSOURCING AGREEMENT is entered into as of this day of , 2012 by and
between Twin Cities Power Holdings, LLC, a Minnesota limited liability company (the "Company"), and
Redwater LLC, a Minnesota limited liability company (the "Contractor"). RECITALS WHEREAS, the
Company has registered for public offer and sale an aggregate principal amount of $50,000,000.00 of
renewable, unsecured, subordinated notes of the Company; and WHEREAS, subject to the termination
rights set forth herein, the Company desires to retain the Contractor to perform certain ministerial
tasks on behalf of the Company, and Contractor desires to accept such duties, all as provided for by
the terms of this Agreement. NOW, THEREFORE, in consideration of the above and for other good and
valuable consideration, receipt of which is acknowledged, and in consideration of the mutual
promises, covenants, representations and warranties hereinafter set forth, the parties hereto agree
as follows: ARTICLE I DEFINITIONS Section 1.01 Defined Terms. Whenever used in this Agreement, the
following terms have the respective meanings set forth below. The definitions of such terms are
applicable to the singular as well as to the plural forms of such terms. Accepted Note Practices. As
applicable to the context in which this term is used, those procedures and practices with respect to
the servicing and administration of the Notes that satisfy the following: (i) the use of reasonable
care; (ii) compliance with all Governmental Rules; (iii) compliance with the provisions of this
Agreement and the Indenture; and (iv) give due consideration to the accepted standards of practice
of prudent servicing firms that service or administer comparable programs for publicly offered notes
or securities and the reliance of the Company on the Contractor for the servicing and administration
of the Renewable Note Program. Contractor. Redwater LLC, a Minnesota limited liability company, or
its successors in interest or assigns, if approved by the Company as provided in Sections 5.02(c)
and 9.03, below. Agreement. This Outsourcing Agreement, including any exhibits or attachments
hereto, as originally executed, and as amended or supplemented from time to time in accordance with
the terms hereof. Business Day. Any day other than (a) a Saturday or Sunday or (b) another day on
which banking institutions in the the State of Minnesota are authorized or obligated by law,
executive order, or governmental decree to be closed.

th
<!-- page 7 -->
Commission or SEC. The Securities and Exchange Commission. Company. Twin Cities Power Generation, or
its successors or assigns, if approved by Contractor as provided in Section 9.03, below. Due Period.
The monthly, quarterly, semi-annual, or annual periods, or the full term of the Note if interest is
due at maturity, for which scheduled payments of interest will be paid on any Note. Exchange Act.
The Securities Exchange Act of 1934, as amended, and as hereafter amended, and the rules and
regulations thereunder. Governmental Rules. Any law, rule, regulation, ordinance, order, code,
interpretation, judgment, decree, policy, decision or guideline of any governmental agency, court or
authority. Holder. The registered owner of any Note as it appears on the records of the Registrar,
including any purchaser or any subsequent transferee or other holder thereof. Incorporated
Documents. All documents that, on or at any time after the effective date of the Registration
Statement, are incorporated by reference therein, in the Prospectus, or in any amendment or
supplement thereto. Indenture. That certain Indenture dated on or about , 2012, by and between the
Company and the Trustee with respect to the Notes as the same may be amended or supplemented in
accordance with its terms, and including a supplement dated , 2012. Investor. Any person who
purchases Notes or who contacts the Contractor expressing an interest in purchasing the Notes or
requesting information concerning the Notes. Material Agreement. With respect to a person, any
agreement, contract, joint venture, lease, commitment, guaranty or other contractual arrangement or
any bond, debenture, indenture, mortgage, deed of trust, loan or security agreement, note,
instrument or other evidence of indebtedness, which in the case of any of the foregoing is material
to the business, assets, operations, condition or prospects, financial or otherwise, of such person
or which is material to the ability of such person to perform its obligations under this Agreement.
FINRA. Financial Industry Regulatory Authority. Note Confirmation. With respect to the issuance and
ownership of the Notes in book-entry form, an appropriate written confirmation of the issuance and
ownership or transfer of ownership of a Note to a Holder, the format of which shall comply with the
provisions of the Indenture. 2
<!-- page 8 -->
Note Portfolio. The aggregate of individual Notes, as it exists from time to time, which, unless the
context otherwise requires or provides, determined by the principal balances of the outstanding
Notes. Notes. The renewable, unsecured, subordinated notes of the Company that are being offered and
sold pursuant to the Registration Statement and that have an aggregate principal amount up to
$50,000,000 and such other terms as described in the Prospectus, and any additional principal amount
of the same or similar notes as may be registered from time to time pursuant to the Registration
Statement. Offering. The offer and sale of the Notes in accordance with the terms and subject to the
conditions set forth in the Registration Statement. Paying Agent. Bank, National Association or its
successors or assigns, or such other paying agent with respect to the Notes as may be subsequently
appointed by the Company pursuant to the Indenture. Paying Agent Agreement. That certain agreement
by and between the Company and the Paying Agent relating to the Company's engagement of the Paying
Agent to act as the paying agent for the Notes. Paying Agent Fees. All fees and expenses payable to
the Paying Agent in accordance with the Paying Agent Agreement. Proprietary Rights. All rights
worldwide in and to copyrights, rights to register copyrights, trade secrets, inventions, patents,
patent rights, trademarks, trademark rights, confidential and proprietary information protected
under contract or otherwise under law, and other similar rights or interests in intellectual or
industrial property. Prospectus. The prospectus included in the Registration Statement at the time
it was declared effective by the Commission, as supplemented by all prospectus supplements
(including interest rate supplements) related to the Notes that are filed with the Commission
pursuant to Rules 424(b) or (c) under the Securities Act. References to the Prospectus shall be
deemed to refer to and include the Incorporated Documents to the extent incorporated by reference
therein. Redemption Payment. The payment of principal plus any accrued and unpaid interest that is
being made at the discretion of the Company in accordance with the Indenture. Registration
Statement. That certain Registration Statement on Form S-1 (File No. - ) of the Company with respect
to the Notes filed with the Securities and Exchange Commission under the Securities Act on or about
, 2012, as amended and declared effective by the Commission, including the respective copies thereof
filed with the Commission. References to the 3
<!-- page 9 -->
Registration Statement shall be deemed to refer to and include the Incorporated Documents to the
extent incorporated by reference therein. Renewable Note Program. The marketing, administration,
customer service and investor relations, registration of ownership, reporting, payment, repurchase,
redemption, renewal and related activities associated with the Notes. Repurchase Payment. The
payment of principal plus any accrued and unpaid interest, less any penalties upon the repurchase of
any Note, that is being made at the request of the Holder in accordance with the Indenture.
Scheduled Payment. For any Due Period and any Note, the amount of interest and/or principal
indicated in such Note as required to be paid by the Company under such Note for the Due Period and
giving effect to any rescheduling or reduction of payments in any insolvency or similar proceeding
and any portion thereof. Securities Act. The Securities Act of 1933, as amended, and as hereafter
amended, and the rules and regulations thereunder. Subscription Agreement. A subscription agreement
entered into by a Person under which such Person has committed to purchase certain Notes as
identified thereby, in such form and substance as mutually agreed by the parties and as filed as an
exhibit to the Registration Statement. Trust Account. The trust account established by the Trustee
pursuant to the Indenture. Trust Indenture Act. The Trust Indenture Act of 1939, as amended, and as
hereafter amended, and the rules and regulations thereunder. Trustee. Bank, National Association, or
its successors or assigns, or any replacement Trustee under the terms of the Indenture. Trustee's
Fees. All fees and expenses payable to the Trustee in accordance with the Indenture. Section 1.02
Accounting Terms. Unless otherwise specified in this Agreement, all accounting terms used in this
Agreement shall be interpreted, all accounting determinations under this Agreement shall be made,
and all financial statements required to be delivered by any person pursuant to this Agreement shall
be prepared, in accordance with U.S. generally accepted accounting principles, as in effect from
time to time and as applied on a consistent basis. To the extent such principles do not apply to
certain reports or accounting practices of the Contractor, the parties will mutually agree on the
accounting practices and assumptions. 4

ARTICLE II RETENTION OF THE CONTRACTOR AND RELATED AGREEMENTS Section 2.01 Retention. On the basis
of the representations, warranties and agreements herein contained, and subject to the terms,
conditions and covenants set forth herein during the term of this Agreement, the Company retains the
Contractor to perform the tasks specified herein on behalf of the Company related to servicing of
the Notes, in each case, under the Renewable Note Program upon the terms and conditions set forth
herein, including, without limitation, compliance and conformity with Accepted Note Practices and
Governmental Rules, and the Contractor agrees to use its best efforts perform such tasks until the
later of the termination of the Offering or the sale of all of the Notes, or until the termination
of this Agreement, if earlier. In connection with the servicing of the Renewable Note Program, the
Contractor will carry out the duties provided for herein. Section 2.02 Scope of Duties. In the
performance of its duties hereunder, the Contractor shall have only such power and authority to take
action for purposes of servicing the Notes, under the Renewable Note Program that the Company, in
its discretion, deems necessary or appropriate, subject in all respects to compliance and conformity
with Accepted Note Practices and Governmental Rules. Initial instructions of the Company to the
Contractor are set forth in Exhibit B to this Agreement, which Company may, in its discretion, amend
and supplement from time to time. In the performance of its duties hereunder, the Contractor shall
(i) act as the agent of the Company in connection with the Renewable Note Program; (ii) promptly
forward to the Company all Subscription Agreements, notices or other documents received by it in
connection with the Renewable Note Program for the sole and exclusive use and benefit of the
Company; and (iii) make dispositions of the items in clause (ii) only in accordance with this
Agreement or at the written direction of the Company. Except as set forth in this Agreement with
respect to the Renewable Note Program, the Contractor shall have no authority, express or implied,
to act in any manner or by any means for or on behalf of the Company. Section 2.03 Compensation to
the Contractor. (a) The Contractor's Fees. In consideration of the agreement of the Contractor to
provide its services as set forth in this Agreement, the Company will pay the Contractor the
following amounts: (i) a monthly service fee of $7.50 per note based on the maximum number of notes
outstanding during the month, subject to a monthly minimum of $2,500; (ii) a fee for media services
further described in Exhibit A equal to the 15% gross/net differential or the fee equivalent
thereof; (iii) a fulfillment fee of $2.00 per investment kit mailed; (iv) a fulfillment fee of $1.00
per address for each bonus offer or marketing postcard mailed, subject to a $10,000 maximum per
project. 5
<!-- page 10 -->
<!-- page 11 -->
(b) The Contractor's Expenses. Except as otherwise provided in this Agreement, each party shall bear
all of its own expenses. To the extent that the Company agrees herein to pay specified
offering-related expenses such as all marketing and advertising costs, the Company will pay or cause
to be paid such expenses whether incurred prior or subsequent to the date of this Agreement (c)
Payment of Fees. On the first Business Day of each month, or as soon thereafter as practicable, the
Contractor shall provide the Company with a written invoice for the previous month's fees and
expenses that are payable with respect to Notes issued up to the last day of such month.. Such fees
and expenses will be due and payable by the later of the fifteenth (15 ) day of every month or
fifteen (15) days after the date such invoice is received. Section 2.04 Brokers and Dealers. At the
discretion of the Company, the Company may, at no additional obligation or expense to the
Contractor, use the services of brokers or dealers who are members in good standing of FINRA in
connection with the offer and sale of the Notes. The Company may enter into agreements with any such
broker or dealer to act as its agents for the sale of the Notes and shall be solely responsible for
the payment of any portion of the Contractor's compensation hereunder to such broker or dealer. The
Contractor's administrative services will apply to all notes sold by brokers or dealers and the
Company will compensate the Contractor for such services in accordance with Section 2.03. Section
2.05 The Contractor's Unrelated Activities. The Company agrees that the Contractor may service
renewable note programs for other issuers during the course of the Offering, but such activities
shall not prevent the Contractor from promptly and efficiently performing its duties hereunder. The
Contractor (and the Agency as defined in Section 3.01(b) below) may direct other issuers to
advertise the securities of other issuers on websites, in print, by radio, or by any other means and
at such times as they may determine; provided, however, that any such advertising which refers to
the Notes shall not refer to, mention, or advertise any securities or notes of any other issuer, nor
include any links to any other issuer, renewable note program or offering. The Contractor shall have
the right to advertise or otherwise disclose to unrelated prospective issuers, at its own expense,
its relationship with the Company, the services it provides in connection with the Notes and the
amount of money that it raised through the Offering and the performance of the Offering, subject to
the Company's consent, which shall not be unreasonably withheld. Section 2.06 Independent
Contractor. The Contractor shall have no obligation to purchase Notes for its own account. During
the term of this Agreement, all actions taken by the Contractor pursuant to this Agreement shall be
in the capacity of an independent contractor, and in no event shall the Contractor have any
obligations under the Notes. Section 2.07 Issuance and Payment. The Notes shall be issued pursuant
to the Indenture and all Scheduled Payments, Redemption Payments and Repurchase Payments shall be
made by automated clearing house (i.e., ACH) remittance from the Trust Account by the Paying Agent
in accordance with the Paying Agent Agreement and the Indenture. 6

th
<!-- page 12 -->
ARTICLE III SERVICES; STANDARD OF CARE Section 3.01 Services for the Notes. The services to be
provided to the Company by the Contractor pursuant to and during the term of this Agreement shall
include the following: (a) Marketing and Advertising. During the term of this Agreement, the
Contractor shall develop and execute a direct response marketing strategy for the Notes designed to
meet the Company's capital goals in a timely manner, which shall be subject to the prior approval of
the Company. The Contractor shall also oversee designing and printing all marketing materials
(subject to the prior approval of the Company), in accordance with the Securities Act, including the
applicable rules and regulations and any other requirements of the SEC and any other Governmental
Rules. The Contractor will provide the Company with media planning, media buying, media production
and media placement services related to the Offering. All ad placements and use of all marketing
materials shall be subject to the prior written approval of the Company. The Company will pay all
marketing and advertising costs related to the offering, including printing, postage, advertising
and web site hosting. (i) During the term of this Agreement, the Company hereby grants the
Contractor a limited license to use the Company's logo, corporate colors, trademarks, trade names,
fonts, and other aspects of corporate identity in advertisements and marketing materials related to
the Notes and on the Contractor's website, subject to the Company's prior written approval of the
specific use of these items in writing in each instance (which shall not be unreasonably withheld).
The Contractor will not make use of the Company's logo, corporate colors, trademarks or trade names
in any manner that would reasonably be expected to disparage or damage such marks or the reputation
of the Company or diminish the Company's goodwill. It is expressly agreed that the Contractor is not
acquiring any right, title or interest in the Company's logo, corporate colors, trademarks, trade
names or other intellectual property. (b) Subscription, Sale and Ownership. During the term of this
Agreement, the Contractor shall promptly forward to the Company each Subscription Agreement for the
Notes received from an Investor. The Company shall be responsible for determining whether (i) such
subscription shall be accepted, (ii) such agreement is complete and accurate in all material
respects, including without limitation the execution thereof by such Investor, (iii) such Investor
timely remits the proper purchase price for the Notes in accordance with the Subscription Agreement,
and (iv) the principal amount, interest rate and term to maturity and any other material terms of
the Notes are verified for accuracy and completeness. Upon delivery by each Investor of a completed
Subscription Agreement for Notes and full payment of the principal amount of such Notes in
accordance with the Investor's Subscription Agreement, and subject to the acceptance of the
Subscription Agreement by the Company, the Company shall promptly notify the Contractor and the
Contractor shall promptly (i) verify that the payment of the principal amount of such Investor's
accepted subscription for the Notes 7
<!-- page 13 -->
is being remitted to the Company in accordance with the Subscription Agreement in an account
established by the Company for such purpose or in such other manner as may be directed by the
Company from time to time, and (ii) remit to the Trustee electronic or hard copies of all accepted
Subscription Agreements and related records as may be reasonably requested by the Trustee, including
without limitation, a record of each deposit relating to the payment of the subscription amount of
the Notes. Pursuant to the preceding sentence, Notes shall be issued by the Contractor as the
Company's Registrar in book-entry form only and the Contractor shall deliver a Note Confirmation to
each Holder with respect to such Holder's respective accepted Subscription Agreement and the receipt
of full payment for such Holder's Notes. In the event that the Company rejects a Subscription
Agreement, the Contractor shall promptly return the Subscription Agreement and the related
subscription amount to the related Investor. The Company hereby appoints the Contractor, and the
Contractor hereby accepts such appointment, as its initial Registrar (as such term is defined in the
Indenture) for the Notes pursuant to the terms of the Indenture. For so long as the Contractor shall
serve as the Registrar for the Notes, the Contractor shall perform, in accordance with the terms of
the Indenture, all of the duties and obligations of the Registrar under the Indenture, including,
without limitation, the obligation to maintain a book-entry registration and transfer system for the
ownership of the Notes in accordance with the terms of the Indenture. (c) Investor Relations and
Reporting. During the term of this Agreement the Contractor, in conjunction with the Trustee, shall
perform ministerial tasks included in the customer service and investor relations functions with
respect to the Offering, as directed from time to time by the Company, which may include, but not be
limited to, handling inquiries from Investors in a manner consistent with Section 3.01(d), mailing
investment kits, delivering to each Investor the Prospectus and Subscription Agreement, and
processing Subscription Agreements. The Contractor shall to the best of its knowledge ensure that
each person submitting a Subscription Agreement shall have received the Prospectus. An Investor who
visits the offering web site shall be deemed to have received the Prospectus, provided such person
either delivers an Electronic Delivery Consent Form with such Investors Subscription Agreement or
certifies under penalties of perjury that he, she or it has received the Prospectus. (d) The
Contractor shall forward to the Company written or telephonic questions by Investors and Holders
relating to the Notes regarding topics that are not addressed in the Prospectus or its supplements,
including without limitation questions relating to the Company's finances and business, the
Company's performance and practices with regard to the Notes, and substantive matters regarding an
investment in the Notes, unless such questions can be answered solely by reference to the Company's
SEC filings. Notwithstanding the foregoing, the Contractor may respond to questions that are purely
administrative or ministerial in nature. The Contractor shall also be responsible for recording
changes in Holders' addresses or accounts, preparing and issuing maturity and renewal notices,
quarterly statements, newsletters, reports and analyses to Holders and to the Company, directing the
Paying Agent to make Scheduled Payments, Repurchase Payments and Redemption Payments to Holders in a
timely manner, and directing the Paying Agent to issue Form 1099INT's to Holders as required by law.
In addition, the Contractor shall provide the Trustee (and copy the Company) with management reports
regarding the Notes as required under the Indenture. 8
<!-- page 14 -->
(e) Web Site Development. Subject to compliance and conformity with Accepted Note Practices by the
Contractor, the Contractor (or a third party service provider working at the Contractor's direction)
shall assist the Company in developing a dedicated Internet web site separate from the Company's
corporate site to allow Investors to view online and download copies of the Offering documents
(including the Prospectus and Subscription Agreement) and marketing materials that are included in
the investment kit or comparable information. (f) Ownership of Web Pages. Any and all web pages used
by Contractor in connection with the Offering (the "Web Pages"), and all associated Proprietary
Rights, shall be owned exclusively by the Company. (g) Daily Payment Reports to Company. On each
Business Day during the term of the Notes, the Contractor shall furnish daily reports to the Company
that detail and summarize the amount of cash that is required to pay interest and principal on the
Notes. Section 3.02 Maintenance of Files and Records. The Contractor shall establish and maintain at
all times during the term of this Agreement files and records (including, without limitation,
computerized records) regarding the Notes and the Note Portfolio, with full and correct entries of
all transactions or modifications in a reasonably secure, up-to-date manner and in accordance with
the following: (a) Location. All Note and Note Portfolio files and records shall be stored and
maintained at the Contractor's principal place of business, or other location as designated by the
Company. The Contractor shall keep in such files all correspondence received or sent regarding each
Note, each Investor, and each Holder, whether upon any purchase or transfer of a Note. (b) Original
Documents. The Contractor will store all original Subscription Agreements, Note Confirmations,
correspondence from Investors and Holders and other materials relating to the Renewable Note Program
in a reasonably secure manner at the Contractor's principal offices or such other location as may be
designated by the Company. The Contractor shall exercise due care in handling and delivering the
original documents and the other documents in the Note files and records. The Contractor shall not
grant or allow any person an interest in original documents or rights thereunder, and all original
documents in the possession of the Contractor shall be deemed to be in the possession of the
Company. (c) Examination. At any time the Company and its agents and representatives may physically
inspect any documents, files or other records relating to the Renewable Note Program and discuss the
same with the Contractor's officers and employees. The Contractor shall supply copies of any such
documents, files, or other records upon the request of the Company, as soon as is reasonably and
commercially practicable at the Company's cost and expense. (d) Retention. Unless otherwise
requested by the Company, or unless otherwise required by Governmental Rules, the Contractor shall
retain, with respect to 9
<!-- page 15 -->
each Note, for a period of 24 months from the date the Note is fully paid, all records, files and
documents related to each such Note. At the end of such 24-month period, unless otherwise directed
by the Company, all such items shall be transferred to the Company, or to a third party as
designated by the Company, at the Company's sole cost and expense. The Contractor shall be permitted
to retain copies of any such documents for its own files for its own account and at its own expense.
The Contractor shall maintain the privacy of the Investors and Holders in accordance with all
applicable Governmental Rules. (e) Return. If this Agreement is terminated, or otherwise at the
instruction of the Company, the Contractor shall promptly deliver to the Company or its designee, as
the case may be, all Note files and records (including, without limitation, copies of computerized
records and servicing and other software, except as may be prohibited by any third party contract or
license) related to the administration of the Notes and all monies collected by it relating to the
Renewable Note Program (less any fees or expenses due to the Contractor). The Contractor shall be
entitled to make and keep copies of such records, at its cost and expense. In addition to delivering
such data and monies, the Contractor shall use its best efforts to effect the orderly and efficient
transfer of the administration of the Notes to the Company or other party designated by the Company
to assume responsibility for such administration, including, without limitation, directing Holders
to remit all repurchase or other notices to the address designated by the Company. All costs of
conversion and transfer of such records to the Company or another agent shall be paid by the
Company. (f) Security. The parties shall take appropriate security measures to protect customer
nonpublic personal information ("NPI"), as defined in the Gramm-Leach-Bliley Act of 1999, Title V,
and its implementing regulations, against accidental or unlawful destruction and unauthorized
access, tampering, and copying during storage in either party's computing or paper environment.
Access to NPI must be restricted to only the personnel that have a business need relating to the
Renewable Note Program. NPI must be stored in a secured format within all systems at both parties'
location and any other locations where the data may reside. Transmission of such NPI between the
parties or vendors must be done in a secure manner, in a method mutually agreed upon by both
parties. Each party will engage appropriate and industry-standard measures necessary to meet
information security guidelines as required by the Gramm- Leach-Bliley Act, Title V and its
implementing regulations as applicable to such party to effectuate this Agreement. Section 3.03
Information to the Company. As agreed by the parties, the Contractor shall make reports and analyses
available to the Company regarding the status of the Note Portfolio, the marketing results and the
amount of Notes remaining available for issuance under the Registration Statement. The Contractor
shall also provide interim or custom reports at the Company's request as is commercially reasonable,
including, without limitation, a weekly update via email identifying new Holders by name, address
and principal amount of Notes purchased. The Contractor shall also furnish statements, reports and
information to the Paying Agent to the extent that the Company is required to furnish or cause to be
furnished such statements, reports or information to the Paying Agent under the Paying Agent
Agreement. 10
<!-- page 16 -->
ARTICLE IV REPRESENTATIONS AND COVENANTS OF THE COMPANY Section 4.01 Representations, Warranties and
Agreements of the Company. The Company represents and warrants to and agrees with the Contractor as
follows, which representations and warranties shall be deemed to be made continuously from and as of
the date hereof until this Offering is terminated and all then outstanding Notes have been paid in
full or such earlier date that this Agreement has been terminated, except for those representations
and warranties that address matters only as of a particular date, which representations and
warranties shall be deemed to be made as of such date. (a) The Company satisfies all of the
requirements for the use of Form S-1 with respect to the offer and sale of securities as
contemplated by the Offering. The Commission has not issued any order preventing or suspending the
use of the Registration Statement or Prospectus and no proceeding for that purpose has been
instituted or, to the Company's knowledge, threatened by the Commission or the securities authority
of any state or other jurisdiction. (b) The Company has full requisite power and authority to enter
into this Agreement and perform the transactions contemplated hereby. This Agreement has been duly
authorized, executed and delivered by the Company and is a valid and binding agreement on the part
of the Company, enforceable against the Company in accordance with its terms subject to bankruptcy,
insolvency, fraudulent transfer, reorganization, moratorium and similar laws of general
applicability relating to or affecting creditors' rights and to general principles of equity. The
performance of this Agreement and the consummation of the transactions herein contemplated will not
result in a breach or violation of any of the terms and provisions of, or constitute a default
under: (i) any Material Agreement to which the Company or any subsidiary is a party or by which the
Company or any subsidiary or their respective properties may be bound; (ii) the articles of
incorporation or bylaws of the Company, or (iii) any applicable law, order, rule, regulation, writ,
injunction, judgment or decree of any court, government or governmental agency or body, domestic or
foreign, having jurisdiction over the Company or any subsidiary or their respective properties. (c)
No consent, approval, authorization or order of or qualification with any court, governmental agency
or body, domestic or foreign, having jurisdiction over the Company or over its properties is
required for the execution and delivery of this Agreement and the consummation by the Company of the
transactions herein contemplated, except such as may be required under the Securities Act, the
Exchange Act, the Trust Indenture Act, or under state or other securities or blue sky laws, all of
which requirements have been satisfied. 11
<!-- page 17 -->
Section 4.02 Covenants of the Company. The Company hereby covenants and agrees with the Contractor
as follows: (a) The Company will notify the Contractor promptly of the time when the Registration
Statement or any post-effective amendment to the Registration Statement has become effective or any
supplement to the Prospectus has been filed and of any request by the Commission for any amendment
or supplement to the Registration Statement or Prospectus or additional information. In the event
that the Company files any amendment or supplement to the Registration Statement or Prospectus to
which the Contractor shall reasonably object, the Contractor will be relieved of its obligations
with respect to the Offering (but not the administration) of the Notes until such time as the
Company shall have filed such further amendments or supplements such that the Contractor is
reasonably satisfied with the Registration Statement and the Prospectus, as then amended or
supplemented. (b) The Company will advise the Contractor, promptly after it shall receive notice or
obtain knowledge thereof, of the issuance by the Commission of any stop order suspending the
effectiveness of the Registration Statement, of the suspension of the qualification of the Notes for
offering or sale in any jurisdiction, or of the initiation or receipt of any specific threat of any
proceeding for any such purpose. (c) The Company will furnish to the Contractor copies of the
Registration Statement, the Prospectus, and all amendments and supplements to such documents, in
each case as soon as available and in such quantities as the Contractor may from time to time
reasonably request. (d) For such period as this Agreement may be in effect, the Company shall make
available to the Contractor, as soon as the same shall be sent to its stockholders generally, copies
of all annual or interim stockholder reports of the Company and will, for the same period, also
furnish the Contractor one copy of any report, application or document (other than exhibits, which,
however, will be furnished on the Contractor's request) filed by the Company with the Commission,
The Nasdaq Stock Market or any other securities exchange. (e) At all times during the term of this
Agreement, the Company shall provide all information reasonably requested by the Contractor that
relates to the Renewable Note Program in a timely manner and shall use its best efforts to insure
that such information is complete and accurate. (f) The Company will, during the term of this
Agreement, furnish directly to the Contractor quarterly profit and loss statements and reports of
the Company's cash flow as reported on the applicable quarterly report on Form 10-Q. 12

ARTICLE V REPRESENTATIONS AND COVENANTS OF THE CONTRACTOR; CONDITIONS Section 5.01 Representations
and Warranties of the Contractor. The Contractor hereby represents and warrants to the Company as
follows, which representations and warranties shall be deemed to be made continuously from and as of
the date hereof until this Offering is terminated or such earlier date that this Agreement has been
terminated: (a) The Contractor (i) has been duly organized, is validly existing and in good standing
as a Minnesota limited liability company, (ii) has qualified to do business as a foreign corporation
and is in good standing in each jurisdiction where the character of its properties or the nature of
its activities (including without limitation activities of the Contractor hereunder) makes such
qualification necessary, and (iii) has full power, authority and legal right to own its property, to
carry on its business as presently conducted, and to enter into and perform its obligations under
this Agreement. (b) The Contractor has full requisite power and authority to enter into this
Agreement and perform the transactions contemplated hereby. This Agreement has been duly authorized,
executed and delivered by the Contractor and is a valid and binding agreement on the part of the
Contractor, enforceable against the Contractor in accordance with its terms subject to bankruptcy,
insolvency, fraudulent transfer, reorganization, moratorium and similar laws of general
applicability relating to or affecting creditors' rights and to general principles of equity. The
performance of this Agreement and the consummation of the transactions herein contemplated will not
result in a breach or violation of any of the terms and provisions of, or constitute a default
under: (i) any Material Agreement to which the Contractor is a party or by which the Company or its
properties may be bound; (ii) the articles of incorporation or bylaws of the Contractor, or (iii)
any applicable law, order, rule, regulation, writ, injunction, judgment or decree of any court,
government or governmental agency or body, domestic or foreign, having jurisdiction over the
Contractor or over its properties. (c) The Contractor has obtained all governmental consents,
licenses, approvals and authorizations, registrations and declarations which are necessary for the
execution, delivery, performance, validity and enforceability of the Contractor's obligations under
this Agreement. (d) The Contractor has operated and is operating in compliance with all
authorizations, licenses, certificates, consents, permits, approvals and orders of and from all
state, federal and other governmental regulatory officials and bodies necessary to conduct its
business as contemplated by and described in this Agreement, all of which are, to the Contractor's
knowledge, valid and in full force and effect. The 13
<!-- page 18 -->
Contractor is conducting its business in compliance with all applicable Governmental Rules, laws,
rules and regulations of the jurisdictions in which it is conducting business, and the Contractor is
not in violation of any applicable Governmental Rules, law, order, rule, regulation, writ,
injunction, judgment or decree of any court, government or governmental agency or body, domestic or
foreign, having jurisdiction over the Contractor or over its properties. (e) The Contractor
maintains insurance, which is in full force and effect, with insurers of recognized financial
responsibility of the types and in the amounts generally deemed adequate for its business and, to
the best of the Contractor's knowledge, in line with the insurance maintained by similar companies
and businesses; and the Contractor has no reason to believe that it will not be able to renew its
existing insurance coverage as and when such coverage expires or obtain similar coverage from
similar insurers as may be necessary to continue its business at a cost that would not materially
and adversely affect the financial condition or business operations of the Contractor. Section 5.02
Covenants of the Contractor. The Contractor hereby covenants to the Company as follows, which
covenants shall be deemed in force unless and until this Agreement is terminated as provided herein:
(a) The Contractor shall punctually perform and observe all of its obligations and agreements
contained in this Agreement. (b) The Contractor shall conduct its business in compliance with all
applicable Governmental Rules, and its activities shall not violate any governmental rules relating
to the registration or the activities of securities brokers and dealers. To the extent that this
covenant to comply with all Governmental Rules conflicts with any other covenant contained in this
Agreement, the covenant to comply with all Governmental Rules shall control. (c) Except as provided
in this Agreement, the Contractor shall not take any action, or permit any action to be taken by
others, which would excuse any person from any of its covenants or obligations under any Note, or
under any other instrument related to a Note, or which would result in the amendment, hypothecation,
subordination, termination or discharge of, or impair the validity or effectiveness of, any Note or
any such instrument or any right in favor of the Company in a Note or such instrument, without the
written consent of the Company. (d) The Contractor shall not assign this Agreement or any of its
rights, powers, duties or obligations hereunder without the express prior written consent of the
Company, which shall not be unreasonably withheld. (e) At all times during the term of this
Agreement, the Contractor shall provide all information relating to the Offering, the Renewable Note
Program or the Note Portfolio reasonably requested by the Company in a timely manner and shall use
its best efforts to insure that such information is complete and accurate in all material respects.
14
<!-- page 19 -->
(f) The Contractor shall take such additional action as is reasonably requested by the Company in
order to carry out the purposes of this Agreement. Such reasonable additional action includes, but
is not limited to, cooperating with Company in verification of Contractor's compliance, such as by
providing copies of certificates of insurance and of other books and records of Contractor, and by
permitting inspection of the premises, books and records of Contractor. ARTICLE VI CONDITIONS
Section 6.01 Conditions of the Contractor's Obligations. The obligation of the Contractor to
administer the Offering on a best efforts basis as provided herein shall be subject to the accuracy
of the representations and warranties of the Company, to the performance by the Company of its
obligations hereunder, and to the satisfaction of the following additional conditions: (a) The
Registration Statement shall be effective, and no stop order suspending the effectiveness thereof
shall have been issued and no proceedings for that purpose shall have been initiated or, to the
knowledge of the Company, or the Contractor, threatened by the Commission or any state securities
commission or similar regulatory body. Any request of the Commission for additional information (to
be included in the Registration Statement or the Prospectus or otherwise) shall have been complied
with to the reasonable satisfaction of the Contractor and the Contractor's counsel. (b) The
Contractor shall not have advised the Company of its reasonable belief that the Registration
Statement or Prospectus, or any amendment thereof or supplement thereto, contains any untrue
statement of a fact which is material or omits to state a fact which is material and is required to
be stated therein or is necessary to make the statements contained therein, in light of the
circumstances under which they were made, not misleading, or, if the Contractor has so advised the
Company, the Company shall not have taken reasonable action to investigate such belief and, where
appropriate, amend the Registration Statement or supplement the Prospectus so as to correct such
statement or omission or effect such compliance. (c) The Indenture shall have been duly authorized,
executed and delivered by the Company and duly qualified under the Trust Indenture Act. (d) All
corporate proceedings and other legal matters in connection with this Agreement, the form of
Registration Statement and the Prospectus, and the registration, authorization, issue, sale and
delivery of the Notes shall have been reasonably satisfactory to the Contractor's counsel, in all
material respects, and the Contractor's counsel shall have been furnished with such papers and
information as it may reasonably have requested to enable it to pass upon the matters referred to in
this Section. 15
<!-- page 20 -->
ARTICLE VII INDEMNIFICATION AND CONTRIBUTION Section 7.01 The Company's Indemnification of the
Contractor. The provisions of Exhibit A hereto, entitled "Responsibility of and Indemnification by
Agency" are hereby incorporated herein by reference. Section 7.02 The Contractor's Indemnification
of the Company. The provisions of Exhibit A hereto, entitled "Responsibility of and Indemnification
by Company" are hereby incorporated herein by reference. Section 7.03 Intellectual Property
Infringement. The Contractor agrees that it shall defend, indemnify and hold harmless, at its own
expense, all suits and claims against the Company and any officers, directors, employees and
affiliates of the Company (collectively, the "Company Indemnified Parties"), for infringement or
violation of any patent, trademark, copyright, trade secret or other intellectual property rights of
any third party that relates to this Agreement or the Offering, or servicing of the Notes. The
Contractor agrees that it shall pay all sums, including without limitation, reasonable attorneys'
fees and other costs incurred by the Company, in defense of, by final judgment or decree, or in
settlement of any suit or claim asserted or assessed against, or incurred by, any of the Company
Indemnified Parties on account of such infringement or violation, provided that the Company
Indemnified Parties involved shall cooperate in all reasonable respects with the Contractor and its
attorneys in the investigation, trial and defense of such lawsuit or action and any appeal arising
therefrom; provided, however, that the Company Indemnified Parties may, at their own cost,
participate in the investigation, trial and defense of such lawsuit or action and any appeal arising
therefrom. The parties shall cooperate with each other in any notifications to insurers. Section
7.04 Confidentiality. The parties to this Agreement acknowledge and agree that all information,
whether oral or written, concerning a disclosing party and its business operations, prospects and
strategy, which is furnished by the disclosing party to the other party is deemed to be
confidential, restricted and proprietary to the disclosing party (the "Proprietary Information").
Proprietary Information supplied shall not be disclosed, used or reproduced in any form except as
required to accomplish the intent of, and in accordance with the terms of, this Agreement and the
Indenture. The receiving party shall provide the same care to avoid disclosure or unauthorized use
of Proprietary Information as it provides to protect its own proprietary information, including
without limitation retaining Proprietary Information in a secure place with limited access, but in
no event shall the receiving party fail to use reasonable care under the circumstances to avoid
disclosure or unauthorized use of Proprietary Information. Unless otherwise specified in writing,
all Proprietary Information shall (i) remain the property of the disclosing party, (ii) be used by
the receiving party only for the purpose for which it was intended under this Agreement and the
Indenture, and (iii) together with all copies of such information, be returned to the disclosing
party or destroyed upon request of the disclosing party, and, in any event, upon termination of this
Agreement, except as otherwise provided or contemplated by this Agreement, including Sections
3.02(b) and (e) and 8.05 hereof. Proprietary Information does not include information which is: (a)
published or included as disclosure within the Registration Statement or otherwise available in the
public domain through no fault of the receiving party; (b) lawfully received from a third party
having rights in the information without 16
<!-- page 21 -->
restriction of the third party's right to disseminate the information and without notice of any
restriction against its further disclosure; or (c) produced under order of a court of competent
jurisdiction or other similar requirement of a governmental agency or authority, so long as the
party required to disclose the information provides the other party with prior notice of such order
or requirement and its cooperation to the extent reasonable in preserving its confidentiality.
Because damages may be difficult to ascertain, and without limiting any other rights and remedies
specified herein, an injunction may be sought against the party who has breached or threatened to
breach this Section. ARTICLE VIII TERM AND TERMINATION Section 8.01 Effective Date of this
Agreement. This Agreement shall become effective as of the date first set forth above, and shall
continue in full force and effect until terminated as provided below. Section 8.02 Termination. The
Company or the Contractor may terminate this Agreement at any time in whole or in part as more
specifically provided below, and in such case, the Contractor will be paid fees incurred up to the
date of such termination plus its expenses accrued as of such date within 30 days of such
termination. The Company will have the ability to terminate this Agreement by giving 60 days' prior
written notice to the Contractor. The Contractor will have the ability to terminate this Agreement
by giving 90 days' prior written notice to the Company. Section 8.03 Termination Without Termination
of Offering. Anything to the contrary notwithstanding, the termination of this Agreement shall not
prevent the Company from commencing or cause the Company to terminate the Offering. In the event
this Agreement is terminated without a termination of the Offering, then the Company, or its agents,
shall be entitled to use all materials developed by the Contractor related to the Notes as provided
elsewhere herein. ARTICLE IX MISCELLANEOUS Section 9.01 Survival. The respective indemnity and
contribution agreements of the Company and the Contractor set forth herein and the respective
representations, warranties, covenants and agreements of the Company and the Contractor set forth
herein, shall remain operative and in full force and effect, regardless of any investigation made
by, or on behalf of, the Contractor, the Company, any of its officers and directors, or any
controlling person referred to in Article VII and shall survive the sale of the Notes and any
termination or cancellation of this Agreement. Any successor of any party or of any such controlling
person, or any legal representative of such controlling person, as the case may be, shall be
entitled to the benefit of the respective indemnity and contribution agreements. Section 9.02
Notices. All notices or communications hereunder, except as herein otherwise specifically provided,
shall be in writing and shall be mailed, delivered or transmitted by any standard form of
telecommunication, as follows: 17
<!-- page 22 -->
Section 9.03 Successors and Assigns; Transfer. This Agreement shall inure to the benefit of and be
binding upon the Contractor and the Company and their respective successors and permitted assigns.
Nothing expressed in this Agreement is intended or shall be construed to give any person or
corporation, other than the parties hereto, their respective successors and assigns, any legal or
equitable right, remedy or claim under, or in respect of, this Agreement or any provision herein
contained; this Agreement and all conditions and provisions hereof being intended to be and being
for the sole and exclusive benefit of the parties hereto and their respective executors,
administrators, successors, and for the benefit of no other person or corporation. Neither party may
assign its rights and obligations under this Agreement without the written consent of the other
party. Section 9.04 Cumulative Remedies. Unless otherwise expressly provided herein, the remedies of
the parties provided for herein shall be cumulative and concurrent, and may be pursued singularly,
successively or together, at the sole discretion of the party for whose benefit such remedy is
provided, and may be exercised as often as occasion therefor shall arise. Section 9.05 Attorneys'
Fees. In the event of any action to enforce or interpret this Agreement, the prevailing party shall
be entitled to recover reasonable attorneys' fees and costs, whether or not such action proceeds to
judgment. 18

If to the Contractor, to:

Redwater LLC 5400 Opportunity Court Suite 160 Minneapolis, Minnesota 55343 Attention: K. Edward
Elverud Tel. (952) 345-3385 If to the Company, to:

Twin Cities Power Holdings, LLC 16233 Kenyon Avenue Suite 210 Lakeville, Minnesota 55044 Attn: Chief
Executive Officer Tel. 952-431-0400 with a copy to:

Leonard, Street and Deinard 150 South Fifth Street — Suite 2300 Minneapolis, Minnesota 55402
Attention: Mark S. Weitz Tel. 612-335-1517
<!-- page 23 -->
Section 9.06 Entire Agreement. Except as otherwise expressly provided herein, this Agreement
constitutes the entire agreement of the parties hereto with respect to the matters addressed herein
and supersedes all prior or contemporaneous contracts, promises, representations, warranties and
statements, whether written or oral (including, but not limited to, the Proposal), with respect to
such matters. Section 9.07 Choice of Law; Venue. This Agreement shall be governed by and construed
in accordance with the laws of the State of Minnesota, without regard to conflict of law principles.
Any dispute shall be heard in the courts of the state of Minnesota. Section 9.08 Rights to Investor
Lists. The parties acknowledge that the Offering will produce a list of investors that purchase
Notes, a list of prospects that respond to advertisements, but do not purchase any Notes, a list of
former investors who redeemed their Notes, and a list of former investors whose Notes the Company
redeemed. Subject to any privacy laws, both the Company and the Contractor will be able to use these
lists for their own business purposes as long as doing so does not interfere with the marketing,
sale or administration of the Notes. Section 9.09 Waiver; Subsequent Modification. Except as
expressly provided herein, no delay or omission by any party in insisting upon the strict observance
or performance of any provision of this Agreement, or in exercising any right or remedy, shall be
construed as a waiver or relinquishment of such provision, nor shall it impair such right or remedy,
and no waiver by any party or any failure or refusal of the other party to comply with its
obligations under this Agreement shall be deemed a waiver of any other or subsequent failure or
refusal to so comply by such other party. No waiver or modification of the terms hereof shall be
valid unless in writing and signed by the party to be charged, and then only to the extent therein
set forth. Section 9.10 Severability. If any term or provision of this Agreement or application
thereof to any person or circumstance shall, to any extent, be found by a court of competent
jurisdiction to be invalid or unenforceable, the remainder of this Agreement, or the application of
such term or provision to persons or circumstances other than those as to which it is held invalid
or unenforceable, shall not be affected thereby and each term or provision of this Agreement shall
be valid and enforceable to the fullest extent permitted by law. Section 9.11 Joint Preparation. The
preparation of this Agreement has been a joint effort of the parties and the resulting document
shall not, solely as a matter of judicial construction, be construed more severely against one of
the parties than the other. Section 9.12 Captions. The title of this Agreement and the headings of
the various articles, section and subsections have been inserted only for the purpose of
convenience, are not part of this Agreement and shall not be deemed in any manner to modify,
explain, expand or restrict any of the provisions of this Agreement. Section 9.13 Counterparts. This
Agreement may be executed in any number of counterparts, each of which shall be deemed an original,
but all of which together shall constitute one instrument. Section 9.14 Third Party Contractors. In
the event that the Company engages a third party to perform any of the obligations of the Contractor
under this Agreement, the Company 19
<!-- page 24 -->
shall provide written notice to the Contractor of such engagement, the Contractor shall thereafter
be relieved of any such obligations for which the third party was engaged. [Remainder of page
intentionally left blank] 20
<!-- page 25 -->
IN WITNESS WHEREOF, this Outsourcing Agreement is hereby entered into by the undersigned parties as
of the date first set forth above.

21

Exhibit A Media Services The following describes the advisory services to be provided by Redwater
LLC ("Contractor") to Twin Cities Power Generation ("Company") in connection with the administration
of Company's renewable, unsecured, subordinated notes (the "Notes"), as more specifically defined
in, and pursuant to the terms of, the Outsourcing Agreement to which this description is an exhibit.
1. Agent Services. Agent will perform the following services for Company: · Acting on the study,
analysis and knowledge of the product described above, formulate and recommend a media plan to the
Company and coordinate the execution of such a plan as directed by the Company. · Check and verify
insertions, displays, broadcasts or other means used. · Audit invoices for space and time and other
marketing services performed on Company's behalf. · Coordinate creative and copy development, direct
mail services, literature fulfillment, commercial printing, list management, list brokering,
efficiency analysis and other similar activities. 2. General Provisions.

TWIN CITIES POWER HOLDINGS, LLC By:

Name:

Title:

REDWATER LLC. By:

Name: K. Edward Elverud Title: Manager
<!-- page 26 -->
Approval of Expenditures: Contractor agrees to secure Company's written approval of all expenditures
in connection with Company's plans. Cancellation of Plans: Company reserves the right to modify,
reject, cancel or stop any and all plans, schedules or work in progress. In such event Contractor
shall take reasonable steps to carry out Company's instructions as promptly as practicable. Company
agrees to assume liability for all commitments made by Contractor on its behalf, and to reimburse
Contractor for any losses (including cancellation penalties) that Contractor may sustain derived
therefrom and for all expenses incurred in connection with Company approved plans on its
authorization, and to pay Contractor any service charges relating thereto, in accordance with the
provisions hereof. Failure of Suppliers to Perform: Contractor will endeavor to the best of its
knowledge and ability guard against any loss to Company through failure of media or suppliers to
properly execute their commitments, but shall not be held responsible for any failure on their part.
Confidentiality: Contractor acknowledges its responsibility to use all reasonable efforts to
preserve the confidentiality of any proprietary or confidential information or data developed by
Contractor on behalf of Company or disclosed by Company to Contractor. 22
<!-- page 27 -->
Responsibility of and Indemnification by Agency: Contractor agrees to indemnify and hold Company,
its officers, directors, agents and employees harmless from and against any claims, liabilities,
losses, costs, expenses, or the like, including reasonable attorneys' fees, incurred in respect to
any material breach by Contractor hereof or Contractor's negligence and/or intentional wrongdoing in
connection with the services. Responsibility of and Indemnification by Company: Company agrees to
indemnify and hold Contractor, its officers, managers, directors, agents and employees harmless from
and against any claims, liabilities, losses, costs, expenses, or the like, including reasonable
attorneys' fees, incurred in respect to any material breach by Company of this Agreement or
Company's negligence and/or intentional wrongdoing in connection with the services. Company shall be
responsible for the accuracy, completeness and propriety of information concerning its products and
services that it furnishes to Contractor in connection with the performance of the services. 3.
Expenses and Fees. · Company agrees to pay or prepay advertising, graphic design and printing
expenses either directly to the respective vendors or to the Contractor as required. The Company
will pay the Contractor the difference between the published gross rates and the net rates for all
advertisements, graphic design services or printing services or an equivalent mark-up. All
Contractor fees will be subject to the approval of the Company. · Refunds: Contractor shall refund
or credit Company any other refunds received in connection with advertisements. · Other Marketing
Expenses. Subject to its prior approval, the Company agrees to pay Contractor for all reasonable out
of pocket, non-media charge marketing expenses related to the development and production of all
direct marketing and promotional materials. 5. Termination. · Period of Services: The services
described herein to be provided by Agency shall begin upon execution and delivery of the Outsourcing
Agreement and shall continue until termination of Contractor's activities to administer the Notes
thereunder. · Payment for Purchases and Work Done: Any materials, services, etc. Contractor has
committed to purchase for Company's account, or with Company's approval (or any uncompleted work
previously approved by Company either specifically or as part of a plan) prior to termination of the
Services shall be paid for by Company in accordance with the provisions of this Agreement. 23
<!-- page 28 -->
Exhibit B Service Standards Initial Instructions of Company to Contractor pursuant to that certain
Outsourcing Agreement dated as of , 2012, between Twin Cities Power Holdings, LLC and Redwater LLC.
Geographical Limitations. Contractor shall not communicate with Investors resident in any state that
is identified in the then-current Prospectus as a state in which the Notes are not offered, other
than to communicate, in substance, that the Notes are not offered to persons resident in such
states. The initial list of such states is as follows, but the Company may, in its discretion, amend
such list by filing an amended Prospectus or a supplement to Prospectus: . [TBD] 24
