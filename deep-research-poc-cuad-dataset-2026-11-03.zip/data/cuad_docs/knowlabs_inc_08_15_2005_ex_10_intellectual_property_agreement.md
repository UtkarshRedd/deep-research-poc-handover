<!-- page 1 -->
# INTELLECTUAL PROPERTY AGREEMENT
| Field | Value |
|---|---|
| Document Type | IP Agreement |
| Agreement Date | 2004-06-16 |
| Parties | Visualant Incorporated ("Company"); Kenneth Turpin ("Turpin") |
| Source | CUAD v1 / KNOWLABS,INC_08_15_2005-EX-10-INTELLECTUAL PROPERTY AGREEMENT |

Exhibit 10.1

INTELLECTUAL PROPERTY AGREEMENT

THIS AGREEMENT (the "Agreement"), dated June 16, 2004, is made and entered into by and between
VISUALANT INCORPORATED, a Nevada corporation (the "Company") and KENNETH TURPIN ("Turpin"),

WHEREAS, the Company is in the business of researching, developing, acquiring, and commercializing
products and services related to color technology outside the visible spectrum, using specialized
narrow band N-IR and N-UV sensors and spatial analysis software modeling which translate the
invisible into the visible (the "Business"), and involving specialized and proprietary information
and trade secrets which the Company considers to be amongst its most sensitive, confidential, and
proprietary information;

WHEREAS, Turpin has identified, researched and is developing the Business for and on behalf of the
Company;

NOW THEREFORE, in consideration of the sum of $10.00 paid by each party to the other, and the
representations, warranties and covenants contained herein, the sufficiency of which is hereby
acknowledged, the parties hereto agree as follows:

1. Definitions. In this Agreement, the following words and phrases shall have the following
meanings:

(a) "Affiliate" shall have the same meaning as contained in the Canada Business Corporations Act;
"Company Affiliate" shall mean any Affiliate of the Company;

(b) "Company Property" means any and all information, equipment, hardware, components, documents and
other property of the Company or any Company Affiliate provided to or used by Turpin, including all
computers, monitors, laptops, personal digital assistants, mobile computing devices, computer
peripherals, cell phones and other telephones, pagers, storage media, security cards, keys, calling
cards, charge cards, reference materials, designs, specifications, schematics, drawings, diagrams,
pictures, notes, memoranda, papers, manuals, records, and the like;

(c) "Intellectual Property Rights" means any and all copyrights, design rights, trade-marks, trade
secrets and confidential information, patent rights, and all other proprietary rights, which may
subsist anywhere in the world, whether registered or unregistered, including all applications for
registration or issuance of any of the foregoing, all priority and convention rights in any of the
foregoing, and all rights to file any such applications;

(d) "Research and Development" means information pertaining to any research, development,
investigation, study, analysis, experiment or test carried on or proposed to be carried on by the
Company or any Company Affiliate;

(e) "Software" means any and all algorithms, data structures, code, instructions, scripts, tables,
data, and other information used by a computer or processor to process information, such Software
including, without limitation, (i) all source code, object code and executable code, and (ii) all
routines, subroutines, program material, computer files, system architectures, models, flowcharts,
requirements, specifications, notes, outlines, papers, descriptions and other

1

documents created or developed in connection with any of the foregoing, the resulting screen formats
and other visual effects of the Software, and any formulae, processes, or ideas, whether or not
protected by copyright;

(f) "Work" means, with respect to the Business, any and all inventions, discoveries, designs,
developments, modifications, improvements, products, methods, trade secrets, mid know- how that
Turpin, solely or with others, conceives of, modifies, develops, contributes to, or reduces to
practice, including without limitation Software, records, documents, photographs, video recordings,
sound recordings, images, designs, animations, drawings, sketches, diagrams, plans, compilations,
and analyses, and all parts, elements, combinations and derivative works thereof, and

(g) "Work Product" means any and all Work and other items in any form that Turpin, solely or with
others, conceives of, modifies, develops, contributes to, or reduces to practice during the period
of Turpin's employment with the Company and which:

(i) relate, directly or indirectly, to the Company's present or future foreseeable Business or
Research and Development; or

(ii) result from any work performed by Turpin for the Company;

whether or not such are made during or after working hours, on or off the Company's premises.

2. Ownership by the Company. Turpin acknowledges and agrees that all Work
<!-- page 2 -->
Product have been made for the Company and that the Company shall be the exclusive owner of all
right, title, and interest in and to the Work Product and all Intellectual Property Rights therein.
Turpin does hereby assign and transfer to the Company, effective upon creation, all right, title,
and interest that Turpin may have in and to the Work Product and all Intellectual Property Rights
therein and does hereby assign all of Turpin's future right, title, and interest that Turpin may
have in and to each of the Work Product and Intellectual Property Rights therein, effective at the
time each is created. Turpin hereby irrevocably and expressly waives as against any person all moral
rights Turpin may have in any and all Work Product.

3. Disclosure of Work Product. Turpin agrees to maintain at all times adequate and current records
relating to the creation and development of the Work Product and Intellectual Property Rights
therein, which records and all copies thereof shall be and shall remain the exclusive property of
the Company, and to disclose all such records and copies to the Company promptly.

4. Assistance. Turpin shall, at the Company's request, assist with, execute and deliver all further
documents, applications, declarations, verifications, submissions, transfers and assignments and do
all other things requested by the Company, acting reasonably, during the term hereof and thereafter,
at the expense of the Company, but without additional compensation, to enable the Company or its
nominees to apply for, acquire, prosecute, perfect, enforce and/or maintain any and all right, title
and interest, in any country, in and to the Confidential Information, the Work Product and the
Intellectual Property Rights in same.

2

5. Protection of Work Product. Turpin covenants that Turpin shall not at any time directly or
indirectly contest or assist any third party in contesting the Company's right, title, and interest
in and to the Work Product or any Intellectual Property Rights therein. Turpin shall not, directly
or indirectly, apply for or seek registration of any Intellectual Property Rights in any Work
Product in any jurisdiction without the express written approval of the Company. Turpin waives any
and all existing and future moral rights with respect to the Work Product and all Intellectual
Property Rights therein.

6. Return of Company Property. Turpin shall deliver to the Company all Work Product and Company
Property, including all originals and copies thereof, in Turpin's possession and/or control, at the
request of the Company, or, in the absence of such a request, upon the termination of Turpin's
employment with the Company.

7. Term and Termination. This Agreement shall continue until terminated as provided herein. This
Agreement may, with written notice, be terminated by either party should Turpin's employment with
the Company terminate for any reason. Termination under this Section 12 shall be effective from the
date written notice is delivered or the date specified in the written notice. whichever is later.

8. Injunctive Relief. Turpin acknowledges that monetary damages would be inadequate to compensate
the Company for any breach by Turpin of this Agreement and that any such breach would constitute
irreparable harm to the Company. Accordingly, Turpin agrees that upon the breach or threatened
breach of any terms of this Agreement, the Company shall, in addition to all other remedies, be
entitled to an immediate injunction enjoining any breach of this Agreement or a decree for specific
performance.

9. Amendment. Waiver. Variation. No amendment, waiver, or variation of the terms, conditions,
warranties, covenants, agreements or undertakings set out herein shall be of any force or effect
unless reduced to writing duly executed by all parties hereto in the same manner and with the same
formality as this Agreement is executed.

10. Successors and Assigns. This Agreement shall be binding upon Turpin and the heirs and legal
representatives of Turpin, and shall be binding upon and ensure to the benefit of the Company and
its successors and assigns, including any corporation with which or into which the Company or its
successors may be merged or which may succeed, to its assets or business.

11. Employment by Affiliates. Turpin acknowledges and agrees that Turpin's employment with the
Company may be succeeded by employment with a Company Affiliate, in which case the terms of this
Agreement shall continue in effect with respect to such employment until an agreement relating to
this subject matter is signed between Turpin and the Company Affiliate.

12. Governing Law. This Agreement shall be governed by and construed in accordance with the laws of
the Province of British Columbia (without regard to its conflict of laws provisions) which shall be
deemed to be the proper law thereof. All disputes or claims arising out of or in relation to the
Agreement may be submitted to and resolved by the Courts of the Province of British Columbia
(including the Supreme Court of Canada). The parties hereby irrevocably submit and attorn to the
non-exclusive jurisdiction of such Courts to finally adjudicate or determine any suit, action, or
proceeding arising out of or in relation to this Agreement.

3

13. Terms Paramount. The terms of this Agreement are in addition to any other existing terms (the
"Existing Terms") between the Company and Turpin. In
<!-- page 3 -->
the event of any inconsistency or conflict between the terms of this Agreement and any Existing
Terms, the terms of this Agreement shall be paramount and shall supersede the Existing Terms to the
extent of the inconsistency or conflict.

14. Time. Time shall be of the essence for each and every term and condition hereof.

15. Severability. The provisions of this Agreement, whether or not contained in the same section,
are independent and separable. If any of the provisions of this Agreement shall be invalid or
unenforceable under the laws of the jurisdiction where enforcement is sought, such invalidity or
unenforceability shall not invalidate or render unenforceable the entire Agreement but rather the
entire Agreement shall be construed as if not containing the particular invalid or unenforceable
provision or provisions and the rights and obligations of the parties shall be construed and
enforced accordingly, with the invalid or unenforceable provision modified so as to be limited and
enforced to the fullest extent possible under the laws of that jurisdiction, with retroactive effect
to the date of this Agreement.

16. Interpretation. The language in all parts of this Agreement shall be in all cases construed
simply according to its fair meaning and not strictly for or against any of the parties hereto. Any
rule of construction that any ambiguities are to be resolved against the drafting party shall not be
employed in the interpretation of this Agreement. Each of the terms "including", "include" and
"includes", when used in this Agreement, is not limiting whether or not non-limiting language (such
as "without limitation" or "but not limited to" or words of similar import) is used with reference
thereto.

17. Headings and Gender. The headings and subheadings contained in this Agreement are used solely
for convenience and do not constitute a part of the Agreement, nor should they be used to aid in any
manner in the construction or interpretation of this Agreement. Unless the context requires
otherwise, words importing the singular include the plural and vice versa and words importing gender
include all genders.

18. Counterparts and Execution by Fax. This Agreement may be executed in any number of counterparts
with the same effect as if' all the parties have signed the same document. All counterparts shall be
construed together and shall constitute one agreement. This Agreement may be validly executed by
means of transmission of signed facsimile.

19. Acknowledgement. Turpin has carefully read and considered the terms of this Agreement and,
having done so, understands the terms and agrees that the terms herein are fair and reasonable and
are reasonably required for the protection of the interests of the Company.

IN WITNESS WHEREOF the parties have duly executed this Agreement on the date first above written.

VISUALANT INCORPORATED

PER /s/ RONALD P. ERICKSON -------------------------- RONALD P. ERICKSON

Authorized Signatory

/s/ KENNETH TURPIN ------------------ KENNETH TURPIN

4
