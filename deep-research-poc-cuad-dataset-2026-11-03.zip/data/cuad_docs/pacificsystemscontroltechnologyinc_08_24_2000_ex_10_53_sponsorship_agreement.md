<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 2000-04-14 |
| Parties | American Champion Media, ("ACM"); Shun Li De Commerce & Trading Ltd, ("SLD") |
| Source | CUAD v1 / PACIFICSYSTEMSCONTROLTECHNOLOGYINC_08_24_2000-EX-10.53-SPONSORSHIP AGREEMENT |

EXHIBIT 10.53

SPONSORSHIP AGREEMENT for Boxing Event in China, on April 22, 2000

American Champion Media, Inc. ("ACM"), a Delaware company with headquarters at 1694 The Alameda, San
Jose, CA 95126, U.S.A., is the host and producer of a boxing event to take place at the Tian He
Stadium in Guangzhou, China (the "Event"). This Event is scheduled to take place on April 22, 2000,
and this Sponsorship Agreement (the "Agreement") dated as of April 14, 2000 is made by and between
Shun Li De Commerce & Trading Ltd ("SLD") a Beijing company, with headquarters at Xin Xing Dong
Xiang, Bldg 1 Suite 1413, Xi Cheng District, Beijing, China (the "Sponsor") and ACM.

1) The Sponsor wishes to become a sponsor of the Event, a production of ACM, to take place on April
22, 2000 at the Tian He Stadium in Guangzhou, China.

2) As a sponsor of the Event, the Sponsor is entitled to the following sponsorship components:

* Two Floor Cards (12in x 66in) in prominent position for TV camera * Two Drapes over ropes (5in x
60in, with lettering within the middle 36") * Two Ring Side banners (200cm x 15cm) * One overhead
banner (5ft x 8 ft) to be hung over boxing ring * Other handout materials for audience

3) For the above sponsorship components, the Sponsor agrees to pay ACM a total amount of
US$400,000.00. The amount is payable 180 days from the date of the Event.

4) This is understood between the parties that SLD may resale all or some of the above sponsorship
components to other buyers, provided that SLD shall submit third party display materials at least
five days prior to the event for ACM's approval.

5) ACM retains all of its rights under copyright and trademark laws pertaining to the Event's
intellectual property, whether registered or unregistered, and any applications of the Event's logo,
name, characters and likeness. Video and audio excerpts of the Event must have ACM's approval in
writing prior to such use. The Sponsor shall retain all of its rights under copyright and trademark
laws pertaining to any of its intellectual property.

6) Display materials from the Sponsor must be delivered to the Tian He Stadium at least two days
prior to the event.

7) All covenants, promises and agreements by or on behalf of the parties contained in this Agreement
shall be binding upon and shall inure to the benefit of the successors and assigns of the parties;
but nothing in this Agreement, expressed or implied is intended to confer on any party the right to
assign its rights or obligations hereunder. Nothing in this Agreement, whether expressed or implied,
is intended to confer any rights or remedies under or by reason of this Agreement on any persons
other than the parties to it and their respective successors and assigns, nor is anything in this
Agreement intended to relieve or discharge the obligation or liability of any third persons to any
party to this Agreement, nor shall any provision give any third person any right of subrogation or
action over or against any party to this Agreement.

8) This Agreement shall be governed by, and construed and enforced in accordance with, the laws of
the State of California and the laws of Hong Kong. In the event of a dispute, the parties shall seek
mediation at a third country mutually agreed upon.

9) This Agreement sets forth the entire agreement of the parties hereto with regard to the subject
matter hereof and supersedes and replaces all prior agreements, understandings and representations,
oral or written, with regard to such matter.

10) This Agreement may be executed in two or more counterparts, each of which shall be deemed an
original, but all of which together shall constitute one and the same instrument.

IN WITNESS WHEREOF, the parties have caused this Agreement to be duly executed as of the date hereby
written.

/s/ Anthony K. Chan

Anthony K. Chan Chief Executive Officer American Champion Media, Inc.

/s/ He, Li
<!-- page 2 -->
He, Li Chief Financial Officer Shun Li De Commerce & Trading Ltd
