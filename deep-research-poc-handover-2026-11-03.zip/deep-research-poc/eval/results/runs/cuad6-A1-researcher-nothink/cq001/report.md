# Which jurisdiction's law governs the Cooperation Agreement between e.l.f. Beauty, Inc. ...

*Question:* Which jurisdiction's law governs the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01)?

## Identify the Cooperation Agreement

The Cooperation Agreement between e.l.f. [uncited] Beauty, Inc. and Marathon Partners Equity Management, LLC is dated July 1, 2020. [e42a4ef8cda58762 p.1] The agreement identifies e.l.f. [uncited] Beauty, Inc., a Delaware corporation, as the Company and Marathon Partners Equity Management, LLC as one of the Marathon Parties. [e42a4ef8cda58762 p.1] The effective date of July 1, 2020 matches the date specified in the question. [e42a4ef8cda58762 p.1]

## Locate governing law provision

The Cooperation Agreement between e.l.f. [uncited] Beauty, Inc. and Marathon Partners Equity Management, LLC dated 2020-07-01 is governed by the internal laws of the State of Delaware. [e42a4ef8cda58762 p.9] The governing law provision states that the agreement shall be governed by and construed in accordance with the internal laws of the State of Delaware applicable to agreements made and to be performed within that state. [e42a4ef8cda58762 p.9] The provision further specifies that this applies without giving effect to any law or principles of law that would result in the application of the laws of any other jurisdiction. [e42a4ef8cda58762 p.9]

## Verification appendix

Claims: 9 · supported: 6 · partially: 0 · dropped: 0 · gaps: 3 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  | no evidence cited |
| s1.2 | s1 | keep | 1.00 | e1→[e42a4ef8cda58762 p.1] |  |
| s1.3 | s1 | gap |  |  | no evidence cited |
| s1.4 | s1 | keep | 1.00 | e1→[e42a4ef8cda58762 p.1] |  |
| s1.5 | s1 | keep | 1.00 | e1→[e42a4ef8cda58762 p.1] |  |
| s2.1 | s2 | gap |  |  | no evidence cited |
| s2.2 | s2 | keep | 1.00 | e2→[e42a4ef8cda58762 p.9] |  |
| s2.3 | s2 | keep | 1.00 | e2→[e42a4ef8cda58762 p.9] |  |
| s2.4 | s2 | keep | 1.00 | e2→[e42a4ef8cda58762 p.9] |  |

### Evidence

- e1 [e42a4ef8cda58762 p.1 L12-19] keep (1.0): "COOPERATION AGREEMENT

This Cooperation Agreement ("Agreement") is entered into as of July 1, 2020, by and between e.l.f. Beauty, Inc., a Delaware corporation (the "Company"), and Marathon Partners Equity Management, LLC ("Marathon Partners…"
- e2 [e42a4ef8cda58762 p.9 L538-543] keep (1.0): "(g) Governing Law; Choice of Venue.

(i) This Agreement shall be governed by and construed in accordance with the internal laws of the State of Delaware applicable to agreements made and to be performed within that state, without giving eff…"
