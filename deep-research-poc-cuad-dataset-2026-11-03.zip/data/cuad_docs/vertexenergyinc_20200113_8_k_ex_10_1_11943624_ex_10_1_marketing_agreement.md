<!-- page 1 -->
# JOINT SUPPLY AND MARKETING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Marketing Agreement |
| Agreement Date | 2020-01-10 |
| Parties | Bunker One (USA) Inc. ("Bunker One"); Vertex Energy Operating LLC ("Vertex") |
| Source | CUAD v1 / VertexEnergyInc_20200113_8-K_EX-10.1_11943624_EX-10.1_Marketing Agreement |

Vertex Energy, Inc. 8-K Exhibit 10.1 THE SYMBOL "[****]" DENOTES PLACES WHERE CERTAIN IDENTIFIED
INFORMATION HAS BEEN EXCLUDED FROM THE EXHIBIT BECAUSE IT IS BOTH (i) NOT MATERIAL, AND (ii) WOULD
LIKELY CAUSE COMPETITIVE HARM TO THE COMPANY IF PUBLICLY DISCLOSED JOINT SUPPLY AND MARKETING
AGREEMENT This Joint Supply and Marketing Agreement (hereinafter referred to as the "JSMA") shall be
effective as of May 1, 2020 "the Commencement Date" and is made and entered into this 10t h day of
January, 2020 between Bunker One (USA) Inc., with principal offices located at 107 St. Francis
Street, Mobile, AL 36602 ("Bunker One"), and Vertex Energy Operating, LLC, with principal offices
located at 1331 Gemini Suite 250, Houston, TX 77058 ("Vertex"). BUNKER ONE and VERTEX are
hereinafter sometimes referred to as a Party or jointly as Parties. WHEREAS: A. Vertex currently
owns a production facility in Marrero, LA which has the capacity to produce 100,000 bbls/mo. +/- 10
% of a feedstock/product (the "Output") that can be consumed as bunker suitable fuel for offshore
use and use as a marine vessel's propulsion system. See Appendix A for qualities of the
feedstock/product (the "Product"). B. Bunker One being a physical supplier of bunker fuel having
blending expertise being able to utilize the Product together with associated physical assets for
storage and transportation, leased and owned real property, tangible and intangible personal
property, personnel, intellectual prop- erty and know-how (collectively the "Bunkering Business").
C. Pursuant to the terms of a Co-operation Agreement that went into effect on October 15, 2017 (the
"Original COOA"), which addressed the sourcing, storing, transportation, marketing and selling of
the Product in the states of Louisiana and Texas, Vertex agreed to sell, and Bunker One agreed to
purchase, the Output (as defined in the above) each month. By virtue of entering into this JSMA the
Parties intend to continue the activities previously conducted pursuant to the Original COOA and
expand thereon as more particularly hereinbelow set forth. D. The overall objective of the Original
COOA was to give the Parties the opportunity to further expand their business by co-operating in the
sourcing, storing, transportation, marketing and selling of the Product in and around Louisiana and
Texas, where (i) Vertex was primarily responsible for the sourcing and storing of the feedstock
Product, (ii) Bunker One was primarily responsible for the transporting, blending, marketing,
selling and delivering of the Product, (iii) Bunker One was responsible for the risk
management/exposure (e.g. hedging) of the bunker fuels, and (iv) Bunker One was the exclusive seller
of the Product to third parties. E. The Parties wish to amend and restate the Original COOA as a
JSMA to extend the term, provide for the inclusion of new and existing businesses and territories
not previously included in the Original COOA, and to address certain governance issues, all as more
particularly hereinbelow provided.

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 2 -->
THE PARTIES hereto hereby agree as follows: 1. Definitions. "Area" means Texas, Louisiana, Alabama
and areas immediately adjacent thereto if mutually agreed. "Bunker Holding", a Danish holding
company and sole shareholder of Bunker One (USA) Inc.. "Business Day" means any day except a
Saturday, Sunday, or a Federal Reserve Bank holiday. A Business Day shall open at 8:00a.m. and close
at 5:00p.m. Houston, Texas, time. "JSMA Output" has the meaning ascribed thereto in Section 2.1.
"Effective Date" means the date as of which the last signature of a Party is affixed hereto. "Fiscal
Year" shall mean the period beginning with May 1st in each calendar year and ending on the next
succeeding April 30t h. "Hedge Position Value" means the then current settlement value of any and
all open hedge transactions entered into by Bunker One as determined by Bunker One on a
mark-to-market basis in a commercially reasonable manner. "Hedging Profit" means the greater of zero
and the net gain on all hedging transactions closed and settled during the applicable Tracking
Account reporting or settlement period, including any interest received by Bunker One with respect
to any margin deposits made by Bunker One with any hedge transaction counterparties exclusive of any
such amount in excess of that which would be taken into account by parties dealing at arm's length
on a commercial basis. "Hedging Loss" means the lesser of zero and the net loss on all hedging
transactions closed and settled during the applicable Tracking Account reporting or settlement
period, including any in- terest received by Bunker One with respect to any margin deposits made by
Bunker One with any hedge transaction counterparties exclusive of any such amount in excess of that
which would be taken into account by parties dealing at arm's length on a commercial basis.
"Interest Rate" means (a) with respect to a non-defaulting Party, a per annum rate of interest equal
to USD 1M LIBOR as per the last fixing of the preceding month + 3.5 per cent pro anno (compounded
monthly for each month or part thereof) and (b) with respect to a Defaulting Party, a per annum rate
of interest equal to 5 % over the rate mentioned above in (a), provided, how- ever, that the rate
set forth in (a) shall be adjusted by the Parties annually at the last meeting of the JDMB (as such
term is defined in the Heads of Agreement entered into between the Parties as of January 10, 2020.
"Inventory" shall mean the Product purchased by Bunker One pursuant to this Agreement. "Inventory
Cost" shall mean the amount paid by Bunker One to Vertex for the Inventory.

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 3 -->
"Inventory Market Value" shall mean the then current market value of Inventory as determined by
Bunker One on a mark-to-market basis in a commercially reasonable manner. "Inventory Resale
Transaction(s)" shall mean any sale by Bunker One to a third party of the Inventory whether or not
the Inventory is sold in the original condition delivered to Bunker One or is blended by Bunker One
into a different product. "Nomination" shall be as defined in Section 2.6. "Output" has the meaning
ascribed thereto in the recitals. "Product" has the meaning ascribed thereto in the recitals.
"Remaining Exposure" means Total Exposure plus payments received by Bunker One and Vertex pursuant
to this Agreement during the applicable Tracking Account Statement reporting period less payments
made by Bunker One and Vertex pursuant to this Agreement during the applicable Tracking Account
Statement reporting period. "Term Sheet" means that certain summary of terms regarding the proposed
purchase of Series B1 Preferred Shares of Vertex Energy, Inc. dated November 25, 2019. "Total
Exposure" means the sum of (i) Unrealized Gain on Hedging, (ii) Unrealized Loss on Hedg- ing, (iii)
Unrealized Gain on Inventory, (iv) Unrealized Loss on Inventory and (v) Total Realized P/L. "Total
Realized P/L" means and shall be equal to the sum of each monthly calculation of below following
IFRS principles: (a) the sum of: (i) gross revenue received by Bunker One from any third party for
Inventory Resale Transactions (but excluding for any applicable Tracking Account reporting or
settlement period any such gross revenue that was included in a prior reporting or settlement period
as described in clause (ii) immediately below), (ii) gross revenue due, but not yet received by
Bunker One from any third party for Inventory which has been sold at a fixed price, whether or not
delivered, (iii) Hedging Profit; and (iv) proceeds of insurance maintained by Bunker One with
respect to the Inventory that are received by Bunker One; less (b) the sum of: (i) the measured cost
of the goods sold, (ii) all actual costs incurred by Bunker One (U.S.) hereunder including, but not
limited to costs for tank storage, tank expenses, tank cleaning, freight (includes
fleeting/heating/tanker man/sparging), cargo insurance, inspection, demurrage, broker commissions,
blending costs (including blending inventories/products, additives and other direct costs incurred
in blending the Product for resale), financial charges, interest, Transfer Taxes and miscellaneous
items,

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 4 -->
(iii) Hedging Loss, and (iv) SG&A costs allocated to the operation (to be agreed to in a budget and
in writing ahead of time, provided, however, neither Party will include SG&A incurred by a parent
entity absent mutual agreement otherwise). "Transfer Taxes" means all transfer, documentary, sales,
use, stamp, registration, conveyance or similar taxes or charges ("Transfer Taxes") arising out of
the transactions contemplated hereby and all charges for or in connection with the recording of any
document or instrument contem- plated hereby. "Unrealized Gain on Hedging" means the greater of zero
and the Hedge Position Value. "Unrealized Loss on Hedging" means the lesser of zero and the Hedge
Position Value. "Unrealized Gain on Inventory" means the greater of zero and the net gain in
Inventory Market Value as compared to the Inventory Cost. "Unrealized Loss on Inventory" means the
lesser of zero and the net loss in Inventory Market Value as compared to the Inventory Cost. 2.
Co-operation procedure. 2.1. Sourcing and Purchase. Vertex shall be responsible for the
sourcing/producing of the Product and shall sell to Bunker One, and Bunker One shall purchase, the
agreed Output of the Product in accordance to FOB (Marrero, LA, US (or per new/additional agreed
Area)) the Incoterms® 2010 rules, at the following scheduled pricing: the arithmetic mean of Platts
#2 USGC Pipe and Platt's ULSD USGC Waterborne on agreed pricing days less the agreed upon discount
[****]. Pricing mechanism for the Product will be made in accordance to FOB (Marrero, LA, US) the
Incoterms® 2010 rules (hereinafter, the "Product Cost"). The above pricing will be mutually
negotiated and revised every third month. Unless the Parties otherwise agree in writing, 100% of the
Output shall be allocated for use in the Area (the "COOA Output") . Vertex, on not less than 120
days prior written notice to Bunker One (the "Withdrawal Notice"), shall have the right to remove
all or a portion of the Output from the coverage of the JSMA, provided, however, that, in such
event, (a) Vertex shall supply a volume of alternative material equal to, or better than, in amount
and quality (the "Alternative Supply") to the volume of material withdrawn, or (b) Vertex shall
reimburse Bunker One for the net loss experienced by Bunker One by reason of the loss of the
withdrawn material, determined on the basis of what Bunker One would have earned on a net basis
under the terms of the JSMA had the Output not been withdrawn.

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 5 -->
In addition, in calculating the net loss experienced by Bunker One in the event of withdrawal
subject to compensation under (b) mentioned in the above, Vertex shall be credited with any
additional income realized by Bunker One, determined on a cumulative basis from and after the date
of this JSMA, for any Product provided by Vertex in excess of the Output as well as any cost savings
realized by Bunker One with respect to the Alternative Supply. 2.2. Blending. The JSMA Output is
meant for blending into other products by Bunker One for the pur- pose of being transformed into
bunker suitable fuel for a marine vessel's propulsion system and/or marketable wholesale products in
various other markets for sale by Bunker One to cus- tomers in the Area. Bunker One will be solely
responsible for the blending, marketing, sale and delivery of the Product in the Area. The JSMA
Output may also be sold as is without any blending. 2.3. Storage. The Parties will, with prior
written agreement, coordinate efforts to secure storage ca- pacity for the accumulation and blending
of Product to make up the cargo to be supplied pursuant to the JSMA. The Parties agree that
tank/storage fees incurred for the sole (any other use will be upon mutual written agreement)
purposes of the JSMA shall be for the account of the JSMA. At commencement of this Agreement the
Parties have entered into the sublet agreement attached hereto as Appendix B. 2.4. Vessel Charter:
Bunker One will coordinate, secure and charter suitable vessels needed for the shipment of the
Product to various sale destinations. The Parties agree that fees incurred in con- nection with
chartering vessels for the sole (any other use will be upon mutual written agreement) purposes of
the JSMA shall be for the account of the JSMA. 2.5. Risk management: Bunker One shall be responsible
for obtaining risk management related prod- ucts / hedging of the JSMA Output consistent with the
decisions of the JDMB under the Heads of Agreement. All fees incurred, and profit/loss incurred in
connection with hedging of the JSMA Output shall be for the account of the JSMA. All hedging is to
be done on a physical, not specula- tive, basis. 2.6. Exclusive co-operation: It is agreed that only
Bunker One will be marketing this JSMA and the JSMA Output towards various customers, but if a Party
receives a Nomination (being a written or oral request by/from a customer to a Party stating
delivery place, delivery date and window etc.) or any other communication from a customer regarding
the supply of Product (either spot or whole cargo) in the Area, the Party is obliged to forward the
Nomination to Bunker One and refer the customer to Bunker One. During the Term, neither Vertex nor
any affiliate of Vertex may sell any Product to any customers for their use as bunker fuel other
than pursuant to the terms of this JSMA. All sales towards customers for bunker fuel will be carried
out exclusively by Bunker One in accordance to the terms set forth herein. As such all communication
with customers shall go via Bunker One unless otherwise is specific written agreed in advance. 3.
Mutual Cooperation. 3.1. The JSMA will generate either a profit or a loss which shall be distributed
between the Parties as set out forth further below in this clause. VERTEX and Bunker One will act
cooperatively in a commercially reasonable manner, to maximize profits and minimize losses and
comply with all terms and conditions pursuant to the JSMA. The Parties have established a Joint
Decision-Making Body that will: (a) establish a budget no later than March in each Fiscal Year for
the immediately ensuing

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 6 -->
Fiscal Year, to include forecasts of income and expense and planned capital expenditures (which
capital expenditure budgets shall include a focus on items related to the supply and optimization of
the marine fuels or components and items related to support the marketing of the Product and
associated credit risks with respect to Bunker One, and with respect to Vertex, a focus on asset
acquisition/leasing of improvements required in support of acquisition and production of the Product
to the refining rack or other designated transfer point), (b) review the financial information
provided by the respective Parties for the transactions occurring during the preceding
month/quarter/year; (c) Strategize on the proposed blending plan, ensuing month for volume and
margin per MT. plan for resupply of components and associated pricing targets, related expenses,
timing and volumes; (d) discuss and approve any other business brought before the Committee for its
review and approval. 3.2. Accounting Records; Reporting: Bunker One shall establish and maintain at
its office in Mobile, Alabama a detailed ledger (the "detailed ledger") within their current
reporting system with re- spect to this Agreement and all transactions hereunder sufficient to track
and reconcile all such transactions and to calculate and track Hedge Position Value, Hedging Profit,
Hedging Loss, Inventory Cost, Inventory Market Value, Remaining Exposure, Total Exposure, Total
Realized P/L, Inter- est, Unrealized Gain on Hedging, Unrealized Loss on Hedging, Unrealized Gain on
Inventory and Unrealized Loss on Inventory and any and all payments made by or to Bunker One or
Vertex with respect to this Agreement. 3.3. Bunker One shall prepare and provide to Vertex, on a
monthly and quarterly basis, a statement setting forth the status of the detailed ledger and each
component thereof (the "detailed ledger Statement"). The detailed ledger Statement and all other
reports and settlement statements provided for herein shall be in such format as may be agreed upon
by the Parties from time to time and shall include such supporting documentation as is reasonably
necessary or reasonably requested by Vertex to enable Vertex to verify the accuracy of such report
or settlement statement. Bunker One shall prepare and maintain such other accounting and transaction
records as may be necessary to provide a full accounting of all transactions and other activities
under this Agree- ment. Vertex has the right, at its sole expense and during normal working hours,
to have a third party accountant examine the records of Bunker One. If any such examination reveals
any inaccuracy in any statement, the necessary adjustments in such statement and the payments
thereof will be made promptly and shall bear interest calculated at the Interest Rate from the date
the overpayment or underpayment was made until paid. 4. Settlement and Payment term. 4.1. Payment by
Bunker One for the Product, as defined in clause 2.1, will be made by wire transfer within three (3)
Business Days after the date Vertex invoices Bunker One, to an account desig- nated from time to
time by Vertex. 4.2. On or before the seventh (7t h) Business Day after the end of each quarter
during the Fiscal Year May 1- April 30) Bunker One shall prepare and send to Vertex the detailed
ledger statement for the immediately preceding quarter. If any such quarterly detailed ledger
statement, or the final detailed ledger statement issued by Bunker One, shows positive Remaining
Exposure for the pe- riod covered by the statement, then Bunker One shall pay [****] percent
([****]%) of such amount to Vertex. If any such quarterly detailed ledger statement shows negative
Remaining Exposure for the period covered by the statement, then Vertex shall pay [****] percent
([****]%)

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 7 -->
of such amount to Bunker One. The first ledger statement for the first full fiscal quarter ending
after the Effective Date shall include an adjustment taking into account the period beginning with
the first day following the last day included in the last ledger statement provided under the terms
of the Original COOA, and the first day of the period included in the first ledger statement
provided in accordance with the provisions of this JSMA. For example, if the last ledger statement
provided under the Original COOA includes the three-month period ending on September 30, 2019, and
the first ledger statement provided under the terms of this JSMA includes the three- month period
ending January 31, 2020, then such first ledger statement shall also include the month of October,
2019 in addition to the months of November, December and January. 4.3. In addition to the foregoing,
on or before the fifteenth (15t h) Business Day after the end of each Fiscal Year Bunker One shall
prepare and send to Vertex the detailed ledger statement for the immediately preceding Fiscal Year
calculated on a cumulative basis showing payments made and received by the Parties in satisfaction
of the percentage splits shown above, adjusted to include any period excluded by reason of the
conversion from a calendar year to a fiscal year in the same manner in which quarterly calculations
are adjusted in Section 4.2 (i.e. the months of January, February, March and April, 2019 would be
excluded in the annual calculations for the Fiscal Year ending April 30, 2020, and these must be
included for purposes of preparing the ledger statement for FYE 4/30/20). In the event a Party has
received payments in excess of those to which such Party is entitled on a cumulative basis as
reflected in the annual detailed ledger Statement, such Party shall remit such excess to the other
Party promptly upon receipt of demand therefor, or if such Party has underfunded its obligation in
these same regards, such Party shall promptly remit the amount underfunded to the other Party. Any
amount to which a Party is entitled by virtue of any monthly or quarterly detailed ledger Statement
in excess of that reflected in the annual de- tailed ledger Statement that has not been received
shall be canceled. 4.4. In addition, within thirty (30) days after the later of the expiration of
the Term or the final settlement and termination of all resale and hedge transactions entered into
during the term of this Agreement, Bunker One shall issue a final detailed ledger Statement. If the
Remaining Exposure shown on such final detailed ledger Statement is less than zero then Vertex shall
pay [****] percent ([****]%) of such amount to Bunker One. If the Remaining Exposure shown on such
final detailed ledger Statement is greater than zero then Bunker One shall pay [****] percent
([****]%) of such amount to Vertex. 4.5. Payment for any amounts due in accordance with the above
shall be made within three (3) Business Days after the date of the applicable detailed ledger
Statement. If any detailed ledger State- ment is disputed in good faith, the Party owing money will
pay the undisputed portion by the due date and will by such due date provide a written explanation
of the basis for the disputed portion to such due date. The Parties shall endeavor to resolve any
disputes promptly, and the disputed amount found due, if any, plus accrued interest at the Interest
Rate shall be paid within three (3) Business Days following resolution of the dispute. All payments
under the terms of this Agreement shall be made in US Dollars and immediately available funds. The
Parties shall net all undisputed amounts due and owing on the same day, and/or past due, arising
under this Agreement such that the Party owing the greater amount shall make a single payment of the
net amount to the other Party. Interest on late payments shall accrue at the Interest Rate from the
due date until the date of payment.

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 8 -->
5. Term 5.1. The term of this JSMA shall commence on May 1, 2020 (the "Commencement Date") and ends
at April 30, 2029 (the "Term"), with automatic renewals each for a period of five (5) years (a
"Renewal Term") unless notice is given pursuant to 5.2. 5.2. This JSMA will be terminated as of the
end of the Term or any Renewal Term, by either Party giving written notice of non-renewal to the
other Party no less than 120 prior to the applicable expiry date (the "Termination Period"). 5.3. If
at any time an Event of Default (as defined below) has occurred and is continuing, the Defaulting
Party shall have ten (10) days after receipt of written notice from the Non-Defaulting Party speci-
fying the default, within which to cure any such default, unless such default is not susceptible of
cure within such ten (10) day period in which case the Defaulting Party shall have such additional
time as may be accepted by the Non-Defaulting Party (in its sole discretion), provided that the
Defaulting Party initiates cure proceedings promptly and thereafter diligently pursues cure to
completion. Notwithstanding the foregoing, in no event shall the cure period exceed thirty (30)
days. Upon the expiration or lapse of all notice and cure rights if the default remains uncured the
Non-Defaulting Party may terminate this JSMA with immediate effect. 5.4. In the event of a
termination in accordance to clause 5.2 it is agreed that both parties agree to unwind and minimize
costs and exit the JSMA as soon as practicably possible not exceeding 120 days. 5.5. In the event of
a termination in accordance to clause 5.3 the Defaulting Party has to indemnify and hold harmless
the Non-Defaulting Party for any and all losses, damages, costs etc. incurred by the Non-defaulting
Party as a consequence of an Event of Default. 5.6. A Party may terminate the JSMA immediately upon
the delivery of written notice to the other Party if there has been a Change in Control. The term
"Change in Control", as used in this Agreement, means (A) the sale or transfer, through one
transaction or a series of transactions, of all or some portion of the issued and outstanding shares
of voting equity interests of a Party, or such Party's parent, such that the majority of such equity
interests are owned by individual(s) or entity(ies) that did not own a majority of such equity
interests on the Commencement Date; (B) the reorganization, merger or consolidation of a Party, or
such Party's parent, unless immediately following such business combination, all or substantially
all of the individuals and entities who were the beneficial owners of either entity immediately
prior to such business combination beneficially own, directly or indirectly, a majority of the
issued and outstanding shares of voting equity interests of such entity; (C) the sale or transfer,
through one transaction or a series of transactions, of all or substantially all of the assets of a
Party, or such Party's parent; or (D) the occurrence of any other event(s) whereby the individual or
group of individuals who ultimately own or control a Party or such Party's parent as of the
Commencement Date no longer has the right or ability to control or cause the direction of the
management and policies of such entity. For these purposes Bunker Holding Group is the parent of
Bunker One, Inc., and Vertex Energy, Inc. is the parent of Vertex Energy Operating LLC.

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 9 -->
6. Event of Default 6.1. The occurrence at any time of any of the following events, and expiration
of any applicable notice or cure rights, shall constitute an event of default (an "Event of
Default") : 6.1.1. A Party fails to make, when due, any payment under this JSMA and such failure is
not remedied within three (3) Business Days after written notice of such failure is given to the
Party; 6.1.2. A Party fails to comply with or perform any other obligation under this JSMA, if such
failure is not cured within the expiration of all applicable notice and cure rights; 6.1.3.
Insolvency etc. A Party is (i) dissolved; (ii) becomes insolvent or is unable to pay its debts as
they fall due or admits to be so in writing; (iii) makes a general arrangement with or for the
benefits of its creditors; (iv) suspends making payments; (v) institutes or has instituted against
it a proceeding seeking a judgement of insolvency or bankruptcy or any other relief under any
bankruptcy or insolvency law other similar law affecting creditor's rights, or a petition is
presented for its winding-up or liquidation and such petition is not withdrawn, dismissed,
discharged, stayed or restrained within thirty (30) days; (vi) seeks or becomes subject to the
appointment of an administrator, provisional liquidator, conservator, receiver, trustee, custodian
or other similar official for it for all or substantially all its assets; (vii) has a secured party
take possession of all or substantially all its assets; (viii) causes or is subject to any event
with respect to it which, under the applicable laws of any jurisdiction, has an analogous effect to
any of the events specified in (i)-(viii); or (ix) takes any action in furtherance of, or indicating
its consent of, approval of, or acquiescence in, any of the acts referred to in this clause. 7.
Taxes 7.1. Each Party is responsible for payment and reporting of its federal, state, and local
income taxes and state franchise, license, and similar taxes required for the maintenance of its
business existence. 7.2. Should any unexpected taxes, fees, and/or other charges, including
penalties and/ or interest, occur because of one Party's failure to pay and/or report, said Party
shall bear all costs associated with such failure and shall indemnify the other Party from
additional costs. 8. Confidentiality 8.1. The JSMA is private and confidential. Both Parties agree
that all information, other than Exempt Information, obtained in connection with the JSMA from the
other Party shall be treated as confidential property of the other Party, and such confidential
property shall not be disclosed without the written consent of the other Party or used by the other
Party for any purpose other than fulfilling its duties and responsibilities established hereunder;
provided however, that either Party may disclose such information where required or requested by any
law, court of competent jurisdiction or any judicial, governmental, supervisory or regulatory body,
provided that the disclosing Party notifies the other Party (to the extent permitted by law and
regulation), as soon as possible, upon becoming aware of any such requirement to give that Party the
opportunity to seek any other legal remedies to maintain such information in confidence. Each Party
shall use its reasonable efforts to have the information maintained as confidential when such
disclosure is required. "Exempt Information" is any information that the recipient can demonstrate
(a) was in

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 10 -->
its possession prior to the time of disclosure; (b) is or becomes public knowledge through no fault,
omission, or other act of the recipient; (c) is obtained from a third party under no obligation of
confidentiality; or (d) was independently developed by or for the recipient without violating the
terms of this Agreement. 8.2. In the event that any Party makes a disclosure contrary to the
provisions of this clause the other Party shall have the right, without prejudice to any other
rights or remedies it may have hereunder or otherwise, to terminate the JSMA effective immediately
upon notice to the disclosing Party. The obligation of confidentiality shall be of a continuing
nature for 2 years after termination of this JSMA and shall not be canceled by the expiration,
suspension or termination of the JSMA. Notwithstanding the foregoing, each Party on demand shall
promptly disclose to the other all documents and accounts relating to the JSMA. 9. Non-competition
9.1. Both Parties undertake, during the Term of this JSMA and for 2 (two) years from the termination
or expiry of the JSMA not to directly conduct or otherwise promote activities which compete at the
point source of the other Party's business in the Area. The point source of Vertex being a specialty
refiner of alternative feedstocks engaged in supply and marketing of said refined streams and the
point source of Bunker One being a marine fuel blending bunker company with sale outlets via trade,
direct, wholesale and bunkering business. Any exceptions from the above-stated principle require the
written consent of the other Party. Each Party is entitled to exercise any and all rights and
remedies available at law or in equity, including, without limitation, pursuing injunc- tive relief.
10. No authority to bind. 10.1. Neither Party has the authority to bind or enter into any contracts
or agreements on behalf of the other Party, unless instructed in writing prior to the conclusion of
the respective transaction. The Parties specifically acknowledge that they are not establishing a
joint venture or partnership or any similar arrangement. 11. Assignment. 11.1. Neither Party shall
assign or transfer any rights or obligations hereunder without the express prior written consent of
the other Party, which may not be unreasonably withheld. Nothing in the JSMA is intended or shall be
construed to confer upon or give to any person or entity any rights as a third party beneficiary of
the JSMA or any Party thereof. 12. Indemnification. 12.1. Vertex shall promptly indemnify Bunker One
and pay any and all damages, losses, liabilities, costs and expenses, including reasonable
attorneys' fees, incident to any suits, actions, investigations, claims or proceedings suffered,
sustained, incurred or required to be paid by Bunker One by reason of any negligence, gross
negligence and/or intentional act or omission on the part of Vertex in rendering services hereunder,
or any breach or failure of observance or performance of any representation, warranty, covenant or
agreement made by Vertex hereunder.

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 11 -->
12.2. Bunker One shall promptly indemnify Vertex and pay any and all damages, losses, liabilities,
costs and expenses, including reasonable attorneys' fees, incident to any suits, actions,
investigations, claims or proceedings suffered, sustained, incurred or required to be paid by Vertex
by reason of any negligence, gross negligence and/or intentional act or omission on the part of
Bunker One in rendering services hereunder, or any breach or failure of observance or performance of
any rep- resentation, warranty, covenant or agreement made by Bunker One hereunder. 12.3. This
clause shall survive termination of this JSMA. 13. Law and jurisdiction. 13.1. This Agreement shall
be governed, interpreted and construed in accordance with the laws of the State of Alabama, without
giving effect to its conflict of laws provisions. Any dispute arising out of or in connection with
this JSMA, including without limitation any question regarding its existence, validity or
termination, that is not resolved in accordance with the provisions set forth below in Section 13.3,
shall be submitted to the exclusive jurisdiction of the United States District Court for the
Southern District of Alabama in the City of Mobile, unless that court does not have subject-matter
jurisdiction or declines jurisdiction, in which case any such dispute shall be submitted to the
exclusive jurisdiction of the State Court for the State of Alabama, City of Mobile, as described in
the following paragraphs. Any counterclaim arising out of, or in connection with, the dispute shall
be brought in the same proceeding. 13.2. Each Party submits to the jurisdiction of the United States
District Court for the Southern District of Alabama. Each Party waives, to the fullest extent
permitted by applicable law, any objection to venue in the United States District Court for the
Southern District of Alabama or to or any claim of inconvenient forum of such court or of sovereign
immunity. Each Party waives, to the fullest extent permitted by applicable law, any right it may
have to a trial by jury in respect of any proceeding relating to this JSMA. 13.3. Arbitration.
13.3.1 Resolution of Disputes. If a Dispute arises between the parties, the parties agree to use the
following procedures in good faith to resolve such Dispute promptly and non judicially. For purposes
of this Agreement, "Dispute" shall mean any alleged material breach of any representation, warranty
or obligation herein, or a disagreement regarding the interpretation, performance or nonperformance
of any provision thereof, or the validity, scope and enforceability of these dispute resolution
procedures, or any dispute regarding any damages arising from the termination of this Agreement. Any
party may give written notice to any other party of the existence of a Dispute (a "Dispute Notice").
13.3.2 Negotiation. Within five (5) days after delivery of any Dispute Notice the parties involved
in the Dispute shall meet at a mutually agreeable time and place and thereafter as often as they
deem reasonably necessary to exchange relevant information and attempt in good faith to negotiate a
resolution of the Dispute. If the Dispute has not been resolved within ten (10) days after the first
meeting of the parties, or, if the party receiving the Dispute Notice will not meet within ten (10)
days after receipt of the Dispute Notice, then either party may, by delivering notice to the other
party, commence arbitration proceedings.

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 12 -->
13.3.3 General Dispute Resolution Provisions. (a) All deadlines specified in this Section 13.3 may
be extended by mutual agreement. The procedures specified in this Section 13.3 are an essential
provision of this Agreement and are legally binding on the parties. These procedures shall be the
sole and exclusive procedures for the resolution of any Dispute between the parties arising out of
or relating to this Agreement. Any and all actions to enforce the obligations under this Section
13.3 shall be brought in any court specified in Section 13.1. (b) The parties acknowledge that the
provisions of this Section 13.3 are intended to provide a private resolution of Disputes between
them. Accordingly, all documents, records, and other information relating to the Dispute shall at
all times be maintained in the strictest confi- dence and not disclosed to any third party, other
than the arbitrators, except where specifically allowed hereunder. All proceedings, communications
and negotiations pursuant to this Section 13.3 are confidential. In the event of any judicial
challenge to, or enforcement of, any order or award hereunder, any party may designate such portions
of the record of such proceedings, communications, and negotiations as such party deems appropriate
to be filed under seal. All pro- ceedings, communications and negotiations pursuant to this Section
13.3 shall be treated as com- promise negotiations for all purposes, including for purposes of the
US Federal Rules of Evidence and state rules of evidence. None of the statements, disclosures,
offers, or communications (or other assertions made in any proceeding or negotiation) made pursuant
to this Section 13.3 shall be deemed admissions, nor shall any of said statements, disclosures,
offers, communications or assertions be admissible for any purpose other than the enforcement of the
terms of this Section 13.3. (c) The parties agree to act in good faith to comply with all of their
respective obligations under this Agreement as much as possible as if there were no Dispute during
any pending mediation or arbitration hereunder. (d) The parties agree that the terms of this Section
13.3 shall survive the termination or expiration of this Agreement. (e) WAIVER OF JURY TRIAL. The
parties agree to have any Dispute that is not resolved pursuant to the procedures established in
Section 13.3(a) - (c) decided by neutral arbitration as provided in this Section 13.3(e) and the
parties are giving up any rights they might possess to have the Dispute litigated in a court or by a
jury trial. The parties are giving up their judicial rights to discovery and appeal, unless such
rights are specifically included in this Section 13.3(e). The parties acknowledge and agree that
their agreement to this arbitration provision is voluntary. FOR THE AVOIDANCE OF DOUBT AND IN
FURTHERANCE OF THE FOREGOING, EACH PARTY HERETO HEREBY WAIVES AND COVENANTS THAT IT WILL NOT ASSERT
(WHETHER AS PLAINTIFF, DEFENDANT OR OTHERWISE) ANY RIGHT TO TRIAL BY JURY IN ANY FORUM IN RESPECT OF
ANY ISSUE OR ACTION, CLAIM, CAUSE OF ACTION OR SUIT (IN CONTRACT, TORT OR OTHERWISE), INQUIRY,
PROCEEDING OR INVESTIGATION ARISING OUT OF OR BASED UPON THIS AGREEMENT OR THE SUBJECT MATTER
HEREOF, IN EACH CASE WHETHER NOW EXISTING OR HEREAFTER ARISING. 13.4 Each Party agrees to the
service of any court process by registered or certified U.S. mail (return receipt requested) or by
express mail courier delivered to the Party at its last designated address. In

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 13 -->
addition, each party agrees that any other method of service allowed by Alabama law may be used. All
process and any accompanying complaint or other pleadings shall be in the English language and do
not require officialization. 13.5 The United Nations Convention on Contracts for the International
Sale of Goods of Vienna 1980 shall not apply to this JSMA. 14. Merger. 14.1. The JSMA is a complete
and exclusive statement of all terms and conditions governing the activities contemplated by the
JSMA, and supersedes all prior agreements between the parties, written or oral, relating hereto.
Unless identified in the JSMA (i.e. sales agreement, terminaling agreements, charter party
agreements, etc.) or subsequently documented in writing, no other contract or course of dealing
between the Parties, and no statement of any agent, employee or representa- tive of either Party
shall be admissible in construing the terms of the JSMA. Each Party affirms that no representations
have been made by the other Party, or relied on by it, in entering into this JSMA. 15. Severability
of Provisions. 15.1. The invalidity, illegality or unenforceability of any one or more of the
provisions of the JSMA, other than the FCPA provision, shall in no way affect or impair the validity
and enforceability of the remaining provisions hereof. 16. Notices. 16.1. All notices and other
communications given under the JSMA shall be in writing (including, without limitation, by fax and
email) and shall be effective upon receipt by the addressee. 17. Waiver. 17.1. No failure or any
delay on the part of a Party exercising any rights hereunder shall operate as a waiver of any such
rights. No waiver of any default or breach of any provision of this JSMA shall be deemed a
continuing waiver or waiver of any other breach or default. 18. Anti-Bribery/Corruption. 18.1. Each
Party, and any agent or representative of any Party acting at such Party's direction, on such
Party's behalf, or for such Party's benefit, in any way related to this Agreement (collectively,
"Concerned Persons"), will be familiar with and comply with (i) the provisions of the United States
Foreign Corrupt Practices Act (15 U.S.C.A. §§ 78dcl-1 et seq. (1997 & Supp. 2004)), including any
amendments which may be effected during the term hereof (ii) the Laws of the country of incor-
poration of such Party or such Party's ultimate parent company or the principal place of business of
such ultimate parent company; or (m) the principles described in the Convention on Combating Bribery
of Foreign Public Officials in International Business Transactions signed in Paris in December 19,
1997, which entered into force on February 15, 1999 and the Conventions Commentaries

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 14 -->
or the UK Bribery Act 2010. In particular, in carrying out any duties under this Agreement, no
Concerned Person will make or offer to make the payment of money or anything else of value to: a.
any government official of any country, b. any political party of any country, c. any candidate of
any political party of any country, d. any other person, while knowing or having reason to know,
that such person will make a payment to a government official, political party, or a candidate of a
political party of any country. 18.2. Any breach of this Paragraph by a Concerned Person will result
in the termination of this Agreement and will obligate the return of any amounts paid hereunder to
such Concerned Person. 19. Board of Directors meetings. During the Term of this JSMA, provided that
Bunker One, directly or indirectly, consummates the capital investment described in the Term Sheet,
Vertex shall permit a representative of Bunker One, reasonably acceptable to a majority of Vertex's
Board of Directors (it being understood that Carlos G. Torres, Sara Shipman Myers and Peter
Zachariassen meet such criteria), to attend all meetings of the Board of Directors of Vertex and its
committees (committees defied as Audit and Nominating Committee and any special committee formed to
consider extraordinary transac- tions) in a non-voting observer capacity and, in this respect, shall
give such representative of Bunker One copies of all notices, minutes, consents and other material
that Vertex provides to its directors and committee members, provided, that Vertex reserves the
right to withhold any in- formation and to exclude such representative from any meeting or portion
thereof if Vertex de- termines, upon advice of counsel, such withholding or exclusion is necessary
to preserve the at- torney-client privilege between Vertex and its counsel or would result in
disclosure of trade se- crets. Bunker One agrees, and any representative of Bunker One will agree,
to hold in confidence any confidential information provided to or learned by it in connection with
its rights under this section. The confidentiality provisions hereof will survive termination of the
Term.

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
<!-- page 15 -->
APPENDIX A: (SEE INTERTEK REPORT OF ANALYSIS to include IFO-180, IFO-380 and DMA) APPENDIX B:
Storage Agreement. IN WITNESS WHEREOF, THE PARTIES HERETO HAVE HEREBY EXECUTED THIS AGREEMENT AS OF
THE DATE FIRST WRITTEN ABOVE. Bunker One, Inc. /s/ Sara Shipman Myers Name: Sara Shipman Myers
Vertex Energy Operating, LLC

Name: Ben Cowart

Source: VERTEX ENERGY INC., 8-K, 1/13/2020
