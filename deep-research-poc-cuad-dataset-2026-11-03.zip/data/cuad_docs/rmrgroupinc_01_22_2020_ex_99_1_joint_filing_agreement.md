<!-- page 1 -->
# JOINT FILING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| Agreement Date | 2020-01-22 |
| Parties | ABP TRUST; ADAM D. PORTNOY |
| Source | CUAD v1 / RMRGROUPINC_01_22_2020-EX-99.1-JOINT FILING AGREEMENT |

Exhibit 99.1 JOINT FILING AGREEMENT The undersigned hereby agree that the Schedule 13G/A with
respect to the shares of Class A Common Stock, $0.001 par value per share, of The RMR Group Inc.,
dated as of December 31, 2019, is, and any amendments thereto (including amendments on Schedule 13D)
signed by each of the undersigned shall be, filed on behalf of each of us pursuant to and in
accordance with the provisions of Rule 13d-1(k) under the Securities Exchange Act of 1934, as
amended. January 22, 2020 (Date) ABP TRUST /s/ Adam D. Portnoy (Signature) Adam D. Portnoy,
President (Name/Title) ADAM D. PORTNOY /s/ Adam D. Portnoy (Signature) 10
