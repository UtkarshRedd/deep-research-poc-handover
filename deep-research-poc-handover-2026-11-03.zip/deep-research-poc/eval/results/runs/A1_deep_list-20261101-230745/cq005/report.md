# Which jurisdiction's law governs the Intellectual Property Agreement between NMS Commun...

*Question:* Which jurisdiction's law governs the Intellectual Property Agreement between NMS Communications Corp. and Verson Backhaul Solutions, Inc. (dated 2007-12-20)?

## Identify the governing law clause

The Intellectual Property Agreement between NMS Communications Corp. and Verson Backhaul Solutions, Inc. is dated December 20, 2007. [821fafa98452e23d p.1] The agreement states that it shall be construed and interpreted according to the laws of the State of Georgia. [821fafa98452e23d p.1]

## Verification appendix

Claims: 2 · supported: 2 · partially: 0 · dropped: 0 · gaps: 0 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[821fafa98452e23d p.1] |  |
| s1.2 | s1 | keep | 1.00 | e3→[821fafa98452e23d p.1] |  |

### Evidence

- e1 [821fafa98452e23d p.1 L2-8] keep (1.0): "# INTELLECTUAL PROPERTY AGREEMENT
| Field | Value |
|---|---|
| Document Type | IP Agreement |
| Agreement Date | 2007-12-20 |
| Parties | NMS Communications Corp. ("Seller"); Verson Backhaul Solutions, Inc. ("Backhaul") |"
- e3 [821fafa98452e23d p.1 L54-55] keep (1.0): "This Intellectual Property Agreement shall be construed and interpreted according to the laws of the State of Georgia, applicable contracts to be wholly performed within the State of Georgia."
