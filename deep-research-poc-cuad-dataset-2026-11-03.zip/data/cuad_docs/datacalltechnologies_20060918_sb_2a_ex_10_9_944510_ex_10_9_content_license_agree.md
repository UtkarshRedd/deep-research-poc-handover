<!-- page 1 -->
# CONTENT LICENSING AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2006-03-24 |
| Parties | Data Call Technologies, Inc ("Licensor"); PLAN_B MEDIA AG ("plan_b") |
| Source | CUAD v1 / DataCallTechnologies_20060918_SB-2A_EX-10.9_944510_EX-10.9_Content License Agreement |

Exhibit 10.9

CONTENT LICENSING AGREEMENT

between

Data Call Technologies, Inc. 600 Kenrick, Suite B-12 Houston, Texas 77060

hereinafter referred to as "Licensor"

and

PLAN_B MEDIA AG Schaafenstr. 25 50676 Cologne Germany hereinafter referred to as "plan_b"

1 PURPOSE OF THE AGREEMENT

1.1 The purpose of this content distribution Agreement (hereinafter "Agreement") is to set forth the
terms and conditions under which plan_b may use the Content ("Content" as set forth in APPENDIX 2)
owned or licensed by LICENSOR for a commercial distribution to plan_b's End Users in the territory
("Territory" as set forth in APPENDIX 2).

1.2 End User means any third Party receiving Content on a mobile device for a payment in accordance
with the terms and conditions of this Agreement for their own private and non- commercial use.

2 OBLIGATIONS OF LICENSOR

2.1 LICENSOR shall make a first delivery of Content to plan_b within 14 days after the signing of
this Agreement unless separately agreed between the Parties.

2.2 LICENSOR shall deliver Content according to the specifications (for example formats, file sizes)
set by plan_b or to be agreed between the Parties in writing.

2.3 LICENSOR grants plan_b for the term of this Agreement the right to produce, market and
distribute Content to End Users (in the territory specified in appendix 2) through its own and its
partner's platform.

3 OBLIGATIONS OF PLAN_B

3.1 plan_b will distribute Content to End Users in the Territory through its distribution channels.

3.2 plan_b shall use reasonable commercial efforts to market and stimulate interest in the Content
with its customers.

3.3 plan_b shall provide LICENSOR with a detailed written record, which includes the number of End
User downloads and each distribution channel. Such report shall be provided to LICENSOR in
electronic format within 6 weeks of the end of a quarter.

3.4 LICENSOR shall have the right to use a certified public accountant to inspect and audit all the
related records and books of plan_b to ensure plan_b's compliance with the terms of this Agreement.
In the event that any such audit reveals that plan_b has underpaid fees to the value of ten (10)
percent or more of the total amount of payments for the period covered by the audit, plan_b shall
bear the cost of the audit and shall in any event immediately pay to LICENSOR

Source: DATA CALL TECHNOLOGIES, SB-2/A, 9/18/2006
<!-- page 2 -->
the full value of the underpaid or under-reported fees. Such audits shall normally be conducted
during normal business hours at plan_b's premises.

4 REVENUES

4.1 plan_b shall pay LICENSOR a share of its revenues as set forth in APPENDIX 2 ("REVENUES").

4.2 All shares are net, plus the respective applying value added tax (if applicable).

5 INTELLECTUAL PROPERTY RIGHTS

5.1 LICENSOR is the owner of all intellectual property rights, including without limitation, any and
all patents, utility models, trade marks, rights in designs, trade, business or domain names,
know-how, rights in databases and copyrights, rights in inventions, ideas, concepts, trade secrets
and confidential information which have to be given to fulfill this contract.

5.2 In the alternative, if LICENSOR is not the sole and exclusive owner of all of the foregoing
intellectual property rights to the Content, LICENSOR has been granted by the owner or rightful
sub-licensee of the intellectual property of the Content the right to grant the rights provided by
LICENSOR to plan_b under this Agreement.

5.3 LICENSOR grants to plan_b a license to produce, use, distribute, promote and publicly display
the Content in any possible way for distribution and marketing purposes. Additionally, Licensee
shall have the right to use the trademarks, trade names, or logos relating to Content (the
"TRADEMARKS").

5.4 LICENSOR warrants that Content does not infringe an intellectual property right enforceable in
the agreed country of delivery or use. LICENSOR indemnifies and holds harmless plan_b against all
claims that Content infringes any of the above mentioned rights of a third Party. LICENSOR shall pay
all damages awarded in a trial to a third Party.

6 CONFIDENTIALITY

6.1 Each Party shall keep in confidence all material and information, including without limitation
Content, received from the other Party and marked as confidential or which should be understood to
be confidential, and may not use such material or information for any other purposes than those set
forth in this Agreement. The confidentiality obligation shall, however, not be applied to material
and information, which as shown by the receiving Party,

6.1.1 is generally available or otherwise public; or

6.1.2 the receiving Party has received from a third party without any obligation of confidentiality;
or

6.1.3 was in the possession of the receiving Party prior to receipt of the same from the other Party
without any obligation of confidentiality related thereto; or

6.1.4 the receiving party has independently developed without using material or information received
from the other Party.

6.2 Each Party shall promptly upon termination of this Agreement or when the Party no longer needs
the material or information in question for the purpose stated in this Agreement cease using
confidential material and information received from the other Party and, unless the Parties
separately agree on destruction of such material, return the material in question (including all
copies thereof).

6.3 The rights and responsibilities under this section shall survive any termination or cancellation
of this Agreement for 2 years.

7 TERM OF THE AGREEMENT AND TERMINATION

Source: DATA CALL TECHNOLOGIES, SB-2/A, 9/18/2006
<!-- page 3 -->
7.1 Unless otherwise stated in the Appendix the term of this letter Agreement shall continue for
twenty-four (24) months with the effective date unless terminated sooner or extended pursuant to the
terms hereof ("Initial Term"). The Initial Term shall automatically be extended for an additional
period of half a year unless either party provides the other party with written notification of
termination of the letter Agreement at least 60 days prior to end of such period.

7.2 Either Party shall be entitled to cancel this Agreement if the other Party is materially in
breach of the terms of this Agreement. If the breach of contract is capable of being remedied, this
Agreement can be cancelled only provided that the Party in breach has not rectified its breach
within thirty (30) days of the written notice by the other Party.

7.3 Either Party may cancel this Agreement already prior to the date of its fulfillment, if it
becomes evident that the other Party will commit a breach of contract entitling to cancellation of
this Agreement.

7.4 Upon termination or cancellation of this Agreement plan_b shall cease to use Content for any
purpose and delete Content from any files and data storage.

7.5 After termination of this contract, there shall be a sell-off period (defined in APPENDIX 2)
following the date of termination of this contract.

8 MISCELLANEOUS

8.1 The Parties acknowledge that they act as independent contractors and this Agreement does not
constitute any partnership, joint venture, agency relationship or other independent legal entity
separate from the Parties.

8.2 Neither Party shall assign or transfer to any third party, without the prior written consent of
the other Party, this Agreement or any rights granted herein.

8.3 Any amendments to this Agreement shall be in writing and shall have no effect before signed by
the duly authorized representatives of the Parties.

8.4 All payments will be made to Licensor in United States dollars.

9 SEVERABILITY

9.1 In the event that any provision in this Agreement will be subject to an interpretation under
which it would be void or unenforceable, such provisions will be construed so as to constitute it a
valid and enforceable provision to the fullest extent possible, and in the event that it cannot be
so construed, it will, to that extent, be deemed deleted and separable from the other provisions of
this Agreement, which will remain in full force and effect and will be construed to effectuate its
purposes to the maximum legal extent.

10 GOVERNING LAW AND VENUE

10.1 This Agreement shall be governed and construed in accordance with the laws of the United States
of America. The courts of competent jurisdiction at New York City, New York, shall have the
exclusive jurisdiction over any dispute arising out of or in connection with this Agreement.

10.2 This Agreement has been prepared in two (2) identical copies, one for each Party.

PLAN_B MEDIA AG PLAN_B MEDIA AG

Source: DATA CALL TECHNOLOGIES, SB-2/A, 9/18/2006
<!-- page 4 -->
03/24/06 03/24/06 ______________________________ _____________________________ Date Date

/s/ Heim Brecht /s/ Stefan Meyes-Sickenagel ______________________________
_____________________________ Signature Signature

Heim Brecht Stefan Meyes-Sickenagel ______________________________ _____________________________
Name (Please print) Name (Please print)

CIO COO ______________________________ _____________________________ Title/Position Title/Position

LICENSOR LICENSOR

3/23/06 ______________________________ _____________________________ Date Date

/s/ James Ammons ______________________________ _____________________________ Signature Signature

James Ammons ______________________________ _____________________________ Name (Please print) Name
(Please print)

President and CEO ______________________________ _____________________________ Title/Position
Title/Position

APPENDIX I

1. CONTACT PLAN_B MEDIA AG

Name: Matthias Hellmann

Position: Head of Content

Phone: XXXXXXXXXXXXX

Email: XXXXXXXXXXXXXXX

2 CONTACT LICENSOR

Name: Jim Ammons

Position: CEO / President

Phone: 866-219-2025

Email: ammons@datacalltech.com

3 CONTACT LICENSOR AGENT (IF APPLICABLE)

Name:

Position:

Phone:

Email:

4 BANK ACCOUNT LICENSOR

Bank name: Bank Of America

Bank address: Dallas, Texas

Source: DATA CALL TECHNOLOGIES, SB-2/A, 9/18/2006
<!-- page 5 -->
Country: USA

APPENDIX 2

1 CONTENT, SHARE & TERRITORY

1.1 Contract name (for internal plan_b-ware use): Data Call Technologies, Inc.

CONTENT LICENSOR TERRITORY TERMINATION SHARE

Top News Headlines Top Business Headlines Science/Health News Entertainment Headlines

National Football League National Basketball Association National Hockey League Major League
Baseball NCAA Football NCAA Men's Basketball Professional Golf Association NASCAR

Latest Sports Lines 45% Worldwide 24 months Latest Sports Headlines Thought for Today Market Details
World Financial Highlights Weather: Current Conditions 48-Hour Forecast 7-Day Forecast Weather
Alerts Doppler Weather Radar

2 TERMS

2.1 Contract start: 04-01-06

2.2 Contract end: 04-01-08

2.3 Commercial distribution possible from:

2.4 Sell-off period: 3 months after termination

3 PAYMENTS AND REPORTS TO LICENSOR

3.1 Reporting: Quarterly; 30 days after end of quarter

3.2 Payment terms: 30 days after receipt of invoice

4 EXCLUSIVITY COPYRIGHT

4.1 Content exclusive: [ ] Yes [ ] No

4.2 Copyright:

Source: DATA CALL TECHNOLOGIES, SB-2/A, 9/18/2006
