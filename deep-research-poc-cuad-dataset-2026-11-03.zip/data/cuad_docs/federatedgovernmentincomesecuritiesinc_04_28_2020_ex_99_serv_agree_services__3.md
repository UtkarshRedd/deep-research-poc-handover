<!-- page 1 -->
# LIMITED POWER OF ATTORNEY
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2004-01-01 |
| Parties | FEDERATED INVESTMENT MANAGEMENT COMPANY ("Adviser"); FEDERATED ADVISORY SERVICES COMPANY ("FASC") |
| Source | CUAD v1 / FEDERATEDGOVERNMENTINCOMESECURITIESINC_04_28_2020-EX-99.SERV AGREE-SERVICES AGREEMENT_POWEROF |

LIMITED POWER OF ATTORNEY

KNOW ALL MEN BY THESE PRESENTS, dated as of January 1, 2004, that FEDERATED INVESTMENT MANAGEMENT
COMPANY, a statutory trust duly organized under the laws of the State of Delaware (the "Adviser"),
does hereby nominate, constitute and appoint FEDERATED ADVISORY SERVICES COMPANY, a statutory trust
duly organized under the laws of the State of Delaware ("FASC"), to act hereunder as the true and
lawful agent and attorney-in-fact of the Adviser, acting on behalf of each of the funds or accounts
for which Adviser acts as investment adviser or subadviser shown on Schedule 1 attached hereto and
incorporated by reference herein (each such fund or account being hereinafter referred to as a
"Fund" and collectively as the "Funds"), for the specific purpose of executing and delivering all
such agreements, instruments, contracts, assignments, bond powers, stock powers, transfer
instructions, receipts, waivers, consents and other documents, and performing all such acts, as
Adviser, or FASC acting as agent for the Adviser pursuant to the Services Agreement dated as of
January 1, 2004 between the Adviser and FASC (such agreement, as may be amended, supplemented or
otherwise modified from time to time is hereinafter referred to as the "Services Agreement"), may
deem necessary or reasonably desirable, related to the acquisition, disposition and/or reinvestment
of the funds and assets of a Fund in accordance with Adviser's supervision of the investment, sale
and reinvestment of the funds and assets of each Fund pursuant to the authority granted to the
Adviser as investment adviser or subadviser of each Fund under the Adviser's investment advisory or
subadvisory contract for such Fund (such investment advisory or subadvisory contract, as may be
amended, supplemented or otherwise modified from time to time is hereinafter referred to as the
"Investment Advisory Contract").

The Adviser hereby ratifies and confirms as good and effectual, at law or in equity, all that FASC,
and its officers and employees, may do by virtue hereof. However, despite the above provisions,
nothing herein shall be construed as imposing a duty on FASC to act or assume responsibility for any
matters referred to above or other matters even though FASC may have power or authority hereunder to
do so. Nothing in this Limited Power of Attorney shall be construed (i) to be an amendment or
modifications of, or supplement to, the Investment Advisory Contract, (ii) to amend, modify, limit
or denigrate any duties, obligations or liabilities of the Adviser under the terms of the Investment
Advisory Contract or (iii) exonerate, relieve or release the Adviser from any losses, obligations,
penalties, actions, judgments and suits and other costs, expenses and disbursements of any kind or
nature whatsoever which may be imposed on, incurred by or asserted against the Adviser (x) under the
terms of the Investment Advisory Contract or (y) at law, or in equity, for the performance of its
duties as the investment adviser or subadviser of any of the Funds.

The Adviser hereby agrees to indemnify and save harmless FASC and its trustees, officers and
employees (each of the foregoing an "Indemnified Party" and collectively the "Indemnified Parties")
against and from any and all losses, obligations, penalties, actions, judgments and suits and other
costs, expenses and disbursements of any kind or nature whatsoever which may be imposed on, incurred
by or asserted against an Indemnified Party, other than as a consequence of gross negligence or
willful misconduct on the part of an Indemnified Party, arising out of or in connection with this
Limited Power of Attorney or any other agreement, instrument or document executed in connection with
the exercise of the authority granted to FASC herein to act on behalf of the Adviser, including
without limitation the reasonable costs, expenses and disbursements in connection with defending
such Indemnified Party against any claim or liability related to the exercise or performance of any
of FASC's powers or duties under this Limited Power of Attorney or any of the other agreements,
instruments or documents executed in connection with the exercise of the authority granted to FASC
herein to act on behalf of the Adviser, or the taking of any action under or in connection with any
of the foregoing. The obligations of the Adviser under this paragraph shall survive the termination
of this Limited Power of Attorney with respect to actions taken by FASC on behalf of the Adviser
during the term of this Limited Power of Attorney.

Any person, partnership, corporation or other legal entity dealing with FASC in its capacity as
attorney-in-fact hereunder for the Adviser on behalf of any Fund is hereby expressly put on notice
that FASC is acting solely in the capacity as an agent of the Adviser as agent for the Fund and that
any such person, partnership, corporation or other legal entity must look solely to the Fund in
question for enforcement of any claim against the Fund, as FASC assumes no personal liability
whatsoever for obligations of the Fund entered into by FASC in its capacity as attorney-in-fact for
the Adviser.

Each person, partnership, corporation or other legal entity which deals with a Fund through FASC in
its capacity as agent and attorney-in-fact of the Adviser, is hereby expressly put on notice (i)
that all persons or entities dealing with the Fund must look solely to the assets of the Fund on
whose behalf FASC is acting pursuant to its powers hereunder for enforcement of any claim against
the Fund, as the trustees, officers and/or agents of such Fund, the shareholders of the various
classes of shares of the Fund, and the other Funds of the trust or corporation of which a Fund may
be a series, assume no personal liability whatsoever for obligations entered into on behalf of such
Fund, and (ii) that the rights, liabilities and obligations of any one Fund are separate and
distinct from those of any other Fund.

The execution of this Limited Power of Attorney by the Adviser acting on behalf of the several Funds
shall not be deemed to evidence the existence of any express or implied joint undertaking or
appointment by and among any or all of the Funds. Liability for or recourse under or upon any
undertaking of FASC pursuant to the power or authority granted to FASC under this Limited Power of
Attorney under any rule of law, statute or constitution or by the enforcement of any assessment or
penalty or by legal or equitable proceedings or otherwise shall be limited only to the assets of the
Fund on whose behalf FASC was acting pursuant to the authority granted hereunder.

The Adviser hereby agrees that no person, partnership, corporation or other legal entity dealing
with FASC shall be bound to inquire into FASC's power and authority hereunder and any such person,
partnership, corporation or other legal entity shall be fully protected in relying on such power or
authority unless such person, partnership, corporation or other legal entity has received prior
<!-- page 2 -->
written notice from the Adviser that this Limited Power of Attorney has been revoked. This Limited
Power of Attorney shall be revoked and terminated automatically upon the cancellation or termination
of the Services Agreement or as to any Fund upon the cancellation or termination of the Adviser's
Investment Advisory Contract for such Fund. Except as provided in the immediately preceding
sentence, the powers and authorities herein granted may be revoked or terminated by the Adviser at
any time provided that no such revocation or termination shall be effective until FASC has received
actual notice of such revocation or termination in writing from the Adviser.

This Limited Power of Attorney constitutes the entire agreement between the Adviser and FASC and may
be changed only by a writing signed by both of them, except that the Adviser may at any time change
the list of Funds to which this Limited Power of Attorney relates by executing and delivering to
FASC a later dated version of Schedule 1. This Limited Power of Attorney shall bind and benefit the
respective successors and assigns of the Adviser and FASC; provided, however, that FASC shall have
no power or authority hereunder to appoint a successor or substitute attorney in fact for the
Adviser or any Fund.

This Limited Power of Attorney shall be governed and construed in accordance with the laws of the
Commonwealth of Pennsylvania without reference to principles of conflicts of laws. If any provision
hereof, or any power or authority conferred upon FASC herein, would be invalid or unexercisable
under applicable law, then such provision, power or authority shall be deemed modified to the extent
necessary to render it valid or exercisable while most nearly preserving its original intent, and no
provision hereof, or power or authority conferred upon FASC herein, shall be affected by the
invalidity or the non-exercisability of another provision hereof, or of another power or authority
conferred herein.

This Limited Power of Attorney may be executed in as many identical counterparts as may be
convenient and by the different parties hereto on separate counterparts. This Limited Power of
Attorney shall become binding on the Adviser when the Adviser shall have executed at least one
counterpart and FASC shall have accepted its appointment by executing this Limited Power of
Attorney. Immediately after the execution of a counterpart original of this Limited Power of
Attorney and solely for the convenience of the parties hereto, the Adviser and FASC will execute
sufficient counterparts so that FASC shall have a counterpart executed by it and the Adviser, and
the Adviser shall have a counterpart executed by the Adviser and FASC. Each counterpart shall be
deemed an original and all such taken together shall constitute but one and the same instrument, and
it shall not be necessary in making proof of this Limited Power of Attorney to produce or account
for more than one such counterpart.
<!-- page 3 -->
IN WITNESS WHEREOF, the Adviser has caused this Limited Power of Attorney to be executed by its duly
authorized officer as of the date first written above.

FEDERATED INVESTMENT MANAGEMENT COMPANY By: /s/ Keith M. Schappert Name Keith M. Schappert Title:
President

Accepted and agreed to this January 1, 2004 FEDERATED ADVISORY SERVICES COMPANY By: /s/ G. Andrew
Bonnewell Name: G. Andrew Bonnewell Title: Vice President
<!-- page 4 -->
Schedule 1 to Limited Power of Attorney dated as of October 1, 2016 revised March 1, 2020 by
FEDERATED INVESTMENT MANAGEMENT COMPANY (the Adviser "), acting on behalf of each of the funds and
accounts listed below, and appointing FEDERATED ADVISORY SERVICES COMPANY the attorney-in-fact of
the Adviser List of Funds and Accounts Emerging Markets Core Fund Federated Adjustable Rate
Securities Fund Federated Bank Loan Core Fund Federated Bond Fund Federated California Municipal
Cash Trust Federated Capital Reserves Fund Federated Corporate Bond Strategy Portfolio Federated
Emerging Market Debt Fund Federated Equity Advantage Fund Federated Fixed Income Opportunity Fund
Federated Floating Rate Strategic Income Fund Federated Fund for U.S. Government Securities
Federated Hermes Fund for U.S. Government Securities II Federated Georgia Municipal Cash Trust
Federated Government Income Securities, Inc. Federated Government Income Trust Federated Government
Obligations Fund Federated Government Obligations Tax-Managed Fund Federated Government Reserves
Fund Federated Government Ultrashort Duration Fund Federated Hermes Absolute Return Credit Fund
Federated Hermes SDG Engagement High Yield Credit Fund Federated Hermes Unconstrained Credit Fund
Federated Hermes High Income Bond Fund II Federated High Income Bond Fund, Inc. Federated High Yield
Strategy Portfolio Federated High Yield Trust Federated Institutional High Yield Bond Fund Federated
Intermediate Corporate Bond Fund Federated Intermediate Municipal Trust Federated International Bond
Fund Federated International Bond Strategy Portfolio Federated Liberty U.S. Government Money Market
Trust Federated Managed Risk Fund Federated Hermes Managed Volatility Fund II Federated
Massachusetts Municipal Cash Trust Federated Michigan Intermediate Municipal Trust Federated
Institutional Money Market Management Federated Mortgage Core Portfolio Federated Select Total
Return Bond Fund (formerly Federated Mortgage Fund) Federated Mortgage Strategy Portfolio Federated
Municipal Cash Series Federated Municipal High Yield Advantage Fund Federated Municipal Obligations
Fund Federated Municipal Securities Fund, Inc. Federated Municipal Ultrashort Fund Federated New
York Municipal Cash Trust Federated Ohio Municipal Income Fund Federated Pennsylvania Municipal Cash
Trust Federated Pennsylvania Municipal Income Fund Federated Premier Intermediate Municipal Income
Fund Federated Premier Municipal Income Fund Federated Prime Cash Obligations Fund Federated Prime
Cash Series Federated Hermes Prime Money Fund II Federated Institutional Prime Obligations Fund
<!-- page 5 -->
Federated Institutional Prime Value Obligations Fund Federated Project and Trade Finance Core Fund
Federated Hermes Quality Bond Fund II Federated Real Return Bond Fund Federated Short-Intermediate
Duration Municipal Trust Federated Short-Intermediate Total Return Bond Fund Federated Short-Term
Income Fund Federated Strategic Income Fund Federated Tax-Free Obligations Fund Federated
Institutional Tax-Free Cash Trust Federated Total Return Bond Fund Federated Total Return Government
Bond Fund Federated Trade Finance Income Fund Federated Treasury Cash Series Federated Treasury
Obligations Fund Federated Trust for U.S. Treasury Obligations Federated U.S. Government Securities
Fund: 1-3 Years Federated U.S. Government Securities Fund: 2-5 Years Federated U.S. Treasury Cash
Reserves Federated Ultrashort Bond Fund Federated Unconstrained Bond Fund Federated Virginia
Municipal Cash Trust High Yield Bond Portfolio Short Fixed Income Fund

AS - Federated High Yield Bond Fund AS - Federated High Yield Portfolio BB&T Funds Prime Money
Market Chesapeake Investors Gartmore- Federated GVIT High Income Great West- Maxim Federated Bond
Fund IDEX Federated Tax Exempt ONatl - High Income Bond Portfolio SA - Corporate Bond Portfolio Trav
- High Yield Portfolio
