<!-- page 1 -->
# Sponsorship Agreement
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 2007-12-05 |
| Parties | R. C. Boyd Enterprises, LLC ("Company" or "Boyd"); Cano Petroleum, Inc. ("Sponsor" or "Cano") |
| Source | CUAD v1 / CANOPETROLEUM,INC_12_13_2007-EX-10.1-Sponsorship Agreement |

QuickLinks -- Click here to rapidly navigate through this document

EXHIBIT 10.1

Sponsorship Agreement

THIS AGREEMENT made this 5th day of December, 2007, between R. C. Boyd Enterprises, LLC, a Texas
limited liability company, whose principal place of business is located at 2003 Navasota Cove,
Westlake, Texas, referred to in this Agreement as "Company" or "Boyd", and Cano Petroleum, Inc., a
Delaware corporation qualified to transact business in Texas, whose principal place of business is
located at 801 Cherry Street, Suite 3200, Fort Worth, Texas 76102, referred to in this agreement as
"Sponsor" or "Cano".

WHEREAS, the Company is the owner of the rights to the television production known as Honey Hole
(hereinafter "Honey Hole" or "Show");

WHEREAS, Sponsor desires to acquire the exclusive right to be the lead sponsor of the Show at an
agreed price and under specified terms and conditions;

NOW, THEREFORE, for and in consideration of the premises and the mutual promises, covenants, and
agreements set forth in this Agreement, the Company and Cano agree as follows:

1. Required Production. The Company shall produce no less than forty (40) original episodes of the
Show per year;

2. Lead Sponsorship. The Company agrees that Cano shall be identified as the lead sponsor, by having
a thirty second lead-in promotion at the beginning of each episode; a thirty second trailer
promotion at the end of each episode; and two thirty second commercials during each episode.

3. Signage at Public Appearances. The Company agrees that Cano shall be entitled to place signage,
up to 6 feet × 10 feet at each public appearance made by Honey Hole, including four (4) "Kids
Corner" children's benefits during the term of this Agreement.

4. Use of Logo. The Company agrees that the Cano logo and slogan shall appear on the primary boat
and vehicle used in each episode. Cano recognizes and agrees that it does not and will not have
exclusive rights and that other sponsor's logos may appear on the primary boat and vehicle. The
Company agrees that Cano's logo shall be substantially the same size as other such sponsors;

5. Featured Guests. The Company agrees to feature not less than two (2) persons designated by Cano
as guests on not less than six (6) separate episodes per year.

6. Provision of Lead in Trailer and Commercials. Cano has already provided the Company with voice
over lead-in(s), 30 second commercials and trailers of a quality satisfactory to the Company and
content that meets the Company's minimum standards. The Company shall utilize the already produced
lead-in, commercials and trailers.

7. Sales and Other Taxes. The Company will add sales, excise and any other tax or surcharge to its
invoices which it is obligated to collect and remit under the laws of the State of Texas, the United
States or any other jurisdiction.

8. Notice. Any notice provided for under the terms of this Agreement by either party to the other
shall be in writing and may be effected by personal delivery in writing or registered or certified
mail, return receipt requested. Notice to Boyd shall be sufficient if made or addressed to 2003
Navasota Cove, Westlake, Texas 76092. Notice to Cano shall be sufficient if made or addressed to
Cano Petroleum, Inc., 801 Cherry Street, Suite 3200, Fort Worth, Texas 76102. Each party may change
the address at which notice may be sent to that party by giving notice of such change to the other
party in accordance with the provisions of this Paragraph.

9. Term and Renewal. The term of this Agreement shall be one (1) year, commencing January 1, 2008
and ending on December 31, 2008.
<!-- page 2 -->
10. Force Majeure. In the event that either party shall be prevented from performing any of its
obligations due under the terms of this Agreement by an act of God, by acts of war, riot, or civil
commotion, by an act of State, by strikes, fire, flood, or by the occurrence of any other event
beyond the control of the parties hereto, that party shall be excused from any further performance
of the obligations and undertakings set forth under the terms of this Agreement.

11. Governing Law. This Agreement shall be governed by and construed in accordance with the laws of
the State of Texas and venue for any legal action brought in State Court shall lie exclusively in
Tarrant County, Texas and venue for any action brought in federal court shall lie exclusively in the
Northern District of Texas, Fort Worth Division.

12. Rights Cumulative. The rights and remedies granted in this agreement to Cano in the event of
default are cumulative, and the exercise of such rights shall be without prejudice to the
enforcement of any other right or remedy authorized by law or this agreement.

13. Attorneys' Fees. If any legal action is brought by either of the parties hereto, it is expressly
agreed that the prevailing party in such legal action shall be entitled to recover from the other
party reasonable attorney's fees in addition to any other relief that may be awarded. For the
purposes of this clause, the prevailing party is the party in whose favor final judgment is entered.
In the event that declaratory or injunctive relief alone is granted, the court may determine which,
if either, of the parties shall be considered to be the prevailing party. The amount of reasonable
attorney's fees shall be determined by the court, in the trial of such action or in a separate
action brought for that purpose. Attorney's fees awarded under the provisions of this paragraph
shall be in addition to any other relief that may be awarded.

14. Multiple Counterparts. This Agreement is executed in duplicate copies, each of which shall be
considered a true and original copy of this Agreement.

15. Payment of Money. In consideration of the services to be rendered under this Agreement as set
forth above, the Company shall be entitled to compensation in the amount of $150,000.00 (One Hundred
Fifty Thousand Dollars), to be paid in equal installments of $37,500.00 (Thirty Seven Thousand Five
Hundred Dollars) on January 1, 2008, April 1, 2008, July 1, 2008 and October 1, 2008. If Cano fails
to make any payment when required by this Agreement, the Company shall have the option of canceling
this Agreement following the passage of ten (10) days after having given Cano written notice of its
default. While the Company shall have no further obligation to Cano following cancellation of the
Agreement, Cano shall remain liable for all unpaid installments for the then current term of the
Agreement, which installments shall be immediately due and payable.

16. Exculpatory Clause. The parties agree that Cano will not be liable to the Company or any third
party for any injury sustained by the Company, its employees, independent contractors, invitees or
any other third party while preparing for, filming or working on post production of any episode.

17. Place of Performance. All sums payable under this Agreement shall be paid to the Company at
Southlake, Tarrant County, Texas.

18. Assignment. This Agreement may not be assigned by either party without the prior written consent
of the other party.

19. Other Agreements. This Agreement supersedes any and all other agreements, either oral or in
writing, between the parties with respect to the subject matter of this contract, and contains all
of the covenants and agreements between the parties with respect to the subject matter. Each party
to this contract acknowledges that no representations, inducements, promises, or agreements, orally
or otherwise, have been made by any party, or anyone acting on behalf of any party, that are

2
<!-- page 3 -->
not set forth in this contract, and that no agreement, statement, or promise not contained in this
contract shall be valid or binding.

20. Partial Invalidity. If any term or provision of this Agreement is held by a court of competent
jurisdiction to be invalid, void, or unenforceable, the remainder of the provisions of this
agreement shall remain in full force and effect and shall in no way be affected, impaired, or
invalidated.

21. Government Regulation. This Agreement is subject to all applicable federal, state and municipal
laws, regulations and ordinances, whether existing or enacted hereafter, including the rules and
regulations of all governmental agencies or commissions having jurisdiction in matters covered by
this Agreement or either of the parties hereto.

This Agreement is executed in duplicate on the 5th day of December, 2007, in Fort Worth, Tarrant
County, Texas, to be effective January 1, 2008.

3

R. C. BOYD ENTERPRISES, LLC By: /s/ R.C. Boyd

Printed Name: R.C. Boyd Title: President CANO PETROLEUM, INC. By: /s/ Jeff Johnson

Printed name: Jeff Johnson Title: CEO
<!-- page 4 -->
QuickLinks

EXHIBIT 10.1
