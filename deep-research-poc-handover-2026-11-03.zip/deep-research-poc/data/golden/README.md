# Golden set v1 — synthetic financial-legal corpus

`questions.jsonl` (42 questions) is evaluated against `data/golden_docs/` (31 documents). Both are
written by one deterministic generator, so every gold answer is a verbatim span on the cited gold
page(s) and every `not_in_corpus` answer is provably absent. Nothing here is a real document.

```bash
.venv/Scripts/python.exe scripts/make_golden_corpus.py          # regenerate (≈0.2 s, fixed seed)
.venv/Scripts/python.exe scripts/make_golden_corpus.py --check  # exit 1 if disk differs from the generator
.venv/Scripts/python.exe -m pytest -q tests/test_golden.py
.venv/Scripts/python.exe -m dr.eval.run --dry --golden data/golden/questions.jsonl --docs data/golden_docs
```

Edit `scripts/make_golden_corpus.py`, never the generated files: the test suite fails if the files
on disk differ from what the generator produces.

## Corpus design

Five credit facilities, each a family of documents sharing a `Facility ID`, plus four distractors.
Documents use the `data/sample_docs` format: `<!-- page N -->` on its own line before every page,
and a metadata table on page 1 (`Document Type`, `Effective Date`, `Parties`, `Facility ID`,
`Version`) that `dr.ingest.metadata.parse_metadata_block` understands. Credit agreements are 12 pages
(definitions, commitments, interest and fees, prepayments, representations, affirmative, financial and
negative covenants, events of default, agent and assignments, miscellaneous); ancillary documents are
3–6 pages. Covenants carry exact ratios, amounts and dates and cross-reference sections by number.

| Facility | Borrower | Agent | Documents |
|---|---|---|---|
| FAC-2025-0042 | Halvorsen Marine Holdings, Inc. | Meridian Trust Bank, N.A. | Credit Agreement, conformed copy, First and Second Amendment, Guarantee, Security Agreement, Fee Letter, Limited Waiver, Side Letter |
| FAC-2025-0108 | Corvallis Foods Group LLC | Pacific Commerce Bank | Credit Agreement, First Amendment, Guarantee, Security Agreement, Fee Letter, Lender Consent |
| FAC-2024-0311 | Brightwater Renewables plc | Meridian Trust Bank, N.A. | Credit Agreement, conformed copy, First Amendment, Guarantee, Fee Letter |
| FAC-2025-0193 | Tolland Precision Components Corp. | Northgate Capital Bank | Credit Agreement, Security Agreement, Limited Waiver, Side Letter |
| FAC-2026-0007 | Keswick Logistics Partners LP | Pacific Commerce Bank | Credit Agreement, Guarantee, Fee Letter |
| — | distractors | — | office lease (Halvorsen as tenant), mutual NDA (Corvallis), executive employment agreement (Keswick), master equipment lease (Tolland, lessor affiliated with Northgate) |

Document counts by type: Credit Agreement 7 (5 executed + 2 conformed copies), Amendment 4,
Guarantee 4, Fee Letter 4, Security Agreement 3, Waiver 2, Side Letter 2, Consent 1, distractors 4.

## Traps

- **Near-duplicate conformed copies** (Halvorsen, Brightwater). Same body as the executed agreement,
  different header (`Version: Conformed Copy`, metadata as `Key: Value` lines instead of a table) and a
  convenience note on page 1 saying the copy does not reflect later amendments. They carry the facility
  id, so an identifier question must not count them as a separate instrument, and a temporal question
  must not read their (original) covenant level as current.
- **Version traps.** Halvorsen has two amendments: the First changes the Leverage Ratio and the
  Applicable Margin, the Second changes the Aggregate Commitment and the Maturity Date. "Latest
  document" is therefore the wrong heuristic for the leverage covenant, and amendments must not be
  applied before their effective date.
- **Waiver vs amendment.** The Halvorsen and Tolland Limited Waivers quote a *reported* ratio that
  breached the covenant and state explicitly that they do not amend Section 7.1.
- **Shared parties.** Halvorsen and Brightwater share an agent (and its notice address and fee-account
  prefix); Corvallis and Keswick share another. Same section numbering across all agreements.
- **Distractors that mention the borrowers.** The lease, NDA, employment agreement and equipment lease
  name the same companies and contain notice periods, dollar amounts and governing-law clauses, but
  have no facility id and are not Loan Documents.

## Question types (schema in `PLAN.md`, "Golden set spec")

| type | n | what it tests |
|---|---|---|
| single | 10 | one fact on one page: ratios, amounts, agent, governing law, notice periods |
| temporal | 8 | which version governs on a date (before/after each amendment; latest doc not governing) |
| multihop | 7 | chain through a guarantee, fee letter, security agreement, waiver or consent to a term in another document |
| identifier | 5 | exact facility ids, fee-letter references and account numbers; near-duplicate trap |
| coverage | 6 | enumerations with `gold_items`: guarantors, fees, amendments, covenants, notice provisions across a borrower's documents, borrowers sharing an agent |
| not_in_corpus | 6 (14%) | plausible analyst asks whose subject does not exist anywhere (Excess Cash Flow sweep, LIBOR, Default Rate, swingline sublimit, sustainability pricing, an unknown facility id) |

`gold_docs` reference documents by `<file-stem>` placeholder because doc_ids are content hashes
computed at load time; `dr.eval.golden.resolve_gold_docs(questions, docs)` (or
`load_golden(path, docs=docs)`) maps them to real ids and raises on an unresolvable stem.
`gold_answer` and every `gold_items` entry are verbatim spans on a cited page; computed or comparative
parts of an answer (for example "the margin rose from 2.75% to 3.00%") live in the `rubric`.
`not_in_corpus` questions carry `absent_terms`, the strings whose absence from the whole corpus makes
the abstention correct; the test suite verifies them.

## Known limitations

- The questions are developer-written against a synthetic corpus and are easier than real analyst
  requests over real documents (PLAN.md Phase 0 asks for real user asks when available).
- Verbatim gold answers are short spans; a report that states the same fact in different words is
  judged by the rubric (Phase 6 judge), not by the exact-match test.
- For the identifier question on FAC-2025-0042 the conformed copy is deliberately *not* in `gold_docs`
  even though it contains the id; a doc-recall metric that counts it as a false positive is measuring
  the intended behaviour.

# CUAD — real contracts (`cuad_questions.jsonl`, `data/cuad_docs/`)

A second corpus built from **CUAD v1** (Contract Understanding Atticus Dataset, The Atticus Project,
**CC BY 4.0**): 510 commercial contracts from SEC filings with ~13k expert clause annotations in 41
categories. Unlike the synthetic set, these are real documents with real page breaks, OCR noise and
boilerplate; the questions are derived from the expert labels, so gold answers are still verbatim
spans on known pages. Nothing CUAD-derived is checked in: `data/raw/` and `data/cuad_docs/` are
git-ignored, only the scripts and `cuad_questions.jsonl` are.

```bash
.venv/Scripts/python.exe -I scripts/fetch_cuad.py          # 106 MB from Zenodo (DOI 10.5281/zenodo.4595826), md5-verified
.venv/Scripts/python.exe -I scripts/make_cuad_corpus.py    # 510 PDFs -> data/cuad_docs/*.md + *.meta.json (~2 min)
.venv/Scripts/python.exe -I scripts/make_cuad_golden.py    # annotations -> data/golden/cuad_questions.jsonl
.venv/Scripts/python.exe -m pytest -q tests/test_cuad.py   # skipped with a reason until the corpus is built
.venv/Scripts/python.exe -m dr.eval.run --dry --golden data/golden/cuad_questions.jsonl --docs data/cuad_docs
```

`-I` keeps the interpreter from importing anything next to the downloaded data; the archive is only
ever parsed. `data/raw/cuad/SOURCE.md` records the licence, URL, checksum and fetch time (attribution
is required by CC BY 4.0). `pymupdf` must be installed in the venv (`pip install pymupdf`).

## Sizes

| | |
|---|---|
| Documents | 510 (all of CUAD v1), `data/cuad_docs/<stem>.md` + `<stem>.meta.json`, ~30 MB |
| Pages | 9,348 (18.3 per document; 1 to 200+) |
| Page starts anchored in the PDF | 98% (the rest are blank PDF pages or interpolated) |
| Documents with approximate pages | 1 (`pages_approximate: true` in the sidecar; never cited by a question) |
| Questions | 112: single 36 · temporal 24 · identifier 16 · coverage 12 · multihop 8 · not_in_corpus 16 (14%) |

`scripts/make_cuad_corpus.py --stats` reprints the corpus numbers from `data/cuad_docs/_alignment.json`.

## How the corpus is built

- **Body = CUAD text, pages = PDF.** The markdown body is the CUAD plain text (the annotation
  offsets refer to it; the PDF text layer is often worse). `dr.ingest.pages` reads each PDF page
  with pymupdf, picks 2–3 distinctive anchor lines per page (unique in the PDF, or matched by
  occurrence rank for repeated headers / TOC entries), finds them in the text and puts
  `<!-- page N -->` before the first anchor, so a citation `[doc p.N]` points at the real PDF page.
  Pages whose anchors are not found are placed proportionally and the document is flagged
  `pages_approximate`; pages whose length disagrees with the PDF by > 35% are listed in
  `pages_suspect` and are never used as gold pages.
- **Reflow.** Within a page, whitespace runs collapse to one space and lines longer than 100
  columns wrap (original line breaks are kept, reflow never crosses a page start). Characters are
  never changed, so an annotated span is verbatim on its page **up to whitespace**; tests and
  generators compare whitespace-collapsed text. Tier-1 verification tokenizes anyway.
- **Metadata** (sidecar + a table on page 1): `title` = CUAD "Document Name" span; `doc_type` from
  the CUAD category folder (Distributor Agreement, License Agreement, ...); `date` = CUAD
  "Agreement Date" answer (else "Effective Date", else the SEC filing date from the file name —
  `date_source` says which, and the page-1 table then says "SEC Filing Date"); `parties` = CUAD
  "Parties" answer as `A ("Role"); B ("Role")`. `cuad_title` and `source_pdf` give provenance.
- **Stems** are slugs of the CUAD file names (`<stem>` placeholders in the questions resolve
  through `dr.eval.golden.resolve_gold_docs`, as for the synthetic set).

## Question design

All gold text comes from the CUAD annotations; the generator maps each span's character offsets to
its page(s) through `_alignment.json`, then re-reads the markdown on disk and asserts every answer
and item is on a cited page before writing. Only contracts with exact page alignment are cited.

| Type | What it asks | Gold |
|---|---|---|
| single | governing law, cap on liability, exclusivity, non-compete, termination for convenience, anti-assignment of a named contract | the annotated clause (cut to 300 chars at a word boundary if longer; `notes` says so) |
| temporal | expiration date, renewal term, notice period to terminate renewal | the annotated clause; the CUAD normalized answer ("60 days", "12/31/14") is in `rubric` |
| identifier | which contract is between two named parties / is dated "<date phrase>" | the "Document Name" span; parties and date spans are unique to that contract corpus-wide |
| coverage | among 8–12 listed contracts, which contain a given clause (non-compete, exclusivity, cap on liability, MFN, change of control, termination for convenience) | `gold_items` = one party name unique to each positive contract; negatives are contracts CUAD marks as lacking the clause |
| multihop | governing law of "the agreement between A and B" (parties page → clause page) | the governing-law clause |
| not_in_corpus | a clause category CUAD marks absent in the named contract | no gold docs; `notes` = `contract=<stem>; category=...` |

Contracts are referred to in questions as "the <Title> between <A> and <B> (dated YYYY-MM-DD)",
exactly the fields in the page-1 metadata table and the manifest, so `list_docs` + `grep` can find them.

## Caveats

- **Annotation recall is not perfect.** CUAD negatives ("no non-compete") are expert labels, but a
  clause the annotators missed will make a coverage or not_in_corpus question unfair to a correct
  system. Treat disagreements on those two types as candidates for manual review, not as errors.
- **Approximate / suspect pages.** 1 document has interpolated page starts and 54 pages (0.6%) have a
  length that disagrees with the PDF (usually signature pages, exhibits, or a TOC the text file
  orders differently). Neither is used for gold pages, but citations into those pages during an
  eval run may be off by one page.
- **Long spans.** Clause spans are often several hundred characters; `gold_answer` is cut to 300
  characters when so, which is still a verbatim prefix. The judge rubric carries the short answer.
- **Dates.** 75 contracts have no annotated agreement/effective date; their `date` is the SEC filing
  date (`date_source: filename (SEC filing date)`), which can be years after signing. 6 have none.
- **OCR noise.** A few contracts are OCR'd scans: broken words, odd characters. They are kept (the
  pipeline must cope) but the generator only cites contracts whose pages aligned exactly.
- **Not a persistent index.** `_alignment.json` is a build artefact for the golden generator and tests,
  not something the pipeline reads.
