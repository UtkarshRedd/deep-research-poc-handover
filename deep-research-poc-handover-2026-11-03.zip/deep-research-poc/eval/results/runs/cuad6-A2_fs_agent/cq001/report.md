# Which jurisdiction's law governs the Cooperation Agreement between e.l.f. Beauty, Inc. ...

*Question:* Which jurisdiction's law governs the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01)?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Identify governing law clause

[GAP] No evidence was found for: Establish the explicit jurisdiction named in the Cooperation Agreement's governing law provision.

## Verify clause applicability

[GAP] No evidence was found for: Establish that the identified clause applies to the entire Cooperation Agreement dated 2020-07-01 between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC.

## Verification appendix

Claims: 2 · supported: 0 · partially: 0 · dropped: 0 · gaps: 2

Notes: no evidence in the bank; every section is a gap

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  |  |
| s2.1 | s2 | gap |  |  |  |

### Evidence

