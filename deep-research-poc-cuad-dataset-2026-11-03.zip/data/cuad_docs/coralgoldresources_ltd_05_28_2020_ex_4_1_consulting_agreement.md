<!-- page 1 -->
# CONSULTING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Consulting Agreement |
| Agreement Date | 2020-02-01 |
| Parties | CORAL GOLD RESOURCED LTD. ("Company"); INTERMARK CAPITAL CORP. ("Consultant") |
| Source | CUAD v1 / CORALGOLDRESOURCES,LTD_05_28_2020-EX-4.1-CONSULTING AGREEMENT |

EXHIBIT 4.1 CONSULTING AGREEMENT THIS AGREEMENT is dated for reference the 1st day of February, 2020
(the "Effective Date"). BETWEEN: CORAL GOLD RESOURCES LTD., a company duly incorporated pursuant to
the laws of the Province of British Columbia and having its head office at Suite 900 - 570 Granville
Street, Vancouver, British Columbia V6C 3Pl (the "Company") AND: INTERMARK CAPITAL CORP., a company
duly incorporated pursuant to the laws of the Province of British Columbia and having an office at
Suite 900 - 570 Granville Street, Vancouver, British Columbia V6C 3PI (the "Consultant") WHEREAS: A.
The Company is a mining and exploration company, whose common shares are listed on the TSX Venture
Exchange and OTCQX;

B. The Consultant provides management and financial consulting services to exploration and
development companies, and the principal shareholder of the Consultant, David Wolfin (the
"Principal"), has been the President and Chief Executive Officer and a director of the Company; and

C. The Company wishes to engage the management and financial services of the Consultant, and the
Consultant wishes to be engaged by the Company, to perform the functions of a management consultant
to the Company as set forth herein below. NOW THEREFORE, in consideration of the premises and the
covenants and agreements of the parties hereto as hereinafter set forth, and for other good and
reliable consideration, the sufficiency of which is hereby acknowledged by the parties, the parties
hereto covenant and agree as follows: 1. ENGAGEMENT OF CONSULTANT

1.1 The Company hereby appoints and engages the Consultant as a consultant with respect to the
Services (as defined below) and the Consultant hereby accepts such appointment and engagement by the
Company, all upon and subject to the terms and conditions of this Agreement.

2. SERVICES OF CONSULTANT

2.1 During the Term (as defined below), the Consultant shall provide to the Company advisory and
consulting services as more particularly set forth in Schedule "A" or as the Company may request
from time to time (collectively, the "Services").

-1-
<!-- page 2 -->
2.2 The Consultant shall at all times and in all respects do its utmost to enhance and develop the
business interests and welfareof the Company.

2.3 The Consultant shall be subject to such supervision as may be imposed by the Company in its sole
discretion, and the Consultant shall furnish regular reports and any other data and information
relating to the Services as may, from time to time, be requested by the Company.

2.4 The Consultant shall provide its services to the Company.

3. FEES

3.1 The Company will pay the Consultant basic remuneration for its services in the sum of $10,000
per month (the "Consulting Fee") commencing on the 1st day of February, 2020, and payable on the
last day of each month thereafter up to and including the 31st day of January, 2025, together with
any such increments thereto as the Compensation Committee of the Board of Directors of the Company
may from time to time determine. In addition, the Company will pay to the Consultant all reasonable
expenses of the Consultant as agreed to from time to time which are incurred by the Consultant in
delivery of the Services, based on monthly invoices submitted to the Company, including copies of
all paid receipts; plus harmonized sales taxes or goods and services taxes, as the case may be, in
addition to the Consulting Fees, which taxes will be remitted by the Consultant to the Canada
Revenue Agency.

4. TERM AND RENEWAL

4.1 During the term of this Agreement, the Consultant shall provide its Services to the Company
through its Principal, and the Consultant shall ensure that the Principal will be available to
provide such Services to the Company in a timely manner.

4.2 The term of this Agreement is for a period of five (5) years (the "Term") commencing on the
Effective Date and, unless terminated earlier in accordance with the termination provisions of this
Agreement, ending on January 31, 2025.

5. TERMINATION

5.1 This Agreement can be terminated at any time prior to the expiry of the Term, as follows: (a) by
the Consultant electing to give the Company not less than 3 months prior notice of such termination;

(b) by the Company electing to give the Consultant 3 months prior notice of such termination along
with a termination payment equal to the annual Consulting Fee;

(c) by the Consultant electing to give the Company notice, in the event that there occurs a Change
of Control (as defined below) within six (6) months of the effective date of such Change of Control,
and if the Consultant so elects to terminate this Agreement, then the Consultant will be immediately
entitled to a termination payment equal to CDN$750,000; and

-2-
<!-- page 3 -->
(d) For the purpose of this clause, a Change of Control shall be deemed to have occurred when: (i)
any person, entity or group becomes the beneficial owner of 20% or more of the combined voting power
of the Company's then outstanding voting securities entitled to vote generally in the election of
directors, and such person, entity or group uses such effective voting control to change a majority
of the Board of Directors of the Company, either all at once or through any series of elections and
appointments when considered together; or

(ii) completion of the sale or other disposition by the Company of all or substantially all of the
Company's assets or a reorganization or merger or consolidation of the Company with any other entity
or corporation, other than: (A) a reorganization or merger or consolidation that would result in the
voting securities of the Company outstanding immediately prior thereto continuing to represent,
either by remaining outstanding or by being converted into voting securities of another entity, more
than 50.1 % of the combined voting power of the voting securities of the Company or such other
entity outstanding immediately after such reorganization or merger or consolidation; or

(B) a reorganization or merger or consolidation effected to implement a recapitalization or
reincorporation of the Company (or similar transaction) that does not result in a material change in
beneficial ownership of the voting securities of the Company or its successor. 5.2 On any
termination of this Agreement under Section 5.l (a), (b), or (c) all outstanding stock options
granted to the Consultant shall be exercisable in accordance with the terms of the option agreements
covering such grants. If there is any inconsistency between the terms of this Agreement and the
terms of any stock option agreement governing the grant of any stock options to the Consultant or
the Principal, then the terms of such stock option agreement shall prevail.

5.3 This Agreement and the Term shall terminate automatically, without any prior notice or any
payment to the Consultant, inthe event that: a. the five year Term expires on January 31, 2025;

b. the Consultant should no longer be able to provide the Services through the Principal for any
reason;

c. upon the death or permanent incapacity of the Principal; or

d. The Consultant commits any material breach of this Agreement which breach is not remedied within
30 days after notice to the Consultant of such breach. 6. CONFIDENTIALITY

6.1 The Consultant acknowledges and agrees that in the performance of its obligations under this
Agreement, it may obtain knowledge of Confidential Information (as defined below) relating to the
business or affairs of the Company or its affiliated companies (the "Affiliated Companies").

-3-
<!-- page 4 -->
The Consultant and the Principal shall not, without the prior written consent of the Company, either
during the Term or at any time thereafter: (a) use or disclose any Confidential Information outside
of the Company or the Affiliated Companies;

(b) except in undertaking the Services, remove or aid in the removal from the premises of the
Company or any of the Affiliated Companies any Confidential Information or any property or material
relating thereto; or

(c) use the Confidential Information for any purpose other than in performing the Services. 6.2 The
Consultant shall exercise a reasonable degree of care in safeguarding the aforementioned
Confidential Information against loss, theft, or other inadvertent disclosure, and further agrees to
take all reasonable steps necessary to ensure the maintenance of confidentiality.

6.3 Upon the termination of this Agreement, or upon the Company's earlier request, the Consultant
and the Principal shall promptly deliver to the Company all of the Confidential Information that the
Consultant and the Principal may have in their possession or control.

6.4 In this Agreement, "Confidential Information" shall mean any information or knowledge including,
without limitation, any document, materials, know how, discovery, strategy, method, idea, client
list, marketing strategy or employee compensation, or copies or adaptations thereof, that relates to
the business or affairs of the Company and I or the Affiliated Companies; and is private or
confidential in that it is not generally known or available to the public. Without limiting the
generality of the forgoing "Confidential Information" will include: (a) information regarding the
Company and the Affiliated Companies' business operations, methods and practices, including
marketing strategies, product pricing, margins and hourly rates for staff, costs and all information
regarding the financial affairs of the Company and the Affiliated Companies;

(b) all information related to the mineral exploration interests of the Company and the Affiliated
Companies including maps, data, records, reports, technical studies, drill hole logs, calculations,
opinions, charts, drawings, sketches, plans, documents, summaries, memoranda, analysis and all
geological or technical information;

(c) all information related to the properties, projects, facilities, equipment and other assets used
in the business of the Company and the Affiliated Companies, and all information related to the
exploration or development of (or potential exploration or development of) the Company and the
Affiliated Companies' properties or projects, including without limitation any properties or
projects in respect of which the Company has made any application or is in any negotiations for the
acquisition of an ownership, leasehold or other interest in;

(d) terms of the Company and the Affiliated Companies' relationship with, its investors, (if not
otherwise publically available), partners, clients, suppliers of products or services, and the
Company and the Affiliated Companies' referral sources;

(e) all information concerning exploration, financing or other business opportunities of the Company
and the Affiliated Companies, including all projects, ventures or joint ventures considered by the
Company and the Affiliated Companies, whether or not pursued; and

-4-
<!-- page 5 -->
(f) all trade secrets or other confidential or proprietary information of the Company and the
Affiliated Companies including, business plans, concepts, techniques, processes, designs, data,
software programs, formula, development or experimental work, work in process or other know-how.

(g) Confidential Information shall specifically not include anything that:

(h) is in or enters lawfully into the public domain other than as a result of a disclosure by the
Consultant or the Principal;

(i) becomes available to the Consultant on a non-confidential basis from a source other than the
Company or the affiliated Companies, or any of its representatives, and that source was not under
any obligation of confidentiality; or

(j) the Consultant is required to disclose pursuant to an order of a court of competent jurisdiction
or by the operation of law; provided that, the Consultant provides prompt prior written notice to
the Company of such required disclosure and of the action which is proposed to be taken in response.
In such an event, and only after the Consultant shall have made a reasonable effort to obtain a
protective order or other reliable assurance affording such information confidential treatment, the
Consultant shall furnish only that portion of the Confidential Information which it is required to
disclose. 7. NON-SOLICITATION

7.1 The Consultant covenants, undertakes and agrees with the Company that during the Term and for a
period of one year from the date of expiration or termination of this Agreement for any reason
whatsoever, it shall not, on its own behalf or on behalf of any person, whether directly or
indirectly, in any capacity whatsoever, offer employment to or solicit the employment of or
otherwise entice away from the employment of the Company or any of the Affiliated Companies, any
individual who is employed or engaged by the Company or any of the Affiliated Companies at the date
of expiration or termination of this Agreement or who was employed or engaged by the Company or any
of the Affiliated Companies, within the one year period immediately preceding the date of expiration
or termination of this Agreement, as applicable.

7.2 The Consultant acknowledges and agrees that the above restriction on non-solicitation is
reasonable and necessary for the proper protection of the businesses, property and goodwill of the
Company and the Affiliated Companies.

8. DISCLOSURE AND ASSIGNMENT OF PROJECTS AND WORKS

8.1 The Consultant agrees that all discoveries, maps, technical studies, plans, spreadsheets,
documents, inventions, copyright, software, improvements, know-how or other intellectual property,
whether or not patentable or copyrightable, created by the Consultant during the Term of this
Agreement pertaining to any service, matter, thing, process or method related to this Agreement (the
"Works") will be the sole and absolute property of the Company. The Consultant will keep and
maintain adequate and current written records of all Works made, which records will be available at
all times to the Company and will remain the sole property of the Company.

8.2 The Consultant will assist the Company in obtaining and enforcing, for the Company's own
benefit, patents, copyrights and any other protections in any and all countries for any and all
Works made by the Consultant (in whole or in part) the rights to which belong to or have been
assigned to the Company. The Consultant agrees, upon request, to execute all applications,
assignments, instruments and papers and perform all acts that the Company or its counsel may deem
necessary or desirable to obtain any and all patents, copyrights or other protection in such Works
and otherwise to protect the interests of the Company therein.

-5-
<!-- page 6 -->
9. COMPLIANCE WITH LAWS

9.1 The Services undertaken by the Consultant under this Agreement shall be in full compliance with
all applicable laws andconsistent with a high degree of business ethics.

10. INDEMNIFICATION

10.1 The Consultant shall indemnify and save harmless the Company for any demonstrated losses,
damages, costs or other amounts, including without limitation reasonable legal fees, suffered or
incurred by the Company arising out of third party claims relating to the presence or activities of
the Consultant or its representatives in performing the Services to the extent that such losses,
damages, costs or other amounts are caused by: (a) any breach of the Consultant's obligation in
Section 9 herein; and

(b) any negligence, willful misconduct or fraud on the part of the Consultant in performing the
Services. 10.2 Subject to the Consultant's obligation to indemnify the Company under this Section
10, and provided that the Consultant has not breached Section 9, the Company shall indemnify and
save harmless the Consultant for any demonstrated losses, damages, costs or other amounts, including
without limitation reasonable legal fees, suffered or incurred by the Consultant arising out of
third party claims relating to the presence or activities of the Consultant and/or its
representatives in performing the Services to the extent that such losses, damages, costs or other
amounts are caused by the negligence, willful misconduct or fraud on the part of the Company.

10.3 Neither the Company nor the Consultant shall be liable for any consequential loss, including
but not limited to, claims for loss of profit, revenue or capital, loss of use of utilities,
equipment or facilities, down-time cost, service interruption, cost of money, injury or damage of
any character whatsoever.

11. REMEDIES

11.1 The Consultant acknowledges and agrees that any breach of this Agreement by it could cause
irreparable damage to the Company and I or the Affiliated Companies and that in the event of a
breach by the Consultant, the Company shall have in addition to any and all other remedies at law or
in equity, the right to an injunction, specific performance or other equitable relief to prevent any
violation by the Consultant of any of the provisions of this Agreement. In the event of any such
dispute, the Consultant agrees that the Company shall be entitled, without showing actual damages,
to a temporary or permanent injunction restraining conduct of the Consultant pending a determination
of such dispute and that no bond or other security shall be required from the Company in connection
therewith. The Consultant acknowledges and agrees that the remedies of the Company specified in this
Agreement are in addition to and not in substitution for any other rights and remedies of the
Company at law or in equity and that all such rights and remedies are cumulative and not alternative
or exclusive of any other rights or remedies and that the Company may have recourse to any one or
more of its available rights and remedies as it shall see fit.

-6-
<!-- page 7 -->
12. RELATIONSHIP

12.1 The Company and Consultant each acknowledge and agree that the only relationship of the
Consultant to the Company created by this Agreement shall for all purposes be that of a contractor,
and all persons employed or engaged by the Consultant, including David Wolfin in connection herewith
shall for all purposes be considered to be employed or engaged, as applicable, by the Consultant and
not by the Company. The Company shall have no obligation whatsoever to pay or compensate the
Consultant and/or any representative of the Consultant including David Wolfin, for taxes of any kind
whatsoever that arise out of or with respect to any Consulting Fee, or any other fee, remuneration
or compensation provided to the Consultant under this Agreement.

12.2 The Consultant shall fully indemnify and hold harmless the Company from and against all
assessments, claims, liabilities, costs, expenses and damages that the Company and I or any of the
Affiliated Companies may suffer or incur with respect to any such taxes or benefits. For greater
clarity, the Consultant is solely responsible for the deduction and remissions of income tax,
pension and employment insurance in respect of any employees retained by the Consultant to perform
the services under this Agreement. Furthermore, if these amounts are not remitted, the Consultant
will, in addition to any other provision under this Agreement, indemnify and hold harmless the
Company, its subsidiaries, affiliates and their respective directors and officers from and against
any claim for taxes, penalties and for withholding of funds by the applicable tax, worker's
compensation, employment standards and insurance agencies or any other government agency with
respect to any amount found to be payable by the Company to such agency or commission in respect of
the Consultant's provision of services under this Agreement, including any legal fees incurred by
the Company in defending such claims.

13. SURVIVAL OF TERMS

13.l Sections 6 through 12, inclusive, and this Section 13, shall survive and remain in force
notwithstanding the expiration or other termination of this Agreement for any reason whatsoever. Any
expiration or termination of this Agreement shall be without prejudice to any rights and obligations
of the parties hereto arising or existing up to the effective date of such expiration or
termination, or any remedies of the parties with respect thereto.

14. LIMITED AUTHORITY AS AGENT

14.1 Unless otherwise agreed to in writing by the parties, the Consultant may not act as an agent of
the Company; however, this does not and is not intended to restrict the powers of the Principal to
act as President and Chief Executive Officer of the Company in any way. Without limiting the
generality of the foregoing, the Consultant shall not commit or be entitled to commit the Company to
any obligation whatsoever nor shall the Consultant incur or be entitled to incur any debt or
liability whatsoever on behalf of the Company, except as otherwise agreed to by the Company.

15. NO ASSIGNMENT

15.1 Neither this Agreement nor any of the rights of any of the parties under this Agreement shall
be assigned without thewritten consent of all the parties.

-7-
<!-- page 8 -->
16. SUCCESSORS AND ASSIGNS

16.1 The Agreement shall enure to the benefit of and be binding upon the parties and their
respective heirs, executors,administrators, successors and permitted assigns, as the case may be.

17. WAIVER

17.1 Any waiver of any breach or default under this Agreement shall only be effective if in writing
signed by the party against whom the waiver is sought to be enforced, and no waiver shall be implied
by indulgence, delay or other act, omission or conduct. Any waiver shall only apply to the specific
matter waived and only in the specific instance i n which it is waived.

18. GOVERNING LAWS

18.1 Unless otherwise agreed to in writing by the parties, the Agreement shall be governed by and
construed in accordance with the laws of the Province of British Columbia and the federal laws of
Canada applicable therein, and the parties hereto submit and attorn to the jurisdiction of the
courts of the Province of British Columbia.

19. FURTHER ASSURANCES

19.1 Each of the parties shall, on request by the other party, execute and deliver or cause to be
executed and delivered all such further documents and instruments and do all such further acts and
things as the other party may reasonably require to evidence, carry out and give full effect to the
terms, conditions, intent and meaning of this Agreement and to ensure the completion of the
transactions contemplated hereby.

20. NOTICES

20.1 All notices required or permitted under this Agreement shall be in writing and shall be given
by delivering such notice or mailing such notice by pre-paid registered mail, by facsimile
transmission or electronic mail to the addresses provided under the names of each party on the first
page to this Agreement. Any such notice or other communication shall, if delivered, be deemed to
have been given or made and received on the date delivered (or the next business day if the day of
delivery is not a business day), and if mailed, shall be deemed to have been given or made and
received on the fifth business day following the day on which it was so mailed and if faxed (with
confirmation received) shall be deemed to have been given or made and received on the day on which
it was so faxed (or the next business day if the day of sending is not a business day). The parties
may give from time to time written notice of change of address in the manner aforesaid.

21. CONSTRUCTION

21.1 In this Agreement, unless otherwise indicated: (a) "Agreement" means this Consulting Agreement;

(b) the words "include", "including" or "in particular", when following any general term or
statement, shall not be construed as limiting the general term or statement to the specific items or
matters set forth or to similar items or matters, but rather as permitting the general term or
statement to refer to all other items or matters that could reasonably fall within the broadest
possible scope of the general term or statement;

-8-
<!-- page 9 -->
(c) "herein", "hereby", "hereunder", "hereof', "hereto" and words of similar import, refer to this
Agreement as a whole and not to any particular Section of this Agreement;

(d) a reference to a statute means that statute, as amended and in effect as of the date hereof, and
includes each and every regulation and rule made thereunder and in effect as of the date hereof, and
includes all amendments thereof given effect from time to time;

(e) a reference to a Section means, unless the context otherwise requires, that specific Section in
Agreement;

(f) a reference to a "consent", "notice" or "agreement" means a consent, notice or agreement, as the
case may be, by an authorized representative of the party or parties thereto;

(g) where a word, term or phrase is defined herein, its derivatives or other grammatical forms have
a corresponding meaning;

(h) all words, other than defined terms, used in this Agreement, regardless of the number and gender
in which they are used, shall be deemed and construed to include the singular or the plural and the
masculine, feminine or body corporate, as the context may require;

(i) time is of the essence;

(j) in the event that any date on which any action is required to be taken hereunder by any of the
parties hereto is not a business day, such action shall be required to be taken on the next
succeeding day which is a business day;

(k) references to a "party" or "parties" are references to a party or parties to this Agreement;

(l) the headings in this Agreement form no part of this Agreement and shall be deemed to have been
inserted for convenience only;

(m) unless otherwise agreed to in writing by the parties, all dollar amount referred to herein are
expressed in Canadian dollars; and

(n) the Effective Date of this Agreement shall be February 1, 2020, despite the actual date of
execution of this Agreement. 22. SEVERABILITY

22.1 If any provision of this Agreement is held by a court of competent jurisdiction to be invalid,
illegal or unenforceable, then tothe fullest extent permitted by law: (a) all other provisions of
this Agreement shall remain in full force and effect in such jurisdiction and shall be liberally
construed in order to carry out the intentions of the parties as nearly as may be possible; and

(b) such invalidity, illegality or unenforceability shall not affect the validity, legality or
enforceability of such provision in any other jurisdiction. 23. COUNTERPARTS AND FACSIMILE

23.l This Agreement may be executed in one or more counterparts and delivered by facsimile, each of
which when so executed shall constitute an original and all of which together shall constitute one
and the same agreement.

24. INDEPENDENT LEGAL ADVICE

24.1 The Company has recommended to the Consultant that it obtain independent legal advice prior to
signing this Agreement. The Consultant acknowledges that it has received independent legal advice or
have waived the opportunity to do so and have elected to proceed without benefit of same.

-9-
<!-- page 10 -->
IN WITNESS WHEREOF this Agreement has been executed as of the Effective Date. CORAL GOLD RESOURCES
LTD. Per: "Ronald Andrews" Authorized Signatory INTERMARK CAPITAL CORP. Per: "David Wolfin"
Authorized Signatory

-10-
<!-- page 11 -->
THIS IS SCHEDULE "A" TO THE CONSULTING AGREEMENT BETWEEN CORAL GOLD RESOURCES LTD. AND lNTERMARK
CAPlTAL CORP. Description of Consulting Services: The Consultant shall provide management and
financial consulting services, including the supervision of the senior management, all staff, and
all field personnel of the Company, whether employees or consultants, strategic planning and
property acquisitions, strategic financial planning and annual budget reviews, as well as the
implementation and monitoring of the Company's compliance with continuous reporting requirements,
internal controls over accounting systems and financial reporting to the Company. Duties and
Responsibilities: The Executive shall serve the Company as an executive officer in the position of
President and Chief Executive Officer. The Executive shall report to the Board and shall undertake
and perform the following duties and responsibilities: · actively engage with the Board to ensure
that the initiatives of the management team are aligned with the strategic direction and objectives
for the Company that have been established by the Board;

· provide overall direction for the Company in order for it to implement agreed strategies in order
to meet Company goals and objectives;

· provide shareholder and investor communication and manage key investment banking and institutional
relationships;

· make decisions in line with organizational goals, leading to desired results, and will be
responsible and accountable for results;

· create and sustain the organizational culture and environment needed to achieve objectives and
results and recruit and retain a high-performance operating team;

· oversee the implementation and monitoring of internal controls, reporting compliance obligations,
sign off on CEO Certificates for the interim and annual financial statements and setting
environmental protection policies; and

· such other duties and responsibilities as may be assigned or vested in him by the Board from time
to time and which are consistent with the duties and responsibilities of a President and Chief
Executive Officer. The Executive agrees, during the continuance of his employment, to devote
sufficient working time, services, skill and ability to such employment and to serve at all times
with loyalty and honesty in the best interests of the Company. The Executive acknowledges that the
position of President and CEO will involve significant travel for business development and for
investor relations.

-11-
