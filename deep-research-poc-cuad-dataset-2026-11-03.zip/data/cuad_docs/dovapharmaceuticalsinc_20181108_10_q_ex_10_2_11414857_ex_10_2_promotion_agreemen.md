<!-- page 1 -->
# CO-PROMOTION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Promotion Agreement |
| Agreement Date | 2018-09-26 |
| Parties | Dova Pharmaceuticals, Inc. ("Dova"); Valeant Pharmaceuticals North America LLC ("Valeant")("Party" and together as the "Parties") |
| Source | CUAD v1 / DovaPharmaceuticalsInc_20181108_10-Q_EX-10.2_11414857_EX-10.2_Promotion Agreement |

Exhibit 10.2

______________________________________________________________________________

CO-PROMOTION AGREEMENT

by and between

DOVA PHARMACEUTICALS, INC.

and

VALEANT PHARMACEUTICALS NORTH AMERICA LLC

September 26, 2018

______________________________________________________________________________

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 2 -->
TABLE OF CONTENTS

Page

ARTICLE 1 DEFINITIONS 1

ARTICLE 2 RIGHTS AND OBLIGATIONS 8

2.1 Engagement; Grant of Rights. 8

2.2 Retention of Rights. 9

2.3 Non-Competition; Non-Solicitation. 9

2.4 Dova Trademarks and Copyrights. 10

ARTICLE 3 JOINT STEERING COMMITTEE 11

3.1 Formation of the JSC. 11

3.2 Meetings and Minutes. 11

3.3 Purpose of the JSC. 11

3.4 Decision Making. 13

3.5 Marketing Sub-Committee. 13

ARTICLE 4 VALEANT ACTIVITIES FOR THE PRODUCT 14

4.1 Valeant Activities. 14

4.2 Detailing. 15

4.3 Compliance with Applicable Law. 17

4.4 Field Force Personnel Training; Product Materials. 19

4.5 Provisions Related to Field Force Personnel. 21

4.6 Responsibility for Valeant Activity Costs and Expenses. 22

4.7 Data Sharing. 22

ARTICLE 5 REGULATORY, SAFETY AND SURVEILLANCE, COMMERCIAL MATTERS 23

5.1 Dova Responsibility. 23

5.2 Valeant Involvement. 23

5.3 Inspections. 23

5.4 Pharmacovigilance. 24

5.5 Unsolicited Requests for Medical Information. 24

5.6 Recalls and Market Withdrawals. 25

5.7 Certain Reporting Responsibilities. 25

5.8 Booking of Sales Revenues. 25

5.9 Returns. 25

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 3 -->
i

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 4 -->
TABLE OF CONTENTS (continued)

5.10 Manufacturing; Distribution; Marketing. 25

ARTICLE 6 FINANCIAL PROVISIONS 26

6.1 Promotion Fee. 26

6.2 Milestone Payment. 27

6.3 Reports; Payments. 27

6.4 Taxes. 28

6.5 Determination of Specialty. 29

ARTICLE 7 AUDIT RIGHTS 30

7.1 Recordkeeping. 30

7.2 Valeant Rights. 30

7.3 Dova Rights. 31

ARTICLE 8 INTELLECTUAL PROPERTY 32

8.1 Ownership of Intellectual Property. 32

8.2 Title to Trademarks and Copyrights. 32

8.3 Protection of Trademarks and Copyrights. 32

8.4 Disclosure of Know-How. 33

ARTICLE 9 CONFIDENTIALITY 33

9.1 Confidential Information. 33

9.2 Public Announcements. 34

ARTICLE 10 REPRESENTATIONS AND WARRANTIES; ADDITIONAL COVENANTS 35

10.1 Representations and Warranties of Dova. 35

10.2 Representations and Warranties of Valeant. 37

10.3 Disclaimer of Warranty. 38

10.4 Additional Covenants. 39

ARTICLE 11 INDEMNIFICATION; LIMITATIONS ON LIABILITY 39

11.1 Indemnification by Dova. 39

11.2 Indemnification by Valeant. 39

11.3 Indemnification Procedures. 40

11.4 Limitation of Liability. 40

11.5 Insurance. 40

ARTICLE 12 TERM AND TERMINATION 41

12.1 Term. 41

12.2 Early Termination for Cause. 41

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 5 -->
12.3 Other Early Termination. 42

12.4 Effects of Termination. 42

12.5 Tail Period. 42

ii

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 6 -->
TABLE OF CONTENTS (continued)

12.6 Survival. 43

ARTICLE 13 MISCELLANEOUS 43

13.1 Force Majeure. 43

13.2 Assignment. 43

13.3 Severability. 44

13.4 Notices. 44

13.5 Governing Law. 45

13.6 Dispute Resolution. 45

13.7 Waiver of Jury Trial. 45

13.8 Entire Agreement; Amendments. 46

13.9 Headings. 46

13.10 Independent Contractors. 46

13.11 Third Party Beneficiaries. 46

13.12 Waiver. 46

13.13 Cumulative Remedies. 46

13.14 Waiver of Rule of Construction. 46

13.15 Use of Names. 46

13.16 Further Actions and Documents. 47

13.17 Certain Conventions. 47

13.18 Counterparts. 47

iii

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018

CO-PROMOTION AGREEMENT
<!-- page 7 -->
This Co-Promotion Agreement (this "Agreement") is entered into and dated as of September 26, 2018
(the "Effective Date") by and between Dova Pharmaceuticals, Inc., a Delaware corporation ("Dova"),
and Valeant Pharmaceuticals North America LLC, a Delaware limited liability company ("Valeant").
Dova and Valeant are each referred to individually as a "Party" and together as the "Parties".

RECITALS

WHEREAS, Dova has developed and has rights to market and sell the Product (as defined below) in the
Territory;

WHEREAS, the Parties believe that it would be mutually beneficial to collaborate on promotional
activities for the Product and, accordingly, Dova desires that Valeant conduct certain promotional
activities, and Valeant desires to conduct such activities, for the Product in the Territory;

NOW, THEREFORE, in consideration of the following mutual promises and obligations, and for other
good and valuable consideration the adequacy and sufficiency of which are hereby acknowledged, the
Parties agree as follows:

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 8 -->
ARTICLE 1 DEFINITIONS

1.1 "Act" shall mean the Federal Food, Drug and Cosmetic Act, 21 U.S.C. § 301 et seq., as it may be
amended from time to time, and the regulations promulgated thereunder.

1.2 "Adverse Event" shall mean any untoward medical occurrence in a patient or clinical
investigation subject who is administered the Product, but which does not necessarily have a causal
relationship with the treatment for which the Product is used. An "Adverse Event" can include any
unfavorable and unintended sign (including an abnormal laboratory finding), symptom or disease
temporally associated with the use of the Product, whether or not related to the Product. A
pre-existing condition that worsened in severity after administration of the Product would be
considered an "Adverse Event".

1.3 "Affiliate" shall mean, with respect to any Person, any other Person that directly or indirectly
controls, is controlled by or is under common control with such Person. A Person shall be deemed to
control another Person if such Person possesses the power to direct or cause the direction of the
management, business and policies of such Person, whether through the ownership of fifty percent
(50%) or more (or such lesser percentage which is the maximum allowed to be owned by a foreign
corporation in a particular jurisdiction) of the voting securities of such Person, by contract or
otherwise.

1.4 "Agreement" shall have the meaning set forth in the preamble to this Agreement.

1.5 "Alliance Managers" shall have the meaning set forth in Section 4.1.4.

1.6 "Alternate Product" shall mean a pharmaceutical product that is commercialized by Valeant or its
Affiliates in the Territory and that is part of the Salix business segment of Valeant's parent
company, Bausch Health Companies, Inc. (or, in the event that such business segments are
restructured, that is part of the Salix business unit), and which product is complementary to the
Product with regard to Target Professionals in the Specialty.

1.7 "Applicable Laws" shall mean all applicable statutes, ordinances, regulations, codes, rules, or
orders of any kind whatsoever of any Governmental Authority in the Territory pertaining to any of
the activities and obligations contemplated by this Agreement, including, as applicable, the Act,
the Generic Drug Enforcement Act of 1992 (21 U.S.C. § 335a et seq.), the Anti- Kickback Statute (42
U.S.C. § 1320a-7b et seq.), the Health Insurance Portability and Accountability Act of 1996, the
Federal False Claims Act (31 U.S.C. §§ 3729-3733) (and applicable state false claims acts), the
Physician Payments Sunshine Act, the Code, the Department of Health and Human Services Office of
Inspector General Compliance Program Guidance for Pharmaceutical Manufacturers, released April 2003,
the Antifraud and Abuse Amendment to the Social Security Act, the American Medical Association
guidelines on gifts to physicians, generally accepted standards of good clinical practices adopted
by current FDA regulations, as well as any state laws and regulations (i) impacting the promotion of
pharmaceutical products, (ii) governing the provision of meals and other gifts to medical
professionals, including pharmacists, or (iii) governing consumer

2

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 9 -->
protection and deceptive trade practices, including any state anti-kickback/fraud and abuse related
laws, all as amended from time to time.

1.8 "Business Day" means each day of the week, excluding Saturday, Sunday or a day on which banking
institutions in New York, New York, USA are closed.

1.9 "Calendar Quarter" shall mean each successive period of three (3) calendar months commencing on
January 1, April 1, July 1 and October 1, except that the first Calendar Quarter of the Term shall
commence on the Effective Date and end on the day immediately prior to the first to occur of January
1, April 1, July 1 or October 1 after the Effective Date, and the last Calendar Quarter shall end on
the last day of the Term.

1.10 "Calendar Year" shall mean each successive period of twelve (12) months commencing on January 1
and ending on December 31, except that the first Calendar Year of the Term shall commence on the
Effective Date and end on December 31 of the year in which the Effective Date occurs, and the last
Calendar Year of the Term shall commence on January 1 of the year in which the Term ends and end on
the last day of the Term.

1.11 "Claims" shall mean all charges, complaints, actions, suits, proceedings, hearings,
investigations, claims, demands, judgments, orders, decrees, stipulations or injunctions, in each
case of a Third Party (including any Governmental Authority).

1.12 "Code" shall mean the Code on Interactions with Healthcare Professionals promulgated by the
Pharmaceutical Research and Manufacturers of America (PhRMA)/BIO, as it may be amended.

1.13 "Compensation Report" shall have the meaning set forth in Section 4.2.2(b).

1.14 "Compliance Manager" shall have the meaning set forth in Section 4.3.9.

1.15 "Compliance Report" shall have the meaning set forth in Section 4.2.2(c).

1.16 "Confidential Information" shall mean all secret, confidential, non-public or proprietary
Know-How, whether provided in written, oral, graphic, video, computer or other form, provided by or
on behalf of one Party to the other Party pursuant to this Agreement, including information relating
to the disclosing Party's existing or proposed research, development efforts, promotional efforts,
regulatory matters, patent applications or business and any other materials that have not been made
available by the disclosing Party to the general public. All such information related to this
Agreement disclosed by or on behalf of a Party (or its Affiliate) to the other Party (or its
Affiliate) pursuant to the Confidentiality Agreement shall be deemed to be such Party's Confidential
Information disclosed hereunder. For purposes of clarity, (i) Dova's Confidential Information shall
include all Product Materials unless and until made available by Dova to the general public
(including through Valeant) and (ii) the terms of this Agreement shall be considered Confidential
Information of both Parties.

1.17 "Confidentiality Agreement" shall have the meaning set forth in Section 9.1.1.

3

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 10 -->
1.18 "Designated Product" shall mean a specific pharmaceutical product marketed by Valeant which is
agreed to in writing by the Parties on or prior to the Effective Date.

1.19 "Detail(s)" shall mean a Product presentation during a face-to-face sales call between a Target
Professional and a Sales Representative, during which a presentation of the Product's attributes,
benefits, prescribing information and safety information are orally presented, for use in the Field
in the Territory. Neither e-details, nor presentations made at conventions, exhibit booths, a sample
drop, educational programs or speaker meetings, or similar gatherings, shall constitute a Detail.

1.20 "Detail Report" shall have the meaning set forth in Section 4.2.2.

1.21 "Dispute" shall have the meaning set forth in Section 13.6.1.

1.22 "Dollar" or "$" shall mean United States dollar.

1.23 "Dova Trademarks and Copyrights" shall mean the logos, trade dress, slogans, domain names and
housemarks of Dova or any of its Affiliates as may appear on any Product Materials or Product
Labeling, in each case, as may be updated from time to time by Dova.

1.24 "Dova's Third Party Data Source" shall mean [***] or such other data source as selected by Dova
and with which Dova enters into an agreement, at its cost.

1.25 "Effective Date" shall have the meaning set forth in the preamble to this Agreement.

1.26 "FDA" shall mean the United States Food and Drug Administration or any successor agency
performing comparable functions.

1.27 "Field" shall mean the treatment of thrombocytopenia in adult patients with chronic liver
disease who are scheduled to undergo a procedure and any and all additional indications for which
the Product is approved in the Territory.

1.28 "Field Force Personnel" shall mean collectively, the Sales Representatives, the members of the
institutional account management team described in Section 4.1.5, if any, that are engaged in
Detailing the Product and any other employees of Valeant engaged in the Valeant Activities.

1.29 "GAAP" shall mean United States generally accepted accounting principles.

1.30 "Governmental Authority" shall mean any court, agency, authority, department, regulatory body
or other instrumentality of any government or country or of any national, federal, state,
provincial, regional, county, city or other political subdivision of any such government or any
supranational organization of which any such country is a member, which has competent and binding
authority to decide, mandate, regulate, enforce, or otherwise control the activities of the Parties
contemplated by this Agreement.

4

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 11 -->
1.31 "Gross to Net Fraction" shall mean, for each SKU of the Product, a fraction (i) the numerator
of which is the net sales of the SKU of the Product in the Territory for an applicable period (based
on the gross-to-net discounts for all sales of such SKU of the Product (i.e., sales attributable to
the Specialty, as well as all other sales of such SKU of the Product), and (ii) the denominator of
which is gross sales of such SKU of the Product in the Territory for an applicable period, in each
case, as determined in accordance with Dova's revenue recognition policies, which is in accordance
with GAAP (on a consistent basis), for quarterly financial reporting purposes, as reported in Dova's
quarterly filings with the U.S. Securities Exchange Commission.

1.32 "Indemnified Party" shall have the meaning set forth in Section 11.3.

1.33 "Indemnifying Party" shall have the meaning set forth in Section 11.3.

1.34 "Intellectual Property" shall have the meaning set forth in Section 8.1.2.

1.35 "Intermediary" shall mean any wholesaler or distributor who sells Product to Retail Pharmacies
and Non-Retail Institutions, but not patients, and with which Dova (or its Affiliates) has entered
into an agreement or otherwise has arrangements.

1.36 "Inventions" shall have the meaning set forth in Section 8.1.2.

1.37 "JSC" shall have the meaning set forth in Section 3.1.

1.38 "Know-How" shall mean information, whether or not in written form, including biological,
chemical, pharmacological, toxicological, medical or clinical, analytical, quality, manufacturing,
research, or sales and marketing information, including processes, methods, procedures, techniques,
plans, programs and data.

1.39 "Losses" shall mean any and all amounts paid or payable to Third Parties with respect to a
Claim (including any and all losses, damages, obligations, liabilities, fines, fees, penalties,
awards, judgments, interest), together with all documented out-of- pocket costs and expenses,
including attorney's fees, reasonably incurred.

1.40 "Net Sales" shall mean, for an applicable period, the aggregate amount, without duplication,
equal to the Specialty Pharmacy Net Sales for each SKU, the Retail Net Sales for each SKU, if any,
and the Non-Retail Net Sales for each SKU.

1.41 "Non-Retail Institution" shall mean any institution (other than the Specialty Pharmacies,
Retail Pharmacies and Intermediaries) to which Dova (or its Affiliates or its Intermediaries) sells
and/or ships units of Product during the Term, which shall include group purchasing organizations
(GPOs), hospitals, clinics, long term care facilities and any outlets that are a member of an
Integrated Delivery Network (IDN), and with which Dova or its Affiliates do not have data agreements
which enables Dova to track shipments of Product from such institution to patients based on the
Target Professional prescribing such Product.

1.42 "Non-Retail Net Sales" shall mean, for each SKU of the Product:

5

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 12 -->
(i) the number of units of such SKU of Products shipped by Dova (or its Affiliates or its
Intermediaries) to the Non-Retail Institutions in the Territory during an applicable period
(excluding any shipments in excess of one unit of either SKU shipped to such Non-Retail Institutions
based on the initial orders from such Non-Retail Institutions):

MULTIPLIED BY

(ii) the applicable Specialty Fraction for such SKU of the Product for the applicable period,

MULTIPLIED BY

(iii) the applicable WAC for such SKU of the Product for the applicable period,

MULTIPLIED BY

(iv) the Gross to Net Fraction for such SKU of the Product for the applicable period.

1.43 "Party" shall have the meaning set forth in the preamble to this Agreement.

1.44 "Person" shall mean any individual, corporation, partnership, limited liability company,
association, joint-stock company, trust, unincorporated organization or other entity, or government
or political subdivision thereof.

1.45 "Product" shall mean the product approved pursuant to New Drug Application (NDA) No. 210238, as
such approval may be supplemented from time to time (including by way of supplemental new drug
application (sNDA)), currently marketed as DOPTELET® (avatrombopag) in the Territory and shall
include an authorized generic version of such Product.

1.46 "Product Labeling" shall mean the labels and other written, printed or graphic matter upon (a)
any container or wrapper utilized with the Product or (b) any written material accompanying the
Product, including Product package inserts, in each case as approved by the FDA.

1.47 "Product Materials" shall have the meaning set forth in Section 4.4.1(a).

1.48 "Product Training Materials" shall have the meaning set forth in Section 4.4.1(a).

1.49 "Quarterly Average Sales Force Size" shall have the meaning set forth in Section 4.2.2.

1.50 "Quarterly Minimum Details" for an applicable Calendar Quarter shall mean [***].

1.51 "Regulatory Approval" shall mean any and all necessary approvals, licenses, registrations or
authorizations from any Governmental Authority, in each case, necessary to commercialize the Product
in the Territory.

1.52 "Retail Pharmacy" shall mean an outlet which dispenses the Product directly to a patient in a
retail setting or through mail order services.

6

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 13 -->
1.53 "Retail Net Sales" shall mean, for each SKU of the Product:

(i) the number of units of such SKU of the Product shipped from Retail Pharmacies to patients based
on prescriptions written by the Specialty in the Territory (as determined by data reported by data
aggregator) or such other data source with which Dova enters into an agreement at its cost),

MULTIPLIED BY

(ii) the applicable WAC for such SKU of the Product for the applicable period,

MULTIPLIED BY

(iii) the Gross to Net Fraction for such SKU of the Product for the applicable period.

1.54 "Sales Representative" shall mean an individual employed and compensated by Valeant as a
full-time employee as part of its sales forces and who engages in Detailing of the Designated
Product (or the Alternate Product, as the case may be) in the Territory, and who is also trained
with respect to the Product in accordance with this Agreement (including the Product Labeling and
the use of the Promotional Materials) to deliver Details for the Product in the Field in the
Territory.

1.55 "Senior Officer" shall mean, with respect to Dova, its President and Chief Executive Officer
(or such officer's designee), and with respect to Valeant, its [***] (or such officer's designee).
From time to time, each Party may change its Senior Officer by giving written notice to the other
Party.

1.56 "Specialty" shall mean (i) Target Professionals with a primary or secondary specialty
designation of Gastroenterology, Colorectal Surgery or Proctology (excluding any such Target
Professionals with a primary or secondary specialty designation of Hepatology (including Transplant
Hepatology), in each case, as determined by data reported by Dova's Third Party Data Source, subject
to any adjustments determined pursuant to the process set out in Section 6.5, and (ii) all
healthcare professionals with Nurse or Physician Assistant specialty designations affiliated with
the Target Professionals described in subsection (i), as adjusted.

1.57 "Specialty Fraction" shall mean, for each SKU of the Product, a fraction (i) the numerator of
which is the number of units of such SKU of the Product shipped from the Specialty Pharmacies or the
Retail Pharmacies to patients based on prescriptions written by the Specialty in the Territory (as
determined by data reported pursuant to agreements between Dova (or its Affiliates) and the
Specialty Pharmacies or the data aggregators, applicable), and (ii) the denominator of which is the
number of units of such SKU of the Product shipped from the Specialty Pharmacies or the Retail
Pharmacies to all patients in the Territory (namely based on prescriptions written by the Specialty
and outside the Specialty) (as determined by data reported pursuant to agreements between Dova (or
its Affiliates) and the Specialty Pharmacies or the data aggregators, as applicable).

1.58 "Specialty Pharmacy Net Sales" shall mean, for each SKU of the Product:

7

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 14 -->
(i) the number of units of such SKU of the Product shipped from the Specialty Pharmacies to all
patients based on prescriptions written by the Specialty in the Territory during an applicable
period (as determined by data reported pursuant to agreements between Dova (or its Affiliates) and
the Specialty Pharmacies or the data aggregators, as applicable); and

MULTIPLIED BY

(ii) the applicable WAC for such SKU of the Product for the applicable period,

MULTIPLIED BY

(iii) the Gross to Net Fraction for such SKU of the Product for the applicable period.

1.59 "Specialty Pharmacy" shall mean those specialty pharmacies to which Dova (or its Affiliates)
sells and/or ships units of Product during the Term and for which Dova or its Affiliates have
agreements with that include data provisions or provide for separate data agreements which enables
Dova to track shipments of Product from such Specialty Pharmacy to patients based on the Target
Professional prescribing such Product.

1.60 "Tail Period" shall mean the period commencing on the day after the last day of the Term and
ending on the earlier of (i) [***] and (ii) [***], unless terminated early pursuant to Section
2.3.1(a) of the Agreement.

1.61 "Target Professionals" shall mean physicians, nurse practitioners, physician assistants and any
other medical professionals in the Territory with prescribing authority (as authorized under
Applicable Law) in the Territory for the Product.

1.62 "Term" shall have the meaning set forth in Section 12.1.

1.63 "Territory" shall mean the United States of America and its territories and possessions.

1.64 "Third Party(ies)" shall mean any person or entity other than Dova and Valeant and their
respective Affiliates.

1.65 "Third Party Agreements" shall mean the agreements described on Schedule 1.65 hereto.

1.66 "Valeant Activities" shall mean any and all promotional activities (including Detailing)
conducted by Valeant to encourage the appropriate use of the Product in the Specialty in the Field
in the Territory in accordance with the terms of this Agreement.

1.67 "Valeant Property" shall have the meaning set forth in Section 8.1.1.

1.68 "WAC" shall mean, for each SKU of the Product, Dova's list price for a unit of the SKU of the
Product to wholesalers or direct purchasers in the Territory, as reported in wholesale price guides
or other nationally recognized publications of drug pricing data.

ARTICLE 2 RIGHTS AND OBLIGATIONS

2.1 Engagement; Grant of Rights. During the Term, subject to the terms and conditions of this
Agreement, Dova hereby grants to Valeant the right, on a co-exclusive basis (solely with Dova and
its Affiliates), to Detail and promote the Product in the Specialty in the Territory in the Field,
and to conduct the Valeant Activities and the activities of the institutional account management
team (pursuant to and subject to the terms of Section 4.1.5) for the Product in the Territory in the
Field in accordance with the terms and conditions of this Agreement. Notwithstanding the foregoing,
Dova retains and reserves the right for Dova and its Affiliates to promote the Product in the
Territory including in the Specialty. Valeant shall have no other rights relating to the Product,
except as specifically set forth in this Agreement and, without limiting the foregoing, except as
set out in Section 4.1.5, if agreed upon, Valeant shall have no right to, and shall not, conduct the
Valeant Activities for the Product outside the Specialty or outside the Territory or for use outside
the Field. Except to Affiliates of Valeant, Valeant's rights and obligations under this Section 2.1
are non-transferable, non-assignable, and non-delegable. Except to Affiliates of Valeant, Valeant
shall not subcontract the Valeant Activities with any Third Party (including any contract sales
force). Any obligation of Valeant under or pursuant to this Agreement may be satisfied, met or
fulfilled, in whole or in part, at Valeant's sole and exclusive option, either by Valeant or its
Affiliates. Valeant guarantees the performance of all actions, agreements and obligations to be
performed by its Affiliates under the terms and conditions of this Agreement. For clarity, Valeant
shall not have any license rights hereunder nor any rights to sublicense any rights hereunder.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 15 -->
2.2 Retention of Rights. Except with respect to the exclusive rights granted to Valeant to conduct
the Valeant Activities for the Product in the Specialty in the Territory in the Field pursuant to
Section 2.1 and, and if agreed upon, outside the Specialty in the Territory in the Field pursuant to
Section 4.1.5, Dova retains all rights in and to the Product. Without limiting the generality of the
foregoing (and without limiting Dova's retained rights set forth in Section 2.1), Dova specifically
retains the following rights (and Valeant and its Affiliates shall have no rights to the following,
except as set forth below in this Section 2.2):

2.2.1 responsibility for promoting the Product outside the Specialty;

2.2.2 responsibility for the manufacture and distribution of the Product, and any future development
of the Product;

2.2.3 responsibility for all decisions regarding regulatory submissions and, except as expressly set
forth herein, for interactions with any Governmental Authority, including but not limited to FDA,
with respect to the Product;

2.2.4 responsibility for final approval of all Product Materials content (including submission of
Promotional Materials to FDA's Office of Prescription Drug Promotion) with respect to the conduct of
the Valeant Activities for Product, except as expressly set forth herein;

2.2.5 selling and booking all sales of the Product; and

2.2.6 responsibility for handling all safety related activities related to Product as set forth in
ARTICLE 5 (including submitting all safety reports and interacting with Governmental Authorities
with respect thereto) and initiating and managing any Product recalls.

For clarity, except as provided in Sections 2.1 or 2.4, Valeant shall not acquire any license or
other intellectual property interest, by implication or otherwise, in any technology, Know-How or
other intellectual property owned or controlled by Dova or any of its Affiliates, and Dova is not
providing any such technology, Know-How or other intellectual property, or any assistance related
thereto, to Valeant for any use other than for the mutual benefit of the Parties as expressly
contemplated hereby.

2.3 Non-Competition; Non-Solicitation.

2.3.1 Non-Competition. (a) [***], neither Valeant nor its Affiliates shall, directly or indirectly,
[***] in the Territory other than the Product; provided that if the Agreement is terminated by Dova
pursuant to [***], then any Tail Period shall be immediately terminated if either Valeant or any of
its Affiliates, directly or indirectly, [***] in the Territory other than the Product during such
Tail Period. Notwithstanding the foregoing, this Section 2.3.1(a) shall not apply to any products
marketed, promoted, detailed, offered for sale, or sold by any business (or any portion thereof),
other Person, or group of Persons, [***].

(a) [***], neither Dova nor is Affiliates shall, directly or indirectly, [***]. Notwithstanding the
foregoing, this Section 2.3.1(b) shall not apply to any products marketed, promoted, detailed,
offered for sale, or sold by any business (or any portion thereof), other Person, or group of
Persons[***].

2.3.2 Non-Solicitation. [***], neither Valeant nor Dova (nor any of their respective Affiliates)
shall directly or indirectly solicit for hire or employee as an employee, consultant or otherwise
any of the other Party's professional personnel who have had direct involvement with the JSC, with
the Valeant Activities under this Agreement (which, in the case of Valeant, includes the Field Force
Personnel) or with Dova's commercialization activities for the Product, without the other Party's
prior written consent. Notwithstanding anything to the contrary, in no event shall the restrictions
set forth in this Section 2.3.2 apply to [***].

2.4 Dova Trademarks and Copyrights.

2.4.1 Valeant shall have the non-exclusive right to use the Dova Trademarks and Copyrights solely on
Product Materials in order to perform the Valeant Activities and solely in accordance with the terms
and conditions of this Agreement. Dova shall promptly notify Valeant of any updates or changes to
the Dova Trademarks and Copyrights on the Product Materials, and Valeant shall thereafter solely use
such updated Product Materials in performing its obligations under this Agreement. Valeant shall
promptly notify Dova upon becoming aware of any violation of this Section 2.4.1.

2.4.2 Valeant shall follow all instructions and guidelines of Dova (of which Dova has provided
Valeant copies) in connection with the use of any Dova Trademarks and Copyrights, and, if Dova
reasonably objects to the manner in which any such Dova Trademarks and Copyrights are being used,
Valeant shall cease the use of any such Dova Trademarks and Copyrights in such manner upon written
notice from Dova thereof. Without limiting the foregoing, Valeant shall also adhere to at least the
same quality control provisions as companies in the pharmaceutical industry adhere to for their own
trademarks and copyrights. In all cases, Valeant shall use the Dova Trademarks and Copyrights with
the necessary trademark (and copyright, as applicable) designations, and shall use the Dova
Trademarks and Copyrights in a manner that does not derogate from Dova's rights in the Dova
Trademarks and Copyrights. Valeant shall not at any time during the Term knowingly do or allow to be
done any act or thing which will in any way impair or diminish the rights of Dova in or to the Dova
Trademarks and Copyrights. All goodwill and

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 16 -->
improved reputation generated by Valeant's use of the Dova Trademarks and Copyrights shall inure to
the benefit of Dova, and any use of the Dova Trademarks and Copyrights by Valeant shall cease at the
end of the Term. Valeant shall have no rights under this Agreement in or to the Dova Trademarks and
Copyrights except as specifically provided herein. During the Term, Valeant will not contest the
ownership of the Dova Trademarks and Copyrights, their validity, or the validity of any registration
therefor. During the Term, Valeant will not knowingly register and/or use any marks (including in
connection with any domain names) that are confusingly similar to the Dova Trademarks and
Copyrights.

ARTICLE 3 JOINT STEERING COMMITTEE

3.1 Formation of the JSC. As soon as practicable, but no later than twenty (20) days after the
Effective Date, the Parties shall form a joint steering committee ("JSC") whose responsibilities
during the Term shall be to oversee the activities set forth in Section 3.3. The JSC shall consist
of three (3) representatives from each Party, each with suitable seniority and relevant experience
and expertise to enable such person to address matters falling within the purview of the JSC. From
time to time, each Party may change any of its representatives on the JSC by giving written notice
to the other Party. The meetings of the JSC will be chaired by a representative from Dova or
Valeant, on an alternating basis. The JSC shall determine a meeting schedule; provided, that, in any
event, meetings shall be conducted no less frequently than quarterly by teleconference or in person,
or as otherwise agreed by the Parties. In person meetings shall occur at such places as mutually
agreed by the Parties. Employees or consultants of either Party that are not representatives of the
Parties on the JSC may attend meetings of the JSC; provided, that such attendees (i) shall not
participate in the decision-making process of the JSC, and (ii) are bound by obligations of
confidentiality and non-disclosure equivalent to those set forth in ARTICLE 9.

3.2 Meetings and Minutes. Meetings of the JSC may be called by either Party on no less than thirty
(30) days' notice during the Term. Each Party shall make all proposals for agenda items and shall
provide all appropriate information with respect to such proposed items at least ten (10) days in
advance to the applicable meeting; provided that under exigent circumstances requiring input by the
JSC, a Party may provide its agenda items to the other Party within a shorter period of time in
advance of the meeting, or may propose that there not be a specific agenda for that particular
meeting, so long as the other Party consents to such later addition of such agenda items or the
absence of a specific agenda for such meeting, such consent not to be unreasonably withheld. The
chairperson shall prepare and circulate for review and approval of the Parties minutes of each
meeting within thirty (30) days after the meeting. Each Party shall bear its own costs for its
members to attend such meetings.

3.3 Purpose of the JSC. The purposes of the JSC shall be to, subject to Section 3.4:

3.3.1 provide a forum to discuss and coordinate the Parties' activities under this Agreement;

3.3.2 provide a forum to discuss and coordinate the promotion of the Product in the Territory,
including in and outside the Specialty;

3.3.3 provide a forum to discuss Product Materials (it being understood that the JSC shall not have
the right to approve such Product Materials);

3.3.4 facilitate the flow of information and otherwise promote the communications and collaboration
within and among the Parties relating to this Agreement and the promotion of the Product;

3.3.5 discuss planning and implementation of all Valeant Activities, including but not limited to
training of Sales Representatives and, if agreed upon, the activities of the institutional account
management team referred to in Section 4.1.5;

3.3.6 decide on the acceptable form of and review and discuss the Detail Reports and reports of Net
Sales;

3.3.7 decide on the acceptable form of and review and discuss the Compensation Reports and the
incentive compensation matters described in Section 4.1.3, including any applicable adjustments to
the Product-related sales goals and targets of the Sales Representatives;

3.3.8 review and discuss any matters brought to its attention by either Party's Alliance Manager;

3.3.9 review, discuss and decide on the Alternate Product described in Section 4.2.1(c) or any
additional product that may be Detailed by Valeant described in Section 4.2.1(d);

3.3.10 discuss the Promotional Materials matters described in Section 4.4.1(b);

3.3.11 discuss supply or distribution issues relating to the Product, such as any supply shortages;

3.3.12 discuss the pricing of the Product (provided that Dova shall have sole authority to determine
pricing of the Product); Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 17 -->
3.3.13 act as a first level escalation to address disagreements or disputes between the Parties;

3.3.14 form and oversee any sub-committee or working group in furtherance of the activities
contemplated by this Agreement;

3.3.15 decide on the acceptable form of and review and discuss the Compliance Reports; and

3.3.16 perform such other responsibilities as may be mutually agreed upon by the Parties in writing
from time to time; provided, however, for clarity the JSC shall have no authority to amend or modify
any provisions of this Agreement and no authority to waive or definitively interpret the provisions
of this Agreement.

3.4 Decision Making. Meetings of the JSC will occur only if at least one representative of each
Party is present at the meeting. Each Party shall have one (1) vote. The JSC will use good faith
efforts to reach consensus on all matters properly brought before it. If the JSC does not reach
unanimous consensus on an issue at a meeting or within a period of [***] thereafter, then the JSC
shall submit in writing the respective positions of the Parties to the Senior Officers of the
Parties. Such Senior Officers shall use good faith efforts to resolve promptly such matter, which
good faith efforts shall include at least one (1) teleconference between such Senior Officers within
[***] after the JSC's submission of such matter to them. Any final decision mutually agreed to in
writing by the Senior Officers shall be conclusive and binding on the Parties. If the Senior
Officers are not able to agree on the resolution of any such issue within [***] after such issue was
first referred to them, then (i) Valeant shall have the right to conclusively determine all matters
related to Valeant Activities and Detailing of the Product, including matters relating to the
institutional account manager team, the incentive compensation of the Sales Representatives and
targeting for Details, provided that such determination and any related activities comply with the
terms and conditions of this Agreement, and (ii) Dova shall have the right to conclusively determine
all other matters; provided, however, for clarity any such determination shall not amend, modify or
waive any provisions of this Agreement or definitively interpret the provisions of this Agreement.

3.5 Marketing Sub-Committee.

3.5.1 Promptly after the Effective Date, the JSC shall facilitate the formation of a Marketing
Sub-Committee comprised of an equal number of representatives from each Party. Such sub-committee
shall meet from time to time and discuss, among other things:

(a) the number of speaker programs for the Product to be conducted by Dova in each Calendar Year;

(b) the Promotional Materials and quantities thereof;

(c) the annual brand plan; and

(d) the annual conference strategy.

3.5.2 [***] shall constitute the "Speaker Program Threshold". If Dova wishes to conduct speaker
programs in any Calendar Year after 2018 in excess of the Speaker Program Threshold, then the
Parties shall meet, through the Marketing Sub-Committee, to discuss such excess speaker programs and
the costs thereof. If the Marketing Sub-Committee unanimously agrees that such excess speaker
programs should be conducted, then the following costs and expenses will be shared equally by the
Parties: (i) the costs and expenses associated with conducting the excess number of speaker programs
and (ii) the additional incremental costs and expenses associated with training necessary to address
the number of the speaker programs above and below the Speaker Program Threshold. In addition, if
the Parties unanimously agree that such excess speaker programs should be conducted, then, as a
condition of the payment by Valeant of its share of such costs, Valeant shall have the right to
review and approve (acting reasonably and in good faith) any such excess speaker programs, including
with respect to the number of speakers approved to speak on the Product as part of the speaker
programs, the rates paid to speakers at such speaker programs and the rules regarding attendees who
may attend such speaker programs (including frequency of attendance). For greater certainty, if
Valeant does not agree to conduct speaker programs above the Speaker Program Threshold, then the
costs described herein for any speaker programs conducted by Dova in excess of the Speaker Program
Threshold shall not be shared by the Parties, but shall be borne solely by Dova. In the event that
Dova incurs costs and expenses for which Valeant is responsible under this Section 3.5.2, Dova may
deduct such amounts from the payments due under Section 6.3 and shall include a description thereof
in the applicable report under Section 6.3.

ARTICLE 4 VALEANT ACTIVITIES FOR THE PRODUCT

4.1 Valeant Activities.

4.1.1 General. Valeant shall conduct the Valeant Activities for the Product in the Specialty in the
Field in the

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 18 -->
Territory in accordance with this Agreement.

4.1.2 Number of Sales Representatives. Without limiting the generality of the foregoing, [***]) and
continuing throughout the remainder of the Term, Valeant shall maintain at least one hundred (100)
Sales Representatives with responsibility to Detail the Product in the Specialty in the Territory.
Notwithstanding the above, the sole remedy of Dova for breach of this Section 4.1.2 shall be (i) the
adjustment to the promotion fee as set forth in Section 6.1.2 and (ii) the termination right set out
in Section 12.2.2.

4.1.3 Target Incentive Compensation. In addition, [***] and continuing throughout the remainder of
the Term, Valeant shall ensure the incentive compensation package for each Sales Representatives
requires that at least fifty percent (50%) of the target incentive compensation is derived from
achieving target sales of the Product. On at least a quarterly basis, the Parties will meet, through
the JSC, to review the target incentive compensation and the actual incentive compensation paid out
to the Sales Representatives to discuss, in good faith, any appropriate adjustments to the sales
targets and goals related to the Product (but not to the above-mentioned fifty percent (50%)
threshold of the target incentive compensation), with the intent of achieving, on average, an actual
payout to the Sales Representatives of 50% of their incentive compensation relating to sales of the
Product.

4.1.4 Alliance Managers. Each Party shall appoint a person who shall oversee interactions between
the Parties for all matters related to this Agreement, and any related agreements between the
Parties (each an "Alliance Manager"). The Alliance Managers shall endeavor to ensure clear and
responsive communication between the Parties and the effective exchange of information, and shall
serve as a single point of contact for all matters arising under this Agreement. The Alliance
Managers shall have the right to attend all JSC meetings and if applicable, subcommittee meetings as
non-voting participants and may bring to the attention of the JSC or, if applicable, subcommittee
any matters or issues either of them reasonably believes should be discussed, and shall have such
other responsibilities as the Parties may mutually agree in writing. Each Party may designate
different Alliance Mangers by notice in writing to the other Party.

4.1.5 Institutional Account Management Team. Upon prior mutual agreement of the Parties in writing,
Valeant may maintain a team of institutional account managers who, among other products, promote the
Product in the Territory at liver transplant centers and large academic institutions only, and for
purposes of this Section 4.1.5 only, both inside and outside the Specialty. Prior to any promotion
of the Product by any institutional account managers, the Parties will discuss in good faith (acting
reasonably) the number of institutional account managers that will promote the Product in the
Territory, the appropriate portion of such institutional account managers' target incentive
compensation to be derived from sales of the Product and the liver transplant centers or large
academic institutions such institutional account managers will be responsible for. Such
institutional account managers shall not be counted for purposes of determining the Quarterly
Average Sales Force Size or the Quarterly Minimum Details. The Parties agree that these
institutional account managers shall not be required to achieve any minimum number of Details. The
Parties agree that such team may be added or removed by the mutual written agreement of the Parties
without the need to amend this Agreement in accordance with Section 13.8.

4.2 Detailing.

4.2.1 Detail Requirements.

(a) Commencing promptly upon completion of training of the Field Force Personnel that are engaged in
Detailing the Product as described in Section 4.4.1 (but on the condition that Promotional Materials
have been approved and delivered), Valeant shall deploy its Field Force Personnel that are engaged
in Detailing to Detail the Product in accordance with the terms of this Agreement. Subject to
compliance with the terms of this Agreement, Valeant shall be responsible, in its discretion, acting
reasonably, for determining the manner in which it allocates and prioritizes the Details, provided
that, in so allocating the Details, Valeant shall take into consideration geographic territory,
frequency of calls, prescribing levels and other reasonable considerations. Except as set forth in
this Agreement, without the prior written consent of Dova (not to be unreasonably withheld, delayed
or conditioned), Valeant shall not conduct any Valeant Activities, other than Detailing, with
respect to the Product.

(b) [***]

(c) Beginning after [***], Valeant may initiate discussions with Dova, upon at least [***] notice to
Dova (which notice shall specify the proposed Alternate Product), regarding the potential
replacement of the Designated Product with an Alternate Product. Following such notice period the
Parties shall meet, through the JSC, and discuss in good faith (acting reasonably), for a period of
up to [***], the potential replacement of the Designated Product with the Alternate Product. If the
Parties agree on an Alternate Product, then the Parties shall make such agreement in writing and
thereafter such Alternate Product shall be the Designated Product for purposes of this Agreement. If
the Parties cannot agree on the Alternate Product during such period, then Valeant may give to Dova
a written notice (the "Alternate Product Notice") designating the proposed Alternate Product as the
Alternate Product and, effective [***] after the Alternate Product Notice, such designated Alternate
Product shall be the Designated Product for purposes of this Agreement; provided however that,
notwithstanding the foregoing, Dova shall have the right to terminate this Agreement upon [***]
written notice to Valeant after the Alternate Product Notice, provided further that if the Alternate
Product is being proposed by Valeant as a result of an anticipated or the existence of a generic
version of the

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 19 -->
Designated Product, a decision, judgment, ruling or other requirement of a Government Authority,
including the FDA relating to or impacting the Designated Product in the Territory, a material
safety concern regarding the Designated Product or a mandatory recall or withdrawal of the
Designated Product, then Dova shall have no right to terminate this Agreement pursuant to this
Section 4.2.1(c).

(d) [***]

(e) Notwithstanding the terms of this Section 4.2.1, Valeant shall have the right, from time to
time, during the Term, to include in the incentive compensation package of all or some of the Sales
Representatives a spiff, spiv or other similar incentive bonus that is based on [***], provided that
the actual, maximum payout from such incentive bonuses does not exceed, in the aggregate, an amount
equal to [***] for each Sales Representative for each Calendar Quarter. Any such spiff, spiv or
other similar incentive bonus shall not be included in the calculation of the applicable Sales
Representatives incentive compensation package in determining Valeant's compliance with the terms of
Section 4.1.3.

4.2.2 Records and Reports.

(a) Valeant shall keep accurate and complete records, consistent with pharmaceutical industry
standards, of each Detail and its obligations hereunder in connection therewith. Such records shall
be kept for the longer of (i) [***] after the end of the Calendar Year to which they relate and (ii)
such period of time as required by Applicable Laws. Within [***] following the end of each Calendar
Quarter during the Term, Valeant shall provide Dova with a written report (each a "Detail Report"),
setting out (i) the quarterly average number of Sales Representatives during such Calendar Quarter
(calculated by taking the sum of the number of Sales Representatives employed by Valeant (or its
affiliates) that have incentive compensation packages that comply with the terms of Section 4.1.3 on
each Business Day of the Calendar Quarter divided by the number of Business Days in such Calendar
Quarter) (the "Quarterly Average Sales Force Size"), and (ii) the aggregate actual number of Details
for the Product made by its Sales Representatives during such Calendar Quarter, and the number of
Details broken down by the name of the Target Professionals,. Through the JSC, the Parties shall
agree on a mutually acceptable form of Detail Report.

(b) Within [***] following the end of each Calendar Quarter during the Term, Valeant shall provide
Dova with a written report (each a "Compensation Report"), which describes (i) the details of the
incentive compensation package of each Sales Representative as it relates to the Product and the
Designated Product (or Alternate Product, as the case may be) (but, in the case of the Designated
Product or Alternate Product, such details shall be limited to information regarding what portion of
the Sales Representatives' target incentive compensation package is derived from achieving sales
targets or goals of the Designated Product (or Alternate Product) , but shall not include any sales
targets or goals for the Designated Product (or Alternate Product)), and (ii) the actual incentive
compensation payouts for each Sales Representatives as described in Section 4.1.3. Through the JSC,
the Parties shall agree on a mutually acceptable form of Compensation Report.

(c) Within [***] following the end of each Calendar Quarter during the Term, Valeant shall provide
Dova with a written report (each a "Compliance Report"), which sets out a summary of Valeant's
compliance monitoring and auditing of the Field Force Personnel that are engaged in Detailing (as
such monitoring is further described in Section 4.5.1(b)), a summary of any compliance-related
disciplinary actions relating to any Field Force Personnel that are engaged in Detailing and any
associated remedial actions, a summary of all compliance investigations conducted by Valeant of any
of the Field Force Personnel that are engaged in Detailing and any associated outcome, and, for the
fourth Calendar Quarter only, a summary of the compliance-related training (including a reasonable
description of each training topic) received by each Field Force Personnel that are engaged in
Detailing during the Calendar Year. Through the JSC, the Parties shall agree on a mutually
acceptable form of Compliance Report.

4.3 Compliance with Applicable Law.

4.3.1 In conducting the Valeant Activities hereunder, Valeant shall, and shall require all Field
Force Personnel to, comply in all respects with Applicable Laws. In addition, Dova shall, and shall
require all of its sales representatives to, comply in all respects with Applicable Laws in
connection with its promotion of the Product in the Territory.

4.3.2 Neither Valeant nor Field Force Personnel shall offer, pay, solicit or receive any
remuneration to or from Target Professionals, in order to induce referrals of or purchase of the
Product.

4.3.3 In performing the activities contemplated by this Agreement, neither Valeant nor Field Force
Personnel shall make any payment, either directly or indirectly, of money or other assets to
government or political party officials, officials of international public organizations, candidates
for public office, or representatives of other businesses or persons acting on behalf of any of the
foregoing where such payment would constitute violation of any Applicable Law. In addition, Valeant
shall not make any payment either directly or indirectly to officials if such payment is for the
purpose of unlawfully influencing decisions or actions with respect to the subject matter of this
Agreement.

4.3.4 No employee of Valeant or its Affiliates shall have authority to give any direction, either
written or oral,

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 20 -->
relating to the making of any commitment by Dova or its agents to any Third Party in violation of
terms of this or any other provision of this Agreement

4.3.5 Neither Valeant nor Dova shall undertake any activity under or in connection with this
Agreement which violates any Applicable Law.

4.3.6 Valeant's or Dova's material failure to abide by the provisions of this Section 4.3 shall be
deemed a material breach of this Agreement by Valeant or Dova (as the case may be) and subject to
the terms of Section 12.2 hereof.

4.3.7 Dova shall ensure that any patient assistance program used in connection with the Product (and
the services performed thereby in connection with the Product) shall be operated in accordance with
Applicable Law. Notwithstanding the immediately preceding sentence, Dova shall have no liability
with respect to any breach or non-compliance with Applicable Law relating to any patient assistance
program used in connection with the Product to the extent caused by the act or omission of any Field
Force Personnel, which act or omission is not in compliance with the terms of this Agreement,
Applicable Law or instructions of Dova.

4.3.8 Dova shall ensure that government-insured patients do not receive co-pay support from Dova
with respect to the Product.

4.3.9 Dova shall ensure that its donations to, and interactions with, any 501(c)(3) charitable
foundation that provides co-pay assistance to government-insured patients with respect to the
Product are in full compliance with all Applicable Laws.

4.3.10 If, during the Term, Valeant becomes aware of a material violation or failure to comply with
Applicable Law or the terms of this Agreement by a member of the Field Force Personnel that are
engaged in Detailing, it shall promptly, but no later than two (2) Business Days after it becomes
aware, notify Dova of such violation and, as promptly as possible thereafter, shall notify the steps
it has taken or intends to take to remediate such violation.

4.3.11 Compliance Managers. As soon as practicable, but no later than thirty (30) days after the
Effective Date, each Party shall appoint a representative to act as its compliance manager under
this Agreement, each of which is routinely responsible for advising such Party on compliance matters
and has suitable seniority and other relevant experience and expertise (each, a "Compliance
Manager"). From time to time, each Party may change its Compliance Manager by giving written notice
to the other Party. The Compliance Managers shall serve as a key point of contact between the
Parties for compliance-related matters. Each Compliance Manager shall facilitate the resolution of
any compliance issue with the Compliance Manager of the other Party. The Compliance Managers will
use good faith efforts to reach consensus on all compliance matters. If the Compliance Managers do
not reach consensus on an issue promptly, then such issue shall be submitted to dispute resolution
process described in Section 13.6. Upon the reasonable request of Dova from to time, Valeant shall
deliver to Dova copies of Valeant's compliance program policies and compliance training materials
which are applicable to the Field Force Personnel's promotion of the Product. Other than as
expressly stated herein, Valeant shall not be required to modify its compliance policies or
practices in connection with the compliance-related provisions herein.

4.4 Field Force Personnel Training; Product Materials.

4.4.1 Training, Training Materials and Promotional Materials.

(a) Subject to the terms of this Section 4.4.1, Dova shall prepare and control the content of (i)
all Product training materials for Field Force Personnel (the "Product Training Materials") and (ii)
all Product marketing and educational materials (the "Promotional Materials") (the Product Training
Materials and the Promotional Materials, collectively, the "Product Materials"). Dova shall be
solely responsible for ensuring that the Product Materials prepared and approved by it are in
compliance with the Regulatory Approval for the Product, the Product Labeling and Applicable Law.
Once approved by Dova, the content of the Product Materials shall be provided by Dova to Valeant in
advance of the Valeant Activates to allow for Valeant to review such content and provide verbal
feedback to Dova in advance of use of the Product Materials. Within [***] of receipt of such Product
Materials, Valeant shall verbally provide to Dova any comments and/or proposed revisions to such
Product Materials, which comments and revisions Dova shall reasonably consider so long as Dova deems
such suggestions are acceptable in the promotion of the Product; provided that in any event, to the
extent that Dova reasonably believes that such changes are not in compliance with Applicable Law,
the Regulatory Approval for the Product or the applicable Product Labeling, then Dova shall not be
required to incorporate any such suggestions from Valeant in the Product Materials. In the event of
any disagreement between the Parties regarding any feedback received from Valeant with respect to
the Product Materials, Dova shall have the right to conclusively determine such matter. If Valeant
has provided comments to Dova on the Product Materials and Dova accepts some or all of such
comments, then, once revised, Dova shall provide to Valeant the revised versions of such Product
Materials for further review by Valeant, in accordance with the terms and timelines of this Section
4.4.1(a) above. Valeant shall use only Product Materials approved by Dova in the performance of
Valeant Activities under this Agreement; provided, however, that Valeant shall not be required to
use any Product Materials that have not been approved by Valeant or which have not incorporated
comments

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 21 -->
provided by Valeant and nothing herein shall require Valeant to use all Product Materials created or
prepared by Dova and Valeant reserves the right not to use certain Product Materials. The content of
Product Materials shall not be modified or changed by Valeant or Field Force Personnel at any time
without the prior written approval of Dova in each instance. Dova shall be responsible for the costs
and expenses of creation and development of the Product Materials and Valeant shall be responsible
for the costs and expense of reproduction, printing and delivery of the Product Materials to and for
Valeant. The Parties will coordinate the production and delivery of Product Materials to allow
sufficient internal and field force review time to accommodate scheduled training meetings and
distribution to Field Force Personnel that are engaged in Detailing. In the event that Dova incurs
costs and expenses for which Valeant is responsible under this Section 4.4.1, Dova may deduct such
amounts from the payments due under Section 6.3 and shall include a description thereof in the
applicable report under Section 6.3. Promptly after the Effective Date, the Parties will collaborate
to finalize the Product Materials in accordance with this Section 4.4.1(a), as soon as reasonably
practical.

(b) Commencing with the Promotional Materials to be used for Calendar Year 2019 and for the
remainder of the Term, Valeant and Dova shall meet to discuss the content of such Promotional
Materials in order to ensure that such Promotional Materials appropriately address any messaging
that may be desired for the Target Professionals in the Specialty. Such discussions may take place
in the forum of the JSC. Dova shall in good faith reasonably consider all comments and suggestions
of Valeant regarding the Promotional Materials.

(c) Promptly after the Effective Date, the Parties will collaborate to plan and schedule training
for the Sales Representatives at a mutually acceptable time(s) and date(s), including a launch
meeting for the Sales Representatives at a mutually acceptable location. Dova will lead such initial
training and Valeant shall cooperate with any reasonable requests of Dova in order to support such
training. The costs and expenses of such launch meeting will be shared equally by the Parties, other
than travel and lodging for the Sales Representatives which shall be the responsibility of Valeant.
All other training costs and expenses shall be the responsibility of Valeant. After the initial
training, the Parties will collaborate to provide additional training at such frequency, times and
places as the circumstances warrant and the Parties mutually agree. Valeant shall have the right,
but not the obligation, to conduct such additional training itself, provided that the Valeant
trainers have been trained by Dova, and provided further that Dova shall have the right to attend
such training upon reasonable notice by Valeant to Dova. Valeant will certify in writing to Dova
that all Field Force Personnel have completed the training described in this Section 4.4.1(b).

(d) Valeant and all Field Force Personnel that are engaged in Valeant Activities shall comply with
the applicable provisions of the Code, and shall be trained on Valeant's compliance policies,
including those that are consistent with the applicable provisions of Sec. 1128B(b) of the Social
Security Act and the American Medical Association Ethical Guidelines for Gifts to Physicians from
Industry (which such training may have been accomplished prior to the Term), prior to commencing any
Valeant Activities. Valeant agrees that it shall train any employee or agent of Valeant who is
involved in performing the activities contemplated by this Agreement on anti-corruption and
anti-bribery at its own expense.

(e) Field Force Personnel that are engaged in Detailing shall conduct the Valeant Activities only
after having undergone the training described in this Section 4.4 and, without limiting the
foregoing, no Field Force Personnel member shall Detail the Product without having undergone such
training. Subject to the foregoing, Valeant shall have the responsibility for on- going training of
its Field Force Personnel that are engaged in Detailing in accordance with customary practice in the
pharmaceutical industry.

4.4.2 Ownership of Product Materials. As between the Parties, Dova shall own all right, title and
interest in and to any Product Materials (and all content contained therein) and any Product
Labeling (and all content contained therein), including applicable copyrights and trademarks (other
than any name, trademark, trade name or logo of Valeant or its Affiliates that may appear on such
Product materials or Product Labeling), and to the extent Valeant (or any of its Affiliates) obtains
or otherwise has a claim to any of the foregoing, Valeant hereby assigns (and shall cause any
applicable Affiliate to assign) all of its right, title and interest in and to such Product
Materials (and content) and Product Labeling (and content) (other than any name, trademark, trade
name or logo of Valeant or its Affiliates that may appear on such Product materials or Product
Labeling) to Dova and Valeant agrees to (and shall cause its applicable Affiliate to) execute all
documents and take all actions as are reasonably requested by Dova to vest title to such Product
Materials (and content) and Product Labeling (and content) in Dova (or its designated Affiliate).

4.5 Provisions Related to Field Force Personnel.

4.5.1 Activities of Field Force Personnel. Valeant hereby agrees and acknowledges that the following
shall apply with respect to itself and the Field Force Personnel that are engaged in Detailing:

(a) Valeant shall instruct and cause the Field Force Personnel that are engaged in Detailing to use
only the Product Labeling and, subject to the terms of Section 4.4, Product Materials approved by
Dova for the conduct of the Valeant Activities for the Product and consistent with Applicable Laws.
Valeant shall instruct the Field Force Personnel that are engaged in Detailing to, and will monitor
the Field Force Personnel that are engaged in Detailing to ensure that such Field Force Personnel,
limit their claims of efficacy and safety for the Product to those claims which are consistent with
and do not exceed the Product Labeling and any Promotional Materials.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 22 -->
(b) Valeant shall instruct the Field Force Personnel that are engaged in Detailing to conduct the
Valeant Activities for the Product, and will monitor and audit (in accordance with Valeant's
standard practice) the Field Force Personnel that are engaged in Detailing so that such personnel
conduct the Valeant Activities for the Product in adherence in all respects with Applicable Laws.

(c) Valeant shall instruct the Field Force Personnel that are engaged in Detailing regarding
provisions of this Agreement applicable to Details of the Product, including Section 4.2 and this
Section 4.5.1.

(d) Valeant acknowledges and agrees that Dova will not maintain or procure any worker's
compensation, healthcare, or other insurance for or on behalf of the Field Force Personnel, all of
which shall be Valeant's sole responsibility.

(e) Valeant acknowledges and agrees that all Field Force Personnel are employees of Valeant and are
not, and are not intended to be treated as, employees of Dova or any of its Affiliates, and that
such individuals are not, and are not intended to be, eligible to participate in any benefits
programs or in any "employee benefit plans" (as such term is defined in section 3(3) of ERISA) that
are sponsored by Dova or any of its Affiliates or that are offered from time to time by Dova or its
Affiliates to their own employees. All matters of compensation, benefits and other terms of
employment for any such Field Force Personnel shall be solely a matter between Valeant and such
individual. Dova shall not be responsible to Valeant, or to the Field Force Personnel, for any
compensation, expense reimbursements or benefits (including vacation and holiday remuneration,
healthcare coverage or insurance, life insurance, severance or termination of employment benefits,
pension or profit-sharing benefits and disability benefits), payroll-related taxes or withholdings,
or any governmental charges or benefits (including unemployment and disability insurance
contributions or benefits and workmen's compensation contributions or benefits) that may be imposed
upon or be related to the performance by Valeant or such individuals of this Agreement, all of which
shall be the sole responsibility of Valeant, even if it is subsequently determined by any
Governmental Authority that any such individual may be an employee or a common law employee of Dova
or any of its Affiliates or is otherwise entitled to such payments and benefits.

(f) Valeant shall be solely responsible for the acts or omissions of the Field Force Personnel that
are not in compliance with Applicable Law and the terms of this Agreement while performing any of
the activities under this Agreement. Valeant shall be solely responsible and liable for all
probationary and termination actions taken by it, as well as for the formulation, content and
dissemination (including content) of all employment policies and rules (including written
probationary and termination policies) applicable to its employees.

4.5.2 Termination of Employment; Cessation of Valeant Activities. If any Field Force Personnel
leaves the employ of Valeant (or any of its Affiliates), or otherwise ceases to conduct the Valeant
Activities for the Product, Valeant shall, to the extent consistent with, and in a manner similar
to, its practices with respect to departures of the sales representatives or other field force
personnel, as applicable, promoting, marketing or detailing other products for Valeant, account for,
and shall cause such departing Field Force Personnel to return to Valeant and delete from his/her
computer files (to the extent such materials or information have been provided in, or converted
into, electronic form) all materials relating to the Product that have been provided to such
individual, including the Product Materials and account level information, including all copies of
the foregoing.

4.5.3 Discipline. If Dova has a reasonable basis for believing any member of the Field Force
Personnel that are engaged in Detailing has violated any Applicable Laws, or failed to comply with
this Agreement, then Dova shall notify Valeant of the alleged violation and Valeant shall promptly
investigate the matter and, if the allegation turns out to be true, shall take the appropriate
remedial action. Subject to the foregoing, Valeant shall be solely responsible for taking any
disciplinary actions in connection with its Field Force Personnel that are engaged in Detailing. If,
at any time, Dova has any other compliance-related concerns regarding any Field Force Personnel
Detailing, Dova's Compliance Manager shall notify Valeant's Compliance Manager of such concerns in
writing and the Compliance Managers will discuss and resolve such matters pursuant to Section 4.3.9.

4.6 Responsibility for Valeant Activity Costs and Expenses. Other than as expressly set out herein,
Valeant shall be solely responsible for any and all costs and expenses incurred by Valeant or any of
its Affiliates in connection with the conduct of the Valeant Activities for the Product hereunder,
including all costs and expenses in connection with Sales Representatives, including salaries,
travel expenses and other expenses, credentialing, licensing, providing benefits, deducting federal,
state and local payroll taxes, and paying workers' compensation premiums, unemployment insurance
contributions and any other payments required by Applicable Laws to be made on behalf of employees.

4.7 Data Sharing. Dova shall provide to Valeant certain information relating to the sale,
commercialization, marketing and promotion of the Product, as may be mutually agreed by the Parties
from time to time, for use by Valeant and the Field Force Personnel in connection with the Valeant
Activities. Such information may include data from the applicable reimbursement HUB, specialty data
aggregator, market research, and market access contracting and Third Party-provided brand
performance data ([***]). The timing of the delivery of such information shall be mutually agreed
upon by the Parties, acting reasonably.

ARTICLE 5 REGULATORY, SAFETY AND SURVEILLANCE, COMMERCIAL MATTERS

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 23 -->
5.1 Dova Responsibility. As between the Parties, except as expressly set out herein, all regulatory
matters regarding the Product shall be the responsibility of Dova, including responsibility for all
communications with Governmental Authorities, including but not limited to FDA, related to the
Product, and Dova shall have sole responsibility to seek and/or obtain any necessary approvals of
any Product Labeling and the Promotional Materials used in connection with the Product, and for
determining whether the same requires approval. As between the Parties, Dova shall be responsible
for any reporting of matters regarding the manufacture, sale or promotion of the Product (including
Adverse Events) to or with the FDA and other relevant regulatory authorities, in accordance with
Applicable Laws. Dova shall maintain, at its cost, the Regulatory Approvals for the Product and
shall comply with all Applicable Law relevant to the conduct of Dova's business with respect to the
Product or pursuant to this Agreement, including, without limitation, all applicable requirements
under the Act.

5.2 Valeant Involvement. Except as expressly permitted herein, Valeant shall not, without Dova's
prior written consent, correspond or communicate with the FDA or with any other Governmental
Authority concerning the Product, or otherwise take any action concerning any Regulatory Approval or
other authorization under which the Product is marketed or sold. If not prohibited by any Government
Authority or Applicable Law, Valeant shall provide to Dova, promptly upon receipt, copies of any
communication from the FDA or other Governmental Authority related to the Product. If not prohibited
by any Government Authority or Applicable Law, Dova has the right to review and comment on Valeant's
draft responses to any Governmental Authorities relevant to Detail of the Product prior to Valeant's
issuance of such response; and Valeant agrees to consider any comments or suggestions from Dova in
good faith.

5.3 Inspections.

5.3.1 If not prohibited by any Government Authority or Applicable Law, Valeant shall notify Dova
immediately upon receipt of any notice of inspection or investigation by any Governmental Authority
related to or that Valeant reasonably believes may impact any aspect of the Valeant Activities. If
not prohibited by any Government Authority or Applicable Law, Dova shall have the right to have a
representative present at any such portion of the inspection involving any Valeant Activities. In
such cases, Valeant shall (i) keep Dova fully informed of the progress and status of any such
inspection or investigation, (ii) prior to undertaking any action pursuant to this Section 5.3.1,
notify Dova of the inspection or investigation, and disclose to Dova in writing the Governmental
Authorities' assertions, findings and related results of such inspection or investigation pertaining
to the Valeant Activities, and (iii) provide full disclosure to Dova with respect to any action
undertaken or proposed to be undertaken pursuant to this Section 5.3.1 prior to acting as it
pertains to the Valeant Activities. In addition, if such findings or the Governmental Authority
requests or suggests that Valeant should change any aspect of the Valeant Activities, the Parties
will work together to make any such modification; provided, however, that notwithstanding anything
to the contrary herein, Valeant will not be required to engage in any Valeant Activities to the
extent any finding or Government Authority has requested or suggested that Valeant may not engage in
such activity.

5.3.2 If not prohibited by any Government Authority or Applicable Law, Dova shall notify Valeant
immediately upon receipt of any notice of inspection or investigation by any Governmental Authority
related to or that Dova reasonably believes may impact the Valeant Activities. In such cases, Dova
shall (i) keep Valeant fully informed of the progress and status of any such inspection or
investigation, (ii) disclose to Valeant in writing the Governmental Authorities' assertions,
findings and related results of such inspection or investigation pertaining to the Product or its
promotion, and (iii) provide full disclosure to Valeant with respect to any action undertaken or
proposed to be undertaken pursuant to this Section 5.3.2 prior to acting as it pertains to the
Valeant Activities. In addition, if such findings or the Governmental Authority requests or suggests
that Valeant should change any aspect of the Valeant Activities, the Parties will work together to
make any such modification; provided, however, that notwithstanding anything to the contrary herein,
Valeant will not be required to engage in any Valeant Activities to the extent any finding or
Government Authority has requested or suggested that Valeant may not engage in such activity.

5.4 Pharmacovigilance. Subject to the terms of this Agreement, as soon as practicable following the
Effective Date (but in no event later than [***]), Dova and Valeant (under the guidance of their
respective pharmacovigilance departments, or equivalent thereof) shall identify and finalize the
responsibilities the Parties shall employ to protect patients and promote their well- being in a
separate safety data exchange agreement ("Pharmacovigilance Agreement"). These responsibilities
shall include mutually acceptable guidelines and procedures for the receipt, investigation,
recordation, communication and exchange (as between the Parties) of safety information such as
Adverse Events, lack of efficacy, misuse/abuse, and any other information concerning the safety of
the Product. Such guidelines and procedures will be in accordance with, and enable the Parties and
their Affiliates to fulfill, regulatory reporting obligations to Governmental Authorities. The
Pharmacovigilance Agreement shall provide that: (i) Dova shall be responsible for all
pharmacovigilance activities regarding the Product, including signal detection, medical
surveillance, risk management, medical literature review and monitoring, Adverse Event reporting and
responses to Governmental Authority requests or enquiries, and shall provide information related
thereto to Valeant, and (ii) in the event Valeant receives safety information regarding the Product,
or information regarding any safety-related regulatory request or inquiry, Valeant shall notify Dova
as soon as practicable, but, in any event, within the timelines set forth in the Pharmacovigilance
Agreement.

5.5 Unsolicited Requests for Medical Information. Valeant shall direct to Dova any unsolicited
requests for off-label medical information from health care professionals with respect to the
Product promptly following receipt by Valeant (but in no

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 24 -->
event later than [***] after receipt). Dova shall, within [***] following receipt of any such
request from Valeant, address any such requests directly.

5.6 Recalls and Market Withdrawals. As between the Parties, Dova shall have the sole right to
determine whether to implement, and to implement, a recall, field alert, withdrawal or other
corrective action related to the Product. Dova shall bear the cost and expense of any such recall,
field alert, withdrawal or other corrective action. Each Party shall promptly (but in any case, not
later than [***]) notify the other Party in writing of any order, request or directive of a court or
other Governmental Authority to recall or withdraw the Product.

5.7 Certain Reporting Responsibilities. Notwithstanding the foregoing provisions of this ARTICLE 5,
each Party shall be responsible for its own federal, state and local government pricing reporting
and payment transparency reporting in the Territory arising from its Product promotional activities
and related expenditures pursuant to Applicable Law. It is the intention of the Parties that any
payments or transfer of value by a Party as it relates to the Product shall constitute transfers of
value by that Party and such Party shall be responsible for the reporting described in the
immediately preceding sentence. However, if a Party is deemed to have provided any payments or
transfers of value to a Third Party on behalf of the other Party as it relates to the Product, then
such Party shall provide to the other Party, in a format reasonably acceptable to such other Party,
the data and other information on a timely basis (i.e., in the case of manual reporting of such data
and other information, within [***] following the end of each Calendar Quarter, and, in the case of
automated reporting of such data and other information, on a periodic basis during each Calendar
Quarter as reasonably requested by such other Party) for such other Party's reporting under the
Physician Payments Sunshine Act and other Applicable Laws.

5.8 Booking of Sales Revenues. Dova shall retain ownership of the rights to the Product and record
on its books all revenues from sales of the Product. Dova shall be exclusively responsible for
accepting and filling purchase orders, billing, and returns with respect to the Product. If Valeant
receives an order for the Product, it shall promptly transmit such order to Dova (or its designee)
for acceptance or rejection. Dova shall have sole responsibility for shipping, distribution and
warehousing of Product, and for the invoicing and billing of purchasers of the Product and for the
collection of receivables resulting from the sales of the Product in the Territory.

5.9 Returns. Valeant is not authorized to accept any Product returns. Valeant shall advise any
customer who attempts to return any Product to Valeant (or its Affiliates) that such Product must be
shipped by the customer to the facility designated by Dova from time to time (and in accordance with
other instructions provided by Dova). Dova shall provide to Valeant written instructions as to how
Valeant should handle any Product that is actually physically returned to Valeant. Valeant shall
take no other actions with respect to such return without the prior written consent of Dova.

5.10 Manufacturing; Distribution; Marketing. Dova shall have the sole authority, at its cost, to
manufacture, package, label, warehouse, sell and distribute the Product in the Territory. Dova shall
use commercially reasonable efforts to cause sufficient quantities of the Product to be available in
inventory to promptly fill orders throughout the Territory and otherwise meet the forecasted demand
for the Product in the Territory. If, despite such efforts, there is insufficient supply of Product
to meet demand, then Dova shall use commercially reasonable efforts to promptly address such
insufficiency. Dova shall contractually require (and shall use commercially reasonable efforts to
enforce such contractual provisions) that all Product is manufactured, shipped, sold and distributed
in accordance with all Product specifications and all Applicable Law and that its contract
manufacturers and/or suppliers of Product operate their facilities in accordance with Applicable
Law. Dova shall ensure that all Product Labeling complies with the applicable Regulatory Approval
for the Product and Applicable Law. Other than as set forth in this Agreement, Dova shall be
responsible for all marketing of the Product in the Territory, provided that Dova shall continue to
invest in marketing that is targeted towards the Specialty.

ARTICLE 6 FINANCIAL PROVISIONS

6.1 Promotion Fee.

6.1.1 Calculation of Promotion Fee. Commencing with the Calendar Quarter commencing on October 1,
2018, as consideration for the Valeant Activities performed by Valeant, Dova shall pay Valeant a
promotion fee based on annual Net Sales during the Term, calculated as follows:

(a) For any portion of Net Sales up to and equal [***] in a Calendar Year, an amount equal to [***]
of such portion of Net Sales;

(b) For any portion of Net Sales in excess of [***] and up to and equal [***] in a Calendar Year, an
amount equal to [***] of such portion of Net Sales; and

(c) For any portion of Net Sales in excess of [***] in a Calendar Year, [***] of such portion of Net
Sales.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 25 -->
6.1.2 Adjustment of Promotion Fee. The percentages set forth in Section 6.1.1 [***] shall each be
referred to as an "Applicable Percentage".

(a) If the aggregate actual number of Details for the Product made by the Sales Representatives for
a Calendar Quarter is less than the Quarterly Minimum Details for such Calendar Quarter, then in
calculating the promotion fee due under Section 6.1.1, the Applicable Percentage for such Calendar
Quarter shall be reduced to a new percentage equal to [***].

(b) If the Quarterly Average Sales Force Size is less than [***] Sales Representatives for an
applicable Calendar Quarter, then in calculating the promotion fee due under Section 6.1.1, the
Applicable Percentage for such Calendar Quarter shall be reduced to a new percentage equal to [***].

(c) In the event that subsections (a) above and (b) above are both applicable in an applicable
Calendar Quarter, then the Applicable Percentage shall be reduced to a new percentage equal to the
lower of the percentages calculated under subsections (a) and (b).

6.2 Milestone Payment. In addition to the promotion fee above and as additional consideration for
the performance of such Valeant Activities, Dova shall pay to Valeant a milestone payment in the
amount of Two Million Five Hundred Thousand Dollars ($2,500,000) when aggregate Net Sales in a
Calendar Year first reach [***], payable within [***] after the end of the Calendar Quarter in which
such Net Sales are reached. For clarity, such payment shall be made only once during the Term.

6.3 Reports; Payments.

6.3.1 Quarterly Reports and Payments. Within [***] after the end of each Calendar Quarter during the
Term, Dova shall provide to Valeant a written report setting forth in reasonable detail the
calculation of the Net Sales for such Calendar Quarter and the promotion fee payable in respect of
such Net Sales in accordance with Section 6.1, including (i) the number of units of the Product
shipped from Specialty Pharmacies to patients in the Territory during such Calendar Quarter,
together with an itemized list of such units by Target Professional writing the applicable
prescription, (ii) the number of units of the Product shipped from Specialty Pharmacies to patients
in the Territory based on prescriptions written by the Specialty only during such Calendar Quarter,
together with an itemized list of such units by Target Professional in the Specialty writing the
applicable prescription (iii) the number of units per shipment of Products (and the number of such
shipments) sold by Dova (or its Affiliates or Intermediaries) to the Non-Retail Institutions during
such Calendar Quarter, including details respecting which shipments are based on initial orders from
such Non-Retail Institutions and which Non-Retail Institutions ordered the Product, (iv) the number
of units of the Product shipped from Retail Pharmacies to patients in the Territory during such
Calendar Quarter, together with an itemized list of such units by Target Professional writing the
applicable prescription, (v) the number of units shipped from Retail Pharmacies to patients based on
prescriptions written by the Specialty in the Territory during such Calendar Quarter, together with
an itemized list of such units by Target Professional in the Specialty writing the applicable
prescription, (vi) the applicable Specialty Fraction for such Calendar Quarter, (vii) the WAC
applicable to each dispensable unit, (ix) the Gross to Net Fraction for the applicable period,
together with the details respecting the calculation thereof (including details regarding each of
the categories of the deductions to gross sales for such Calendar Quarter). Within sixty (60) days
after the end of each Calendar Quarter during the Term, Dova shall pay to Valeant the undisputed
portion of the promotion fee payable in respect of such Net Sales in accordance with Section 6.1. If
this Agreement terminates or expires during a Calendar Quarter, the promotion fee payable to Valeant
under Section 6.1 will be calculated only on the Net Sales that occurred during such Calendar
Quarter prior to the effective date of such termination or expiration.

6.3.2 Monthly Reports. Within fifteen (15) days of the end of each month within each Calendar
Quarter, Dova shall provide to Valeant a written report setting forth Dova's good faith estimate of
the Net Sales and the estimated promotion fee payable in respect of such Net Sales for each of such
calendar month and the Calendar Quarter-to-date period, together with its good faith estimates of
each of the items described in Section 6.3.1 above (assuming there will be no adjustments made to
the promotion fee pursuant to Section 6.1.2). The Parties acknowledge and agree that the monthly
reports will only set forth Dova's good faith estimates of the items contained therein and are being
provided to Valeant for information purposes only and shall not be determinative of the any amounts
due hereunder.

6.3.3 Disputes. Promptly upon receipt of the quarterly or monthly reports described in this Section
6.3, Valeant shall review such reports and, in the event that Valeant disputes any of the items
described in such report, Valeant shall promptly notify Dova of any such disputes. The Parties shall
meet promptly thereafter to attempt to resolve such disputes.

6.3.4 Data for Net Sales. During the Term, in the event Dova (or its Affiliates) enters into
agreements with any specialty pharmacies (other than Non-Retail Institutions) in order to sell
and/or ship units of the Product directly to such specialty pharmacies, Dova shall use commercially
reasonable efforts to include in the agreements provisions relating to the supply of data by such
specialty pharmacies to Dova that can be used to support the calculation of Net Sales or shall use
commercially reasonable efforts to enter into separate data agreements with such specialty
pharmacies that provide for the supply of data by such specialty pharmacies to Dova that can be used
to support the calculation of Net Sales.

6.3.5 Manner of Payment. All payments under this Agreement shall be made in US Dollars by wire
transfer or

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 26 -->
ACH to a bank account designated in writing by Valeant or Dova, as applicable, which shall be
designated at least five (5) Business Days before such payment is due.

6.3.6 Late Payments. If Valeant does not receive payment of any sum due to it on or before the due
date, simple interest shall thereafter accrue on the sum due to Valeant from the due date until the
date of payment at the Prime Rate plus [***] or the maximum rate allowable by Applicable Law,
whichever is less; provided, however, if it is discovered that any payment is past due as of the
result of any audit conduct by Valeant pursuant to Section 7.2, such interest shall not accrue until
[***] after the completion of such audit and not at the time the payment was originally due.
Notwithstanding the foregoing, if the reason for any late payment is resulting from or arising out
of any act or omission on the part of Valeant, including but not limited to any delay providing the
requisite reports in Section 4.2.2, or the payment instructions pursuant to Section 6.3.4, such
interest shall not accrue.

6.4 Taxes. To the extent Dova is required to deduct and withhold taxes from any payment to Valeant,
Dova shall pay the amounts of such taxes to the proper Governmental Authority in a timely manner and
promptly transmit to Valeant an official tax receipt or other evidence of timely payment sufficient
to enable Valeant to claim the payment of such taxes as a deduction or tax credit. Valeant may
provide to Dova any tax forms that may be reasonably necessary in order for Dova to not withhold tax
and Dova shall dispense with withholding, as applicable. Dova shall provide Valeant with reasonable
assistance to enable the recovery, as permitted by Applicable Laws, of withholding taxes.

6.5 Determination of Specialty.

6.5.1 No later than [***] (or in the case of the first full Calendar Quarter following the Effective
Date, promptly following the Effective Date), Dova shall provide Valeant with a list of Target
Professionals in the Territory, together with their primary and secondary specialty designation, as
generated by Dova's Third Party Data Source. Promptly following receipt by Valeant of such list, but
no later than [***] after receipt of the list of Target Professionals, Valeant may present to Dova a
list of Target Professionals that, acting in good faith, it reasonably believes have a primary
specialty designation of or otherwise currently practice in the specialty of Gastroenterology,
Colorectal Surgery or Proctology. For greater certainty, this list may include, but not be limited
to, Target Professionals with a primary specialty designation of Gastroenterology, Colorectal
Surgery or Proctology and a secondary specialty designation of Hepatology, for which Valeant wishes
to confirm the primary specialty.

6.5.2 Promptly following receipt by Dova of such list from Valeant, the Parties shall meet and
discuss, acting reasonably and in good faith, such list and their appropriate primary specialty. If
the parties agree that the Target Professional included on such list has (or should have) a primary
specialty designation of or otherwise currently practices in the specialty of Gastroenterology,
Colorectal Surgery or Proctology, then Dova will submit an inquiry to Dova's Third Party Data Source
for each such Target Professional, requesting that Dova's Third Party Data Source conduct an
investigation to determine the primary specialty designation of each such Target Professional. In
addition, if the Parties do not agree, but Valeant, acting reasonably and in good faith, still
believes that the Target Professional has (or should have) a primary specialty designation of or
otherwise currently practices in the specialty of Gastroenterology, Colorectal Surgery or
Proctology, then Dova will submit an inquiry to Dova's Third Party Data Source for each such Target
Professional, requesting that Dova's Third Party Data Source conduct an investigation to determine
the primary specialty designation of each such Target Professional. The Parties shall equally share
in the incremental costs to Dova of any such investigations by Dova's Third Party Data Source. For
greater certainty, if, under Dova's agreement with Dova's Third Party Data Source, Dova is entitled
to a certain number of investigations at no additional cost, and such investigations requested by
Valeant causes Dova to incur additional costs that it would not have, but for such investigations
requested by Valeant, then Valeant shall still be required to share in any costs of investigations
(pursuant to Dova's Third Party Data Source's standard rates) that would otherwise be a no-cost
investigations. In the event that Dova incurs costs for which Valeant is responsible under this
Section 6.5, Dova may deduct such amounts from the payments due under Section 6.3 and shall include
a description thereof in the applicable report under Section 6.3.

6.5.3 In the event that Dova's Third Party Data Source agrees to conduct such investigation, and
then based on the results of such investigation, Dova's Third Party Data Source changes the primary
designation of the Target Professional to Gastroenterology, Colorectal Surgery or Proctology or, in
the case of those Target Professionals with a primary specialty designation of Gastroenterology,
Colorectal Surgery or Proctology and a secondary specialty designation of Hepatology, confirms that
the primary specialty designation should remain Gastroenterology, Colorectal Surgery or Proctology,
then, commencing with the Calendar Quarter in which such investigations were conducted, such Target
Professionals shall be deemed to be in the Specialty (regardless of whether their secondary
specialty designation remains or becomes Hepatology). In the event that, following such
investigation, Dova's Third Party Data source does not change the primary specialty designation to
Gastroenterology, Colorectal Surgery or Proctology or, in the case of those Target Professionals
with a primary specialty designation of Gastroenterology, Colorectal Surgery or Proctology and a
secondary specialty designation of Hepatology, changes the primary specialty designation to a
specialty other than Gastroenterology, Colorectal Surgery or Proctology, then those Target
Professionals shall be deemed not to be in the Specialty. For those Target Professionals that were
not the subject of an inquiry to or an investigation by Dova's Third Party Data Source, then the
specialty designations set out in the original list generated by Dova's Third Party Data Source
shall apply for such Calendar Quarter, namely those Target Professionals that have either a

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 27 -->
primary or a secondary specialty designation of Gastroenterology, Colorectal Surgery or Proctology
and that do not have either a primary or a secondary specialty designation of Hepatology shall be
deemed to be in the Specialty.

6.5.4 The process described in this Section 6.5 shall be repeated for each Calendar Quarter of the
Term; provided, however, that, pursuant to the process described above, if Dova's Third Party Data
Source has confirmed that a Target Professional's primary specialty designation should be or should
remain Gastroenterology, Colorectal Surgery or Proctology, it is not necessary for Valeant to seek
this confirmation in subsequent Calendar Quarters; provided, further, that, if Dova's Third Party
Data Source is subsequently updated (by Dova or any Third Party) to change the specialty designation
(primary or secondary) of a Target Professional, pursuant to a request by Dova or a Third Party,
then the process described in this Section 6.5 shall be repeated with respect to such Target
Professional.

ARTICLE 7 AUDIT RIGHTS

7.1 Recordkeeping. Each Party shall maintain complete and accurate books and records in sufficient
detail, in accordance with GAAP (to the extent applicable and in accordance with the Agreement) and
all Applicable Law, to enable verification of the performance of such Party's obligations under this
Agreement and any payments due to a Party under this Agreement. Unless otherwise specified herein,
the books and records for a given Calendar Year of the Term shall be maintained for a period of
[***] after the end of such Calendar Year or longer if required by Applicable Law.

7.2 Valeant Rights. Valeant shall have the right, at its own expense, during normal business hours
and upon reasonable prior notice, through certified public accounting firm or other auditor selected
by Valeant and reasonably acceptable to Dova and upon execution of a confidentiality agreement
reasonably satisfactory to Dova in form and substance, to inspect and audit the applicable records
and books maintained by Dova for purposes of verifying Dova's payment obligations within this
Agreement, including the applicable records and books of account maintained by Dova, or any
Affiliate, as applicable, with respect to Net Sales in order to confirm the accuracy and
completeness of such records and books of account and all payments hereunder; provided, however,
that (i) such examination shall not take place more often than once per every twelve (12) months
during the Term and once during the one (1) year period following the end of the Term, and (ii) such
examination shall not cover a period of time that has previously been audited; provided that Valeant
shall have the right to conduct additional "for cause" audits to the extent necessary to address
significant problems relating to Dova's payment obligations hereunder. Dova shall reasonably
cooperate in any such inspection or audit conducted by Valeant. Any undisputed adjustments required
as a result of overpayments or underpayments identified through the exercise of audit rights shall
be made by payment to the Party owed such adjustment within [***] after identification of such
adjustment. Valeant shall bear the out-of-pocket costs and expenses incurred by the Parties in
connection with any such inspection or audit, unless the audit shows an undisputed under-reporting
or underpayment for that audited period in excess of [***] of the amounts properly determined, in
which case, Dova shall reimburse Valeant for its audit fees and reasonable out-of-pocket expenses in
connection with said audit, which reimbursement shall be due and payable within [***] of receiving
appropriate invoices and other support for such audit-related costs.

7.3 Dova Rights. Dova shall have the right, at its own expense, during normal business hours and
upon reasonable prior notice, through a certified public accounting firm or other auditor selected
by Dova and reasonably acceptable to Valeant and upon execution of a confidentiality agreement
reasonably satisfactory to Valeant in form and substance, to inspect and audit the applicable
records and books maintained by Valeant relating to the Valeant Activities for purposes of verifying
Valeant's compliance with the terms of this Agreement, provided that (i) such examination shall not
take place more often than once per every twelve (12) months during the Term and once during the one
(1) year period following the end of the Term, and (ii) such examination shall not cover a period of
time that has previously been audited; provided that Dova shall have the right to conduct additional
"for cause" audits to the extent necessary to address significant compliance problems relating to
Valeant's obligations hereunder or in response to any inquiry, inspection, investigation or other
requirements of a Government Authority in the Territory relating to the Valeant Activities. For
purposes of clarity, any such inspection or audit described in this Section 7.3 shall be limited to
only those books and records of Valeant that are applicable to Valeant's performance of its
obligations under this Agreement. Where necessary, on reasonable request, Dova's audit rights shall
include interviewing Sales Representatives and other employees of Valeant. Valeant shall reasonably
cooperate in any such inspection or audit conducted by Dova. Any undisputed adjustments required as
a result of overreporting the aggregate actual number of Details for the Product made by the Sales
Representatives for a Calendar Quarter or the Quarterly Average Sales Force Size identified through
the exercise of audit rights shall be made by payment by Valeant to Dova within [***] after
identification of such adjustment. Dova shall bear the out-of-pocket costs and expenses incurred by
the Parties in connection with any such inspection or audit, unless the audit shows an undisputed
over- payment for that audited period in excess of [***] of the amounts properly determined, in
which case, Valeant shall reimburse Dova for its audit fees and reasonable out-of-pocket expenses in
connection with said audit, which reimbursement shall be due and payable within [***] of receiving
appropriate invoices and other support for such audit-related costs.

ARTICLE 8 INTELLECTUAL PROPERTY

8.1 Ownership of Intellectual Property.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 28 -->
8.1.1 Valeant Property. Dova acknowledges that Valeant owns or is licensed to use certain Know-How
relating to the proprietary sales and marketing information, methods and plans that has been
independently developed or licensed by Valeant (such Know-How, the "Valeant Property"). The Parties
agree that any improvement, enhancement or modification made, discovered, conceived, or reduced to
practice by Valeant to any Valeant Property in performing its activities pursuant to this Agreement
which is not primarily related to the Product, or which is not otherwise derived from the
Confidential Information of Dova, shall be deemed Valeant Property. [***], Valeant hereby grants to
Dova a fully paid-up, royalty free, non-transferable, non- exclusive license (with a limited right
to sub-license to its Affiliates) to any Valeant Property that appears on, embodied on or contained
in the Product materials or Product Labeling solely for use in connection with Dova's promotion or
other commercialization of the Product in the Territory.

8.1.2 Dova Property. Subject to the terms of Section 8.1.1, Dova shall have and retain sole and
exclusive right, title and interest in and to all inventions, developments, discoveries, writings,
trade secrets, Know-How, methods, practices, procedures, designs, improvements and other technology,
whether or not patentable or copyrightable, and any patent applications, patents, or copyrights
based thereon (collectively, "Intellectual Property") relating to the Product that are (i) owned or
controlled by Dova as of the Effective Date, (ii) made, discovered, conceived, reduced to practice
or generated by Dova (or its employees or representatives) during the Term, or (iii) made,
discovered, conceived, reduced to practice or generated by Valeant (or its employees or
representatives) in performing its activities pursuant to this Agreement to the extent primarily
related to the Product or which is otherwise derived from the Confidential Information of Dova
("Inventions"). Valeant agrees to assign, and hereby does assign, to Dova (and shall cause its
Affiliates and its and their respective employees and other representatives to assign to Dova) any
and all right, title and interest that Valeant (or any such Affiliates, employees or other
representatives) may have in or to any Invention. For clarity, any and all Inventions and any
information contained therein or related thereto shall constitute Confidential Information of Dova.

8.2 Title to Trademarks and Copyrights. The ownership, and all goodwill from the use, of any Dova
Trademarks and Copyrights shall at all times vest in and inure to the benefit of Dova, and Valeant
shall assign, and hereby does assign, any rights it may have in the foregoing to Dova.

8.3 Protection of Trademarks and Copyrights. As between the Parties, Dova shall have the sole right
(but not the obligation), as determined by Dova in its sole discretion, to (i) maintain the Dova
Trademarks and Copyrights and/or (ii) protect, enforce and defend the Dova Trademarks and
Copyrights. Valeant shall give notice to Dova of any infringement of, or challenge to, the validity
or enforceability of the Dova Trademarks and Copyrights promptly after learning of such infringement
or challenge. If Dova institutes an action against Third Party infringers or takes action to defend
the Dova Trademarks and Copyrights, Valeant shall reasonably cooperate with Dova, at Dova's cost and
expense. Any recovery obtained by Dova as a result of such proceeding or other actions, whether
obtained by settlement or otherwise, shall be retained by Dova. Valeant shall not have any right to
institute any action to defend or enforce the Dova Trademarks and Copyrights.

8.4 Disclosure of Know-How. For clarity, the Parties hereby agree and acknowledge that to the extent
that either Party hereto has disclosed, or in the future discloses, to the other Party any Know-How
or other intellectual property of such Party or its Affiliates pursuant to this Agreement, the other
Party shall not acquire any ownership rights in such Know-How or other intellectual property by
virtue of this Agreement or otherwise, and as between the Parties, all ownership rights therein
shall remain with the disclosing Party (or its Affiliate).

ARTICLE 9 CONFIDENTIALITY

9.1 Confidential Information.

9.1.1 Confidentiality and Non-Use. Each Party agrees that, during the Term and for a period of [***]
thereafter, it shall keep confidential and shall not publish or otherwise disclose and shall not use
for any purpose other than as provided for in this Agreement (which includes the exercise of its
rights or performance of any obligations hereunder) any Confidential Information furnished to it by
or on behalf of the other Party pursuant to this Agreement, except to the extent expressly
authorized by this Agreement or otherwise agreed in writing by the Parties. Without limiting the
foregoing, each Party will use at least the same standard of care as it uses to protect its own
Confidential Information to ensure that its employees, agents, consultants and contractors do not
disclose or make any unauthorized use of such Confidential Information. Each Party will promptly
notify the other upon discovery of any unauthorized use or disclosure of the other's Confidential
Information. Any and all information and materials disclosed by a Party pursuant to the
Confidentiality Agreement between the Parties dated [***] (the "Confidentiality Agreement") shall be
deemed Confidential Information disclosed pursuant to this Agreement. The foregoing confidentiality
and non-use obligations shall not apply to any portion of the other Party's Confidential Information
that the receiving Party can demonstrate by competent tangible evidence:

(a) was already known to the receiving Party or its Affiliate, other than under an obligation of
confidentiality, at the time of disclosure by the other Party;

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 29 -->
(b) was generally available to the public or otherwise part of the public domain at the time of its
disclosure to the receiving Party;

(c) became generally available to the public or otherwise part of the public domain after its
disclosure and other than through any act or omission of the receiving Party or its Affiliates in
breach of this Agreement;

(d) was disclosed to the receiving Party or its Affiliate by a Third Party who has a legal right to
make such disclosure and who did not obtain such information directly or indirectly from the other
Party (or its Affiliate); or

(e) was independently discovered or developed by the receiving Party or its Affiliate without access
to or aid, application, use of the other Party's Confidential Information, as evidenced by a
contemporaneous writing.

9.1.2 Authorized Disclosure. Notwithstanding the obligations set forth in Section 9.1.1, a Party may
disclose the other Party's Confidential Information and the terms of this Agreement to the extent:

(a) such disclosure is reasonably necessary (x) to comply with the requirements of Governmental
Authorities; or (y) for the prosecuting or defending litigation as contemplated by this Agreement;

(b) such disclosure is reasonably necessary to its Affiliates, employees, agents, consultants and
contractors on a need-to-know basis for the sole purpose of performing its obligations or exercising
its rights under this Agreement; provided that in each case, the disclosees are bound by obligations
of confidentiality and non-use consistent with those contained in this Agreement and the disclosing
Party shall be liable for any failures of such disclosees to abide by such obligations of
confidentiality and non-use; or

(c) such disclosure is reasonably necessary to comply with Applicable Laws, including regulations
promulgated by applicable securities exchanges, court order, administrative subpoena or order.

Notwithstanding the foregoing, in the event a Party is required to make a disclosure of the other
Party's Confidential Information pursuant to Section 9.1.2(a) or 9.1.2(c), such Party shall, if
permitted, promptly notify the other Party of such required disclosure and shall use reasonable
efforts to assist the other Party (at the other Party's cost) in obtaining, a protective order
preventing or limiting the required disclosure.

9.2 Public Announcements. The press release announcing the execution of this Agreement shall be
issued in the form attached hereto as Exhibit A. No public announcement or statements (including
presentations to investor meetings and customer updates) concerning the existence of or terms of
this Agreement or incorporating the marks of the other Party or their respective Affiliates shall be
made, either directly or indirectly, by either Party or a Party's Affiliates, without first
obtaining the written approval of the other Party and agreement upon the nature, text and timing of
such announcement or disclosure. Either Party shall have the right to make any such public
announcement or other disclosure required by Applicable Law after such Party has provided to the
other Party a copy of such announcement or disclosure and an opportunity to comment thereon and the
disclosing Party shall reasonably consider the other Party's comments. Each Party agrees that it
shall cooperate fully with the other with respect to all disclosures regarding this Agreement to the
Securities Exchange Commission and any other Governmental Authorities, including requests for
confidential treatment of proprietary information of either Party included in any such disclosure.
Once any written statement is approved for disclosure by the Parties or information is otherwise
made public in accordance with this Section 9.2, either Party may make a subsequent public
disclosure of the same contents of such statement in the same context as such statement without
further approval of the other Party. Notwithstanding anything to the contrary contained herein, in
no event shall either Party disclose any financial information of the other without the prior
written consent of such other Party, unless such financial information already has been publicly
disclosed by the Party owning the financial information or otherwise has been made part of the
public domain by no breach of a Party of its obligations under this ARTICLE 9.

8

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 30 -->
ARTICLE 10 REPRESENTATIONS AND WARRANTIES; ADDITIONAL COVENANTS

10.1 Representations and Warranties of Dova. Dova represents and warrants to Valeant as of the
Effective Date that:

10.1.1 it is a corporation duly organized and validly existing under the laws of the state or other
jurisdiction of its incorporation;

10.1.2 the execution, delivery and performance of this Agreement by it has been duly authorized by
all requisite corporate action;

10.1.3 it has the power and authority to execute and deliver this Agreement and to perform its
obligations hereunder;

10.1.4 this Agreement constitutes a legal, valid and binding obligation enforceable against it in
accordance with its terms, subject to the effects of bankruptcy, insolvency or other laws of general
application affecting the enforcement of creditor rights, judicial principles affecting the
availability of specific performance and general principles of equity (whether enforceability is
considered a proceeding at law or equity);

10.1.5 the execution, delivery and performance of this Agreement by Dova does not require the
consent of any Person (including under the Third Party Agreements) or the authorization of (by
notice or otherwise) any Governmental Authority including the FDA;

10.1.6 there is no action, suit or proceeding pending or, to the knowledge of Dova, threatened,
against Dova or any of its Affiliates, or to the knowledge of Dova, any Third Party acting on their
behalf, which would be reasonably expected to impair, restrict or prohibit the ability of Dova or
Valeant to perform its obligations and enjoy the benefits of this Agreement;

10.1.7 it is in compliance in all material respects with all Applicable Laws applicable to the
subject matter of this Agreement, including its donations to, and interactions with, any 501(c)(3)
charitable foundation that provides co-pay assistance to government-insured patients with respect to
the Product have been in compliance with all Applicable Laws;

10.1.8 it has the right to market and sell the Product in the Territory as contemplated herein and
has all licenses, authorizations, permissions, consents or approvals from any applicable
Governmental Authority including the FDA necessary to make, use, sell and offer to sell the Product
in the Territory and all such licenses, authorizations, permissions, consents or approvals are in
good standing;

10.1.9 it has the exclusive right to promote the Product in the Territory to the Target
Professionals in the Specialty and the rights granted by it to Valeant hereunder do not conflict
with any rights granted by Dova to any Third Party;

10.1.10 to the knowledge of Dova, all manufacturing, stability testing, labeling, packaging,
storing, shipping and distribution operations conducted by or on behalf of Dova relating to the
commercial supply of the Product have been conducted in compliance with Applicable Law and it has no
knowledge of any information indicating that Dova would be unable to manufacture and supply (or have
manufactured and supplied) the Product in sufficient quantities to meet the reasonable demands in
the Territory;

10.1.11 it has no knowledge of any information relating to the safety or efficacy of the Product or
any communications with any Governmental Authority, which would reasonably be expected to materially
impair, restrict, prohibit or affect Dova's ability to perform its obligations and enjoy the
benefits of this Agreement;

10.1.12 it is not a party to any agreement or arrangement with any Third Party or under any
obligation or restriction agreement (including any outstanding order, judgment or decree of any
court or administrative agency) which in any way limits or conflicts with its ability to execute and
deliver this Agreement and to fulfill any of its obligations under this Agreement;

10.1.13 each of the Third Party Agreements constitutes a valid and binding obligation of Dova or its
Affiliate, as applicable, and is enforceable against Dova or its Affiliate, as applicable, and, to
the knowledge of Dova, each of the Third Party Agreements constitutes a valid and binding obligation
of the counterparty thereto and is enforceable against such counterparty, except in each case as may
be limited by bankruptcy, insolvency, fraudulent transfer, moratorium, reorganization, preference or
similar laws of general applicability relating to or affecting the rights of creditors generally and
subject to general principles of equity (regardless of whether enforcement is sought in equity or at
law). Dova or its Affiliate, as applicable, and to the knowledge of Dova, the applicable
counterparty thereto, are not in material breach of or default under either of the Third Party
Agreements. The

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 31 -->
counterparty to each of the Third Party Agreements has not exercised or, to the knowledge of Dova,
threatened in writing to exercise any termination right with respect to the applicable Third Party
Agreement.

10.1.14 neither Dova nor any of its personnel (i) have been debarred under the 21 U.S.C. § 335a,
(ii) are excluded, debarred, suspended, or otherwise ineligible to participate in the Federal health
care programs or in Federal procurement or nonprocurement programs, (iii) are convicted of a
criminal offense that falls within the ambit of the Federal statute providing for mandatory
exclusion from participation in Federal health care programs but has not yet been excluded,
debarred, suspended, or otherwise declared ineligible to participate in those programs, (iv) are
listed on the HHS/OIG List of Excluded Individuals/Entities (available through the Internet at
http://oig.hhs.gov) or (v) are listed on the General Services Administration's List of Parties
Excluded from Federal Programs (available through the Internet at hhtp://epls.arnet.gov). If, during
the Term, Dova or any of its personnel becomes or is the subject of a proceeding that could lead to,
as applicable, (i) debarment under 21 U.S.C. § 335a, (ii) exclusion, debarment, suspension or
ineligibility to participate in the Federal health care programs or in Federal procurement or
nonprocurement programs, (iii) convicted (or conviction) of a criminal offense that falls within the
ambit of the Federal statute providing for mandatory exclusion from participation in Federal
healthcare programs, (iv) listed (or listing) on the HHS/OIG List of Excluded Individuals/Entities
(available through the Internet at http://oig.hhs.gov) or (v) listed (or listing) on the General
Services Administration's List of Parties Excluded from Federal Programs (available through the
Internet at hhtp://epls.arnet.gov), Dova shall immediately notify Valeant, and Valeant shall have
the option to prohibit such Person from performing work relating to this Agreement or the Product;
and

10.1.15 any patient assistance program used in connection with the Product used in connection with
the Product have each been operated in accordance with Applicable Law.

10.2 Representations and Warranties of Valeant. Valeant represents and warrants to Dova as of the
Effective Date that:

10.2.1 it is a limited liability company duly organized and validly existing under the laws of the
state or other jurisdiction of its incorporation;

10.2.2 the execution, delivery and performance of this Agreement by it has been duly authorized by
all requisite corporate action;

10.2.3 it has the power and authority to execute and deliver this Agreement and to perform its
obligations hereunder;

10.2.4 this Agreement constitutes a legal, valid and binding obligation enforceable against it in
accordance with its terms, subject to the effects of bankruptcy, insolvency or other laws of general
application affecting the enforcement of creditor rights, judicial principles affecting the
availability of specific performance and general principles of equity (whether enforceability is
considered a proceeding at law or equity);

10.2.5 the execution, delivery and performance of this Agreement by Valeant does not require the
consent of any Person or the authorization of (by notice or otherwise) any Governmental Authority or
the FDA;

10.2.6 there is no action, suit or proceeding pending or, to the knowledge of Valeant, threatened,
against Valeant or any of its Affiliates, or to the knowledge of Valeant, any Third Party acting on
their behalf, which would be reasonably expected to impair, restrict or prohibit the ability of Dova
or Valeant to perform its obligations and enjoy the benefits of this Agreement;

10.2.7 it is in compliance in all material respects with all Applicable Laws applicable to the
subject matter of this Agreement;

10.2.8 it has the right to market and sell the Designated Product in the Territory as contemplated
herein and has all licenses, authorizations, permissions, consents or approvals from any applicable
Governmental Authority including the FDA necessary to make, use, sell and offer to sell the Product
in the Territory and all such licenses, authorizations, permissions, consents or approvals are in
good standing;

10.2.9 it is not a party to any agreement or arrangement with any Third Party or under any
obligation or restriction agreement (including any outstanding order, judgment or decree of any
court or administrative agency) which in any way limits or conflicts with its ability to execute and
deliver this Agreement and to fulfill any of its obligations under this Agreement;

10.2.10 it has no knowledge of any information relating to any communications with any Governmental
Authority, which would reasonably be expected to materially impair, restrict, prohibit or affect
Valeant's ability to perform its obligations and enjoy the benefits of this Agreement;

10.2.11 neither Valeant nor any of its personnel (i) have been debarred under the 21 U.S.C. § 335a,
(ii) are

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 32 -->
excluded, debarred, suspended, or otherwise ineligible to participate in the Federal health care
programs or in Federal procurement or nonprocurement programs, (iii) are convicted of a criminal
offense that falls within the ambit of the Federal statute providing for mandatory exclusion from
participation in Federal health care programs but has not yet been excluded, debarred, suspended, or
otherwise declared ineligible to participate in those programs, (iv) are listed on the HHS/OIG List
of Excluded Individuals/Entities (available through the Internet at http://oig.hhs.gov) or (v) are
listed on the General Services Administration's List of Parties Excluded from Federal Programs
(available through the Internet at hhtp://epls.arnet.gov). If, during the Term, Valeant or any of
its personnel become or are the subject of a proceeding that could lead to, as applicable, (i)
debarment under 21 U.S.C. § 335a, (ii) exclusion, debarment, suspension or ineligibility to
participate in the Federal health care programs or in Federal procurement or nonprocurement
programs, (iii) convicted (or conviction) of a criminal offense that falls within the ambit of the
Federal statute providing for mandatory exclusion from participation in Federal healthcare programs,
(iv) listed (or listing) on the HHS/OIG List of Excluded Individuals/Entities (available through the
Internet at http://oig.hhs.gov) or (v) listed (or listing) on the General Services Administration's
List of Parties Excluded from Federal Programs (available through the Internet at
hhtp://epls.arnet.gov), Valeant shall immediately notify Dova, and Dova shall have the option to
prohibit such Person from performing work under this Agreement; and

10.2.12 all Field Force Personnel that are engaged in Detailing are, and will be, licensed to the
extent required and in accordance with all Applicable Laws.

10.3 Disclaimer of Warranty. EXCEPT FOR THE EXPRESS WARRANTIES SET FORTH IN THIS AGREEMENT, DOVA
(AND ITS AFFILIATES) AND VALEANT (AND ITS AFFILIATES) MAKE NO REPRESENTATIONS AND NO WARRANTIES,
EXPRESS OR IMPLIED, EITHER IN FACT OR BY OPERATION OF LAW, BY STATUTE OR OTHERWISE, AND DOVA (AND
ITS AFFILIATES) AND VALEANT (AND ITS AFFILIATES) EACH SPECIFICALLY DISCLAIM ANY OTHER
REPRESENTATIONS AND WARRANTIES, WHETHER WRITTEN OR ORAL, EXPRESS, STATUTORY OR IMPLIED, INCLUDING
ANY WARRANTY OF QUALITY, MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE OR PURPOSE OR ANY WARRANTY
AS TO THE VALIDITY OF ANY INTELLECTUAL PROPERTY OR THE NON-INFRINGEMENT OF ANY INTELLECTUAL PROPERTY
RIGHTS OF THIRD PARTIES.

10.4 Additional Covenants.

10.4.1 Initial Orders to Non-Retail Institutions. For initial orders of Product from Dova (or its
Affiliates or its Intermediaries) to the Non-Retail Institutions, Dova shall not engage in any
"channel stuffing" or any similar program, activity or other action (including any rebate, discount,
chargeback or refund policy or practice) that in each case is intended by Dova to result in
purchases by the Non-Retail Institutions that are materially in excess of purchases in the ordinary
course of business or that is intended to materially adversely impact Valeant's promotion fee
pursuant to this Agreement; provided, however, this Section10.4.1 shall not be applicable to any
activity or action taken by Dova which applies to all or substantially all customers for the
Product, or any activity or action taken by Dova in good faith and consistent with customary sales
and marketing practices in the pharmaceutical industry.

10.4.2 Third Party Agreements. Dova shall remain solely responsible for the payment of royalty,
milestone and other payment obligations, if any, due to Third Parties on (or in connection with) the
sale of Product in the Territory, including under the Third Party Agreements.

ARTICLE 11 INDEMNIFICATION; LIMITATIONS ON LIABILITY

11.1 Indemnification by Dova. Dova shall defend, indemnify and hold harmless Valeant and its
Affiliates and its and their respective officers, directors, employees, agents, representatives,
successors and assigns from and against all Claims, and all associated Losses, to the extent
incurred or suffered by any of them to the extent resulting from or arising out of (a) any
misrepresentation or breach of any representations, warranties, agreements or covenants of Dova
under this Agreement, (b) the negligence, willful misconduct or violation of Applicable Laws by Dova
(or any of its Affiliates or its or their respective officers, directors, employees, agents or
representatives), (c) the infringement of the intellectual property rights of any Third Party in
connection with the Product, including from the use of the Dova Trademarks and Copyrights on Product
Labeling or Product Materials in accordance with this Agreement, (d) death or personal injury to any
person related to use of the Product, or (e) the failure to comply with Applicable Laws by the
Specialty Pharmacies, applicable reimbursement hub or any 501(c)(3) charitable foundation used in
connection with the Product; except in each case to the extent any such Claims, and all associated
Losses, are caused by an item for which Valeant is obligated to indemnify Dova pursuant to Section
11.2.

11.2 Indemnification by Valeant. Valeant shall defend, indemnify and hold harmless Dova and its
Affiliates and its and their respective officers, directors, employees, agents, representatives,
successors and assigns from and against all Claims and all associated Losses, to the extent incurred
or suffered by any of them to the extent resulting from or arising out of (a) any misrepresentation
or breach of any representations, warranties, agreements or covenants of Valeant under this
Agreement, or (b) the negligence, willful misconduct, or violation of Applicable Laws by Valeant (or
any of its Affiliates or its and their respective

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 33 -->
officers, directors, employees, agents or representatives); except in each case to the extent any
such Claims, and all associated Losses, are caused by an item for which Dova is obligated to
indemnify Valeant pursuant to Section 11.1.

11.3 Indemnification Procedures. The Party seeking indemnification under Section 11.1 or 11.2, as
applicable (the "Indemnified Party") shall give prompt notice to the Party against whom indemnity is
sought (the "Indemnifying Party") of the assertion or commencement of any Claim in respect of which
indemnity may be sought under Section 11.1 or 11.2, as applicable, and will provide the Indemnifying
Party such information with respect thereto that the Indemnifying Party may reasonably request. The
failure to give such notice will relieve the Indemnifying Party of any liability hereunder only to
the extent that the Indemnifying Party has suffered actual prejudice thereby. The Indemnifying Party
shall assume and control the defense and settlement of any such action, suit or proceeding at its
own expense. The Indemnified Party shall, if requested by the Indemnifying Party, cooperate in all
reasonable respects in such defense, at the Indemnifying Party's expense. The Indemnified Party will
be entitled at its own expense to participate in such defense and to employ separate counsel for
such purpose. For so long as the Indemnifying Party is diligently defending any proceeding pursuant
to this Section 11.3, the Indemnifying Party will not be liable under Section 11.1 or 11.2, as
applicable, for any settlement effected without its consent. No Party shall enter into any
compromise or settlement which commits the other Party to take, or to forbear to take, any action
without the other Party's prior written consent (and unless such compromise or settlement includes
no payments by the Indemnified Party, an unconditional release of, and no admission of liability by,
the Indemnified Party from all liability in respect of such Claim).

11.4 Limitation of Liability. NOTWITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN (OTHER THAN AS
SET FORTH IN THE SECOND SENTENCE OF THIS SECTION 11.4), IN NO EVENT SHALL DOVA (OR ITS AFFILIATES)
OR VALEANT (OR ITS AFFILIATES) BE LIABLE TO THE OTHER OR ANY OF THE OTHER PARTY'S AFFILIATES FOR ANY
CONSEQUENTIAL, INCIDENTAL, INDIRECT, SPECIAL, PUNITIVE OR EXEMPLARY DAMAGES (INCLUDING LOST PROFITS)
SUFFERED OR INCURRED BY SUCH OTHER PARTY OR ITS AFFILIATES THAT ARISE OUT OF OR RELATE TO THIS
AGREEMENT OR IN CONNECTION WITH A BREACH OR ALLEGED BREACH OF THIS AGREEMENT, WHETHER IN CONTRACT,
TORT, STRICT LIABILITY OR OTHERWISE, AND REGARDLESS OF ANY NOTICE OF THE POSSIBILITY OF SUCH
DAMAGES. THE FOREGOING SENTENCE SHALL NOT LIMIT (1) THE OBLIGATIONS OF EITHER PARTY TO INDEMNIFY THE
OTHER PARTY FROM AND AGAINST THIRD PARTY CLAIMS UNDER SECTION 11.1 OR 11.2, AS APPLICABLE, OR (2)
DAMAGES AVAILABLE FOR A PARTY'S BREACH OF THE CONFIDENTIALITY AND NON-USE OBLIGATIONS IN ARTICLE 9.

11.5 Insurance. Each Party acknowledges and agrees that during the Term, it shall maintain, through
purchase or self- insurance, adequate insurance, including products liability coverage and
comprehensive general liability insurance, adequate to cover its obligations under this Agreement
and which are consistent with normal business practices of prudent companies similarly situated.
Each Party shall provide reasonable written proof of the existence of such insurance to the other
Party upon request. Dova does not and will not maintain or procure any worker's compensation,
healthcare, or other insurance for or on behalf of any Field Force Personnel, all of which shall be
Valeant's sole responsibility. For clarity, the insurance requirements of this Section 11.5 shall
not be construed to create a limit of either Party's liability with respect to its indemnification
obligations under this ARTICLE 11.

ARTICLE 12 TERM AND TERMINATION

12.1 Term. This Agreement shall become effective as of the Effective Date and, unless earlier
terminated as provided in this ARTICLE 12, shall extend until the four (4) year anniversary of the
Effective Date (the "Term").

12.2 Early Termination for Cause. A Party shall have the right to terminate this Agreement before
the end of the Term as follows:

12.2.1 by a Party upon written notice to the other Party in the event of a material breach of this
Agreement by such other Party where such breach is not cured (if able to be cured) within [***]
following such other Party's receipt of written notice of such breach (and any such termination
shall become effective at the end of such [***] period unless the breaching Party has cured such
breach prior to the expiration of such [***] period);

12.2.2 by Dova if the Quarterly Average Sales Force Size is less than [***] Sales Representatives
for [***] consecutive Calendar Quarters, upon [***] written notice to Valeant, such notice to be
delivered no less than [***] following the end of the last consecutive Calendar Quarter in which the
Quarterly Average Sales Force Size is less than [***] Sales Representatives;

12.2.3 by Dova if the aggregate actual number of Details for the Product made by the Sales
Representatives for a Calendar Quarter is less than the Quarterly Minimum Details for [***]
consecutive Calendar Quarters, upon [***] written notice to Valeant, such notice to be delivered no
less than [***] following the end of the last consecutive Calendar Quarter in which the actual
Details are less than the Quarterly Minimum Details;

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 34 -->
12.2.4 by either Party upon [***] written notice to the other Party following the withdrawal of the
Product from the market by Dova (or the decision by Dova to withdraw the Product from the market)
due to (i) any decision, judgment, ruling or other requirement of the FDA, or (ii) material safety
concern;

12.2.5 by Dova upon [***] written notice to Valeant upon the cessation of marketing by Valeant of
the Designated Product (or the Alternate Product in accordance with Section 4.2.1(c), as the case
may be);

12.2.6 by Dova pursuant to Section 4.2.1(c); and

12.2.7 by a Party immediately upon written notice to the other Party upon the filing or institution
of bankruptcy, reorganization, liquidation or receivership proceedings with respect to such other
Party, or upon an assignment of a substantial portion of the assets for the benefit of creditors by
such other Party, or in the event a receiver or custodian is appointed for such other Party's
business or a substantial portion of such other Party's business is subject to attachment or similar
process; provided, however, in the case of any involuntary bankruptcy proceeding such right to
terminate shall only become effective if the party consents to the involuntary bankruptcy or such
proceeding is not dismissed within [***] after the filing thereof.

12.3 Other Early Termination.

12.3.1 Either Party shall have the right to terminate this Agreement before the end of the Term for
its convenience upon [***] written notice to the other Party (and any such termination shall become
effective at the end of such [***]); [***].

12.3.2 Either Party shall have the right to terminate this Agreement before the end of the Term upon
[***] written notice to the other Party delivered within [***] after the conclusion of any Calendar
Quarter, beginning with the Calendar Quarter commencing on [***], in which the Net Sales in such
Calendar Quarter are less [***] (and any such termination shall become effective at the end of such
[***] period); provided that Valeant shall not have the right to terminate this Agreement pursuant
to this Section 12.3.2 with respect to any Calendar Quarter for which the Quarterly Average Sales
Force Size is less than [***] Sales Representatives.

12.4 Effects of Termination. Upon the expiration or effective date of termination of this Agreement,
(i) all rights and obligations of both Parties hereunder shall immediately terminate, subject to any
survival as set forth in Sections 12.5 and 12.6, (ii) Valeant, at Dova's direction, shall
immediately return to Dova or destroy in accordance with all Applicable Laws all Product Materials,
reports and other tangible items provided by or on behalf of Dova to Valeant or otherwise developed
or obtained by Valeant pursuant to the terms of this Agreement (other than Valeant Property) (and at
the request of Dova, Valeant shall certify destruction of such materials if Valeant does not to
return such materials to Dova), (iii) Valeant shall immediately cease all Valeant Activities with
respect to the Product, and (iv) each of Dova and Valeant shall, at the other Party's direction,
either return to such other Party or destroy all Confidential Information of such other Party.
Notwithstanding the foregoing, each Party may retain archival copies of any Confidential Information
to the extent required by law, regulation or professional standards or copies of Confidential
Information created pursuant to the automatic backing-up of electronic files where the delivery or
destruction of such files would cause undue hardship to the receiving Party, so long as any such
archival or electronic file back-up copies are accessible only to its legal or IT personnel,
provided that such Confidential Information will continue to be subject to the terms of this
Agreement.

12.5 Tail Period. Solely in the event that Dova has terminated this Agreement pursuant to Section
12.3.1 and notwithstanding anything else herein, in consideration of the promotion services
performed by Valeant during the Term, with respect to the Tail Period, Dova shall make payments to
Valeant in an amount equal to [***] of the amounts that would have been payable by Dova to Valeant
with respect to such Tail Period pursuant to Section 6.1 had the Agreement not been so terminated.
Such payments shall be made within [***] following the end of each calendar quarter in the Tail
Period. Sections 6.3, 6.4 and 6.5 shall apply, mutatis mutandis, to such Tail Period payments. For
clarity, no tail payment shall be due following any expiration or termination of this Agreement
except as set forth in this Section 12.5.

12.6 Survival. Termination or expiration of this Agreement shall be without prejudice to any rights
that shall have accrued to the benefit of any Party prior to such termination or expiration.
Notwithstanding any expiration or termination of this Agreement, such expiration or termination
shall not relieve any Party from obligations which are expressly or by implication intended to
survive expiration or termination, including Sections 2.3, , 4.4.2, 5.7, 5.9, 6.3.6, 6.3.5, 11.1,
11.2, 11.3, 11.4, 12.4, 12.5 and 12.6, Articles 7, 8, 9 and 13 (to the extent applicable to
implementation of the survival of the preceding Sections and Articles) and, solely as it relates to
the last Calendar Quarter, Sections 6.1, 6.2 and 6.3, which shall survive and be in full force and
effect.

ARTICLE 13 MISCELLANEOUS

13.1 Force Majeure. Neither Party shall be held liable to the other Party nor be deemed to have
defaulted under or breached this Agreement for failure or delay in performing any obligation under
this Agreement to the extent such failure or delay is

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 35 -->
caused by or results from causes beyond the reasonable control of the affected Party, potentially
including, embargoes, war, acts of war (whether war be declared or not), acts of terrorism,
insurrections, riots, civil commotions, strikes, lockouts or other labor disturbances, fire, floods,
or other acts of God, or acts, omissions or delays in acting by any Governmental Authority. The
affected Party shall notify the other Party of such force majeure circumstances as soon as
reasonably practicable, and shall promptly undertake all reasonable efforts necessary to cure such
force majeure circumstances and re-commence its performance hereunder as soon as practicable.

13.2 Assignment. Except as provided in this Section 13.2, this Agreement may not be assigned or
otherwise transferred, nor may any rights or obligations hereunder be assigned or transferred, by
either Party, without the written consent of the other Party (such consent not to be unreasonably
withheld); provided that a merger, sale of stock or comparable transaction shall not constitute an
assignment. In the event either Party desires to make such an assignment or other transfer of this
Agreement or any rights or obligations hereunder, such Party shall deliver a written notice to the
other Party requesting the other Party's written consent in accordance with this Section 13.2, and
the other Party shall provide such Party written notice of its determination whether to provide such
written consent within [***] following its receipt of such written notice from such Party.
Notwithstanding the foregoing, (a) either Party may, without the other Party's consent, assign this
Agreement and its rights and obligations hereunder in whole or in part to an Affiliate; and (b) Dova
may assign this Agreement to a successor in interest in connection with the sale or other transfer
of all or substantially all of Dova's assets or rights relating to the Product; provided that such
assignee shall remain subject to all of the terms and conditions hereof in all respects and shall
assume all obligations of Dova hereunder whether accruing before or after such assignment. Any
permitted assignee shall assume all assigned obligations of its assignor under this Agreement. Any
attempted assignment not in accordance with this Section 13.2 shall be void. This Agreement shall be
binding on, and inure to the benefit of, each Party, and its permitted successors and assigns.

13.3 Severability. If any one or more of the provisions contained in this Agreement is held invalid,
illegal or unenforceable in any respect, the validity, legality and enforceability of the remaining
provisions contained herein shall not in any way be affected or impaired thereby, unless the absence
of the invalidated provision(s) adversely affects the substantive rights of the Parties. The Parties
shall in such an instance use reasonable efforts to replace the invalid, illegal or unenforceable
provision(s) with valid, legal and enforceable provision(s) which, insofar as practical, implement
the purposes of this Agreement.

13.4 Notices. All notices which are required or permitted hereunder shall be in writing and
sufficient if delivered personally, sent by e-mail (and promptly confirmed by personal delivery,
registered or certified mail or overnight courier), sent by nationally-recognized overnight courier,
or sent by registered or certified mail, postage prepaid, return receipt requested, addressed as
follows:

if to Dova, to: Dova Pharmaceuticals, Inc. 240 Leigh Farm Road, Suite 245 Durham, NC 27707
Attention: Chief Executive Officer Email: asapir@dova.com

With a copy to: Dova Pharmaceuticals, Inc. 240 Leigh Farm Road, Suite 245 Durham, NC 27707
Attention: General Counsel Email: mbanjak@dova.com

if to Valeant, to: Valeant Pharmaceuticals North America LLC 400 Somerset Corporate Boulevard
Bridgewater, NJ 08807 Attention: XXXXXXXXX Email: XXXXXXXX

With a copy to: XXXXXXXX Attention: XXXXXXXX Fax: XXXXXXXX Email: XXXXXXXX

or to such other address(es) as the Party to whom notice is to be given may have furnished to the
other Party in writing in accordance herewith. Any such notice shall be deemed to have been given:
(a) when delivered if personally delivered; (b) on the

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 36 -->
Business Day after dispatch if sent by nationally-recognized overnight courier; or (c) on the fifth
(5th) Business Day following the date of mailing, if sent by mail.

13.5 Governing Law. This Agreement and any and all matters arising directly or indirectly herefrom
shall be governed by and construed and enforced in accordance with the internal laws of the [***]
applicable to agreements made and to be performed entirely in such state, including its statutes of
limitation but without giving effect to the conflict of law principles thereof.

13.6 Dispute Resolution.

13.6.1 JSC; Escalation for Other Disputes. Except for disputes resolved by the procedures set forth
in Section 3.4, if a dispute arises between the Parties in connection with or relating to this
Agreement or any document or instrument delivered in connection herewith (a "Dispute"), then either
Party shall have the right to refer such dispute to the Senior Officers who shall confer within
[***] after such Dispute was first referred to them to attempt to resolve the Dispute by good faith
negotiations. Any final decision mutually agreed to by the Senior Officers in writing shall be
conclusive and binding on the Parties. If such Senior Officers do not agree on the resolution of an
issue within [***] after such issue was first referred to them, either Party may, by written notice
to the other Party, initiate arbitration for resolution of such Dispute pursuant to Section 13.6.2.

13.6.2 Arbitration of Other Disputes. If a Dispute is not resolved by the Senior Officers pursuant
to Section 13.6.1, such Dispute shall be submitted to and finally settled by [***] The Parties
hereby submit to the exclusive jurisdiction of the federal and state courts located in [***] for the
purposes of an order to compel arbitration, for preliminary relief in aid of arbitration and for a
preliminary injunction to maintain the status quo or prevent irreparable harm prior to the
appointment of the arbitrators and to the non-exclusive jurisdiction of such courts for the
enforcement of any ward issued hereunder.

13.7 Waiver of Jury Trial. EACH OF THE PARTIES HERETO IRREVOCABLY WAIVES ANY AND ALL RIGHT TO TRIAL
BY JURY IN ANY LEGAL PROCEEDING ARISING OUT OF OR RELATED TO THIS AGREEMENT OR THE TRANSACTIONS
CONTEMPLATED HEREBY.

13.8 Entire Agreement; Amendments. This Agreement, together with the Schedules and Exhibits hereto,
contains the entire understanding of the Parties with respect to the subject matter hereof. Any
other express or implied agreements and understandings, negotiations, writings and commitments,
either oral or written, in respect to the subject matter hereof (including the Confidentiality
Agreement, but solely with respect to information which is deemed Confidential Information
hereunder) are superseded by the terms of this Agreement. The Exhibits to this Agreement are
incorporated herein by reference and shall be deemed a part of this Agreement. This Agreement may be
amended, or any term hereof modified, only by a written instrument duly executed by authorized
representative(s) of both Parties hereto.

13.9 Headings. The captions to the several Articles, Sections and subsections hereof are not a part
of this Agreement, but are merely for convenience to assist in locating and reading the several
Articles and Sections hereof.

13.10 Independent Contractors. It is expressly agreed that Valeant and Dova shall be independent
contractors and that the relationship between the two Parties shall not constitute a partnership,
joint venture or agency. Neither Valeant nor Dova shall have the authority to make any statements,
representations or commitments of any kind, or to take any action, which shall be binding on the
other Party, without the prior written consent of the other Party.

13.11 Third Party Beneficiaries. Except as set forth in ARTICLE 11, no Person other than Dova or
Valeant (and their respective Affiliates and permitted successors and assignees hereunder) shall be
deemed an intended beneficiary hereunder or have any right to enforce any obligation of this
Agreement.

13.12 Waiver. The waiver by either Party hereto of any right hereunder, or of any failure of the
other Party to perform, or of any breach by the other Party, shall not be deemed a waiver of any
other right hereunder or of any other breach by or failure of such other Party whether of a similar
nature or otherwise.

13.13 Cumulative Remedies. No remedy referred to in this Agreement is intended to be exclusive, but
each shall be cumulative and in addition to any other remedy referred to in this Agreement or
otherwise available under law.

13.14 Waiver of Rule of Construction. Each Party has had the opportunity to consult with counsel in
connection with the review, drafting and negotiation of this Agreement. Accordingly, the rule of
construction that any ambiguity in this Agreement shall be construed against the drafting Party
shall not apply.

13.15 Use of Names. Except as otherwise provided herein, neither Party shall have any right, express
or implied, to use in any manner the name or other designation of the other Party or any other trade
name, trademark or logo of the other Party for any purpose in connection with the performance of
this Agreement.

13.16 Further Actions and Documents. Each Party agrees to execute, acknowledge and deliver all such
further

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 37 -->
instruments, and to do all such further acts, as may be reasonably necessary or appropriate to carry
out the intent and purposes of this Agreement.

13.17 Certain Conventions. Any reference in this Agreement to an Article, Section, subsection,
paragraph, clause, or Exhibit shall be deemed to be a reference to an Article, Section, subsection,
paragraph, clause, or Exhibit, of or to, as the case may be, this Agreement, unless otherwise
indicated. Unless the context of this Agreement otherwise requires, (a) words of any gender include
each other gender, (b) words such as "herein", "hereof", and "hereunder" refer to this Agreement as
a whole and not merely to the particular provision in which such words appear, (c) words using the
singular shall include the plural, and vice versa, (d) whenever any provision of this Agreement uses
the term "including" (or "includes"), such term shall be deemed to mean "including without
limitation" (or "includes without limitations"), and (e) references to any Articles or Sections
include Sections and subsections that are part of the references' Article or Section (e.g., a
section numbered "Section 2.2.1" would be part of "Section 2.2", and references to "ARTICLE 2" or
"Section 2.2" would refer to material contained in the subsection described as "Section 2.2.1").

13.18 Counterparts. This Agreement may be executed in two or more counterparts, each of which shall
be deemed an original, but all of which together shall constitute one and the same instrument.
Counterparts may be delivered via facsimile or electronic mail (including pdf) and any counterpart
so delivered shall be deemed to have been duly and validly delivered and be valid and effective for
all purposes and shall have the same force and effect as original signatures.

[signature page follows]

[Signature page to Co-Promotion Agreement]

IN WITNESS WHEREOF, the Parties have executed this Agreement as of the Effective Date.

DOVA PHARMACEUTICALS, INC.

By: __/s/ Alex C. Sapir______________________

Name: Alex C. Sapir

Title: CEO

VALEANT PHARMACEUTICALS NORTH AMERICA LLC

By: ___/s/ Joseph C. Papa_______________

Name: Joseph C. Papa

Title: Chief Executive Officer and President

9

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 38 -->
EXHIBIT A

Joint Press Release

DURHAM, N.C. and BRIDGEWATER, N.J., Sept. 27, 2018 (GLOBE NEWSWIRE) -- Dova Pharmaceuticals, Inc.
("Dova") (DOVA), a specialty pharmaceutical company focused on acquiring, developing, and
commercializing drug candidates for diseases where there is a high unmet need, and Salix
Pharmaceuticals ("Salix"), one of the largest specialty pharmaceutical companies in the world
committed to the prevention and treatment of gastrointestinal diseases and its parent company,
Bausch Health Companies Inc. (NYSE/TSX: BHC), today announced that they have entered into an
exclusive agreement to co-promote Dova's DOPTELET (avatrombopag) in the United States (U.S.). The
U.S. Food and Drug Administration ("FDA") approved DOPTELET on May 21, 2018 for the treatment of
thrombocytopenia in adult patients with chronic liver disease (CLD) who are scheduled to undergo a
procedure. DOPTELET represents the first thrombopoietin (TPO) receptor agonist approved in the
United States for this indication.

Thrombocytopenia, a condition in which patients have a low platelet count, is the most common
hematological abnormality in patients with CLD that often worsens with the severity of liver
disease. It is estimated that approximately 15 percent of the 7.5 million patients with CLD have
some form of thrombocytopenia. In a study published in 2010, patients with severe thrombocytopenia
(<75,000/µL) had a 31 percent incidence of procedure-related bleeding. As a result of the associated
increased rate of bleeding, there is an increased risk for the CLD patient when undergoing common
scheduled medical procedures such as liver biopsy, colonoscopy, endoscopy, and routine dental
procedures.

As part of the co-promotion arrangement, Salix intends to deploy approximately 100 sales specialists
who will promote DOPTELET to gastroenterology healthcare professionals. The Salix sales force will
begin selling DOPTELET in mid-October 2018. Dova will continue its commercial efforts targeting
primarily hepatologists and interventional radiologists and certain other specialties. Pursuant to
the agreement, Dova will pay Salix a quarterly fee based on net sales (as defined in the agreement)
of DOPTELET prescribed by gastroenterologists in the U.S.

"We are delighted to be working with Salix, a company considered by many to have the preeminent
gastroenterology sales force in the United States," said Alex C. Sapir, president and chief
executive officer, Dova Pharmaceuticals. "Given Salix's presence and strong reputation within large
gastroenterology group practices coupled with the early interest we are seeing among the
gastroenterology community, we are excited to see the impact this partnership will bring to DOPTELET
and to patients."

"Salix considers liver disease a strategic therapeutic area of focus, given our history and
knowledge with XIFAXAN® (rifaximin), an innovative medicine indicated for the treatment of overt
hepatic encephalopathy (HE), a condition that is often a consequence of chronic liver disease," said
Mark McKenna, president, Salix Pharmaceuticals. "Adding DOPTELET to our portfolio will enable our
sales force to promote yet another innovative product that addresses a true unmet need in the
marketplace."

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 39 -->
About DOPTELET DOPTELET (avatrombopag) is a second generation, once daily, orally administered TPO
receptor agonist approved for the treatment of thrombocytopenia in adult patients with CLD who are
scheduled to undergo a procedure. DOPTELET is designed to mimic the effects of TPO, the primary
regulator of normal platelet production.

Two global Phase 3, double-blind, placebo-controlled trials (ADAPT-1 [N=231] and ADAPT-2 [N=204]),
conducted in adults with thrombocytopenia (platelet count of less than 50,000/µL) and CLD, supported
the FDA approval. Patients were assigned to either 40 mg or 60 mg of avatrombopag daily for five
days based on their Baseline platelet counts (40 to <50,000/µmL or <40,000/µmL, respectively).
Avatrombopag was shown to be superior to placebo in increasing the proportion of patients not
requiring platelet transfusions or rescue procedures for bleeding up to seven days following a
scheduled procedure in both trials in both the 40 mg (ADAPT-1, 88% vs. 38%, p <0.0001; ADAPT-2, 88%
vs. 33%; p<0.0001), and 60 mg (ADAPT-1, 66% vs. 23%, p <0.0001; ADAPT-2, 69% vs. 35%; p=0.0006)
treatment groups. Avatrombopag was also superior to placebo at the two secondary efficacy endpoints
in each trial. In the avatrombopag treatment groups, there was an increased proportion of patients
achieving the target platelet count of ≥50,000/µmL on procedure day, and a greater magnitude of the
change in mean platelet count from baseline to procedure day; all treatment differences between the
avatrombopag and placebo treatment groups for each secondary endpoint were highly statistically
significant with p values <0.0001. The most common adverse reactions with avatrombopag included
pyrexia, abdominal pain, nausea, headache, fatigue and edema peripheral. Portal vein thromboses have
been reported in patients with CLD and in patients receiving TPO receptor agonists. One
treatment-emergent event of portal vein thrombosis was reported in the ADAPT trials in an
avatrombopag-treated patient.

INDICATION

DOPTELET (avatrombopag) is indicated for the treatment of thrombocytopenia in adult patients with
chronic liver disease who are scheduled to undergo a procedure.

IMPORTANT SAFETY INFORMATION

WARNINGS AND PRECAUTIONS

DOPTELET is a thrombopoietin (TPO) receptor agonist and TPO receptor agonists have been associated
with thrombotic and thromboembolic complications in patients with chronic liver disease. Portal vein
thrombosis has been reported in patients with chronic liver disease treated with TPO receptor
agonists. In the ADAPT-1 and ADAPT-2 clinical trials, there was one treatment- emergent event of
portal vein thrombosis in a patient (n=1/430) with chronic liver disease and thrombocytopenia
treated with DOPTELET.

Consider the potential increased thrombotic risk when administering DOPTELET to patients with known
risk factors for thromboembolism, including genetic prothrombotic conditions (Factor V Leiden,
Prothrombin 20210A, Antithrombin deficiency or Protein C or S deficiency).

DOPTELET should not be administered to patients with chronic liver disease in an attempt to
normalize platelet counts.

CONTRAINDICATIONS: None

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 40 -->
ADVERSE REACTIONS

Most common adverse reactions (≥ 3%) were: pyrexia, abdominal pain, nausea, headache, fatigue, and
edema peripheral.

Please see full Prescribing Information for DOPTELET (avatrombopag) www.doptelet.com

About XIFAXAN XIFAXAN is a nonsystemic* antibiotic that slows the growth of bacteria in the gut that
are believed to be linked to symptoms of overt hepatic encephalopathy (HE). It has been proven to
reduce the risk of overt HE recurrence and HE-related hospitalizations in adults.

*There is an increased systemic exposure in patients with severe (Child-Pugh Class C) hepatic
impairment. Caution should be exercised when administering XIFAXAN to these patients.

INDICATION XIFAXAN (rifaximin) 550 mg tablets are indicated for the reduction in risk of overt
hepatic encephalopathy (HE) recurrence in adults and for the treatment of irritable bowel syndrome
with diarrhea (IBS-D) in adults.

IMPORTANT SAFETY INFORMATION

•XIFAXAN is not for everyone. Do not take XIFAXAN if you have a known hypersensitivity to rifaximin,
any of the rifamycin antimicrobial agents, or any of the components in XIFAXAN.

•If you take antibiotics, like XIFAXAN, there is a chance you could experience diarrhea caused by an
overgrowth of bacteria (C. difficile). This can cause symptoms ranging in severity from mild
diarrhea to life-threatening colitis. Contact your healthcare provider if your diarrhea does not
improve or worsens.

•Talk to your healthcare provider before taking XIFAXAN if you have severe hepatic (liver)
impairment, as this may cause increased effects of the medicine.

•Tell your healthcare provider if you are taking drugs called P-glycoprotein and/or OATPs inhibitors
(such as cyclosporine) because using these drugs with XIFAXAN may lead to an increase in the amount
of XIFAXAN absorbed by your body.

•In clinical studies, the most common side effects of XIFAXAN were: HE: Peripheral edema (swelling,
usually in the ankles or lower limbs), nausea (feeling sick to your stomach), dizziness, fatigue
(feeling tired), and ascites (a buildup of fluid in the abdomen) IBS-D: Nausea (feeling sick to your
stomach) and an increase in liver enzymes

•XIFAXAN may affect warfarin activity when taken together. Tell your healthcare provider if you are
taking warfarin because the dose of warfarin may need to be adjusted to maintain proper
blood-thinning effect.

•If you are pregnant, planning to become pregnant, or nursing, talk to your healthcare provider
before taking XIFAXAN because XIFAXAN may cause harm to an unborn baby or nursing infant. You are
encouraged to report negative side effects of prescription drugs to the FDA. Visit
www.fda.gov/medwatch or call 1-800- FDA-1088.

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 41 -->
For product information, adverse event reports, and product complaint reports, please contact: Salix
Product Information Call Center Phone: 1-800-321-4576 Fax: 1-510-595-8183 Email: salixmc@dlss.com
Please click here for full Prescribing Information.

About Dova Pharmaceuticals, Inc. Dova is a pharmaceutical company focused on acquiring, developing,
and commercializing drug candidates for rare diseases where there is a high unmet need, with an
initial focus on addressing thrombocytopenia. Dova's proprietary pipeline includes one commercial
product, DOPTELET, for the treatment of thrombocytopenia in adult patients with CLD scheduled to
undergo a procedure.

About Salix Salix is one of the largest specialty pharmaceutical companies in the world committed to
the prevention and treatment of gastrointestinal diseases. For almost 30 years, Salix has licensed,
developed, and marketed innovative products to improve patients' lives and arm health care providers
with life-changing solutions for many chronic and debilitating conditions. Salix currently markets
its product line to U.S. health care providers through an expanded sales force that focuses on
gastroenterology, hepatology, pain specialists, and primary care. Salix is headquartered in
Bridgewater, New Jersey.

About Bausch Health Bausch Health Companies Inc. (NYSE/TSX: BHC) is a global company whose mission
is to improve people's lives with our health care products. We develop, manufacture and market a
range of pharmaceutical, medical device and over-the-counter products, primarily in the therapeutic
areas of eye health, gastroenterology and dermatology. We are delivering on our commitments as we
build an innovative company dedicated to advancing global health. More information can be found at
www.bauschhealth.com.

Dova Pharmaceuticals Cautionary Notes Regarding Forward-Looking Statements Any statements contained
in this press release that do not describe historical facts may constitute forward-looking
statements as that term is defined in the Private Securities Litigation Reform Act of 1995. These
statements may be identified by words such as "anticipated", "believe", "expect", "may", "plan",
"potential", "will", and similar expressions, and are based on Dova's current beliefs and
expectations. These forward-looking statements include the potential benefits of the collaboration,
the timing of the Salix sales force beginning to sell DOPTELET and other information relating to the
transaction between Dova and Salix. These statements involve risks and uncertainties that could
cause actual results to differ materially from those reflected in such statements. Risks and
uncertainties that may cause actual results to differ materially include uncertainties inherent in
the conduct of clinical trials, increased regulatory requirements, Dova's reliance on third parties
over which it may not always have full control, and other risks and uncertainties that are described
in Dova's Annual Report on Form 10-K for the year ended December 31, 2017, filed with the U.S.
Securities and Exchange Commission (SEC) on February 16, 2018, and Dova's other periodic reports
filed with the SEC. Any forward-looking statements speak only as of the date of this press release
and are based on information available to Dova as

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 42 -->
of the date of this release, and Dova assumes no obligation to, and does not intend to, update any
forward-looking statements, whether as a result of new information, future events or otherwise.

Bausch Health Forward-looking Statements This news release may contain forward-looking statements,
which may generally be identified by the use of the words "anticipates," "expects," "intends,"
"plans," "should," "could," "would," "may," "will," "believes," "estimates," "potential," "target,"
or "continue" and variations or similar expressions. These statements are based upon the current
expectations and beliefs of management and are subject to certain risks and uncertainties that could
cause actual results to differ materially from those described in the forward- looking statements.
These risks and uncertainties include, but are not limited to, risks and uncertainties discussed in
the Bausch Health's most recent annual or quarterly report and detailed from time to time in Bausch
Health's other filings with the Securities and Exchange Commission and the Canadian Securities
Administrators, which factors are incorporated herein by reference. In addition, certain material
factors and assumptions have been applied in making these forward-looking statements, including that
the risks and uncertainties outlined above will not cause actual results or events to differ
materially from those described in these forward-looking statements. Bausch Health believes that the
material factors and assumptions reflected in these forward-looking statements are reasonable, but
readers are cautioned not to place undue reliance on any of these forward-looking statements. These
forward-looking statements speak only as of the date hereof. Bausch Health and Salix undertake no
obligation to update any of these forward-looking statements to reflect events or circumstances
after the date of this news release or to reflect actual outcomes, unless required by law.

Dova Investor Contacts: Mark W. Hahn Chief Financial Officer mhahn@dova.com (919) 338-7936

Salix Investor Contact: Arthur Shannon Arthur.Shannon@bauschhealth.com 514-856-3855 877-281-6642
(toll free)

Westwicke Partners John Woolford john.woolford@westwicke.com (443) 213-0506

Salix Media Contacts: Lainie Keller Lainie.Keller@bauschhealth.com 908-927-0617

Karen Paff

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 43 -->
Karen.Paff@salix.com 908-927-1190

AkaRx, Inc., a wholly owned subsidiary of Dova Pharmaceuticals, Inc., is the exclusive licensee and
distributor of DOPTELET® in the United States and its territories. ©2018 DOPTELET® is a registered
trademark of AkaRx, Inc.

PM-US-DOP-0072

The Xifaxan 550 mg product and the Xifaxan trademark are licensed by Alfasigma S.p.A.to Salix
Pharmaceuticals or its affiliates.

SAL.0103.USA.18

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
<!-- page 44 -->
Schedule 1.65

Third Party Agreements

1. Stock Purchase Agreement dated March 29, 2016 (as amended) between PBM AKX Holdings, LLC and
Eisai, Inc.

2. License Agreement dated August 15, 2005 (as amended) between Astellas Pharma Inc. and AkaRx, Inc.

CONFIDENTIAL TREATMENT HAS BEEN REQUESTED FOR PORTIONS OF THIS EXHIBIT. THE COPY FILED HEREWITH
OMITS THE INFORMATION SUBJECT TO A CONFIDENTIALITY REQUEST. OMISSIONS ARE DESIGNATED [***]. A
COMPLETE VERSION OF THIS EXHIBIT HAS BEEN FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE
COMMISSION.

Source: DOVA PHARMACEUTICALS INC., 10-Q, 11/8/2018
