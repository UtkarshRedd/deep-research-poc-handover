<!-- page 1 -->
# CELEBRITY ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2012-03-14 |
| Parties | Bizzingo, Inc ("Bizzingo"); Joseph Theismann ("Theismann") |
| Source | CUAD v1 / BizzingoInc_20120322_8-K_EX-10.17_7504499_EX-10.17_Endorsement Agreement |

CELEBRITY ENDORSEMENT AGREEMENT THIS AGREEMENT is made as of this March 14, 2012 but effective as of
March 1, 2012 ("Effective Date") by and between Bizzingo, Inc., a Nevada corporation with offices at
63 Main Street, Suite 202, Flemington, NJ 08822 ("Bizzingo") and Joseph Theismann, an individual
whose address is 21495 Ridgetop Circle, Suite 304A, Sterling Virginia 20166 ("Theismann")
(collectively the "Parties"). WITNESSETH: WHEREAS, Theismann is recognized and widely known
throughout the world as a retired, hall of fame professional athlete, and sports celebrity; and
WHEREAS, Theismann's name, by virtue of his ability and experience, has acquired a meaning in the
mind of the purchasing public important to the advertising, promotion, and sale of services and
merchandise; and WHEREAS, Bizzingo has developed a B2B interactive platform which engages in
business social media including mobile and Internet applications ("Network"); and WHEREAS, Bizzingo
is desirous of acquiring the rights to utilize Theismann's name in connection with the
advertisement, promotion, and sale of the Network as provided herein and Theismann is willing to
grant such right NOW, THEREFORE, in consideration of the mutual covenants set forth herein and for
other good and valuable consideration, it is agreed as follows: 1. GRANT OF RIGHTS. Subject to the
terms and conditions set forth herein, Theismann hereby grants to Bizzingo and its affiliates the
unlimited right and privilege during the Term (as defined herein) and within the Territory to use
the Property (as defined herein) in connection with the advertisement, promotion, and sale of the
Network in the Territory whether through film, television, radio, print and Internet media,
including the right to use the Property in or on the Network. It being understood and agreed that
Bizzingo shall have the right to exhibit commercials, infomercials, advertisements and otherwise
make use of all Property on a worldwide basis and that Bizzingo and its affiliates shall be the sole
owner of all commercials, promotional materials and other items produced or created hereunder and
all related rights worldwide, including, without limitation, copyright, trademark and intellectual
property rights, subject however to the terms and conditions herein. Theismann agrees to cooperate
with Bizzzingo's promotional efforts in this regard. In addition, as reasonably requested by
Bizzingo, Theismann agrees to provide Bizzingo with such signatures, photographs and the like in
order to fulfill his obligations hereunder.

1

Source: BIZZINGO, INC., 8-K, 3/22/2012
<!-- page 2 -->
Bizzingo agrees that any use of the Property for advertising, promotional or sale purposes will be
approved in advance by Theismann. Theismann agrees that such material, submitted for approval as
provided herein may be deemed by Bizzingo to have been approved hereunder if the same is not
disapproved by the Theismann in writing within fourteen (14) days after Theismann's receipt thereof.
Theismann agrees that any material submitted hereunder will not be unreasonably disapproved and, if
it is disapproved, that Theismann shall advise Bizzingo in writing of the specific grounds therefor
at the time of disapproval and provide Bizzingo with specific changes or alterations to such
materials. Bizzingo thereafter shall have the right and privileged to use such Property as provided
in this Agreement subject to such changes or alterations. Except as stated herein, no other rights
or privileges are granted to Bizzingo by Theismann. "Property" as stated herein shall mean
Theismann's name (including "Joe Theismann", "Theismann" "J. Theismann"), nicknames, initials,
autograph, facsimile signature, photograph, image, likeness, voice, video portrayals, biographical
data, character, symbols, and/or other endorsement, and any variations or deviations thereof.
"Territory" as stated herein shall mean worldwide. 2. TERM. Unless sooner terminated under the
provisions hereof, this Agreement shall commence on the Effective Date and continue for a period of
one (1) year ("Term"). provided however, that the Parties may extend the Term for an additional year
period by entering into an written addendum of the Agreement extending such term. 3. COMPENSATION.

a. In consideration for the rights granted hereunder and for the promotional appearances provided
herein, Bizzingo, subject to the other terms and conditions herein, agrees to pay to Theismann
during the Term the royalty recited in Schedule A (the "Royalty"). In addition, concurrent with the
execution hereof, Bizzingo will pay Theismann the Initial Bonus described in Schedule A. b. The
Royalty owed Theismann shall be calculated on a quarterly calendar basis ("Royalty Period")
commencing on the first (1st) day of June, September, December, and March, except that the first and
last calendar quarters may be "short" depending on the effective date of this Agreement. Payment of
the Royalty shall be made no later than 45 days after the termination of the preceding full calendar
quarter. The foregoing notwithstanding, if this Agreement is terminated in accordance with the
provisions herein during a Royalty Period, the Royalty shall be calculated up to and including the
Termination Date and payment of the Royalty shall be made as provided herein. c. For each Royalty
Period, Bizzingo shall provide Theismann with a written royalty statement in a form acceptable to
Theismann certified by a duly authorized officer of Bizzingo. d. Theismann shall be responsible for
all federal, state and local taxes related to the Royalty.

2

Source: BIZZINGO, INC., 8-K, 3/22/2012
<!-- page 3 -->
4. PROMOTIONAL APPEARANCES. In addition to the other terms and conditions herein, during the Term,
Theismann also will;

Bizzingo recognizes that Theismann's schedule and will not schedule any such session or appearance
at a time that would conflict with Theismann's current obligations. Following the execution of this
Agreement, Theismann will provide Bizzingo with an availability schedule indicating black out and/or
available dates and from time to time will endeavor to update such schedule. In this regard,
Bizzingo agrees to provide Joseph Theismann with at least thirty (30) days' written notice of any
photographic sessions or public appearances to permit Theismann to properly schedule the session or
appearance. Bizzingo will pay all reasonable out of pocket expenses incurred by Theismann in
connection with such session or appearance which expenses shall not exceed One Thousand Dollars
($1,000) per day unless Theismann receives prior written approval from Bizzingo. For any travel
incurred by Theismann as part of his appearances, Bizzingo will provide first class air travel and
hotel accommodations. 5. NOTICES AND PAYMENTS. Any notice, request, demand or other communication
required or permitted hereunder shall be in writing and shall be deemed properly given when actually
received or within fourteen (14) days of mailing by certified or registered mail, return receipt
requested, postage prepaid, whichever first occurs,

a. Make himself available for four (4) sessions for production of photographs, or radio, television,
video or other multi-media programming for use in Bizzingo's advertising or promotional materials,
with each such session not exceeding eight (8) hours. b. Make four (4) public appearance for the
purpose of promoting the Network, which may include autograph sessions, dinner appearances, and/or
other appearances not described in 4(a) above, with each such session not exceeding two (2) hours.

to Theismann at: JRT Associates, Inc. 21495 Ridgetop Circle, Suite 304A Sterling, Virginia 20166
With a copy to: Eric V. Zimmerman, Esquire Miller Zimmerman, PLC 50 Catoctin Circle, Suite 201
Leesburg, Virginia 20176 to Bizzingo at: 63 Main Street Suite 202 Flemington, NJ 08822

3

Source: BIZZINGO, INC., 8-K, 3/22/2012
<!-- page 4 -->
Either party may change its address for the purpose of this Agreement by giving notice to the other
party in accordance herewith. 6. INSPECTION AND AUDIT. Theismann or his representatives, at his cost
and expense, shall have the right, upon reasonable notice and during normal business hours, to
inspect Bizzingo's books and records and all other documents and material in Bizzingo's possession
or control with respect to the determination of Royalties payable hereunder. Theismann shall have
free and full access thereto for such purposes and may make copies thereof. All books and records
relative to Bizzingo's obligations hereunder shall be maintained and made accessible to Theismann
for inspection at a location in the United States for at least one year after termination of this
Agreement. 7. RESERVATION OF RIGHTS. (a). Except as stated herein, Theismann shall retain all rights
in and to his name, his right of publicity, and the endorsement whether during the Term or any
extension thereof. Notwithstanding the foregoing, during the term and for a period of one (1) year
thereafter, Theismann shall not use, permit the use of, or license to others the Property in
connection with the advertisement, promotion, and sale of any network or Internet service, including
but limited to all computer/video games, CD-ROMs, and/or interactive video of any form, except for a
pre-existing license by Theismann. Bizzingo and Theismann agree that they shall take all necessary
steps during the Term to protect the endorsement in connection with the advertisement, promotion,
and sale of the Network. (b). It is understood and agreed that Theismann shall retain all right,
title, and interest in his likeness, name, and/or trademarks, where applicable, except as rights
granted hereunder. (c). The parties agree to execute any documents reasonably requested by the other
party to effect any of the above provisions. 8. RESTRICTED STOCK, RISK OF INVESTMENT, AND INVESTMENT
INTENT. (a). Theismann acknowledges that the Royalty Warrant and Bonus Warrant and the shares of
common stock of Bizzingo underlying such warrants are "restricted securities" as that term is
defined under federal securities laws. In addition, any stock certificate representing such shares
shall contain the restrictive legend set for on Schedule A may not be sold, transferred or
hypothecated unless such transfer is pursuant to an effective registration statement or an exemption
from such registration as verified by an opinion of counsel acceptable to Bizzingo.

With a copy to: Daniel H. Luciano, Esq. 242A West Valley Brook Road Califon,NJ 07830

4

Source: BIZZINGO, INC., 8-K, 3/22/2012
<!-- page 5 -->
(b). Theismann acknowledges and agrees that any investment in Bizzingo warrants and common stock
involves substantial risks and that Theismann or his representative has had the opportunity to
review fully the books, records and financial statements of Bizzingo along with the Quarterly,
Annual and Periodic filings of Bizzingo on the Securities and Exchange Commission's EDGAR website
(http://sec.gov/edgar/searchedgar/companvsearch.html) and has determined that Bizzingo common stock
is a suitable investment and he can bear the risk associated with such investment. (c). Theismann
represents and warrants to Bizzingo that he is acquiring such shares of Bizzingo common stock for
investment purposes and not with a view towards distribution. 9. REPRESENTATIONS, WARRANTIES AND
INDEMNITY.

a. Theismann represents and warrants that, except as otherwise disclosed herein, he has not granted
nor will he grant during the Term and for a period of one (1) year thereafter to any other party any
right, permission, or license to use the Property in connection with the advertisement, sale, or
promotion of the Network or in connection with networks that are identical or substantially similar
to the Network. b. Theismann further represents and warrants to Bizzingo that he is the owner free
and clear of the rights granted herein, and has the full right. power, legal capacity and authority
to grant the rights herein. c. Theismann further represents and warrants that he has not
misrepresented or concealed anything with respect to his or her background that may have a
prejudicial effect on the value of the endorsement, that he is in good health and does not plan to
retire during the Term of this Agreement, and that he or she has not engaged nor will he or she
engage during the Term of this Agreement in any activity (criminal or otherwise) that could
potentially have a negative impact on the Network. d. Bizzingo agrees to defend, indemnify, and hold
Theismann harmless against all costs, expenses, and losses (including reasonable attorney fees and
costs) incurred through claims of third parties against Theismann based on the manufacture or sale
of the Network including, but not limited to, actions founded on network liability. In this
regarding, within thirty (30) days from the execution of this Agreement, Bizzingo will secure an
insurance policy with limits of $5,000,000 per event and $ 5,000,000 umbrella, naming Theismann as
an additional insured, covering the losses and claims stated in this sub-paragraph d. e. Theismann
agrees to defend, indemnify, and hold Bizzingo, and its officers, directors, agents, and employees,
harmless against all costs, expenses, and losses (including reasonable attorney fees and costs)
incurred through claims of third parties against Bizzingo based on a breach by Theismann of any
representation and/or warranty made in this Agreement or with respect to any third-party claims for
infringement involving the use of the Property by Bizzingo.

5

Source: BIZZINGO, INC., 8-K, 3/22/2012
<!-- page 6 -->
10. TERMINATION.

Upon termination of this Agreement as provided in this Section 10 (each a "Termination Date") or
upon the expiration of the Term, Bizzingo shall cease using the Property in any way, and Theismann
shall not be entitled to the Royalty, in each case from and after the Termination Date. 11.
RELATIONSHIP OF THE PARTIES. Theismann's performance of services for Bizzingo hereunder is in his or
her capacity as an independent contractor. Accordingly, nothing contained in this Agreement shall be
construed as establishing an employer/employee, a partnership, or a joint venture relationship
between Theismann and Bizzingo.

a. Theismann shall have the right to terminate this Agreement upon thirty (30) days prior written
notice to Bizzingo upon the occurrence of any of the following: i. Bizzingo is adjudicated
insolvent, declares bankruptcy, or ii. Bizzingo fails to continue its business of selling the
Network; provided, however, that nothing contained in this Agreement shall obligate Bizzingo to sell
any specific quantities of Network during the Term; iii. Bizzingo fails to make payment to Theismann
of any Royalties due pursuant to this Agreement within thirty (30) days after such due date; iv.
Bizzingo fails to maintain the liability insurance as herein provided. b. Bizzingo shall have the
right to terminate this Agreement upon thirty (30) days prior written notice to Theismann or his or
her legal representative upon the occurrence of any of the following: i. Theismann engages in
illegal, immoral, or criminal conduct resulting in a felony conviction; misrepresents or conceals
anything in his or her background that could be detrimental to the value of the endorsement being
made; engages in conduct contrary to the best interests of Bizzingo; engages in conduct that offends
the sensitivities of a significant portion of the population; or engages in conduct that could bring
Theismann into public disrepute; ii. Totally retires from the entertainment or sports industry; or
iii. Upon Theismann's death. c. In addition to as stated in (a) or (b) above, either party may
terminate this Agreement in the event of a breach of any provision of this Agreement by the other by
providing thirty (30) days* prior written notice to the breaching party, provided that, during the
30- day period, the breaching party fails to cure such breach. d. Theismann shall have the right to
terminate this Agreement at any time upon thirty (30) days' written notice to Bizzingo, such
termination to become effective at the conclusion of such 30-day period.

6

Source: BIZZINGO, INC., 8-K, 3/22/2012
<!-- page 7 -->
12. FORCE MAJEURE. Neither party will be liable for, or will be considered to be in breach of or
default under this Agreement on account of, any delay or failure to perform as required by this
Agreement as a result of any causes or conditions that are beyond such Party's reasonable control
and that such Party is unable to overcome through the exercise of commercially reasonable diligence.
If any force majeure event occurs, the affected Party will give prompt written notice to the other
Party and will use commercially reasonable efforts to minimize the impact of the event. 13.
JURISDICTION/DISPUTES. The Parties hereby agree that all disputes related to this Agreement shall be
settled by arbitration pursuant to the rules and regulations of the American Arbitration
Association. Parties all consent to the jurisdiction of such courts, agree to accept service of
process by mail, and hereby waive any jurisdictional or venue defenses otherwise available to it 14.
AGREEMENT BINDING ON SUCCESSORS. The provisions of the Agreement shall be binding upon and shall
inure to the benefit of the Parties hereto, their heirs, administrators, successors and assigns. 15.
ASSIGNABILITY. Neither party may assign this Agreement or the rights and obligations thereunder to
any third party without the prior express written approval of the other party which shall not be
unreasonably withheld. 16. WAIVER. No waiver by either party of any default shall be deemed as a
waiver of prior or subsequent default of the same of other provisions of this Agreement. 17.
SEVERABILITY. If any term, clause or provision hereof is held invalid or unenforceable by a court of
competent jurisdiction, such invalidity shall not affect the validity or operation of any other
term, clause or provision and such invalid term, clause or provision shall be deemed to be severed
from the Agreement. 18. INTEGRATION. This Agreement constitutes the entire understanding of the
Parties, and revokes and supersedes all prior agreements between the Parties and is intended as a
final expression of their Agreement. It shall not be modified or amended except in writing signed by
the Parties hereto and specifically referring to this Agreement. This Agreement shall take
precedence over any other documents which may conflict with this Agreement. 19. CONFIDENTIALITY AND
NON-DISPARAGEMENT AGREEMENT. Concurrent with the execution of this agreement, the parties will
execute a mutually acceptable Confidentiality and Non-Disparagement Agreement. IN WITNESS WHEREOF,
the Parties hereto, intending to be legally bound hereby, have each caused to be affixed hereto its
or his/her hand on the day indicated above.

7

Source: BIZZINGO, INC., 8-K, 3/22/2012
<!-- page 8 -->
Theismann

Bizzingo, Inc.

Joseph Theismann

Douglas Toth President

8

Source: BIZZINGO, INC., 8-K, 3/22/2012
<!-- page 9 -->
SCHEDULE A (Attached to and made a part of the Celebrity Endorsement Agreement dated March 14, 2012
by and between Bizzingo, Inc. and Joseph Theismann) I Background Bizzingo expects to populate its
Network with Activated Users (as defined herein) through two distinct methods. Method 1. (a).
Bizzingo will acquire basic business information for a prospective user of the Network, which will
include all or part of the following; business name and address, telephone number, email address or
website. This basic business information will be acquired through (i) arrangements with specific
groups, clubs, networks, or associations, such as Chambers of Commerce, Universities, or trade
organization, to acquire member information, or (ii) through purchase or license arrangements with
content providers. In either case, once Bizzingo obtains information for a specific user, it will
use that information to create or seed a separate user profile in its database for that prospective
user ("Seeded Profile"). As of the date of this Agreement, Bizzingo has arrangements with content
providers and associations to provide the basic business information for over 6,000,000 prospective
users which will be seeded by Bizzingo. For clarification purposes, at this point in the process, a
Seeded Profile is not an "Activated User." (b). In order to activate a Seeded Profile, Bizzingo will
contact a prospective user informing them of the existence of their Seeded Profile on the Network,
and the prospective user is then required to: (i) search and locate the Bizzingo database for its
Seeded Profile and (ii) claim the Seeded Profile by editing or adding content to the Seeded Profile.
Once the steps set forth in the immediately preceding sentence has been completed by a user, that
user will be deemed to be an "Activated User" and the Network will identify that user as an
Activated User. Method 2. A prospective user independently (from Method 1) may create its own user
profile on the Network. This user will be deemed an Activated User and the Network will identify
that user as an "Activated User." II Royalty and Initial Bonus 1. Royalty. The Royalty payable under
the Agreement shall be in the form of one (1) common stock purchase warrant of Bizzingo (as further
described herein) for each Activated User (as defined above) that occurs during a Royalty Period
determined on the last day of each Royalty Period during the Term. It being the intent of the
parties that no more than one (1) common stock purchase warrant shall be issued per Activated User,
and by way of example, if on the last day of the first and second Royalty Periods, the Network has
500,000 and 1,500,000 Activated Users, respectively, Theismann shall receive 500,000 common stock
purchase warrants for the first Royalty Period and an additional 1,000,000 common stock purchase
warrants for the second Royalty Period. Each common stock purchase warrant shall enable Theismann to
acquire one (1) share of common stock of Bizzingo at an exercise price of $0.15 per share during a
term of five (5) years from the end of the applicable Royalty Period. The form of the warrant is
attached hereto as Schedule A-l and shall be referred to as the "Royalty Warrant."

9

Source: BIZZINGO, INC., 8-K, 3/22/2012
<!-- page 10 -->
2. Initial Bonus. Concurrent with the execution hereof, Bizzingo will issue Theismann, as a one time
bonus, a common stock purchase warrant to purchase 1,000,000 shares of common stock of Bizzingo at a
purchase price of $0.15 per share during a term of five (5) years. The form of warrant is attached
hereto as Schedule A-II and shall be referred to as the "Bonus Warrant." 3. Restrictive Legend. The
restricted legend for purposes of any certificate representing the Royalty Warrant and Bonus
Warrant, and the stock certificate for shares underlying the Royalty Warrant or Bonus Warrant is as
follows:

The securities represented by this certificate have not been registered under the United States
Securities Act of 1933, as amended (the "Act") or any state securities law. These shares have been
acquired for investment and may not be offered for sale, hypothecated, sold or transferred, nor will
any assignee or transferee thereof be recognized by the Company as having any interest in such
shares, in the absence of(i) an effective registration statement with respect to the shares under
the Act, and any other applicable state law, or (ii) an opinion of counsel satisfactory to the
Company that such shares will be offered for sale, hypothecated, sold or transferred only in a
transaction which is exempt under or is otherwise in compliance with the applicable securities laws.
***

10

Source: BIZZINGO, INC., 8-K, 3/22/2012
<!-- page 11 -->
Source: BIZZINGO, INC., 8-K, 3/22/2012
