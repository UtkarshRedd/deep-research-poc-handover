<!-- page 1 -->
# SECOND AMENDMENT TO SERVICES AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2016-03-01 |
| Parties | FEDERATED INVESTMENT MANAGEMENT COMPANY ("Adviser"); FEDERATED ADVISORY SERVICES COMPANY ("FASC") |
| Source | CUAD v1 / FEDERATEDGOVERNMENTINCOMESECURITIESINC_04_28_2020-EX-99.SERV AGREE-SERVICES AGREEMENT_SECONDAMENDMENT |

SECOND AMENDMENT TO SERVICES AGREEMENT This SECOND AMENDMENT TO SERVICES AGREEMENT, dated and
effective as of March 1, 2016, (this "Second Amendment"), is made between FEDERATED INVESTMENT
MANAGEMENT COMPANY, a Delaware statutory trust (the "Adviser"), and FEDERATED ADVISORY SERVICES
COMPANY, a Delaware statutory trust ("FASC"). Capitalized terms used, but not defined, in this
Amendment have the meanings given to such terms in the Services Agreement (as defined below).
RECITALS WHEREAS, the Adviser and FASC have entered into that certain Services Agreement dated as of
January 1, 2004 (as amended, the "Services Agreement"), pursuant to which FASC provides certain
performance attribution and administration and risk management services to Adviser in connection
with Adviser providing investment advisory or sub-advisory services to investment companies
registered under the Investment Company Act of 1940 ("1940 Act") and/or separate accounts not
required to be so registered (collectively, "Accounts"); WHEREAS, the Adviser and FASC have entered
into the Amendment to Services Agreement dated as of March 30, 2009 (the "Amendment"), pursuant to
which the Services indicated in Exhibit A to the Services Agreement were amended solely with respect
to Accounts that are not investment companies registered under the 1940 Act, to provide that, as
part of the administration and risk management services provided by FASC, FASC may provide certain
coordination of client portfolios and related fixed income trade execution implementation and
administration services to Adviser when Adviser is acting as adviser or sub-adviser with respect to
such Accounts; and WHEREAS, the Adviser and FASC desire to amend the Services indicated in Exhibit A
to the Services Agreement, as amended, solely with respect to Accounts for which the Adviser trades
in equity securities, equity derivatives and other related equity investments as part of the
investment strategy for the Account, to provide that FASC may provide equity trading and transaction
settlement, fundamental analysis and quantitative analysis services to Adviser when Adviser is
acting as adviser or sub-adviser with respect to such Accounts. NOW, THEREFORE, the parties hereto,
intending to be legally bound, agree as follows: 1. Second Amendment to Exhibit A to Services
Agreement. Exhibit A to the Services Agreement shall be, and here by is, supplemented with the
following: "3. Equity Trading and Transaction Settlement. The equity trading desks execute buy and
sell order based on instructions provided by affiliated advisers. The trading staff either places
orders electronically or contacts brokers to place orders, find liquidity and seek price levels.
Upon completion of a transaction, the transaction settlement group works with the broker and the
account custodian to ensure timely and accurate exchange of securities and monies. 4. Fundamental
Analysis. The equity investment analysts provide independent research and analysis of specific
companies within a sector. Typically, analysis includes review of published reports, interviews of
company management, on-site observation of company operations, and the use of various financial
models. In addition, analysts read trade journals, attend industry conferences, and focus on trends
within the sector and industry. Based on this proprietary analysis, the analyst makes buy, sell or
hold recommendations to the Adviser. 5. Quantitative Analysis. Quantitative analysts develop and
apply financial models designed to enable equity portfolio managers and fundamental analysts to
screen potential and current investments, assess relative risk and enhance performance relative to
benchmarks and peers. To the extent that such services are to be provided with respect to any
Account which is a registered investment company, Categories 3, 4 and 5 above shall be treated as
"investment advisory services" for purposes of Section 5(b) of the Agreement." 2. Miscellaneous.
This Second Amendment shall be effective as of the date first above written upon its execution and
delivery by each of the parties hereto. The Services Agreement, as amended by the Amendment and this
Second Amendment with respect to Accounts for which the Adviser trades in equity securities, equity
derivatives and other related equity investments as part of the investment strategy for the Account,
shall remain in full force and effect. The Services Agreement, as amended by the Amendment, also
shall remain in full force and effect without this Second Amendment with respect to Accounts for
which the Adviser does not trade in equity securities, equity derivatives and other related equity
investments as part of the investment strategy for the Account. This Second Amendment shall be
governed by and construed in accordance with the laws of the Commonwealth of Pennsylvania. This
Second Amendment may be executed in one or more counterparts, each of which will be deemed to be an
original copy of this Second Amendment and all of which, when taken together, will be deemed to
constitute one and the same agreement. IN WITNESS WHEREOF, the parties hereto, through their duly
authorized officers, have executed this Second Amendment as of the date first above written.
FEDERATED INVESTMENT MANAGEMENT FEDERATED ADVISORY SERVICES COMPANY COMPANY By: /s/ John B. Fisher
By: /s/ J. Christopher Donahue Name: John B. Fisher Name: J. Christopher Donahue Title: President
Title: Chairman
