# When does the Recipe Development Agreement between Reed's, Inc. and BC Marketing Concep...

*Question:* When does the Recipe Development Agreement between Reed's, Inc. and BC Marketing Concepts Inc., dba Full Sail Brewing Company (dated 2019-10-11) expire, according to its term clause?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Answer

[GAP] No evidence was found for: Answer the question: When does the Recipe Development Agreement between Reed's, Inc. and BC Marketing Concepts Inc., dba Full Sail Brewing Company (dated 2019-10-11) expire, according to its term clause?

## Verification appendix

Claims: 1 · supported: 0 · partially: 0 · dropped: 0 · gaps: 1

Notes: no evidence in the bank; every section is a gap; OpenAIRateLimitError: Error code: 429

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  |  |

### Evidence

