"""Client-side request pacing so a rate-limited endpoint is never tripped (Phase 8 hardening).

A 429 costs 20-60 s of backoff per call and, on the NVIDIA Build free tier, kept a whole eval run
throttled; pacing requests under the limit avoids the penalty entirely. One token bucket per
endpoint key (base_url), shared by every role, thread-safe, process-wide.

Configure with DR_RPM_LIMIT (requests per minute across all roles; 0 or unset = off). Read at
call time so `.env` (loaded by dr.llm) applies without passing config around.
"""
from __future__ import annotations

import os
import threading
import time
from collections import deque


class RateLimiter:
    """Sliding-window limiter: at most `rpm` acquisitions in any 60 s window."""

    def __init__(self, rpm: int):
        self.rpm = max(1, rpm)
        self._times: deque[float] = deque()
        self._lock = threading.Lock()

    def acquire(self) -> float:
        """Block until a request may be sent; returns the seconds waited."""
        waited = 0.0
        while True:
            with self._lock:
                now = time.time()
                while self._times and now - self._times[0] >= 60.0:
                    self._times.popleft()
                if len(self._times) < self.rpm:
                    self._times.append(now)
                    return waited
                sleep_for = 60.0 - (now - self._times[0]) + 0.05
            time.sleep(sleep_for)
            waited += sleep_for


_limiters: dict[str, RateLimiter] = {}
_lock = threading.Lock()


def configured_rpm() -> int:
    try:
        return int(os.getenv("DR_RPM_LIMIT") or 0)
    except ValueError:
        return 0


def limiter_for(key: str, rpm: int | None = None) -> RateLimiter | None:
    """The shared limiter for `key` (e.g. the endpoint base_url), or None when pacing is off."""
    rpm = configured_rpm() if rpm is None else rpm
    if rpm <= 0:
        return None
    with _lock:
        lim = _limiters.get(key)
        if lim is None or lim.rpm != rpm:
            lim = RateLimiter(rpm)
            _limiters[key] = lim
        return lim


def pace(key: str, rpm: int | None = None) -> float:
    """Acquire a slot for one request; returns the seconds waited (0 when pacing is off)."""
    lim = limiter_for(key, rpm)
    return lim.acquire() if lim else 0.0
