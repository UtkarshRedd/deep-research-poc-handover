<!-- page 1 -->
# INTELLECTUAL PROPERTY RIGHTS AGREEMENT
| Field | Value |
|---|---|
| Document Type | IP Agreement |
| Agreement Date | 2017-10-02 |
| Parties | Synchron ("Investor"); Rare Element Resources Ltd. ("Company") |
| Source | CUAD v1 / RareElementResourcesLtd_20171019_SC 13D_EX-99.4_10897534_EX-99.4_Intellectual Property Agreement |

Exhibit 4

Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement

INTELLECTUAL PROPERTY RIGHTS AGREEMENT Synchron, a California corporation having a principal place
of business at 3550 General Atomics Court, San Diego, CA 92121-1122 (or one or more Affiliates, the
"Investor"), and Rare Element Resources Ltd., a British Columbia Corporation having a principal
place of business at P.O. Box 271049, Littleton, Colorado 80127 (the "Company") (Investor and
Company each a "Party" and together the "Parties"), agree as follows: I. Background of Agreement
1.00 Company is the owner of certain Patents and related Technical Information relating to rare
earth mineral processing and rare earth separation. 1.01 Investor wishes to acquire certain rights
under the Patents and related Technical Information in accordance with the terms of this IP
Agreement. 1.02 Company and Investor are concurrently entering into an Investment Agreement
("Investment Agreement") whereby Investor is making a monetary investment in Company. 1.03 Company
is issuing the Option pursuant to which Investor will be entitled to purchase common shares of
Company. II. Definitions As used herein, the following terms have the meaning set forth below: 2.01
Any term set out in this IP Agreement with its initial letters capitalized, shall have the same
meaning as it has in the Investment Agreement, unless a different meaning is explicitly assigned to
the term in this IP Agreement. 2.02 "Affiliate" has the meaning set forth in the Investment
Agreement. 2.03 "Business Day" has the meaning set forth in the Investment Agreement. 2.04 "Company"
has the meaning set out above in the introductory paragraph. 2.05 "Company Improvements" has the
meaning set out below in Article 5.00.

Page 1 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 2 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement 2.06 "Dispute" has the meaning set
out below in Article 18.00. 2.07 "Dispute Notice" has the meaning set out below in Article 18.00.
2.08 "Effective Date" has the meaning of the "Closing Date" set forth in the Investment Agreement.
2.09 "Escalation to Mediation Date" has the meaning set out below in Article 18.01. 2.10
"Improvement" or "Improvements" means any modification of a process or other technology described in
a Patent, and any modification to Technical Information. 2.11 "Investment Agreement" has the meaning
set out above in Article 1.02. 2.12 "Investor" has the meaning set out above in the introductory
paragraph. 2.13 "Investor Improvements" has the meaning set out below in Article 5.01. 2.14 "IP
Agreement" means this agreement, including all Exhibits referenced herein and attached hereto. 2.15
"Joint Improvements" has the meaning set out below in Article 5.02. 2.16 "Option" has the meaning
set forth in the Investment Agreement. 2.17 "Option Period" has the meaning set forth in the
Investment Agreement. 2.18 "Patent" or "Patents" means: (a) any and all patents and patent
applications owned by Company anywhere in the world as of the Effective Date relating to rare earth
mineral processing and rare earth separation including without limitation those patents and patent
applications listed in Exhibit A; (b) any and all divisions, continuations, continuations-in-part of
any of the patents and patent applications within subdivision (a); (c) any and all patents that may
directly or indirectly issue from any patent applications within subdivisions (a) and (b); (d) any
and all re- issues, substitutes and extensions of any of the patents within subdivisions (a), (b)
and (c); and (e) any and all counterparts or equivalents to any of the foregoing in any country of
the world. 2.19 "Party" and "Parties" have the meanings set out above in the introductory paragraph.

Page 2 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 3 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement 2.20 "Person" has the meaning set
forth in the Investment Agreement. 2.21 "Technical Information" means research and development
information that is published or unpublished, unpatented inventions, know-how, trade secrets, and
technical data in the possession of Company at the Effective Date of this IP Agreement or developed
by Company during the term of this IP Agreement that relate to rare earth mineral processing and
rare earth separation. 2.22 "Third Party" means a Person other than Investor, the Company or one of
their Affiliates. III. License 3.00 Company grants to Investor, for the duration of the Option
Period, a worldwide, royalty-free, non-exclusive, irrevocable license (with the right to grant
sublicenses to Affiliates) under the Patents to practice the methods therein described and claimed
and to make and have made, use, offer to sell, sell and import products made using such methods, and
to make Improvements, and to engage in any activity which would give rise to a claim of infringement
(direct or indirect or otherwise) of one or more of the Patents in the absence of a license. 3.01
Company further grants to Investor, during the duration of the Option Period, a worldwide,
royalty-free, non-exclusive, irrevocable license (with the right to grant sublicenses to Affiliates)
to use the Technical Information to practice the methods described and claimed in the Patents and to
make and have made, use, offer to sell, sell and import products made using the methods, and to make
Improvements, and to engage in any activity which would give rise to a claim of infringement (direct
or indirect or otherwise) of one or more of the Patents in the absence of a license. 3.02 If the
Option is not exercised prior to the expiration of the Option Period, then Company agrees to extend
the license grants set forth in Articles 3.00 and 3.01 beyond the expiration of the Option Period,
subject to an annual licensing fee paid by Investor to Company. The non- exclusive rights granted to
Investor under this Article 3.02 do not include the right to grant sublicenses to Third Parties. The
amount and parameters of the annual licensing fee shall be commercially reasonable, as determined by
an independent expert who is mutually agreeable to the Parties and whose determination shall be
final and binding; provided, however, that if the Parties cannot agree on the independent expert,
each Party shall designate an expert of their choice and the two experts designated by the Parties
shall work together in good faith to identify and designate a third, independent expert whose
determination shall be binding.

Page 3 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 4 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement 3.03 If the Option is exercised
before the expiration of the Option Period, the license grants set forth in Articles 3.00 and 3.01
will become exclusive to Investor for a perpetual term, shall not be subject to a licensing fee, the
granted licenses in favor of the Investor shall be deemed fully paid-up, and the rights granted to
Investor under Articles 3.00 and 3.01 shall include the right to grant sublicenses to Third Parties.
3.04 Prior to the earlier of Investor exercising the Option and the expiration of the Option Period,
Company will not grant to any Third Party any rights to the Patents or to the Technical Information
that extend beyond the expiration of the Option Period. 3.05 The licenses granted in Articles 3.01
to 3.04 of this IP Agreement are subject to a reserved non-exclusive license in the Company to
practice the methods described and claimed in the Patents and to make, have made, use, offer to
sell, sell and import rare earth products made using such methods, and to use the Technical
Information to practice the methods described and claimed in the Patents for such purposes. Such
reserved non-exclusive license shall be solely for use by the Company and its Affiliates and shall
not be transferable to any Third Party, except in connection with a merger, consolidation, or the
sale or transfer of substantially all of the Company's assets associated with the performance of
this IP Agreement. 3.06 Investor will not disclose to Third Parties any unpublished Technical
Information furnished by Company to Investor during the term of this IP Agreement, or any time
thereafter; provided, however, that disclosure may be made of any such Technical Information at any
time (i) with the prior written consent of Company, (ii) to Affiliates of Investor, (iii) to Third
Parties, in confidence, if and when the Option is exercised before the expiration of the Option
Period, (iv) after such Technical Information has become public through no fault of Investor, (v) if
such Technical Information is received from a third person who had a right to disclose it, (vi) if
Investor can show such Technical Information was independently developed without access to any such
Technical Information, or (vii) if Investor can demonstrate such Technical Information was in its
rightful possession free of any obligation of confidentiality prior to its first receipt from
Company.

Page 4 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 5 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement 3.07 The licenses and other rights of
Investor set forth in this IP Agreement are an encumbrance on (and thus run with) the Patents and
Technical Information, and shall be enforceable against any entity having or obtaining ownership of,
or the right to enforce, any of the Patents and Technical Information or any rights therein. Company
shall obligate any Person to whom Company assigns or otherwise confers an ownership interest or
right to enforce any of the Patents and Technical Information or any rights therein to: (a) fully
honor in all respects all of the rights and licenses granted to Investor under this IP Agreement;
and (b) obligate all subsequent assignees or other Persons who obtain an ownership interest or right
to enforce any of the Patents and Technical Information or any rights therein to (i) similarly fully
honor all of the foregoing in all respects, and (ii) expressly flow down all of the foregoing
(including, without limitation, this flow down obligation) in all subsequent assignments or other
agreements that confer an ownership interest or right to enforce any of the Patents and Technical
Information or any rights therein. Any assignment or agreement or other transaction by Company that
fails to be in complete compliance with this Article 3.07 or any other provision of this IP
Agreement shall be null and void. 3.08 Company does not warrant the accuracy of Technical
Information provided to Investor hereunder. Subject to and except for any indemnification
obligations under Article 3.09 below, Company will not be under any liability arising out of the
supplying of Technical Information under, in connection with, or as a result of this IP Agreement,
whether on warranty, contract, negligence or otherwise. 3.09 Company represents that to the best of
its knowledge, the methods described and claimed in the Patents and the Technical Information, and
the products produced thereby in accordance with such information, will be free from claims of
infringement of the patents and copyrights of any Third Party. Company further represents that it
has not received any written notice of a claim and otherwise has no knowledge that the methods
described and claimed in the Patents and the Technical Information, and the products produced
thereby in accordance with such information, violate or infringe upon the rights of any Person.
Company shall indemnify and hold harmless Investor, Investors' Affiliates, and their officers and
directors, and their direct and indirect customers, to the fullest extent permitted by applicable
law, from and against any and all losses, liabilities, obligations, claims, contingencies, damages,
diminution in value, deficiencies, actions, proceedings, taxes, costs and expenses, including all
judgments, amounts paid in settlements, court costs and reasonable attorneys' fees and costs of
investigation as incurred, arising out of or relating to any breach of any of the representations
made in this Article 3.09.

Page 5 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 6 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement 3.10 Company represents and warrants
that the definitions of Patents and Technical Information cover and include all patents, patent
applications, patent rights, research and development information, inventions, know-how, trade
secrets, and technical data used by the Company in its business at the Effective Date of this IP
Agreement that relate to rare earth mineral processing and rare earth separation. IV. Prosecution of
the Patents 4.00 Company will have the sole right to file, prosecute, and maintain all Patents
covering the inventions that are the property of Company and will have the right to determine
whether or not, and where, to file a patent application, to abandon the prosecution of any patent or
patent application, or to discontinue the maintenance of any patent or patent application.
Notwithstanding the foregoing, if Company elects to abandon any patent application, to not pay
maintenance fees or annuities to keep a patent in force, or to otherwise take or fail to take any
action that will result in a loss of patent rights, Company shall give Investor at least sixty (60)
days prior written notice and an opportunity to take over the prosecution of the patent application
that would be abandoned and/or pay the fees necessary to keep the patent in force and/or take any
other action necessary to avoid the loss of patent rights. In the event that Investor takes over the
prosecution of a patent application or maintenance of a patent under this Article 4.00, Company
shall retain ownership of the patent application or patent, and the patent shall remain subject to
this IP Agreement.

Page 6 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 7 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement V. Improvements 5.00 Improvements
made or acquired solely by the Company ("Company Improvements") during the term of this IP Agreement
shall be deemed Technical Information hereunder and shall be subject to the license provisions set
forth in Article III for Technical Information. Any patent applications and any patents relating to
any Company Improvements shall be deemed Patents hereunder and shall be subject to the license
provisions set forth in Article III for Patents. 5.01 Investor shall own all right, title and
interest in any Improvement made or acquired by the Investor ("Investor Improvement"). Investor
hereby agrees to grant to Company a non-exclusive, irrevocable, royalty-free license under any
Investor Improvement and any patent claiming such Investor Improvement, solely for use in rare earth
mineral processing and rare earth separation, to make and have made, use, offer to sell, sell and
import products made using the Investor Improvements. Such rights to Investor Improvements shall be
solely for use by the Company and its Affiliates and shall not be transferable to any Third Party,
except in connection with a merger, consolidation, or the sale or transfer of substantially all of
Company's assets associated with performance under this IP Agreement. 5.02 Investor shall own all
right, title and interest in any Improvement made jointly by Company and Investor ("Joint
Improvements") during the term of this IP Agreement, and Company agrees to and hereby does assign to
Investor any right, title and interest it may otherwise have in any Joint Improvement. 5.03 Investor
hereby agrees to grant to Company a non-exclusive, irrevocable, royalty-free license under any Joint
Improvement and any patent claiming such Joint Improvement solely for use in rare earth mineral
processing and rare earth separation. Such rights to Joint Improvements shall be solely for use by
the Company and shall not be transferable to any Third Party except in connection with a merger,
consolidation, or the sale or transfer of substantially all of Company's assets associated with
performance under this IP Agreement.

Page 7 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 8 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement 5.04. For the avoidance of doubt, all
right, title and interest in intellectual property, whether or not patented, that is made or
acquired by one Party or its Affiliate after the Effective Date of this IP Agreement, that is wholly
unrelated to the Patents and Technical Information, shall be owned by said Party or its Affiliate.
VI. Representations and Disclaimer of Warranties 6.00 SUBJECT TO AND EXCEPT FOR ANY INDEMNIFICATION
OBLIGATIONS UNDER ARTICLE 3.09 ABOVE, NOTHING IN THIS IP AGREEMENT WILL BE DEEMED TO BE A
REPRESENTATION OR WARRANTY BY COMPANY OF THE ACCURACY, SAFETY OR USEFULNESS FOR ANY PURPOSE OF ANY
TECHNICAL INFORMATION, TECHNIQUES, OR PRACTICES AT ANY TIME MADE AVAILABLE BY COMPANY. COMPANY WILL
HAVE NO LIABILITY WHATSOEVER TO INVESTOR OR ANY OTHER PERSON FOR OR ON ACCOUNT OF ANY INJURY, LOSS
OR DAMAGE OF ANY KIND OR NATURE, SUSTAINED BY, OR ANY DAMAGES ASSESSED OR ASSERTED AGAINST, OR ANY
OTHER LIABILITY INCURRED BY OR IMPOSED ON INVESTOR OR ANY OTHER PERSON, ARISING OUT OF OR IN
CONNECTION WITH OR RESULTING FROM: (A) THE PRODUCTION, USE OR SALE OF ANY APPARATUS OR PRODUCT OR
METHOD, OR THE PRACTICE OF THE PATENTS BY INVESTOR OR ITS ASSIGNS; (B) THE USE BY INVESTOR OR ITS
ASSIGNS OF ANY TECHNICAL INFORMATION, TECHNIQUES, OR PRACTICES DISCLOSED BY COMPANY; OR (C) ANY
ADVERTISING OR OTHER PROMOTIONAL ACTIVITIES BY INVESTOR OR ITS ASSIGNS WITH RESPECT TO ANY OF THE
FOREGOING, AND INVESTOR WILL HOLD COMPANY, AND ITS OFFICERS, EMPLOYEES AND AGENTS, HARMLESS IN THE
EVENT COMPANY, OR ITS OFFICERS, EMPLOYEES OR AGENTS, IS HELD LIABLE.

Page 8 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 9 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement 6.01 NOTHING IN THIS IP AGREEMENT
WILL BE DEEMED TO BE A REPRESENTATION OR WARRANTY BY INVESTOR OF THE ACCURACY, SAFETY OR USEFULNESS
FOR ANY PURPOSE OF ANY IMPROVEMENTS AT ANY TIME MADE AVAILABLE BY INVESTOR. INVESTOR WILL HAVE NO
LIABILITY WHATSOEVER TO COMPANY OR ANY OTHER PERSON FOR OR ON ACCOUNT OF ANY INJURY, LOSS OR DAMAGE
OF ANY KIND OR NATURE, SUSTAINED BY, OR ANY DAMAGES ASSESSED OR ASSERTED AGAINST, OR ANY OTHER
LIABILITY INCURRED BY OR IMPOSED ON COMPANY OR ANY OTHER PERSON, ARISING OUT OF OR IN CONNECTION
WITH OR RESULTING FROM: (A) THE PRODUCTION, USE OR SALE OF ANY APPARATUS OR PRODUCT OR METHOD, OR
THE PRACTICE OF ANY IMPROVEMENTS AT ANY TIME BY THE COMPANY, ITS AFFILIATES OR ASSIGNS; (B) THE USE
OF ANY IMPROVEMENTS AT ANY TIME MADE AVAILABLE BY INVESTOR BY THE COMPANY, ITS AFFILIATES OR
ASSIGNS; OR (C) ANY ADVERTISING OR OTHER PROMOTIONAL ACTIVITIES BY COMPANY ITS AFFILIATES OR ASSIGNS
WITH RESPECT TO ANY OF THE FOREGOING, AND COMPANY WILL HOLD INVESTOR, AND ITS OFFICERS, EMPLOYEES
AND AGENTS, HARMLESS IN THE EVENT INVESTOR, OR ITS OFFICERS, EMPLOYEES OR AGENTS, IS HELD LIABLE.
VII. Litigation 7.00 Investor will notify Company of any suspected infringement of the Patents.
Subject to Article 7.01 below, the sole right to institute a suit for infringement of the Patents
rests with Company. Investor agrees to reasonably cooperate with Company in such suit for
infringement, including requesting Investor's employees or consultants to testify when requested by
Company in writing, making available records, papers, information, specimens, and the like, provided
and only to the extent such is reasonably necessary to prosecute the suit. For the avoidance of
doubt, nothing in this Article 7.00 shall require Investor to join any such suit as a party, and
Company shall not seek to join Investor to any such suit as a party absent the express written
consent of Investor. Any recovery received pursuant to such suit will first go to Investor to
reimburse Investor for any costs and expenses (including attorneys' fees) reasonably incurred by
Investor in cooperating with Company in the suit, and any remaining amounts shall be retained by
Company.

Page 9 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 10 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement 7.01 If, after the Option is
exercised before the expiration of the Option Period such that the license grants set forth in
Articles 3.00 and 3.01 have become exclusive under Article 3.03, Company does not enforce the
Patents, through legal action or otherwise, Investor may enforce the Patents and Company agrees to
reasonably cooperate with Investor in such suit for infringement, including requesting Company's
employees or consultants to testify when requested by Investor in writing, making available records,
papers, information, specimens, and the like, provided and only to the extent such is reasonably
necessary to prosecute the suit. For the avoidance of doubt, nothing in this Article 7.01 shall
require Company to join any such suit as a party, and Investor shall not seek to join Company to any
such suit as a party absent the express written consent of Company; provided, however, if Company
elects not to give its express written consent to be joined as a party, but joinder is required in
order for Investor to file or maintain legal action to enforce any Patents, Company agrees that if
requested by Investor, Company will negotiate and enter into an amendment to this IP Agreement to
the extent necessary for Investor to file or maintain legal action to enforce the Patents. Any
recovery received pursuant to such suit will first go to Company to reimburse Company for any costs
and expenses (including attorneys' fees) reasonably incurred by Company in cooperating with Investor
in the suit, and any remaining amounts shall be retained by Investor. VIII. Non-assignability 8.00
This IP Agreement imposes personal obligations on Investor. Investor will not assign to any Third
Party any rights under this IP Agreement not specifically transferable by its terms without the
prior written consent of Company, such consent not to be unreasonably withheld. For the avoidance of
doubt and notwithstanding the foregoing: (1) such rights are assignable by Investor to an Affiliate
of Investor, and (2) Investor's rights in Investor Improvements and Joint Improvements shall be
freely assignable by Investor to any Person.

Page 10 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 11 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement IX.Severability 9.00 The Parties
agree that if any part, term or provision of this IP Agreement is found illegal or in conflict with
any valid controlling law, the validity of the remaining provisions will not be affected thereby.
9.01 Should any provision of this IP Agreement be held by a court of law to be illegal, invalid or
unenforceable, such provision shall be replaced by such provision as most closely reflects the
intent of the invalid provision, and the legality, validity and enforceability of the remaining
provisions of this Agreement will not be affected or impaired thereby. X. Waiver, Integration,
Alteration 10.00 The waiver of a breach hereunder may be effected only by a writing signed by the
waiving Party and will not constitute a waiver of any other breach. 10.01 This IP Agreement,
together with the Investment Agreement and any other documents or agreements executed in connection
with the transactions contemplated thereunder, represents the entire understanding between the
Parties, and supersedes all other agreements, express or implied, between the Parties concerning the
Patents and Technical Information. XI. Execution 11.00 This IP Agreement may be executed in
counterparts, all of which when taken together shall be considered one and the same agreement and
shall become effective when counterparts have been signed by each Party and delivered to each other
Party, it being understood that the Parties need not sign the same counterpart. In the event that
any signature is delivered by facsimile transmission or by e-mail delivery of a ".pdf" format data
file, such signature shall create a valid and binding obligation of the Party executing (or on whose
behalf such signature is executed) with the same force and effect as if such facsimile or ".pdf"
signature page were an original thereof.

Page 11 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 12 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement XII. Cooperation 12.00 Each Party
will execute any instruments reasonably believed by the other Party to be necessary to implement the
provisions of this IP Agreement. XIII. Construction 13.00 This IP Agreement will be construed in
accordance with the substantive laws of the state of New York and of the United States of America.
XIV. Exportation of Technical Information 14.00 Investor agrees that it will not export the
Technical Information furnished to Investor either directly or indirectly by Company, to any
destination or Person prohibited by the U.S. Export Administration Regulations or other U.S. export
control laws and regulations. 14.01 Company agrees that it will not export any information relating
to Improvements or otherwise furnished to Investor either directly or indirectly by Investor
Company, to any destination or Person prohibited by the U.S. Export Administration Regulations or
other U.S. export control laws and regulations. XV. Notices Under this IP Agreement 15.00 All
written communications and notices between the Parties relating to this IP Agreement shall be made
in the manner set forth in the Investment Agreement. XVI. Term and Termination 16.00 Unless earlier
terminated in accordance with the terms of this Article XVI, this IP Agreement and the licenses
granted herein will continue in effect from the Effective Date until the expiration of the last to
expire of the Patents and any additional period of time thereafter that any of the Patents remain
enforceable such as in the United States where a party can sue for infringement after a patent
expires and seek damages for any infringement of the patent during the six years immediately
preceding the filing of a suit for infringement.

Page 12 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 13 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement 16.01 Investor at any time may
provide written notice to Company of a material breach of this IP Agreement. If Company fails to
cure the identified breach within thirty (30) days after the date of the notice, Investor may
terminate this IP Agreement by written notice to Company. 16.02 If the Option is not exercised
before the expiration of the Option Period, Company may provide written notice to Investor of a
material breach of this IP Agreement. If Investor fails to cure the identified breach within thirty
(30) days after the date of the notice, Company may terminate this IP Agreement by written notice to
Investor. If the Option is exercised before the expiration of the Option Period, Company may not
terminate this IP Agreement for material breach. 16.03 The following provisions of this IP Agreement
shall survive termination of this IP Agreement: Article I, Article II, Articles 3.08 and 3.09,
Article V (as to Improvements made or acquired during the term of the IP Agreement), Article VI, and
Articles VIII-XVIII. In addition, for as long as there continues to exist Technical Information of
use by Investor in its business, any rights or licenses Investor has in Technical Information under
this Agreement shall survive termination of this IP Agreement under Article 16.00 but not
termination under Articles 16.01 or 16.02 for material breach. XVII. Bankruptcy 17.00 Each Party
acknowledges that all rights, covenants and licenses granted by one Party to the other Party are,
and shall otherwise be deemed to be, for purposes of Section 365(n) of the U.S. Bankruptcy Code,
licenses of rights to "intellectual property" as defined under Section 101(35A) of the Bankruptcy
Code. Each Party acknowledges this IP Agreement is an Executory Contract and that should any Party
become a petitioner under the Bankruptcy Code, §365(n) applies to this IP Agreement and the rights
afforded thereunder apply. Each Party further acknowledges that if such Party, as a debtor in
possession or a trustee-in-bankruptcy in a case under the Bankruptcy Code, rejects this IP
Agreement, the other Party may elect to retain their rights under this IP Agreement as provided in
Section 365(n) of the Bankruptcy Code. Any change of control resulting from any such bankruptcy
proceeding shall be subject to the rights and licenses granted in this IP Agreement. Each Party
agrees that to the extent the Bankruptcy laws of Canada provide the same or similar rights to a
licensee as Section 365(n) of the U.S. Bankruptcy Code, a Party may exercise such same or similar
rights as specified herein as to the rights under the U.S. Bankruptcy Code.

Page 13 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 14 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement XVIII. Governing Law; Jurisdiction;
Dispute Resolution 18.00 Exclusive Dispute Resolution Mechanism. The procedures set forth in this
Article XVIII shall be the exclusive mechanism for resolving any dispute that may arise from time to
time relating to this IP Agreement ("Dispute"). Either Party may commence the procedures
contemplated by this Article XVIII by written notice to the other that a Dispute has arisen (a
"Dispute Notice"). 18.01 Negotiations. The Parties shall first attempt in good faith to resolve any
Dispute by negotiation and consultation between themselves, including without limitation not fewer
than two (2) negotiation sessions which shall occur within ten (10) Business Days of the Dispute
Notice. In the event that such dispute is not resolved on an informal basis by the conclusion of the
second negotiation session, or, if either Party has not participated in negotiation sessions as to
which notice has been given (the last day of such time period, the "Escalation to Mediation Date"),
either Party may initiate mediation under Article 18.02. 18.02 Mediation. (a) Either Party may, at
any time after the Escalation to Mediation Date, submit the Dispute for mediation. The Parties shall
cooperate with one another in selecting a neutral mediator and in scheduling the mediation
proceedings. Each Party covenants that they will use commercially reasonable efforts in
participating in the mediation. Each Party shall prepare for the mediator a written request for
mediation, setting forth the subject of the Dispute, the position and supporting documentation of
such Party, and the relief requested. Each Party agrees that the mediator's fees and expenses and
the costs incidental to the mediation will be shared equally between the Parties.

Page 14 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 15 -->
Rare Element Resources Ltd. EXECUTION COPY IP Rights Agreement (b) The Parties further agree that
all offers, promises, conduct, and statements, whether oral or written, made in the course of the
mediation by the Parties, their agents, employees, experts, and attorneys, and by the mediator, are
confidential, privileged, and inadmissible for any purpose, including impeachment, in any
litigation, arbitration or other proceeding involving the Parties, provided that evidence that is
otherwise admissible or discoverable shall not be rendered inadmissible or non-discoverable as a
result of its use in the mediation. 18.03 Litigation or Arbitration as a Final Resort. If the
Parties cannot resolve any Dispute for any reason, including, but not limited to, the failure of the
Parties to agree to enter into mediation or agree to any settlement proposed by the mediator, within
sixty (60) days after the Escalation to Mediation Date, either the Company or the Holder may file
suit in a court of competent jurisdiction in accordance with Article 18.04. 18.04 Governing Law;
Jurisdiction. All questions concerning the construction, validity, enforcement and interpretation of
this IP Agreement shall be determined in accordance with the provisions of the Investment Agreement.
IN WITNESS WHEREOF, the Parties have caused this IP Agreement to be executed by their duly
authorized officers on the respective dates herein set forth. Rare Element Resources Ltd. By: /s/
Randall J. Scott Name: Randall J. Scott Title: President and Chief Executive Officer Date: October
2, 2017 Synchron By: /s/ Kenneth J. Mushinski Name: Kenneth J. Mushinski Title: President Date:
October 2, 2017

Page 15 of 15

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
<!-- page 16 -->
EXHIBIT A

Title Country orAuthority Application No. Filing Date Publication No. Patent No. Status

Extraction of Metals from Metallic Compounds PCT PCT/US2014/012153 01/18/2014 WO 2014/113742 N/A
Expired

Selective Extraction of Cerium from Other Metals US 14/735,118 6/9/2015 2016/0002751 -- Published

Selective Extraction of Cerium from Other Metals PCT PCT/US2015/03498 6/9/2015 WO2015/191645 --
Expired

Extraction of Metals from Metallic Compounds AU AU 2014207355 6/9/2015 Pending

Extraction of Metals from Metallic Compounds CA CA 2,898,612 6/9/2015 Pending

Extraction of Metals from Metallic Compounds EP EP 14740863.7 6/9/2015 Pending

Extraction of Metals from Metallic Compounds RU RU 2015134576 6/9/2015 Pending

Extraction of Metals from Metallic Compounds ZA ZA 2015/05821 6/9/2015 Pending

Extraction of Metals from Metallic Compounds US 14/831,020 8/20/2015 2015/0354026 Published

Processing of Rare Earth Elements PCT PCT/US2015/055403 10/13/2015 WO 2016/058007 N/A Expired

Processing for the Extraction of Rare Earth Elements US 15/517,884 10/13/2015 -- -- Pending

Processing for the Extraction of Rare Earth Elements CA CA 2,964,306 10/13/2015 -- -- Pending

Processing for the Extraction of Rare Earth Elements AU AU 2015329723 10/13/2015 -- -- Pending

1 of 1

Source: RARE ELEMENT RESOURCES LTD, SC 13D, 10/19/2017
