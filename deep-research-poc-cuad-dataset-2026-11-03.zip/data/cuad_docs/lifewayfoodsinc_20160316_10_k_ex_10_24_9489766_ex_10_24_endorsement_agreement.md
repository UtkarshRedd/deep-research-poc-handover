<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2016-03-14 |
| Parties | Lifeway Foods, Inc. ("Lifeway"); Ludmila Smolyansky ("Individual") |
| Source | CUAD v1 / LifewayFoodsInc_20160316_10-K_EX-10.24_9489766_EX-10.24_Endorsement Agreement |

EXHIBIT 10.24 ENDORSEMENT AGREEMENT

This Endorsement Agreement ("Agreement") is made this 14th day of March, 2016 ("Effective Date"), by
and between Lifeway Foods, Inc. ("Lifeway") with a principal business address of 6431 West Oakton
Street, Morton Grove, IL 60053 and Ludmila Smolyansky("Individual") on her own behalf with an
address of 182 N. Harbor Drive, Chicago, IL 60602. Lifeway and Individual are collectively referred
to as the "parties," or individually as a "party." The terms of the Agreement are as follows: 1.
License - Individual grants Lifeway together with its affiliates, subsidiaries, parent companies and
their representatives and employees have an unlimited, perpetual, non-exclusive, worldwide and,
except as set forth in Section 9, royalty-free, right to use, reuse, publish, reproduce, perform,
copy, create derivative works, exhibit, broadcast, and display throughout the world the name, image
and likeness of Individual in Marketing Materials (as defined below) in connection with marketing,
advertising or otherwise promoting the Lifeway products and/or services and for historical reference
and display purposes and other internal purposes, including without limitation, internal sales
meetings. Notwithstanding anything herein to the contrary, Lifeway shall be under no obligation to
cause the Marketing Materials to be displayed, published or performed. Individual further waives the
right to inspect or approve the Marketing Materials. 2. Marketing Materials - Marketing Materials
shall mean those marketing, sales, advertising, publicity and promotional materials produced by
Lifeway or produced on Lifeway's behalf that contain Individual's biographical materials, name,
nickname, likeness, voice, photograph, signature or facsimile thereof, reviews, endorsements,
testimonials, demonstrations, depictions of the same, or other identifying personal characteristics
made in any and all forms of media, that reflect the personal opinions and views of the Individual
in connection with Lifeway products and/or services in whatever medium whether now known or
hereafter created including, without limitation, websites, intranets, social media, radio and
television commercials, video and audio tapes, digitally formatted computer media including but not
limited to internet and CD-ROMs, product labels, product packaging, point-of-purchase materials,
trade, direct mail, magazines, newspapers, coupons, free standing inserts, and posters. 3. Release -
Individual hereby releases and discharges Lifeway from any and all claims, demands, or causes of
action in law or equity that he or she may have or may hereafter acquire, including without
limitation in connection with any prior use, reuse, publication, reproduction, performance, copy,
creation of derivative works, exhibition, broadcast, and display of the name, image and likeness of
Individual and any and all claims for libel, slander, invasion of privacy, copyright or trademark
violation, right of publicity, or false light, that may arise out of or in connection with the use
of the Marketing Materials in accordance with this Agreement. 4. Right to Edit - Lifeway may modify
and vary the Marketing Materials produced hereunder, as it may elect, and to make additional
versions of such Marketing Materials in any manner without approval from Individual; provided that
Individual shall not be required to render any services in connection with the production of such
modifications or variations. Moreover, Individual understands and agrees that Lifeway may use the
Marketing Materials with or without her name.

Source: LIFEWAY FOODS, INC., 10-K, 3/16/2016
<!-- page 2 -->
5. Ownership - Individual agrees that she does not have, and shall not claim to have, either under
this Agreement or otherwise, any right, title or interest of any kind or nature in and to the ideas,
likenesses, images, announcements, phrases, titles, music or words used in the Marketing Materials,
and that all rights therein, including the copyright, are recognized to be owned by Lifeway. 6.
Non-Competing Services - Individual agrees that, during the Term hereof, she will not render similar
services for, or permit the use of her name, nickname, likeness, voice, live or recorded
performance, photograph, signature or facsimile thereof, and biographical materials in advertising
or publicizing in any medium for any other Kefir product, yogurt product, cheese, frozen desserts
and other products that compete with products manufactured or distributed by Lifeway and its
affiliates, subsidiaries and parent companies other than those products manufactured or distributed
by Lifeway and its affiliates, subsidiaries, and parent companies. 7. Representation - Individual
represents and warrants that any testimonial or review provided reflects her own honest opinions,
findings, beliefs, or experiences. Individual represents that she is a bona fide user of Lifeway
products and/or services. 8. Indemnification - Individual agrees to indemnify, defend and hold
harmless Lifeway from and against any and all claims, actions, causes or other expenses incurred
arising from any misrepresentations or false statements made by the Individual in the Marketing
Materials. 9. Compensation (a) In consideration of the rights granted by Individual hereunder,
Lifeway agrees to pay Individual a royalty (the "Royalty") equal to $0.02 for each Lifeway product
or individual item sold by Lifeway during each calendar month of the Term bearing Individual's first
name, last name or other identifying personal characteristics; provided, however, the Royalty will
cease being paid upon the death of Individual. Notwithstanding anything to the contrary herein, the
Royalty will not exceed $50,000 in any month. All undisputed Royalty payments shall be made in U.S.
dollars in cash or to the order of Individual and shall be due and payable within thirty (30) days
after the end of each calendar month for sales during the previous month. (b) All amounts due under
this Agreement are net of any applicable taxes, duties, fees or governmental charges, including
without limitation, transfer tax, sales tax, use tax, consumption tax, value-added tax, excise tax,
import tax, export tax, and custom duties (collectively "Taxes"). Accordingly, Lifeway will be
solely responsible for the payment of all Taxes, together with any related liabilities (including
interest and penalties), imposed upon it by law or any governmental authority for which Lifeway is
primarily liable. (c) The Royalty due hereunder shall be paid to Individual at the address set forth
above. 10. Confidentiality - With respect to this Agreement and any information supplied in
connection with this Agreement and designated by the disclosing party as confidential, the recipient
agrees to: (i) protect the confidential information in a reasonable and appropriate manner; (ii) use
confidential information only to perform its obligations under this Agreement; and (iii) reproduce
confidential information only as required to perform its obligations under this Agreement. This
section shall not apply to information that is: (i) publicly known; (ii) already known to the
recipient; (iii) disclosed to a third party without restriction; (iv) independently developed; or
(v) disclosed pursuant to legal requirement or order.

Source: LIFEWAY FOODS, INC., 10-K, 3/16/2016
<!-- page 3 -->
11. Mutual Representations, Warranties and Covenants - Each party (the "Warranting Party"), to
induce the other party to enter into this Agreement, represents, warrants and covenants that: (a)
the Warranting Party has the full right and authority, and possesses all licenses, permits,
authorizations and rights to intellectual property required to enter into this Agreement and to
perform the acts required of it hereunder; (b) the performance by the Warranting Party pursuant to
this Agreement and/or the rights in this Agreement granted to the other party will not conflict with
or result in a breach or violation of any of the terms or provisions, or constitute a default under
any agreement by which the Warranting Party is bound; and (c) with respect to the performance of its
obligations hereunder, the Warranting Party will comply with all applicable laws, rules and
regulation. 12. Assignment - Neither party will assign any of its rights or obligations under this
Agreement without the prior written consent of the other party, such consent not to be unreasonably,
conditioned, withheld or delayed. 13. Notice - Notices to the parties shall be sent via overnight
mail or U.S. Certified Mail or overnight express or priority mail to the addresses listed in the
Agreement. Either party may change its address upon written notice to the other party. Written
notices for approvals under this agreement may be via email. 14. [Intentionally Omitted.] 15. Choice
of Law and Forum - This Agreement will be construed and governed in accordance with the laws of the
State of Illinois, without regard to conflict of laws principles. 16. Survival - Unless and to the
extent otherwise specified herein, all terms of this Agreement which by their nature extend beyond
its termination, remain in effect until fulfilled, and apply to respective successors and assigns.
17. Force Majeure - If performance hereunder is prevented, restricted or interfered with by any act
or condition whatsoever beyond the reasonable control of a party, the party so affected, upon giving
prompt notice to the other party, will be excused from such performance to the extent of such
prevention, restriction or interference. 18. Waiver - The waiver by either party of a breach or a
default of any provision of this Agreement by the other party will not be construed as a waiver of
any succeeding breach of the same or any other provision.

Source: LIFEWAY FOODS, INC., 10-K, 3/16/2016
<!-- page 4 -->
19. Counterparts and Facsimile Signatures - This Agreement may be executed in multiple counterparts
and via facsimile, each of which will be deemed to be an original, but all of which together
constitute one and the same instrument. 20. Entire Agreement and Amendment - This Agreement,
together with all exhibits, schedules and attachments, constitutes the entire agreement between the
parties with respect to the subject matter hereof. This Agreement supersedes, and the terms of this
Agreement govern, any prior agreements with respect to the subject matter hereof with the exception
of any prior confidentiality agreements between the parties. This Agreement may only be changed by
mutual agreement of authorized representatives of the parties in writing. IN WITNESS WHEREOF Lifeway
has caused its duly authorized representatives to execute this Agreement and Individual has signed
the Agreement on her own behalf as of the Effective Date. Lifeway Foods, Inc. Ludmila Smolyansky By:
/s/ Julie Smolyansky By: /s/ Ludmila Smolyansky Name: Julie Smolyansky Title: CEO Date: March 14,
2016 Date: March 14, 2016

Source: LIFEWAY FOODS, INC., 10-K, 3/16/2016
