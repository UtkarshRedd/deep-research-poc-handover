<!-- page 1 -->
# Guarantee — Brightwater Renewables
| Field | Value |
|---|---|
| Document Type | Guarantee |
| Effective Date | 2024-09-30 |
| Parties | Brightwater Wind Holdings Limited; Brightwater Solar Assets Limited; Meridian Trust Bank, N.A. |
| Facility ID | FAC-2024-0311 |
| Version | Original (Execution Version) |

THIS GUARANTEE (this "Guarantee") is made as of 2024-09-30 by each of the undersigned subsidiaries of Brightwater Renewables plc (each a "Guarantor") in favor of Meridian Trust Bank, N.A., as Administrative Agent for the Lenders under the Credit Agreement dated as of 2024-09-30 among Brightwater Renewables plc, the Lenders and the Administrative Agent (facility FAC-2024-0311).
<!-- page 2 -->
## Section 1 — Guarantors
The Guarantors on the date hereof are:
(a) Brightwater Wind Holdings Limited;
(b) Brightwater Solar Assets Limited;
together with each other person that becomes a party hereto by executing a Guarantor Joinder pursuant to Section 6.9 of the Credit Agreement.
<!-- page 3 -->
## Section 2 — The Guarantee
Each Guarantor, jointly and severally, unconditionally and irrevocably guarantees the punctual payment when due of all Obligations of the Borrower under the Loan Documents.
This Guarantee is a guarantee of payment and not of collection. The Administrative Agent is not required to exhaust remedies against the Borrower before proceeding against any Guarantor.
## Section 3 — Limitation
The obligations of each Guarantor are limited to the maximum amount that can be guaranteed without rendering this Guarantee voidable under applicable fraudulent transfer law.
<!-- page 4 -->
## Section 4 — Waivers; Reinstatement
Each Guarantor waives presentment, demand, protest and notice of any kind, and any defense arising from any amendment, waiver or release under the Loan Documents.
This Guarantee shall be reinstated if any payment is rescinded or must be returned upon the insolvency of the Borrower.
## Section 5 — Release
A Guarantor is released automatically upon the sale of all of its equity interests in a transaction permitted by Section 7.6 of the Credit Agreement.
<!-- page 5 -->
## Section 6 — Notices; Governing Law
Notices to any Guarantor shall be delivered care of the Borrower at 40 Cannon Street, London EC4N 6JJ, United Kingdom, Attention: General Counsel, and are effective in the manner provided in Section 10.1 of the Credit Agreement.
This Guarantee shall be governed by the laws of the State of New York.
Brightwater Wind Holdings Limited, as Guarantor — By: /s/ Authorized Signatory
Brightwater Solar Assets Limited, as Guarantor — By: /s/ Authorized Signatory
