# When does the Technical Infrastructure Maintenance Agreement between MEDICAL MANAGER MI...

*Question:* When does the Technical Infrastructure Maintenance Agreement between MEDICAL MANAGER MIDWEST, INC. and MTS, INC. (dated 1998-03-01) expire, according to its term clause?

## Locate the Agreement

The Technical Infrastructure Maintenance Agreement between MEDICAL MANAGER MIDWEST, INC. and MTS, INC. dated 1998-03-01 is present in the document set. [6f5edff8361f32dd p.1] The agreement date is 1998-03-01. [6f5edff8361f32dd p.1] The Initial Term of this Technical Infrastructure Maintenance Agreement is twelve months, commencing on the Effective Date. [partially supported by review] [6f5edff8361f32dd p.1] The Effective Date is defined as the date of signed acceptance by MMMW, not the March 1, 1998 agreement date. [6f5edff8361f32dd p.1]

[GAP] The document set does not state the date of signed acceptance or the resulting expiration date.

## Identify the Term Clause

[GAP] The writer produced nothing for: Establish the specific clause within the agreement that defines the term or duration of the contract.

## Not established by the evidence

[GAP] No evidence was found for: Establish the exact expiration date stated in the term clause.

## Verification appendix

Claims: 7 · supported: 4 · partially: 0 · dropped: 0 · gaps: 3 · tier-1 support rate: 1.00 · tier 2 checked: 2 (unsupported 0, partially 1)

Notes: 1 empty section(s) collapsed into gaps: Determine Expiration Date; OpenAIRateLimitError: Error code: 429; OpenAIRateLimitError: Error code: 429

| claim | section | tier 1 | score | tier 2 | clusters | sources | note |
|---|---|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | skipped | 1 | e1→[6f5edff8361f32dd p.1] |  |
| s1.2 | s1 | keep | 1.00 | supported | 1 | e1→[6f5edff8361f32dd p.1] |  |
| s1.3 | s1 | keep | 1.00 | partially | 1 | e2→[6f5edff8361f32dd p.1] | tier 2 partially: The evidence states the Initial Term is twelve months commencing on the Effective Date, but the Effective Date is defined as the date of signed acceptance by MM |
| s1.4 | s1 | keep | 1.00 | skipped | 1 | e4→[6f5edff8361f32dd p.1] |  |
| s1.5 | s1 | gap |  | skipped |  |  |  |
| s2.1 | s2 | gap |  | skipped |  |  |  |
| gaps.1 | gaps | gap |  | skipped |  |  |  |

### Evidence

- e1 [6f5edff8361f32dd p.1 L2-8] keep (1.0): "# TECHNICAL INFRASTRUCTURE MAINTENANCE AGREEMENT | Field | Value | |---|---| | Document Type | Maintenance Agreement | | Agreement Date | 1998-03-01 | | Parties | MEDICAL MANAGER MIDWEST, INC. ("MMMW"); MTS, INC. ("Customer")"
- e2 [6f5edff8361f32dd p.1 L65-74] keep (1.0): "2 2. TERM

(a) MMMW provided Customer with an all inclusive warranty for a period of 12 months commencing on
the date of installation to include system purchased by Customer from MMMW. Upon expiration of that
12 months, MMMW affords the Cus…"
- e4 [6f5edff8361f32dd p.1 L53-54] keep (1.0): "(c) This Agreement shall be effective on the date of signed acceptance ("Effective Date") by MMMW."
