<!-- page 1 -->
# SUPPLY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Supply Agreement |
| Agreement Date | 2020-01-27 |
| Parties | EWSD 1, LLC, d/b/a SHI FARMS ("Shi Farms"); Gridiron BioNutrients ("Gridiron"); EWSD 1, LLC, d/b/a SHI FARMS and Gridiron BioNutrients (individually “a Party,” and collectively, “the Parties.”) |
| Source | CUAD v1 / GRIDIRONBIONUTRIENTS,INC_02_05_2020-EX-10.3-SUPPLY AGREEMENT |

EXHIBIT 10.3 SUPPLY AGREEMENT This Agreement ("the Agreement"), is made by and between EWSD 1, LLC,
d/b/a/ SHI FARMS ("Shi Farms"), a Delaware limited liability company and Gridiron BioNutrients, Inc,
a Nevada Corporation ("Gridiron") , each individually "a Party," and collectively, "the Parties."
WHEREAS Shi Farms grows industrial hemp and wishes to sell hemp biomass ("Product"); and Gridiron
wishes to purchase Product from Shi Farms; and Both Parties acknowledge that Shi Farms is the owner
of the Product as defined below; and Shi Farms is willing to sell Product to Gridiron and Gridiron
desires to acquire in accordance with the terms and conditions set forth below. NOW, THEREFORE for
good and valuable consideration, the receipt and sufficiency of which are hereby acknowledged, the
Parties agree as follows: 1. Products and Payments A. Product. Shi Farms agrees to sell Product and
Gridiron agrees to purchase 30,000 lbs. of hemp biomass ("Biomass") from Shi Farms. Biomass must
contain a minimum of six percent (6%) total Cannabidiol (CBD/and or CBDA) and all Biomass must have
less than three percent (3%) total TCH content. The Biomass must contain no contaminates that are
above acceptable industry standards for processing Biomass including but not limited to: Mold and
Mildew; Non- Hemp Plant Material; Soil; Insects; Rodent Droppings; Wet or Rotting Material; Heavy
Metals; Residual Pesticides or Herbicides; Bacteria. B. Pricing. Both Parties mutually agree that
the Purchase Price of the Product is determined on a $5.00 per pound basis for a total cost of one
hundred fifty thousand dollars ($150,000). C. Certificate of Analysis (COA). Both Parties agree that
CBD potency numbers are determined by a third-party lab according to standard testing protocol which
was provided by the seller. Buyer may take their own samples ("Product Samples") for testing as
well. D. Payment. Both Parties agree that once the Parties have agreed to transaction which includes
the purchase and sale of the Product that the Buyer will remit payment upon execution of this
agreement. E. Quarantine. Once the payment has been received, Shi Farms will use its best efforts to
quarantine product to ensure safe keeping of the Product until delivery date as agreed by the
Parties. F. Delivery. Product Samples. The point of delivery of the Product Samples shall be a
laboratory determined by Gridiron, if Gridiron determines that third party analysis of the Biomass
is required for processing. Shi Farms shall be responsible to ship the Product Samples to the
designated laboratory. Biomass. Shi Farms shall be responsible for delivery of the Biomass to the
processor determined by Gridiron, in good form as described above "A. Product".

1
<!-- page 2 -->
2. Term and Termination. A. Termination. Either Party may terminate this Agreement at any time prior
to delivery of the Product. 3. Indemnification. Gridiron and affiliated parties shall indemnify and
hold Shi Farms harmless from any claims, losses, actions, damages, liabilities, taxes , obligations,
fines, proceedings, deficiencies and out of pocket costs and expenses (including but not limited to
attorneys' fees and disbursements) without limitation resulting from or arising out of any
inaccuracy or breach of any representation or warranty; any non-performance or any obligation
incurred by Gridiron and its affiliated parties. If any claim or legal proceeding is filed by a
third party, prompt notice is required by the one to the other. 4. Notices. All notices required or
permitted under this Agreement must be in writing and delivered by email or personal delivery on the
date sent; or if my facsimile on the date sent; or if by certified US mail on the third business day
following such mailing; or if by overnight courier, on the next business day. Shi Farms:214 39t h
Lane Pueblo, CO 81006 ATTN: Steven Turetsky Gridiron: 1119 West 1st Ave - Suite G Spokane, WA 99021
ATTN: Tim Orr 5. Entire Agreement. A. Amendment, Waiver, Assignment. This Agreement may not be
waived, amended or assigned without an agreed written and signed document, signed by both Parties.
B. Governing Law. This Agreement and any amendments thereto shall be construed according to the laws
of the State of Colorado without regard to conflicts of law principles and any disputes hereunder
shall be litigated in a state court in Colorado. C. Confidential Information. In the course of
performing their respective obligations, each party will enter into possession of information of the
other party which the Parties wish to protect and deem "Confidential Information." This will include
all Intellectual Property, processes, pricing, and any information that is marked confidential. When
the Agreement ends, each party shall return all copies of any such information to the other and take
every reasonable measure to preclude its representatives from sharing or keeping such information.
Failure to do so shall constitute a material breach of this Agreement with all rights and remedies
available to the party whose material has been Disclosed. D. Counterparts and Severability. This
document may be signed in counterparts which, when taken together, constitute the whole. Should any
provision of this Agreement deemed unenforceable and thus stricken, the remainder of the Agreement
remains in full force and effect upon both parties.

[Remainder of Page Intentionally Left Blank] 2
<!-- page 3 -->
IN WITNESS WHEREOF, the Parties have executed this Agreement as of the date below. EWSD 1, LLC d/b/a
Shi Farms Gridiron BioNutrients, Inc. BY: /s/ Thomas A. Gallo BY: /s/ Timothy S Orr Date: 1/26/2020
Date: 1/27/2020 Name: Thomas A. Gallo Name: Timothy Orr- President Title: Executive Director 3
