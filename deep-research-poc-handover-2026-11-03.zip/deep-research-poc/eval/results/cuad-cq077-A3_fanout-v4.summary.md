### A3_fanout

| slice | n | err | cand recall | opened/cited | gold page | support | gate fail | has answer | item recall | abstain ok | judge pass | judge ? | wall s p50 | calls p50 | tokens p50 | tok/correct |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| all | 1 | 0 | 1.0 | 0.8 | 0.8 | 0.95 | 1.0 |  | 1.0 | 1.0 | 0.0 | 0.0 | 111.1 | 88 | 435530 |  |
| coverage | 1 | 0 | 1.0 | 0.8 | 0.8 | 0.95 | 1.0 |  | 1.0 | 1.0 | 0.0 | 0.0 | 111.1 | 88 | 435530 |  |
