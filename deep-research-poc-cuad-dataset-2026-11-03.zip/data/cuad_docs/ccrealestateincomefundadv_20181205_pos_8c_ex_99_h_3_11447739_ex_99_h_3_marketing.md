<!-- page 1 -->
# WHOLESALE MARKETING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Marketing Agreement |
| Agreement Date | 2018-08-24 |
| Parties | ALPS Distributors, Inc. (the “Distributor”); S2K Financial LLC (“S2K”); |
| Source | CUAD v1 / CcRealEstateIncomeFundadv_20181205_POS 8C_EX-99.(H)(3)_11447739_EX-99.(H)(3)_Marketing Agreement |

Exhibit 99(h)(3) WHOLESALE MARKETING AGREEMENT THIS AGREEMENT is entered into effective as of the
24t h day of August 2018, by and among ALPS Distributors, Inc., a Colorado corporation (the
"Distributor") and S2K Financial LLC, a Delaware limited liability company ("S2K"). WITNESSETH:
WHEREAS, the Distributor has entered into a Distribution Agreement with each fund set forth in
Exhibit A hereto, each a Delaware statutory trust and each of which is registered under the
Investment Company Act of 1940, as amended (the "1940 Act"), as a closed-end management investment
company (each a "Fund" and collectively referred to as the "Funds"); WHEREAS, the Distributor is the
distributor of each Fund and enters into broker-dealer selling agreements ("Selling Agreements")
with respect to each such Fund; WHEREAS, the Funds' shares may be sold by broker-dealers registered
with the Securities and Exchange Commission (the "SEC") and the Financial Industry Regulatory
Authority ("FINRA"); and WHEREAS, the Distributor wishes to retain S2K, through registered
representatives of S2K ("Authorized S2K Representatives"), to introduce the Funds to registered
representatives of broker-dealers and registered investment advisers located at the financial
institutions (each, an "Intermediary" and collectively, "Intermediaries") that may have customers
interested in investing in a Fund. NOW, THEREFORE, in consideration of these premises and of the
mutual covenants and agreements hereinafter contained, the sufficiency of which is hereby
acknowledged by the parties, the parties hereto agree as follows: 1. Services Provided by S2K. S2K
agrees, subject to the provisions of this Agreement, through its Authorized S2K Representatives, to
use its reasonable best efforts to market the Funds to the Intermediaries, and to identify, refer
and/or introduce Intermediaries to the Funds. In connection therewith, S2K may (i) engage in
seminars, conferences and media interviews for financial intermediaries; (ii) distribute sales
literature and other communications (including electronic media) regarding the Funds, subject to
review and approval of such material by the Distributor; and (iii) perform other services reasonably
contemplated in writing by S2K and the Distributor. S2K shall not act as an underwriter in
connection with S2K's wholesale activities relating to shares of the Funds where S2K receives all or
substantially all of the sales load, as set forth in each Fund's then-current prospectus
("Prospectus"). S2K will market the Funds to Intermediaries that: (a) are registered as
"broker-dealers" with the SEC, FINRA, and any other applicable jurisdiction in which they operate
and are required to be so registered by law;

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 2 -->
(b) will enter into a Selling Agreement agreed to by Distributor and such "broker-dealers," or in
such other form of Intermediary agreement (which shall include, without limitation, broker/dealer
Selling Agreements, platform agreements and wirehouse agreements) as required by an Intermediary
with the Distributor to sell shares of the Funds to investors (copies of which shall be made
available to S2K); and (c) will sell shares of the Funds through representatives in accordance with
the then-current applicable Prospectus and in accordance with the provisions of the Selling
Agreement. 2. Services Provided by the Distributor. (a) The Distributor will coordinate the
completion and execution of Selling Agreements with broker-dealers and/or Intermediaries. (b)
Advertising and Sales Literature Review (i) The Distributor shall provide review of broker-dealer
related advertising and sales literature pieces ("marketing pieces") submitted to Distributor by
S2K. Documentation (which shall include electronic correspondence) not defined as "marketing
pieces," which shall include, but is not limited to, correspondence and materials provided directly
in response to due diligence requests, shall be principally reviewed and approved by S2K. (ii)
Distributor's services are based on the understanding that S2K will utilize current systems and
expertise owned by Distributor, specifically the AdLit Advertising Review System ("AdLit"), and that
Distributor will base its reviews on: (i) the guidelines contained within Distributor's Sales and
Advertising Guide and Distributor's Written Supervisory Procedures; (ii) rules and guidance issued
by FINRA and the SEC related to communications with the public and/or communications to
institutional investors, as those terms are defined in FINRA Rules 2210 and 2211 and in various
other FINRA and SEC rules and interpretive material; and (iii) Distributor's submission guidelines
with respect to the use of trademarked and/or copyright materials, to the extent applicable. All
material submitted to Distributor will be provided by Distributor to S2K with comments or approval
no later than three business days after receipt in AdLit. (iii) Each marketing piece submitted to
Distributor for review will be subject to the following process: a) Each piece will undergo review
at Distributor by a FINRA-licensed registered principal possessing the required expertise and
appropriate license to review the marketing piece submitted to Distributor; b) Distributor's
comments shall consist of (i) recommendations for changes that, in the opinion of the Distributor
reviewer, will be consistent with the guidelines specified by Distributor in Section 2(b)(ii) above,
or (ii) in the form of an acknowledgement that the submitted material is consistent with such
guidelines with no additional changes. In the event of the latter, the item will be approved by the
registered principal and filed with the applicable regulatory body if necessary;

- 2 -

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 3 -->
c) Distributor will provide system training and ongoing consulting with respect to advertising
review guidelines and rules for each marketing piece submitted via the process described herein; and
d) Distributor will make all required FINRA filings of marketing materials which have been approved
by Distributor. (iv) If S2K wishes Distributor to perform an expedited review of marketing pieces
within one business day of Distributor' receipt of such marketing pieces, the expedited review will
be performed subject to and in accordance with the following: a) A charge of $250 will apply to each
request for expedited review, in addition to FINRA filing fees. b) The marketing piece must be 30
pages or less in actual length in order to be considered for expedited review. Web pages and other
marketing pieces over 30 pages require a more in-depth review; therefore, Distributor cannot
guarantee a one business day review for these items. c) The marketing piece must be submitted via
Distributor's AdLit system by no later than 3:00 P.M. Mountain Time (2:00 P.M. PT/5:00 P.M. ET) on a
business day in order to ensure that the Distributor has a full one business day to review and
provide S2K with comments within such one business day timeframe. d) S2K must check the box on the
AdLit coversheet whereby S2K requests and accepts the terms and fee(s) associated with expedited
review in order to ensure that Distributor is notified of the expedited request. e) Distributor
cannot guarantee that a marketing piece will be APPROVED within one business day of being received
via AdLit. Distributor will review and submit comments to S2K within this timeframe. If Distributor
fails to provide S2K with comments within one business day, the $250 expedited review charge will
not apply. 3. Performance Requirements. S2K shall devote sufficient staff and expenditures to the
performance of its services as shall be consistent with industry standards for the marketing of
shares of the Fund. S2K shall perform these services in a professional and competent manner and
shall provide such office space and equipment, telephone facilities and personnel as it determines
may be reasonably necessary or beneficial in order to provide such services at no cost to the
Distributor. 4. Duration and Termination. The term of this Agreement shall commence on the Effective
Date and shall end on the 60th day following a written notice from one party to the other of its
decision to terminate this Agreement at the end of such 60-day period or upon termination of the
applicable Distribution Agreement with respect to a Fund. Termination of this Agreement as to a Fund
shall not terminate this Agreement with respect to any other Fund so long as such other Fund's (or
Funds', as the case may be) Distribution Agreement is effective. If this Agreement is terminated by
one party, it shall terminate the entire Agreement.

- 3 -

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 4 -->
5. Compensation; Expenses (a) As described in the Fund's Prospectus, the Fund may impose a sales
charge "load" in connection with the purchase of shares of the Fund, a portion of which will be paid
to S2K pursuant to the terms and conditions of the Prospectus. (b) In consideration of the
marketing, sales and other related activities provided by S2K, the Distributor may compensate S2K
for such services on each Fund's behalf and at the direction of each such Fund. The amount of
compensation payable by the Distributor to S2K hereunder shall be determined on a class by class
basis. At the direction of each Fund, ALPS or its designated agent will facilitate the payment of
the applicable dealer reallowance fee to S2K in the amounts set forth in Exhibit B hereto. S2K shall
perform such distribution-related activities for which such payments are appropriate under all
applicable rules and regulations and shall make such occasional certification as required by the
Distributor to such effect. (c) No compensation with respect to a Fund shall be due and owing
hereunder until the Distributor actually receives payments from such Fund, to the extent applicable.
(d) Notwithstanding anything to the contrary herein, in no event shall S2K be entitled to receive
fees or compensation that would cause a Fund's sales charges to exceed the maximum amount allowed
under FINRA rules or applicable law. (e) S2K shall reimburse Distributor for all reasonable
out-of-pocket expenses, including but not limited to: FINRA advertising/filing fees (including
additional fees for expedited reviews as set forth in Section 2(b) herein). 6. Representations. (a)
S2K hereby represents and warrants to the Distributor that: (i) It is a limited liability company
duly organized and existing and in good standing under the laws of the State of Delaware; (ii) It
and all requisite personnel have or shall obtain and each shall use their best efforts to maintain
all approvals and licenses necessary for the performance of the Services including proper
registration and licensing with the SEC and or FINRA, as applicable; (iii) It is and will use its
best efforts to remain duly licensed or registered with the SEC, applicable state securities
regulators and FINRA, as applicable; (iv) It is empowered under applicable laws and by its limited
liability company agreement to enter into and perform this Agreement;

- 4 -

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 5 -->
(v) No consent, approval, authorization or other order of governmental authority is required in
connection with the execution or delivery by S2K of this Agreement; (vi) There are no actions, suits
or proceedings pending, or to the knowledge of S2K, threatened against S2K at law or in equity or
before or by any federal or state commission, regulatory body or administrative agency or other
governmental body, domestic or foreign, which would be reasonably expected to have a material
adverse effect on the business or property of S2K; (vii) The execution and delivery of this
Agreement, the consummation of the transactions herein contemplated and compliance with the terms of
this Agreement by S2K will not conflict with or constitute a default under any charter, bylaw,
indenture, mortgage, deed of trust, lease, rule, regulation, writ, injunction or decree of any
government, governmental instrumentality or court, domestic or foreign, having jurisdiction over a
Fund, except for such conflicts or defaults that would not reasonably be expected to have a material
adverse effect on the business or property of S2K; (viii) It will make no representations concerning
a Fund other than those contained in the applicable Prospectus or in any promotional materials or
sales literature furnished to S2K by the Distributor or prepared by S2K and approved for use by the
Distributor, except as otherwise noted in this Agreement; (ix) While it is authorized by the
Distributor to solicit purchases of Fund shares, it is understood that it will not open or maintain
customer accounts or handle orders for a Fund; (x) All requisite corporate actions have been taken
to authorize it to enter into and perform this Agreement; (xi) It and Authorized S2K Representatives
are and will use best efforts to remain properly registered with and licensed by the SEC and are and
will use best efforts to remain members in good standing of FINRA or any relevant subsidiary
thereof, as applicable; (xii) The Authorized S2K Representatives will be registered representatives
of S2K and subject to S2K's supervisory oversight in accordance with all applicable laws, rules and
regulations in connection with the services provided hereunder; and (xiii) S2K understands and
agrees that this Agreement does not relieve S2K of any obligation to which S2K may be subject under
any applicable federal or state law. (b) The Distributor represents and warrants to S2K that: (i) It
is a corporation duly organized and existing and in good standing under the laws of the State of
Colorado;

- 5 -

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 6 -->
(ii) It is a member of FINRA and it and its employees and representatives have all required licenses
and registrations required by the SEC, FINRA or any other governing body to act under this
Agreement; (iii) It is empowered under applicable laws and by its Articles of Incorporation and
By-laws to enter into and perform this Agreement; (iv) All requisite corporate proceedings have been
taken to authorize it to enter into and perform this Agreement; (v) No consent, approval,
authorization or other order of governmental authority is required in connection with the execution
or delivery by the Distributor of this Agreement; (vi) There are no actions, suits or proceedings
pending or to the knowledge of the Distributor, threatened against the Distributor at law or in
equity or before or by any federal or state commission, regulatory body or administrative agency or
other governmental body, domestic or foreign, which would be reasonably expected to have a material
adverse effect on the business or property of the Distributor; (vii) The execution and delivery of
this Agreement, the consummation of the transactions herein contemplated and compliance with the
terms of this Agreement by the Distributor will not conflict with or constitute a default under any
charter, bylaw, indenture, mortgage, deed of trust, lease, rule, regulation, writ, injunction or
decree of any government, governmental instrumentality or court, domestic or foreign, having
jurisdiction over a Fund, except for such conflicts or defaults that would not reasonably be
expected to have a material adverse effect on the business or property of the Distributor; (viii) It
has and will continue to have access to the necessary facilities, equipment and personnel to perform
its duties and obligations under this Agreement in accordance with industry standards; (ix) Each
Fund has filed a registration statement (a "Registration Statement") with the SEC relating to its
shares under the Securities Act of 1933, as amended (the "1933 Act"), on Form N-2 which includes a
Prospectus. The Registration Statement (including the Prospectus) conforms in all material respects
to the requirements of the 1933 Act, the 1940 Act and the rules thereunder; and (x) To the extent
required by applicable law, the Funds are registered and their shares are qualified for sale in the
jurisdictions listed on Exhibit C unless S2K is notified in writing to the contrary. S2K may rely
solely on such representation to the extent that S2K will only market a Fund in those jurisdictions
where such Fund is registered. The Distributor otherwise assumes no responsibility or obligation as
to S2K's right to market a Fund in any jurisdiction.

- 6 -

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 7 -->
7. Indemnification. (a) S2K shall indemnify and hold harmless the Distributor and each of its
affiliates, officers, directors, employees, agents and control persons (as defined in Section 15 of
the 1933 Act or Section 20 of the Securities Exchange Act of 1934, as amended (the "1934 Act")),
from and against any loss, liability, claim, damage or expense (including the reasonable cost of
investigating or defending any alleged loss, liability, claim, damage or expense and reasonable
counsel fees incurred in connection therewith), as incurred, arising in connection with (i) S2K's
violation of any of the provisions of this Agreement or (ii) S2K's violation of any applicable law,
rule or regulation with respect to its conduct under the Agreement; provided, however, that in no
case is the foregoing indemnity to be deemed to protect the Distributor or any of its affiliates,
officers, directors, employees, agents or control persons (as defined in Section 15 of the 1933 Act
or Section 20 of the 1934 Act) against any liability to which the Distributor or any such person
would otherwise be subject by reason of its willful misfeasance, bad faith or gross negligence or by
reason of the Distributor's reckless disregard of its obligations and duties under this Agreement.
(b) The Distributor shall indemnify and hold harmless S2K and each of its affiliates, directors,
officers, employees, agents and control persons (as defined in Section 15 of the 1933 Act or Section
20 of the 1934 Act), from and against any loss, liability, claim, damage or expense (including the
reasonable cost of investigating or defending any alleged loss, liability, claim, damage or expense
and reasonable counsel fees incurred in connection therewith), as incurred, arising in connection
with (i) the Distributor's violation of any of the provisions of this Agreement, (ii) the
Distributor's violation of any applicable law, rule or regulation with respect to its conduct under
the Agreement, or (iii) any untrue statement of a material fact or any omission of a material fact
necessary in order to make the statements made, in light of the circumstances under which they were
made, not misleading in any advertising or promotional material published or provided by the
Distributor to S2K; provided, however, that in no case is the foregoing indemnity to be deemed to
protect S2K and its affiliates, directors, officers, employees, agents and control persons (as
defined in Section 15 of the 1933 Act or Section 20 of the 1934 Act), against any liability to which
S2K or any such person would otherwise be subject by reason of its willful misfeasance, bad faith or
gross negligence or by reason of the reckless disregard of S2K's obligations and duties under this
Agreement. (c) Any and all claims, losses, cost or expenses shall be limited to actual and direct
costs. In no event shall any party be responsible to the other for indirect, special or
consequential damages. 8. Confidentiality. (a) Each party to this Agreement shall safeguard and hold
confidential from disclosure to unauthorized parties all Confidential Information (as defined below)
of the other party or parties. For purposes of this Section 8, the term "Confidential Information"
shall mean any and all information which is in any way connected with, derived from or related to
the business of a party, including without limitation, any business and financial records, any
retail or institutional customer information, computer programs, technical data, investment
information, lists, compilations, compositions, programs, plans, devices, descriptions, drawings,
methods, techniques, processes, designs, theories concepts or ideas, and any information relating to
the pricing or marketing policies, suppliers or customers of a party.

- 7 -

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 8 -->
(b) Confidential Information shall not include information to the extent such information is (i)
already known to the receiving party free of any restriction at the time obtained, including
information in the public domain; (ii) subsequently learned from an independent third party free of
restriction; (iii) known through no wrongful act of any party; or (iv) independently developed by
one party without reference to information which is confidential. (c) For purposes of this Section
8, only the officers, directors and employees and agents of the parties, including their respective
accountants, auditors and attorneys, shall be authorized parties, provided those individuals have a
"need to know" the Confidential Information that is consistent with their respective positions and
legal obligations and responsibilities. In the event that one party (the "Disclosing Party") is
requested or required by a court of competent jurisdiction or by any regulatory body which regulates
the conduct of the Disclosing Party to disclose any Confidential Information of another party (the
"Non-Disclosing Party"), the Disclosing Party shall provide the Non-Disclosing Party with prompt
notice of any such request or requirement so that the Non-Disclosing Party may seek a protective
order or other appropriate remedy and/or waive compliance with the provisions of this Agreement. If,
in the absence of a protective order or other remedy or the receipt of a waiver by the
Non-Disclosing Party, the Disclosing Party is nonetheless, in the opinion of counsel, required to
disclose Confidential Information, the Disclosing Party may, without liability hereunder, disclose
only that portion of the Confidential Information which such counsel advises the Disclosing Party is
required to be disclosed, provided that the Disclosing Party attempt to preserve the confidentiality
of the Confidential Information, including, without limitation, by cooperating with the
Non-Disclosing Party, at the Non-Disclosing Party's expense, to obtain an appropriate protective
order or other reliable assurance that confidential treatment will be accorded the Confidential
Information. (d) Each party further acknowledges and agrees that, in the event of a breach by it of
the provisions of this Section 8, the other party or parties will suffer irreparable harm and
damages and, accordingly, shall be entitled to seek injunctive or other equitable relief in a court
of competent jurisdiction. (e) The provisions of this Section 8 shall survive any termination of
this Agreement. 9. Fund Materials. S2K shall be entitled to produce materials ("Fund Materials") for
use in marketing a Fund as described herein, so long as the Fund Materials are produced, reviewed,
principally approved, used and filed, where necessary, in accordance with FINRA and SEC regulations
and those of any jurisdiction in which a Fund is solicited through use of the Fund Materials. All
expenses and costs attributable to the foregoing provision shall be borne by S2K in accordance with
Section 2 and Section 5 herein. S2K shall remain liable for any representations made by it or
contained in materials produced and approved by S2K for use in marketing the Funds. 10. Relationship
of the Parties. In carrying out the provisions of this Agreement, S2K is, for all purposes, an
independent contractor and none of S2K's offices, directors, employees or representatives is an
employee of the Distributor. As an independent contractor, S2K has no authority, express or implied,
to speak for, act for or bind the Distributor in any manner whatsoever.

- 8 -

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 9 -->
11. Regulatory Issues. (a) It is understood and agreed that in performing S2K's duties under this
Agreement, S2K hereby undertakes to, and will use commercially reasonable efforts to cause each of
its representatives, officers, directors or employees who perform services under this Agreement to
act in a manner consistent with written instructions received from the Distributor. (b) Each party
hereto agrees that any "Nonpublic Personal Information," as the term is defined in Regulation S-P
(17 CFR 248.1 - 248.30) ("Reg S-P"), may be disclosed by a party hereunder only for the specific
purpose of permitting the other party or parties to perform services set forth in this Agreement.
Each party agrees that with respect to such information, it will comply with Reg S-P and any other
applicable Federal or state regulations and that it will not disclose any Nonpublic Personal
Information received in connection with this Agreement to any party except to the extent required to
carry out the services set forth in this Agreement or as required by applicable law. 12. Use of
Names; Marketing Materials. Each party to this Agreement shall obtain the other party's prior
written consent before using any marketing or sales literature related to the consenting party, and
shall not use the other party's names in any marketing or advertising materials without prior
written consent from the consenting party. 13. Miscellaneous Provisions. (a) Notices. All notices
and other communications hereunder shall be in writing, shall be deemed to have been given when
received or when sent by telex or facsimile, and shall be given to the following addresses (or such
other addresses as to which notice is given): To Distributor: ALPS Distributors, Inc. 1290 Broadway,
Suite 1100 Denver, Colorado 80203 Attn: Jeremy O. May, President Fax: (303) 623-7850 To S2K: 777
Third Avenue 28t h Floor New York, New York 10017 Attn: Steven Kantor

- 9 -

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 10 -->
(b) Entire Agreement. This Agreement contains the entire agreement between the parties hereto
concerning the transaction contemplated herein and supersedes all prior agreements or understandings
between the parties hereto relating to the subject matter hereof. No oral representation, agreement
or understanding made by any party hereto shall be valid or binding upon such party or any other
party hereto. (c) Amendments. Except as otherwise provided herein, no provision of this Agreement
may be amended other than by a writing signed by the Distributor and S2K. (d) Severability;
Assignment. Each provision of this Agreement is intended to be severable. If any provision of this
Agreement shall be held illegal or made invalid by court decision, statute, rule or otherwise, such
illegality or invalidity shall not affect the validity or enforceability of the remainder of this
Agreement. No party to this Agreement has the right to assign any of its rights or obligations
hereunder, except as already set forth under this Agreement. (e) Headings. The headings in this
Agreement are inserted for convenience and identification only and are in no way intended to
describe, interpret, define or limit the size, extent or intent of this Agreement or any provision
hereof. (f) Counterparts. This Agreement may be executed in two or more counterparts, each of which
shall be deemed an original but all of which together shall constitute one and the same agreement.
(g) Application of Law; Consent to Jurisdiction. This Agreement and the application and
interpretation hereof shall be governed exclusively by the laws of the State of Colorado. The
parties to this Agreement agree that any appropriate state or any Federal Court located in Denver,
Colorado shall have exclusive jurisdiction of any case or controversy arising under or in connection
with this Agreement and shall be a proper forum in which to adjudicate such case of controversy. The
parties hereto consent to the jurisdiction of such courts. (Signature page follows)

- 10 -

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 11 -->
IN WITNESS WHEREOF, the parties hereto have executed this Agreement as of the date first above
written. "Distributor" ALPS DISTRIBUTORS, INC. By: Name: Steven B. Price Its: Senior Vice President
and Director of Distribution Services S2K FINANCIAL LLC By: Name: Steven Kantor Its: Chief Executive
Officer [Signature Page to Wholesale Marketing Agreement]

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 12 -->
Exhibit A NorthStar Real Estate Capital Income Fund NorthStar Real Estate Capital Income Fund-T
NorthStar Real Estate Capital Income Fund-ADV NorthStar Real Estate Capital Income Fund-C

Exhibit A

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 13 -->
Exhibit B Fee Schedule At the direction of each Fund set forth in Exhibit A to this Agreement, ALPS
or its designated agent will facilitate the payment of the applicable dealer reallowance fee to S2K
(as a percentage of the offering price) in the amounts set forth in each such Fund's then-current
Prospectus. Note: The following applies to all Funds set forth in Exhibit A to this Agreement with
the exception of the NorthStar/Townsend Institutional Real Estate Fund Inc.: In no event will a
Fund's aggregate selling commissions, dealer manager fees and distribution and servicing fees, if
applicable, exceed 8.0% of the aggregate gross proceeds raised in the Fund's offering. Therefore,
the Distributor's facilitation of the dealer reallowance payments set forth in each Fund's
then-current Prospectus shall cease with respect to the applicable Fund as of the date such 8.0%
threshold has been reached with respect to such Fund.

Exhibit B

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
<!-- page 14 -->
Exhibit C Jurisdictions [List of jurisdictions where the Funds are registered for sale]

Exhibit C

Source: CC REAL ESTATE INCOME FUND-ADV, POS 8C, 12/5/2018
