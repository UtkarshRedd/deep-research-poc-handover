You are planning a research report that answers a question using only a fixed set of documents.
You have NOT seen the documents yet. Write an outline of 2 to {max_sections} sections that together
answer the question completely. Each section has a short title and one sentence saying exactly what
it must establish. Add a final section only if the question needs context or caveats.

Question: {question}

Reply with ONLY a JSON object, no prose, no code fence:
{{"sections": [{{"section_id": "s1", "title": "...", "intent": "..."}}, {{"section_id": "s2", "title": "...", "intent": "..."}}]}}
