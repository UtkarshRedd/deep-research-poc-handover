<!-- page 1 -->
# Online Hosting Agreement
| Field | Value |
|---|---|
| Document Type | Hosting Agreement |
| Agreement Date | 1999-06-01 |
| Parties | Diplomat Direct Marketing Corporation ("Diplomat"); Tadeo E-Commerce Corp. ("Tadeo") |
| Source | CUAD v1 / DYNTEKINC_07_30_1999-EX-10-ONLINE HOSTING AGREEMENT |

[FORM]

ONLINE HOSTING AGREEMENT

This Online Hosting Agreement (this "Agreement") is being entered into effective as of the 1st day
of June, 1999 and is entered into by and between Diplomat Direct Marketing Corporation, a Delaware
corporation ("Diplomat"), and Tadeo E-Commerce Corp., a Delaware corporation ("Tadeo").

R E C I T A L S

A. Historically, Diplomat has been engaged directly in, among other things, the business of offering
consumers the opportunity to place apparel orders directly with Diplomat through its toll free
telephone number and its web site (the "Direct Access Business").

B. Recently, Tadeo was formed and Tadeo and Diplomat have entered into a Web Design and Consulting
Agreement of even date herewith (the "Web Agreement") pursuant to which Tadeo has agreed to assist
Diplomat in developing the technology, and providing other services necessary, to further Diplomat's
Direct Access Business, including the hosting and maintenance of Diplomat's web site (the "Web
Site").

C. In connection with Diplomat's operation of its Direct Access Business, Diplomat desires to obtain
various online hosting services ("Services") from Tadeo, and Tadeo desires to provide such Services
to Diplomat.

THEREFORE, THE PARTIES HEREBY AGREE AS FOLLOWS:

Section 1. SERVICES.

Tadeo shall provide, directly or through a third party vendor reasonably satisfactory to Diplomat,
the Online Hosting Services described on EXHIBIT A hereto, at the cost specified and on the other
terms and conditions as set forth on EXHIBIT A.

Section 2. COMPENSATION.

Diplomat will pay to Tadeo when due a fee for each of the Services equal to the amount described in
EXHIBIT A hereto relating to each such Service; PROVIDED, that in the event Diplomat terminates this
Agreement in accordance with Section 3 hereof, the fee for the provision of each

- 2 -

terminated Service shall cease to accrue on and after the effective date of such termination. In the
event that Diplomat terminates this Agreement other than in accordance with Section 3, Diplomat
shall be obligated to pay for the Services in accordance with the fee schedule contained on EXHIBIT
A throughout the balance of the Period (as hereinafter defined) as though Tadeo continued to provide
the terminated Services through the balance of the Period. Late payments shall accrue interest at a
rate equal to fifteen (15%) percent per annum.

Section 3. TERM.

(a) The term of this Agreement shall begin on the date hereof (the "Effective Date") and shall
continue for a period of 12 months thereafter (the "Period") in full force and effect until it is
terminated in accordance with this Section 3.

(b) Diplomat or Tadeo, if such party is not in default of the terms of this Agreement, may extend
the term of this Agreement for an additional one year ("Additional Period"), provided the extending
party gives the other party at least sixty (60) days advance written notice before the end of the
Period. If either party elects to extend the Agreement for the Additional Period, all other terms
and conditions of this Agreement shall continue during the Additional Period.

(c) Tadeo shall have the right (but not the obligation) to terminate this Agreement and the rights
granted to Diplomat hereunder if:

(i) Diplomat is in material breach of any of its obligations hereunder, which breach is not cured
within five days of receipt of written notice from Tadeo of such breach;

(ii) The Web Agreement is terminated by any of Tadeo, Diplomat, or any other party thereto [in the
event the rights and obligations of any party(ies) to such Web Agreement have been duly assigned to
a third party(ies) under the terms thereof] in accordance with the terms of the Web Agreement, but
not if the Web Agreement is terminated by Tadeo or its assignee(s) other than in accordance with the
terms of the Web Agreement;

(iii) Diplomat is the subject of a voluntary petition in bankruptcy or any voluntary proceeding
relating to insolvency, receivership, liquidation or composition for the benefit of creditors, if
such petition or proceeding is not dismissed within 60 days of filing, or becomes the subject of any
involuntary petition in bankruptcy or any involuntary proceeding relating to insolvency,
receivership, liquidation or composition for the benefit of creditors, if such petition or
proceeding is not dismissed within 60 days of filing;
<!-- page 2 -->
(iv) Diplomat involuntarily dissolves or is dissolved;

- 3 -

(v) Diplomat is judicially adjudicated insolvent or generally is unable to pay its debts as they
mature or makes an assignment for the benefit of its creditors; or

(vi) Upon Tadeo giving Diplomat at least sixty (60) days advance written notice of termination of
this Agreement.

(d) Diplomat shall have the right (but not the obligation) to terminate this Agreement and the
rights granted to Tadeo hereunder if:

(i) Tadeo is in material breach of any of its obligations hereunder, which breach is not cured
within five days of receipt of written notice from Diplomat of such breach;

(ii) The Web Agreement is terminated by any of Tadeo, Diplomat, or any other party thereto [in the
event the rights and obligations of any party(ies) to such Web Agreement have been duly assigned to
a third party(ies) under the terms thereof] in accordance with the terms of the Web Agreement, but
not if the Web Agreement is terminated by Diplomat or its assignee(s) other than in accordance with
the terms of the Web Agreement;

(iii) Tadeo is the subject of a voluntary petition in bankruptcy or any voluntary proceeding
relating to insolvency, receivership, liquidation or composition for the benefit of creditors, if
such petition or proceeding is not dismissed within 60 days of filing, or becomes the subject of any
involuntary proceeding relating to insolvency, receivership, liquidation or composition for the
benefit of creditors, if such petition or proceeding is not dismissed within 60 days of filing.

(iv) Tadeo involuntarily dissolves or is dissolved;

(v) Tadeo is judicially adjudicated insolvent or generally is unable to pay its debts as they mature
or makes an assignment for the benefit of its creditors; or

(vi) Upon Diplomat giving Tadeo at least sixty (60) days advance written notice of termination of
this Agreement.

(e) Tadeo will have the right (but not the obligation) to terminate this Agreement and the rights
granted to Diplomat hereunder, upon 60 days written notice to Diplomat, following the acquisition of
all or substantially all of the assets of Diplomat by any Permitted Assignee (as defined in Section
9(a) of this Agreement), or the acquisition of the beneficial ownership of at least 20% (the
"Threshold") of the voting power represented by the voting securities of Diplomat, any successor
thereto or any Permitted Assignee by any person or

- 4 -

"group" within the meaning of Sections 13(d)(3) and 14(d)(2) of the Securities Exchange Act of 1934,
as amended (the "Exchange Act"), or any successor provision to either of the foregoing, including
any group acting for the purpose of acquiring, holding or disposing of securities within the meaning
of Rule 13d-5(b)(1) under the Exchange Act or any successor provision thereof (a "group") other than
The Rubin Family Irrevocable Stock Trust U/A dated April 30, 1997, organized under the laws of the
State of New York (the "Trust"), Robert M. Rubin ("Rubin"), or any affiliate of Rubin or the Trust.
For purposes of this Agreement, (i) the term "beneficial ownership" shall have the meaning set forth
in Rule 13d-3 of the Exchange Act or any successor provisions thereof, (ii) the term "voting
securities' means the common Stock, par value $.0001 per share, of Diplomat and any other securities
issued by Diplomat having the power to vote generally in the election of directors of Diplomat and
(iii) the term "affiliate" means a person or entity directly or indirectly controlled by,
controlling or under common control with another person. For purposes of this Section 3, an
acquisition shall not include (A) the acquisition by a person of voting securities of Diplomat
pursuant to an involuntary disposition through foreclosure or similar event, or (B) the acquisition
by a person of voting securities of Diplomat pursuant to a dividend intended to be on a tax-free
basis (a "Tax-Free Spin-Off") under the Internal Revenue Code of 1986, as amended from time to time,
but shall include a subsequent acquisition of voting securities pursuant to a disposition by the
person that acquired the voting securities in such involuntary disposition or such Tax-Free
Spin-Off. In the event any person acquires beneficial ownership of voting power in excess of the
Threshold as a result of a transaction described in the immediately preceding sentence, the
Threshold with respect to such person shall be adjusted to an amount equal to the percentage of
beneficial ownership held by such person immediately following such transaction.

(f) A party may exercise its right to terminate pursuant to this Section 3 by sending appropriate
written notice to the other party. No exercise by a party of its rights under this Section will
limit its remedies by reason of the other party's default, the party's rights to exercise any other
rights under this Section 3, or any of that party's other rights.

Section 4. RECORDS AND ACCOUNTS.
<!-- page 3 -->
Tadeo will maintain accurate books, records and accounts of all transactions relating to the
Services performed by it pursuant to this Agreement. Diplomat may, at its own expense, examine and
copy those books and records as provided in this Section 4. Such books, records and accounts will be
maintained in a manner that allows Diplomat to separate these matters from those relating to Tadeo's
other operations. Such books, records and accounts will reflect such information as would normally
be examined by an independent accountant in performing an audit pursuant to United States generally
accepted auditing standards for the purpose of certifying financial statements, and to permit
verification thereof by governmental agencies. Diplomat may make examinations pursuant hereto during
Tadeo's usual business hours, and at the place in the continental United States where Tadeo
regularly keeps these books and records. Diplomat will be required to notify Tadeo at least five
business days before the date of planned examination. If Diplomat's examination is not completed
within one month from commencement, Tadeo at any time may require Diplomat to terminate such
examination on

- 5 -

seven days' notice to Diplomat; PROVIDED that Tadeo has cooperated with Diplomat in the examination
of such books and records.

Section 5. NO RESTRICTIONS.

Nothing in this Agreement shall limit or restrict the right of any of Diplomat's directors, officers
or employees or any of Tadeo's directors, officers or employees to engage directly or indirectly in
the same or similar business activities or lines of business as Diplomat or, respectively, or limit
or restrict the right of Diplomat or Tadeo as the case may be, to engage in any other business or to
render or obtain, as the case may be, services of any kind to or from, as the case may be , any
corporation, firm, individual, trust or association.

Section 6. INDEPENDENT CONTRACTORS.

Tadeo and Diplomat are independent contractors. There is no relationship of partnership, joint
venture, employment, franchise or agency between Tadeo and Diplomat. Neither Tadeo nor Diplomat
shall have the power to bind the other or incur obligations on the other's behalf without the
other's prior written consent. When Tadeo's employees act under the terms of this Agreement, they
shall be deemed at all times to be under the supervision and responsibility of Tadeo and no person
employed by Tadeo and acting under the terms of this Agreement shall be deemed to be acting as agent
or employee of Diplomat or any customer of Diplomat for any purpose whatsoever.

Section 7. CONFIDENTIALITY.

Tadeo and Diplomat each agree to hold in strict confidence, and to use reasonable efforts to cause
each of their employees and representatives to hold in strict confidence, all confidential
information concerning Tadeo or Diplomat, as the case may be, furnished to or obtained by the other
party, in the course of performing the obligations provided for under this Agreement except to the
extent that (a) such information has been in the public domain through no fault of Tadeo or
Diplomat, as the case may be, (b) disclosure or release is compelled by judicial or administrative
process, or (c) in the opinion of counsel to Tadeo or Diplomat, as the as may be, disclosure or
release is necessary pursuant to requirements of law or the requirements of any governmental entity
including, without limitation, disclosure requirements under the securities laws of the United
States or similar laws of other jurisdictions applicable to Tadeo or Diplomat, as the case may be.

Section 8. PROPRIETARY RIGHTS OF TADEO.

All materials, including but not limited to any computer software (in object code and source code
form), data or information developed or provided by Tadeo, or its suppliers under this Agreement,
and any know-how, methodologies, equipment, or processes used by Tadeo to provide the Services to
Diplomat, including, without limitation, all copy-rights, trademarks,

- 6 -

patents, trade secrets, and any other proprietary rights inherent therein and appurtenant thereto
(collectively, "Host Materials") shall remain the sole and exclusive property of Tadeo or its
suppliers. To the extent, if any, that ownership of the Hose Materials does not automatically vest
in Tadeo by virtue of this Agreement or otherwise, Diplomat hereby transfers and assigns to Tadeo
all rights, title and interest which Diplomat may have in and to the Host Materials. Diplomat
acknowledges and agrees that Tadeo is in the business of designing and hosting Web sites, and that
Tadeo shall have the right to provide to third parties services which are the same or similar to the
Tadeo Services, and to use or otherwise exploit any Host Materials in providing such services.

Section 9. DISPUTE RESOLUTION.

(a) In the event that any party to this Agreement has any claim, right or cause of action against
any other party to this Agreement, which the parties shall be unable to settle by agreement between
themselves, such claim, right or cause of action, to the extent that the relief sought by such party
is for monetary damages or awards, shall be determined by arbitration in accordance with the Rules
of the American Arbitration Association ("AAA"),
<!-- page 4 -->
through the adjudication by a single arbitrator, in New York, New York, with the decision of such
arbitrator to be final and binding upon all parties. The fees, costs and expenses of such
arbitration, as submitted by the AAA, shall be borne equally by both Tadeo and Diplomat; PROVIDED,
that each of Tadeo and Diplomat shall pay the fees, costs and expenses of its own counsel,
accountants and other representatives in connection with such arbitration. The parameters of the AAA
proceedings undertaken in accordance with this Section 8 shall be prescribed such that a decision
shall be rendered within sixty (60) days following the initial written reference of the related
dispute to AAA arbitration.

(b) Notwithstanding any other provisions of this Section 8, in the event that a party against whom
any claim, right or cause of action is asserted commences, or has commenced against it, bankruptcy,
insolvency or similar proceedings, the party or parties asserting such claim, right or cause of
action shall have no obligations under this Section 8 and may assert such claim, right or cause of
action in the manner and forum it deems appropriate, subject to applicable laws. No determination or
decision by the arbitrators pursuant to this Section 8 shall limit or restrict the ability of any
party hereto to obtain or seek in any appropriate forum, any relief or remedy that is not a monetary
award or money damages.

Section 10. MISCELLANEOUS.

(a) Neither party any assign this Agreement, or their respective rights and obligations hereunder,
in whole or in part, without the other party's prior written consent; PROVIDED, HOWEVER, that Tadeo
shall be entitled to assign all of its rights and obligations hereunder to any subsidiary or
affiliated entity without the consent of Diplomat. Any attempt to assign this Agreement without such
consent (if required) shall be void and of no effect AB INITIO. Notwithstanding the immediately
preceding sentence, either party may assign this Agreement or all, but not less than all, of its
rights and obligations hereunder to any entity that acquires it by

- 7 -

purchase of stock or by merger or otherwise, or by obtaining all or substantially all of its assets
(a "Permitted Assignee"); PROVIDED, that any such Permitted Assignee thereafter succeeds to all of
the rights and is subject to all of the obligations of the assignor under this Agreement; and
PROVIDED, HOWEVER, that the provisions of this Section 9(a) shall in no way modify the provisions of
Section 3(d).

(b) This Agreement shall be governed by and construed in accordance with the internal laws of the
State of New York applicable to agreements made and to be performed entirely within such State,
without regard to the conflicts of law principles of such State. Each party shall comply in all
respects with all laws and regulations applicable to its activities under this Agreement.

(c) Notwithstanding the provisions of Section 8, each party hereto irrevocably submits to the
exclusive jurisdiction of (a) the courts of the State of New York, New York County, or (b) the
Untied States District Court for the southern District of New York, for the purposes of any suit,
action or other proceeding arising out of this Agreement or any transaction contemplated hereby or
thereby. Each of Diplomat and Tadeo agrees to commence any such action, suit or proceeding either in
the Untied States District Court for the Southern District of New York, or if such suit, action or
other proceeding may not be brought in such court for jurisdictional reasons, in the courts of the
State of New York County. Each of Diplomat and Tadeo further agrees that service of any process,
summons, notice or documents by U.S. registered mail to such party's respective address set forth
below shall be effective service of process for any action, suit or proceeding in New York with
respect to any matters to which it has submitted to jurisdiction in this Section 9(c). Each of
Diplomat and Tadeo irrevocably and unconditionally waives any objection to the laying of venue of
any action, suit or proceeding arising out of this Agreement or the transactions contemplated hereby
and thereby in (i) the courts of the State of New York County, or (ii) the United States District
Court for the Southern District of New York, and hereby and thereby further irrevocably and
unconditionally waives and agrees not to plead or claim in any such court that any such action, suit
or proceeding brought in any such court has been brought in an inconvenient forum.

(d) If any provisions of this Agreement (or any portion thereof) or the application of any such
provision (or any portion thereof) to any person or circumstance shall be held invalid, illegal or
unenforceable in any respect by a court of competent jurisdiction, such invalidity, illegality or
unenforceability shall not affect any other provision hereof (or the remaining portion thereof) or
the application of such provision to any other persons or circumstances.

(e) All notices or other communications required or permitted to be given hereunder shall be in
writing and shall be delivered by hand, by facsimile (with confirmation back), or sent, postage
prepaid, by registered, certified or express mail or nationally recognized overnight courier service
and shall be deemed given when so delivered by hand, by facsimile (with confirmation back), or if
mailed, three days after mailing (one business day in the case of express mail or overnight courier
service), as follows:

- 8 -

(i) if to Tadeo:
<!-- page 5 -->
Tadeo E-Commerce Corp. 5 Hanover Square New York, New York 10004 Attention: Damon Testaverde,
President

(ii) if to Diplomat:

Diplomat Direct Marketing Corporation 414 Alfred Avenue Teaneck, New Jersey 07666 Attention: Warren
H. Golden, President

(f) The provisions of Sections 7, 8 and 9 hereof shall survive any termination of this Agreement.

(g) No failure to either party to exercise or enforce any of its rights under this Agreement shall
act as a waiver of such right.

(h) This Agreement, along with the Exhibit hereto, contains the entire agreement and understanding
between the parties hereto with respect to the subject matter hereof and supersedes all prior
agreements and understandings relating to such subject matter. Neither party shall be liable or
bound to any other party in any manner by any representations, warranties or convenants relating to
such subject matter expect as specifically set forth herein.

(i) This Agreement may be executed in one or more counterparts, all of which shall be considered one
and the same agreement, and shall become effective when one or more such counterparts have been
signed by each of the parties and delivered to each of the other parties.

(j) This Agreement may not be amended except by an instrument in writing signed on behalf of each of
the parties hereto.

(k) This Agreement is for the sole benefit of the parties hereto and nothing herein expressed or
implied shall give or be construed to give to any person, other than the parties hereto any legal or
equitable rights hereunder.

(l) The headings contained in this Agreement or in any Exhibit hereto are for reference purposes
only and shall not affect in any way the meaning or interpretation of this Agreement. All Exhibits
annexed hereto or referred to herein are hereby incorporated in and made a part of this Agreement as
if set forth in full herein. Any capitalized terms used in any Exhibit but not otherwise defined
therein, shall have the meaning as defined in this Agreement. When a reference is made in this
Agreement to a Section or an Exhibit, such reference shall be to a Section of, or an Exhibit to,
this Agreement unless otherwise indicated.

- 9 -

IN WITNESS WHEREOF, the parties hereto have executed this Agreement as of June 30, 1999.

TADEO E-COMMERCE CORP.

By: /s/ Damon Testaverde Damon Testaverde President

DIPLOMAT DIRECT MARKETING CORP.

By /s/ Warren H. Golden Warren H. Golden President

EXHIBIT A

ONLINE HOSTING SERVICES

If requested by Diplomat, Tadeo will provide, by itself or through its subsidiaries or affiliates,
the Services described below:

(a) Scope and Description of Services. Tadeo will provide Diplomat with all online hosting services
currently provided to Diplomat through third party contracts, including, without limitations, the
development and maintenance for Diplomat's operating divisions and/or operating subsidiaries of
Commerce Web Subsites (as defined below) within the www.______ web site on the Internet based on
online Enrollment and Information Forms, completed by Diplomat, submitted in conformance with
Tadeo's instructions. Notwithstanding anything herein to the contrary, Tadeo and Diplomat will
confer, from time to time, with respect to the placement of the link to this information and the
manner in which this link appears on the subject web site; PROVIDED, that if mutual agreement is not
reached on such placement, the reasonable determination with respect thereto made by Tadeo shall be
final and binding on both parties. If a consumer places an order directly on a Tadeo-operated
Commerce Web Subsite for a Diplomat Direct Access Business product, Tadeo agrees to transmit such
order to Diplomat's Direct Access Business network and Diplomat will convert that order to a message
and direct the order for internally processed fulfillment, with Diplomat receiving 100% of the
order's value subject to any processing charges (subject
<!-- page 6 -->
to the terms of the Web Agreement). For the purposes of this Agreement, the terms "Commerce Web
Subsite" means a web site through which a consumer can place an order for Diplomat products.

(b) Price. For the services described above, Diplomat will pay Tadeo a monthly fee of $____________
for each Commerce Web Subsite hosted by Tadeo in accordance with the Fee Schedule annexed as EXHIBIT
A-1.

(c) Payment and Accounting. Tadeo will invoice Diplomat within 15 days of the end of each month for
Services rendered in such month. Diplomat will pay such invoice within 30 days of receipt.

EXHIBIT A-1

[Omitted]
