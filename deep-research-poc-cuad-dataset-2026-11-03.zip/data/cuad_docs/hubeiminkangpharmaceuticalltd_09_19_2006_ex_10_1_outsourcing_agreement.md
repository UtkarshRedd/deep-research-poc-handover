<!-- page 1 -->
# PHOTO RETOUCHING OUTSOURCING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Outsourcing Agreement |
| Agreement Date | 2006-06-01 |
| Parties | (DGT Corp. ("DGT"); Dolphin Industries Limited ("Dolphin") |
| Source | CUAD v1 / HUBEIMINKANGPHARMACEUTICALLTD_09_19_2006-EX-10.1-OUTSOURCING AGREEMENT |

PHOTO RETOUCHING OUTSOURCING AGREEMENT

Between: DGT Corp. Suite 207 - 1130 Austin Avenue, Coquitlam, British Columbia, Canada V3K 3P5
(hereinafter referred to as "DGT")

And: Dolphin Industries Limited Room 1302 Golden Gate Commercial Bldg 136 Austin Road Tsimshatsui,
Hong Kong (hereinafter referred to as "Dolphin")

WHEREAS:

DGT is an internet provider of professional digital photo-editing services for photography studios
and digital photo processors.

Both parties are desirous of entering into this Agreement regarding the outsourcing of photo-editing
services of DGT's clients in the North American market place and elsewhere.

NOW THEREFORE THIS AGREEMENT WITNESSETH that both parties agrees as follows: 1.DGT shall pay Dolphin
USD10,000, for carrying out the beta testing of the quality of their photo-editing services and
testing of the Internet bandwidth for file transmission. This amount is to be paid in two monthly
installments, USD5,000 on the date of this Agreement and USD5,000, 30 days subsequent to the date of
this Agreement; 2.Upon successful completion of the beta testing stage, DGT will guarantee Dolphin
the greater of: (1) USD5,000 for each 30 day period of photo-editing work completed for a total of
90 days (payment to be effective 30 days from the successful completion of the beta tests); or (2) a
minimum of 3,300 pictures to be edited for each 30 day period for a total of 90 days at USD1.50 per
finished digital photo; 3.Dolphin agrees to complete its photo-editing services within 14 days of
receiving the original digital photo files. The completed files must meet DGT pre-defined standards
for finished products; 4.Dolphin shall charge DGT USD1.50 per delivered, completed photo. The price
per unit shall be open to renegotiation - in response to competitive pricing pressures - upon
receipt of written notice at any time by either party; Page 1 of 5
<!-- page 2 -->
5.Dolphin will provide photo-editing services exclusively, at DGT option, when the number of
downloaded photos to be edited by Dolphin totals 50,000 in a single year; 6.Dolphin acknowledges
that it is illegal to copy or reproduce these photographs, including but not limited to electronic
reproduction, without DGT expressed permission, and any violation will be subject to civil and
criminal penalties. WHEREAS BOTH PARTIES AGREE FURTHER TO THE TERMS AND CONDITONS AS FOLLOWS:
Indemnity And Limitation of Liability: Dolphin hereby indemnifies, holds harmless and defends DGT,
its Board of Directors, officers, and agents against any and all claims (including all legal fees
and disbursements incurred in association therewith) arising out of the exercise of any rights under
this Agreement including, without limiting the generality of the foregoing, against any damages or
losses, consequential or otherwise, arising from or out of the use of DGT's products under this
Agreement by Dolphin or their customers or end-users howsoever the same may arise. DGT's total
liability, whether under the express or implied terms of this Agreement, in tort (including
negligence), or at common law, for any loss or damage suffered by Dolphin, whether direct, indirect
or special, or any other similar or like damage that may arise or does arise from any breaches of
this Agreement by DGT and its Directors, Officers or agents, shall be limited to the amount of the
cost of the products. In no event shall DGT be liable for consequential or incidental damages
arising from any breach or breaches of this Agreement. No action, whether in contract or tort
(including negligence), or otherwise arising out of or in connection with this Agreement, may be
brought by Dolphin more than six months after the cause of action has occurred. Right of photo
Records: Dolphin shall maintain at its principal place of business, or such other place as may be
most convenient, separate accounts and records of all services provided to DGT, such accounts and
records to be in sufficient detail to enable proper returns to be made under this Agreement. Dolphin
shall deliver to DGT on the date 30 days after each and every year a detailed photo-editing report
on all services provided on a unit basis (i.e. customer number, file number, cost). Page 2 of 5
<!-- page 3 -->
The calculation shall be carried out in accordance with generally accepted U.S. accounting
principles ("GAAP"), or the standards and principles adopted by the U.S. Financial Accounting
Standards Board ("FASB") applied on a consistent basis. During the term of this Agreement, and
thereafter, Dolphin shall use reasonable efforts to ensure that all information provided to DGT or
its representatives pursuant to this Article remains confidential and is treated as such by DGT.
Governing Law And Arbitration: This Agreement shall be governed by and construed in accordance with
the laws of the State of Nevada, USA in force therein without regard to its conflict of law rules.
All parties agree that by executing this Agreement they have attorned to the jurisdiction of the
Supreme Court of the United States. The Supreme Court shall have exclusive jurisdiction over this
Agreement. In the event of any dispute arising between the parties concerning this Agreement, its
enforceability or the interpretation thereof, the same shall be settled by a single arbitrator
appointed pursuant to the provisions of the Commercial Arbitration Act of the State of Nevada, or
any successor legislation then in force. The language to be used in the arbitration proceedings
shall be English. Notices: All payments, reports and notices or other documents that any of the
parties hereto are required or may desire to deliver to any other party hereto may be delivered only
by personal delivery or by registered or certified mail, telex or fax, all postage and other charges
prepaid, at the address for such party set forth below or at such other address as any party may
hereinafter designate in writing to the others. Any notice personally delivered or sent by telex or
fax shall be deemed to have been given or received at the time of delivery, telexing or faxing. Any
notice mailed as aforesaid shall be deemed to have been received on the expiration of five days
after it is posted, provided that if there shall be at the time of mailing or between the time of
mailing and the actual receipt of the notice a mail strike, slow down or labour dispute which might
affect the delivery of the notice by the mails, then the notice shall only be effected if actually
received. Termination: DGT shall be entitled to terminate this Agreement if Dolphin fails to meet
its requirements and material obligation hereunder and only after DGT have given Dolphin written
notice of such failure and only after Dolphin has not rectified such failure within 10 days of the
notice. Dolphin shall be entitled to terminate this Agreement only after DGT fails to meet a
material obligation hereunder and only after Dolphin has given DGT written notice of such failure
and only after the DGT has not rectified such failure within 30 days of the notice. Page 3 of 5
<!-- page 4 -->
General: 1.Dolphin shall be entitled to defer any obligation hereunder in the event of force
majeure, where force majeure is defined as an act of God, war, revolution, insurrection, riot,
blockade or any other unlawful act against public order or authority, strike, lockout or other
industrial disturbance, storm, fire, flood, explosion or lightning, the failure to obtain the
approval or any government, governmental agency, commission, board or other tribunal having
jurisdiction, and any other event not reasonably within the control of Dolphin; 2.Any notice,
demand, payment or other communication (collectively the "Correspondence") to be given hereunder
shall be in writing and shall be delivered to the address or fax number of the party appearing
herein; 3.Both parties shall do all such things and execute all such written materials as may be
required to carry out the full intent and meaning of this Agreement; and 4.This is the entire
Agreement between the parties in respect of the matter referred to herein and no amendment or
interpretation of this Agreement will be binding on the parties unless same is in writing executed
by the parties hereto. 5.Dolphin shall permit any duly authorized representative of DGT, during
normal business hours and at DGT's sole risk and expense, to enter upon and into any premises of
Dolphin for the purpose of inspecting the service. 6.Nothing contained herein shall be deemed or
construed to create between the parties hereto a partnership or joint venture. No party shall have
the authority to act on behalf of any other party, or to commit any other party in any manner or
cause whatsoever or to use any other party's name in any way not specifically authorized by this
Agreement. No party shall be liable for any act, omission, representation, obligation or debt of any
other party, even if informed of such act, omission, representation, obligation or debt. 7.Subject
to the limitations hereinbefore expressed, this Agreement shall enure to the benefit of and be
binding upon the parties and their respective successors and permitted assigns. 8.No condoning,
excusing or overlooking by any party of any default, breach or non-observance by any other party at
any time or times in respect of any covenants, provisos or conditions of this Agreement shall
operate as a waiver of such party's rights under this Agreement in respect of any continuing or
subsequent default, breach or non-observance, so as to defeat in any way the rights of such party in
respect of any such continuing or subsequent default or breach, and no waiver shall be inferred from
or implied by anything done or omitted by such party, save only an express waiver in writing. 9.No
exercise of a specific right or remedy by any party precludes it from or prejudices it in exercising
another right or pursuing another remedy or maintaining an action to which it may otherwise be
entitled either at law or in equity. Page 4 of 5
<!-- page 5 -->
10.Marginal headings as used in this Agreement are for the convenience of reference only and do not
form a part of this Agreement and are not be used in the interpretation hereof. 11.If any Article,
part, section, clause, paragraph or subparagraph of this Agreement shall be held to be indefinite,
invalid, illegal or otherwise voidable or unenforceable, the entire Agreement shall not fail on
account thereof, and the balance of this Agreement shall continue in full force and effect. 12.Time
shall be of the essence of this Agreement. 13.Whenever the singular or masculine or neuter is used
throughout this Agreement the same shall be construed as meaning the plural or feminine or body
corporate when the context or the parties hereto may require. IN WITNESS WHEREOF the parties hereto
have hereunto executed this Agreement on the 1st day of JUNE , 2006 , but effective as of the Date
of Commencement. SIGNED FOR AND ON BEHALF of DGT CORP. ) by its duly authorized officers: ) ) ) /s/
Norman Joe, President ) Authorized Signatory ) ) SIGNED FOR AND ON BEHALF of DOLPHIN INDUSTRIES
LIMITED ) ) by its duly authorized officers: ) ) ) /s/ Chung-Keung Ho, President/Director )
Authorized Signatory )
