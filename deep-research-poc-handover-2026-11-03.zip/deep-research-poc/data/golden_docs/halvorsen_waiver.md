<!-- page 1 -->
# Limited Waiver — Halvorsen Marine Holdings
| Field | Value |
|---|---|
| Document Type | Waiver |
| Effective Date | 2025-11-07 |
| Parties | Halvorsen Marine Holdings, Inc.; Meridian Trust Bank, N.A. |
| Facility ID | FAC-2025-0042 |
| Version | Limited Waiver |

THIS LIMITED WAIVER (this "Waiver") is entered into as of 2025-11-07 among Halvorsen Marine Holdings, Inc. (the "Borrower"), the Required Lenders and Meridian Trust Bank, N.A., as Administrative Agent, under the Credit Agreement dated as of 2025-02-14 (as amended, the "Credit Agreement"; facility FAC-2025-0042).

## Recitals
WHEREAS, the Borrower has advised the Administrative Agent that the Leverage Ratio as of the fiscal quarter ended 2025-09-30 was 4.68 to 1.00, exceeding the maximum of 4.50 to 1.00 permitted under Section 7.1 of the Credit Agreement (the "Specified Default");
WHEREAS, the Borrower has requested that the Required Lenders waive the Specified Default, and the Required Lenders are willing to do so on the terms set forth herein;
<!-- page 2 -->
## Section 1 — Limited Waiver
Subject to Section 2, the Required Lenders hereby waive the Specified Default solely for the fiscal quarter ended 2025-09-30. This Waiver does not amend Section 7.1 of the Credit Agreement, which continues to require a Leverage Ratio not exceeding 4.50 to 1.00 for each subsequent fiscal quarter.
## Section 2 — Conditions
This Waiver is effective upon the Administrative Agent's receipt of (a) counterparts executed by the Borrower and the Required Lenders and (b) a waiver fee of $125,000 for the ratable account of the consenting Lenders.
The Borrower shall deliver to the Administrative Agent, within ten (10) Business Days after the date hereof, a thirteen-week cash flow forecast and shall deliver an updated forecast on the first Business Day of each month thereafter until the Leverage Ratio is in compliance for two consecutive fiscal quarters.
<!-- page 3 -->
## Section 3 — Reservation of Rights; Effect
Except as expressly set forth herein, the Lenders reserve all rights and remedies under the Loan Documents. Nothing herein constitutes a waiver of any other Default or a course of dealing.
Except as expressly waived hereby, the Credit Agreement remains in full force and effect. This Waiver is a Loan Document.
This Waiver shall be governed by the laws of the State of New York. Notices shall be given in the manner set forth in Section 10.1 of the Credit Agreement.
Halvorsen Marine Holdings, Inc., as Borrower — By: /s/ Authorized Signatory
Meridian Trust Bank, N.A., as Administrative Agent — By: /s/ Authorized Signatory
