# Retrieval for paraphrased and reasoning-intensive clauses — research report (2026-11-02)

**Question.** Our retrieval is purely lexical (ephemeral per-query BM25 over ~15,000 chunks, grep, a planner-written
first move with pseudo-relevance expansion, an agent that reformulates). It is near-perfect when the question and the
clause share vocabulary and misses clauses phrased in other words ("non-compete" vs "shall not sell competing
products"). An embedding endpoint may become available. What is the best-evidenced design for (a) the first move,
(b) the agent's search tool, (c) the extract grid's chunk selection, (d) enumeration across many contracts,
(e) negation and conditional questions, and what should be measured?

**Method.** Automated deep-research workflow: 5 search angles → 23 sources fetched → 114 claims extracted → the top
25 verified by a 3-vote adversarial panel (2 of 3 refutations kill a claim) → 15 confirmed, 10 refuted, 0 unverified
→ merged into 8 findings. Verification votes and synthesis ran on Claude Opus 5.5. Numbers below are as reported by the
cited sources; domain transfer to English commercial contracts is weak everywhere (see Caveats). Companion to the
broader architecture report commissioned the same day.

## Summary

The best-supported change for the paraphrase gap is to **add dense retrieval alongside the BM25 deep list and fuse
the two, not to replace BM25**. In zero-shot legal retrieval, tuned BM25 still beat every neural model on top-rank
precision (R@10 0.367 vs 0.325 for BGE-M3 dense), while dense won at deep recall (R@500 0.734 vs 0.672). Fusing the
two improved 82 % of the configurations tested (BM25 + SPLADE raised R@500 from 0.672 to 0.755). On contract
retrieval, the only legal embedding benchmark that survived verification (vendor-built) ranks Voyage 3 Large first at
86.05 nDCG@10; the best open-weight model is Qwen3-Embedding-4B at 84.19, ahead of text-embedding-3-large (79.70) and
BGE-M3 (73.04).

For reranking, **listwise** reasoning rerankers lead BRIGHT (ReasonRank-7B 35.74, ReasonRank-32B 38.03, vs Rank1-32B
28.34) and run 2–2.7× faster than pointwise reasoning rerankers. Chain-of-thought inside a **pointwise** reranker does
not help (7B: 31.0 without it vs 27.8 with it). An LLM reranker in the first move should either judge a window of
candidates at once (listwise) or score each candidate without reasoning.

Questions beyond similarity are weak spots for retrieval itself. **Negation:** on NevIR only LLM rerankers reach
65–77 % pairwise accuracy; most cross-encoders sit near random. **Versioned documents:** on TIDE, dense RAG trails
gold-context reading by 4.4–12.4 points; even with the correct text supplied the best model reaches 68.5 % and
detects a wrong version only 26.7 % of the time. Both point to the same design: retrieve the positive clause type,
have the model read each contract to decide presence or absence, and resolve versions with deterministic
effective-date logic in the harness.

**No verified evidence survived on embedding cost and latency, contract chunking, query-side expansion (HyDE,
Query2doc, SPLADE per query) or zero-shot CUAD clause classification. All of these must be measured locally.**

## Verified findings

### 1. Which embedders lead on contract clauses (medium confidence, vote 2–1)
MLEB Contractual domain (nDCG@10, Table 2; 353 queries = Contractual Clause Retrieval 90 + License TL;DR 65 +
Consumer Contracts QA 198; CUAD, ContractNLI and MAUD are not in MLEB):
Voyage 3 Large 86.05 · Voyage 3.5 85.92 · Kanon 2 84.67 · **Qwen3-Embedding-4B 84.19** (beats Qwen3-8B 82.88) ·
voyage-law-2 81.65 · text-embedding-3-large 79.70 · Gemini Embedding 77.88 · Qwen3-0.6B 76.61 · Jina v4 76.44 ·
Arctic Embed L v2 76.41 · EmbeddingGemma 76.07 · text-embedding-3-small 74.24 · BGE-M3 73.04 · E5-large-instruct 65.62.
Implications: Qwen3-Embedding-4B is the strongest local option on this evidence; an endpoint at
text-embedding-3-large level sits ~6 points below the leader. NVIDIA NIM embedders were not evaluated; Cohere was
excluded by its terms. Caveats: benchmark built and sponsored by Isaacus (whose Kanon 2 ranks first overall);
~1-point gaps are noise at 353 queries; October 2025; no BM25 baseline, so it cannot say whether dense beats lexical
on contracts; a claim about MLEB's *overall* leaderboard was refuted 0–3, so only the Contractual column is usable.
Source: arXiv 2510.19365.

### 2. Tuned BM25 wins top-rank precision; dense wins deep recall (medium, 3–0)
LLeQA zero-shot (1,868 French questions over 27,942 Belgian statute articles; 195-question test split; BM25
k1 = 2.5, b = 0.2): BM25 RP 0.163 / R@10 0.367 / R@500 0.672; BGE-M3 dense RP 0.090 / R@10 0.325 / R@500 0.734;
mE5-large RP 0.074 / R@10 0.194. BM25 also beat monoBERT, DPR, SPLADE and ColBERT on RP and R@10. Fit with our gap:
lexical is near-perfect when vocabulary matches; dense adds recall deeper in the list, where paraphrased clauses sit.
Caveats: French statutes, not contracts; BM25 parameters may be tuned in-domain; no 2025 embedders; no significance
test. Source: aclanthology.org/2025.coling-main.290.

### 3. Zero-shot fusion almost always helps; fusion after fine-tuning does not (medium, 3–0)
LLeQA dev, zero-shot: 72 of 88 hybrid configurations (82 %) beat the systems they combine; 55 of 56 that include BM25
improve. Test: BM25 + SPLADE (z-score fusion) R@500 0.672 → 0.755; BM25 + DPR + ColBERT R@10 0.407 vs 0.367 for BM25
alone (+4 points); on R-precision BM25 alone (0.163) still beats every fusion (0.092–0.139). After in-domain
fine-tuning (1.5K questions) ~70 % of combinations underperform their best constituent and the maximum two-system
R@10 gain falls from 7.1 % to 1.4 %. Because our harness is training-free, the zero-shot result applies. Caveats: the
fused neural models were weak CamemBERT retrievers; BGE-M3 itself was never fused; a verifier cites a 2026 BRIGHT
study (arXiv 2604.03676, not verified here) where BM25 fusion hurt already-strong dense retrievers — gains may shrink
with a strong dense model, so measure. Source: aclanthology.org/2025.coling-main.290.

### 4. Listwise reasoning rerankers lead BRIGHT and are faster than pointwise reasoning (medium, 3–0)
BRIGHT average nDCG@10, reranking the ReasonIR-8B top-100: ReasonRank-32B 38.03 · ReasonRank-7B 35.74 · Rank-K-32B
32.61 · Rearank-7B 31.75 · Rank-R1-14B 29.66 · Rank1-32B 28.34 · RankZephyr-7B 22.64 · no reranking 30.59.
ReasonRank-7B (window 20, step 10) is 2–2.7× faster than pointwise Rank1-7B on 4×A800; absolute seconds per query
appear only in figures; no paper gives latency for 100–1,000 candidates. Rank1 mitigations: vLLM and int4 AWQ (32B
65.5 → 19.3 GB with NevIR 70.1 → 69.9). Caveats: author-reported; StackExchange-style text; trained rerankers —
zero-shot listwise reranking with GPT-OSS is not measured anywhere in this evidence. Sources: arXiv 2508.07050,
2502.18418.

### 5. Chain-of-thought inside a pointwise reranker does not help (medium, 3–0 / 3–0 / 2–1)
Controlled comparison (Qwen2.5 base, ~386K MS MARCO examples, with vs without DeepSeek-R1 reasoning chains):
StandardRR beats ReasonRR on BRIGHT by 3.4 / 1.0 / 3.2 nDCG@10 at 1.5B / 3B / 7B (7B: 31.0 vs 27.8) and on TREC DL by
5.3 / 3.7 / 5.0; switching reasoning off at inference also helps at 7B (30.8 vs 27.8). A 2026 revision adds 14B where
the gap widens to +5.2. Counter-evidence for listwise: removing reasoning from ReasonRank-7B drops BRIGHT 35.74 →
32.96. Implication for GPT-OSS: for a pointwise relevance pass, low `reasoning_effort` may be better as well as
cheaper; spend reasoning on listwise windows. Sources: arXiv 2505.16886, 2508.07050.

### 6. Retrieval handles negation poorly; only LLM rerankers do reasonably (high, 2–1 / 3–0 / 3–0)
NevIR pairwise accuracy (random 25 %, human 100 %): listwise RankGPT with o3-mini 77.3, GPT-4o 70.1, GPT-4o-mini
64.1; Rank1 7B/14B/32B 65.1 / 67.5 / 70.1; jina-reranker-v2-base-multilingual (278M) 65.2 beats MonoT5-3B 50.6; most
other cross-encoders near random (RankLLaMA-7B 31.6, bge-reranker-base 32.2); best bi-encoder GritLM-7B 39.0; best
late-interaction ColBERTv1 19.8; small open listwise models weak (Mistral-7B 46.3, Qwen2-7B 36.9, Llama-3.2-3B 25.7).
Fine-tuned cross-encoders reach ~75 %. Caveats: pairwise accuracy is non-standard and does not track nDCG@5;
general-domain text; our models untested; a claim that bi-encoders are at or below random was refuted 1–2, so treat
exact bi-encoder figures cautiously. Sources: arXiv 2502.18418, 2502.13506.

### 7. Version questions need harness-side resolution, not better retrieval (medium, 3–0)
TIDE (644 Bangladeshi customs instruments 1969–2025, 3,050 QA; gemini-embedding-2, k = 40 chunks → ≤ 10 parent
clauses, no temporal reranking). Macro strict accuracy parametric / RAG / gold-context: RAG trails gold context for all
nine models, from 4.42 points (GPT-OSS-120B 30.76 / 52.69 / 57.11) to 12.36 (Gemma-4-31B 32.04 / 47.69 / 60.05); best
GPT-5.2 35.39 / 57.06 / 68.49. With gold context, resolving the version from an implicit date reaches 59.7 %; detecting
that a supplied version does not govern the date only 26.7 %; 29.2 % wrong even with gold context. GPT-OSS-120B is in
our stack; its small RAG gap partly reflects its lower ceiling. Caveats: unreviewed August 2026 preprint; customs
instruments; LLM-judge scoring (κ 0.83–0.86). Source: arXiv 2608.08512.

### 8. Architecture synthesis (low confidence: inference from 1–7, not itself verified)
Ranked recommendations:
1. **Fuse dense with BM25; do not replace it.** Per-query dense scoring fused by RRF or normalized scores, used in
   the first-move deep list and the extract grid's chunk selection. Gain: high on the paraphrase slice, mostly at deep
   recall. Constraint: an ephemeral per-query index is allowed; a cross-query vector cache is effectively a persistent
   index and needs an explicit decision. Cost: embedding every chunk is ~15,000 × 300 ≈ 4.5M tokens per query; cut it
   by embedding only (i) all chunks of the top-N BM25 documents and (ii) all chunks of the contracts named in an
   enumeration question — document-level lexical recall is easier than chunk-level, so most of the benefit survives.
   Model: Qwen3-Embedding-4B locally, or whatever the endpoint serves.
2. **Rerank listwise in the first move.** After the per-clue union and fusion, rerank the fused top-100 listwise
   with the planner model (window 20, step 10) to build the opening observation; keep the 1,000-deep list for
   `page_results`. No pointwise chain-of-thought. Fallback: a cheap local cross-encoder such as
   jina-reranker-v2-base (278M), best among cross-encoders on NevIR (no legal numbers available).
3. **Answer negation and condition questions by reading, not by ranking.** Retrieve the positive clause type per
   contract with the fused retriever, then a per-contract extract grid decides present / absent and the value, and
   records an explicit "not found after reading sections X–Y" for absences; thresholds ("< 30 days") are compared in
   code over extracted values.
4. **Make enumeration retrieval per contract.** Scope retrieval to each named contract and take the top-k of the
   fused ranking per contract, so every one of the 8–12 contracts gets its own candidates.
5. **Resolve versions in code.** Extract a deterministic amendment chain at materialize time (effective date,
   supersedes, amends sections), resolve the governing version in code, then retrieve within that version.
6. **Keep BM25 as the precision anchor and the agent's primary search tool**; add a fused mode rather than a
   separate dense-only tool.

Top five experiments and the metric that decides each:
- **E1 paraphrase-slice recall.** BM25 vs dense vs fused on gold clauses sharing little vocabulary with the question;
  candidate recall@100 / @500 and gold-chunk rank; adopt fusion if paraphrase recall rises and the lexical slice stays
  at 1.0.
- **E2 embedding latency and cost.** Full-corpus vs lexically scoped embedding through the endpoint and on a local
  GPU; seconds per query (a small fraction of 300 s), dollars or GPU-seconds per query, recall lost by scoping.
- **E3 reranker placement.** None vs listwise planner model (low vs high effort) vs pointwise no-CoT vs local
  cross-encoder on the fused top-100; gold-chunk recall@20 and nDCG@10 against seconds per query.
- **E4 negation and condition slice.** Retrieval-only vs positive retrieval + per-contract grid; contract-set
  precision and recall, calls per question.
- **E5 enumeration and version slice.** Global vs per-contract fused top-k; code-resolved vs retrieval-only
  versioning; item recall across named contracts and version-resolution strict accuracy. Track cost per correct
  answer across all five.

Novelty: dense-on-demand triggered by a deterministic recall signal, per-query ephemeral dense re-scoring scoped by
lexical document recall, and clause-type grids over a lexical pre-filter — no surviving claim says whether any has
been published.

## Caveats
- **No surviving evidence** on: embedding API cost, latency and rate limits at ~15k chunks; contract chunking
  (clause-level, heading-aware, contextual prefixes); long-context embedders; hosted rerankers on legal text (the
  LegalBench-RAG "Cohere rerank hurt" claim was refuted 0–3, so there is no evidence either way); query rewriting,
  HyDE and instruction-following retrievers (DIVER and BRIGHT-Pro claims refuted); zero-shot CUAD clause
  classification; Query2doc, RM3 limits, per-query SPLADE latency, doc2query. Recommendations on these are inference.
- **Domain transfer is weak throughout:** MLEB Contractual (353 queries, vendor-built, no BM25 baseline, Oct 2025);
  LLeQA (French statutes, 195-question test split); BRIGHT (StackExchange); NevIR (general text, pairwise metric);
  TIDE (customs instruments, unreviewed).
- **Reranker evidence** comes from trained models and is author-reported; zero-shot listwise reranking with GPT-OSS,
  Nemotron or Gemma is untested, and small open listwise models scored poorly on NevIR.
- **Fusion evidence** comes from weak dense models; a 2026 BRIGHT study (cited by a verifier, not verified) found
  fusion can hurt strong dense retrievers.
- Most results are from 2025; newer embedders and NVIDIA NIM embedders were never evaluated.
- Whether a per-document embedding cache across queries is compatible with "no persistent index" is a project
  decision.

## Open questions
1. On a contract paraphrase slice, how much candidate recall do the embedders we can reach (an endpoint model, or local
   Qwen3-Embedding-4B) gain over BM25, and what is the real per-query latency and cost of ~4.5M tokens vs a
   lexically scoped subset?
2. Does zero-shot listwise reranking with GPT-OSS-120B reproduce ReasonRank-style gains on contract clauses and
   negation within the first move's latency?
3. Does BM25 + dense fusion still help with a strong dense model, and which fusion (RRF vs normalized scores) is robust
   without in-domain tuning?
4. How far do query-side techniques needing no endpoint (legal-synonym expansion, HyDE-style hypothetical clauses from
   small models) close the gap vs dense; has per-query ephemeral dense re-scoring or dense-on-demand been published?

## Claims that did NOT survive verification (do not cite these)
| Claim | Vote | Source |
|---|---|---|
| MLEB overall leaderboard figures (Kanon 2 86.03, Voyage 3 Large 85.71, …, BGE-M3 18th of 21) | 0–3 | arXiv 2510.19365 |
| MLEB's Contractual Clause Retrieval is a direct definition-to-clause paraphrase test (90 queries) | 0–3 | arXiv 2510.19365 |
| Cohere rerank-english-v3.0 on top of text-embedding-3-large decreased LegalBench-RAG quality | 0–3 | arXiv 2408.10343 |
| Dense-only text-embedding-3-large on contract datasets: P@1 6.41, R@64 62.22; MAUD P@1 2.65 % | 1–2 | arXiv 2408.10343 |
| Rank1 roughly doubles BRIGHT nDCG@10 vs classification-head rerankers (27.5 / 28.7 / 29.4 vs 13.9–16.8) | 0–3 | arXiv 2502.18418 |
| Bi-encoders, sparse and late-interaction retrievers at or below random on NevIR (exact figures) | 1–2 | arXiv 2502.13506 |
| DIVER 46.8 nDCG@10 on BRIGHT (31.9 with original queries) | 0–3 | arXiv 2508.07995 |
| LLM query expansion is the largest single lever on BRIGHT (DIVER's 46.8 vs 31.9 gap) | 0–3 | arXiv 2508.07995 |
| BRIGHT-Pro: reasoning-trained retrievers sit 4–14 points above general embedders and far above BM25 (40.3) | 1–2 | arXiv 2605.04018 |
| **Inside an agentic multi-round loop BM25 becomes competitive with dense (40.3 → 51.5 α-nDCG@15)** | **0–3** | arXiv 2605.04018 |

The last row matters for us: the earlier research record (HANDOVER Appendix A.3.1, "BRIGHT-Pro: inside an agentic loop
BM25 rises 40.3 → 51.5") leaned on this claim to justify lexical-only retrieval plus agent reformulation. The
adversarial panel refuted it unanimously; treat that justification as unsupported until re-checked against the paper.

## Sources fetched (23; quality as assessed by the extractor)
Primary: arXiv 2510.19365 (MLEB) · arXiv 2408.10343 (LegalBench-RAG) · aclanthology 2025.coling-main.290 (LLeQA
hybrid study) · arXiv 2508.07050 (ReasonRank) · arXiv 2502.18418 (Rank1) · arXiv 2505.16886 (StandardRR vs ReasonRR) ·
arXiv 2502.13506 (NevIR / negation rerankers) · arXiv 2508.07995 (DIVER) · arXiv 2605.04018 (BRIGHT-Pro) ·
arXiv 2608.08512 (TIDE) · arXiv 2604.27421 · Sadeghi & Lin SIGIR-AP 2026 (cs.uwaterloo.ca) · arXiv 2303.07678 ·
arXiv 2601.11238 · arXiv 2607.24223 · arXiv 2109.10739 · arXiv 2405.02732 · OpenAI text-embedding-3-large docs.
Blogs / vendor: ragie.ai LegalBench-RAG evaluation · Voyage voyage-law-2 post · Voyage rerank-2.5 post ·
Anthropic contextual retrieval · oneuptime cross-encoder reranking (2026-01).

Run statistics: 5 angles, 23 sources, 114 claims extracted, 25 verified, 15 confirmed, 10 refuted, 8 findings after
merging, 105 agent calls. Workflow run id `wf_bb3f9191-788`; per-agent returns in that run's `journal.jsonl`.
