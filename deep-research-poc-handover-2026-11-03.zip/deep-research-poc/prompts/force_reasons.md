## max_calls
The tool-call budget ({max_calls} calls) is exhausted
## deadline
The time budget for research is exhausted
## no_tool_calls
You have replied without tool calls twice
## forced
Research is being stopped by the harness
