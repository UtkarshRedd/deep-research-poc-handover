<!-- page 1 -->
# JOINT FILING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| Agreement Date | 2020-07-06 |
| Parties | HPS INVESTMENT PARTNERS, LCC; HPS MEZZANINE PARTNERS II, LLC; HPS MEZZANINE PARTNERS II OFFSHORE GP, L.P.; MEZZANINE PARTNERS - OFFSHORE INVESTMENT MASTER FUND II, L.P.; MEZZANINE PARTNERS II OFFSHORE LUX S.À R.L; MEZZANINE PARTNERS II OFFSHORE LUX S.À R.L II; HPS MEZZANINE PARTNERS II GP, L.P.; MEZZANINE PARTNERS II, L.P.; MEZZANINE PARTNERS II ONSHORE LUX S.À R.L; MEZZANINE PARTNERS II ONSHORE LUX S.À R.L II |
| Source | CUAD v1 / ATENTOSA_07_06_2020-EX-99.1-JOINT FILING AGREEMENT |

Exhibit 99.1

JOINT FILING AGREEMENT

Pursuant and subject to Rule 13d-1(k)(1) promulgated under the Securities Exchange Act of 1934, as
amended, the undersigned hereby agree to the joint filing of the Statement on Schedule 13D to which
this Joint Filing Agreement is attached, and any amendments thereto may be filed without the
necessity of filing additional joint filing agreements. This Joint Filing Agreement may be executed
in any number of counterparts, each of which shall be deemed an original, but all of which shall
constitute one and the same instrument.

The execution and filing of this agreement shall not be construed as an admission that the
below-named parties are a group or have acted as a group.

Dated: July 6, 2020

HPS INVESTMENT PARTNERS, LLC /s/ John Madden Name: John Madden Title: Authorized Signatory HPS
MEZZANINE PARTNERS II, LLC By: HPS Investment Partners, LLC, its sole member /s/ John Madden Name:
John Madden Title: Authorized Signatory

[Signature Page to Joint Filing Agreement]
<!-- page 2 -->
HPS MEZZANINE PARTNERS II OFFSHORE GP, L.P. By: HPS Partners Holdings II, LLC, its general partner
/s/ John Madden Name: John Madden Title: Authorized Signatory MEZZANINE PARTNERS - OFFSHORE
INVESTMENT MASTER FUND II, L.P. By: HPS Mezzanine Partners II, LLC, its investment manager By: HPS
Investment Partners, LLC, its sole member /s/ John Madden Name: John Madden Title: Authorized
Signatory MEZZANINE PARTNERS II OFFSHORE LUX S.À R.L /s/ John Madden Name: John Madden Title:
Authorized Signatory MEZZANINE PARTNERS II OFFSHORE LUX S.À R.L II /s/ John Madden Name: John Madden
Title: Authorized Signatory

[Signature Page to Joint Filing Agreement]
<!-- page 3 -->
HPS MEZZANINE PARTNERS II GP, L.P. By: HPS Partners Holdings II, LLC, its general partner /s/ John
Madden Name: John Madden Title: Authorized Signatory MEZZANINE PARTNERS II, L.P. By: HPS Mezzanine
Partners II Offshore GP, L.P., its general partner By: HPS Partners Holdings II, LLC, its general
partner /s/ John Madden Name: John Madden Title: Authorized Signatory MEZZANINE PARTNERS II ONSHORE
LUX S.À R.L /s/ John Madden Name: John Madden Title: Authorized Signatory MEZZANINE PARTNERS II
ONSHORE LUX S.À R.L II /s/ John Madden Name: John Madden Title: Authorized Signatory

[Signature Page to Joint Filing Agreement]
