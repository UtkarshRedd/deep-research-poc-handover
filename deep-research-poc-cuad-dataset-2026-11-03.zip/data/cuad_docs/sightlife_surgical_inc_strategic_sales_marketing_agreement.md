<!-- page 1 -->
# STRATEGIC SALES & MARKETING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Marketing Agreement |
| Agreement Date | 2017-04-28 |
| Parties | SightLife Surgical, Inc. (“Surgical”); Imprimis Pharmaceuticals, Inc. (“Imprimis”) |
| Source | CUAD v1 / SightLife Surgical, Inc. - STRATEGIC SALES _ MARKETING AGREEMENT |

EXHIBIT 10.1 STRATEGIC SALES & MARKETING AGREEMENT THIS STRATEGIC SALES & MARKETING AGREEMENT (the
"Agreement") is effective as of the last date provided for on the signature page and is entered into
by and between SightLife Surgical, Inc., a Delaware corporation, having its principal place of
business at 1200 6th Ave, Ste. 300, Seattle, WA 98101 ("Surgical") and Imprimis Pharmaceuticals,
Inc., a Delaware corporation, and its subsidiaries, having its principal place of business at 12264
El Camino Real, Suite 350, San Diego, CA 92130 ("Imprimis"). WHEREAS, Imprimis and/or its subsidiary
companies are licensed and accredited pharmacies and/or outsourcing facilities; WHEREAS, Surgical is
a cornea-focused organization that provides comprehensive services to support ophthalmic surgeons;
and WHEREAS, Imprimis wishes to engage Surgical and its employees to provide contract sales services
under the terms and conditions as set forth below. NOW THEREFORE, in consideration of the mutual
promises contained herein and other good and valuable consideration, the receipt and sufficiency of
which are hereby acknowledged, Surgical and Imprimis agree, intending to be legally bound, as
follows: 1. Sales Representation Services. 1.1. Surgical will provide sales representation services
to Imprimis during the Term of this Agreement (Surgical and its sales representatives may be
referred to collectively hereinafter as Surgical). The sales representation services ("Services")
are set forth in the Statement of Work ("SOW") that is attached hereto as Appendix A and made a part
hereof, as it may be amended from time to time by the parties hereto. 1.2. Surgical represents and
warrants to Imprimis that: (a) Surgical has the required skill, experience and qualifications to
perform the Services, shall perform the Services in a professional and workmanlike manner in
accordance with generally recognized industry standards for similar services and shall devote
sufficient resources to ensure that the Services are performed in a timely and reliable manner; and
(b) Surgical shall perform the Services in compliance with all applicable federal, state and local
laws and regulations. 2. Effective Date; Term and Termination. 2.1. This Agreement shall be
effective on the later of the dates that it is executed by Imprimis and Surgical (the "Effective
Date") and shall terminate pursuant to the terms of the SOW (the "Term"). 2.2. Surgical shall
immediately cease to provide any further Services under this Agreement and/or any applicable SOW
upon receipt of notice from Imprimis that Imprimis is terminating this Agreement and/or such SOW.
Upon termination of this Agreement and/or such SOW, Surgical shall be entitled to payment for
Services completed prior to such termination. Thereafter, Imprimis shall owe Surgical no further
amounts or obligations in law or equity. Page 1 of 11
<!-- page 2 -->
3. Sales Commissions. In consideration of the Services provided hereunder, Imprimis shall pay
Surgical sales commissions ("Sales Commissions") as set forth in the SOW. Surgical shall be
responsible for all expenses incurred in association with performance of the Services. 4. Sales
Commission Payment. Within sixty (60) days after the end of each calendar quarter during the Term,
Imprimis shall deliver to Surgical a report setting forth for such calendar quarter the calculation
of the applicable Sales Commission due under this Agreement for the sale of the Product (as defined
in the SOW). Imprimis shall remit the total Sales Commission payments due for the sale of Product
during such calendar quarter at the time such report is made. 5. Ownership of Intellectual Property
/ Inventions / Work Product. Surgical agrees that it shall disclose promptly to Imprimis all
inventions, ideas, concepts, and discoveries, including but not limited to processes, methods,
formulas, biological materials, specimens, chemical compounds, formulations, software, data,
techniques, products, applications, systems, procedures, technical information, drawings, reports
and designs as well as improvements and modifications thereof and know-how thereto (whether or not
protectable by copyright, patent, trademark, trade secret or any other proprietary rights), that it
makes, conceives of, discovers or develops as a result of the receipt of Confidential Information
(as defined in the Confidentiality Agreement referenced in Section 6 below) ("Work Product").
Surgical agrees that all Work Product shall be the sole and exclusive property of Imprimis. 5.1.
Surgical represents and warrants that all Work Product is and shall be Surgical's original work
(except for material in the public domain or provided by Imprimis) and, to the best of Surgical's
knowledge, does not and will not violate or infringe upon the intellectual property right or any
other right whatsoever of any person, firm, corporation or other entity. 5.2. Surgical agrees that
any Work Product, if subject to copyright, shall be considered a "work made for hire" within the
meaning of the Copyright Act of 1976, as amended (the "Act"). If and to the extent that any Work
Product is found as a matter of law not to be a "work made for hire" within the meaning of the Act,
Surgical agrees to assign, and by this Agreement and Surgical's signature below, Surgical hereby
does assign to Imprimis all right, title and interest in and to Work Product, and all copies
thereof, and the copyright, patent, trademark, trade secret and all other proprietary rights in Work
Product. 5.3. Surgical agrees that, at the request of Imprimis, Surgical will execute all such
documents and perform all such acts as Imprimis or its duly authorized agents may reasonably
require: (a) to effect the assignment of Work Product as agreed above; (b) to apply for, obtain, and
vest in the name of Imprimis alone patents, patent applications, copyrights or other intellectual
property rights in any country and (c) at Imprimis' expense, to assist Imprimis in prosecuting any
such rights. Page 2 of 11
<!-- page 3 -->
5.4. Surgical agrees that promptly upon termination of this Agreement, Surgical shall deliver to
Imprimis all Work Product, either completed or uncompleted, and any documents, reports and other
materials which are in Surgical's possession in connection with the performance of Services under
this Agreement. 6. Confidentiality. Concurrently with this Agreement, the parties shall enter into a
confidentiality agreement (the "Confidentiality Agreement"), a copy of which has been attached
hereto as Exhibit A, which shall govern the confidentiality of any Confidential Information (as
defined in the Confidentiality Agreement) disclosed between the parties. In addition, Surgical
shall, at Imprimis' request and in Imprimis' sole discretion, if given access to patient health
information, execute a "Business Associate Agreements" as required by the U.S. Health Insurance
Portability and Accountability Act of 1996 ("HIPAA"). 7. Conflicts of Interest. 7.1. Surgical
represents and warrants that Surgical is not under any pre-existing obligation in conflict or in any
way inconsistent with the provisions of this Agreement. Surgical represents and warrants that
Surgical's performance of all the terms of this Agreement will not (a) breach any agreement to keep
in confidence proprietary information acquired by Surgical in confidence or in trust prior to
commencement of this Agreement, or (b) breach any other agreement with any third party. Surgical
warrants that Surgical has the right to disclose and/or or use all ideas, processes, techniques and
other information, if any, which Surgical has gained from third parties, and which Surgical
discloses to Imprimis or uses in the course of performance of this Agreement, without liability to
such third parties. Surgical represents and warrants that Surgical has not granted and will not
grant any rights or licenses to any intellectual property or technology that would conflict with
Surgical's obligations under this Agreement. Surgical will not knowingly infringe upon any
copyright, patent, trade secret or other property right of any former client, employer or third
party in the performance of the Services. 7.2. Subject to the SOW, Imprimis acknowledges that
Surgical may perform services for other clients. Surgical represents and warrants that as of the
Effective Date, there is no conflict of interest which would prevent Surgical from performing the
Services for Imprimis, and that Surgical is not under any legal or contractual relationship with any
third party which is inconsistent with any provision of this Agreement. During the Term of this
Agreement, Surgical will not to enter into any other agreement or arrangement that will directly or
indirectly compete with the Services to be rendered hereunder, as such agreement shall be considered
a breach of this Agreement. In the event that Surgical becomes aware of any potential or actual
conflicts of interest regarding the provision of the Services, Surgical shall promptly disclose the
fact and nature of such conflict to Imprimis. 8. Debarred Person. Surgical hereby certifies that
Surgical is not currently nor has been debarred by the U.S. Food and Drug Administration pursuant to
21 USC §335a(a) or (b), or under any similar law or regulation by the European Medicines Evaluation
Agency or any other national or regulatory authority or agency. If Surgical becomes aware that
Surgical is or becomes the subject of any debarment or similar proceedings in any jurisdiction, then
Surgical shall promptly notify Imprimis. Page 3 of 11
<!-- page 4 -->
9. Compliance with Laws and Quality Standards. As further outlined in the SOW, Surgical and its
employees shall conduct all activities under this Agreement or relating to the Product in accordance
with all applicable laws and regulations and all quality standards, protocols and systems
established by Imprimis from time to time therefor. 10. Tax Indemnity. Surgical agrees to indemnify
and hold harmless Imprimis from any and all claims or demands under the Internal Revenue Code of
1986, as amended, or any state or local tax law or ordinance in respect of any failure of Imprimis
to withhold income tax, FICA or any other tax from the Sales Commissions paid to Surgical, including
any interest or penalties relating thereto and any costs or expenses incurred in defending such
claims. 11. Indemnification and Insurance. 11.1. Each party shall indemnify and hold harmless the
other party, and its directors, officers, employees and agents, from and against all losses,
liabilities, damages and expenses, including reasonable attorneys' fees and costs (collectively,
"Liabilities"), resulting from any claims, demands, actions or other proceedings by any third party
to the extent resulting from the breach of any representation, warranty or covenant by the breaching
party under this Agreement. 11.2. Insurance. Each party shall maintain insurance, including
comprehensive or commercial general liability and products liability insurance (contractual
liability included), with respect to its activities under this Agreement in such amounts and with
such limits as reasonable and customary in the industry, but with limits not less than the
following: (a) each occurrence, one million dollars ($1,000,000); (b) products/completed operations
aggregate, five million dollars ($5,000,000); (c) personal and advertising injury, one million
dollars ($1,000,000); and (d) general aggregate (commercial form only), five million dollars
($5,000,000). Each Party shall maintain such insurance for so long as it continues its activities
under this Agreement, and thereafter for so long as it customarily maintains insurance for itself
covering similar activities. 12. Assignment. Surgical shall not assign this Agreement or any of its
rights or privileges without the prior written consent of Imprimis, which consent Imprimis may grant
or withhold in its sole discretion. Imprimis may assign this Agreement to any party that agrees to
assume this Agreement and all of Imprimis' duties and obligations thereunder. 13. Waiver. No waiver
of this Agreement or any of its provisions shall be binding upon a party unless in writing and
signed by each party. The waiver by either party of a breach or violation of any provision of this
Agreement shall not constitute or be construed as a waiver of any subsequent breach or violation of
that provision or as a waiver of any breach or violation of any other provision. 14. Severability.
If any provision of this Agreement is held by a court of competent jurisdiction to be invalid,
illegal or unenforceable, the remaining provisions of this Agreement shall be unimpaired, and the
invalid, illegal or unenforceable provision shall be replaced by a mutually acceptable provision,
which, being valid, legal and enforceable, comes closest to the intention of the parties underlying
the invalid, illegal or unenforceable provision. Page 4 of 11
<!-- page 5 -->
15. Survival. The provisions of Sections 2, 5, 6, 9-20 and any other obligation under this Agreement
which is to survive or be performed after termination of this Agreement, regardless of the cause
therefor, shall survive any termination or expiration of this Agreement. 16. Notices. Any notice or
other communication required or permitted to be made or given under this Agreement to either party
shall be in writing and shall be sufficiently given if (i) hand delivered, (ii) sent by overnight
guaranteed delivery service, such as Federal Express or UPS; or (iii) sent by facsimile transmission
or electronic mail during addressee's normal business hours, with a duplicate copy sent by overnight
delivery or certified or registered mail (except for any notice of termination which must be sent by
method (i) or (ii)), addressed as follows: If to Surgical: SightLife Surgical, Inc. 1200 6t h Ave.,
Ste. 300 Seattle, WA 98101 Attn: Monty Montoya, CEO E-mail: monty.montoya@sightlife.org If to
Imprimis: Imprimis Pharmaceuticals, Inc. 12264 El Camino Real, Suite 350 San Diego, CA 92130 Attn:
Mark L. Baum, CEO Email: mark@imprimispharma.com or to such other address or addressee as either
party may from time to time designate to the other by written notice. Any such notice or other
communication shall be deemed to be given as of the date it is received by the addressee. 17.
Publicity. Neither party nor its Affiliates shall make any public announcements concerning matters
regarding this Agreement or the negotiation thereof without the prior written consent of the other
party unless such disclosure is required by law, in which case the announcing party shall provide
the other party with reasonable notice of such disclosure sufficient to make written comments
concerning such disclosure. For the avoidance of doubt, mutually agreed upon marketing plans shall
be deemed to have received the requisite consent pursuant to the preceding sentence. 18. Advice of
Counsel. Each party acknowledges that, in executing this Agreement, such party has had the
opportunity to seek the advice of independent legal counsel, and has read and understood all of the
terms and provisions of this Agreement. This Agreement shall not be construed against any party by
reason of the drafting or preparation hereof. 19. Governing Law. This Agreement shall be governed by
and construed in accordance with the laws of the State of California, excluding the choice of law
rules, and the parties hereby agree to submit to the jurisdiction and venue of the State and Federal
courts of the State of California, and agree that the State and Federal courts of the State of
California shall be the exclusive forum for the resolution of all disputes related to or arising out
of this Agreement. Page 5 of 11
<!-- page 6 -->
20. Entire Agreement; Amendments; Counterparts. This Agreement, including Appendix A, and the
Confidentiality Agreement represents the entire agreement between the parties in relation to the
subject matter contained herein and supersedes all previous other agreements and representations,
whether oral or written. This Agreement may be modified only if such modification is in writing and
signed by a duly authorized representative of each party. This Agreement may be executed in separate
counterparts, each of which shall be deemed an original, but all of which together shall constitute
one and the same instrument. *****SIGNATURE PAGE FOLLOWS*** Page 6 of 11
<!-- page 7 -->
SIGNATURE PAGE IN WITNESS WHEREOF, the parties hereto have caused this Strategic Sales & Marketing
Agreement to be duly executed in duplicate original on the dates set forth below. IMPRIMIS
PHARMACEUTICALS, INC. SIGHTLIFE SURGICAL, INC. /s/ Mark L. Baum /s/ Monty Montya By: Mark L. Baum
By: Monty Montoya Its: Chief Executive Officer Its: Its: President & Chief Executive Officer Date:
4/26/2017 Date: 4/28/2017 Page 7 of 11
<!-- page 8 -->
APPENDIX A Statement of Work under Strategic Sales & Marketing Agreement by and between SightLife
Surgical, Inc. and Imprimis Pharmaceuticals, Inc. Services: Surgical will provide "Services" for
Imprimis and its subsidiaries which shall include: 1. In coordination with Imprimis, calling on
potential clients including, but not limited to, doctors, practitioners, practice groups, surgical
centers, hospitals and other prescribers (collectively "Clients") and assisting in the promotion,
marketing and generation of inbound sales and prescription orders for the Product in the Territory.
2. Opening new Client accounts, servicing existing Client accounts, promoting products, facilitating
sales orders and handling customer services for Clients in the Territory, including interfacing with
the Imprimis customer service team and the Imprimis commercial sales team on a regular basis. 3.
Providing a dedicated sales staff of four (4) Surgical employees (the "Sales Team") in the provision
of the Services. The Sales Team shall have specific and sufficient related ophthalmic experience and
relationships with potential purchasers of the Product to adequately provide the Services. Product
"Product" shall mean Imprimis' autologous serum tears formulation. Territory "Territory" shall mean
the United States of America. Exclusivity: Surgical shall not promote, market or sell any products
for any third party during the Term, which directly or indirectly compete with the Product. Imprimis
Support, Training & Marketing: Imprimis has provided marketing materials and product information to
Surgical and the Sales Team which they have deemed adequate in order to allow them to understand the
Product and perform the Services. Surgical's Chief Executive Officer and Imprimis' Chief Commercial
Officer shall initially meet, and continue to meet on a regular basis, to transition, train and
manage the Sales Team in order to allow them to integrate into the existing Imprimis commercial
sales and marketing plan and adequately perform the Services during the Term. Page 8 of 11
<!-- page 9 -->
The Sales Team shall use only such marketing and other materials for the Product in the Territory as
are expressly approved in writing in advance by Imprimis, are consistent in all respects with the
external marketing of such Product by Imprimis, include all warnings and instructions applicable for
the proper use of the Product, comply with all applicable laws and regulations in the Territory, and
do not contain any claims regarding a Product or its performance that the Sales Team does not
reasonably demonstrate are supported by such Product or its performance. The Sales Team has adequate
experience and is knowledgeable in applicable state and federal laws and FDA regulations related to
the sales and marketing of the Product in the Territory, including, but not limited to: Stark Law;
Anti-Kickback Statute; Food, Drug and Cosmetic Act (Sections 503A and 503B); and Drug Quality and
Security Act. The Sales Team shall have the right to use copies of marketing materials provided by
Imprimis to the Sales Team hereunder to the extent reasonably necessary to perform its obligations
under this Agreement and subject to the terms and conditions of this Agreement. If Imprimis
reasonably believes that any marketing materials or strategies used by the Sales Team for the
Product in the Territory fail to fully comply with the terms and conditions of this Agreement or any
applicable law, Imprimis shall give written notice thereof and the Sales Team immediately shall
cease to use such non-compliant materials. The Sales Team shall not make any warranty or claim,
express or implied, relating to any Product other than those contained in any marketing materials
provided by Imprimis to the Sales Team or otherwise expressly authorized in writing by Imprimis.
Compensation: 1. Sales Commissions. During the Term of the Agreement and subject to the terms and
conditions of the Agreement, Imprimis shall pay to Surgical Sales Commissions equal to ten percent
(10%) of the Net Sales for Product. "Net Sales" shall mean the gross sales price of such Product in
the Territory invoiced by Imprimis and its affiliates to customers who are not affiliates less: (a)
credits, allowances, discounts and rebates to, and chargebacks from the account of, such customers;
(b) freight and insurance costs in transporting such Product; (c) cash, quantity and trade
discounts, rebates and other price reductions for such Product; (d) sales, use, value-added and
other direct taxes; and (e) an allowance for uncollectible or bad debts determined in accordance
with accounting principles generally accepted in the United States of America ("GAAP"). 2. Milestone
Payments; Stock Issuances. a. Initial Milestone Payment. An initial milestone payment of five
thousand (5,000) shares of Imprimis' restricted common stock, par value $0.001 ("Common Stock")
shall become due and issuable to Surgical if Net Sales for Product reaches $2,000,000 prior to
December 31, 2017. b. Periodic Milestone Payments. In addition to the initial milestone payment as
outlined in Section 2(a) above, Imprimis may make four (4) additional milestone payments to Surgical
during the Term as follows: Page 9 of 11
<!-- page 10 -->
i. seven thousand five hundred (7,500) shares of Common Stock if Net Sales for Product reaches
$2,500,000; ii. seven thousand five hundred (7,500) shares of Common Stock if Net Sales for Product
reaches $5,000,000; iii. seven thousand five hundred (7,500) shares of Common Stock if Net Sales for
Product reaches $7,500,000; and iv. seven thousand five hundred (7,500) shares of Common Stock if
Net Sales for Product reaches $10,000,000. c. Insider Trading Policy. If any shares of Common Stock
are issued to Surgical, Surgical (or any related holder of Common Stock) shall be required to
execute and follow Imprimis' standard form insider trading policy. Term & Termination: 1. Term. The
Agreement shall commence on the Effective Date and, unless terminated earlier pursuant to this
Agreement or extended by mutual agreement between the parties, shall continue in effect for thirty
six (36) months following the Effective Date (the "Term"). 2. Termination. Either party shall have
the right to terminate this Agreement at any time for any reason. Expiration or termination of this
Agreement shall not limit any obligations of a party that were incurred prior to such expiration or
termination. Page 10 of 11
<!-- page 11 -->
<!-- page 12 -->
EXHIBIT A Confidentiality Agreement Page 11 of 11
