# Which jurisdiction's law governs the Endorsement Agreement between Teardrop Putter Corp...

*Question:* Which jurisdiction's law governs the Endorsement Agreement between Teardrop Putter Corporation and Consolidated Artists Inc. (dated 1996-01-01)?

## Identify governing law clause

The Endorsement Agreement dated 1996-01-01 between Teardrop Putter Corporation ("TPC") and Consolidated Artists Inc. [uncited] ("Consolidated Artists") contains an express choice-of-law provision. [21ec1cb8e3926ed1 p.1] Section 28, titled "GOVERNING LAW," states that "This Agreement shall be governed by and construed in accordance with the laws of the Commonwealth of Virginia applicable to contracts entered into and wholly to be performed within the Commonwealth of Virginia and, in the event of any litigation arising out of this Agreement, venue shall be the Commonwealth of Virginia". [21ec1cb8e3926ed1 p.6] The agreement designates the Commonwealth of Virginia as the governing jurisdiction. [21ec1cb8e3926ed1 p.6]

## Verification appendix

Claims: 4 · supported: 3 · partially: 0 · dropped: 0 · gaps: 1 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  | no evidence cited |
| s1.2 | s1 | keep | 1.00 | e1→[21ec1cb8e3926ed1 p.1] |  |
| s1.3 | s1 | keep | 1.00 | e2→[21ec1cb8e3926ed1 p.6] |  |
| s1.4 | s1 | keep | 1.00 | e2→[21ec1cb8e3926ed1 p.6] |  |

### Evidence

- e1 [21ec1cb8e3926ed1 p.1 L1-8] keep (1.0): "# Endorsement Agreement
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 1996-01-01 |
| Parties | Teardrop Putter Corporation ("TPC"); Consolidated Artists Inc. ("Consolidated Artists") |"
- e2 [21ec1cb8e3926ed1 p.6 L373-376] keep (1.0): "28. GOVERNING LAW. This Agreement shall be governed by and construed in accordance with the laws of
the Commonwealth of Virginia applicable to contracts entered into and wholly to be performed within
the Commonwealth of Virginia and, in the…"
