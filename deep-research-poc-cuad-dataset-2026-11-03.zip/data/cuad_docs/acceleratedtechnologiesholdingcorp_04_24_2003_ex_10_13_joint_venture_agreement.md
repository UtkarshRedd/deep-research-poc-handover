<!-- page 1 -->
# JOINT VENTURE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture Agreement |
| Agreement Date | 2003-03-01 |
| Parties | Collectible Concepts Group, Inc. ("CCGI"); Pivotal Self Service Tech, Inc. ("PVSS"); (the "Parties" or "Joint Venturers" if referred to collectively, or the "Party" or Joint Venturer" if referred to singularly) |
| Source | CUAD v1 / ACCELERATEDTECHNOLOGIESHOLDINGCORP_04_24_2003-EX-10.13-JOINT VENTURE AGREEMENT |

EXHIBIT 10.13

JOINT VENTURE AGREEMENT

Collectible Concepts Group, Inc. ("CCGI") and Pivotal Self Service Tech, Inc. ("PVSS"), (the
"Parties" or "Joint Venturers" if referred to collectively, or the "Party" or Joint Venturer" if
referred to singularly), by this Agreement associate themselves as business associates, and not as
partners, in the formation of a joint venture (the "Joint Venture"), for the purpose of engaging
generally in the business provided for by terms and provisions of this Agreement.

1. Name of the Joint Venture. The name of the Joint Venture will be MightyCell Batteries, and may
sometimes be referred to as "MightyCell" or the "Joint Venture" in this Agreement. The principal
office and place of business shall be located in 1600 Lower State Road, Doylestown, PA 18901.

2. Scope of the Joint Venture Business. The Joint Venture is formed for the purpose of engaging
generally in the business of marketing batteries and related products, (the "Products") that include
the display of licensed logos, images, brand names and other labels that differentiate them from the
branding (the "PVSS Products") under which PVSS and/or its affiliates, sell to retailers and
distributors in the normal course of their business. Without in any way limiting the generality of
the foregoing, the business of the Joint Venture shall include:

(a) The purchase of Products for resale; (b) The acquisition of a license(s) permitting the use of
selected images in the Products; (c) The sale and distribution of the Products to retailers and
distributors; and, (d) The transaction of such other and further business as is necessary,
advisable, or incidental to the business of the Joint Venture. (e) Develop a global marketing
program for licensed Products

Exhibit A attached hereto, describes by way of example but not limitation the responsibilities of
the Joint Venturers

3. Capital Contributions. Except as agreed upon by mutual consent, the Joint Venturers shall not be
required to make any capital contribution to the Joint Venture.

4. Offices of the Joint Venture. The principal place of business of the Joint Venture shall be at
1600 Lower State Road, in the City of Doylestown, Bucks County, Pennsylvania, but may maintain such
other offices as the Joint Venturers may deem advisable at any other place or places within or
without the Commonwealth of Pennsylvania.

5. Powers and Authority of the Joint Venturers. The Joint Venturers shall have full and complete
charge of all affairs of the Joint Venture. The Joint Venturers recognize that both of the Joint
Venturers are and will continue to be engaged in the conduct of their respective businesses for
their own account. Neither Joint Venturer shall be entitled to compensation for services rendered to
the Joint Venture as such, but each Joint Venturer shall be reimbursed for all direct expenses,
including travel, office, and all other out-of-pocket expenses incurred in the operation of the
affairs of the Joint Venture and the promotion of its businesses.

It is agreed that either Joint Venturer shall, except as provided for below, have authority to
execute instruments of any character relating to the affairs of the Joint Venture; provided, that
without the written consent or approval of both of the Joint Venturers: (i) the Joint Venture shall
incur no liability of any sort, nor any indebtedness for borrowed funds; (ii) no assets owned in the
name of the Joint Venture be disposed of; and (iii) no commitment to purchase any item for the Joint
Venture shall be made.

39

6. Division of Income and Losses. All income and credits, and all losses and deductions shall be
owned and shared among the Joint Venturers as follows:

50% to Collectible Concepts Group, Inc.

50% to Pivotal Self Service Tech, Inc.

Depreciation and all other charges and expenses, which are not expressly apportioned by this
Agreement, shall be apportioned in accordance with generally accepted accounting principles,
consistently applied.

7. Accounting Provisions. The Joint Venturers shall maintain adequate books and records to be kept
of all the Joint Venture activities and affairs conducted pursuant to the terms of this Agreement.
All direct costs and expenses, which shall include any insurance costs in connection with the
distribution of the Products or operations of the Joint Venture, or if the business of the Joint
Venture requires additional office facilities than those now presently maintained by each Joint
Venturer, such item shall be
<!-- page 2 -->
paid by the Joint Venture. The fiscal year of the Joint Venture shall be the calendar year, and
shall use the cash basis of accounting. If requested by a Joint Venturer, the Joint Venture books
and records shall be audited as of the close of each year by an independent accountant acceptable to
both Joint Venturers. All books and records of every kind and character, of the Joint Venture, and
other information, shall be kept at the principal office of the Joint Venture, or at such other
place or places as may be agreed upon by the Joint Venturers, and shall be fully available to each
Joint Venturer or his duly authorized representative, all at reasonable times. The books of the
Joint Venture shall represent the complete record and report of business operations, including a
balance sheet and income and expense statements reflecting all receipts and disbursements of the
Joint Venture, and such reports shall be submitted to the Joint Venturers on a regular basis.

8. Term of Joint Venture. The Joint Venture shall commence on the 1st of March, 2003, and shall be
effective until February 28, 2004 unless extended by written agreement of the Joint Venturers not
less than thirty (30) days prior to scheduled termination.

9. Distributions. During the term of the Joint Venture, no interest shall be allowed to any Joint
Venturer upon the amount of his contribution. No Joint Venturer shall withdraw, transfer or have
paid to him in any manner any part of his capital contribution or account, or any other funds or
property of the Joint Venture without the consent of both Joint Venturers; provided, however, there
may be distributed to the Joint Venturers, from time to time, so much of the gross income of the
Joint Venture as shall not be needed to defray the necessary and expected costs and expenses of the
Joint Venture business. Distributions may only be made if after any distribution is made, the Joint
Venture assets are in excess of all liabilities of the Joint Venture. Each distribution shall be
made ratably to the Joint Venturers according to their prorata interest in the Joint Venture as
shown in Section 6.

10. Internal Revenue Code Election. The Joint Venturers agree and declare that this association for
the carrying on of a joint venture business operation does not, and is not intended to create a
partnership, for either legal or United States income tax purposes, each Party recognizing that the
other is willing and able to contribute capital, labor, and services for the operation of a
successful joint venture business. Further, each Party elects under the authority of Section 761(a)
of the Internal Revenue Code of 1986 (the "Code"), as amended and all successor statutes, to be
excluded from the application of all of the provisions of Subchapter K of Chapter 1 of the Subtitle
A of the Code, and the Parties agree that the election out of Subchapter K of Chapter 1 of Subtitle
A of the Code shall, if necessary, be manifested by their execution and filing of all appropriate
documentation. The Parties also declare that they are not making any agreement to undertake any
business other than that set forth in this Agreement; and nothing in this Agreement is to be
construed as a limitation of the powers or rights of either Party to carry on his separate business
for his sole benefit; provided, however, the Parties shall cooperate with each other according to
the terms and spirit of this Agreement in the performance of their joint venture business operation.

11. Procedure on Termination and Liquidation. On any termination of the Joint Venture, its debt
shall be paid or provided for in a manner satisfactory to the Joint Venturers. Then, any unexpended
portion of Joint Venture funds shall be distributed to the Joint Venturers in accordance with their
prorata ownership in the Joint Venture and all other assets of the Joint Venture shall be
distributed as undivided interests to the Joint Venturers ratably according to their prorata
interests in the Joint Venture as set forth in Section 6. If any asset is not capable of being
distributed on an undivided basis, the Parties shall agree on a price for such asset and it shall be
distributed to one Party and a corresponding balance, in cash or property, shall be made of the
Joint Venture assets so that each Party receives his proportionate share of all the Joint Venture
assets.

12. Sale or Purchase of Interest of Joint Venturer Prohibited. No Joint Venturer shall be authorized
or empowered to mortgage, hypothecate, pledge, sell, or transfer, an interest in the Joint Venture,
nor confer on any successor or assignee the right to become a Joint Venturer without the consent of
the other Joint Venturer.

13. Notice. Any notice which a Joint Venturer shall have occasion to give to the other Joint
Venturer shall be deemed sufficient notice for all purposes as to its contents if given in writing,
hand delivered, by fax, or prepaid mail, to the address of such Joint Venturer as set out below his
signature.

14. Construction. The Joint Venturers declare that in entering into this Agreement, they have
contracted with reference to the laws of the Commonwealth of Pennsylvania, and the construction and
interpretation of the terms and provisions of this Agreement shall be interpreted and construed
under the laws of the Commonwealth of Pennsylvania, except in such cases and to such extent as the
laws of another jurisdiction shall necessarily control.

15. Benefit. This Agreement shall be binding on the Joint Venturers and their respective heirs,
successors, executors, administrators, and assigns.

16. Counterparts. This Agreement may be signed in counterparts and shall be deemed one original
instrument.
<!-- page 3 -->
For Collectible Concepts Group, Inc.

By: ____________________________________

Its: ____________________________________

Date: ___________________________________

For Pivotal Self Service Tech, Inc. By: ___________________________________

Its: ____________________________________ Date: __________________________________

EXHIBIT A

GENERAL RESPONSIBILITIES OF THE PARTIES

Collectible Concepts Group will:

1) Obtain any licenses deemed by the Joint Venturers to add value in the marketing of the Products
2) Prepare any artwork necessary for the reproduction of licensed or branded images for the purpose
of manufacturing the Products and / or packaging 3) In concert with PVSS, appoint appropriate sales
agents and / or representatives and distributors to sell the Products into specific retail channels
4) Prepare marketing materials for sales agents', representatives' and distributors' use in
presentations to prospective clients 5) Engage in any support activities required to promote and
sell the Products 6) Provide fulfillment services through affiliates for final distribution of the
Products

Pivotal Self Service Tech, Inc. will:

1) Provide the Products in accordance with the specifications and quantities and time frames
designated by CCGI 2) Provision any additional Products deemed by the Joint Venturers to be salable
through the channels established by CCGI 3) Negotiate such favorable pricing and terms with the
suppliers of the Products so as to assure the viability of the Joint Venture offerings and the
continuity of Product availability to the customers of the Joint Venture 4) Provide alternate
fulfillment and distribution services of the Products as backup to those provided by CCGI

40
