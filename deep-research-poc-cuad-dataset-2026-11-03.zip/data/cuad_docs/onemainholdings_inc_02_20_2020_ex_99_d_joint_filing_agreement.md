<!-- page 1 -->
# JOINT FILING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| Agreement Date | 2020-02-20 |
| Parties | UNIFORM INVESTCO LP; UNIFORM INVESTCO GP LLC; THE VÄRDE FUND VI-A, L.P.; VÄRDE INVESTMENT PARTNERS, L.P.; VÄRDE INVESTMENT PARTNERS (OFFSHORE) MASTER, L.P.; VÄRDE INVESTMENT PARTNERS G.P., LLC; THE VÄRDE SKYWAY MASTER FUND, L.P.;THE VÄRDE SKYWAY FUND G.P., L.P.; THE VÄRDE SKYWAY FUND UGP, LLC; THE VÄRDE FUND XII (MASTER), L.P.; THE VÄRDE FUND XII G.P., L.P.; THE VÄRDE FUND XII UGP, LLC; VÄRDE CREDIT PARTNERS MASTER, L.P. |
| Source | CUAD v1 / ONEMAINHOLDINGS,INC_02_20_2020-EX-99.D-JOINT FILING AGREEMENT |

Exhibit D

JOINT FILING AGREEMENT OneMain Holdings, Inc.

In accordance with Rule 13d-1(k) under the Securities Exchange Act of 1934, as amended, the
undersigned hereby confirm the agreement by and among them to the joint filing on behalf of them of
the Statement on Schedule 13D and any and all further amendments thereto, with respect to the
securities of the above referenced issuer, and that this Agreement be included as an Exhibit to such
filing. This Agreement may be executed in any number of counterparts each of which shall be deemed
to be an original and all of which together shall be deemed to constitute one and the same
Agreement.

IN WITNESS WHEREOF, the undersigned hereby execute this Agreement as of February 20, 2020. UNIFORM
INVESTCO LP

By: Uniform InvestCo GP LLC, its General Partner By: Värde Partners, Inc., its Manager

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

UNIFORM INVESTCO GP LLC

By: Värde Partners, Inc., its Manager

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

THE VÄRDE FUND VI-A, L.P.

By: Värde Investment Partners G.P., LLC, its General Partner By: Värde Investment Partners UGP, LLC,
its General Partner By: Värde Partners, L.P., its Managing Member By: Värde Partners, Inc., its
General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel
<!-- page 2 -->
VÄRDE INVESTMENT PARTNERS, L.P.

By: Värde Investment Partners G.P., LLC, its General Partner By: Värde Investment Partners UGP, LLC,
its General Partner By: Värde Partners, L.P., its Managing Member By: Värde Partners, Inc., its
General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

VÄRDE INVESTMENT PARTNERS (OFFSHORE) MASTER, L.P.

By: Värde Investment Partners G.P., LLC, its General Partner By: Värde Investment Partners UGP, LLC,
its General Partner By: Värde Partners, L.P., its Managing Member By: Värde Partners, Inc., its
General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

VÄRDE INVESTMENT PARTNERS G.P., LLC

By: Värde Investment Partners UGP, LLC, its General Partner By: Värde Partners, L.P., its Managing
Member By: Värde Partners, Inc., its General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

VÄRDE INVESTMENT PARTNERS UGP, LLC

By: Värde Partners, L.P., its Managing Member By: Värde Partners, Inc., its General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel
<!-- page 3 -->
THE VÄRDE SKYWAY MASTER FUND, L.P.

By: The Värde Skyway Fund G.P., LLC, its General Partner By: The Värde Skyway Fund UGP, LLC, its
General Partner By: Värde Partners, L.P., its Managing Member By: Värde Partners, Inc., its General
Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

THE VÄRDE SKYWAY FUND G.P., L.P.

By: The Värde Skyway Fund UGP, LLC, its General Partner By: Värde Partners, L.P., its Managing
Member By: Värde Partners, Inc., its General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

THE VÄRDE SKYWAY FUND UGP, LLC

By: Värde Partners, L.P., its Managing Member By: Värde Partners, Inc., its General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

THE VÄRDE FUND XII (MASTER), L.P.

By: The Värde Fund XII G.P., L.P., its General Partner By: The Värde Fund XII UGP, LLC, its General
Partner By: Värde Partners, L.P., its Managing Member By: Värde Partners, Inc., its General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel
<!-- page 4 -->
THE VÄRDE FUND XII G.P., L.P.

By: The Värde Fund XII UGP, LLC, its General Partner By: Värde Partners, L.P., its Managing Member
By: Värde Partners, Inc., its General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

THE VÄRDE FUND XII UGP, LLC

By: Värde Partners, L.P., its Managing Member By: Värde Partners, Inc., its General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

VÄRDE CREDIT PARTNERS MASTER, L.P.

By: Värde Credit Partners G.P., LLC, its General Partner By: Värde Credit Partners UGP, LLC, its
General Partner By: Värde Partners, L.P., its Managing Member By: Värde Partners, Inc., its General
Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

VÄRDE CREDIT PARTNERS G.P., LLC

By: Värde Credit Partners UGP, LLC, its General Partner By: Värde Partners, L.P., its Managing
Member By: Värde Partners, Inc., its General Partner
<!-- page 5 -->
By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

VÄRDE CREDIT PARTNERS UGP, LLC

By: Värde Partners, L.P., its Managing Member By: Värde Partners, Inc., its General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

VÄRDE SFLT, L.P.

By: The Värde Specialty Finance Fund G.P., L.P., its General Partner By: The Värde Specialty Finance
Fund U.G.P., LLC, its General Partner By: Värde Partners, L.P., its Managing Member By: Värde
Partners, Inc., its General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

THE VÄRDE SPECIALTY FINANCE FUND G.P., L.P.

By: The Värde Specialty Finance Fund U.G.P., LLC, its General Partner By: Värde Partners, L.P., its
Managing Member By: Värde Partners, Inc., its General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

THE VÄRDE SPECIALTY FINANCE FUND U.G.P., LLC

By: Värde Partners, L.P., its Managing Member By: Värde Partners, Inc., its General Partner
<!-- page 6 -->
By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

VÄRDE PARTNERS, L.P.

By: Värde Partners, Inc., its General Partner

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

VÄRDE PARTNERS, INC.

By: /s/ David A. Marple Name: David A. Marple Title: General Counsel

GEORGE G. HICKS

By: /s/ George G. Hicks

ILFRYN CARSTAIRS

By: /s/ Ilfryn Carstairs
