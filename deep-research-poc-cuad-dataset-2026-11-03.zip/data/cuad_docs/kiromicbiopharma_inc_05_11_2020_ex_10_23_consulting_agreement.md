<!-- page 1 -->
# CONSULTING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Consulting Agreement |
| Agreement Date | 2018-07-20 |
| Parties | Kriomic, Inc ("Company"); Gianluca Rotino ("Consultant") |
| Source | CUAD v1 / KIROMICBIOPHARMA,INC_05_11_2020-EX-10.23-CONSULTING AGREEMENT |

Exhibit 10.23 Corporate Address Fannin South Professional Building, Suite 140 7707 Fannin Street
Houston, Texas 77054 t: 832.968.4888

CONSULTING AGREEMENT

July 20, 2018

Gianluca Rotino

Dear Gianluca:

Kiromic, Inc, a Delaware corporation (the "Company"), is pleased to this offer to this Consulting
Agreement (this "Agreement") to retain Gianluca Rotino ("Consultant") to perform certain consulting
activities as described below on the following terms:

1. Services and Compensation. Consultant agrees to act as a consultant to Company with respect to
such matters and projects as are mutually agreed from time to time by and between Consultant and
Company, and perform the services described on Exhibit A hereto (collectively, "Services").

Company agrees to pay Consultant the compensation set forth on Exhibit A hereto for the performance
of the Services.

2. Confidentiality. "Confidential Information" means any proprietary information technical data,
trade secrets or know-how, including, but not limited to, research and product plans, products,
services, markets, developments, inventions, processes, formulas, technology, marketing, finances or
other business information disclosed to Consultant by Company either directly or indirectly in
writing, orally or otherwise. Confidential Information also includes all Inventions (as defined
below) and any other information or materials generated in connection with the Services.

Consultant shall not, during or subsequent to the term of this Agreement, use any Confidential
Information for any purpose whatsoever other than the performance of the Services on behalf of
Company, or disclose Confidential Information to any third party. Consultant agrees that
Confidential Information shall remain the sole property of Company. Consultant further agrees to
take all reasonable precautions to prevent any unauthorized disclosure or use of Confidential
Information. Notwithstanding the above, Consultant's obligation under this Section 2(b) relating to
Confidential Information shall not apply to information which (i) is known to Consultant at the time
of disclosure to Consultant by Company as evidenced by written records of Consultant, (ii) has
become publicly known and made generally available through no wrongful act of Consultant, or (iii)
has been rightfully received by Consultant from a third party authorized to make such disclosure.

Consultant agrees that Consultant will not, during the term of this Agreement, improperly use or
disclose to Company any proprietary information or trade secrets of any former or current employer
or other person or entity to which Consultant has a duty to keep in confidence such information and
that Consultant will not bring onto the premises of Company any unpublished document or proprietary
information belonging to such employer, person or entity unless consented to in writing by the same.
Consultant will indemnify Company and hold it harmless from 844.KEY.CURE | www.kiromic.com PAGE 1
<!-- page 2 -->
and against all claims, liabilities, damages and expenses, including reasonable attorneys' fees and
costs of suit, arising out of or in connection with any violation or claimed violation by Company of
such third party's rights resulting in whole or in part from Company's use of the work product of
Consultant under this Agreement.

Consultant recognizes that Company has received and in the future will receive from third parties
their confidential or proprietary information subject to a duty on Company's part to maintain the
confidentiality of such information and to use it only for certain limited purposes. Consultant
agrees that Consultant owes Company and such third parties, during the term of this Agreement and
thereafter, a duty to hold all such confidential or proprietary information in the strictest
confidence and not to disclose it to any person, firm or corporation or to use it except as
necessary in carrying out the Services for Company consistent with Company's agreement with such
third party.

Upon the termination of this Agreement, or upon Company's earlier request, Consultant will deliver
to Company all Confidential Information and Company's property relating thereto and all tangible
embodiments thereof, in Consultant's possession or control.

3. Ownership. Consultant hereby irrevocably assigns to Company all right, title and interest in and
to any information (including, without limitation, business plans and/or business information),
technology, know-how, materials, notes, records, designs, ideas, inventions, improvements, devices,
developments, discoveries, compositions, trade secrets, processes, methods and/or techniques,
whether or not patentable or copyrightable, that are conceived, reduced to practice or made by
Consultant alone or jointly with others in the course of performing the Services or through the use
of Confidential Information (collectively, 111nventions").

Consultant agrees to sign, execute and acknowledge or cause to be signed, executed and acknowledged
without cost, but at the expense of Company, any and all documents and to perform such acts as my be
necessary, useful or convenient for the purposes of perfecting the foregoing assignments and
obtaining, enforcing and defending intellectual property rights in any and all countries with
respect to Inventions. It is understood and agreed that Company or Company's designee shall have the
sole right, but not the obligation, to prepare, file, prosecute and maintain patent applications and
patents worldwide with respect to Inventions.

Upon the termination of this Agreement, or upon Company's earlier requests, Consultant will deliver
to Company all property relating to, and all tangible embodiments of, Inventions in Consultant's
possession or control.

Consultant agrees that if, in the course of performing the Services, Consultant incorporates into
any Invention developed hereunder any invention, improvement, development concept, discovery or
other proprietary subject matter owned by Consultant or in which Consultant has an interest
("Item"), Consultant will inform Company in writing thereof, and Company is hereby granted and shall
have a non-exclusive, royalty-free, perpetual, irrevocable, worldwide license to make, have made,
modify, reproduce, display, use and sell such Item as part of or in connection with the exploitation
of such Invention.

Consultant agrees that if Company is unable because of Consultant's unavailability, mental or
physical incapacity, or for any other reason, to secure Consultant's signature to apply for or to
pursue any application or registration for any intellectual property rights covering any Invention,
then Consultant hereby irrevocably designates and appoints Company and its duly authorized officers
and agents as Consultant's agent and attorney-in-fact, to act for and in Consultant's behalf
844.KEY.CURE | www.kiromic.com PAGE 2
<!-- page 3 -->
to execute and file any such applications and to do all other lawfully permitted acts to further the
prosecution and issuance of such intellectual property rights thereon with the same legal force and
effect as if executed by Consultant.

4. Reports. Consultant agrees, from time to time during the term of this Agreement, to keep Company
advised as to Consultant's progress in performing the Services and, as reasonably requested by
Company, prepare written reports with respect thereto. It is understood that the time required in
the preparation of such written reports shall be considered time devoted to the performance of the
Services by Consultant. All such reports prepared by Consultant shall be the sole property of
Company.

5. Term and Termination. This Agreement will commence on the Effective Date and will continue until
termination as provided below.

Either Consultant or Company may terminate this Agreement upon prior written notice thereof to the
other party.

Upon termination of this Agreement, all rights and duties of the parties hereunder shall cease
except:

Company shall be obliged to pay, within thirty (30) days after receipt of Consultant's final
statement, all amounts owing to Consultant for unpaid Services completed by Consultant and related
expenses, if any, in accordance with the provisions of Section 1 hereof, and Sections 2, 3, S(c), 6,
7, 8 and 10 shall survive termination of this Agreement.

6. Independent Contractor. Nothing in this Agreement shall in any way be construed to constitute
Consultant as an agent, employee or representative of Company, but Consultant shall perform the
Services as an independent contractor. Consultant acknowledges and agrees that Consultant is
obligated to report as income all compensation received by Consultant pursuant to this Agreement.

7. No Debarment. Consultant represents and warrants that Consultant has not been debarred under
Section (a) or (b) of 21 U.S.C. Section 335a and does not appear on the United States Food and Drug
debarment list. Consultant represents and warrants that Consultant has not committed any crime or
conduct that could result in such debarment or Consultant's exclusion from any governmental
healthcare program. Consultant represents and warrants that, to Consultant's knowledge, no
investigations, claims or proceedings with respect to any such crimes or conduct are pending or
threatened against Consultant. Consultant agrees and undertakes to promptly notify the Company if
Consultant becomes debarred or proceedings have been initiated against Consultant with respect to
debarment, whether such debarment or initiation of proceedings occurs during or after the term of
this Agreement.

8. Conflicting Obligations. Consultant hereby certifies that Consultant has no outstanding agreement
or obligation that is in conflict with any of the provisions of this Agreement, or that would
preclude Consultant from complying with the provisions hereof, and further certifies that Consultant
will not enter into any such conflicting agreement during the term of this Agreement. Subject to
written waivers that may be provided by the Company upon request, which shall not be unreasonably
withheld, Consultant agrees that, during the term of this Agreement, Consultant will not directly or
indirectly (i) participate in the formation of any business or commercial entity in the Field of
Interest or otherwise competitive with the Company. Without limiting the foregoing, Consultant
agrees to use his or her best efforts (A) to segregate Consultant's 844.KEY.CURE | www.kiromic.com
PAGE 3
<!-- page 4 -->
Services performed under this Agreement from Consultant's work done for any other companies for whom
Consultant is providing services so as to minimize any questions of disclosure of, or rights under,
any inventions, (B) to notify the Company if at any time the Consultant believes that such questions
may result from his or her performance under this Agreement and (C) to assist the Company in fairly
resolving any questions in this regard which may arise. The Services performed hereunder will not be
conducted on time that is required to be devoted to any other third party. The Consultant shall not
use the funding, resources and facilities of any other third party, without the prior written
consent of the Company, to perform Services hereunder and shall not perform the Services hereunder
in any manner that would give any third-party rights or access to the product of such Services.

9. General. This Agreement (together with the Exhibits hereto) is the sole agreement and
understanding between Company and Consultant concerning the subject matter hereof, and it supersedes
any and all prior agreements and understandings with respect to such matter, whether written or
oral, provided, that, except as set forth in Exhibit B. Any required notice shall be given in
writing by customary means with receipt confirmed at the address of each party set forth below, or
to such other address as either party may substitute by written notice to the other. Consultant
shall not subcontract any portion of Consultant's duties under this Agreement without the prior
written consent of Company. Neither this Agreement nor any right hereunder or interest herein may be
assigned or transferred by Consultant without the express written consent of Company. Company may
assign this Agreement to any entity that succeeds to substantially all of the business or assets of
Company. This Agreement shall be governed by the laws of the State of Texas, without reference to
its conflicts of law principles. This Agreement may only be amended or modified by a writing signed
by both parties. Waiver of any term or provision of this Agreement or forbearance to enforce any
term or provision by either party shall not constitute a waiver as to any subsequent breach or
failure of the same term or provision or a waiver of any other term or provision of this Agreement.
In the event that any provision of this Agreement becomes or is declared by a court of competent
jurisdiction to be illegal, unenforceable or void, this Agreement shall continue in full force and
effect without said provision, provided that no such severability shall be effective if it
materially changes the economic benefit of this Agreement to either Company or Consultant.

10. Tax Matters. As follows:

(a) Withholding. All forms of compensation referred to in this letter agreement are subject to
reduction to reflect applicable withholding and payroll taxes and other deductions required by law.

(b) Tax Advice. You are encouraged to obtain your own tax advice regarding your compensation from
the Company. You agree that the Company does not have a duty to design its compensation policies in
a manner that minimizes your tax liabilities, and you will not make any claim against the Company or
the Board related to tax liabilities arising from your compensation.

11. Background Check and Authorization to Work. This offer of employment is contingent on the
Company's completion of a satisfactory background check of you. Please note that because of employer
regulations adopted in the Immigration Reform and Control Act of 1986, within three (3) business
days of starting your new position you will need to present documentation demonstrating that you
have authorization to work in the United States. If you have questions about this requirement, which
applies to U.S. citizens and non-U.S. citizens alike, please let us know.

12. Interpretation, Amendment and Enforcement. This letter agreement will be effective as of July 1,
2018. This letter agreement and the Company's standard Proprietary Information and Inventions
Agreement supersede and replace any prior agreements, representations or understandings (whether
written, oral, implied or otherwise) between you and 844.KEY.CURE | www.kiromic.com PAGE 4
<!-- page 5 -->
the Company and constitute the complete agreement between you and the Company regarding the subject
matter set forth herein. This letter agreement may not be amended or modified, except by an express
written agreement signed by both you and a duly authorized officer of the Company.

13. Arbitration Agreement. Any controversy or claim arising out of or relating to this agreement or
breach thereof, shall be settled by binding arbitration controlled by the rules of the American
Arbitration Association. The number of arbitrator(s) shall be one. The seat of arbitration shall be
Houston, Texas. Texas law shall also apply to the extent necessary to fill any gaps created by the
rules of the American Arbitration Association. The arbitration award shall be final and binding on
the parties. Judgement of the award rendered by the arbitrator(s) may be entered into any court of
competent jurisdiction. If any provision of this Arbitration Agreement is held illegal or
unenforceable in a arbitration proceeding, such provision shall be severed and shall be inoperative,
and the remainder of this Agreement shall remain operative and binding on the Parties. The
arbitrator(s) shall have sole kompetenz-kompetenz regarding this Arbitration Agreement.

14. Severability. If any provision of this Agreement is held illegal or unenforceable in a judicial
proceeding, such provision shall be severed and shall be inoperative, and the remainder of this
Agreement shall remain operative and binding on the Parties.

15. Counterparts. This Agreement may be executed in any number of counterparts, each of which when
so executed and delivered will be deemed an original, and all of which together will constitute one
and the same agreement.

16. Entire Agreement. This Agreement and the documents referred to herein constitute the entire
agreement and understanding of the parties with respect to the subject matter of this Agreement, and
supersede all prior understandings and agreements, whether oral or written, between the parties
hereto with respect to such subject matter.

[SIGNATURE PAGE TO FOLLOW] 844.KEY.CURE | www.kiromic.com PAGE 5
<!-- page 6 -->
IN WITNESS WHEREOF, the parties hereto have executed this Agreement as of the Effective Date.
KIROMIC, INC: CONSULTANT:

By: /s/ Scott Dahlbeck /s/ Gianluca Rotino Signature

Name: Scott Dahlbeck Gianluca Rotino

Title: President 844.KEY.CURE | www.kiromic.com PAGE 6
<!-- page 7 -->
EXHIBIT A

SERVICES AND COMPENSATION

1. Services. Consultant will render to Company the following Services: • Provide business and
statistical analysis of company metrics • Provide leadership role for business development
strategies • Manage all in house consulting duties to maximize return for company objectives •
Manage key marketing and communication campaigns • Prioritize and support clinical product pipeline
business priorities • Work closely with executive team to ensure department initiatives are all
aligned • Locate, evaluate and develop new business contacts and opportunities

2. Compensation. The Company will compensate Consultant at the rate of $400 per hour (19 hours cap
monthly; anything over these hrs must be preapproved by management), payable in accordance with the
Company's standard payroll schedule, and subject to withholding as legally required. This
compensation will be subject to adjustment pursuant to the Company's consultant compensation
policies in effect from time to time. Consultants shall be given written notice of any adjustments
to compensation at least fourteen (14) days prior to adjustments becoming effective. 844.KEY.CURE |
www.kiromic.com PAGE 7
