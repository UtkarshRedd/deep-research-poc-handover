# Under which jurisdiction's law is the agreement between Premier Biomedical, Inc. and Te...

*Question:* Under which jurisdiction's law is the agreement between Premier Biomedical, Inc. and Technology Health, Inc. governed?

## Identify governing law clause

The agreement between Premier Biomedical, Inc. and Technology Health, Inc. is governed by the laws of the Commonwealth of Pennsylvania. [f57b577c0db58ef4 p.5] The governing law clause states that the agreement and the rights of the parties shall be governed by and construed in accordance with the laws of the Commonwealth of Pennsylvania including all matters of construction, validity, performance, and enforcement and without giving effect to the principles of conflict of laws. [f57b577c0db58ef4 p.5] Premier Biomedical, Inc. and Technology Health, Inc. are parties to the agreement. [f57b577c0db58ef4 p.1]

## Verification appendix

Claims: 3 · supported: 3 · partially: 0 · dropped: 0 · gaps: 0 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[f57b577c0db58ef4 p.5] |  |
| s1.2 | s1 | keep | 1.00 | e1→[f57b577c0db58ef4 p.5] |  |
| s1.3 | s1 | keep | 1.00 | e2→[f57b577c0db58ef4 p.1] |  |

### Evidence

- e1 [f57b577c0db58ef4 p.5 L219-222] keep (1.0): "8. VENUE. This Agreement and the rights of the Parties hereunder shall be governed by and construed in accordance with the laws of the Commonwealth of Pennsylvania including all matters of construction, validity, performance, and enforcemen…"
- e2 [f57b577c0db58ef4 p.1 L7-7] keep (1.0): "| Parties | Marv Enterprises, LLC ("Marv"); Premier Biomedical, Inc. ("Premier"); Technology Health, Inc. ("THI"); (Each shall be referred to as a “Party” and collectively as the “Parties.”) |"
