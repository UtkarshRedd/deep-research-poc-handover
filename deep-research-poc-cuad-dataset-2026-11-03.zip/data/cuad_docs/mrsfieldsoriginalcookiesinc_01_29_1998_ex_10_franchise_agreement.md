<!-- page 1 -->
# FRANCHISE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Franchise Agreement |
| SEC Filing Date | 1998-01-29 |
| Parties | Pretzel Time, Inc. doing business as Pretzel Time ("Pretzel Time"; "FRANCHISOR"); Franchisee ("Franchisee") |
| Source | CUAD v1 / MRSFIELDSORIGINALCOOKIESINC_01_29_1998-EX-10-FRANCHISE AGREEMENT |

FRANCHISE AGREEMENT TABLE OF CONTENTS

1. INTRODUCTION AND DEFINITIONS.......................................1 1.A.
INTRODUCTION..............................................1 1.B.
DEFINITIONS...............................................3

2. GRANT OF FRANCHISE RIGHTS..........................................7 2.A. GRANT OF
FRANCHISE........................................7 2.B. PRINCIPAL OWNERS'
GUARANTY................................7 2.C. TERRITORIAL
RIGHTS........................................8 2.D. RESERVATION OF
RIGHTS.....................................8 2.E. OPTION TO DEVELOP OTHER SITES WITHIN THE
TERRITORY........9 2.F. TERM OF FRANCHISE.........................................9

3. OTHER DISTRIBUTION METHODS........................................10 3.A. SPECIAL DISTRIBUTION
ARRANGEMENTS........................10

4. FRANCHISE AND OTHER FEES..........................................10 4.A. INITIAL FRANCHISE
FEE....................................10 4.B. DEFERRAL OF FRANCHISE
FEE................................10 4.C. ROYALTY
FEE..............................................10 4.D. ADVERTISING FUND
FEE.....................................11 4.E. TRANSFER
FEE.............................................11 4.F. FEES FOR ADDITIONAL
FRANCHISES...........................11 4.G. FEES FOR RENEWAL OF
FRANCHISE............................12 4.H. PAYMENT BY ELECTRONIC FUNDS
TRANSFER.....................12 4.I. LATE CHARGE AND INTEREST. ...............................12

5. RENEWAL OF FRANCHISE TERM.........................................13 5.A. FRANCHISEE'S RIGHT TO A
SUCCESSOR FRANCHISE..............13 5.B. RELEASES.................................................14
5.C. NOTICES..................................................15

6. TRADEMARKS AND LIMITATIONS........................................15 6.A. OWNERSHIP OF
MARKS.......................................15 6.B. DISCONTINUANCE OF USE OF
MARKS...........................16 6.C. CORPORATE NAME...........................................16
6.D. TERMINATION..............................................17 6.E. TRADEMARK
ENFORCEMENT....................................17 6.F. USE OF SERVICE
MARK......................................17

7. SELECTION OF FRANCHISE LOCATION...................................18 7.A. SITE
SELECTION...........................................18 7.B.
LEASE....................................................18 7.C.
RELOCATION...............................................20

8. DEVELOPMENT OF UNIT...............................................21 8.A. UNIT DESIGN
SPECIFICATIONS AND CONSTRUCTION PLANS........21 8.B. DEVELOPMENT OF THE
UNIT..................................21 8.C. EQUIPMENT, FIXTURES, FURNISHINGS, AND
SIGNS..............22 8.D. EXCEPTIONS TO EQUIPMENT OR FURNISHINGS...................22 8.E.
CONSTRUCTION ASSISTANCE..................................23 8.F. LIMITATION ON
LIABILITY..................................23

9. UNIT OPENING......................................................24 9.A. COMMENCEMENT OF
OPERATIONS...............................24

10. FRANCHISEE TRAINING...............................................24 10.A. INITIAL
TRAINING.........................................24 10.B. EMPLOYEE
TRAINING........................................25 10.C. ON-SITE
TRAINING...........................................26 10.D. COMPANY
GROWTH...........................................26 10.E. RETRAINING
PROGRAMS......................................26 10.F. OTHER
GUIDANCE...........................................26

11. ADVERTISING AND OTHER PROMOTIONS..................................27 11.A. PROVIDING OF
ADVERTISING MATERIALS.......................27 11.B. CONTROL OF ADVERTISING PROGRAMS AND
CONCEPTS.............27 11.C. SEGREGATION OF ADVERTISING FUND..........................28 11.D.
SUSPENSION OF ADVERTISING FUND FEES......................29 11.E. FRANCHISEE'S REQUIRED ADVERTISING
EXPENDITURES...........29 11.F. USE OF TRADEMARK REFERENCES AND APPROVAL............... OF
FRANCHISEE'S MARKETING..............29

12. ADHERENCE TO UNIFORM STANDARDS....................................30 12.A. STANDARDS AND
OPERATIONS MANUAL..........................30 12.B. CONFIDENTIALITY OF OPERATIONS
MANUAL.....................32 12.C. INCORPORATION OF OPERATIONS MANUAL INTO AGREEMENT........32
12.D. MODIFICATIONS/UPDATES OF OPERATIONS MANUAL...............33

13. UNIT IMAGE AND OPERATION..........................................33 13.A. CONDITION AND
APPEARANCE OF UNIT.........................33 13.B. UNIT
MENU..................................................35 13.C. ADHERENCE TO APPROVED
ITEMS..............................35 13.D. EXCEPTION
PROCESS........................................36 13.E. PROMOTIONAL
ALLOWANCES.....................................37

14. FRANCHISEE OPERATIONS.............................................37 14.A.
MANAGEMENT...............................................37 14.B. SUFFICIENT WORKING
CAPITAL.................................38 14.C. FILING OF OPERATIONS AND SALES
REPORTS.....................38 14.D. EMPLOYEE DRESS AND CUSTOMER SERVICE......................38
<!-- page 2 -->
14.E. COMPLIANCE WITH LAWS AND GOOD BUSINESS PRACTICES...........38 14.F. PAYMENT OF
TAXES.........................................39 14.G. SALE OF
PRODUCT..........................................39 14.H.
COOPERATION..............................................39 14.I.
INSURANCE................................................39 14.J. SUGGESTED RETAIL
PRICES..................................40

15. ACCOUNTING, REPORTS AND FINANCIAL STATEMENTS......................41 15.A. ESTABLISHMENT OF
ACCOUNTING SYSTEM.........................41 15.B. MAINTENANCE OF
RECORDS....................................41

16. AUDITS AND INSPECTIONS............................................42 16.A.
AUDITS...................................................42 16.B. RIGHT OF ENTRY AND
INSPECTION............................42

17. TRANSFER, ASSIGNMENT AND REPURCHASE. .............................43 17.A. BY PRETZEL
TIME............................................43 17.B. BY
FRANCHISEE..............................................43 17.C. CONDITIONS FOR APPROVAL OF
TRANSFER........................44 17.D. TRANSFER TO A WHOLLY-OWNED CORPORATION...................45
17.E. FORMATION OF A CORPORATION.................................46 17.F. DEATH OR DISABILITY OF
FRANCHISEE..........................47 17.G. PRETZEL TIME'S FIRST RIGHT OF
REFUSAL....................47 17.H. PUBLIC OR PRIVATE OFFERINGS..............................48

18. TERMINATION OF AGREEMENT BY FRANCHISEE............................49 18.A. FRANCHISEE'S RIGHT TO
TERMINATE............................49

19. DEFAULT AND TERMINATION...........................................50 19.A. EXACT AND COMPLETE
PERFORMANCE REQUIRED....................50 19.B. DEFAULT AND RIGHT TO
CURE................................50 19.C. EXTENSION OF
NOTICE........................................50 19.D. REPEATED
BREACHES..........................................50 19.E. EVENTS OF DEFAULT - 30 DAYS NOTICE -
CURABLE DEFAULTS....51 19.F. EVENTS OF DEFAULT - IMMEDIATE TERMINATION - NO RIGHT TO
CURE............................................53

20. RIGHTS AND OBLIGATIONS OF PRETZEL TIME AND FRANCHISEE UPON TERMINATION OR EXPIRATION OF THE
FRANCHISE..................................56 20.A. AMOUNTS
OWED...............................................56 20.B. DISCONTINUANCE OF
MARKS..................................56 20.C. RETURN OF
MATERIALS......................................57 20.D. TELEPHONE
COMPANY........................................57 20.E. CONFIDENTIAL
INFORMATION.................................58 20.F.
LEASING..................................................58 20.G. COVENANT NOT TO
COMPETE..................................58 20.H. PRETZEL TIME'S RIGHT TO PURCHASE ASSETS OF THE
UNIT........59

21. RELATIONSHIP OF THE PARTIES/INDEMNIFICATION.......................60 21.A. EXCLUSIVE
RELATIONSHIP...................................60 21.B. NO LIABILITY FOR ACTS OF OTHER
PARTY.......................61 21.C. TAXES....................................................61
21.D. INDEMNIFICATION..........................................62 21.E. INDEPENDENT
CONTRACTOR.....................................62

22. PROTECTION OF TRADE SECRETS.......................................63 22.A. CONFIDENTIAL
INFORMATION...................................63 22.B. DISCLOSURE OF IDEAS AND NEW
PROCEDURES.....................64

23. ENFORCEMENT.......................................................65 23.A. UNAVOIDABLE
DELAYS.......................................65 23.B. RIGHTS OF PARTIES ARE
CUMULATIVE.........................65 23.C. WAIVER OF
OBLIGATIONS....................................65 23.D. CONTINUING
OBLIGATIONS...................................66 23.E. INVALID OR UNENFORCEABLE
PROVISIONS......................66 23.F. INJUNCTIVE
RELIEF..........................................66 23.G. APPLICABLE
LAW...........................................67 23.H. ENTIRE STATUS OF
AGREEMENT...............................67 23.I. AMENDMENT OF
AGREEMENT...................................67 23.J. HEIRS, SUCCESSORS AND
ASSIGNS............................67 23.K. CONDITIONS AND
CONTINGENCIES.............................67 23.L. WAIVER BY PRETZEL
TIME...................................68 23.M. COSTS AND EXPENSES OF
ENFORCEMENT........................68 23.N. RIGHTS OF PARTIES ARE CUMULATIVE
........................69 23.O. WAIVER OF JURY TRIAL.....................................69 23.P.
WAIVER OF PUNITIVE DAMAGES.................................69 23.Q. EXCLUSIVE
JURISDICTION.....................................69 23.R. LIMITATIONS OF
CLAIMS....................................69

24. ACKNOWLEDGMENTS AND REPRESENTATIONS...............................70

25. CONSTRUCTION......................................................70 25.A.
HEADINGS.................................................70 25.B.
TERMINOLOGY................................................70 25.C.
COUNTERPARTS.............................................71 25.D.
REASONABLENESS.............................................71

26. SECURITY AGREEMENT................................................70 26.A. SECURITY
INTEREST........................................71 26.B. DEFAULT REMEDIES UNDER
U.C.C...............................72

27. NOTICES...........................................................72 27.A. DELIVERY OF
NOTICES......................................72
<!-- page 3 -->
EXHIBITS

FRANCHISE ACKNOWLEDGMENTS AND REPRESENTATIONS STATEMENT . . . . . . . . . . . . . . . . . . . . . .
.. A

PRINCIPAL OWNER, OTHER OWNERS, DESIGNATED PRINCIPAL OWNERS, UNIT AND MANAGER, SUPERVISING OWNERS AND
INITIAL CAPITALIZATION . . . . . . . . . . . . . . . .. . . . B

PERMITTED COMPETITIVE BUSINESSES, FORM DEVELOPMENT AGREEMENT (FOR SINGLE-UNIT FRANCHISES), IDENTITY
OF DEVELOPER AND DATE OR DEVELOPMENT AGREEMENT . . . .C

OWNER'S AND GUARANTOR'S UNDERTAKING AND ASSUMPTION OF OBLIGATIONS. . . . . . . . . . . . . . . . . .
. . . . . . . . D

AUTHORIZATION AGREEMENT FOR PREARRANGED PAYMENTS (DIRECT DEBITS). E

UNIT SITE AGREEMENT . . . . . . . . . . . . . . . F

COLLATERAL ASSIGNMENT OF TELEPHONE NUMBERS AND LISTINGS . . G

MUTUAL CONFIDENTIALITY AGREEMENT . . .H

TCBY YOGURT PRODUCTS ADDENDUM . . . . . . I

FRAN.AGT 6.5.96

SATELLITE UNIT ADDENDUM . . . . . . . . . . . . . . J

RELEASE AGREEMENT . . . . . . . . . . . . . . K

THIRD PARTY ASSIGNMENT AGREEMENT . . . . . . . . . L

SUBLEASE . . . . . . . . . . . . . . . . . M

COLLATERAL ASSIGNMENT OF LEASE . . . . . . . . . N

PRETZEL TIME, INC. FRANCHISE AGREEMENT

This agreement is made and entered into this day of , 19 (hereinafter referred to as "Effective
Date") by and between Pretzel Time, Inc., a Pennsylvania corporation with its principal place of
business at 4800 Linglestown Road, Suite 202, Harrisburg, Pennsylvania 17112 trading and doing
business as Pretzel Time (hereinafter referred to as Pretzel Time) and Franchisee (as defined below)
who hereby agrees to the following:

Franchisee:

,

a

,

with its principal address at:

NOW THEREFORE, in consideration of the mutual covenants herein contained, and intending to be
legally bound hereby, the parties agree as follows:

1. INTRODUCTION AND DEFINITIONS.

1.A. INTRODUCTION.

Pretzel Time and its Affiliates (as defined below) have developed and continue to develop methods of
operating food service businesses, including the food service business referred to in this Agreement
as a Pretzel Time Unit (defined below), which feature Products (defined below) for off premises
consumption. Pretzel Time has established quality products and services which will continue to be a
unique benefit to Pretzel Time and its Franchisees. In addition to off-premises dining, Pretzel Time
may, in its sole discretion, offer to a Pretzel Time Unit the right to offer TCBY frozen yogurt and
other TCBY yogurt products. Pretzel Time Units operate at locations that feature a distinctive food
service format and Trade Dress (defined below) and utilize distinctive business formats,
specifications, employee selection and training programs, signs, equipment, layouts, unit fronts,
operation systems, recipes,
<!-- page 4 -->
methods, procedures, designs and marketing and advertising standards and formats, all of which
Pretzel Time may modify from time to time in its sole discretion (the" Pretzel Time System").
Pretzel Time operates, and franchises certain qualified persons and entities to license and grants
the privildge to operate, Pretzel Time Units using the Pretzel Time System and the Marks (defined
below).

Pretzel Time has developed and perfected a System for providing to the public, at retail, in an
efficient manner, a variety of distinctive, hand-rolled soft pretzels, pretzel-related products
(such as pretzel dogs), beverages, and complimentary pretzel toppings. These Products and services
which comprise a part of the Pretzel Time System are delineated and set forth in detail in the
Pretzel Time Operations Manual (hereinafter "Operations Manual"). These Pretzel Time Units, which
may include stores, carts, and kiosks, are known as "Pretzel Time Units".

Franchisee acknowledges and agrees that Pretzel Time has expended a considerable amount of time and
effort in developing and refining the recipes for, the methods of preparation of, the Products.
Pretzel Time may from time to time modify such recipes and methods of preparation, which may include
requiring Franchisee to prepare pretzels and other Products from scratch mixes and to purchase
prepared food products from Pretzel Time or an approved Pretzel Time Affiliate. Pretzel Time and its
Affiliates currently operate and will continue to operate Pretzel Time Units offering and selling
the Products. Pretzel Time franchises others to operate Pretzel Time Units and other outlets
offering and selling the Products. Pretzel Time owns, uses, promotes and franchises certain trade
names, trademarks, service marks and other commercial symbols, including the trade and service
marks, "Pretzel Time" and associated logos, which have gained and continue to gain public acceptance
and goodwill, and may hereafter create, use and franchise additional trademarks, service marks and
commercial symbols in conjunction with the operation of Pretzel Time Units.

The distinguishing characteristics of the Pretzel Time System include, but are not limited to, the
following:

(a) The Pretzel Time trade name and in combination with other commercial symbols owned by Pretzel
Time with a color scheme pattern, Unit design, insignia, slogans, coordinating Pretzel Time's
overall operation, retail facilities, advertising, training, and other related matters;

(b) A developed marketing concept and uniform procedure for the operation of a Pretzel Time Unit,
including stylized designs and display facilities to provide the highest quality of Pretzel Time
pretzels, soft beverages, toppings and other Pretzel Time-approved products; and

(c) Rules of operation and a procedure for operating and training Franchisees, managers and
employees.

Franchisee recognizes the benefits to be derived from being identified with and licensed by Pretzel
Time, and being able to utilize the Pretzel Time System of retailing Pretzel Time Products and
related products, service and trademarks which Pretzel Time makes available to its Franchisees.
Franchisee has applied for a franchise to operate a Pretzel Time Unit at the Site (defined below).
Franchisee's application and the Site have been approved by Pretzel Time in reliance upon all of the
representations made in such application and the Franchisee's Acknowledgments and Representations
Statement, a copy of which is attached hereto as Exhibit A, which shall be executed by Franchisee
concurrently with this Agreement. Franchisee desires to operate a Pretzel Time Franchise pursuant to
the provisions hereof and at the Site specified herein, and Franchisee has had a full and adequate
opportunity to be thoroughly advised of the terms and conditions of this Franchise Agreement by
legal counsel of its own choosing.

1.B. DEFINITIONS.

For purposes of this Agreement, the terms listed below have the following meanings: Other terms used
in this Agreement are defined and construed in the context in which they occur.

"Affiliate" - Any person or legal entity that directly or indirectly owns or controls Pretzel Time,
that is directly or indirectly owned or controlled by Pretzel Time, or that is under common control
with Pretzel Time. For purposes of this definition, "control" means the power to direct or cause the
direction of the management and policies of an entity.

"Cart" - It is a type of Pretzel Time Unit which is free-standing and sells Pretzel Time pretzels
and other Pretzel Time-approved Products which are produced or manufactured at a co-existing Kiosk
(defined below) or Store (defined below) situated in the Territory.

"Competitive Business" - A business or enterprise, other than a Pretzel Time Unit, that: (1) Offers
food products which are the same as or similar to the products for consumer consumption off premises
or other distribution channels; or (2) Grants or has granted franchises or licenses or establishes
or has established joint ventures for the development and/or operation of a business or an
enterprise described in the foregoing clause (1).

"Controlling Interest" - An interest, the ownership of which empowers the holder thereof to exercise
a controlling influence over the management, policies or personnel of an entity on any issue and
shall prevent any other person, group, combination, or entity from blocking voting control on any
issue or exercising any veto power. If a limited partnership, a general partnership interest or such
percentage of limited partnership interests as shall permit the
<!-- page 5 -->
replacement or removal of any general partner. Without limiting the generality of the foregoing,
ownership of forty percent (40%) or more of the equity or voting securities of a corporation or
ownership of any general partnership interest in a partnership or joint venture shall be deemed
conclusively to constitute a Controlling Interest in the corporation, partnership, or joint venture,
as the case may be.

"Area Developer's Agreement" - Agreement pursuant to which an area developer is granted the right to
develop one (1) or more Pretzel Time Units in a geographic area in which the Unit is located.

"Franchisee" - The party to whom the Franchise is granted by the Franchisor, Pretzel Time, Inc. The
term is applicable to one or more persons, a corporation or a partnership, as the case may be. If
two or more persons are at any time the Franchisee hereunder, their obligations and liabilities to
Pretzel Time shall be joint and several. References to Franchisee and assignee which are applicable
to an individual or individuals shall mean the Owner (defined below) or Principal Owners (defined
below) of the equity or operating control of the Franchisee or the assignee, if the Franchisee or
the assignee is a corporation or partnership.

"Net Revenues" - For purposes of this Agreement, the term "Net Revenues" includes all gross sums,
monies and other consideration received by Franchisee of every kind and nature from sales and
services made in, upon, or from any and all retail Units operated by Franchisee under the Pretzel
Time Marks in his Territory, whether upon credit or for cash, without reserve or deduction for
inability or failure to collect, less all refunds and allowances, if any, given in good faith to
customers, and any sales, use or excise taxes which are separately stated and which Franchisee pays
to any federal, state or local tax authority.

"Immediate family" - (1) The spouse of a person; and (2) the natural and adoptive parents and
natural and adopted children and siblings of such person and their spouses; and (3) the natural and
adoptive parents and natural and adopted children and siblings of the spouse of such person; and (4)
any other member of the household of such person.

"Interest" - Eighteen percent (18%) per annum for the number of days overdue or the highest
applicable rate allowed by law.

"Kiosk" - Is a type of Pretzel Time Unit, which is a free-standing enclosed area located within the
common area of a mall which can manufacture and sell Pretzel Time pretzels and other Pretzel
Time-approved Products without the co-existence of a Pretzel Time Store within the territory.

"Marks" - The trademarks, service marks, logos and other commercial symbols which Pretzel Time
authorizes Franchisee to use to identify the services and/or products offered by Pretzel Time Units,
including the mark "Pretzel Time" and the Trade Dress (defined below); provided that such
trademarks, service marks, logos, other commercial symbols and the Trade Dress are subject to
modification and discontinuance at Pretzel Time's sole discretion and may include additional or
substitute trademarks, service marks, logos, commercial symbols and Trade Dress as provided in this
Agreement.

"Owner" - Each person or entity holding direct or indirect, legal or beneficial Ownership Interests
(defined below) in Franchisee and each person who has other direct or indirect property rights in
Franchisee, this Agreement, the Franchise or the Unit and as designated in Exhibit B attached and
incorporated herein.

"Ownership Interests" - In relation to a: (i) corporation, the legal or beneficial ownership of
shares in the corporation; (ii) partnership, the legal or beneficial ownership of a general or
limited partnership interest; or (iii) trust, the ownership of a beneficial interest of such trust.

"Permanent Disability" - A mental or physical disability, impairment or condition that is reasonably
expected to prevent or actually does prevent Franchisee or an Owner of a Controlling Interest in
Franchisee from supervising the management and operation of the Unit for a period of six (6) months
from the onset of such disability, impairment or condition.

"Permitted Competitive Business" - A business which constitutes a Competitive Business and is
disclosed in Exhibit C which shall be made by Franchisee and Owners as of the date of this agreement
provided that such business does not offer hard or soft pretzels, or yogurt on its menu.

"Pretzel Time Unit" - A food service business that:

(1) offers Products for consumer consumption off-premises, provided that Pretzel Time, may in its
sole discretion, authorize and/or require such business to offer TCBY yogurt products pursuant to a
Yogurt Product Addendum (defined below) or to operate Special Distribution Arrangements pursuant to
a Special Distribution Agreement (defined below); and

(2) operates using the Pretzel Time System and the Marks; and

(3) is either operated by Pretzel Time or its Affiliates or pursuant to a valid franchise from
Pretzel Time.

Pretzel Time Units are of three types: stores, carts, and kiosks.

"Principal Owner" - Each Owner which:
<!-- page 6 -->
(1) is a general partner in Franchisee; or

(2) has a direct or indirect equity interest:

(a) in Franchisee of twenty percent (20%) or more (regardless of whether such Owner is entitled to
vote thereon); or

(b) in any Pretzel Time unit; or

(3) is designated as a Principal Owner in Exhibit B of this Agreement.

"Products" - Products approved or required by Pretzel Time from time to time in its sole discretion
for sale at or from Pretzel Time Units, including, without limitation, hand-rolled soft pretzels of
various flavors including, without limitation, chocolate chip, raisin, honey-wheat, and cinnamon,
frozen pretzels and other pretzel-related products and toppings, frozen yogurt, beverages, and other
Pretzel Time-approved products, provided that the foregoing products are subject to modification or
discontinuance in Pretzel Time's sole discretion from time to time and may

include additional or substitute products.

"Site" - The location of the Pretzel Time Unit as described in this Agreement. The term refers to
the inside of the four walls of the Unit premises.

"Special Distribution Agreement" - A separate agreement whereby Pretzel Time authorizes a Franchisee
of a Pretzel Time Unit to operate a Special Distribution Arrangement at a Special Distribution
Location designated by Pretzel Time.

"Special Distribution Arrangement" - The sale of Products at or from a Special Distribution Location
(defined below), whether or not by or through on-premises food service facilities or concessions,
pursuant to Pretzel Time's standards and specifications for such sales, which Pretzel Time may
change from time to time in its sole discretion.

"Special Distribution Location" - A facility or location, which as by way of example and without
limitation, a school, hospital, office, work site, military facility, grocery store, convenience
store, supermarket, entertainment or sporting facility or event, bus or train station, park, toll
road or limited access highway facility, shopping mall or other similar facility, at or from which
Pretzel Time, in its sole discretion, authorizes the operation of a Special Distribution Arrangement
pursuant to a Special Distribution Agreement, which facility may be located within or outside the
Territory.

"Store" - Is a traditional in-line Pretzel Time Unit where Pretzel Time Products are produced and
sold to customers at retail for off-premises consumption.

"Territory" - The geographic area described in this Agreement.

"Trade Dress" - The unit design, decor and image which Pretzel Time authorizes and requires
Franchisee to use in connection with the operation of Pretzel Time Units, as it may be revised and
further developed by Pretzel Time or its Affiliates from time to time and as further described in
the Manuals.

"Transfer" - The voluntary, involuntary, direct or indirect assignment, sale, gift, pledge,
mortgage, hypothecation, encumbrance or other disposition by Franchisee (or any of its Owners) or by
operation of law of:

(1) Any interest in this Agreement;

(2) A Controlling Interest in Franchisee; or

(3) Any interest in the Unit, equipment, furnishings or fixtures.

A Transfer shall also be deemed to include a merger or consolidation of Franchisee with any other
entity, the issuance of additional securities representing, or convertible into, an Ownership
Interest in Franchisee and any Transfer as a result of death (subject to this Section), divorce,
insolvency, corporate or partnership dissolution proceedings or otherwise by operation of law.

"Unit" - The Pretzel Time Unit which Franchisee is franchised to operate at the Site pursuant to
this Agreement.

"Yogurt Product Addendum" - The form of addendum to the Franchise Agreement used by Pretzel Time
attached hereto as Exhibit "I" from time to time to authorize or require, in its sole discretion, a
franchisee of a Pretzel Time Unit to offer TCBY frozen yogurt and other TCBY frozen yogurt products.

2. GRANT OF FRANCHISE RIGHTS.

2.A. GRANT OF FRANCHISE.

Pretzel Time hereby grants to Franchisee and Franchisee agrees to undertake, during the term of this
Agreement and upon the terms and conditions stated in this Agreement, the right, license and
privilege to operate, conduct,
<!-- page 7 -->
and do business and to use certain trade names, trademarks, service marks, logos, and other
commercial symbols, including Pretzel Time (referred to as "Marks") solely and exclusively for the
operation of one retail franchise Unit (referred to as "Franchise"), which is in the form of a
(Store/Kiosk/Cart), and to sell those Products known as Pretzel Time pretzels and other Pretzel
Time-approved menu items and Products further described in Section 2 (hereinafter "Products") in
accordance with the provisions of this Agreement and in accordance with rules, standards, systems,
and procedures as prescribed by Pretzel Time which may be changed, improved and further developed
from time to time, (hereinafter "Pretzel Time System"), at one (1) location only, such location to
be

(hereinafter "Site").

Pretzel Time will not, as long as this Agreement is in effect and Franchisee is not in default,
enfranchise or operate any other Pretzel Time Franchise within the following enclosed mall or
building except as otherwise provided herein (hereinafter referred to as "Territory"): none.
Franchisee has no territory other than the actual store location. Franchisee acknowledges that
Franchisee has no rights outside of the actual store location and that Pretzel Time has the right to
sell certain frozen products as Pretzel Time desires and Pretzel Time may conduct Pretzel Time's
business as Pretzel Time so desires without hinderance from Franchisee.

Franchisee shall not conduct the business of the Unit from any Site other than the Site specified,
except as otherwise provided under this Agreement. The form of addendum to the Franchise Agreement
used by Pretzel Time is attached hereto as Exhibit "J" to be used from time to time to add a
satellite unit pursuant to the Satelite Unit Addendum.

2.B. PRINCIPAL OWNERS' GUARANTY.

Franchisee shall cause all Principal Owners, and their spouses, as of the Effective Date to execute
and deliver to Pretzel Time concurrently with this Agreement, and all persons or entities which
become Principal Owners, and their spouses, thereafter to execute and deliver to Pretzel Time
promptly thereafter, the "Owner's and Guarantor's Undertaking and Assumption of Obligations,"
attached hereto as Exhibit D, or such other agreement as Pretzel Time prescribes from time to time,
undertaking to be bound jointly and severally by, and to guarantee the payment and performance of,
all provisions of this Agreement. Franchisee shall furnish to Pretzel Time, at any time upon
request, in such form as Pretzel Time may require, a list of its shareholders or partners (of record
and beneficially) reflecting their respective interests in Franchisee.

2.C. TERRITORIAL RIGHTS.

Except as otherwise provided in this Agreement and provided that Franchise is in full compliance
with this Agreement, Pretzel Time and its Affiliates will not during the term of this Agreement
operate or grant franchises for the operation of Pretzel Time Units within the Territory other than
the Franchise granted to Franchisee pursuant to this Agreement. Franchisee acknowledges that
Franchisee shall have no right to any Territory unless Franchisee and Pretzel Time have entered into
a separate Area Developer's Agreement. Franchisee shall have no exclusive Territory based on this
Agreement.

2.D. RESERVATION OF RIGHTS.

Except as expressly limited by Section 2.C., Pretzel Time (on behalf of itself, its Affiliates and
its designees) retains all rights, in its sole and exclusive discretion, to offer to sell the
Products and services authorized for Pretzel Time Units under the Marks hereinafter described in
Section 6 or other trade names, trademarks, service marks and commercial symbols through similar or
dissimilar channels of distribution and national accounts and pursuant to such terms and conditions
as Pretzel Time deems appropriate. Pretzel Time and its Affiliates retain the right to offer for
sale and sell, and franchise others to offer for sale and sell, any other Products or services under
the "Marks" and own and operate and grant to others the right to operate Pretzel Time Units solely
or in conjunction with TCBY stores or other snack food businesses at such locations and on such
terms and conditions as Pretzel Time, in its sole discretion, deems appropriate. Such Products shall
include, but not be limited to, soft pretzels, frozen pretzels and other pretzel-related products,
frozen yogurt and other Pretzel Time-approved Products and such methods of distribution may include,
but shall not be limited to, sales at sports arenas and stadiums, amusement parks, department
stores, airports, toll road travel plazas, hospitals, office buildings, schools and colleges and
other Non Traditional Unit venues as well as sales to wholesalers and/or distributors for resale.
Notwithstanding the foregoing, Pretzel Time reserves the right both within and outside the Territory
(if any) to sell at wholesale all Products and services which comprise a part of the Pretzel Time
System.

FRANCHISEE ACKNOWLEDGES AND AGREES THAT PRETZEL TIME HAS THE RIGHT TO PLACE UNITS AT ANY LOCATION,
EXCEPT AS LIMITED BY THIS AGREEMENT, AT ITS SOLE DISCRETION AND WITHOUT REGARD TO THE IMPACT UPON
THE FRANCHISEE'S BUSINESS. FRANCHISEE ACKNOWLEDGES THAT ABSENT A SEPARATE AREA DEVELOPER'S
AGREEMENT, PRETZEL TIME HAS THE RIGHT TO PLACE UNITS AT ANY LOCATION, AT ITS SOLE DISCRETION, AND
WITHOUT REGARD TO THE IMPACT UPON THE FRANCHISEE'S BUSINESS.

Franchisee acknowledges that because complete and detailed uniformity under many varying conditions
may not be possible or practical, Pretzel Time specifically reserves the right and privilege, at its
sole discretion and as it may deem in the best interests of all concerned in any specific instance,
to
<!-- page 8 -->
vary standards for any Franchisee based upon the peculiarities of the particular Site, landlords'
requirements, business potential, or other conditions which Pretzel Time deems to be of importance
to the successful operation of such Franchisee's business.

2.E. OPTION TO DEVELOP OTHER SITES WITHIN THE TERRITORY.

If Franchisee seeks to add a different type of Pretzel Time Unit, such as a kiosk or a cart, within
the Territory, then Franchisee must seek Pretzel Time's approval by notifying Pretzel Time, in
writing, that he desires to develop and operate other units, including a cart or kiosk, within the
Territory. If Pretzel Time has fully negotiated a lease agreement for such location, then Franchisee
shall (1) obtain the consent of the landlord to execute such lease and execute such lease, if
applicable; (2) execute Pretzel Time's then current form of Satellite Unit Addendum (containing
Pretzel Time's then current fees and expense requirements) and such ancillary documents (including
guarantees) as are then customarily used by Pretzel Time in the grant of franchises for Pretzel Time
Units as modified for use in connection with the Site, as necessary, and (3) pay Pretzel Time's
reasonable out-of-pocket expenses incurred in locating such additional Site and negotiating the
lease agreement, all within ten (10) business days after Pretzel Time's delivery to Franchisee of
the lease agreement and the franchise documents.

If Franchisee timely notifies Pretzel Time in writing that Franchisee desires to develop and operate
an additional Pretzel Time Unit, such as a kiosk or cart, within its Territory and Pretzel Time has
not fully negotiated a lease agreement for such location, then Franchisee will have thirty (30) days
in which to negotiate and deliver to Pretzel Time a lease agreement for such site in form for
execution. If Pretzel Time disapproves the lease agreement for failure to meet Pretzel Time's
requirements, Franchisee will have ten (10) days within which to negotiate and deliver to Pretzel
Time a revised lease agreement for such location in form for execution. If Pretzel Time approves the
lease agreement for such location as meeting Pretzel Time's requirements, then Franchisee will (1)
execute such lease agreement; (2) execute the franchise documents; and (3) pay Pretzel Time's
reasonable out-of-pocket expenses incurred, if any, in locating such additional Site and negotiating
the lease agreement, all within ten (10) business days after Pretzel Time's delivery to Franchisee
of the lease agreement and the franchise documents.

2.F. TERM OF FRANCHISE.

The term of this Agreement shall commence on the Effective Date of this Agreement and shall expire
twenty (20) years from the effective date of this Agreement. References in this Agreement to the
term of this Agreement mean the initial term and any renewal term.

3. OTHER DISTRIBUTION METHODS.

3.A. SPECIAL DISTRIBUTION ARRANGEMENTS.

Franchisee acknowledges and agrees that (1) Franchisee is not granted any rights to operate Special
Distribution Arrangements within or outside the Territory pursuant to this agreement; and (2) the
right to operate or grant to others the right to operate Special Distribution Arrangements is
reserved to Pretzel Time; and (3) Pretzel Time has no obligation to offer to Franchisee the right to
operate Special Distribution Arrangements; and (4) Pretzel Time or its designees may instead operate
or grant to others the right to operate Special Distribution Arrangements within and/or outside the
Territory.

4. FRANCHISE AND OTHER FEES.

4.A. INITIAL FRANCHISE FEE.

The initial franchise fee is Twenty-Five Thousand Dollars ($25,000.00). Upon execution of this
Agreement by Franchisee, Franchisee shall pay to Pretzel Time, in consideration of the franchise
granted herein, Twenty-Five Thousand Dollars ($25,000.00) payable by certified check or cashier's
check in United States currency due upon execution of the Franchise Agreement. The franchise fee is
fully earned by Pretzel Time upon the payment in full thereof and is nonrefundable (except as
specifically provided in this agreement) as consideration for expenses incurred by Pretzel Time in
furnishing assistance and services to Franchisee and for Pretzel Time's lost or deferred opportunity
to franchise others, and not as compensation for the use of the copyrighted works, Marks or Trade
Dress. Franchisee acknowledges and agrees that this franchise fee is reasonable. The fee is not
reduced if Pretzel Time is unable to obtain a TCBY Franchise. An additional $1,000 is payable by
Franchisee to Pretzel Time as a Yogurt Fee if Yogurt Product is included in the Franchise.

4.B. DEFERRAL OF FRANCHISE FEE.

Payment of the initial franchise fee is deferred for franchises to be located in Minnesota and for
Minnesota residents until the franchise Unit opens at which time the franchise fee must be paid in
full to Pretzel Time. Franchise fees for Maryland residents and franchises to be located in Maryland
will be escrowed until the unit is opened. There may be other stores in which state administrators
have required fees or royalties to be deferred or escrowed.

4.C. ROYALTY FEE.
<!-- page 9 -->
Franchisee, in partial consideration of the grant of a franchise, agrees to pay to Pretzel Time a
continuing Royalty of seven percent (7%) of Franchisee's net revenues (as defined in Section 1) on a
weekly basis as specified in this Section; provided only 4% Royalty shall be payable on TCBY frozen
yogurt and other TCBY frozen yogurt products. The Royalty is not uniform as to all franchisees, it
is fully earned, and is nonrefundable in any circumstance. Franchisee shall pay weekly by electronic
funds transfer (ACH) without offset, defalcation, credit or deduction of any nature to Pretzel Time
the royalty fee, the advertising fund fee and all other amounts due and payable on each Wednesday
for the immediately preceding week. The Royalty shall be paid by electronic funds transfer from
Franchisee's general operating account. The Royalty is paid, in part, to compensate Pretzel Time for
various services provided to Franchisee after the Unit opens, including, but not limited to,
quality, service, and cleanliness inspections. Pretzel Time, upon written notice to Franchisee,
shall have the right to change the timing of Franchisee's payments of Royalty Fees and Advertising
Fund Fees due under this Agreement. Franchisee shall not subordinate to any other obligation his
obligation to pay the Royalty Fee or any other fee or charge hereunder.

4.D. ADVERTISING FUND FEE.

Franchisee agrees to pay on a weekly basis to Pretzel Time, as partial consideration for the grant
of the Franchise, an Advertising Fund Fee of one percent (1%) of Net revenues for the preceding week
as defined in Section 1. Franchisee herein acknowledges that the Advertising Fund Fee is not uniform
as to all franchisees. The Advertising Fund Fee is fully earned and nonrefundable. The Advertising
Fund Fee shall be paid by electronic funds transfer from the Franchisee's general operating account
on Wednesday of each week based on the preceding week's Net revenues.

4.E. TRANSFER FEE.

If Franchisee desires to assign his rights under the Franchise to a new franchisee, Franchisee
(Assignor of the Franchise), agrees to pay to Pretzel Time a transfer fee equal to the greater of
SIX THOUSAND TWO HUNDRED FIFTY DOLLARS ($6,250.00) or the then current transfer fee being paid by
franchisees upon the assignment, gift, bequeath or transfer of ownership of the Franchise to cover
administrative costs and expenses. The transfer fee is non-refundable. The fee shall be due and
payable by the current Franchisee to Pretzel Time five (5) days prior to the transfer of the
Franchise to the assignee. Additionally, the assignee of the Franchisee shall pay Pretzel Time an
additional amount of Twenty-Five Thousand Dollars ($25,000.00) (plus $1,000.00 if Yogurt Product is
included), for any additional units that are not existing stores or the then current initial
franchisee fee for traditional Pretzel Time Units.

4.F. FEES FOR ADDITIONAL FRANCHISES.

In the event that Franchisee meets Pretzel Time's qualifications to open additional Franchises at
sites acceptable to both Franchisee and Pretzel Time, which approval is at the sole discretion of
Pretzel Time, the initial franchisee fee shall be the greater of FIVE THOUSAND DOLLARS
($5,000.00)(plus $1,000.00 if Yogurt Product is included) or the then current fee for additional
franchises set by Pretzel Time, at its sole discretion. The decision to grant an additional
franchise location shall be in the sole discretion of Pretzel Time and at no time does Pretzel Time
promise or guarantee that additional franchises will be offered or approved. Such decisions will be
made on a case-to-case basis, based on factors including, but not limited to the availability of
suitable locations, quality of standards maintained in the Franchisee's current Units, the impact of
additional locations upon the operations of the Franchisee's current Units, the geographical
distance between the Franchisee's existing and proposed location, the business plan of Pretzel Time,
national contracts with major corporations, the population of the area near the prospective site,
the quality of the site, and other economic and business factors. Under no circumstances is
Franchisee entitled to demand or require Pretzel Time to grant to Franchisee a Franchise or a
similar variation thereof.

4.G. FEES FOR RENEWAL OF FRANCHISE.

Franchisee agrees that in consideration of the grant of the "Successor Franchise" (defined in
Section 5.A.), Franchisee shall pay the current renewal fee as of the date of renewal and execute a
general release in the form prescribed by Pretzel Time in accordance with Section 5.B. The renewal
fee is due and payable thirty (30) days prior to the renewal day.

4.H. PAYMENT BY ELECTRONIC FUNDS TRANSFER.

Franchisee agrees to pay all Royalties, Advertising Fund Fees, amounts due Pretzel Time for
purchases by Franchisee from Pretzel Time or its Affiliates and other amounts which Franchisee owes
to Pretzel Time via electronic funds transfer from Franchisee's general account, which shall be
initiated by Pretzel Time and any transfer fees shall be paid by Franchisee every Wednesday for the
preceding week based upon the Net Revenues. Franchisee herein agrees to execute and complete all
necessary documentation required by Pretzel Time to permit the wire transfer to Pretzel Time (in the
form attached hereto as Exhibit E or such other form as Pretzel Time shall accept). Under this
procedure, Franchisee shall authorize Pretzel Time to initiate debit entries and/or credit
correction entries to Franchisee's general operating bank account for payments of Royalties,
Advertising Fund Fees and other amounts payable under this Agreement and any late or interest
charges due thereon. Franchisee shall make the funds
<!-- page 10 -->
available to Pretzel Time for withdrawal by electronic transfer no later than one day prior to the
due date for payment therefor. The Royalty and Advertising Fund Fees amount actually transferred
from Franchisee's account shall be based on the Unit's Net Revenues indicated on the reports
submitted by Franchisee as required hereunder. If Franchisee has not reported the Unit's Net
Revenues to Pretzel Time for any week as required herein, then Pretzel Time shall be authorized to
debit Franchisee's account in an amount equal to the fees transferred from Franchisee's account for
the last reporting period for which a report of the Unit's Net Revenues was provided to Pretzel Time
as required hereunder. If, at any time, Pretzel Time determines that Franchisee has under-reported
the Unit's Net Revenues, or underpaid Royalty or Advertising Fund Fees or other amounts due
hereunder, Pretzel Time shall be authorized to initiate immediately a debit to Franchisee's account
in the appropriate amount in accordance with the foregoing procedure, plus interest as provided for
in this Agreement. Any overpayment shall be credited to Franchisee's account through a credit
effective as of the first week after Franchisee and Pretzel Time determine that such credit is due.
Notwithstanding any designation by Franchisee, Pretzel Time shall have the sole discretion to apply
any payments by Franchisee to any past indebtedness of Franchisee for Royalty or Advertising Fund
Fees, purchases from Pretzel Time and/or its Affiliates, interest or any other indebtedness,
including, without limitation, payment of rental sums in arrears for the Unit.

4.I. LATE CHARGE AND INTEREST.

To compensate Pretzel Time for the increased administrative expense of handling late payments,
Pretzel Time may charge Franchisee a $50.00 late charge for each delinquent payment. All Royalty and
Advertising Fund Fees, amounts due for purchases by Franchisee from Pretzel Time or its Affiliates,
and other amounts which Franchisee owes to Pretzel Time or its Affiliates shall bear interest after
their due date at a rate equal to the lesser of: (1) eighteen percent (18%) per annum for the number
of days which such payment is due; or (2) the highest applicable legal rate permitted by applicable
law. Franchisee acknowledges that this Section shall not constitute Pretzel Time's or its
Affiliates' agreement to accept such payments after they are due or a commitment by Pretzel Time or
its Affiliates to extend credit to or otherwise finance operation of the Unit. Notwithstanding the
provisions of this Section 4.I., Franchisee acknowledges and agrees that his failure to pay all
amounts when due shall constitute grounds for termination of this Agreement.

5. RENEWAL OF FRANCHISE TERM.

5.A. FRANCHISEE'S RIGHT TO A SUCCESSOR FRANCHISE.

Upon the expiration of the initial term of this Agreement, Franchisee shall have the one time right
to obtain a successor franchise to operate a Pretzel Time Unit at the Site (a "Successor Franchise")
for a single term of five (5) years immediately following the expiration of the initial term of the
Franchise upon giving Pretzel Time six (6) months notice prior to the expiration of the then current
term if:

(1) Franchisee and its Owners have complied with this Agreement and any amendment during the initial
term of this Agreement in all material respects; and

(2) Franchisee maintains possession of the Site and agrees to remodel and/or expand the Unit, add or
replace equipment, furnishings, fixtures and signs and otherwise modify the Unit to bring it into
compliance with specifications and standards then applicable under new or Successor Franchises for
Pretzel Time Units; or if Franchisee is unable to maintain possession of the Site, or if, in the
judgment of Pretzel Time, the Unit should be relocated, Franchisee secures a substitute site
approved by Pretzel Time and agrees to develop expeditiously such substitute site in compliance with
specifications and standards then applicable under new or successor franchises for Pretzel Time
units; and

(3) Pretzel Time has not given notice of its election not to renew six (6) months prior to the
expiration of the initial twenty (20) year term; and

(4) Franchisee is not in default of any material term or condition of the lease agreement, or any
other agreement between Pretzel Time and Franchisee; and

(5) Franchisee executes Pretzel Time's then current Franchise Agreement and other ancillary
agreements required and being offered to new Franchisees on the date of renewal, which agreements
shall supersede in all respects this Agreement and the terms of which may differ from the terms of
this Agreement, including, without limitation, Royalty Fees and Advertising Fund Fees, other fees
and charges, performance criteria, and a provision which allows Pretzel Time and its Affiliates to
reserve the right, both within and outside of the Territory, to offer and sell at wholesale or
retail, through channels of distribution distinct from those of a Franchise, Products and services
which comprise, or may in the future comprise a part of the Pretzel Time System, which Products may
be resold at retail to the general public by such entities; and

(6) Franchisee is in full compliance with Pretzel Time's Operations Manual; and

(7) On renewal, Franchisee agrees to pay the current renewal fee, the Royalty and Advertising Fund
fees specified in Pretzel Time's current
<!-- page 11 -->
Franchise Agreement then being offered new Franchisees on the date of renewal; and

(8) Franchisee shall execute general releases, in form satisfactory to Pretzel Time, of any and all
claims against Pretzel Time and its Affiliates and their officers, directors, employees, agents,
successors and assigns arising under this Agreement; and

(10) Franchisee has complied with Pretzel Time's then current qualification and training
requirements.

Following receipt of Franchisee's election to renew, Pretzel Time shall provide Franchisee with an
execution copy of the form of Franchise Agreement to be entered into for the renewal term. If the
Franchisee does not execute and return the renewal Franchise Agreement within thirty (30) days of
receipt, then Franchisee shall be deemed to have withdrawn its notice of renewal, and this Agreement
shall terminate at the end of the current term.

Pretzel Time may, at its option, with reasonable cause and upon written notice, elect not to renew
the Franchise Agreement. Pretzel Time shall notify Franchisee of the nonrenewal not less than six
(6) months prior to the expiration of the term of this Agreement. If applicable law requires that
Pretzel Time give longer notice to Franchisee prior to the expiration of the term than is specified
in the Franchise Agreement, the Franchise Agreement will remain in effect on a month-to-month basis
until the requisite notice has been given.

5.B. RELEASES.

Franchisee and its Owners shall execute general releases, in form satisfactory to Pretzel Time (the
general form of which is attached hereto as Exhibit "K"), of any and all claims against Pretzel Time
and its Affiliates and their respective shareholders, officers, directors, employees, agents,
successors and assigns. Failure by Franchisee and its Owners to sign and deliver to Pretzel Time,
such agreements and releases within thirty (30) days after delivery thereof to Franchisee shall be
deemed an election by Franchisee not to obtain a Successor Franchise.

5.C. NOTICES.

Franchisee shall give Pretzel Time written notice of its election to obtain a Successor Franchise
not more than twelve (12) months and not less than six (6) months prior to the expiration of this
Agreement. Pretzel Time agrees to give Franchisee, written notice, not more than thirty (30) days
after receipt of Franchisee's notice of (a) Pretzel Time's determination whether or not it will
grant Franchisee a Successor Franchise pursuant to this Section and/or (b) any deficiencies in
Franchisee's operation of the Unit (or any other failure to comply with the terms of this Agreement)
which could cause Pretzel Time to refuse to grant a Successor Franchise. Such notice shall state
what actions Franchisee must take to correct the deficiencies and shall specify the time period in
which such deficiencies must be corrected. Pretzel Time shall give Franchisee written notice of a
decision not to grant a Successor Franchise based upon Franchisee's failure to cure deficiencies not
less than ninety (90) days prior to the expiration of the initial term of this Agreement. Such
notice shall state the reasons for Pretzel Time's refusal to grant a Successor Franchise. In the
event Pretzel Time fails to give Franchisee (a) notice of deficiencies in the Unit or in
Franchisee's operation of the Unit, within thirty (30) days after receipt of Franchisee's timely
election to obtain a Successor Franchise, or (b) notice of Pretzel Time's decision not to grant a
Successor Franchise at least ninety (90) days prior to the expiration of the term of this Agreement,
Pretzel Time may extend the term of this Agreement for such period of time as is necessary in order
to provide Franchisee reasonable time to cure deficiencies or to provide ninety (90) days notice of
Pretzel Time's determination not to grant a Successor Franchise. The grant of a Successor Franchise
shall be conditioned upon Franchisee's continued compliance with all the terms and conditions of
this Agreement until the date of expiration.

6. TRADEMARKS AND LIMITATIONS.

6.A. OWNERSHIP OF MARKS.

Franchisee acknowledges that Pretzel Time is the owner of all right, title and interest together
with all the goodwill in and to the Marks. Franchisee acknowledges that his right to use the Marks
is derived solely from this Agreement and is limited to his conduct of business pursuant to and in
compliance with this agreement and all applicable standards, specifications and operating procedures
Pretzel Time prescribes from time to time during its term. Franchisee shall not have nor assert any
right, title or interest in Pretzel Time's Marks or any goodwill of Pretzel Time. Franchisee agrees
that he will not register such trade name or marks in his own name or that of any other firm, person
or corporation. The following Marks are currently authorized for Franchisee's use in the Franchised
Business as follows:

Pretzel TimeJ Pretzel Time Stylized7 Pretzel Time Clock DesignJ Pretzel Time StorefrontJ Fitness
with a twist.J

Franchisee acknowledges and recognizes Pretzel Time's interest and exclusive right to the concepts
of the Pretzel Time System and its distinguishing characteristics, including the name and style of
the unique decor
<!-- page 12 -->
of the Pretzel Time stylized literature, display and promotional materials, marketing methods,
operating procedures, training program and the manufacture of Pretzel Time Products. Pretzel Time
makes no representation or warranty, express or implied, as to the use, exclusive ownership,
validity or enforceability of the Marks. Pretzel Time reserves the right to develop other
trademarks, service marks, copyrights and patents for use in other businesses. Pretzel Time and
Franchisee acknowledge and agree that it is not required to defend Franchisee against a claim
against his use of Pretzel Time Marks. Pretzel Time may reimburse Franchisee for his liability and
reasonable costs in connection with defending Pretzel Time's registered trademarks provided
Franchisee has notified Pretzel Time immediately when he learned about the infringement or
challenge.

Franchisee agrees to use Pretzel Time's trade name and Marks as the sole trade identification of the
Unit and in connection with, and exclusively for the promotion and conduct of the Franchise as
provided hereunder and in accordance with instructions, rules, and procedures prescribed by Pretzel
Time from time to time with respect thereto. Notwithstanding the foregoing, Franchisee shall
identify himself as the independent owner of the Unit in the manner prescribed by Pretzel Time.
Franchisee agrees to give such notices of trademark and service mark registrations as Pretzel Time
may specify and to obtain such business name registrations as may be required under applicable law.
Franchisee shall not at any time during the term of this Agreement or after its termination, contest
the validity or ownership of any of the Marks or assist any other person in contesting the validity
or ownership of the Marks.

6.B. DISCONTINUANCE OF USE OF MARKS.

If it becomes advisable at any time, in Pretzel Time's sole discretion, for Pretzel Time or the Unit
to modify or discontinue use of any Mark, and/or use of one or more additional or substitute trade
names, trademarks, service marks, or other commercial symbols, Franchisee shall comply with Pretzel
Time's directions within a reasonable time after notice to Franchisee by Pretzel Time. Neither
Pretzel Time nor its Affiliates shall have any obligation to reimburse Franchisee for any
expenditures made by Franchisee to modify or discontinue the use of a Mark or to adopt additional
marks or substitutes for a discontinued Mark, including, without limitation, any expenditures
relating to advertising or promotional materials or to compensate Franchisee for any goodwill
related to the discontinued Mark.

6.C. CORPORATE NAME.

Franchisee agrees not to use any Mark or trade name of Pretzel Time or any part thereof or with any
prefix, suffix or other modifying words, terms, designs, or symbols or in any modified form as part
of any corporate or trade name nor shall Franchisee use any Mark in connection with the sale of any
unauthorized product or service or in any other manner not expressly authorized in writing by
Pretzel Time.

6.D. TERMINATION.

Immediately upon the termination of this Agreement, the Franchisee agrees to cease and forever
abstain from using the Pretzel Time trade name and Marks and return to Pretzel Time all documents,
manuals, instructions, display items and the like bearing the aforesaid trade names or any of the
Marks.

6.E. TRADEMARK ENFORCEMENT.

Pretzel Time shall police and enforce its rights with respect to its trademarks and other
proprietary aspects of the Pretzel Time System with the cooperation of Franchisee, and shall bring
appropriate actions or proceedings against infringers or other unlawful users at its sole expense.

Franchisee agrees to immediately notify Pretzel Time of any claim, demand or suit based upon or
arising from or of any attempt by any other person, firm or corporation to use Pretzel Time's
trademarks, service marks, copyrights, trade secrets, or Systems licensed hereunder or colorable
variation thereof in which Pretzel Time has a proprietary interest. Pretzel Time will take the
action it thinks appropriate. In the event Pretzel Time undertakes any prosecution of litigation or
defense relating to the proprietary Marks licensed hereunder, Franchisee agrees to execute any and
all documents and do such acts and things as may in Pretzel Time's opinion, be necessary to carry
out such defense or prosecution. Franchisee agrees that Pretzel Time has the right to control
administrative proceedings or litigation with respect to this issue.

Franchisee agrees to participate and cooperate in the prosecution of any action to prevent the
infringement, imitation, illegal use or misuse of the Marks and agrees to be named as a party in any
such action if requested by Pretzel Time. Pretzel Time agrees to bear the legal expenses incident to
Franchisee's participation in such action, except for the cost of Franchisee's personal legal
counsel if Franchisee elects to be represented by counsel of his own choosing.

6.F. USE OF SERVICE MARK.

Except with the prior written consent of Pretzel Time, Franchisee agrees not to infringe upon, use
or imitate Pretzel Time's System, or any of its distinguishing characteristics, and further agrees
not to cause or allow any other person to infringe upon, use or imitate Pretzel Time's System, or
any of its distinguishing characteristics. Franchisee agrees to use and display the Marks at all
times only in accordance with the quality control standards set forth in this Agreement and in the
Operations Manual. During the term of this Agreement, and renewal term, if any, Franchisee will
operate the Unit only under the Marks . Franchisee will use or display the Marks only within the
designated Territory. Franchisee will cause a sign bearing the name Pretzel Time which meets Pretzel
Time's specifications for color, design and size, to be installed
<!-- page 13 -->
on the outside of the retail Unit. Franchise shall not, at any time during the term of this
Agreement or after its termination or expiration use any Mark in connection with the sale of any
unauthorized product or service or in any other manner not expressly authorized in writing by
Pretzel Time.

7. SELECTION OF FRANCHISE LOCATION.

7.A. SITE SELECTION.

Franchisee shall be responsible for leasing a suitable site for the Franchise subject to Pretzel
Time's approval. Pretzel Time agrees to assist Franchisee in locating and securing a location for
the unit which is acceptable to both Pretzel Time and Franchisee. Franchisee shall submit to Pretzel
Time a list of desired locations on the Location Agreement attached hereto as Exhibit W or if
Pretzel Time directs on a form prepared by Pretzel Time and attached hereto as Exhibit F, and
Pretzel Time shall contact the appropriate leasing representatives to determine the availability of
sites at those locations. After obtaining information from appropriate leasing representatives,
Pretzel Time shall notify Franchisee whether or not the sites made available to Pretzel Time are
acceptable by Pretzel Time. In the event that a site for the franchise cannot be located which is
acceptable and suitable to both Pretzel Time and Franchisee within One Hundred Twenty (120) days,
then the Franchise Agreement shall be terminated and all franchise fees paid by Franchisee shall be
refunded.

Pretzel Time shall approve the site for the unit in reliance upon information furnished and
representations made by Franchisee with respect to the size, appearance, and other physical
characteristics of the site, photographs of the site, demographic characteristics, traffic patterns,
competition from other businesses in the area, and other commercial characteristics. Pretzel Time's
approval of the site indicates only that Pretzel Time believes that the site falls within acceptable
criteria established by Pretzel Time as of the time period encompassing the evaluation. Franchisee
agrees that Pretzel Time shall not be responsible for the failure of a franchise, site and/or
premises approved by Pretzel Time to meet expectations as to potential revenue or operational
criteria. Franchisee acknowledges and agrees that his acceptance of a Franchise for the operation of
a Unit in the Territory is based on his own independent investigation of the suitability of the mall
location.

Franchisee acknowledges that Pretzel Time's approval of the lease or sublease for the Unit does not
constitute a guarantee or warranty by Pretzel Time, express or implied, of the successful operation
or profitability of a Unit operated at the designated Site. Such approval indicates only that
Pretzel Time believes that the Unit and the terms of the lease fall within the acceptable criteria
established by Pretzel Time as of the time period encompassing the evaluation.

7.B. LEASE.

Pretzel Time and Franchisee further agree that Pretzel Time shall negotiate the basic economic terms
of the lease in consultation with the Franchisee. Franchisee agrees to execute a letter of intent
for the lease premises which outlines the basic economic terms of the lease and return it to Pretzel
Time within five (5) days of receipt of same. Franchisee acknowledges and agrees that he is
responsible for reviewing the terms of the agreement and making any necessary changes to the lease
agreement. Franchisee shall not execute any lease agreement without the prior approval of Pretzel
Time, which shall be conditioned upon inclusion of terms in the lease acceptable to Pretzel Time and
at Pretzel Time's option shall contain such provisions, including, but not limited, to:

(1). Notice to Pretzel Time of, and Pretzel Time's right to cure, Franchisee's default under the
lease provided, however, that if Pretzel Time cures any such default, the total amount of all costs
and payments incurred by Pretzel Time in effecting the cure shall be immediately due and owing to
Pretzel Time by Franchisee;

(2). Franchisee's right to assign his interest under the lease or sublease to Pretzel Time without
the lessor's or sublessor's consent;

(3). Allowing Franchisee to transfer the lease to Pretzel Time or another approved franchisee in the
event that Franchisee sells his business (a copy of the form of the third party assignment agreement
that Franchisee and the prospective purchaser would sign is attached hereto as Exhibit L);

(4). Authorizing and requiring the Lessor or sublessor to disclose to Pretzel Time, upon its
request, sales and other information that Franchisee furnishes to the lessor or sublessor; and

(5). Providing that Pretzel Time (or one of its Affiliates or its Assignee) shall have the right
(but not the obligation) to assume the lease or sublease:

(i) Upon termination of this Agreement by Pretzel Time or upon expiration of this Agreement (unless
a Successor Franchise is
<!-- page 14 -->
granted to Franchisee), or

(ii) If Franchisee fails to exercise any options to renew or extend the lease or sublease or,

(iii) If Franchisee commits a default that gives the lessor or sublessor the right to terminate the
lease or sublease, or

(iv) If Pretzel Time or one of its Affiliates or its designee/assignee purchases the Unit.

(6). A provision allowing sampling in front of the retail Unit;

(7). A provision that the premises are to be used exclusively for a Pretzel Time Unit only; and

(8). A provision which permits alterations to the premises in a good and workman-like manner by
Franchisee as required by Pretzel Time.

Franchisee further agrees to execute and return the lease and any other riders, guaranties or
sureties required by the Landlord within seven (7) days from receipt of the same and no later than
sixty (60) days after signing of this Agreement. If any lease expires prior to the expiration of
this Agreement, Franchisee will be required to arrange any necessary lease for the Unit and Pretzel
Time shall have the right to approve the terms of the renewal lease for the Unit prior to
Franchisee's execution thereof. Franchisee agrees that he will not execute a lease or sublease which
Pretzel Time has disapproved. Franchisee shall deliver a copy of the signed lease to Pretzel Time
for the Unit within five (5) business days after its full execution. The copy shall be complete and
include copies of all signature pages and exhibits.

A copy of the form of the sublease that Franchisee shall execute (if Pretzel Time is the tenant
pursuant to the lease) is attached hereto as Exhibit M. A copy of the form of the collateral
assignement of lease that Franchisee shall execute (if Franchisee is the tenant pursuant to the
lease) is attached hereto as Exhibit N.

Franchisee shall be responsible for all terms and conditions of the lease covering the franchise
location, including any required security deposit and prepaid rent. Franchisee agrees to pay the
Unit rent directly to the landlord at the rate and terms specified in the primary lease between
landlord and Franchisee. Rent is generally paid monthly on the first day of the month and is
non-refundable. Franchisee agrees that the Unit shall be used only as a Pretzel Time franchise.

If Franchisee fails to obtain lawful possession of an approved Site (through a lease or assignment)
within sixty (60) days after delivery of Pretzel Time's approval of the Site, Pretzel Time, may, in
its sole discretion, withdraw approval of such Site at any time.

7.C. RELOCATION.

In the event that Franchisee's lease is terminated, with or without fault of Franchisee, if the Site
is damaged, condemned or otherwise rendered unusable as a Pretzel Time Unit in accordance with this
Agreement, or if, in the judgment of Pretzel Time and Franchisee, there is a change in the character
of the location of the Site sufficiently detrimental to his business potential to warrant its
relocation, Pretzel Time will not unreasonably withhold permission for relocation of the Unit to
another Site, which meets Pretzel Time's then-current site criteria, subject to the rights of
existing Pretzel Time franchisees under their franchise agreements with Pretzel Time. Franchisee
acknowledges and agrees that Pretzel Time is under no obligation to approve a relocation of the
Franchise. However, upon written approval from Pretzel Time, Franchisee may relocate the Franchise
to another location. Such approval shall not be granted unless Franchisee is in compliance with all
terms and conditions of this Agreement and Franchisee has the financial resources available to
relocate the Unit and construct a new and comparable Unit according to Pretzel Time's then current
design standards. Any such relocation of the Franchise is subject to Pretzel Time's prior approval
of the new Unit location. Relocation shall be at Franchisee's sole expense and Pretzel Time shall
have the right to charge Franchisee for any and all costs incurred by Pretzel Time, and a reasonable
fee for its services, in connection with any such approval, evaluation and relocation of the
Franchise. The Unit shall re-open at the replacement Site as soon as reasonably practicable but in
no event more than ninety (90) days after the closing of the original location.

8. DEVELOPMENT OF UNIT.

8.A. UNIT DESIGN SPECIFICATIONS AND CONSTRUCTION PLANS.

Franchisee shall be responsible for constructing and developing the Unit, including payment of all
costs. Pretzel Time shall furnish to Franchisee prototypical plans and specifications for the Unit,
reflecting Pretzel Time's requirements for dimensions, interior design and decor, layout, image,
building materials, color scheme, exterior and interior finishes, fixtures, equipment, furnishings,
and signs.

Franchisee shall promptly after obtaining approval of the Site for the Franchise:

(1). cause to be prepared by a Pretzel Time approved architect and
<!-- page 15 -->
submit for approval by Pretzel Time a site survey and any modifications to Pretzel Time's basic
architectural plans and specifications for the Pretzel Time Unit (including requirements for
dimensions, exterior design, materials, interior design and layout, equipment, fixtures, furniture,
signs and decorating) required for the construction of the Franchise at the Site leased therefor.
Franchisee shall have all such modifications approved by Pretzel Time and prior to obtaining
permitting;

(2). insure that such plans and specifications comply with applicable ordinances, building codes,
and permit requirements and with lease requirements and restrictions and all modification to Pretzel
Time's basic plans and specifications are modified to the extent necessary to comply with local
ordinances and state laws, building codes, permit requirements, lease restrictions and federal law;
and

(3). Franchisee shall also submit all revised or "as built" plans and specifications during the
course of such construction upon request of Pretzel Time. Franchisee agrees to pay for any and all
architect fees and pay the architectural fees for the architect to review, approve and modify the
plans.

8.B. DEVELOPMENT OF THE UNIT.

Pretzel Time shall have the right to approve any contractor hired by Franchisee to develop the Unit.
Within one-hundred twenty (120) days of the execution of the Franchise Agreement, Franchisee agrees,
at his sole expense, to do or cause to be done the following with respect to developing the Unit:

(1). Familiarizing himself with the physical condition of the property, local laws, ordinances and
other requirements in connection with the construction of the Unit;

(2). Secure all financing required to develop and operate the Unit;

(3). Obtain all required building, utility, sign, health, sanitation, business, environmental and
other permits and licenses required for construction and operation of the Unit;

(4). Extending all utilities to the Site and constructing all required improvements to the Unit and
decorate the Unit in compliance with plans and specifications Pretzel Time approves within four to
six weeks of possession of the Site and two days prior to the commencement date set forth in the
lease for the Unit;

(5). Purchase and install all required fixtures, furnishings, equipment and signs required for the
Unit (provided, however, that Pretzel Time shall have the right, in its sole discretion, to install
all required signs at the Unit at Franchisee's sole expense);

(6). Purchase an opening inventory of Products, materials, and supplies;

(7). In accordance with Pretzel Time's standard specifications, Franchisee shall totally equip,
ready and inventory the Site at its sole cost for opening to the public two (2) days prior to the
opening date specified in the lease; and

(8). Franchisee agrees that it will not open the Unit for business without Pretzel Time's prior
approval and training.

8.C. EQUIPMENT, FIXTURES, FURNISHINGS, AND SIGNS.

Franchisee agrees to use in developing and operating the Unit only such fixtures, furnishings,
equipment, and signs that Pretzel Time requires and has approved for Pretzel Time Units as meeting
its specifications and standards for quality, design, appearance, function and performance.
Franchisee further agrees to place or display at the Unit only such signs, emblems, lettering, logos
and display materials that Pretzel Time approves in writing from time to time; provided, however,
that Pretzel Time shall have the right, in its sole discretion, to install all required signs at the
Unit at Franchisee's sole expense. Franchisee shall purchase or lease approved brands, types or
models of fixtures, furnishings, equipment and signs only from suppliers designated or approved by
Pretzel Time (which may include Pretzel Time and/or its Affiliates). Franchisee further agrees that
all fixtures, furnishings and equipment used in connection with the operation of the Unit shall be
free and clear of all liens, claims and encumbrances whatsoever, except with respect to any such
liens, claims or encumbrances asserted by Pretzel Time or third party purchase money security
interests.

8.D. EXCEPTIONS TO EQUIPMENT OR FURNISHINGS.

If Franchisee proposes to purchase any brand or type of construction or decorating material,
fixture, equipment, furniture or sign not then approved by Pretzel Time, or any such item from a
supplier which is not then approved by Pretzel Time, Franchisee shall first notify Pretzel Time, in
writing, and shall submit to Pretzel Time, upon its request, sufficient specifications, photographs,
drawings and other information or samples for a determination by Pretzel Time of whether such brand
or type of construction or decorating material, fixture, equipment, furniture or sign complies with
its specifications and standards or such supplier meets Pretzel Time's approved supplier criteria,
which determination shall be made and communicated in writing to Franchisee within a reasonable
time. Additionally, Franchisee shall pay all fees for said
<!-- page 16 -->
testing and be responsible for acquiring and submitting equipment necessary for such testing.

8.E. CONSTRUCTION ASSISTANCE.

Upon request by Franchisee and without liability, Pretzel Time agrees to provide construction
assistance to Franchisee in one or more of the following areas:

(1). Assist Franchisee in finding an architect for the construction and development of the Unit;

(2). Assist Franchisee in finding a general contractor for the construction and development of the
Unit; and

(3). Respond to a reasonable amount of questions from Franchisee's contractor relating to
construction and development of the Unit in accordance with the requirements of Pretzel Time.

8.F. LIMITATION ON LIABILITY.

Pretzel Time shall not be liable to Franchisee, the contractor, or any other person, and Franchisee
waives all claims for liability or damages of any type whatsoever (whether direct, indirect,
incidental, consequential, or exemplary), on account of the rendition of any services by Pretzel
Time in accordance with this Section, except to the extent caused by the gross negligence or
intentional misconduct of Pretzel Time, and then any such liability or damages shall be limited to
five thousand dollars ($5,000.00). Without limiting the generality of the foregoing, Pretzel Time
shall not have liability with respect to any of the following, all of which are the sole
responsibility of Franchisee:

(1). if construction of the Unit does not fully satisfy the requirements (if any) of the landlord,
the architect, the contractor, and any governmental agency having jurisdiction or does not fully
satisfy the criteria established by Pretzel Time for construction and development of Pretzel Time
Units;

(2). if the Unit improvements are not structurally sound or free from defects or deficiencies;

(3). if there are any construction delays or cost overruns; or

(4). if there are any disputes with any landlord, contractor, subcontractor, architect, supplier or
governmental agency with respect to any aspect of the design, construction, provision, or equipping
of the Unit.

9. UNIT OPENING.

9.A. COMMENCEMENT OF OPERATIONS.

Franchisee shall commence operation of the Franchise the earlier of: 1) one hundred fifty (150) days
after the execution of this Agreement; (2) as specified in the lease for the Site; or (3) as
otherwise required or approved in writing by Pretzel Time. Failure to open the Unit within the
aforementioned time period shall result in the termination of this Franchise Agreement and all
franchise fees paid by Franchisee shall be nonrefundable. Franchisee agrees not to open the Unit for
business until the following has occurred:

(1). Pretzel Time approves the Unit pursuant to its Pre-Opening Checklist;

(2). Pre-opening training of Franchisee and Unit personnel has been completed to Pretzel Time's
satisfaction;

(3). The initial franchise fee and all other amounts then due to Pretzel Time have been paid in
full;

(4). Pretzel Time has been furnished with copies of all insurance policies required by this
Agreement, or such other evidence of insurance coverage and payment of premiums as Pretzel Time
requests; and

(5) Franchisee has executed Pretzel Time's wire transfer agreement.

Franchisee agrees to open the Unit for business on or before the opening date specified in the lease
if it has the Landlord's approval and only after Pretzel Time notifies Franchisee that the
conditions set forth in Sections 8 and 9 have been satisfied.

10. FRANCHISEE TRAINING.

10.A. INITIAL TRAINING.

Franchisee acknowledges and agrees that, while Pretzel Time's training program will provide
Franchisee with the fundamental knowledge necessary to operate a unit, Franchisee cannot expect
success unless he devotes his best personal efforts to the business and exercises good business
judgment in dealing with customers, suppliers, and employees. Prior to the Unit's opening, Pretzel
Time shall furnish an initial training program on the operation of a Pretzel Time Unit which shall
take place at Pretzel Time's headquarters in Harrisburg, Pennsylvania, or at a location which will
provide the best training for the
<!-- page 17 -->
Franchisee, which may or may not be close to Pretzel Time's headquarters. The Franchisee agrees that
he and his Unit Manager shall attend the initial training session held four (4) to eight (8) weeks
prior to the Unit's projected opening date. Pretzel Time will not charge for the initial training of
the Franchisee or if a corporation or partnership, the Principal Owners of the Franchisee and the
Unit Manager. All incidental expenses relative to the required training, including travel expenses,
hotel/motel expenses, and meals shall be the responsibility of the Franchisee while attending
training. Prior to the commencement of the operation of the Unit, the manager of the Unit ("Unit
Manager") and the Franchisee or if a corporation or partnership, one Owner of the Franchisee as
identified in Exhibit B, who will be personally overseeing the Unit shall attend and successfully
complete the Pretzel Time initial training program to the satisfaction of Pretzel Time.

The Franchisee and his Unit Manager must satisfactorily complete Pretzel Time's training as
determined by Pretzel Time, in its sole opinion, before Franchisee is allowed to operate the
Franchise. If Pretzel Time, in its sole discretion, determines that Franchisee is unable to
satisfactorily complete the training program, Pretzel Time shall have the right to terminate this
Agreement and no franchise fees shall be refunded. The initial training program shall cover material
aspects of the operation of a Pretzel Time Unit, including financial controls, employee relations,
food preparation, service and operational techniques, sampling, recipes and cooking procedures,
marketing and public relations, cleanliness and maintenance procedures, and maintenance of Pretzel
Time System standards. Franchisee shall receive one copy of the Operations Manual, which cannot be
reproduced, in whole or in part. In the event that the Franchisee's copy is lost destroyed or
significantly damaged, Franchisee shall be obligated to obtain from Pretzel Time, at Franchisee's
expense a replacement copy of the Operations Manual.

10.B. EMPLOYEE TRAINING.

Pretzel Time may provide to Franchisee, at Franchisee's request, guidance in the selection of a Unit
Manager and may provide periodic evaluations of Franchisee's Unit, Managers and employees, but
without any liability therefore to Pretzel Time. Franchisee shall hire all employees of the
franchise, be exclusively responsible for the terms of their employment and compensation, and
implement a training program for employees of the franchise. Franchisee agrees to maintain a staff
of trained employees to operate the Unit in compliance with Pretzel Time's standards.

In the event the Unit Manager ceases to hold such full-time position at the Unit, Franchisee shall
have thirty (30) days in which to appoint a substitute or replacement Unit Manager, who must attend
and successfully complete, to Pretzel Time's satisfaction the initial training program as specified
above within sixty (60) days after employment as Unit Manager. If Pretzel Time in its sole
discretion determines that the Unit Manager or any subsequently appointed Unit Manager has failed to
satisfactorily complete the initial training program or any additional or refresher training
program, Franchisee agrees to immediately hire a substitute Unit Manager and promptly arrange for
such person to complete the initial training program to the satisfaction of Pretzel Time. Franchisee
agrees to notify Pretzel Time of any new Unit Managers for the Unit within seven (7) business days
of their employment. In the event Franchisee operates more than one (1) Unit, at least one (1)
trained and competent Unit Manager referred to above shall act as a full-time manager in each
Territory. Franchisee shall keep Pretzel Time informed at all times of the identity of any Unit
Manager(s) of the Unit.

All Unit Managers of the Unit must have successfully completed an initial training program as
specified by Pretzel Time at the sole expense of the Franchisee, including, but not limited to,
salary and incidental travel expenses attendant to any training provided by Pretzel Time. Franchisee
and Unit Managers who successfully complete training will receive a Training Certificate from
Pretzel Time. Pretzel Time shall make training available to Franchisee's Unit Manager during Pretzel
Time's regularly scheduled training course. In no event, will Pretzel Time be under any obligation
to provide individual training to Franchisee's Unit Managers. Franchisee agrees that each Unit
Manager shall participate at Franchisee's expense in Pretzel Time's initial training program and all
other mandatory training programs which may subsequently be offered by Pretzel Time.

10.C. ON-SITE TRAINING.

Additionally, Pretzel Time will provide on-site training at Franchisee's business location for a
period of five (5) days, generally to be commenced immediately prior to Franchisee's day of opening
and continued the first three (3) days of operation. Franchisee herein agrees to notify Pretzel
Time, in writing, of his opening date twenty (20) days prior thereto. This training will include all
functions required for the proper operation of the franchise.

Should Franchisee request additional assistance from Pretzel Time in order to facilitate the opening
of the Franchise, and should Pretzel Time, in its discretion, deem it necessary, feasible and
appropriate to comply with the request or should Pretzel Time determine that additional training is
required, Franchisee shall reimburse Pretzel Time at Pretzel Time's then current daily training
service fee, for the expense of Pretzel Time providing such additional assistance and for its
training related expenses, which may include, travel, room and board.

10.D. COMPANY GROWTH.

Throughout the term of this Agreement, Pretzel Time may provide Franchisee with information on
company growth and operations as well as new
<!-- page 18 -->
techniques developed to reduce costs and/or enhance sales or profits.

10.E. RETRAINING PROGRAMS.

Pretzel Time shall provide re-training programs at a location of Pretzel Time's choice from time to
time for experienced franchisees and their managers and/or employees. Pretzel Time may charge fees
for refresher training courses for previously trained and experienced managers. Fees for special
programs will be based upon Pretzel Time's actual costs and attendance shall be required. Attendance
at retraining programs or seminars shall be at Franchisee's sole expense, provided, however, that
attendance will not be required at more than two (2) such programs in any calendar year and shall
not collectively exceed ten (10) business days in duration during any calendar year.

10.F. OTHER GUIDANCE.

Pretzel Time may advise Franchisee from time to time of operating problems of the Unit which come to
Pretzel Time's attention and, at Franchisee's request but without any liability therefore to Pretzel
Time, Pretzel Time shall furnish to Franchisee guidance in connection with: (i) Methods, standards,
specifications and operating procedures utilized by Pretzel Time Units;

(ii) Purchasing required fixtures, furnishings, equipment, signs, Products, materials and supplies;

(iii) Advertising and Promotional programs;

(iv) Employee training; and

(v) Administrative, bookkeeping, accounting and general operating and management procedures.

Such guidance shall, in Pretzel Time's discretion, be furnished in the form of Pretzel Time's
Operations Manual, bulletins and other written materials, electronic computer messages, telephone
conversations and/or consultations at Pretzel Time's offices or at the Unit. Pretzel Time will make
no separate charge to Franchisee for such operating assistance as Pretzel Time customarily provides.
From time to time, Pretzel Time may make special assistance programs available to Franchisee,
however, Franchisee will be required to pay the per diem fees and charges that Pretzel Time
establishes from time to time for such special assistance programs.

11. ADVERTISING AND OTHER PROMOTIONS.

11.A. PROVIDING OF ADVERTISING MATERIALS.

Franchisee and Pretzel Time agree and recognize the value of uniform advertising to the goodwill and
public image of Pretzel Time Units. Pretzel Time has instituted and maintains and administers an
advertising fund for such advertising or public relations programs as Pretzel Time, in its sole
discretion, may deem necessary or appropriate to advertise or promote the Pretzel Time System,
nationally or regionally. Pretzel Time will periodically provide Franchisee with programs,
promotional concepts, and other information designed to enhance the operation of the Franchise. In
addition, Pretzel Time may provide optional special promotions from time to time which will be at
Franchisee's cost, which may be mandatory. At its initial opening, Pretzel Time, at Franchisee's
expense, shall designate and supply an initial quantity of forms, literature, display, and
promotional materials. Pretzel Time, in consideration of the Advertising Fund Fee, shall
periodically provide Franchisee with camera ready advertising materials. Multiple copies of
advertising materials will be furnished to Franchisee for an additional fee, including any related
shipping, handling and storage charges.

11.B. CONTROL OF ADVERTISING PROGRAMS AND CONCEPTS.

Pretzel Time shall direct all such programs, with sole discretion over the creative concepts,
materials, endorsements, and media used therein, and the placement and allocation thereof. The
manner, media and cost of such advertising, public relations and promotional mailings shall be
solely and completely within the discretion of Pretzel Time. Pretzel Time shall have the right to
determine, in its sole discretion, the target and market areas for the development and
implementation of such programs. Pretzel Time may expend, disburse and use funds from the
Advertising Fund, in its sole discretion, for the following purposes:

(1) The creation and development of nonlocal advertising, promotional campaigns, and public
relations to promote and enhance the value of the Service Marks and the business of all the Pretzel
Time retail establishments;

(2) Payments to Pretzel Time of such reasonable sums as may be necessary for actual costs of
advertising production, direct mail purchases, and other media marketing tools;

(3) Payment of salaries and benefits for staff personnel in the marketing and public relations
department as well as other administrative costs and overhead expenses of the department incurred by
Pretzel Time;

(4) The costs of employing advertising, marketing, public relations and promotion agencies to assist
in preparing and conducting media programs and activities and supporting public relations, market
<!-- page 19 -->
research and other advertising, promotion and marketing activities;

(5) Market research expenditures related to the development and evaluation of the effectiveness of
advertising and sales promotion; and

(6) Costs of organizing and providing facilities for international, national, or regional franchisee
conferences.

Franchisee understands and acknowledges that the Advertising Fund is intended to maximize
recognition of the Marks and patronage of Pretzel Time Units. Although Pretzel Time will endeavor to
utilize the Advertising Fund to develop advertising and marketing materials and programs and to
place advertising that will benefit all Pretzel Time Units, Pretzel Time undertakes no obligation to
ensure that expenditures by the Advertising Fund in or affecting any geographic area are
proportionate or equivalent to the contributions to the Advertising Fund by Pretzel Time Units
operating in that geographic area or that any Pretzel Time Units will benefit directly or in
proportion to its contribution to the Advertising Fund from the development of advertising and
marketing materials or the placement of Advertising.

11.C. SEGREGATION OF ADVERTISING FUND.

Pretzel Time herein agrees to administratively segregate the Advertising Fund on its books and
records. Fees paid by Franchisee into the advertising fund shall not under any circumstance be used
for the general operating expenses of Pretzel Time but shall and will be used exclusively for
advertising as outlined herein. Pretzel Time may spend in any fiscal year an amount greater or less
than the aggregate contributions of the franchisees to the fund in that year and Pretzel Time may
make loans to the fund bearing reasonable interest to cover any deficits of the fund and cause the
fund to invest any surplus for future use by the fund. It is anticipated, and it is the intent of
Pretzel Time that all contributions to the Fund shall be expended for advertising and promotional
purposes during Pretzel Time's fiscal year within which contributions are made. Any monies not
expended in the fiscal year in which they were contributed shall be applied and used for Fund
expenses in the following year.

11.D. SUSPENSION OF ADVERTISING FUND FEES.

Pretzel Time reserves the right to suspend contributions/fees and operations of the Advertising Fund
for one or more periods, and the right to terminate the Advertising Fund, upon thirty (30) days'
prior written notice to Franchisee. All unspent monies on the date of termination shall be
distributed to Pretzel Time's franchisees and Pretzel Time, its Affiliates and designees in
proportion to their respective contributions to the Advertising Fund upon the same terms and
conditions set forth herein upon thirty (30) days' prior written notice Franchisee.

11.E. FRANCHISEE'S REQUIRED ADVERTISING EXPENDITURES.

In addition to any contributions by Franchisee to the Advertising Fund, Franchisee is required to
spend on marketing and related programs such amount as is required pursuant to the terms and
conditions of Franchisee's lease or sublease. Franchisee acknowledges such amounts will vary from
lease to lease, and therefore, all Pretzel Time Unit franchisees will not be obligated to expend the
same amount on local advertising and marketing of the Unit.

11.F. USE OF TRADEMARK REFERENCES AND APPROVAL OF FRANCHISEE'S MARKETING.

Franchisee further agrees that all advertising, promotion and marketing by Franchisee shall be
completely clear and factual and not misleading and shall conform to the highest standards of
ethical marketing and promotion policies which may be prescribed from time to time by Pretzel Time.
Franchisee agrees to use the registration symbol of "R" within a circle (7 ) in connection with its
use of the Marks. Franchisee agrees to refrain from any business or marketing practice which may be
injurious to the business of Pretzel Time and the good will associated with the Marks and other
Pretzel Time Units. Prior to their use by Franchisee, all press releases, literature, and samples of
all local advertising, marketing, point-of-purchase, and related materials not prepared or
previously approved by Pretzel Time shall be submitted to Pretzel Time for approval, which shall not
be unreasonably withheld. If written disapproval is not received within twenty (20) days from the
date of receipt by Pretzel Time of such materials, Pretzel Time shall be deemed to have approved the
materials. Franchisee agrees not to use promotional or advertising materials which have been
disapproved by Pretzel Time or that have not been approved for use within the preceding twelve
months.

In addition, any pamphlets, brochures, cards or other promotional materials offering free Products
may only be used if prepared by Pretzel Time, unless otherwise approved in advance by Pretzel Time.
Notwithstanding the foregoing, Pretzel Time will give favorable consideration to Franchisee's use of
free product cards developed by Franchisee, if the cards clearly state that they may only be
redeemed at Pretzel Time Units owned by Franchisee. Franchisee agrees to list and advertise the
Franchise in the regular white pages telephone directories distributed within Franchisee's
metropolitan area.

Franchisee agrees to distribute and display at Franchisee's location, literature, display and
promotional materials including special promotional materials as Pretzel Time may from time to time
make available. Franchisee agrees that only those advertising, promotional materials, or items which
are authorized by Pretzel Time in writing prior to use shall be used, sold or
<!-- page 20 -->
distributed, and no alternate display or use of the Pretzel Time Service Mark shall be made without
the prior written permission of Pretzel Time. Replacement or updated literature, display,
point-of-purchase and promotional materials may be obtained from Pretzel Time for a fee including
shipping.

12. ADHERENCE TO UNIFORM STANDARDS.

12.A. STANDARDS AND OPERATIONS MANUAL.

Franchisee acknowledges and agrees that the operation of the Pretzel Time Unit in accordance with
the specifications, standards, operating procedures and rules Pretzel Time prescribes for the
operation of Pretzel Time Units is the essence of this Agreement and is essential to preserve the
goodwill of the Marks and all Pretzel Time Units. Franchisee agrees to operate his Unit in strict
compliance and adhere to Pretzel Time's Unit design, signage, interior decor, equipment and
inventory requirements and rules and standards and procedures (hereinafter referred to as
"Standards") set forth in any Operations Manual or Training Manual, as periodically modified and
supplemented by Pretzel Time in its discretion during the term of this Agreement ("Operations
Manual") and acknowledges that the same are reasonable, necessary and essential to the image and
success of each Unit and the Pretzel Time System and agrees to comply with all such requirements and
procedures. The Operations Manual shall contain mandatory and suggested specifications, standards
and operating procedures that Pretzel Time prescribes from time to time for Pretzel Time Units and
information relating to Franchisee's other obligations under this Agreement. The Operations Manual
sets forth Standards regulating and relating to certain important obligations on the part of
franchisees and sanctions in the event of noncompliance with such obligations. Pretzel Time may
regulate, designate or approve any one or more of the following with respect to the Pretzel Time
Unit:

(1) Design, layout, decor, appearance and lighting; periodic and daily maintenance, cleaning and
sanitation; replacement of obsolete or worn-out fixtures, furnishings, equipment and signs; use of
interior and exterior signs, emblems, lettering and logos and the illumination thereof;

(2) Types, models, brands, maintenance and replacement of required equipment, fixtures, furnishings
and signs;

(3) Approved, disapproved and required Products and other items to be offered for sale;

(4) Designated and approved suppliers (including Pretzel Time and/or its Affiliates) of equipment,
fixtures, furnishings, signs, Products, materials and supplies;

(5) Use and operation of an approved point of sale register;

(6) Payment of vendors; terms and conditions of sale and delivery of and payment for Products,
materials, supplies and services sold by Pretzel Time, its Affiliates or unaffiliated suppliers;

(7) Marketing, advertising and promotional activities and materials required or authorized for use;

(8) Use of the Marks;

(9) Qualifications, training, dress, appearance and staffing of employees;

(10) Minimum hours of operation;

(11) Participation in market research and testing and Product and service development programs
prescribed by Pretzel Time;

(12) Management by Unit Managers who have successfully completed Pretzel Time's initial training
program; communication to Pretzel Time of the identities of such Unit Managers; replacement of
managers whom Pretzel Time determines to be unqualified to manage the Pretzel Time Unit; and other
matters relating to the management of the Pretzel Time Unit and its management personnel;

(13) Use of a designated computer hardware and software system and equipment with telecommunications
capability, including the procedures for providing sales information of the Unit to Pretzel Time;

(14) Bookkeeping, accounting, data processing and record keeping systems and forms, methods,
formats, content and frequency of reports to Pretzel Time of sales, revenues, financial performance
and condition; operational information; tax returns and other operating and financial information,
including without limitation, audited yearly financial statements;

(15) Types, amounts, terms and conditions and approved underwriters and brokers of public, product,
business interruption, crime loss, fire and other required insurance coverage; Pretzel Time's rights
under such policies as an additional named insured; required or impermissible insurance contract
provisions; assignment of policy rights to Pretzel Time; Pretzel Time's right to obtain insurance
coverage for the Unit at Franchisee's expense if Franchisee fails to obtain required coverage;
Pretzel Time's right to defend claims; and similar matters relating to
<!-- page 21 -->
insured and uninsured claims;

(16) Compliance with applicable laws; obtaining required licenses and permits; adherence to good
business practices; observing high standards of honesty, integrity, fair dealing and ethical
business conduct in all dealings with customers, suppliers and Pretzel Time and its Affiliates
and/or designees; and notification of Pretzel Time in the event any action, suit or proceeding is
commenced against Franchisee or relating to the Unit; and

(17) Regulation of such other elements and aspects of the appearance, operation of and conduct of
business by, Pretzel Time Units as Pretzel Time determines from time to time, in its sole
discretion, to be required to preserve or enhance the efficient operation, image or goodwill of
Pretzel Time Units and the Marks.

12.B. CONFIDENTIALITY OF OPERATIONS MANUAL.

Pretzel Time will make available to Franchisee during the term of the Franchise (1) copy of the
Operations Manual by loaning a copy of the Operations Manual to Franchisee. Franchisee acknowledges
and agrees that all manuals loaned to Franchisee contain confidential and proprietary material and
information of Pretzel Time provided to Franchisee is to be used by Franchisee only in connection
with the operation of the franchised Unit and other Pretzel Time Units. The Operations Manual
contains trade secrets and confidential information and will remain the property of Pretzel Time and
shall be returned to it on termination of this Agreement. Franchisee covenants not to reveal the
contents of the Operations Manual to unauthorized persons. Franchisee may not, at any time, copy the
Operations Manual, in whole or in part, either physically or electronically. In the event
Franchisee's copy of the Operations Manual is lost, destroyed or significantly damaged, Franchisee
shall be obligated to obtain from Pretzel Time, at Pretzel Time's then applicable charge, a
replacement copy of the Operations Manual.

12.C. INCORPORATION OF OPERATIONS MANUAL INTO AGREEMENT.

The Operations Manual's specifications, standards, and operating procedures communicated to
Franchisee in writing shall be deemed a part of this Agreement and are incorporated herein by
reference. Such Operations Manual provisions and all reasonable modifications shall be binding upon
Franchisee to the same extent as if set forth verbatim in this Franchise Agreement, and such
provisions may be changed from time to time by Pretzel Time, in its sole discretion, provided that
changes are reasonably designed to enhance Pretzel Time's Products, the Pretzel Time System, or
franchise operation and are uniformly applied with respect to all franchisees. Any administrative or
financial Section set forth in the Operations Manual shall be in addition to, and not in derogation
or limitation of, any right or remedy granted to Pretzel Time under the Franchise Agreement, the
Operations Manual, or any other document, or otherwise available to Pretzel Time, at law or in
equity, including, without limitation, the right to terminate a franchise in the event of certain
defaults or delinquencies.

12.D. MODIFICATIONS/UPDATES OF OPERATIONS MANUAL.

Franchisee understands and agrees that the Pretzel Time System is constantly being modified and
improved, and that such modifications and improvements require changes from time to time in the
system of operations. Franchisee further agrees to accept and comply with such modifications,
revisions, and additions to the Pretzel Time System and Operations Manual which Pretzel Time in the
good faith exercise of its judgment believes to be desirable and reasonably necessary in the time
period indicated by Pretzel Time.

Franchisee agrees that Standards may be periodically modified by Pretzel Time and that such
modifications may obligate Franchisee to invest additional capital in the Unit and/or incur higher
operating costs. Pretzel Time will not obligate Franchisee to invest additional capital at a time
when such investment cannot in Pretzel Time's reasonable judgment be amortized during the remaining
term of this Agreement. Franchisee hereby agrees that standards and specifications prescribed from
time to time in the Operations Manual, or otherwise communicated to Franchisee in writing or
electronically, shall constitute provisions of this Agreement as if fully set forth herein.

13. UNIT IMAGE AND OPERATION.

13.A. CONDITION AND APPEARANCE OF UNIT.

Franchisee agrees that:

(1) neither the Unit nor the Site will be used for any purpose other than the operation of a Pretzel
Time Unit in full compliance with this Agreement or other agreements with Pretzel Time; and

(2) Franchisee will maintain the condition and appearance of the Unit, its equipment, furnishings,
fixtures, and signs in accordance with the specifications and standards of Pretzel Time and
consistent with the image of a Pretzel Time Unit as a first-class, clean, sanitary, attractive and
efficiently operated food service business; and

(3) Franchisee will perform such maintenance (including, without limitation, maintenance procedures
and routines which Pretzel Time prescribes from time to time) with respect to the decor,
<!-- page 22 -->
equipment, fixtures, furnishings, vehicles, and signs of the Unit and the Site, as may be required
or directed by Pretzel Time from time to time to maintain such condition, appearance, and efficient
operation, including, without limitation:

(a) continuous and thorough cleaning and sanitation of the interior and exterior of the Unit;

(b) thorough repainting and redecorating of the interior and exterior of the Unit and/or the Site at
reasonable intervals;

(c) interior and exterior repair of the Unit and/or Site; and

(d) repair or replacement of damaged, worn out or obsolete furnishings, equipment, fixtures and
signs, provided that Pretzel Time will not require Franchisee to replace any obsolete equipment
unless Pretzel Time has initiated a program to replace such equipment as it becomes necessary in its
company-owned Pretzel Time Units; and

(4) Franchisee will not make any material alterations to the Site or to the appearance of the Unit
as originally developed, without prior approval in writing by Pretzel Time; and

(5) Upon notice from Pretzel Time, Franchisee shall remodel and conform Franchisee's building
design, Trade Dress, color schemes, and presentation of Marks to Pretzel Time's then current public
image within a reasonable amount of time, which shall not exceed six (6) months. Such a remodeling
may include extensive structural changes to the Unit fixtures and improvements as well as such other
changes as Pretzel Time may direct and Franchisee shall undertake such a program promptly upon
notice from Pretzel Time; provided the remodeling shall not be required until such time as Pretzel
Time has commenced or completed a similar program in at least fifty percent (50%) of those Pretzel
Time Units owned and operated by Pretzel Time. This requirement shall not apply in the event notice
from Pretzel Time is received during the last year of the term hereof or the term of any agreement
by virtue of which Franchisee occupies the Unit.

In addition to Pretzel Time's rights to terminate this Agreement as set forth herein, if Franchisee
does not maintain the condition and appearance of the Unit as herein required, Pretzel Time, may,
upon not less than ten (10) days' written notice (or, in cases of health or sanitation hazards or
other public endangerment, immediately on oral or written notice) to Franchisee:

(i) arrange for the necessary cleaning or sanitation, repair, remodeling, upgrading, painting or
decorating; or

(ii) replace the necessary fixtures, furnishings, equipment, signs.

If Franchisee fails or refuses to initiate within ten (10) days after receipt of a notice that the
general state of repair, appearance, and cleanliness of your store does not meet Pretzel Time's
standards, and thereafter continue in good faith and with due diligence a bona fide program to
undertake and complete required maintenance or refurbishing, Pretzel Time has the right, but is not
obligated, to enter upon the premises of the Unit and effect such maintenance and refurbishing on
Franchisee's behalf, and Franchisee shall pay the entire cost thereof to Pretzel Time on demand.

13.B. UNIT MENU.

Franchisee agrees that the Unit shall offer for sale all Products and no other products, which
Pretzel Time, in its sole discretion, may authorize and/or require from time to time for the Unit.
Franchisee agrees that the Unit shall not offer for sale or sell any Products or services at or from
the Unit which have not been approved in writing by Pretzel Time or use the Site or Unit for any
purpose other than the operation of a Pretzel Time Unit. Franchisee agrees that the Unit shall not
sell any Products at, from or away from the Site until Pretzel Time, in its sole discretion, has
approved the same, provided the foregoing shall not limit Franchisee to sample in front of the lease
line as limited in Franchisee's lease. Pretzel Time reserves the right to change the types of
authorized Products and require Franchisee to offer to sell and sell the new, modified or
substituted Products. Pretzel Time may develop new Products, methods of operations, and standards
and may provide you with information about developments. Franchisee also acknowledges and agrees
that if Pretzel Time requires the Unit to use new or substitute products not currently offered at
Pretzel Time Units, Franchisee agrees to offer such Products in compliance with Pretzel Time's
specifications, standards and procedures prescribed in the Operations Manuals or otherwise in
writing and to diligently pursue obtaining any permits and take such actions (including, without
limitation, constructing improvements and acquiring fixtures, furnishings, equipment, supplies, and
materials) required to offer such Products. Franchisee acknowledges and understands that such
modifications to the Products to be offered by the Unit may require Franchisee to incur additional
costs and expenses to operate the Unit, including, without limitation, the purchase and/or lease of
additional or substitute furnishings, furniture, fixtures or equipment and Franchisee agrees to
incur such expenses in connection therewith.

13.C. ADHERENCE TO APPROVED ITEMS.
<!-- page 23 -->
The reputation and goodwill of all Pretzel Time Units are based upon, and can only be maintained by,
the sale of distinctive, high-quality Products and the presentation, packaging and service of
Products in an efficient and appealing manner. Pretzel Time has developed and shall continue to
develop certain proprietary food products which will be prepared by or for Pretzel Time according to
Pretzel Time's recipes and formulas. Pretzel Time has developed and shall continue to develop
standards and specifications for fresh hand-rolled pretzels, frozen pretzels, pretzel toppings,
beverages and other healthy snack food products, materials and supplies incorporated in or used in
the preparation, baking, or serving of Products authorized by Pretzel Time. The need for quality and
quantity control in the Products offered for sale at the Unit is acknowledged by Franchisee. All
Products offered by Franchisee must be of uniform quality and quantity and offered for sale to the
public in accordance with Pretzel Time's specifications as set forth in Pretzel Time's Operations
Manual and as may be amended from time to time.

Pretzel Time has approved and shall review and continue to approve suppliers and distributors of the
foregoing Products, supplies, materials, equipment, fixtures and machines that meet Pretzel Time's
standards and requirements including, without limitation, quality, quantity and portions, prices,
output requirements, distribution methods and locations, standards of service, financial capability,
customer service and other criteria. Franchisee agrees that minimum standards for items of
inventory, Products, machines, and equipment may be recognized by brand name rather than by
technical or engineering description.

Franchisee agrees that it will use all equipment and Products, including, without limitation, food
products, smallwares, equipment, and paper products as designated by Pretzel Time and shall purchase
Pretzel Time's private label food products, materials, supplies and proprietary food products,
ingredients, spices, sauces, mixes, beverages, materials and supplies used in the preparation of
Products developed by or for Pretzel Time or its Affiliates whether or not pursuant to a special
recipe or formula or bearing the Marks only from Pretzel Time, its Affiliates or non-affiliated
sources designated by Pretzel Time. Franchisee further agrees to purchase only from distributors and
suppliers approved or required by Pretzel Time. Franchisee agrees that the approved Products,
equipment, smallwares, and inventory used on the premises may alter from time to time as Pretzel
Time reasonably deems necessary. Franchisee agrees to offer for sale only those Products approved by
Pretzel Time and no others without the prior written approval of Pretzel Time. Franchisee shall not,
after receipt in writing of any modification of an approved or required supplier or distributor,
manufacturer of equipment, products, materials, supplies or other items reorder any product from any
supplier or distributor that is no longer approved. Pretzel Time may approve or require a single
distributor or supplier for any Products, materials or supplies and may approve or require a
distributor or supplier only as to certain products, materials and supplies, and such approval may
be temporary pending a further evaluation of such distributor or supplier by Pretzel Time. Pretzel
Time may concentrate purchases with one or more distributors or suppliers to obtain lower prices
and/or advertising support and/or services for the benefit of Pretzel Time, the Pretzel Time System
and/or Pretzel Time Units.

Pretzel Time will loan to Franchisee a list of approved brand Products for use during the term of
this Franchise Agreement at the initial training session. Franchisee agrees to not copy the list.
Franchisee will, during the term of this Agreement and after its termination or expiration, maintain
the list and its contents in strict confidence, and upon the expiration or termination of this
Franchise Agreement, whichever is earlier, will immediately return it to Pretzel Time. Pretzel Time
shall promptly provide Franchisee with any amendments to the designated list of inventory of
available Products and supplies to be carried and sold at Franchisee's location. Franchisee shall at
all times maintain an adequate inventory of approved Products sufficient in quality and variety to
realize the full potential of the Unit.

13.D. EXCEPTION PROCESS.

If Franchisee proposes to purchase materials or supplies not theretofore approved by Pretzel Time as
meeting its specifications, or from a supplier or distributor not previously approved by Pretzel
Time, Franchisee shall first notify Pretzel Time and request Pretzel Time's approval using the
special exception form provided to Franchisee in its Operations Manual, and pay any reasonable fees
that Pretzel Time designates therefor. Further, Franchisee agrees to use all forms specified and
developed by Pretzel Time for requesting any exceptions in products or suppliers. Pretzel Time may
require submission of sufficient information and samples to determine whether such materials,
supplies or suppliers meet its specifications as well as financial information regarding the
supplier. Pretzel Time will advise Franchisee within a reasonable time whether such

materials or supplies meet its specifications. Pretzel Time does not maintain a formal criteria for
approving materials, supplies or suppliers. All approvals, disapprovals and revocations of approval
of suppliers will be communicated to Franchisee, in writing, and shall be in the sole discretion of
Pretzel Time. Franchisee must comply with the following conditions in order to seek a substitution
for a Pretzel Time approved Product:

(1) Franchisee shall submit a written request to Pretzel Time
<!-- page 24 -->
for approval of a non-approved supplier or product;

(2) Franchisee and supplier shall demonstrate to Pretzel Time's reasonable satisfaction that it is
able to supply the commodity which meets Pretzel Time's specifications to Franchisee; and

(3) The supplier shall demonstrate to Pretzel Time's reasonable satisfaction that the supplier is of
good standing in the business community with respect to its financial soundness and the reliability
of its product and service and shall request in writing to Pretzel Time to be named an approved
supplier.

13.E. PROMOTIONAL ALLOWANCES.

Franchisee acknowledges and agrees that Pretzel Time may, in its sole discretion, collect and retain
all allowances, benefits, credits, monies, payments or rebates (collectively "Promotional Rebates"),
whether for promotional, advertising or other purposes, offered to Franchisee or Pretzel Time or its
Affiliates by manufacturers, suppliers and distributors based upon Franchisee's purchases of
Products or other products and materials. Franchisee assigns to Pretzel Time or its designee all of
Franchisee's right, title and interest in and to any and all such Promotional Allowances and
authorizes Pretzel Time or its designee to collect any such Promotional Allowances for remission to
the general operating funds of Pretzel Time.

14. FRANCHISEE OPERATIONS.

14.A. MANAGEMENT.

Franchisee agrees that he will at all times faithfully, honestly, and diligently perform his
obligations hereunder, that he will continuously exert his best efforts and shall continually train
and supervise his personnel to Pretzel Time's reasonable standards, in furtherance of the mutual
business interests of both Pretzel Time and Franchisee and that he will not engage in any other
business or activity that may conflict with his obligations hereunder. A Unit shall be under the
direct, on-premises supervision of a trained and competent Franchisee or a trained and competent
employee acting as a Unit Manager at all times. Franchisee shall remain active in overseeing the
operations of the Unit conducted under the supervision of such Unit Manager. Pretzel Time shall have
the right to deal with the Unit Manager and assistant managers on matters pertaining to the
day-to-day operations of, and reporting requirements for the Unit. Franchisee shall be required to
notify Pretzel Time within seven (7) business days of changing Unit Managers. Franchisee shall hire
all employees of the Unit and shall be exclusively responsible for the terms of their employment and
compensation and for the proper training of such employees in the operation of the Unit.

If the Unit at any time is not being managed by you or a Unit Manager who shall have satisfactorily
completed Pretzel Time's training program, Pretzel Time is authorized, but is not required to
immediately appoint a Manager to maintain the operations of the Unit for you. Pretzel Time has the
right to change a reasonable fee for such management services, not to exceed our costs, and to cease
to provide such management services at any time. Pretzel Time's right to manage a Unit and obtain
reimbursement for costs also applies in the event of your death or disability.

14.B. SUFFICIENT WORKING CAPITAL.

Franchisee shall maintain an adequate sales force to serve properly all customers, and shall carry
at all times a stock of merchandise of such size, character, quality and price to produce the
maximum return to Franchisee and so as to produce all of the gross revenue which may be produced by
such manner of operation.

14.C. FILING OF OPERATIONS AND SALES REPORTS.

Franchisee's net revenues and operational analysis are to be reported on or before Tuesday at 12:00
P.M. Eastern Standard Time (or Eastern Daylight Savings Time) or any other time reasonably
designated by Pretzel Time, to Pretzel Time on forms designated by Pretzel Time for the immediately
preceding week. If the gross sales report is not submitted as herein specified, Pretzel Time may, at
its option, charge a late fee of $50.00 to Franchisee. There will only be one late fee for each late
report.

14.D. EMPLOYEE DRESS AND CUSTOMER SERVICE.

The presentation of an uniform image is essential to a successful franchise system. Franchisee shall
cause all employees of Franchisee while working at the franchise location to dress appropriately (in
the specific uniform approved and designated by Pretzel Time) in keeping with the Pretzel Time
image, as Pretzel Time may designate from time to time, to present a neat and clean appearance and
to render confident and courteous service to the Franchise's customers.

14.E. COMPLIANCE WITH LAWS AND GOOD BUSINESS PRACTICES.

Franchisee shall secure and maintain in force in his name all required licenses, permits, and
certificates relating to the conduct of his business pursuant to this Agreement. Franchisee will
conduct the Franchise in strict compliance with all applicable laws, ordinances, regulations, and
other requirements of any federal, state, county, municipal or other government, including, without
limitation, those laws and regulations pertaining to preparation, purchase and handling of food
products, occupational hazards,
<!-- page 25 -->
health, safety and sanitation, worker's compensation insurance, unemployment insurance, and
withholding and payment of all taxes. While Pretzel Time may advise Franchisee as a courtesy on any
applicable laws, ordinances, or regulations, Pretzel Time undertakes no duty to do so and Franchisee
hereby acknowledges it is Franchisee's sole duty to inquire regarding and concerning all laws,
ordinances, and regulations affecting the Unit, its operations, employees and Franchisee.

Franchisee shall in all dealings with its customers, suppliers, Pretzel Time, and public officials
adhere to high standards of honesty, integrity, fair dealing and ethical conduct. Franchisee agrees
to refrain from any business or advertising practice which may be injurious to the business of
Pretzel Time and the goodwill associated with the Marks and other Pretzel Time Units.

Franchisee shall notify Pretzel Time within three (3) business days after the commencement of any
action, suit, proceeding or issuance of any order, writ, injunction, award or court decree which may
adversely affect the operation or financial condition of Franchisee or the unit or immediately
notify Pretzel Time of any notice of health or sanitation violation.

14.F. PAYMENT OF TAXES.

Franchisee shall be solely responsible for payment of all taxes, including, but not limited to, real
estate, sales, payroll, franchise, income, personal property, and gross receipts taxes which are
assessed as a result of Franchisee's operation of the Franchise.

14.G. SALE OF PRODUCT.

Franchisee agrees not to sell or offer to sell any materials, supplies, or inventory used in the
preparation of any of the Products other than to Pretzel Time and that he shall not sell, dispense,
give away or otherwise provide without Pretzel Time's prior written consent any product except by
means of retail sales in the franchise location. Franchisee may only sell finished Products and may
not sell any Products to any person or entity purchasing the Products for resale. Notwithstanding
the foregoing, Franchisee may offer free samples of Products at or directly in front of the Unit to
retail customers only.

14.H. COOPERATION.

Franchisee agrees that he shall cooperate with Pretzel Time in taking any action, or refraining from
any action, which in the judgment of Pretzel Time is necessary or desirable to promote and enhance
the quality of the products of the Franchise location, the service provided by the Franchisee, or
the image of the Franchise in the community.

14.I. INSURANCE.

Franchisee shall maintain at Franchisee's expense, in form, amounts and with insurers satisfactory
to Pretzel Time, which insurers must have an A.M. Best Company rating of "A-" or better and naming
Pretzel Time an additional insured, insurance against all types of public liability with personal
injury coverage and property damage coverage. In addition to coverage as aforesaid such insurance
shall include coverages as set forth in the Operations Manual and shall contain a provision
obligating all insurers to provide a written notice Pretzel Time of any cancellation or modification
of coverage at least thirty (30) days prior to the effective date of such modification or
cancellation.

The insurance afforded by the policy or policies respecting liability shall not be limited in any
way by reason of any insurance which may be maintained by Pretzel Time. Within sixty (60) days of
the signing of this Agreement, but in no event later than the date on which Franchisee acquires an
interest in the real property (by lease or purchase) on which it will develop and operate the
Franchise, a Certificate of Insurance showing compliance with the foregoing requirements shall be
furnished by Franchisee to Pretzel Time for approval. Such certificate shall state that said policy
or policies will not be canceled or altered without at least thirty (30) days prior written notice
to Pretzel Time and shall reflect proof of payment of premiums. Maintenance of such insurance and
the performance by Franchisee of the obligations under this Section shall not relieve Franchisee of
liability under the indemnity provision set forth in this Agreement. Minimum limits as required
above may be modified from time to time, as conditions require by written notice to Franchisee.

Should Franchisee not procure and maintain such insurance coverage as required by Pretzel Time,
Pretzel Time shall have the right and authority, without any obligation to do so, immediately
procure such insurance coverage and to charge same to Franchisee, which charges together with a
reasonable fee for expenses incurred by Pretzel Time in connection with such procurement, shall be
payable by Franchisee immediately upon notice.

Franchisee shall fully cooperate with Pretzel Time in its efforts to obtain such insurance policies,
promptly execute all forms or instruments required to obtain or maintain such insurance policies,
allow inspections of the Unit or vehicles which are required to obtain and maintain insurance and
pay Pretzel Time on demand for any costs or premiums.

14.J. SUGGESTED RETAIL PRICES.

Pretzel Time may from time to time advise or offer guidance to Franchisee relative to prices for
Products offered for sale by Franchisee that in Pretzel Time's judgment constitute good business
practice. Franchisee shall not be obligated to accept any such advice or guidance and shall have the
sole right to determine and to sell products at any price that it determines.
<!-- page 26 -->
Whenever Pretzel Time recommends a retail price, such recommendations are based on Pretzel Time's
experience concerning all factors that enter into a proper price, but such recommendation is in no
manner binding on Franchisee and no such advice or guidance shall be deemed or construed to impose
upon Franchisee any obligation to charge any fixed, minimum or maximum prices for any product
offered for sale by the Franchise. Pretzel Time reserves the right to advertise retail prices of
Pretzel Time Products, provided that such retail prices are qualified as "suggested." The parties
understand and agree that such advertising shall not be construed as requiring Franchisee to adhere
to such prices but Franchisee shall have complete freedom to establish retail prices.

15. ACCOUNTING, REPORTS AND FINANCIAL STATEMENTS.

15.A. ESTABLISHMENT OF ACCOUNTING SYSTEM.

Franchisee shall establish at his own expense a complete and accurate bookkeeping, accounting,
record keeping and data processing system prepared in accordance with generally accepted accounting
principles and conforming to the requirements and formats that Pretzel Time prescribes from time to
time. Pretzel Time shall provide Franchisee with forms on which to maintain certain sales and
operational data. Franchisee shall furnish to Pretzel Time on said forms that Pretzel Time
prescribes from time to time:

(i) On Tuesday of each week, a report on the Unit's net revenues and sales and operations for the
previous week;

(ii) Every six calendar month period, a balance sheet and a profit and loss statement for the Unit
for the previous semi-annual period and a year to-date statement of financial condition as of the
end of such previous period; and

(iii) Within thirty (30) days after Franchisee's year end, an annual financial report.

The reports required in Section 15.A. (ii) and (iii) if not audited, should be signed by the
Franchisee or its financial officer, attesting that (1) the reports are true and accurate, (2) they
are prepared in accordance with GAPP on a basis consistent with prior periods, (3) they fully
describe and completely disclose the information sought, and (4) the signer has made diligent
efforts to ascertain the truth and completeness of the information.

15.B. MAINTENANCE OF RECORDS.

Franchisee agrees, at all times, he shall keep and maintain adequate, accurate, true, and proper
records, books, reports, data, and accounts relative to the franchise in the English language and in
accordance with generally accepted accounting principles, and retain the records for a period of
three (3) years after the date they were prepared, from which there may be readily determined the
information required in the operating reports to be filed with Pretzel Time. Such records include,
without limitation, daily cash reports, cash receipts journal and general ledger, cash disbursements
journal and weekly payroll register, monthly bank statements and daily deposit slips and cancelled
checks; tax returns, supplier invoices, dated cash register tapes, weekly inventories, sales
reports, financial statements and tax returns.

Franchisee hereby authorizes Pretzel Time to utilize the data supplied by Franchisee under this
Section in any publication, discovery statement, Offering Circular, or advertisements related to the
sale of Franchises or related entities by Pretzel Time, anywhere, at any time, without specific
compensation therefor.

16. AUDITS AND INSPECTIONS.

16.A. AUDITS.

Pretzel Time or its designee shall have the right at any time during business hours and without
prior notice to Franchisee, to inspect, audit and copy or the right to cause to be inspected,
audited and copied, the business records, bookkeeping and accounting records, sales and income tax
records and returns and other records of the Franchised Business, including but not limited to,
daily cash reports, cash receipts journal and general ledger, cash disbursements journal and weekly
payroll register, monthly bank statements and daily deposit slips and cancelled checks; tax returns,
supplier invoices, dated cash register tapes, weekly inventories, sales reports, financial
statements and tax returns and the books and records of any corporation or partnership which holds
the Franchise including the personal financial records and tax returns of the Franchisee during and
after the term of the Franchise Agreement. Franchisee agrees to maintain on the premises all sales
and operational information for four weeks.

Any such inspection or audit will take place at a time which will not interfere with Franchisee's
normal business. Franchisee shall fully cooperate with Pretzel Time's representatives and
independent accountants hired by Pretzel Time to conduct any such inspection or audit. If Pretzel
Time deems necessary, Franchisee shall deliver to Pretzel Time or its designated agents copies of
all bookkeeping records not already in the possession of Pretzel Time, including customer records,
cash register tapes, sales and purchase records and tax records, to enable Pretzel Time or its
representative or designee to adequately audit Franchisee's gross sales. Franchisee hereby waives
any right to withhold tax records relative to the Franchise as privileged information. Each report
and
<!-- page 27 -->
financial statement shall be signed and verified by Franchisee in the manner Pretzel Time
prescribes. Pretzel Time reserves the right to require Franchisee to have audited or reviewed
financial statements prepared on an annual basis.

In the event that an audit discloses that Franchisee's actual net revenues exceed Franchisee's
reported net revenues by two percent (2%) or more for any thirty day period, Franchisee is obligated
to pay to Pretzel Time, within fifteen (15) days after receipt of the inspection or audit report,
the royalty of seven percent (7%) and the Advertising Fund Fee of one percent (1%) of the amount of
such understatement plus interest from the date such payments were originally due. The audit will be
conducted at the expense of Pretzel Time, provided that if an audit disclosed an understatement of
two percent (2%), as described above, Franchisee will bear the cost of the audit, including without
limitation, the charges of attorneys and any independent accountants, their travel expenses, room
and board, and compensation of Pretzel Time's representatives and independent accountants. Providing
that in no case will Franchisee be obligated to pay more than ten thousand dollars ($10,000) for
such inspection or audit costs. The foregoing remedies shall be in addition to Pretzel Time's other
remedies and rights under this Agreement or applicable law.

16.B. RIGHT OF ENTRY AND INSPECTION.

To determine whether Franchisee and the Unit are complying with this Agreement and with all Pretzel
Time's standards and operations as prescribed by Pretzel Time, Pretzel Time or its designated agents
shall have the right at any reasonable time and without prior notice to Franchisee to:

a. Inspect the Unit;

b. Observe, photograph and video tape the Unit's operations for such consecutive or intermittent
periods as Pretzel Time deems necessary;

c. Remove samples of any Products, materials or supplies for testing and analysis;

d. Interview personnel of the Unit;

e. Interview customers of the Unit; and

f. Inspect and copy any books, records and documents relating to the operation of the Unit.
Franchisee agrees to cooperate fully with Pretzel Time in connection with any such inspections,
observations, photographing, video taping, Product removal and interviews. Franchisee shall present
to his customers such comment or evaluation forms as Pretzel Time periodically prescribes and shall
participate and/or request his customers to participate in any surveys performed by or on behalf of
Pretzel Time. At the conclusion of his inspection, Pretzel Time's field representative shall prepare
a written report which shall contain all of his observations and conclusions. If the field
representative determines that a condition amounting to a default of this Agreement has occurred or
exists, this conclusion shall be promptly communicated to Franchisee and Pretzel Time.

17. TRANSFER, ASSIGNMENT AND REPURCHASE.

17.A. BY PRETZEL TIME.

This Agreement is fully transferable by Pretzel Time and shall inure to the benefit of any assignee,
transferee or other legal successor to Pretzel Time's interest herein. If Pretzel Time's assignee
will perform any of Pretzel Time's obligations under this Agreement, then that assignee must be
financially capable of performing those obligations and the assignee must expressly assume and agree
to perform them. Franchisee agrees that Pretzel Time shall have the right, from time to time, to
delegate the performance of any portion or all of its obligations and duties under this Agreement.

17.B. BY FRANCHISEE.

Franchisee understands and acknowledges that the rights and duties created by this Franchise
Agreement are personal to Franchisee (or if Franchisee is a corporation or partnership, to its
Owners) and that Pretzel Time has granted the Franchise to Franchisee in reliance upon Pretzel
Time's perceptions of the individual or collective character, skill, aptitude, attitude, business
ability and financial capacity of Franchisee (or its Owners). Accordingly, Franchisee agrees no
Transfer shall be made without Pretzel Time's prior written approval. Any Transfer without such
approval shall constitute a breach of this Agreement and shall be void and of no effect. Pretzel
Time's consent to the assignment shall neither constitute a novation or change in Franchisee's
obligations under this agreement, nor constitute a waiver of any claims Pretzel Time may have
against Franchisee (or its Owners) nor be deemed a waiver of Pretzel Time's right to demand the
transferee's exact compliance with all of the terms or conditions of this Agreement.

17.C. CONDITIONS FOR APPROVAL OF TRANSFER.

If Franchisee is in full compliance with this Agreement (and, if Franchisee is a corporation or
partnership, its Owners are in full compliance with this Agreement), Pretzel Time shall not
unreasonably withhold its approval of a Transfer that meets all of the following requirements:

(1) The transferee and its Owners must meet Pretzel Time's then applicable standards for Pretzel
Time Unit franchisees and must have had sufficient business experience, aptitude, and financial
resources to operate the Unit;
<!-- page 28 -->
(2) Franchisee has paid such royalty, advertising fund fees, amounts owed for purchases by
Franchisee from Pretzel Time and its Affiliates and all other amounts owed to Pretzel Time or its
Affiliates and third party creditors and shall have submitted to Pretzel Time all required reports
and statements;

(3) Franchisee or the transferee has paid Pretzel Time's then current transfer fee to defray
expenses Pretzel Time incurs in connection with the transfer, except that if the proposed Transfer
is, to or among Owners of Franchisee, this provision shall not apply;

(4) The Transferee and/or its Unit Manager have agreed to complete Pretzel Time's training program
to Pretzel Time's satisfaction and prior to the date of transfer;

(5) The Transferee has agreed to be bound by all of the terms and conditions of this Agreement and
executes a current Franchise Agreement and other franchise documents, a sublease agreement, if any,
and other documents required by Pretzel Time;

(6) Franchisee (and its transferring Owners) have executed a general release, in form satisfactory
to Pretzel Time, of any and all claims against Pretzel Time and its Affiliates and their officers,
directors, employees and agents;

(7) Pretzel Time has approved the material terms and conditions of such Transfer, including, without
limitation, that the price and terms of payment are not so burdensome as to affect adversely the
transferee's operation of the Unit; provided, however, that Pretzel Time's approval of such Transfer
does not ensure the transferee's success as a Pretzel Time Unit franchisee, nor should the
transferee rely upon Pretzel Time's approval of such Transfer in determining whether to acquire
Franchisee's Pretzel Time Unit; (8) If Franchisee (and/or its Owners) finances any part of the sale
price of the transferred interest, Franchisee and/or its Owners have agreed that all obligations of
the transferee under or pursuant to any promissory notes, agreements or security interests reserved
by Franchisee or its Owners in the assets of the Unit or the Premises shall be subordinate to the
transferee's obligations to pay royalty and service fees and other amounts due to Pretzel Time and
its Affiliates and otherwise to comply with this Agreement;

(9) Franchisee (and its Owners) have executed a noncompetition covenant in favor of Pretzel Time and
the transferee agreeing that, for a period of twelve (12) months commencing on the effective date of
the Transfer, Franchisee, its Owners and members of the immediate families of Franchisee and each of
its Owners will not hold any direct or indirect interest as a disclosed or beneficial owner,
investor, partner, director, officer manager, employee, consultant, representative or agent, or in
any other capacity, in a Competitive Business located or operating within three (3) miles of the
Unit, and within three (3) miles of any other Pretzel Time Unit;

(10) If consent is required, the lessor of the Premises consents to the assignment or sublease of
the Premises to the transferee;

(11) Franchisee has complied with all of its obligations to Pretzel Time, its Affiliates, suppliers,
and distributors, and Franchisee is not in default under this Agreement or any other Agreement with
Pretzel Time or Pretzel Time's Affiliates;

(12) All improvements, including refurbishings, remodelings, new equipment must be made prior to the
Transfer; and

(13) Franchisee (and its Owners) has agreed that he will not directly or indirectly at any time or
in any manner (except with respect to Pretzel Time Units owned and operated by Franchisee) identify
himself or any business as a current or former Pretzel Time Unit, or as a franchisee, licensee or
dealer of Pretzel Time or its Affiliates, use any Mark, any colorable imitation thereof or other
indicia of a Pretzel Time Unit in any manner or for any purpose or utilize for any purpose any
tradename, trade or service mark or other commercial symbol that suggests or indicates a connection
or association with Pretzel Time or its Affiliates.

17.D. TRANSFER TO A WHOLLY-OWNED CORPORATION.

Notwithstanding Section 17.B., if Franchisee is in full compliance with this Agreement, Franchisee
may transfer this Agreement to a corporation which conducts no business other than the Pretzel Time
Unit and in which Franchisee maintains management control and owns and controls one hundred percent
(100%) of the equity and voting power of all issued and outstanding capital stock. Transfers of
shares of such corporation will be subject to the provisions of Section 17.C.(2) and 17.C.(8).
Notwithstanding anything to the contrary herein, Franchisee shall remain personally liable under
this Agreement as if the Transfer to such corporation had not occurred. The articles of
incorporation, by-laws and other organizational documents of such corporation shall recite that the
issuance and assignment of any interest therein is restricted by the terms of Section 17 of this
Franchise Agreement, and all issued and outstanding stock certificates of such corporation shall
bear a legend reciting or referring to the restrictions hereof.

17.E. FORMATION OF A CORPORATION.
<!-- page 29 -->
In the event, Franchisee desires to form a corporation for the sole purpose of acting as a
Franchisee under this Agreement, in addition to the conditions imposed under Section 17, the
following terms and conditions must be complied with, unless otherwise agreed in writing by Pretzel
Time:

(1) Franchisee must be the owner of the majority interest in the voting stock of the corporation and
the principal executive officer thereof;

(2) Franchisee's shareholders shall enter into an agreement under seal with Pretzel Time, on Pretzel
Time's standard form, guaranteeing the full payment of the corporation's money obligations to
Pretzel Time as individual surety and agreeing to be bound individually by the non-competition
obligation stated herein; and

(3) Franchisee and all shareholders must continue to meet its obligations under the noncompetition
provisions of this Agreement.

In the event Franchisee or its successor is a corporation or partnership or similar entity, it is
agreed as follows:

(1) That the Articles of Incorporation and By-Laws or the Partnership Agreement, shall reflect that
the issuance and transfer of voting stock or other ownership interest therein, is restricted by the
terms of this Agreement. Franchisee shall furnish Pretzel Time at the time of the execution of this
Agreement or of assignment to the corporation or partners of Franchisee, a written agreement stating
that no stockholder or partner will sell, assign or transfer voluntarily or by operation of law any
securities of Franchisee, or other ownership interest in Franchisee, to any person or entity other
than existing shareholders or partnership, to the extent permitted hereunder, without the prior
written consent of Pretzel Time. All securities issued by Franchisee will bear the following legend
which shall be printed legibly and conspicuously on each stock certificate or other evidence of
Ownership Interest:

"The transfer of these securities is subject to the terms and conditions of a Franchise Agreement
with Pretzel Time, Inc. dated , 199____. Reference is made to said Agreement and to the restrictive
provisions of the Articles and By-laws or Shareholders or Partnership Agreement."

(2) That if Franchisee or a successor, is a corporation, the majority of the capital stock thereof
shall not at any time or in the aggregate be sold, assigned, pledged, mortgaged or transferred
without the prior written consent of Pretzel Time.

(3) Franchisee represents and warrants that its Owners are as set forth on Exhibit B attached to
this Agreement and covenants that it will not vary from that ownership structure without the prior
written approval of Pretzel Time.

17.F. DEATH OR DISABILITY OF FRANCHISEE.

Upon the death or Permanent Disability of Franchisee or, if Franchisee is a corporation or
partnership, the Owner of a Controlling Interest in Franchisee, the executor, administrator,
conservator, guardian or other personal representative of such person shall transfer Franchisee's
interest in this Agreement or such interest in Franchisee to a third party approved by Pretzel Time.
Such disposition of this Agreement or such interest in Franchisee (including, without limitation,
transfer by bequest or inheritance) shall be completed within a reasonable time, not to exceed six
(6) months from the date of death or Permanent Disability, and shall be subject to all the terms and
conditions applicable to Transfers contained in Section 17.B. and 17.C. Failure to transfer the
interest in this Agreement or such interest in Franchisee within said period of time shall
constitute a breach of this Agreement.

17.G. PRETZEL TIME'S FIRST RIGHT OF REFUSAL.

If Franchisee (or its Owners) shall at any time determine to sell, assign or transfer for
consideration this Agreement or an Ownership Interest in Franchisee or the Unit, Franchisee (or its
Owners) shall obtain a bona fide, executed written offer and earnest money deposit from a
responsible and fully disclosed purchaser (including lists of the Owners of record and beneficially
of any corporate offeror and all general and limited partners of any partnership offeror and, in the
case of a publicly-held corporation or limited partnership, copies of the most current annual and
quarterly reports) and shall immediately submit to Pretzel Time a true and complete copy of such
offer, which shall include details of the payment terms of the proposed sale and the sources and
terms of any financing for the proposed purchase price. To be a valid, bona fide offer, the proposed
purchase price shall be denominated in a dollar amount. The offer must apply only to an interest in
this Agreement, Franchisee or the Unit and may not include an offer to purchase any other property
or rights of Franchisee (or its Owners). However, if the offeror proposes to buy any other property
or rights from Franchisee (or its Owners) under a separate, contemporaneous offer, the price and
terms of purchase offered to Franchisee (or its Owners) for the interest in this Agreement,
Franchisee or the Unit shall reflect the bona fide price offered therefore and shall not reflect any
value for any other property or rights.
<!-- page 30 -->
Pretzel Time shall have the right, exercisable by written notice delivered to Franchisee (or its
Owners) within sixty (60) days from the date of delivery of an exact copy of such offer to Pretzel
Time, to purchase such interest for the price and on the terms and conditions contained in such
offer, provided that Pretzel Time may substitute cash for any form of payment proposed in such
offer, Pretzel Time's credit shall be deemed equal to the credit of any proposed purchaser and
Pretzel Time shall have not less than sixty (60) days to prepare for closing. Without regard to the
representations and warranties demanded by the proposed purchaser, if any, Pretzel Time shall be
entitled to purchase such interest subject to all customary representations and warranties given by
the Franchisee, seller of the assets of a business or voting stock of an incorporated business, as
applicable, including, without limitation, representations and warranties as to ownership, condition
and title to stock, and /or assets, liens and encumbrances relating to the stock and/or assets,
validity of contracts and liabilities of the corporation whose stock is purchased and affecting the
assets, contingent or otherwise.

If Pretzel Time exercises its right of first refusal, Franchisee (and its Owners) agrees that, for a
period of twelve (12) months commencing on the date of the closing, neither Franchisee (nor its
Owners) shall have any direct or indirect interest (through a member of the immediate families of
Franchisee or its Owners of otherwise) as a disclosed or beneficial owner, investor, partner,
director, officer, employee, consultant, representative, or agent or in any other capacity in any
Competitive Business located or operating within three (3) miles of the Unit, and/or three (3) miles
of any other Pretzel Time Unit. The restrictions of this Section shall not be applicable to the
ownership of shares of a class of securities listed on a stock exchange or traded on the
over-the-counter market that represent two percent (2%) or less of the number of shares of that
class of securities issued and outstanding. If Pretzel Time exercises its right of first refusal,
Franchisee (and its Owners) further agrees that he will abide by the restrictions of Section
17.C.(13).

If Pretzel Time does not exercise its right of first refusal, Franchisee or its Owners may complete
the sale to such purchaser pursuant to and on the exact terms of such offer, subject to Pretzel
Time's approval of the Transfer as provided in Section 17, provided that if the sale to such
purchaser is not completed within 120 days after delivery of such offer to Pretzel Time, or if there
is a material change in the terms of the sale (which Franchisee shall promptly communicate to
Pretzel Time), Pretzel Time's right to first refusal shall be extended for thirty (30) days after
the expiration of such 120 day period or after the material change in the terms of the sale so
communicated to Pretzel Time.

17.H. PUBLIC OR PRIVATE OFFERINGS.

In the event Franchisee (or any of its Owners) shall, subject to the restrictions and conditions of
Transfer contained in Section 17, attempt to raise or secure funds by the sale of securities
(including, without limitation, common or preferred stock, bonds, debentures or general or limited
partnership interests) in Franchisee or any affiliate of Franchisee, Franchisee, recognizing that
the written information may reflect upon Pretzel Time, agrees to submit any such written information
used with respect thereto prior to its inclusion in any registration statement, prospectus or
similar offering circular or memorandum and to obtain Pretzel Time's written consent to the method
of financing prior to any offering or sale of such securities. Pretzel Time's written consent
pursuant to this Section shall not imply or constitute Pretzel Time's approval with respect to the
sale of the securities, the offering literature submitted to Pretzel Time or any other aspect of the
offering. No information respecting Pretzel Time shall be included in any disclosure document unless
such information has been furnished by Pretzel Time in writing pursuant to Franchisee's written
request, in which Franchisee states the specific purposes for which the information is to be used.
Should Pretzel Time, in its sole discretion, object to any reference to it or its business or to the
relationship of Franchisee or a controlled affiliate in such offering literature or prospectus, such
literature or prospectus shall not be used unless and until Pretzel Time's objections are withdrawn.
Pretzel Time assumes no responsibility whatsoever for any offering. Franchisee shall pay Pretzel
Time's expenses in connection with the offering or proposed offering.

The prospectus or other literature utilized in any such offering shall contain the following
language in bold-face type on the first textual page thereof:

PRETZEL TIME, INC. IS NOT DIRECTLY OR INDIRECTLY THE ISSUER OF THE SECURITIES OFFERED HEREBY AND
ASSUMES NO RESPONSIBILITY WITH RESPECT TO THIS OFFERING AND/OR THE SUFFICIENCY OR ACCURACY OF THE
INFORMATION SET FORTH HEREIN, INCLUDING ANY STATEMENTS WITH RESPECT TO PRETZEL TIME, INC. PRETZEL
TIME, INC. DOES NOT ENDORSE OR MAKE ANY RECOMMENDATION WITH RESPECT TO THE INVESTMENT CONTEMPLATED
BY THIS OFFERING.

Franchisee (and each of its Owners) agrees to indemnify, defend and hold harmless Pretzel Time, its
parent company, subsidiaries, and Affiliates and their officers, directors, employees and agents
from any and all claims, demands and liabilities, and all costs and expenses (including, without
limitation, reasonable attorneys' fees) incurred in defending against such claims, demands or
liabilities, arising from the offer or sale of such securities, whether asserted by a purchaser of
any such security or by a governmental agency. Pretzel Time shall have the right (but not the
obligation) to defend any such claims, demands or liabilities and/or to participate in the defense
of any action to which it is named as a party.

18. TERMINATION OF AGREEMENT BY FRANCHISEE.

18.A. FRANCHISEE'S RIGHT TO TERMINATE.
<!-- page 31 -->
If Franchisee is in substantial compliance with this Agreement and Pretzel Time substantially
breaches a material provision of this Agreement and (1) fails to cure such breach within thirty (30)
days after written notice thereof is delivered to Pretzel Time or (2) if such breach cannot
reasonably be cured within thirty (30) days after Pretzel Time's receipt of such notice, undertake
(within thirty (30) days after Pretzel Time's receipt of such notice and continue until completion),
reasonable efforts to cure such breach, Franchisee may terminate this Agreement. Such termination
shall be effective ten (10) days after delivery to Pretzel Time of notice that such breach has not
been cured and Franchisee elects to terminate this Agreement. A termination of this Agreement by
Franchisee for any reason other than a substantial breach of a material provision of this Agreement
by Pretzel Time, and Pretzel Time's failure to cure such breach as provided above shall be deemed a
termination by Franchisee without cause.

19. DEFAULT AND TERMINATION.

19.A. EXACT AND COMPLETE PERFORMANCE REQUIRED.

Franchisee acknowledges that complete performance of all the terms of this Agreement is necessary
for the protection of Pretzel Time and its franchisees. It is therefore agreed that complete and
exact performance by the Franchisee of each of his promises contained herein is a condition to the
continuance of this Franchise.

19.B. DEFAULT AND RIGHT TO CURE.

If Franchisee defaults in the performance of any of the terms of this Agreement or the Operations
Manual, Pretzel Time, in addition to all other remedies available to it at law or in equity and
without prejudice to any other rights or remedies, may immediately terminate this Agreement by
delivering a written notice to Franchisee of any breach of this Agreement and a notice period of
forty-five (45) days shall be given to Franchisee, unless such default is cured by the Franchisee
within thirty (30) days after written notice thereof from Pretzel Time to Franchisee.
Notwithstanding the foregoing, if the default is other than a failure to pay a monetary obligation
to Pretzel Time or to a related company and of a nature that more than thirty (30) days are
reasonably required to cure, Franchisee shall commence to cure the default within said thirty (30)
day period and shall proceed with such cure with due diligence with a view to accomplishing the cure
at the earliest possible moment, and within the period, if any, designated by Pretzel Time as the
allowable additional time within which the cure must be accomplished.

19.C. EXTENSION OF NOTICE.

If any applicable law or rule requires a greater prior notice of termination, the prior notice
required by such law or rule shall be substituted for the notice requirements herein.

19.D. REPEATED BREACHES.

Further, notwithstanding anything herein elsewhere contained, if Franchisee shall repeatedly fail to
comply with the terms of this Agreement, or any of them, of any nature, even though such failures
may be cured within the applicable grace periods, Pretzel Time shall have the right by written
notice given to Franchisee immediately to declare this Agreement terminated, which right shall be in
addition to and without prejudice to any other right or remedy to which Pretzel Time may be entitled
under this Agreement or otherwise under applicable law. As used in this Agreement the term
"repeatedly fail" shall mean three (3) defaults within any twelve (12) month period, even if the
defaults are later cured. 19.E. EVENTS OF DEFAULT - 30 DAYS NOTICE - CURABLE DEFAULTS.

The occurrence of any one of the following events shall constitute a default under this Agreement
requiring a 30 day notice period of termination by Pretzel Time to Franchisee:

(i) Franchisee fails to pay money when due to Pretzel Time as required under the Franchise
Agreement, including, without limitation, the franchise fee, the renewal fee, the transfer fee,
royalties, and the advertising fund fee; or

(ii) If Franchisee or his Unit Manager fails to satisfactorily complete any mandatory training
programs (except the initial training in which case, the Franchise Agreement can be terminated upon
notice) offered by Pretzel Time; or

(iii) If Franchisee fails to submit to Pretzel Time financial or other information when required
under this Agreement or submits a financial statement which materially understates net revenues; or

(iv) If Franchisee fails to develop or construct the Unit in accordance with this Agreement; Pretzel
Time's plans and specifications or fails to equip and furnish the location in accordance with
Pretzel Time's plans and specifications; or

(v) A final judgment against Franchisee remains unsatisfied of record for thirty (30) days, unless a
supersedeas or other appeal bond has been filed; or

(vi) Franchisee or any of its Owners abandons, surrenders or
<!-- page 32 -->
transfers control of the operation of the Unit without the prior written approval of Pretzel Time,
or threatens to abandon the same; or

(vii) Franchisee fails to use Pretzel Time approved marketing and promotional materials or
Franchisee fails to receive Pretzel Time's prior approval of marketing and promotional materials; or

(viii) Failure to obtain Pretzel Time's prior written consent or approval where expressly required
by the Franchise Agreement; or

(ix) If Franchisee operates the franchise in such a manner so as to affect materially and adversely
the goodwill or reputation of Pretzel Time or its System or any product manufactured by any
Affiliate; or

(x) Franchisee denies Pretzel Time the right to inspect the Unit or to examine or audit his books;
or

(xi) Franchisee misuses Pretzel Time's Marks or asserts any interest in Pretzel Time's Marks; uses
Pretzel Time's tradename or any part thereof as part to of its corporate name; does not cooperate in
the enforcement of any Mark; or challenges or seeks to challenge the validity of the Marks; or

(xii) Franchisee fails to maintain and operate the Unit in accordance with standards and
specifications established by Pretzel Time as to the services or maintenance of inventory; or

(xiii) Franchisee fails to obtain all permits, insurance, licenses and other necessary documents for
the opening of the Unit; or

(xiv) Franchisee fails to maintain uniform Unit design and image, and/or fails to refurbish or
remodel as required by Pretzel Time; or

(xv) Franchisee attempts or does mortgage, pledge or otherwise assign as security the premises, any
equipment, furnishings, fixtures or any interest Franchisee may have; or

(xvi) Conduct by Franchisee which is of such a nature that a reasonably objective person would
consider same to be deleterious to or to reflect unfavorably on Pretzel Time or the Pretzel Time
Unit System; or

(xvii) Failure by Franchisee to maintain a responsible credit rating by failing to make prompt
payment of undisputed bills, invoices and statements from suppliers or distributors of goods and
services to the Unit; or

(xviii) Failure to comply with all of the terms of the Operations Manual as amended from time to
time, the standards and specifications required by Pretzel Time or any other agreement between the
Franchisee and Pretzel Time; or

(xix) Fails to pay any federal or state income, sales or other taxes due on the Unit's operations
unless Franchisee is in good faith contesting his liability for such taxes; or

(xx) Franchisee knowingly sells any product or service that does not conform to Pretzel Time's
specifications, uses or sells products other

than in strict accordance with the requirements of the Franchise Agreement or the Operations Manual;
fails to sell products or services approved by Pretzel Time or deals with vendors and suppliers not
approved by Pretzel Time.

(xxi) Franchisee fails to pay any subcontractor, contractor or other person to whom money is due and
that subcontractor, contractor or other person demands said money from Pretzel Time.

(xxii) Franchisee is late in paying rent to the landlord more than 2 times in any twleve month
period.

19.F. EVENTS OF DEFAULT - IMMEDIATE TERMINATION - NO RIGHT TO CURE.

The following acts of default will result in termination of the Franchise effective immediately upon
delivery and receipt of written notice of same to Franchisee and with no right to cure where the
grounds for termination or cancellation are:

(i) Franchisee or a Owner fails to complete all phases of the initial training program to Pretzel
Time's satisfaction; or
<!-- page 33 -->
(ii) Franchisee fails to commence operation of the Unit within the time specified in this Agreement;
or

(iii) Any affirmative act of bankruptcy or insolvency by Franchisee, or the filing by Franchisee of
any petition or action in bankruptcy or insolvency, or for appointment of a receiver or trustee,
Franchisee admits in writing his inability to pay his debts or an assignment by Franchisee for the
benefit of creditors, or the failure to vacate or dismiss within five (5) days after filing any such
proceedings commenced against Franchisee by a third party. Franchisee expressly and knowingly waives
any rights that he may have under the provisions of the Bankruptcy Rules and consents to the
termination of this Agreement or any other relief which may be sought in a complaint filed by
Pretzel Time to lift the provisions of the automatic stay of the Bankruptcy Rules. Additionally
Franchisee agrees not to seek an injunction order from any court in any jurisdiction relating to
insolvency, reorganization of arrangement proceedings which would have the effect of staying or
enjoining this provision. THIS PROVISION MAY NOT BE ENFORCEABLE UNDER FEDERAL BANKRUPTCY LAW (11
U.S.C.A. Sec. 101 et seq.); or

(iv) Failure to cure within seventy-two (72) hours after delivery of written notice of default under
the Franchise Agreement which materially impairs the goodwill associated with Pretzel Time's trade
names, trademarks, service marks, logo types or other commercial

symbols or the use by Franchisee of any name, mark, system insignia or symbol not authorized by
Pretzel Time; or

(v) The conviction of Franchisee, or any if its principals if it is a partnership or corporation, of
a crime related to the business conducted pursuant to the franchise which may tend to affect
adversely the goodwill or reputation of Franchisee, Pretzel Time or its System or the products of
Pretzel Time's Affiliates; or

(vi) Abandonment of the Franchise. For purposes of this agreement "Abandonment" shall mean
Franchisee's failure (other than with Pretzel Time's prior written approval) to keep the franchise
open and operating for business during the minimum opening hours specified in this Agreement or
Lease Agreement; or

(vii) Franchisee ceases to occupy the premises. If the loss of possession in the result of
governmental exercise of eminent domain, destruction of the site, or termination of lease (except by
reason of Franchisee's fault), Franchisee may (with Pretzel Time's consent and subject to
availability) relocate to other premises in a comparable location. Failure to relocate to other
Pretzel Time-approved premises within the time specified in this Agreement after loss of possession
due to eminent domain, destruction of premises or termination of lease without Franchisee's fault
shall constitute an act of Default with no right to cure and immediate termination upon notice; or

(viii) The existence of an imminent danger to public health or safety or fails or refuses to comply
with standards relating to the cleanliness or sanitation of the Unit or violates any health, safety
or sanitation, law ordinance or regulation and does not correct such noncompliance within
forty-eight (48) hours after written notice thereof is delivered to Franchisee; or

(ix) The loss of the right to occupy the premises from which the franchise is operated by either
Franchisee or Pretzel Time; or

(x) Material falsification of business records and reports required by Pretzel Time; or

(xi) Franchisee (or any of its Owners) makes an assignment, surrenders or transfers control of the
Unit's operation in violation of this Agreement; or

(xii) Franchisee (or any of its Owners) has made any material misrepresentation or omission in the
application for the Franchise or in materials submitted relating to a transfer; or

(xiii) Franchisee, (or its Owners) or members of their immediate family violate the restrictions on
the operation of Competitive Businesses during the term of this Agreement; or

(xiv) Franchisee (or any of its Owners or employees) makes an unauthorized use or disclosure of or
duplicates any copy of
<!-- page 34 -->
any Confidential Information or uses, duplicates or discloses any portion of the Operations Manual
in violation of this Agreement; or

(xv) Failure on two (2) or more separate occasions within any period of twelve (12) consecutive
months or on three (3) occasions during the term of this Agreement to submit when due reports or
other data, information or supporting records or to pay when due the Royalty and fees or other
payments due to Pretzel Time or its Affiliates or otherwise fails to comply with this Agreement,
whether or not such failures to comply with this Agreement, Advertising Fund Fee are corrected after
notice thereof is delivered to Franchisee; or

(xvi) Fails to cure a default under this Agreement within the time specified or provide proof
acceptable to Pretzel Time of efforts which are reasonably calculated to correct such failure within
a reasonable time, which shall in no event be more than sixty (60) days after such notice, if such
failure cannot reasonably be corrected within twenty (20) days after written notice of such notice
of default is delivered to Franchisee; or

(xvii) Franchisee terminates this Agreement without cause; or

(xviii) Franchisee understates the Unit's net revenues in any report or financial statement by an
amount greater than two (2) percent; or

(xix) Franchisee causes or permits to exist a default under the lease or sublease for the Site and
fails to cure such default within the applicable cure period set forth in the lease or sublease; or

(xx) Franchisee (or any of its Owners) fails on three (3) or more separate occasions within any
period of twenty-four (24) consecutive months to comply with this Agreement whether or not such
failures to comply are corrected after notice of default is given, or failure on two (2) or more
separate occasions within any period of twelve (12) consecutive months to comply within the same
requirement under this Agreement, whether or not such failures to comply are corrected after notice
of default is given.

20. RIGHTS AND OBLIGATIONS OF PRETZEL TIME AND FRANCHISEE UPON TERMINATION OR EXPIRATION OF THE
FRANCHISE.

20.A. AMOUNTS OWED.

Unless otherwise authorized by Pretzel Time in writing, in the event of expiration or termination of
this Agreement for any reason, or upon the sale, transfer or assignment of the Franchise by
Franchisee, all of Franchisee's rights hereunder shall terminate and Franchisee shall cease to
operate the Franchise. Franchisee agrees to pay Pretzel Time within fifteen (15) days after the
effective date of termination or expiration of this Agreement, or such later date that the amounts
due to Pretzel Time are determined, such Royalty Fees, Advertising Fund Fees, amounts owed for
purchases by Franchisee from Pretzel Time or its Affiliates, interest due on any of the foregoing
and all other amounts owed to Pretzel Time or its Affiliates which are then unpaid.

Expiration or termination of this Agreement for any reason shall not affect, modify, or discharge
any note, account receivable, or debt, contingent or otherwise, existing or arising under this
Agreement, or any prior agreement, contract, or dealing between Pretzel Time and Franchisee.

20.B. DISCONTINUANCE OF MARKS.

Franchisee agrees to immediately discontinue all use of trade names, trademarks, logotypes, forms of
advertising and other commercial symbols of Pretzel Time, and forms of advertising indicative of
Pretzel Time and cancel all assumed name registrations. Franchisee further shall remove or cause to
be removed all signs and structures indicative of a Pretzel Time Unit and shall alter the premises
occupied by Franchisee so as to distinguish the same from its former appearance and from a Pretzel
Time franchise. Further, Franchisee shall discontinue the use of any and all printed goods and
materials using said trade names, trademarks, logos and other commercial symbols of Pretzel Time. If
Franchisee refuses to comply with the terms of this Section 20 after Pretzel Time requests
compliance, Pretzel Time shall have the right to enter upon Franchisee's premises without being
deemed guilty of trespassing or any other offense, and make or cause to be made such changes at
Franchisee's expense, which Franchisee agrees to pay upon demand.

Franchisee agrees to not directly or indirectly at any time or in any manner (except with respect to
other Pretzel Time Units owned by the Franchisee) identify himself or any business as a current or
former Pretzel Time Unit, or as a franchisee, licensee or dealer of Pretzel Time or its Affiliates.
Franchisee further agrees to not use any Mark, any colorable imitation thereof or other indicia of a
Pretzel Time Unit in any manner or for any purpose or utilize for any purpose any trade name, trade
or service mark or other commercial symbol that suggests or indicates a connection or association
with Pretzel Time or its Affiliates. Franchisee (or any of its Owners) agrees after termination he
will not do business under any name or in any manner that might tend to give the general public the
impression that he is associated, affiliated, licensed, franchised by or related to Pretzel Time.
The Franchisee (or any of its Owners) may not thereafter use any name, logo type, or symbol
confusingly similar to
<!-- page 35 -->
Pretzel Time's Service Mark, logo type or symbol. If Franchisee continues operating a business at
the franchised location it will exert every reasonable effort to inform the public of his new
status, including a change of telephone number and advertising materials.

The Franchise granted to Franchisee hereunder to sell Products bearing Pretzel Time's Marks does not
include the right to sell or advertise for sale of Franchisee's Franchise itself or of its business
location. No advertisement by Franchisee or other public solicitation for sale of his interest in
this Agreement may include a representation of Pretzel Time's trademark or any reference to Pretzel
Time or its trademark system.

20.C. RETURN OF MATERIALS.

Franchisee agrees to return to Pretzel Time all signs, sign-faces, forms, invoices, letterhead, and
other materials containing any Mark or otherwise identifying or relating to a Pretzel Time Unit and
allow Pretzel Time, without liability to remove all such items from the Unit. Franchisee also agrees
to return all materials and confidential information loaned to Franchisee, including, without
limitation, all Operations Manuals and Training Manuals and videos. Franchisee agrees to return all
materials and supplies identified by the Marks in full cases or packages to Pretzel Time for credit
and dispose of all other materials and supplies, but not equipment, identified by the Marks within
thirty (30) days after the effective date of termination or expiration of this Agreement.

20.D. TELEPHONE COMPANY.

Franchisee agrees to notify the telephone company and all telephone directory publishers of the
termination or expiration of Franchisee's right to use any telephone and telecopy numbers and any
regular, classified or other telephone directory listings associated with any Mark and to authorize
the transfer thereof to Pretzel Time or at its direction. Franchisee acknowledges and agrees that as
between him and Pretzel Time, Pretzel Time has the sole rights to and interest in all telephone and
telecopy numbers and directory listings associated with any Mark. Franchisee authorizes Pretzel
Time, and hereby appoints Pretzel Time and any of its officers as Franchisee's attorney in fact, to
direct the telephone company and all telephone directory publishers to transfer any telephone and
telecopy numbers and directory listings relating to the Pretzel Time Units to Pretzel Time or at its
direction, should Franchisee fail or refuse to do so, and the telephone company and all telephone
directory publishers may accept such direction or this agreement as conclusive of Pretzel Time's
exclusive rights in such telephone and telecopy numbers and directory listings and Pretzel Time's
authority to direct their transfer. Franchisee agrees to execute a collateral assignment of
telephone numbers and listings agreement which is attached hereto as Exhibit G. In no event shall
Pretzel Time be responsible for any charges incurred by Franchisee and associated with the telephone
company prior to the date of transfer.

20.E. CONFIDENTIAL INFORMATION.

Franchisee (and its Owners) agrees that upon termination or expiration of this Agreement, he will
immediately cease to use any Confidential Information of Pretzel Time or its Affiliates disclosed to
him pursuant to this Agreement in any business or otherwise. This provision is also applicable to
the Owners if the Franchise is a corporation or partnership.

20.F. LEASING.

If Franchisee has leased the premises, Pretzel Time may, in its sole discretion and without any
obligation to do so, assume the lease. Franchisee will not be entitled to any refund of the initial
franchise fee, royalties, or Advertising Fund Fees.

20.G. COVENANT NOT TO COMPETE.

Upon termination of this Agreement, in accordance with its terms and conditions or by Franchisee
without cause, or upon expiration of this Agreement (unless the Franchise is renewed as provided for
in this Agreement), Franchisee and its Owners agree that for a period of TWELVE (12) months
commencing on the effective date of termination or expiration or the date on which Franchisee
complies with this Section, whichever is later, neither Franchisee, nor its Owners, nor any person
or entity affiliated with Franchisee or Franchisee's shareholders or partners shall have any direct
or indirect interest (through a member of the immediate families of Franchisee or its Owners or
otherwise) as a disclosed or beneficial owner, investor, partner, director, officer, employee,
consultant, representative, agent or in any other capacity in any Competitive Business located or
operating: (1) at the Site; (2) within three (3) miles of the Unit; and/or (3) within three (3)
miles of any other Pretzel Time Unit in operation or under development on the effective date of
termination or expiration of this agreement for a period of one year after the termination or
expiration. The restrictions of this Section shall not be applicable to the ownership of shares of a
class of securities listed on a stock exchange or traded on the over-the-counter market that
represent two percent (2%) or less of the number of shares of that class of securities issued and
outstanding. Franchisee and its Owners expressly acknowledge that they possess skills and abilities
of a general nature and have other opportunities for exploiting such skills. Consequently,
enforcement of the covenants made in this Section will not deprive the Franchisee or its Owners or
shareholders of their personal goodwill or ability to earn a living.

The Franchise Agreement contains a covenant not to compete which extends beyond
<!-- page 36 -->
the termination of the franchise. Franchisee and its Owners acknowledge that the covenant not to
compete is fair and reasonable, and will not impose any undue hardship, since the Franchisee (and
its Owners) has other considerable skills, experience and education which will afford him the
opportunity to derive income from other endeavors.

Neither Franchisee nor any of its Owners shall divert or attempt to divert any business or any
customers of any Pretzel Time Unit to any Competitive Business or employ or seek to employ any
person who is employed by Pretzel Time, its Affiliates or a franchisee of Pretzel Time nor induce or
attempt to induce any such person to leave said employment without the prior written consent of such
person's employer.

20.H. PRETZEL TIME'S RIGHT TO PURCHASE ASSETS OF THE UNIT.

Upon termination of this Agreement by Pretzel Time in accordance with its terms and conditions or by
Franchisee without cause or upon expiration of this Agreement (unless the franchise has been
renewed), Pretzel Time, its Affiliates or its assignee shall have the option (not the obligation),
exercisable by giving written notice thereof within sixty (60) days from the date of such expiration
or termination, to acquire from Franchisee all the assets in the Unit including the equipment,
furnishings, signs, leasehold improvements, usable inventory of Products, materials, supplies and
other tangible assets of the Unit and an assignment of the lease for the Unit. Pretzel Time shall
have the unrestricted right to assign this option to purchase. Pretzel Time or its assignee shall be
entitled to all customary warranties and representations in connection with its asset purchase,
including, without limitation, representations and warranties as to ownership, condition of and
title to assets, no liens and encumbrances on the assets, validity of contracts and agreements and
liabilities inuring to Pretzel Time or affecting the assets, contingent or otherwise.

(1) The purchase price for the assets of the Unit shall be equal to the greater of:

The sum of the book value of the Unit's assets (including furnishings, fixtures, equipment, and
leasehold improvements) amortized on a straight-line basis over a five (5) year period plus the
lesser of costs and the then-current wholesale market value of all usable inventory of Products,
materials and supplies (i.e. in good and saleable condition and not obsolete or discontinued), or

The product of the Unit's average cash flow for the two (2) most recently completed fiscal years
multiplied by two (2). "Cash flow" represents the Unit's net revenues less all pretzel unit-related
costs (i.e., cost of goods sold, labor, occupancy and other Unit expenses) as well as annual
administrative costs of ten thousand dollars ($10,000.00) and royalty and service fees, but not
including interest and depreciation.

(2) Pretzel Time and its Affiliates shall have the right to set off against and reduce the purchase
price by any and all amounts owed by Franchisee to Pretzel Time and its Affiliates. Pretzel Time may
exclude from the assets purchased hereunder any equipment, furnishings, signs, usable inventory of
Products, materials or supplies of the Unit that Pretzel Time has not approved as meeting its
standards for Pretzel Time Unit, and the purchase price shall be reduced by the replacement costs of
such excluded items which are required in the operation of the Unit.

(3) The purchase price shall be paid in cash at the closing of the purchase, which shall take place
no later than ninety (90) days after receipt by Franchisee of Pretzel Time's notice of exercise of
this option to purchase the Unit, at which time Franchisee shall deliver instruments transferring to
Pretzel Time or its assignee good and merchantable title to the assets purchased, free and clear of
all liens and encumbrances with all sales and other transfer taxes paid by Franchisee, and all
licenses or permits of the Unit which may be assigned or transferred. In the event the closing of
the purchase does not occur within said ninety (90) day period because Franchisee fails to act
diligently in connection therewith, the purchase price shall be reduced by ten percent (10%).
Franchisee further agrees that the purchase price shall be further reduced by ten percent (10%) per
month for each subsequent month Franchisee fails to act diligently to consummate this transaction.
In the event that Franchisee cannot deliver clear title to all of the purchased assets as aforesaid,
or in the event there are other unresolved issues, at Pretzel Time's option, the losing of the sale
shall be accomplished through an escrow. Prior to closing, Franchisee and Pretzel Time shall comply
with the applicable Bulk Sales provisions of the Uniform Commercial Code as enacted in the state in
which the Unit is located.

(4) If Pretzel Time or its assignee exercises this option to purchase, pending the closing of such
purchase, Pretzel Time may appoint a manager to maintain the operation of the Unit, at its option,
require Franchisee to close the Unit during such time period without removing any assets. If Pretzel
Time appoints a manager to maintain the operation of the Unit pending closing of such purchase, all
funds from the Unit's operation during the period of management by a Pretzel Time appointed manager
shall be kept in a separate fund and all expenses of the Unit, including compensation, other costs
and travel and living expenses of the Pretzel Time appointed manager, shall be charged to such fund.
As compensation for the management services provided, Pretzel Time shall charge such fund ten
percent (10%) of the Unit's net revenues during the period of Pretzel Time's management. Operation
of the Unit during any such period shall be for and on behalf of Franchisee, provided that Pretzel
Time shall have a duty only to utilize its good faith efforts and shall not be liable to Franchisee
or
<!-- page 37 -->
its Owners for any debts, losses or obligations incurred by the Unit or to any creditor of
Franchisee for any merchandise materials, supplies or service purchased by the Unit during any
period in which it is managed by Pretzel Time's appointed manager. Franchisee shall maintain in
force all insurance policies required for the Unit until the date of closing.

21. RELATIONSHIP OF THE PARTIES/INDEMNIFICATION.

21.A. EXCLUSIVE RELATIONSHIP.

Franchisee acknowledges and agrees that Pretzel Time would be unable to protect Confidential
Information against unauthorized use or disclosure and would be unable to encourage a free exchange
of ideas and information among Pretzel Time Units if Franchisees of Pretzel Time Units were
permitted to hold interests in or perform services for a Competitive Business except as specified in
Exhibit C. Franchisee also acknowledges that Pretzel Time has granted the Franchise to Franchisee in
consideration of and reliance upon Franchisee's agreement to deal exclusively with Pretzel Time.
Franchisee therefore agrees that during the term of the Franchise Agreement, or the period of time
which Franchisee operates a Unit under this Agreement, whichever is shorter, neither Franchisee nor
any Affiliate, immediate family member, or in the event Franchisee is a corporation

any Owner thereof and member of his immediate family or in the event Franchise is a partnership any
partner (general or limited) thereof and any member of his immediate family, shall:

(1) Have any direct or indirect interest as an owner, investor, partner, director, officer,
employee, consultant, representative, agent or in any other capacity in any Competitive Business
located or operating at the Site or within three (3) miles of any Pretzel Time Unit in operation or
under development on the effective date of termination or expiration of this Agreement, except a
Pretzel Time Unit operated by Franchisee under Franchise Agreements with Pretzel Time; or

(2) Recruit or hire any employee who, within the immediately preceding six (6) month period, was
employed by Pretzel Time or any Pretzel Time Unit operated by Pretzel Time, its Affiliates or
another franchisee or licensee of Pretzel Time, without obtaining the prior written permission of
Pretzel Time or such franchisee.

Notwithstanding the foregoing, Franchisee shall not be prohibited from owning securities listed on a
stock exchange or traded on the over-the-counter market that represents two percent (2%) or less of
that class of securities.

Covenants contained in this Section shall be construed as severable and independent, and shall be
interpreted and applied consistent with the requirements of reasonableness. Any judicial reformation
of these covenants consistent with this interpretation shall be enforceable as though contained
herein and shall not affect any other provisions or terms of this Agreement. This non-compete
provision may not be enforceable under the laws of your state.

21.B. NO LIABILITY FOR ACTS OF OTHER PARTY.

Franchisee shall not employ any of the Marks in signing any contract or applying for any franchise
or permit or in a manner that may result in Pretzel Time's liability for any of Franchisee's
indebtedness or obligations, nor may Franchisee use the Marks in any way not expressly authorized by
Pretzel Time. Except as expressly authorized in writing, neither Pretzel Time nor Franchisee shall
make any express or implied agreements, warranties, guarantees or representations or incur any debt
in the name or on behalf of the other, represent that their relationship is other than Pretzel Time
and franchisee, or be obligated by or have any liability under any agreements or representations
made by the other that are not expressly authorized in writing. Pretzel Time shall not be obligated
for any damages to any person or property directly or indirectly arising out of the operation of the
Unit or Franchisee's business authorized by or conducted pursuant to this Agreement.

21.C. TAXES.

Pretzel Time shall have no liability for any sales, use, service, occupation, excise, gross
receipts, income, property or other taxes, whether levied upon Franchisee, the Unit, Franchisee's
property or upon Pretzel Time, in connection with the sales made or business conducted by
Franchisee. Payment of all such taxes shall be Franchisee's responsibility.

21.D. INDEMNIFICATION.

Franchisee agrees to indemnify and hold Pretzel Time and its subsidiaries, Affiliates, stockholders,
directors, officers, employees, agents and assignees harmless against, and to reimburse them for,
any loss, liability, judgment or damages (actual or consequential) and all reasonable costs and
expenses of defending any claim brought against any of them or any action in which any of them is
named as a party (including, without limitation, reasonable accountants, attorneys' and expert
witness fees, costs of investigation, court costs, other litigation expenses, damages to Pretzel
Time's reputation and good will, travel expenses) which any of them may suffer, sustain or incur by
reason of, arising from or in connection with Franchisee's ownership or operation of the Unit,
unless such loss, liability or damage is only due to the negligence of Pretzel Time (or its
Affiliates, subsidiaries). Pretzel Time's right to indemnity under this agreement shall arise
notwithstanding that joint or concurrent liability may be imposed on Pretzel Time by statute,
ordinance, regulation or other law. Franchisee acknowledges and agrees that any action or inaction
by any third party which is not an Affiliate of Pretzel Time shall not
<!-- page 38 -->
be attributable to or constitute negligence of Pretzel Time. The indemnities and assumptions of
liabilities and obligations herein shall continue in full force and effect subsequent to and
notwithstanding the expiration or termination of this Agreement.

Pretzel Time shall notify Franchisee of any claims and Franchisee shall be given the opportunity to
assume the defense of the matter. If Franchisee fails to assume the defense within three (3) days of
notice thereof, Pretzel Time may defend the action in the manner reasonably appropriate, and
Franchisee shall pay to Pretzel Time all reasonable costs, including without limitation attorney's
fees, court costs, expert witness fees, travel and telephone expenses, incurred by Pretzel Time in
effecting such defense, in addition to any such sum which Pretzel Time may pay by reason of any
settlement agreed to by the parties or reasonably negotiated by Pretzel Time in the event Franchisee
fails to assume the defense, or judgment against Pretzel Time.

21.E. INDEPENDENT CONTRACTOR.

It is understood and agreed by the parties hereto that Franchisee is an independent contractor and
is not an agent, partner, joint venturer, or employee of Pretzel Time. Pretzel Time and Franchisee
agree that nothing in this Agreement is intended to create a fiduciary relationship between them.
Franchisee shall have no right to bind or obligate Pretzel Time in any way nor shall he represent
that he has any right to do so. Pretzel Time shall have no control over the terms and conditions of
employment of Franchisee's employees.

In all public records and in his relationship with other persons, on stationery, business forms and
checks, Franchisee shall indicate his independent ownership of the franchised Unit and that he is a
franchisee of Pretzel Time. Franchisee shall exhibit on the premises in such places as may be
designated by Pretzel Time, a Pretzel Time approved notice that the franchised Unit is operated by
an independent operator and not by Pretzel Time or Pretzel Time's Affiliates, which operate company
owned franchises. Franchisee shall take all legal steps such as a fictitious name registration to
ensure Franchisee's independent business status.

22. PROTECTION OF TRADE SECRETS.

22.A. CONFIDENTIAL INFORMATION.

Pretzel Time possesses and will further develop and acquire certain confidential and proprietary
information and trade secrets relating to the operation of Pretzel Time Units, which includes, but
not limited to the following categories of information, methods, techniques, procedures, and
knowledge developed or to be developed by Pretzel Time, its consultants or contractors, its
Affiliates or its designees, and/or franchisees ("Confidential Information"):

(1) methods, techniques, equipment, specifications, standards, policies, procedures, information,
concepts and systems relating to and knowledge of and experience in the development, operation and
franchising of Pretzel Time Units:

(2) site selection criteria;

(3) marketing and promotional programs for Pretzel Time Units;

(4) recipes, ingredients, formulas, mixes, spices, seasonings, sauces, recipes for, and methods for
the preparation, cooking, and serving of the Products;

(5) techniques, formats, specifications, systems, procedures, and knowledge of and experience in the
development and operation of Pretzel Time Units;

(6) knowledge of specifications for and suppliers of certain Products, materials, supplies,
equipment, furnishings and fixtures;

(7) sales data and information concerning inventory requirements for Products, materials and
supplies, and specifications for and knowledge of suppliers of certain materials, equipment, and
fixtures for Pretzel Time Units;

(8) employee selection procedures, training and staffing levels;

(9) Operations Manual and other Manuals prepared by Pretzel Time; and

(10) information concerning Product sales, operating results, financial performance and other
financial data of Pretzel Time Units.

Pretzel Time will disclose such parts of the Confidential Information as Pretzel Time deems
necessary or advisable from time to time in its sole discretion for the operation of a Pretzel Time
Unit to Franchisee during training, and in guidance and assistance furnished to Franchisee during
the term of the Franchise, and Franchisee may learn or otherwise obtain from Pretzel Time additional
Confidential Information of Pretzel Time during the term of the Franchise. Franchisee acknowledges
that the foregoing Confidential Information is highly confidential. Franchisee acknowledges and
agrees that he will not acquire any interest in Confidential Information, other than the right to
utilize Confidential Information disclosed to Franchisee in the operation of the Pretzel Time Unit
during the term of this Agreement, and that the use or duplication of any Confidential Information
in any other business would constitute an unfair method of competition. Franchisee, including its
directors,
<!-- page 39 -->
officers, shareholders, and partners agree(s) that Confidential Information is proprietary, includes
trade secrets of Pretzel Time and is disclosed to Franchisee solely on the condition that Franchisee
agrees, and Franchisee (and its Owners) does hereby agree, that he:

(1) shall not disclose any information pertaining to the Pretzel Time System, directly or
indirectly, to any person, natural or corporate, without the express prior written consent of
Pretzel Time. Franchisee may disclose to its Unit Manager such information deemed necessary to
disclose, provided such Unit Manager has agreed to maintain such information in confidence in
Pretzel Time's confidentiality agreement and Pretzel Time has received such executed agreement
(attached hereto as Exhibit H);

(2) Will not use Confidential Information in any other business or capacity;

(3) Will maintain the absolute confidentiality of Confidential Information during and after the term
of this Agreement;

(4) Will not make unauthorized copies of any portion of Confidential Information disclosed in
written or other tangible form; and

(5) Will adopt and implement all reasonable procedures that Pretzel Time prescribes from time to
time to prevent unauthorized use or disclosure of Confidential Information, including, without
limitation, restrictions on disclosure thereof to his employees.

This confidentiality requirement shall not apply in a judicial or administrative proceeding to the
extent Franchisee is legally compelled to disclose such information, provided Franchisee shall have
used his best efforts and shall have afforded Pretzel Time the opportunity to obtain an appropriate
protective order or other assurance satisfactory to Pretzel Time of confidential treatment for the
information required to be so disclosed. This restrictions on Franchisee's disclosure and use of the
Confidential Information shall also not apply to the disclosure of information, methods, procedures,
techniques and knowledge which are or become generally known in the food service business in the
Territory, other than through disclosure (whether deliberate or inadvertent) by Franchisee.

Notwithstanding the foregoing and any other provision of this Agreement, Franchisee may use the
Confidential Information in connection with the operation of other Pretzel Time Units (in addition
to the Unit) pursuant to other Franchise Agreements with Pretzel Time.

22.B. DISCLOSURE OF IDEAS AND NEW PROCEDURES.

Franchisee shall fully and promptly disclose to Pretzel Time, all ideas, concepts, methods and
techniques relating to the development and operation of a dessert or snack food business conceived
or developed by the Franchisee and/or Franchisee's employees during the term of this Agreement.
Franchisee agrees and grants to Pretzel Time and its Affiliates a perpetual and worldwide right to
use and authorize other Pretzel Time Units or other food service businesses operated by Pretzel Time
or its Affiliates, franchisees and designees to use such ideas, recipes, formulas, concepts,
methods, and techniques relating to the development and/or operation of a dessert or snack food
business. If incorporated into the Pretzel Time System for the development and/or operation of
Pretzel Time Units, such ideas, recipes, formulas, concepts, methods and techniques shall become the
sole and exclusive property of Pretzel Time without any further consideration to Franchisee. Pretzel
Time shall have no obligation to make any lump sum or on-going payments to Franchisee with respect
to any such idea, concept, method, technique or product. Franchisee agrees that Franchisee will not
use nor will it allow any other person or entity to use any such concept, method, technique or
product without obtaining Pretzel Time's prior written approval.

23. ENFORCEMENT.

23.A. UNAVOIDABLE DELAYS.

Delays in the performance of any duties hereunder which are not the fault of, and not within the
reasonable preventive control of, the party due to perform, including but not limited to, fire,
flood, labor disputes, natural disasters, acts of God, civil disorders, riots, insurrections, work
stoppages, slowdowns or disputes, or other similar events, shall not cause a default in said
performance, but the parties shall extend the time of performance for a period of time equivalent to
the length of delay, or for such other reasonable period of time as agreed by the parties.

23.B. RIGHTS OF PARTIES ARE CUMULATIVE.

The rights of Pretzel Time and Franchisee hereunder are cumulative and no exercise or enforcement by
Pretzel Time or Franchisee of any right or remedy hereunder shall preclude the exercise or
enforcement by Pretzel Time or Franchisee of any other right or remedy herein or which Pretzel Time
or Franchisee is entitled by law to enforce.

23.C. WAIVER OF OBLIGATIONS.

Pretzel Time may by written instrument unilaterally waive or reduce any obligation of or restriction
upon Franchisee under this Agreement, and Franchisee may by written instrument unilaterally waive or
reduce any obligation of or restriction upon Pretzel Time under this Agreement, effective upon
delivery of written notice thereof to the other or such other effective date stated on the notice of
waiver. Whenever this Agreement requires Pretzel Time's
<!-- page 40 -->
prior approval or consent, Franchisee shall make a timely written request therefore, and such
approval shall be obtained in writing. Pretzel Time makes no warranties or guaranties upon which
Franchisee may rely, and assumes no liability or obligation to Franchisee, by granting any waiver,
approval or consent to Franchisee, or by reason of any neglect, delay, or denial of any request
therefore. Any waiver granted by Pretzel Time shall be without prejudice to any other rights Pretzel
Time may have, will be subject

to continuing review by Pretzel Time, and may be revoked, in Pretzel Time's sole discretion, at any
time and for any reason, effective upon delivery to Franchisee of ten (10) days' prior written
notice.

23.D. CONTINUING OBLIGATIONS.

All obligations of Pretzel Time and Franchisee which expressly or by their very nature survive the
expiration or termination of this Agreement shall continue in full force and effect subsequent to
and notwithstanding its expiration or termination and until they are satisfied or by their nature
expire.

23.E. INVALID OR UNENFORCEABLE PROVISIONS.

If any provisions of this Agreement, or its application to any person or circumstance, is deemed
invalid or unenforceable by a court of competent jurisdiction, then the remainder of this Agreement
or the application of such provision to other persons or circumstances shall not be affected
thereby, provided, however, that if any provision or application thereof is invalid or
unenforceable, the court shall substitute a suitable and equitable provision therefore in order to
carry out, so far as may be valid and enforceable, the intent and purpose of the invalid or
unenforceable provision.

If any applicable and binding law or rule of any jurisdiction requires a greater prior notice of the
termination of or refusal to enter into a successor Franchise Agreement to this Agreement than is
required hereunder, or the taking of some other action not required hereunder, or if, under any
applicable and binding law or rule of any jurisdiction, any provision of this Agreement or any
standard or procedure outlined in the Operations Manual is invalid or unenforceable, the prior
notice and/or other action required by such law or rule shall be substituted for the comparable
provisions hereof, and Pretzel Time shall have the right, in its sole discretion, to modify such
invalid or unenforceable operations procedure or standard to the extent required to be valid and
enforceable.

23.F. INJUNCTIVE RELIEF.

Franchisee recognizes and acknowledges the unique value and secondary meaning attached to the
Pretzel Time system, its trademarks, service marks, standards of operation and Pretzel Time's
property. Franchisee acknowledges and agrees that any noncompliance with the restrictive covenants
contained herein, including without limitation those provisions pertaining to noncompetition,
confidentiality and the improper or unauthorized use of Pretzel Time's Marks will cause irreparable
damage to Pretzel Time and its franchisees. Franchisee therefore agrees that should it violate any
restrictive covenant, or threaten to breach the restrictive covenants, then Pretzel Time shall be
entitled to both permanent and temporary injunctive relief, without bond, from any court of
competent jurisdiction in addition to any other remedies to which Pretzel Time may be entitled, at
law or in equity, under this agreement or otherwise under applicable law.

23.G. APPLICABLE LAW.

Except to the extent governed by the U.S. Trademark Act of 1946 (Lanham Act, 15 U.S.C. "1051 et
seq.), this Agreement, the other agreements referred herein, and the offer and the sale of the
franchise shall be governed in all respects and aspects by the laws of the Commonwealth of
Pennsylvania and expressly excluding the laws pertaining to the choice of law and conflict of laws.

23.H. ENTIRE STATUS OF AGREEMENT.

This Agreement contains the entire agreement of the parties and there are no other oral or written
understandings or agreements between Pretzel Time and Franchisee relating to the subject matter of
this agreement, except as set forth in Pretzel Time's Offering Circular required by Rule under the
Federal Trade Commission Act, a copy of which has been provided to Franchisee and of which
Franchisee acknowledges receipt, there are no representations, inducements, promises, agreements
arrangements or undertakings, oral or written, between the parties hereto other than those set forth
and duly executed in writing. No agreement of any kind shall be binding upon either party unless and
until the same has been made in writing and duly executed by both parties.

Upon acceptance of this Agreement by Pretzel Time, all previous agreements, contracts, arrangements
or understandings of any kind, oral or written, relative to the franchise granted herein are
cancelled, and all claims and demands thereon are fully satisfied. This agreement, although drawn by
Pretzel Time, shall be construed fairly and reasonable, and not more strictly against one party than
against the other party hereto.

23.I. AMENDMENT OF AGREEMENT.

This Agreement shall not be modified or amended except by written
<!-- page 41 -->
agreement executed by both parties hereto. No oral amendment or waiver will be effective and that
this provision cannot be orally amended or waived. No waiver of default or rights will be effective
unless in writing.

23.J. HEIRS, SUCCESSORS AND ASSIGNS.

Subject to the provisions hereof relating to transfer and assignment, this Agreement is intended to
and does bind the heirs, executors, administrators and successors of any or all of the parties
hereto.

23.K. CONDITIONS AND CONTINGENCIES.

The obligations of the parties hereunder are expressly conditional and contingent upon the full
execution of and performance of all obligations by the parties under this Agreement. This Agreement
is expressly conditional upon Franchisee executing all documents required by this Agreement within
ten (10) days of receipt of the document. Failure by Franchisee to execute any documents shall
result in the Agreement being null and void.

In addition during Franchisee's training, all documents pertaining to the franchising of Franchisee
as a Pretzel Time Unit shall be held in escrow by Pretzel Time. Title in and to the Pretzel Time
Unit shall not pass to Franchisee until Franchisee has been trained as a Pretzel Time franchisee to
the satisfaction of Pretzel Time. If Franchisee fails to satisfactorily complete Pretzel Time
initial training, the appointment of Franchisee as a Pretzel Time franchisee and the granting of the
franchise business to Franchisee shall be null and void, all documents executed between Franchisee
and Pretzel Time or its designees with respect to the transaction shall be terminated and cancelled.
The Franchisee acknowledges and agrees that no portion of the Franchise fee shall be refunded if
Franchisee fails to complete Pretzel Time's initial training class to the satisfaction of Pretzel
Time. If the Franchisee completes the initial training to the satisfaction of Pretzel Time, Pretzel
Time will provide to Franchisee fully signed copies of the Franchise Agreement.

It is understood and agreed by the parties that the granting of the franchise and all contracts and
agreements entered into by and between the parties with respect to the Unit are specifically
contingent upon the signing of a lease for the Site. In the event that a lease for the Site cannot
be obtained on or before sixty (60) days after delivery of Pretzel Time's approval of the Site at no
fault or delay by Franchisee, then all contracts and agreements entered into by Pretzel Time, and
Franchisee shall become null and void and of no effect, and all monies deposited by Franchisee less
a nonrefundable fee of $2,500 shall be refunded.

23.L. WAIVER BY PRETZEL TIME.

No waiver by Pretzel Time of any default or failure to perform by Franchisee, or of any breach of
the terms of this Agreement or no failure, refusal or neglect of Pretzel Time to exercise any right,
option or power given it under this Agreement, shall preclude Pretzel Time from thereafter requiring
strict compliance or from declaring this Agreement and the franchise granted herein revoke or
terminated. The failure of Pretzel Time to terminate this Agreement upon the occurrence of one or
more Acts of Default will not constitute a waiver or otherwise affect the right of Pretzel Time to
terminate this Franchise because of a continuing or subsequent failure to cure one or more of the
aforesaid events of default or any other default.

23.M. COSTS AND EXPENSES OF ENFORCEMENT.

If a claim for amounts owed by Franchisee to Pretzel Time or its Affiliates is asserted in any
judicial or arbitration proceeding or later appeal, or if Pretzel Time is required to enforce the
Franchise Agreement in a judicial or arbitration proceeding or later appeal, the prevailing party
will be entitled to reimbursement of its costs and expenses, including reasonable arbitrators',
accountants' and legal fees, whether incurred prior to, in preparation for or in contemplation of
the filing of any written demand, claim, action, hearing or proceeding to enforce the obligations of
the Franchise Agreement. If Pretzel Time incurs expenses in connection with your failure to pay when
due amounts owing to Pretzel Time, to submit when due any reports, information or supporting records
or otherwise to comply with the Franchise Agreement, including, but not limited to legal,
arbitrators' and accounting fees, you are required to reimburse Pretzel Time for any such costs and
expenses which it incurs. 23.N. RIGHTS OF PARTIES ARE CUMULATIVE

THE RIGHTS OF FRANCHISEE AND PRETZEL TIME ARE CUMULATIVE AND NO EXERCISE OR ENFORCEMENT BY PRETZEL
TIME OR FRANCHISEE OF ANY RIGHT OR REMEDY HEREUNDER SHALL PRECLUDE THE EXERCISE OR ENFORCEMENT BY
PRETZEL TIME OR FRANCHISEE OF ANY OTHER RIGHT OR REMEDY TO WHICH THE PARTY IS ENTITLED.

23.O. WAIVER OF JURY TRIAL.

BOTH PRETZEL TIME AND THE FRANCHISEE IRREVOCABLY WAIVES TRIAL BY JURY IN ANY ACTION, PROCEEDING OR
COUNTERCLAIM, WHETHER AT LAW OR IN EQUITY, BROUGHT BY EITHER PARTY. THE PARTIES FURTHER AGREE THAT
NEITHER SHALL DEMAND A JURY TRIAL IN THE EVENT OF LITIGATION.

23.P. WAIVER OF PUNITIVE DAMAGES.

EXCEPT WITH RESPECT TO FRANCHISEE'S OBLIGATION TO INDEMNIFY PRETZEL TIME, THE PARTIES WAIVE TO THE
FULLEST EXTENT PERMITTED BY LAW ANY RIGHT TO OR CLAIM FOR ANY PUNITIVE OR EXEMPLARY DAMAGES AGAINST
THE OTHER AND AGREE THAT, IN THE EVENT OF A DISPUTE BETWEEN THEM, THE PARTY MAKING A CLAIM SHALL BE
LIMITED TO RECOVERY OF ANY ACTUAL DAMAGES IT SUSTAINS.

23.Q. EXCLUSIVE JURISDICTION.
<!-- page 42 -->
BOTH PRETZEL TIME AND FRANCHISEE AGREE THAT ANY ACTION ARISING OUT OF OR RELATING TO THIS AGREEMENT,
INCLUDING WITHOUT LIMITATION, THE OFFER AND GRANTING OF THE FRANCHISE RIGHTS HEREUNDER SHALL BE
INSTITUTED AND MAINTAINED ONLY IN A STATE OR FEDERAL COURT OF GENERAL JURISDICTION IN DAUPHIN
COUNTY, PENNSYLVANIA OR THE COUNTY IN WHICH PRETZEL TIME MAINTAINS ITS PRINCIPAL PLACE OF BUSINESS.

FRANCHISEE IRREVOCABLY SUBMITS TO THE JURISDICTION OF SAID COURT AND WAIVES ANY OBJECTION FRANCHISEE
MAY HAVE TO EITHER THE JURISDICTION OR VENUE OF SUCH COURT.

23.R. LIMITATIONS OF CLAIMS

EXCEPT FOR CLAIMS BROUGHT BY PRETZEL TIME WITH REGARD TO FRANCHISEE'S OBLIGATIONS TO MAKE PAYMENTS
TO PRETZEL TIME PURSUANT TO THIS AGREEMENT OR TO INDEMNIFY PRETZEL TIME PURSUANT TO THIS AGREEMENT,
ANY AND ALL CLAIMS ARISING OUT OF OR RELATING TO THIS AGREEMENT OR THE RELATIONSHIP OF FRANCHISEE
AND PRETZEL TIME PURSUANT TO THIS AGREEMENT SHALL BE BARRED UNLESS AN ACTION IS COMMENCED WITHIN:
(1) TWO (2) YEARS FROM THE DATE ON WHICH THE ACT OR EVENT GIVING RISE TO THE CLAIM OCCURRED OR (2)
ONE (1) YEAR FROM THE DATE ON WHICH FRANCHISEE OR PRETZEL TIME KNEW OR SHOULD HAVE KNOWN, IN THE
EXERCISE OF REASONABLE DILIGENCE OF THE FACTS GIVEN RISE TO SUCH CLAIMS, WHICHEVER OCCURS FIRST.

24. ACKNOWLEDGMENTS AND REPRESENTATIONS.

Franchisee acknowledges that he has read this Agreement and that he understands and accepts the
terms, conditions and covenants contained in this Agreement as being reasonably necessary to
maintain Pretzel Time's high quality and service and the uniformity of those standards at all
Pretzel Time Units and thereby to protect and preserve the goodwill of the Marks.

Pretzel Time disclaims and Franchisee acknowledges that he has not received or relied upon any
representations, promises, guarantees or warranties, expressed or implied, made to induce the
execution hereof or in connection herewith which is not expressly contained herein or in the
disclosure statement. More specifically, Franchisee acknowledges and agrees that no person acting on
behalf of Pretzel Time or its affiliated companies has made any written or oral claim, statement,
assurance, promise or projection of any sort regarding the actual or prospective sales, earnings,
gross profit or net profit of the franchise, which is the subject of this agreement. Franchisee
acknowledges and agrees that Pretzel Time's officers, directors, employees and agents act only in a
representative and not in a personal capacity in connection with any of their dealings with
Franchisee. Franchisee recognizes that neither Pretzel Time nor any other person can guarantee
Franchisee's success in the franchised business. Franchisee further represents to Pretzel Time, as
an inducement to its entry into this Agreement, that all statements in Franchisee's application for
the Franchise are accurate and complete and that Franchisee has made no misrepresentations or
material omissions in obtaining the franchise.

25. CONSTRUCTION.

25.A. HEADINGS.

The Section headings throughout this Agreement are for the convenience and reference only of the
parties and their attorneys, and the words contained therein shall not be held to expand, modify,
limit, define, amplify or aid in the interpretation, construction or meaning of this Agreement.

25.B. TERMINOLOGY.

All terms and words used in this Agreement, regardless of the number and gender in which they are
used, shall be deemed and construed to include any other number, singular or plural, and any other
gender, masculine, feminine, or neuter, as the context or sense of this Agreement or any Section or
clause herein may require, as if such word had been fully and properly written in the appropriate
number and gender. The term Franchisee as used herein is applicable to one or more persons, a
corporation or a partnership, as the case may be. If two or more persons are at any time Franchisee
hereunder, their obligations and liabilities to Pretzel Time shall be joint and several. References
to Franchisee and assignee which are applicable to an individual or individuals shall mean the
Owners of Franchisee or the assignee, if the Franchisee or the assignee is a corporation nor
partnership.

25.C. COUNTERPARTS.

This Agreement may be executed in one or more counterparts, any and all of which shall constitute
one and the same instrument.

25.D. REASONABLENESS.

Pretzel Time and Franchisee agree to act reasonably in all dealings with each other pursuant to this
Agreement. Whenever the consent or approval of either party is required or contemplated, the party
whose consent is required agrees not to unreasonably withhold the same, unless such consent is
expressly subject to such party's sole discretion pursuant to the terms of this Agreement. In no
event shall Pretzel Time's withholding of consent allow Franchisee a claim for money damages.

26. SECURITY AGREEMENT.
<!-- page 43 -->
26.A. SECURITY INTEREST.

In order to secure full and prompt payment of the fees and other charges to be paid by Franchisee to
Pretzel Time, and to secure performance of the other obligations and covenants to be performed by
Franchisee, under this Agreement, Franchisee hereby grants Pretzel Time a valid and effectual
security interest in, lien upon, and right of set off against all of Franchisee's interest in the
improvements, fixtures, inventory, goods, appliances and equipment now or hereafter owned and
located at the Unit (whether annexed to the Premises or not) or used in connection with the business
conducted at the Unit, including, without in any manner limiting the generality of the foregoing,
all machinery, materials, appliances and fixtures for generating or distributing air, water, heat,
electricity, light, fuel or refrigeration, for ventilating, cooling or sanitary purposes, for the
exclusion of vermin or insects and for the removal of dust, refuse or garbage; all engines,
machinery, ovens, refrigerators, freezers, furnaces, partitions, doors, vaults, sprinkling systems,
light fixtures, fire hoses, fire brackets, fire boxes, alarm systems, brackets, screens, floor tile,
linoleum, carpets, plumbing, water systems, appliances, walk-in refrigerator boxes, cabinets,
dishwashers, stoves, set-up tables, rolling counters, kitchen ranges, display counters and shelves,
humidified cabinets, computers and computer software, and other equipment and installations; all
other and further installations and appliances; all raw materials, work in process, finished goods
and all inventory; and all replacements thereof, attachments, additions and accessions thereto, and
products and proceeds thereof in any form, including but not limited to insurance proceeds and any
claims against third parties for loss or damage to or destruction of any or all of the foregoing
(collectively, the "Collateral"). Without the prior written consent of Pretzel Time, Franchisee
agrees that no lien upon or security interest in the Collateral or any item thereof will be created
or suffered to be created and that no lease will be entered into with respect to any item of
Collateral. Franchisee will not sell or otherwise dispose of any item of Collateral, or remove any
Collateral from the Premises, unless the same is replaced by a similar item of equal or greater
value, and except for the sale of inventory in the ordinary course of business, without the prior
written consent of Pretzel Time. Franchisee agrees to give to Pretzel Time advance notice in writing
of any proposed change in Franchisee's name, identity or structure and not to make any such change
without the prior written consent of Pretzel Time and compliance with the provisions of this
Agreement. Franchisee agrees to execute for filing such financing statements and continuation
statements as Pretzel Time may require from time to time. Pretzel Time agrees to pay all filing
fees, including fees for filing continuation statements in connection with such financing
statements.

26.B. DEFAULT REMEDIES UNDER U.C.C.

In the event of a default by Franchisee under this Agreement, Pretzel Time shall have the remedies
and rights available as a secured party with respect to the Collateral under the Uniform Commercial
Code as in effect from time to time in the state where the premises are located. The grant of the
security interest to Franchisee pursuant to this Section shall not be construed to derogate from or
impair any other rights which Pretzel Time may have under this Agreement or otherwise at law or
equity.

27. NOTICES.

27.A. DELIVERY OF NOTICES.

All written notices permitted or required to be delivered by the provisions of this Agreement or of
the Operations Manual shall be deemed so delivered to the Franchisee:

a. At the time delivered by hand; or

b. One business day after transmission by facsimile, telecopy, telegraph or other electronic system;

c. One business day after being placed in the hands of a commercial carrier service for next
business day delivery; or

d. Three (3) business days after placement in the United States mail by registered or certified
mail, return receipt requested, postage prepaid and addressed to the party to be notified at the
addresses listed below or the most current business address of which the notifying party has been
notified. If Franchisee refuses delivery of the same then notice shall be deemed delivered when
refused by Franchisee.

IF TO PRETZEL TIME:

Pretzel Time, Inc. Attn: Martin Lisiewski, CEO 4800 Linglestown Road, Suite 202 Harrisburg,
Pennsylvania 17112

WITH COPIES TO:

Rashti and Mitchell Attorneys at Law Attn: Timothy T. Mitchell 4422 Ridgeside Drive Dallas, Texas
75244
<!-- page 44 -->
IF TO FRANCHISEE:

IN WITNESS WHEREOF, the parties hereto have executed this Agreement the day and year first written
above.

WITNESSES: PRETZEL TIME, INC. FRANCHISOR

- ----------------------- BY:

_______________________ NAME: ____________________

TITLE: _____________________

WITNESSES: FRANCHISEE: ----------------------------

BY:

______________________ NAME: _____________________

TITLE:

CORPORATE ACKNOWLEDGMENT

STATE OF ) : ' COUNTY OF )

On this _____ day of ___________, 19 __, before me, (Name of Notary)

the undersigned officer, personally appeared and , known personally to me to be the Presidentand
Secretary, respectively, of the above-named corporation, and that they, as such officers, being
authorized to do so, executed the foregoing instrument for the purpose therein contained, by signing
the name of the corporation for themselves as such officers.

IN WITNESS WHEREOF I have hereunto set my hand and official seal.

(Notary Public)

My Commission Expires:

(Notary Seal)

INDIVIDUAL OR PARTNERSHIP ACKNOWLEDGMENT

STATE OF ) : ' COUNTY OF )

On this _____ day of ___________, 19 __, before me, (Name of Notary)

the undersigned officer, personally appeared to me personally known and known to me to be the same
person(s) whose name(s) is (are) signed to the foregoing instrument, and acknowledged the execution
thereof for the uses and purposes therein set forth.

IN WITNESS WHEREOF I have hereunto set my hand and official seal.

(Notary Public)

My Commission Expires:
<!-- page 45 -->
(Notary Seal)

FRAN.AGT 6.5.96 FRANCHISE AGREEMENT

By and between

Pretzel Time, Inc., a Pennsylvania corporation as Franchisor

and

, Franchisee

EXHIBIT C TO THE OFFERING CIRCULAR OF PRETZEL TIME, INC.

FRANCHISE AGREEMENT

Exhibit "M"

Sublease

[Substitute 2 page short form - Karen to send Tim the disk]
