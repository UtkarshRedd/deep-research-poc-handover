<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2011-02-21 |
| Parties | Golfers Incorporated ("Company"); Andy North ("North") |
| Source | CUAD v1 / PerformanceSportsBrandsInc_20110909_S-1_EX-10.10_7220214_EX-10.10_Endorsement Agreement |

ENDORSEMENT AGREEMENT entered into by and between ANDY NORTH and GOLFERS INCORPORATED

Effective February 21, 2011

Source: PERFORMANCE SPORTS BRANDS, INC., S-1, 9/9/2011
<!-- page 2 -->
TABLE OF CONTENTS

Paragraph Page 1. Definitions 3 2. Term 4 3. Grant of License and Exclusivity 4 4. Retention of
Rights 4 5. Appearances 4 6. Compensation 5 7. Supply of Endorsed Products 6 8. Approval of
Advertising 7 9. Ownership 8 10. SAG and/or AFTRA 8 11. Standards 8 12. Events of Default 8 13.
Termination/Remedies 9 14. Company's Debts 9 15. Indemnification 9 16. Insurance 9 17. Waiver 9 18.
Notices 10 19. Assignment 10 20. Independent Contractor 10 21. Joint Venture 10 22. Governing Law 10
23 Entire Agreement 10 24. Amendments 10 25. Authority 11 26. Severability 11 27. Compliance with
Laws 11 28. Attorney's Fees and Costs 11 29. Force Majeure 11 30. Confidentiality 11 31.
Counterparts 11

Page 2 of 12

Source: PERFORMANCE SPORTS BRANDS, INC., S-1, 9/9/2011
<!-- page 3 -->
ENDORSEMENT AGREEMENT THIS ENDORSEMENT AGREEMENT (herein the "Agreement") is effective on this 21s t
day of February 2011, by and between Golfers Incorporated, a Delaware Corporation, having a mailing
address of 1021 N. Sepulveda Blvd., Suite G, Manhattan Beach, CA 90266 (hereinafter referred to as
"Company") and Andy North, having a mailing address of 1624 S. High Point Road, Madison, WI 53719
(hereinafter referred to as "North"). WITNESSETH WHEREAS, North is recognized and known throughout
the world to be a highly skilled golfer and television commentator; and WHEREAS, North's name and
likeness (hereinafter defined) has commercial value with respect to the advertisement, promotion and
sale of products and services in the commercial marketplace; and WHEREAS, Company is engaged in the
business of developing, marketing and selling F2 Golf Clubs (hereinafter referred to as "Product"),
and Company desires to obtain North's services and endorsement to be utilized in the advertising and
sale of such Product; and WHEREAS, North agrees, subject to the terms and conditions contained
herein, to provide certain services to Company and to authorize the use of North's endorsement by
Company for such purposes. NOW, THEREFORE, in consideration of the mutual promises and covenants
contained herein, and for other good and valuable consideration, the receipt and sufficiency of
which are hereby acknowledged, the parties agree as follows:

1. Definitions. As used herein, the following terms shall be defined as set forth below:

a. "Contract Period" shall mean that period of time from February 21, 2011 through December 31,
2012.

b. "Contract Year" shall mean the specific period of time during the Contract Period as more
specifically set forth below: · Contract Year 2011 (2/21/11 - 12/31/11) · Contract Year 2012
(1/1/12- 12/31/12)

c. "Contract Territory" shall mean the world.

d. "North's Likeness" shall mean and include North's name, image, photograph, voice, initials,
signature, biographical information, and persona.

f. "North's Endorsement" shall mean and include North's public statements and comments about
Company's Product.

Page 3 of 12

Source: PERFORMANCE SPORTS BRANDS, INC., S-1, 9/9/2011
<!-- page 4 -->
g. "Endorsed Product(s)" shall only mean and include Company's irons, woods, wedges and putters.

2. Term. The Term of this Agreement shall be for the Contract Period unless it is terminated or
extended as set forth in this Agreement.

3. Grant of License and Exclusivity. Subject to the terms set forth in this Agreement, North hereby
grants to Company the right and privilege to use North's Likeness and North's Endorsement during the
Term and within the Contract Territory in all reasonable forms of advertising including, but not
limited to television (including the infomercial format), radio, print advertising, brochures,
pamphlets, product packaging, point-of-purchase materials, Company's web-site and a demonstration
video (hereinafter referred to as "Advertising Materials") in connection with Company's
advertisement and sale of the Endorsed Product only. During the Term of this Agreement and within
the Contract Territory, North agrees not to enter into an agreement with another company or entity
for the purpose of endorsing or promoting products similar to the Endorsed Products. Upon the
expiration or termination of this Agreement, Company shall be prohibited from using or distributing
any new or existing Advertising Materials using North's Likeness and North's Endorsement except for
Endorsed Product with North's Likeness and/or North's Endorsement on the packaging that is already
in the channel of retail distribution. Company shall be prohibited from selling or shipping any new
Endorsed Product with North's Likeness and/or North's Endorsement on the packaging upon the
expiration or termination of this Agreement.

4. Retention of Rights. All rights not specifically granted or licensed to Company hereunder shall
be reserved and retained by North and may be utilized or licensed by North to any third parties in
any manner which is not in contravention of this Agreement.

5. Appearances.

a. Production Appearances.

i. Contract Year 2011. North agrees to make one (1) Production Appearance on behalf of Company
during Contract Year 2011 for the purpose of producing the following: (1) one 30-minute infomercial;
(2) one 30-second television commercial; (3) one demonstration dvd on how to use the Endorsed
Product. (4) product testimonials and (5) still photographs for print advertisements and packaging
(hereinafter referred to as "Production Appearance"). Said Production Appearance shall take place on
February 22 & 23, 2011 in or around Phoenix, AZ. The Production Appearance shall be approximately
nine (9) hours in duration on February 22nd and five (5) hours in duration on February 23rd. During
such Production Appearance, North shall be permitted to wear the apparel of his choice. ii. Contract
Year 2012. North agrees to make one (1) Production Appearance on behalf of Company during Contract
Year 2012 for the purpose of producing either new or updated Advertising Materials. Said Production
Appearance shall take place at a mutually agreed upon time and location. The Production Appearance
shall be approximately nine (9) hours in duration on the first day and five (5) hours in duration on
the second day. During such Production Appearance, North shall be permitted to wear the apparel of
his choice.

Page 4 of 12

Source: PERFORMANCE SPORTS BRANDS, INC., S-1, 9/9/2011
<!-- page 5 -->
b. Additional Production/Promotional Appearances. If requested by Company, North agrees to use
reasonable effort to make Additional Production/Promotional Appearances on behalf of Company
(hereinafter referred to as "Additional Production/Promotional Appearances"). Should Company request
for North to conduct Additional Production/Promotional Appearances and North agrees to appear,
Company shall pay North an additional fee for such appearance(s) as set forth in paragraph 6.d.
below. North has no obligation to make such appearance.

c. Voice-Over Appearances. If requested by Company, North shall make one (1) voice over appearance
during the Term. The voice over appearance shall take place at North's personal residence or at
another mutually agreed upon location in Wisconsin, and shall not exceed two (2) hours in duration.

d. Promotional Appearance. If requested by Company, North agrees to make one (1) promotional
appearance each Contract Year during the Term at certain events to promote the Endorsed Products.
Said appearance shall be approximately three (3) hours in duration.

e. Promotion/Media Activities. North will use reasonable efforts to mention the benefits of
Company's Endorsed Products when North is being interviewed or North is participating in Public
Events as defined below.

f. Expenses. If travel is necessary to provide the services set forth in this Agreement, Company
shall provide or reimburse all such travel expenses of North, including round-trip first-class
airfare on the airline of North's choice, first-class hotel accommodations, reasonable meal and
ground transportation expenses. Company shall deliver the airline tickets to North at least seven
(7) days prior to the scheduled appearance, and reimburse North for other such expenses within ten
(10) days after receipt of the expense receipts.

g. Scheduling. All appearances shall be scheduled on dates, times and locations that are mutually
agreed upon by Company and North. All such appearances shall be scheduled through North's duly
authorized agent for this project-Fidelity Sports Group, LLC.

6. Use of F2 Wedges/Using F2 Golf Bag. During the Contract Period and within the Contract Territory,
North agrees to:

a. Wedges. Use Company's F2 branded wedges when competing professionally, conducting public clinics
or outings, participating in public golf events and when appearing at other public functions where
it is appropriate to use or have golf clubs at such events (herein "Public Events').

Page 5 of 12

Source: PERFORMANCE SPORTS BRANDS, INC., S-1, 9/9/2011
<!-- page 6 -->
The Contract Year 2011 Guaranteed Fee shall be paid as follows:

The Contract Year 2012 Guaranteed Fee shall be paid as follows:

b. Golf Bag. Use and carry Company's F2 branded golf bag at all Public Events as defined immediately
above. North shall have the right to place a maximum of two (2) non-competitive third party sponsor
names/logos that are of a reasonable size on the belly portion of the F2 branded golf bag.

c. Irons, Woods, Putter. Use reasonable efforts to use F2 branded irons, woods and putter at all
Public Events. For purposes of clarification, North shall not be required to use F2 branded irons,
woods and putters.

7. Compensation. a. Guaranteed Service Fee and Marketing Retainer. In consideration for the rights,
services and benefits granted by North hereunder, Company agrees to pay North a non-refundable
Guaranteed Service Fee and Marketing Retainer (hereinafter referred to as "Guaranteed Fee") of
fifty-five thousand dollars ($55,000USD) in Contract Year 2011 and seventy thousand dollars
($70,000USD) in Contract Year 2012.

(i) Twenty-Five thousand dollars ($25,000USD) on or before two days after this Agreement is fully
executed. (ii) Fifteen thousand dollars ($15,000USD) on or before July 1, 2011. (iii) Fifteen
thousand dollars ($ 15,000USD) on or before November 1, 2011.

(i) Twenty-Five thousand dollars ($25,000USD) on or before February 1, 2012 (ii) Twenty-Five
thousand dollars ($25,000USD) on or before July 1, 2012 (iii) Twenty thousand dollars ($20,000USD)
on or before November 1, 2012

b. Royalties. In addition to payments due North by Company as set forth in paragraphs 7.a. above,
Company further agrees to pay North a one percent (1%) royalty on all Gross Revenue generated from
the sale of all Company Products (herein "Royalties").

c. Payment of Royalties/Statement of Accounts. (i) Company agrees to pay all royalties due as set
forth in section 7.b. above on or before thirty (30) days following the end of each quarterly period
during the Contract Period. The quarterly royalty payment shall be accompanied by a statement of
account indicating the quantities of Products sold, the Gross Revenue generated from all sales of
the Product where the sales were derived from (i.e. direct sales or retail sales) and the royalty
payment that is due to North. (ii) Company shall keep, at its principal office, 1021 N. Sepulveda
Blvd., Suite G, Manhattan Beach, CA 90266, a complete and accurate set of books and records
maintained in accordance with generally accepted accounting principles and business practices. Said
books and records shall be maintained for a two (2) year period following the expiration or
termination of this Agreement. Company shall make said books available to North or North's
representative on reasonable notice during the Term of this Agreement and the two (2) year period
immediately following thereafter. The cost of any and all inspections shall be paid by North, unless
an inspection shows an under-reporting or under-payment of more than five- percent (5%) for any
quarterly period, in which event Company shall reimburse North for all such inspection costs.

Page 6 of 12

Source: PERFORMANCE SPORTS BRANDS, INC., S-1, 9/9/2011
<!-- page 7 -->
Fidelity Sports Group, LLC Bank of America ABA #: 026009593 SWIFT Code #: BOFAUS3N Trust Account #:
8980 1796 5942

d. Additional Production/Promotional Appearances Fee. In addition to the amounts payable by Company
to North set forth in paragraph 7.a. and 7.b. above, and should Company request for North to make
Additional Production/Promotional Appearances, Company further agrees to pay North a mutually agreed
upon fee for each Additional Production/Promotional Appearance conducted by North. All compensation
to be paid to North for Additional Production/Promotional Appearances shall be due and payable to
North prior to each scheduled Additional Production/Promotional Appearance.

e. Form of Payment. All payments hereunder shall be made payable to the order of "Fidelity Sports
Group, LLC, as agent for Andy North" and shall be paid via check or wire transfer. If by wire
transfer, then direct payment to the following bank account:

f. Late Payments. Amounts not received within ten (10) days following their respective due dates
shall be assessed a late charge equal to one and one-half percent (1 _%) per month of the overdue
amount until paid, commencing on the eleventh day.

g. Supply of Endorsed Products. Company shall deliver to North, at no charge, and in a timely
fashion, a reasonable number of Endorsed Products for North's personal use each Contract Year during
the Contract Period. All postage expenses associated with the delivery of the Endorsed Products
shall be borne by Company.

8. Approval of Advertising. a. Company agrees that it will not use North's Likeness or North's
Endorsement hereunder unless and until all Advertising Materials and their intended use has been
approved by North. North agrees that any Advertising Materials submitted for approval as provided
herein may be deemed by Company to have been approved hereunder if the same is not disapproved by
North within seven (7) business days after receipt thereof. North agrees that any Advertising
Materials submitted hereunder will not be unreasonably disapproved and, if it is disapproved, that
Company will be advised of the specific grounds for the disapproval. Company shall not use such
disapproved Advertising Materials until it has written approval from North.

Page 7 of 12

Source: PERFORMANCE SPORTS BRANDS, INC., S-1, 9/9/2011
<!-- page 8 -->
b. Should Company utilize stock photographs of North, Company agrees to use current photographs and
not to add, delete, alter, amend or modify any existing names, logos, designs, trademarks or other
indicia of any other sponsor of North which appear in the portion of the photograph used by Company.

c. Company acknowledges and agrees that the script and layout of the Advertising Materials,
including, but not limited to the infomercial, shall be reasonably compatible with North's
personality and/or style. Should the Advertising Materials be approved as set forth in Section 8.a.
above, the Advertising Materials shall reflect North's personal experience and/or "testimonial"
concerning the Product. Such Advertising Material shall be deemed to be North's representation and
warranty that such testimonial copy in fact reflects North's personal experience with and opinion of
the Endorsed Product.

9. Ownership. All materials, in any form whatsoever, relating to the Advertising Materials will be
and shall remain the absolute property of Company. North acknowledge that they do not now have and
in the future will assert no right, title, or interest of any kind or nature whatsoever, in or to
any component of the Advertising Materials. Furthermore, subject to North's approval as set forth in
section 8 above, Company shall have the right at any time during the Term of this Agreement to make
any revisions to the Advertising Materials or prepare versions of all or any part of the Advertising
Materials to conform to the requirements of individual markets or customers.

10. SAG and/or AFTRA. In the event of any of the Advertising Materials contemplated herein come
within the purview or jurisdiction of the Screen Actors Guild ("SAG") and/or the American Federation
of Television and Radio Artists ("AFTRA"), and North is required for any reason to become a member
thereof, North agrees to join such union(s), and Company agrees to pay any and all expenses
whatsoever including all dues, assessments, or contributions necessary in order for North to render
his services hereunder, including any and all pension and health contributions or assessments that
may be required by such entities. North's participation in any such Advertising Materials pursuant
to this paragraph in the Agreement shall not result in any expenses or diminution of the Guaranteed
Fee or Royalties of this Endorsement Agreement whatsoever to North.

11. Standards. Company and North shall at all times deal with each other in good faith and strive to
maintain and enhance each other's positive image and reputation. North and Company shall act at all
times in a manner that shall not be in contravention of public morals and conventions.

12. Event of Default. a. It shall be an event of default hereunder by North if i) North shall
materially breach this Agreement and such breach remains uncured for a period of thirty (30) days
after written notice thereof from Company to North, or ii) North shall be indicted for a felony
involving moral turpitude which brings disrepute to the Company.

Page 8 of 12

Source: PERFORMANCE SPORTS BRANDS, INC., S-1, 9/9/2011
<!-- page 9 -->
The foregoing indemnity shall survive the expiration, fulfillment or termination of this Agreement.

b. It shall be an event of default hereunder by Company if i) Company fails to pay all fees when due
and payable pursuant to this Agreement, ii) Company is adjudicated as insolvent or declares
bankruptcy, or iii) Company shall materially breach this Agreement and such breach remains uncured
for a period of thirty (30) days after written notice thereof from North to Company.

13. Termination/Remedies. Either party shall have the right to terminate this Agreement upon the
occurrence of an event of default by the other party by providing written notice thereof to the
defaulting party. All rights and remedies of the parties herein specified are cumulative and are in
addition to, not in limitation of, any rights and remedies the parties may have at law or in equity
and all such rights and remedies may be exercised singularly or concurrently.

14. Company's Debts. North shall not be liable for any debts or obligations of Company resulting
directly or indirectly from the aforesaid use of the North's Likeness, North's Endorsement or the
services provided by North. Company shall make no representation, or in any way imply in its actions
or failure to act, that North is on will be liable for debts or obligations of Company.

15. Indemnification. Company shall indemnify, defend, and hold harmless North and its employees,
officers, agents, and representatives from and against any and all claims, suits, assessments,
losses, obligations, penalties, charges, actions, damages, liabilities, costs, and expenses
including reasonable attorney's fees whether incurred at trial or in connection with any review by
appeal or certiorari of both the trial and appellate court levels (collectively referred to as
"Claims") arising out of or in connection with: a Any claim or action for negligent or intentional
misconduct of Company in relation to the advertisement, promotion, or sale of the Endorsed Product,
or Company's use of North's Likeness or North's Endorsement to advertise, promote, distribute, or
sell the Endorsed Product; or b. Any claim or action for personal injury, death, or property damage
resulting from a customer's use of the Endorsed Product; or c. Any claims or action for the breach
by Company of any of its representations and warranties set forth in this Agreement.

16. Insurance. Company agrees, at its own expense, to obtain and maintain general comprehensive
liability insurance, with an insurance company that has a rating of A++ (per AM Best), insuring
North as a "named insured party", against any claims, suits, losses and damages arising out of or
caused by Company's use of North's Likeness. North's Endorsement or North's services hereunder. Such
insurance policy shall be maintained with limits of not less than two million dollars ($2,000,000).
Said policy of insurance shall remain in force for the duration of this Agreement. A copy of such
insurance policy shall be provided to North within thirty (30) days after execution of this
Agreement.

17. Waiver. The failure of either party at any time or times to demand strict performance of the
other party of any of the terms, covenants or conditions set forth herein shall not be construed as
a continuing waiver or relinquishment thereof and each party may at any time demand strict and
complete performance by the other party.

Page 9 of 12

Source: PERFORMANCE SPORTS BRANDS, INC., S-1, 9/9/2011
<!-- page 10 -->
18. Notices. All notices, claims, certificates, requests, demands and other communication hereunder
shall be made in writing and will be deemed to have been duly given if delivered by hand, via
facsimile transmission, or mailed and addressed as follows:

To Company: Golfers Incorporated 1021 N. Sepulveda Blvd., Suite G Manhattan Beach, CA 90266
Attention: Mike or Steve Abram To North: Andy North c/o Fidelity Sports Group, LLC 514 Broadway
Avenue Orlando, Florida 32803 Attention: David J. Moorman, President & CEO

19. Assignment. Neither party to this Agreement shall assign the rights and benefits herein without
the prior written consent of the other party.

20. Independent Contractor. Company has engaged North for certain rights which are set forth in this
Agreement, and North's relationship to Company, and Company's relationship to North, shall at all
times be that of an independent contractor.

21. Joint Venture. This Agreement does not constitute a partnership or joint venture between North
and Company. No party shall have the right to obligate or bind the other party in any manner
whatsoever.

22. Governing Law. The Agreement shall be governed by and construed under the laws of the State of
Florida in the United States of America, and venue for any such legal action shall be in the Circuit
Court or County Court in Orlando, FL or the U.S. District Court having jurisdiction over Orlando,
FL.

23. Entire Agreement. This writing constitutes the entire agreement and understanding between the
parties with respect to its subject matter. This Agreement supersedes all prior or contemporaneous
agreements and understandings between the parties with respect to its subject matter.

24. Amendments. This Agreement may be amended only by a written instrument duly executed by both
parties.

Page 10 of 12

Source: PERFORMANCE SPORTS BRANDS, INC., S-1, 9/9/2011
<!-- page 11 -->
25. Authority. Each party warrants and represents to the other that it has the full right, power and
authority to enter into and perform this Agreement, to make the covenants and representations
contained in this Agreement and further, that the execution, delivery and performance of this
Agreement will not violate, conflict with, or constitute a default under, any contract, agreement or
undertaking to which it is a party or by which it is bound.

26. Severability. The illegality, unenforceability or invalidity of any term, clause or provision of
this Agreement shall not affect any other term, clause or provision hereof, and this Agreement shall
continue in full force and effect, and be construed and enforced, as if such provision had not been
included.

27. Compliance with Laws. Company represents and warrants to North that it will comply with all
rules, regulations, laws, orders, decrees and ordinances of the United States, each state and
political subdivision thereof, and each and every foreign country having legal jurisdiction over any
aspect of Company's activities under this Agreement, including, but not limited to, the use of
North's Likeness in advertisements for and on behalf of the Company.

28. Attorney's Fees and Costs. The prevailing party in any litigation or other proceeding between
the parties arising out of the interpretation, application, or enforcement of any provision of this
Agreement shall be entitled to recover all of its reasonable fees, court costs, and expenses,
including fees for attorneys, whether incurred at trial or in connection with any review by appeal
or certiorari, accountants, and other professionals.

29. Force Majeure. In the event any of the appearances set forth in this Agreement are cancelled or
delayed due to matters of "Force Majeure", as such term is defined below, Company and North shall
use their reasonable efforts to reschedule such appearance as soon as possible following such
cancellation or delay. As used herein, the term "Force Majeure" shall mean war, civil unrest, acts
of God, unusually severe weather, environmental matters, failure of common carrier, governmental
action, labor disputes, casualty, illness, injury and/or emergency.

30. Confidentiality. The compensation terms of this Agreement hereunder and any financial
information collected through the review of Company's records or statements shall be treated by the
parties as confidential information. The parties hereto agree not to disclose any such terms,
amounts or information to any other person or entity whatsoever other than its attorneys,
accountants, or as required by law.

31. Counterparts. This Agreement may be executed in one or more counterparts, each of which shall be
deemed an original, but all of which together shall constitute one and the same instrument.

Page 11 of 12

Source: PERFORMANCE SPORTS BRANDS, INC., S-1, 9/9/2011
<!-- page 12 -->
IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be executed as of the date
first above written.

ANDY NORTH:

GOLFERS INCORPORATED: /s/ Michael F. Abram WITNESS: /s/ [ILLEGIBLE] By: Michael F. Abram Its:
President Date: 2-21-11

/s/ Andy North WITNESS: /s/ [ILLEGIBLE] Andy North Date: 2-20-11

Page 12 of 12

Source: PERFORMANCE SPORTS BRANDS, INC., S-1, 9/9/2011
