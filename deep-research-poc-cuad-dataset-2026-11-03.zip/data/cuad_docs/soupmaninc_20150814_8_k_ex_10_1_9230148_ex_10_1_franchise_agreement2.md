<!-- page 1 -->
# GUARANTEES OF MASTER FRANCHISE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Franchise Agreement |
| SEC Filing Date | 2015-08-14 |
| Parties | Kiosk Concepts, Inc. ("Franchisor"); ("Master Franchisee"); ("Guarantors") |
| Source | CUAD v1 / SoupmanInc_20150814_8-K_EX-10.1_9230148_EX-10.1_Franchise Agreement2 |

Attachment B to Master Franchise Agreement GUARANTEES OF MASTER FRANCHISE AGREEMENT As an i nducemen
t t o K iosk Concep t s , I nc . ( "F ranch i so r " ) t o en t e r i n to a Mas t e r F r anch i s
e Agreemen t w i th __N/A____________________ ("Master Franchisee") dated __________________, 20____
(the " Master Franchise Agreement"), ___________________________________ ("Guarantors"), jointly and
severally agree as follows: A. Guarantors shall pay or cause to be paid to Franchisor all monies
payable by Master Franchisee under the Master Franchise Agreement on the days and times and in the
manner therein appointed for payment thereof. B. Guarantors shall unconditionally guarantee full
performance and discharge by Master Franchisee of all the obligations of Master Franchisee under the
Master Franchise Agreement at the times and in the manner therein provided. C. Guarantors shall
indemnify and save harmless Franchisor and its affiliates against and from all losses, damages,
costs, and expenses which Franchisor and its affiliates may sustain, incur, or become liable for by
reason of: (1) the failure for any reason whatsoever of Master Franchisee to pay the monies payable
pursuant to the Master Franchise Agreement or to do and perform any other act, matter or thing
pursuant to the provisions of the Master Franchise Agreement; or (2) any act, action, or proceeding
of or by Franchisor for or in connection with the recovery of monies or the obtaining of performance
by Master Franchisee of any other act, matter or thing pursuant to the provisions of the Master
Franchise Agreement. D. Franchisor shall not be obligated to proceed against Master Franchisee or
exhaust any security from Master Franchisee or pursue or exhaust any remedy, including any legal or
equitable relief against Master Franchisee, before proceeding to enforce the obligations of the
Guarantors under this Guarantee, and the enforcement of such obligations may take place before,
after, or contemporaneously with, enforcement of any debt or obligation of Master Franchisee under
the Master Franchise Agreement. E. Without affecting the Guarantors' obligations under this
Guarantee, Franchisor, without notice to the Guarantors, may extend, modify, or release any
indebtedness or obligation of Master Franchisee, or settle, adjust, or compromise any claims against
Master Franchisee. Guarantors waive notice of amendment of the Master Franchise Agreement and notice
of demand for payment or performance by Master Franchisee. F. Guarantors' obligations under this
Guarantee shall remain in full force and effect, and shall be unaffected by: (1) the
unenforceability of the Master Franchise Agreement against Master Franchisee; (2) the termination of
any obligations of Master Franchisee under the Master Franchise Agreement by operation of law or
otherwise; (3) the bankruptcy, insolvency, dissolution, or other liquidation of Master Franchisee,
including, without limitation, any surrender or disclaimer of the Franchise Agreement by the trustee
in bankruptcy of Master Franchisee; (4) Franchisor's consent or acquiescence to any bankruptcy,
receivership, insolvency, or any other creditor's proceedings of or against Master Franchisee, or by
the winding-up or dissolution of Master Franchisee, or any other event or occurrence which would
have the effect at law of terminating the existence of Master Franchisee's obligations prior to the
termination of the Master Franchise Agreement; or (5) by any other agreements or other dealings
between Franchisor and Master Franchisee having the effect of amending or altering the Master
Franchise Agreement or Master Franchisee's obligations under this Guarantee, or by any want of
notice by Franchisor to Master Franchisee of any default of Master Franchisee or by any other
matter, thing, act, or omission of Franchisor whatsoever.

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 2 -->
G. Notice to Guarantors shall be given as follows: Names and addresses: H. This Guarantee shall be
interpreted and construed under the laws of the state in which Franchisor has its principal place of
business at the time the action is initiated. In the event of any conflict of law, the laws of such
state shall prevail, without regard to the application of such state's conflict of law rules. If,
however, any provision of this Guarantee would not be enforceable under the laws of the state in
which Franchisor has its principal place of business at the time the action is initiated, and if the
Master Franchisee's franchised business is located outside of such state and such provision would be
enforceable under the laws of the state in which the Master Franchisee's franchised business is
located, then such provision shall be interpreted and construed under the laws of that state. Any
action brought to enforce or interpret this Guarantee in any court, whether federal or state, shall
be brought within the county and state in which Franchisor has its principal place of business at
the time the action is initiated, and Guarantors hereby waive all questions of personal jurisdiction
or venue for the purpose of carrying out this provision. IN WITNESS WHEREOF, each of the undersigned
has signed this Guarantee as of the day and year set forth below. GUARANTORS : Date: Date: Date:
Date:

2

Source: SOUPMAN, INC., 8-K, 8/14/2015
