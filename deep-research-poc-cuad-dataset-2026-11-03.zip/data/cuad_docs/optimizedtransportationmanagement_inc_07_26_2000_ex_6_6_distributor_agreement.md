<!-- page 1 -->
# DISTRIBUTOR AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| SEC Filing Date | 2000-07-26 |
| Parties | COMWARE TECHNICAL SERVICES ("COMWARE"); INTERNATIONAL TEST SYSTEMS, INC. ("ITS") |
| Source | CUAD v1 / OPTIMIZEDTRANSPORTATIONMANAGEMENT,INC_07_26_2000-EX-6.6-DISTRIBUTOR AGREEMENT |

DISTRIBUTOR AGREEMENT

1. CERTIFICATION AND IDENTIFICATION:

COMWARE TECHNICAL SERVICES OF 17922 SKY PARK CIRCLE, SUITE E, IRVINE, CALIFORNIA 92614-6414
(COMWARE) certifies that the Products furnished under this agreement by INTERNATIONAL TEST SYSTEMS,
INC. OF 4703 SHAVANO OAK, SUITE 102, SAN ANTONIO, TEXAS 78249 (ITS) will be incorporated by COMWARE
as a part of COMWARE'S systems which COMWARE sells or leases to unaffiliated third parties in the
regular course of COMWARE'S business and that COMWARE'S own contribution to these systems reflect a
verifiable value added. COMWARE also represents that it is an experienced user of computer equipment
and software sufficiently like the Products, as defined below, and that it needs only minor support
in the incorporation of the Products into its lines of business.

2. DEFINITIONS:

INITIAL DISTRIBUTION PERIOD: April 15, 2000 through October 15, 2000 (6 Months from the Effective
Date)

PRODUCTS: The CircuiTest 2000S In-Circuit Test System

The CircuiTest 2100 Scanner Expansion

EXCLUSIVE TERRITORIES: The 48 Contiguous United States

EFFECTIVE DATE: The earlier of the date Comware orders and pays for a minimum of $22,710 worth of
Products, in any combination, or April 15, 2000.

3. EXCLUSIVE RIGHTS: Upon the effective date of this agreement COMWARE shall have the exclusive
right to purchase, at the DISCOUNTS described below, and resell Products to potential customers
during the Initial Distribution Period, based on the following terms and conditions:

(a) COMWARE must purchase no less than $22,710.00 worth of Products, in any combination, by April
15, 2000. This initial order shall be evidenced by valid purchase order from COMWARE to be received
by ITS no later than 5:00PM April 1, 2000, with payment to be received by ITS no later than April
15, 2000. In the event either of these dates are not met, this Agreement will automatically and
immediately terminate and neither of the parties hereto will have any further obligations, one to
the other.

(b) Future Purchase Orders and delivery will approximate the 15 day delivery schedule (but not the
dates), although payment will be made by COMWARE to ITS no later than thirty (30) days after receipt
of invoice from ITS.

(c) Provided COMWARE purchases the initial products as in (a) above, COMWARE shall have the right to
purchase additional Products up to a total of $45,420.00 at the following discounts:

1

INITIAL DISCOUNTS:

PRODUCT IDENTIFICATION SUGGESTED RETAIL PRICE DISCOUNT PRICE TO COMWARE
-------------------------------------------------------------------------------------------------
CircuiTest 2000S $5,995.00 45% $3,297.25 CircuiTest 2100 Scanner $2,995.00 56% $1,317.80

(INTERNATIONAL TEST SYSTEMS RESERVES THE RIGHT TO CHANGE THE RETAIL PRICE AT ANY TIME, WITH NOTICE
TO COMWARE.)

(d) In the event COMWARE purchases products in excess of $45,420.00 during the Initial Distribution
Period, COMWARE shall have the right to purchase additional Products at the following discounts:

SUBSEQUENT DISCOUNTS:

PRODUCT IDENTIFICATION SUGGESTED RETAIL PRICE DISCOUNT PRICE TO COMWARE
-------------------------------------------------------------------------------------------------
CircuiTest 2000S $5,995.00 50% $2,997.50 CircuiTest 2100 Scanner $2,995.00 60% $1,198.00

(INTERNATIONAL TEST SYSTEMS RESERVES THE RIGHT TO CHANGE THE RETAIL PRICE AT ANY TIME, WITH NOTICE
TO COMWARE.)

4. RENEWAL PERIOD: Provided that COMWARE purchases a minimum of $45,420.00 worth of Products, in any
combination, during the Initial Distribution
<!-- page 2 -->
Period, this Agreement will automatically renew for an additional 6 months (the Renewal Period). In
the event COMWARE purchases an amount less than $45,420.00, than this Agreement will automatically
terminate.

5. MINIMUM ORDERS TO MAINTAIN AGREEMENT: COMWARE must purchase order a minimum of $4,200 worth of
Products per month during the Renewal Period TO maintain the terms and conditions of this Agreement.
In the event COMWARE does not meet these minimum purchase requirements, this Agreement will
automatically and immediately terminate and neither of the parties hereto will have any further
obligations, one to the other.

6. OBLIGATIONS OF COMWARE:

o Use best efforts to market and sell the Products to customers. o Provide marketing feedback to
ITS. o Train customers on and demonstrate ITS products. o COMWARE reserves the right to develop and
sell value-added services that support the sales of ITS systems. o COMWARE reserves the right to
develop their own marketing materials, brochures, and advertisements for ITS' products at no cost to
ITS. o Communicate with and respond to ITS AND ITS inquires. o Assist ITS in customer feedback.

2

7. OBLIGATIONS OF ITS:

o ITS will deliver working systems no later than 30 days after a hard copy purchase order is
received from COMWARE. o ITS will provide free technical support to customers who have purchased ITS
systems for a period of 30 days. After the 30 day free technical support period, ITS reserves the
right to charge a reasonable fee for additional support. o ITS will be solely responsible for the
production of brochures describing the products, and will provide COMWARE with ample space for
placement of business card/label and provide COMWARE with as many brochures as it may from time to
time reasonably require, free of charge. o In event of cancellation of a purchase order, or
re-scheduling of any item on a purchase order beyond the discount period, COMWARE may be liable for
bill back or adjustment of discounts based upon actual quantities of items delivered within the
discount period. o COMWARE will not be penalized for delays in delivery caused by ITS, or any agent
of ITS. o ITS will use its best efforts to provide a swift and complete resolution of any
product-related problems, whether or not such problems are covered under the terms of the WARRANTY.
In the event that one of COMWARE'S customers has a problem that is beyond the scope of COMWARE'S
capabilities, ITS will address the problem without delay in the best interest of customer service.

8. WARRANTY: ITS Products are warranted free from defects of material or workmanship for 3 years
after shipment from the manufacturer. Equipment purchased from ITS, which becomes defective within
that time period will be repaired by ITS at its headquarters in San Antonio, Texas at no cost to
COMWARE beyond cost of shipping the equipment to ITS. ITS will bear the cost of returning the item
to COMWARE by UPS, REGULAR DELIVERY. priority shipping costs will be borne by COMWARE.

This warranty is contingent upon proper use and installation of the Products and does not cover
equipment which has been modified without ITS' consent or which has been subjected to unusual
physical or electrical stress or on which the original identification marks have been removed or
altered.

9. DOCUMENTATION AND SUPPORT: ITS will supply with each of the Products ordered one set of user and
technical documentation and one set of software in reproducible form.

COMWARE may purchase additional copies of the documentation and software disks at then prevailing
prices.

COMWARE will receive minimal assistance and support from ITS consistent with the certifications in
Section 1.

3

TERMINATION: except as specifically described elsewhere in this agreement, either ITS or COMWARE
shall have the right to terminate this Agreement with 30 days written notice from the other party,
for any reason whatsoever.

11. GOVERNMENT SALES: COMWARE reserves the right to incorporate, as extension of this Agreement,
additional terms and conditions as may be required for sale of Products to the US Government. These
terms and conditions will be expressly quoted in attachments to subject purchase orders. ITS
reserves the right to reject such purchase orders only under those conditions where these terms and
conditions are in conflict with stated policy or corporate condition of ITS at the time the purchase
orders are received.
<!-- page 3 -->
12. ENTIRE AGREEMENT: This Agreement supersedes all prior agreements and understandings between the
parties relating to the subject matter and is intended by the parties as the complete and exclusive
statement of the terms of the Agreement. No modification, addition to or waiver of the terms and
conditions of this Agreement shall be effective unless in writing and signed by the party against
whom the same is sought to be enforced.

13. GOVERNED BY THE STATE OF TEXAS: This Agreement shall be interpreted and governed by the laws of
the State of Texas. Comware agrees to submit to the jurisdiction of the State of Texas, Bexar
County, USA.

INTERNATIONAL TEST SYSTEMS, INC. COMWARE TECHNICAL SERVICES

BY BY ------------------------------- ---------------------------------

PRINTED PRINTED -------------------------- ----------------------------

TITLE TITLE ---------------------------- ------------------------------

DATE DATE ----------------------------- -------------------------------

4
