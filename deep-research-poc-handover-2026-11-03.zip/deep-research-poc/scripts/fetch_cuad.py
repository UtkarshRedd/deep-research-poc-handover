"""Download CUAD v1 (Contract Understanding Atticus Dataset) into data/raw/cuad/.

    .venv/Scripts/python.exe -I scripts/fetch_cuad.py            # download (≈106 MB), verify md5, extract
    .venv/Scripts/python.exe -I scripts/fetch_cuad.py --force    # re-download even if the zip verifies

Source: Zenodo record 10.5281/zenodo.4595826 (The Atticus Project), licence CC BY 4.0.
The archive is treated as untrusted data: it is checksum-verified, extracted with a path-traversal
guard, and only ever *parsed* (by scripts/make_cuad_corpus.py); nothing in it is executed.

Layout after extraction (as shipped by Atticus, left untouched):
    data/raw/cuad/CUAD_v1.zip
    data/raw/cuad/CUAD_v1/CUAD_v1.json                 SQuAD-style annotations (41 categories, 510 contracts)
    data/raw/cuad/CUAD_v1/master_clauses.csv           one row per contract, one column pair per category
    data/raw/cuad/CUAD_v1/full_contract_pdf/<part>/<type>/<name>.pdf
    data/raw/cuad/CUAD_v1/full_contract_txt/<name>.txt
    data/raw/cuad/SOURCE.md                            provenance written by this script
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = ROOT / "data" / "raw" / "cuad"

RECORD_URL = "https://zenodo.org/records/4595826"
DOWNLOAD_URL = "https://zenodo.org/api/records/4595826/files/CUAD_v1.zip/content"
DOI = "10.5281/zenodo.4595826"
LICENSE = "CC BY 4.0 (Creative Commons Attribution 4.0 International)"
ZIP_NAME = "CUAD_v1.zip"
EXPECTED_MD5 = "c38f490a984420b8a62600db401fafd5"   # from the Zenodo record metadata
EXPECTED_SIZE = 105_883_672                          # bytes, idem
CITATION = (
    "Hendrycks, Burns, Chen & Ball (2021). CUAD: An Expert-Annotated NLP Dataset for Legal Contract "
    "Review. NeurIPS 2021 Datasets and Benchmarks. https://arxiv.org/abs/2103.06268"
)


def md5_of(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def download(url: str, dest: Path) -> None:
    tmp = dest.with_suffix(dest.suffix + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": "deep-research-poc/0.0.1 (CUAD fetch)"})
    with urllib.request.urlopen(req, timeout=120) as resp, tmp.open("wb") as out:
        total = int(resp.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = resp.read(1 << 20)
            if not chunk:
                break
            out.write(chunk)
            done += len(chunk)
            if total:
                print(f"\r  {done / 1e6:7.1f} / {total / 1e6:.1f} MB", end="", flush=True)
    print()
    tmp.replace(dest)


def safe_extract(zip_path: Path, dest: Path) -> int:
    """Extract regular files only, refusing absolute paths, '..' components and symlinks."""
    n = 0
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            name = info.filename
            parts = Path(name).parts
            if info.is_dir():
                continue
            if Path(name).is_absolute() or ".." in parts or name.startswith(("/", "\\")):
                raise RuntimeError(f"refusing unsafe archive member: {name!r}")
            if (info.external_attr >> 16) & 0o170000 == 0o120000:   # symlink
                raise RuntimeError(f"refusing symlink archive member: {name!r}")
            target = dest / Path(*parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, target.open("wb") as out:
                shutil.copyfileobj(src, out)
            n += 1
    return n


def write_source_md(zip_path: Path, md5: str, n_files: int) -> Path:
    pdfs = sorted(RAW_DIR.rglob("*.pdf"))
    txts = sorted((RAW_DIR / "CUAD_v1" / "full_contract_txt").glob("*.txt"))
    now = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    body = f"""# CUAD v1 — source and provenance

- **Dataset:** Contract Understanding Atticus Dataset (CUAD) v1, The Atticus Project
- **Licence:** {LICENSE} — https://creativecommons.org/licenses/by/4.0/
- **Record:** {RECORD_URL} (DOI {DOI})
- **Download URL:** {DOWNLOAD_URL}
- **Archive:** `{ZIP_NAME}`, {zip_path.stat().st_size:,} bytes
- **md5:** `{md5}` (expected `{EXPECTED_MD5}`)
- **Fetched:** {now} by `scripts/fetch_cuad.py`
- **Extracted:** {n_files} files; {len(pdfs)} PDFs, {len(txts)} text files
- **Citation:** {CITATION}

Everything under this directory is untrusted third-party data: it is parsed by
`scripts/make_cuad_corpus.py` and `scripts/make_cuad_golden.py` and never executed.
Attribution is required by the licence; keep this file next to any redistribution.
"""
    out = RAW_DIR / "SOURCE.md"
    out.write_text(body, encoding="utf-8")
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--force", action="store_true", help="re-download and re-extract even if the archive verifies")
    ap.add_argument("--no-extract", action="store_true")
    args = ap.parse_args()

    print(f"CUAD v1 — licence: {LICENSE}")
    print(f"source: {RECORD_URL}  (DOI {DOI})")
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    zip_path = RAW_DIR / ZIP_NAME

    need = args.force or not zip_path.exists()
    if not need:
        md5 = md5_of(zip_path)
        if md5 != EXPECTED_MD5:
            print(f"existing archive has md5 {md5}, expected {EXPECTED_MD5}: re-downloading")
            need = True
        else:
            print(f"archive present and verified: {zip_path}")
    if need:
        print(f"downloading {DOWNLOAD_URL} (~{EXPECTED_SIZE / 1e6:.0f} MB) -> {zip_path}")
        try:
            download(DOWNLOAD_URL, zip_path)
        except OSError as e:
            print(f"download failed: {e}\n"
                  f"Manual fallback: download {RECORD_URL}/files/{ZIP_NAME}?download=1 in a browser, "
                  f"save it as {zip_path}, then rerun this script.", file=sys.stderr)
            return 2
        md5 = md5_of(zip_path)
        size = zip_path.stat().st_size
        if md5 != EXPECTED_MD5 or size != EXPECTED_SIZE:
            print(f"checksum mismatch: md5={md5} size={size} (expected {EXPECTED_MD5} / {EXPECTED_SIZE}). "
                  "The archive on Zenodo may have changed; verify it at the record page before trusting it.",
                  file=sys.stderr)
            return 3
        print(f"verified md5 {md5}")

    if args.no_extract:
        return 0
    extracted = RAW_DIR / "CUAD_v1"
    if extracted.exists() and (args.force or not (extracted / "CUAD_v1.json").exists()):
        shutil.rmtree(extracted)
    if extracted.exists():
        n = sum(1 for p in extracted.rglob("*") if p.is_file())
        print(f"already extracted: {n} files under {extracted}")
    else:
        print("extracting ...")
        n = safe_extract(zip_path, RAW_DIR)
        print(f"extracted {n} files under {RAW_DIR}")
    src = write_source_md(zip_path, md5, n)
    print(f"wrote {src}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
