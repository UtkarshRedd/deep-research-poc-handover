# What cap on liability does the Amended and Restated Strategic Licensing, Distribution a...

*Question:* What cap on liability does the Amended and Restated Strategic Licensing, Distribution and Marketing Agreement between PACIRA PHARMACEUTICALS, INC. and EKR THERAPEUTICS, INC. (dated 2009-10-15) provide?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Answer

[GAP] No evidence was found for: Answer the question: What cap on liability does the Amended and Restated Strategic Licensing, Distribution and Marketing Agreement between PACIRA PHARMACEUTICALS, INC. and EKR THERAPEUTICS, INC. (dated 2009-10-15) provide?

## Verification appendix

Claims: 1 · supported: 0 · partially: 0 · dropped: 0 · gaps: 1

Notes: no evidence in the bank; every section is a gap; OpenAIRateLimitError: Error code: 429

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  |  |

### Evidence

