<!-- page 1 -->
# Credit Agreement — Acme Industrial LLC
| Field | Value |
|---|---|
| Document Type | Credit Agreement |
| Effective Date | 2024-03-15 |
| Parties | Acme Industrial LLC; First National Bank |
| Facility ID | FAC-2024-0117 |

## 1. Definitions
"Applicable Margin" means 2.25% per annum for Term SOFR Loans.
<!-- page 2 -->
## 2. Commitments
The aggregate Revolving Commitment is $25,000,000 as of the Effective Date.
Borrower may request increases up to $40,000,000 subject to Section 2.14.
## 3. Financial Covenants
Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00.
<!-- page 3 -->
## 4. Termination
Either party may terminate this Agreement upon ninety (90) days written notice.
Termination does not relieve Borrower of accrued obligations.
