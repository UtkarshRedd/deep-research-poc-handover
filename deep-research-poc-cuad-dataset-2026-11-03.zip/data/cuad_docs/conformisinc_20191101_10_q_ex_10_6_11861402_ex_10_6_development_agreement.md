<!-- page 1 -->
# DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2019-09-30 |
| Parties | Howmedica Ostenonics Corp. ("Stryker"); Conformis, Inc. ("Conformis"); Stryker and Conformis (“Parties” and individually as a “Party.”) |
| Source | CUAD v1 / ConformisInc_20191101_10-Q_EX-10.6_11861402_EX-10.6_Development Agreement |

Execution Version Certain identified information has been excluded from the exhibit because it is
both (i) not material and (ii) would likely cause competitive harm to the Company, if publicly
disclosed. Double asterisks denote omissions. DEVELOPMENT AGREEMENT This Development Agreement
("this Agreement") is entered into and effective as of September 30, 2019 ("Effective Date") by and
between Howmedica Osteonics Corp., a New Jersey corporation, also known as Stryker Orthopaedics
("Stryker"), and Conformis, Inc., a Delaware corporation having a principal place of business
located at 600 Technology Park Drive, Billerica, MA 01821 ("Conformis"). Stryker and Conformis are
collectively referred to herein as the "Parties" and individually as a "Party." WHEREAS, the Parties
are concurrently entering into an asset purchase agreement for Stryker's purchase of certain
Conformis assets concerning Patient-Specific Instrumentation ("Asset Purchase Agreement"), and a
License Agreement, a Distribution Agreement and a Quality Agreement, as defined in and attached to
the Asset Purchase Agreement (collectively, such agreements are referred to herein as the "Other
Agreements"). WHEREAS, Stryker and its Affiliates have developed and commercialized an Off-The-Shelf
Knee Implant offered under the trademark Triathlon. WHEREAS, Conformis currently offers
Patient-Specific Instrumentation for use with its Patient-Specific Implants, including partial and
total knee and hip arthroplasty. WHEREAS, Stryker desires that Conformis develop, in accordance with
the R&D Program, certain Patient-Specific Instrumentation to be used with the current version of the
Off-The-Shelf Knee Implant offered under the trademark Triathlon (such Patient-Specific
Instrumentation as so developed, the "KIB Product"). THEREFORE, in consideration of the mutual
representations, warranties and covenants herein and in the Other Agreements constituting good and
valuable consideration, the receipt and sufficiency of which is hereby acknowledged, the Parties
hereby agree as follows: ARTICLE I DEFINITIONS 1.1 Definitions. For purposes of this Agreement, the
following terms shall have the following meanings, and to the extent not defined in this section or
otherwise in this Agreement, a term shall have the meaning ascribed to it in any of the Other
Agreements: Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 2 -->
"Acceptance" and "Accept" have the meaning set forth in Article 3.4 of this Agreement. "Acceptance
Criteria" has the meaning set forth in the R&D Work Plan. "Acceptance Notification Period" has the
meaning set forth in Article 3.3 of this Agreement. "Affiliate" has the meaning set forth in the
Asset Purchase Agreement. "Agents" means Third Parties who are acting under the direction or control
of a Party. "Applicable Laws" means all applicable federal, state, local and foreign laws,
ordinances, rules, regulations, orders, writs, injunctions and decrees of any kind. "Asset Purchase
Agreement" has the meaning set forth in the recitals. "Change of Control" has the meaning set forth
in the Asset Purchase Agreement. "Claims" has the meaning set forth in Article 7.3(a) of this
Agreement. "Confidential Information" has the meaning set forth in the Asset Purchase Agreement.
"Conformis Background IP" means any Invention, and all Intellectual Property rights underlying such
Invention, that is, as of the Effective Date, owned or licensable by Conformis without causing a
breach of, or incurring any obligation to, a third party, in each case to the extent necessary or
reasonably useful to design, develop, manufacture, sell or otherwise exploit the KIB Product, and
for the avoidance of doubt, excluding the Purchased Assets, Conformis Foreground IP, Stryker
Background IP, Improved Stryker Background IP and Improved Conformis Background IP. 2 Source:
CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 3 -->
"Conformis Foreground IP" means any Invention first developed by Conformis after the Closing Date
other than in the performance of the R&D Program, and all Intellectual Property rights underlying
such Invention (for the avoidance of doubt, excluding any Intellectual Property rights subsisting
prior to the Closing Date or generated in the performance of the R&D Program). For the avoidance of
doubt, Conformis Foreground IP shall not include any Inventions using Stryker Confidential
Information (which shall not include the Purchased Assets for the purposes of the definition of
Conformis Foreground IP) or Stryker Background IP. "Conformis Indemnified Parties" has the meaning
set forth in Article 7.3(b) of this Agreement. "Conformis-Prosecuted Joint IP Rights" has the
meaning set forth in Article 5.8 of this Agreement. "Court" has the meaning set forth in the Asset
Purchase Agreement. "Deliverables" has the meaning set forth under the R&D Work Plan. "Disclosing
Party" has the meaning set forth in the Asset Purchase Agreement. "Distribution Agreement" has the
meaning set forth in the Asset Purchase Agreement. "Equipment" has the meaning set forth in Article
5.6(a) of this Agreement. "Failure Notice" has the meaning set forth in Article 3.4 of this
Agreement. "Finally Rejects" has the meaning set forth in Article 3.4 of this Agreement. "Force
Majeure Event" has the meaning set forth in Article 10.4(a) of this Agreement. 3 Source: CONFORMIS
INC, 10-Q, 11/1/2019
<!-- page 4 -->
"Improved Conformis Background IP" means any Invention to the extent first arising in the
performance of the R&D Program, whether or not embodied in the KIB Product, that constitutes an
improvement to Conformis Background IP, Conformis Confidential Information (which shall not include
any Confidential Information owned or commonly owned by Stryker) or the Purchased Assets, and all
Intellectual Property rights underlying such Invention (but expressly excluding all Transferred IP,
Conformis Foreground IP, Conformis Background IP and Stryker Background IP, and, for the avoidance
of doubt, excluding all Intellectual Property rights subsisting prior to the Closing Date).
"Improved Stryker Background IP" means any Invention to the extent first arising in the performance
of the R&D Program, whether or not embodied in the KIB Product, that constitutes an improvement to
Stryker Background IP or any Stryker Confidential Information (which shall not include the Purchased
Assets for the purposes of this definition), and all Intellectual Property rights underlying such
Invention (but expressly excluding all Transferred IP, Conformis Foreground IP, Conformis Background
IP and Stryker Background IP, and, for the avoidance of doubt, excluding all Intellectual Property
rights subsisting prior to the Closing Date). "Insolvency Event" means, with respect to any Party,
the occurrence of any one of the following events: (i) an involuntary proceeding is commenced
against such Party under any applicable United States bankruptcy, insolvency, reorganization or
other similar United States or foreign law now or hereafter in effect, or a proceeding is commenced
seeking appointment of a receiver, liquidator, assignee, custodian, trustee, sequestrator (or other
similar official) for such Party or for all or any substantial part of its property and such
proceeding shall not be dismissed within [**] or an order for relief by a court of competent
jurisdiction shall be entered in any such proceeding; or (ii) such Party shall commence a voluntary
proceeding under any applicable United States or foreign bankruptcy, insolvency, reorganization or
other similar law now or hereafter in effect, or shall consent to the entry of an order for relief
in an involuntary case under any such law, or shall consent to the appointment of or taking
possession by a receiver, liquidator, 4 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 5 -->
assignee, custodian, trustee, sequestrator (or other similar official) of such Party or of all or
any substantial part of its property, or shall make an assignment for the benefit of creditors.
"Intellectual Property" has the meaning set forth in the Asset Purchase Agreement. "Invention" means
any idea, invention, discovery, know-how, data, work of authorship, information, improvement,
technology, process, concept or material, whether or not patentable, copyrightable or protectable as
a trade secret, and whether or not reduced to practice or memorialized in writing. "Joint CI" has
the meaning set forth in the Asset Purchase Agreement. "Joint IP" has the meaning set forth in
Article 5.1(c) of this Agreement. "Joint IP Rights" has the meaning set forth in Article 5.8 of this
Agreement. "KIB Product" has the meaning set forth in the recitals. "KIB Product IP" means any
Invention first arising in the performance of the R&D Program, whether or not embodied in the KIB
Product, and all Intellectual Property rights underlying such Invention (but expressly excluding all
Transferred IP, Conformis Background IP, Stryker Background IP, Improved Conformis Background IP and
Improved Stryker Background IP, and, for the avoidance of doubt, excluding all Intellectual Property
rights subsisting prior to the Closing Date). "License Agreement" has the meaning set forth in the
Asset Purchase Agreement. "Off-The-Shelf Implant" has the meaning set forth in the Asset Purchase
Agreement. 5 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 6 -->
"Off-The-Shelf Knee Implant" has the meaning set forth in the Asset Purchase Agreement. "Other
Agreements" has the meaning set forth in the recitals. "Patents" has the meaning set forth in the
Asset Purchase Agreement. "Patient-Specific Implants" has the meaning set forth in the Asset
Purchase Agreement. "Patient-Specific Instrumentation" has the meaning set forth in the Asset
Purchase Agreement. "Person" has the meaning set forth in the Asset Purchase Agreement. "Prior CDA"
has the meaning set forth in the Asset Purchase Agreement. "Purchased Assets" has the meaning set
forth in the Asset Purchase Agreement. "Receiving Party" has the meaning set forth in the Asset
Purchase Agreement. "Redelivery Period" has the meaning set forth in Article 3.4 of this Agreement.
"R&D Program" means work performed in the development of the KIB Product under this Agreement
pursuant to the R&D Work Plan. "R&D Work Plan" means the research and development plan set forth in
Exhibit 1. "Relevant Indemnified Parties" means (a) if Stryker is the indemnified Party, the Stryker
Indemnified Parties and (b) if Conformis is the indemnified Party, the Conformis Indemnified
Parties. 6 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 7 -->
"Representatives" has the meaning set forth in the Asset Purchase Agreement. "Stryker Background IP"
means any Invention, and all Intellectual Property rights underlying such Invention, that is, as of
the Effective Date owned or licensable by Stryker without causing a breach of, or incurring any
obligation to, a third party, in each case to the extent each such Invention is (a) necessary or
reasonably useful to design, develop, manufacture, sell and otherwise exploit the KIB Product and
(b) provided to Conformis by or on behalf of Stryker in connection with Conformis' activities under
this Agreement, and, for the avoidance of doubt, excluding the Transferred IP, Conformis Background
IP, Improved Conformis Background IP and Improved Stryker Background IP. "Stryker Indemnified
Parties" has the meaning set forth in Article 7.3(a) of this Agreement. "Stryker-Prosecuted Joint IP
Rights" has the meaning set forth in Article 5.8 of this Agreement. "Termination Notice" means a
written notice delivered by one Party to the other Party of its election to terminate this Agreement
pursuant to Article VIII. "Third Party" has the meaning set forth in the Asset Purchase Agreement.
"Trademarks" has the meaning set forth in the Asset Purchase Agreement. "Transferred IP" has the
meaning set forth in the Asset Purchase Agreement. "Triathlon" has the meaning set forth in the
Asset Purchase Agreement. "Wire Instructions" has the meaning set forth in the Asset Purchase
Agreement. 7 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 8 -->
ARTICLE II RESEARCH AND DEVELOPMENT PROGRAM 2.1 R&D Work Plan. The Parties agree to conduct the R&D
Program pursuant to the R&D Work Plan and to perform their respective obligations therein. To the
extent Conformis' performance under the R&D Program is delayed due to Stryker's delay in performing
any of its obligations in accordance with the timelines in the R&D Work Plan, the applicable
timelines shall be deemed extended by a period of time corresponding to the length of such portion
of the delay attributable to Stryker, on a day-by- day basis. The R&D Work Plan may be amended by
mutual written agreement of the Parties from time to time. 2.2 Agents or Third Parties. To the
extent working with Agents or other Third Parties is permitted under the R&D Work Plan, should a
Party wish to engage an Agent or any other Third Party in connection with the R&D Work Plan or any
other work under this Agreement, such Party must obtain in advance a written agreement by such Agent
or other Third Party (i) to assign to the Party all Inventions conceived, created or generated by
the Agent or other Third Party, and (ii) to maintain all Confidential Information in confidence as
set forth in Section 5.2. ARTICLE III DELIVERABLES AND COMPLETION 3.1 Deliverables. Subject to the
remedies set forth in Section 3.4, Conformis shall furnish Stryker with the Deliverables as defined
in the R&D Work Plan, and Stryker shall have the opportunity to analyze and test each Deliverable
for the purposes of determining Acceptance as set forth in the R&D Work Plan. Each Deliverable shall
be deemed to be completed once such Deliverable has been Accepted (as defined below). 3.2 Free from
Infringement. Without the consent of Stryker, Conformis shall not introduce any structure or
methodology in the Deliverables (including a Deliverable within a Product or a Stryker Product) that
(1) raise a colorable argument of patent infringement in the manufacture, use, sale, offer for sale
or importation of the Deliverable as such Deliverable 8 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 9 -->
is intended to be exploited under the Other Agreements, (2) misappropriate any Confidential
Information of any Third Party, or (3) otherwise violate any Intellectual Property rights of any
Third Party. For clarity, disclosure of a matter on the Disclosure Schedules to the Asset Purchase
Agreement shall not be deemed consent by Stryker under this Section 3.2. 3.3 Completion. After a
Deliverable has been furnished to Stryker, Stryker (or its Agent designee) will be entitled to
analyze and test the Deliverable to determine if it operates in accordance with and otherwise
conforms to the applicable Acceptance Criteria set forth in R&D Work Plan. Conformis shall provide
such assistance as Stryker may reasonably request in such determination. Stryker shall have [**]
("Acceptance Notification Period") following the date the Deliverable is received by Stryker to
Accept or reject the Deliverable as described in Section 3.4. 3.4 Acceptance or Rejection.
Respecting any Deliverable for Milestone #1 or Milestone #2, as set forth below, if Stryker
determines that a Deliverable operates in accordance with and otherwise conforms to the applicable
Acceptance Criteria pursuant to the R&D Work Plan, then Stryker will notify Conformis in writing
that Stryker Accepts such Deliverable. If Stryker reasonably determines that a Deliverable does not
operate in accordance with or otherwise conform to the applicable Acceptance Criteria, then Stryker
will provide Conformis with a written notice of rejection within the Acceptance Notification Period
describing the defect in view of the relevant Acceptance Criteria and including sufficient detail
with respect to such Stryker testing and testing results as Conformis reasonably requests ("Failure
Notice"). Conformis shall have [**] (or such longer period of time as may be agreed between the
parties in good faith should the scope and complexity of the applicable Deliverable warrant some
longer period of time) ("Redelivery Period") following the date it receives the Failure Notice to
correct and redeliver the Deliverable. If Conformis timely delivers a corrected version of the
Deliverable within the Redelivery Period, then Stryker will be 9 Source: CONFORMIS INC, 10-Q,
11/1/2019
<!-- page 10 -->
entitled to repeat its acceptance analysis and testing process for the purposes of determining
Acceptance as set forth in the R&D Work Plan until such Deliverable operates in accordance with or
otherwise conforms to the applicable Acceptance Criteria; provided, however, that if Stryker
properly rejects a particular Deliverable three (3) or more times in accordance with this Article
III, or if Conformis fails to deliver a version or corrected version, as the case may be, of the
Deliverable within any respective [**] period, Stryker may, terminate this Agreement in accordance
with Section 8.2(c) (in the event of such three (3) rejections, Stryker "Finally Rejects" the
Deliverable). Such termination, together with the provisions of Section 5.2 of the License
Agreement, constitutes as Stryker's sole remedy and Conformis' exclusive liability in the event of
any such rejection or failure by Conformis to deliver materially conforming Deliverables hereunder
so long as such rejection or failure does not arise from Conformis' fraud, willful misconduct, gross
negligence or bad faith. Stryker shall be deemed to have accepted a Deliverable timely furnished to
it unless (a) the Deliverable fails to operate in accordance with and otherwise conform the
applicable Acceptance Criteria, and (b) Stryker provides Conformis a written Failure Notice within
the Acceptance Notification Period in accordance with this Section 3.4 (any acceptance or deemed
acceptance, described in this Section 3.4, "Acceptance" or "Accept"). Acceptance of a Deliverable
shall not constitute a waiver of any rights Stryker may have based on Conformis' warranties set
forth in this Agreement. 3.5 Payment for Milestones. Stryker shall pay to Conformis the following
milestone payments for the development work to be conducted hereunder if and when the following
milestones are met, as follows: (a) Milestone #1 - Within thirty (30) days following the date on
which Stryker receives the first prototype of the Patient- Specific Instrumentation delivered to it
by Conformis in accordance with the R&D Work Plan, Stryker shall pay to Conformis a total of two
million U.S. dollars ($2,000,000); and 10 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 11 -->
(b) Milestone #2 - Within thirty (30) days following the date on which there is a design freeze of
the Patient-Specific Instrumentation for the KIB Product in accordance with the R&D Work Plan,
Stryker shall pay to Conformis a total of three million U.S dollars ($3,000,000). 3.6 Payment.
Stryker shall make all payments to Conformis required herein by wire transfer in accordance with the
Wire Instructions. Such payments are non-refundable and non-creditable except as set forth in the
Other Agreements. ARTICLE IV RESTRICTIVE COVENANT 4.1 Exclusivity. Except as specifically provided
in the Distribution Agreement, Conformis shall be prohibited from developing or assisting another in
developing, or causing another to develop, Patient-Specific Instrumentation for Off-The-Shelf Knee
Implants for any Third Party in the field of orthopedics until January 1, 2032 (or earlier, to the
extent set forth in Section 2.3.3.4 or Section 2.3.5 of the Distribution Agreement), with the
exception that Conformis (including any entity involved in a Change of Control of Conformis, any
such entity an "Acquirer"), may develop Patient-Specific Instrumentation for any Off-The- Shelf
Implants of Conformis, an Acquirer or any of their Affiliates. For purposes of clarity, the
foregoing does not prevent Conformis from granting any license, release, covenant not to sue or
other immunity to any third party under any Patents, including any such immunity that would
authorize manufacture, use or sale of Patient-Specific Instrumentation for Off-The-Shelf Knee
Implants outside the Buyer Field. ARTICLE V INTELLECTUAL PROPERTY 5.1 Inventions. (a) Inventorship
of all Inventions developed by either Party, or both Parties, in the performance of the R&D Program,
shall be determined in accordance with the inventorship laws of the United States, even to the
extent such Invention is not pursued in patent applications. (b) All right, title and interest in
and to the Improved Stryker Background IP will vest solely in Stryker. Conformis agrees to assign
and hereby assigns to Stryker all right, title and interest in and to all Improved Stryker
Background IP in which ownership in same has vested in 11 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 12 -->
Conformis by operation of law or by assignment by its employees or consultants; and to facilitate
such assignment to Stryker, Conformis agrees (i) to regularly ensure that its employees and
consultants timely make any appropriate assignments to it of that which constitutes Improved Stryker
Background IP, and (ii) at Stryker's reasonable request, to execute and have its employees and
consultants execute, as necessary, all assignments and any other documentation necessary to perfect
title in Stryker of such Improved Stryker Background IP. (c) All right, title and interest in and to
the Improved Conformis Background IP and KIB Product IP ("Joint IP") shall be owned jointly by the
Parties. Subject to the limitations set forth in this Agreement, the Joint IP may be used freely by
either Party or its Affiliates and licensed to Third Parties by Conformis and its Affiliates, on the
one hand, outside of the Buyer Field or by Stryker and its Affiliates, on the other hand, within the
Buyer Field, in each case, without the consent of, or duty to account to or notify, the other Party,
but, except with respect to external licenses of the Improved Conformis Background IP by Conformis
or its Affiliates to Third Parties, any external Third Party license shall be governed in accordance
with the last sentence of Section 4.3(c) of the APA. Each Party to whom ownership is to vest in
Joint IP by operation of law or by assignment by its employees or Agents agrees to assign and hereby
assigns to the other Party an undivided one-half right, title and interest in and to all Joint IP;
and to facilitate such assignment, the Party possessing such ownership agrees (i) to regularly
ensure that its employees and consultants timely make any appropriate assignments to it; and (ii) at
the other Party's reasonable request, to execute and have its employees and consultants execute, as
necessary, all assignments and any other documentation to perfect the undivided one-half right,
title and interest in and to the other Party of such Joint IP. (d) Notwithstanding anything to the
contrary, the foregoing does not constitute either (1) the grant by Conformis to Stryker of any
license or immunity of any kind with respect to the Conformis Background IP or Conformis Foreground
IP, regardless of the extent to which the Joint IP constitutes improvements to the Conformis
Background IP or Conformis Foreground IP, (2) the grant by Stryker to Conformis of any license or
immunity of any kind with respect to the Stryker Background IP, or (3) the grant by either Party of
any license or immunity of any kind under any Intellectual Property rights owned by such Party,
regardless of whether the exploitation of the Joint IP would infringe such Intellectual Property
rights. Neither Party shall assign a partial interest in 12 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 13 -->
the Joint IP or Joint IP Rights to any Affiliate or Third Party (i.e., neither Party shall create
any additional joint owners of the Joint IP), but each Party may assign all of its right, title and
interest in and to the Joint IP and Joint IP Rights to an Affiliate or Third Party pursuant to and
in accordance with Section 10.2. (e) Conformis shall promptly disclose to Stryker all (i) Improved
Stryker Background IP, and (ii) Joint IP. Stryker shall promptly disclose to Conformis all Joint IP.
(f) To the extent required and for the avoidance of doubt, Stryker hereby grants Conformis, and
Conformis hereby accepts, a non-exclusive license to the Stryker Background IP and Improved Stryker
Background IP solely for purposes of performing any obligations under this Agreement and the
Distribution Agreement. 5.2 Confidential Information. The provisions of Sections 4.3(a)-(i) of
Article 4 of the APA are incorporated herein as if fully set forth herein. 5.3 Maintenance of
Records. Each Party shall prepare and maintain complete and accurate records concerning all
Inventions for the purpose of documenting any possible Intellectual Property rights arising under
this Agreement. 5.4 No Other Rights. (a) Conformis acknowledges and agrees that, as between the
Parties, Stryker owns all right, title and interest, including all Intellectual Property rights,
within the Stryker Background IP and Stryker's Confidential Information, including any Stryker
Confidential Information underlying the Joint IP, and that, under this Agreement, except as
expressly set forth herein, Conformis shall acquire no right, title, or interest in or to any of the
foregoing, or any other Intellectual Property rights that are owned or controlled by Stryker, by
implication, estoppel or otherwise. (b) Stryker acknowledges and agrees that, as between the
Parties, Conformis owns all right, title and interest, including all Intellectual Property rights,
in and to Conformis Background IP and Conformis' Confidential Information, including any Conformis
Confidential Information underlying the Joint IP, and that, under this Agreement, Stryker shall
acquire no right, title, or interest in or to any of the foregoing or any other Intellectual
Property rights that are owned or controlled by Conformis, by implication, estoppel or otherwise.
5.5 Employees and Consultants. 13 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 14 -->
(a) Conformis shall ensure that all its employees, consultants, Agents or other Third Parties who
perform any portion of Conformis' R&D Program obligations under this Agreement have entered into
written agreements with Conformis whereby such employee, consultant, Agent or other Third Party
assigns to Conformis all ownership rights in any Inventions made or developed by such employee,
consultant, Agent or Third Party in the course of such R&D Program work under this Agreement. (b)
Stryker shall ensure that all its Affiliates and its or their employees, consultants, Agents or
other Third Parties who perform any portion of Stryker's R&D Program obligations under this
Agreement have entered into written agreements with Stryker whereby such employee, consultant, Agent
or Third Party assigns to Stryker all ownership rights in any Inventions made or developed by such
employee, consultant, Agent or Third Party in the course of such R&D Program work under this
Agreement. 5.6 Tangible Property. (a) All tooling, patterns, dies, gauges, jobs, fixtures, and all
specifications, drawings, samples, designs, software, firmware, programs, formulae, and other
tangible items ("Equipment") furnished by Stryker to Conformis in connection with this Agreement:
(i) shall only be used in the performance of the R&D Program; (ii) shall remain the property of
Stryker; and (iii) shall be disposed of or returned in good repair, normal wear and tear excepted,
by Conformis to Stryker at Stryker's direction and expense upon Stryker's request. Conformis assumes
risk of loss and damage to said items while in its possession or under its control, subject to
normal wear and tear. Conformis shall notify Stryker promptly whenever any items of Stryker's
tangible property are in need of repair or replacement. Stryker shall endeavor to mark its property
as property of Stryker for 14 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 15 -->
use only under this Agreement. Conformis waives any right it may have in law or equity to withhold
Stryker's property. (b) All Equipment furnished by Conformis to Stryker in connection with this
Agreement: (i) shall only be used in the performance of the R&D Program; (ii) shall remain the
property of Conformis; and (iii) shall be disposed of or returned in good repair, normal wear and
tear excepted, by Stryker to Conformis at Conformis' direction and expense upon Conformis' request.
Stryker assumes risk of loss and damage to said items while in its possession or under its control,
subject to normal wear and tear. Stryker shall notify Conformis promptly whenever any items of
Conformis' tangible property are in need of repair or replacement. Conformis shall endeavor to mark
its property as property of Conformis for use only under this Agreement. Stryker waives any right it
may have in law or equity to withhold Conformis' property. 5.7 Trademarks. Nothing in this Agreement
shall confer to any Party any rights, whether by way of ownership, license or right to use, in any
of the Trademarks of any other Party. Conformis shall not use the Trademarks of Stryker without
Stryker's prior written consent and Stryker shall not use the Trademarks of Conformis without
Conformis' prior written consent. 5.8 Prosecution of Patent Rights. Stryker shall be solely
responsible, in its sole discretion, for preparing, filing, prosecuting and maintaining Patents
arising from all Improved Stryker Background IP. Stryker shall be solely responsible for costs and
expenses of preparing, filing, prosecuting and maintaining any such Patents. Stryker shall have the
first right to prepare, file, prosecute and maintain Patents or copyrights arising from any Joint IP
that is not Improved Conformis Background IP ("Stryker- Prosecuted Joint IP Rights"). Conformis
shall have the first right to prepare, file, prosecute and maintain Patents or copyrights arising
from any Improved Conformis Background IP ("Conformis-Prosecuted Joint IP Rights", and together with
the Stryker- Prosecuted Joint IP Rights, "Joint IP Rights"). With respect to Joint IP Rights, the
non-prosecuting Party will have the right, but not the obligation, to review and comment, and have
the comments reasonably considered by the prosecuting Party, with regard to the filing, prosecution,
15 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 16 -->
and maintenance of the Joint IP Rights. In this regard, the prosecuting Party agrees to provide
reasonable time for the non- prosecuting party to review and comment prior to any deadline
associated with such Patent. Conformis and Stryker shall be equally responsible for costs and
expenses of preparing, filing, prosecuting and maintaining any such Joint IP Rights. Notwithstanding
the foregoing, in the event that the applicable Party decides not to file at all or not to file a
continuing or other application to maintain the viability of the U.S part of a family of patents to
which an application belongs, or decides to abandon or discontinue the prosecution or maintenance of
any of the Joint IP Rights, such Party shall notify the other Party thereof, and such other Party
may elect to continue the prosecution (including non-provisional application and PCT entry) or
maintenance of such Joint IP Rights at its sole expense and in the name(s) of both Stryker and
Conformis. The provisions of Sections 5.1(c) and 5.1(d) and this Section 5.8 shall run with the
Joint IP, and each party shall ensure that any assignee of its interest in the Joint IP expressly
assumes in writing such provisions. Any Party pursuing Patent applications in accordance with this
Section 5.8 may disclose Confidential Information in patent applications to the extent necessary to
provide requisite support for claims therein, provided however, the non-prosecuting Party will have
the right, but not the obligation, to review and comment on the scope and content of the proposed
disclosure, including the proposed disclosure of Confidential Information, prior to submission of
the first disclosure of same in any such Patent applications, and have the comments reasonably
considered by the prosecuting Party. In this regard, the prosecuting Party agrees to provide
reasonable time for the non-prosecuting party to review and comment prior to any such submission
associated with such Patent. 5.9 Infringement and Defense. (a) Each Party may in its sole discretion
enforce the Patents or other intellectual property rights it solely owns pursuant to this Agreement,
as well as to defend against any assertions of invalidity, unenforceability or ownership of such
Patents. (b) The Parties shall confer and consult with respect to disputes with Third Parties
respecting the infringement, validity, enforceability or ownership of any Joint IP, including the
settlement thereof. Such consultation shall be for the purpose of determining the best approach
within such actions and neither Party shall take any action to enforce or defend any Joint IP
without the other Party's prior written consent. 16 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 17 -->
5.10 Publicity. Neither Party shall issue any press release or otherwise publicize this Agreement or
the development work to be conducted hereunder, except in accordance with Section 4.2 of the APA.
ARTICLE VI REPRESENTATIONS AND WARRANTIES 6.1 Representations, Warranties and Covenants. Each Party
hereby represents and warrants to, and covenants with, each other Party that: (a) Due Organization.
Good Standing and Power. It is a corporation duly organized, validly existing and in good standing
under the laws of its jurisdiction of organization and has the power and authority to own, lease and
operate its assets and to conduct the business now being conducted by it. It has all requisite
corporate power and authority to enter into this Agreement and to perform its obligations hereunder.
(b) Authorization and Validity of Agreement. The execution, delivery and performance by it of this
Agreement and the consummation by it of the transactions contemplated hereby have been duly
authorized and approved by all necessary corporate or equivalent action on its part. This Agreement
has been duly executed and delivered by it and constitutes its legal, valid and binding obligation,
enforceable against it in accordance with its terms, except as the same may be limited by applicable
bankruptcy, insolvency, reorganization, moratorium or other Applicable Laws relating to or affecting
creditors' rights generally and by general equity principles. (c) Absence of Conflicts. The
execution, delivery and performance by it of this Agreement and the consummation by it of the
transactions contemplated hereby do not and will not: (i) violate any Applicable Laws, regulations,
orders, writs, injunctions or decrees of any governmental, judicial, legislative, executive,
administrative or regulatory 17 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 18 -->
authority of the United States or any foreign country or of any state or local governmental
authority; (ii) conflict with, or result in the breach of any provision of, its certificate or
articles of incorporation, bylaws or equivalent organizational documents; (iii) result in the
creation of any lien or encumbrance of any nature upon any property being transferred or licensed by
it pursuant to this Agreement; or (iv) violate, conflict with, result in the breach or termination
of or constitute a default under (or event which with notice, lapse of time or both would constitute
a default under), any permit, contract or agreement to which it is a Party or by which any of its
properties or businesses are bound. (d) Consents. No authorization, consent or approval of, or
notice to or filing with, any governmental authority is required for the execution, delivery and
performance by it of this Agreement, other than those associated with obtaining required regulatory
approvals as contemplated hereby. (e) Employee and Consultant Obligations. Each of its employees,
consultants and Agents who will engage in activities on behalf of a Party under the R&D Work Plan,
or who will have access to Confidential Information, is contractually obligated, or will be
contractually obligated prior to his/her participation or access, to (i) assign to the Party all
Intellectual Property rights conceived, made or discovered by such employee or Agent, whether solely
or in collaboration with others, in connection with such employee's, consultant's or Agent's work
for the Party, and (ii) maintain the confidentiality of the Confidential Information. To the extent
applicable, it is the intent of the Parties that ownership of all developments under this Agreement
shall vest in the respective Party by operation of law or by assignment prior to assignment to the
other Party pursuant to Article V. 18 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 19 -->
(f) Debarment. No employee, consultant or Agent who will engage in activities on behalf of such
Party under the R&D Work Plan, or who will have access to Confidential Information of the other
Party, has been the subject of a debarment proceeding under 21 U.S.C. § 335a, and has been excluded
from participation in any Federal or State or other government health care program. 6.2 EXCEPT AS
EXPRESSLY PROVIDED ELSEWHERE IN THIS AGREEMENT, INCLUDING THE REQUIREMENTS IN THE R&D WORK PLAN,
CONFORMIS MAKES NO WARRANTY WITH RESPECT TO THE SERVICES OR DELIVERABLES FURNISHED HEREUNDER, AND NO
WARRANTIES OF ANY KIND, WHETHER WRITTEN, ORAL, IMPLIED OR STATUTORY, INCLUDING WARRANTIES OF
MERCHANTABILITY, NON- INFRINGEMENT OR FITNESS FOR A PARTICULAR PURPOSE, SHALL APPLY. ARTICLE VII
LIMITATION ON LIABILITY AND INDEMNIFICATION 7.1 Responsibility and Control. Each Party shall be
solely responsible for the safety of its own employees, Agents and subcontractors with respect to
their activities related to this Agreement. 7.2 Limitation of Liability. EXCEPT FOR [**], IN NO
EVENT WILL EITHER PARTY BE LIABLE TO THE OTHER PARTY FOR [**], EVEN IF SUCH PARTY WAS ADVISED OR
AWARE OF THE POSSIBILITY OF SUCH DAMAGES. CONFORMIS' LIABILITY ON A PER OCCURRENCE BASIS UNDER
SECTION 7.3(A)(IV) SHALL NOT EXCEED THE GREATER OF (I) $[**] AND (II) THE AMOUNT OF INSURANCE
COVERAGE ACTUALLY PAID TO CONFORMIS UNDER THEN-CURRENT INSURANCE POLICIES OF CONFORMIS IN RESPECT OF
SUCH DAMAGES. For the purposes of this Section 7.2, "per occurrence" means the occurrence of any
claim or series of claims directly arising out of or resulting from the same act, omission or event.
7.3 Mutual Indemnification. (a) Indemnification by Conformis. Conformis shall indemnify and hold
harmless Stryker, its directors, officers, employees, Agents and Affiliates and 19 Source: CONFORMIS
INC, 10-Q, 11/1/2019
<!-- page 20 -->
their respective successors, heirs and assigns (collectively the "Stryker Indemnified Parties")
against any and all claims, suits, actions, and demands, wherever brought and however denominated,
brought by a Third Party (all of the foregoing being referred to herein as "Claims") against the
Stryker Indemnified Party including all damages, collateral damages and settlements arising
therefrom and reasonable outside attorneys' fees and litigation expenses related thereto, to the
extent arising from or related to (i) any breach of Conformis' representations, warranties or
obligations under this Agreement, (ii) any alleged violation of any Applicable Laws by Conformis,
(iii) the negligence (excluding any product liability Claim), gross negligence or intentionally
wrongful acts or omissions of Conformis, its employees, consultants, Agents and Affiliates in their
performance hereunder, and (iv) any portion of a Claim alleging personal injury on account of
product liability attributable to a Deliverable (including a Deliverable within a Product or a
Stryker Product). Conformis shall have no obligation or liability with respect to any Claim under
Section 7.3(a)(iii) or Section 7.3(a)(iv) to the extent directly arising out of or relating to: (1)
any use of the Products in any manner not in accordance with applicable documentation (e.g.,
instructions for use, package inserts, labels, surgical guides and other materials provided by or
approved by Conformis) that is not a result of Conformis' conduct; (2) damage to the Products
occurring after shipment that is not a result of Conformis' conduct; or (3) any modifications to the
Products that are not contemplated by the instructions for use thereto by any Person other than
Supplier and that is not a result of Conformis' conduct. Notwithstanding anything to the contrary,
Stryker's sole remedy and Conformis' exclusive liability for breach of Section 3.2 with respect to a
Product or a Stryker Product shall be as set forth in Section 10.1(i) of the Distribution Agreement.
(b) Indemnification by Stryker. Stryker shall indemnify and hold harmless Conformis, its directors,
officers, employees, Agents and 20 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 21 -->
Affiliates and their respective successors, heirs and assigns (collectively the "Conformis
Indemnified Parties") against any and all Claims against the Conformis Indemnified Parties to the
extent arising from or related to (i) any breach of Stryker's representations or warranties under
this Agreement, (ii) any alleged violation of any Applicable Laws by Stryker, and (iii) the grossly
negligent or intentionally wrongful acts or omissions of Stryker, its employees, consultants, Agents
and Affiliates in their performance hereunder. (c) Joint Liability. To the extent that Stryker, on
the one hand, and Conformis, on the other hand, each has indemnification obligations to the other in
connection with a single Claim, they will contribute to the aggregate damages, liabilities, costs
and expenses arising from such Claim in a proportion reflecting the relative and comparative
responsibilities and determined liability of the Parties for such damages, liabilities, costs and
expenses, as well as any other relevant equitable considerations. The amount paid or payable by a
Party for purposes: of apportioning the aggregate damages, liabilities, costs and expenses shall be
deemed to include all reasonable legal fees and expenses incurred by such Party in connection with
investigating, preparing for or defending against such Claim. (d) Indemnification Procedures. Claims
for indemnification under this Agreement shall be governed by the indemnification procedures set
forth in Section 5.5 of the Asset Purchase Agreement. (e) Settlement. If the indemnifying Party
assumes the defense of a Claim, no compromise or settlement of such claims may be effected by the
indemnifying Party without the indemnified Party consent unless: (a) there is no finding or
admission of any violation of Applicable Requirements or any violation of the rights of any Person
by the indemnified Party and no effect on any other claims that may be made against the indemnified
Party, (b) the sole relief provided is 21 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 22 -->
monetary damages that are paid in full by the indemnifying Party and (c) such settlement includes as
an unconditional release of liability by such Third Party claimant in respect of all Indemnified
Persons. ARTICLE VIII TERM AND TERMINATION 8.1 Term. The term of this Agreement shall begin as of
the Effective Date and continue until Acceptance of all Deliverables for Milestones #1 and #2
pursuant to Section 3.4 and completion of Milestone #3, unless earlier terminated under Section 8.2,
as provided for under the Other Agreements, or as mutually agreed by the Parties. 8.2 Termination.
(a) Dissolution or Insolvency Event. Either Party may terminate this Agreement effective immediately
upon delivery of a Termination Notice if the other Party is (A) dissolved or is seeking to dissolve
itself under applicable corporate law other than as part of a corporate restructuring under which
its assets were first transferred to an assignee under this Agreement in accordance with Section
10.2; or (B) (i) becomes subject to an Insolvency Event, provided that, no termination right shall
exist in respect of an Insolvency Event that is a chapter 11 case under the Bankruptcy Code if the
Party subject to such chapter 11 case (x) continues to perform all of its material obligations under
this Agreement, (y) does not seek to reject this Agreement or take any action in such chapter 11
case to disavow or undermine the rights of the other Party under this Agreement, and (z) assumes
this Agreement on or before any deadline in such chapter 11 case for such assumption;
notwithstanding the foregoing, nothing herein shall limit or prevent the Party not subject to an
Insolvency Event from objecting to assumption or assumption and assignment of this Agreement or
requiring cure payments or adequate assurance 22 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 23 -->
of future performance as a condition of assumption or assumption and assignment. (b) Default. If any
Party believes the other is in material breach of any of its material obligations under this
Agreement in a manner other than as set forth in Article III to which this Section 8.2(b) does not
apply, it may give notice of such material breach to the allegedly breaching Party, which Party
shall have [**] (or such longer period of time as may be reasonably commensurate with the effort
reasonably required to remedy such default) in which to remedy such default. If such alleged
material breach is not remedied in the time period set forth above, the Party alleging material
breach shall refer the matter to the chief executive officers of each Party, who shall meet and
confer within [**] after notice from the non-breaching Party of its desire for such a meeting. If
the Parties are unable to resolve any dispute in such meeting and no Action has been brought in
accordance with Section 10.8 with respect to such dispute, the non-breaching Party may terminate
this Agreement immediately upon delivery to the defaulting Party of a Termination Notice. The
non-defaulting Party's right to terminate this Agreement in accordance with this Section 8.2(b)
shall not be construed as an exclusive remedy. (c) If Stryker Finally Rejects any Deliverable for
Milestone #1 or #2 in accordance with Article III, Stryker may terminate this Agreement, which
termination shall be effective immediately upon delivery of a Termination Notice to Conformis. 8.3
Surviving Rights/Obligations. (a) The provisions of Articles V, VI, VII and IX and Sections 8.3,
8.4, 10.1, 10.2, 10.5 - 10.13 and 10.15, together with any provisions required for the
interpretation or enforcement of any of the foregoing, shall survive the termination or expiration
of this Agreement, provided, however that Section 7.3(a)(iv) shall survive the termination or
expiration of this Agreement for only [**] thereafter. The termination of this Agreement shall not
relieve any Party from obligations that are expressly indicated to survive termination of the
Agreement. 23 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 24 -->
8.4 Return or Destruction of Confidential Information. Solely with respect to Confidential
Information in which a Party has no ownership interest at all, owned or co-owned Confidential
Information being exempt herefrom, upon termination of this Agreement, unless independently
authorized to retain such of the Disclosing Party's Confidential Information under an Other
Agreement, each Receiving Party shall, and shall direct its Representatives to, cease all use and
make no further use of any Confidential Information of the Disclosing Party and shall, upon written
request from the Disclosing Party, promptly return or destroy all Confidential Information of the
Disclosing Party (including copies thereof) that is in tangible form (provided, however, that, with
respect to electronic imaging of the Disclosing Party's Confidential Information, such materials
shall be deleted and removed from access by an ordinary user from all computer hard drives, servers
and similar media but shall not require any action to delete or erase such materials from any
disaster recovery tapes or other back-up media or any record retention or computer storage system so
long as the Receiving Party and its Representatives take such actions as are reasonably likely to
prevent access to such materials by any person other than information technology and other
administrative employees who are responsible for maintaining those disaster recovery tapes and other
back-up media) and any documents created by the Receiving Party or any of its Representatives
containing Confidential Information of the Disclosing Party. The Receiving Party shall provide to
the Disclosing Party written certification of destroyed Confidential Information of the Disclosing
Party promptly following the destruction thereof. Notwithstanding the foregoing, the Receiving Party
and its Representatives may retain one copy of any Confidential Information of the Disclosing Party
in a secure location in the Receiving Party's legal department for the purpose of establishing
compliance with Applicable Laws (including professional standards) and for defending or maintaining
any litigation (including any administrative proceeding) relating to this Agreement, the Other
Agreement, the Prior CDA or the Confidential Information, provided that all such information shall
continue to be kept confidential pursuant to the terms of this Agreement. 24 Source: CONFORMIS INC,
10-Q, 11/1/2019
<!-- page 25 -->
ARTICLE IX RECORD-KEEPING AND AUDITS 9.1 Records Retention. Each of the Parties shall record in
written or electronic form all material information with respect to the performance of its
obligations relating to the R&D Program in accordance with standard industry practices. ARTICLE X
MISCELLANEOUS 10.1 Agency. Neither this Agreement nor any of the Other Agreements creates any
partnership, agency or other relationship among the Parties for any purpose, including for all tax
purposes. No Party is granted any right or authority to assume or to create any obligation or
responsibility on behalf or in the name of the other Party or to bind the other Party in any manner
whatsoever. 10.2 Assignment and Change of Control. Except as otherwise provided herein, a Party
shall not have the right to assign any of its rights or obligations under this Agreement (whether
through a merger, sale of stock, or otherwise) without the prior written consent of the other Party;
except that, either Party shall be permitted, without any need for the other Party's consent, to
assign this Agreement (a) in whole or in part to an Affiliate (provided, however, that once such
Person is no longer an Affiliate of the assigning Party, such former Affiliate shall assign this
Agreement back to the assigning Party), provided that the assigning Party provides the other Party
notice of any such assignment provided further that failure to provide such notice of such
assignment shall not render such assignment void; or (b) to a Third Party in connection with sale or
transfer of all or substantially all of the assigning Party's business or assets relating to the
subject matter of this Agreement, whether by Change of Control, merger, sale of assets or otherwise;
provided, however, that, with respect to clause (b), (i) any assignment of this Agreement shall be
void and have no effect unless and until the assignee assumes the 25 Source: CONFORMIS INC, 10-Q,
11/1/2019
<!-- page 26 -->
obligations of the assigning Party in a written instrument, a copy of which is provided to the other
Party; and (ii) any assignment of this Agreement must be accompanied by a simultaneous assignment of
the Other Agreements to the same assignee, and the assigning Party's interest in the Purchased
Assets to the same assignee unless otherwise agreed by Conformis in advance, which agreement shall
not be unreasonably withheld. Any assignment in whole or in part shall not relieve the assigning
Party of its obligations hereunder. If and to the extent that a Party assigns any of its rights
and/or obligations hereunder in accordance with this Section 10.2, then this Agreement shall be
binding upon the assignee to the same extent as if it were a Party hereto. Any assignment not in
accordance with this Section 10.2 shall be void. 10.3 Further Actions. Each Party agrees, subsequent
to the execution and delivery of this Agreement and without any additional consideration, to
execute, acknowledge and deliver such further documents and instruments, and to do all such other
acts, as may be necessary or appropriate in order to carry out the purposes and intent of this
Agreement. 10.4 Force Majeure. (a) In the event that either Party is unable to perform any of its
obligations under this Agreement, or to enjoy any of its benefits because of fire, natural disaster,
action or decrees of Governmental Entities or any other event not within such Party's reasonable
control (a "Force Majeure Event"), the Party who has been so affected shall give written notice to
the other Party as soon as practicable and shall do everything reasonably possible to resume
performance. Upon receipt of such notice, all obligations under the Agreement shall be immediately
suspended. If the period of nonperformance exceeds [**] from the receipt of notice of the Force
Majeure Event, the Party whose ability to perform has not been so affected may, by giving written
notice, terminate the Agreement. Any acceptance or warranty period affected by a Force Majeure Event
shall likewise be extended for a period equal to the duration of such Force Majeure Event. As
applied to this Section 10.4 26 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 27 -->
and to determine whether an event is reasonably beyond control of a Party, materials shortages,
strikes, slowdowns, other labor related delays or events resulting from a Party's, its Affiliates or
their respective agents' negligence, gross negligence, fraud or intentional misconduct are not Force
Majeure Events. (b) Notwithstanding the provisions set forth in Section 10.4(a), above, a Force
Majeure Event shall not include any governmental action of an enforcement nature that arises from or
relates to either Party's failure to comply with any federal, national, state, provincial,
international, or local law, statute, regulation or ordinance applicable to such Party's performance
hereunder. 10.5 Notices. All notices, requests, demands, waivers, instructions, consents and other
communications to be given pursuant to the terms of this Agreement will be in writing and will be
deemed to have been duly given upon receipt if delivered by hand, sent by a nationally recognized
overnight mail service, or mailed by registered or certified mail, return receipt requested, postage
prepaid: If to Stryker, addressed to: Howmedica Osteonics Corp. c/o Stryker Corporation Attn: Legal
Department, [**] 325 Corporate Drive Mahwah, NJ 07430 If to Conformis, addressed to: Conformis, Inc.
Attn: Chief Executive Officer and General Counsel 600 Technology Park Drive Billerica, MA 01821 With
a copy (which shall not constitute notice) to: 27 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 28 -->
WilmerHale Attn: Jason Kropp, Esq. 60 State Street Boston, MA 02109 Any Party may change its
address, telephone number, or facsimile number by prior written notice to the other Party. 10.6
Amendments and Waivers. This Agreement may not be modified or amended except by an instrument or
instruments in writing signed by the Party against whom enforcement of any such modification or
amendment is sought. Conformis may waive compliance by Stryker or Stryker may waive compliance by
Conformis with any term or provision of this Agreement on the part of such Party to be performed or
complied with, but only by an instrument in writing. The waiver by any Party of a breach of any term
or provision of this Agreement will not be construed as a waiver of any subsequent breach. 10.7
Governing Law. This Agreement shall be governed and construed in accordance with the laws of New
York State (without regard to the conflict of laws provisions thereof). 10.8 Jurisdiction. Subject
to Section 10.14, the federal and state Courts of New York State shall have exclusive jurisdiction
to hear and decide any suit, Action or proceedings, and to settle any disputes, which may arise out
of or in connection with this Agreement; provided, however, that each Party shall have the right to
institute judicial proceedings in any court of competent jurisdiction against the other Party or
anyone acting by, through or under the other Party, in order to enforce an Order entered by federal
state courts of New York. Each Party shall cause its applicable permitted Third Party sublicensees
and Affiliates receiving any rights or benefits (including the receipt of any Confidential
Information) under this Agreement to be bound by this Section 10.8 prior to their exercise of any
such rights or receipt of any such benefits. If such Party fails to comply with the foregoing
sentence 28 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 29 -->
with respect to any such Third Party or Affiliate, the other Party shall have the right to seek
relief in any court of competent jurisdiction in connection with any dispute involving such Third
Party or Affiliate. 10.9 Severability. The provisions of this Agreement shall be deemed severable
and the invalidity or unenforceability of any provision shall not affect the validity or
enforceability of the other provisions hereof. If any term or other provision of this Agreement, or
the application thereof to any Person or any circumstance, is invalid, illegal or unenforceable by a
Court of competent jurisdiction, (a) a suitable and equitable provision shall be substituted
therefor in order to carry out, so far as may be valid and enforceable, the intent and purpose of
such invalid or unenforceable provision and (b) the remainder of this Agreement and the application
of such provision to other Persons or circumstances shall not be affected by such invalidity,
illegality or unenforceability, nor shall such invalidity, illegality or unenforceability affect the
validity or enforceability of such provision, or the application thereof, in any other jurisdiction.
10.10 Entire Agreement and Third-Party Beneficiaries. This Agreement (including the Other
Agreements) contains the entire agreement by and among the Parties with respect to the subject
matter hereof and there are no agreements, understandings, representations or warranties between the
Parties other than those set forth or referred to herein. This Agreement is not intended to confer
upon any Person not a party (or their successors and assigns permitted by Section 10.2), and to the
extent expressly provided, their Affiliates, Agents, employees and representatives, any rights or
remedies hereunder, except that Section 7.3(a) and Section 7.3(b) hereof are intended to benefit,
and to be enforceable by, any of the Relevant Indemnified Parties therein described. 10.11 Jointly
Prepared. This Agreement has been prepared jointly and shall not be strictly construed against any
Party. 29 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 30 -->
10.12 Expenses. Except as otherwise set forth in this Agreement and the Other Agreements, all legal
and other costs and expenses incurred in connection with this Agreement and the transactions
contemplated hereby will be paid by the Party incurring such costs and expenses. 10.13 Counterparts
and Electronic Transmission. This Agreement may be executed in one or more counterparts, all of
which will be considered one and the same agreement, and will become effective when one or more
counterparts have been signed by each of the Parties and delivered to the other Party. This
Agreement may be executed and delivered by facsimile or e- mail transmission with the same effect as
if a manually signed original was personally delivered. 10.14 Negotiation in Event of Dispute. In
the event of any dispute or disagreement between any of the Parties as to the interpretation of any
provision of this Agreement or any agreement incorporated herein, the performance of obligations
hereunder or thereunder, or any other disputed matter relating hereto or thereto, such matter, upon
the written request of any Party, will be referred to an executive of each Party. Such executives
will promptly meet in good faith to resolve the dispute. If the executives do not agree upon a
decision within thirty calendar days after the reference of the matter to them, any Party will be
free to exercise any remedies available to it. 10.15 Rules of Construction. As used in this
Agreement, the words "include", "includes" and "including" means "including without limitation", and
no inferences or conclusions of any sort shall be drawn from the fact that in some instances in this
Agreement the words "include", "includes" and "including" are actually followed by the phrase
"without limitation" or the equivalent while in other instances they are not. Except where the
context expressly requires otherwise, the use of any gender herein will be deemed to encompass
references to any gender, and the use of the singular will be deemed to include the plural (and vice
versa). 30 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 31 -->
[Signature Page Follows] 31 Source: CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 32 -->
IN WITNESS WHEREOF, the parties have caused this Development Agreement to be duly executed as of the
respective dates written below. HOWMEDICA OSTEONICS CORP. CONFORMIS, INC. By: /s/ Spencer Stiles By:
/s/ Mark A. Augusti Name: Spencer Stiles Name: Mark A. Augusti Title: President Title: President and
CEO Date: September 26, 2019 Date: 9-30-2019 [Signature Page to Development Agreement] Source:
CONFORMIS INC, 10-Q, 11/1/2019
<!-- page 33 -->
Execution Version Certain identified information has been excluded from the exhibit because it is
both (i) not material and (ii) would likely cause competitive harm to the Company, if publicly
disclosed. Double asterisks denote omissions. Source: CONFORMIS INC, 10-Q, 11/1/2019
