"""grep: regex search over the workspace.

Returns COMPLETE per-document counts (the agent reasons over counts — INDEXACT ablation:
binary feedback instead of counts costs ~12 points) and a CAPPED list of matches with
short context. Pure-Python implementation over the cached lines; `rg` is used only to
pre-select candidate documents when available and the workspace is large.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import time
from collections import Counter

from ..config import DEFAULT, Config
from ..models import GrepMatch, GrepResult
from ..workspace import Workspace


def _rg_candidate_docs(
    ws: Workspace, pattern: str, ignore_case: bool, fixed_strings: bool = False
) -> set[str] | None:
    """Use ripgrep to list files with >=1 match. Returns None if rg is unavailable/fails.

    `fixed_strings` must mirror the Python side: when `grep()` fell back to a literal search
    because the pattern is not a valid regex, rg is told the same with `-F` so both stages
    agree on what counts as a match.
    """
    rg = shutil.which("rg")
    if not rg:
        return None
    cmd = [rg, "-l", "--no-messages"]
    if ignore_case:
        cmd.append("-i")
    if fixed_strings:
        cmd.append("-F")
    cmd += ["-e", pattern, str(ws.docs_dir)]
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=10, check=False)
    except (subprocess.TimeoutExpired, OSError):
        return None
    if out.returncode not in (0, 1):  # 1 = no matches
        return None
    return _doc_ids_from_rg_output(out.stdout)


def _doc_ids_from_rg_output(stdout: str) -> set[str]:
    """Map rg's one-path-per-line output to doc_ids.

    rg prints OS-native paths, so on Windows the separator is a backslash; splitting on '/'
    alone returned the whole path as the "doc_id" and silently emptied the search scope.
    doc_ids never contain either separator (see Workspace.path_of), so normalising both is safe.
    """
    ids: set[str] = set()
    for line in stdout.splitlines():
        name = line.strip().replace("\\", "/").rsplit("/", 1)[-1]
        if name.endswith(".md") and len(name) > 3:
            ids.add(name[:-3])
    return ids


def grep(
    ws: Workspace,
    pattern: str,
    doc_ids: list[str] | None = None,
    ignore_case: bool = True,
    max_matches: int | None = None,
    context_lines: int | None = None,
    config: Config = DEFAULT,
) -> GrepResult:
    """Search `pattern` (Python regex) across the workspace, optionally scoped to `doc_ids`."""
    t0 = time.perf_counter()
    caps = config.tools
    max_matches = caps.GREP_MAX_MATCHES if max_matches is None else min(max_matches, caps.GREP_MAX_MATCHES)
    ctx = caps.GREP_CONTEXT_LINES if context_lines is None else min(context_lines, 3)
    flags = re.IGNORECASE if ignore_case else 0
    literal = False
    try:
        rx = re.compile(pattern, flags)
    except re.error:
        # Fall back to a literal search rather than failing the agent's turn.
        rx = re.compile(re.escape(pattern), flags)
        literal = True

    scope = list(doc_ids) if doc_ids else ws.doc_ids()
    scope = [d for d in scope if d in ws.manifest]
    if len(scope) > 200:
        cand = _rg_candidate_docs(ws, pattern, ignore_case, fixed_strings=literal)
        if cand is not None:
            scope = [d for d in scope if d in cand]

    counts: Counter[str] = Counter()
    matches: list[GrepMatch] = []
    truncated = False
    for doc_id in scope:
        lines = ws.lines(doc_id)
        for i, ln in enumerate(lines, start=1):
            if rx.search(ln):
                counts[doc_id] += 1
                if len(matches) < max_matches:
                    before = [_clip(x, caps) for x in lines[max(0, i - 1 - ctx) : i - 1]]
                    after = [_clip(x, caps) for x in lines[i : i + ctx]]
                    matches.append(
                        GrepMatch(
                            doc_id=doc_id,
                            line=i,
                            page=ws.page_of(doc_id, i),
                            text=_clip(ln, caps),
                            before=before,
                            after=after,
                        )
                    )
                else:
                    truncated = True
    ranked = counts.most_common()
    per_doc = ranked[: caps.GREP_MAX_DOCS_IN_COUNTS]
    return GrepResult(
        pattern=pattern,
        total_matches=sum(counts.values()),
        docs_with_matches=len(counts),
        per_doc_counts=per_doc,
        per_doc_counts_truncated=len(ranked) > len(per_doc),
        matches=matches,
        matches_truncated=truncated,
        elapsed_ms=int((time.perf_counter() - t0) * 1000),
    )


def _clip(s: str, caps) -> str:
    return s if len(s) <= caps.GREP_MAX_LINE_CHARS else s[: caps.GREP_MAX_LINE_CHARS] + "…"


def render(res: GrepResult) -> str:
    """Compact text rendering for the model."""
    out = [
        f"grep /{res.pattern}/: {res.total_matches} matches in {res.docs_with_matches} docs"
        + (" (showing first %d)" % len(res.matches) if res.matches_truncated else "")
    ]
    if res.per_doc_counts:
        out.append("counts: " + ", ".join(f"{d}:{c}" for d, c in res.per_doc_counts)
                   + (" …" if res.per_doc_counts_truncated else ""))
    for m in res.matches:
        pg = f" p.{m.page}" if m.page else ""
        out.append(f"[{m.doc_id}:{m.line}{pg}] {m.text}")
        for a in m.after:
            out.append(f"    {a}")
    return "\n".join(out)
