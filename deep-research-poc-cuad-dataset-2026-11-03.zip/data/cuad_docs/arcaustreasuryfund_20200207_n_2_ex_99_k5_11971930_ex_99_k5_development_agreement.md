<!-- page 1 -->
# BLOCKCHAIN ADMINISTRATION AND DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| SEC Filing Date | 2020-02-07 |
| Parties | ARCA U.S. TREASURY FUND ("Fund"); ARCA CAPITAL MANAGEMENT, LLC ("Blockchain Administrator") |
| Source | CUAD v1 / ArcaUsTreasuryFund_20200207_N-2_EX-99.K5_11971930_EX-99.K5_Development Agreement |

Exhibit 99(k)(5) FORM OF BLOCKCHAIN ADMINISTRATION AND DEVELOPMENT AGREEMENT BETWEEN ARCA U.S.
TREASURY FUND AND ARCA CAPITAL MANAGEMENT, LLC This Agreement ("Agreement") is made as of [___],
2020 by and between ARCA U.S. TREASURY FUND, a Delaware statutory trust (the "Fund"), and ARCA
CAPITAL MANAGEMENT, LLC, a Delaware limited liability company (the "Blockchain Administrator").
WHEREAS, the Fund is a closed-end management investment fund that has registered as an investment
company under the Investment Company Act of 1940, as amended (the "Investment Company Act") and that
intends to operate as an interval fund pursuant to Rule 23c-3 under the Investment Company Act;
WHEREAS, the Fund desires to retain the Blockchain Administrator to provide services related to the
development of ERC-1404 compatible digital securities and administration of the smart contracts
underlying the Fund's digital securities in the manner and on the terms set forth herein; WHEREAS,
the Blockchain Administrator is willing to provide such services to the Fund on the terms and
conditions set forth herein; WHEREAS, the Blockchain Administrator will also serve as the Fund's
investment adviser (the "Adviser") pursuant to an Investment Advisory Agreement entered into by and
between the Fund and the Adviser (as amended from time to time, the "Advisory Agreement"); and
WHEREAS, the Fund bears all costs and expenses incurred in its operation, administration and
transactions which are not specifically assumed by the Adviser pursuant to the Advisory Agreement or
this Agreement. NOW, THEREFORE, in consideration of the premises and the covenants hereinafter
contained and for other good and valuable consideration, the receipt and adequacy of which is hereby
acknowledged, the Fund and the Blockchain Administrator hereby agree as follows: 1. Duties of the
Blockchain Administrator (a) The Fund hereby employs the Blockchain Administrator to act as the
blockchain administrator of the Fund, and to furnish, or arrange for others to furnish, the
services, personnel and facilities described below, subject to review by and the overall control of
the Fund's Board of Trustees (the "Board"), for the period and on the terms and conditions set forth
in this Agreement. (b) The Blockchain Administrator hereby accepts such employment and agrees during
such period to render, or arrange for the rendering of, such services and to assume the obligations
herein set forth subject to the reimbursement of costs and expenses provided for below. (c) The
Blockchain Administrator shall perform (or oversee, or arrange for, the performance of) development
and administrative services necessary for the issuance of the Fund's shares as ERC-1404 compatible
digital securities ("Shares") and the on-going maintenance and administration of the smart contracts
underlying such Shares. Without limiting the generality of the foregoing, the Blockchain
Administrator shall provide the Fund with facilities, equipment, technology, coding and such other
services as the Blockchain Administrator, subject to review by the Board, shall from time to time
determine to be necessary or useful to perform its obligations under this Agreement.

1

Source: ARCA U.S. TREASURY FUND, N-2, 2/7/2020
<!-- page 2 -->
(d) The Blockchain Administrator shall also, on behalf of the Fund, conduct relations with
custodians, depositories, transfer agents, dividend disbursing agents, other stockholder servicing
agents, accountants, attorneys, underwriters, brokers and dealers, corporate fiduciaries, insurers,
banks and such other persons as the Blockchain Administrator shall deem to be necessary or desirable
in connection with the issuance and transfer of the Fund's ERC-1404 compatible digital security,.
(e) The Blockchain Administrator shall make reports to the Board of its performance of obligations
hereunder and furnish advice and recommendations with respect to such other aspects of the business
and affairs of the Fund as it shall determine to be desirable; provided that nothing herein shall be
construed to require the Blockchain Administrator to, and the Blockchain Administrator shall not, in
its capacity as Blockchain Administrator pursuant to this Agreement, provide any advice or
recommendation relating to the securities and other assets that the Fund should purchase, retain or
sell or any other investment advisory services to the Fund. (f) The Blockchain Administrator shall
for all purposes herein be deemed to be an independent contractor and shall, unless otherwise
expressly provided or authorized herein, have no authority to act for or represent the Fund in any
way or otherwise be deemed an agent of the Fund. (g) The Blockchain Administrator is hereby
authorized to enter into agreements with other service providers pursuant to which the Blockchain
Administrator may obtain the services of the service providers in fulfilling its responsibilities
hereunder. The Blockchain Administrator shall ensure that any such service provider shall operate in
conformity with the requirements of the Investment Company Act and other applicable federal and
state law and shall maintain books and records of the Fund (if any) in a manner substantially
similar to Section 2 of this Agreement. 2. Maintenance of Records The Blockchain Administrator
agrees to maintain and keep all books, accounts and other records of the Fund that relate to
activities performed by the Blockchain Administrator hereunder and will maintain and keep such
books, accounts and records in accordance with the Investment Company Act. In compliance with the
requirements of Rule 31a-3 under the Investment Company Act, the Blockchain Administrator agrees
that all records which it maintains for the Fund shall at all times remain the property of the Fund,
shall be readily accessible during normal business hours, and shall be promptly surrendered upon the
termination of the Agreement or otherwise on written request. The Blockchain Administrator further
agrees that all records which it maintains for the Fund pursuant to Rule 31a-1 under the Investment
Company Act will be preserved for the periods prescribed by Rule 31a-2 under the Investment Company
Act unless any such records are earlier surrendered as provided above. Records shall be surrendered
in usable machine-readable form. The Blockchain Administrator shall have the right to retain copies
of such records subject to observance of its confidentiality obligations under this Agreement. 3.
Confidentiality The parties hereto agree that each shall treat confidentially the terms and
conditions of this Agreement and all information provided by each party to the other regarding its
business and operations. All confidential information provided by a party hereto, including
nonpublic personal information (regulated pursuant to Regulation S-P), shall be used by any other
party hereto solely for the purpose of rendering services pursuant to this Agreement and, except as
may be required in carrying out this Agreement, shall not be disclosed to any third party, without
the prior consent of such providing party. The foregoing shall not be applicable to any information
that is publicly available when provided or thereafter becomes publicly available other than through
a breach of this Agreement, or that is required to be disclosed by any regulatory authority, any
authority or legal counsel of the parties hereto, by judicial or administrative process or otherwise
by applicable law or regulation. 4. Compensation; Allocation of Costs and Expenses (a) In full
consideration of the provision of the services of the Blockchain Administrator set forth herein, the
Fund shall pay the Blockchain Administrator a fees calculated at the annual rate of 0.20% of the
value of the Fund's average annual net assets. Such fee shall be accrued daily and paid monthly in
arrears.

2

Source: ARCA U.S. TREASURY FUND, N-2, 2/7/2020
<!-- page 3 -->
(b) The Fund shall bear all fees, costs and expenses incurred in connection with its operation,
administration and transactions that are not specifically assumed by the Blockchain Administrator
(or the Adviser, if not the Blockchain Administrator, pursuant to the Advisory Agreement), including
but not limited to: (i) compensation of the Fund's Trustees who are not affiliated with the Fund's
Adviser or the Fund's principal underwriter/distributor or any of their respective affiliates; (ii)
taxes and governmental fees; (iii) interest charges; (iv) fees and expenses of the Fund's
independent accountants and legal counsel; (v) trade association membership dues; (vi) fees and
expenses of any custodian (including maintenance of books and accounts and calculation of the net
asset value of shares of the Fund), transfer agent, registrar and dividend disbursing agent of the
Fund; (vii) expenses of issuing, redeeming, registering and qualifying for sale shares of beneficial
interest in the Fund; (viii) expenses of preparing prospectuses and reports to shareholders,
notices, proxy statements and reports to regulatory agencies; (ix) the cost of office supplies,
including stationery; travel expenses of all officers, Trustees and employees; (x) insurance
premiums; (xi) brokerage and other expenses of executing portfolio transactions; (xii) expenses of
shareholders' meetings; (xiii) organizational expenses; and (xiv) extraordinary expenses. 5.
Limitation of Liability of the Blockchain Administrator; Indemnification The Blockchain
Administrator (and its officers, managers, partners, agents, employees, controlling persons, members
and any other person or entity affiliated with the Blockchain Administrator) shall not be liable to
the Fund for any action taken or omitted to be taken by the Blockchain Administrator in connection
with the performance of any of its duties or obligations under this Agreement or otherwise as
blockchain administrator of the Fund, and the Fund shall indemnify, defend and protect the
Blockchain Administrator (and its officers, managers, partners, agents, employees, controlling
persons, members and any other person or entity affiliated with the Blockchain Administrator)
(collectively, the "Indemnified Parties") and hold them harmless from and against all damages,
liabilities, costs and expenses (including reasonable attorneys' fees and amounts reasonably paid in
settlement) incurred by the Indemnified Parties in or by reason of any pending, threatened or
completed action, suit, investigation or other proceeding (including an action or suit by or in the
right of the Fund or its security holders) arising out of or otherwise based upon the performance of
any of the Blockchain Administrator's duties or obligations under this Agreement or otherwise as
administrator of the Fund. Notwithstanding the preceding sentence of this Section 5 to the contrary,
nothing contained herein shall protect or be deemed to protect the Indemnified Parties against or
entitle or be deemed to entitle the Indemnified Parties to indemnification in respect of, any
liability to the Fund or its security holders to which the Indemnified Parties would otherwise be
subject by reason of criminal conduct, willful misfeasance, bad faith or gross negligence in the
performance of the Blockchain Administrator's duties or by reason of the reckless disregard of the
Blockchain Administrator's duties and obligations under this Agreement. 6. Activities of the
Blockchain Administrator The services of the Blockchain Administrator to the Fund are not to be
deemed to be exclusive, and the Blockchain Administrator and its affiliates are free to render
services to others. It is understood that trustees, officers, employees and stockholders of the Fund
are or may become interested in the Blockchain Administrator and its affiliates, as directors,
officers, members, managers, employees, partners, stockholders or otherwise, and that the Blockchain
Administrator and directors, officers, members, managers, employees, partners and stockholders of
the Blockchain Administrator and its affiliates are or may become similarly interested in the Fund
as stockholders or otherwise. 7. Duration and Termination of this Agreement (a) This Agreement shall
become effective as of the first date above written. This Agreement may be terminated at any time,
without the payment of any penalty, upon 60 days' written notice, by the vote of a majority of the
outstanding voting securities of the Fund or by the vote of the Fund's Trustees or by the Blockchain
Administrator. The provisions of Section 5 of this Agreement shall remain in full force and effect,
and the Blockchain Administrator shall remain entitled to the benefits thereof, notwithstanding any
termination of this Agreement. Further, notwithstanding the termination or expiration of this
Agreement as aforesaid, the Blockchain Administrator shall be entitled to any amounts owed under
Section 4 through the date of termination or expiration, and Section 5 shall continue in force and
effect and apply to the Blockchain Administrator and its representatives as and to the extent
applicable.

3

Source: ARCA U.S. TREASURY FUND, N-2, 2/7/2020
<!-- page 4 -->
(b) This Agreement shall continue in effect for two years from the date hereof, and thereafter shall
continue automatically for successive annual periods, provided that such continuance is specifically
approved at least annually by (A) the vote of the Board, or by the vote of a majority of the
outstanding voting securities of the Fund and (B) the vote of a majority of the Fund's directors who
are not parties to this Agreement or "interested persons" (as such term is defined in Section
2(a)(19) of the Investment Fund Act) of any such party, in accordance with the requirements of the
Investment Fund Act. (c) This Agreement will automatically terminate in the event of its
"assignment" (as such term is defined for purposes of Section 15(a) (4) of the Investment Fund Act).
8. Notices Any notice under this Agreement shall be given in writing, addressed and delivered or
mailed, postage prepaid, to the other party at its principal office. 9. Amendments This Agreement
may be amended pursuant to a written instrument by mutual consent of the parties. 10. Entire
Agreement; Governing Law This Agreement contains the entire agreement of the parties and supersedes
all prior agreements, understandings and arrangements with respect to the subject matter hereof.
This Agreement shall be construed in accordance with the laws of the State of New York applicable to
contracts formed and to be performed entirely within the State of New York, without regard to
conflict of laws principles, and in accordance with the applicable provisions of the Investment Fund
Act. In such case, to the extent the applicable laws of the State of New York, or any of the
provisions herein, conflict with the provisions of the Investment Fund Act, the latter shall
control. [Remainder of Page Intentionally Left Blank]

4

Source: ARCA U.S. TREASURY FUND, N-2, 2/7/2020
<!-- page 5 -->
IN WITNESS WHEREOF, the parties hereto have executed and delivered this Agreement as of the date
first above written. ARCA U.S. TREASURY FUND By: Name: Philip Liu Title: President ARCA CAPITAL
MANAGEMENT, LLC By: Name: J. Rayne Steinberg Title: Chief Executive Officer 5

Source: ARCA U.S. TREASURY FUND, N-2, 2/7/2020
