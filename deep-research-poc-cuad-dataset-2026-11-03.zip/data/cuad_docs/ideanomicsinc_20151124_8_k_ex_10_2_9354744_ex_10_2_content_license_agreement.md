<!-- page 1 -->
# FORM OF CONTENT LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| SEC Filing Date | 2015-11-24 |
| Parties | Beijing Sun Seven Stars Culture Development Limited ("Licensor"); YOU ON DEMAND HOLDINGS, INC ("Licensee") |
| Source | CUAD v1 / IdeanomicsInc_20151124_8-K_EX-10.2_9354744_EX-10.2_Content License Agreement |

Exhibit 10.2 FORM OF CONTENT LICENSE AGREEMENT THIS CONTENT LICENSE AGREEMENT (this "Agreement"),
dated as of ___________, 2015 (the "Effective Date"), is entered into between Beijing Sun Seven
Stars Culture Development Limited, a P.R.C. company with an address at Eastern Fangzheng Road,
Southern Dongying Village, Hancunhe Town, Fangshan District, Beijing City, P.R.C. ("Licensor"), and
YOU ON DEMAND HOLDINGS, INC., a Nevada corporation with an address at 375 Greenwich Street, Suite
516, New York, New York 10013 ("Licensee"). WHEREAS, Licensor and Licensee have agreed to enter into
this Agreement, pursuant to which Licensor shall license to Licensee certain video programming on
the terms and subject to the conditions contained in this Agreement. NOW, THEREFORE, in
consideration of the foregoing, the mutual promises and covenants herein contained and other good
and valuable consideration, the receipt and sufficiency of which are hereby acknowledged, and
incorporating the above recitals with and into this Agreement, the parties hereby agree as follows:
TERMS AND CONDITIONS 1. Definitions. (a) "Additional Title" shall have the meaning specified in
Section 5. (b) "Advertising" shall have the meaning specified in Section 9. (c) "Affiliate(s)" shall
mean an entity controlling, controlled by or under common control with a party. "Control," for
purposes of this definition, means direct or indirect ownership or control of more than 50% of the
voting interests of the subject entity. (d) "Confidential Information" shall have the meaning
specified in Section 14(a). (e) "Indemnified Party" shall have the meaning specified in Section 13.
(f) "Indemnifying Party" shall have the meaning specified in Section 13. (g) "Licensor Marks" shall
have the meaning specified in Section 11. (h) "Materials" shall have the meaning specified in
Section 4(b). (i) "Mobile Sites" shall mean any and all versions of the Licensee Sites optimized for
delivery and/or distribution via a wireless network. (j) "Reports" shall have the meaning specified
in Section 8(b).

1

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 2 -->
(k) "Share Consideration" has the meaning specified in Section 10. (l) "Sites" shall mean any and
all websites, applications, products and other services through which Licensee (itself or through a
third party) delivers content via the public Internet or an IP-based network, regardless of whether
the device used to access such websites, applications, products or other services is a laptop or
desktop computer, mobile device, tablet, mobile phone, set-top box, or other device. (m) "Term"
shall have the meaning specified in Section 7. (n) "Territory" shall mean mainland China. (o)
"Titles" shall mean the programming listed on Schedule A (as Schedule A may be amended in accordance
with Section 5 from time to time). (p) "Users" shall mean all subscribers to Licensee's services.
(q) "VOD" shall mean a system that allows for the exhibition of video programming chosen by a
subscriber for display on that subscriber's video display unit on an on-demand basis, such that a
subscriber is able, at his or her discretion, to select the time for commencement of exhibition, and
shall include subscription VOD ("SVOD"), transactional VOD ("TVOD"), ad-supported VOD ("AVOD") and
free VOD. 2. Rights Granted. (a) License Grant. In exchange for the Share Consideration, Licensor
hereby grants to Licensee a non-exclusive, royalty-free, perpetual and non-perpetual license
(subject to the duration for which Licensor has the rights to each Title as specified in Schedule
A1-A5 of Schedule A) to: i. license, exhibit, distribute, reproduce, transmit, perform, display, and
otherwise exploit and make available each Title within the Territory in any language by VOD
(including SVOD, TVOD, AVOD and free VOD) for Internet, TV and mobile platforms (including, but not
limited to, OTT streaming services, Sites and Mobile Sites), except that for Titles listed in
Schedule A1-A2 of Schedule A, Licensor can only grant Licensee distribution rights to up to six (6)
MSOs plus two (2) of China's Internet TV license holders or their OTT Internet- based video partners
by VOD (including SVOD, TVOD, AVOD and free VOD). China's current Internet TV license holders
include: CNTV (中国网络电视台/未来电视), BesTV (百视通), Wasu (华数), Southern Media Cooperation (南方传媒), Hunan TV
(芒果TV), China National Radio/Galaxy Internet TV (GITV) (银河电视), and China Radio International
(中国国际广播电台).

2

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 3 -->
ii. copy and dub the Titles, and authorize any person to do the foregoing. Licensee shall also have
the right to make (or have made on its behalf) translations of the Titles. iii. promote each Title
in any manner or media, including, without limitation, the right to use and license others to use
Licensor's name, the title of, trailers created for and excerpts from such Title (including but not
limited to audio portions only), Materials and the name, voice and likeness of and any biographical
material concerning all persons appearing in or connected with such Title for the purpose of
advertising, promoting and/or publicizing such Title, Licensee and the program service on which the
Title is exhibited; iv. use the Titles for (i) audience and marketing testing, (ii)
sponsor/advertiser screening, and (iii) reference and file purposes; and v. include Licensee's name,
trademark and logo in the Titles to identify Licensee as the exhibitor of the Titles. (b)
Sublicensing. Licensee shall have the right to assign or sublicense any or all of its rights granted
under this Agreement, in whole or in part, to third parties exhibiting the Titles in the ordinary
course of Licensee's business with prior written notice to Licensor. Except as otherwise specified
in the previous sentence, Licensee may not sublicense any of its rights under Section 2(a) without
Licensor's prior written consent, which shall not be unreasonably withheld or delayed. (c) Display
of Titles. Licensee agrees to display the Titles without material alteration to the content thereof.
Licensee may modify or edit the format of the Titles for technical purposes. Nothing in this
Agreement prevents Licensee from providing Users with the ability to use the Titles as permitted by
law or in a manner for which a license is not required. (d) Removal of Titles. If Licensee receives
written notice from Licensor that Licensor no longer has the rights to provide a Title to Licensee,
Licensee shall use commercially reasonable efforts to remove such Title from Licensee's services.
Nothing in this Agreement shall obligate Licensee to distribute, exhibit or otherwise use any Title.
In addition, should Licensee deem any aspect of any Title as either inappropriate or otherwise
objectionable or undesirable (whether for editorial, legal, business or other reasons), Licensee
reserves the right, but does not assume the obligation, to discontinue distribution of such Title,
without liability and without limiting any rights or remedies to which Licensee may be entitled,
whether under this Agreement, at law, or in equity. (e) Profit Participation. For content listed in
Schedule A6 of Schedule A, Licensor will only grant Licensee certain profit participation rights,
for certain durations, as detailed and set forth in Schedule A6 of Schedule A. Licensee will not
have distribution rights or any other rights to the content in Schedule A6 of Schedule A under
Section 2(a)-(d). If for any reason the A6 projects do not get produced, SSS will

3

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 4 -->
substitute comparable projects, to be mutually approved." [PRIOR TO EXECUTION OF THIS AGREEMENT, THE
PARTIES WILL AGREE UPON APPROPRIATE LANGUAGE AND PROVISONS FOR THE PAYMENT OF PROFIT INTEREST, AUDIT
RIGHTSS AND DISPUTE PROVISIONS.] 3. Licenses and Clearances. Licensor shall be solely responsible
for the Titles and any and all legal liability resulting from the Titles, excluding any legal
liability caused by Licensee's breach of this Agreement or gross negligence with regards to the
Titles. Without limiting the generality of the foregoing, Licensor shall be solely responsible for
any and all royalties and other fees payable to any applicable licensor(s) or any third party for
distribution of the Titles by Licensee (including, without limitation, residuals and clearances or
other payments to guilds or unions and rights for music clearances, such as performance rights,
synchronization rights and mechanical rights), and all other fees, payments and obligations arising
out of the activities contemplated by this Agreement, and Licensee shall have no responsibility or
liability for any such royalties or fees. Licensor acknowledges that Licensee cannot and does not
undertake to review, and shall not be responsible for Users' unauthorized use or exploitation of,
the Titles. Should Licensee become aware of Users' unauthorized use or exploitation of the Titles,
Licensee shall immediately report such use to Licensor. 4. Delivery Requirements; Customer Service.
(a) Within fifteen (15) days after the Effective Date or on December 31, 2015 (whichever is
earlier), Licensor shall (at Licensor's sole expense), make the Titles available either online or by
hard drive to Licensee or the third-party vendor specified by Licensee to provide or deliver the
Titles from Licensee's or its third-party vendor's facilities. Delivery of the Titles shall be
deemed complete if Licensor makes the Titles available in accordance with the previous sentence. If,
from time to time, Licensee requests an alternate delivery method for the Titles and/or the
implementation of Licensee's technical specifications relating to the online delivery of the Titles,
then Licensor will use commercially reasonable efforts to comply with each such request. (b) When
Licensor delivers each Title to Licensee, Licensor shall provide Licensee (at the place specified by
Licensee) with all available promotional materials for such Title, including, but not limited to,
captioned photographs, brochures, a synopsis and description of such Title, a complete list of cast
and credits, biographies of key performers, and any electronic press kits, trailers or featurettes
created for such Title (collectively, the "Materials"). (c) In the event of technical problems with
any of the Titles, each party shall use commercially reasonable efforts to notify the other and to
remedy any such problems in a timely manner.

4

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 5 -->
(d) Licensor will provide Licensee with reasonable assistance in responding to User inquiries
regarding the Titles. 5. Additional Titles. If, during the Term, Licensor develops or obtains the
rights to license any live action or animated feature-length motion picture (each an "Additional
Title"), Licensor shall give Licensee the first right of negotiation for each Additional Title
(i.e., the preferred vendor). Licensor will promptly provide written notice to Licensee in which
Licensor lists each Additional Title. Should Licensee agree to be the vendor for an Additional
Title, Licensor and Licensee will negotiate in good faith to mutually agree upon the pricing and
terms for each Additional Title in an amendment to this Agreement. Licensor will deliver each
Additional Title in accordance with Section 4(a). Unless otherwise expressly stated in such an
amendment, each Additional Title listed in such an amendment will be deemed a "Title" and Schedule A
will be deemed amended to include such Additional Title. 6. Expansion of Licensee's VOD Services.
Licensor will use its partners and media channels to expand distribution of Licensee's VOD services
to more cable MSOs and all other platforms for which Licensee is permitted to distribute the Titles
under Section 2(a)(i). 7. Term and Termination. (a) The Term of this Agreement (the "Term") shall
commence on the Effective Date listed above and continue for twenty (20) years, unless sooner
terminated as provided in Section 7(b). (b) This Agreement may be terminated at any time by either
party, effective immediately upon written notice, if the other party: (i) becomes insolvent; (ii)
files a petition in bankruptcy; or (iii) makes an assignment for the benefit of its creditors.
Either party may terminate this Agreement upon written notice if the other party materially breaches
this Agreement and fails to cure such breach within thirty (30) days after the date that it receives
written notice of such breach from the non-breaching party. (c) Sections 2(a), 2(b), 2(c), 2(d), 3,
and 11 shall survive the expiration or termination of this Agreement: (i) in perpetuity with respect
to Titles for which the licenses granted in Section 2(a) are perpetual; and (ii) for the duration of
the applicable license term specified in Schedule A with respect to Titles for which the license
term specified in Schedule A extends beyond the expiration or termination of this Agreement.
Sections 1, 7, 8(a), 12, 13, 14, 15, 16 and 17 shall survive any expiration or termination of this
Agreement in perpetuity.

5

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 6 -->
8. Privacy and Data Collection; Reports. (a) All User information (including, without limitation,
any personally identifiable information and statistical information regarding Users' use and viewing
of the Titles) generated, collected or created in connection with the display of the Titles through
Licensee's services shall be considered Confidential Information of Licensee, and all right, title
and interest in and to such information shall be owned by Licensee. (b) Licensee will provide
Licensor with reports ("Reports") containing statistical information collected by Licensee on (i)
Users' use of the Titles, (ii) distribution channels used by Licensee for the distribution of the
Titles, (iii) sub-licensees to which the Titles were sub-distributed by Licensee and (if permitted
under Licensee's agreements with the sublicensees) any relevant reports received by Licensee from
those sublicensees, and (iv) any other information that the Licensor may request Licensee to gather
from time to time, subject to mutual approval. The Reports will be delivered in a format that is
mutually agreed upon by the parties. The Reports and all information contained in the Reports shall
be considered Confidential Information of Licensee, and all right, title and interest in and to such
Reports and information shall be owned by Licensee. 9. Advertising. The parties acknowledge and
agree that Licensee's services may contain advertising, promotions and/or sponsorship material
(collectively, "Advertising"). Such Advertising shall be determined by Licensee in its sole
discretion and Licensee shall be entitled to retain all revenues resulting from the sale of
Advertising. 10. Consideration. No royalty or fees of any kind shall be owed by Licensee under this
Agreement. The consideration for the licenses granted by Licensor to Licensee under this Agreement
is the issuance of the IP Common Shares as defined in the Securities Purchase Agreement, dated as of
November 23, 2015, by and among the Licensee and the Licensor (the "Share Consideration"). 11. Use
of Licensor Marks. Licensor hereby grants Licensee a non-exclusive license to use the logos,
trademarks and service marks used by Licensor to identify the Titles (collectively, "Licensor
Marks") in connection with the use of the Titles as set forth in this Agreement. Licensee
acknowledges and agrees that Licensee's use of the Licensor Marks shall inure to the benefit of
Licensor. Should Licensor find objectionable any use of the Licensor Marks by Licensee, Licensor
shall have the right to revoke, with respect to the objectionable use, the rights granted to
Licensee under this Agreement to use the Licensor Marks, and Licensee shall promptly cease using the
Licensor Marks in the manner found objectionable by Licensor.

6

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 7 -->
12. Representations and Warranties. (a) Licensor represents and warrants that: i. The execution,
delivery and performance of this Agreement have been duly authorized by all necessary corporate
action on the part of Licensor and this Agreement constitutes a valid and legally binding agreement
of Licensor enforceable against Licensor in accordance with its terms; ii. It will not take or
authorize any action, or fail to take any action, by which any of the rights in any Title granted
herein may be impaired in any way; iii. It has all rights and authority necessary to fully perform
its obligations and grant the rights granted under this Agreement and all rights in and to the
Titles and in and to all literary, artistic, dramatic, intellectual property and musical material
included therein required for the exercise of rights granted in this Agreement without liability of
any kind to any third party; provided however, that this representation and warranty shall not apply
to non-dramatic performing rights in music to the extent that they are controlled by SESAC, ASCAP or
BMI or to the extent that such music is in the public domain; iv. Each Title is and will be
protected during the Term by copyright throughout the Territory; v. There are no taxes, charges,
fees, royalties or other amounts owed to any party other than as set forth in this Agreement for the
exercise of rights granted in this Agreement and Licensor has paid or will pay all charges, taxes,
license fees and other amounts that have been or may become owed in connection with the Titles or
the exercise of any rights granted under this Agreement; vi. Licensor shall make all payments which
may become due to any union or guild and to any third parties who rendered services in connection
with the production of the Titles by virtue of the use made of the Titles hereunder; vii. No claim
or litigation is pending or threatened and no lien, charge, restriction or encumbrance is in
existence with respect to any Title that would adversely affect or impair any of the rights granted
under this Agreement; viii. The Titles, Materials and Licensor Marks will not violate or infringe
any common law or statutory right of any person or other entity including, without limitation, any
contractual rights, proprietary rights, trademark, service mark, copyright or patent rights, or any
rights of privacy or publicity; ix. The Titles, Materials and the Licensor Marks will not be
unlawful, slanderous or libelous; and x. To the extent that any Title makes any claims or renders
any instruction or advice, such claim, instruction or advice shall comply with all federal, state
and

7

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 8 -->
other applicable laws and regulations and shall cause no harm to any person or entity following or
acting in accordance with such instruction or advice. (b) Licensee represents and warrants that: i.
The execution, delivery and performance of this Agreement have been duly authorized by all necessary
corporate action on the part of Licensee and this Agreement constitutes a valid and legally binding
agreement of Licensee enforceable against Licensee in accordance with its terms; ii. It will use the
Titles solely as permitted under this Agreement; iii. It has the full right, capacity and authority
to enter into this Agreement and to perform all of its obligations hereunder; and iv. As of the
Effective Date, there is no claim, action, suit, investigation or proceeding relating to or
affecting Licensee pending or threatened, in law or in equity, or any other circumstance which might
adversely affect Licensee's ability to perform all of its obligations hereunder. 13.
Indemnification. Each party shall defend, indemnify and hold the other party and its Affiliates, and
their respective directors, officers, employees, agents, successors, assigns, licensees and
distributors harmless from and against any and all judgments, settlements, damages, penalties, costs
and expenses (including, but not limited to, reasonable attorneys' fees) arising out of any third
party claims relating to the Indemnifying Party's breach or alleged breach of any of its
representations, warranties, covenants or obligations hereunder. The party seeking indemnification
(the "Indemnified Party") will give prompt notice to the indemnifying party (the "Indemnifying
Party") of any claim for which the Indemnified Party seeks indemnification under this Agreement;
provided, however, that failure to give prompt notice will not relieve the Indemnifying Party of any
liability hereunder (except to the extent the Indemnifying Party has suffered actual material
prejudice by such failure). The Indemnified Party will reasonably cooperate (at the Indemnifying
Party's expense) in the defense of any claim for which the Indemnified Party seeks indemnification
under this Section 13. The Indemnified Party shall have the right to employ separate counsel and to
participate in (but not control) any such action, but the fees and expenses of such counsel will be
at the expense of the Indemnified Party unless: (i) the employment of counsel by the Indemnified
Party has been authorized by the Indemnifying Party; (ii) the Indemnified Party has been advised by
its counsel in writing that there is a conflict of interest between the Indemnifying Party and the
Indemnified Party in the conduct of the defense of the action (in which case the Indemnifying Party
will not have the right to direct the defense of the action on behalf of the Indemnified Party); or
(iii) the Indemnifying Party has not in fact employed counsel to assume the defense of the action
within a reasonable time following receipt of the notice given pursuant to this Section 13, in each
of which cases the fees and expenses of such counsel will be at the expense of the Indemnifying
Party. The Indemnifying Party

8

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 9 -->
will not be liable for any settlement of an action effected without its written consent (which
consent will not be unreasonably withheld or delayed), nor will the Indemnifying Party settle any
such action without the written consent of the Indemnified Party (which consent will not be
unreasonably withheld or delayed). The Indemnifying Party will not consent to the entry of any
judgment or enter into any settlement that does not include as an unconditional term thereof the
giving by the claimant or plaintiff to the Indemnified Party a release from all liability with
respect to the claim. 14. Confidentiality. (a) Confidential Information. "Confidential Information"
means all non-public information about the disclosing party's business or activities that is marked
or designated by such party as "confidential" or "proprietary" at the time of disclosure or that
reasonably would be understood to be confidential given the circumstances of disclosure.
Notwithstanding the foregoing, Confidential Information does not include information that: (a) is in
or enters the public domain without breach of this Agreement; (b) the receiving party lawfully
receives from a third party without restriction on disclosure and without breach of a nondisclosure
obligation; (c) the receiving party rightfully knew prior to receiving such information from the
disclosing party; or (d) the receiving party develops entirely independently of, and without any
access or reference to or use of, any Confidential Information communicated to the receiving party
by the disclosing party. (b) Restrictions. Each party agrees that, during the Term and for two (2)
years thereafter: (i) it will not disclose to any third party any Confidential Information disclosed
to it by the other party except as expressly permitted in this Agreement; (ii) it will only permit
access to Confidential Information of the disclosing party to those of its employees or authorized
representatives or advisors (including, without limitation, the receiving party's auditors,
accountants, and attorneys) having a need to know and who, prior to obtaining such access, are
legally bound to protect the disclosing party's Confidential Information at least to the same extent
as set forth herein; (iii) it will use any Confidential Information disclosed to it by the other
party only for the purpose of performing its obligations or exercising its rights under this
Agreement and not for any other purpose, whether for such party's own benefit or the benefit of any
third party; (iv) it will maintain the confidentiality of all Confidential Information of the other
party in its possession or control; and (v) that (x) upon the expiration or termination of this
Agreement, or (y) at any time the disclosing party may so request, it will deliver promptly to the
disclosing party, or, at the disclosing party's option, it will destroy, all Confidential
Information of the disclosing party that it may then possess or have under its control.
Notwithstanding the foregoing, each party may disclose Confidential Information of the other party
to the extent required by a court of competent jurisdiction or other governmental authority or
otherwise as required by law, provided that such party will, as soon as reasonably practicable,
provide the disclosing party with written notice of such requirement so that the disclosing

9

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 10 -->
party may seek a protective order or other appropriate remedy. The receiving party and its
representatives will cooperate fully with the disclosing party to obtain any such protective order
or other remedy. If the disclosing party elects not to seek, or is unsuccessful in obtaining, any
such protective order or similar remedy and if the receiving party receives advice from reputable
legal counsel confirming that the disclosure of Confidential Information is required pursuant to
applicable law, then the receiving party may disclose such Confidential Information to the extent
required; provided, however, that the receiving party will use commercially reasonable efforts to
ensure that such Confidential Information is treated confidentially by each party to which it is
disclosed. 15. Disclaimers. EXCEPT AS EXPRESSLY STATED IN SECTION 12, THE PARTIES HEREBY DISCLAIM
ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, CONCERNING THE SUBJECT MATTER OF THIS
AGREEMENT. 16. Limitation of Liability. EXCEPT FOR THE ABOVE INDEMNIFICATION OBLIGATIONS AND FOR
BREACHES OF SECTION 14, NEITHER PARTY SHALL BE LIABLE TO THE OTHER FOR ANY INCIDENTAL,
CONSEQUENTIAL, SPECIAL OR PUNITIVE DAMAGES ARISING OUT OF THIS AGREEMENT (INCLUDING, BUT NOT LIMITED
TO, LOSS OF PROFITS), WHETHER IN AN ACTION OR ARISING OUT OF BREACH OF CONTRACT, TORT OR ANY OTHER
CAUSE OF ACTION EVEN IF SUCH PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 17.
Miscellaneous. (a) Governing Law. This Agreement shall be governed by and construed in all respects
in accordance with the laws of the State of New York, without giving effect to any conflicts of laws
principles. (b) Dispute Resolution. Any dispute, controversy and/or difference which may arise out
of or in connection with or in relation to this Agreement, shall be solely and finally settled by
binding arbitration pursuant to then-current rules of the International Chamber of Commerce. Such
arbitration shall be held in New York, New York. The merits of the dispute shall be resolved in
accordance with the laws of the State of New York, without reference to its choice of law rules. The
tribunal shall consist of three arbitrators, each of whom shall be knowledgeable in the subject
matter hereof. The arbitration shall be conducted in the English language, and all documents shall
be submitted in English or be accompanied by a certified English translation. The arbitrators will
provide a written explanation to the parties of any arbitration award. The award thereof shall be
final and binding upon the parties hereto, and judgment on such award may be entered in any court or
tribunal having jurisdiction, and the parties hereby irrevocably waive any objection to the
jurisdiction of such courts based on any ground,

10

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 11 -->
including without limitation, improper venue or forum non conveniens. The parties and the
arbitration panel shall be bound to maintain the confidentiality of this Agreement, the dispute and
any award, except to the extent necessary to enforce any such award. The prevailing party, if a
party is so designated in the arbitration award, shall be entitled to recover from the other party
its costs and fees, including attorneys' fees, associated with such arbitration. By agreeing to this
binding arbitration provision, the parties understand that they are waiving certain rights and
protections which may otherwise be available if a dispute between the parties were determined by
litigation in court, including, without limitation, the right to seek or obtain certain types of
damages precluded by this arbitration provision, the right to a jury trial, certain rights of
appeal, and a right to invoke formal rules of procedure and evidence. Notwithstanding anything to
the contrary herein, each party shall be entitled, at any time, without first resorting to the
dispute resolution process set forth above, to seek injunctive or other equitable relief from any
court of competent jurisdiction, wherever such party deems appropriate, in order to preserve or
enforce such party's rights hereunder. (c) Non-Exclusivity. Nothing in this Agreement limits or
restricts Licensee from entering into any similar agreements with any third party. (d) Severability.
The invalidity or unenforceability of any provision of this Agreement shall not affect the validity
or enforceability of any other provision of this Agreement. In the event that any provision of this
Agreement is determined to be invalid, unenforceable or otherwise illegal, such provision shall be
deemed restated, in accordance with applicable law, to reflect as nearly as possible the original
intentions of the parties, and the remainder of the Agreement shall remain in full force and effect.
(e) Waiver. No term or condition of this Agreement shall be deemed waived, and no breach shall be
deemed excused, unless such waiver or excuse is in writing and is executed by the party against whom
such waiver or excuse is claimed. (f) Entire Agreement. This Agreement contains the entire agreement
and understanding between the parties with regard to the subject matter hereof, and supersedes all
prior and contemporaneous oral or written agreements and representations with respect to such
subject matter. This Agreement may be modified or amended only in a writing signed by all parties.
(g) Jury Trial Waiver. THE PARTIES SPECIFICALLY WAIVE ANY RIGHT TO TRIAL BY JURY IN ANY COURT WITH
RESPECT TO ANY CONTRACTUAL, TORTIOUS, OR STATUTORY CLAIM, COUNTERCLAIM, OR CROSS-CLAIM AGAINST THE
OTHER ARISING OUT OF OR CONNECTED IN ANY WAY TO THIS AGREEMENT, BECAUSE THE PARTIES HERETO, BOTH OF
WHOM ARE REPRESENTED BY COUNSEL, BELIEVE THAT THE COMPLEX COMMERCIAL AND PROFESSIONAL ASPECTS OF
THEIR DEALINGS WITH ONE ANOTHER MAKE A JURY DETERMINATION NEITHER DESIRABLE NOR APPROPRIATE.

11

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 12 -->
(h) Assignment. Neither party may assign its rights, duties or obligations under this Agreement to
any third party in whole or in part, without the other party's prior written consent, except that
(i) Licensee may assign its rights and obligations to this Agreement to any of its Affiliate or
subsidiaries with the prior written consent of the Licensor, and (ii) Licensor may assign its rights
and obligations in this Agreement to its Affiliates or subsidiaries and either party may assign this
Agreement in its entirety to any purchaser of all or substantially all of its business or assets
pertaining to the line of business to which this Agreement relates or to any Affiliate of the party
without the other party's approval. This Agreement will be binding upon, and inure to the benefit
of, the respective permitted assignees, transferees and successors of each of the parties. (i) No
Third Party Beneficiaries. The parties acknowledge and agree that there are no third party
beneficiaries to this Agreement. (j) Interpretation. In interpreting the terms and conditions of
this Agreement, no presumption shall be interpreted for or against a party as a result of the role
of such party in the drafting of this Agreement. Sections headings are for convenience only and
shall not be used to interpret this Agreement. (k) Notice. Any notice required or permitted by this
Agreement shall be in writing and shall be delivered as follows, with notice deemed given upon
receipt or refusal: (i) by overnight courier service; (ii) hand delivery; or (iii) by certified or
registered mail, return receipt requested. Notice shall be sent to the addresses set forth below or
to such other address as either party may specify in a notice given under this Section 17(k). If to
Licensee: You On Demand Holdings, Inc. 375 Greenwich Street, Suite 516 New York, New York 10013
Attn: Mr. Xuesong Song With a copy (which shall not constitute notice or such other communication)
to each of: Cooley LLP The Grace Building 1114 Avenue of the Americas New York, New York 10036-7798
Attn: William Haddad and Cooley LLP 101 California Street, 5th Floor San Francisco, California
94111-5800 Attn: Garth Osterman

12

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 13 -->
If to Licensor: Beijing Sun Seven Stars Culture Development Limited Eastern Fangzheng Road Southern
Dongying Village Hancunhe Town Fangshan District Beijing City, P.R.C. Attn: Zhang Jie With a copy
(which shall not constitute notice or such other communication) to: Shanghai Sun Seven Stars
Cultural Development Limited 686 WuZhong Road, Tower D, 9th Floor Shanghai, China 201103 Attn: Polly
Wang (l) Press Releases. Unless required by law, neither party will, without the prior written
approval of the other party, issue any press release or similar announcement relating to the
existence or terms of this Agreement. (m) Counterparts. This Agreement may be executed in
counterparts, all of which when taken together shall be deemed to constitute one and the same
instrument. [Signature Page Follows]

13

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 14 -->
IN WITNESS WHEREOF and intending to be legally bound hereby, the parties have executed this Content
License Agreement as of the date first set forth above. LICENSOR: BEIJING SUN SEVEN STARS CULTURE
DEVELOPMENT LIMITED By: Name: Bruno Wu Title: Chairman & CEO LICENSEE: YOU ON DEMAND HOLDINGS, INC.
By: Name: Title: [SIGNATURE PAGE TO CONTENT LICENSE AGREEMENT]

Source: IDEANOMICS, INC., 8-K, 11/24/2015
<!-- page 15 -->
SCHEDULE A TITLES

Source: IDEANOMICS, INC., 8-K, 11/24/2015
