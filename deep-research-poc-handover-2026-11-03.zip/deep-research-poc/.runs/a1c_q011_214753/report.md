# What maximum Leverage Ratio applies to Halvorsen Marine Holdings as of 2025-05-01

*Question:* What maximum Leverage Ratio applies to Halvorsen Marine Holdings as of 2025-05-01?

## Identify Halvorsen Marine Holdings

[GAP] No evidence was found for: Establish that Halvorsen Marine Holdings is the entity referenced in the documents and confirm its legal identity as of 2025-05-01.

## Locate Leverage Ratio covenant

Section 7.1 of the Original Credit Agreement dated 2025-02-14 sets the maximum Leverage Ratio at 4.00 to 1.00. [8b969cb203b8817e p.9] The Borrower shall not permit the Leverage Ratio as of the last day of any fiscal quarter to exceed 4.00 to 1.00. [8b969cb203b8817e p.9] The Side Letter addresses Permitted Vessel Dispositions and does not address the Leverage Ratio. [6e41e32c63bc8a4b p.2]

## Determine applicable date

The Leverage Ratio covenant is in effect on 2025-05-01. [5734789b958179bc p.2] The First Amendment changes the Leverage Ratio from 4.00 to 1.00 to 4.50 to 1.00, effective 2025-07-31. [5734789b958179bc p.2] Because 2025-07-31 is after 2025-05-01, the 4.00 to 1.00 limit applies on 2025-05-01. [5734789b958179bc p.2]

## Extract maximum Leverage Ratio

[GAP] No evidence was found for: Establish the exact numerical maximum Leverage Ratio limit stated for Halvorsen Marine Holdings as of 2025-05-01.

## Verification appendix

Claims: 8 · supported: 6 · partially: 0 · dropped: 0 · gaps: 2 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  |  |
| s2.1 | s2 | keep | 1.00 | e1→[8b969cb203b8817e p.9] |  |
| s2.2 | s2 | keep | 1.00 | e1→[8b969cb203b8817e p.9] |  |
| s2.3 | s2 | keep | 1.00 | e3→[6e41e32c63bc8a4b p.2] |  |
| s3.1 | s3 | keep | 1.00 | e2→[5734789b958179bc p.2] |  |
| s3.2 | s3 | keep | 1.00 | e2→[5734789b958179bc p.2] |  |
| s3.3 | s3 | keep | 1.00 | e2→[5734789b958179bc p.2] |  |
| s4.1 | s4 | gap |  |  |  |

### Evidence

- e1 [8b969cb203b8817e p.9 L74-76] keep (1.0): "Section 7.1 Maximum Leverage Ratio. The Borrower shall not permit the Leverage Ratio as of the last day of any fiscal quarter to exceed 4.00 to 1.00."
- e2 [5734789b958179bc p.2 L19-21] keep (1.0): "Effective as of the First Amendment Effective Date, the Credit Agreement is amended as follows:
1.1 Section 7.1 is amended by replacing "4.00 to 1.00" with "4.50 to 1.00", so that the Borrower shall not permit the Leverage Ratio as of the l…"
- e3 [6e41e32c63bc8a4b p.2 L18-20] keep (1.0): "## 1. Permitted Vessel Dispositions
Notwithstanding Section 7.6 of the Credit Agreement, the Borrower may dispose of vessels in the ordinary course of fleet renewal for aggregate consideration of up to $20,000,000 per fiscal year without th…"
