<!-- page 1 -->
# Wireless Content License Agreement Number 12965
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2006-03-27 |
| Parties | Fox Mobile Entertainment, Inc. ("Fox"); Glu Mobile, Inc. f/k/a Sorrent, Inc. ("Licensee") |
| Source | CUAD v1 / GluMobileInc_20070319_S-1A_EX-10.09_436630_EX-10.09_Content License Agreement3 |

AMENDMENT NO. 2

Dated as of March 27, 2006

Reference is hereby made to that certain fully executed Wireless Content License Agreement Number
12965 dated as of December 16, 2004, as amended November 11, 2005, ("Agreement"), between Fox Mobile
Entertainment, Inc. ("Fox"), as Administrator for Twentieth Century Fox Film Corporation ("Trademark
Licensor") and Glu Mobile, Inc. f/k/a Sorrent, Inc. ("Licensee").

The parties agree to modify the Agreement as follows:

A. "ICE AGE 2" a/k/a "ICE AGE: THE MELTDOWN" AUDIO AND VIDEO WIRELESS PRODUCTS:

1. Grant of Rights: Fox grants to Licensee a limited, non-exclusive right and license to distribute
the following Wireless Products in connection with the Property "ICE AGE: THE MELTDOWN" in the
United States: (A) 2 Scrat voicetones; (B) 2 John Leguizamo voicetones; and (C) 3 premium videos.
Fox also grants Licensee a limited, non-exclusive right and license to distribute the following
Wireless Products in connection with the Property "ICE AGE 2" outside of the United States: (A) 4
Scrat voicetones; (B) 1 John Leguizamo voicetone; and (C) 3 premium videos. (collectively, "IA2
Audio and Video Wireless Products")

B. IA 2 AUDIO AND VIDEO WIRELESS PRODUCTS ROYALTY:

1. Royalty: In consideration of the rights granted to Licensee pursuant to this Amendment 2,
Licensee shall pay to Fox, or such other party as Fox may designate in writing, a royalty in the
following amount:

(a) From the first unit sold, Fox shall earn a royalty at the rate of ***** percent (*****%) of
Licensee's Gross Receipts (as defined in the Agreement) from Licensee's sale and distribution of the
IA2 Audio and Video Wireless Products. ("IA2 Audio and Video Royalty"). For the avoidance of doubt,
Licensee may not recoup any portion of the Ice Age 2 Guarantee (as defined in Amendment 1) through
its sale and distribution of the IA2 Audio and Video Wireless Products.

2. VGSL and other CSP Accounting: All VGSL and other CSP payments remitted directly to Fox pursuant
to the VGSL Agreement and other CSP agreements with respect to the IA Audio and Video Wireless
Products shall be treated in the same manner as set forth in Paragraphs 7(b)(ii) and 7(b)(iii) of
the Agreement.

***** The omitted portions of this exhibit have been filed with the Securities and Exchange
Commission pursuant to a request for confidential treatment under Rule 406 promulgated under the
Securities Act of 1933.

Source: GLU MOBILE INC, S-1/A, 3/19/2007
<!-- page 2 -->
3. No Direct-to-Consumer Distribution Royalty: Licensee shall not be entitled to receive a share of
any revenues and shall have no claim to any revenues earned and collected by Fox, or a third-party
Fox designates, for the IA2 Audio and Video Wireless Products which Fox distributes through its and
its assigns' direct-to-consumer distribution channels.

Except as herein expressly amended or by necessary implication modified by this Amendment, the
Agreement in all other respects is hereby ratified and shall continue in full force and effect.

By signing in the places indicated below, the parties hereto accept and agree to all of the terms
and conditions hereof.

Glu Mobile, Inc. f/k/a Sorrent, Inc. ("Licensee") Fox Mobile Entertainment, Inc. ("Fox") By: /s/
PAUL ZUZELO By: /s/ JAMIE SAMSON Jamie Samson Name: Paul Zuzelo Its: Senior Vice President Its: CAO
Date: March 28, 2006 Date: 3/28/06

Source: GLU MOBILE INC, S-1/A, 3/19/2007
