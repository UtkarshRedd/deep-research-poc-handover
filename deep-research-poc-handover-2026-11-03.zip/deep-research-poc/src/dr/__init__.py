"""deep-research-poc: agentic deep research over a pre-filtered document set.

Layout
------
config.py      explicit budgets and caps (nothing else hard-codes a limit)
models.py      pydantic contracts shared by every stage
workspace.py   per-query materialized working set (line-addressable docs + manifest)
evidence.py    EvidenceBank — harness-owned state the writer reads
tools/         framework-agnostic tool functions + adapters (grep, read, outline, manifest, ...)
verify/        tier-1 deterministic alignment (+ tier-2 agentic, later)
agents/        first move, router, researcher, fan-out, writer (LangGraph)
eval/          golden set, metrics, runner
llm.py         the ONLY place that knows endpoint URLs and model ids
trace.py       structured audit events
"""

__all__ = ["config", "models", "workspace", "evidence"]
