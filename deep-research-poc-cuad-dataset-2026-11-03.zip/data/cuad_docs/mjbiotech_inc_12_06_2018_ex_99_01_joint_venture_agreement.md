<!-- page 1 -->
# JOINT VENTURE AGREEMEN
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| Agreement Date | 2018-11-27 |
| Parties | MJ Syndicated, Inc.; SIMPLY HERBAL; individually and collectively "JVP" |
| Source | CUAD v1 / MJBIOTECH,INC_12_06_2018-EX-99.01-JOINT VENTURE AGREEMENT |

Exhibit 99.01 JOINT VENTURE AGREEMENT THIS JOINT VENTURE AGREEMENT (the "Agreement") made and
entered into this 27th day of November 2018 (the "Execution Date"),

BETWEEN: MJ Syndicated, Inc. a Florida Corporation of _______________________________, FL 33436 And

SIMPLY HERBALS, Nervanah Herbal Medicine Company of _______________________________TN 37660

(individually and collectively the Joint Venture Participants "JVP").

BACKGROUND:

The JVP wish to associate themselves in business of Selling a variety of Health- related products.

This Agreement sets out the terms and conditions that govern the Joint Venture.

IN CONSIDERATION OF and as a condition of the JVP entering into this Agreement and other valuable
consideration, the receipt and sufficiency of which consideration is acknowledged, the parties to
this Agreement agree as follows:

Formation

By this Agreement the Participants enter into a general Joint Venture (the "Joint Venture") in
accordance with the laws of The State of Florida. The rights and obligations of the JVP will be as
stated in the applicable legislation of The State of Florida except as otherwise provided in this
Agreement.

Name

A.

B.

1.
<!-- page 2 -->
The firm name of the Joint Venture will be: TBD

Purpose

The purpose of the Joint Venture will be: Manufacturing and Selling Health Related products.

The Joint Venture is a fixed term Joint Venture beginning November 27, 2018 and ending November
30th, 2019 or as otherwise provided in this Agreement. Where the Joint Venture is entered for a
fixed term and the Joint Venture continues after the expiration of that term then in the absence of
an express new agreement, the rights and duties of the Participants remain the same as they were at
the expiration of that term so far as those terms are consistent with a Joint Venture at will.

Place of Business

The principal office of the business of the Joint Venture will be located
at__________________________, FL 33434 or such other place as the Participants may from time to time
designate.

Capital Contributions

Each of the Participants will contribute to the capital of the Joint Venture, in cash or property in
agreed upon value. All Participants will contribute their respective Contributions as agreed.

Withdrawal of Capital

No participant will withdraw any portion of their Contribution without the express written consent
of the other Participant.

Additional Capital

Capital Contributions may be amended from time to time, according to the requirements of the Joint
Venture provided that the interests of the Participants are not affected, except with the unanimous
consent of the Participants. No Participant will be required

2.

3.

4.

5.

6.

7.

8.
<!-- page 3 -->
to make Additional Capital Contributions. Whenever additional capital is determined to be required
and an individual Participant is unwilling or unable to meet the additional contribution requirement
within a reasonable period, as required by Joint Venture business obligations, remaining
Participants may contribute in proportion to their existing Capital Contributions to resolve the
amount in default. In such case the allocation of profits or losses among all the Participants will
be adjusted to reflect the aggregate change in Capital Contributions by the Participants.

Any advance of money to the Joint Venture by any Participant in excess of the amounts provided for
in th is Agreement or subsequently agreed to as Additional Capital Contribution will be deemed a
debt owed by the Joint Venture and not an increase in Capital Contribution of the Participant. This
liability will be repaid with interest at rates and times to be determined by a majority of the
Participants within the limits of what is required or permitted in the Act. This liability will not
entitle the lending Participant to any increased share of the Joint Venture's profits nor to a
greater voting power. Such debts may have preference or priority over any other payments to
Participants as may be determined by a majority of the Participants.

Capital Accounts

An individual capital account (the "Capital Accounts") will be maintained for each Participant and
their Initial Capital Contribution will be credited to this account. Any Additional Capital
Contributions made by any Participant will be credited to that Participant's individual Capital
Account.

Interest on Capital

No borrowing charge or loan interest will be due or payable to any Participant on their agreed
Capital Contribution inclusive of any agreed Additional Capital Contributions.

9.

10.

11.
<!-- page 4 -->
Financial Decisions

Decisions regarding the distribution of profits, allocation of losses, and the requirement for
Additional Capital Contributions as well as all other financial matters will be decided by a
unanimous vote of the Participants.

Profit and Loss

Subject to any other provisions of this Agreement, the net profits and losses of the Joint Venture,
for both accounting and tax purposes, will accrue to and be borne by the Participants in proportion
to the Participants' Capital Contributions inclusive of any Additional Capital Contributions (the
"Profit and Loss Distribution").

Books of Account

Accurate and complete books of account of the transactions of the Joint Venture will be kept in
accordance with generally accepted accounting principles (GAAP) and at all reasonable times will be
available and open to inspection and examination by any Participant. The books and records of the
Joint Venture will reflect all the Joint Venture's transactions and will be appropriate and adequate
for the business conducted by the Joint Venture.

Annual Report

As soon as practicable after the close of each fiscal year, the Joint Venture will furnish to each
Participant an annual report showing a full and complete account of the condition of the Joint
Venture. This report will consist of at least the following documents:

a statement of all information as will be necessary for the preparation of each Participant's income
or other tax returns;

a copy of the Joint Venture's federal income tax returns for that fiscal year;

12.

13.

14.

15.

a.

b.
<!-- page 5 -->
supporting income statement;

a balance sheet;

a cash flow statement;

a breakdown of the profit and loss attributable to each Participant; and

any additional information that the Participants may require.

Banking and Joint Venture Funds

The funds of the Joint Venture will be placed in such investments and banking accounts as will be
designated by the Participants. Joint Venture funds will be held in the name of the Joint Venture
and will not be commingled with those of any other person or entity.

Fiscal Year

The fiscal year will end on the 31st day of December of each year.

Audit

Any of the Participants will have the right to request an audit of the Joint Venture books. The cost
of the audit will be borne by the Joint Venture. The audit will be performed by an accounting firm
acceptable to all the Participants. Not more than one (1) audit will be required by any or all of
the Participants for any fiscal year.

Management

Except as all of the Participants may otherwise agree in writing, all actions and decisions
respecting the management, operation and control of the Joint Venture and its business will be
decided by a majority vote of the Participants.

c.

d.

e.

f.

g.

16.

17.

18.

19.
<!-- page 6 -->
Contract Binding Authority

All actions and decisions with respect to binding the Joint Venture in contract requires the consent
of a majority of the Participants.

Tax Matters Participant

The tax matters Participant will be MJ Syndicated Inc. (the "Tax Matters Participant"). The Tax
Matters Participant will prepare, or cause to be prepared, all tax returns and reports for the Joint
Venture and make any related elections that the Participants deem advisable.

A Tax Matters Participant can voluntarily withdraw from the position of Tax Matters Participant or
can be appointed or replaced by a majority vote of the other Participants. In the event of a
withdrawal of the Tax Matters Participant from the Joint Venture, the remaining Participants will
appoint a successor as soon as practicable.

Meetings

Regular meetings of the Participants will be held quarterly.

Any Participant can call a special meeting to resolve issues that require a vote, as indicated by
this Agreement, by providing all Participants with reasonable notice. In the case of a special vote,
the meeting will be restricted to the specific purpose for which the meeting was held.

All meetings will be held at a time and in a location that is reasonable, convenient and practical
considering the situation of all Participants.

Admitting a New Participant

A new Participant may only be admitted to the Joint Venture with a unanimous vote of the existing
Participants.

20.

21.

22.

23.

24.

25.

26.
<!-- page 7 -->
Any new Participant agrees to be bound by all the covenants, terms, and conditions of this
Agreement, inclusive of all current and future amendments. Further, a new Participant will execute
such documents as are needed to affect the admission of the new Participant. Any new Participant
will receive such business interest in the Joint Venture as determined by a unanimous decision of
the other Participants.

Voluntary Withdrawal of a Participant

Any Participant will have the right to voluntarily withdraw from the Joint Venture at any time.
Written notice of intention to withdraw must be served in writing upon the remaining Participants at
least Thirty (30) business days prior to the withdrawal date.

The voluntary withdrawal of a Participant will result in the dissolution of the Joint Venture.

A Dissociated Participant will only exercise the right to withdraw in good faith and will act to
minimize any present or future harm done to the remaining Participants as a result of the
withdrawal.

Involuntary Withdrawal of a Participant

Events resulting in the involuntary withdrawal of a Participant from the Joint Venture will include,
but not be limited to: death of a Participant; Participant mental incapacity; Participant disability
preventing reasonable participation in the Joint Venture; Participant incompetence; breach of
fiduciary duties by a Participant; criminal conviction of a Participant; Expulsion of a Participant;
Operation of Law against a Participant; or any act or omission of a Participant that can reasonably
be expected to bring the business or societal reputation of the Joint Venture into disrepute.

The involuntary withdrawal of a Participant will result in the dissolution of the Joint Venture.

27.

28.

29.

30.

31.

32.
<!-- page 8 -->
A trustee in bankruptcy or similar third party who may acquire that Dissociated Participant's
interest in the Joint Venture will only acquire that Participant's economic rights and interests and
will not acquire any other rights of that Participant or be admitted as a Participant of the Joint
Venture or have the right to exercise any management or voting interests.

Dissociation of a Participant

Where the dissociation of a Participant for any reason results in the dissolution of the Joint
Venture then the Joint Venture will proceed in a reasonable and timely manner to dissolve the Joint
Venture, with all debts being paid first, prior to any distribution of the remaining funds.
Valuation and distribution will be determined as described in the Valuation of Interest section of
this Agreement.

The remaining Participants retain the right to seek damages from a Dissociated Participant where the
dissociation resulted from a malicious or criminal act by the Dissociated Participant or where the
Dissociated Participant had breached their fiduciary duty to the Joint Venture or was in breach of
this Agreement or had acted in a way that could reasonably be foreseen to bring harm or damage to
the Joint Venture or to the reputation of the Joint Venture.

Dissolution

Except as otherwise provided in this Agreement, the Joint Venture may be dissolved only with the
unanimous consent of all Participants.

Distribution of Property on Dissolution of Joint Venture

In the event of the dissolution of the Joint Venture, each Participant will share in any remaining
assets or liabilities of the Joint Venture in proportion to the Participants' Capital Contributions
inclusive of any Additional Capital Contributions (the "Dissolution Distribution").

33.

34.

35.

36.

37.
<!-- page 9 -->
Upon Dissolution of the Joint Venture and liquidation of Joint Venture Property, and after payment
of all selling costs and expenses, the liquidator will distribute the Joint Venture assets to the
following groups according to the following order of priority:

in satisfaction of liabilities to creditors except Joint Venture obligations to current
Participants;

in satisfaction of Joint Venture debt obligations to current Participants; and then

to the Participants according to the Dissolution Distribution described above.

The claims of each priority group will be satisfied in full before satisfying any claims of a lower
priority group. Any excess of Joint Venture assets after liabilities or any insufficiency in Joint
Venture assets in resolving liabilities under this section will be shared by the Participants
according to the Dissolution Distribution described above.

Valuation of Interest

In the absence of a written agreement setting a value, the value of the Joint Venture will be based
on the fair market value appraisal of all Joint Venture assets (less liabilities) determined in
accordance with generally accepted accounting principles (GAAP). This appraisal will be conducted by
an independent accounting firm agreed to by all Participants. An appraiser will be appointed within
a reasonable period of the date of withdrawal or dissolution. The results of the appraisal will be
binding on all Participants. A withdrawing Part ic ipant 's interest wi l l be based on that
Participant's proportion of the Dissolution Distribution described above, less any outstanding
liabilities the withdrawing Participant may have to the Joint Venture. The intent of this section is
to ensure the survival of the Joint Venture despite the withdrawal of any individual Participant.

38.

a.

b.

c.

39.

40.
<!-- page 10 -->
No allowance will be made for goodwill, trade name, patents or other intangible assets, except where
those assets have been reflected on the Joint Venture books immediately prior to valuation.

Goodwill

The goodwill of the Joint Venture business will be assessed at an amount to be determined by
appraisal using generally accepted accounting principles (GAAP).

Title to Joint Venture Property

Title to all Joint Venture Property will remain in the name of the Joint Venture. No Participant or
group of Participants will have any ownership interest in such Joint Venture Property in whole or in
part.

Voting

Any vote required by the Joint Venture will be assessed where each Participant receives one vote
carrying equal weight.

Force Majeure

A Participant will be free of liability to the Joint Venture where the Participant is prevented from
executing their obligations under this Agreement in whole or in part due to force majeure, such as
earthquake, typhoon, flood, fire, and war or any other unforeseen and uncontrollable event where the
Participant has communicated the circumstance of said event to any and all other Participants and
taken any and all appropriate action to mitigate said event.

Duty of Loyalty

No Participant will engage in any business, venture or transaction, whether directly or indirectly,
that might be competitive with the business of the Joint Venture or that would be in direct conflict
of

41.

42.

43.

44.

45.

46.
<!-- page 11 -->
interest to the Joint Venture without the unanimous written consent of the remaining Participants.
Any and all businesses, ventures or transactions with any appearance of conflict of interest must be
fully disclosed to all other Participants. Failure to comply with any of the terms of this clause
will be deemed an Involuntary Withdrawal of the offending Participant and may be treated accordingly
by the remaining Participants.

Duty of Accountability for Private Profits

Each Participant must account to the Joint Venture for any benefit derived by that Participant
without the consent of the other Participants from any transaction concerning the Joint Venture or
any use by that Participant of the Joint Venture property, name or business connection. This duty
continues to apply to any transactions undertaken after the Joint Venture has been dissolved but
before the affairs of the Joint Venture have been completely wound up by the surviving Participant
or Participants or their agent or agents.

Duty to Devote Time

Each Participant will devote such time and attention to the business of the Joint Venture as the
majority of the Participants will from time to time reasonably determine for the conduct of the
Joint Venture business.

Actions Requiring Unanimous Consent of the Participants

The following list of actions will require the unanimous consent of all Participants:

committing the Joint Venture to new liabilities or obligations totaling To Be Determined;

and

incurring single expenditures that exceed "To Be Determined".

47.

48.

49.

a.

b.
<!-- page 12 -->
Any losses incurred as a result of a violation of this section will be charged to and collected from
the individual Participant that acted without unanimous consent and caused the loss.

Forbidden Acts

No Participant may do any act in contravention of this Agreement.

No Participant may permit, intentionally or unintentionally, the assignment of express, implied or
apparent authority to a third party that is not a Participant in the Joint Venture.

No Participant may do any act that would make it impossible to carry on the ordinary business of the
Joint Venture.

No Participant may confess a judgment against the Joint Venture.

No Participant will have the right or authority to bind or obligate the Joint Venture to any extent
with regard to any matter outside the intended purpose of the Joint Venture.

Any violation of the above Forbidden Acts will be deemed an Involuntary Withdrawal of the offending
Participant and may be treated accordingly by the remaining Participants.

Indemnification

All Participants will be indemnified and held harmless by the Joint Venture from and against any and
all claims of any nature, whatsoever, arising out of a Participant's participation in Joint Venture
affairs. A Participant will not be entitled to indemnification under this section for liability
arising out of gross negligence or wil l ful misconduct of the Participant or the breach by the
Participant of any provisions of this Agreement.

Liability

50.

51.

52.

53.

54.

55.

56.

57.
<!-- page 13 -->
A Participant will not be liable to the Joint Venture, or to any other Participant, for any mistake
or error in judgment or for any act or omission done in good faith and believed to be within the
scope of authority conferred or implied by this Agreement or the Joint Venture.

Liability Insurance

The Joint Venture may acquire insurance on behalf of any Participant, employee, agent or other
person engaged in the business interest of the Joint Venture against any liability asserted against
them or incurred by them while acting in good faith on behalf of the Joint Venture.

Amendments

This Agreement may not be amended in whole or in part without the unanimous written consent of all
Participants.

Jurisdiction

The Participants submit to the jurisdiction of the courts of The State of Florida for the
enforcement of this Agreement or any arbitration award or decision arising from this Agreement.

Definitions

For the purpose of this Agreement, the following terms are defined as follows:

"Additional Capital Contributions" means Capital Contributions, other than Initial Capital
Contributions, made by Participants to the Joint Venture.

"Capital Contribution" means the total amount of cash or Property contributed to the Joint Venture
by any one Participant.

58.

59.

60.

61.

a.

b.
<!-- page 14 -->
"Dissociated Participant" means any Participant who is removed from the Joint Venture through a
voluntary or involuntary withdrawal as provided in this Agreement.

"Expulsion of a Participant" can occur on application by the Joint Venture or another Participant,
where it has been determined that the Participant:

has engaged in wrongful conduct that adversely and materially affected the Joint Venture's business;

has willfully or persistently committed a material breach of this Agreement or of a duty owed to the
Joint Venture or to the other Participants; or

has engaged in conduct relating to the Joint Venture's business that makes it not reasonably
practicable to carry on the business with the Participant.

"Initial Capital Contribution" means Capital Contributions made by any Participant to acquire an
interest in the Joint Venture.

"Operation of Law" means rights or duties that are cast upon a party by the law, without any act or
agreement on the part of the individual including, but not limited to, an assignment for the benefit
of creditors, a divorce, or a bankruptcy.

Miscellaneous

Time is of the essence in this Agreement.

This Agreement may be executed in counterpart.

Headings are inserted for the convenience of the parties only and are not to be considered when
interpreting this Agreement. Words in the singular mean and include the plural and vice versa. Words
in the

c.

d.

i.

ii.

iii.

e.

f.

62.

63.

64.
<!-- page 15 -->
masculine gender include the feminine gender and vice versa. Words in the neuter gender include the
masculine gender and the feminine gender and vice versa.

If any term, covenant, condition or provision of this Agreement is held by a court of competent
jurisdiction to be invalid, void or unenforceable, it is the parties' intent that such provision be
reduced in scope by the court only to the extent deemed necessary by that court to render the
provision reasonable and enforceable and the remainder of the provisions of this Agreement will in
no way be affected, impaired or invalidated as a result.

This Agreement contains the entire agreement between the parties. All negotiations and
understandings have been included in this Agreement. Statements or representations which may have
been made by any party to this Agreement in the negotiation stages of this Agreement may in some way
be inconsistent with this final written Agreement. All such statements are declared to be of no
value in this Agreement. Only the written terms of this Agreement will bind the parties.

This Agreement and the terms and conditions contained in this Agreement apply to and are binding
upon the Participant's successors, assigns, executors, administrators, beneficiaries, and
representatives.

Any notices or delivery required here will be deemed completed when hand-delivered, delivered by
agent, or seven (7) days after being placed in the post, postage prepaid, to the parties at the
addresses contained in this Agreement or as the parties may later designate in writing.

All of the rights, remedies and benefits provided by this Agreement will be cumulative and will not
be exclusive of any other such rights, remedies and benefits allowed by law.

IN WITNESS WHEREOF the Participants have duly affixed their signatures under hand on this 27th day
of November 2018.

65.

66.

67.

68.

69.
<!-- page 16 -->
Simply Herbals

Per: ____________________

CEO: MJ Syndicated, Inc CEO: Simply Herbals, Inc.

MJ Syndicated, Inc.

Per: __/s/ Maxine Pierson________
