# Which jurisdiction's law governs the Cooperation Agreement between e.l.f. Beauty, Inc. ...

*Question:* Which jurisdiction's law governs the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01)?

## Identify the governing law clause

The Cooperation Agreement between e.l.f. [uncited] Beauty, Inc. and Marathon Partners Equity Management, LLC dated 2020-07-01 is governed by the internal laws of the State of Delaware applicable to agreements made and to be performed within that state, without giving effect to any law or principles of law that would result in the application of the laws of any other jurisdiction. [e42a4ef8cda58762 p.9]

## Verify clause applicability

The Cooperation Agreement dated July 1, 2020, was entered into by and between e.l.f. [uncited] Beauty, Inc. and Marathon Partners Equity Management, LLC. [e42a4ef8cda58762 p.1] The governing law clause applies to the entire Cooperation Agreement between e.l.f. [uncited] Beauty, Inc. and Marathon Partners Equity Management, LLC dated 2020-07-01. [e42a4ef8cda58762 p.1]

## Verification appendix

Claims: 6 · supported: 3 · partially: 0 · dropped: 0 · gaps: 3 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  | no evidence cited |
| s1.2 | s1 | keep | 1.00 | e1→[e42a4ef8cda58762 p.9] |  |
| s2.1 | s2 | gap |  |  | no evidence cited |
| s2.2 | s2 | keep | 1.00 | e2→[e42a4ef8cda58762 p.1] |  |
| s2.3 | s2 | gap |  |  | no evidence cited |
| s2.4 | s2 | keep | 1.00 | e2→[e42a4ef8cda58762 p.1] |  |

### Evidence

- e1 [e42a4ef8cda58762 p.9 L538-543] keep (1.0): "(g) Governing Law; Choice of Venue.
(i) This Agreement shall be governed by and construed in accordance with the internal laws of the State of Delaware applicable to agreements made and to be performed within that state, without giving effe…"
- e2 [e42a4ef8cda58762 p.1 L14-19] keep (1.0): "This Cooperation Agreement ("Agreement") is entered into as of July 1, 2020, by and between e.l.f. Beauty, Inc., a Delaware corporation (the "Company"), and Marathon Partners Equity Management, LLC ("Marathon Partners"), Marathon Partners L…"
