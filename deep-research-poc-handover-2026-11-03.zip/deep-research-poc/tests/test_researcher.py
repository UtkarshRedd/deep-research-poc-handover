"""Deterministic tests for the researcher loop's HARNESS mechanics (no model calls).

A ScriptedChatModel replays tool-call messages; the tests check what the harness does around
the model: width messages, parallel execution, the min-calls floor, the max-calls stop and the
forced submit, malformed-call recovery, repeat short-circuiting, offload, compaction, the
deadline, document scoping, tracing and the Finding contract. Agent *quality* is measured by
the eval harness (CLAUDE.md invariant 9), not here.
"""
import json
import time
import uuid
from dataclasses import replace
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

from dr.agents.researcher import ResearchContext, ResearchLoop, render_finding, run_researcher
from dr.config import DEFAULT
from dr.evidence import EvidenceBank
from dr.ingest.load import load_dir
from dr.llm import get_scripted_llm
from dr.prompts import load, load_sections
from dr.tools.offload import estimate_tokens, maybe_offload
from dr.tools.read import ReadTracker
from dr.trace import Trace
from dr.workspace import Workspace

SAMPLE = Path(__file__).resolve().parents[1] / "data" / "sample_docs"
QUOTE = "Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00."


@pytest.fixture()
def ws(tmp_path):
    return Workspace.materialize(load_dir(SAMPLE), tmp_path / "ws")


@pytest.fixture()
def ids(ws):
    by_title = {m.title: d for d, m in ws.manifest.items()}
    return {
        "a": by_title["Credit Agreement — Acme Industrial LLC"],
        "m": next(d for t, d in by_title.items() if t.startswith("First Amendment")),
    }


# --------------------------------------------------------------------------- helpers

def cfg(**agents):
    base = {"RESEARCH_MIN_CALLS": 2, "RESEARCH_MAX_CALLS": 8}
    base.update(agents)
    return replace(DEFAULT, agents=replace(DEFAULT.agents, **base))


def tc(name, args):
    return {"name": name, "args": args, "id": f"call_{uuid.uuid4().hex[:8]}", "type": "tool_call"}


def ai(*calls, content=""):
    return AIMessage(content=content, tool_calls=list(calls))


def submit(evidence_ids, answer="see evidence", not_in_corpus=False, confidence="medium"):
    return tc("submit", {"sub_question": "q", "answer": answer, "evidence_ids": evidence_ids,
                         "confidence": confidence, "not_in_corpus": not_in_corpus})


def add_ev(a):
    return tc("add_evidence", {"doc_id": a, "start_line": 17, "end_line": 17, "quote": QUOTE, "note": "original covenant"})


def make_loop(ws, tmp_path, script, config=None, **ctx_kw):
    ctx = ResearchContext(ws=ws, bank=EvidenceBank(ws), tracker=ReadTracker(),
                          trace=Trace(tmp_path / "trace.jsonl", "t"), config=config or cfg(),
                          llm=get_scripted_llm(script), **ctx_kw)
    return ResearchLoop(ctx)   # the context is reachable as loop.ctx


def tool_msgs(run):
    return [m for m in run.state["messages"] if isinstance(m, ToolMessage)]


def humans(run):
    return [m for m in run.state["messages"] if isinstance(m, HumanMessage)]


def trace_events(tmp_path):
    lines = (tmp_path / "trace.jsonl").read_text(encoding="utf-8").splitlines()
    return [json.loads(ln) for ln in lines if ln.strip()]


# --------------------------------------------------------------------------- happy path

def test_happy_path_submits_with_evidence(ws, ids, tmp_path):
    a, m = ids["a"], ids["m"]
    script = [
        ai(tc("grep", {"pattern": "Leverage Ratio"}), tc("grep", {"pattern": "Applicable Margin"}), tc("list_docs", {})),
        ai(tc("read", {"doc_id": a, "start_line": 12, "n_lines": 10}), tc("outline", {"doc_id": m})),
        ai(add_ev(a), submit(["e1"], answer="3.50 to 1.00 [e1]", confidence="high")),
    ]
    loop = make_loop(ws, tmp_path, script)
    run = loop.run("What is the maximum Leverage Ratio under the original Credit Agreement?")
    f = run.finding
    assert run.done == "submitted" and f.evidence_ids == ["e1"] and f.confidence == "high"
    assert run.calls_used == 6 and run.turns == 3 and f.calls_used == 6

    msgs = run.state["messages"]
    assert isinstance(msgs[0], SystemMessage) and "fixed set of 3 documents" in msgs[0].content
    assert msgs[1].content.startswith("Research task:")
    widths = [h for h in humans(run) if h.content.startswith("Turn ")]
    assert [w.content.split(".")[0] for w in widths] == ["Turn 1", "Turn 2", "Turn 3"]
    assert "Issue up to 3 INDEPENDENT" in widths[0].content      # early width
    assert "Issue up to 2 INDEPENDENT" in widths[1].content      # narrowed

    tm = tool_msgs(run)
    assert len(tm) == 7 and all(m.tool_call_id for m in tm)
    assert any(m.name == "grep" and "3 matches in 3 docs" in m.content for m in tm)
    assert any(m.name == "submit" and m.content == "SUBMITTED" for m in tm)
    assert len(loop.ctx.bank) == 1 and loop.ctx.bank.get("e1").page == 2

    ev = trace_events(tmp_path)
    kinds = [e["kind"] for e in ev]
    assert kinds.count("model") == 3 and kinds.count("tool") == 6 and kinds.count("submit") == 1
    assert ev[0]["kind"] == "stage" and ev[0]["status"] == "start"
    assert ev[-1]["kind"] == "stage" and ev[-1]["status"] == "end" and ev[-1]["done"] == "submitted"

    text = render_finding(f, loop.ctx.bank)
    assert f"[{a} p.2]" in text and QUOTE in text and "[e1]" not in text


def test_run_researcher_with_sub_question_and_default_trace(ws, ids, tmp_path):
    a = ids["a"]
    ctx = ResearchContext(ws=ws, bank=EvidenceBank(ws), tracker=ReadTracker(), config=cfg(RESEARCH_MIN_CALLS=1),
                          llm=get_scripted_llm([ai(add_ev(a), submit(["e1"]))]))
    loop = ResearchLoop(ctx)
    run = loop.run("overall question", sub_question="the sub-question")
    assert run.finding.evidence_ids == ["e1"]
    assert "assigned sub-question" in run.state["messages"][1].content
    assert (ws.root / "trace.jsonl").exists()      # trace created in the workspace when none is given
    # convenience wrapper returns the Finding only; a zero floor disables the min-calls check, and a
    # fresh bank on the same workspace reloads e1 from evidence.jsonl
    ctx2 = ResearchContext(ws=ws, bank=EvidenceBank(ws), tracker=ReadTracker(), config=cfg(RESEARCH_MIN_CALLS=0),
                           llm=get_scripted_llm([ai(submit(["e1"]))]))
    assert run_researcher(ctx2, "q").evidence_ids == ["e1"]


# --------------------------------------------------------------------------- floors and caps

def test_min_calls_floor_rejects_early_submit(ws, ids, tmp_path):
    a = ids["a"]
    script = [
        ai(tc("grep", {"pattern": "Leverage Ratio"})),
        ai(add_ev(a), submit(["e1"])),                                   # 2 calls < min 3 -> rejected
        ai(tc("grep", {"pattern": "amend"}), tc("grep", {"pattern": "Margin"})),
        ai(submit(["e1"])),
    ]
    loop = make_loop(ws, tmp_path, script, config=cfg(RESEARCH_MIN_CALLS=3))
    run = loop.run("q")
    rejected = [m for m in tool_msgs(run) if m.name == "submit" and m.content.startswith("REJECTED")]
    assert len(rejected) == 1 and "2 tool calls" in rejected[0].content and "minimum is" in rejected[0].content
    assert run.done == "submitted" and run.calls_used == 4 and run.finding.evidence_ids == ["e1"]


def test_max_calls_forces_submit(ws, tmp_path):
    def g(p):
        return tc("grep", {"pattern": p})

    script = [
        ai(g("Leverage"), g("Margin"), g("Commitment")),
        ai(g("Termination"), g("notice"), g("amend")),                   # only one fits the budget of 4
        ai(submit([], answer="The documents do not state it.", not_in_corpus=True)),   # forced turn
    ]
    loop = make_loop(ws, tmp_path, script, config=cfg(RESEARCH_MIN_CALLS=1, RESEARCH_MAX_CALLS=4))
    run = loop.run("q")
    assert run.done == "forced_submit" and run.finding.not_in_corpus and run.calls_used == 4
    assert sum(1 for m in tool_msgs(run) if m.content.startswith("NOT EXECUTED")) == 2
    forced = [h for h in humans(run) if h.content.startswith("STOP RESEARCHING")]
    assert len(forced) == 1 and "4 calls" in forced[0].content


def test_force_ignored_builds_finding_from_bank(ws, ids, tmp_path):
    a = ids["a"]
    script = [
        ai(tc("grep", {"pattern": "Leverage"}), add_ev(a)),
        AIMessage(content="I believe the answer is 3.50 to 1.00."),      # ignores the forced submit
    ]
    loop = make_loop(ws, tmp_path, script, config=cfg(RESEARCH_MIN_CALLS=1, RESEARCH_MAX_CALLS=2))
    run = loop.run("q")
    f = run.finding
    assert run.done == "max_calls" and f.confidence == "low" and f.evidence_ids == ["e1"]
    assert "No answer was submitted" in f.answer and "max_calls" in f.answer and "[e1]" in f.answer


# --------------------------------------------------------------------------- small-model robustness

def test_malformed_calls_recover_via_constrained_json(ws, ids, tmp_path):
    a = ids["a"]
    script = [
        ai(tc("read", {"doc_id": a, "start_line": "twelve"})),           # wrong type
        ai(tc("nosuchtool", {"x": 1})),                                   # unknown tool -> 2nd malformed turn
        AIMessage(content='Sure:\n```json\n{"tool": "grep", "args": {"pattern": "Leverage Ratio"}}\n```'),
        ai(add_ev(a), submit(["e1"])),
    ]
    loop = make_loop(ws, tmp_path, script, config=cfg(RESEARCH_MIN_CALLS=1))
    run = loop.run("q")
    tm = tool_msgs(run)
    assert any(m.content.startswith("INVALID ARGUMENTS for read") for m in tm)
    assert any(m.content.startswith("UNKNOWN TOOL") for m in tm)
    assert any(m.name == "grep" and "3 matches in 3 docs" in m.content for m in tm)
    assert run.done == "submitted" and run.calls_used == 2
    assert sum(1 for h in humans(run) if "ONLY one JSON object" in h.content) == 1


def test_constrained_step_fails_twice_then_stalls(ws, tmp_path):
    script = [
        ai(tc("grep", {"pattern": "x", "doc_ids": "notalist"})),         # doc_ids must be a list
        ai(tc("read", {})),                                               # missing doc_id
        AIMessage(content="I am not sure what to do."),
        AIMessage(content="Still unsure."),
    ]
    loop = make_loop(ws, tmp_path, script)
    run = loop.run("q")
    assert run.done == "stalled" and run.finding.confidence == "low" and run.calls_used == 0
    assert sum(1 for h in humans(run) if h.content.startswith("That was not a valid JSON")) == 1


def test_text_only_turns_are_nudged_then_forced(ws, tmp_path):
    script = [
        AIMessage(content="The answer is probably 3.5."),
        AIMessage(content="As I said, 3.5."),
        ai(submit([], not_in_corpus=True)),
    ]
    loop = make_loop(ws, tmp_path, script)
    run = loop.run("q")
    assert run.done == "forced_submit"
    assert sum(1 for h in humans(run) if "no tool call" in h.content) == 1
    assert any(h.content.startswith("STOP RESEARCHING") and "without tool calls" in h.content for h in humans(run))


# --------------------------------------------------------------------------- context hygiene

def test_repeat_call_is_short_circuited(ws, tmp_path):
    script = [
        ai(tc("grep", {"pattern": "Leverage Ratio"})),
        ai(tc("grep", {"pattern": "Leverage Ratio"})),
        ai(submit([], not_in_corpus=True)),
    ]
    loop = make_loop(ws, tmp_path, script, config=cfg(RESEARCH_MIN_CALLS=1))
    run = loop.run("q")
    greps = [m for m in tool_msgs(run) if m.name == "grep"]
    assert "3 matches" in greps[0].content and greps[1].content.startswith("(repeat)")
    ev = trace_events(tmp_path)
    assert sum(1 for e in ev if e["kind"] == "tool" and e["tool"] == "grep") == 1
    assert sum(1 for e in ev if e["kind"] == "tool_repeat") == 1
    assert run.calls_used == 2                                            # repeats still burn budget


def test_oversized_result_is_offloaded(ws, tmp_path):
    small = replace(cfg(RESEARCH_MIN_CALLS=1), tools=replace(DEFAULT.tools, OFFLOAD_TOKENS=10, OFFLOAD_PREVIEW_LINES=2))
    script = [ai(tc("grep", {"pattern": "a"})), ai(submit([], not_in_corpus=True))]
    loop = make_loop(ws, tmp_path, script, config=small)
    run = loop.run("q")
    g = next(m for m in tool_msgs(run) if m.name == "grep")
    assert g.content.startswith("(result too large") and "tool_out/" in g.content
    assert len(g.content.splitlines()) == 3                               # pointer + 2 preview lines
    files = list((ws.root / "tool_out").glob("*_grep.txt"))
    assert len(files) == 1 and files[0].read_text(encoding="utf-8").startswith("grep /a/")
    assert any(e["kind"] == "tool_offload" for e in trace_events(tmp_path))


def test_context_compaction_elides_old_tool_results(ws, tmp_path):
    tiny = cfg(RESEARCH_MIN_CALLS=1, RESEARCH_MAX_CONTEXT_TOKENS=1)
    script = [
        ai(tc("grep", {"pattern": "Leverage Ratio"})),
        ai(tc("grep", {"pattern": "Applicable Margin"})),
        ai(submit([], not_in_corpus=True)),
    ]
    loop = make_loop(ws, tmp_path, script, config=tiny)
    run = loop.run("q")
    greps = [m for m in tool_msgs(run) if m.name == "grep"]
    assert all(m.content.startswith("(elided:") for m in greps)         # both predate the final turn
    assert next(m for m in tool_msgs(run) if m.name == "submit").content == "SUBMITTED"
    assert sum(1 for e in trace_events(tmp_path) if e["kind"] == "compaction") == 2
    assert len(tool_msgs(run)) == 3                                       # replaced in place, not duplicated


# --------------------------------------------------------------------------- deadline and scope

def test_deadline_already_passed_forces_submit_within_grace(ws, tmp_path):
    loop = make_loop(ws, tmp_path, [ai(submit([], not_in_corpus=True))], deadline_ts=time.time() - 1)
    run = loop.run("q")
    assert run.done == "forced_submit" and run.calls_used == 0 and run.turns == 0


def test_deadline_past_grace_skips_the_model(ws, tmp_path):
    loop = make_loop(ws, tmp_path, [ai(submit([], not_in_corpus=True))],
                          config=cfg(FORCE_SUBMIT_GRACE_S=0.0), deadline_ts=time.time() - 5)
    run = loop.run("q")
    assert run.done == "deadline" and len(loop.ctx.llm.script) == 1        # the model was never called
    assert "deadline" in run.finding.answer and run.finding.confidence == "low"


def test_scoped_doc_ids_restrict_tools(ws, ids, tmp_path):
    a, m = ids["a"], ids["m"]
    script = [
        ai(tc("grep", {"pattern": "Leverage Ratio"}), tc("read", {"doc_id": m, "start_line": 1, "n_lines": 5}),
           tc("list_docs", {})),
        ai(submit([], not_in_corpus=True)),
    ]
    loop = make_loop(ws, tmp_path, script, config=cfg(RESEARCH_MIN_CALLS=1), scoped_doc_ids=[a])
    run = loop.run("q")
    tm = {m.name: m.content for m in tool_msgs(run)}
    assert "1 matches in 1 docs" in tm["grep"]
    assert tm["read"].startswith("REJECTED") and "scope" in tm["read"]
    assert tm["list_docs"].startswith("1 docs")
    assert "fixed set of 1 documents" in run.state["messages"][0].content


# --------------------------------------------------------------------------- prompts and offload units

def test_prompt_loader():
    text = load("width_turn", turn=1, calls_used=0, max_calls=25, min_calls=6, n_evidence=0,
                phase_hint="x", width=3, deadline_hint="")
    assert text.startswith("Turn 1.") and "{" not in text
    with pytest.raises(KeyError, match="calls_used"):
        load("width_turn", turn=1)
    with pytest.raises(FileNotFoundError):
        load("no_such_prompt")
    assert set(load_sections("width_phase_hints")) == {"early", "mid", "late", "deadline"}
    ask = load_sections("constrained_call")["ask"].format(error="e", tool_schemas="s")
    assert '{"tool": "<tool name>", "args": {...}}' in ask


def test_offload_under_cap_is_unchanged(ws):
    text, path = maybe_offload(ws, "grep", "short", DEFAULT)
    assert text == "short" and path is None
    assert estimate_tokens("abcd" * 10) == 10


# --------------------------------------------------------------------------- endpoint resilience

def test_transient_model_error_costs_a_turn_not_the_run(ws, ids, tmp_path):
    def boom(messages):
        raise ConnectionError("connection reset")

    script = [boom, ai(add_ev(ids["a"]), submit(["e1"]))]
    loop = make_loop(ws, tmp_path, script, config=cfg(RESEARCH_MIN_CALLS=1))
    run = loop.run("q")
    assert run.done == "submitted" and run.state["model_errors"] == 1
    assert sum(1 for e in trace_events(tmp_path) if e["kind"] == "model_error") == 1
    loop2 = make_loop(ws, tmp_path, [boom, boom, ai(submit([], not_in_corpus=True))], config=cfg(RESEARCH_MIN_CALLS=1))
    assert loop2.run("q").done == "model_error"                   # MODEL_ERRORS_MAX=2 failures end the run
