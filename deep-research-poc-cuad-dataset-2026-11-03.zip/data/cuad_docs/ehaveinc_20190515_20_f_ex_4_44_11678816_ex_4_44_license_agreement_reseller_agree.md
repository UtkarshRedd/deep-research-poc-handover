<!-- page 1 -->
# LICENSE AND RESELLER AGREEMENT
| Field | Value |
|---|---|
| Document Type | Reseller Agreement |
| Agreement Date | 2018-10-30 |
| Parties | EHAVE, INC. ("Ehave"); COMPANION HEALTHCARE TECHNOLOGIES CORP ("CHT") |
| Source | CUAD v1 / EhaveInc_20190515_20-F_EX-4.44_11678816_EX-4.44_License Agreement_ Reseller Agreement |

Exhibit 4.44 THIS LICENSE AND RESELLER AGREEMENT dated as of the October 30, 2018 is made BETWEEN:
EHAVE, INC., a company incorporated under the laws of the Province of Ontario, Canada ("Ehave"); -
and - COMPANION HEALTHCARE TECHNOLOGIES CORP, a company incorporated under the laws of the Province
of Ontario ("CHT") RECITALS: A. Ehave has developed a software platform that provides an end-to-end
patient management solution to healthcare professionals and provides that platform to users as a
service. B. CHT has developed a business model to bring a similar service that Ehave provides using
the Ehave Platform for the domain of the animal market including companion animals (i.e. pets). C.
The Parties desire to enter into this Agreement to enable CHT to pursue its business model whereby
CHT will license and provide services in relation to companion and other animals using the Ehave
Companion Solution under the terms and conditions contained herein. NOW THEREFORE, in consideration
of the premises and the mutual agreements hereinafter set out herein and of other consideration (the
receipt and sufficiency of which are acknowledged by each Party), the Parties covenant and agree as
follows: 1. INTERPRETATION (a) Definitions In this Agreement and the schedules annexed hereto, the
following terms shall have the respective meanings indicated below: "Acceptance Criteria" has the
meaning ascribed to it in Section 3(d). "Acceptance Period" has the meaning ascribed to it in
Section 3(d). "Acceptance Procedures" has the meaning ascribed to it in Section 3(d). "Agreement"
means this license and reseller agreement and all Schedules, Appendixes and Exhibits attached
hereto. "Applicable Laws" means any and all (i) laws, statutes, rules, regulations, by laws, codes,
treaties, constitutions and ordinances, including Privacy Legislation ("Laws"), (ii) order,
directive, judgment, decree, award or writ of any court (including a court of equity), arbitrator or
arbitration panel, or any Governmental Authority or other body exercising adjudicative, regulatory,
judicial or quasi-judicial powers, including any stock exchange ("Orders"), and (iii) policies,
guidelines, standards, requirements, notices and protocols of any Governmental Authority
("Policies"); which are applicable to or govern CHT, Ehave or the transactions contemplated by this
Agreement.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 2 -->
"Authentication ID" means a security mechanism by which an Authorized User identifies herself or
himself to the Ehave Companion Solution and gains access thereto, which security mechanism may
include user identification, passwords, digital certificates or any other similar process mechanism
for authentication and recognition as determined by Ehave from time to time. "Authorized User" means
an individual who an End User has authorized to access and use CHT's services, which includes the
use of the Ehave Companion Solution. "Business Day" means any calendar day except for Saturday or
Sunday or any statutory holiday observed in the Province of Ontario. "CHT Developments" has the
meaning ascribed to it in Section 4(a). "CHT Indemnified Parties" has the meaning ascribed to it on
Section 16(a). "CHT Marks" means the names, trademarks, trade names, service marks, designs and
logos of CHT. "Claim" has the meaning ascribed to it in Section 16(a). "Competitive Transaction" has
the meaning ascribed to it in Section 2(d). "Confidential Information" means this Agreement, the
Ehave Companion Solution, End User Data and all ideas, designs, business models, databases,
drawings, documents, diagrams, formulas, test data, marketing, financial or personnel data, sales
information, customer or supplier information, including information provided by such customers or
suppliers, or any other information already furnished and to be furnished or made available by one
Party to the other, whether in oral, written, graphic or electronic form including any such
information exchanged during informational sessions designated as confidential, including, without
limitation, information concerning a Party's actual and potential customers and other Intellectual
Property Rights of such Party, provided, however, that Confidential Information shall not include
any data or information: (i) that, at the time of disclosure, is in or, after disclosure, becomes
part of the public domain, through no act or failure on the part of the receiving Party, whether
through breach of this Agreement or otherwise; (ii) that, prior to disclosure by the disclosing
Party, was already in the possession of the receiving Party, as evidenced by written records kept by
the receiving Party in the ordinary course of its business, or as evidenced by proof of actual prior
use by the receiving Party; (iii) independently developed by the receiving Party, by Persons having
no direct or indirect access to the disclosing Party's Confidential Information provided that the
receiving Party provides clear and convincing evidence of such independent development; (iv) which,
subsequent to disclosure, is obtained from a third Person: (A) who is lawfully in possession of such
information; (B) who is not in violation of any contractual, legal, or fiduciary obligation to
either Party, as applicable, with respect to such information; and (C) who does not prohibit either
Party from disclosing such information to others; or (v) is further disclosed with the prior written
consent of the disclosing Party, but only to the extent of such consent. "Effective Date" means the
date first written above. "Ehave Companion Solution" means the Ehave Platform, as modified, adapted
and customized, as provided herein, the specifications of which are set out in Schedule "1".

2.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 3 -->
"Ehave Platform" means the Software, Ehave Server and such devices and peripherals physically
located with the Ehave Server, including all computer hardware, software, network elements, and
electrical and telecommunications infrastructure located behind the Point of Access. "Ehave Server"
means that computer server located at Ehave's premises, or a third party provider of hosting and/or
network services, that houses the Software. "End User" means CHT's customers who have entered into a
subscription agreement with CHT for CHT services, which services include the use of the Ehave
Companion Solution. "End User Data" means collectively any data, files, documentation or other
information (including personal information) that an End User or any of its Authorized Users may:
(i) upload to the Ehave Companion Solution; and/or (ii) have processed through the use of the Ehave
Companion Solution, and includes any data or output resulting from or derived from such use. "Escrow
Agent" has the meaning ascribed thereto in Section 12(a). "Escrow Agreement" has the meaning
ascribed thereto in Section 12(a). "Field of Use" means indications and outcomes related to any
companion and other animals. "Governmental Authority" means any domestic, foreign or supranational
government, whether federal, provincial, state, territorial or municipal; and any governmental
agency, ministry, department, tribunal, commission, bureau, board or other instrumentality,
including international institutions, exercising or purporting to exercise legislative, judicial,
regulatory or administrative functions of, or pertaining to, government. "Implementation Plan" has
the meaning ascribed to it in Section 3(a). "Intellectual Property" means any property, tangible or
intangible, that may be subject to Intellectual Property Rights, including without limitation,
ideas, formulae, algorithms, concepts, techniques, processes, procedures, approaches, methodologies,
plans, systems, research, information, documentation, data, data compilations, specifications,
requirements, designs, diagrams, programs, inventions, technologies, software (including its source
code), tools, products knowledge, know-how, including without limitation, trade secrets, and other
materials or things. "Intellectual Property Rights" means (a) any and all proprietary rights
anywhere in the world provided under (i) patent law; (ii) copyright law, including moral rights;
(iii) trademark law; (iv) design patent or industrial design law; (v) semiconductor chip or mask
work law; (vi) trade secret law; (vii) privacy law; or (viii) any other statutory provision or
common law principle applicable to this Agreement which may provide a right in either (A)
Intellectual Property; or (B) the expression or use of Intellectual Property; and (b) any and all
applications, registrations, licenses, sub-licenses, franchises, agreements or any other evidence of
a right in any of the foregoing. "Objectionable Content" means content that infringes any Applicable
Laws or third party rights, and content which is obscene, indecent, pornographic, seditious,
defamatory, threatening, liable to incite racial hatred, menacing, blasphemous, misleading,
deceptive or in breach of any person's Intellectual Property Rights. "Party" means either Ehave or
CHT; and "Parties" means both of them. "Person" means any individual, estate, sole proprietorship,
firm, partnership, unincorporated association, unincorporated syndicate, unincorporated
organization, limited liability company, corporation, body corporate, trustee, trust, Governmental
Authority or other entity or organization and includes any successor to any of the foregoing.

3.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 4 -->
"Point of Access" means Ehave's, or its subcontractor's, border router, which is used to establish
connectivity from the Ehave Platform to Ehave's, or its subcontractor's, Internet provider, or the
public Internet. "Royalties" means the fees, charges and other amounts to be paid by CHT to Ehave
for the rights granted hereunder and which amounts are set out in Schedule "6". "Security
Requirements" means those safeguards and controls set out in Schedule "5". "Software" means Ehave's
proprietary patient and data management software and any related documentation, as modified for use
in the animal (including companion animal) and veterinary industry. "Source Code" means the
human-readable form of a computer instruction, including, but not limited to, related system
documentation, flow charts, all comments and any procedural code and a description of the procedure
for generating object code, all of a level sufficient to enable a programmer reasonably fluent in
the programming language in which the Software was written to understand, build, operate, support,
maintain and develop modifications, upgrades, updates, adaptations, enhancements, new versions, and
other derivative works and improvements of, and to develop computer programs compatible with, the
Software. "Specifications" has the meaning ascribed to it in Section 3(a)."Subscription Agreement"
has the meaning ascribed to it in Section 5(b). "Term" has the meaning ascribed to it in Section 9.
"Territory" means any jurisdiction in the World where the use of the Ehave Companion Solution for
the intended purpose herein is permitted under Applicable Law. "Transition out Period" has the
meaning ascribed to it in Section 10(f). "Transition-out Services" has the meaning ascribed to it in
Section 10(f). "Virus" means a piece of code usually (but not necessarily) disguised as something
else that causes some unexpected and, for the victim, usually undesirable, event and which is
designed so that it may automatically spread to other computer users; the term 'Virus' will also be
deemed to include worms, cancelbots, trojan horses, harmful contaminants (whether self-replicating
or not) and nuisance causing or otherwise harmful applets. (b) Headings; Extended Meanings The
division of this Agreement into articles, sections, schedules and other subdivisions, and the
inclusion of headings are for convenience of reference only and shall not affect the construction or
interpretation of this Agreement. The headings in the Agreement are not intended to be full or
precise descriptions of the text to which they refer. Unless something in the subject matter or
context is inconsistent therewith, references herein to Articles and Sections are to Articles and
Sections of this Agreement. The word "including" or "include(s)" means "including without
limitation" or "include(s) without limitation". (c) Currency Unless otherwise specified, all
references to monetary amounts, including the symbol "$", are in respect of Canadian currency.

4.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 5 -->
(d) Exhibits and Schedules The following Schedules are a part of and are integral to this Agreement:
Schedule "1" - Ehave Companion Solution Specifications Schedule "2" - Development and Implementation
Plan Schedule "3" - Support Procedures Schedule "4" - Service Level Commitments Schedule "5" -
Security Requirements Schedule "6" - Royalties and Early Termination Fee Schedule "7" - Source Code
Escrow (e) Entire Agreement This Agreement, together with any other documents to be delivered
pursuant hereto, constitutes the entire agreement between the Parties pertaining to the subject
matter hereof and supersedes all prior agreements, negotiations, discussions and understandings,
written or oral, between the Parties. Except as expressly provided in this Agreement, there are no
representations, warranties, conditions other agreements or acknowledgements, whether direct or
collateral, express or implied, that form part of or affect this Agreement. The execution of this
Agreement has not been induced by, nor do either of the Parties rely upon or regard as material, any
representations, warranties, conditions, other agreements or acknowledgements not expressly made in
this Agreement or in the other documents to be delivered pursuant hereto. (f) Governing Law: This
Agreement shall be governed by, and construed and enforced in accordance with, the laws in force in
the Province of Ontario (excluding any conflict of laws rule or principle which might refer such
construction to the laws of another jurisdiction). The Parties hereto agree to submit to the
exclusive jurisdiction of the courts of the Province of Ontario and waive any objection relating to
improper venue or forum non conveniens to the conduct of any proceeding in any such court. (g)
Severability: In the event that any provision (or any portion of a provision) of this Agreement
shall for any reason be held by a court of competent jurisdiction to be invalid, illegal, or
unenforceable for any reason, such invalidity, illegality or unenforceability shall not affect any
other provision hereof and this Agreement shall be construed as if such invalid, illegal or
unenforceable provision (or portion of a provision) had never been contained herein in regards to
that particular jurisdiction. 2. APPOINTMENT AND LICENSE GRANT (a) Exclusive Appointment Ehave
hereby appoints CHT, and CHT hereby accepts the appointment, to act as Ehave's reseller of the use
of the Ehave Companion Solution within the Field of Use in the Territory for the duration of the
Term solely in accordance with the terms and conditions of this Agreement. Subject to Section 2(e),
the foregoing appointment is exclusive such that Ehave shall not appoint any other Person to, nor
may Ehave itself, sell or resell the use of the Ehave Companion Solution within the Field of Use
anywhere in the Territory.

5.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 6 -->
(b) Grant by Ehave Subject to the terms and conditions of this Agreement commencing as of the
Effective Date and for the duration of the Term and any Transition-out Period, Ehave hereby grants
to CHT a non-transferable (except as permitted under Section 20(f)), right to: (i) sub-license the
use of the Ehave Companion Solution within the Field of Use in the Territory to End Users and their
respective Authorized Users, including in operation or by interfacing with other software, hardware,
systems, networks and services, in accordance with and subject to the provisions of CHT's
Subscription Agreement; and (ii) use the Ehave Companion Solution to support its licensed End Users.
Subject to Section 2(e), the grant set out in Clause 2(b)(i) is exclusive such that Ehave shall not
license any other Person to, nor may Ehave itself, license, sub-license the use of, or provide
services similar to, the Ehave Companion Solution within the Field of Use anywhere in the Territory.
(c) Restrictions on Use Any rights not granted herein are strictly reserved by Ehave. CHT shall not,
and shall not permit others to, reverse engineer, decompile, disassemble or translate any software
used by Ehave to provide the Ehave Companion Solution, or otherwise attempt to view, display or
print such software, including its Source Code, except as permitted herein. (d) Prohibition on
Competitive Solutions For so long as the appointment set out in Section 2(a) is exclusive, CHT shall
not enter into an agreement (a "Competitive Transaction") with any other Person related to the
license, sub-license, sale, resale or provide service, solutions, goods or products, that are
substantially similar to or competitive with the Ehave Companion Solution. For clarity, a
Competitive Transaction shall not include an agreement for use, integration or interfacing, or
co-marketing, of the Ehave Companion Solution with other services, solutions, devices, goods or
products, where such other services, solutions, devices, goods or products do not contain the same
or similar functionality of the Ehave Companion Solution, but provides for a complementary solution.
(e) Conversion to Non-Exclusive Notwithstanding anything to the contrary contained herein, the
exclusive appointment and license set out in Sections 2(a) and 2(b) shall become non-exclusive if:
(i) at any time during the Term hereof, CHT breaches Section 2(d) as determined by arbitration in
accordance with Section 19(c) or by a final non-appealable judgment of a court of competent
jurisdiction; or (ii) at any time after November 1, 2010 CHT fails to achieve annual revenues of
$500,000. (f) No Franchise Agreement The Parties to this Agreement are independent contractors and
nothing in this Agreement shall be deemed or constructed as creating a joint venture, partnership,
agency relationship, or franchise between Ehave and CHT. Neither Party, by virtue of this Agreement,
will have any right, power or authority to act or create an obligation, express or implied, on
behalf of the other Party. Each Party assumes responsibility for the actions of their personnel
under this Agreement and will be solely responsible for their supervision, daily direction and
control, wage rates, withholding income taxes, Canada Pension Plan contributions, employment
insurance premiums, disability benefits, or the manner and means through which the work under this
Agreement will be accomplished. Except as provided otherwise in this Agreement, CHT has the sole
discretion to determine CHT's methods of operation, CHT's accounting practices, the types and
amounts of insurance CHT carries, CHT's personnel practices, CHT's advertising and promotion, CHT's
customers and CHT's service areas and methods. The relationship created hereby between the parties
is solely that of supplier and reseller, and licensor and licensee.

6.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 7 -->
3. DEVELOPMENT AND IMPLEMENTATION OF THE COMPANION SOLUTION (a) Specifications and Implementation
Attached hereto as Schedule "1" are the business requirements and technical specifications of the
Ehave Companion Solution (the "Specifications"). Attached hereto as Schedule "2" is the development
and implementation plan (the "Implementation Plan"), which sets out the procedures and obligations
of each of the Parties and the key milestones and timelines in relation to the development and
implementation of the Ehave Companion Solution. The Parties acknowledge that at the time of
execution of this Agreement that the Specifications and Implementation Plan may not have been fully
developed, but that the creation of the Specifications and development of the detailed
Implementation Plan will be the first step in respect of the development and implementation of the
Ehave Companion Solution, in which case, once approved by the Parties in writing, the Specifications
and Implementation Plan so developed will be attached hereto and shall replace Schedules "1" and "2"
respectively. Once finalized the Specifications and Implementation Plan may not be changed or
modified by either Party, except in accordance with the procedures set out in Section 3(c). (b)
Obligations Each of Ehave and CHT shall perform, at their own expense (or as otherwise set out in
Schedule "6"), their respective obligations and responsibilities set out in the Implementation Plan
as necessary to accomplish the development and implementation of the Ehave Companion Solution in
accordance with the milestones and timelines set out therein. CHT acknowledges that the development
and implementation of the Ehave Companion Solution requires decisions and input from CHT and for CHT
to perform its obligations thereunder in a timely manner. In the event that CHT delays in providing
such decisions, input or performance of its obligations, the development and implementation of the
Ehave Companion Solution shall be correspondingly delayed. Subject to the foregoing, Ehave
acknowledges that time is of the essence with respect to its obligations hereunder and that prompt
and timely performance of all such obligations, including all development and implementation dates,
timetables, project milestones and other requirements in this Agreement is strictly required. Once
the implementation of the Ehave Companion Solution is completed, Ehave shall notify CHT of such
completion and that the Ehave Companion Solution is ready for testing in accordance with Section
3(d).

7.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 8 -->
(c) Change Control Process Either Party may request additions, deletions or amendments in respect of
the development and implementation of the Ehave Companion Solution ("Change"). Changes shall be
requested in writing signed by an authorized representative of the Party requesting the Change
("Change Request"). Ehave shall have no obligation to perform, and CHT shall have no obligation to
pay for, services related to any proposed modification or change unless both Parties have agreed to
the modifications or changes in writing in accordance with the procedures set forth herein. The
Change Request shall include a reasonably detailed description of the scope and nature of the
requested Change. If CHT desires a Change, Ehave shall evaluate the feasibility of such change as it
relates to the proposed Field of Use. As soon as reasonably possible after receipt of CHT's request,
Ehave agrees to provide CHT with a written estimate of the cost, if any, of and the timing to
implement the requested Changes as well as any additional terms and conditions related to such
Changes. The costs, if any, associated with the development of such estimate shall be borne by CHT.
Upon CHT's approval in writing of the cost estimate and any additional terms and conditions related
to such Changes, including delivery dates and payment terms provided by Ehave, the Parties shall
revise the Specifications and Implementation Plan and shall replace the Specifications and
Implementation Plan attached hereto as Schedules "1" and "2", and Ehave shall develop and implement
the Change as so agreed. Changes shall be subject to acceptance testing by CHT prior to being
deployed into production in accordance with procedures described in Section 3(d) or as otherwise
agreed by the parties in writing. Ehave shall not refuse to accept a CHT Change request unless it is
unable to make the Change requested using commercially reasonable efforts, in which event Ehave will
provide an explanation to CHT; or Ehave and CHT fail to agree on the terms and conditions related to
the performance of such Change, including the costs, if any. If a mutually acceptable resolution is
not reached in respect of a CHT Change request, the Parties may submit the issue to mediation
pursuant to Section 19(b). (d) Acceptance The criteria ("Acceptance Criteria") which the Ehave
Companion Solution is to meet and the procedures by which such criteria are to be tested
("Acceptance Procedures") shall be set out in the Implementation Plan and shall follow the
requirements set out in this Section 3(d). Once notified by Ehave that the Ehave Companion Solution
is ready for acceptance testing, CHT shall perform the tests as set out in the Acceptance
Procedures. Unless otherwise set out in the Acceptance Procedures, CHT shall have ten (10) Business
Days to perform the acceptance tests as set out in the Acceptance Procedures and to provide Ehave
written notice of acceptance or non-acceptance of the Ehave Companion Solution (the "Acceptance
Period"). CHT shall not refuse to accept the Ehave Companion Solution unless all or one or more
portions of the Solution fail to perform, in any material respect, in accordance with the Acceptance
Criteria. Any notice of non- acceptance shall describe the material failure of the Ehave Companion
Solution in reasonable detail and CHT shall provide Ehave with reasonably detailed documentation and
explanations, together with underlying data, to substantiate the failure and to reasonably assist
Ehave in its efforts to diagnose and correct the failure. If CHT gives notice to Ehave of
non-acceptance of the Ehave Companion Solution then Ehave shall investigate the reported failure in
good faith and correct same, and if the engagement is on a fixed fee basis at no additional cost to
CHT, within fifteen (15) Business Days unless an extension is granted by CHT. If, within such
fifteen (15) Business day period (or extended period, as applicable), Ehave corrects the failure,
then Ehave shall give written notice to CHT certifying that the failure has been corrected, and
another Acceptance Period of the same duration as the initial Acceptance Period shall begin and
shall be governed by the provisions of this Section 3(d) upon delivery of the corrected Ehave
Companion Solution to CHT. If the Acceptance Procedures were conducted three (3) times in respect of
the initial implementation of the Ehave Companion Solution, and the eHAve Companion Solution failed
to pass the Acceptance Criteria on the third (3rd) try, then, at the discretion of either Party,
Ehave may continue to fix the problem, or terminate this Agreement in which case, CHT shall promptly
return to Ehave all copies of the Ehave Companion Solution, including the Specifications and any
other items delivered to CHT by Ehave thereunder and Ehave shall promptly refund to CHT any monies
paid by CHT in respect of the initial development and implementation of the Ehave Companion
Solution. If the Acceptance Procedures were conducted three (3) times in respect of a Change, and
the Change failed to pass the Acceptance Criteria on the third (3rd) try, then, at the discretion of
CHT, Ehave may continue to fix the problem, or terminate the performance of the development of the
Change, in which case CHT shall promptly return to Ehave all copies of the Change, including the
Specifications thereto and Ehave shall promptly refund to CHT any monies paid by CHT in respect of
the development and implementation of the Change.

8.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 9 -->
(e) Deployment Once CHT provides Ehave written notice of acceptance, Ehave will deploy the Ehave
Companion Solution or Change, as applicable, by putting the Ehave Companion Solution or Change into
production in accordance with, and within the timelines set out, in the Implementation Plan or
Change Request, as the case may be. (f) Branding The Ehave Companion Solution may, in the sole
discretion of CHT, be branded, marketed, advertised, promoted and sublicensed under CHT Marks. For
such purpose, CHT hereby grants to Ehave a non-exclusive, royalty-free, revocable, limited license
during the Term and Transition-out Period and within the Territory to use, reproduce, publish and
display the CHT Marks solely in connection with the operation of the Ehave Companion Solution for
and on behalf of CHT and End Users. Ehave agrees that its use of any CHT Marks will comply with
CHT's branding guidelines to the extent made available by CHT to Ehave from time to time and will
enure to the benefit of CHT. The CHT Marks are proprietary to CHT and nothing in this Agreement
constitutes the grant of a general license for their use. Other than as expressly set forth herein,
Ehave does not acquire any right, title or interest in or to any CHT Marks or the goodwill
associated therewith. CHT reserves any and all rights in and to the CHT Marks not expressly granted
herein. 4. CHT DEVELOPMENTS (a) Development From time to time, CHT may request Ehave to develop
functionality that is separate from, but interfaces with the Ehave Companion Solution (the "CHT
Developments"). Any such development effort shall be subject to a separate services agreement
between the Parties which will set out the respective obligations of the Parties regarding the
development and deployment of any CHT Developments, including without limitation assignment or
transfer of any rights that Ehave may have in such CHT Developments. (b) APIs If CHT desires a third
party to develop any CHT Developments, Ehave shall provide to CHT the specifications of the
application program interfaces to permit CHT or such other third party to develop the CHT
Developments so that it may inter-operate with the Ehave Companion Solution. (c) License If CHT
requires Ehave to host the CHT Developments, then CHT hereby grants to Ehave a royalty-free,
non-exclusive, non-transferable, limited right and licence during the Term hereof to use the CHT
Developments solely for the purpose of enabling its operation for CHT and its End Users' purposes.
5. GENERAL PERFORMANCE OBLIGATIONS (a) Marketing CHT shall, in good faith and at its own expense:
(i) market, advertise, promote and re-license the use of the Ehave Companion Solution to End Users
located in the Territory consistent with good business practice, provided that CHT shall have full
discretion as to where in the Territory it chooses to do so at any time and from time to time;

9.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 10 -->
(ii) develop and execute a marketing plan sufficient to fulfil its obligations under this Agreement;
(iii) have sufficient knowledge of the industry and solutions competitive with the Ehave Companion
Solution (including specifications, features and benefits) so as to be able to explain in detail to
the End Users: A. the material differences between the Ehave Companion Solution and competing
solutions; and B. information on standard protocols and features of the Ehave Companion Solution;
(iv) market, advertise, promote and provide the Ehave Companion Solution and conduct business in a
manner that at all times reflects favourably on the Ehave Companion Solution and, subject to Section
3(f), the good name, goodwill and reputation of Ehave; and (v) maintain books, records and accounts
of all transactions and activities covered by this Agreement and permit reasonable examination
thereof by Ehave and its representatives in accordance with this Agreement. (b) Provision to End
Users CHT shall require each End User to enter into and execute a subscription agreement in a form
and substance satisfactory to Ehave and CHT, acting reasonably, and which contains provisions
similar to Ehave's collaboration agreement for the use of the Ehave solution (the "Subscription
Agreement"). Ehave shall be a third party beneficiary hereunder, but shall not have any obligations
to the End User thereunder. (c) End User Data Pursuant to the Subscription Agreement, CHT shall
obtain from each End User the right to and hereby grants, effective upon the execution and delivery
of such End User's Subscription Agreement, to Ehave: (i) a royalty-free, non-exclusive,
non-transferable, limited right and licence during the term of such Subscription Agreement to use,
copy, store and display the End User Data solely for the purpose of enabling Ehave to operate the
Ehave Companion Solution for such End User and as may be necessary for the purpose of enabling Ehave
to provide support services in accordance with this Agreement; and (ii) a royalty-free,
non-exclusive, limited, perpetual right and license to use, copy, store and display End User Data on
an aggregated and anonymous basis and so as not to permit the identification of any End User or
individual for the sole purpose of improving or developing enhancements to the Ehave Companion
Solution , provided that Ehave shall not have any right to use, commercialize or exploit such End
User Data in any other manner or for any other purpose. Except for the limited license expressly
provided in Section 5(c), nothing contained in this Agreement shall be construed as granting to
Ehave or any third party any right, title, or interest in or to any End User Data. Without limiting
the foregoing, Ehave agrees that it shall not (i) modify, alter or commercially exploit any End User
Data; or (ii) distribute or sell, rent, lease, license or otherwise make any End User Data available
to any third party (other than the particular End User to whom the End User Data pertains and its
Authorized Users).

10.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 11 -->
(d) Authority to Perform Under this Agreement Each Party shall, at its own expense, obtain and
maintain required certifications, credentials, licences and permits necessary to conduct business in
accordance with this Agreement. CHT shall obtain all necessary licenses, permits, certifications and
credentials to conduct its business. (e) End User Support On and after the launch of the Ehave
Companion Solution, CHT shall, at its own expense, ensure that an adequate number of trained,
capable and qualified technical personnel with sufficient knowledge of the Ehave Companion Solution
are available to provide first line support to assist End Users. If CHT's support personnel are
unable to resolve any trouble tickets from an End User, CHT may escalate the trouble ticket to Ehave
in accordance with the support procedures set out in Schedule "3". On and after the launch of the
Ehave Companion Solution, Ehave shall ensure that an adequate number of trained, capable and
qualified technical personnel with sufficient knowledge of the Ehave Companion Solution are
available to provide support in accordance with the support procedures set out in Schedule "3". (f)
Government Approval If, at any time during the Term, any notification, registration or approval is
required to give legal effect in any applicable jurisdiction to this Agreement or the transactions
contemplated under this Agreement, CHT shall: (i) immediately take whatever steps may be necessary
to properly notify, register or obtain approval; (ii) be responsible for any charges incurred in
connection with notifying, registering or obtaining this approval; and (iii) keep Ehave currently
informed of its efforts regarding this Section 5(f). Ehave is not obligated to provide access to the
Ehave Companion Solution in a particular jurisdiction under this Agreement until CHT has provided
Ehave with satisfactory evidence that: (i) this approval, notification or registration is not
required or that (ii) it has been obtained. At CHT's cost and expense, Ehave shall provide
reasonable assistance and cooperation to CHT as CHT may reasonably request in its efforts to obtain
or provide any such approval, notification or registration, provided that, CHT shall at all times
retain full discretion as to where in the Territory it chooses to market, promote, advertise and/or
sublicense the Ehave Companion Solution. (g) Prohibited Acts Notwithstanding anything to the
contrary in this Agreement, neither CHT nor CHT personnel shall: (i) make any representations,
conditions, warranties, guarantees, indemnities, similar claims or other commitments: A. actually,
apparently or ostensibly on behalf of Ehave, or B. to any End User regarding the Ehave Companion
Solution, which representations, conditions, warranties, guarantees, indemnities, similar claims or
other commitments are additional to or inconsistent with any then-existing representations,
conditions, warranties, guarantees, indemnities, similar claims or other commitments in this
Agreement or any written or electronic documentation provided by Ehave to CHT; or

11.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 12 -->
(ii) engage in any unfair, competitive, misleading or deceptive practices respecting Ehave, Ehave's
Trade-marks or the Ehave Companion Solution, including any product disparagement or
"bait-and-switch" practices. 6. EHAVE COMPANION SOLUTION (a) Provision and Access to Ehave Companion
Solution Once deployed, Ehave shall operate, support and maintain the Ehave Companion Solution in
accordance with the terms of this Agreement, including the Support Procedures set out in Schedule
"3", the Service Level Commitments set out in Schedule "4" and the Security Requirements set out in
Schedule "5". Access to the Ehave Companion Solution may be through a secure connection with the
public Internet. CHT acknowledges and agrees that Ehave is not responsible or liable for any
communication over the public Internet. (b) Security Requirements Ehave shall implement and maintain
those safeguards and controls set out in Schedule "5" to deter and for the detection, prevention and
correction of any unauthorized intrusion, access or use of the Ehave Companion Solution, as well as
to protect against any loss, theft or unauthorized access, use, disclosure, copying, or modification
of End User Data. CHT acknowledges and agrees, and shall obtain such acknowledgement and agreement
from its End Users, that notwithstanding the Security Requirements, such methods and procedures may
not prevent unauthorized electronic intruders to access the Ehave Companion Solution through the
Internet or through other form of electronic communication. If such unauthorized electronic
intruders are able to bypass Ehave's security protocols, firewall and safeguards, such unauthorized
electronic intruder may change, delete or otherwise corrupt the contents and data contained in the
Ehave Server, including any End User Data. Except for the maintenance of appropriate firewall and
safeguards in compliance with the Security Requirements, which are designed to frustrate access from
unauthorized electronic intruders, Ehave shall not be liable to CHT or to any of its End users, and
hereby disclaims responsibility, with respect to any action, destructive or otherwise, by any
unauthorized electronic intruder. (c) Maintenance From time to time, it will be necessary for Ehave
to perform maintenance on the Ehave Companion Solution. Such maintenance includes routine
maintenance to ensure the continued provision of the Ehave Companion Solution or upgrading, updating
or enhancing the Ehave Companion Solution. Ehave shall use its commercially reasonable efforts to
perform such maintenance at such times within the designated maintenance windows set forth in
Schedule "3" to minimize the impact of any downtime of the Ehave Platform to CHT and its End Users.
To the extent Ehave is able, Ehave shall notify CHT at least 48 hours in advance of any scheduled
maintenance by sending an email to the designated CHT Service Manager of the scheduled maintenance
time and the anticipated duration of such maintenance. (d) Changes to Service Ehave may, at any
time, with or without written notice (except in cases where such change may affect the manner in
which the Services are delivered, in which case, Ehave shall use reasonable efforts to provide
advance written notice, but in any event as soon as reasonably possible thereafter) to CHT (i) make
changes to the Ehave Companion Solution that are necessary to comply with applicable safety,
security or other statutory requirements or orders from applicable Governmental Authorities; (ii)
supplement or make changes to its user documentation and to its rules of operations, access
procedures, security and privacy procedures and policies, provided such changes do not materially
adversely affect CHT or its End Users; and (iii) change the components, type and location of the
Ehave Platform, provided that such changes do not adversely affect the performance, features,
functionality or security of the Ehave Companion Solution.

12.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 13 -->
(e) Authentication IDs CHT shall, and shall require its End Users to, control and maintain the
security of all Authentication IDs. As between CHT and Ehave, CHT shall be solely responsible for
all instructions, commitments and other actions or communications taken under any of CHT's
Authentication IDs. CHT shall promptly report to Ehave any errors or irregularities in the Ehave
Companion Solution or the Ehave Platform or any unauthorized use of any part thereof that come to
CHT's attention and inform Ehave immediately if CHT becomes aware that any Authentication ID becomes
known to any third person who is not authorized to possess such password. (f) End User Data CHT
acknowledges and agrees that Ehave: (i) will not be responsible for the accuracy, completeness or
adequacy of any End User Data or the results generated from any End User Data uploaded to and
processed by the Ehave Companion Solution in accordance with the Specifications; (ii) has no control
over any End User Data or the results therefrom; (iii) does not purport to monitor End User Data;
and (iv) shall not be responsible to back up or maintain any back up of the End User Data or portion
thereof. (g) Viruses If Ehave, in its absolute discretion, forms the view that any End User Data or
any other information or files uploaded by CHT or any of its End User and their Authorized Users
contains or includes a Virus or is reasonably considered Objectionable Content, Ehave may remove
such End User Data, information or file from the Ehave Companion Solution and take such other action
as Ehave deems necessary to protect the integrity and operation of the Ehave Companion Solution. Any
reasonable costs associated with such removal may be charged by Ehave to CHT. Ehave shall notify CHT
of its actions under this Section 6(g) as soon as reasonably possible. 7. ROYALTIES AND PAYMENT (a)
Royalties The Royalties and payment terms are as set out in Schedule "6". The Royalties do not
include applicable taxes. CHT agrees to pay the Royalties and applicable taxes in accordance with
the payment terms as set out in Schedule "6". (b) Taxes: CHT shall pay any and all applicable taxes,
however designated or incurred, which are payable by it pursuant to Applicable Law as a result of or
otherwise in connection with the transactions contemplated in this Agreement including, without
limitation, federal, provincial and local, excise, sales, use, goods and services, harmonized, value
added and any similar taxes, except for any taxes based on Ehave's net income. (c) Interest on Late
Payments: Where CHT fails to pay any amount in accordance with the payment terms set out in Schedule
"6", Ehave shall have the right, in addition to any other rights or remedies available to it, to
charge, and CHT shall pay, interest on such overdue amounts at the rate of 1% per month calculated
daily, compounded monthly (12.68% per annum) both before and after any court judgement in respect of
the same from the date such payment was due.

13.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 14 -->
8. AUDIT RIGHTS (a) Ehave Right to Audit CHT will provide Ehave and its representatives, auditors
and inspectors ("Auditors") upon ten (10) Business Days prior written notice with reasonable access,
during business hours, to all facilities, systems and assets used by CHT, to CHT personnel and
subcontractors and to all relevant CHT books and records, in each case, to the extent relevant to
this Agreement, in order to conduct appropriate audits, examinations and inspections ("Audits") to:
(i) verify compliance with the requirements set out in this Agreement; and (ii) verify the Royalty
calculations. (b) Principles Regarding Audits CHT shall provide to Ehave and its Auditors any
assistance they may reasonably require to conduct such Audits. Audits may be conducted once a
calendar year, provided that the foregoing limit shall not apply where an audit discovered an
overcharge of 5% or more, in which case, Ehave may conduct another audit sooner. No period shall be
audited more than once. Costs incurred by Ehave in connection with any audit or inspection conducted
shall be borne by Ehave. Notwithstanding the foregoing, if an Audit reveals that CHT underpaid Ehave
for any Royalties hereunder, by more than five percent (5%) of the total Royalties paid during the
period being audited, CHT shall promptly reimburse Ehave for all reasonable third party expenses
incurred by Ehave in connection with such Audit. In all cases CHT shall promptly pay Ehave in full
for any underpayments revealed by an Audit. All information obtained by Ehave and its Auditors
during any such Audit shall be kept confidential and shall be considered CHT's Confidential
Information. Ehave shall impose confidentiality obligations on its Auditors that are substantially
similar to those under Section 13 and shall be responsible for any breach of confidentiality by its
Auditors. (c) Records CHT shall keep detailed records and books of account with supporting vouchers,
invoices and other documentation showing all expenditures, charges and related calculations of
whatsoever nature made by it in the performance of its obligations under this Agreement. CHT shall
retain such records for the greater of: (i) three (3) years; or (ii) the period required by
Applicable Laws. (d) Security Audit On an annual basis, Ehave shall conduct and provide CHT the
results of an audit conducted in accordance with the Statement on Standards for Attestation
Engagements (SSAE) No. 18, Service Organization Control (SOC) 2 Report type audit or similar audits
in respect of its operations. Ehave shall also provide CHT written notice and detail of any
deficiencies that Ehave's auditors (whether internal or external) found through the conduct of such
audits and the remediation efforts that Ehave shall undergo to rectify such deficiencies. Ehave
shall promptly rectify any deficiencies identified that may materially and adversely impact the
Ehave Companion Solution or End User Data, and shall provide CHT with such information as CHT may
reasonably request from time to time with respect to its security controls including any remediation
efforts undertaken to rectify any deficiencies. 9. TERM This term of this Agreement and the rights
and obligations of the Parties hereto shall commence as of the Effective Date and shall continue in
perpetuity (the "Term"), unless terminated earlier in accordance with the provisions contained
herein.

14.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 15 -->
10. SUSPENSION AND TERMINATION (a) Suspension of Services: Subject to the provisions of this
Section, in the event that CHT does not pay the Royalties or any portion thereof, when due, Ehave
may immediately suspend CHT's and each of its End Users' right to access and use the Ehave Companion
Solution. However, Ehave shall not suspend CHT's or its End Users' right to access and use the Ehave
Companion Solution or any End User Data by reason of CHT's good faith withholding of any payment or
amount, or in the event of any payment dispute between the parties arising under or concerning this
Agreement, in each case, unless and until such dispute is resolved pursuant to Section 19, provided
that CHT shall have a period of five (5) Business Days to pay any amount agreed to in settlement or
determined by arbitration pursuant to Section 19 to be payable by it. (b) CHT's Right to Terminate:
Subject to Sections 10(e) and 10(g), CHT may terminate this Agreement and the rights granted
hereunder, in whole or in part, without prejudice to enforcement of any other legal right or remedy
(including any express termination right set forth elsewhere in this Agreement), immediately upon
giving written notice of such termination if Ehave: (i) breaches any material provision of this
Agreement and such breach continues for a period of twenty (20) Business Days after delivery of a
written notice by CHT requiring Ehave to correct such failure; or (ii) becomes or is adjudicated
insolvent or bankrupt, admits in writing its inability to pay its debts as they mature, or makes an
assignment for the benefit of creditors; or Ehave applies for or consents to the appointment of any
receiver, trustee or similar officer for it or for all or any substantial part of its property; or
such receiver, trustee or similar officer is appointed without the consent of Ehave; or Ehave
institutes any bankruptcy, insolvency, reorganization, moratorium, arrangement, readjustment or
debt, dissolution, liquidation or similar proceeding relating to it under the laws of any
jurisdiction, or any such proceeding is instituted against Ehave and is not dismissed within sixty
(60) Business Days; or any judgment, writ, warrant or attachment or execution of similar process is
issued or levied against a substantial part of Ehave's property and remains unsatisfied for sixty
(60) Business Days. In addition, CHT may terminate this Agreement and the rights granted hereunder,
in whole or in part, and without prejudice to enforcement of any other legal right or remedy
(including any express termination right set forth elsewhere in this Agreement), at any time without
cause, by providing at least thirty (30) Business Days prior written notice to Ehave, but subject to
payment of a termination fee equal to an amount set out in Schedule 6. (c) Ehave's Right to
Terminate: Subject to Sections 10(e) and 10(g), Ehave may terminate this Agreement and the rights
granted hereunder without prejudice to enforcement of any other legal right or remedy, immediately
upon giving written notice of such termination if CHT: (i) fails to pay in full any sum owing by it
under this Agreement by the due date thereof (other than any sum the payment of which is disputed by
CHT in good faith and withheld pending resolution of such dispute in accordance with Section 19) and
such failure continues for a period of ten (10) Business Days after delivery of a written notice by
Ehave requiring CHT to correct such failure;

15.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 16 -->
(ii) breaches any other material provision of this Agreement and such breach continues for a period
of twenty (20) Business Days after delivery of a written notice by Ehave requiring CHT to correct
such failure; or (iii) becomes or is adjudicated insolvent or bankrupt, admits in writing its
inability to pay its debts as they mature, or makes an assignment for the benefit of creditors; or
CHT applies for or consents to the appointment of any receiver, trustee or similar officer for it or
for all or any substantial part of its property; or such receiver, trustee or similar officer is
appointed without the consent of CHT; or CHT institutes any bankruptcy, insolvency, reorganization,
moratorium, arrangement, readjustment or debt, dissolution, liquidation or similar proceeding
relating to it under the laws of any jurisdiction, or any such proceeding is instituted against CHT
and is not dismissed within sixty (60) Business Days; or any judgment, writ, warrant or attachment
or execution of similar process is issued or levied against a substantial part of CHT's property and
remains unsatisfied for sixty (60) Business Days. (d) Waiver: The waiver by either Party of a breach
or default of any provision of this Agreement by the other Party shall not be effective unless in
writing and shall not be construed as a waiver of any succeeding breach of the same or of any other
provision. Nor shall any delay or omission on the part of either Party to exercise or avail itself
of any right, power or privilege by such Party shall constitute a waiver. (e) Effect of Termination:
Upon the termination of this Agreement for any reason, subject to and without limiting the
provisions of Section 12: (i) the Parties shall implement the Transition-Out Services pursuant to
Section 10(f); (ii) at the end of the Transition-out Period (or earlier upon CHT's request) Ehave
shall terminate and invalidate any Authentication IDs associated with CHT and any of its End Users;
(iii) Ehave shall, but not earlier than twenty (20) Business Days after the later of termination or
expiration of this Agreement or the Transition-out Period, destroy any copies of the End User Data
contained in the Ehave Companion Solution and certify in writing to CHT that it has done so; (iv)
CHT shall pay to Ehave the full amount of all Royalties payable hereunder as of the date of
termination, if any, whether already invoiced or not (including any amounts due as late payment
charges), and any other monies owing to Ehave hereunder; and (v) each Party will return to the other
Party, or at the other Party's written request, destroy, in a secure manner all Confidential
Information of the other Party which is then in its possession or control and certify in writing
that it has done so. CHT acknowledges and agrees if any End User fails to download its End User Data
from the Ehave Companion Solution in a timely manner (i.e. on or before the later of termination or
expiry of this Agreement and the Transition-out Period), it may not have access to such information
or such information may be destroyed by Ehave in accordance with the terms of this Section 10(e).
Subject to Section 10(f), it is CHT's and each End User's responsibility to download and obtain all
the End User Data on or prior to the termination of this Agreement or expiry of the Transition-out
Period (whichever is later). Ehave shall have no responsibility for maintaining or providing to CHT
or to any of its End Users the End User Data or any portion thereof, or any liability to CHT or any
End User for destroying End User Data, in either case, from and after the twentieth (20th) Business
Day after the termination or expiration of this Agreement or the Transition-out Period, whichever
later.

16.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 17 -->
(f) Transition Assistance: Without limiting the provisions of Section 11, commencing on the delivery
of any notice of termination of this Agreement, and continuing through the effective date of
termination and for a period of sixty (60) Business Days thereafter (the "Transition-out Period"),
Ehave will, to the extent requested by CHT, provide to CHT (or at CHT's request to CHT's End User)
such reasonable cooperation, assistance and services to facilitate the orderly wind down, transition
and migration and transfer of the End User Data from Ehave to CHT (the "Transition-out Services").
(g) Survival of Covenants: Notwithstanding the termination or expiration of this Agreement for any
reason, the covenants set out in this Section 10(g) and in Sections 7(c), 10(e), 10(f), 11, 12, 13,
14(c), 15, 16, 17, 19, 20(a) and those provisions set out in Section 1 as necessary to interpret the
foregoing provisions, of this Agreement shall survive any such termination or expiration. 11.
OWNERSHIP (a) Ehave's Ownership CHT acknowledges and agrees that, as between CHT and Ehave, Ehave
owns all worldwide right, title and interest, including all Intellectual Property Rights, in and to
the Ehave Companion Solution, including any developments, enhancements or customizations made as a
result of Section 3 and any modifications, enhancements, upgrades, updates or Customization
subsequent to the development and implementation in accordance with Section 3, excluding, however,
any CHT Developments. CHT does not acquire any rights, title or ownership interests of any kind
whatsoever, express or implied, in any of the foregoing other than the licenses granted herein. (b)
CHT's Ownership Ehave acknowledges and agrees that, as between Ehave and CHT, CHT owns all worldwide
right, title and interest, including all Intellectual Property Rights, in and to the CHT
Developments. Ehave does not acquire any rights, title or ownership interests of any kind
whatsoever, express or implied, in any of the foregoing other than the licenses granted herein.
Further, as between CHT and Ehave, (i) CHT (or its End User) is and will remain the sole and
exclusive owner of all right, title, and interest in and to End User Data, including all
Intellectual Property Rights therein and/or relating thereto, subject only to the limited license
granted in Section 5(c), and (ii) End User Data and CHT Developments are and will be the
Confidential Information of CHT. CHT and End Users shall at all times, including in the event of
termination of this Agreement and for a period thereafter as set out in Section 10(e), have access
to their respective End User Data and the ability to download and/or export their End User Data out
of the Ehave Companion Solution.

17.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 18 -->
12. ESCROW (a) Escrow Agreement (i) Concurrently with execution of this Agreement or, at CHT's
option, as soon as practicable after the Effective Date but in no event later than CHT's acceptance
of and the launch of the Ehave Companion Solution, CHT and Ehave shall enter into a Source Code
Escrow Agreement with a reputable software escrow agent mutually acceptable to the Parties ("Escrow
Agent"), in or substantially in the form attached hereto as Schedule "7", or otherwise in a form
acceptable to the Parties, acting reasonably, and to the Escrow Agent (the "Escrow Agreement"),
providing for the release of the Source Code for the Software, as modified pursuant to Section 3 and
all necessary programming documentation, utilities and tools used by Ehave to maintain the Software
and to compile the source code into object code (excluding third party utilities and tools licensed
by Ehave for which Ehave has not been granted the right to sublicense or otherwise make available
such utilities and tools to third parties without additional charge, but including such information
as necessary for CHT to obtain licenses to and obtain such third party utilities and tools), all in
its then-existing form, to CHT, in the certain circumstances expressly stated in Section 12(b). The
Escrow Agreement shall provide that the Software, including the Source Code and object code,
Specifications and related documentation are and shall be deemed to be "intellectual property" and
the rights under the Escrow Agreement and the license granted under Section 12(a)(iii) are deemed to
be "rights to use intellectual property" for purposes of section 65.11(7) of the BIA and section
32(6) of the CCAA. (ii) Upon release of the Source Code by the Escrow Agent to CHT pursuant to the
terms and conditions of the Escrow Agreement, Ehave hereby warrants that such Source Code and other
materials are and will be the then current version of the Software as used by CHT in its provision
to End Users of the eEhave Companion Solution under the Subscription Agreements and that Ehave shall
throughout the Term keep the Source Code so deposited with the Escrow Agent current by periodically
submitting material updates to the Escrow Agent from time to time, as necessary. Save and except for
express warranties specified in this Agreement and the Escrow Agreement, Ehave specifically
disclaims all other warranties, express or implied, including, without limitation, any warranty of
merchantability and fitness for a particular purpose. (iii) In connection with the exercise of CHT's
rights under the Escrow Agreement, Ehave hereby grants to CHT a non- exclusive, non-transferable
(except as set forth in Section 20(f)), right and license to use and copy the materials deposited
with the Escrow Agent, including the Source Code, its Specifications and documentation, and any
resulting corrections, repairs, translations, enhancements, and other derivative works and
improvements made by CHT, for the sole purposes of providing to CHT the ability to operate, support
and maintain, the Ehave Companion Solution for its End Users from time to time, until such time that
CHT is able to migrate off the Ehave Companion Solution, but in any event not exceeding twelve
months from the date of release of the materials from escrow. CHT may use third parties to perform
its foregoing rights, provided that any such third parties are not competitors of Ehave and shall be
subject to confidentiality obligations. CHT expressly agrees, however, that CHT shall not exercise
any of the foregoing right and license unless and until CHT obtains such Source Code from the Escrow
Agent. CHT's obligations with respect to confidentiality and use of the Source Code shall be
equivalent to CHT's obligations set forth in Section 13 of this Agreement. Notwithstanding any
release of the Source Code pursuant to the provisions hereof, Ehave shall retain sole ownership of
and other proprietary rights with respect to the Source Code (including any Source Code relating to
any modifications made by CHT to the Source Code, all of which shall be owned by Ehave). CHT shall
be responsible for all of the Escrow Agent's fees and charges under the Escrow Agreement.

18.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 19 -->
(b) Release Conditions The parties acknowledge and agree that a "Release Condition" for purposes of
the Escrow Agreement shall be deemed to mean any one or more of the following listed events (in
addition to any other event specified as a release condition under the Escrow Agreement): (i) Ehave
makes a general assignment for the benefit of creditors; (ii) Ehave voluntarily institutes any
bankruptcy, insolvency, reorganization, moratorium, arrangement, readjustment or debt, dissolution,
liquidation or similar proceeding relating to it under the laws of any jurisdiction, or any such
proceeding is instituted against Ehave and is not dismissed within sixty (60) Business Days; or any
judgment, writ, warrant or attachment or execution of similar process is issued or levied against a
substantial part of Ehave's property and remains unsatisfied for sixty (60) Business Days; or Ehave
applies for or consents to the appointment of any receiver, trustee or similar officer for it or for
all or any substantial part of its property; or such receiver, trustee or similar officer is
appointed without the consent of Ehave; (iii) Ehave consents to the filing of a petition of
bankruptcy against it; (iv) a petition of bankruptcy is filed against Ehave which is not discharged
within sixty (60) days; (v) Ehave becomes or is adjudicated by a court of competent jurisdiction as
being bankrupt or insolvent or admits in writing its inability to pay its debts as they mature;
Ehave ceases doing business as a going concern; (vi) Ehave undergoes a change of control or is a
party to a merger or amalgamation; (vii) Ehave takes steps to dissolve, liquidate, wind up or
otherwise terminate its existence; (viii) Ehave has terminated its provision of or ceased to provide
the Ehave Companion Solution or support services for a continuing period of fifteen (15) Business
Days or more, except pursuant to the termination of this Agreement by Ehave in accordance with its
rights contained hrein. (c) Effect of Bankruptcy All of the Software, including the Source Code and
object code, the Specifications and related documentation, and all other escrow deposit materials
constitute "intellectual property" and all rights and licenses granted by Ehave to CHT under this
Agreement or the Escrow Agreement (which is supplementary to this Agreement) are and shall be deemed
to be licenses and "rights to use intellectual property" by CHT for the purposes of and as such
terms are used and interpreted under section 65.11(7) of the BIA and section 32(6) of the CCAA. CHT
shall have the right to exercise all rights and elections under the BIA and CCAA and all other
applicable bankruptcy, insolvency and similar laws with respect to this Agreement, the Escrow
Agreement and the subject matter hereof and thereof. Without limiting the generality of the
foregoing, if Ehave or its estate becomes subject to any bankruptcy or similar proceeding subject to
CHT's rights of election, all rights and licenses granted to CHT under this Agreement and the Escrow
Agreement will continue subject to the respective terms and conditions hereof and thereof, and will
not be affected, even by Ehave's rejection of this Agreement or the Escrow Agreement.

19.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 20 -->
13. CONFIDENTIALITY (a) Obligation: Each Party acknowledges that all Confidential Information
consists of confidential and proprietary information of the disclosing Party. Each Party shall, and
shall cause its employees, agents and contractors to hold Confidential Information of the other
Party in confidence, and shall use the same degree of care by instruction, agreement or otherwise,
to maintain the confidentiality of the other Party's Confidential Information that it uses to
maintain the confidentiality of its own Confidential Information, but with at least a reasonable
degree of care commensurate with the nature and importance of such Confidential Information. Each
Party agrees not to make use of Confidential Information other than for the exercise of rights or
the performance of obligations under this Agreement (and the Source Code Escrow Agreement), and not
to release, disclose, communicate it or make it available to any third person other than employees,
agents and contractors of the Party who reasonably need to know it in connection with the exercise
of rights or the performance of obligations by such Party under this Agreement (and the Source Code
Escrow Agreement) and who are bound by confidentiality and restricted use obligations at least as
protective of the Confidential Information as those set forth herein. Each Party agrees to notify
the other Party in writing promptly of any loss or unauthorized disclosure or use of such other
Party's Confidential Information and cooperate with such other Party to protect the confidentiality
and ownership of all Intellectual Property Rights and other rights therein. (b) Subpoena: In the
event that any Party receives a request to disclose all or any part of the Confidential Information
of the other Party under the terms of a valid and effective subpoena or order issued by a court of
competent jurisdiction or by a Governmental Authority, such Party agrees to (i) immediately notify
the other Party of the existence, terms and circumstances surrounding such a request; (ii) consult
with the other Party on the advisability of taking legally available steps to resist or narrow such
request; and (iii) if disclosure of such Confidential Information is required, exercise its
commercially reasonable efforts to obtain, and/or assist the other Party to obtain, at the other
Party's expense, an order or other reliable assurance that confidential treatment will be accorded
to such portion of the disclosed Confidential Information which the other Party so designates. (c)
Injunctive Relief: Each Party acknowledges and agrees that any unauthorized use or disclosure by it
of any of the other Party's Confidential Information, in whole or part, will cause irreparable
damage to the disclosing Party, that monetary damages would be an inadequate remedy and that the
amount of such damages would be extremely difficult to measure. The receiving Party agrees that the
disclosing Party shall be entitled to seek temporary and permanent injunctive relief to restrain the
receiving Party from any unauthorized disclosure or use. Nothing in this Agreement shall be
construed as preventing the disclosing Party from pursuing any and all remedies available to it for
a breach or threatened breach of a covenant made in this Section 13, including the recovery of
monetary damages from the receiving Party.

20.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 21 -->
14. REPRESENTATIONS, WARRANTIES AND DISCLAIMERS (a) Mutual Representations of the Parties: Each
Party represents to the other that: (i) it is a company duly organized, validly existing and in good
standing under the laws of its incorporation and it has full power and authority to enter into this
Agreement and to perform each and every covenant and agreement herein contained; (ii) this Agreement
has been duly authorized, executed and delivered by it and constitutes a valid, binding and legally
enforceable agreement of it; (iii) the execution and delivery of this Agreement, and the performance
of the covenants and agreements herein contained, are not, in any manner or to any extent, limited
or restricted by, and are not in conflict with, any commercial arrangements, obligations, contract,
agreement or instrument to which it is either bound or subject; and (iv) the execution and delivery
of this Agreement and the performance of its covenants and agreements herein contained shall comply
in all respects with all laws and regulations to which it or its business is subject. (b) Additional
representations of Ehave: Ehave represents to CHT that Ehave possesses the knowledge, skill and
experience necessary for the provision and completion of the Ehave Companion Solution in accordance
with the terms of this Agreement. (c) Warranties Ehave warrants that for the duration of the Term,
(i) the Ehave Companion Solution will substantially conform to and operate in accordance with, and
have the functions and features set out in, the Specifications, and any related documentation
provided by Ehave, and any such documentation shall be complete and accurate in all material
respects; and the Ehave Companion Solution will not contain any material undocumented feature; (ii)
Ehave has implemented and will maintain industry standard protection for the detection, protection
and removal of Viruses; (iii) Ehave will perform all services under this Agreement in a timely,
professional and workmanlike manner using personnel of required skill, experience and
qualifications, and will devote adequate resources to meet its obligations (including the Service
Level Commitments and its support obligations) hereunder; (iv) it has or will have all necessary
right, power and authority, including all licenses and Intellectual Property Rights required, to
provide and operate the Ehave Companion Solution and to grant all rights and licenses granted or
required to be granted by it under this Agreement; and (v) Ehave is not aware of any infringement or
misappropriation claims by any third party in relation to the Ehave Companion Solution.

21.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 22 -->
(d) Exclusion of Other Warranties: Except as otherwise expressly stated in this Agreement, there are
no express or implied warranties or conditions in relation to the Ehave Companion Solution that are
the subject matter of this Agreement, including implied warranties or conditions of merchantable
quality, fitness for a particular purpose, or non-infringement, or that the Ehave Companion Solution
will meet CHT's or any End Users' needs or will be available for use at any particular time or will
be error free. Under no circumstances will Ehave be liable for the results of CHT or any of its End
Users' misuse of the Ehave Companion Solution, including any use contrary to Applicable Law. 15.
INSURANCE (a) Required Insurance: Both Parties shall, at all times during the currency of this
Agreement and for a period of one (1) year after the termination or expiration of this Agreement,
maintain the following policies of insurance in effect: (i) a comprehensive general liability
insurance policy, with minimum coverage of $1,000,000 per occurrence and in the annual aggregate for
product liability and completed operations, covering bodily and personal injury, including death,
and property damage, including loss of use; and (ii) an information and network technology blended
liability insurance policy with an insured limit of at least $1,000,000 in the aggregate. (b)
Evidence of Insurance: Upon the execution of this Agreement or at any time at a Party's request
during the term of this Agreement, the other Party shall provide the requesting Party with evidence
of the aforementioned insurance coverage in the form of a certificate of insurance acceptable to the
requesting Party. In the event of any material change or cancellation of the required insurance
policies, the applicable Party will provide the other Party with thirty (30) calendar days' prior
written notice and will promptly replace such insurance policy in accordance with this Section 15,
without lapse in coverage. 16. INDEMNITIES (a) Intellectual Property Indemnity Ehave shall defend at
its own expense any claim, proceeding or suit (a "Claim") brought against CHT and/or any of its
directors, officers, employees, agents, subcontractors, affiliates and/or End Users (collectively,
the "CHT Indemnified Parties") to the extent such Claim alleges that the Ehave Companion Solution
furnished hereunder or the use thereof by CHT or its End Users as authorized hereunder or in any
Subscription Agreement infringes any copyright, Canadian patent, or registered trademark of a third
person, and will indemnify and hold harmless the CHT Indemnified Parties from and against any and
all related liabilities, costs, losses, damages and expenses (including reasonable legal fees)
arising out of or in connection with or relating to any such Claim, provided that: (i) Ehave is
given prompt written notice of the Claim or of any allegations or circumstances known to CHT which
could reasonably result in a Claim; (ii) Ehave is given all reasonable information and assistance
from CHT, at Ehave's expense, which Ehave may require to defend the Claim;

22.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 23 -->
(iii) Ehave is given sole control of the defence of the Claim, and all negotiations for the
settlement or compromise thereof, provided that Ehave shall promptly engage competent counsel and
initiate defence in a professional manner and CHT may observe or participate in such proceedings
with its own counsel at its own expense; and (iv) the alleged infringement does not result from any
non-permitted uses, alterations, modifications or enhancements carried out by CHT, any End User or
on its or their behalf by a third person (other than any Ehave personnel or contractors). If such
Claim has occurred, or in Ehave's opinion is likely to occur, without limiting Ehave's obligation to
defend and indemnify the CHT Indemnified Parties as aforesaid, Ehave may, at its option and expense,
either procure for CHT the right to continue using the Ehave Companion Solution in accordance with
this Agreement or modify or replace the same so that it becomes non-infringing without loss of
functionality, or if none of the foregoing alternatives is reasonably available and at Ehave's
discretion, discontinue the use of the Ehave Companion Solution on not less than sixty (60) Business
Days' prior written notice to CHT and its End Users. The foregoing states the entire obligations of
Ehave with respect to any infringement of Intellectual Property Rights of any third Person. (b) CHT'
Indemnity CHT shall defend at its own expense any Claim brought against Ehave, its affiliates,
directors, officers, employees and agents, to the extent such Claim: (i) alleges, directly or
indirectly, that any End User Data infringes any Canadian copyright, patent or registered trademark
of a third person; alleges, directly or indirectly, that the End User Data contains any
Objectionable Content; (ii) arises through a breach by CHT of its obligations set out in Section
5(g); or (iii) is in relation to any of its End Users' use of the Ehave Companion Solution,
including contrary to Applicable Law, except however to the extent as Ehave has indemnified CHT
pursuant to Section 16(a); provided that CHT is given: (i) prompt written notice of the Claim or of
any allegations or circumstances known to Ehave which could result in a Claim; (ii) all reasonable
information and assistance from Ehave, at CHT's expense, which CHT may require to defend the Claim;
and (iii) sole control of the defence of the Claim, and all negotiations for its settlement or
compromise thereof. 17. LIMITATION OF LIABILITY (a) Consequential Damages Subject to Section 17(c),
in no event shall either Party be liable to the other for any consequential, incidental, exemplary
or punitive damages even if advised in advance of the possibility of such damages. Further, subject
to Section 17(c), neither Party shall not be liable to the other Party for any lost revenue, lost
profit or lost savings. (b) Limitation of Direct Damages Subject to Section 17(c), in no event shall
either Party's liability under this Agreement exceed the aggregate of all amounts paid under this
Agreement and amounts that have accrued but not yet been paid in the twelve (12) months preceding
the event giving rise to the claim.

23.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 24 -->
(c) Exceptions to Limitations Notwithstanding Sections 17(a) and 17(b), neither Party excludes or
limits any liability for: (i) personal injury or death to the extent that such injury or death
results from the negligence or wilful misconduct of a Party or its employees or subcontractors; (ii)
fraud, fraudulent misrepresentation or fraudulent concealment; (iii) the Party's obligations set out
in Sections 2(c), 5(b), 5(c), 6(b), 11, 13 or 16; (iv) CHT's payment obligations under Section 7; or
(v) willful misconduct or gross negligence. (d) Application of Limitations and Exclusions The
limitations and exclusions set out in this Section shall apply whether a claim, demand or action is
based in contract, tort (including negligence), or otherwise. 18. FORCE MAJEURE Except for any
obligation to make payments, any delay or failure of either Party to perform its obligations under
this Agreement or under any Schedule attached hereto shall be excused if, and to the extent, that
the delay or failure is caused by an event or occurrence beyond the reasonable control of the Party
and without its fault or negligence and that could not have been prevented or avoided by the
exercise of reasonable due diligence, such as, by way of example and not by way of limitation, acts
of God, action by any Governmental Authority (whether valid or invalid), fires, flood, wind storms,
explosions, riots, natural disasters, wars, terrorist acts, sabotage, labour problems (including
lock-outs, strikes and slow downs, except for any labour problems of the Party claiming a force
majeure event), or court order or injunction; provided that written notice of delay (including
anticipated duration of the delay) shall be given by the affected Party to the other Party within
two (2) Business Days of the affected Party first becoming aware of such event and the affected
Party shall use diligent efforts to end the failure or delay and minimize the effects of such force
majeure event. In the event that the force majeure event lasts for fifteen (15) Business Days or
longer, either Party shall have the option to terminate this Agreement upon written notice to the
other without liability. 19. DISPUTE RESOLUTION (a) Discussions: Each Party agrees to utilize all
reasonable efforts to resolve any dispute, whether arising during the term of this Agreement or at
any time after the expiration of termination of this Agreement, which touches upon the validity,
construction, meaning, performance or effect of this Agreement or the rights and liabilities of the
Parties or any matter arising out of or connected with this Agreement, promptly and in an amicable
and good faith manner by negotiations between the Parties.

24.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 25 -->
(b) Mediation: Either Party may submit a dispute to mediation by providing written notice to the
other Party. In the mediation process, the Parties will try to resolve their differences voluntarily
with the aid of a single, impartial mediator, who shall attempt to facilitate negotiations. The
mediator shall be selected by agreement of the Parties. If the Parties cannot otherwise agree on a
mediator within five (5) Business Days, a single mediator shall be designated by the ADR Institute
of Canada, Inc. or any successor organization ("ADR") at the request of a Party. Any mediator so
designated must not have a conflict of interest with respect to any Party. The mediation shall be
conducted as specified by the mediator and agreed upon by the Parties. The Parties agree to discuss
their differences in good faith and to attempt, with the assistance of the mediator, to reach an
amicable resolution of the dispute. The mediation shall be treated as a settlement discussion and
therefore shall be confidential. The mediator may not testify for either Party in any later
proceeding relating to the dispute. No recording or transcript shall be made of the mediation
proceedings. Each Party shall bear its own costs and legal fees in the mediation. The Parties shall
share the fees and expenses of the mediator equally. (c) Arbitration: Subject to Section 19(d), any
dispute that has proceeded through mediation established in Section 19(b) without resolution may be
submitted to arbitration. Any arbitration conducted pursuant to this Agreement shall take place in
the City of Toronto, Ontario. The costs of the arbitration shall be borne equally by the Parties or
as may be specified in the arbitrator's decision. The provisions of the Arbitration Act of Ontario,
as amended, except as otherwise provided in this Agreement shall govern the arbitration process. The
Parties agree to exclude the appeal provisions of the Arbitration Act, as may be amended from time
to time, and in particular, section 45 thereof. The determination arising out of the arbitration
process shall be final and binding upon the Parties to the arbitration. (d) Exceptions to
Arbitration: The following matters shall be excluded from arbitration under this Agreement: (i) any
disputes involving third Persons; (ii) breach of confidentiality by either Party; and (iii)
intellectual property claims, whether initiated by third Persons or by one of the Parties to this
Agreement. 20. MISCELLANEOUS (a) Notice: Every notice or other communication hereunder shall be
deemed to have been duly given and made if in writing and if served by personal delivery upon the
Party for whom it is intended, if delivered by registered or certified mail, return receipt
requested, or by a national courier service, or if sent by fax (receipt of which is confirmed) to
the Person at the address set forth below, or such other address as may be designated in writing
hereafter, in the same manner, by such Person: To: Ehave To: CHT 277 Lakeshore Road E 1 Scarsdale
Road Suite 203 Oakville, Ontario Toronto, Ontario Canada Canada L6J 6J3 M3B 2R2 Attention: Prateek
Dwivedi, President & CEO Attention: Scott Woodrow, CEO Any such notification shall be deemed
delivered (a) upon receipt, if delivered personally, (b) on the next Business Day, if sent by
national courier service for next Business Day delivery or if sent by fax. Any correctly addressed
notice or last known address of the other Party that is relied on herein that is refused, unclaimed,
or undeliverable because of an act or omission of the Party to be notified as provided herein shall
be deemed effective as of the first date that said notice was refused, unclaimed, or deemed
undeliverable by the postal authorities by mail, through messenger or commercial express delivery
services.

25.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 26 -->
(b) Modifications: The Parties may modify this Agreement only upon written agreement. (c) Further
Assurances: Each Party shall take such action (including, but not limited to, the execution,
acknowledgement and delivery of documents) as may reasonably be requested by the other Party for the
implementation or continuing performance of this Agreement. (d) Relationship: The Parties are
independent contractors and no other relationship is intended. Nothing herein shall be deemed to
constitute either Party as an agent, representative or employee of the other Party, or both Parties
as joint venturers or partners for any purpose. Neither Party shall act in a manner that expresses
or implies a relationship other than that of independent contractor. Each Party shall act solely as
an independent contractor and shall not be responsible for the acts or omissions of the other Party.
Neither Party will have the authority or right to represent nor obligate the other Party in any way
except as expressly authorized by this Agreement. (e) Enurement: This Agreement shall enure to the
benefit of and be binding upon each of the Parties hereto and their permitted successors and
assigns. (f) No Assignment: Neither this Agreement nor any rights or obligations hereunder shall be
assignable by a Party without the prior written consent of the other Party, provided that either
Party shall have the right, on notice to but without the other Party's consent, to assign this
Agreement and its rights and obligations contained herein, to an affiliate or to a third party who
is not a competitor of the other Party in connection with a sale of all or substantially all of the
assigning Party's business or assets relating to this Agreement. (g) Counterparts and Facsimile
Execution and Delivery: This Agreement may be executed in counterparts, each of which shall be
deemed to be an original and both of which together shall constitute one and the same instrument. To
evidence its execution of an original counterpart of this Agreement, a Party may send a copy of its
original signature on the execution page hereof to the other Party by facsimile transmission or
email and such transmission shall constitute delivery of an executed copy of this Agreement to the
receiving Party as of the date of receipt thereof by the receiving Party or such other date as may
be specified by the sending Party as part of such transmission. (h) Language: It is the Parties
desire and agreement that this Agreement and all Exhibits and associated documentation be drafted in
English. Les Parties conviennent que la présente convention et tous les documents s'y rattachant,
soient rédigés en anglais.

26.

Source: EHAVE, INC., 20-F, 5/15/2019
<!-- page 27 -->
IN WITNESS WHEREOF, each Party hereto has caused this Agreement to be duly executed as of the date
first written above by an officer authorized in that behalf. EHAVE, INC. COMPANION HEALTHCARE
TECHNOLOGIES CORP per: /s/ Prateek Dwivedi per: /s/ Scott Woodrow Name: Prateek Dwivedi Name: Scott
Woodrow Title: Chief Executive Officer Title: Chief Executive Officer

27.

Source: EHAVE, INC., 20-F, 5/15/2019
