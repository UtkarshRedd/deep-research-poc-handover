<!-- page 1 -->
# SERVICE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2020-04-01 |
| Parties | Theravance Biopharma UK Limited ("Employer"); Brett Haumann ("Executive") |
| Source | CUAD v1 / THERAVANCEBIOPHARMA,INC_05_08_2020-EX-10.2-SERVICE AGREEMENT |

Exhibit 10.2

STRICTLY PRIVATE AND CONFIDENTIAL

1 April, 2020

THERAVANCE BIOPHARMA UK LIMITED and BRETT HAUMANN

SERVICE AGREEMENT
<!-- page 2 -->
THIS AGREEMENT is entered into between the parties on 1 April, 2020.

PARTIES (1) Theravance Biopharma UK Limited is a company registered in the United Kingdom and whose
registered office is at 12 New Fetter Lane, London, United Kingdom, EC4A 1JP (the "Employer"); and
(2) Brett Haumann of [address removed] (the "Executive").

AGREED TERMS 1. Definitions 1.1 The following terms shall have the following meanings unless the
context requires otherwise: "Capacity" means as agent, consultant, director, employee, owner,
partner, shareholder or otherwise;

"Commencement Date" means 1 April 2020;

"Confidential Information" means trade secrets, knowhow and information (whether or not recorded in
documentary form, or stored on any magnetic or optical disk or memory) relating to the business,
products, affairs and finances of any Group Company or any of their suppliers, customers, agents,
shareholders or management, including (but not limited to): (a) business, financial or strategic
information or plans; (b) technical data and know-how; (c) litigation, potential litigation or legal
advice; (d) employment terms or pay of the Executive or others; (e) commercial terms with business
partners; (f) products or services in the course of development; (g) processes or know-how; (h)
details of any joint ventures, which (in each case) the Executive creates, develops, learns,
receives or obtains in connection with the Executive's employment before or after the date of this
agreement, whether or not such information is marked confidential;

"Copies" means copies or records of any Confidential Information in whatever form (including,
without limitation, in written, oral, visual or electronic form or on any magnetic or optical disk
or memory and wherever located) including, without limitation, extracts, analysis, studies, plans,
compilations or any other way of representing or recording and recalling information which contains,
reflects or is derived or generated from Confidential Information;

"Garden Leave" means any period during which the Company has exercised its rights under clause 19;
"Group Company" means the Company and any group undertaking (as such term is defined in section
1161(5) of the Companies Act 2006) of the Company in any jurisdiction from time to time;
"Intellectual Property Rights" means patents, rights to Inventions, copyright and related rights,
trademarks, trade names and domain names, rights in get-up, rights in goodwill or to sue for passing
off, unfair competition rights, rights in designs, rights in computer software, database rights,
topography rights, rights in confidential information (including know-how and trade secrets) and any
other intellectual property rights, in each case

2
<!-- page 3 -->
whether registered or unregistered and including all applications (or rights to apply) for, and
renewals or extensions of, such rights and all similar or equivalent rights or forms of protection
which subsist or will subsist now or in the future in any part of the world; "Invention" means any
invention, idea, discovery, development, improvement or innovation, whether patentable or capable of
registration, and whether or not recorded in any medium; "Permitted Investment" has the meaning
given to it in clause 14.2; and "Termination" means the termination of the Executive's employment
under this Agreement however caused, whether lawful or not, and "Termination Date" means the date of
Termination. 1.2 In this Agreement, unless the context otherwise requires: 1.2.1 words in the
singular include the plural and in the plural include the singular; 1.2.2 any phrase introduced by
the terms "including", "include", "in particular" or any similar expression shall be construed as
illustrative and shall not limit the sense of the words preceding those terms; 1.2.3 the headings
are inserted for convenience only and shall not affect its construction; 1.2.4 reference to a
particular law is a reference to it as it is in force for the time being taking account of any
amendment, extension or re-enactment and includes any subordinate legislation for the time being in
force made under it; 1.2.5 reference to any regulator or other body includes a reference to any
successor. 2. Term of Employment 2.1 The Executive's employment with the Company will commence on
the Commencement Date and shall continue, subject to the remaining terms of this Agreement, until
terminated by either party giving the other the following minimum advance written notice: 2.1.1 6
weeks' notice;

2.1.2 such other longer period as required by law.

2.2 The Executive's period of continuous employment for the purposes of the Employment Rights Act
1996 commenced on 29 October 2013. 3. Pre-Conditions and Warranties The Executive's employment under
this Agreement is conditional upon the Executive having produced to the Company for inspection
original documents proving the Executive's right to work lawfully in the United Kingdom.

3
<!-- page 4 -->
4. Duties 4.1 The Executive shall serve as Chief Medical Officer and Senior Vice President,
Development (reporting to Rick Winningham) or in such other role as the Company may determine. 4.2
During the employment the Executive shall: 4.2.1 devote the whole of their working time, attention
and abilities to the business of the Company and any other Group Company for which the Executive is
required to work from time to time; 4.2.2 promptly make such reports to the Company in connection
with the Executive's duties or other such matters at such times as are reasonably required; 4.2.3
faithfully and diligently exercise such powers and perform such duties for each Group Company as may
from time to time be assigned by the Company; 4.2.4 comply with all reasonable and lawful directions
given by the Company; 4.2.5 report their own wrongdoing and any wrongdoing or proposed or potential
wrongdoing of any other employee, officer or consultant of any Group Company to the Company
immediately on becoming aware of it; 4.2.6 use their utmost endeavours to promote, protect, develop
and extend the business of the Company; 4.2.7 comply with their common law, statutory, regulatory
and fiduciary duties as well as any policies put in place by the Company from time to time; 4.2.8
exercise the Executive's powers jointly with such other person that the Company may appoint; and
4.2.9 at all times conduct the business of each Group Company for which the Executive is responsible
in a lawful and ethical manner. 5. Place of Work 5.1 The normal place of work of the Executive is at
the Executive's home (or such other location as agreed between the Company and the Executive from
time to time). 5.2 The Executive agrees to travel on any business of any Group Company (both within
the United Kingdom and abroad) as may be required for the proper performance of the Executive's
duties. 5.3 The Executive shall not be required to work outside the United Kingdom for any
continuous period of more than one month. If the Executive is required to do so, their terms of
employment during this time will be communicated with them separately.

4
<!-- page 5 -->
6. Hours of Work 6.1 The Executive shall work such hours as are required for the proper and
efficient performance of their duties including the Company's normal business hours which are 9am
until 5:30pm from Monday to Friday. 6.2 The Executive agrees that the limit on weekly working time
contained in Regulation 4 of The Working Time Regulations 1998 does not apply because Regulation 20
applies to the Executive. 7. Salary 7.1 The Executive shall be paid a basic salary of £448,903 per
annum subject to deductions required by law. The Executive's salary shall accrue from day to day,
shall be payable in equal monthly instalments in arrears on or about the last day of each month. 7.2
The salary paid to the Executive will be reviewed on or around 1 April 2021. The Company is under no
obligation to award an increase following a salary review. 7.3 The Company may deduct from the
salary or any other sums payable to the Executive any money owed to any Group Company by the
Executive. The Executive will reimburse the Company upon demand for the personal use of any Company
credit card, any other unauthorised transactions entered into by the Executive or any overpayments
made to the Executive. 8. Expenses The Company shall reimburse any reasonable travel expenses
wholly, exclusively and necessarily incurred by the Executive in the proper performance of the
Executive's duties under this Agreement subject always to the rules and policies of the Company from
time to time and subject to the Executive providing receipts or other evidence of payment as the
Company may require. 9. Annual Bonus 9.1 The Executive shall be entitled to participate in an annual
bonus plan on such terms and with such individual, team or corporate targets as the Company may
communicate from time to time which shall provide the Executive with an opportunity to be considered
each year for a bonus equivalent to up to 50% of the Executive's basic salary. The Company shall be
entitled to determine whether such targets have been met and where such targets have been met in
full or part shall have a discretion to determine whether to make payments and, if so, in what
amount and when. 9.2 The Company may suspend, alter or discontinue any bonus payment(s) or any bonus
plan and its eligibility requirements at any time (whether generally or in relation to the Executive
only) at its absolute discretion. If the Executive receives any bonus payment the Company is not
obliged to make any further bonus payments and any bonus payment will not become part of the
Executive's contractual remuneration or fixed salary. In order to be eligible to receive a bonus
payment, the Executive must be in the Company's employment and not under notice, given or received
on the date that the bonus is paid. Bonus entitlement does not accrue in the course of a year, and
the Executive is not entitled to

5
<!-- page 6 -->
payment of a bonus, or any pro rata portion of it, if the Executive leaves employment prior to the
date that the bonus is paid. 9.3 The Executive shall not be eligible to be considered for any bonus
nor shall any bonus be paid if the Executive is subject to any disciplinary action or investigation
at the date any bonus is being considered and/or at the bonus payment date (as applicable) although
the Company may reconsider the matter upon the conclusion of the disciplinary action or
investigation in question. 10. Pensions 10.1 The Company intends to comply with the employer pension
duties in respect of the Executive in accordance with Part 1 of the Pensions Act 2008. 10.2 The
Executive's participation in the Company's pension arrangements is subject to the rules of the
relevant scheme and the statutory requirement as each are varied from time to time. In particular
the Company reserves the right to change the scheme provider, the funds available, the charging
structure and the default fund from time to time. 11. Benefits During the course of employment the
Executive may participate in benefit plans operated by the Company. The Executive's participation in
any such benefit plans are subject to the terms and conditions of any such plan. The Company
reserves the right to discontinue, vary or amend each benefit plan (including the level of cover) at
any time on reasonable notice to the Executive. 12. Holidays 12.1 The Executive shall be entitled to
28 days' paid holiday in each holiday year (which includes public holidays) to be taken at times
convenient to the Company and authorised in advance. 12.2 The Company's holiday year runs from 1
January to 31 December. If the Executive's employment commences or terminates part way through a
holiday year, the Executive's entitlement during that holiday year shall be calculated on a pro rata
basis rounded up to the nearest whole day. 12.3 The Executive shall have no entitlement to any
payment in lieu of accrued but untaken holiday except on Termination. The amount of such payment in
lieu shall be 1/260 of the Executive's salary for each untaken day of entitlement. 12.4 If on
Termination the Executive has taken in excess of their accrued holiday entitlement, the Company
shall be entitled to recover from the Executive by way of deduction from any payments due to the
Executive or otherwise, one day's pay for each excess day calculated at 1/260 of the Executive's
salary. 12.5 If either party has served notice to terminate the employment, the Company may require
the Executive to take any accrued but unused holiday entitlement during the notice period. Any
accrued but unused holiday entitlement shall be deemed to be taken during any period of Garden
Leave.

6

th

th
<!-- page 7 -->
13. Sickness 13.1 The Company may in its absolute discretion pay the Executive an amount equal to
the Executive's normal basic pay ("Company Sick Pay") for the first 3 months of sickness absence in
any rolling 12-month period, subject to such conditions as the Company may specify. Company Sick Pay
will include any entitlement to statutory sick pay or any benefits provided by virtue of any
permanent health insurance scheme. Company Sick Pay is also subject to the Executive's compliance
with this Agreement and will not be paid in respect of any period of illness that commences during
the first 6 months of the Executive's employment or whilst the Company is addressing performance or
disciplinary issues. 13.2 The Executive must comply with the Company's sickness absence notification
procedures. Any period of absence of up to five days may be self-certified and any period of absence
of more than five days must be supported by doctor's certificate. 13.3 The Executive consents to
undergo a medical examination by a doctor nominated by the Company at the Company's request and
expense. The Executive agrees that any report produced in connection with any such examination may
be disclosed to the Company and the Company may discuss the contents of any such report with the
relevant doctor. 13.4 The rights of the Company to terminate the Executive's employment under the
terms of this Agreement apply even when such termination would or might cause the Executive to
forfeit any entitlement to sick pay, permanent health insurance or other benefits. 14. Outside
Activities and Interests 14.1 The Executive shall not during the employment except as a
representative of the Company or with the Company's prior written consent (whether directly or
indirectly, paid or unpaid) be employed, engaged, concerned or interested in any other actual or
prospective business, organisation, occupation or profession. 14.2 Nothing in this Agreement shall
prevent the Executive from holding an investment by way of shares or other securities to in any
entity listed or dealt on a recognised stock exchange (a "Permitted Investment") provided always
that during the term of the employment the Permitted Investment shall not constitute more than 3% of
the issued share capital of the entity concerned . 15. Confidential Information 15.1 Without
prejudice to the Executive's common law and fiduciary duties, the Executive shall not during
employment or at any time after Termination and whether for their own benefit or for the benefit of
any third party: 15.1.1 use any Confidential Information; or 15.1.2 disclose any Confidential
Information to any person, company or other organisation whatsoever, except in the proper course of
their duties, as required by law or as authorised by the Company in writing.

7
<!-- page 8 -->
15.2 The Executive shall be responsible for protecting the confidentiality of the Confidential
Information and shall use best endeavours to prevent the misuse of Confidential Information by
others. 15.3 All Confidential Information and Copies shall be the property of the Company and the
Executive shall not make any Copies save in the proper course of their employment. 15.4 Save as
authorised by the Company, the Executive shall not make or publish any comment regarding to the
business or affairs of any Group Company or any Group Companies' current or former employees or
directors to the media (including on social media). 16. Intellectual Property 16.1 The Executive
shall disclose to the Company details of all Inventions and of all works embodying Intellectual
Property Rights made solely or jointly with others at any time during the term of the employment
which relate to, or are capable of being used in, the business of any Group Company whether or not
in the course of their ordinary duties and whether or not made in working time (together, the
"Company IP"). The Executive acknowledges that all Intellectual Property Rights subsisting (or which
may in the future subsist) in such Company IP shall automatically, on creation, vest in the Company
absolutely. To the extent that the Company IP does not vest automatically in the Company the
Executive hereby assigns all right, title and interest in the Company IP to the Company with full
title guarantee by way of a present assignment of all future rights and shall otherwise hold them on
trust for the Company. The Executive agrees promptly to execute all documents and to do all acts as
may, in the opinion of the Company, be necessary or desirable to give the Company full benefit of
this clause. 16.2 The Executive irrevocably waives all "moral rights" under the Copyright, Designs
and Patents Act 1988 (and, to the fullest extent permitted by law, all similar rights in other
jurisdictions) which the Executive has or will have in any Company IP. 16.3 By way of security for
the Executive's obligations under this Agreement, the Executive irrevocably appoints the Company to
be the Executive's attorney to execute any instrument or to do anything and generally to use the
Executive's name for the purpose of giving the Company or i ts nominee the benefit of this clause.
The Executive acknowledges in favour of a third party that a certificate in writing signed by the
Company that any instrument or act falls within the authority conferred by this clause shall be
conclusive evidence that such is the case. 16.4 The Executive agrees that the Executive's work for
the Company will be the Executive's own original work and the Executive will not violate the
intellectual property rights of third parties. The Company does not want and does not need any
confidential information relating to any former employer of the Executive and the Executive agrees
to not to copy, use or disclose such information. 17. Payment in Lieu of Notice 17.1 The Company
may, in its sole and absolute discretion, terminate the Executive's employment under this Agreement
at any time and with immediate effect by notifying the Executive that the Company is exercising its
right under this clause 17 and that it will make a payment in l ieu of not ice ("PILON") to the
Executive. The Executive's employment will terminate immediately and any PILON due to the Executive
in accordance with the

8
<!-- page 9 -->
provisions of this clause 17 will be paid within 28 days. The PILON will be equal to the basic
salary (as at the Termination Date) which the Executive would have been entitled to receive under
this Agreement during the notice period referred to at clause 2 (or, if notice has already been
given, during the remainder of the notice period) less deductions required by law. 17.2 The
Executive shall have no right to receive a PILON unless the Company has exercised its discretion in
clause 17.1. 17.3 Notwithstanding clause 17.1, the Executive shall not be entitled to any PILON if
the Company would otherwise have been entitled to terminate the Executive's employment under this
Agreement without notice in accordance with clause 18. In that case the Company shall also be
entitled to recover from the Executive any PILON already made. 18. Termination Without Notice 18.1
The Company may terminate the Executive's employment under this Agreement with immediate effect
without notice and with no liability to make any further payment to the Executive (other than in
respect of amounts accrued at the Termination Date) if in the reasonable opinion of the Company the
Executive: 18.1.1 is guilty of gross misconduct; or 18.1.2 commits any serious or repeated breach or
non-observance of any of the provisions of this Agreement or refuses to comply with any reasonable
and lawful directions of the Company; or 18.1.3 commits any serious or repeated breach of the
Company's policies or procedures; or 18.1.4 is grossly negligent or grossly incompetent in the
performance of their duties; 18.1.5 is declared bankrupt or makes any arrangement with or for the
benefit of their creditors or has a county court administration order made under the County Court
Act 1984; or 18.1.6 is convicted of any criminal offence (other than an offence under any road
traffic legislation in the United Kingdom or elsewhere for which a fine or non-custodial penalty is
imposed); or 18.1.7 is no longer eligible to work in the United Kingdom; or 18.1.8 is guilty of any
fraud or dishonesty or acts in any manner which brings or is likely to bring the Executive or any
Group Company into disrepute or is materially adverse to the interests of any Group Company; or
18.1.9 makes any statement or other form of communication that disparages or undermines the goodwill
or reputation of any Group Company. 18.2 The rights of the Company under clause 18.1 are without
prejudice to any other rights that it might have at law to terminate the Executive's employment or
to accept any breach of

9
<!-- page 10 -->
this Agreement by the Executive as having brought the Agreement to an end. Any delay by the Company
in exercising it rights to terminate shall not constitute a waiver thereof. 18.3 The Company may
suspend the Executive from any or all of the Executive's duties during any period in which the
Company is investigating any disciplinary matter involving the Executive or while any disciplinary
procedure or regulatory investigation is outstanding. Any such suspension shall not constitute
disciplinary action. During any period of suspension, the Company may impose the same conditions
that apply to Garden Leave. 19. Garden Leave 19.1 Following service of notice to terminate the
employment by either party, or if the Executive purports to terminate the employment in breach of
contract, the Company may by written notice place the Executive on Garden Leave for the whole or
part of the remainder of the employment. 19.2 During any period of Garden Leave: 19.2.1 the Company
shall be under no obligation to provide any work to the Executive and may revoke any powers the
Executive holds on behalf of any Group Company; 19.2.2 the Executive shall continue to receive their
basic salary but shall not be entitled to receive any bonus or other incentives in respect of the
period of Garden Leave; 19.2.3 the Company may require the Executive to carry out alternative duties
or to only perform such specific duties as are expressly assigned to the Executive, at such location
(including the home of the Executive) as the Company may reasonably decide; 19.2.4 the Company may
appoint another person to carry out the Executive's normal duties; 19.2.5 the Executive shall remain
an employee of the Company and bound by the terms of this Agreement; 19.2.6 the Executive shall be
contactable during each working day (except during any periods taken as holiday in the usual way);
19.2.7 the Company may exclude the Executive from any premises of any Group Company, require the
Executive to return any Group Company property and remove the Executive's access from some or all of
its information systems; and 19.2.8 the Company may require the Executive not to contact or deal
with (or attempt to contact or deal with) any officer, employee, consultant, client or other
business contact of any Group Company as it may reasonably determine. 20. Obligations Upon
Termination 20.1 On Termination or, if earlier, at the start of a period of Garden Leave following
the service of notice or purported Termination by the Executive, the Executive shall:

10
<!-- page 11 -->
20.1.1 immediately deliver to the Company all documents, books, materials, records, correspondence,
papers, Copies, Confidential Information and other business information (on whatever media and
wherever located) relating to the business or affairs of any Group Company or its business contacts,
any keys and any other property of any Group Company, which is in the Executive's possession or
control; 20.1.2 irretrievably delete any information relating to the business of any Group Company
stored on any magnetic or optical disk or memory (including on any personal computer, personal
device, personal email account or web account), and all matter derived from such sources which is in
their possession or under their control outside the premises of the Company; 20.1.3 provide such
handover of their duties as the Company shall consider appropriate; and 20.1.4 provide a signed
statement confirming full compliance with the obligations under clauses 20.1.1 and 20.1.2 together
with such reasonable evidence of compliance as the Company may request. 21. Post Termination
Restrictions During the term of employment and for one (1) year thereafter, the Executive will not
directly or indirectly, either themselves or through others, encourage or solicit any employee of
the Company to leave the Company for any reason. This obligation shall not affect any responsibility
the Executive has as an employee of the Company with respect to the bona fide hiring and firing of
Company personnel. 22. Statutory Particulars 22.1 The Executive is subject to the Company's
disciplinary and grievance procedures, copies of which are available upon request (although the
Company reserves the right to deviate from these procedures in light of the Executive's seniority).
These procedures do not form part of the Executive's contract of employment. 22.2 If the Executive
wishes to raise a grievance or appeal a disciplinary decision the matter should be raised in writing
with Rick Winningham. 22.3 There is no collective agreement which affects the Executive's employment
or this Agreement. 23. Workplace Privacy 23.1 The Executive's attention is drawn to the Company's
Privacy Notice which is available upon request. 23.2 The Executive consents to the Company
monitoring their communication and electronic equipment including, without limitation, the Company's
telephone, chat and e-mail systems, information stored on the Company's computer equipment
(including all electronically stored information that is the property of the Company), recordings
from the Company's closed circuit television cameras and any other computer equipment or other
device used by the Executive in the performance of their duties.

11
<!-- page 12 -->
24. General 24.1 The Executive will, at the request of the Company at any time after the Termination
Date, co-operate and provide assistance to any Group Company in any internal investigation,
administrative, regulatory, quasi-judicial proceedings or any threatened or actual litigation
concerning any Group Company where the Executive is aware of any facts or other matters which the
Company reasonably considers is relevant to such process or legal proceedings (including, but not
limited to, giving statements/affidavits, meeting with their legal and other professional advisers,
attending any legal hearing and giving evidence) on the understanding that the Company will pay any
reasonable expenses for which receipts and other supporting documents are provided to the reasonable
satisfaction of the Company and provided any expense is authorised in advance by the Company). 24.2
If the Executive's employment is terminated at any time by reason of any reconstruction or
amalgamation of any Group Company, whether by winding up or otherwise, and the Executive is offered
employment with any concern or undertaking involved in or resulting from the reconstruction or
amalgamation on terms which (considered in their entirety) are no less favourable to any material
extent than the terms of this Agreement, the Executive acknowledges and agrees that there shall be
no claim against the Company or any undertaking arising out of or connected with such termination.
24.3 This clause applies if the Executive subscribes for or is awarded shares in the Company or any
Group Company or participates in any share option, restricted share, restricted share unit, long
term incentive, carried interest, co-invest or any other form of profit sharing, incentive, bonus or
equity plan or arrangement (each, an "Incentive") or may do so. Upon Termination, the Executive's
rights (if any) in respect of each Incentive shall be solely determined by the articles of
association, rules or other documents governing each Incentive which are in force on the Termination
Date and the Executive hereby irrevocably waives all claims or rights of action in respect of the
loss of any rights or benefits under or in respect of any Incentive granted or not yet granted to
the Executive (including any loss relating to the lapse of, or their ineligibility to exercise, any
share options, the value of any shares, the operation of any compulsory transfer provisions or the
operation of any vesting criteria)

24.4 A notice given to a party under this Agreement shall be in writing in the English language and
signed by or on behalf of the party giving it. It shall be delivered by hand or sent to the party at
the address given for that party in this Agreement, in the case of the Executive to their personal
email address or as otherwise notified in writing to the other party. A notice given by email shall
be deemed to take effect one hour after it is sent, a notice sent by first class post shall be
deemed to take effect on the next working day and notice sent by courier upon delivery at the
address in question. A notice required to be given to the Company under this Agreement shall not be
validly given if sent by email. 24.5 This Agreement and any document referred to in it constitutes
the entire agreement between the parties and supersedes and extinguishes all previous discussions,
correspondence, negotiations, drafts, agreements, promises, assurances, warranties, representations
and understandings between them, whether written or oral, relating to its subject matter.

24.6 The Executive agrees that in entering into this Agreement the Executive does not rely on and
shall have no remedies in respect of, any statement, representation, assurance or warranty (whether
made innocently or negligently) that is not expressly set out in this

12
<!-- page 13 -->
Agreement. The Executive waives any claim for innocent or negligent misrepresentation or negligent
misstatement including in respect of any statement set out in this Agreement. 24.7 No variation or
agreed termination of this Agreement shall be effective unless it is in writing and signed by the
parties (or their authorised representatives). If the Executive commences employment or continues in
employment without executing a copy of this Agreement and fails to object within one month of the
Commencement Date then the Executive will be deemed to have agreed to its terms. 24.8 The Executive
shall not be contractually entitled to receive any benefit from the Company which is not expressly
provided for by this Agreement. 24.9 This Agreement may be executed in any number of counterparts,
each of which, when executed and delivered, shall be an original, and all the counterparts together
shall constitute one and the same agreement. 24.10 The Contracts (Rights of Third Parties) Act 1999
shall only apply to this Agreement in relation to any Group Company. No person other than the
parties to this Agreement and any Group Company shall have any rights under it and it will not be
enforceable by any person other than those parties. 24.11 This Agreement and any dispute or claim
arising out of or in connection with it or its subject matter or formation (including
non-contractual disputes or claims) shall be governed by and construed in accordance with the law of
England. 24.12 Each party irrevocably agrees that the courts of England shall have exclusive
jurisdiction to settle any dispute or claim arising out of or in connection with this Agreement or
its subject matter or formation (including non-contractual disputes or claims).

13
<!-- page 14 -->
Signed by Rick E Winningham for and on behalf of Theravance Biopharma UK Limited

/s/ Rick E Winningham

Signature Signed as a deed by Brett Haumann in the presence of: /s/ Brett Haumann Signature

/s/ Connor Haumann Witness's Signature Name of witness Connor Haumann Address of witness [address
removed] Occupation of witness Student

14
