# Among the following 8 agreements, which contain a non-compete clause? For each, quote t...

*Question:* Among the following 8 agreements, which contain a non-compete clause? For each, quote the clause. Agreements: the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley (dated 2017-11-14); the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. (dated 2011-03-14); the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc (filed 2018-11-09); the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC (dated 2013-05-15); the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies (filed 2005-11-02); the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01); the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. (dated 2010-01-01); the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. (filed 2013-09-26).

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Identify agreements containing non-compete clauses

The Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. contains a non-compete clause in Section 11.3. [23e65a3b8bc5cc9e p.25] The Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley contains an exclusivity clause rather than a non-compete clause. [4cb98e07400203bf p.3] The Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC references a non-compete only in connection with a third-party settlement agreement, not as a clause in the supply agreement itself. [31cbf0d18f7d763e p.13]

[GAP] Evidence is missing for the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc, the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies, the Cooperation Agreement between e.l.f.

Beauty, Inc. and Marathon Partners Equity Management, LLC, the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC., and the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. [uncited]

## Not established by the evidence

[GAP] No evidence was found for: Extract and quote the exact non-compete clause text from each agreement identified as containing one

## Verification appendix

Claims: 6 · supported: 3 · partially: 0 · dropped: 0 · gaps: 3 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Quote non-compete clauses

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[23e65a3b8bc5cc9e p.25] |  |
| s1.2 | s1 | keep | 1.00 | e2→[4cb98e07400203bf p.3] |  |
| s1.3 | s1 | keep | 1.00 | e3→[31cbf0d18f7d763e p.13] |  |
| s1.4 | s1 | gap |  |  |  |
| s1.5 | s1 | gap |  |  | no evidence cited |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [23e65a3b8bc5cc9e p.25 L947-963] keep (1.0): "Section 11.3 Non-Competition and Non-Solicitation. (a) During the Term, except as otherwise provided in this Agreement, Network Affiliate and its affiliates agree not to engage or participate in any business, hold equity interests, directly…"
- e2 [4cb98e07400203bf p.3 L105-107] keep (1.0): "8. Exclusivity. Talent represents and warrants that during the Term and in the Territories, Talent will not endorse or make any appearances or advertisements on behalf of any other product which is directly competitive to ESSI's products."
- e3 [31cbf0d18f7d763e p.13 L640-642] keep (1.0): "(e) Non-Compete. The Settlement Agreement and Mutual Release between *** and *** does not contain a covenant-non-compete applicable to *** and, to the best of PcoMed's current knowledge, *** is not subject to any covenant-non-compete that w…"
