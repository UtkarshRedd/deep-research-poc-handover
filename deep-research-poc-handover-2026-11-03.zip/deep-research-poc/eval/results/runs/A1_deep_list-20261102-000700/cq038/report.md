# When does the Technical Infrastructure Maintenance Agreement between MEDICAL MANAGER MI...

*Question:* When does the Technical Infrastructure Maintenance Agreement between MEDICAL MANAGER MIDWEST, INC. and MTS, INC. (dated 1998-03-01) expire, according to its term clause?

## Identify the agreement

The agreement is identified as the Technical Infrastructure Maintenance Agreement between MEDICAL MANAGER MIDWEST, INC. [uncited] ("MMMW") and MTS, INC. [uncited] ("Customer"), with an agreement date of 1998-03-01. [6f5edff8361f32dd p.1] [DROPPED: claim s1.4 could not be verified against its cited source.] Signature dates appear as March 4, 1998 and 3-5-98. [6f5edff8361f32dd p.4]

[GAP] The term clause and expiration date are not present in the provided evidence.

## Locate the term clause

The term clause states that the Initial Term of this Technical Infrastructure Maintenance Agreement is twelve months, commencing on the Effective Date. [6f5edff8361f32dd p.1] The Effective Date is defined as the date of signed acceptance by MMMW. [6f5edff8361f32dd p.1] The agreement is dated 1998-03-01, but the evidence does not state the date of signed acceptance. [partially supported by review] [6f5edff8361f32dd p.1] [6f5edff8361f32dd p.1] Therefore, the expiration date cannot be determined from the evidence provided because the Effective Date is not specified. [6f5edff8361f32dd p.1] [6f5edff8361f32dd p.1]

## Extract the expiration date

The term of this Agreement consists of the Initial Term and any continuations. [6f5edff8361f32dd p.2] Customer may cancel this Agreement at the end of the Initial Term and thereafter on each anniversary of the end of the Initial Term. [6f5edff8361f32dd p.2] The evidence does not state the length of the Initial Term or the expiration date. [6f5edff8361f32dd p.2]

[GAP] The exact expiration date is missing because the Initial Term duration is not provided.

## Verification appendix

Claims: 14 · supported: 9 · partially: 0 · dropped: 1 · gaps: 4 · tier-1 support rate: 0.90 · tier 2 checked: 4 (unsupported 0, partially 1)

| claim | section | tier 1 | score | tier 2 | clusters | sources | note |
|---|---|---|---|---|---|---|---|
| s1.1 | s1 | gap |  | skipped |  |  | no evidence cited |
| s1.2 | s1 | gap |  | skipped |  |  | no evidence cited |
| s1.3 | s1 | keep | 1.00 | supported | 1 | e1→[6f5edff8361f32dd p.1] |  |
| s1.4 | s1 | drop | 0.00 | skipped | 1 | e4→[6f5edff8361f32dd p.1] |  |
| s1.5 | s1 | keep | 1.00 | skipped | 1 | e6→[6f5edff8361f32dd p.4] |  |
| s1.6 | s1 | gap |  | skipped |  |  |  |
| s2.1 | s2 | keep | 1.00 | skipped | 1 | e2→[6f5edff8361f32dd p.1] |  |
| s2.2 | s2 | keep | 1.00 | skipped | 1 | e5→[6f5edff8361f32dd p.1] |  |
| s2.3 | s2 | keep | 1.00 | partially | 1 | e2→[6f5edff8361f32dd p.1] e5→[6f5edff8361f32dd p.1] | tier 2 partially: The evidence states the agreement is effective on the date of signed acceptance, but does not provide the actual date of signed acceptance or the Effective Date |
| s2.4 | s2 | keep | 1.00 | supported | 1 | e2→[6f5edff8361f32dd p.1] e5→[6f5edff8361f32dd p.1] |  |
| s3.1 | s3 | keep | 1.00 | skipped | 1 | e3→[6f5edff8361f32dd p.2] |  |
| s3.2 | s3 | keep | 1.00 | supported | 1 | e3→[6f5edff8361f32dd p.2] |  |
| s3.3 | s3 | keep | 1.00 | skipped | 1 | e3→[6f5edff8361f32dd p.2] |  |
| s3.4 | s3 | gap |  | skipped |  |  |  |

### Evidence

- e1 [6f5edff8361f32dd p.1 L6-7] keep (1.0): "| Agreement Date | 1998-03-01 | | Parties | MEDICAL MANAGER MIDWEST, INC. ("MMMW"); MTS, INC. ("Customer") |"
- e2 [6f5edff8361f32dd p.1 L65-74] keep (1.0): "2. TERM

(a) MMMW provided Customer with an all inclusive warranty for a period of 12 months commencing on
the date of installation to include system purchased by Customer from MMMW. Upon expiration of that
12 months, MMMW affords the Custo…"
- e3 [6f5edff8361f32dd p.2 L106-110] keep (1.0): "(d) Customer, upon thirty days prior written notice, may cancel this Agreement at the end of the
Initial Term and thereafter on each anniversary of the end of the Initial Term. MMMW may cancel this
Agreement if the Customer does not remit p…"
- e4 [6f5edff8361f32dd p.1 L16-16] drop (0.0): "Date: March 1, 1998"
- e5 [6f5edff8361f32dd p.1 L53-53] keep (1.0): "(c) This Agreement shall be effective on the date of signed acceptance ("Effective Date") by MMMW."
- e6 [6f5edff8361f32dd p.4 L263-263] keep (1.0): "Date: March 4, 1998 Date: 3-5-98"
