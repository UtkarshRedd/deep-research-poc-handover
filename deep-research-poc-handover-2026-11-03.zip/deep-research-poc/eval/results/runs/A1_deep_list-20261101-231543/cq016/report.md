# What cap on liability does the Agency Agreement between Athens Bancshares Corporation a...

*Question:* What cap on liability does the Agency Agreement between Athens Bancshares Corporation and Athens Federal Community Bank (filed 2009-11-02) provide?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Locate the liability cap provision

[GAP] The writer produced nothing for: Establish the specific section or clause within the agreement that addresses the cap on liability.

## Not established by the evidence

[GAP] No evidence was found for: Establish that the document filed on 2009-11-02 is the Agency Agreement between Athens Bancshares Corporation and Athens Federal Community Bank.

[GAP] No evidence was found for: Establish the exact monetary limit, percentage, or formula defining the cap on liability provided by the agreement.

## Verification appendix

Claims: 3 · supported: 0 · partially: 0 · dropped: 0 · gaps: 3

Notes: 2 empty section(s) collapsed into gaps: Identify the Agency Agreement; Extract the cap amount or formula; OpenAIRateLimitError: Error code: 429; OpenAIRateLimitError: Error code: 429

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s2.1 | s2 | gap |  |  |  |
| gaps.1 | gaps | gap |  |  |  |
| gaps.2 | gaps | gap |  |  |  |

### Evidence

