<!-- page 1 -->
# NON-EXCLUSIVE LICENSE AGREEMENT- FOR SALES
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2016-05-03 |
| Parties | The John Hopkins University ("JHU"); Virtuoso Surgical, Inc. ("Company") |
| Source | CUAD v1 / VirtuosoSurgicalInc_20191227_1-A_EX1A-6 MAT CTRCT_11933379_EX1A-6 MAT CTRCT_License Agreement |

Exhibit 6.2 NON-EXCLUSIVE LICENSE AGREEMENT BETWEEN THE JOHNS HOPKINS UNIVERSITY & VIRTUOSO
SURGICAL, INC.

JHU Agreement: A29889

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

1
<!-- page 2 -->
May 3, 2016 NON-EXCLUSIVE LICENSE AGREEMENT- FOR SALES This Non-Exclusive License Agreement
(hereinafter "Agreement") is entered into by and between The Johns Hopkins University (hereinafter
"JHU"), a corporation of the State of Maryland, having a principal place of business 3400 N. Charles
Street, Baltimore, Maryland 21218- 2695 and, Virtuoso Surgical, Inc. (hereinafter "Company"), a
Tennessee corporation having an address at 5701 Old Harding Pike; Suite 200; Nashville, TN 37205.
The parties hereto agree as follows: 1. BACKGROUND 1.1 In the course of a fundamental research
program at JHU, a valuable invention entitled Active Cannulas for Bio-Sensing and Surgical
Intervention (JHU Ref. C04873) was developed by Drs. Robert Webster, III, Noah Cowan, Allison
Okamura, and Russell Taylor (hereinafter "Inventors"). 1.2 JHU has acquired all right, title and
interest, with the exception of certain retained rights by the United States government, in said
invention but is without the capacity to commercially develop, manufacture and distribute products
and methods which embody the invention. 1.3 Company is interested in providing such commercial
products and methods to third parties on a non-exclusive basis and agrees to comply with the terms
and conditions in this Agreement. 1.4 All references to particular Exhibits or Paragraphs shall mean
the Exhibits to, and Paragraphs of, this Agreement, unless otherwise specified. 2. DEFINITIONS 2.1
"EFFECTIVE DATE" of this Agreement shall mean the date the last party hereto has executed this
Agreement. 2.2 "LICENSED FIELD" shall mean Cannulated Surgical Intervention. 2.3 "LICENSED
PRODUCT(S)" as used herein in either singular or plural shall mean any material, compositions, or
other product, the manufacture, use or sale of which would constitute, but for the license granted
to Company pursuant to this Agreement, an infringement of a claim of PATENT RIGHT(S) (infringement
shall include, but is not limited to, direct, contributory, or inducement to infringe). 2.4
"LICENSED SERVICE(S)" as used herein in either singular or plural shall mean the performance on
behalf of a third party of any method including cannulated surgical intervention or the manufacture
of any product or the use of any product which would constitute, but for the license granted to
Company pursuant to this Agreement, an infringement of a claim of the PATENT RIGHT(S), (infringement
shall include, but not be limited to, direct, contributory or inducement to infringe).

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

2
<!-- page 3 -->
May 3, 2016 2.5 "NET SALES" shall mean gross sales revenues and fees billed by Company from the sale
of LICENSED PRODUCT(S) less trade discounts allowed, refunds, returns and recalls, and sales taxes.
In the event that Company sells a LICENSED PRODUCT(S) in combination with other ingredients or
substances or as part of a kit, the NET SALES for purposes of royalty payments shall be based on the
sales revenues and fees received from the entire combination or kit. 2.6 "NET SERVICE REVENUES"
shall mean gross service revenues and fees billed by Company for the performance of LICENSED
SERVICE(S) less sales and/or use taxes imposed upon and with specific reference to the LICENSED
SERVICE(S). In the event that Company sells a LICENSED SERVICE(S) in combination with other services
or substances or as part of a kit, the NET SERVICE REVENUES for purposes of royalty payments shall
be based on the sales revenues and fees received from the entire combination. 2.7 "PATENT RIGHT(S)"
shall mean, collectively, JHU's interest in those set forth in EXHIBIT C of this Agreement and the
inventions disclosed and claimed therein, and all continuations, divisions, and reissues based
thereof, and any corresponding foreign patent applications, and any patents, or other equivalent
foreign PATENT RIGHT(S) issuing, granted or registered thereon. 3. GRANT 3.1 License Granted:
Subject to the terms and conditions of this Agreement and to non-exclusive license agreements
executed prior to the EFFECTIVE DATE, JHU hereby grants to the Company a non-exclusive,
non-transferable license to make, have made, import, offer for sale and sell the LICENSED PRODUCT(S)
and the LICENSED SERVICE(S) in the United States and worldwide under the PATENT RIGHT(S) in the
LICENSED FIELD. 3.2 No Sublicensing: Company shall not sublicense to others under this Agreement,
nor extend the rights granted hereunder to any affiliated company. 4. PAYMENTS, ROYALTY AND
REPORTING 4.1 License Fee: As consideration for JHU's grant of a License to Company under this
Agreement, Company shall pay to JHU a license fee, cash and equity, as set forth in Exhibit A within
thirty (30) days of the EFFECTIVE DATE. The license fee is nonrefundable and shall not be credited
against royalties or other fees. 4.2 Minimum Annual Royalties: Company shall pay to JHU minimum
annual royalties as set forth in Exhibit A. These minimum annual royalties shall be due within
thirty (30) days of each anniversary of the EFFECTIVE DATE beginning with the first anniversary.
Running royalties accrued under Paragraph 4.3 and paid to JHU during the one year period preceding
an anniversary of the EFFECTIVE DATE shall be credited against the minimum annual royalties due on
that anniversary date.

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

3
<!-- page 4 -->
May 3, 2016 4.3 Running Royalties: Company shall pay to JHU, a running royalty as set forth in
Exhibit A, for each LICENSED PRODUCT(S) sold and each LICENSED SERVICE(S) provided, based upon NET
SALES and NET SERVICE REVENUES respectively, for the term of this Agreement. Such payments shall be
made within thirty (30) days of the end of each calendar quarter following first commercial sale of
LICENSED PRODUCT or providing LICENSED SERVICES. All non-US taxes related to LICENSED PRODUCT(S) and
LICENSED SERVICE(S) sold under this Agreement shall be paid by Company and shall not be deducted
from royalty or other payments due to JHU. 4.4 Reporting and Payments: Upon achieving first
commercial sale of LICENSED PRODUCTS and LICENSED SERVICES, Company shall provide a quarterly
royalty report, substantially in the format of Exhibit B, accompanying each royalty payment as
required in Paragraph 4.3. Royalty reports shall disclose the amount of LICENSED PRODUCT(S) and
LICENSED SERVICE(S) sold, the total NET SALES and NET SERVICE REVENUES of such LICENSED PRODUCT(S)
and LICENSED SERVICE(S), and the running royalties due to JHU as a result of NET SALES and NET
SERVICE REVENUES by Company. In lieu of sending quarterly royalty reports to JHU via mail or
courier, Company may provide all required reports in electronic format to the email address
specified by JHU. 4.5 Late Payments: In the event that any payment due hereunder is not made when
due, the payment shall accrue interest beginning on the tenth day following the due date thereof,
calculated at the annual rate of six percent (6%), the interest being compounded on the last day of
each calendar year. Each such royalty payment when made shall be accompanied by all interest so
accrued. Said interest and the payment and acceptance thereof shall not negate or waive the right of
JHU to seek any other remedy, legal or equitable, to which it may be entitled because of the
delinquency of any payment. 4.6 Records: The Company shall make and retain, for a period of three
(3) years following the period of each report required by Paragraph 4.4, true and accurate records,
files and books of account containing all the data reasonably required for the full computation and
verification of sales and other information required in Paragraph 4.4. Such books and records shall
be in accordance with generally accepted accounting principles consistently applied. The Company
shall permit the inspection and copying of such records, files and books of account by JHU or its
agents during regular business hours upon ten (10) business days' written notice to the Company.
Such inspection shall not be made more than once each calendar year. All costs of such inspection
and copying shall be paid by JHU, provided that if any such inspection shall reveal that an error
has been made in the amount equal to five percent (5%) or more of such payment, such costs shall be
borne by the Company.

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

4
<!-- page 5 -->
May 3, 2016 4.7 Non-Arms Length Transactions: In order to insure JHU the full royalty payments
contemplated hereunder, the Company agrees that in the event any LICENSED PRODUCT(S) shall be sold
to an affiliated company or to a corporation, firm or association with which Company shall have any
agreement, understanding or arrangement with respect to consideration (such as, among other things,
an option to purchase stock or actual stock ownership, or an arrangement involving division of
profits or special rebates or allowances) the royalties to be paid hereunder for such LICENSED
PRODUCT(S) shall be based upon the greater of: 1) the net selling price at which the purchaser of
LICENSED PRODUCT(S) resells such product to the end user, 2) the NET SERVICE REVENUE received from
using the LICENSED PRODUCT(S) in providing a service, 3) the fair market value of the LICENSED
PRODUCT(S) or 4) the net selling price of LICENSED PRODUCT(S) paid by the purchaser. 4.8 Method of
Payment: All payments under this Agreement shall be made in U.S. Dollars by either check or wire
transfer. 4.9 Payment Information. All check payments from Company to JHU shall be sent to: Director
Johns Hopkins Technology Ventures The Johns Hopkins University 100 N. Charles Street, 5t h Floor
Baltimore, MD 21201 Reference: JHU Agreement A29889 or such other addresses which JHU may designate
in writing from time to time. Checks are to be made payable to "The Johns Hopkins University". Wire
transfers may be made through: ACH for U.S. Payments Johns Hopkins University Central Lockbox Bank
of America 1400 Best Plaza Drive Richmond, VA 23227 Transit/routing/ABA number: 052001633 Account
number: Type of account: depository CTX format is preferred; CCD+ is also accepted Reference: JHU
Tech Transfer (JHU Agreement A29889) FED WIRE for International Payments Johns Hopkins University
Central Lockbox Bank of America 100 West 33rd Street New York, NY 10001 SWIFT code: BOFAUS3N Account
number: Type of account: depository

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

5
<!-- page 6 -->
May 3, 2016 Reference: JHU Tech Transfer (JHU Agreement A29889) Company shall be responsible for any
and all costs associated with wire transfers. Company shall provide JHU with the date of wire
transfer payment and ACH confirmation number upon completion of such payment. 4.10 Invoices. Any
invoice for payment sent by JHU to Company may be electronically provided by e-mail service. JHU
will send invoices to an e-mail address provided by Company. Company will provide JHU with any
updates to this e-mail address. 5. PATENT MATTERS 5.1 Prosecution & Maintenance: JHU, at its sole
option and discretion, shall file, prosecute and maintain all patents and patent applications
specified under PATENT RIGHT(S). Title to all such patents and patent applications shall reside in
JHU. JHU shall have full and complete control over all patent matters in connection therewith under
the PATENT RIGHT(S). 5.2 Right to Enforce: JHU shall have the first right to enforce the PATENT
RIGHTS against any infringement or alleged infringement thereof in the LICENSED FIELD OF USE. 6.
TERM AND TERMINATION 6.1 Expiration: This term of this Agreement shall commence on the EFFECTIVE
DATE and shall continue, in each country, until the date of expiration of the last to expire patent
within PATENT RIGHT(S) in that country. 6.2 Termination by Company: Company may terminate this
Agreement and the license granted herein, for any reason, upon giving JHU sixty (60) days written
notice under Paragraph 8.1. 6.3 Termination by JHU: JHU, at its option, may terminate this Agreement
and the license granted herein if Company has not made any sales of LICENSED PRODUCT(S) or LICENSED
SERVICE(S) in any period of four consecutive quarters, after the initial commercial sale of the
PRODUCT(S) or LICENSED SERVICE(S). 6.4 Unpaid Royalty/Reversion of Rights: Termination or expiration
of this Agreement shall not affect JHU's right to recover unpaid royalties accrued prior to
termination or expiration. Upon termination or expiration of this Agreement, all rights in and to
the licensed technology shall revert to JHU at no cost to JHU. 6.5 Survival: All applicable
provisions, including but not limited to Paragraphs 4.1 (License Fee), 9.3 (Severability), 9.4 (Use
of Name), 9.6 (Disclaimer of Warranties), 9.7 (Indemnification), 9.8 (Product Liability), 9.13
(Binding Effect) and 9.14 (Governing Law) shall survive termination or expiration of this Agreement.

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

6
<!-- page 7 -->
May 3, 2016 7. DEFAULT 7.1 Default & Termination: Upon breach or default of any term or condition of
this Agreement by either party, the defaulting party shall be given written notice of such default
in writing by the party not in default. The defaulting party shall have a period of sixty (60) days
after receipt of such notice to correct the default or breach. If the default or breach is not
corrected within said sixty (60) day period, the party not in default shall have the right to
terminate this Agreement. 8. NOTICES 8.1 Notice Information: All notices and/or other communications
pertaining to this Agreement shall be in writing and sent by registered mail or certified mail,
return receipt requested, or sent by overnight courier, such as Federal Express, to the parties at
the following addresses or such other address as such party shall have furnished in writing to the
other party in accordance with this Paragraph 8.1: FOR JHU: Director Johns Hopkins Technology
Ventures The Johns Hopkins University 100 N. Charles Street, 5t h Floor Baltimore, MD 21201
Reference: JHU Agreement A29889 FOR Company: VIRTUOSO SURGICAL, INC. 5701 Old Harding Pike; Suite
200 Nashville, TN 37205 9. MISCELLANEOUS 9.1 Audit: JHU shall have the right to audit any and all
Company records related to this Agreement. 9.2 Assignment: This Agreement is binding upon and shall
inure to the benefit of JHU, its successors and assignees and shall not be assignable to another
party, except that the Company shall have the right to assign this Agreement to another party in the
case of the sale or transfer by the Company of all, or substantially all, of its assets relating to
the LICENSED PRODUCT(S), LICENSED SERVICE(S) or PATENT RIGHT(S), to that party.

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

7
<!-- page 8 -->
May 3, 2016 9.3 Severability: In the event that any one or more of the provisions of this Agreement
should for any reason be held by any court or authority having jurisdiction over this Agreement, or
over any of the parties hereto to be invalid, illegal or unenforceable, such provision or provisions
shall be reformed to approximate as nearly as possible the intent of the parties, and if
unreformable, shall be divisible and deleted in such jurisdictions; elsewhere, this Agreement shall
not be affected. 9.4 Use of Name: The Company shall not use the name of The Johns Hopkins University
or The Johns Hopkins Health System or any of its constituent parts, such as the Johns Hopkins
Hospital or any contraction thereof or the name of Inventors in any advertising, promotional, sales
literature or fundraising documents without prior written consent from an authorized representative
of JHU. Company shall allow at least seven (7) business days notice of any proposed public
disclosure for JHU's review and comment or to provide written consent. 9.5 Duties of the Parties:
JHU is not a commercial organization. It is an institute of research and education. Therefore, JHU
has no ability to evaluate the commercial potential of any PATENT RIGHT(S), LICENSED PRODUCT(S),
LICENSED SERVICE(S) or other license or rights granted in this Agreement. It is therefore incumbent
upon Company to evaluate the rights and products in question, to examine the materials and
information provided by JHU, and to determine for itself the validity of any PATENT RIGHT(S), its
freedom to operate, and the value of any LICENSED PRODUCT(S) or LICENSED SERVICE(S) or other rights
granted. 9.6 Disclaimer of Warranties: JHU does not warrant the validity of any patents or that the
practice under such patents, or the manufacture, use, sale or import of LICENSED PRODUCT(S) or
LICENSED SERVICE(S), shall be free from patent infringement. EXCEPT AS EXPRESSLY SET FORTH IN THIS
PARAGRAPH 9.6, COMPANY AGREES THAT THE PATENT RIGHT(S) ARE PROVIDED "AS IS", AND THAT JHU MAKES NO
REPRESENTATION OR WARRANTY WITH RESPECT TO THE PERFORMANCE OF LICENSED PRODUCTS OR LICENSED SERVICES
INCLUDING THEIR SAFETY, EFFECTIVENESS, OR COMMERCIAL VIABILITY. JHU DISCLAIMS ALL WARRANTIES WITH
REGARD TO LICENSED PRODUCTS AND LICENSED SERVICES UNDER THIS AGREEMENT, INCLUDING, BUT NOT LIMITED
TO, ALL WARRANTIES, EXPRESS OR IMPLIED, OF MERCHANTABILITY AND FITNESS FOR ANY PARTICULAR PURPOSE.
NOTWITHSTANDING ANY OTHER PROVISION OF THIS AGREEMENT, JHU ADDITIONALLY DISCLAIMS ALL OBLIGATIONS
AND LIABILITIES ON THE PART OF JHU AND INVENTORS, FOR DAMAGES, INCLUDING, BUT NOT LIMITED TO,
DIRECT, INDIRECT, SPECIAL, AND CONSEQUENTIAL DAMAGES, ATTORNEYS' AND EXPERTS' FEES, AND COURT COSTS
(EVEN IF JHU HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, FEES OR COSTS), ARISING OUT OF OR
IN CONNECTION WITH THE MANUFACTURE, USE, OR SALE OF THE LICENSED PRODUCTS AND LICENSED SERVICES
UNDER THIS AGREEMENT. COMPANY ASSUMES ALL RESPONSIBILITY AND LIABILITY FOR LOSS OR DAMAGE CAUSED BY
ANY PRODUCT OR SERVICE MANUFACTURED, USED, OR SOLD BY COMPANY WHICH IS A LICENSED PRODUCT OR
LICENSED SERVICE AS DEFINED IN THIS AGREEMENT.

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

8
<!-- page 9 -->
May 3, 2016 9.7 Indemnification: JHU and the Inventors will have no legal liability exposure to
third parties if JHU does not license the LICENSED PRODUCT(S) and LICENSED SERVICE(S), and any
royalties JHU and the Inventors may receive is not adequate compensation for such legal liability
exposure. Therefore, JHU requires Company to protect JHU and Inventors from such exposure to the
same manner and extent to which insurance, if available, would protect JHU and Inventors. JHU and
the Inventors will not, under the provisions of this Agreement or otherwise, have control over the
manner in which Company or those operating for its account or third parties who purchase LICENSED
PRODUCT(S) or LICENSED SERVICE(S) from any of the foregoing entities, practice the inventions of
LICENSED PRODUCT(S) and LICENSED SERVICE(S). The Company shall indemnify, defend with counsel
reasonably acceptable to JHU, and hold JHU, The Johns Hopkins Health Systems, their representatives
including but not limited to present and former, trustees, officers, Inventors, agents, faculty,
employees and students harmless as against any judgments, fees, expenses, or other costs arising
from or incidental to any product liability or other lawsuit, claim, demand or other action brought
as a consequence of the practice of said inventions by any of the foregoing entities, whether or not
JHU or said Inventors, either jointly or severally, is/are named as a party defendant in any such
lawsuit. Practice of the inventions covered by LICENSED PRODUCT(S) or LICENSED SERVICE(S) by an
agent or a third party on behalf of or for the account of the Company, or by a third party who
purchases LICENSED PRODUCT(S) or LICENSED SERVICE(S) from the Company, shall be considered the
Company's practice of said inventions for purposes of this Paragraph 9.7. The obligation of the
Company to defend and indemnify as set out in this Paragraph 9.7 shall survive the termination of
this Agreement and shall not be limited by any other limitation of liability elsewhere in the
Agreement. 9.8 Product Liability: Prior to first commercial sale of any LICENSED PRODUCT(S) or
LICENSED SERVICE(S) as the case may be in any particular country, Company shall establish and
maintain, in each country in which Company shall sell LICENSED PRODUCT(S) or LICENSED SERVICE(S),
product liability or other appropriate insurance coverage appropriate to the risks involved in
marketing LICENSED PRODUCT(S) and/or LICENSED SERVICE(S) and will annually present evidence to JHU
that such coverage is being maintained. Upon JHU's request, Company will furnish JHU with a
Certificate of Insurance of each product liability insurance policy obtained. JHU shall be listed as
an additional insured in Company's said insurance policies. If such Product Liability insurance is
underwritten on a 'claims made' basis, Company agrees that any change in underwriters during the
term of this Agreement will require the purchase of 'prior acts' coverage to ensure that coverage
will be continuous throughout the term of this Agreement. 9.9 Entire Agreement: This Agreement
constitutes the entire understanding between the parties with respect to the obligations of the
parties with respect to the subject matter hereof, and supersedes and replaces all prior agreements,
understandings, writings, and discussions between the parties relating to said subject matter.

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

9
<!-- page 10 -->
May 3, 2016 9.10 Amendment & Waiver: This Agreement may be amended and any of its terms or
conditions may be waived only by a written instrument executed by the authorized officials of the
parties or, in the case of a waiver, by the party waiving compliance. The failure of either party at
any time or times to require performance of any provision hereof shall in no manner affect its right
at a later time to enforce the same. No waiver by either party of any condition or term in any one
or more instances shall be construed as a further or continuing waiver of such condition or term or
of any other condition or term. 9.11 Binding Effect: This Agreement shall be binding upon and inure
to the benefit of and be enforceable by the parties hereto and their respective successors and
permitted assigns. 9.12 Governing Law: This Agreement shall be construed, and legal relations
between the parties hereto shall be determined, in accordance with the laws of the State of Maryland
applicable to contracts solely executed and wholly to be performed within the State of Maryland
without giving effect to the principles of conflicts of laws. Any disputes between the parties to
the Agreement shall be brought in the state or federal courts of Maryland. Both parties agree to
waive their right to a jury trial. 9.13 Headings: Article headings are for convenient reference and
are not a part of this Agreement. All Exhibits are incorporated herein by this reference. 9.14 Use
of Name: Nothing contained in this Agreement confers any right to either party hereto to use in
advertising, publicity, or other promotional activities any name, trade name, trademark, or other
designation of the other party hereto (including any contraction, abbreviation or simulation of any
of the foregoing). Unless otherwise required by law, LICENSEE is prohibited from using the name "The
Johns Hopkins University" or the name of any affiliate of the Johns Hopkins University, including
but not limited to The Johns Hopkins Health System Corporation, or any of its hospitals or
affiliates, or the names of any of their respective faculty, employees, students or INVENTORS, in
advertising, publicity, or other promotional activities, without JHU's prior written approval of
such use. JHU may disclose to all INVENTORS the terms and conditions of this Agreement upon their
request. JHU may acknowledge to third parties the existence of this Agreement and the extent of the
licenses granted to LICENSEE and AFFILIATES under Section 3 hereof, but JHU shall not disclose the
financial terms of this Agreement to third parties, except where JHU is required by law to do so.
LICENSEE hereby grants JHU permission to include LICENSEE's name and a link to LICENSEE's website in
JHU's annual reports and on JHU's website to showcase technology transfer-related stories. JHU shall
have the right to list LICENSEE and display the logotype or symbol of LICENSEE on JHU's website and
on JHU publications as a licensee startup company based upon JHU technology.

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

10
<!-- page 11 -->
May 3, 2016 IN WITNESS WHEREOF the respective parties hereto have executed this Agreement by their
duly authorized officers on the date appearing below their signatures. THE JOHNS HOPKINS UNIVERSITY
VIRTUOSO SURGICAL, INC. By: /s/ Neil Veloso By: /s/ C. Mark Pickrell Neil Veloso Name:C. Mark
Pickrell Executive Director Title: Attorney-in-Fact Johns Hopkins Technology Ventures Date:5/11/2016
Date:: 5/4/2016

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

11
<!-- page 12 -->
May 3, 2016 EXHIBIT A LICENSE FEES and ROYALTY 1. LICENSE FEE 1.1 The license fee due under
Paragraph 4.1 is two-thousand dollars ($2000). 1.2 In addition, COMPANY shall issue to JHU that
number of shares of common stock representing five percent (5%) of the outstanding common and
preferred shares on a fully diluted basis of COMPANY pursuant to an agreed upon stock purchase
agreement between COMPANY and JHU. The stock purchase agreement shall contain provisions protecting
JHU against dilution of its equity interest in the event the post-money valuation of any equity
investment is less than two million dollars ($2,000,000), and it will also contain a provision for
the piggy-back registration of common shares with any other class of stock in an initial public
offering. If COMPANY proposes to sell any equity securities or securities that are convertible into
equity securities of COMPANY (collectively, "Equity Securities") in any new round of financing, then
COMPANY shall offer JHU and/or its Assignee (as defined below) an opportunity to purchase either:
(i) up to that portion of the Equity Securities that equals JHU's then current, fully-diluted
percentage ownership interest in COMPANY, or (ii) if the percentage offered for sale by COMPANY is
less, then up to five percent (5%) of the Equity Securities offered for sale. Such offer to purchase
shall be on the same terms and conditions as are offered with respect to such Equity Securities sold
in such financing. For purposes of this section 7 of Exhibit A, the term "Assignee" means: (a) any
entity to which JHU's preemptive rights have been assigned either by JHU or by another entity, or
(b) any entity that is controlled by JHU. 2. EARNED ROYALTY 2.1 Annual Earned Royalty. COMPANY shall
pay an annual EARNED ROYALTY as follows: 2.1.1 Four percent (4%) of the sum of NET REVENUES. 2.2
Royalty Stacking. If COMPANY is required to pay running royalties on any patent rights not licensed
hereunder ("Other Royalties") in order to make, use or sell a particular LICENSED PRODUCT or
LICENSED SERVICE, COMPANY shall be entitled to credit half (50%) of such Other Royalties against the
Earned Royalty due, but the Earned Royalties shall not be reduced below fifty percent (50%) of those
that would otherwise be due JHU for that LICENSED PRODUCT or LICENSED SERVICE.

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

12
<!-- page 13 -->
May 3, 2016 2.3 Least Developed Countries. EARNED ROYALTY shall not be due and payable to JHU on NET
REVENUES generated from: (i) LICENSED PRODUCTS sold in Least Developed Countries as defined by the
United Nations Country Classification in the most recent United Nations' publication "Statistical
Annex" ("LEAST DEVELOPED COUNTRIES"); or (ii) LICENSED PRODUCTS sold to the Public Sector providing
LICENSED PRODUCTS at a Cost-Based Price in such Least Developed Countries, but only if COMPANY sells
such LICENSED PRODUCTS at COMPANY's cost of production thereof. 3. MINIMUM ANNUAL ROYALTIES 3.1 The
minimum annual royalties pursuant to the Agreement are: 1st anniversary of the EFFECTIVE DATE and
each subsequent anniversary of the EFFECTIVE DATE during the term: Three-thousand dollars ($3000)
3.2 Earned Royalties payable for each calendar year are creditable on a non-cumulative basis against
MINIMUM ANNUAL ROYALTIES for that year only. 4. LIQUIDITY EVENT 4.1 COMPANY will pay JHU a fee equal
one percent (1%) of the Aggregate Consideration received by the COMPANY, or the total amount
received by stockholders of COMPANY, upon the occurrence of a Liquidity Event. Such fee shall be
paid after only the first to occur of either a Liquidation Event or an Initial Public Offering. The
respective fees, when and if payable, shall be paid upon closing; except that if there are
additional contingent amounts ("Trailing Consideration") payable upon the occurrence of subsequent
events, then the Trailing Consideration shall be due and payable to JHU within thirty (30) days
after receipt thereof by COMPANY. 4.2 For a Liquidity Event, the fee required under Section 4.1 of
this Exhibit A above shall be payable to JHU by COMPANY in the same form as the proceeds paid or
payable to either COMPANY or its security holders, whether in cash, securities or other property,
and in the same proportion as such form of consideration is paid or payable to COMPANY or its
security holders. Notwithstanding the foregoing, in the event the form of consideration paid or
payable includes securities for which there is not an active public market, in lieu of paying that
portion of the fee with such securities COMPANY will make a cash payment to JHU equal to the fair
market value of such securities. The valuation of such securities shall be determined in accordance
with the definition of "Aggregate Consideration" set forth below. 4.3 For an Initial Public
Offering, the fee shall be payable in the form of cash, and shall be based upon the Pre Money
Valuation.

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

13
<!-- page 14 -->
May 3, 2016 4.4 "Aggregate Consideration" means the amount equal to: 4.4.1 In the case of an Asset
Sale, the sum of: (a) all cash, and the fair market value of all securities or other property
transferred to COMPANY at the time of the transaction, less all current and long-term liabilities
(but not contingent liabilities) of COMPANY that are not discharged or assumed by the buyer (or its
affiliates) in connection with the Asset Sale; and (b) all cash, and the fair market value of all
securities and other property for Trailing Consideration payable to COMPANY, when and if actually
paid; or 4.4.2 In the case of a Merger or Stock Sale, the sum of: (a) all cash, and the fair market
value of all securities and other property transferred to the stockholders of COMPANY (and any
option holders or warrant holders) in return for their stock (or options or warrants) in COMPANY at
the time of the transaction, and (b) all cash, and the fair market value of all securities and other
property transferred to the stockholders of COMPANY (and any option holders or warrant holders) for
Trailing Consideration payable to the holders of COMPANY's securities, when and if actually paid.
4.4.3 The valuation of any securities or other property shall be determined by reference to the
operative transaction agreement for a respective Merger, Stock Sale or Asset Sale, provided that, if
no such valuation is readily determinable from such operative transaction agreement, then for
securities for which there is an active public market: (a) If traded on a securities exchange or the
NASDAQ Stock Market, the value shall be deemed to be the average of the closing prices of the
securities on such exchange or market over the thirty day (30) period ending three (3) days prior to
the closing of such transaction; or (b) If actively traded over-the-counter, the value shall be
deemed to be the average of the closing bid prices over the thirty day (30) period ending three (3)
days prior to the closing of such transaction. (c) The method of valuation of securities subject to
investment letters or other similar restrictions on free marketability shall take into account an
appropriate discount from the market value as determined pursuant to clause (a) or (b) above so as
to reflect the approximate fair market value thereof. (d) For securities for which there is no
active public market, the value shall be the fair market value thereof as either: (i) determined in
good faith by the Board of Directors of COMPANY; (ii) approved by JHU, such approval not to be
unreasonably withheld; or (iii) determined by a third party appraiser appointed and paid for by
COMPANY.

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

14
<!-- page 15 -->
May 3, 2016 4.5 "Pre-Money Valuation" means the amount equal to the product of: (i) the price per
share of common stock sold in the Initial Public Offering, and (ii) the total number of outstanding
shares of common stock of COMPANY immediately prior to the closing of the Initial Public Offering,
determined on a fully diluted, as converted into common stock basis, giving effect to any stock
split, stock dividend, stock combination, recapitalization or similar action impacting COMPANY's
capitalization that occurs, or is deemed to occur, upon consummation of the Initial Public Offering.

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

15
<!-- page 16 -->
May 3, 2016 EXHIBIT B QUARTERLY SALES & ROYALTY REPORT FOR NON-EXCLUSIVE LICENSE AGREEMENT A29889
BETWEEN VIRTUOSO SURGICAL, INC. AND THE JOHNS HOPKINS UNIVERSITY EFFECTIVE DATE OF AGREEMENT
_________________ FOR PERIOD OF _________ TO _________ TOTAL ROYALTIES DUE FOR THIS PERIOD$_________

PRODUCT ID NO. PRODUCT NAME

*JHU REF NO.

PT COMMERCIAL SALE DATE TOTAL NE SALES/SERVICES ROYALTY RATE AMOUNT DUE

* Please provide the JHU Ref. C04873 This report format is to be used to report quarterly royalty
statements to JHU. It should be placed on Company letterhead and accompany any royalty payments due
for the reporting period. This report shall be submitted even if no sales are reported.

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019

16
<!-- page 17 -->
May 3, 2016 EXHIBIT C JHU Ref Number Technology Title Inventors Country/#

C04873 Active Cannulas for Bio-sensing and Surgical Intervention Allison M. Okamura Noah J. Cowan
Robert James Webster, III Russell H. Taylor

Japan 2008-541319

C04873 Active Cannulas for Bio-sensing and Surgical Intervention Allison M. Okamura Noah J. Cowan
Robert James Webster, III Russell H. Taylor

European Patent Office 06844376.1

C04873 Active Cannulas for Bio-sensing and Surgical Intervention Allison M. Okamura Noah J. Cowan
Robert James Webster, III Russell H. Taylor

Canada 2,630,061

C04873 Active Cannulas for Bio-sensing and Surgical Intervention Allison M. Okamura Noah J. Cowan
Robert James Webster, III Russell H. Taylor

Japan 2012-139088 5550682

C04873 Active Cannulas for Bio-sensing and Surgical Intervention Allison M. Okamura Noah J. Cowan
Robert James Webster, III Russell H. Taylor

Japan 2015-094824

C04873 Active Cannulas for Bio-sensing and Surgical Intervention Allison M. Okamura Noah J. Cowan
Robert James Webster, III Russell H. Taylor

Japan 2014-000372

C04873 Active Cannulas for Bio-sensing and Surgical Intervention Allison M. Okamura Noah J. Cowan
Robert James Webster, III Russell H. Taylor

China 200680050046.8 ZL 200680050046.8

C04873 Active Cannulas for Bio-sensing and Surgical Intervention Allison M. Okamura Noah J. Cowan
Robert James Webster, III Russell H. Taylor

United States 8,152,756

C04873 Active Cannulas for Bio-sensing and Surgical Intervention Allison M. Okamura Noah J. Cowan
Robert James Webster, III Russell H. Taylor

United States 8,715,226

Source: VIRTUOSO SURGICAL, INC., 1-A, 12/27/2019
