<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 1998-02-24 |
| Parties | Southern Racing Promotions, Inc. ("SRP"); Logan's Roadhouse, Inc. ("Logan's") |
| Source | CUAD v1 / LOGANSROADHOUSEINC_03_27_1998-EX-10.17-SPONSORSHIP AGREEMENT |

1 Exhibit 10.17

SPONSORSHIP AGREEMENT

THIS SPONSORSHIP AGREEMENT (the "Agreement") is made and entered into this the 24th day of February,
1998, by and between Southern Racing Promotions, Inc., ("SRP") a Tennessee corporation, and Logan's
Roadhouse, Inc., a Tennessee corporation ("Logan's"), with its principal place of business in
Nashville, Tennessee.

WHEREAS, SRP is engaged in the business of operating an automobile racing team;

WHEREAS, SRP is securing sponsorship funds to offset the direct costs of campaigning a NASCAR Late
Model Stock Car ("LMSC") Racing Team (the "Team") in the 1998 racing season at Nashville Motor
Speedway ("NMS");

WHEREAS, Logan's desires to become the primary sponsor of the Team to promote its restaurant concept
in Middle Tennessee and the southeastern United States; and

WHEREAS, the parties desire to set forth in this agreement their respective rights and obligations;

NOW, THEREFORE, in consideration of the promises and Agreements set forth herein, the parties hereto
agree as follows:

1. PRIMARY SPONSOR. For the 1998 racing season, Logan's shall be the primary sponsor of the Team,
which fields a LMSC racing vehicle (the "Race Car") driven by Brad Baker. During the term of this
Agreement, SRP will not represent any other product or company or accept as a primary, secondary,
associate or contingent decal sponsor any other product reasonably deemed by Logan's to be
competitive with Logan's.

2. TERM. The term of this Agreement shall commence on the date hereof and, unless terminated as
provided herein, shall continue through November 30, 1998.

3. SERVICES TO BE PROVIDED BY SRP. SRP shall perform the following services for Logan's in
connection with race programs:

(A) THE DRIVER. Except as specifically provided in this Agreement, Brad Baker ("Baker") will be the
only driver for the Team for the term of this Agreement. If Baker is unavailable to perform as
driver as a result of injury, illness or any other disability, or cause beyond his control, SRP
shall provide an alternate driver subject to the approval of Logan's ("Alternate Driver"), which
approval shall not be unreasonably withheld. Baker and any Alternate Driver appointed by SRP and
approved by Logan's pursuant to this Agreement are herein collectively

1 2

referred to as the "Driver." The Driver shall not drive for any other sponsor which competes with
Logan's. The Driver shall not drive any other race vehicle for any other sponsor than Logan's
without prior written notice from SRP to Logan's.

(B) ADVERTISING, ENDORSEMENTS, ETC. Unless otherwise provided in this Agreement, Logan's shall have
the right at no additional expense to use the name, likeness and voice of Baker for endorsements,
advertising and promotions in all forms of media.

(C) PUBLIC IMAGE. SRP shall be primarily responsible for developing and maintaining a positive
public image for the Driver and the Team. To facilitate this aim and in recognition of Logan's
sensitivity to any adverse publicity with respect to the Driver and the Racing Team, SRP shall be
responsible for the public image of the Driver and the Racing Team at all times, including but not
limited to any statement by the Driver or the Team in connection with press conferences, media
contact and any contact of the Driver or Team with the general public, whether at a race or
otherwise.

(D) CAR DESIGN. Consistent with NASCAR rules and regulations and the terms of Articles 4 and 5 of
this Agreement, SRP will develop a graphic design for the Race Car (the "Graphic Design"). SRP will
purchase decals for the Race Car based upon the Graphic Design and shall be responsible for painting
the Race Car in conformity with the Graphic Design.

(E) UNIFORMS. SRP will provide race day uniforms for up to a maximum of 12 personnel and a driver
suit for the Driver. Consistent with the NASCAR rules and regulations, and excluding any patches
required by NASCAR, Logan's shall have the exclusive right to promote its Logan's logo on uniforms
and Driver's suit on the areas depicted on Exhibit A to this Agreement. Logan's also shall have the
exclusive right to promote its Logan's trademark on the side of the helmet, as shown on Exhibit B to
this Agreement. Uniforms and Driver's suit may display one patch each for up to two secondary or
associate sponsors, provided such secondary or associate sponsors have been approved in advance by
Logan's, such patches to be located as mutually agreed upon by Logan's and SRP. The Driver shall not
appear in a race uniform or driving suit other than the
<!-- page 2 -->
Logan's uniform/suit in connection with or portraying involvement in NASCAR LMSC racing, whether or
not used in product advertising or promotion.

(F) CREDENTIALS. At the request of Logan's and consistent with NASCAR and race track rules,
regulations and procedures, SRP will use best efforts to secure credentials for the pre-race
admissions of a maximum of four designees of Logan's to pit row and/or the garage area of each
regularly scheduled or special LMSC event in which the Race Car competes.

(G) SHOW CAR. SRP will build and provide to Logan's a 1997 Ford Thunderbird automobile ("Show Car")
that will have an appearance identical to

2

3

that of the race car, to include full roll cage, race interior, paint, graphics and under-hood race
look. Logan's will provide equipment and driver to transport the Show Car to destinations and
according to schedules as determined by Logan's. At the expiration of this contract, Logan's will
return the Show Car to SRP in substantially the same condition as when received by Logan's, normal
wear and tear excepted.

(H) TRANSPORTER. SRP is attempting to purchase or lease a 53 foot semi-trailer to be pulled by a
Peterbilt class eight tractor which will function as the Race Car transporter (the "Transporter").
In the event SRP is successful in procuring the Transporter, it will be lettered and pictured with
Logan's racing graphics by SRP up to a maximum cost allowance of Two Thousand Five Hundred and
No/100's ($2,500.00), with Logan's retaining the right to apply more extensive graphics at its own
expense if Logan's so chooses. Any associate sponsor graphics appearing on the Transporter will be
displayed in a subservient manner to clearly reflect Logan's as the primary sponsor of the Team.

(I) AUTHORITY OF SRP. SRP hereby warrants that it has the authority to grant all rights to Baker
under this Article 3.

4. ASSOCIATE AND SECONDARY SPONSORSHIPS. SRP shall have the right to obtain secondary and associate
sponsors for the Race Car and Team, subject to the approval of Logan's, which approval shall not be
unreasonably withheld. SRP may not obtain any associate or secondary sponsors whose products or
concepts compete with Logan's. Any associate and/or secondary sponsor may promote its role as a
sponsor by signage, logos or trademarks on the Race Car, provided that such associate and/or
secondary sponsors signage, logos or trademarks used on the Race Car, when viewed collectively,
shall not cover any area greater than 25% of that of Logan's signage, logos or trademarks, nor
conflict with the graphic design, or in other locations or on clothing as may be permitted by the
terms of the Agreement. Logan's shall have the exclusive use of the hood, the rear quarter panel
area above the tire and the bottom of the deck lid (rear facing panel, TV panel) of the Race Car, as
shown on Exhibit C to this Agreement. All other areas permitted by NASCAR for sponsor signage, logos
or trademarks and the "spoiler space" are reserved for NASCAR, SRP and the associate and secondary
sponsors. All associate and secondary sponsors' graphic layouts for the Race Car are subject to
Logan's approval, which shall not be unreasonably withheld. Furthermore, SRP shall not permit any
associate or secondary sponsor to suggest in any manner that its sponsorship role is as great as
that of Logan's.

5. CONTINGENT SPONSORS. SRP intends to participate in NASCAR and NMS decal sponsor programs such as
a series sponsor, and race related products such as tires and fuel. Logan's acknowledges that NASCAR
or NMS require the placing of certain decals on the Race Car as a prerequisite for competing in a
racing event. SRP acknowledges that such required decals shall be placed forward of the

3

4

door panel, or as otherwise required by NASCAR rules and regulations, in a way not to detract from
Logan's signage.

6. COMPENSATION. In consideration of the services provided, SRP shall be entitled to a base fee of
Eighty Thousand Dollars and No/100's (580,000.00) payable as follows:

(i) $40,000.00 payable upon execution of this contract; and

(ii) the balance of $40,000.00 payable in eight equal monthly installments of $5,000 each, due the
first day of March, April, May, June, July, August, September and October, 1998.

7. TRADEMARKS. It is expressly understood that SRP may use the Logan's trademarks, logos or other
symbols only as directed or approved by Logan's and that Logan's may use the trademarks, logos,
symbols, name, likeness, voice or signature of the Driver, the Team or any secondary or associate
sponsor only as directed or approved by the Driver, or secondary sponsors, as appropriate. SRP may
license and use the Logan's name and Trademark in promotions directly related to the Race Car or the
Team, such as souvenir items, hats, shirts, etc. Upon termination of this Agreement, SRP and any
associate or secondary sponsors shall immediately cease all use of all Logan's trademarks, trade
names, service marks, logos, symbols or other designations, and Logan's shall immediately cease all
use of trademarks, trade names, service marks, logos, symbols or other
<!-- page 3 -->
designation of SRP or any associate or secondary sponsors, as well as any and all use of name,
likeness, voice or signature of the Driver.

8. CONFIDENTIALITY. Both parties shall exercise due care to protect the confidentiality of any
information exchanged between them as a result of this Agreement, including information exchanged
during the negotiation of this Agreement, and shall not use such information to the disadvantage of
the other party. However, nothing contained herein will prevent either party from fully utilizing
information already known to such party or information which is or becomes generally available to
the public through no fault of such party that has the right to disperse such information without
breaching any obligation to one of the parties to this Agreement. The parties each specifically
agree not to share confidential information received from the other party with any agent, including
their respective advertising agencies, unless the party wishing to share such information with this
agent receives written approval from the other party.

9. POWER AND AUTHORITY. Logan's and SRP warrant they have full power and authority to enter into and
perform this Agreement, and the transactions contemplated hereby have been duly and validly
authorized by all necessary corporate action, and each has the ability to provide the services
called for hereunder. Upon the execution and delivery of this agreement, it will be a valid and
binding obligation of Logan's and SRP in accordance with its terms. Logan's and

4

5

SRP further warrant they have not made, nor will make, any Agreement or commitment which would
prevent or interfere in any way with the full performance of the obligations hereunder or the full
enjoyment of the other party hereunder.

10. SPECIAL RIGHT OF TERMINATION. Either party shall have the right to terminate this Agreement,
subject to the following terms and conditions:

(a) Either party ("the Terminating Party") may terminate this Agreement upon prior written notice to
the other party (the "Defaulting Party") upon the occurrence of any of the following conditions:

(i) In the event that such party materially breaches this Agreement or materially defaults in the
performance of any obligation hereunder and fails to cure said breach within 30 days of written
notice to the Defaulting Party by the Terminating Party;

(ii) Immediately in the event that the Defaulting Party (including, for SRP, the Driver) commits any
crime involving moral turpitude or otherwise commits any act or is involved in any situation
bringing itself, the Terminating Party or the products of the Terminating Party into public hatred
or contempt, or engages in conduct that shocks or insults the community or brings the Terminating
Party, or its products into public disrespect, scandal or ridicule; or

(iii) In the event the LMSC series at NMS is canceled.

(b) In the event Logan's terminates this Agreement pursuant to this Article 10, Logan's shall be
entitled to a pro rata refund of amounts prepaid for the current calendar year, with no further
obligations under this Agreement.

11. FORCE MAJEURE. Neither party hereto will be considered in default of this Agreement or be liable
for damages therefor, for any failure of performance hereunder occasioned by an Act of God, force of
nature, physical casualty, accident, war or warlike activity, insurrection or civil disorder or
other cause beyond its reasonable control, provided the party so affected gives prompt notice to the
other.

12. RELEASE. Except as may be otherwise provided in this Agreement, including amounts due SRP from
Logan's under Article 6 of this Agreement, neither SRP nor its employees or agents shall make any
claims against Logan's with respect to any remuneration in the nature of salary or otherwise for any
cost, damage, loss or expense incurred for any reason, including, but not limited to, damage, injury
or death which may be suffered by SRP or its employees or agents, third parties, or any property of
SRP or property of its agents or employees, or property of any third parties. SRP shall obtain from
the Driver and from each of its employees who is a member of the Team a release in favor of Logan's
from all liability with respect to any of the above.

5

6

13. INSURANCE. SRP shall provide at its expense, and maintain throughout the term of this Agreement,
comprehensive general liability insurance in the amount of Five Million Dollars and No/100's
($5,000,000.00) per occurrence with respect to any liability relating to the activities of SRP in
the performance of this Agreement SRP shall supply Logan's with a copy of the Certificate of
Insurance naming Logan's as an additional insured. Such policies shall provide for at least fifteen
(15) days' written notice to Logan's of the cancellation or substantial modification thereof. Such
insurance will be supplemental coverage in excess of the Five Million Dollars ($5,000,000.00)
<!-- page 4 -->
primary coverage provided to SRP and Logan's by the comprehensive liability policy of NMS.

14. NOTICES. All notices required or permitted hereunder shall be in writing and shall be deemed to
be properly given: (a) when personally delivered to the party entitled to receive the notice; (b)
upon receipt of facsimile message confirmed by first class mail, postage prepaid; (c) upon receipt
of package delivered by overnight courier; or (d) when sent by certified or registered mail, postage
prepaid properly addressed.

15. WAIVERS. A waiver of any provision of this Agreement shall be enforceable only if the waiver is
in writing signed by the party against whom the waiver is sought to be enforced. A failure by a
party at any time to exercise any rights hereunder shall not constitute a waiver of such rights at
another time.

16. NATURE OF RELATIONSHIP. The parties expressly acknowledge and agree that SRP is acting as an
independent contractor and not as a employee of, or partner or joint venturer with, Logan's. Each
party is responsible for all taxes relating to its operation, including payroll taxes for its
employees.

17. AMENDMENTS AND ASSIGNMENTS. This Agreement may not be modified or assigned except in writing
signed by SRP and Logan's.

18. GOVERNING LAW. This Agreement shall be constructed under and governed by the laws of the State
of Tennessee.

19. SEVERABILITY. In the event that any provision of this Agreement is for any reason found and
declared to be invalid, illegal or unenforceable, then such provision shall be deemed amended only
to the extent necessary to eliminate such invalidity, illegality or unenforceability. In any such
event, the validity of the remaining portions or provisions of this Agreement shall not be affected.

20. BENEFITS. This Agreement shall inure to the benefit of and be binding upon the parties and their
respective heirs, executors, administrators, successors and permitted assigns.

21. CAPTIONS. Sections, titles or captions contained in this Agreement are inserted as a matter of
convenience and for reference and in no way define, limit,

6

7

extend or describe the scope of this Agreement or the intent of any provision thereof.

22. COUNTERPARTS. This Agreement may be executed in multiple counterparts, each of which shall be
deemed an original, but all of which taken together shall constitute but one in the same instrument.

23. ENTIRE AGREEMENT. This Agreement contains the entire understanding between the parties with
respect to the subject matter hereof and supersedes all prior written or oral agreements between
them with respect to the subject to the subject matter hereof.

IN WITNESS WHEREOF, the parties have executed this Agreement.

Logan's Roadhouse, Inc.

By: /s/ Edwin W. Moats, Jr. -------------------------------

Name: Edwin W. Moats, Jr. -------------------------------

Title: President and CEO -------------------------------

Southern Racing Promotions, Inc.

By: /s/ Gary T. Baker -------------------------------

Name: Gary T. Baker -------------------------------

Title: President -------------------------------

7
