"""Convert CUAD v1 (data/raw/cuad, see scripts/fetch_cuad.py) into the loader's document format.

    .venv/Scripts/python.exe -I scripts/make_cuad_corpus.py              # all 510 contracts (~2 min)
    .venv/Scripts/python.exe -I scripts/make_cuad_corpus.py --limit 20   # quick look
    .venv/Scripts/python.exe -I scripts/make_cuad_corpus.py --stats      # re-print the summary from _alignment.json

Output, per contract, in data/cuad_docs/:
    <stem>.md         '<!-- page N -->' on its own line before every page; page 1 opens with a
                      '# Title' heading and a metadata table (same shape as data/sample_docs).
    <stem>.meta.json  sidecar: title, doc_type, date, parties, plus provenance and alignment flags
                      (pages_approximate, pages_located, cuad_title, source_pdf, ...).
    _alignment.json   one record per stem: the page start offsets in the ORIGINAL CUAD text, so
                      scripts/make_cuad_golden.py can map annotation offsets to pages exactly.

Design
------
* The body is the CUAD text (`CUAD_v1.json` context == `full_contract_txt/*.txt`), never the PDF
  text: the 13k expert annotations are character offsets into that text, and the PDF extraction
  is often worse (ligatures, mid-word breaks, column order). The PDF is used only to find where
  each page begins (dr.ingest.pages, anchor lines), so page citations refer to the real PDF page.
* Each page's text is then reflowed: runs of whitespace collapse to one space and long lines are
  wrapped at WRAP_COLS, but original line breaks are kept and reflow never crosses a page start,
  so an annotated span always lands on the page(s) computed from its original offset. Gold answers
  are therefore compared whitespace-insensitively (see data/golden/README.md).
* Metadata: title = CUAD "Document Name" span; doc_type = the category folder of the PDF; date =
  CUAD "Agreement Date" answer (else "Effective Date", else the filing date in the file name),
  ISO-formatted; parties = CUAD "Parties" answer ('A ("Role"); B ("Role")').
* CUAD is untrusted third-party data: everything here is parsing; nothing is executed.
"""
from __future__ import annotations

import argparse
import csv
import datetime as _dt
import json
import re
import sys
import textwrap
import time
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dr.ingest.pages import (  # noqa: E402
    PageAlignment, locate_page_starts, normalize_stream, pdf_page_texts, snap_to_line_starts, _norm_key,
)

RAW = ROOT / "data" / "raw" / "cuad" / "CUAD_v1"
OUT = ROOT / "data" / "cuad_docs"
ALIGNMENT = OUT / "_alignment.json"
WRAP_COLS = 100
SUSPECT_RATIO = 0.35   # |len(text page) - len(pdf page)| / len(pdf page) above this -> suspect page

DOC_TYPE_BY_FOLDER = {
    "affiliate_agreements": "Affiliate Agreement", "affiliate agreement": "Affiliate Agreement",
    "agency agreements": "Agency Agreement", "co_branding": "Co-Branding Agreement",
    "collaboration": "Collaboration Agreement", "consulting agreements": "Consulting Agreement",
    "development": "Development Agreement", "distributor": "Distributor Agreement",
    "endorsement": "Endorsement Agreement", "endorsement agreement": "Endorsement Agreement",
    "franchise": "Franchise Agreement", "hosting": "Hosting Agreement", "ip": "IP Agreement",
    "joint venture": "Joint Venture Agreement", "joint venture_filing agreement": "Joint Venture Agreement",
    "license_agreements": "License Agreement", "maintenance": "Maintenance Agreement",
    "manufacturing": "Manufacturing Agreement", "marketing": "Marketing Agreement",
    "non_compete_non_solicit": "Non-Compete / Non-Solicit Agreement", "outsourcing": "Outsourcing Agreement",
    "promotion": "Promotion Agreement", "reseller": "Reseller Agreement", "service": "Service Agreement",
    "sponsorship": "Sponsorship Agreement", "strategic alliance": "Strategic Alliance Agreement",
    "supply": "Supply Agreement", "transportation": "Transportation Agreement",
}


# --------------------------------------------------------------------------- helpers


def ws(s: str) -> str:
    """Whitespace-collapsed form (the comparison form for gold answers)."""
    return " ".join(s.split())


def slug(title: str) -> str:
    s = unicodedata.normalize("NFKD", title).encode("ascii", "ignore").decode()
    s = re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")
    return s[:80].rstrip("_") or "doc"


def doc_type_of(pdf_path: Path) -> str:
    folder = pdf_path.parent.name
    key = folder.strip().lower()
    if key in DOC_TYPE_BY_FOLDER:
        return DOC_TYPE_BY_FOLDER[key]
    words = re.sub(r"[_]+", " ", folder).strip()
    return words if "agreement" in words.lower() else f"{words} Agreement"


_DATE_FORMATS = ("%m/%d/%y", "%m/%d/%Y", "%Y-%m-%d", "%B %d, %Y", "%b %d, %Y", "%d %B %Y")


def iso_date(raw: str) -> str | None:
    raw = ws(raw).strip(" .")
    for fmt in _DATE_FORMATS:
        try:
            return _dt.datetime.strptime(raw, fmt).date().isoformat()
        except ValueError:
            continue
    return None


_FNAME_DATE_RES = (re.compile(r"_(\d{2})_(\d{2})_(\d{4})-"), re.compile(r"_(\d{4})(\d{2})(\d{2})_"))


def filename_date(title: str) -> str | None:
    m = _FNAME_DATE_RES[0].search(title)
    if m:
        mm, dd, yyyy = m.groups()
        try:
            return _dt.date(int(yyyy), int(mm), int(dd)).isoformat()
        except ValueError:
            return None
    m = _FNAME_DATE_RES[1].search(title)
    if m:
        yyyy, mm, dd = m.groups()
        try:
            return _dt.date(int(yyyy), int(mm), int(dd)).isoformat()
        except ValueError:
            return None
    return None


def reflow(text: str) -> list[str]:
    """Collapse whitespace runs, wrap long lines, keep original line breaks, squeeze blank runs."""
    out: list[str] = []
    blank = False
    for raw in text.split("\n"):
        line = ws(raw)
        if not line:
            if not blank and out:
                out.append("")
            blank = True
            continue
        blank = False
        if len(line) <= WRAP_COLS:
            out.append(line)
        else:
            out.extend(textwrap.wrap(line, WRAP_COLS, break_long_words=False, break_on_hyphens=False) or [line])
    while out and out[-1] == "":
        out.pop()
    return out


def md_table(rows: list[tuple[str, str]]) -> list[str]:
    body = ["| Field | Value |", "|---|---|"]
    for k, v in rows:
        if v:
            body.append(f"| {k} | {v.replace('|', '/')} |")
    return body


# --------------------------------------------------------------------------- inputs


def load_inputs() -> tuple[list[dict], dict[str, dict], dict[str, Path]]:
    data = json.loads((RAW / "CUAD_v1.json").read_text(encoding="utf-8"))["data"]
    with (RAW / "master_clauses.csv").open(encoding="utf-8", newline="") as f:
        rows = {_norm_key(r["Filename"].rsplit(".", 1)[0]): r for r in csv.DictReader(f)}
    pdfs: dict[str, Path] = {}
    for p in RAW.rglob("*"):
        if p.suffix.lower() == ".pdf":
            pdfs.setdefault(_norm_key(p.stem), p)
    return data, rows, pdfs


def match_pdf(title: str, context: str, pdfs: dict[str, Path], taken: set[Path]) -> Path | None:
    """By normalized file name first; otherwise the unmatched PDF whose first page is found in the text."""
    p = pdfs.get(_norm_key(title))
    if p is not None:
        return p
    stream, _ = normalize_stream(context[:20000])
    best: tuple[int, Path] | None = None
    for cand in pdfs.values():
        if cand in taken:
            continue
        try:
            first = _norm_key(pdf_page_texts(cand)[0])
        except Exception:  # noqa: BLE001 - unreadable PDF: skip it
            continue
        probes = [first[i:i + 40] for i in range(0, min(len(first), 400), 80) if len(first[i:i + 40]) == 40]
        score = sum(1 for pr in probes if pr in stream)
        if probes and score >= max(3, len(probes) - 1) and (best is None or score > best[0]):
            best = (score, cand)
    return best[1] if best else None


# --------------------------------------------------------------------------- conversion


def convert_one(entry: dict, csv_row: dict | None, pdf_path: Path | None, stem: str) -> tuple[str, dict, dict]:
    """Return (markdown, sidecar, alignment_record) for one contract."""
    context: str = entry["paragraphs"][0]["context"].replace("\r", " ")
    qas = {q["id"].rsplit("__", 1)[-1]: q for q in entry["paragraphs"][0]["qas"]}

    def spans(cat: str) -> list[str]:
        return [ws(a["text"]) for a in qas.get(cat, {}).get("answers", []) if ws(a["text"])]

    # ---- page alignment (PDF -> offsets into the original text)
    suspect: list[int] = []
    if pdf_path is not None:
        page_texts = pdf_page_texts(pdf_path)
        al = locate_page_starts(context, page_texts)
        if al.n_pages == 0:
            al = PageAlignment(n_pages=1, starts=[0], located=[True], blank=[False], approximate=True)
            page_texts = [""]
        starts = snap_to_line_starts(context, al.starts)
        stream, index = normalize_stream(context)
        import bisect
        for i in range(al.n_pages):
            s, e = starts[i], (starts[i + 1] if i + 1 < al.n_pages else len(context))
            md_len = bisect.bisect_left(index, e) - bisect.bisect_left(index, s)
            pdf_len = len(_norm_key(page_texts[i]))
            if pdf_len >= 40 and abs(md_len - pdf_len) / pdf_len > SUSPECT_RATIO:
                suspect.append(i + 1)
    else:
        al = PageAlignment(n_pages=1, starts=[0], located=[False], blank=[False], approximate=True)
        starts = [0]

    # ---- metadata
    title = (spans("Document Name") or [""])[0].strip(" (-:,;.\"'")
    doc_type = doc_type_of(pdf_path) if pdf_path else "Agreement"
    if not title:
        title = doc_type
    date_source, date = "", None
    if csv_row:
        for col, src in (("Agreement Date-Answer", "cuad:Agreement Date"), ("Effective Date-Answer", "cuad:Effective Date")):
            d = iso_date(csv_row.get(col, "") or "")
            if d:
                date, date_source = d, src
                break
    if not date:
        date = filename_date(entry["title"])
        date_source = "filename (SEC filing date)" if date else ""
    parties = ""
    if csv_row and ws(csv_row.get("Parties-Answer", "") or ""):
        parties = ws(csv_row["Parties-Answer"])
    else:
        seen: list[str] = []
        for p in spans("Parties"):
            if p not in seen and len(p) > 3:
                seen.append(p)
        parties = "; ".join(seen)

    # ---- body: metadata block + reflowed pages
    head = [f"# {title}"]
    head += md_table([
        ("Document Type", doc_type),
        ("SEC Filing Date" if date_source.startswith("filename") else "Agreement Date", date or ""),
        ("Parties", parties),
        ("Source", f"CUAD v1 / {entry['title']}"),
    ])
    head.append("")
    lines: list[str] = []
    for i, s in enumerate(starts):
        e = starts[i + 1] if i + 1 < len(starts) else len(context)
        lines.append(f"<!-- page {i + 1} -->")
        if i == 0:
            lines.extend(head)
        lines.extend(reflow(context[s:e]))
    markdown = "\n".join(lines) + "\n"

    sidecar = {
        "title": title,
        "doc_type": doc_type,
        "date": date or "",
        "parties": parties,
        "date_source": date_source,
        "cuad_title": entry["title"],
        "source_pdf": str(pdf_path.relative_to(ROOT)).replace("\\", "/") if pdf_path else "",
        "n_pages": len(starts),
        "pages_approximate": bool(al.approximate),
        "pages_located": int(sum(al.located)),
        "pages_suspect": suspect,
        "license": "CC BY 4.0 (CUAD v1, The Atticus Project)",
    }
    record = {
        "stem": stem,
        "cuad_title": entry["title"],
        "source_pdf": sidecar["source_pdf"],
        "n_pages": len(starts),
        "page_starts": starts,           # offsets into the ORIGINAL context (after '\r' -> ' ')
        "located": [bool(x) for x in al.located],
        "approximate": bool(al.approximate),
        "suspect_pages": suspect,
        "n_chars": len(context),
    }
    return markdown, sidecar, record


def summarize(records: list[dict]) -> str:
    n = len(records)
    pages = sum(r["n_pages"] for r in records)
    approx = sum(1 for r in records if r["approximate"])
    no_pdf = sum(1 for r in records if not r["source_pdf"])
    located = sum(sum(r["located"]) for r in records)
    suspect = sum(len(r["suspect_pages"]) for r in records)
    return (f"{n} documents, {pages} pages ({pages / max(n, 1):.1f}/doc); "
            f"{located} page starts anchored ({located / max(pages, 1):.1%}); "
            f"{approx} documents with approximate pages; {no_pdf} without a PDF; "
            f"{suspect} pages whose length disagrees with the PDF (> {SUSPECT_RATIO:.0%})")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--limit", type=int, default=0, help="convert only the first N contracts (for a quick look)")
    ap.add_argument("--stats", action="store_true", help="only print the summary from an existing _alignment.json")
    args = ap.parse_args()
    if args.stats:
        print(summarize(json.loads(ALIGNMENT.read_text(encoding="utf-8"))))
        return 0
    if not (RAW / "CUAD_v1.json").exists():
        print(f"CUAD not found under {RAW}: run scripts/fetch_cuad.py first", file=sys.stderr)
        return 2

    data, csv_rows, pdfs = load_inputs()
    data = sorted(data, key=lambda t: t["title"].lower())
    if args.limit:
        data = data[: args.limit]
    OUT.mkdir(parents=True, exist_ok=True)
    for old in list(OUT.glob("*.md")) + list(OUT.glob("*.meta.json")):
        old.unlink()

    t0 = time.time()
    stems: set[str] = set()
    taken: set[Path] = set()
    records: list[dict] = []
    for i, entry in enumerate(data, start=1):
        title = entry["title"]
        pdf_path = match_pdf(title, entry["paragraphs"][0]["context"], pdfs, taken)
        if pdf_path is not None:
            taken.add(pdf_path)
        base = slug(title)
        stem, k = base, 2
        while stem in stems:
            stem, k = f"{base[:76]}_{k}", k + 1
        stems.add(stem)
        markdown, sidecar, record = convert_one(entry, csv_rows.get(_norm_key(title)), pdf_path, stem)
        (OUT / f"{stem}.md").write_text(markdown, encoding="utf-8", newline="\n")
        (OUT / f"{stem}.meta.json").write_text(json.dumps(sidecar, ensure_ascii=False, indent=1), encoding="utf-8")
        records.append(record)
        if i % 50 == 0 or i == len(data):
            print(f"  {i}/{len(data)}  {time.time() - t0:.0f}s")
    ALIGNMENT.write_text(json.dumps(records, ensure_ascii=False), encoding="utf-8")
    print(f"wrote {OUT} in {time.time() - t0:.0f}s")
    print(summarize(records))
    missing = [r["cuad_title"] for r in records if not r["source_pdf"]]
    if missing:
        print("no PDF matched (single approximate page):", missing)
    return 0


if __name__ == "__main__":
    sys.exit(main())
