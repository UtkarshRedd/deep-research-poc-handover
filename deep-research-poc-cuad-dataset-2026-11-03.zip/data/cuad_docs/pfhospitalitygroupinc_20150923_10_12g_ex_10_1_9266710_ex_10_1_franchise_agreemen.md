<!-- page 1 -->
# FORM OF FRANCHISE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Franchise Agreement |
| SEC Filing Date | 2015-09-23 |
| Parties | Pizza Fusion Holding, Inc. ("we", "us", "our"); the individual or legal entity identified on the cover page ("Franchisee", "You", "your") |
| Source | CUAD v1 / PfHospitalityGroupInc_20150923_10-12G_EX-10.1_9266710_EX-10.1_Franchise Agreement1 |

FORM OF FRANCHISE AGREEMENT Location of the Premises: Agreement Date Franchisee Business Address

Type of Legal Entity (if applicable) State in which entity organized (if applicable) Shareholder /
Partner / Member Name Ownership Percentage % (the "Operating Principal") % % % %

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 2 -->
TABLE OF CONTENTS SECTION PAGE 1. RIGHTS GRANTED 2 2. TERM; SUCCESSOR FRANCHISE AGREEMENTS 4 3. FEES
4 4. OPENING DEADLINE 6 5. TRAINING 10 6. OPERATIONS 11 7. PROPRIETARY MARKS 18 8. BUSINESS RECORDS
AND REPORTING 19 9. MARKETING FUND AND ADVERTISING 21 10. TECHNOLOGY 23 11. OPERATING MANUAL 26 12.
CONFIDENTIAL INFORMATION 26 13. TRANSFERS BY US 26 14. TRANSFERS BY YOU 27 15. TERMINATION 29 16.
OBLIGATIONS ON TERMINATION OR EXPIRATION 31 17. RESTRICTIONS ON COMPETITION 33 18. RELATIONSHIP OF
THE PARTIES 34 19. INDEMNIFICATION 35 20. CONSENTS AND WAIVERS 35 21. NOTICES 35 22. ENTIRE
AGREEMENT AND AMENDMENTS 35 23. CONSTRUCTION OF THE AGREEMENT, SEVERABILITY, AND SURVIVAL 36 24.
GOVERNING LAW 36 25. DISPUTES 36 26. ACKNOWLEDGMENTS 37 Appendix A - Opening Deadline,
Delivery/Catering and Advertising Area, and Site Selection Area Appendix B - Personal Guarantee
Appendix C - Sample of Non-Disclosure and Non-Competition Agreement - i -

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 3 -->
Pizza Fusion Holdings, Inc. Franchise Agreement This Franchise Agreement (the "Agreement") is
entered into as of the Agreement Date shown on the cover page between Pizza Fusion Holding, Inc., a
Florida corporation, and the individual or legal entity identified on the cover page ("Franchisee").
If Franchisee is a corporation, partnership, or limited liability company, then the Franchisee's
owner(s) are also identified on the cover page. In this Agreement, "we," "us" and "our" refers to
Pizza Fusion Holding, Inc., the franchisor. "You" and "your" refers to the Franchisee. "Owners"
means the person(s) listed on the cover page and all other persons whom we may subsequently approve
to acquire an interest in Franchisee. "Operating Principal" means the person designated as the
Operating Principal on the cover page and who meets the criteria in Section 6.15 of this Agreement.
RECITALS A. We are in the business of franchising others to operate "Pizza Fusion" restaurant
businesses, which feature a competitively priced menu of organic and all-natural gourmet pizza and
related food specialties, and standards and methods of operation designed to be "green," and which
are operated in buildings that bear our interior and/or exterior trade dress (each a "Restaurant" or
"Franchised Business"). B. We have developed a distinctive set of specifications and operating
procedures (collectively, the "System") for Restaurants. The distinguishing characteristics of the
System include: dough, sauce, and other recipes and products that are prepared or manufactured in
accordance with our proprietary and/or secret recipes, trade secrets, standards, and specifications
that we deem secret ("Secret Recipe Products") and other designated and approved products; standards
and procedures for business operations, including "green" design, construction, and operating
practices; equipment layouts, graphics packages and signage, distinctive interior and exterior
design and accessories, quality and uniformity of products and services offered; procedures for
management and inventory control; training and assistance; advertising and promotional programs; and
customer development and service techniques. These are not necessarily all of the elements of the
System. We may change, improve, add to, delete from, and further develop the elements of the System
from time to time. C. We identify the businesses operating under the System by means of the "Pizza
Fusion" name and certain other trademarks, service marks, trade names, signs, logos, and other
indicia of origin (collectively, the "Proprietary Marks"). We may designate other trade names,
service marks, and trademarks (and also periodically delete old names and marks) as Proprietary
Marks. D. You understand the importance of our high standards of quality, appearance, and service
and the necessity of operating your Franchised Business in accordance with this Agreement and our
standards, specifications and procedures. Therefore, the parties, who each intend to be legally
bound by this Agreement, and for good and valuable consideration, now agree as follows: Page 1 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 4 -->
1. RIGHTS GRANTED 1.1. Grant of Franchise. 1.1.1 We grant you the right, and you accept the
obligation, to use the Proprietary Marks and the System to operate one Restaurant (the "Franchised
Business") at the Premises, in accordance with the terms of this Agreement. The term "Premises"
means the location shown on the cover page to this Agreement or a location that is determined under
process set out in Section 4.1 [Site Selection and Approval] below. 1.1.2 Your rights under this
Agreement have limits, such as the following: (a) You have no right to operate the Franchised
Business at any location other than the Premises, as described in Section 1.2 [Activities of
Franchised Business] below; (b) You have no right to sublicense either the Proprietary Marks or the
System to anyone else; and (c) You have no right to use the Proprietary Marks or the System in any
manner except as expressly authorized under this Agreement. 1.2. Activities of Franchised Business.
1.2.1 You may operate the Franchised Business only from the Premises, only in accordance with the
requirements of this Agreement and the procedures and terms and conditions set forth in the Pizza
Fusion Manuals, and only to sell Products to: (a) retail customers for consumption on the Premises
or for personal, carry out consumption; and (b) catering and delivery customers who are located
within the area specified in Exhibit A as the "Delivery/Catering and Advertising Area". We may
specify terms and conditions for catering and delivery activities, which may include guidelines and
requirements relating to insurance coverage, vehicle use in such activities, and use of a third
party phone order processing center as we may require. Without our prior written approval, you may
not engage in any other type of sale, including, but not limited to: selling, distributing, or
otherwise providing, any services or products to third parties at wholesale, or for resale or
distribution by any third party; and selling, distributing or otherwise providing any products
and/or services through catalogs, mail order, toll free numbers for delivery, or electronic means
(e.g., the Internet). You acknowledge and agree that the sole purpose of the Delivery/Catering and
Advertising Area is to specify the geographic area in which you will be authorized to provide
catering and delivery services and conduct advertising under the terms of this Agreement, and that
the designation of the Delivery/Catering and Advertising Area does not grant, and will not be
implied to grant, any territorial rights or protections to you or the Franchised Business, and we
reserve all other rights as set forth in Section 1.3 [Our Limitations and Our Reserved Rights]
below. 1.2.2 You may advertise and market the Franchised Business and directly solicit customers
only within your Delivery/Catering and Advertising Area (subject to Section 9.3 [Regional Fund]
below). You agree not to: (a) advertise or market the services of your Franchised Business outside
of the Delivery/Catering and Advertising Area; and/or (b) engage in direct solicitation of customers
outside of the Delivery/Catering and Advertising Area. The term "direct solicitation" includes, but
is not limited to, solicitation in person, by telephone, by mail, by e-mail, the internet, or other
electronic means, advertising, marketing, and by distribution of brochures, business cards or other
materials. 1.2.3. If any of your advertising within the Delivery/Catering and Advertising Area is in
media that will or may reach a significant number of persons outside of the Delivery/Catering and
Advertising Area, you must notify us in advance and obtain our prior written consent (in addition to
the requirements in Section 9.3 [Regional Fund] below). We may periodically establish rules and
policies regarding such advertising. Page 2 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 5 -->
1.3. Our Limitations and Our Reserved Rights. The rights granted to you under this Agreement are not
exclusive. We and our affiliates have the right to conduct any business activities, under any name,
and at (or from) any location notwithstanding those business activities' actual or threatened impact
on sales of the Franchised Business. For example, we may, among other things, on any terms and
conditions we deem advisable, and without granting you any rights therein, do any or all of the
following: 1.3.1 We have the right to establish, and license others to establish, Franchised
Businesses at any location notwithstanding their proximity to the Franchised Business or the
Premises or their actual or threatened impact on sales of the Franchised Business. 1.3.2 We have the
right to establish, and license others to establish, businesses under other systems or other
proprietary marks, which businesses may offer or sell products and services that are different from
the principal products and services offered from the Franchised Business, and which businesses may
be located within or outside the Premises, notwithstanding such business' proximity to the
Franchised Business or the Premises or their actual or threatened impact on sales of the Franchised
Business. 1.3.3 We have the right to acquire and operate any business of any kind or be acquired by
another business, notwithstanding such business' actual or threatened impact on sales of the
Franchised Business. 1.3.4 We have the right to establish, and license others to establish,
Restaurants at any Institutional Facility (as defined below), notwithstanding such Restaurants'
proximity to the Franchised Business or their actual or threatened impact on sales of the Franchised
Business. The term "Institutional Facility" is agreed to mean any outlet that primarily serves the
customers located within the facility, such as captive audience facilities and limited purpose or
limited access facilities, and includes among other things: airports; train or bus stations; travel
plazas; factories; federal, state or local government facilities (including military bases);
hospitals and other health-care facilities; stadiums and arenas; recreational facilities; schools,
colleges and other academic facilities; convention centers; seasonal facilities; shopping malls;
theaters; museums; and workplace cafeterias. 1.3.5 We have the right to sell and distribute,
directly or indirectly, through any channels of distribution (including, but not limited to,
supermarkets, gourmet shops, mail order, and on the internet) any products or services (including
products and services that are the same or similar to those offered by Restaurants and using the
Pizza Fusion name), from any location or to any purchaser or customer, advertise in any area
(including in your Delivery/Catering and Advertising Area) and/or serve customers who reside within
your Delivery/Catering and Advertising Area. You acknowledge that customers have total freedom to
select the Pizza Fusion Restaurant that they wish to patronize. 1.3.6 We have the right to provide,
and license others to provide, products or services to Major Accounts (as that term is defined
below) at any location, notwithstanding such Major Accounts' proximity to the Franchised Business or
the Premises or their actual or threatened impact on sales at the Franchised Business. The term
"Major Account" is agreed to mean any customer we designate as such, based upon our sole
determination that, because such customer conducts its business at multiple locations and we deem
this customer to be of strategic importance, the account, services and pricing of such customer
shall be negotiated and secured either (i) by us or (ii) with our assistance, approval and
oversight; as further described in Section 6.12 [Major Accounts] below. 1.4. Limitations. You agree
not to engage in any of the sales activities that we have reserved to ourselves in Sections 1.3 [Our
Limitations and Our Reserved Rights] above. Page 3 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 6 -->
2. TERM; SUCCESSOR FRANCHISE AGREEMENTS 2.1. Term. This Agreement expires ten (10) years from the
Agreement Date (the "Term"), unless it is terminated sooner as provided in other sections of this
Agreement. 2.2. Successor Franchise Agreements. When this Agreement expires, you will have the
option to continue the franchise relationship with us for two (2) additional terms of ten (10) years
each. We may require you to satisfy any or all of the following as a condition of continuing the
franchise relationship with us: 2.2.1. You must give us written notice of your desire to exercise
your option not more than twelve (12) months and not less than nine (9) months before this Agreement
expires. 2.2.2. You and all Owners must execute the standard form of Pizza Fusion Franchise
Agreement that we are then offering to new franchisees (or the standard form that we most recently
offered to new franchisees, if we are not at that time actively offering new franchises) (the
"Successor Franchise Agreement"). The terms of the Successor Franchise Agreement may be
substantially different from the terms of this Agreement and may require the payment of different
fees. 2.2.3. You must pay all amounts owed to us, to our affiliates, and to your major suppliers;
you must not be in default of this Agreement or any other agreement with us, our affiliates, or our
suppliers; and you must have substantially and timely complied with all of your obligations
throughout the term of each such agreement. 2.2.4. If we inspect your Franchised Business and give
you notice at least six months before the end of the term of any required maintenance, refurbishing,
renovating, and upgrading (including purchasing one or more new delivery vehicles); then you must
complete all such required maintenance, refurbishing, renovating, and upgrading to our reasonable
satisfaction no later than 60 days before expiration of the term. 2.2.5. You must pay us a
discounted successor franchise fee in the amount of $7,500 or twenty-five percent (25%) of our then-
current initial franchise fee (whichever is more). 2.2.6. You and all of your Owners must execute
and deliver to us a general release, in a form we require, of any and all claims against us, our
affiliates, and our past, present and future officers, directors, shareholders and employees arising
out of or relating to your Franchised Business. 2.2.7. You, the Operating Principal, and/or your
designated employees must successfully complete any additional or refresher training courses that we
may require. 3. FEES 3.1. Initial Franchise Fee. You must pay us an initial franchise fee of $30,000
when you sign this Agreement. The initial franchise fee is paid in consideration of the rights
granted in Section 1 and is fully earned at the time paid. You acknowledge that we have no
obligation to refund the initial franchise fee in whole or in part for any reason. 3.2. Royalty
3.2.1. You must pay us a royalty fee ("Royalty") equal to six percent (6%) of your Gross Revenues.
The Royalty is in consideration of your right to use the Proprietary Marks and the System in
accordance with this Agreement, and not in exchange for any specific services we render. If by
reason of state or other law, we are prohibited from receiving a percentage of certain components of
Gross Revenues (including alcoholic-beverage sales), you must pay us an equivalent amount by
increasing the Royalty percentage applied to Gross Revenues exclusive of the prohibited components.
Page 4 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 7 -->
3.2.2. You must calculate and pay the Royalty weekly, based on your Gross Revenues for the previous
Period. For purposes of this Agreement, unless otherwise designated by us in writing, a "Period"
begins on Monday and ends on the following Sunday. 3.2.3. "Gross Revenues" means all revenue from
the sale of all services and products and all other income of every kind and nature related to,
derived from, or originating from the Franchised Business, including proceeds of any business
interruption insurance policies, whether for cash or credit, and regardless of collection in the
case of credit; provided, however, that "Gross Revenues" does not include any coupon sales (for
which customers do not pay for product), customer refunds, sales taxes or other taxes you collected
from customers and actually transmitted to the appropriate taxing authorities. 3.3. Advertising
Contributions. During any Period that the Marketing Fund (as defined in Section 9.1 [Pizza Fusion
Marketing Fund] below) is in effect, you must make a contribution as described in Section 9.1 [Pizza
Fusion Marketing Fund] below equal to three percent (3%) of your Gross Revenues for the preceding
Period. Additionally, during any Period that a Regional Fund (as defined in Section 9.3 [Regional
Fund] below) for the area in which your Franchised Business is located is in effect, you must make a
contribution as described in Section 9.2 [Local Marketing] below in such amounts as we specify in
writing up to two percent (2%) of your Gross Revenues for the preceding Period; in addition, you may
be required to contribute to a Regional Fund up to an additional two percent (2%) of Gross Revenues
of your Franchised Business if the members of that Regional Fund vote to increase the total
contribution, as provided in Section 9.3.5 [Regional Fund] below. Required contributions to the
Marketing Fund and Regional Fund are referred to as "Advertising Contributions." 3.4. Index. The
parties agree that all fixed dollar amounts set out in this Agreement are subject to adjustment, up
or down, depending on changes in the Index. For the purpose of this Agreement, the term "Index" is
agreed to mean the Consumer Price Index (1982-84=100: all items; CPI- U; all urban consumers)
published by the U.S. Bureau of Labor Statistics (or if the Index is no longer published, a
successor index that we may reasonably specify in the Manuals or otherwise in writing). We have the
right to decide whether or not to make adjustments to fixed dollar amounts set out in this Agreement
and if we decide to invoke that right, we will make changes not more than once each year by sending
you written notice of the change. 3.5. Due Date for Payment. Your Royalty payments and Advertising
Contributions are due by the first (1st) day after the end of each Period (or the next business day
if the first day is a Sunday or federal holiday) (as of the Agreement Date, the due date is Monday
of each week). You must pay all other amounts due to us as specified in this Agreement or, if no
time is specified, such amounts are due upon receipt of an invoice from us. 3.6. Method of Payment.
You must make all payments to us by the method or methods that we specify from time to time. We
require payment via wire transfer or electronic debit to your bank account, and you must maintain
sufficient balance in your operating account to meet the payment requirements. You must furnish us
and your bank with all authorizations necessary to effect payment by the methods we specify. You may
not, under any circumstances, set off, deduct or otherwise withhold any Royalty fees, Advertising
Contributions, interest charges, or any other monies payable under this Agreement on grounds of our
alleged non-performance of any obligations. Additionally, you authorize us to charge against any of
your credit cards any amounts due to us or to any of our affiliates. You agree to supply us a
written list of all of your credit cards (including card number, name, and expiration date) and to
update that list periodically, if there are changes to the information. Page 5 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 8 -->
3.7. Delinquency. If any Royalties or other amounts owed to us are not paid in full by the due date,
we have the right to charge interest on the overdue amount at the rate of one and one-half percent
(1.5%) per month (or the maximum rate permitted by applicable law, if less than 1.5%) from the date
such amount was due until paid in full. Unpaid interest charges will compound annually. In addition,
we will have the right to charge a late fee for each occurrence of a payment that is more than 30
days past due, which fee will be $100 for the first such occurrence, $200 for the second such
occurrence, and $300 for the third and each subsequent occurrence during the Term of this Agreement.
The late fee is to compensate us for our administrative costs incurred in enforcing your obligation
to pay us. 3.8. Dishonored Payments. For any amount that you must pay to us or our affiliates, if we
are not able to successfully complete a wire transfer or electronic debit for such payment as
described Section 3.6 [Method of Payment] above, or if a check that you issue for such payment is
returned by the bank against which it was drawn, due to insufficient funds in your account(s),
closure of your account(s) or any other reason resulting in the nonpayment (each a "Dishonored
Payment"), we have the right to charge a fee of $100 per occurrence (a "Dishonored Payment Charge").
We will notify you of each Dishonored Payment and any Dishonored Payment Charge that we impose. We
may add the Dishonored Payment Charge to the amount to be paid via the next wire transfer or
electronic debit. The Dishonored Payment Charge applies in addition to any late fee and interest
that we have the right to charge, or any other remedy to which we are entitled, under this
Agreement, at law, or in equity. 3.9 Taxes. You are responsible for all taxes levied or assessed on
you or the Franchised Business in connection with your activities under this Agreement. 3.10
Obligations Absolute. You agree that your obligations to pay us (as well as our affiliates) under
this Agreement or any other agreement in connection to the Franchised Business are absolute and
unconditional, and not subject to abatement or setoff for past or future claims that you may assert.
3.11 Security Agreement. Upon our written request, you agree to grant to us a first-priority
security interest in all of your assets (including all proceeds thereof and after-acquired
property), as security for all your monetary and other obligations to us or our affiliates arising
under or relating to this Agreement or any other agreement. Such assets include all furniture,
fixtures, machinery, equipment, inventory and all other property, (tangible or intangible), that you
now own or later acquire, used in connection with the Franchised Business, and wheresoever located
as well as all contractual and related rights you have under this Agreement and all other agreements
between the parties. If we request, you must execute such financing statements, continuation
statements, notices of lien, assignments or other documents as we may require in order to perfect
and maintain our security interest, including but not limited to a UCC-1 Financing Statement.
Alternatively, you authorize us to execute any of the foregoing financing statements, continuation
statements, notices of lien, assignments, and/or other documents on your behalf, or on our own (in
our name), describing the collateral in such manner as we consider appropriate. You hereby grant us
an irrevocable power of attorney, coupled with an interest, to execute, in your name, any of such
financing statements, continuation statements, notices of lien, assignments or other documents. You
must pay all filing fees and costs for perfecting our security interest. 4. SITE SELECTION,
PREPARATION, AND OPENING DEADLINE 4.1. Site Selection and Approval. You will be responsible, at your
own expense, for finding and then acquiring, by lease or purchase, a suitable site at which to
develop and operate your Franchised Business (the "Premises"). Any sites that you propose must be
within the area identified in Exhibit A (the "Site Selection Area"). You acknowledge and agree that:
(a) the sole purpose of designating a Site Selection Area is to identify the geographic area in
which you intend (and, upon our written approval, will be authorized) to operate a Franchised
Business under the terms of this Agreement; (b) the designation of the Site Selection Area does not
grant, and will not be implied to grant, any territorial rights or protections to you or to the
Franchised Business; and (c) we reserve all rights as set forth elsewhere in this Agreement,
including but not limited to those described in Section 1.3 [Our Limitations and Our Reserved
Rights] above. Before committing to a site, you must obtain our written approval of the site to
serve as the Premises, as described in Section 4.2 [Site Lease or Acquisition] below. Page 6 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 9 -->
4.1.1. We will give you certain assistance in connection with your selection of Premises and
establishment of your Franchised Business: (a) We will provide to you a copy of our standard site
selection criteria and guidelines, including our minimum standards for Franchised Businesses. (b) We
will have the right to provide to you the degree of site selection counseling and assistance that we
deem appropriate. If we (either on our own initiative or at your request) consider on-site
evaluation necessary or appropriate, you agree to reimburse us for the reasonable expenses that we
incur in connection with providing that on-site evaluation (including the cost of travel, lodging
and meals). (c) We will provide, at no charge, our standard image specifications for the
construction of the Franchised Business, improvement of the premises, and for the layout of
fixtures, furnishings, equipment, and signs. On or before the date you open the Franchised Business,
you must return to us the plans and specifications we provided to you (and any copies that you may
have made or shared with other parties). 4.1.2 You must submit a site review report and such other
information or materials as we may reasonably require (including but not limited to, photographs,
demographic information, an option contract, letter of intent, or other evidence satisfactory to us
that confirms your favorable prospects for obtaining the site). We will review site approval
submissions on a first-in basis. (a) If we do not approve in writing the proposed site, you must,
within 30 days after our disapproval of the proposed site, submit a new proposed site within the
Delivery/Catering and Advertising Area for our review and approval. (b) By no later than 90 days
after the Agreement Date, you must have obtained our written approval of a site. If you have not
done so, we may elect to terminate this Agreement, and we will not refund to you the Initial
Franchise Fee or any other money paid to us. (c) We will not unreasonably withhold approval of any
site that meets our standards. You may not lease or otherwise acquire the right to occupy the
proposed site without our prior written approval. 4.2 Site Lease or Acquisition. You must, within 30
days after we approve a site for the Franchised Business (but in no event later than 120 days after
the Agreement Date), either by lease or purchase the approved site for the Premises, as further
described below. 4.2.1 If you will occupy the Premises under a lease or sublease, you must submit
the lease to us for our review and our prior written approval. Your lease (or rider to a lease) must
include provisions that will: (a) Allow us the right to elect to take an assignment of the leasehold
interest upon termination or expiration of your rights under this Agreement, and that allow us (or
our designee) to operate a "Pizza Fusion" restaurant upon the premises for the remaining term of the
lease or sublease; (b) Require the lessor to provide us with a copy of any written notice of
deficiency under the lease sent to you, at the same time as notice is given to you (as the lessee
under the lease), and which grants to us the right (but not obligation) to cure any deficiency by
you under the lease within fifteen (15) business days after the expiration of the period in which
you had to cure any such default should you fail to do so; Page 7 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 10 -->
(c) Recognize your right to display and use the Proprietary Marks in accordance with the
specifications required by the Manual, subject only to the provisions of applicable law; (d) Require
that the premises be used solely for the operation of a Franchised Business; and (e) Acknowledge
that, if this Agreement is terminated or expires (without you renewing your franchise rights): (i)
you must take certain steps to de-identify the location as a Pizza Fusion Restaurant; and (ii)
lessor will cooperate with us in enforcing your obligation to de-identity, including allowing us,
our employees and/or agents to enter the premises and remove signs, décor and materials that bear or
display our Proprietary Marks, designs, or logos. 4.2.2 You must deliver to us a copy of the signed
lease or sublease to us within fifteen (15) days after it has been signed by you and by the lessor.
You may not execute or agree to any modification of the lease or sublease that would affect our
rights without our prior written approval of the modification. 4.3 Location Development and
Preparation. You must construct, furnish, and open the Franchised Business as required by this
Agreement and must open the Franchised Business not later than six (6) months after securing the
necessary authorization and approval for permits and/or certificates. Time is of the essence. 4.3.1
You agree that you will do all of the following things: (a) make sure that you have obtained all
necessary zoning permits as well as all required building, utility, health, sign permits and
licenses, and any other required permits and licenses; (b) buy or lease Products and other materials
as required under this Agreement (as well as the other specifications that we provide in writing);
(c) in accordance with Section 4.3.2 [Location Development and Preparation] below, prepare all plans
and complete construction, or remodeling, of the Franchised Business, and complete installation of
all equipment in compliance with plans and specifications for the Franchised Business that we have
approved, as well as all applicable federal, state and local laws, codes and regulations (including,
without limitation, the applicable provisions of the ADA, zoning requirements, and permitting
requirements), ordinances, building codes and permit requirements; (d) purchase and install at the
Premises all interior and exterior signage, from such suppliers, that we may designate. From time to
time, we have the right to require that you purchase and install replacement or additional Signage;
(e) obtain all customary contractors' sworn statements and partial and final waivers of lien for
construction, remodeling, decorating and installation services; (f) obtain and maintain in force
during the entire period of construction the insurance required under this Agreement or as otherwise
specified in the Manuals; (g) satisfy all of our pre-opening requirements, whether set out in this
Agreement, the Manuals, or as we may otherwise specify; (h) You must obtain a Certificate of
Occupancy within 10 days after completing construction, unless we agree in writing to extend this
deadline; and Page 8 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 11 -->
(i) within thirty (30) days after the store opening, you agree to provide us a full written
breakdown of all costs associated with the development of your Franchised Business in the form that
we may reasonably require. 4.3.2 Before starting and during any construction or renovation of the
Premises, you must, at your own expense, meet all of the following requirements: (a) You must employ
a qualified, licensed architect or engineer who we have designated or approved in writing to
prepare, for our approval, preliminary plans and specifications for site improvement and
construction of the Franchised Business based upon prototype design and image specifications we
furnished to you. We will not unreasonably withhold our approval of special plans and
specifications, prepared at your expense, when the Approved Location will not accommodate our
standard plans and specifications, provided that such plans and specifications conform to our
general design criteria. You will be responsible for the design and layout that your architect or
engineer prepares. If we express an opinion about the plans or indicate our approval, it will be
merely for the purpose of our own determination that your plans will satisfy our internal standards,
specifications, and layout. We will not be in a position to provide any assurances, and therefore
can not be deemed to have given any information about, whether your plans satisfy any federal,
state, and local laws, codes and regulations (including, without limitation, the Americans with
Disabilities Act ("ADA")). (b) After obtaining any required governmental approvals and clearances,
you must submit to us, for our approval, final plans for construction based upon the preliminary
plans and specifications. Once approved by us, such final plans may not be changed or modified
without our prior written consent. (c) You must employ a qualified, licensed general contractor to
construct the Franchised Business and complete all improvements. (d) Your architect or engineer must
also comply with all applicable zoning, signage, seating capacity, parking requirements and
alcoholic-beverage (i.e., beer and wine products that we designate or approve) licensing and storage
requirements. (e) Within 10 days after commencing construction, you must provide us with written
notice of the date you began construction. 4.3.3 We may require that you provide us a written
certification from your registered architect that the Franchised Business has been constructed,
furnished, equipped, and decorated in accordance with approved plans and specifications. 4.3.4 We
may recommend that you use a construction project manager that we designate for constructing the
Premises. If we do so and you choose not to use our recommended construction manager, you must hire
a general contractor who is reasonably acceptable to us and who must have the following minimum
insurance coverage: (a) commercial general liability in an amount of $2,000,000 combined single
limit; (b) comprehensive automobile liability for owned, hired and non-owned motor vehicles in an
amount of $1,000,000 combined single limit; (c) workers' compensation, occupational diseases and
disability benefits in accordance with applicable statutory requirements; (d) employers' liability
in an amount of $1,000,000; (e) employee fidelity bond of $2,000,000; and (f) umbrella form excess
liability insurance in excess of the limits provided by the commercial general liability policy
required above with limits of $3,000,000 per occurrence and annual aggregate. Page 9 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 12 -->
4.3.5 Before you can open for business, you must satisfy all of our pre-opening requirements,
whether they are set out in this Agreement, the Manuals, or as we may otherwise specify, and you
must obtain our written approval prior to opening the Franchised Business. You must open the
Franchised Business within seven days after obtaining our written approval for opening, unless we
agree in writing to extend this deadline. 4.4. Our Review. Any reviews that we conduct under this
Section 4 are only for our benefit. You acknowledge that our review and approval of a site, lease,
sublease, design plans or renovation plans for a Franchised Business do not constitute a
recommendation, endorsement, or guarantee of the suitability of that location or the terms of the
lease, or sublease, or purchase agreement. You agree that you will take all steps necessary to
determine for yourself whether a particular location and the terms of any lease, sublease, or
purchase agreement for the site are beneficial and acceptable to you. 4.5 Opening Deadline. You must
begin operating the Franchised Business by the opening deadline specified in Appendix A. The date
you actually open the Franchised Business is the "Opening Date." 4.6 Relocation and other Uses of
the Premises. You may not relocate the Franchised Business from the Premises without our prior
written consent. You may only use the Premises for the purpose of operating your Franchised Business
and for no other purpose. You may not sublet or otherwise allow any other party to operate any
enterprise at your Premises without our prior written approval. 5. TRAINING 5.1. Initial Training
Program 5.1.1. Before you begin operating, the two persons who you designate (and who we find
acceptable) to provide managerial responsibilities (each a "Manager Trainee") must all successfully
attend (at the same time) and successfully complete our initial training program (we may designate
portions of the training program that each person must attend and successfully complete), which is
held at our headquarters and/or another location(s) that we specify. One Manager Trainee must be
your Operating Principal (who meets the criteria in Section 6.15 of this Agreement), unless we
mutually agree otherwise. You may designate another person who will be active in the day-to-day
activities and management of the Franchised Business to be the second Manager Trainee. You may ask
that additional employees be allowed to attend the portions of the initial training that are
designed for your employees, and we will have the right to approve or disapprove that request. All
trainees must be persons that we find acceptable at all times to serve in their respective
capacities. As of the Effective Date, our training program has two components, as follows: (a) An
Advanced Operations Course for your Operating Principal, which consists of up to twelve days for
your Operating Principal and is conducted at our training facilities in Broward County, Florida, or
at another location that we may specify in writing. (b) A Basic Operations Course for any Manager
Trainee other than your Operating Principal, which consists of up to twelve days of training and is
conducted at our training facilities in Broward County, Florida, or at another location that we may
specify in writing. Your Manager Trainees (other than your Operating Principal), and such of the
Franchisee's other employees as we designate must attend this component of training. 5.1.2. We will
issue a certificate of completion for each Manager Trainee who completes the initial training
program we require to our satisfaction (each such person will be referred to as a "Certified
Manager"). We have the right to determine whether a person has or has not successfully completed
training. If you (or your personnel) fail to complete initial training to our satisfaction, we may
permit you (or they) to repeat the course or allow you to send a substitute to the next available
scheduled training session; however, we will have no obligation to extend the opening deadline in
Section 4 for this purpose. Page 10 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 13 -->
5.1.3. We have the right to reduce the duration or content of the training program for any trainee
who has prior experience with our concept or in similar businesses. We also may allow you to train
certain of your managers (which may include Certified Managers) and successors in those positions at
your location. 5.1.4. Failure to complete the initial training program constitutes grounds for
termination, as provided in Section 15 of this Agreement. 5.2. Opening Training and Assistance. We
provide up to fourteen (14) days of pre-opening training and opening assistance at your Premises.
The Operating Principal and the other Manager Trainee and such of your other employees as we
designate must attend this component of training, which will begin approximately seven days before
the Opening Date and conclude approximately seven days thereafter. 5.3. Additional Training by Us.
We may require your Certified Managers and/or other designated persons to successfully complete
additional training courses during the Term of this Agreement at a location that we specify
(including an annual conference for franchisees in the System). We may also offer optional training
programs. You may also request that we provide additional training at the location of your
Franchised Business, and we will provide such training if we determine that we are able to do so. We
may charge you a training fee and our out-of-pocket expenses for all additional training programs,
whether mandatory or optional, or whether you request or we require such training, which fee shall
be as set forth in the Manual or otherwise in writing. 5.4. Training by You. We have the right to
specify training programs related to the System that you must conduct for your employees using
approved training materials or that we will provide at our headquarters. For any training of your
personnel that we conduct, you are responsible for expenses incurred while they attend training,
including salaries, benefits, travel, lodging, meals, and other related expenses. We reserve the
right to charge you for training additional personnel. 5.5. Training Materials and Methods. All
training materials that we provide to you remain our property. We have the right to provide training
programs in person, on tape, via the Internet or other electronic means, or by other means and
media, as we determine. 5.6. Expenses. We will provide instructors, facilities, and materials for
the initial training program at no charge, provided that all of your personnel are trained during
the same training session. We reserve the right to charge a reasonable fee for training additional
personnel (in excess of two), re-training persons who are repeating the course or replacing a person
who did not pass. For all training, including initial training, you are responsible for any travel
expenses, living expenses, wages, and other expenses incurred by your trainees. 6. OPERATIONS 6.1.
Compliance with Standards. You agree to comply with all mandatory specifications and procedures set
forth from time to time in our confidential operating manual (the "Manual"). You acknowledge that
the accounting practices, record keeping, software, services, and operation of your Franchised
Business are important to us and our other franchisees. However, you acknowledge that we have the
right to vary our standards and specifications, in our reasonable judgment, to accommodate
circumstances of individual franchisees. 6.2. Products and Services You May Offer. You may offer
customers only the products and services that we have expressly authorized Franchised Businesses to
offer, as we have the right to specify in the Manual from time to time. We have the right to change
the authorized products and services, and we may designate specific products or services as optional
or mandatory (including alcoholic beverages). You acknowledge that we may approve some services,
products, and other items for certain franchisees and not others based on legitimate business
reasons. You must use menus that meet our then-current specifications as to content, materials,
finish, style, pattern, and design. Page 11 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 14 -->
6.3. Secret Recipe Products. We have developed and may continue to develop additional Secret Recipe
Products. The Secret Recipe Products are our proprietary products. In order to maintain the high
standards of quality, taste, and uniformity of these products and protect the proprietary nature of
these products, you agree to purchase the Secret Recipe Products only from us, our affiliates or
from sources that we designate or approve and license 6.4 Sourcing of Other Products, Equipment and
Supplies. 6.4.1. Without limiting Section 6.3 [Secret Recipe Products] above, we have the right to
require that all of the food items, equipment (including but not limited to vehicles used in
connection with the Franchised Business), supplies, materials, and other products and services used
or offered for sale at your Franchised Business: (a) meet specifications that we establish from time
to time; and/or (b) be purchased only from suppliers that we have expressly approved; and/or (c) be
purchased only from a single source (which may include us or our affiliates or a buying cooperative
that we organize). To the extent that we establish specifications, require approval of suppliers, or
designate specific suppliers for particular items, we will publish our requirements in the Manual.
6.4.2. If you would like to use or offer food items (other than the Secret Recipe Products),
equipment, supplies, materials, and other products and services that we have not approved, or
purchase from a vendor, supplier, distributor, or other source (together, "supplier(s)") that we
have not approved, then you must submit to us a written request for approval. We have the ongoing
right to inspect any proposed supplier's facilities and to test samples of the proposed products or
services. You agree to pay us an amount not to exceed the reasonable cost of the inspection and our
actual cost of testing the proposed product or service, including personnel and travel costs,
whether or not we ultimately approve the supplier. We have the right to grant, deny, or revoke
approval of products, services, and suppliers. We will notify you in writing of our decision as soon
as practicable following our evaluation. We reserve the right to reinspect the facilities and
products of any approved supplier and to revoke approval if we find that the supplier fails to meet
any of our then-current criteria. If you receive a notice of revocation of approval, you agree to
immediately stop buying products or services from the disapproved supplier and, in the case of
revocation based on failure of products to meet our standards, you agree to dispose of your
remaining inventory of the disapproved supplier's products as we direct. 6.4.3. If you wish to test
market an item that we have not approved, then, so long as we have given you our prior written
approval, you may do so for so long, and on such terms, that we mutually agree upon (a "Test"), and
the item so tested, and all associated formulae, plans, and materials, will become our property. If,
following the Test, we determine that we will approve the tested item, then for so long as we deem
that item to be an "approved item" under this Agreement, you will have the right to use that item
under the terms of this Agreement; and we will have the right to use and market that item as we see
fit, including but not limited to use in our own Restaurants as well as that of other licensees and
franchisees, without compensation to you. You agree to sign such documents (and require your
employees and any independent contractors that you have engaged to sign such documents) as we may
require in order to implement the provisions of this Section 6.4.3 [Sourcing of Other Products,
Equipment and Supplies]. 6.4.4. We and our affiliates may receive payments or other compensation
from suppliers on account of such suppliers' dealings with you and other franchisees; and, we may
use all amounts so received for any purpose we and our affiliates deem appropriate. 6.5. Delivery
Vehicles. If you wish to use a vehicle to provide delivery services (a "Delivery Vehicle") as part
of your Franchised Business, you must comply with the specifications and standards that we may
periodically prescribe in the Manuals for Delivery Vehicles. Our specifications and standards may
include, among other things: designating Delivery Vehicles specific make and model; limitations on
the Useful Life for a Delivery Vehicle and standards for maintenance or repair services. Page 12 of
39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 15 -->
6.5.1. The term "Useful Life" means the period of time after which you must stop using the Delivery
Vehicle for the Franchised Business. We have the right to determine the Useful Life of any Delivery
Vehicle, which may include reasonable standards as to how many model years old the vehicle may be,
the appearance of the vehicle, and the performance of the vehicle. After the Useful Life, you must
remove all Proprietary Marks and any other indicia associating the Delivery Vehicle with the System,
and immediately purchase or lease a new Delivery Vehicle. 6.5.2. We have the right to specify the
makes and models of Delivery Vehicles approved for use by our franchisees, and anticipate that we
will make changes over time to reflect and take advantage of advances in technology and/or
alternative energy powered vehicles. 6.6. Alcohol Permits. Before you begin operating the Franchised
Business you must obtain, and at all times thereafter you must maintain, all licenses and permits
required to sell, dispense, and store beer and wine beverages and be prepared to offer and sell such
beer and wine products to customers at the Premises as we designate as mandatory product offerings,
unless you obtain from us a written waiver of this requirement. You must comply with all laws and
regulations relating to the selling, dispensing, and storing of alcoholic beverages. You must also
comply with the standards, specifications, and terms that we may establish regarding the offer,
sale, and presentation of alcoholic beverages, as require or approved products. You must obtain and
maintain appropriate insurance coverage for you and for our benefit, including any minimum coverages
that we may establish. 6.7. Image Standards. You must keep the Premises, vehicles, equipment, and
uniforms used in the Franchised Business and/or by your employees in the highest degree of
cleanliness, orderliness, appearance, sanitation, and repair in accordance with our standards and
specifications, including but not limited to those set out in our Manuals. 6.8. Employees. Your
employees must wear uniforms, or comply with such other dress code as we may require, and otherwise
identify themselves with the Proprietary Marks at all times in the manner we specify while on a job
for the Franchised Business. 6.9. Employment Responsibilities. You have sole responsibility for all
employment decisions and functions related to your Franchised Business, including hiring, firing,
compensation, benefits, work hours, work rules, record-keeping, supervision, and discipline of
employees. You must take such steps as are necessary to ensure that your employees preserve good
customer relations; render competent, prompt, courteous, and knowledgeable service; and meet any
minimum standards that we may establish from time to time in the Manual, which may include standards
as to the minimum number of employees, which we may determine, necessary to meet the anticipated
volume of business and to achieve the goals of the System. 6.10. Customer Service Program. You
acknowledge that providing superior customer service is a vital component of the System. You must
participate in customer service programs, which we have the right to specify from time to time in
the Manual. Such programs may include the use of independent evaluation service to conduct "mystery
customer" quality control, customer satisfaction surveys, or any other quality control or evaluation
programs. If you receive an unsatisfactory or failing report in connection with any such program,
you must immediately implement any remedial actions we require and pay us all expenses we incurred
to have the evaluation service evaluate the Franchised Business, and all expenses we may have
incurred to inspect the Franchised Business thereafter. 6.11. Customer List. You must create and
maintain, in such manner as we may from time to time require, a current customer list (the "Customer
List") containing as to each of your customers, such customer's name, e-mail address, location
address, telephone number and zip code (9 digits). You must provide a copy of such list to us on a
quarterly basis (or at such other intervals as we may prescribe). The Customer List is, and remains,
our exclusive property, you hereby assign to us all rights you now have or hereafter may acquire in
the Customer List. After the expiration or termination of this Agreement, you may not retain, use or
disclose the Customer List, or any of the information contained therein, without our written
authorization. Page 13 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 16 -->
6.12. Major Accounts 6.12.1. You acknowledge that our negotiation of Major Accounts, including rates
and services to be performed, enhances the potential value of the System and inures to your benefit
as well as to our benefit and that of other Restaurant franchisees. As noted in Section 1.3 [Our
Limitations and Our Reserved Rights] above, we reserve the right to provide products and services to
all Major Accounts. We may offer you the right to provide products and services to a Major Account
within your Delivery/Catering and Advertising Area. If you accept the obligation to provide products
and services to a Major Account, you must service such Major Account on our behalf, in accordance
with the pricing and other terms that we negotiate with the Major Account customer. You may not
enter into any relationship with a Major Account customer that we deem to conflict with the
customer's Major Account arrangement with us. We will have the right to handle all billing and
collection for services performed under a Major Account arrangement. Certain Major Account customers
may require that we provide additional volume rebates, which we will negotiate with the customer on
a case-by-case basis. You will have the option not to provide products or services to any Major
Account customer that is offered to you. 6.12.2. We may terminate your right to provide products and
services to a Major Account customer at any time by giving you at least 30 days' prior written
notice, and you may terminate your right to provide products and services to a Major Account at any
time by giving us at least 30 days' prior written notice. If we elect not to offer you the
opportunity to provide products or services to a Major Account, if you decline the option to accept
a Major Account, if your right to provide products or services to a Major Account terminates, or if
you fail to satisfy the conditions and obligations of any Major Account agreement, we have the right
to service and/or authorize others to service Major Account customers within your Delivery/Catering
and Advertising Area without any compensation to you. We have no obligation to permit you to provide
products or services to a Major Account or to transfer any Major Account customer to you if you are
subsequently willing and able to provide service. 6.13. Inspections. We have the right, at any time
during normal business hours: (i) to conduct inspections of the Franchised Business; (ii) to
interview your employees, work crews, and customers; and (iii) to review your business records,
including those maintained electronically or off premises. We can initiate these actions with or
without prior notice to you. You must cooperate with such inspections by giving our representatives
unrestricted access and rendering such assistance as our representatives may reasonably request. If
we notify you of any deficiencies after the inspection, you must promptly take steps to correct
them. If you fail to correct any deficiencies within a reasonable time, we have the right to correct
such deficiencies and to invoice you for our expenses. 6.14. Compliance with Laws. You agree to
operate the Franchised Business in full compliance with all applicable municipal, county, state, and
federal laws, rules, regulations, and ordinances. You have sole responsibility for such compliance
despite any information or advice that we may provide. (To the extent that the requirements of those
laws are in conflict with the terms of this Agreement, the Manuals, or our other instructions, you
must: (a) comply with those laws; and (b) immediately give us written notice of the conflict.) 6.15.
Operating Principal and Management Supervision 6.15.1. If you are a corporation, partnership or LLC,
you must have an individual owner serve as your Operating Principal. The Operating Principal must
own a majority of the voting and ownership interests in the franchisee entity, unless you obtain our
prior written approval for the Operating Principal to hold a smaller interest. The Operating
Principal must complete our training program, must have authority over all business decisions
related to the Franchised Business, and must have the power to bind you in all dealings with us. You
may not change the Operating Principal without our prior approval. Page 14 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 17 -->
6.15.2. At all times that the Franchised Business is operating, it must be under the personal,
on-premises supervision of the Operating Principal who is a Certified Manager, or another individual
who is a Certified Manager. You may not permit the Franchised Business to be operated, managed,
directed, or controlled by any other person without our prior written consent. At least one
Certified Manager must devote, on a full-time basis, his or her best efforts to managing and
operating the Franchised Business. Unless we agree otherwise in writing, before the Operating
Principal or any other manager may manage the Franchised Business, he or she must become a Certified
Manager (as provided in Section 5.1.2 [Initial Training Program]) and acquire any
food-safety-program certification that the local, state or municipality may require, as well as any
other licenses, permits, and certifications that we may require from time to time. 6.15.3 If the
Certified Manager is an individual other than Operating Principal, and such Certified Manager ceases
to satisfy his or her obligations under this Agreement due to death, disability, termination of
employment, or for any other reason, the Operating Principal must satisfy such obligations until you
designate a new Certified Manager of the Franchised Business, who is acceptable to us and has
successfully completed the initial training program we require. 6.15.4. All persons with a 5% or
greater ownership interest in the franchise must sign a personal guaranty on the form attached to
this Agreement as Appendix B. 6.16 Maintenance of Premises. You must at all times maintain the
Franchised Business in a high degree of sanitation, repair, and condition, and must make such
additions, alterations, repairs, and replacements (but no others without our prior written consent)
as may be required for that purpose, including, without limitation, such periodic repainting or
replacement of obsolete signs, furnishings, equipment, and decor as we may reasonably direct. 6.17
Ongoing Upgrades and Refurbishments. Throughout the term of this Agreement, you must maintain all of
the fixtures, furnishings, equipment, decor, and signs that we prescribe from time to time in the
Manuals or otherwise in writing. If we determine that additional or replacement equipment is needed
because of a change in menu items or method of preparation and service, a change in technology,
customer concerns, health or safety considerations, or because of any other reason, you agree that
you will install the additional equipment or replacement equipment within the reasonable time we
specify. 6.18 Five-Year Refurbishment and Renovations. At our request, but not more often than once
every five (5) years (and not before the fifth year after you begin operating), unless sooner
required by your lease, you must refurbish the Premises, at your expense, to conform to the
restaurant design, façade, signage, trade dress, color schemes, and presentation of the Proprietary
Marks in a manner consistent with the then- current image for new Pizza Fusion restaurants. Such
refurbishment may include structural changes, installation of new equipment and signs, remodeling,
redecoration, and modifications to existing improvements, and, shall be completed pursuant to such
standards, specifications, and deadlines as we may reasonably specify. 6.19. Insurance. 6.19.1.
Types and Amounts of Coverage. Throughout the entire Term, you must maintain such types of
insurance, in such amounts, as we may require. Such insurance is in addition to any other insurance
that may be required by applicable law, your landlord, or otherwise. Policies that we require must
be written by an insurance company reasonably satisfactory to us with an A.M. Best rating of "A" or
better, and, must name us as an additional insured party. At a minimum, such policies must include
the following: (a) commercial general liability insurance, completed-operations and
independent-contractors coverage in the amount of $1,000,000, per person/per occurrence for bodily
injury and property damage combined with a general aggregate of $3,000,000. Page 15 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 18 -->
(b) workers'-compensation coverage in the amount of at least $100,000/$500,000/$100,000,
unemployment insurance and employer's liability insurance, as well as such other insurance as may be
required by statute or rule of the state in which the Franchised Business is located; (c) fire,
lightning, vandalism, theft, malicious mischief, flood (if in a special flood-hazard area),
sprinkler damage, and the perils described in ex-tended-coverage insurance with primary and excess
limits of not less than the full-replacement value of the supplies, furniture, fixtures, equipment,
machinery, inventory, and plate glass having a deductible of not more than $1,000 and naming us as a
loss payee; (d) automobile liability insurance-including coverage of vehicles not owned by you, but
used by employees in connection with the Franchised Business, with a combination of primary and
excess limits of not less than $1,000,000; (e) commercial blanket bond in the amount of $100,000;
and (f) such other insurance, in such amounts, as we reasonably require for our and your protection.
At any time, we may adjust the amounts of coverage required under such insurance policies and
require different or additional kinds of insurance, including excess liability insurance. 6.19.2.
Evidence of Insurance. By the dates specified below, an approved insurance company must issue a
certificate of insurance showing compliance with the insurance requirements in this Section 6.19
[Insurance] and you must furnish us with a paid receipt showing the certificate number: (a) 30 days
before beginning construction of the Premises; (b) if the Premises are constructed and presently
owned or leased by you, 10 days from the Agreement Date; or (c) if the Premises are not presently
owned or leased, 10 days after ownership of the Premises is conveyed to you or you sign a lease for
the Premises. The certificate of insurance must include a statement by the insurer that the policy
or policies may not be canceled, subject to nonrenewal, or materially altered without at least 30
days' prior written notice to us. Upon our request, you must supply us with copies of all insurance
policies and proof of payment. Every year, you must send us current certificates of insurance and
copies of all insurance policies. 6.19.3. Requirements for Construction and Renovation. In
connection with any construction, renovation, refurbishment, or remodeling of the Premises, you must
cause the general contractor to maintain commercial general liability insurance (with comprehensive
automobile liability coverage for both owned and non-owned vehicles, builder's risk, product
liability, and independent contractors coverage) with a reputable insurer. Such insurance must be in
the amount of at least $1,000,000 and must name us and you as an additional named insured party, as
our respective interests may appear. You must also cause the general contractor to maintain workers'
compensation and employer's liability insurance as may be required by law. 6.19.4. Our Right to
Participate in Claims Procedure. We, or our insurer, may participate in discussions with your
insurance company or any claimant (in conjunction with your insurance company) regarding any claim.
6.19.5. Waiver of Subrogation. To the extent this Section may be effective without invalidating, or
making it impossible to secure, insurance coverage from responsible insurance companies that are
doing business in your state (even though an extra premium may result), with respect to any loss
covered by insurance we and you then carry, neither party's insurance companies have any right of
subrogation against those of the other. Page 16 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 19 -->
6.19.6. Effect of Our Insurance. Any insurance that we maintain does not in any way limit or affect
your obligation to obtain and maintain the foregoing policy or policies in the amounts specified in
this Section. Our performance of your obligations will relieve you of liability under the indemnity
provisions set forth in this Agreement. 6.19.7. Your Failure to Maintain Insurance. If, for any
reason, you fail to procure or maintain the insurance required by this Agreement (as we may revise
from time to time), we have the right (but not the duty) to procure such insurance. If we do so, we
may charge the cost of such insurance, plus interest at the contract interest rate, to you. Upon
demand, you must immediately pay us such charges, together with a reasonable fee for our expenses in
so acting. 6.19.8. Group Insurance. We may make available to you insurance coverage through group or
master policies we arrange (such as relating to property and casualty, workers' compensation,
liability and health, life and disability insurance). 6.20. Vendors. You agree to promptly pay, when
due, all trade creditors and vendors (including but not limited to any that are affiliated with us)
that supply goods and/or services to you in connection with operating your Franchised Business.
6.21. General Advice. We will make available to you information about new developments, techniques,
and improvements in the areas of operations, management, and marketing, to the same extent as we
make the information available to other Restaurant franchisees in good standing. We may fulfill our
obligation in this section through the distribution of printed or filmed material, an Extranet or
other electronic forum, meetings or seminars, individual or group counseling, training programs,
telephone communications, or other forms of communications. 6.22 Special Assistance. If you request,
and we can reasonably accommodate such request, we will furnish non-routine guidance and assistance
to deal with your unusual or unique operating problems at reasonable per diem fees and charges that
we periodically establish, as well as our out-of-pocket expenses. 6.23 Credit Cards and Other
Methods of Payment. At all times, you must maintain credit-card relationships with the credit- and
debit-card issuers or sponsors, check or credit verification services, financial-center services,
and electronic-fund-transfer systems that we designate as mandatory, and you must not use any such
services or providers that we have not approved in writing or for which we have revoked our
approval. We have the right to modify our requirements and designate additional approved or required
methods of payment and vendors for processing such payments, and to revoke our approval of any
service provider. You must comply with all our credit-card policies, including minimum purchase
requirements for a customer's use of a credit card as prescribed in the Manual. 6.24 Conferences. We
may conduct annual conferences or conventions, which may include training sessions. We may require
your Operating Principal, Certified Managers, and other designated employees to attend the
conferences. You will be solely responsible for all costs incurred by you and your employees in
attending any conferences or conventions. 6.25 Pricing. We may, from time to time, but only to the
extent permitted by law, establish and impose maximum and minimum prices for the goods and services
that you are permitted to sell or offer to sell. If we do so, you must not set your prices below the
minimum level that we have established, and not above the maximum level that we have established.
6.26 Certification of Performance. After we perform our preopening obligations under this Agreement,
we may request that you execute a certification (the "Certification of Performance"), in a form we
reasonably request, confirming such performance. If we make this request, you must execute and
deliver the Certification of Performance to us within three-business days of our request. If,
however, you do not reasonably believe that we have performed all our preopening obligations under
this Agreement, you must, within said three-day period, provide us with written notice specifically
describing the obligations that we have not performed. Not later than three-business days after we
complete all the obligations specifically described in your notice, you must execute and deliver the
Certification of Performance to us. You must do so even if we performed such obligations after the
time performance was due under this Agreement. The term "preopening obligations" means such of our
obligations to you under this Agreement that must be performed before the Opening Date for the
Franchised Business. Page 17 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 20 -->
7. PROPRIETARY MARKS 7.1. Your Right to Use the Proprietary Marks. Your right to use the Proprietary
Marks applies only to the Franchised Business operated from the Premises as expressly provided in
this Agreement. During the Term of this Agreement and after its expiration or termination, you agree
not to directly or indirectly contest, or aid in contesting, the validity or ownership of the
Proprietary Marks or take any action detrimental to our rights in the Proprietary Marks. 7.2. Your
Acknowledgments. You acknowledge that: (a) the Proprietary Marks serve to identify our services and
the businesses operating under the System; (b) your use of the Proprietary Marks under this
Agreement does not give you any ownership interest in them; and (c) all goodwill associated with and
identified by the Proprietary Marks inures exclusively to our benefit and is our property. Upon the
expiration or termination of this Agreement, no monetary amount will be attributable to goodwill
associated with your activities as a franchisee under this Agreement. 7.3. Limitations on Use of the
Proprietary Marks. You agree: 7.3.1. To use only the Proprietary Marks we designate, and only in the
manner we authorize; 7.3.2. To use the Proprietary Marks only for the operation of the Franchised
Business and only at the Premises, or in advertising we have approved for the business conducted at
the Premises; 7.3.3. To operate and advertise the Franchised Business only under the name "Pizza
Fusion" without prefix or suffix; 7.3.4. To ensure that the Proprietary Marks are used together with
the symbol (such as "®", "™", or "SM") that we require from time to time. 7.3.5. To permit us or our
representatives to inspect your operations to assure that you are properly using the Proprietary
Marks; 7.3.6. To use the Proprietary Marks to promote and to offer for sale only the products and
services that we have approved, and not use any Proprietary Marks in association with the products,
materials or services of others; 7.3.7. You agree not to use or permit the use or display of the
Proprietary Marks as part of any Internet domain name or website, or any other electronic identifier
(including but not limited to e-mail addresses, account names in a social media site, and the like)
of you or the Franchised Business in any forum or medium; 7.3.8. Not to use the Proprietary Marks to
incur any obligation or indebtedness on our behalf; 7.3.9. Not to use any of the Proprietary Marks
as part of your corporate or legal name; Page 18 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 21 -->
7.3.10 That your use of the Proprietary Marks does not give you any ownership or other interest in
or to the Proprietary Marks (except the license granted by this Agreement); 7.3.11 To accept the
validity of the Proprietary Marks as they exist now and in the future and agree that you will not
contest the validity of any of the Proprietary Marks at any time; and 7.3.12 To comply with our
instructions in filing and maintaining trade name or fictitious name registrations, and sign any
documents we deem necessary to obtain protection of the Proprietary Marks or to maintain their
continued validity and enforceability. 7.4. Changes to the Proprietary Marks. We have the right,
upon reasonable notice, to change, discontinue, or substitute for any of the Proprietary Marks and
to adopt new Proprietary Marks for use with the System without any liability for any diminishment of
the brand. You agree to implement any such change at your own expense within the time we reasonably
specify. 7.5. Third-Party Challenges. The parties agree as follows: 7.5.1 You agree to promptly
notify us if you learn of any suspected infringement of the Proprietary Marks, any challenge to the
validity of the Proprietary Marks, or any known challenge to our ownership of, or your right to use,
the Proprietary Marks. 7.5.2 You understand and agree that we will have the sole right to direct and
control any administrative proceeding or litigation involving the Proprietary Marks, including any
settlement of such a matter. You also understand and agree that we have the sole right, but not the
obligation, to take action against uses by others that may constitute infringement of the
Proprietary Marks. 7.5.3 If you have used the Proprietary Marks in accordance with this Agreement
and our other written instructions, then we will defend you, at our expense, against any third party
claim, suit, or demand involving the Proprietary Marks arising out of your use of those marks. If
you have used the Proprietary Marks but not in accordance with this Agreement and our other written
instructions, then we will still defend you, but at your expense, against such third party claims,
suits, or demands; and you agree to pay all of our expenses (including but not limited to attorney's
fees and any settlements or judgments) when we ask that you do so. In any case, though, you will be
responsible for your staff's payroll and related costs. 7.5.4 If we undertake the defense or
prosecution of any litigation relating to the Proprietary Marks, you agree to execute any and all
documents and do the things that our counsel deems necessary to carry out such defense or
prosecution (including, but not limited to, becoming a nominal party to any legal action). 8.
BUSINESS RECORDS AND REPORTING 8.1. Business Records. You agree to keep complete and accurate books,
records, and accounts of all business conducted under this Agreement, in the form and manner
prescribed in the Manual or other written instructions. You must preserve all of your books and
records in at least electronic form for seven (7) years from the date of preparation. 8.2. Reports
and Financial Statements. 8.2.1 You agree to submit financial and operational reports and records
and documents to us at the times and in the manner specified in the Manual or other written
instructions. You agree to submit, (a) within twenty (20) days after the end of each calendar month,
a balance sheet and income statement, and (b) within ninety (90) days of the end of each fiscal
year, an annual balance sheet and income statement. Upon our request, each such financial statement
must accompanied by an unqualified review opinion from an independent certified public accountant
acceptable to us. You or the Operating Principal must certify that the income statement and balance
sheet are correct and complete and that they have been prepared in accordance with generally
accepted accounting principles in the US (or, if we request, international financial reporting
standards if, by then, IFRS have been adopted in the US). You must also submit to us a complete
photocopy of the Franchised Business' annual federal and state income tax returns when you file such
reports with the appropriate tax authorities. Page 19 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 22 -->
8.2.2 If we request in writing, you agree that your financial institution is authorized to send us a
monthly statement of all activity in the designated account (and such other reports of the activity
in the operating account as we reasonably request) at the same time as it sends such statements to
you. You also agree to sign such documents as your financial institution may require in order to
implement this provision. 8.2.3 If you maintain other accounts of any type for the Franchised
Business, you agree to provide us with a written description of those accounts and to provide to us
copies of the monthly statements for all such accounts and the details of all deposits to, and
withdrawals from, those accounts. 8.3. Examination and Audit Rights. We have the right, both during
and after the Term of this Agreement, to inspect, copy and audit your books and records, your
federal, state and local tax returns, and any other forms, reports, information or data that we may
reasonably designate. We will provide you 10 days written notice before conducting an in-person
financial examination or audit. We may conduct the examination or audit at our offices or those of a
third-party, in which case we may require you to send us your records. If the examination or audit
reveals an understatement of Gross Revenues, you must immediately pay us any Royalty fees,
Advertising Contributions, or other amounts owing, plus interest as provided in Section 3.8
[Dishonored Payments]. If Gross Revenues have been understated by more than 2% for the period
covered by the examination or audit, you must also: (1) reimburse us for the full reasonable cost of
the examination or audit, including, travel, lodging, meals, and wages of our representatives and
the legal and accounting fees of any attorneys or independent accountants we use for the examination
or audit; and (2) at our request, thereafter provide us with periodic audited financial statements.
If you have understated Gross Revenues by 2% or more on three or more occasions in any twelve-month
period, or by 5% or more for any period of four (or more) consecutive weeks, we have the right to
terminate this Agreement with no opportunity for cure. The foregoing remedies are in addition any
other remedies and rights available to us under this Agreement or applicable law. 8.4. Governing
Documents. If you are a corporation, partnership, LLC, or LLP, or transfer this Agreement to a
corporation, partnership, LLC, or LLP, then, upon our request, you must provide to us a list of
holders of direct or indirect equity interests and their percentage interests, as well as copies of
your governing documents and any other corporate documents, books, or records. The Owners may not
enter into any shareholders' agreement, management agreement, voting trust or other arrangement that
gives a third party the power to direct and control your affairs without our prior written consent.
Throughout the Term of this Agreement, your governing documents must provide that no transfer of any
ownership interest may be made except in accordance with Section 14 of this Agreement. Any
securities that you issue must bear a conspicuous printed legend to that effect. 8.5. Back-office.
We have the right to require that you use an independent bookkeeper and/or independent accounting
firm that we designate, in writing, for all such requirements of your Franchised Business. If we
make such a designation, you agree to promptly work and cooperate with the designated bookkeeper
and/or accountant. Page 20 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 23 -->
9. MARKETING FUND AND ADVERTISING 9.1 Pizza Fusion Marketing Fund 9.1.1. We have the right, but not
the obligation, to establish, maintain, and administer a fund for the marketing of the "Pizza
Fusion" brand and Restaurants (the "Marketing Fund"). You must contribute each Period (commencing
from the time we establish the Marketing Fund) to the Marketing Fund as provided in Section 3.3
[Advertising Contributions]. 9.1.2. We have the right to determine the proper operation and other
decisions of the Marketing Fund. We may use your contributions and any earnings on the Marketing
Fund for any costs associated with advertising, marketing, public relations, and/or promotional
programs and materials, and any other activities we believe would benefit Franchised Businesses
generally, including advertising campaigns in various media; creation and maintenance of one or more
Websites; direct mail advertising; market research, including secret shoppers and customer
satisfaction surveys; employing advertising and/or public relations agencies; purchasing promotional
items; conducting and administering promotions, contests, giveaways, public relations events,
community involvement activities, etc.; and providing promotional and other marketing materials and
services to our franchisees. We have the right to direct all marketing programs, with the final
decision over creative concepts, materials, and media used in the programs and their placement. We
do not guarantee that you will benefit from the Marketing Fund in proportion to your contributions
to the Marketing Fund. 9.1.2. We will deposit all contributions to the Marketing Fund in an account
separate from our other funds and will not use them to defray any of our general operating expenses,
except for reasonable administrative costs and overhead we incur in activities reasonably related to
the administration of the Marketing Fund or the management of Marketing Fund-supported programs
(including full or partial salaries of our personnel who devote full- or part-time services to
Marketing Fund activities). 9.1.3. We will make available to you, at a reasonable cost, any
promotional materials produced with Marketing Fund monies, and we will deposit the proceeds of those
sales into the Marketing Fund account. We are not required to have an independent audit of the
Marketing Fund completed. We will make available an unaudited statement of contributions and
expenditures for the Marketing Fund 60 days after the close of our fiscal year to franchisees that
make a written request for a copy. 9.2. Local Marketing. Beginning on the Opening Date, during each
consecutive three-calendar-month period during the Term, you must spend three percent (3%) or more
of your Gross Sales on local marketing of the Franchised Business. You must make these local
marketing expenditures on a quarterly basis, based upon your Gross Sales calculated for the current
year on an annualized basis. Your local spending obligation is in addition to your Marketing Fund
contributions. Upon our request, you agree to submit to us, for our approval, an annual proposal and
quarterly proposals detailing your plan for implementing your local marketing budget. At our
request, you must submit appropriate documentation to verify compliance with the minimum spending
obligation. All local advertising, marketing, and promotions by you must be in such media, and such
types and format as we may approve; must be conducted in a dignified manner; and, must conform to
such standards and requirements as we may specify. You must not use any advertising, marketing
materials, or promotional plans unless and until you have received written approve from us, pursuant
to the procedures and terms set forth in Section 9.5 [Advertising Approval] below. We have the right
to periodically designate in the Manual the types of expenditures that will or will not count toward
the minimum annual spending requirement. You must advertise the Franchised Business in all major
directories in your Delivery/Catering and Advertising Area, including local online directories, as
specified in the Manual. If you advertise jointly with other franchisees, your share of the cost
will count toward your local spending requirement under this Section 9.2 [Local Marketing]. Page 21
of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 24 -->
9.3. Regional Fund. We have the right to designate any geographical area for purposes of
establishing a regional marketing fund ("Regional Fund"). If we have established a Regional Fund for
the geographic area in which your Franchised Business is located by the time you commence operations
hereunder, you must immediately become a member of such Regional Fund. If we establish a Regional
Fund for the geographic area in which your Franchised Business is located the Term of this
Agreement, you must become a member of such Regional Fund within thirty (30) days after the date on
which the Regional Fund commences operation. In no event will you be required to be a member of more
than one Regional Fund. The following provisions shall apply to each such Regional Fund: 9.3.1 Each
Regional Fund will be organized and governed in a form and manner, and will commence operations on a
date, that we have approved in advance in writing. 9.3.2 Each Regional Fund will be organized for
the exclusive purpose of administering regional marketing programs and developing, subject to our
approval, standardized promotional materials for use by the members in local marketing and
promotion. 9.3.3 No advertising, marketing, or promotional plans or materials may be used by a
Regional Fund or furnished to its members without our prior approval pursuant to the procedures and
terms as set forth in Section 9.5 [Advertising Approval] below. 9.3.4 You must contribute each
Period (commencing from the time we establish the Marketing Fund) to the Marketing Fund as provided
in Section 3.3 [Advertising Contributions], together with such statements or reports as we, or the
Regional Fund with our prior written approval, may require. If we request, you must submit your
Regional Fund contribution and reports to the Regional Fund directly to us for distribution to the
Regional Fund. 9.3.5 A majority of the Restaurant owners in the Regional Fund may vote to increase
the amount of each Restaurant owner's Regional Fund contribution by up to an additional two percent
(2%) of each Restaurant's Gross Revenues. Voting will be on the basis of one vote per Restaurant,
and any locations that we operate in the region, if any, will have the same voting rights as those
owned by our franchisees. You must contribute to the Regional Fund in accordance with any such vote
by the Regional Fund to increase each Restaurant's contribution by up to two percent (2%) of the
Gross Revenues of your Franchised Business. 9.3.6 We will credit the contributions you make to the
Regional Fund against the amounts you must spend on local advertising under Section 9.2 [Local
Marketing] above. 9.3.7 Although once established, each Regional Fund is intended to be of perpetual
duration, we maintain the right to terminate any Regional Fund. A Regional Fund will not be
terminated, however, until all monies in that Regional Fund have been expended for marketing and/or
promotional purposes. 9.4 Initial Advertising Campaign. You agree to conduct a Grand Opening
Advertising Program for the Franchised Business throughout the first four weeks after the Opening
Date, spending an amount not less than $12,000. You must obtain our prior written approval as
provided in Section 9.5 [Advertising Approval] below before implementing any advertising plans
and/or making any use or placement of advertising and promotional materials as part of the Grand
Opening Advertising Program. You acknowledge that the Grand Opening Advertising Program may not be
sufficient in all cases to develop adequate exposure to the services offered by your Franchised
Business, and that it may be necessary for you to supplement the Grand Opening Advertising Program
with additional advertising and promotional expenditures and efforts. Page 22 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 25 -->
9.5. Advertising Approval. You agree to conduct all advertising in a dignified manner and to conform
to the standards and requirements we specify from time to time in the Manual or other written
materials. We will make available to you approved advertising and promotional materials, including
signs, posters, collaterals, etc. that we have prepared. We will have the final decision on all
creative development of advertising and promotional messages. You must submit to us in writing, for
our approval before your use, all proposed plans, promotion materials, and advertising that we did
not prepare or approve in the previous year. If you do not receive our written approval within 10
business days from the date we received the material, the material is deemed disapproved. We reserve
the right to require you to discontinue the use of any advertising or marketing materials. 9.6.
Special Promotions. You agree to participate in and comply with special promotional activities that
we may prescribe from time to time for Franchised Businesses generally or in specific geographic
areas or for specific types of venues. You agree to bear your own costs of participating locally in
such promotions. 10. TECHNOLOGY 10.1. Computer System. We have the right to specify or require that
certain brands, types, makes, and/or models of communications, computer systems, and hardware to be
used by, between, or among Franchised Businesses, including without limitation: (a) back office and
point of sale systems, data, audio, video, and voice storage, retrieval, and transmission systems
for use at Franchised Businesses, between or among Franchised Businesses, and between and among your
Franchised Business and us, our designee and/or you; (b) Cash Register Systems (defined below); (c)
physical, electronic, and other security systems; (d) printers and other peripheral devices; (e)
archival back-up systems; and (f) internet access mode (e.g., form of telecommunications connection)
and speed (collectively, the "Computer System"). You agree to abide by our requirements with respect
to the Computer System. 10.1.1 We have the right, but not the obligation, to develop or have
developed for us, or to designate: (a) computer software programs and accounting system software
that you must use in connection with the Computer System ("Required Software"), which you must
install; (b) updates, supplements, modifications, or enhancements to the Required Software, which
you must install; (c) the tangible media upon which such you must record or receive data; (d) the
database file structure of your Computer System; and (e) an Extranet for informational assistance,
which may include, without limitation, the Manuals, training other assistance materials, and
management reporting solutions; and (f) answering service requirements and/or system-wide phone
order processing of all delivery orders, and/or to designate vendors that will provide such order
processing. 10.1.2 You agree to install and use the Computer System and Required Software in the
manner that we require. 10.1.3 You agree to implement and periodically upgrade and make other
changes to the Computer System and Required Software as we may reasonably request in writing
(collectively, "Computer Upgrades"). Page 23 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 26 -->
10.1.4 You agree to comply with the specifications that we issue with respect to the Computer System
and the Required Software, and with respect to Computer Upgrades, at your expense. You also agree to
afford us unimpeded access to your Computer System and Required Software in the manner, form, and at
the times that we request. 10.2 Data. You agree that all data that you collect from customers and
potential customers in connection with the Franchised Business ("Customer Data") is deemed to be
owned exclusively by us, and you also agree to provide the Customer Data to us at any time that we
request as you to do so. You have the right to use Customer Data while this Agreement or a Successor
Franchise Agreement is in effect, but only in connection with operating the Franchised Business and
only in accordance with the policies that we establish from time to time. You may not sell,
transfer, or use Customer Data for any purpose other than operating the Franchised Business and
marketing "Pizza Fusion" products and services. However, if you Transfer the Franchised Business (as
provided in Section 14.2 [No Transfer without Our Prior Written Consent] below), as part of the
Transfer, you may Transfer use of the Customer Data to the buyer for value. 10.3 Ownership of Data.
We have the right to specify, from time to time, in the Manual or otherwise in writing, the
information that you must collect and maintain on the Computer System, and you agree to provide us
with the reports that we may reasonably request from the data so collected and maintained. You agree
to download to us daily, or in such other intervals that we may require, all information and
materials that we may require in connection with your operation of the Franchised Business, and
shall display such information and materials in the manner we may prescribe, including, without
limitation, to employees of the Franchised Business. All data pertaining to, derived from, or
displayed at the Franchised Business (including without limitation data pertaining to or otherwise
about Franchised Business customers) is and shall be our exclusive property, and we hereby grant you
a royalty-free non-exclusive license to use that data during the Term of this Agreement. 10.4
Privacy Laws. You agree to abide by all applicable laws pertaining to the privacy of consumer,
employee, and transactional information ("Privacy Laws"). 10.4.1 You agree to comply with our
standards and policies pertaining to Privacy Laws. If there is a conflict between our standards and
policies pertaining to Privacy Laws and actual applicable law, you shall: (i) comply with the
requirements of applicable law; (ii) immediately give us written notice of said conflict; and (iii)
promptly and fully cooperate with is and our counsel in determining the most effective way, if any,
to meet our standards and policies pertaining to Privacy Laws within the bounds of applicable law.
10.4.2 You agree not to publish, disseminate, implement, revise, or rescind a data privacy policy
without our prior written consent as to said policy. 10.5 Website. We will maintain a Website for
benefit of ourselves and our franchisees. You agree not to establish a Website or permit any other
party to establish a Website that relates in any manner to your Franchised Business or referring to
the Proprietary Marks. We have the right, but not the obligation, to provide one or more references
or webpage(s) to your Franchised Business, as we may periodically designate, within our Website.
(The term "Website" means one or more related documents, designs, pages, or other communications
that can be accessed through electronic means, including but not limited to the Internet, World Wide
Web, social networking sites (including but not limited to Facebook, Twitter, LinkedIn, Google Wave,
etc.), blogs, vlogs, and other applications, etc.). If we ever do approve in writing a request for
you to use a separate Website, then we have the right to require that you meet any or all of the
following requirements: 10.5.1 You agree that any Website that you own or that is maintained for
your benefit will be deemed "advertising" under this Agreement, and will be subject to (among other
things) our prior written approval. 10.5.2 You shall not establish or use any Website without our
prior written approval. Page 24 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 27 -->
10.5.3 Before establishing any Website, you must submit to us, for our prior written approval, a
sample of the proposed Website domain name, format, visible content (including, without limitation,
proposed screen shots), and non-visible content (including, without limitation, meta data and meta
tags) in the form and manner we may reasonably require. 10.5.4 You agree not to use or modify any
such Website without our prior written approval as to such proposed use or modification. 10.5.5 In
addition to any other applicable requirements, you agree to comply with the standards and
specifications for Websites that we may periodically prescribe in the Manuals or otherwise in
writing. 10.5.6 If we require you to do so, you agree to establish hyperlinks to our Website and
others as we may request in writing. 10.6 Cash Register Systems. You must record all sales on
computer-based point of sale systems on such other types of cash registers that we have the right to
designate or approve in the Manual or otherwise in writing ("Cash Register Systems"). The Cash
Register System is deemed to be part of your Computer System. You must utilize computer-based
point-of-sale cash registers which are fully compatible with any program or system which we have the
right to designate and you must record all Gross Revenues and all revenue information on such
equipment. 10.7 Gift Cards. If we require, you agree to participate in a gift card program that we
specify. For this purpose, you must purchase the software, hardware, and other items needed to sell
and process gift cards, as we may specify in writing in the Manuals or otherwise. You must also pay
such monthly and per-swipe transaction fees as may be required by the vendor of the gift card
system. You must sell or honor gift cards only in accordance with our written standards. You must
not sell, issue, or redeem gift certificates other than gift cards we have approved in writing. 10.8
Use of the Proprietary Marks. You agree not to use or permit the use or display of the Proprietary
Marks as part of any Internet domain name or website, or any other electronic identifier (including
but not limited to e-mail addresses, account names in a social media site, and the like) of you or
the Franchised Business in any forum or medium. 10.9 Identification of the Franchised Business. You
must use, and only use, the email address and other identifiers we designate in connection with the
business of the Franchised Business. You agree not to transmit or cause any other party to transmit
advertisements or solicitations by e-mail or other electronic media without first obtaining our
written consent as to: (a) the content of such e mail advertisements or solicitations; and (b) your
plan for transmitting such advertisements. In addition to any other provision of this Agreement, you
will be solely responsible for compliance with any laws pertaining to sending e-mails including but
not limited to the Controlling the Assault of Non-Solicited Pornography and Proprietary Marketing
Act of 2003 (known as the "CAN-SPAM Act of 2003"). 10.10 Changes to Technology. Because changes to
technology are dynamic and not predictable within the term of this Agreement, and in order to
provide for inevitable but unpredictable changes to technological needs and opportunities, you
agree: (a) that we will have the right to establish, in writing, reasonable new standards to address
new technologies, and to implement those changes in technology into the System; and (b) to abide by
our reasonable new standards as if this Section 10 were periodically revised for that purpose. 10.11
E-Mail and Fax Communication. You agree that exchanging information with us by e-mail and fax is an
important way to enable quick, effective, and efficient communication, and that we are entitled to
rely upon each other's use of e-mail and faxes for communicating as part of the economic bargain
underlying this Agreement. To facilitate the use of e-mail and fax to exchange information, you
authorize the transmission of e-mail by us and our employees, vendors, and affiliates (on matters
pertaining to the business contemplated hereunder) (together, "Official Senders") to you and your
employees during the term of this Agreement. Page 25 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 28 -->
10.11.1 In order to implement the terms of this Section 10.11 [E-Mail and Fax Communication], you
agree that: (a) Official Senders are authorized to send e-mails and faxes to you and your employees;
(b) you will cause your officers, directors, and employees (as a condition of their employment or
position with you) to give their consent (in an e-mail, electronically, or in a pen-and-paper
writing, as we may reasonably require) to Official Senders' transmission of e-mails and faxes to
those persons, and that such persons shall not opt-out, or otherwise ask to no longer receive
e-mails, from Official Senders during the time that such person works for or is affiliated with you;
and (c) you will not opt- out, or otherwise ask to no longer receive e-mails and/or faxes, from
Official Senders during the term of this Agreement. 10.11.2 The consent given in this Section 10.11
[E-Mail and Fax Communication] will not apply to the provision of notices under this Agreement by
either party using e-mail (unless the parties otherwise agree in a pen-and-paper writing signed by
both parties). 11. OPERATING MANUAL We will furnish you with one copy of, or electronic access to,
the Manual, on loan, for as long as this Agreement or a Successor Franchise Agreement remains in
effect. We reserve the right to furnish all or part of the Manual to you in electronic form or
online and to establish terms of use for access to any restricted portion of our website. You
acknowledge that we own the copyright in the Manual and that your copy of the Manual remains our
property. You agree to treat the Manual, training materials, and any other manuals or materials
created or approved by us for use with the System as secret and confidential. You agree not to copy,
duplicate, record or otherwise reproduce the Manual or other materials provided by us, in whole or
in part. In addition, you agree not to make any confidential information or materials supplied by us
available to any unauthorized person. We have the right to amend and supplement the Manual from time
to time by letter, electronic mail, bulletin, videotape, audio tapes, software, or other forms of
communication. You agree to keep your copy of the Manual up-to-date and to comply with each new or
changed standard promptly upon receipt of notice from us. If a dispute develops relating to the
contents of the Manual, our copy of the Manual maintained at our headquarters will control. 12.
CONFIDENTIAL INFORMATION During and after the term of this Agreement, you may not communicate,
divulge, or use for any purpose other than the operation of the Franchised Business any confidential
information, knowledge, trade secrets or know-how that may be communicated to you or that you may
learn by virtue of your relationship with us and the System. You may divulge confidential
information only to your professional advisers and to your employees who must have access to the
information to operate the Franchised Business. All information, knowledge and know-how relating to
us, our business plans, or the System are deemed confidential for purposes of this Agreement, except
information that you can demonstrate came to your attention by lawful means prior to our disclosure;
or which, at the time of our disclosure to you, had become a part of the public domain. You must
require your employees, and any other person or entity to which you wish to disclose any
confidential information, to execute (and deliver to us upon our request) agreements, in the form
provided in Appendix C to this Agreement or as we may otherwise require in writing, that they will
maintain the confidentiality of the disclosed information. If you do not obtain execution of the
covenants required by this Section 12 and, upon our request, deliver those signed agreements to us,
that will constitute a default under Section 15.2.13 [Termination By Us Without A Cure Period]
below. Page 26 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 29 -->
13. TRANSFERS BY US We have the unrestricted right to transfer or assign all or any part of our
rights and/or our obligations under this Agreement to any person or legal entity without your
consent. You agree that we will have no liability after the effective date of transfer or assignment
for the performance of, or for any failure to perform, any obligations we have transferred. We also
have the absolute right to delegate to others the performance of any of our duties, obligations, or
benefits under this Agreement, to third parties (including, without limitation, an area developer
under the terms of an area development agreement with us), which will not be parties to an agreement
with you. 14. TRANSFERS BY YOU 14.1. Definition of Transfer. In this Agreement, "Transfer" as a verb
means to sell, assign, give away, pledge, or encumber, either voluntarily or by operation of law
(such as through divorce or bankruptcy proceedings), any interest in this Agreement the rights
and/or obligations under this Agreement, all or substantially all of the assets of the Franchised
Business, and/or any direct or indirect interest in the ownership of Franchisee (if the Franchisee
is a corporation, partnership, or limited liability company). "Transfer" as a noun means any such
sale, assignment, etc. 14.2. No Transfer without Our Prior Written Consent. Neither you nor any of
the Owners may make any Transfer or permit any Transfer to occur without obtaining our prior written
consent. We have the right to withhold our consent, except as otherwise provided in Sections 14.3
[Transfer of Entire Business] through 14.8 [Our Right of First Refusal]. We have the right to
communicate with and counsel both you and the proposed transferee on any aspect of a proposed
Transfer. If a Transfer requires our consent, then that transaction may not take place until at
least sixty (60) days after we receive written notice of the proposed Transfer. You agree to provide
any information and documentation relating to the proposed Transfer that we reasonably require.
Unless otherwise agreed, we do not waive any claims against the transferring party if we approve the
Transfer. 14.3. Transfer of Entire Business. For a proposed Transfer of the Franchised Business or
this Agreement (or, if Franchisee is a corporation or other entity, a Transfer of ownership
interests that would result in a change of control of Franchisee), the following conditions apply
(unless waived by us): 14.3.1. You must be in compliance with all obligations to us under this
Agreement and any other agreement you have with us and our affiliates as of the date of the request
for our approval of the Transfer, or you must make arrangements satisfactory to us to come into
compliance by the date of the Transfer. 14.3.2. The proposed transferee must complete all of the
following requirements: (a) Demonstrate to our satisfaction that he or she meets all of our
then-current qualifications to become a Pizza Fusion franchisee, and, at our request, the proposed
transferee must travel (at his or her expense) to our principal office for an interview. (b) Sign
our then-current standard form of franchise agreement (or the standard form most recently offered to
new franchisees, if we are not then offering franchises to new franchisees) for the then-remaining
balance of the Term of this Agreement, and such other ancillary agreements we require for new
Franchised Businesses. Their new franchise agreement may materially differ from the terms of this
Agreement. (c) Successfully complete our then-current training requirements and pay the then-current
fee for training. (d) If the proposed transferee is one of our other franchisees, he or she must not
be in default under his or her agreements with us and must have a good record of customer service
and compliance with our operating standards. (e) If the transferee is a corporation or other entity,
the owner or owners of a beneficial interest in the transferee must execute our then-current form of
personal guarantee. Page 27 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 30 -->
14.3.3. You or the transferee must make arrangements to modernize, upgrade, and conform the
Franchised Business, at your and/or the transferee's expense, to our then-current standards and
specifications for new Franchised Businesses. 14.3.4. We must be paid, either by you or the
transferee, a transfer fee ("Transfer Fee") in an amount equal to $7,500 (or twenty- five percent
(25%) of the then-current initial franchise fee, if greater). The payment of this transfer fee is in
place of any initial franchise fee due under the Franchise Agreement the transferee will enter under
Section 14.3.2 [Transfer of Entire Business] above. If the transferee is a spouse, son, or daughter
of the transferor and the transfer is for estate-planning purposes, no transfer fee is charged, but
the transferor must reimburse us for the out-of-pocket expenses (including attorneys' fees) we incur
in connection with reviewing, approving, and properly documenting the transfer. 14.3.5. You and all
Owners must execute a general release, in a form satisfactory to us, of all claims against us and
our past, present and future affiliates, officers, directors, shareholders, agents and employees.
You and the Owners will remain liable to us for all obligations arising before the effective date of
the Transfer. 14.3.6. The price and other proposed terms of the Transfer must not, in our reasonable
business judgment, have the effect of negatively impacting the future viability of the Franchised
Business. 14.4. Transfer of a Partial Ownership Interest. For any proposal to admit a new Owner, to
remove an existing Owner, or to change the distribution of ownership shown on the cover page, or for
any other transaction that amounts to the Transfer of a partial interest in the Franchised Business,
you must give us advance notice and submit a copy of all proposed contracts and other information
concerning the Transfer that we may request. We will have the right to require reimbursement of any
out-of-pocket expenses that we incur in reviewing the proposed Transfer. We will have a reasonable
time (not less than thirty (30) days) after we have received all requested information to evaluate
the proposed Transfer. You must satisfy the conditions in Sections 8.6, 14.3.2(a) [Transfer of
Entire Business], 14.3.4 [Transfer of Entire Business], 14.3.5 [Transfer of Entire Business], and
14.3.6 [Transfer of Entire Business] above in connection with any such transfer. We may withhold our
consent on any reasonable grounds or give our consent subject to reasonable conditions. You
acknowledge that any proposed new owner must submit a personal application and execute a personal
guarantee in the same form signed by the original Owners. 14.5. Transfer to a Corporation or Other
Entity. We will consent to the assignment of this Agreement to a corporation, partnership or limited
liability corporation that you form for the convenience of ownership, provided that: (a) the entity
has and will have no other business besides operating a Franchised Business (b) you satisfy the
conditions in Sections 14.3.2(a) [Transfer of Entire Business], 14.3.3 [Transfer of Entire
Business], 14.3.4 [Transfer of Entire Business] and 14.3.5 [Transfer of Entire Business] above; and
(c) the Owners hold equity interests in the new entity in the same proportion shown on the cover
page. There is no Transfer Fee for a Transfer to a corporation for convenience of ownership. 14.6.
Transfer upon Death or Incapacity. If you or any Owner dies, becomes incapacitated, or enters
bankruptcy proceedings, that person's executor, administrator, personal representative, or trustee
must apply to us in writing within three (3) months after the event (death, declaration of
incapacity, or filing of a bankruptcy petition) for consent to Transfer the person's interest. The
Transfer will be subject to the provisions of Sections 14.2 [No Transfer without Our Prior Written
Consent] through 14.8 [Our Right of First Refusal], as applicable, except there will be no Transfer
Fee. In addition, if the deceased or incapacitated person is the Operating Principal, you must
within 30 days thereafter, hire and retain a replacement, who is satisfactory to us, to perform such
obligations. If a satisfactory replacement is not retained, we will have the right (but not the
obligation) to take over operation of the Franchised Business, or to hire and retain a replacement
on your behalf, until the Transfer is completed and to charge a reasonable management fee for these
services. For purposes of this Section, "incapacity" means any physical or mental infirmity that
will prevent the person from performing his or her obligations under this Agreement: (i) for a
period of thirty (30) or more consecutive days; or (ii) for sixty (60) or more total days during a
calendar year. In the case of Transfer by bequest or by intestate succession, if the heirs or
beneficiaries are unable to meet the conditions of Section 14.3 [Transfer of Entire Business], the
executor may transfer the decedent's interest to another successor that we have approved, subject to
all of the terms and conditions for Transfers contained in this Agreement. If an interest is not
disposed of under this Section 14.6 [Transfer upon Death or Incapacity] within six (6) months after
the date of death or appointment of a personal representative or trustee, we may terminate this
Agreement under Section 15.2 [Termination By Us Without A Cure Period] below. Page 28 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 31 -->
14.7. Non-Conforming Transfers. Any purported Transfer that is not in compliance with this Section
14 is null and void and constitutes a material breach of this Agreement, for which we may terminate
this Agreement without opportunity to cure. Our consent to a Transfer does not constitute a waiver
of any claims that we have against the transferor, nor is it a waiver of our right to demand exact
compliance with the terms of this Agreement. 14.8. Our Right of First Refusal. We have the right,
exercisable within thirty (30) days after receipt of the notice specified in Section 14.2 [No
Transfer without Our Prior Written Consent], to send written notice to you that we intend to
purchase the interest proposed to be Transferred. We may assign our right of first refusal to
someone else either before or after we exercise it. However, our right of first refusal will not
apply with regard to a Transfer under Section 14.5 [Transfer to a Corporation or Other Entity] or a
Transfer to your parents, spouse, son, daughter, or mother or father in-law (including Transfers to
your parents, spouse, son, daughter, or mother or father in-law as a result of death or incapacity
as described in Section 14.6 [Transfer upon Death or Incapacity]). 14.8.1. If the Transfer is
proposed to be made pursuant to a sale, we or our designee may purchase the interest proposed to be
Transferred on the same economic terms and conditions offered by the third-party. Closing on our
purchase must occur by the later of (a) 60 days after the date of our notice to the seller electing
to purchase the interest, or (b) the closing date as proposed in the third-party's purchase offer.
If we cannot reasonably be expected to furnish the same consideration as the third-party, then we
may substitute the reasonable equivalent in cash. If the parties cannot agree within 30 days on the
reasonable equivalent in cash, we will designate, at our expense, an independent appraiser and the
appraiser's determination will be final. Any material change in the terms of the offer from a
third-party after we have elected not to purchase the seller's interest will constitute a new offer
subject to the same right of first refusal as the third party's initial offer. 14.8.2. If a Transfer
is proposed to be made by gift, we will designate, at our expense, an independent appraiser to
determine the fair market value of the interest proposed to be transferred. We may purchase the
interest at the fair market value determined by the appraiser. Closing on the purchase will occur
within 30 days after our notice to the transferor of the appraiser's determination of fair market
value. 14.8.3. If we elect not to exercise our rights under this Section, the transferor may
complete the Transfer after complying with Sections 14.2 [No Transfer without Our Prior Written
Consent] through 14.6 [Transfer upon Death or Incapacity] above. Closing of the Transfer must occur
within 60 calendar days of our election (or such longer period as applicable law may require);
otherwise, the third-party's offer will be treated as a new offer subject to our right of first
refusal. The Transfer is conditional upon our determination that the Transfer was on terms
substantially the same as those offered to us. 15. TERMINATION 15.1. Termination By Us Without
Notice. You will be in default under this Agreement and all rights granted by this Agreement will
automatically terminate without notice to you if you become insolvent or make an assignment for the
benefit of your creditors; if a receiver is appointed; if execution is levied against your business
assets; or if suit to foreclose any lien or mortgage or bankruptcy is instituted against you and not
dismissed within 60 days. Page 29 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 32 -->
15.2. Termination By Us Without A Cure Period. We may terminate this Agreement by written notice to
you, without giving you an opportunity to cure, upon the occurrence of any of the following events:
15.2.1. You, the Operating Principal, and/or your personnel fail to complete training under Section
5.1 [Initial Training Program] to our satisfaction. 15.2.2. You fail to open for business by the
opening deadline specified in Appendix A. 15.2.3. You disclose the contents of the Manual or other
trade secrets or confidential information contrary to Sections 11 and 12 of this Agreement. 15.2.4.
You refuse to permit, or try to hinder, an examination or audit of your books and records or of the
Franchised Business as provided in this Agreement. 15.2.5. You make any material misrepresentation
in connection with your application to us for the franchise, or you submit to us any report or
statement that you know or should know to be false or misleading. 15.2.6. You understate to us your
Gross Revenues, by 2% or more on three or more occasions in any twelve-month period, or by 5% or
more for any period of four or more consecutive weeks. 15.2.7. You fail to operate the Franchised
Business for three or more consecutive business days on which you were required to operate, unless
we determine that the failure was beyond your control. 15.2.8. You or any Owner, officer or director
is convicted of a crime that we reasonably believe is likely to harm the reputation of the Pizza
Fusion concept. 15.2.9. Any Transfer occurs that does not comply with Section 14, including a
failure to transfer to a qualified successor after death or disability within the time allowed by
Section 14.7 [Non-Conforming Transfers]. 15.2.10. You are in default three (3) or more times under
Sections 15.3 [Termination by Us Following Expiration of Cure Period for Monetary Default] and/or
15.4 [Termination by Us Following Expiration of Cure Period] within any twelve (12) month period,
whether or not the defaults are similar and whether or not they are cured. 15.2.11. After curing a
default pursuant to Sections 15.3 [Termination by Us Following Expiration of Cure Period for
Monetary Default] or 15.4 [Termination by Us Following Expiration of Cure Period], you commit the
same default within twelve (12) months, whether or not the second default is cured. 15.2.12. Any
condition exists with respect to the Franchised Business that, in our reasonable judgment, seriously
jeopardizes public health or safety. 15.2.13. You fail to comply with the covenants in Section 17
below or fail to timely obtain execution of the covenants required under Section 12 above and
Section 17.3 [Owners and Employees] below. 15.2.14. You fail to obtain or maintain required
insurance. 15.2.15. You cease to operate the Franchised Business for more than seven (7) consecutive
days or fourteen (14) days in any calendar year unless we approved a temporary closing or we
determine, that the failure to operate was beyond your control, you otherwise abandon the Franchised
Business, or you lose the right to possess the Premises or you otherwise forfeit the right to do or
transact business as required under this Agreement. If, however, through no fault of you, the
Premises are damaged or destroyed by an event such that repairs or reconstruction cannot be
completed within ninety (90) days thereafter, you will have thirty (30) days after such event in
which to apply for our approval to relocate and/or reconstruct the premises, and we will not
unreasonably hold our approval. Page 30 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 33 -->
15.3. Termination by Us Following Expiration of Cure Period for Monetary Default. You will be in
default under this Agreement if you fail, refuse, or neglect to pay when due (including if we are
not able to collect payments by electronic fund transfer pursuant to Section 3.6 [Method of Payment]
due to insufficient funds in your account(s), closure of your account(s), or any other reason
resulting in the nonpayment) any monies owing to us, our affiliates, or any lender that has provided
financing to you under this Agreement or any other agreement, or to your landlord and/or any
supplier of goods or services to your Franchised Business. You will have ten (10) days after written
notice of such default from us within which to remedy the default. You may avoid termination by
curing the default to our satisfaction within the 10-day period (or such longer period as applicable
law may require). If you do not cure the default within such 10-day period (or such longer period as
applicable law may require), this Agreement will terminate automatically and without further notice,
effective immediately upon the expiration of the specified time period. 15.4 Termination by Us
Following Expiration of Cure Period. For any default not covered under Sections 15.1 [Termination By
Us Without Notice], 15.2 [Termination By Us Without A Cure Period], or 15.3 above, you will have
thirty (30) days after written notice of default from us within which to remedy the default. You may
avoid termination by curing the default to our satisfaction within the 30-day period (or such longer
period as applicable law may require). If you do not cure the default within the specified time,
this Agreement will terminate automatically and without further notice, effective immediately upon
the expiration of the specified time period. Any failure to comply with this Agreement, as amended
or reasonably supplemented by the Manual or otherwise in writing, not covered by Sections 15.1
[Termination By Us Without Notice], 15.2 [Termination By Us Without A Cure Period], or 15.3 above
constitutes a default, including, but not limited to, the following: 15.3.1. You fail, refuse, or
neglect to submit to us the financial and other reports and information required under this
Agreement. 15.3.2. You fail to comply with any of the mandatory standards or procedures prescribed
by us in this Agreement, the Manual, or otherwise in writing. 15.3.3. You fail, refuse, or neglect
to obtain our prior written approval or consent as required by this Agreement (other than a failure
to obtain consent to a proposed Transfer, for which we may terminate without a cure period as
provided in Section 15.2 [Termination By Us Without A Cure Period]). 15.3.4. For a period of fifteen
(15) days, you allow a continued violation of any law, ordinance, rule or regulation of a
governmental agency, including the failure to maintain or procure any required licenses, permits, or
certifications, in the absence of a good faith dispute over its application or legality and without
promptly resorting to an appropriate administrative or judicial forum for relief. 15.3.5. You misuse
or make any unauthorized use of the Proprietary Marks or otherwise materially impair our goodwill or
rights in the Proprietary Marks. 15.5. Cross-Default. Any default by you (including for this purpose
your affiliates) under any other agreement with us will constitute a default under this Agreement,
subject to the same provisions for notice and cure, if any, as may be applicable to the default
under the other agreement. 16. OBLIGATIONS ON TERMINATION OR EXPIRATION 16.1. Upon termination or
expiration of this Agreement for any reason, unless we direct you otherwise: 16.1.1. You agree to
promptly pay all sums owing to us, our affiliates and suppliers, including, but not limited to,
Royalty payments, contributions to the Marketing Fund, or other fees, damages, expenses, and
attorney's fees incurred as a result of your default. Page 31 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 34 -->
16.1.2. You agree to stop making any use of the confidential methods, procedures, and techniques
associated with the System. You also agree to immediately deliver to us the Manual and all training
materials, marketing materials, records, files, forms, instructions, signs, equipment,
correspondence, copies, Customer Data, and other property in your possession or control that contain
confidential information (as defined in Section 12) or that bear the Proprietary Marks and you agree
not to retain any unauthorized copies of these materials. You also must deliver to us all customer
information that you have compiled. 16.1.3. You agree to immediately cease to use, by advertising or
in any other manner, the name "Pizza Fusion," all other Proprietary Marks, and all other distinctive
forms, slogans, signs, symbols, Websites, domain name, website, e-mail address, and any other
identifier (whether or not we have authorized its use) that you used in connection with your
operation of the Franchised Business or that are otherwise associated with the Proprietary Marks,
System, and/or us. If you subsequently begin to operate another business, you agree that you will
not use any reproduction, counterfeit, copy or colorable imitation of the Proprietary Marks that you
used either in connection with the Franchised Business or its promotion, which is likely to cause
confusion, mistake or deception, or which is likely to dilute our exclusive rights in and to the
Proprietary Marks, nor any trade dress or designation of origin or description or representation
which falsely suggests or represents an association or connection with us. 16.1.4. You agree to
promptly take such action as may be necessary to cancel any assumed name registration or equivalent
registration containing the name PIZZA FUSION or any other Proprietary Marks. 16.1.5 You will, at
our option, assign to us any interest which you have in the lease or sublease for the Premises. (a)
If we do not elect or are unable to exercise our option to acquire, or to acquire the lease or
sublease for the Premises, you must make such modifications or alterations to the premises operated
hereunder (including, without limitation, the changing of the telephone number) immediately upon
termination or expiration of this Agreement as may be necessary to distinguish the appearance of the
Premises from that of other Restaurants under the System, and such specific additional changes as we
may reasonably request for that purpose. In addition, you must stop making any use of any telephone
number and/or any domain name, website, e-mail address, and any other identifier (whether or not we
have authorized its use) that you used in connection with your operation of the Franchised Business,
and you must promptly execute such documents or take such steps necessary to remove reference to the
Franchised Business from all trade or business telephone directories, including physical and online
"yellow" and "white" pages, or at our request transfer same to us. (b) If you fail or refuse to
comply with the requirements of this Section 16.1.5 [OBLIGATIONS ON TERMINATION OR EXPIRATION], we
will have the right to enter upon the Premises, without being guilty of trespass or any other tort,
for the purpose of making or causing to be made such changes as may be required, at your expense,
which you agree to pay upon demand. 16.2. Purchase of Assets. You agree that, at our option, you
will sell to us any or all your assets used to operate the Franchised Business (including equipment,
fixtures, furnishings, Delivery Vehicles, supplies, and inventory) that we ask in writing to
purchase. 16.2.1. The purchase price for such items will be equal to your depreciated cost
(determined below) or fair market value, whichever is less. The cost will be determined based upon a
five (5) year straight-line depreciation of original costs. For equipment that is five (5) or more
years old, the parties agree that fair market value will be deemed to be ten percent (10%) of the
equipment's original cost. The fair market value of tangible assets must be determined without
reference to good will, going-concern value, or other intangible assets. Page 32 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 35 -->
16.2.2. We may exercise this option by delivering a notice of intent to purchase to you within 30
days after the expiration or termination of this Agreement. During that 30-day period, you agree not
to dispose of, transfer, or otherwise hinder our ability to exercise our rights with respect to your
assets. 16.2.3. If we exercise our option to purchase, we may setoff all amounts due to us under
this Agreement and the cost of the appraisal (if any), against any payment due to you. 16.2.4. If we
do not exercise our rights to purchase your Delivery Vehicle(s), you must immediately make such
modifications or alterations to the Delivery Vehicle(s) that may be needed to remove any Proprietary
Marks and to otherwise distinguish the appearance of the vehicle(s) from those used by other
Restaurants. 16.3. Right to Enter and Continue Operations. In order to preserve the goodwill of the
System following termination, we (or our designee) have the right to enter the Premises (without
liability to you, your Owners, or otherwise) for the purpose continuing the Franchised Business'
operation and maintaining the goodwill of the business. 16.4. Liquidated Damages. If this Agreement
is terminated due to your default, you must, upon written demand, pay us a lump-sum payment in an
amount calculated as follows: (a) the average of your Royalty fees and Advertising Contributions due
for the last 60 months before our delivery of notice of default (or, if lesser, the months you had
been operating before our delivery of notice of default), (b) multiplied by the lesser of 60 or the
number of months remaining in the term of this Agreement. 16.5. Liquidated Damages. 16.5.1 The
payments called for in Section 16.4 [Liquidated Damages] above constitute liquidated damages for
causing the premature termination of this Agreement and not a penalty. A precise calculation of the
full extent of damages that we will incur if this Agreement terminates because you default cannot be
reasonably determined. Nevertheless, the parties agree that the lump-sum payment provided under
Section 16.4 [Liquidated Damages] above is reasonable in light of the damages for premature
termination that may reasonably be expected to occur in such event. 16.5.2 The amounts contemplated
under Section 16.4 [Liquidated Damages] above is not a penalty and is intended by the parties only
as a compensatory remedy for past breaches and not as a preventative remedy to deter future
breaches. Neither does the sum contemplated in Section 16.4 [Liquidated Damages] above represent a
price for the privilege of not performing or its payment represent an alternative manner of
performance. Accordingly, as a purely liquidated damage provision, this Section does not preclude,
nor is inconsistent with, a court granting us specific performance or any other equitable remedies,
such as an injunction, to prevent future breaches. Our rights to liquidated damages and specific
performance or any other equitable relief are not mutually exclusive. 16.6. Enforcement Costs. You
agree to pay all damages, costs, and expenses, including, but not limited to, reasonable attorneys'
fees, that we incur (even if after the expiration or termination of this Agreement) in enforcing
this Section 16 or Section 17.2 [After Termination, Expiration, or Transfer] below. 17. RESTRICTIONS
ON COMPETITION 17.1. During Term. You acknowledge that this Agreement will give you access to
valuable and confidential information regarding the System, including our business development
strategy and the operational, sales, promotional and marketing methods of Franchised Businesses. You
agree that during the term of this Agreement, you will not, without our prior written consent,
either directly or indirectly through any other person or entity: Page 33 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 36 -->
17.1.1. Own, manage, engage in, be employed by, advise, make loans to, consult for, rent or lease
to, or have any other interest in any business that (directly or indirectly) operates, or grants
franchises or licenses to operate, a restaurant featuring pizza and related food specialties or that
offers products or services substantially similar to those then offered by Restaurants ("Competitive
Business"); 17.1.2. Divert or attempt to divert any business or customer, or potential business or
customer, to any Competitive Business; or 17.1.3. Induce any person to leave his or her employment
with us. 17.1.4. In any manner interfere with, disturb, disrupt, impair, diminish, or otherwise
jeopardize our business or that of any of our franchisees. 17.2. After Termination, Expiration, or
Transfer. For two (2) years after the expiration or termination of this Agreement or an approved
Transfer to a new franchisee, you may not directly or indirectly own, manage, engage in, be employed
by, advise, make loans to, consult for, or have any other interest in any Competitive Business that
is, or intends to operate, within three (3) mile radius of the Premises of your Franchised Business
or within a three (3) mile radius of any Restaurant then-operating or under construction to operate
under the System, except as permitted by any Franchise Agreements that remain in effect between you
and us. . 17.3. Owners and Employees. The Owners agree that they will personally bind themselves to
this Section 17 by signing this Agreement or the attached Guaranty. With respect to the Owners, the
time period in Section 17.2 [After Termination, Expiration, or Transfer] will run from the
expiration, termination, or Transfer of this Agreement or from the termination of the Owner's
relationship with you, whichever occurs first. You must also require and obtain execution of
covenants similar to those set forth in Section 12 above, and this Section 17 (as modified to apply
to an individual), from any or all of the following persons: your officers, directors, and their
respective spouses and employees. (These persons and the Owners are each a "Restricted Party") The
covenants required by this Section 17.3 [Owners and Employees] shall be in the form provided in
Appendix C to this Agreement. Failure by Franchisee to obtain execution of a covenant required by
this Section 17.3 [Owners and Employees] shall constitute a default under Section 15.2.13
[Termination By Us Without A Cure Period] above. 17.4. Indirect Violations Prohibited. You may not
attempt to circumvent the restrictions in Sections 17.1 [During Term] and 17.2 [After Termination,
Expiration, or Transfer] by engaging in prohibited activity indirectly through any other person or
entity. 17.5. Enforcement. You agree that the existence of any claim you may have against us,
whether or not arising from this Agreement, will not constitute a defense to our enforcement of this
Section 17. You agree to pay all costs and expenses that we reasonably incur in enforcing this
Section 17, including reasonable attorneys' fees. You acknowledge that a violation of the terms of
this Section 17 would result in irreparable injury to us for which no adequate remedy at law may be
available. Accordingly, you consent to the issuance of an injunction prohibiting any conduct in
violation of the terms of this Section 17. Such injunctive relief will be in addition to any other
remedies that we may have. 18. RELATIONSHIP OF THE PARTIES This Agreement does not create a
fiduciary or other special relationship or make you or us an agent, legal representative, joint
venturer, partner, employee, or servant of each other for any purpose. You are not authorized to,
and agree that you will not, make any contract, agreement, warranty, or representation on our
behalf, or create any obligation, express or implied, on our behalf. During the term of this
Agreement, you agree to hold yourself out to the public as an independent contractor operating the
Franchised Business under license from us, and you agree to disclose your status as independent
contractor in all business dealings and exhibit a notice to that effect (the location and content of
which we reserve the right to specify) on all promotional materials, invoices and stationery. Page
34 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 37 -->
19. INDEMNIFICATION You agree to hold harmless, defend, and indemnify us and our past, present and
future affiliates, officers, directors, shareholders, agents, attorneys, consultants, and employees
against any claims, losses, costs, expenses (including, but not limited to, reasonable attorneys'
fees, costs of investigation, settlement costs, and interest), liabilities and damages
(collectively, "Claims") arising directly or indirectly from, as a result of, or in connection with
your activities under this Agreement. With respect to any threatened or actual litigation,
proceeding, or dispute that could directly or indirectly affect us or any of the other indemnitees
under this Section, if you do not assume the active defense of the matter within a reasonable time,
we will have the right, but not the obligation, to: (i) choose counsel; (ii) direct and control the
handling of the matter; and (iii) settle any claim against the indemnitees. This Section will
survive the expiration or termination of this Agreement, and applies to Claims even if they exceed
the limits of your insurance coverage. 20. CONSENTS AND WAIVERS 20.1. Consent. Whenever our prior
written consent is required under this Agreement, you agree to make a timely written request to us
for such consent. Our approval or consent must be in writing and signed by an authorized officer to
be effective. 20.2. Waivers. No delay or failure to exercise any right under this Agreement or to
insist upon your strict compliance with any obligation or condition, and no custom or practice that
differs from the terms of this Agreement, will constitute a waiver of our right to exercise the
contract provision or to demand your strict compliance with the terms of this Agreement. Our waiver
of any particular default does not affect or impair our rights with respect to any subsequent
default you may commit. Our waiver of a default by another franchisee does not affect or impair our
right to demand your strict compliance with the terms of this Agreement. Our acceptance of any
payments due from you does not waive any prior defaults. 21. NOTICES Notices related to this
Agreement must be in writing and personally delivered, sent by registered mail, or by other means
which affords the sender evidence of delivery, or of rejected delivery, to the respective parties.
Any notice by a means that affords the sender evidence of delivery, or rejected delivery, shall be
deemed to have been given at the date and time of receipt or rejected delivery. We will send notices
intended for you to your address on the first page of this Agreement. You agree to send notices
intended for us to our principal business address, which is currently 2200 West Cypress Creek Road,
1st Floor, Fort Lauderdale, Florida 33309. Either party can change its notice address by informing
the other party in writing of a new address. 22. ENTIRE AGREEMENT AND AMENDMENTS This Agreement and
the documents referred to herein constitute the entire agreement between you and us with respect to
the Franchised Business and supersede all prior negotiations, representations, correspondence, and
agreements concerning the same subject matter. However, nothing in this Agreement is meant to
disclaim any representation that we make in the Franchise Disclosure Document that we have given to
you. Any amendment to this Agreement will not be binding on either party unless that amendment is
writing and signed by both parties. Page 35 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 38 -->
23. CONSTRUCTION OF THE AGREEMENT, SEVERABILITY, AND SURVIVAL 23.1. Clauses are Severable. Each
provision of this Agreement is severable from the others. If, for any reason, any provision is
determined by a court to be invalid, the invalidity will not impair the operation of the remaining
provisions of this Agreement. The latter will continue to be given full force and effect and bind us
and you. 23.2. Survival of Clauses. Each provision of this Agreement that expressly or by reasonable
implication is to be performed, in whole or in part, after the expiration, termination, or Transfer
of this Agreement will survive such expiration, termination, or Transfer. 23.3 Force Majeure. If the
performance of any obligation by any party under this Agreement is prevented, hindered or delayed by
reason of Force Majeure, which cannot be overcome by reasonable commercial measures, then the
parties shall be relieved of their respective obligations (but only to the extent, that the parties,
having exercised best efforts, are prevented, hindered or delayed in such performance) during the
period of such Force Majeure. The party whose performance is affected by an event of Force Majeure
shall give prompt written notice in the circumstances of such Force Majeure event to the other party
by describing the nature of the event and an estimate as to its duration, if possible. As used in
this Agreement, the term "Force Majeure" means any act of God, strike, lock out or other industrial
disturbance, terrorist act, war (declared or undeclared), riot, epidemic, fire or other catastrophe,
or act of any government. However, your inability to obtain financing or make payments (regardless
of the reason) does not constitute "Force Majeure." 23.4 Cover Page, Recitals, and Captions. The
parties agree to incorporate by reference, and include in the text of this Agreement, the
information on the cover page and in the recital paragraphs. The parties also agree that all of the
captions in this Agreement are meant only for the convenience of the parties, and none of the
captions shall be deemed to affect the meaning or construction of any provision of this Agreement.
23.5 No Third Party Rights. Except as otherwise stated in this Agreement, nothing in this Agreement
is intended (nor shall be deemed) to confer upon any party any rights or remedies under or by reason
of this Agreement, except for you, us, and such of our respective successors and assigns as may be
contemplated (and, as to you, permitted) by Sections 13 and 14 above. 24. GOVERNING LAW This
Agreement and the relationship between the parties is governed by and will be construed exclusively
in accordance with the laws of the State of Florida (without regard to, and without applying,
Florida conflict-of-law rules). 25. DISPUTES 25.1. Submission to Mediation. Except as otherwise
provided in Section 25.7 [Remedies Not Exclusive] below, any controversy or claim arising between us
will first be submitted to non-binding mediation administered by an established, neutral mediation
service with experience in franchise disputes. Both parties must sign a confidentiality agreement
before participating in any mediation proceeding. The mediation will take place in the city where
our principal offices are located at the time the demand for mediation is filed. Once either party
has submitted a dispute to mediation, the obligation to attend will be binding on both parties. Each
party will bear its own costs with respect to the mediation. The fee for the mediation, however,
will be split equally. 25.2. Forum for Litigation. You and the Owners must file any suit against us,
and we may file any suit against you, in the federal or state court where our principal office is
located at the time the suit is filed. The parties waive all questions of personal jurisdiction and
venue for the purpose of carrying out this provision. Page 36 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 39 -->
25.3. Mutual Waiver of Class Actions. Any lawsuit, claim, counterclaim, or other action may be
conducted only on an individual basis, and not as part of a consolidated, common, or class action.
25.4. Mutual Waiver of Jury Trial. You and we each irrevocably waive trial by jury in any
litigation. 25.5. Mutual Waiver of Punitive Damages. Each of us waives any right to or claim of
punitive, exemplary, multiple, or consequential damages against the other in litigation and agrees
to be limited to the recovery of actual damages sustained. 25.6 Time Period to Bring Claims. Any and
all claims and actions arising out of or relating to this Agreement, the relationship between you
and us, or your operation of the Restaurant, brought by any party hereto against the other, must be
commenced within one (1) year from the occurrence of the facts giving rise to such claim or action,
or, it is expressly acknowledged and agreed by all parties, such claim or action will be irrevocably
barred. 25.7. Remedies Not Exclusive. Except as provided in Sections 25.1 [Submission to Mediation]
through 25.4 [Mutual Waiver of Jury Trial] above, no right or remedy that the parties have under
this Agreement is exclusive of any other right or remedy under this Agreement or under applicable
law. 25.8. Our Right to Injunctive Relief. Nothing in this Agreement bars our right to obtain
injunctive or declaratory relief against a breach or threatened breach of this Agreement that will
cause us loss or damage. You agree that we will not be required to prove actual damages or post a
bond or other security in seeking or obtaining injunctive relief (both preliminary and permanent)
and/or specific performance. 25.9. Attorneys Fees and Costs. You agree to reimburse us for all
expenses we reasonably incur (including attorneys' fees): (a) to enforce the terms of this Agreement
or any obligation owed to us by you and/or the Owners; and (b) in the defense of any claim you
and/or the Owners assert against us upon which we substantially prevail in court, arbitration,
mediation, or other formal legal proceedings. 26. ACKNOWLEDGMENTS 26.1. Independent Investigation.
You and the Owners acknowledge that: 26.1.1. You have conducted an independent investigation of the
business venture contemplated by this Agreement and recognize that it involves business risks and
that your results will be largely dependent upon your own efforts and ability; 26.1.2. We expressly
disclaim the making of, and you acknowledge that you have not received, any representation, express
or implied, as to the potential volume, profits or success of the business venture contemplated by
this Agreement; 26.1.3. Any financial performance information presented in our Franchise Disclosure
Document is not a warranty or guaranty of the results that you will achieve, and your experience is
likely to differ; and 26.1.4. We do not, by virtue of any approvals or advice provided to you,
assume responsibility or liability to you or any third- party to which we would otherwise not be
subject. Page 37 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 40 -->
26.1.5 You have sole and complete responsibility for the choice of the Premises; that we have not
(and will not be deemed to have, even by virtue of our approval of the proposed Premises) given any
representation, promise, or guarantee of your success at the Premises; and that you will be solely
responsible for its own success at the Premises. 26.1.6 We make no warranty as to your ability to
operate the Franchised Business in the jurisdiction in which the Franchised Business is to be
operated. You must seek or obtain advice of counsel specifically with respect to this issue. 26.2.
Receipt of Documents. You acknowledge that you received a copy of this Agreement, the exhibit(s)
hereto, and agreements relating hereto, if any, with all of the blank lines therein filled in, at
least seven (7) days before the date when this Agreement was signed, and with sufficient time within
which to review the Agreement, with advisors of your choosing. You further acknowledge that you
received our franchise disclosure document required by the Federal Trade Commission's Franchise Rule
at least fourteen (14) days before the date this Agreement was signed. 26.3. Personal Obligations of
Owners. The Owners acknowledge that, by signing this Agreement or the Personal Guaranty attached as
Appendix B, they are binding themselves as individuals to all of the terms and conditions of this
Agreement, including without limitation Section 9, Section 14, Section 17, and Section 25. 26.4.
System Standards. Although we retain the right to establish and periodically modify System
standards, which you have agreed to maintain in the operation of the Franchised Business, you retain
the right and sole responsibility for the day to day management and operation of the Franchised
Business and the implementation and maintenance of System standards at the Franchised Business.
26.5. Other Offers. You acknowledge and agree that we may modify the offer of our franchises to
other franchisees in any manner and at any time, which offers and agreements have or may have terms,
conditions, and obligations that may differ from the terms, conditions, and obligations in this
Agreement. 26.6. No Conflicting Obligations. Each party represents and warrants to the others that
there are no other agreements, court orders, or any other legal obligations that would preclude or
in any manner restrict such party from: (a) negotiating and entering into this Agreement; (b)
exercising its rights under this Agreement; and/or (c) fulfilling its responsibilities under this
Agreement. [Signature page follows.] Page 38 of 39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 41 -->
The parties, intending to be legally bound, have entered into this Agreement on the date first
written above. Pizza Fusion Holdings, Inc. Franchisee By: By: Name: Name: Title: Title: Page 39 of
39

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 42 -->
APPENDIX A OPENING DEADLINE AND DELIVERY/CATERING AND ADVERTISING AREA 1. Opening Deadline:
____________________________ [Unless, otherwise agreed upon, the Opening Deadline will be nine
months after the Agreement Date]. 2. Delivery/Catering and Advertising Area: (to be completed once
Premises known). 3. Site Selection Area (if applicable):

Pizza Fusion Holdings, Inc. Franchisee By: By: Name: Name: Title: Title: -A -

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
