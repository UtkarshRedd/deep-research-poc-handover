<!-- page 1 -->
# DISTRIBUTORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| SEC Filing Date | 2018-08-01 |
| Parties | STARAR SURGICAL AG ("STAAR"); Distributor ("Distributor") |
| Source | CUAD v1 / StaarSurgicalCompany_20180801_10-Q_EX-10.37_11289449_EX-10.37_Distributor Agreement |

Exhibit 10.37 DISTRIBUTORSHIP AGREEMENT THIS DISTRIBUTORSHIP AGREEMENT (the "Agreement") is entered
into and made effective as of ____________ (the "Effective Date"), by and between STAAR SURGICAL AG,
a Swiss corporation, with a principal place of business at Hauptstrasse 104, CH - 2560 Nidau,
Switzerland, ("STAAR"), and _______________, a corporation organized and existing under the laws of
_________________, with its principal place of business at _______________________ ("Distributor").
Recitals A. STAAR is engaged in the manufacture, global distribution and sale of ophthalmic
products, including a range of devices for cataract, glaucoma and refractive surgery. B. Distributor
is engaged in and has experienced and trained personnel for the marketing, distribution and sale of
ophthalmic products in ________________. C. STAAR desires to engage Distributor, and Distributor
desires to be engaged by STAAR, to market, distribute and sell the Products (as defined below) in
_______________ on the terms and conditions set forth herein. NOW, THEREFORE, in consideration of
the foregoing premises, and the mutual covenants and conditions contained herein, and other good and
valuable consideration, the parties hereby agree as follows: Agreement 1. Appointment and Acceptance
1.1 STAAR hereby appoints Distributor, and Distributor hereby accepts such appointment, to purchase
the Products from STAAR and market, distribute and sell them in the Territory on the terms and
conditions set forth herein. Distributor shall not have the right to appoint any subdistributors,
subcontractors or other third parties to market, distribute or sell the Products. All Products shall
be marketed, distributed and sold solely under STAAR's Trademarks. STAAR may utilize any of its
affiliates to carry out STAAR's obligations under this Agreement; provided that STAAR shall remain
liable for the due observance and performance of this Agreement by any such affiliate. 1.2
Distributor shall (a) procure the Products solely from STAAR (or its affiliates) and not (b)
procure, manufacture, market or sell in the Territory any implantable medical devices that compete
directly or indirectly with the Products, during the term of this Agreement. Distributor shall use
its best efforts to promote and sell the Products to the maximum number of responsible customers in
the Territory. 1.3 Subject to Section 8.3, Distributor's right to market, distribute and sell the
Products in the Territory shall be exclusive. Distributor shall not sell any Products to a customer
if Distributor knows or has reason to believe that such customer intends to remove those Products
from the Territory. Distributor acknowledges and agrees that STAAR retains the right to sell the
Products in the Territory directly or indirectly, including but not limited to via electronic
commerce (without compensation to the Distributor). The Distributor shall cooperate with STAAR in
servicing corporate accounts for customers operating in multiple Territories.

1

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 2 -->
1.4 During the term of this Agreement, and subject to the terms and conditions hereof, STAAR hereby
grants to Distributor, and Distributor hereby accepts, the limited, nontransferable, nonexclusive
right and license to use the trade name, trademarks, and logos of STAAR (collectively,
"Trademarks"), without the right to grant sublicenses, solely in connection with the marketing,
distribution and sale of the Products in the Territory pursuant to this Agreement. Distributor shall
use and display the Trademarks solely in the manner, form, design, color and layout agreed by STAAR
in its sole discretion. Distributor shall not use the Trademarks as part of or in combination with
Distributor's trade name or marks. Distributor shall only market, distribute and sell the Products
under the Trademarks and shall not use the Trademarks in any advertising or promotional campaigns or
otherwise, or use any confusingly similar names or logos, in any manner that, in STAAR's sole
discretion, may be misleading or harmful to STAAR (or its affiliates). Subject to the limited use
rights granted to Distributor in respect of the Trademarks under this Agreement, all powers that
would be conferred on authorized users under other laws are expressly excluded. 1.5 The term
"Products" shall mean those certain products, specified by brand name, manufactured and marketed
under the Trademarks by STAAR that are listed on Exhibit A-1 hereto. STAAR may from time to time
modify or change the Products on Exhibit A-1 in its sole discretion, and if so, will notify
Distributor promptly thereof. In the event that STAAR discontinues a Product, it will provide at
least thirty (30) days' prior written notice to Distributor. Distributor shall not modify,
disassemble or reverse engineer any Product, in whole or in part. 1.6 The term "Territory" shall
mean ________. Distributor shall not promote, market, distribute or sell the Products outside the
Territory. 1.7 Except for the rights expressly granted to Distributor pursuant to Sections 1 and 2,
Distributor acknowledges and agrees that STAAR reserves and retains all rights with respect to the
marketing, distribution and sale of the Products in the Territory (and elsewhere). Notwithstanding
any other provision hereof to the contrary, STAAR shall have the unrestricted right, at its sole
discretion, directly or indirectly through third party distributors, to among other things (a)
supply, market, distribute and sell any product in the Territory other than the Products, (b)
supply, market, distribute and sell any Product in the Territory on an OEM basis under third party
trademarks, and (c) market, distribute and sell the Products (or any other product) in any
geographic region outside the Territory. 2. Business of Distributor Distributor is and shall remain
an independent contractor. Distributor agrees that STAAR has granted it no authority to act or make
any representations or warranties on behalf of STAAR. Distributor is at all times acting for its own
account, and at its own expense. Distributor represents to STAAR that Distributor has trained and
experienced personnel, facilities and other resources in the Territory in order to diligently,
professionally and effectively market, distribute and sell the Products. Distributor shall comply
with all applicable laws, statutes, regulations and treaties relating to the marketing, distribution
and sale of the Products and the performance of its duties and obligations hereunder. Distributor
shall be free to establish its own pricing for Products sold by Distributor and shall notify STAAR
of its pricing, as in effect from time to time.

2

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 3 -->
3. Term The term of this Agreement shall commence on the Effective Date and terminate in
_____________, on _____________, unless terminated earlier pursuant to the terms of this Agreement;
provided, however, that this Agreement may be renewed for successive one (1) year periods if STAAR
and Distributor expressly agree in writing and in their sole discretion to renew this Agreement
prior to the foregoing termination date or any successive renewal term. 4. Prices and Terms 4.1 The
prices which Distributor shall pay to STAAR for the Products shall be as specified on Exhibit A 1.
Such prices are exclusive of any national, state, local or other governmental sales, transfer, use,
excise, value-added or other taxes, customs duties, or similar tariffs and fees, which shall be the
sole responsibility of Distributor. In the event that STAAR is required to pay any such taxes,
duties, tariffs or fees, the full amount thereof shall be added to the applicable invoice and
payable by Distributor. Company may change the prices of the Products from time to time with thirty
(30) days prior written notice to Distributor. 4.2 Payment for the Products shall be in U.S.
Dollars, or such other currency as STAAR may require in its sole discretion, and made within thirty
(30) days of STAAR's invoice. Late payments shall be subject to an interest charge of 1% per month
or the maximum amount permitted by applicable law, whichever is less. 4.3 In the event STAAR
establishes a line of credit for Distributor or permits Distributor to purchase Products on open
account, STAAR retains title to said Products and reserves all rights with respect to such delivered
Products permitted by law, including, without limitation, the rights of recession, repossession,
resale and stoppage in transit until the full amount due from Distributor in respect of such
Products has been paid. 5. STAAR Obligations STAAR shall, during the term of this Agreement: 5.1
Provide Product training, at mutually acceptable times and places, for a reasonable number of
Distributor's personnel; provided that Distributor shall pay all expenses of its personnel attending
such training sessions (including without limitation salaries and transportation); 5.2 Furnish
Distributor, without charge, reasonable quantities of English-language Product literature which
STAAR may publish or prepare from time to time; 5.3 Render reasonable periodic assistance to
Distributor on Product technical and sales issues; and

3

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 4 -->
5.4 Invoice Distributor for each Product sold by Distributor. 6. Distributor Obligations Distributor
shall, during the term of this Agreement, and at its expense: 6.1 Actively use its best efforts to
advertise, promote and penetrate the market for the Products in the Territory; 6.2 Employ adequate
staff having specialized technical training, maintain adequate stocks of Products, and maintain
facilities and other resources within the Territory, at its own expense, in order to maximize the
distribution and sale of the Products; 6.3 Provide STAAR with an annual marketing plan setting forth
Distributor's plan for the marketing, distribution and sale of the Products in the Territory,
including (a) Distributor's goals and objectives for Product promotion, sales, and distribution, (b)
advertising campaigns for trade journals and other publications, (c) customer training and
education, (d) participation at trade shows and exhibits, (e) special promotions and financing and
acquisition programs, such as reagent rental programs, (f) distribution strategies and market
analysis, including a detailed summary of the activities of competitors in the marketplace, and (g)
anticipated capital expenditures, personnel requirements and other resources to be utilized in the
succeeding year; 6.4 Participate in appropriate exhibitions and trade shows as part of its marketing
of the Products in the Territory, it being understood and agreed that STAAR and its affiliates also
shall have the right to participate in exhibitions and trade shows in the Territory; 6.5 Submit to
STAAR regular quarterly status reports reflecting sales activities (detailed by customer name and
units sold per customer per month), anticipated requirements of customers in the Territory, general
market conditions, and a summary of activities by competitors; 6.6 Provide customer training and
warranty services; and 6.7 Refrain from making any claims or representations concerning the Products
other than as set forth in the applicable specifications or labeling therefor and never disparage
either STAAR or the Products. 6.8 In the event that Distributor terminates this Agreement, then for
one year thereafter, Distributor shall not sell, promote, advertise or market in the Territory
products which are competitive with the Products. 7. Forecasts/Purchase Orders/Minimum Product
Quantities 7.1 Distributor shall on a calendar-quarter basis furnish to STAAR a written good-faith,
non-binding estimate of Distributor's Product requirements in the Territory and requested shipping
dates (the "Forecast") for each of the succeeding twelve (12) months. Any purchase orders issued by
Distributor are subject to acceptance by STAAR and will not be deemed accepted until a written
confirmation has been dispatched by STAAR.

4

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 5 -->
7.2 Distributor shall order Products from STAAR under this Agreement by submitting to STAAR a
written purchase order specifying Products, quantities, and requested delivery dates to enable STAAR
to fill the order. Each purchase order submitted to STAAR is subject to acceptance by STAAR at its
offices to which such order was submitted. The purpose of the purchase order to be issued under this
Agreement is for scheduling only; no terms and conditions of Distributor's purchase orders or any
other document or instrument of Distributor shall be binding upon STAAR or amend or modify this
Agreement in any manner, notwithstanding any language to the contrary contained in any such purchase
order, instrument or document. Distributor should place its last order in each quarter by the tenth
day of the last month in each quarter (e.g., March 10, June 10, September 10, and December 10). 7.3
During each Contract Year, as defined below, Distributor shall purchase from STAAR the minimum
quantity of each Product that shall be mutually agreed between the parties in advance of the
applicable Contract Year ("Minimum Product Quantities"). The Minimum Purchase Quantities for the
Contract Year are as set forth on Exhibit B attached hereto. Within ninety (90) days prior to the
expiration of each Contract Year, the parties will discuss in good faith and agree on the Minimum
Product Quantities for the successive Contract Year; provided, however, that, if the parties fail to
reach agreement on or otherwise specify the Minimum Purchase Quantities for the successive Contract
Year, the Minimum Product Quantities for such successive Contract Year shall be __________ percent
(___%) of the Minimum Purchase Quantities for the existing Contract Year. "Contract Year" means for
the first Contract Year of the Agreement, the period commencing on the Effective Date hereof and
ending one year thereafter and for subsequent Contract Years, the successive twelve (12) month
period thereafter. Failure of Distributor to purchase the Minimum Purchase Quantities for any
Contract Year, shall be considered a material breach of this Agreement. 8. Delivery 8.1 Delivery of
all Products ordered by Distributor shall be made Ex Works at STAAR's export manufacturing or other
facility or named shipping point as determined by STAAR. ICC INCOTERMS (2010 edition) shall apply,
except insofar as these INCOTERMS may be inconsistent with the terms of this Agreement. 8.2 In the
event Distributor fails to take delivery and/or shipment of Products pursuant to the terms of this
Agreement: (a) STAAR shall be entitled to store the Products in a warehouse at the expense and risk
of Distributor; (b) the price of the Products shall become immediately due and payable by
Distributor; and (c) after thirty (30) days from the date upon which the price becomes payable,
STAAR may dispose of the Products in a commercially reasonable manner without notice to Distributor
and recover any shortfall and related expenses from Distributor. 8.3 All Products ordered pursuant
to accepted purchase orders shall be scheduled for delivery in accordance with STAAR's then current
and normal delivery times.

5

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 6 -->
9. Warranty and Quality Control 9.1 STAAR warrants that, for the period of twelve (12) months from
the date of delivery to Distributor hereunder (the "Warranty Period"), the Products will meet
STAAR's published specifications or labeling for such Products as in effect at the time of such
delivery ("Warranty"). To the maximum extent permitted by applicable law and except as otherwise
stated in this Agreement: (a) the foregoing Warranty is exclusive; and (b) all other terms,
representations, undertakings, rights, remedies and warranties are excluded, whether express or
implied (including but not limited to any warranties of merchantability, fitness for a particular
purpose or against infringement). To the maximum extent permitted by applicable law, the exclusive
remedy for breach of the Warranty shall be, at STAAR's option, the repair or replacement, at STAAR's
expense, of the non-conforming Product; provided that Distributor notifies STAAR of the
non-conformity and returns the non-conforming Product within the Warranty Period. Products may only
be returned by Distributor when accompanied by a return material authorization number issued by
STAAR. Shipping expenses for Products returned by Distributor will be prepaid by Distributor. STAAR
shall pay for the return or replacement shipment to Distributor of Products repaired or replaced
under the Warranty. For Products returned for repair or replacement that are not covered under
Warranty, STAAR's standard repair charges shall be applicable in addition to all shipping expenses.
The above Warranty is contingent upon proper installation, use and maintenance of the Products and
does not apply to Products which have been misused, mishandled, adulterated, repaired or modified
without STAAR's written approval. To the maximum extent permitted by applicable law, STAAR shall not
be responsible for any incidental or consequential loss, damage, or expense which arises directly or
indirectly from the use of any Product. Without limiting the above, and to the maximum extent
permitted by applicable law, Distributor's sole remedy in contract or in tort (including in
negligence) and STAAR's liability shall be limited to the repair or replacement of any Product which
is returned to and found to be defective or non-conforming by STAAR. 9.2 Distributor shall not make
any representation or warranty as to the Products except for the warranty stated in Section 9.1
above. Distributor shall not alter the Products and shall not recommend or knowingly sell the
Products for any uses except as described in STAAR's Product label and labeling and in accordance
with the written instructions and warnings furnished by STAAR. Distributor agrees to deliver to its
customers at or before sale all specifications, inserts, instructions, and warnings furnished by
STAAR and to retain records evidencing such delivery. 10. Regulatory and Post-Market Surveillance
Requirements 10.1 During the term of this Agreement and for at least ten (10) years thereafter,
Distributor shall maintain records to allow for traceability of individual serial/lot numbers to
customers for all sales of the Products. Upon request by STAAR, Distributor shall supply STAAR with
a report of the information contained in such records. 10.2 In the event that STAAR deems it
necessary to recall any Product, or any governmental authority requests recall of any Product
distributed or sold by Distributor in the Territory, Distributor and STAAR shall cooperate fully
with each other in effecting such recall, with an effort to reduce as much as possible the expense
thereof and Distributor must notify STAAR of any contemplated or requested recalls as soon as
possible (and at all times within any period required to notify any regulatory authority under
applicable law) and prior to Distributor taking any steps to effect such a recall. Without limiting
Distributor's obligations under law, as between Distributor and STAAR, the decision of whether or
not to recall any Product shall be made solely by STAAR. Distributor shall notify all customers who
received the recalled Product and shall record all receipts of Product returned under any recall.
Distributor shall maintain copies of recall notification letters and maintain distribution logs that
detail where each Product was shipped by Distributor.

6

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 7 -->
10.3 Distributor shall fully document and inform STAAR in writing of any Complaints or other matters
addressed in this Section 10. Documentation with respect to Complaints shall include the Product
model and serial or lot number, customer contact information, and as much detail as possible
regarding the nature of the Complaint. Distributor will forward to STAAR any Complaint involving
significant bodily injury, illness or death resulting from use of Products within one (1) calendar
day of receipt and Distributor must notify STAAR of any such incident prior to issuing any notice
required by law in respect of such incident (including those to be issued to governmental or
regulatory authorities). Distributor shall forward to STAAR all other Complaints within five (5)
calendar days of receipt. If any evaluation of Product involved in a Complaint by STAAR is necessary
or appropriate, Distributor will use best efforts to retrieve the affected Product, if available,
and return it to STAAR. STAAR will pay for the return shipment of such Product to STAAR. STAAR will
be responsible for investigating all Complaints, determining if reporting to regulatory authorities
in the Territory is required, and submitting such reports to regulatory authorities when required.
The term "Complaints" as used in this Section 10.3 means any report, complaint or other
communication received by Distributor (or its employees, contractors, agents or representatives)
from end users of Products or their healthcare providers related to the safety or efficacy of the
Products. 10.4 STAAR informs Distributor that Sections 10.1, 10.2, and 10.3 above are requirements
of the Medical Device Directive (93/42/EEC), and that non-compliance by Distributor of these
Sections will constitute grounds for STAAR to immediately cease supply of Products to Distributor
and will be deemed a failure by Distributor to perform a material obligation, warranty, duty or
responsibility hereunder. 10.5 Distributor acknowledges and agrees that it has full understanding of
and shall duly observe and abide by any and all legal and regulatory requirements applicable to the
import, commercialization, marketing, distribution or sale of Products in the Territory
(collectively, "Regulatory Requirements"). Distributor further acknowledges and agrees that STAAR
does not take any, and shall not be responsible for, any legal liability or responsibility for
damages, costs or legal consequences that may result from any failure by Distributor to observe or
comply with any Regulatory Requirements. 10.6 Distributor shall observe all transport and storage
requirements and conditions applicable to the Products as indicated on any Product packaging. 11.
Governmental Approvals and Registrations 11.1 With the exception of the health registrations for the
Products provided for in Section 11.2 below, Distributor shall secure (and provide copies thereof to
STAAR) all necessary governmental permits, licenses, sponsorships and registrations required in
connection with the importation and resale of the Products in the Territory. Upon expiration or
termination of this Agreement, Distributor shall transfer to STAAR (or its nominee) all right and
title to all sponsorships or import licenses or permits governing the importation and resale of the
Products into the Territory.

7

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 8 -->
11.2 STAAR shall provide to Distributor all necessary information and data to obtain appropriate
health registrations and applications in the Territory. Distributor shall use its best efforts to
obtain all necessary registrations, which registrations shall be obtained in the name of STAAR.
Distributor agrees that it will have no right or interest in said registrations and applications;
that STAAR is and shall remain the exclusive owner of such registrations and applications free and
clear of any claims by Distributor; and that Distributor shall make no claim to the same at any time
during or after the term of this Agreement. Distributor shall respect such property rights of STAAR
and comply with all local laws and regulations in respect thereof. Distributor shall also assist
STAAR, at STAAR's request, in taking any steps necessary to defend such rights, and any reasonable
expenses incurred in this regard by Distributor shall be reimbursed by STAAR. 11.3 Distributor shall
at all times keep STAAR apprised of all Regulatory Requirements and any changes thereto and, on an
annual basis, shall report to STAAR in writing of any such changes and confirm in such report that
there have been no changes in any Regulatory Requirements other than as specified in the annual
report. 11.4 Copies of all permits, licenses, sponsorships and registrations referred in Sections
11.1 and 11.2 shall be promptly forwarded to STAAR. 12. STAAR's Proprietary Information and Rights
12.1 Distributor recognizes and understands that all information not generally known concerning
Company and the Products, including but not limited to Company's organization and business affairs,
customer lists, sales information, operating procedures and practices, technical data, designs,
software, know-how, trade secrets, and processes (the "Proprietary information"), whether owned by
Company or licensed by Company from third parties, are subject to a valuable proprietary interest of
Company, and that Distributor is under an obligation to maintain the confidentiality of such
Proprietary Information. Without limiting the generality of the foregoing obligations, Distributor
agrees that for the term of this Agreement and thereafter until such time as the Proprietary
information is in the public domain, Distributor will (i) not disclose, publish or disseminate any
Proprietary Information, (ii) not use any Proprietary Information for its own account, (iii) not
authorize any other person to disclose, publish or disseminate the Proprietary information, and (iv)
treat all Proprietary Information in a confidential manner, including appropriate marking and secure
storage of written Proprietary Information. 12.2 No title or ownership of the software bundled or
included with any Product ("Software") is transferred to Distributor, and such Software remains the
proprietary property of Company. The Software is protected by the U.S. Copyright. Act and by
international copyright treaties. All Software, including documentation and any subsequent updates
provided by Company to Distributor, is licensed only for use on the single Product on which the
Software is first installed. Unauthorized copying of the Software is expressly forbidden, and
Distributor agrees not to distribute copies of the Software to nonlicensed parties. In no event
shall Distributor reverse engineer, decompile, or disassemble the Software.

8

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 9 -->
12.3 Distributor acknowledges that the Company is the owner and/or licensee in the Territory of the
trademark(s) indicated on the Product packaging, advertising or promotional material or utilized in
the sale of the Products (the "Trademarks"). During the term of this Agreement, Distributor is
authorized to use the Trademarks solely in connection with Distributor's advertisement, promotion
and distribution of the Products in the Territory. Whenever the Trademark is used, e.g., on any
package, label or advertisement, the right or most prominent use shall always be accompanied by a
legend acceptable to Company indicating that the Trademark is licensed to the Distributor by
Company. 12.4 Distributor shall neither use nor permit others to use the name "STAAR", or any
abbreviation or modification thereof, or the Trademarks or any other trademark or trade name of
Company as part of the Distributor's firm name or corporate titles, in signs or in letterheads
without the prior written consent of Company. Distributor may designate itself as a Distributor of
Products in the Territory in such form and manner as Company may approve of in advance in writing.
Distributor shall not grant this privilege to any third party or to any affiliates without Company's
prior written consent. 12.5 Distributor acknowledges that Company owns and retains all patents,
trademarks, copyrights and other proprietary rights in the Products, and agrees that it will not at
any time during or after the termination of this Agreement assert or claim any interest in or take
any action which may adversely affect the validity or enforceability of any trademark, trade name,
trade secret, copyright, or other proprietary right owned by or licensed to Company. No license,
either express or implied, is granted to the Distributor by this Agreement to any patents,
trademarks, copyrights, processes, or other proprietary rights of Company or its affiliates, except
the right to sell the Products sold to the Distributor hereunder in the Territory, and the license
to use the Software and Trademarks in connection therewith. 12.6 Distributor acknowledges that any
breach of the provisions of this Section shall result in serious and irreparable injury to STAAR for
which STAAR cannot be adequately compensated by monetary damages alone. Thus, Distributor agrees
that, in addition to any other remedy it may have, STAAR shall be entitled to enforce the specific
performance of the obligations of Distributor under this Section and to seek both temporary and
permanent injunctive relief (to the extent permitted by law) without the necessity of proving actual
damages. Distributor shall be responsible for any breach of the provisions for this Section by any
employee, agent or representative of Distributor. 13. Indemnification; Infringement; Insurance; and
Limitation of Liability 13.1 Distributor shall indemnify, defend with competent and experienced
counsel and hold harmless STAAR, and its officers, directors, employees, affiliates and agents
(each, a "Indemnities"), from and against any and all claims, demands, suits or actions (including
without limitation attorneys' fees and disbursements) which may be asserted against STAAR for any
kind of damages, including without limitation damage or injury to property or persons and incidental
and consequential damages, by any third party or any of the Indemnities arising out of, in
connection with or resulting from (a) any breach of any representation or performance obligation of
Distributor hereunder, or (b) any act or omission of Distributor, its employees, agents or
representatives.

9

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 10 -->
13.2 Distributor shall, at its own expense, maintain at a minimum general and product liability
coverage in the Territory of at least US$2 million per occurrence, US$5 million in the aggregate. On
a separate endorsement, Distributor shall name STAAR as an additional named insured. Such separate
endorsement shall indicate that Distributor's insurance is primary and that STAAR's coverage as an
additional named insured is not contributory. Each such insurance policy and endorsement shall
provide that the insurance will not be canceled or reduces without at least thirty (30) days' prior
written notice to STAAR. On request, Distributor shall provide STAAR with copies or certificates of
all such insurance policies. 13.3 EXCEPT FOR EACH PARTY'S CONFIDENTIALITY OBLIGATIONS SET FORTH IN
SECTION 12 AND INDEMNIFICATION OBLIGATIONS SET FORTH IN THIS SECTION 13, WITHOUT LIMITING ANY RIGHT
DISTRIBUTOR MAY HAVE UNDER LOCAL STATUTES THAT CANNOT BE EXCLUDED, RESTRICTED OR MODIFIED, NEITHER
PARTY SHALL BE LIABLE FOR ANY INDIRECT, INCIDENTAL, CONSEQUENTIAL, PUNITIVE OR SPECIAL DAMAGES, OR
FOR DAMAGES DUE TO LOSS OF PROFITS, LOSS OF BUSINESS, LOSS OF USE OR DATA, OR INTERRUPTION OF
BUSINESS, EVEN IF SUCH PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 14. Termination
14.1 STAAR or Distributor shall have the right, at its option, to terminate this Agreement, by
giving written notice to the other party, effective immediately on receipt of such notice, on the
occurrence of any of the following events: (a) In the event that the other party becomes or is
deemed insolvent; proceedings are instituted by or against it in bankruptcy, insolvency,
reorganization or dissolution; or it makes a general assignment for the benefit of creditors; (b) In
the event that the other party fails to observe or perform any obligation, warranty, duty or
responsibility under this Agreement and such failure continues unremedied for a period of thirty
(30) days following written notice thereof by the non breaching party; or 14.2 STAAR shall have the
right to terminate this Agreement by giving written notice to Distributor, effective immediately on
receipt of such notice, (a) if Distributor fails to meet the Annual Minimum Volume as set forth in
Section 7.2 or (b) pursuant to Section 15, or in the event the parties are unable to agree upon
changes in the prices for Products within thirty (30) days following STAAR's notice thereof. 14.3
Notwithstanding the provisions of Section 3 above, either party shall have the right to terminate
this Agreement, without cause, upon no less than ninety (90) days' prior written notice to the other
party.

10

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 11 -->
14.4 Upon any termination or expiration of this Agreement: (a) All sums due to either party from the
other shall be promptly paid; (b) Distributor orders received and accepted by STAAR prior to the
effective date of the termination of this Agreement shall be fulfilled in accordance with their
terms; (c) All property belonging to one party but in the custody of the other shall be returned;
(d) STAAR shall have the option to repurchase any or all current and resalable Products in
Distributor's inventory at eighty percent (80%) of Distributor's original net purchase price
(reflecting a twenty percent (20%) restocking and administrative fee); (e) Distributor shall cease
all display, advertising and use of STAAR trade names, trademarks (including the Trademarks), logos
and designations, except uses on the Products which remain in Distributor's possession, and shall
transfer all registrations and sponsorships for the Products to STAAR or its designee; and (f) The
parties have considered the possibility that one or both parties will incur expenses in preparing
for performance of this Agreement and that one or both parties will incur expenses and suffer losses
as a result of termination, and the parties have nevertheless agreed that the terminating party
shall not incur any liability whatsoever for any damage, loss or expense of any kind suffered or
incurred by the other party (or for any compensation to the other party) arising from or incident to
any termination or non-renewal of this Agreement by the terminating party pursuant to its terms,
whether or not the terminating party is aware of any such damage, loss or expense. Without limiting
the generality of the foregoing, upon any termination of this Agreement by either Party in
accordance with its terms (or otherwise), in no event shall STAAR be required to pay to Distributor
any "good will" or other payment of any nature or kind based on the sales, business development or
other activities of Distributor during the term of this Agreement. Distributor, for itself and on
behalf of each of its employees, hereby waives any rights which may be granted to it or them under
the laws and regulations of the Territory or otherwise which are not granted to it or them by this
Agreement. Termination is not the sole remedy under this Agreement, and, whether or not termination
is effected, all other remedies shall remain available. 15. U.S. Laws and Regulations 15.1
Distributor acknowledges and agrees that it shall comply in all respects with all United States and
local country laws, regulations and standards applicable to its activities under this Agreement,
including but not limited to the exporting and importing requirements (including the prohibition of
the re-export of Products and associated technical data) set forth in this Agreement and in
applicable governmental regulations.

11

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 12 -->
15.2 Distributor warrants and represents that neither Distributor nor any person acting on
Distributor's behalf shall make, directly or indirectly, any offer or promise or authorization of a
bribe, kickback, payoff or any other payment or gift intended to improperly influence an agent,
government official, political party or candidate for public office to exercise their discretionary
authority or influence in order to assist in the sale, marketing, promotion, importation, licensing
or distribution of the Products and shall complete and sign the attached Foreign Corrupt Practices
Certification (Exhibit C). Specifically, Distributor shall not (a) violate any applicable
anti-bribery or anti-corruption laws; or (b) offer, pay or promise to pay, give or promise to give,
or authorize the payment or giving of, anything of value to any official representative of any
Governmental Entity or authority or any political party or officer thereof or any candidate for
office in any jurisdiction (individually and collectively, a "Government Official"), (i) for the
purpose of (A) influencing any act or decision of such Government Official in his official capacity,
(B) inducing such Government Official to do or omit to do any act in violation of his lawful duty,
(C) securing any improper advantage, or (iv) inducing such Government Official to influence or
affect any act or decision of any Government Entity, or (ii) in order to assist Distributor in
obtaining or retaining business for or with, or directing business to Distributor or any of its
affiliates. The term "Governmental Entity" as used in this Section 15.2 means any government or any
department, agency or instrumentality thereof, including any entity or enterprise owned or
controlled by a government, or a public international organization. Distributor shall maintain for
at least two (2) years and make readily available to STAAR or its duly authorized representatives'
books, records and accounts prepared in accordance with generally accepted accounting principles
that accurately and completely reflect the nature of every transaction related to the sale of the
Products. 16. Data Protection 16.1 For the purposes of this Section, the following terms shall have
the following meanings: "Data Protection Laws" means any applicable data protection or privacy laws.
It shall include: (a) the EU Data Protection Directive 95/46/EC and EU ePrivacy Directive 2002/58/EC
as implemented by countries within the European Economic Area ("EEA"); (b) from 25 May 2018, the EU
General Data Protection Regulation ("GDPR") as implemented by countries within the EEA and the UK;
and/or (c) other laws that are similar, equivalent to, successors to, or that are intended to or
implement the laws that are identified in (a) and (b) above; "Shared Personal Data" shall have the
meaning as set out in Section 16.4; and The terms "data controller", "data subject", "personal
data", "processing", and "sensitive personal data" shall have the same meanings ascribed to them
under Data Protection Laws. 16.2 STAAR and Distributor each acknowledge and agree that where a party
processes personal data under or in connection with this Agreement it alone determines the purposes
and means of such processing as a data controller. 16.3 Each Party confirms that it has complied,
and will continue to comply, with its obligations relating to personal data that apply to it under
applicable Data Protection Laws. 16.4 To the extent Distributor discloses, provides or otherwise
makes available, personal data to STAAR under or in connection with the Agreement ("Shared Personal
Data"), Distributor acknowledges that STAAR and/or its service providers or agents may process such
Shared Personal Data for any purpose related to this Agreement, including, without limitation, for
any purpose necessary for STAAR and/or its service providers or agents to comply with applicable
law.

12

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 13 -->
16.5 In connection with the Shared Personal Data, Distributor warrants that it: (a) has provided
adequate notices to, and obtained valid consents from, the relevant individuals, in each case, to
the extent necessary for STAAR and/or its service providers or agents to process the Shared Personal
Data (including any sensitive personal data) in connection with this Agreement which may include the
transfer of the Shared Personal Data to STAAR outside of the EEA; and (b) shall not, by act or
omission, cause STAAR to violate any Data Protection Laws, notices provided to, or consents obtained
from, data subjects as result of processing the Shared Personal Data in connection with this
Agreement. 16.6 To the extent of any conflict in relation to personal data between the terms
contained in this Section and the rest of the Agreement, then the terms of this Section shall
control to the extent of such conflict. 17. Survival In addition to Distributor's obligation to pay
STAAR all amounts due hereunder, the provisions under Sections 9, 10, 11, 12, 13, 14, 15, 16, 17,
18, 19, 24 and 25 shall survive termination of the Agreement, as well as such other provisions which
by their meaning and intent have applicability beyond the terms of this Agreement. 18. Publicity
Distributor agrees that any publicity or advertising which shall be released by it in which STAAR is
identified in connection with the Products shall be in accordance with the terms of this Agreement
and with any information or data which STAAR has furnished in connections with this Agreement (or
related to the Product). STAAR shall have the right to review and approve all such publicity and
advertising prior to dissemination thereof. 19. Assignment Neither party may, directly or indirectly
(including in connection with a change of control transaction), transfer or assign this Agreement or
any of the rights or obligations hereunder without the prior written consent of the other; provided
that STAAR may assign any of its rights and delegate any of its obligations hereunder to its
subsidiaries and affiliated companies or in connection with a sale or transfer of all or
substantially all of its business to which this Agreement relates, whether by merger, sale of assets
or otherwise, without Distributor's prior written consent. This Agreement shall be binding upon and
shall inure to the benefit of the parties hereto and their respective successors and permitted
assigns. 20. Integrated Agreement This Agreement constitutes the entire understanding and agreement
between STAAR and Distributor regarding the subject matter hereof and terminates and supersedes all
prior formal or informal understandings or agreements relating thereto.

13

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 14 -->
21. Force Majeure Performance of the parties hereto of their respective obligations hereunder shall
be subject to force majeure and acts of God, including but not limited to insurrections, riots, wars
and war-like operations, terrorist acts, explosions, governmental acts, epidemics, failure of
contractors to perform, strikes, fires, accidents, acts of any public enemy, inability to obtain
required materials, supplies, products or qualified labor, delay in transportation and any
applicable law, regulation or restriction of any foreign, federal, state or local governmental
entity or instrumentality. However, the parties hereto shall use their commercially reasonable
efforts to avoid, remove or cure said circumstances. Any party temporarily excused for performances
hereunder by any such circumstance shall resume performance with utmost dispatch when such
circumstances are removed or cured. Any party claiming such circumstances as an excuse for delay in
performance shall give prompt notice in writing thereof to the other party. Nothing herein and no
contrary provisions of any law, regulation, or governmental pronouncement shall, however, relieve
Distributor of its obligation to make the payments to STAAR required hereunder at the times and in
the manner herein specified. 22. No Waiver No waiver by either party of any breach or default of any
of the covenants or agreements herein contained shall be deemed a waiver as to any subsequent or
similar breach or default. No right or remedy herein conferred upon either party is exclusive of any
other right or remedy herein or by law or in equity provided or permitted. 23. Severability This
Agreement is divisible, and provisions herein held to be violate of any applicable treaties,
statutes or regulations of any governmental agency having jurisdiction shall effect only that
portion held to be invalid or inoperative, and the remaining portions of this Agreement shall remain
in full force and effect. 24. Notice Any notice required or permitted to be given hereunder shall be
in writing and (a) delivered in person or by internationally-recognized express delivery or courier
service (e.g., FedEx, DHL or UPS), (b) sent by facsimile, or (c) deposited in the mail registered or
certified first class, postage prepaid and return receipt requested (provided that any notice given
pursuant to clause (b) is also confirmed by the means described in clause (a) or (c)), to the
address or facsimile number of the party appearing below its signature below or to such other
address as such party from time to time may designate in writing in compliance with the terms
hereof. Each notice shall be deemed given when so delivered personally, or sent by facsimile
transmission, or, if sent by express delivery or courier service four (4) business days after being
sent, or if mailed, ten (10) days after date of deposit in the mail. 25. Governing Law and Dispute
Resolution 25.1 This Agreement, which is in English, shall be governed by and construed in
accordance with the laws of the State of California without regard to the conflicts of laws
principles thereof. The parties hereby expressly disclaim and exclude any applicable provisions of
the United Nations Convention for the International Sales of Goods.

14

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 15 -->
25.2 The parties waive their rights to seek remedies in court (except where the relief sought is an
injunction or other equitable relief), including any right to a jury trial. Except in a case where
the relief sought is an injunction or other equitable relief, the parties agree that any dispute
between the parties arising out of, relating to or in connection with this Agreement, whether
characterized or sounding in contract or tort or otherwise, shall be resolved exclusively through
binding arbitration conducted in accordance with the Rules of Conciliation and Arbitration of the
International Chamber of Commerce by one or more arbitrators appointed in accordance with the said
Rules. The arbitration shall be held in Los Angeles, California, USA. Judgment upon the award
rendered may be entered in any court having jurisdiction. Each party shall bear its own expenses of
the arbitration, but the arbitration fees and costs shall be borne equally between the parties
participating in the arbitration. Disputes shall not be resolved in any other forum or venue. 26.
Counterparts This Agreement may be executed in duplicate counterparts, each of which shall be deemed
to be an original and all of which counterparts shall together constitute one and the same
instrument. IN WITNESS WHEREOF, STAAR and Distributor have caused their duly authorized
representatives to execute this Distributorship Agreement on this __ day of ____, 20___. STAAR
SURGICAL AG DISTRIBUTOR By: By: Name: Name: Title: Title:

15

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 16 -->
EXHIBIT A-1

List of Products and Prices

All prices in U.S. dollars, or such other currency as STAAR determines in its sole discretion.

A-1-1

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 17 -->
EXHIBIT B Minimum Product Quantities

B-1

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
<!-- page 18 -->
EXHIBIT C Foreign Corrupt Practices Certification I, _________, as the [__________] of ___________
hereby certify as follows: 1. I understand and will comply with the anti-bribery provisions of the
U.S Foreign Corrupt Practices Act and the UK Bribery Act. Neither I, nor any person employed by me
or my business or representing my business, has or will make, offer, promise or authorize, directly
or indirectly, any payment or transfer of anything of value to any official, representative or
employee of any government, government agency or instrumentality, for the purpose of influencing a
decision by any of them to take actions favorable to STAAR Surgical Company or its subsidiaries
("STAAR") or represent them on any matter related directly or indirectly to the purchase of any of
STAAR's products. 2. No officer, director, partner, owner, principle, employee or agent of my
business is an official or employee of a governmental agency or instrumentality in a position to
influence action or decisions regarding me or my business activities on behalf of STAAR and I will
inform STAAR, by written notice, if, and as soon as , any such person assumes such a position as
official or employee of a governmental agency or instrumentality while at the same time remaining an
officer, director, partner, owner, principle, employee or agent of mine or my business at which time
STAAR may elect to terminate this contract without any further liability to me or my business. 3. I
will indemnify an hold harmless STAAR from any and all fines, damages, losses, costs and expenses
(including without limitation reasonable attorneys' fees) incurred by STAAR as a result of any
breach of this Certification by me. 4. I understand and agree that failure to comply with the terms
of this Certification will entitle STAAR to terminate any and all if its contractual relationships
with me and my business. DISTRIBUTOR: By: Officer Title: Print Name: Date:

C-1

Source: STAAR SURGICAL CO, 10-Q, 8/1/2018
