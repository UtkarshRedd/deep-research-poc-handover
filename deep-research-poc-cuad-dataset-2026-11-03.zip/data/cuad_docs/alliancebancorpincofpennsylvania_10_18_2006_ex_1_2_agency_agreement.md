<!-- page 1 -->
# AGENCY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Agency Agreement |
| SEC Filing Date | 2006-10-18 |
| Parties | (Greater Delaware Valley Holdings (“PA MHC”); Alliance Mutual Holding Company (“Federal MHC”); Alliance Bancorp, Inc. of Pennsylvania (“Company"); Greater Delaware Valley Savings Bank d/b/a Alliance Bank (“Bank”); Sandler O’Neill & Partners, L.P. (“Sandler O’Neill” or “Agent”)) |
| Source | CUAD v1 / ALLIANCEBANCORPINCOFPENNSYLVANIA_10_18_2006-EX-1.2-AGENCY AGREEMENT |

Exhibit 1.2

Up to 2,445,223 Shares

(subject to increase to up to 2,812,006 shares in the event of an increase in the pro forma market
value of the Company's Common Stock)

Alliance Bancorp, Inc. of Pennsylvania (a federal stock holding company)

Common Stock (par value $.01 per share)

AGENCY AGREEMENT

November ___, 2006

SANDLER O'NEILL & PARTNERS, L.P. 919 Third Avenue, 6 Floor New York, New York 10022

Ladies and Gentlemen:

Greater Delaware Valley Holdings, A Mutual Company, a Pennsylvania-chartered mutual holding company
(the "PA MHC"), Alliance Mutual Holding Company, a federal mutual savings and loan holding company
in formation (the "Federal MHC"), Alliance Bancorp, Inc. of Pennsylvania, a federal stock holding
company in formation (the "Company"), and Greater Delaware Valley Savings Bank d/b/a Alliance Bank,
a Pennsylvania-chartered stock savings bank (the "Bank"), hereby confirm their agreement with
Sandler O'Neill & Partners, L.P. ("Sandler O'Neill" or the "Agent") with respect to the offer and
sale by the Company of up to 2,445,223 shares (subject to increase to up to 2,812,006 shares in the
event of an increase in the pro forma market value of the Company's common stock) of the Company's
common stock, par value $.01 per share (the "Common Stock"). The shares of Common Stock to be sold
by the Company in the Offerings (as defined below) are hereinafter called the "Securities."

The PA MHC and the Bank have determined to undertake a reorganization pursuant to which the Company
will be created as a mid-tier holding company, the outstanding capital stock of the Bank will be
exchanged for shares of the Common Stock, and the PA MHC will convert from a Pennsylvania-chartered
mutual holding company to a federally-chartered mutual holding company under the name Alliance
Mutual Holding Company, all in accordance with the Agreement and Plan

1

th
<!-- page 2 -->
of Reorganization, dated as of June 21, 2006, as may be amended from time to time pursuant to the
terms thereof. Concurrently therewith, the Securities are being offered for sale in the Offerings
(as defined below) in accordance with the Plan of Additional Stock Issuance dated June 21, 2006 as
may be amended from time to time pursuant to the terms thereof. The Agreement and Plan of
Reorganization and the Plan of Additional Stock Issuance are hereinafter referred to collectively as
the "Plans." The PA MHC and Federal MHC are hereinafter referred to collectively as the "MHCs."

Pursuant to the Plans, the Company will offer to certain depositors of the Bank and to the Bank's
tax qualified employee benefit plans, including the Bank's employee stock ownership plan (the
"ESOP") (collectively, the "Employee Plans"), rights to subscribe for the Securities in a
subscription offering (the "Subscription Offering"). To the extent Securities are not subscribed for
in the Subscription Offering, such Securities may be offered to certain members of the general
public and to other persons in a community offering (the "Community Offering"), with preference
given first to natural persons and trusts of natural persons residing in Delaware and Chester
Counties, Pennsylvania and then to the Bank's stockholders as of ___________, 2006. The Community
Offering, which together with the Subscription Offering, as each may be extended or reopened from
time to time, is herein referred to as the "Subscription and Community Offering," may be commenced
concurrently with, during or after, the Subscription Offering. It is currently anticipated that any
Securities not subscribed for in the Subscription and Community Offering will be offered, subject to
Section 2 hereof, in a syndicated community offering (the "Syndicated Community Offering"). The
Subscription and Community Offering and the Syndicated Community Offering are hereinafter referred
to collectively as the "Offerings." The conversion of the PA MHC from a state-chartered mutual
holding company to a federally-chartered mutual holding company, the formation of the Company, the
exchange of the capital stock of the Bank for capital stock of the Company and the Offerings are
hereinafter referred to collectively as the "Reorganization and Additional Stock Issuance." As a
result of the Reorganization and Additional Stock Issuance, the Bank, which is currently 80.02%
owned by the PA MHC, will become a wholly-owned subsidiary of the Company and the Company will be
55% owned by the Federal MHC. The Securities may be offered to the general public in a public
offering (the "Public Offering") in lieu of or subsequent to the Syndicated Community Offering. If
there is a Public Offering, the Public Offering will be governed by a separate definitive purchase
agreement as described in Section 2 hereof. It is acknowledged that the number of Securities to be
sold in the Offerings may be increased or decreased in accordance with the Plans. If the number of
Securities is increased or decreased, the term "Securities" shall mean such greater or lesser
number, where applicable. In the event that a mid-tier holding company form of organization is not
utilized, all pertinent terms of this Agreement will apply to the sale of the Bank's common stock.

The Company has filed with the Securities and Exchange Commission (the "Commission") a registration
statement on Form S-1 (No. 333- 136853), including a related prospectus, for the registration of the
Securities under the Securities Act of 1933, as amended (the "Securities Act"), has filed such
amendments thereto, if any, and such amended prospectuses as may have been required to the date
hereof by the Commission in order to declare such registration statement effective, and will file
such additional amendments thereto and such amended prospectuses and prospectus supplements as may
hereafter be required. Such registration statement (as amended to date, if applicable, and as from
time to time amended or supplemented hereafter) and the prospectuses constituting a part thereof
(including in each case all documents incorporated or deemed to be incorporated by reference

2
<!-- page 3 -->
therein and the information, if any, deemed to be a part thereof pursuant to the rules and
regulations of the Commission under the Securities Act, as from time to time amended or supplemented
pursuant to the Securities Act or otherwise (the "Securities Act Regulations")), are hereinafter
referred to as the "Registration Statement" and the "Prospectus," respectively, except that if any
revised prospectus shall be used by the Company in connection with the Subscription and Community
Offering or the Syndicated Community Offering which differs from the Prospectus on file at the
Commission at the time the Registration Statement becomes effective (whether or not such revised
prospectus is required to be filed by the Company pursuant to Rule 424(b) of the Securities Act
Regulations), the term "Prospectus" shall refer to such revised prospectus from and after the time
it is first provided to the Agent for such use.

Concurrently with the execution of this Agreement, the Company is delivering to the Agent copies of
the Prospectus of the Company to be used in the Offerings. Such Prospectus contains information with
respect to the Bank, the Company, the MHCs and the Common Stock.

SECTION 1. REPRESENTATIONS AND WARRANTIES.

(a) The Company, the Bank and the MHCs jointly and severally represent and warrant to the Agent as
of the date hereof as follows:

(i) The Registration Statement has been declared effective by the Commission, no stop order has been
issued with respect thereto and no proceedings therefor have been initiated or, to the knowledge of
the Company, the MHCs and the Bank, threatened by the Commission. At the time the Registration
Statement became effective and at the Closing Time referred to in Section 2 hereof, the Registration
Statement complied and will comply in all material respects with the requirements of the Securities
Act and the Securities Act Regulations and did not and will not contain an untrue statement of a
material fact or omit to state a material fact required to be stated therein or necessary to make
the statements therein not misleading. The Prospectus, at the date hereof does not and at the
Closing Time referred to in Section 2 hereof will not, include an untrue statement of a material
fact or omit to state a material fact necessary in order to make the statements therein, in the
light of the circumstances under which they were made, not misleading, provided, however, that the
representations and warranties in this subsection shall not apply to statements in or omissions from
the Registration Statement or Prospectus made in reliance upon and in conformity with information
with respect to the Agent furnished to the Company in writing by the Agent expressly for use in the
Registration Statement or Prospectus (the "Agent Information," which the Company, the MHCs and the
Bank acknowledge appears only in the sixth paragraph of the section "The Offering - Plan of
Distribution and Marketing Arrangements" of the Prospectus.)

(ii) At the time of filing the Registration Statement relating to the offering of the Securities and
at the date hereof, the Company was not, and is not, an ineligible issuer, as defined in Rule 405 of
the Securities Act Regulations. At the time of the filing of the Registration Statement and at the
time of the use of any issuer free writing prospectus, as defined in Rule 433(h) of the Securities
Act Regulations, the Company met the conditions required by Rules 164 and 433 of the Securities Act
Regulations for the use of a free writing prospectus. If required to be filed, the Company has filed
any issuer free writing

3
<!-- page 4 -->
prospectus related to the offered Securities at the time it is required to be filed under Rule 433
of the Securities Act Regulations and, if not required to be filed, will retain such free writing
prospectus in the Company's records pursuant to Rule 433(g) of the Securities Act Regulations and if
any issuer free writing prospectus is used after the date hereof in connection with the offering of
the Securities the Company will file or retain such free writing prospectus as required by Rule 433
of the Securities Act Regulations.

(iii) As of the Applicable Time, neither (i) the Issuer-Represented General Free Writing
Prospectus(es) issued at or prior to the Applicable Time and the Statutory Prospectus, all
considered together (collectively, the "General Disclosure Package"), nor (ii) any individual
Issuer-Represented Limited-Use Free Writing Prospectus, when considered together with the General
Disclosure Package, included any untrue statement of a material fact or omitted to state any
material fact necessary in order to make the statements therein, in the light of the circumstances
under which they were made, not misleading. The preceding sentence does not apply to statements in
or omissions from any Prospectus included in the Registration Statement relating to the offered
Securities or any Issuer-Represented Free Writing Prospectus based upon and in conformity with
written information furnished to the Company by the Agent specifically for use therein. As used in
this paragraph and elsewhere in this Agreement:

1. "Applicable Time" means each and every date when a potential purchaser submitted a subscription
or otherwise committed to purchase Securities.

2. "Statutory Prospectus", as of any time, means the Prospectus relating to the offered Securities
that is included in the Registration Statement relating to the offered Securities immediately prior
to that time, including any document incorporated by reference therein.

3. "Issuer-Represented Free Writing Prospectus" means any "issuer free writing prospectus," as
defined in Rule 433(h) of the Securities Act Regulations, relating to the offered Securities. The
term does not include any writing exempted from the definition of prospectus pursuant to clause (a)
of Section 2(a)(10) of the 1933 Act, without regard to Rule 172 or Rule 173 of the Securities Act
Regulations.

4. "Issuer-Represented General Free Writing Prospectus" means any Issuer-Represented Free Writing
Prospectus that is intended for general distribution to prospective investors.

5. "Issuer-Represented Limited-Use Free Writing Prospectus" means any Issuer-Represented Free
Writing Prospectus that is not an Issuer-Represented General Free Writing Prospectus. The term
Issuer-Represented Limited- Use Free Writing Prospectus also includes any "bona

4
<!-- page 5 -->
fide electronic road show," as defined in Rule 433 of the Securities Act Regulations, that is made
available without restriction pursuant to Rule 433(d)(8)(ii) of the Securities Act Regulations or
otherwise, even though not required to be filed with the Commission.

(iv) Each Issuer-Represented Free Writing Prospectus, as of its date of first use and at all
subsequent times through the completion of the Offerings and sale of the offered Securities or until
any earlier date that the Company notified or notifies the Agent (as described in the next
sentence), did not, does not and will not include any information that conflicted, conflicts or will
conflict with the information contained in the Registration Statement relating to the offered
Securities, including any document incorporated by reference therein that has not been superseded or
modified. If at any time following the date of first use of an Issuer-Represented Free Writing
Prospectus there occurred or occurs an event or development as a result of which such
Issuer-Represented Free Writing Prospectus conflicted or would conflict with the information
contained in the Registration Statement relating to the offered Securities or included or would
include an untrue statement of a material fact or omitted or would omit to state a material fact
necessary in order to make the statements therein, in the light of the circumstances prevailing at
that subsequent time, not misleading, the Company has notified or will notify promptly the Agent so
that any use of such Issuer-Represented Free-Writing Prospectus may cease until it is amended or
supplemented and the Company has promptly amended or will promptly amend or supplement such
Issuer-Represented Free Writing Prospectus to eliminate or correct such conflict, untrue statement
or omission. The foregoing two sentences do not apply to statements in or omissions from any
Issuer-Represented Free Writing Prospectus based upon and in conformity with written information
furnished to the Company by the Agent specifically for use therein.

(v) The MHCs and the Company have filed with the Office of Thrift Supervision (the "OTS") an
application for approval of their acquisition of the Bank (the "Holding Company Application") on
Form H-(e)1 promulgated under the savings and loan holding company provisions of the Home Owners'
Loan Act, as amended ("HOLA") and the regulations promulgated thereunder. The Holding Company
Application includes a proxy statement for the special meeting of stockholders of the Bank called to
approve the Agreement and Plan of Reorganization (the "Proxy Statement"). The MHCs and the Company
have received written notice from the OTS of its approval of the Holding Company Application, such
approval remains in full force and effect and no order has been issued by the OTS suspending or
revoking such approval and no proceedings therefor have been initiated or threatened by the OTS. At
the date of such approval and at the Closing Time referred to in Section 2, the Holding Company
Application complied and will comply in all material respects with the applicable provisions of HOLA
and the regulations promulgated thereunder. The Holding Company Application is truthful and accurate
in all material respects.

The Company has filed with the Pennsylvania Department of Banking (the "Department") an application
for approval of its acquisition of the Bank (the "Application for Approval to Acquire a Savings
Bank"). The Company has received written notice from the

5
<!-- page 6 -->
Department of its approval of the acquisition of the Bank, such approval remains in full force and
effect and no order has been issued by the Department suspending or revoking such approval and no
proceedings therefor have been initiated or threatened by the Department. At the date of such
approval and at the Closing Time referred to in Section 2, the Application for Approval to Acquire a
Savings Bank complied and will comply in all material respects with the applicable provisions of the
Banking Code of 1965 of the Commonwealth of Pennsylvania and the regulations promulgated thereunder.
The Application for Approval to Acquire a Savings Bank is truthful and accurate in all material
respects.

The Bank has filed with the Department an application for approval of the proposed merger between
the Bank and Alliance Interim Savings Bank (the "Application for Approval to Merge or Consolidate").
The Bank has received written notice from the Department of its approval of the Application for
Approval to Merge or Consolidate, such approval remains in full force and effect and no order has
been issued by the Department suspending or revoking such approval and no proceedings therefor have
been initiated or threatened by the Department. At the date of such approval and at the Closing Time
referred to in Section 2, the Application for Approval to Merge or Consolidate complied and will
comply in all material respects with the applicable provisions of the Banking Code of 1965 of the
Commonwealth of Pennsylvania and the regulations promulgated thereunder. The Application for
Approval to Merge or Consolidate is truthful and accurate in all material respects.

The Bank and Alliance Interim Savings Bank have filed with the Federal Deposit Insurance Corporation
(the "FDIC") an application for approval of the proposed merger between the Bank and Alliance
Interim Savings Bank (the "Bank Merger Application"). The Bank and Alliance Interim Savings Bank
have received written notice from the FDIC of its approval of the Bank Merger Application, such
approval remains in full force and effect and no order has been issued by the FDIC suspending or
revoking such approval and no proceedings therefor have been initiated or threatened by the FDIC. At
the date of such approval and at the Closing Time referred to in Section 2, the Bank Merger
Application complied and will comply in all material respects with the applicable provisions of the
Bank Merger Act and the regulations promulgated thereunder. The Bank Merger Application is truthful
and accurate in all material respects.

(vi) Pursuant to the rules and regulations of the OTS, as from time to time amended or supplemented
(the "OTS Regulations"), the Company has filed with the OTS an Application for Approval of a
Minority Stock Issuance by a Mid-Tier Subsidiary of a Mutual Holding Company (Form MHC-2) and has
filed such amendments thereto and supplementary materials as may have been required to the date
hereof. The Form MHC-2, as amended to date, if applicable, and as from time to time amended or
supplemented hereafter, is hereinafter referred to as the "MHC Application." The Company has
received written notice from the OTS of its approval of the MHC Application, such approval remains
in full force and effect and no order has been issued by the OTS suspending or revoking such
approval and no proceedings therefor have been initiated or threatened by the OTS. At the date of
such approval and at the Closing Time referred to in Section 2, the MHC Application

6
<!-- page 7 -->
complied and will comply in all material respects with the applicable provisions of the OTS
Regulations. The MHC Application is truthful and accurate in all material respects.

(vii) At the time of their use, the Proxy Statement and any other proxy solicitation materials will
comply in all material respects with the applicable provisions of the OTS Regulations and will not
contain an untrue statement of a material fact or omit to state a material fact necessary in order
to make the statements therein, in the light of the circumstances under which they were made, not
misleading. The Company, the MHCs and the Bank have filed the Prospectus and any supplemental sales
literature with the Commission and the OTS. The Prospectus and all supplemental sales literature, as
of the date the Registration Statement became effective and at the Closing Time referred to in
Section 2, complied and will comply in all material respects with the applicable requirements of the
OTS Regulations, and the Securities Act Regulations and, at or prior to the time of their first use,
will have received all required authorizations of the OTS and Commission for use in final form.

(viii) None of the Commission, the OTS or any "Blue Sky" authority has, by order or otherwise,
prevented or suspended the use of the Proxy Statement, the Prospectus or any supplemental sales
literature authorized by the Company, the MHCs or the Bank for use in connection with the Offerings,
and no proceedings for such purposes are pending or, to the knowledge of the Company, the MHCs or
the Bank, threatened.

(ix) The Offerings and other transactions contemplated hereby do not and will not require any
material consent, approval, authorization or permit or filing with any other governmental agency or
regulatory authority, except as disclosed in the Prospectus.

(x) The Reorganization and Additional Stock Issuance has been approved by and the Plans have been
duly adopted by the Boards of Directors of the Company, the Bank and the MHCs and such approval and
adoption has not since been rescinded or revoked. At the Closing Time referred to in Section 2, the
Company, the Bank and the MHCs will have completed the conditions precedent to the Reorganization
and Additional Stock Issuance in accordance with the Plans, the applicable OTS Regulations and all
other applicable laws, regulations, decisions and orders, including all material terms, conditions,
requirements and provisions precedent to the Reorganization and Additional Stock Issuance imposed
upon the Company, the Bank or the MHCs by the OTS, the FDIC, or any other regulatory authority,
other than those which the regulatory authority permits to be completed after the Reorganization and
Additional Stock Issuance.

(xi) RP Financial, LC (the "Appraiser"), which prepared the valuation of the Bank as part of the
Reorganization and Additional Stock Issuance, has advised the Company, the MHCs and the Bank in
writing that it satisfies all requirements for an appraiser set forth in the OTS Regulations and any
interpretations or guidelines issued by the OTS or its staff with respect thereto.

(xii) Deloitte & Touche LLP, the accountants who audited and reported on the consolidated financial
statements and supporting schedules of the Bank and its subsidiaries

7
<!-- page 8 -->
included in the Registration Statement, have advised the Company, the MHCs and the Bank in writing
that they are independent public accountants within the meaning of the Code of Ethics of the
American Institute of Certified Public Accountants (the "AICPA"), that they are registered with the
Public Company Accounting Oversight Board ("PCAOB") and such accountants are, with respect to the
Company, the MHCs and the Bank, independent certified public accountants as required by, and are not
in violation of the auditors independence requirements of, the Securities Act, the Securities Act
Regulations and OTS Regulations.

(xiii) The only direct or indirect subsidiary of the Company upon completion of the Reorganization
and Additional Stock Issuance will be the Bank; the only direct or indirect subsidiaries of the Bank
are Alliance Delaware Corporation, 541 Corp., and Alliance Financial and Investment Services LLC
(collectively, the "Subsidiaries"). Except for the Subsidiaries, none of the Company, the MHCs or
the Bank, directly or indirectly, controls any other corporation, limited liability company,
partnership, joint venture, association, trust or other business organization.

(xiv) The consolidated financial statements and the related schedules and notes thereto included in
the Registration Statement and the Prospectus present fairly the financial position of the Bank and
its subsidiaries at the dates indicated and the results of operations, retained earnings, equity and
cash flows for the periods specified, and comply as to form with the applicable accounting
requirements of the Securities Act Regulations and the OTS Regulations; except as otherwise stated
in the Registration Statement and Prospectus, said financial statements have been prepared in
conformity with generally accepted accounting principles applied on a consistent basis; and the
supporting schedules and tables included in the Registration Statement and Prospectus present fairly
the information required to be stated therein. The other financial, statistical and pro forma
information and related notes included in the Prospectus present fairly the information shown
therein on a basis consistent with the audited and unaudited financial statements included in the
Prospectus, and as to the pro forma adjustments, the adjustments made therein have been consistently
applied on the basis described therein.

(xv) Since the respective dates as of which information is given in the Registration Statement and
the Prospectus, except as otherwise stated therein (A) there has been no material adverse change in
the financial condition, results of operations, business affairs or prospects of the Company, the
MHCs, the Bank and the Subsidiaries, considered as one enterprise, whether or not arising in the
ordinary course of business, (B) except for transactions specifically referred to or contemplated in
the Registration Statement and Prospectus, there have been no transactions entered into by the
Company, the MHCs or the Bank, other than those in the ordinary course of business consistent with
past practice, which are material with respect to the Company, the MHCs, the Bank and the
Subsidiaries, considered as one enterprise, (C) the capitalization, liabilities, assets, properties
and business of the Company, the MHCs and the Bank conform in all material respects to the
descriptions contained in the Prospectus and none of the Company, the MHCs or the Bank has any
material liabilities of any kind, contingent or otherwise, except as disclosed in the Registration
Statement or the Prospectus and (D) none of the Company, the MHCs or the Bank will have issued any
securities or incurred any liability or obligation, direct or

8
<!-- page 9 -->
contingent, or borrowed money, except borrowings in the ordinary course of business consistent with
past practice from the same or similar sources and in similar amounts as indicated in the
Prospectus.

(xvi) The Company, upon completion of its formation, and in any event no later than Closing Time
will be duly organized and validly existing as a federal stock holding company chartered under the
laws of the United States of America with full corporate power and authority to own, lease and
operate its properties, to conduct its business as described in the Registration Statement and the
Prospectus, and to enter into and perform its obligations under this Agreement and the transactions
contemplated hereby. The Company, upon completion of its formation, and in any event no later than
the Closing Time will be duly qualified to transact business and in good standing under the laws of
the United States of America, in the Commonwealth of Pennsylvania and in each other jurisdiction in
which such qualification is required, whether by reason of the ownership or leasing of property or
the conduct of business, except where the failure to so qualify would not have a material adverse
effect on the financial condition, results of operations, business affairs or prospects of the
Company, the MHCs and the Subsidiaries, considered as one enterprise (a "Material Adverse Effect").

(xvii) Upon completion of the Offerings as described in the Prospectus, the issued and outstanding
capital stock of the Company will be within the range as set forth in the Prospectus under
"Capitalization" (except for subsequent issuances, if any, pursuant to reservations, agreements or
employee benefit plans referred to in the Prospectus). The authorized capital stock of the Company
consists of 15,000,000 shares of Common Stock and 5,000,000 shares of preferred stock, par value
$.01 per share ("Company Preferred Stock"). No shares of Common Stock or Company Preferred Stock
have been or will be issued prior to the Closing Time referred to in Section 2 hereof. At the date
hereof and at the Closing Time, the Securities will have been duly authorized for issuance and, when
issued and delivered by the Company pursuant to the Plans against payment of the consideration
calculated as set forth in the Plans and stated on the cover page of the Prospectus, will be duly
and validly issued and fully paid and nonassessable. The terms and provisions of the Common Stock
and the other capital stock of the Company conform to all statements relating thereto contained in
the Prospectus. The certificates representing the shares of Common Stock will conform to the
requirements of applicable law and regulations. The issuance of the Securities is not subject to
preemptive or other similar rights, except for subscription rights granted pursuant to the Plans in
accordance with the OTS Regulations.

(xviii) The PA MHC has been duly organized and is validly existing as a mutual savings and loan
holding company chartered under the laws of the Commonwealth of Pennsylvania with full corporate
power and authority to own, lease and operate its properties, to conduct its business as described
in the Registration Statement and the Prospectus, and to enter into and perform its obligations
under this Agreement and the transactions contemplated hereby; and the PA MHC is duly qualified to
transact business and is in good standing under the laws of the Commonwealth of Pennsylvania and in
each other jurisdiction in which such qualification is required, whether by reason of the ownership
or leasing of property or the conduct of business, except where the failure to so qualify would not
have a

9
<!-- page 10 -->
Material Adverse Effect. The Federal MHC, upon completion of its formation, and in any event no
later than the Closing Time will be duly organized and validly existing as a federal mutual savings
and loan holding company chartered under the laws of the United States of America with full
corporate power and authority to own, lease and operate its properties, to conduct its business as
described in the Registration Statement and the Prospectus, and to enter into and perform its
obligations under this Agreement and the transactions contemplated hereby; and the Federal MHC is
duly qualified to transact business and is in good standing under the laws of the United States of
America, in the Commonwealth of Pennsylvania and in each other jurisdiction in which such
qualification is required, whether by reason of the ownership or leasing of property or the conduct
of business, except where the failure to so qualify would not have a Material Adverse Effect.

(xix) The MHCs have no capital stock. All holders of the savings, demand or other authorized
accounts of the Bank are members of the MHCs. As of the Closing Time referred to in Section 2, the
MHCs will not own any equity securities or any equity interest in any business enterprise except as
described in the Prospectus.

(xx) The Bank has been duly organized and is validly existing as a stock savings bank chartered
under the laws of the Commonwealth of Pennsylvania with full corporate power and authority to own,
lease and operate its properties, to conduct its business as described in the Registration Statement
and the Prospectus, and to enter into and perform its obligations under this Agreement and the
transactions contemplated hereby; and the Bank is duly qualified to transact business and is in good
standing under the laws of the Commonwealth of Pennsylvania and in each other jurisdiction in which
such qualification is required, whether by reason of the ownership or leasing of property or the
conduct of business, except where the failure to so qualify would not have a Material Adverse
Effect.

(xxi) The authorized capital stock of the Bank is 10,000,000 shares of common stock, par value $.01
per share ("Bank Common Stock"), and 5,000,000 shares of preferred stock, par value $.01 per share
("Bank Preferred Stock"), and the issued and outstanding capital stock of the Bank is 3,442,383
shares of Bank Common Stock and zero shares of Bank Preferred Stock. No shares of Bank Preferred
Stock have been or will be issued prior to the Closing Time referred to in Section 2 hereof.

The issued and outstanding shares of Bank Common Stock have been duly and validly issued and are
fully paid and nonassessable. Shares of Bank Common Stock owned beneficially and of record by the PA
MHC are owned free and clear of any security interest, mortgage, pledge, lien, encumbrance or legal
or equitable claim; the terms and provisions of the Bank Common Stock conform to all statements
relating thereto contained in the Prospectus, and the certificates representing the shares of the
Bank Common Stock comply with the requirements of applicable laws and regulations; and the issuance
of the Bank Common Stock is not subject to preemptive or similar rights; and there are no other
warrants, options or rights of any kind to acquire additional shares of Bank Common Stock or any
shares of Bank Preferred Stock other than as disclosed in the Prospectus.

10
<!-- page 11 -->
(xxii) The Company, the MHCs, the Bank and the Subsidiaries have each obtained all licenses, permits
and other governmental authorizations currently required for the conduct of their respective
businesses, or required for the conduct of their respective businesses as contemplated by the
Holding Company Application and the MHC Application, except where the failure to obtain such
licenses, permits or other governmental authorizations would not have a Material Adverse Effect; all
such licenses, permits and other governmental authorizations are in full force and effect and the
Company, the MHCs, the Bank and the Subsidiaries are in all material respects in compliance
therewith; none of the Company, the MHCs, the Bank or any Subsidiary has received notice of any
proceeding or action relating to the revocation or modification of any such license, permit or other
governmental authorization which, singly or in the aggregate, if the subject of an unfavorable
decision, ruling or finding, might have a Material Adverse Effect.

(xxiii) Each Subsidiary has been duly organized and is validly existing as a corporation in good
standing under the laws of the jurisdiction of its incorporation, has full corporate power and
authority to own, lease and operate its properties and to conduct its business as described in the
Registration Statement and Prospectus, and is duly qualified as a foreign corporation to transact
business and is in good standing in each jurisdiction in which such qualification is required,
whether by reason of the ownership or leasing of property or the conduct of business, except where
the failure to so qualify would not have a Material Adverse Effect; the activities of each
Subsidiary are permitted to subsidiaries of a Pennsylvania-chartered savings bank and both a
Pennsylvania-chartered and a federally- chartered mutual holding company by the rules, regulations,
resolutions and practices of the OTS, the FDIC and the Department; all of the issued and outstanding
capital stock of each Subsidiary has been duly authorized and validly issued, is fully paid and
nonassessable and is owned by the Bank directly, free and clear of any security interest, mortgage,
pledge, lien, encumbrance or legal or equitable claim; and there are no warrants, options or rights
of any kind to acquire shares of capital stock of any Subsidiary.

(xxiv) The Bank is a member in good standing of the Federal Home Loan Bank of Pittsburgh; the
deposit accounts of the Bank are insured by the FDIC up to the applicable limits. The Bank is a
"qualified thrift lender" within the meaning of 12 U.S.C. Section 1467a(m).

(xxv) The Company, the MHCs and the Bank have taken all corporate action necessary for them to
execute, deliver and perform this Agreement and the transactions contemplated hereby, and this
Agreement has been duly executed and delivered by, and is the valid and binding agreement of, the
Company, the MHCS and the Bank, enforceable against each of them in accordance with its terms,
except as may be limited by bankruptcy, insolvency or similar laws and the availability of equitable
remedies.

(xxvi) No approval of any regulatory or supervisory or other public authority is required in
connection with the execution and delivery of this Agreement or the issuance of the Securities that
has not been obtained and a copy of which has been delivered to the Agent, except as may be required
under the "Blue Sky" or securities laws of various jurisdictions.

11
<!-- page 12 -->
(xxvii) None of the Company, the MHCs, the Bank or any of the Subsidiaries is in violation of their
respective certificate of incorporation, organization certificate, articles of incorporation or
charter, as the case may be, or bylaws or other written corporate governance requirements or
guidelines; and none of the Company, the MHCs, the Bank or any of the Subsidiaries is in default
(nor has any event occurred which, with notice or lapse of time or both, would constitute a default)
in the performance or observance of any obligation, agreement, covenant or condition contained in
any contract, indenture, mortgage, loan agreement, note, lease or other instrument to which the
Company, the MHCs, the Bank or any of the Subsidiaries is a party or by which it or any of them may
be bound, or to which any of the property or assets of the Company, the MHCs, the Bank or any of the
Subsidiaries is subject, except for such defaults that would not, individually or in the aggregate,
have a Material Adverse Effect; and there are no contracts or documents of the Company, the MHCs or
the Bank which are required to be filed as exhibits to the Registration Statement, the Holding
Company Application or the MHC Application which have not been so filed.

(xxviii) The Reorganization and Additional Stock Issuance, the execution, delivery and performance
of this Agreement and the consummation of the transactions contemplated herein, have been duly
authorized by all necessary corporate action on the part of the Company, the MHCs, and the Bank, and
do not and will not conflict with or constitute a breach of, or default under, or result in the
creation or imposition of any lien, charge or encumbrance upon any property or assets of the
Company, the MHCs or the Bank pursuant to, any contract, indenture, mortgage, loan agreement, note,
lease or other instrument to which the Company, the MHCs or the Bank is a party or by which it or
any of them may be bound, or to which any of the property or assets of the Company, the MHCs or the
Bank is subject, except for such conflicts, breaches or defaults that would not, individually or in
the aggregate, have a Material Adverse Effect nor will such action result in any violation of the
provisions of the respective charter or bylaws of the Company, the MHCs or the Bank, or any
applicable law, administrative regulation or administrative or court decree.

(xxix) No labor dispute with the employees of the Company, the MHCs, the Bank or the Subsidiaries
exists or, to the knowledge of the Company, the MHCs, the Bank or the Subsidiaries, is imminent or
threatened; and the Company, the MHCs and the Bank are not aware of any existing or threatened labor
disturbance by the employees of any of its principal suppliers or contractors which might be
expected to have a Material Adverse Effect.

(xxx) Each of the Company, the MHCs, the Bank and the Subsidiaries has good and marketable title to
all of its properties and assets for which ownership is material to the business of the Company, the
MHCs, the Bank or the Subsidiaries and to those properties and assets described in the Prospectus as
owned by them, free and clear of all liens, charges, encumbrances or restrictions, except such as
are described in the Prospectus or are not material in relation to the business of the Company, the
MHCs, the Bank or the Subsidiaries, considered as one enterprise; and all of the leases and
subleases material to the business of the Company, the MHCs, the Bank or the Subsidiaries under
which the Company, the MHCs, the Bank or the Subsidiaries hold properties, including those described
in the Prospectus, are valid and binding agreements of the Company, the MHCs, the Bank or the
Subsidiaries, in full force and effect, enforceable in accordance with their terms except as

12
<!-- page 13 -->
may be limited by bankruptcy, insolvency or similar laws and availability of equitable remedies.

(xxxi) None of the Company, the MHCs or the Bank is in violation of any order or directive from the
OTS, the Commission or any regulatory authority to make any material change in the method of
conducting its respective businesses; the Company, the MHCs, the Bank, and each of the Subsidiaries
have conducted and are conducting their business so as to comply with all applicable statutes,
regulations and administrative and court decrees (including, without limitation, all regulations,
decisions, directives and orders of the OTS, the FDIC and the Commission). Neither the Company, the
MHCs, the Bank nor any of the Subsidiaries is subject or is party to, or has received any notice or
advice that any of them may become subject or party to, any investigation with respect to any
cease-and-desist order, agreement, consent agreement, memorandum of understanding or other
regulatory enforcement action, proceeding or order with or by, or is a party to any commitment
letter or similar undertaking to, or is subject to any directive by, or has been a recipient of any
supervisory letter from, or has adopted any board resolutions at the request of, any Regulatory
Agency (as defined below) that currently restrict the conduct of their business or that in any
manner relates to their capital adequacy, their credit policies, their management or their business
(each, a "Regulatory Agreement"), nor has the Company, the MHCs, the Bank or any of the Subsidiaries
been advised by any Regulatory Agency that it is considering issuing or requesting the issuance of
any such Regulatory Agreement; and there is no unresolved violation, criticism or exception by any
Regulatory Agency with respect to any report or statement relating to any examinations of the
Company, the MHCs, the Bank or any of the Subsidiaries which is expected to have a Material Adverse
Effect, or which might materially and adversely affect the properties or assets thereof or which
might adversely affect the consummation of the Offerings or the performance of this Agreement. As
used herein, the term "Regulatory Agency" means any federal or state agency charged with the
supervision or regulation of depositary institutions or holding companies of depositary
institutions, or engaged in the insurance of depositary institution deposits, or any court,
administrative agency or commission or other governmental agency, authority or instrumentality
having supervisory or regulatory authority with respect to the Company, the MHCs, the Bank or any of
the Subsidiaries.

(xxxii) There is no action, suit or proceeding before or by any court or governmental agency or
body, domestic or foreign, now pending, or, to the knowledge of the Company, the MHCs, or the Bank,
threatened, against or affecting the Company, the MHCs or the Bank which is required to be disclosed
in the Registration Statement (other than as disclosed therein), or which might result in any
material adverse change in the financial condition, results of operations, business affairs or
prospects of the Company, the MHCs and the Bank, considered as one enterprise, or which might
materially and adversely affect the properties or assets thereof, or which might adversely affect
the consummation of the Offerings, or the performance of this Agreement; all pending legal or
governmental proceedings to which the Company, the MHCs, the Bank or any Subsidiary is a party or of
which any of their respective property or assets is the subject which are not described in the
Registration Statement, including ordinary routine litigation incidental to their business, are
considered in the aggregate not material.

13
<!-- page 14 -->
(xxxiii) The Company, MHCs and the Bank have obtained (i) an opinion of their counsel, Elias, Matz,
Tiernan & Herrick L.L.P., with respect to the legality of the Securities to be issued and certain
federal income tax consequences of the Offerings and the Plans, and (ii) the opinion of Elias, Matz,
Tiernan & Herrick L.L.P. with respect to the certain state and local income tax consequences of the
Offerings and the Plans, copies of which are filed as exhibits to the Registration Statement; all
material aspects of the aforesaid opinions are accurately summarized in the Prospectus under "The
Reorganization — Federal and State Tax Consequences," the facts and representations upon which such
opinions are based are truthful, accurate and complete in all material respects; and neither the
Company, the MHCs, nor the Bank has taken or will take any action inconsistent therewith.

(xxxiv) The Company is not and, upon completion of the Reorganization and Additional Stock Issuance
and the application of the net proceeds therefrom, will not be, required to be registered as an
"investment company" as that term is defined under the Investment Company Act of 1940, as amended.

(xxxv) All of the loans represented as assets on the most recent consolidated financial statements
or consolidated selected financial information of the Bank included in the Prospectus meet or are
exempt from all requirements of federal, state or local law pertaining to lending, including without
limitation truth in lending (including the requirements of Regulations Z and 12 C.F.R. Part 226 and
Section 563.99), real estate settlement procedures, consumer credit protection, equal credit
opportunity and all disclosure laws applicable to such loans, except for violations which, if
asserted, would not result in a Material Adverse Effect.

(xxxvi) To the knowledge of the Company, the MHCs, the Bank and each Subsidiary, with the exception
of the intended loan to the Bank's ESOP by the Company to enable the ESOP to purchase shares of the
Common Stock, none of the Company, the MHCs, the Bank or their employees has made any payment of
funds of the Company, the MHCs or the Bank as a loan for the purchase of the Common Stock or made
any other payment of funds prohibited by law, and no funds have been set aside to be used for any
payment prohibited by law.

(xxxvii) Each of the Company, the MHCs, the Bank and each of the Subsidiaries maintains a system of
internal accounting controls sufficient to provide reasonable assurance that (a) transactions are
executed in accordance with management's general or specific authorizations; (b) transactions are
recorded as necessary to permit preparation of financial statements in conformity with generally
accepted accounting principles and to maintain asset accountability; (c) access to assets is
permitted only in accordance with management's general or specific authorization; and (d) the
recorded accountability for assets is compared with the existing assets at reasonable intervals and
appropriate action is taken with respect to any differences.

(xxxviii) The Company, the MHCs, the Bank and each Subsidiary are in compliance with the applicable
financial recordkeeping and reporting requirements of the Currency and Foreign Transaction Reporting
Act of 1970, as amended, and the rules and regulations

14
<!-- page 15 -->
thereunder. The Bank has established compliance programs and is in compliance with the requirements
of the USA Patriot Act and all applicable regulations promulgated thereunder. The Bank is in
compliance with the USA Patriot Act and all applicable regulations promulgated thereunder, and there
is no charge, investigation, action, suit or proceeding before any court, regulatory authority or
governmental agency or body pending or, to the best knowledge of the Company, the MHCs, and the
Bank, threatened regarding the Bank's compliance with the USA Patriot Act or any regulations
promulgated thereunder.

(xxxix) None of the Company, the MHCs, the Bank or any Subsidiary nor any properties owned or
operated by the Company, the MHCs, the Bank or any Subsidiary is in violation of or liable under any
Environmental Law (as defined below). There are no actions, suits or proceedings, or demands,
claims, notices or investigations (including, without limitation, notices, demand letters or
requests for information from any environmental agency) instituted or pending, or to the knowledge
of the Company, the MHCs, the Bank or any Subsidiary threatened, relating to the liability of any
property owned or operated by the Company, the MHCs, the Bank or any Subsidiary, under any
Environmental Law, except for such actions, suits or proceedings, or demands, claims, notices or
investigations that, individually or in the aggregate, would not have a Material Adverse Effect. For
purposes of this subsection, the term "Environmental Law" means any federal, state, local or foreign
law, statute, ordinance, rule, regulation, code, license, permit, authorization, approval, consent,
order, judgment, decree, injunction or agreement with any regulatory authority relating to (i) the
protection, preservation or restoration of the environment (including, without limitation, air,
water, vapor, surface water, groundwater, drinking water supply, surface soil, subsurface soil,
plant and animal life or any other natural resource), and/or (ii) the use, storage, recycling,
treatment, generation, transportation, processing, handling, labeling, production, release or
disposal of any substance presently listed, defined, designated or classified as hazardous, toxic,
radioactive or dangerous, or otherwise regulated, whether by type or by quantity, including any
material containing any such substance as a component.

(xl) The Company, the MHCs, the Bank and each Subsidiary have filed all federal, state and local
income and franchise tax returns required to be filed and have made timely payments of all taxes
shown as due and payable in respect of such returns, and no deficiency has been asserted with
respect thereto by any taxing authority. No tax deficiency has been asserted, and the Company, the
MHCs and the Bank have no knowledge of any tax deficiency which could be asserted against the
Company, the MHCs, the Bank or the Subsidiaries.

(xli) The Company has received all approvals required to consummate the Offerings, and to have the
Securities quoted on the Nasdaq Global Market effective as of the Closing Time referred to in
Section 2 hereof.

(xlii) The Company has filed a registration statement for the Securities under Section 12(g) of the
Securities Exchange Act of 1934, as amended (the "Exchange Act"), and such registration statement
was declared effective concurrent with the effectiveness of the Registration Statement.

15
<!-- page 16 -->
(xliii) There are no affiliations or associations (as such terms are defined by the National
Association of Securities Dealers, Inc. ("NASD")) between any member of the NASD and any of the
MHCs', Company's or Bank's officers or directors.

(xliv) The Company, the MHCs, the Bank and each Subsidiary carries, or is covered by, insurance in
such amounts and covering such risks as is adequate for the conduct of their respective businesses
and the value for their respective properties as is customary for companies engaged in similar
industries.

(xlv) The Company, the MHCs and the Bank have not relied on Agent or its counsel for any legal, tax
or accounting advice in connection with the Offerings.

(xlvi) The records of eligible account holders, supplemental eligible account holders, and other
depositors are accurate and complete in all material respects.

(xlvii) The Company, the MHCs, the Bank and each Subsidiary is in compliance with all presently
applicable provisions of the Employee Retirement Income Security Act of 1974, as amended, including
the regulations and published interpretations thereunder ("ERISA"); no "reportable event" (as
defined in ERISA) has occurred with respect to any "pension plan" (as defined in ERISA) for which
the Company, the MHCs, the Bank or any Subsidiary, respectively, would have any liability; each of
the Company, the MHCs, the Bank, and each Subsidiary has not incurred and does not expect to incur
liability under (i) Title IV of ERISA with respect to termination of, or withdrawal from, any
"pension plan" or (ii) Sections 412 or 4971 of the Internal Revenue Code of 1986, as amended,
including the regulations and published interpretations thereunder (the "Code"); and each "pension
plan" for which the Company, the MHCs, the Bank and any Subsidiary would have any liability that is
intended to be qualified under Section 401(a) of the Code is so qualified and nothing has occurred,
whether by action or by failure to act, which would cause the loss of such qualification.

(xlviii) The Bank has established and maintains disclosure controls and procedures (as such term is
defined in Rule 13a-14 and 15d-14 under the Exchange Act), which (i) are designed to ensure that
material information relating to the Bank, including its consolidated subsidiaries, is made known to
the Bank's principal executive officer and its principal financial officer by others within those
entities; and (ii) are effective in all material respects to perform the functions for which they
were established. There are no significant deficiencies in the design or operation of internal
controls which could adversely affect the Bank's ability to record, process, summarize, and report
financial data. There has been no fraud, whether or not material, that involves management or other
employees who have a significant role in the Bank's internal controls. Since the date of the most
recent evaluation of the Bank's disclosure controls and procedures, there have been no significant
changes in internal controls or in other factors that could significantly affect internal controls,
including any corrective actions with regard to significant deficiencies and material weaknesses.

The Company, upon completion of its formation, and in any event no later than Closing Time will have
established and maintained disclosure controls and procedures (as

16
<!-- page 17 -->
such term is defined in Rule 13a-14 and 15d-14 under the Exchange Act), which (i) are designed to
ensure that material information relating to the Company, including its consolidated subsidiaries,
is made known to the Company's principal executive officer and its principal financial officer by
others within those entities; and (ii) are effective in all material respects to perform the
functions for which they were established.

(xlix) The Company, upon completion of its formation, and in any event no later than Closing Time
will be in compliance with the applicable provisions of the Sarbanes-Oxley Act, the rules and
regulations of the Commission thereunder, and the Nasdaq corporate governance rules applicable to
the Company, will use its best efforts to maintain such compliance and will use its best efforts to
comply with provisions of the Sarbanes-Oxley Act, rules and regulations of the Commission
thereunder, and Nasdaq corporate governance rules that become effective in the future.

(l) Any certificate signed by any officer of the Company, the MHCs, the Bank or any Subsidiary and
delivered to either of the Agent or counsel for the Agent shall be deemed a representation and
warranty by the Company, the MHCs or the Bank to the Agent as to the matters covered thereby.

SECTION 2. APPOINTMENT OF SANDLER O'NEILL; SALE AND DELIVERY OF THE SECURITIES; CLOSING. On the
basis of the representations and warranties herein contained and subject to the terms and conditions
herein set forth, the Company hereby appoints Sandler O'Neill as its Agent to consult with and
advise the Company, and to assist the Company with the solicitation of subscriptions and purchase
orders for Securities, in connection with the Company's sale of Common Stock in the Offerings. On
the basis of the representations and warranties herein contained, and subject to the terms and
conditions herein set forth, Sandler O'Neill accepts such appointment and agrees to use its best
efforts to assist the Company with the solicitation of subscriptions and purchase orders for
Securities in accordance with this Agreement; provided, however, that the Agent shall not be
obligated to take any action which is inconsistent with any applicable laws, regulations, decisions
or orders. The services to be rendered by Sandler O'Neill pursuant to this appointment include the
following: (i) consulting as to the securities marketing implications of any aspect of the Plans or
related corporate documents; (ii) reviewing with the Board of Directors of the Company, the MHCs and
the Bank financial and securities marketing implications of the Appraiser's appraisal of the Common
Stock; (iii) reviewing all offering documents, including the Prospectus, stock order forms and
related offering materials (it being understood that preparation and filing of such documents is the
sole responsibility of the Company and the Bank and their counsel); (iv) assisting in the design and
implementation of a marketing strategy for the Offerings; (v) assisting management of the Company
and the Bank in preparing for meetings with potential investors and broker-dealers; and (vi)
providing such other general advice and assistance regarding financial and marketing aspects of the
Offering as may be requested to promote the successful completion of the Offering.

The appointment of the Agent hereunder shall terminate upon the earlier to occur of (a) forty-five
(45) days after the last day of the Subscription and Community Offering, unless

17
<!-- page 18 -->
the Company and the Agent agree in writing to extend such period and the OTS agrees to extend the
period of time in which the Securities may be sold, or (b) the receipt and acceptance of
subscriptions and purchase orders for all of the Securities, or (c) the completion of the Syndicated
Community Offering.

If any of the Securities remain available after the expiration of the Subscription and Community
Offering, at the request of the Company and the Bank, Sandler O'Neill will seek to form a syndicate
of registered brokers or dealers ("Selected Dealers") to assist in the solicitation of purchase
orders of such Securities on a best efforts basis. Sandler O'Neill will endeavor to limit the
aggregate fees to be paid by the Company, the MHCs and the Bank to an amount competitive with gross
underwriting discounts charged at such time for underwritings of comparable amounts of stock sold at
a comparable price per share in a similar market environment; provided, however, that the aggregate
fees payable to Sandler O'Neill and Selected Dealers shall not exceed 6.0% of the aggregate dollar
amount of the Securities sold in the Syndicated Community Offering by such Selected Dealers. Sandler
O'Neill will endeavor to distribute the Securities among the Selected Dealers in a fashion which
best meets the distribution objective of the Company and the Bank, which may result in limiting the
allocation of stock to certain Selected Dealers. It is understood that in no event shall Sandler
O'Neill be obligated to act as a Selected Dealer or to take or purchase any Securities.

If any of the Securities remain available after the expiration of the Offerings, the Company agrees
to offer the Agent the first right to act as lead managing underwriter for the Public Offering. The
terms of the Public Offering will be set forth in a separate definitive purchase agreement in a form
satisfactory to Sandler O'Neill and containing customary representations, warranties, conditions,
agreements and indemnities, which purchase agreement, when executed, will supersede and replace this
Agreement with respect to Securities sold thereunder (the "Purchase Agreement"). This Agreement is
not intended to constitute, and should not be construed as, an agreement or commitment between the
Company, the Bank and Sandler O'Neill relating to the firm commitment underwriting of any
securities, and Sandler O'Neill may, in its sole judgment and discretion, determine at any time not
to proceed with the proposed firm commitment underwriting. Such proposed underwriting will be
subject, among other things, to: (i) satisfactory completion by Sandler O'Neill of such due
diligence investigation or inquiries as it may deem appropriate, (ii) market conditions, which, in
the sole judgment of Sandler O'Neill, shall be satisfactory, and (iii) the execution and delivery of
a definitive Purchase Agreement.

In the event the Company is unable to sell at least the total minimum of the Securities, as set
forth on the cover page of the Prospectus, within the period herein provided, this Agreement shall
terminate and the Company shall refund to any persons who have subscribed for any of the Securities
the full amount which it may have received from them, together with interest as provided in the
Prospectus, and no party to this Agreement shall have any obligation to the others hereunder, except
for the obligations of the Company, the MHCs and the Bank as set forth in Sections 4, 6(a) and 7
hereof and the obligations of the Agent as provided in Sections 6(b) and 7 hereof. Appropriate
arrangements for placing the funds received from subscriptions for Securities or other offers to
purchase Securities in

18
<!-- page 19 -->
special interest-bearing accounts with the Bank until all Securities are sold and paid for were made
prior to the commencement of the Subscription Offering, with provision for refund to the purchasers
as set forth above, or for delivery to the Company if all Securities are sold.

If at least the total minimum of Securities, as set forth on the cover page of the Prospectus, are
sold, the Company agrees to issue or have issued the Securities sold and to release for delivery
certificates for such Securities at the Closing Time against payment therefor by release of funds
from the special interest-bearing accounts referred to above. The closing shall be held at the
offices of Elias, Matz, Tiernan & Herrick L.L.P., at 10:00 a.m., Eastern Standard Time, or at such
other place and time as shall be agreed upon by the parties hereto, on a business day to be agreed
upon by the parties hereto. The Company shall notify the Agent by telephone, confirmed in writing,
when funds shall have been received for all the Securities. Certificates for Securities shall be
delivered directly to the purchasers thereof in accordance with their directions. Notwithstanding
the foregoing, certificates for Securities purchased through Selected Dealers shall be made
available to the Agent for inspection at least 48 hours prior to the Closing Time at such office as
the Agent shall designate. The hour and date upon which the Company shall release for delivery all
of the Securities, in accordance with the terms hereof, is herein called the "Closing Time."

The Company will pay any stock issue and transfer taxes which may be payable with respect to the
sale of the Securities.

In addition to the reimbursement of the expenses specified in Section 4 hereof, the Agent will
receive the following compensation for its services hereunder:

(a) One percent (1.00%) of the aggregate purchase price of the Securities sold in the Subscription
and Community Offering, excluding in each case shares purchased by (i) any employee benefit plan of
the Company or the Bank established for the benefit of their respective directors, officers and
employees, and (ii) any director, officer or employee of the Company or the Bank or members of their
immediate families (which term shall mean parents, grandparents, spouse, siblings, children and
grandchildren); and

(b) With respect to any Securities sold by a National Association of Securities Dealers, Inc.
("NASD") member firm (other than Sandler O'Neill) in the Syndicated Community Offering, (i) the
compensation payable to Selected Dealers, (ii) any sponsoring dealer's fees; and (iii) a management
fee to Sandler O'Neill of one percent (1.0 %) of the aggregate purchase price of the Securities sold
in the Syndicated Community Offering. Any fees payable to Sandler O'Neill for Securities sold by
Sandler O'Neill under any such agreement shall be limited to an aggregate of six percent (6.0 %) of
the purchase price of the Securities sold by Sandler O'Neill and other NASD member firms.

If this Agreement is terminated by the Agent in accordance with the provisions of Section 9(a)
hereof, no fee shall be payable by the Company to Sandler O'Neill; provided, however, that the
Company shall reimburse the Agent for all of its reasonable out-of-pocket expenses incurred prior to
termination, including the reasonable fees and disbursements of counsel for the Agent in accordance
with the provisions of Section 4 hereof. In addition, the

19
<!-- page 20 -->
Company shall be obligated to pay the fees and expenses as contemplated by the provisions of Section
4 hereof in the event of any such termination.

All fees payable to the Agent hereunder shall be payable in immediately available funds at Closing
Time, or upon the termination of this Agreement, as the case may be. In recognition of the long lead
times involved in the conversion process, the Bank agreed to make an advance payment to the Agent in
the amount of $25,000, all of which has been previously paid, which shall be credited against any
fees or reimbursement of expenses payable hereunder. In the event that the advance payment exceeds
the amount due in payment of fees and reimbursement of expenses hereunder, the excess shall be
refunded.

SECTION 3. COVENANTS OF THE COMPANY, THE MHCS AND THE BANK. The Company, the MHCs and the Bank
covenant with the Agent as follows:

(a) The Company, the MHCs and the Bank will prepare and file such amendments or supplements to the
Registration Statement, the Prospectus, the Holding Company Application, the MHC Application and the
Proxy Statement as may hereafter be required by the Securities Act Regulations or the OTS
Regulations or as may hereafter be requested by the Agent. Following completion of the Subscription
and Community Offering, in the event of a Syndicated Community Offering, the Company, the MHCs and
the Bank will (i) promptly prepare and file with the Commission a post-effective amendment to the
Registration Statement relating to the results of the Subscription and Community Offering, any
additional information with respect to the proposed plan of distribution and any revised pricing
information or (ii) if no such post-effective amendment is required, will file with the Commission a
prospectus or prospectus supplement containing information relating to the results of the
Subscription and Community Offering and pricing information pursuant to Rule 424 of the Securities
Act Regulations, in either case in a form acceptable to the Agent. The Company, the MHCs and the
Bank will notify the Agent immediately, and confirm the notice in writing, (i) of the effectiveness
of any post-effective amendment of the Registration Statement, the filing of any supplement to the
Prospectus and the filing of any amendment to the Plans, (ii) of the receipt of any comments from
the OTS or the Commission with respect to the transactions contemplated by this Agreement or the
Plans, (iii) of any request by the Commission or the OTS for any amendment to the Registration
Statement or the Plans or any amendment or supplement to the Prospectus or for additional
information, (iv) of the issuance by the OTS of any order suspending the Offerings or the use of the
Prospectus or the initiation of any proceedings for that purpose, (v) of the issuance by the
Commission of any stop order suspending the effectiveness of the Registration Statement or the
initiation of any proceedings for that purpose, and (vi) of the receipt of any notice with respect
to the suspension of any qualification of the Securities for offering or sale in any jurisdiction.
The Company, the MHCs and the Bank will take all necessary action to prevent the issuance of any
stop order and, if any stop order is issued, to obtain the lifting thereof at the earliest possible
moment.

(b) The Company represents and agrees that, unless it obtains the prior consent of the Agent and the
Agent represents and agrees that, unless it obtains the prior consent of the Company, it has not
made and will not make any offer relating to the offered Securities

20
<!-- page 21 -->
that would constitute an "issuer free writing prospectus," as defined in Rule 433 of the Securities
Act Regulations, or that would constitute a "free writing prospectus," as defined in Rule 405 of the
Securities Act Regulations, required to be filed with the Commission. Any such free writing
prospectus consented to by the Company and the Agent is hereinafter referred to as a "Permitted Free
Writing Prospectus." The Company represents that it has and will comply with the requirements of
Rule 433 of the Securities Act Regulations applicable to any Permitted Free Writing Prospectus,
including timely Commission filing where required, legending and record keeping. The Company need
not treat any communication as a free writing prospectus if it is exempt from the definition of
prospectus pursuant to clause (a) of Section 2(a)(10) of the 1933 Act without regard to Rule 172 or
173 of the Securities Act Regulations.

(c) The Company, the MHCs and the Bank will give the Agent notice of its intention to file or
prepare any amendment to the Plans or Registration Statement (including any post-effective
amendment) or any amendment or supplement to the Prospectus (including any revised prospectus which
the Company proposes for use in connection with the Syndicated Community Offering of the Securities
which differs from the prospectus on file at the Commission at the time the Registration Statement
becomes effective, whether or not such revised prospectus is required to be filed pursuant to Rule
424(b) of the Securities Act Regulations), will furnish the Agent with copies of any such amendment
or supplement a reasonable amount of time prior to such proposed filing or use, as the case may be,
and will not file any such amendment or supplement or use any such prospectus to which the Agent or
counsel for the Agent may object.

(d) The Company, the MHCs and the Bank will deliver to the Agent as many signed copies and as many
conformed copies of the Holding Company Application, the MHC Application and the Registration
Statement as originally filed and of each amendment thereto (including exhibits filed therewith or
incorporated by reference therein) as the Agent may reasonably request, and from time to time such
number of copies of the Prospectus as the Agent may reasonably request.

(e) During the period when the Prospectus is required to be delivered, the Company, the MHCs and the
Bank will comply, at their own expense, with all requirements imposed upon them by the OTS, by the
OTS Regulations, as from time to time in force, and by the Nasdaq Global Market, the Securities Act,
the Securities Act Regulations, the Exchange Act, and the rules and regulations of the Commission
promulgated thereunder, including, without limitation, Regulation M under the Exchange Act, so far
as necessary to permit the continuance of sales or dealing in shares of the Securities during such
period in accordance with the provisions hereof and the Prospectus.

(f) If any event or circumstance shall occur as a result of which it is necessary, in the opinion of
counsel for the Agent, to amend or supplement the Registration Statement or Prospectus in order to
make the Prospectus not misleading in the light of the circumstances existing at the time it is
delivered to a purchaser, the Company, the MHCs and the Bank will forthwith amend or supplement the
Registration Statement or Prospectus (in form and substance satisfactory to counsel for the Agent)
so that, as so amended or

21
<!-- page 22 -->
supplemented, the Registration Statement or Prospectus will not include an untrue statement of a
material fact or omit to state a material fact necessary in order to make the statements therein, in
the light of the circumstances existing at the time it is delivered to a purchaser, not misleading,
and the Company, the MHCs and the Bank will furnish to the Agent a reasonable number of copies of
such amendment or supplement. For the purpose of this subsection, the Company, the MHCs and the Bank
will each furnish such information with respect to itself as the Agent may from time to time
reasonably request.

(g) The Company, the MHCs and the Bank will take all necessary action, in cooperation with the
Agent, to qualify the Securities for offering and sale under the applicable securities laws of such
states of the United States and other jurisdictions as the OTS Regulations may require and as the
Agent and the Company have agreed; provided, however, that none of the Company, the MHCs or the Bank
shall be obligated to file any general consent to service of process or to qualify as a foreign
corporation in any jurisdiction in which it is not so qualified. In each jurisdiction in which the
Securities have been so qualified, the Company, the MHCs and the Bank will file such statements and
reports as may be required by the laws of such jurisdiction to continue such qualification in effect
for a period of not less than one year from the effective date of the Registration Statement.

(h) The Company authorizes Sandler O'Neill and any Selected Dealer to act as agent of the Company in
distributing the Prospectus to persons entitled to receive subscription rights and other persons to
be offered Securities having record addresses in the states or jurisdictions set forth in a survey
of the securities or "blue sky" laws of the various jurisdictions in which the Offerings will be
made (the "Blue Sky Survey").

(i) The Company will make generally available to its security holders as soon as practicable, but
not later than 60 days after the close of the period covered thereby, an earnings statement covering
a twelve month period beginning not later than the first day of the Company's fiscal quarter next
following the effective date of the Registration Statement (as defined in Rule 158 of the Securities
Act Regulations) that will satisfy the provisions of Section 11(a) of the Securities Act.

(j) During the period ending on the third anniversary of the expiration of the fiscal year during
which the closing of the transactions contemplated hereby occurs, the Company will furnish to its
stockholders as soon as practicable after the end of each such fiscal year an annual report
(including consolidated statements of financial condition and consolidated statements of income,
stockholders' equity and cash flows, certified by independent public accountants) and, as soon as
practicable after the end of each of the first three quarters of each fiscal year (beginning with
the fiscal quarter ending after the effective date of the Registration Statement), the Company will
make available to its stockholders consolidated summary financial information of the Company and the
Bank for such quarter in reasonable detail. In addition, such annual report and quarterly
consolidated summary financial information shall be made public through the issuance of appropriate
press releases at the same time or prior to the time of the furnishing thereof to stockholders of
the Company.

22
<!-- page 23 -->
(k) During the period ending on the fifth anniversary of the expiration of the fiscal year during
which the closing of the transactions contemplated hereby occurs, the Company will furnish to the
Agent (i) as soon as publicly available, a copy of each report or other document of the Company
furnished generally to stockholders of the Company or furnished to or filed with the Commission
under the Exchange Act or any national securities exchange or system on which any class of
securities of the Company is listed, and (ii) from time to time, such other information concerning
the Company as the Agent may reasonably request.

(l) The Company, the MHCs and the Bank will comply, at their own expense, with all requirements
imposed by the Commission, the OTS and the Nasdaq Global Market, or pursuant to the applicable
Securities Act Regulations, OTS Regulations and Nasdaq Global Market Regulations, as from time to
time in force.

(m) The Company will promptly inform the Agent upon its receipt of service with respect to any
material litigation or administrative action instituted with respect to the Offerings.

(n) Each of the Company and the Bank will use the net proceeds received by it from the sale of the
Securities in the manner specified in the Prospectus under "Use of Proceeds."

(o) The Company will report the use of proceeds from the Offerings on its first periodic report
filed pursuant to Sections 13(a) and 15(d) of the Exchange Act and on any subsequent periodic
reports as may be required pursuant to Rule 463 of the Securities Act Regulations.

(p) The Company will maintain the effectiveness of the Exchange Act Registration Statement for not
less than three years and will comply in all material respects with its filing obligations under the
Exchange Act. The Company will use its best efforts to effect and maintain the listing of the Common
Stock on the Nasdaq Global Market and, once listed on the Nasdaq Global Market, the Company will
comply with all applicable corporate governance standards required by the Nasdaq Global Market. The
Company will file with the Nasdaq Global Market all documents and notices required by the Nasdaq
Global Market of companies that have issued securities that are traded in the over-the-counter
market and quotations for which are reported by the Nasdaq Global Market.

(q) The Company and the Bank will take such actions and furnish such information as are reasonably
requested by the Agent in order for the Agent to ensure compliance with Rule 2790 of the National
Association of Securities Dealers, Inc.

(r) Other than in connection with any employee benefit plan or arrangement described in the
Prospectus, the Company will not, without the prior written consent of the Agent, sell or issue,
contract to sell or otherwise dispose of, any shares of Common Stock other than the Securities for a
period of 180 days following the Closing Time.

23
<!-- page 24 -->
(s) During the period beginning on the date hereof and ending on the later of the fifth anniversary
of the Closing Time or the date on which the Agent receives full payment in satisfaction of any
claim for indemnification or contribution to which it may be entitled pursuant to Sections 6 or 7,
respectively, none of the Company, the MHCs or the Bank shall, without the prior written consent of
the Agent, take or permit to be taken any action that could result in the Bank Common Stock becoming
subject to any security interest, mortgage, pledge, lien or encumbrance.

(t) The Company, the MHCs and the Bank will comply with the conditions imposed by or agreed to with
the OTS in connection with its approval of the Holding Company and the MHC Application including the
Plans.

(u) During the period ending on the first anniversary of the Closing Time, the Bank will comply with
all applicable laws and regulations necessary for the Bank to continue to be a "qualified thrift
lender" within the meaning of 12 U.S.C. Section 1467a(m).

(v) The Company shall not deliver the Securities until the Company, the MHCs and the Bank have
satisfied each condition set forth in Section 5 hereof, unless such condition is waived by the
Agent.

(w) The Company, the MHCs and the Bank will furnish to Sandler O'Neill as early as practicable prior
to the Closing Date, but no later than two (2) full business days prior thereto, a copy of the
latest available unaudited interim consolidated financial statements of the Company which have been
read by Deloitte & Touche LLP, as stated in their letters to be furnished pursuant to subsections
(f) and (g) of Section 5 hereof.

(x) Each of the Company, the MHCs and the Bank will conduct its business in compliance in all
material respects with all applicable federal and state laws, rules, regulations, decisions,
directives and orders, including all decisions, directives and orders of the Commission, the Nasdaq
Global Market and the OTS.

(y) The Bank will not amend the Plans in any manner that would affect the sale of the Securities or
the terms of this Agreement without the consent of the Agent.

(z) The Company, the MHCs and the Bank will not, prior to the Closing Time, incur any liability or
obligation, direct or contingent, or enter into any material transaction, other than in the ordinary
course of business consistent with past practice, except as contemplated by the Prospectus.

(aa) The Company, the MHCs and the Bank will use all reasonable efforts to comply with, or cause to
be complied with, the conditions precedent to the several obligations of the Agent specified in
Section 5 hereof.

(bb) The Company, the MHCs and the Bank will provide the Agent with any information necessary to
carry out the allocation of the Securities in the event of an oversubscription, and such information
will be accurate and reliable in all material respects.

24
<!-- page 25 -->
(cc) The Company, the MHCs and the Bank will notify the Agent when funds have been received for the
minimum number of Securities set forth in the Prospectus.

(dd) At the Closing Time, (i) the Company, the MHCs and the Bank will have completed the conditions
precedent to the Offerings in accordance with the Plans, the applicable OTS Regulations and all
other applicable laws, regulations, decisions and orders, including all material terms, conditions,
requirements and provisions precedent to the Reorganization and Additional Stock Issuance imposed
upon the Company, the MHCs or the Bank by the Commission, the OTS or any other regulatory authority
or Blue Sky authority, and will comply with those which the regulatory authority permits to be
completed after the Reorganization and Additional Stock Issuance; and (ii) the Reorganization and
Additional Stock Issuance will have been effected in the manner described in the Prospectus and in
accordance with the Plans, the OTS Regulations and all other applicable material laws, regulations,
decisions and orders, including in compliance with all terms, conditions, requirements and
provisions precedent to the Reorganization and Additional Stock Issuance imposed upon the Company,
the MHCs and the Bank by the Commission, the OTS, the FDIC or any other regulatory or Blue Sky
authority.

SECTION 4. PAYMENT OF EXPENSES. The Company, the MHCs and the Bank jointly and severally agree to
pay all expenses incident to the performance of their obligations under this Agreement, including
but not limited to (i) the cost of obtaining all securities and bank regulatory approvals, (ii) the
preparation, printing and filing of the Registration Statement and the Plans as originally filed and
of each amendment thereto, (iii) the preparation, issuance and delivery of the certificates for the
Securities purchased in the Offerings, (iv) the fees and disbursements of the Company's, the MHCs's
and the Bank's counsel, conversion agent, accountants, appraiser and other advisors, (v) the
qualification of the Securities under securities laws in accordance with the provisions of Section
3(f) hereof, including filing fees and the fees and disbursements of counsel in connection therewith
and in connection with the preparation of the Blue Sky Survey, (vi) the printing and delivery to the
Agent of copies of the Registration Statement as originally filed and of each amendment thereto and
the printing and delivery of the Prospectus and any amendments or supplements thereto to the
purchasers in the Offerings and the Agent (in such quantities as the Agent shall reasonably
request), (vii) the printing and delivery to the Agent of copies of a Blue Sky Survey, and (viii)
the fees and expenses incurred in connection with the listing of the Securities on the Nasdaq Global
Market. In the event the Agent incurs any such fees and expenses on behalf of the Company, the MHCs
or the Bank, the Bank will reimburse the Agent for such fees and expenses whether or not the
Offerings are consummated; provided, however, that the Agent shall not incur any substantial
expenses on behalf of the Company, the MHCs or the Bank pursuant to this Section without the prior
approval of the Bank.

The Company, the MHCs and the Bank jointly and severally agree to pay certain expenses incident to
the performance of the Agent's obligations under this Agreement, regardless of whether the Offerings
are consummated, including (i) the filing fees paid or incurred by the Agent in connection with all
filings with the NASD, and (ii) all reasonable out-of-pocket expenses incurred by the Agent relating
to the Offerings, including without limitation, fees and expenses of the Agent's counsel,
advertising, promotional, syndication

25
<!-- page 26 -->
and travel expenses. All fees and expenses to which the Agent is entitled to reimbursement under
this paragraph of this Section 4 shall be due and payable upon receipt by the Company, the MHCs or
the Bank of a written accounting therefor setting forth in reasonable detail the expenses incurred
by the Agent.

SECTION 5. CONDITIONS OF AGENT'S OBLIGATIONS. The Company, the MHCs, the Bank and the Agent agree
that the issuance and the sale of Securities and all obligations of the Agent hereunder are subject
to the accuracy of the representations and warranties of the Company, the MHCs and the Bank herein
contained as of the date hereof and the Closing Time, to the accuracy of the statements of officers
and directors of the Company, the MHCs and the Bank made pursuant to the provisions hereof, to the
performance by the Company, the MHCs and the Bank of their obligations hereunder, and to the
following further conditions:

(a) No stop order suspending the effectiveness of the Registration Statement shall have been issued
under the Securities Act or proceedings therefor initiated or threatened by the Commission, no order
suspending the Offerings or authorization for final use of the Prospectus shall have been issued or
proceedings therefor initiated or threatened by the Commission or the OTS, and no order suspending
the sale of the Securities in any jurisdiction shall have been issued.

(b) At Closing Time, the Agent shall have received:

(1) The favorable opinion, dated as of Closing Time, of Elias, Matz, Tiernan & Herrick L.L.P.,
counsel for the Company, the MHCs and the Bank, in form and substance satisfactory to counsel for
the Agent, to the effect that:

(i) The Company, at the Closing Time, will be duly organized and validly existing as a federal stock
holding company chartered under the laws of the United States of America; the Federal MHC, at the
Closing Time, will be duly organized and validly existing as a federal mutual holding company
chartered under the laws of the United States of America; the PA MHC has been duly organized and is
validly existing as a mutual holding company chartered under the laws of the Commonwealth of
Pennsylvania; the Bank has been duly organized and is validly existing as a stock savings bank
chartered under the laws of the Commonwealth of Pennsylvania.

(ii) Each of the Company, the MHCs and the Bank has full corporate power and authority to own, lease
and operate its properties and to conduct its business as described in the Registration Statement
and the Prospectus and to enter into and perform its obligations under this Agreement and the
transactions contemplated hereby.

26
<!-- page 27 -->
(iii) Each of the Company, the MHCs and the Bank is duly qualified as a domestic or foreign
corporation to transact business and is in good standing under the laws of the United States of
America, in the Commonwealth of Pennsylvania and in each other jurisdiction in which such
qualification is required, whether by reason of the ownership or leasing of property or the conduct
of business, except where the failure to so qualify would not have a Material Adverse Effect.

(iv) The authorized capital stock of the Company consists of 15,000,000 shares of Common Stock and
5,000,000 shares of preferred stock, par value $.01 per share, and no capital stock of the Company
has been issued prior to the Closing Time; upon consummation of the Offerings, the authorized issued
and outstanding capital stock of the Company will be within the range set forth in the Prospectus
under "Capitalization".

(v) The authorized capital stock of the Bank consists of 10,000,000 shares of common stock, par
value $.01 per share, and 5,000,000 shares of serial preferred stock, par value $.01 per share, and
the issued and outstanding capital stock of the Bank is 3,441,383 shares of common stock, all of
which are owned beneficially and of record by the Company free and clear of any security interest,
mortgage, pledge, lien, encumbrance or legal or equitable claim. All of the issued and outstanding
capital stock of the Bank has been duly authorized, validly issued and fully paid and nonassessable
and has been issued in compliance with all federal and state securities laws.

(vi) The Securities have been duly and validly authorized for issuance and sale; the Securities,
when issued and delivered by the Company pursuant to the Plans against payment of the consideration
calculated as set forth in the Plans, will be duly and validly issued and fully paid and
nonassessable.

(vii) The issuance of the Securities is not subject to preemptive or other similar rights arising by
operation of the law or, to counsel's knowledge after due inquiry, otherwise, except for
subscription rights granted pursuant to the Plans.

(viii) The issuance of the Securities is in compliance with all conditions imposed upon the Company,
the MHCs and the Bank by the OTS under the terms of their written approval or notice of intention
not to object, as applicable.

27
<!-- page 28 -->
(ix) Each of the Company and the MHCs is registered as a savings and loan holding company under the
Home Owners Loan Act.

(x) The Bank is a member in good standing of the Federal Home Loan Bank of Pittsburgh and the
deposit accounts of the Bank are insured by the FDIC up to the applicable limits.

(xi) Each Subsidiary has been duly incorporated and is validly existing as a corporation in good
standing under the laws of the jurisdiction of its incorporation, and each of the Subsidiaries has
full corporate power and authority to own, lease and operate its properties and to conduct its
business as described in the Registration Statement and Prospectus, and is duly qualified as a
foreign corporation to transact business and is in good standing in each jurisdiction in which such
qualification is required, whether by reason of the ownership or leasing of property or the conduct
of business, except where the failure to so qualify would not have a Material Adverse Effect; the
activities of each Subsidiary are permitted to subsidiaries of a Pennsylvania-chartered savings
bank, in the case of the Bank, and a federally chartered stock holding company, in the case of the
Company, by the rules, regulations, resolutions and practices of the OTS, the Department and the
FDIC; all of the issued and outstanding capital stock of each Subsidiary has been duly authorized
and validly issued, is fully paid and non-assessable and is owned by the MHCs or the Bank, as the
case may be, directly, free and clear of any security interest, mortgage, pledge, lien, encumbrance,
or legal or equitable claim.

(xii) The OTS has duly approved the Holding Company Application and the MHC Application, including
the Plans; the FDIC has duly approved the Bank Merger Application; the Department has duly approved
the Application for Approval to Acquire a Savings Bank and the Application for Approval to Merge or
Consolidate; such approvals remains in full force and effect and no action is pending, or to the
best of such counsel's knowledge, threatened respecting such approvals or the Plans. Such approvals
remain in full force and effect and no action is pending, or to such counsel's knowledge, threatened
respecting the approvals or the Plans; the Holding Company Application, the MHC Application, the
Bank Merger Application, the Application for Approval to Acquire a Savings Bank and the Application
for Approval to Merge or Consolidate and the Plans comply as to form in all material respects with
the applicable requirements of the OTS, the FDIC and the Department, as applicable, include all
documents required to be filed as exhibits thereto, and are, to such counsel's knowledge, truthful,
accurate and

28
<!-- page 29 -->
complete (other than the financial statements, notes to financial statements and tabular,
statistical and appraisal data included therein, as to which no opinion need be rendered) and the
Company is duly authorized to own all of the issued and outstanding capital stock of the Bank.

(xiii) The execution and delivery of this Agreement, the incurrence of the obligations herein set
forth, and the consummation of the transactions contemplated hereby, (A) have been duly and validly
authorized by all necessary action on the part of each of the Company, the MHCs and the Bank, and
this Agreement constitutes the legal, valid and binding agreement of each of the Company, the MHCs
and the Bank, enforceable in accordance with its terms, except as rights to indemnity and
contribution hereunder may be limited under applicable law (it being understood that such counsel
may avail itself of customary exceptions concerning the effect of bankruptcy, insolvency or similar
laws and the availability of equitable remedies); (B) will not result in any violation of the
provisions of the certificate of incorporation, reorganization certificate, articles of
incorporation or charter, as the case may be, or bylaws of the Company, the MHCs, the Bank or any
Subsidiary; and, (C) will not conflict with or constitute a breach of, or default under, and no
event has occurred which, with notice or lapse of time or both, would constitute a default under, or
result in the creation or imposition of any lien, charge or encumbrance, that, individually or in
the aggregate, would have a Material Adverse Effect or a material adverse effect upon any property
or assets of the Company, the MHCs, the Bank or the Subsidiaries pursuant to any contract,
indenture, mortgage, loan agreement, note, lease or other instrument to which the Company, the MHCs,
the Bank or the Subsidiaries is a party or by which any of them may be bound, or to which any of the
property or assets of the Company, the MHCs, the Bank or the Subsidiaries is subject.

(xiv) The Prospectus and the Proxy Statement have been duly authorized by the OTS for final use
pursuant to the OTS Regulations and no action has been taken or is pending, or to the best of such
counsel's knowledge after due inquiry, is threatened, by the OTS to revoke such authorization.

(xv) The Registration Statement is effective under the Securities Act and no stop order suspending
the effectiveness of the Registration Statement has been issued under the Securities Act or,
proceedings therefor initiated or, to the best of such counsel's knowledge, threatened by the
Commission.

29
<!-- page 30 -->
(xvi) No further approval, authorization, consent or other order of any public board or body is
required in connection with the execution and delivery of this Agreement, the issuance of the
Securities and the consummation of the Plans, except as may be required under the securities or
"Blue Sky" laws of various jurisdictions as to which no opinion need be rendered.

(xvii) At the time the Registration Statement became effective, the Registration Statement (other
than the financial statements and statistical data included therein, as to which no opinion need be
rendered) complied as to form in all material respects with the requirements of the Securities Act
and the Securities Act Regulations and the OTS Regulations.

(xviii) The Common Stock conforms to the description thereof contained in the Prospectus, and the
form of certificate used to evidence the Common Stock is in due and proper form and complies with
all applicable statutory requirements.

(xix) There are no legal or governmental proceedings pending or threatened against or affecting the
Company, the MHCs, the Bank or the Subsidiaries which are required, individually or in the
aggregate, to be disclosed in the Registration Statement and Prospectus, other than those disclosed
therein, and all pending legal or governmental proceedings to which the Company, the MHCs, the Bank
or any Subsidiary is a party or to which any of their property is subject which are not described in
the Registration Statement, including ordinary routine litigation incidental to the business, are,
considered in the aggregate, not material.

(xx) The information in the Prospectus under "Risk Factors," "We Intend to Continue to Pay Quarterly
Cash Dividends," "Regulation," "Taxation," "The Offering," "The Reorganization," "Restrictions on
Acquisition of Alliance Bancorp and Alliance Bank and Related Anti-Takeover Provisions" "Description
of Alliance Bancorp Capital Stock," and "Legal and Tax Opinions" to the extent that it constitutes
matters of law, summaries of legal matters, documents or proceedings, or legal conclusions, has been
reviewed by them and is complete and accurate in all material respects.

(xxi) There are no contracts, indentures, mortgages, loan agreements, notes, leases or other
instruments required to be described or referred to in the Registration Statement and Prospectus or
to be filed as exhibits thereto other than those described or referred to therein or filed as
exhibits thereto and the descriptions thereof or references thereto are correct, and no default
exists, and no event has

30
<!-- page 31 -->
occurred which, with notice or lapse of time or both, would constitute a default, in the due
performance or observance of any material obligation, agreement, covenant or condition contained in
any contract, indenture, mortgage, loan agreement, note, lease or other instrument so described,
referred to or filed.

(xxii) The approvals of the OTS, the FDIC and the Department of the Plans and the actions
contemplated thereunder remain in full force and effect, and the Agreement and Plan of
Reorganization has been approved by the requisite vote of the Bank's stockholders; the Company, the
MHCs and the Bank have conducted the Offerings in all material respects in accordance with
applicable requirements of the OTS Regulations, the Plans and all other applicable regulations,
decisions and orders thereunder, including all material applicable terms, conditions, requirements
and conditions precedent to the Offerings imposed upon the Company, the MHCs or the Bank by the OTS
and, no order has been issued by the OTS to suspend the Offerings and no action for such purpose has
been instituted or threatened by the OTS; and, to the best of such counsel's knowledge after due
inquiry, no person has sought to obtain review of the final action of the OTS, the Department or the
FDIC in approving the Plans and the actions contemplated thereunder.

(xxiii) To the best of such counsel's knowledge after due inquiry, the Company, the MHCs and the
Bank have obtained all licenses, permits and other governmental approvals and authorizations
currently required for the conduct of their respective businesses as described in the Registration
Statement and Prospectus, and all such licenses, permits and other governmental authorizations are
in full force and effect, and the Company, the MHCs, the Bank and the Subsidiaries are in all
material respects complying therewith.

(xxiv) (A) None of the Company, the MHCs, the Bank, or any of the Subsidiaries is in violation of
their respective certificates of incorporation, organization certificate, articles of incorporation
or charter, as the case may be, or bylaws and (B) to the best of such counsel's knowledge, the
Company, the MHCs, the Bank and the Subsidiaries are not in default (nor has any event occurred
which, with notice or lapse of time or both, would constitute a default) in the performance or
observance of any obligation, agreement, covenant or condition contained in any contract, indenture,
mortgage, loan agreement, note, lease or other instrument to which the Company, the MHCs, the Bank
or the Subsidiaries is a party or by which the Company, the MHCs, the Bank, the Subsidiaries or any
of their property may be bound.

31
<!-- page 32 -->
(xxv) The Company is in compliance with the applicable provisions of the Sarbanes-Oxley Act.

(xxvi) The Company is not and, upon completion of the Reorganization and Additional Stock Issuance
and the application of the net proceeds therefrom, will not be required to be registered as an
investment company under the Investment Company Act of 1940.

(2) The favorable opinion, dated as of Closing Time, of Malizia Spidi & Fisch, PC, counsel for the
Agent, with respect to the matters set forth in Section 5(b)(1)(i), (iv), (v), (vi), (ix), (xi),
(xiv) and (xvi) and such other matters as the Agent may reasonably require.

(3) In addition to giving their opinions required by subsections (b)(l) and (b)(2), respectively, of
this Section, Elias, Matz, Tiernan & Herrick L.L.P. and Malizia Spidi & Fisch, PC shall each
additionally state that nothing has come to their attention that would lead them to believe that the
Registration Statement (except for financial statements and schedules and other financial or
statistical data included therein, as to which counsel need make no statement), at the time it
became effective, or that the General Disclosure Package as of the Applicable Time, contained an
untrue statement of a material fact or omitted to state a material fact required to be stated
therein or necessary to make the statements therein not misleading or that the Prospectus (except
for financial statements and schedules and other financial or statistical data included therein, as
to which counsel need make no statement), at the time the Registration Statement became effective or
at Closing Time, included or includes an untrue statement of a material fact or omitted or omits to
state a material fact necessary in order to make the statements therein, in the light of the
circumstances under which they were made, not misleading.

In giving their opinions, Elias, Matz, Tiernan & Herrick L.L.P. and Malizia Spidi & Fisch, PC may
rely as to matters of fact on certificates of officers and directors of the Company, the MHCs, the
Bank and the Subsidiaries and certificates of public officials, and Malizia Spidi & Fisch, PC may
also rely on the opinion of Elias, Matz, Tiernan & Herrick L.L.P. with respect to matters set forth
in paragraphs (i), (iv), (v), (vi), (vii), (viii), (ix), (xi), (xiii), (xiv), (xv), (xvi) and
(xvii).

(c) At Closing Time referred to in Section 2, the Company, the MHCs and the Bank shall have
completed in all material respects the conditions precedent to the Reorganization and Additional
Stock Issuance in accordance with the Plans, the applicable OTS Regulations and all other applicable
laws, regulations, decisions and orders, including all terms, conditions, requirements and
provisions precedent to the Reorganization and Additional Stock Issuance imposed upon the Company,
the MHCs or the Bank by the OTS, or any other regulatory authority other than those which the OTS
permits to be completed after the Reorganization and Additional Stock Issuance.

(d) At Closing Time, there shall not have been, since the date hereof or since the respective dates
as of which information is given in the Registration Statement and the Prospectus,

32
<!-- page 33 -->
any material adverse change in the financial condition, results of operations, business affairs or
prospects of the Company, the MHCs, the Bank and the Subsidiaries, considered as one enterprise,
whether or not arising in the ordinary course of business consistent with past practice, and the
Agent shall have received a certificate of the President and Chief Executive Officer of the Company,
of the MHCs and of the Bank and the chief financial or chief accounting officer of the Company, of
the MHCs and of the Bank, dated as of Closing Time, to the effect that (i) there has been no such
material adverse change, (ii) there shall have been no material transaction entered into by the
Company, the MHCs or the Bank from the latest date as of which the financial condition of the
Company, the MHCs or the Bank, as set forth in the Registration Statement and the Prospectus other
than transactions referred to or contemplated therein and transactions in the ordinary course of
business consistent with past practice (iii) neither the Company, the MHCs nor the Bank shall have
received from the OTS any order or direction (oral or written) to make any material change in the
method of conducting its business with which it has not complied (which order or direction, if any,
shall have been disclosed in writing to the Agent) or which materially and adversely would affect
the business, financial condition, results of operations or prospects of the Company, the MHCs or
the Bank, considered as one enterprise, (iv) the representations and warranties in Section 1 hereof
are true and correct with the same force and effect as though expressly made at and as of the
Closing Time, (v) each of the Company, the MHCs and the Bank have complied with all agreements and
satisfied all conditions on their part to be performed or satisfied at or prior to Closing Time,
(vi) no stop order suspending the effectiveness of the Registration Statement has been issued and no
proceedings for that purpose have been initiated or threatened by the Commission, and (vii) no order
suspending the Subscription and Community Offering or Syndicated Community Offering or the
authorization for final use of the Prospectus has been issued and no proceedings for that purpose
have been initiated or threatened by the OTS and no person has sought to obtain regulatory or
judicial review of the action of the OTS in approving the Plans in accordance with the OTS
Regulations nor has any person sought to obtain regulatory or judicial review of the action of the
OTS in approving the Plans.

(e) At the Closing Time, the Agent shall have received a certificate of the Chief Executive Officer
and President of the Company, of the MHCs and of the Bank and the Chief Financial Officer of the
Company, of the MHCs and of the Bank, dated as of Closing Time, to the effect that (i) they have
reviewed the contents of the Registration Statement and the Prospectus; (ii) based on each of their
knowledge, the Registration Statement and the Prospectus do not contain any untrue statement of a
material fact or omit to state a material fact necessary in order to make the statements made
therein, in light of the circumstances under which such statements were made, not misleading; and
(iii) based on each of their knowledge, the financial statements and other financial information
included in the Registration Statement and the Prospectus fairly present the financial condition and
results of operations of the Bank and the Subsidiaries as of and for the dates and periods covered
by the Registration Statement and the Prospectus.

(f) At the time of the execution of this Agreement, the Agent shall have received from Deloitte &
Touche LLP a letter dated such date, in form and substance satisfactory to the Agent, to the effect
that: (i) they are independent public accountants with respect to the Company, the MHCs, the Bank
and the Subsidiaries within the meaning of the Code of Ethics of the AICPA, the Securities Act and
the Securities Act Regulations and the OTS Regulations, they are registered with the PCAOB, and they
are not in violation of the auditor independence requirements of the

33
<!-- page 34 -->
Sarbanes-Oxley Act; (ii) it is their opinion that the consolidated financial statements and
supporting schedules included in the Registration Statement and covered by their opinions therein
comply as to form in all material respects with the applicable accounting requirements of the
Securities Act and the Securities Act Regulations; (iii) based upon limited procedures as agreed
upon by the Agent and Deloitte & Touche LLP set forth in detail in such letter, nothing has come to
their attention which causes them to believe that (A) the unaudited consolidated financial
statements and supporting schedules of the Company included in the Registration Statement do not
comply as to form in all material respects with the applicable accounting requirements of the
Securities Act, the Securities Act Regulations and the OTS Regulations or are not presented in
conformity with generally accepted accounting principles applied on a basis substantially consistent
with that of the audited consolidated financial statements included in the Registration Statement
and the Prospectus, (B) the unaudited amounts of net interest income and net income set forth under
"Selected Financial and Other Data" in the Registration Statement and Prospectus do not agree with
the amounts set forth in unaudited consolidated financial statements as of and for the dates and
periods presented under such captions or such amounts were not determined on a basis substantially
consistent with that used in determining the corresponding amounts in the audited financial
statements included in the Registration Statement, (C) at a specified date not more than five (5)
business days prior to the date of this Agreement, there has been any increase in the consolidated
long-term or short-term debt of the Company or any decrease in consolidated total assets, the
allowance for loan losses, total deposits or net worth of the Company, in each case as compared with
the amounts shown in the consolidated statements of financial conditions included in the
Registration Statement or, (D) during the period from January 1, 2006 to a specified date not more
than five (5) business days prior to the date of this Agreement, there were any decreases, as
compared with the corresponding period in the preceding fiscal year, in total interest income, net
interest income, net interest income after provision for loan losses, income before income tax
expense or net income of the Company, except in all instances for increases or decreases which the
Registration Statement and the Prospectus disclose have occurred or may occur; and (iv) in addition
to the examination referred to in their opinions and the limited procedures referred to in clause
(iii) above, they have carried out certain specified procedures, not constituting an audit, with
respect to certain amounts, percentages and financial information which are included in the
Registration Statement and Prospectus and which are specified by the Agent, and have found such
amounts, percentages and financial information to be in agreement with the relevant accounting,
financial and other records of the Company, the MHCs and the Bank identified in such letter.

(g) At Closing Time, the Agent shall have received from Deloitte & Touche LLP a letter, dated as of
Closing Time, to the effect that they reaffirm the statements made in the letter furnished pursuant
to subsection (f) of this Section, except that the specified date referred to shall be a date not
more than five (5) days prior to Closing Time.

(h) At Closing Time, the Securities shall have been approved for quotation on the Nasdaq Global
Market upon notice of issuance.

(i) At Closing Time, the Agent shall have received a letter from the Appraiser, dated as of the
Closing Time, confirming its appraisal.

34
<!-- page 35 -->
(j) At Closing Time, counsel for the Agent shall have been furnished with such documents and
opinions as they may require for the purpose of enabling them to pass upon the issuance and sale of
the Securities as herein contemplated and related proceedings, or in order to evidence the accuracy
of any of the representations or warranties, or the fulfillment of any of the conditions, herein
contained; and all proceedings taken by the Company in connection with the issuance and sale of the
Securities as herein contemplated shall be satisfactory in form and substance to the Agent and
counsel for the Agent.

(k) At any time prior to Closing Time, (i) there shall not have occurred any material adverse change
in the financial markets in the United States or elsewhere or any outbreak of hostilities or
escalation thereof or other calamity or crisis the effect of which, in the judgment of the Agent, is
so material and adverse as to make it impracticable to market the Securities or to enforce
contracts, including subscriptions or orders, for the sale of the Securities, and (ii) trading
generally on either the American Stock Exchange, the New York Stock Exchange or the Nasdaq Stock
Market shall not have been suspended, and minimum or maximum prices for trading shall not have been
fixed, or maximum ranges for prices for securities have been required, by either of said Exchanges
or by order of the Commission or any other governmental authority, and a banking moratorium shall
not have been declared by either Federal, Pennsylvania or New York authorities.

35
<!-- page 36 -->
SECTION 6. INDEMNIFICATION.

(a) The Company, the MHCs and the Bank, jointly and severally, agree to indemnify and hold harmless
the Agent, each person, if any, who controls the Agent, within the meaning of Section 15 of the
Securities Act or Section 20 of the Exchange Act, and its respective partners, directors, officers,
employees and agents as follows:

(i) from and against any and all loss, liability, claim, damage and expense whatsoever, as incurred,
related to or arising out of the Offerings or any action taken by the Agent where acting as agent of
the Company, the MHCs or the Bank or otherwise as described in Section 2 hereof;

(ii) from and against any and all loss, liability, claim, damage and expense whatsoever, as
incurred, based upon or arising out of any untrue statement or alleged untrue statement of a
material fact contained in the Registration Statement (or any amendment thereto), or the omission or
alleged omission therefrom of a material fact required to be stated therein or necessary to make the
statements therein not misleading or arising out of any untrue statement or alleged untrue statement
of a material fact contained in the Prospectus (or any amendment or supplement thereto) or any
Issuer-Represented Free Writing Prospectus, or the omission or alleged omission therefrom of a
material fact necessary in order to make the statements therein, in the light of the circumstances
under which they were made, not misleading;

(iii) from and against any and all loss, liability, claim, damage and expense whatsoever, as
incurred, to the extent of the aggregate amount paid in settlement of any litigation, or any
investigation or proceeding by any governmental agency or body, commenced or threatened, or of any
claim whatsoever described in clauses (i) or (ii) above, if such settlement is effected with the
written consent of the Company, the MHCs or the Bank, which consent shall not be unreasonably
withheld; and

(iv) from and against any and all expense whatsoever, as incurred (including, subject to Section
6(c) hereof, the fees and disbursements of counsel chosen by the Agent), reasonably incurred in
investigating, preparing or defending against any litigation, or any investigation, proceeding or
inquiry by any governmental agency or body, commenced or threatened, or any claim pending or
threatened whatsoever described in clauses (i) or (ii) above, to the extent that any such expense is
not paid under clause (i), (ii) or (iii) above;

provided, however, that the indemnification provided for in this paragraph (a) shall not apply to
any loss, liability, claim, damage or expense to the extent arising out of any untrue statement or
alleged untrue statement of a material fact contained in the Prospectus (or any amendment or
supplement thereto) or any Issuer-Represented Free Writing Prospectus, or the omission or alleged
omission therefrom of a material fact necessary in order to make the statements therein, in the
light of the circumstances under which they were made, not misleading which was made in reliance
upon and in conformity with the Agent Information.

36
<!-- page 37 -->
(b) The Agent agrees to indemnify and hold harmless the Company, the MHCs and the Bank, their
directors, each of their officers who signed the Registration Statement, and each person, if any,
who controls the Company within the meaning of Section 15 of the Securities Act or Section 20 of the
Exchange Act against any and all loss, liability, claim, damage and expense described in the
indemnity contained in subsection (a) of this Section, as incurred, but only with respect to untrue
statements or omissions, or alleged untrue statements or omissions, of a material fact made in the
Prospectus (or any amendment or supplement thereto) or any Issuer-Represented Free Writing
Prospectus, in reliance upon and in conformity with the Agent Information.

(c) Each indemnified party shall give notice as promptly as reasonably practicable to each
indemnifying party of any action commenced against it in respect of which indemnity may be sought
hereunder, but failure to so notify an indemnifying party shall not relieve such indemnifying party
from any liability which it may have otherwise than on account of this indemnity agreement. An
indemnifying party may participate at its own expense in the defense of any such action. In no event
shall the indemnifying parties be liable for fees and expenses of more than one counsel (in addition
to no more than one local counsel in each separate jurisdiction in which any action or proceeding is
commenced) separate from their own counsel for all indemnified parties in connection with any one
action or separate but similar or related actions in the same jurisdiction arising out of the same
general allegations or circumstances.

(d) The Company, the MHCs and the Bank also agree that the Agent shall not have any liability
(whether direct or indirect, in contract or tort or otherwise) to the MHCs and its members, the
Bank, the Company's, the MHCs's or the Bank's creditors relating to or arising out of the engagement
of the Agent pursuant to, or the performance by the Agent of the services contemplated by, this
Agreement.

(e) In addition to, and without limiting, the provisions of Section (6)(a)(iv) hereof, in the event
that the Agent, any person, if any, who controls the Agent within the meaning of Section 15 of the
Securities Act or Section 20 of the Exchange Act or any of its partners, directors, officers,
employees or agents is requested or required to appear as a witness or otherwise gives testimony in
any action, proceeding, investigation or inquiry brought by or on behalf of or against the Company,
the MHCs, the Bank, the Agent or any of its respective affiliates or any participant in the
transactions contemplated hereby in which the Agent or such person or agent is not named as a
defendant, the Company, the MHCs, and the Bank, jointly and severally, agree to reimburse the Agent
and its partners, directors, officers, employees or agents for all reasonable and necessary
out-of-pocket expenses incurred by them in connection with preparing or appearing as a witness or
otherwise giving testimony and to compensate the Agent and its partners, directors, officers,
employees or agents in an amount to be mutually agreed upon.

SECTION 7. CONTRIBUTION. In order to provide for just and equitable contribution in circumstances in
which the indemnity agreement provided for in Section 6 hereof is for any reason held to be
unenforceable by the indemnified parties although applicable in accordance with its terms, the
Company, the MHCs, the Bank, and the Agent shall contribute to the aggregate losses, liabilities,
claims, damages and expenses of the nature contemplated by said indemnity agreement incurred by the
Company, the MHCs or the Bank and the Agent, as incurred, in such proportions (i) that the Agent is
responsible for that portion represented by the percentage that the maximum aggregate

37
<!-- page 38 -->
marketing fees appearing on the cover page of the Prospectus bears to the maximum aggregate gross
proceeds appearing thereon and the Company, the MHCs and the Bank are jointly and severally
responsible for the balance or (ii) if, but only if, the allocation provided for in clause (i) is
for any reason held unenforceable, in such proportion as is appropriate to reflect not only the
relative benefits to the Company, the MHCs and the Bank on the one hand and the Agent on the other,
as reflected in clause (i), but also the relative fault of the Company, the MHCs and the Bank on the
one hand and the Agent on the other, as well as any other relevant equitable considerations;
provided, however, that no person guilty of fraudulent misrepresentation (within the meaning of
Section 11(f) of the Securities Act) shall be entitled to contribution from any person who was not
guilty of such fraudulent misrepresentation. For purposes of this Section, each person, if any, who
controls the Agent within the meaning of Section 15 of the Securities Act or Section 20 of the
Exchange Act shall have the same rights to contribution as the Agent, and each director of the
Company, the MHCs and the Bank, each officer of the Company who signed the Registration Statement,
and each person, if any, who controls the Company, the MHCs or the Bank within the meaning of
Section 15 of the Securities Act or Section 20 of the Exchange Act shall have the same rights to
contribution as the Company, the MHCs and the Bank. Notwithstanding anything to the contrary set
forth herein, to the extent permitted by applicable law, in no event shall the Agent be required to
contribute an aggregate amount in excess of the aggregate marketing fees to which the Agent is
entitled and actually paid pursuant to this Agreement.

SECTION 8. REPRESENTATIONS, WARRANTIES AND AGREEMENTS TO SURVIVE DELIVERY. All representations,
warranties and agreements contained in this Agreement, or contained in certificates of officers of
the Company, the MHCs or the Bank submitted pursuant hereto, shall remain operative and in full
force and effect, regardless of any investigation made by or on behalf of the Agent or any
controlling person, or by or on behalf of the Company, and shall survive delivery of the Securities.

SECTION 9. TERMINATION OF AGREEMENT.

(a) The Agent may terminate this Agreement, by notice to the Company, at any time at or prior to
Closing Time (i) if there has been, since the date of this Agreement or since the respective dates
as of which information is given in the Registration Statement, any material adverse change in the
financial condition, results of operations, business affairs or prospects of the Company, the MHCs
or the Bank, considered as one enterprise, whether or not arising in the ordinary course of
business, (ii) if there has occurred any material adverse change in the financial markets in the
United States or elsewhere or any outbreak of hostilities or escalation thereof or other calamity or
crisis the effect of which, in the judgment of the Agent, is so material and adverse as to make it
impracticable to market the Securities or to enforce contracts, including subscriptions or orders,
for the sale of the Securities, (iii) if trading generally on the Nasdaq Global Market, the American
Stock Exchange or the New York Stock Exchange has been suspended, or minimum or maximum prices for
trading have been fixed, or maximum ranges for prices for securities have been required, by either
of said Exchanges or by order of the Commission or any other governmental authority, or if a banking
moratorium has been declared by either Federal, Pennsylvania or New York authorities, (iv) if any
condition specified in Section 5 shall not have been fulfilled when and as required to be fulfilled;
(v) if there shall have been such material adverse changes in the condition or prospects of the
Company, the MHCs or the Bank or the prospective market for the Company's Securities as in the
Agent's

38
<!-- page 39 -->
good faith opinion would make it inadvisable to proceed with the offering, sale or delivery of the
Securities; (vi) if, in the Agent's good faith opinion, the price for the Securities established by
the Appraiser is not reasonable or equitable under then prevailing market conditions, or (vii) if
the Offerings are not consummated on or prior to June 30, 2007.

(b) If this Agreement is terminated pursuant to this Section, such termination shall be without
liability of any party to any other party except as provided in Sections 2 and 4 hereof relating to
the reimbursement of expenses and except that the provisions of Sections 6 and 7 hereof shall
survive any termination of this Agreement.

SECTION 10. NOTICES. All notices and other communications hereunder shall be in writing and shall be
deemed to have been duly given if mailed or transmitted by any standard form of telecommunication.
Notices to the Agent shall be directed to the Agent at 919 Third Avenue, 6 Floor, New York, New York
10022, attention of General Counsel, with a copy to Malizia Spidi & Fisch, PC at 901 New York
Avenue, N.W., Suite 210 East, Washington, DC 20001; notices to the Company, the MHCs and the Bank
shall be directed to any of them at 541 Lawrence Road, Broomall, Pennsylvania 19008.

SECTION 11. PARTIES. This Agreement shall inure to the benefit of and be binding upon the Agent, the
Company, the MHCs and the Bank and their respective successors. Nothing expressed or mentioned in
this Agreement is intended or shall be construed to give any person, firm or corporation, other than
the Agent, the Company, the MHCs and the Bank and their respective successors and the controlling
persons and the partners, officers and directors referred to in Sections 6 and 7 and their heirs and
legal representatives, any legal or equitable right, remedy or claim under or in respect of this
Agreement or any provision herein or therein contained. This Agreement and all conditions and
provisions hereof and thereof are intended to be for the sole and exclusive benefit of the Agent,
the Company, the MHCs and the Bank and their respective successors, and said controlling persons,
partners, officers and directors and their heirs, partners, legal representatives, and for the
benefit of no other person, firm or corporation.

SECTION 12. ENTIRE AGREEMENT; AMENDMENT. This Agreement represents the entire understanding of the
parties hereto with reference to the transactions contemplated hereby and supersedes any and all
other oral or written agreements heretofore made, except for the engagement letter dated May 11,
2006, by and between the Agent and the Bank, relating to the Agent's providing conversion agent
services to the Company and the Bank. No waiver, amendment or other modification of this Agreement
shall be effective unless in writing and signed by the parties hereto.

SECTION 13. GOVERNING LAW AND TIME. This Agreement shall be governed by and construed in accordance
with the laws of the State of New York applicable to agreements made and to be performed in said
State without regard to the conflicts of laws provisions thereof. Unless otherwise noted, specified
times of day refer to Eastern time.

SECTION 14. SEVERABILITY. Any term or provision of this Agreement which is invalid or unenforceable
in any jurisdiction shall, as to that jurisdiction, be ineffective to the extent of such invalidity
or unenforceability without rendering invalid or unenforceable the remaining terms and provisions of
this Agreement or affecting the validity or enforceability of any of the terms or

39

th
<!-- page 40 -->
provisions of this Agreement in any other jurisdiction. If any provision of this Agreement is so
broad as to be unenforceable, the provision shall be interpreted to be only so broad as is
enforceable.

SECTION 15. HEADINGS. Sections headings are not to be considered part of this Agreement, are for
convenience and reference only, and are not to be deemed to be full or accurate descriptions of the
contents of any paragraph or subparagraph.

[The next page is the signature page]

40
<!-- page 41 -->
If the foregoing is in accordance with your understanding of our agreement, please sign and return
to the Company a counterpart hereof, whereupon this instrument, along with all counterparts, will
become a binding agreement between the Agent on the one hand, and the Company, the MHCs and the Bank
on the other in accordance with its terms.

Very truly yours,

Alliance Bancorp, Inc. of Pennsylvania

By:

Name:

Title:

Greater Delaware Valley Savings Bank

d/b/a Alliance Bank

By:

Name:

Title:

Greater Delaware Valley Holdings, A Mutual Company

By:

Name:

Title:

Alliance Mutual Holding Company

By:

Name:

Title:

CONFIRMED AND ACCEPTED,

as of the date first above written:

SANDLER O'NEILL & PARTNERS, L.P.

By:

Sandler O'Neill & Partners Corp., the sole general partner

By:

Name:

Title:
