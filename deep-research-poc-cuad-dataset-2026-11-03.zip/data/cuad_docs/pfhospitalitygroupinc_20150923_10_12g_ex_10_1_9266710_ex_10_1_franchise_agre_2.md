<!-- page 1 -->
# SAMPLE OF NON-DISCLOSURE AND NON-COMPETITION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Franchise Agreement |
| SEC Filing Date | 2015-09-23 |
| Parties | [] ("Franchisee"); [] ("Member") |
| Source | CUAD v1 / PfHospitalityGroupInc_20150923_10-12G_EX-10.1_9266710_EX-10.1_Franchise Agreement3 |

APPENDIX C SAMPLE OF NON-DISCLOSURE AND NON-COMPETITION AGREEMENT (BETWEEN FRANCHISEE AND ITS
PERSONNEL) THIS SAMPLE OF NON-DISCLOSURE AND NON-COMPETITION AGREEMENT ( "Agreement") is made this
_____ day of _________, 20___, by and between ___________________________ (the "Franchisee"), and
___________________________, who is an officer, director, or employee of Franchisee (the "Member").
RECITALS: WHEREAS, __________________ ("Franchisor") has developed a distinctive set of
specifications and operating procedures (collectively, the "System") for the operation of "Pizza
Fusion" restaurant businesses ("Franchised Businesses"). WHEREAS, Franchisor and Franchisee have
executed a Franchise Agreement ("Franchise Agreement") granting Franchisee the right to operate a
Franchised Business under the terms and conditions of the Franchise Agreement; WHEREAS, the Member,
by virtue of his or her position with Franchisee, will gain access to certain of Franchisor's
Confidential Information, as defined herein, and must therefore be bound by the same confidentiality
and non-competition agreement that Franchisee is bound by. IN CONSIDERATION of these premises, the
conditions stated herein, and for other good and valuable consideration, the sufficiency and receipt
of which are hereby acknowledged, the parties agree as follows: 1. Confidential Information. Member
shall not, during the term of the Franchise Agreement or thereafter, communicate, divulge or use,
for any purpose other than the operation of the Franchised Business, any confidential information,
knowledge, trade secrets or know-how which may be communicated to Member or which Member may learn
by virtue of Member's relationship with Franchisee. All information, knowledge and know-how relating
to Franchisor, its business plans, Franchised Businesses, or the System ("Confidential Information")
is deemed confidential, except for information that Member can demonstrate came to Member's
attention by lawful means prior to disclosure to Member; or which, at the time of the disclosure to
Member, had become a part of the public domain. 2. Covenants Not to Compete. (a) Member specifically
acknowledges that, pursuant to the Franchise Agreement, and by virtue of its position with
Franchisee, Member will receive valuable specialized training and Confidential Information,
including, without limitation, information regarding the operational, sales, promotional, and
marketing methods and techniques of Franchisor and the System. (b) Member covenants and agrees that
during the term of the Franchise Agreement, except as otherwise approved in writing by Franchisor,
Member shall not, either directly or indirectly, for itself, or through, on behalf of, or in
conjunction with any person, persons, partnership, corporation, or entity: (i) Own, manage, engage
in, be employed by, advise, make loans to, consult for, rent or lease to, or have any other interest
in business that (directly or indirectly) operates, or grants franchises or licenses to operate, a
restaurant featuring pizza and related food specialties or that offers products or services
substantially similar to those then offered by Pizza Fusions Restaurants ("Competitive Business"); C
- 1

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 2 -->
(ii) Divert or attempt to divert any business or customer, or potential business or customer, to any
Competitive Business; or (iii) Induce any person to leave his or her employment with Franchisee or
Franchisor. (c) Member covenants and agrees that during the Post-Term Period (defined below), except
as otherwise approved in writing by Franchisor, Member shall not, either directly or indirectly,
own, manage, engage in, be employed by, advise, make loans to, consult for, or have any other
interest in any Competitive Business that is, or intends to operate, within a three (3) mile radius
of the premises of your Franchised Business or within a three (3) mile radius of any Franchised
Business then-operating or under construction to operate under the System. (d) As used in this
Agreement, the term "Post-Term Period" shall mean a continuous uninterrupted period of two (2) years
from the date of: (a) a transfer permitted under Section 14 of the Franchise Agreement; (b)
expiration or termination of the Franchise Agreement (regardless of the cause for termination); (c)
termination of Member's employment with Franchisee; and/or (d) a final order of a duly authorized
arbitrator, panel of arbitrators, or a court of competent jurisdiction (after all appeals have been
taken) with respect to any of the foregoing or with respect to the enforcement of this Agreement;
either directly or indirectly (through, on behalf of, or in conjunction with any persons,
partnership, corporation or entity). 3. Injunctive Relief. Member acknowledges that any failure to
comply with the requirements of this Agreement will cause Franchisor irreparable injury, and Member
agrees to pay all court costs and reasonable attorney's fees incurred by Franchisor in obtaining
specific performance of, or an injunction against violation of, the requirements of this Agreement.
4. Severability. All agreements and covenants contained herein are severable. If any of them, or any
part or parts of them, shall be held invalid by any court of competent jurisdiction for any reason,
then the Member agrees that the court shall have the authority to reform and modify that provision
in order that the restriction shall be the maximum necessary to protect Franchisor's and/or
Franchisee's legitimate business needs as permitted by applicable law and public policy. In so
doing, the Member agrees that the court shall impose the provision with retroactive effect as close
as possible to the provision held to be invalid. 5. Delay. No delay or failure by the Franchisor or
Franchisee to exercise any right under this Agreement, and no partial or single exercise of that
right, shall constitute a waiver of that or any other right provided herein, and no waiver of any
violation of any terms and provisions of this Agreement shall be construed as a waiver of any
succeeding violation of the same or any other provision of this Agreement. 6. Third-Party
Beneficiary. Member hereby acknowledges and agrees that Franchisor is an intended third-party
beneficiary of this Agreement with the right to enforce it, independently or jointly with
Franchisee. C - 2

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
<!-- page 3 -->
IN WITNESS WHEREOF, the Franchisee and the Member attest that each has read and understands the
terms of this Agreement, and voluntarily signed this Agreement on the date first written above.
FRANCHISEE MEMBER By: By: Name: Name: Title: Title: C - 3

Source: PF HOSPITALITY GROUP INC., 10-12G, 9/23/2015
