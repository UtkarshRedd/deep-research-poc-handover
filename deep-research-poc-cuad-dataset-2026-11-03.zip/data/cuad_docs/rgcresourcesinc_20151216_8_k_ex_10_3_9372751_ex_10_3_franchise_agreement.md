<!-- page 1 -->
# GAS FRANCHISE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Franchise Agreement |
| Agreement Date | 2015-11-17 |
| Parties | TOWN OF VINTON, VIRGINIA ("Grantor"); ROANOKE GAS COMPANY ("Grantee") |
| Source | CUAD v1 / RgcResourcesInc_20151216_8-K_EX-10.3_9372751_EX-10.3_Franchise Agreement |

Exhibit 10.3

GAS FRANCHISE AGREEMENT

THIS AGREEMENT ("Agreement"), made and entered into this 17th day of November, 2015, by and between
the TOWN OF VINTON, VIRGINIA, a Virginia municipal corporation ("Grantor"), and ROANOKE GAS COMPANY,
a Virginia corporation ("Grantee").

WHEREAS, Grantor has reviewed the proposal for a Gas Franchise of Grantee; and

WHEREAS, Grantor, at a duly authorized and regular meeting of its Town Council, did vote to grant a
renewal of the Gas Franchise to Grantee pursuant to provisions of the State Code and Town Charter.

NOW, THEREFORE, in consideration of said grant of renewal of the Gas Franchise, the parties agree as
follows:

1. GRANT. Grantor hereby grants to Grantee and Grantee hereby accepts a franchise to construct,
reconstruct, operate, maintain, repair, and extend a Gas Distribution System within Grantor's
Territorial Limits in accordance with the terms and conditions set forth below ("Franchise"). The
Franchise is granted pursuant to Grantor's Franchise Ordinance (Ordinance No. 967), adopted November
17, 2015, ("Ordinance"), which is incorporated by reference herein, including any applicable
definitions.

2. TERM. The term of the Franchise shall be twenty (20) years, commencing on January 1, 2016.

3. FRANCHISE FEE.

(a) Grantee shall pay to Grantor a Franchise Fee which shall be calculated pursuant to this Section.
It is understood that Grantee has or will enter into franchise agreements with the City of Roanoke
("Roanoke") and the City of Salem ("Salem") and the Town of Vinton ("Vinton") (Grantor, Roanoke and
Salem being hereinafter sometimes collectively referred to as the "localities" and singularly as a
"locality") with fee provisions identical to this one, and that the total annual Franchise Fee to be
paid to the three localities in aggregate is $98,196 for calendar year 2016 ("base year total annual
Franchise Fee"). Grantor's Franchise Fee shall be a percentage share of the base year total annual
Franchise Fee, which shall be determined on a pro rata basis according to its percentage share of
the total dollar value of Grantee's gas sales occurring within the localities during the calendar
year. For each calendar year of the Franchise, each locality's percentage share shall be determined
by the following formula:

total dollar value of Grantee's gas sales within Locality's percentage share = the Territorial
Limits of the locality total dollar value of Grantee's gas sales in the three localities

For calendar year 2016, the Franchise Fee shall be paid to Grantor on or before March 31, 2017.

1

Source: RGC RESOURCES INC, 8-K, 12/16/2015
<!-- page 2 -->
(b) For each succeeding calendar year during the term of this Franchise, the total annual Franchise
Fee paid by Grantee to the localities shall be the base year total annual Franchise Fee increased by
three (3) percent compounded annually over the term of the Franchise. For each calendar year during
the term of this Franchise, Grantor's percentage share shall be determined pursuant to this Section,
and paid to Grantor on or before March 31 of the succeeding calendar year.

4. BUSINESS OFFICE. Grantee shall during the term of this Franchise maintain at least one business
office within the Territorial Limits of Grantor. Such office shall be open at least forty (40) hours
per week for the conduct of business between Grantee and its customers.

5. NONDISCRIMINATION. Grantee shall not discriminate on the basis of race, religion, color, sex,
national origin, age, disability, or any other basis prohibited by state law relating to
discrimination in employment, except where there is a bona fide occupational qualification
reasonably necessary to the normal operation of the Grantee.

6. NOTICE. All notices required under this Agreement or the Ordinance shall be in writing and shall
be deemed validly given, unless otherwise required, when sent by certified mail, return receipt
requested, or by a nationally recognized overnight courier, addressed as follows (or any other
address the party to be notified may have designated to the sender by like notice):

Grantor: Grantee:

Town of Vinton Roanoke Gas Company Attention: Town Manager Attention: President 311 S. Pollard
Street 519 Kimball Avenue, N.E. Vinton, Virginia 24179 P.O. Box 13007 Roanoke, Virginia 24030

The parties may, by notice given under this Section, designate such other addresses as they may deem
appropriate for the receipt of notices under this Agreement.

7. EFFECTIVE DATE. The effective date of the Franchise will be January 1, 2016.

SIGNATURES APPEAR ON FOLLOWING PAGES

2

Source: RGC RESOURCES INC, 8-K, 12/16/2015
<!-- page 3 -->
IN WITNESS WHEREOF, the parties hereto have signed this Agreement by their authorized
representatives.

WITNESS: ROANOKE GAS COMPANY

/s/ Diane L. Conner By /s/ John S. D'Orazio John S. D'Orazio, President and CEO Diane L. Conner,
Assistant to CEO 12/14/2015 Printed Name and Title

WITNESS: TOWN OF VINTON, VIRGINIA

/s/ Susan N. Johnson By /s/ Christopher S. Lawrence Christopher S. Lawrence, Town Manager Susan N.
Johnson, Town Clerk Printed Name and Title

3

Source: RGC RESOURCES INC, 8-K, 12/16/2015
