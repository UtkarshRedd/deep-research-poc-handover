<!-- page 1 -->
# Office Lease — Halvorsen Marine Holdings, Inc. (Tenant)
| Field | Value |
|---|---|
| Document Type | Lease |
| Effective Date | 2024-11-01 |
| Parties | Harbor Way Properties LLC; Halvorsen Marine Holdings, Inc. |

THIS OFFICE LEASE (this "Lease") is made as of 2024-11-01 between Harbor Way Properties LLC ("Landlord") and Halvorsen Marine Holdings, Inc. ("Tenant") for Suite 400 at 1200 Harbor Way, Seattle, Washington.
<!-- page 2 -->
## 1. Premises and Term
Landlord leases to Tenant approximately 18,250 rentable square feet on the fourth floor (the "Premises") for a term of ten (10) years commencing 2025-01-01.
## 2. Rent
Base Rent is $62,500 per month for the first lease year, increasing 3% annually.
<!-- page 3 -->
## 3. Use; Assignment
Tenant shall use the Premises for general office purposes only. Tenant shall not assign this Lease without Landlord's prior written consent.
## 4. Default
Failure to pay Rent within five (5) days after written notice constitutes an Event of Default under this Lease.
<!-- page 4 -->
## 5. Notices; Governing Law
Notices to Tenant: 1200 Harbor Way, Suite 400, Seattle, Washington 98101, Attention: Facilities. Notices to Landlord: 700 Fifth Avenue, Suite 5600, Seattle, Washington 98104.
This Lease is governed by the laws of the State of Washington.
