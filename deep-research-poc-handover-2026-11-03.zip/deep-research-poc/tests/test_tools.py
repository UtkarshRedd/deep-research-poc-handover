"""Deterministic tests for the foundation (no model calls)."""
from pathlib import Path, PureWindowsPath

import pytest

from dr.evidence import EvidenceBank
from dr.ingest.load import load_dir
from dr.ingest.metadata import parse_metadata_block
from dr.models import DocRecord, EvidenceItem
from dr.tools import grep as grep_mod
from dr.tools import manifest as manifest_mod
from dr.tools import outline as outline_mod
from dr.tools import read as read_mod
from dr.verify.tier1 import align_quote, verify_bank
from dr.workspace import Workspace

SAMPLE = Path(__file__).resolve().parents[1] / "data" / "sample_docs"


@pytest.fixture()
def ws(tmp_path):
    docs = load_dir(SAMPLE)
    assert len(docs) == 3
    return Workspace.materialize(docs, tmp_path / "ws")


def _id(ws, title_part):
    return next(d for d, m in ws.manifest.items() if title_part in m.title)


# --------------------------------------------------------------------------- ingest / manifest

def test_metadata_parsed_from_table_and_kv():
    text = (SAMPLE / "acme_credit_agreement.md").read_text()
    meta = parse_metadata_block(text)
    assert meta["doc_type"] == "Credit Agreement"
    assert meta["date"] == "2024-03-15"
    assert "First National Bank" in meta["parties"]
    text_b = (SAMPLE / "acme_first_amendment.md").read_text()
    meta_b = parse_metadata_block(text_b)
    assert meta_b["doc_type"] == "Amendment" and meta_b["date"] == "2025-01-10"


def test_manifest_and_page_index(ws):
    a = _id(ws, "Credit Agreement — Acme Industrial LLC")
    me = ws.manifest[a]
    assert me.n_pages == 3 and me.doc_type == "Credit Agreement"
    assert ws.page_of(a, 1) == 1
    assert ws.page_of(a, me.n_lines) == 3
    assert "Leverage Ratio" in ws.page_text(a, 2)


def test_list_docs_filters(ws):
    rows, total = manifest_mod.list_docs(ws, doc_type="Amendment")
    assert total == 1 and rows[0].date == "2025-01-10"
    rows, total = manifest_mod.list_docs(ws, date_from="2025-01-01")
    assert total == 1
    rows, total = manifest_mod.list_docs(ws, party_contains="first national")
    assert total == 3


# --------------------------------------------------------------------------- grep

def test_grep_counts_complete_and_matches_capped(ws):
    res = grep_mod.grep(ws, r"Leverage Ratio", max_matches=1)
    assert res.total_matches == 3 and res.docs_with_matches == 3
    assert len(res.matches) == 1 and res.matches_truncated is True
    assert res.matches[0].page is not None
    txt = grep_mod.render(res)
    assert "counts:" in txt and "3 matches in 3 docs" in txt


def test_grep_exact_identifier_and_scope(ws):
    res = grep_mod.grep(ws, r"FAC-2024-0117")
    assert res.docs_with_matches == 2
    amend = _id(ws, "First Amendment")
    res2 = grep_mod.grep(ws, r"FAC-2024-0117", doc_ids=[amend])
    assert res2.docs_with_matches == 1 and res2.matches[0].doc_id == amend


def test_grep_bad_regex_falls_back_to_literal(ws):
    res = grep_mod.grep(ws, r"$25,000,000 (")  # unbalanced paren -> literal search
    assert res.total_matches == 0  # literal '$25,000,000 (' does not occur
    res = grep_mod.grep(ws, r"\$25,000,000")
    assert res.total_matches == 2


def test_rg_output_parsed_with_native_separators(ws, monkeypatch):
    """rg prints OS-native paths; Windows backslashes must map to doc_ids like POSIX slashes."""
    ids = ws.doc_ids()
    win_docs = PureWindowsPath("C:/work/ws/docs")   # str() renders with backslashes on any OS
    out = "\n".join([
        str(win_docs / f"{ids[0]}.md"),
        f"/tmp/ws/docs/{ids[1]}.md",
        str(win_docs.parent / "manifest.json"),   # not a doc
        "",
    ])
    assert grep_mod._doc_ids_from_rg_output(out) == {ids[0], ids[1]}

    class Proc:
        returncode = 0
        stdout = out

    monkeypatch.setattr(grep_mod.shutil, "which", lambda name: "rg")
    monkeypatch.setattr(grep_mod.subprocess, "run", lambda *a, **k: Proc())
    assert grep_mod._rg_candidate_docs(ws, "anything", True) == {ids[0], ids[1]}


def test_grep_rg_prefilter_scopes_large_workspace(tmp_path, monkeypatch):
    """Above 200 docs grep pre-filters with rg. With Windows-style paths the old parser
    emptied the scope and every grep returned zero matches."""
    docs = [
        DocRecord(doc_id=f"d{i:04d}", title=f"Doc {i}", text=f"<!-- page 1 -->\nline {i}\nNEEDLE-{i % 2}\n")
        for i in range(250)
    ]
    ws_big = Workspace.materialize(docs, tmp_path / "big")
    seen_cmds = []

    class Proc:
        returncode = 0
        stdout = "\n".join(  # even docs only, as Windows-style paths
            str(PureWindowsPath("C:/ws/docs") / f"d{i:04d}.md") for i in range(0, 250, 2)
        )

    def fake_run(cmd, **kwargs):
        seen_cmds.append(cmd)
        return Proc()

    monkeypatch.setattr(grep_mod.shutil, "which", lambda name: "rg")
    monkeypatch.setattr(grep_mod.subprocess, "run", fake_run)
    res = grep_mod.grep(ws_big, r"NEEDLE-0")
    assert res.docs_with_matches == 125 and res.total_matches == 125
    assert "-F" not in seen_cmds[-1]
    # invalid regex -> literal fallback on the Python side must be mirrored to rg with -F
    grep_mod.grep(ws_big, r"NEEDLE-0 (")
    assert "-F" in seen_cmds[-1]


# --------------------------------------------------------------------------- read

def test_read_caps_and_tracker(ws):
    a = _id(ws, "Credit Agreement — Acme Industrial LLC")
    tr = read_mod.ReadTracker()
    r = read_mod.read(ws, a, 1, 5000, tracker=tr)
    assert r.end_line - r.start_line + 1 <= ws.cfg.tools.READ_MAX_LINES
    assert r.page_start == 1 and "| " in r.text
    again = read_mod.read(ws, a, 1, 5, tracker=tr)
    assert again.already_read is True and again.text == ""
    assert "already read" in read_mod.render(again)
    assert tr.docs_read() == [a] and tr.lines_read() == r.end_line - r.start_line + 1


def test_read_rejects_path_escape(ws):
    with pytest.raises((PermissionError, KeyError)):
        ws.path_of("../manifest")
    with pytest.raises((PermissionError, KeyError)):
        ws.path_of("/etc/passwd")
    with pytest.raises(KeyError):
        ws.path_of("deadbeefdeadbeef")


# --------------------------------------------------------------------------- outline

def test_outline_headings_with_pages(ws):
    a = _id(ws, "Credit Agreement — Acme Industrial LLC")
    o = outline_mod.outline(ws, a)
    heads = [(i.heading, i.page) for i in o.items]
    assert ("4. Termination", 3) in heads
    assert outline_mod.render(o).startswith("outline ")


# --------------------------------------------------------------------------- evidence bank

def test_evidence_add_requires_verbatim_and_dedupes(ws):
    a = _id(ws, "Credit Agreement — Acme Industrial LLC")
    bank = EvidenceBank(ws)
    lines = ws.lines(a)
    ln = next(i for i, l in enumerate(lines, 1) if "3.50 to 1.00" in l)
    it = bank.add(a, ln, ln, "Leverage Ratio not exceeding 3.50 to 1.00", "original covenant")
    assert it.id == "e1" and it.page == 2
    dup = bank.add(a, ln, ln, "Leverage Ratio not exceeding 3.50 to 1.00", "same thing")
    assert dup.id == "e1" and len(bank) == 1
    with pytest.raises(ValueError):
        bank.add(a, ln, ln, "Leverage Ratio not exceeding 9.99 to 1.00", "fabricated")
    # persisted and reloadable
    bank2 = EvidenceBank(ws)
    assert len(bank2) == 1 and bank2.get("e1").quote.startswith("Leverage")
    assert "[e1]" in bank2.render_for_writer()
    assert bank2.citation_for("e1") == f"[{a} p.2]"


# --------------------------------------------------------------------------- tier-1 alignment

def test_align_quote_keep_truncate_drop():
    src = "Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00. Termination requires ninety days notice."
    st, sc, _ = align_quote("maintain a Leverage Ratio not exceeding 3.50 to 1.00", src, 5, 0.7, 0.4)
    assert st == "keep" and sc == 1.0
    # partly fabricated tail (~45% of n-grams unsupported) -> truncate to the aligned span
    st, sc, span = align_quote("maintain a Leverage Ratio not exceeding 3.50 to 1.00 and pay a fee", src, 5, 0.7, 0.4)
    assert st == "truncate" and 0.4 <= sc < 0.7 and span and "leverage ratio" in span
    # mostly fabricated -> drop even though a real fragment is embedded
    st, sc, _ = align_quote("maintain a Leverage Ratio not exceeding 3.50 to 1.00 and pay a fee of 2 percent quarterly", src, 5, 0.7, 0.4)
    assert st == "drop" and sc < 0.4
    st, sc, _ = align_quote("the moon is made of cheese and tastes great", src, 5, 0.7, 0.4)
    assert st == "drop" and sc == 0.0


def test_verify_bank_relocates_misattributed_quote(ws):
    a = _id(ws, "Credit Agreement — Acme Industrial LLC")
    amend = _id(ws, "First Amendment")
    bank = EvidenceBank(ws)
    # a quote that truly lives in the amendment, but mis-cited to the original (bypass add() guard)
    bad = EvidenceItem(id="e9", doc_id=a, page=1, start_line=1, end_line=2,
                       quote="Section 3 is amended to read: Borrower shall maintain a Leverage Ratio not exceeding 4.00 to 1.00.")
    res = verify_bank(ws, [bad])
    assert res["e9"].status == "drop"
    assert res["e9"].relocated_doc_id == amend
    assert bad.tier1_status == "drop"
