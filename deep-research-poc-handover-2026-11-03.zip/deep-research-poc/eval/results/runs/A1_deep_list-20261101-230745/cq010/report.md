# Which jurisdiction's law governs the Manufacturing Agreement between Electrameccanica V...

*Question:* Which jurisdiction's law governs the Manufacturing Agreement between Electrameccanica Vehicles Corp and Chongqing Zongshen Automobile Industry Co., LTD.?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Identify parties and document type

[GAP] The writer produced nothing for: Confirm the Manufacturing Agreement between Electrameccanica Vehicles Corp and Chongqing Zongshen Automobile Industry Co., LTD.

## Not established by the evidence

[GAP] No evidence was found for: Establish the explicit choice-of-law provision in the Manufacturing Agreement

[GAP] No evidence was found for: Establish which jurisdiction's law is specified as governing the agreement based on the identified clause

## Verification appendix

Claims: 3 · supported: 0 · partially: 0 · dropped: 0 · gaps: 3

Notes: 2 empty section(s) collapsed into gaps: Identify governing law clause; Determine governing jurisdiction; OpenAIRateLimitError: Error code: 429

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  |  |
| gaps.1 | gaps | gap |  |  |  |
| gaps.2 | gaps | gap |  |  |  |

### Evidence

