<!-- page 1 -->
# ENDORSEMENT AGREEMENT ADDENDUM I
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2017-11-07 |
| Parties | National Football League Alumni - Northern California Chapter ("NFLA-NC"); National Football League Alumni, Inc ("NFLA"); Food For Athletes, Inc./ Gridiron Gridiron BioNutrients™ (collectively, the "Company") |
| Source | CUAD v1 / GridironBionutrientsInc_20171206_8-K_EX-10.2_10972556_EX-10.2_Endorsement Agreement |

EXHIBIT 10.2 ENDORSEMENT AGREEMENT ADDENDUM I This Endorsement Agreement Addendum I (the "Addendum")
is made and effective November 7, 2017, BETWEEN:

National Football League Alumni - Northern California Chapter ("NFLA-NC"), a charitable corporation
organized under the laws of California, having its principal office at 1311 Madison Avenue, Redwood
CA 94061; National Football League Alumni, Inc. ("NFLA"), a charitable corporation organized under
the laws of Florida, having its principal office at 8000 Midlantic Drive, 130 S., Mount Laurel, NJ.
08054. AND: Food For Athletes, Inc. a corporation organized under the laws of California / Gridiron
BioNutrients™, a corporation organized under the laws of Nevada having their principal office(s) at
1147 N Roseburg CT, STE A/B Visalia, CA 93291 (collectively the "Company"). RECITALS The NFLA,
NFLA-NC and the Company (collectively the "Parties") agree that this Addendum I shall be affixed and
be enforceable under the terms of the Endorsement Agreement executed by the Parties on October 30,
2017. Parties agree to the addition of Gridiron CBD H2O Probiotic™ Water to "Licensed Products" as
follows: SECTION ONE. DEFINITIONS As used in this Agreement, the following terms shall be defined as
follows: F. "Licensed Products" shall mean BlackMP Living Water, BlackMP Concentrate, Zezel
Probiotic Water, Zayin Sports Water, Gridiron CBD H2O Probiotics™ Water, Gridiron MVP™ and Gridiron
MVP™ Concentrate using the Pro Football Legends Logo on the Licensed Products' affixed labels,
hang-tags or packaging. Other products of the Company may be added to the list of Licensed Products
during the Contract Period by written amendment to this Agreement. All amendments to this Agreement
must be signed by all parties to this Agreement. Endorsement Agreement Addendum I Page 1 of 2

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
<!-- page 2 -->
SECTION FOUR. REMUNERATION C. A *donation of $0.05 per Unit sold of Licensed Products within the
Contract Territory payable to the **NFL Alumni Northern California Chapter. Donated amounts will be
allocated and dispersed to the Northern California Chapter beginning on the first full quarter
[three (3) month period] of the Agreement and continue on a quarterly basis thereafter for the term
of this Agreement. Where the following per Unit conversion shall apply for the term of this
Agreement:

a. (1) Bottle of BlackMP LivingWater = 1 Unit

b. (1) 4oz bottle of BlackMPConcentrate = 30 Units

c. (1) Bottle of Zezel ProbioticWater = 1 Unit

d. (1) Bottle of Zayin Sports Water = 1 Unit e. (1) Bottle Gridiron MVP™ Water= 1 Unit

f. (1) Bottle Gridiron CBD H20 Probiotics™ Water = 1 Unit

g. (1) 4oz bottle of Gridiron MVP™Concentrate = 30 Units

_____________ * The NFLA-NC will donate 15% of the above described proceeds to the NFLA. ** The
Company will provide to the NFLA-NC upon request the most recent quarterly sales report of the
Company's Licensed Products. The parties have executed this Agreement on November 22nd, 2017. Food
For Athletes, Inc. / Gridiron BioNutrients™ By: /s/ Darren Long Darren Long - CEO The National
Football League Alumni, Inc. By: /s/ Elvis Gooden Elvis Gooden - President NFL Alumni - Northern
California Chapter By: /s/ Eric Price Eric Price - President Endorsement Agreement Addendum I Page 2
of 2

Source: GRIDIRON BIONUTRIENTS, INC., 8-K, 12/6/2017
