<!-- page 1 -->
# Outsourcing Agreement
| Field | Value |
|---|---|
| Document Type | Outsourcing Agreement |
| Agreement Date | 2006-05-01 |
| Parties | Virtual Item Processing Systems, Inc. ("VIP"); Brokers National Life Assurance Company ("BNL") |
| Source | CUAD v1 / BNLFINANCIALCORP_03_30_2007-EX-10.8-OUTSOURCING AGREEMENT |

VIRTUAL ITEM PROCESSING SYSTEMS, INC. 2525 Northwest Expressway, #105 Oklahoma City, Oklahoma 73112

OUTSOURCING AGREEMENT BETWEEN VIRTUAL ITEM PROCESSING SYSTEMS, INC. And BROKERS NATIONAL LIFE
ASSURANCE COMPANY

E - 4
<!-- page 2 -->
OUTSOURCING AGREEMENT This Outsourcing Agreement (" Agreement") is executed as of this 1 st day of
May 2006, by and between Virtual Item Processing Systems, Inc. ("VIP"), with its principal place of
office at 2525 NW Expressway, Suite 105 Oklahoma City, Oklahoma 73112, and Brokers National Life
Assurance Company ("BNL"), with its principal place of office at 7010 Hwy. 71 W., Suite 100, Austin,
Texas 78735. WHEREAS, VIP is engaged in the business of providing Electronic Data Processing
services ("EDP Services") and related consultation and services to insurance companies pursuant to
computer software systems developed and owned by VIP , (the "VIP System"); WHEREAS, BNL is an
insurance company domiciled in the State of Arkansas and licensed to do business in numerous
additional states; and WHEREAS, VIP desires to provide EDP Services to BNL; and WHEREAS, BNL desires
to obtain EDP services from VIP for the processing and administration of its insurance policies;
NOW, THEREFORE, in consideration of the above premises and in consideration of other good and
valuable consideration, the receipt and sufficiency is hereby acknowledged, the parties agree as
follows: 1. PURCHASE OF EQUIPMENT. BNL at its expense shall obtain, install, maintain and upgrade as
necessary any and all hardware, software, data and telephone lines, other communications equipment
and any other equipment (hereinafter collectively referred to as the "Equipment") which it
determines is necessary to allow it to use and access the VIP System pursuant to the terms of this
Agreement. Such Equipment shall be fully compatible with the VIP System. VIP will provide BNL such
information as is reasonably necessary to allow BNL to acquire all such Equipment which meets the
requirements of this paragraph. If requested by BNL and at BNL's expense, VIP shall inspect all such
Equipment and acknowledge its compatibility in writing prior to its use with the VIP System. 2.
VIP's EQUIPMENT AND SERVICES. A. During the term of this Agreement, VIP shall provide BNL such
access as necessary to the VIP System to allow BNL to attach one data communication line and up to
seventy (70) addressable data communications devices to said VIP System. Should BNL desire to attach
additional communication lines or additional communication devices to the VIP System, BNL shall pay
to VIP the additional fees set forth in paragraph 5(F) of this Agreement. B. VIP, at its sole
discretion and expense, may, but is not obligated to, make appropriate enhancements to the VIP
System. Any such enhancements shall be deemed to be included in the EDP Services and VIP System to
be provided to BNL, whether developed by VIP before or during the time when services are to be
provided by VIP pursuant to this Agreement. During the term of this Agreement, VIP shall be
responsible at its expense for the proper maintenance and documentation of the VIP System. 3
.SCHEDULED AND UNSCHEDULED DOWN TIME. BNL acknowledges that there will be scheduled downtime for the
routine preventive maintenance of VIP's System performed by either VIP or its vendors. VIP shall
give BNL reasonable advance notice of all such scheduled downtime. BNL further acknowledges that
there will also be unscheduled down-time that might occur as a result of electrical power failures
and equipment failures and other acts outside of the control of VIP as contemplated in paragraph
16(J). In the event that any such down-time extends for more than two (2) consecutive working days,
VIP, at its expense, will make available to BNL access to a backup facility designated by VIP for
the continued processing of BNL's business. To ensure that a backup facility will be available in

E - 5
<!-- page 3 -->
case of such a failure, VIP will maintain disaster and/or business interruption insurance adequate
to establish alternate site processing, as provided for in paragraph 12(A) of this Agreement. 4.
INCLUDED SERVICES IN THE VIP SYSTEM. It is agreed and understood by BNL that: A. It has reviewed and
inspected the VIP System existing as of the Effective Date of this Agreement, which VIP System
includes (i) a New Business System, (ii) a Policy Administration System, (iii) an Agency
Administration System, (iv) a Financial Administration System. (v) a Claims System, (vi) a Vendor
Provider System, (vii) a Transaction Tracking System and (viii) a Mail Tracking System; B. Such VIP
System as identified in paragraph 4(A) is adequate to meet the needs of BNL; C. VIP shall provide
EDP Services to BNL for such Initial Policies and policies identical thereto and renewals thereof by
the use of such VIP System existing as of the Effective Date of this Agreement, except as such VIP
System may be modified from time to time by VIP , at the discretion of VIP; D. BNL has reviewed the
security system (Security System") included in the VIP System existing as of the Effective Date of
this Agreement; E. BNL acknowledges and agrees that such Security System is adequate to protect the
confidential information and data of BNL processed by the VIP System; F. BNL, throughout the term of
this Agreement, shall be solely responsible for choosing, implementing and utilizing any or all of
such of the security measures and protections offered by said Security System for the use of or
access to the VIP System by any of its officers, directors, shareholders, employees and agents; G.
VIP shall not have any duty to either monitor or enforce such security measures and protections
chosen, implemented or utilized by BNL; H.

E - 6
<!-- page 4 -->
BNL shall be solely responsible for any acts or omissions of any of its officers, directors,
shareholders, employees and agents; I. Notwithstanding anything to the contrary in this Agreement,
VIP at any time during the term of this Agreement may change the platform upon which the VIP System
is operated and through which the EDP Services are provided to BNL by VIP under this Agreement.
Before VIP shall make such platform change VIP shall give BNL prior reasonable written notice of
such change, and VIP's warranties under this Agreement shall continue notwithstanding such change
and VIP agrees to pay any cost created for or imposed on BNL for equipment, training or similar
matters arising from such change. 5. PAYMENTS TO VIP. A. For EDP Services provided pursuant to this
Agreement, BNL will pay to VIP the charges set forth in the Payment Schedule attached hereto as
Schedule B: provided however and notwithstanding anything to the contrary herein. The minimum
monthly fee shall not be less than five thousand dollars ($5,000) per month (as applicable, "Minimum
Fee"). B. For any additional VIP Services provided hereunder, BNL will pay to VIP the charges set
charges set forth in the Payment Schedule attached hereto as Schedule A. C. The fees due hereunder
are subject to the following provisions: 1. The fee for each new policy submitted into the VIP
System is set forth in Schedule B. 2. VIP will process all policies that have thirteen (13) or more
months expired from their original policy date at the annual rates set forth in Schedule B. with a
separate fee for each renewal base policy and each rider, for each plan, prorated to the actual
number of months each policy is represented to be in force on the VIP System. Such representation of
"policy status" includes the "grace period" and "Late payment offer" that each policy may enjoy and
in which case exceeds a time frame not bound by each policy's actual paid for period. The payment
amount for each group of policies in a rate category will be calculated by determining the actual
number of policies and riders in force that are included in the rate category, as set forth in
Schedule B at the end of each calendar month and then multiplying the number of policies by the base
policy renewal amount and the number of riders by the rider renewal amount then adding the totals
together and dividing the resulting amount by twelve (12). The amounts calculated for all rate
categories are added together and this amount is the fee payable in advance at the beginning of the
month. 3. VIP shall not be obligated to process any amended policies or new products that

E - 7
<!-- page 5 -->
are written or acquired by BNL unless and until the parties hereto have mutually executed a written
addendum to this Agreement modifying Schedule B to include the fees for any such products. D. Any
sum due VIP hereunder for which a time for payment is not otherwise specified will be due and
payable within ten (10) days after the date of the postmark for an invoice therefor from VIP. If BNL
fails to pay any amount due within ten (10) days from the date of the postmark for the invoice, late
charges of 1-1/2% per month, or the maximum amount allowable by law, whichever is less, shall also
become payable by BNL to VIP. E. In addition to the communication line and devices which BNL is
authorized to attach to the VIP System pursuant to paragraph 2 of this Agreement, BNL may, for the
monthly fee(s) hereinafter set forth, attach additional communication lines or the following devices
to the VIP System. The monthly fee(s) for such additional lines) or devices is as follows: 1. each
communication line and adapter $200, 2. each visual station whether CRT, PC or similar device $25,
3. each addressable printer under 299 lines per minute ("LPM") $25 4. each addressable printer over
299 LPM $150. F. There are certain other expenses which are directly related to VIP's performance of
this Agreement that are directly billable by VIP and payable by BNL. The purpose and intent of this
provision is not to describe all contemplated charges covered by this provision, but rather to
identify some of the charges that may fall into this category . Such charges include but are not
limited to the following: 1. Cost of all business forms, continuous or non-continuous used by BNL;
2. All telephone calls initiated on behalf of BNL business and operations; 3. All travel, food and
lodging expenses incurred by VIP personnel related to the performance of this Agreement, subject to
BNL's prior written approval; 4. All postage and shipping expenses for materials used by BNL; 5. All
expenses incurred for computer output micro-film "COM" which is contracted by VIP with a service
bureau independent of VIP , subject to BNL' s prior written approval; 6. Any other charges directly
related to BNL ' use or benefit of the VIP System pursuant to this Agreement is subject to BNL '
prior written approval. G. All sums due under this Agreement are payable in U.S. dollars. 6.
PROPRIETARY AND RELATED RIGHTS.

A. CLIENT DATA. Any original documents or files provided to VIP hereunder by BNL ("BNL Data") are
and shall remain BNL's property and, upon the termination of this Agreement for any reason, such BNL
Data will be returned to BNL by VIP, subject to

E - 8
<!-- page 6 -->
the terms hereof. Subject to paragraphs 4(F) and (G), VIP agrees to make the same effort to
safeguard such BNL Data as it does in protecting its own proprietary information. BNL Data will not
be utilized by VIP for any purpose other than those purposes related to rendering EDP Services to
BNL under this Agreement, nor will BNL Data or any part thereof be disclosed to third parties by VIP
, its employees or agents except for purposes related to VIP's rendering ofEDP Services to BNL under
this Agreement or as required by law, regulation, or order of a court or regulatory agency or other
authority having jurisdiction thereover. Notwithstanding the foregoing, VIP shall have the right to
retain in its possession all work papers and files prepared by it in performance of EDP Services
hereunder which may include necessary copies of BNL Data. VIP shall have access to BNL Data, at
reasonable times, during the term of this Agreement and thereafter for purposes related to VIP's
'rendering of EDP Services to BNL pursuant to this Agreement, or as required by law, regulation or
order of a court or regulatory agency or other authority having jurisdiction thereover.
Notwithstanding the foregoing, the confidentiality obligations set forth in this paragraph will not
apply to any information which (i) is or becomes publicly available without breach of this
Agreement, (ii) is independently developed by VIP outside the scope of this Agreement and without
reference to the confidential information received under this Agreement, or (iii) is rightfully
obtained by VIP from third parties which are not obligated to protect its confidentiality. 7.
TERMINATION FOR CAUSE. This Agreement may be terminated by the non- breaching party upon any of the
following events: A. In the event that BNL fails to pay any sums of money due to VIP hereunder and
does not cure such default within thirty (30) days after receipt of written notice of such
nonpayment from VIP , provided that if BNL notifies VIP in writing that BNL disputes a billing and
BNL pays any undisputed portion of such billing VIP shall not institute formal proceedings by
arbitration or judicial review or terminate this Agreement with respect to such disputed billing
until after VIP has afforded BNL an opportunity for a meeting to discuss such dispute. B. In the
event that a party hereto breaches any of the material terms, covenants or conditions of this
Agreement (other than a breach under paragraph (A) above) and fails to cure the same within thirty
(30) days after receipt of written notice of such breach from the non-breaching party. C. In the
event that a party hereto becomes or is declared insolvent or bankrupt, is the subject of any
proceedings relating to its liquidation, insolvency or for the appointment of a receiver or similar
officer for it, makes an assignment for the benefit of all or substantially all of its creditors, or
enters into an agreement for the composition, extension, or readjustment of all or substantially all
of its obligations or admits of its general inability to pay its debts as they become due. D. In the
event of termination under this section, VIP will give BNL, at its request and

E - 9
<!-- page 7 -->
direction, such copies of BNL data maintained on the VIIP system in a format and in a manner as
designated by BNL. BNL shall pay a fee to VIP for preparing such data. Such fee shall be $100 per
hour for programming time and $150 per hour computer processing time. 8. INDEMNIFICATION. A. BNL
agrees to indemnify, defend and hold VIP and its officers, directors, stockholders, employees,
agents and representatives harmless from any and all claims, actions, damages, liabilities, costs
and expenses reasonable attorneys' fees and expenses arising out of or relating to (i) any acts or
omissions of BNL pertaining to the EDP Services, including without limitation any breach of this
Agreement by BNL or (ii) any information provided by or on behalf of, or any instruction, approval
or decision by, BNL pertaining to the EDP Services relied upon by VIP . B. VIP shall indemnify,
defend and hold BNL and its officers, directors, stockholders, employees, agents and representatives
harmless from any and all claims, actions, damages, liabilities, costs and expenses, including
reasonable attorneys' fees and expenses, arising out of any third party claims of infringement of
any United States patents, or a trade secret, or any copyright, trademark, service mark, trade name
or similar proprietary rights alleged to have occurred related to VIP's providing of EDP Services
pursuant to this Agreement or relating to the VIP System used in providing such EDP Services. C.
Subject to the limitations set forth in paragraphs 9(E), 9(F) and 9(G) of this Agreement and not
including the claims covered by paragraph 8(B) of this Agreement, VIP shall indemnify, defend and
hold BNL and its officers, directors, stockholders, employees, agents and representatives harmless
from any and all claims, actions, damages, liabilities, costs and expenses, including reasonable
attorneys' fees and expenses, arising out of or relating to (i) any acts or omissions of VIP
pertaining to the EDP Services, including without limitation any breach of this Agreement by VIP ,
or (ii) any information provided by or on behalf of, or any instruction, approval or decision by,
VIP pertaining to the EDP Services relied upon by BNL. D. The provisions of this paragraph 8 shall
survive the termination of this Agreement. 9. VIP REPRESENTATIONS AND WARRANTIES: DISCLAIMER:
LIMITATIONS. In addition to the other obligations of VIP under this Agreement VIP represents,
warrants and covenants to BNL both at the execution of this Agreement and at all times during the
term of this Agreement that: A. VIP is and will remain duly organized and validly existing as an
Oklahoma corporation (or another state) authorized to engage in the business of providing EDP
Services to its customers;

E - 10
<!-- page 8 -->
B. VIP is not a party to or otherwise subject to any note, debenture, shareholder agreement or other
contractual arrangement, Order, Judgment Decree or Adjudication which prohibits any act or conduct
of VIP contemplated by this Agreement or which would cause VIP to be in violation of or default
respect thereto; C. VIP owns all necessary rights and interests in and to the VIP System and related
programs to fulfill its obligations under this Agreement. The VIP System does not infringe on any
United States patent or any trade secret, copyright, trademark, service mark, trade name or similar
third party proprietary right; and D. VIP warrants that all EDP Services shall be performed in a
prompt and workmanlike manner. Furthermore, the VIP System contains no programming condition which
will limit the VIP System's use after a period of time elapses (such as a fixed calendar limit) and
thus thereafter prevent BNL ' s use of the VIP System without further maintenance. E. Except as set
forth in paragraphs 9(a) through 9(d) inclusive of this agreement, with respect to its EDP services
or other work provided under this agreement, VIP makes no warranties, express or implied, including,
but not limited to, implied warranties of merchantability and fitness for a particular purpose
except as set forth in paragraphs 9(a) through 9(d) inclusive of this agreement, VIP does not
warrant that the services shall meet BNL's requirements or that the services shall be uninterrupted
or error-free. F. Limitation of liability. VIP shall have no liability with respect to its
obligations under this agreement or otherwise for consequential, exemplary, special, indirect,
incidental or punitive damages even if it has been advised of the possibility of such damages in any
event, other than claims covered by paragraph 8(b) or paragraph 6(a) of this agreement (which claims
are excluded from this paragraph 9(f) limitation), the liability of VIP to BNL for any reason and
upon any cause of action or claim in contract, tort or otherwise shall be limited to the amount paid
by BNL to VIP in the twelve (12) month period prior to the accrual of the action or claim for the
specific service which is the subject of the action or claim (or, if such accrual occurs during the
first twelve (12) months of the initial term, then the liability shall be limited to the minimum
fees payable by BNL to VIP during the first twelve (12) months of the initial term). except for the
claims excluded by the preceding sentence, this limitation applies to all causes of action or claims
in the aggregate including without limitation breach of contract, breach of warranty, negligence,
strict liability, misrepresentation and other torts. BNL and VIP acknowledge and agree that the
limitations and exclusions contained herein represent the parties' agreement as to the allocation of
risk between the parties in connection with VIP's obligations under this agreement. the payments
payable to VIP in connection herewith reflect this allocation of risk and the exclusion of
consequential damages in this agreement. G. Notwithstanding anything to the contrary in this
Agreement, VIP shall not be liable in

E - 11

any manner to BNL for any costs, expenses, injury or damages of any kind or nature which are caused
by any of the following: 1. The failure of computer hardware which are not covered by the standard
warranties and indemnification's of such manufacturers; 2. Software designated and supplied by the
computer hardware supplier; or by software designed and implemented by other parties at BNL' request
for which the integrity of said software is BNL' sole responsibility; 3. Erroneous data input or
otherwise provided by BNL and/or failure of BNL to monitor and for the failure of BNL to respond to
the auditing controls of the system; 4. A breach by BNL of any of the terms, covenants,
representations or conditions of this Agreement; 5. The failure by BNL to report to VIP in writing
an error within a reasonable time after BNL discovers or reasonably should have discovered such
error. 10. COVENANTS AND REPRESENTATIONS OF BNL. In addition to the other obligations of BNL under
this Agreement BNL covenants and warrants to VIP both at the execution of this Agreement and at all
times during the term of this Agreement that: A. It is and will remain a duly organized and validly
existing corporation and insurance company under the laws of the State of Arkansas (or another
state) and is otherwise authorized to do business in the State of Arkansas; B. It holds and will
continue to hold all permits, licenses and other governmental authorization necessary for it to
conduct its insurance business; and C. It is not a party to or otherwise subject to any note,
debenture, shareholder agreement or other contractual arrangement, Order, Judgment, Decree of
Adjudication which prohibits any act or conduct of BNL contemplated by this Agreement or which would
cause it to be in violation of or default with respect thereto. BNL acknowledges that BNL, and not
VIP, has the responsibility for compliance with the maintenance and environmental standards for the
operation of the on-site user Equipment specified in paragraph 1.
<!-- page 9 -->
11. BNL LIMITATION OF LIABILITY. BNL shall have no liability with respect to its obligations under
this agreement or otherwise for consequential, exemplary, special, indirect, incidental or punitive
damages even if it has been advised of the possibility

E - 12
<!-- page 10 -->
of such damages. in any event, other than claims covered by the next sentence, the liability of BNL
to VIP for any reason and upon any cause of action and claim in contract, tort or otherwise shall be
limited to the amounts paid by BNL to VIP in the twelve (12) month period prior to the accrual of
the action or claim for the specific service which is the subject of the action or claim (or, if
such accrual occurs during the first twelve (12) months of the initial term, then the liability
shall be limited to the minimum fees payable by BNL to VIP during the first twelve (12) months of
the initial term) claims by VIP for the minimum fees and other fees and expenses owing by BNL under
paragraphs 5, 15(a) and 15(c), or for a breach by BNL of VIP's proprietary rights as set forth in
paragraph 13 are excluded from this paragraph II limitation except for the claims excluded by the
preceding sentence, this limitation applies to all causes of action or claims in the aggregate
including without limitation breach of contract, breach of warranty, negligence, strict liability,
misrepresentation and other torts. VIP and BNL expressly acknowledge and agree that the limitations
and exclusions contained herein represent the parties' agreement as to the allocation of risk
between the parties in connection with BNL's obligations under this agreement the payments payable
to VIP in connection herewith reflect this allocation of risk and the exclusion of consequential
damages in this agreement. 12. VIP OBLIGATION. During the term of this Agreement, in addition to its
other obligations set forth in this Agreement, VIP shall: A. Maintain property insurance in an
amount sufficient to replace or reconstruct the hardware, software, data and facilities necessary
for VIP to operate the VIP System and otherwise provide the EDP Services set forth in this Agreement
and, upon written request, shall provide BNL with evidence of the coverage, including all applicable
limits and conditions, and, upon written request, shall provide BNL with evidence of all renewals,
cancellations, expirations or modifications of the coverage; B. Update on a daily basis, sets of
back-up data files for the BNL Data in the VIP System at an off-site location and/or fire-proof safe
that provides for its safety from destruction or theft. BNL will pay its prorata share based upon
the number of the total users of the VIP System of the cost of storage and/or transportation of
back-up data files to and from the storage facility; C. At BNL' s option and sole expense,
micro-film, all reports or other records as so designated by BNL and store the same in a safe
facility on or off the operational location of VIP; D. Except in instances beyond VIP's reasonable
control under paragraph 16(J) or as provided in paragraph 3, ensure the availability of the VIP
system for BNL ' use at least during the hours of7:00 a.m. through 5:00 p.m. (central time) each day
Monday through Friday. 13. OWNERSHIP OF THE VIP SYSTEM. The VIP System and related programs

E - 13
<!-- page 11 -->
(including software in connection herewith), are and shall at all times remain the sole and
exclusive property of VIP. During the term of this Agreement or any extension thereof, BNL shall
have a non-exclusive license to use the VIP System on-line as designated by VIP. BNL shall not use
the VIP System except as authorized by this Agreement Upon the expiration or earlier termination of
this Agreement, neither BNL nor any third party shall have any further right to use the VIP System
after the retrieval of the BNL data pursuant to paragraph 6(A) of this Agreement. 14. ADDITIONAL
SERVICES. A. Subject to the terms of paragraph 14(C), and for the sums set forth in paragraph 14(B)
hereof, VIP , during the term of this Agreement, agrees to provide the following added services to
BNL upon request: 1. All consultation, systems development, conversion services, programming,
debugging and testing of software, hardware, and for other services other than the VIP System and
which are unique to BNL products and/or method of doing business; 2. All machine time used in
connection with systems development, conversion services, programming, debugging and testing of
software, hardware and other vendor services which are unique to BNL products and/or method of doing
business; 3. Assistance of VIP in connection with the termination of either parties of its services
under this Agreement and the implementation of EDP service by BNL with another data processing
company; 4. Additional processing resulting from changes in regulatory requirements; 5. Special,
unscheduled, and/or non-standard system application processing; 6. Bank draft processing. B. VIP
will provide BNL the above enumerated additional services at the hourly rates set forth in Schedule
A Schedule of Charges and Fees for Additional Services, for the initial twelve (12) months of this
Agreement. After the initial twelve months of this Agreement, VIP may adjust the rates in Schedule A
to VIP's then current standard rates for such services, provided that it provides BNL with notice of
any such adjustment not less ~han thirty (30) days prior to any such adjustment and that such rates
shall not increase by more than ten ( 10% ) percent per year . C. VIP performance of such additional
services for BNL is subject to availability of resources and the development of a schedule for
delivery of such services which is agreeable to both parties. VIP agrees to make a best effort
attempt to develop the required schedules with BNL.

E - 14
<!-- page 12 -->
15. TERM. A. The initial term ("Initial Term") of this Agreement shall be for one year commencing on
the 1st day of May, 2006 ("Effective Date"). Payments under this Agreement by BNL shall commence as
provided in paragraph 5(A) hereof. B. Unless either party gives written notice to terminate this
Agreement at least six (6) months prior to the end of said Initial Term, this Agreement shall
continue on a year to year basis ("Extended Term(s)") until terminated by either party by giving
written notice of termination thereof to the other party at least six (6) months prior to the end of
the then current Extended Term. C. However, if, after the Initial Term, BNL terminates this
Agreement during an Extended Term by giving less than six (6) months notice, in addition to any
other sums due VIP under this Agreement, BNL shall pay to VIP a cancellation fee equal to the
greater of (i) the Minimum Fee multiplied by the remaining number of months in the then current
term, (ii) the average of the monthly billings for the six (6) month period immediately preceding
the date upon which the notice of termination is received by VIP from BNL multiplied by the
remaining number of months in the then current term or (iii) thirty thousand dollars ($30, 000). E.
From and after notice of termination is received by VIP, any new reports or other services provided
by VIP other than routine processing services which have been done for BNL under this Agreement
shall be deemed to be additional services and shall be performed by VIP at VIP's then current rates
for such termination services as specified on Schedule A. F. Upon termination or expiration of this
Agreement, BNL shall return all software and related manuals, if any, provided by VIP to BNL during
the term of this Agreement. 16. MISCELLANEOUS. A. ADVERTISING. During the term of this Agreement BNL
consents to the use of the name of BNL by VIP in identifying BNL as a client, in advertising,
publicity, or similar materials distributed to prospective clients. Except as set forth in this
paragraph 16(A), the terms of this Agreement shall be kept confidential. B. AMENDMENTS. No
amendment, change, waiver, or discharge hereof shall be valid unless in writing and signed by an
authorized representative of the party against which such amendment, change, waiver, or discharge is
sought to be enforced. Any provision of BNL' purchase' order or other request for services shall not
bind VIP. VIP's failure to object to any such provision shall not be construed as a waiver of the
terms and conditions of this Agreement nor as acceptance of any such other provision(s).

E - 15
<!-- page 13 -->
C. ARBITRATION. Any controversy or claim arising out of or relating to this Agreement, or its
breach, or its validity or interpretation, except claims for injunctive relief and claims involving
necessary third parties who refuse to participate, shall be settled by binding arbitration in
accordance with the then current Commercial Arbitration Rules of the American Arbitration
Association (" AAA") subject, however, to the following: 1. The location for the arbitration shall
be at such location reasonably designated by the arbitrators. 2. Such arbitration shall be heard and
determined by a panel of three (3) arbitrators in accordance with the then current rules or
regulations of the AAA relating to commercial disputes. One arbitrator shall be appointed by each
party to serve on the panel. One neutral arbitrator shall be appointed by the AAA and shall serve as
chairperson of the three arbitrator panel. Such neutral arbitrator shall be an attorney with
experience in handling disputes relating to the providing of out sourced electronic data processing
services. 3. The arbitration award shall be binding on the parties and may be enforced in any court
of competent jurisdiction. 4. The prevailing party in such arbitration shall be entitled to recover
its reasonable attorneys' fees and costs incurred in such arbitration proceeding. D. ASSIGNMENT.
Neither party to this Agreement shall assign, subcontract, or otherwise conveyor delegate its rights
or duties hereunder to any third party without the prior written consent of the other party hereto,
such consent not to be unreasonably withheld. E. ATTORNEY FEES. In the event that litigation is
instituted between the parties in connection with any controversy or dispute arising out of or
relating to this Agreement, the prevailing party in such litigation shall be entitled to recover its
reasonable attorney fees and costs. F. BINDING. This Agreement is binding on, and shall inure to the
benefit of VIP, BNL and their respective successors and assigns. G. CHOICE OF LAW. This Agreement
and performance hereunder shall be governed by the laws of the State of Oklahoma without regard to
conflict of laws. Subject to the requirement for arbitration under paragraph 16(C), VIP and BNL
hereby agree on behalf of themselves and any person claiming by or through them that jurisdiction
and venue for any litigation arising from or relating to this Agreement shall be in the appropriate
federal or state court located in Austin, Texas, or in Oklahoma City, Oklahoma, and that any
arbitration shall be conducted in the location selected pursuant to paragraph 16(C)(1).

E - 16
<!-- page 14 -->
H. COUNTERPARTS. This Agreement may be executed in several counterparts, all of which taken together
shall constitute one single agreement between the parties hereto. I. ENTIRE AGREEMENT. This
Agreement, including any Schedules referred to herein or attached hereto, each of which is
incorporated herein for all purposes, constitutes the entire agreement between the parties hereto
with respect to the subject matter hereof and no prior or contemporaneous representations,
inducements, promises, or agreements, oral or otherwise, between VIP and BNL with reference thereto
shall be of any force or effect. J. FORCE MAJEURE. Notwithstanding anything to the contrary in this
Agreement, but except to the extent provided in paragraph 2, VIP shall not be liable to BNL for any
delay or failure to perform any of the EDP Services or other obligations set forth in this Agreement
due to cause(s) beyond its reasonable control, including, without limiting the generality of the
foregoing, (i) accidents, (ii) acts of God, (iii) labor disputes, (iv) BNL's failure to submit data
or information in the prescribed form or in accordance with the agreed upon schedules; (v) special
requests, outside the VIP Systems' functions routinely utilized by BNL, by BNL or any governmental
agency authorized to regulate or supervise BNL or any authority having jurisdiction over BNL; (vi)
BNL's failure to provide any equipment, software, facility or performance called for by this
Agreement, and the same is necessary for VIP's performance hereunder, (vii) BNL's material breach of
any of the terms, covenants, or representations set forth in this Agreement or (viii) the actions of
any government agency or common carrier or other third party over whom VIP has no control.
Performance times shall be considered extended for a period of time equivalent to the time lost
because of such delay. K. HEADINGS. The paragraph headings used herein are for reference and
convenience only and shall not enter into the interpretation hereof. L. INDEPENDENT CONTRACTOR. VIP
and BNL are strictly independent contractors. Neither party has the right to bind the other in any
manner, and nothing in this Agreement shall be interpreted to make either party the agent or legal
representative of the other or to make the parties joint venturers or partners. M. LIMIT A TIONS OF
ACTIONS. Any claim of action of any kind which one party to this Agreement may have against the
other party relating to or arising out of this Agreement must be commenced within two (2) years from
the date such claim or cause of action shall have first accrued. N. NOTICES. Any notice provided
pursuant to this Agreement, if specified to be in writing, shall be in writing and shall be deemed
given (i) if by hand delivery, upon receipt thereof (ii) if mailed, three (2) days after deposit in
the United States mails, postage prepaid, certified mail return receipt requested, or (iii) if by
next day delivery service, upon such delivery .All notices shall be addressed to a party at the
address first set forth above or at such other address as either party may in the future specify in
writing to the other .

E - 17
<!-- page 15 -->
0. SERVICES FOR OTHERS. BNL understands and agrees that VIP may perform for third. parties similar
services using the same personnel, subject to VIP's confidentiality obligations hereunder, and that
VIP may utilize such personnel for rendering services for BNL hereunder. P. SEVERABILITY. If any
provision of this Agreement shall be invalid or unenforceable, the remaining provisions of this
Agreement shall not be affected thereby and each remaining provision shall be valid and enforceable
to the fullest extent permitted by law. Q. SURVIVAL. All provisions of this Agreement relating to
confidentiality and indemnity shall survive the termination of this Agreement. R. NO THIRD PARTY
BENEFICIARY. No third party is intended to be nor shall any such third party be deemed to be a third
party beneficiary of this Agreement nor shall any third party acquire any rights or remedies under
or through this Agreement. S. WAIVER, Any waiver by a party of any breach of any provision of this
Agreement shall not be construed as a waiver of any continuing or succeeding breach of such
provision, a waiver of that provision itself or a waiver of any other right(s) under this Agreement.
The parties agree and acknowledge that they have read this Agreement. The persons signing below on
behalf of the respective parties represent and warrant that they have the authority to bind the
party on which behalf they have executed this Agreement. This Agreement is executed on the dates
shown below and effective as of the Effective Date identified above. VIRTUAL ITEM PROCESSING SYSTEMS
INC. BROKERS NATIONAL LIFE ASSURANCE COMPANY

/s/ David A. Siekman /s/ Barry N. Shamas By: _____________________________________ By:
_________________________________ David A. Siekman Barry N. Shamas President Executive Vice
President May 17, 2006 May 18, 2006 Date: ___________________________________ Date:
_______________________________

E - 18
<!-- page 16 -->
SCHEDULE A SCHEDULE OF CHARGES AND FEES FOR ADDITIONAL SERVICES SYSTEMS AND PROGRAMMING SERVICES
HOURLY RATE 1. CONSULTATION $100.00 2. SYSTEMS DEVELOPMENT 100.00 3. SYSTEMS REQUIREMENTS DEFINITION
100.00 4. SYSTEMS ANALYSIS 100.00 5. COMPUTER PROGRAMMING: SENIOR ANALYST 100.00 JUNIONANALYST 85.00
COMPUTER TIME FOR SYSTEM DEVELOPMENT 6. COMPUTER CHARGED TIME $150.00 TERMINATION SERVICES 7.
CONSULTATION $100.00 8. PROGRAMMING $185.00 9. COMPUTER CHARGED TIME $250.00 ADDITIONAL REGULATORY
PROCESSING 10. COMPUTER CHARGED TIME $150.00 SPECIAL OR NON-STANDARD APPLICATION PROCESSING 11.
COMPUTER CHARGED TIME $150.00 EDUCATION AND HELP 12. EDUCATION: IN VIP OFFICES $ 50.00 13.
EDUCATION: ON-SlTE 90.00 14. PROCEDURAL HELP VIA TELEPHONE 50.00 BANK DRAFTS UNIT RATE 15. BANK
DRAFT PROCESSING (PER DRAFT) $ .06

E - 19
<!-- page 17 -->
SCHEDULE B SCHEDULE OF PROCESSING FEES PLAN NAME OF CATEGORY All BNL Plans Fee = $.305/per policy
per month
