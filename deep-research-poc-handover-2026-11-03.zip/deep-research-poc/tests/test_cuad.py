"""CUAD evaluation corpus (data/cuad_docs) and its golden set (data/golden/cuad_questions.jsonl).

Skipped when the corpus has not been built (scripts/fetch_cuad.py + scripts/make_cuad_corpus.py):
the raw dataset is 106 MB and lives outside the repository. No model calls.

Gold answers are compared whitespace-insensitively: the corpus reflows the CUAD text (collapses
whitespace runs, wraps long lines) but never changes a character, so a span is verbatim up to
whitespace. See data/golden/README.md, "CUAD".
"""
from __future__ import annotations

import json
import re
from collections import Counter
from pathlib import Path

import pytest

from dr.eval.golden import GoldenQuestion, load_golden, placeholder_stem, resolve_gold_docs
from dr.ingest.load import load_dir
from dr.models import DocRecord

ROOT = Path(__file__).resolve().parents[1]
CUAD_DOCS = ROOT / "data" / "cuad_docs"
QUESTIONS = ROOT / "data" / "golden" / "cuad_questions.jsonl"
ALIGNMENT = CUAD_DOCS / "_alignment.json"
RAW_JSON = ROOT / "data" / "raw" / "cuad" / "CUAD_v1" / "CUAD_v1.json"

PAGE_RE = re.compile(r"^<!--\s*page\s+(\d+)\s*-->\s*$", re.MULTILINE)
MIN_DOCS = 500
MIN_QUESTIONS, MAX_QUESTIONS = 80, 150
TYPE_MINIMUMS = {"single": 20, "temporal": 10, "identifier": 8, "coverage": 6, "not_in_corpus": 8}
NOT_IN_CORPUS_SHARE = 0.10
MIN_DATE_SHARE = 0.95
MIN_PARTIES_SHARE = 0.99

requires_corpus = pytest.mark.skipif(
    not (CUAD_DOCS.is_dir() and any(CUAD_DOCS.glob("*.md")) and QUESTIONS.exists()),
    reason="CUAD corpus not built: run scripts/fetch_cuad.py, scripts/make_cuad_corpus.py and "
           "scripts/make_cuad_golden.py (data/cuad_docs is git-ignored)",
)


def ws(s: str) -> str:
    return " ".join(s.split())


def _pages(text: str) -> dict[int, str]:
    out: dict[int, str] = {}
    cur: int | None = None
    buf: list[str] = []
    for ln in text.split("\n"):
        m = PAGE_RE.match(ln)
        if m:
            if cur is not None:
                out[cur] = "\n".join(buf)
            cur, buf = int(m.group(1)), []
        else:
            buf.append(ln)
    if cur is not None:
        out[cur] = "\n".join(buf)
    return out


@pytest.fixture(scope="module")
def docs() -> list[DocRecord]:
    return load_dir(CUAD_DOCS)


@pytest.fixture(scope="module")
def questions() -> list[GoldenQuestion]:
    return load_golden(QUESTIONS)


@pytest.fixture(scope="module")
def resolved(questions, docs) -> list[GoldenQuestion]:
    return resolve_gold_docs(questions, docs)


# --------------------------------------------------------------------------- corpus


@requires_corpus
def test_corpus_loads_with_page_markers_and_metadata(docs):
    assert len(docs) >= MIN_DOCS, len(docs)
    assert len({d.doc_id for d in docs}) == len(docs)
    assert len({Path(d.source_path).stem for d in docs}) == len(docs)
    with_date = with_parties = 0
    for d in docs:
        pages = _pages(d.text)
        assert pages, f"{d.source_path}: no page markers"
        assert sorted(pages) == list(range(1, len(pages) + 1)), f"{d.source_path}: pages not 1..N"
        assert d.text.startswith("<!-- page 1 -->\n# "), f"{d.source_path}: page 1 must open with the title"
        assert "| Document Type |" in pages[1], f"{d.source_path}: metadata table missing on page 1"
        for key in ("title", "doc_type", "cuad_title", "pages_approximate"):
            assert d.metadata.get(key), f"{d.source_path}: metadata missing {key}"
        assert d.metadata["pages_approximate"].lower() in {"true", "false"}
        with_parties += bool(d.metadata.get("parties"))   # an attachment/appendix may name none
        if d.metadata.get("date"):
            assert re.fullmatch(r"\d{4}-\d{2}-\d{2}", d.metadata["date"]), (d.source_path, d.metadata["date"])
            with_date += 1
    assert with_date >= MIN_DATE_SHARE * len(docs), (with_date, len(docs))
    assert with_parties >= MIN_PARTIES_SHARE * len(docs), (with_parties, len(docs))


@requires_corpus
def test_page_counts_match_alignment_record(docs):
    records = {r["stem"]: r for r in json.loads(ALIGNMENT.read_text(encoding="utf-8"))}
    approximate = 0
    for d in docs:
        rec = records[Path(d.source_path).stem]
        assert len(_pages(d.text)) == rec["n_pages"] == int(d.metadata["n_pages"]), d.source_path
        assert (d.metadata["pages_approximate"].lower() == "true") == rec["approximate"]
        approximate += rec["approximate"]
    # the aligner anchors nearly every page; a handful of scanned/odd PDFs may fall back
    assert approximate <= 0.05 * len(docs), approximate


@requires_corpus
def test_no_whole_document_without_pages_and_bodies_are_wrapped(docs):
    for d in docs:
        body = [ln for ln in d.text.split("\n") if not ln.startswith("|")]  # metadata table rows are not wrapped
        longest = max(len(ln) for ln in body)
        # wrapped at 100 columns; a single unbreakable token (URL, redaction run) may exceed it
        assert longest <= 400, (d.source_path, longest)


# --------------------------------------------------------------------------- questions


@requires_corpus
def test_question_counts_and_type_distribution(questions):
    n = len(questions)
    assert MIN_QUESTIONS <= n <= MAX_QUESTIONS, n
    assert len({q.qid for q in questions}) == n, "duplicate qids"
    counts = Counter(q.type for q in questions)
    for t, lo in TYPE_MINIMUMS.items():
        assert counts[t] >= lo, (t, dict(counts))
    assert counts["not_in_corpus"] >= NOT_IN_CORPUS_SHARE * n, dict(counts)
    print("\nCUAD golden set by type:", dict(sorted(counts.items())))


@requires_corpus
def test_every_placeholder_resolves(questions, docs, resolved):
    ids = {d.doc_id for d in docs}
    for q, r in zip(questions, resolved):
        for before, after in zip(q.gold_docs, r.gold_docs):
            assert placeholder_stem(before.doc_id), f"{q.qid}: gold doc_id is not a <stem> placeholder"
            assert placeholder_stem(after.doc_id) is None and after.doc_id in ids, f"{q.qid}: unresolved"
    assert all(gd.doc_id in ids for q in load_golden(QUESTIONS, docs=docs) for gd in q.gold_docs)


@requires_corpus
def test_gold_pages_exist_and_answers_are_on_cited_pages(resolved, docs):
    by_id = {d.doc_id: d for d in docs}
    for q in resolved:
        if q.type == "not_in_corpus":
            continue
        assert q.gold_docs, f"{q.qid}: no gold docs"
        assert q.gold_answer or q.gold_items, f"{q.qid}: neither gold_answer nor gold_items"
        cited: list[str] = []
        for gd in q.gold_docs:
            d = by_id[gd.doc_id]
            assert d.metadata["pages_approximate"].lower() == "false", f"{q.qid}: cites an approximately paged doc"
            pages = _pages(d.text)
            assert gd.pages, f"{q.qid}: {gd.doc_id} cited without pages"
            for p in gd.pages:
                assert p in pages, f"{q.qid}: page {p} missing in {d.source_path}"
                cited.append(ws(pages[p]))
        joined = " \n ".join(cited)
        if q.gold_answer:
            assert ws(q.gold_answer) in joined, f"{q.qid}: gold_answer not on a cited page: {q.gold_answer[:80]!r}"
        for item in q.gold_items:
            assert ws(item) in joined, f"{q.qid}: gold item {item!r} not on a cited page"
        if q.type == "coverage":
            assert len(q.gold_items) >= 2 and len(q.gold_items) == len(q.gold_docs), q.qid
            assert len(set(q.gold_items)) == len(q.gold_items), f"{q.qid}: duplicate gold items"


@requires_corpus
def test_not_in_corpus_questions_name_a_real_contract_without_that_clause(questions, docs):
    stems = {Path(d.source_path).stem for d in docs}
    raw = None
    if RAW_JSON.exists():
        raw = {t["title"]: t for t in json.loads(RAW_JSON.read_text(encoding="utf-8"))["data"]}
    by_stem = {Path(d.source_path).stem: d for d in docs}
    for q in questions:
        if q.type != "not_in_corpus":
            continue
        assert not q.gold_docs, f"{q.qid}: not_in_corpus must not cite documents"
        m = re.search(r"contract=<([^>]+)>; category=([^;]+)", q.notes)
        assert m, f"{q.qid}: notes must record contract and category"
        stem, cat = m.group(1), m.group(2)
        assert stem in stems, f"{q.qid}: unknown contract {stem}"
        if raw is not None:  # the raw annotations are available: the category really is unannotated
            entry = raw[by_stem[stem].metadata["cuad_title"]]
            qa = next(x for x in entry["paragraphs"][0]["qas"] if x["id"].endswith("__" + cat))
            assert not qa["answers"], f"{q.qid}: CUAD does annotate {cat} in {stem}"


@requires_corpus
def test_rubrics_present(questions):
    for q in questions:
        assert q.rubric, f"{q.qid}: empty rubric"


# --------------------------------------------------------------------------- page aligner (pure, always runs)

PARA = [
    "ARTICLE 1 DEFINITIONS. Capitalized terms have the meanings given below in this Agreement.",
    "ARTICLE 2 TERM. This Agreement commences on the Effective Date and runs for five years.",
    "ARTICLE 3 PAYMENT. Distributor shall pay Company within thirty days of each invoice.",
    "ARTICLE 4 GOVERNING LAW. This Agreement is governed by the laws of the State of Delaware.",
]


def test_locate_page_starts_finds_anchor_pages_and_snaps_to_lines():
    from dr.ingest.pages import PageAlignment, insert_markers, locate_page_starts

    header = "CONFIDENTIAL - Distributor Agreement\n"           # running header, repeated on every page
    text = "\n".join(PARA) + "\n"
    pdf_pages = [header + PARA[0] + "\n" + PARA[1], header + PARA[2], header + PARA[3]]
    al = locate_page_starts(text, pdf_pages)
    assert isinstance(al, PageAlignment) and al.n_pages == 3
    assert al.located == [True, True, True] and not al.approximate
    assert al.starts[1] == text.index(PARA[2]) and al.starts[2] == text.index(PARA[3])
    assert al.pages_of_span(text.index("thirty"), text.index("thirty") + 6) == [2]
    marked = insert_markers(text, al.starts)
    assert marked.split("\n")[0] == "<!-- page 1 -->"
    assert marked.count("<!-- page ") == 3
    assert f"<!-- page 3 -->\n{PARA[3]}" in marked


def test_locate_page_starts_interpolates_missing_pages_and_flags_them():
    from dr.ingest.pages import locate_page_starts

    text = "\n".join(PARA) + "\n"
    unseen = "Schedule B rates table 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20"
    al = locate_page_starts(text, [PARA[0], unseen, PARA[3]])
    assert al.located == [True, False, True] and al.approximate
    assert al.starts[0] == 0 < al.starts[1] <= al.starts[2] == text.index(PARA[3])
    blank = locate_page_starts(text, [PARA[0], "", PARA[3]])
    assert blank.blank == [False, True, False] and not blank.approximate
