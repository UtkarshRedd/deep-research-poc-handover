<!-- page 1 -->
# Service Agreement
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2019-04-01 |
| Parties | PC Financial Services Private Limited ("PC Financial"); Mobimagic Co., Ltd. ("Mobimagic"); (each as "Party" collectively as "Parties") |
| Source | CUAD v1 / OPERALTD_04_30_2020-EX-4.14-SERVICE AGREEMENT |

Exhibit 4.14 SERVICE AGREEMENT This Service Agreement ("Agreement") is entered into on April. 1st
2019 ("Effective Date") by and between: PC Financial Services Private Limited, a India company with
an address at Building RZ-2, Pole No.-3, G/F Kapashera, Near HDFC Bank, New Delhi ("PC Financial"),
a registered Non-banking Financial Company (NBFC) in India; and Mobimagic Co., Ltd., a company
Incorporated under the laws of the People 's Republic of China with its principal place of business
at Room 1110-046, A District, No. 1 Building, No.18 East Road, Zhongguancun, Haidlan District,
Beijing City ("Mobimagic"). PC Financial and Mobimagic are individually referred to herein each as a
"Party" and collectively as the "Parties." In consideration of their mutual promises, the Parties
hereby agree as follows: 1. DEFINITIONS 1.1 "Activity" means the offering of small, unsecured loans
to businesses and individuals in the Territory by PC Financial. 1.2 "Business Data" means all end
user data and user account details, as well as commercial records, relating to PC Financial
operation of the Activity in the Territory 1.3 "Confidential Information" means non-public
information that a Party or Its affiliates ("disclosing Party") discloses to the other Party or its
affiliates ("receiving Party") which is designated as being 'proprietary' or 'confidential' or which
by its nature or the circumstances reasonably ought to be treated as confidential. Confidential
Information includes the disclosing Party's software end prototypes and information relating to the
disclosing Party's business affairs, including business methods, marketing strategies, pricing,
competitor Information, product development strategies, and financial results. Confidential
Information does not include information which (a) is known by the receiving Party, free of any
obligation to keep it confidential; (b) is at the time of disclosure, or thereafter becomes,
publicly available through no wrongful act of the receiving Party; (c) Is independently developed by
the receiving Party, without relying on or referring to the Confidential Information of disclosing
Party; or (d) is approved for release by prior written authorization of the disclosing Party. 1.4
"Marks" means the trademarks and brand names used by the PC Financial to operate the Activity in the
Territory. 1.5 "Service Period" means April. 1st 2019 through to March 30, 2020. 1.6 "Services"
means the services to be performed by Mobimagic as stated in clause 2.2 of this Agreement in terms
of this Agreement during the Service Period. 2. THE SERVICES 2.1 PC Financial hereby engages
Mobimagic to provide Services to PC Financial during the Service Period, and Mobimagic hereby
accepts such engagement in order to gain the income from the Territory. 1
<!-- page 2 -->
2.2 Mobimagic will provide the system / platform maintenance services and data processing services
to PC Financial. 2.3 where required, Mobimagic may assign its employees to India for short durations
to support wont for facilitating the rendering of Services and the estimated presence days of those
employees in any case will be less than 183 days in the aggregate in any 12 months. 3. WARRANTIES
3.1 Each Party represents and warrants that it has, and will retain during the Service Period
hereof, all right, title and authority to enter into this Agreement, and to perform all of its
obligations under this Agreement. 3.2 Mobimagic represents and warrants that, (a) Mobimagic is not
subject to any Agreement or duty that would be breached by Mobimagic's entering into or performing
Mobimagic's obligations under this Agreement or that is otherwise inconsistent with this Agreement;
(b) the Services provided hereunder will not infringe any legal rights or interests of any potential
customers or third parties, and will not violate any provision of laws and regulations; (c) the
Services will be provided in a good and workmanlike manner with at least the same degree of skill
and competence normally practiced by professionals providing the same or similar services: (d)
Mobimagic shall not store or retain and shall not be required to store or retain any information
belonging to the PC Financial (passed through the Services) pursuant to this Agreement at any time,
save and except the metadata or hashed data collected in full compliance with applicable law and PC
Financial's privacy policy and solely for the purpose of invoicing .and billing PC Financial; (e) on
the Effective Date and during the Service Period of this Agreement it will conduct its business in
accordance with applicable law and without violating the rights of any third party. (f) It will not
intend to access to the data relating to Indian operations of the PC Financial except for the data
passing through Services. (g) neither Mobimagic, nor any Individual holding any direct or indirect
Interest in Mobimagic, is listed on the U.S. Specially Designated Nationals (SDN) List or
Consolidated Sanction List (ref. https://sanctionssearch.ofac.treas.govn), nor is Mobimagic
otherwise associated with any of the listed individuals or organizations; and (h) in connection with
performance of the Services In the Territory, as well as its performance of this Agreement,
Mobimagic and its affiliates will not violate any provision of the US Foreign Corrupt Practices Act,
the UK Bribery Ad., or any anti- corruption related laws in the Territory. 3.3 PC Financial
represents and warrants that on the Effective Date and during the Service Period of this Agreement:
(a) it will conduct its business in Territory in accordance with applicable law and without
violating the rights of any third party; and (b) in connection with the conduct of its business in
Territory, as well as its performance of this Agreement, PC Financial and Its affiliates will not
violate any provision of the US Foreign Corrupt Practices Act, the UK Bribery Act, or any
anti-corruption related laws in the Territory. 2
<!-- page 3 -->
3.4 Except as set forth in this Section 3, the Parties and their suppliers disclaim all warranties,
either express or implied, statutory or otherwise, inducing without limitation warranties of
functionality, merchantability, fitness for a particular purpose. 4. RIGHTS AND OBLIGATIONS 4.1 PC
Financial shall pay a monthly Fee to Mobimagic in accordance with this Agreement and within the
timeline as permitted under the prevailing India regulations. 4.2 PC Financial shall be responsible
for acquiring the technical equipment necessary for receiving the Service, and shall also in other
respects bear its own costs in the carrying out of any activities relating to its own products and
software applications. 4.3 Mobimagic warrants that the Services provided hereunder will not infringe
any legal rights and interests of any potential customers and third parties, and will not violate
any provision of laws and regulations. The Services it provides pursuant to the Agreement will be
provided in a good and workmanlike manner with at least the same degree of skill and competence
normally practiced by professionals providing the same or similar services and PC Financial has the
right to continuous review and assesses the Services provided by Mobimagic and give its necessary
suggestions towards the Services. Mobimagic may take necessary corrective measures of its Services
according to PC Financial's requirements. 4.4 PC Financial shall maintain an updated privacy policy
and consent driven architecture, to ensure that it has adequate approvals from the concerned
persons, entities and/or authorities as required by law to access, collect, store and transmit
personal data of any entity using the Services. The Parties hereby agree and confirm, and Mobimagic.
warrants, that Mobimagic shall not store or retain and shall not be required to store or retain any
information belonging to the PC Financial (passed through the Services) pursuant to this Agreement
at any time, save and except the records of transactions just for the purpose of Invoicing and
billing the PC Financial. Mobimagic warrants that it will not take any action, or collect any data,
which causes a breach of applicable law or PC Financial'& privacy policy and consent driven
architecture. Subject to the foregoing as wen as Mobimagic's obligations under this Agreement,
Mobimagic shall not in any manner be held or be responsible or liable for any unforeseen
contingency, claims, liabilities, demands. losses, damages or expenses arising due to absence of
storage or retention of any PC Financial data which shall be the sole responsibility of PC Financial
. 4.5 According to this Agreement, the Services provided by the Mobimagic are only for PC
Financial's reference, it does not constitute any recommendation or decision. Any judgments,
inferences or views made by PC Financial on the basis of the Information provided by the Mobimagic
do not represent the positions and opinions of the Mobimagic. PC Financial shall be responsible for
data security management and confidentiality responsibilities. According to this agreement,
Mobimagic shall not be responsible for the usage and consequences of the data information acquired
by PC Financial. 4.6 PC Financial shall not, directly or Indirectly: (a) remove any proprietary
notices or labels; (b) make the Services available to any third party without the prior written
consent of the Mobimagic, other than the authorized users In furtherance of the Activity; (c)
falsely imply any sponsorship or association with Mobimagic; (d) use the Services to send
unsolicited communications junk mail, spam, pyramid schemes or other forms of duplicative or
unsolicited messages; (e) use the Services to store or transmit any content that infringes upon any
person's intellectual property rights (f) use the Services to knowingly post, transmit, upload, link
to, send or store any viruses, malware, Trojan horses or any other similar harmful software; or (g)
knowingly use the Services in violation of this Agreement. 3
<!-- page 4 -->
4.7 Data protection. Each Party agrees to comply with all applicable data protection and privacy
laws arising from its obligations, if any, under the Agreement and to reasonably co-operate with the
other Party in order to allow the other Party to comply with any laws as deemed necessary from time
to time. Each Party shall treat all data, information relating to Services, including but not limit
to the customer personal data, as confidential. Each party warrants that it shall take appropriate
technical and organizational measures against unauthorized or unlawful processing of personal data
and against accidental loss or destruction of, or damage to, the personal data of the other party.
4.8 Both Parties acknowledge and confirm that the Reserve Bank of India (hereafter "RBI") or persons
authorized by it has right to access and inspect the PC Financial's documents, records of Service
transactions and other necessary information related to the Services or Activity given to, stored or
processed by Mobimagic within a reasonable time. 5. INTELLECTUAL PROPERTY RIGHTS 5.1 Nothing in this
Agreement shall be construed as transferring the Intellectual Property Rights of either Party or its
suppliers to the other Party. For the avoidance of doubt: (a) all Intellectual Property Rights In
and to the Marks and the Business Data shall remain the property of PC Financial or its Affiliates
as the case may be. Mobimagic acknowledges that it shall acquire no proprietary rights whatsoever in
and to the Marks used in the Activity or the Business Data generated by the Activity, which shall
remain the sole and exclusive property of PC Financial and Its Affiliates for their unlimited
exploitation and all use and acquired goodwill shall inure to PC Financial and its Affiliates' sole
benefit. 6. COMPENSATION AND EXPENSES 6.1 Subject to the terms and conditions of this Agreement. PC
Financial shall pay to Mobimagic a fixed service fee in the amount of 970,000 United States Dollars
(USD 970,000) for each month (the "Fee") within the timeline as permitted under the prevailing India
regulations. It is stipulated in this Agreement that Mobimagic will send an invoice to PC Financial
on monthly basis according to the progress of the service. After PC Financial confirms that invoice
contents are correct, PC Financial shall pay within 45 days after confirming thus. 6.2 The payment
is effected by means of bank transfer to the account specified In Mobimagic's invoice. 6.3 The Fee
provided is exclusive of Goods and Service Tax (GST) which may be levied under Reverse Charge
Mechanism. Any respective taxes for each party will be the responsibility by each party. If law
requires that taxes be withheld PC Financial shall (a) deduct those taxes from the Fee; (b) pay the
taxes to the proper governmental body; (c) send evidence of the obligation and proof of tax payment
to Mobimagic; (d) remit the Fee amount, after deductions and withholding; and (e) cooperate with
Mobimagic to obtain refunds of such taxes if there Is any preferential tax treatment available. 6.4
The Fee may be changed by mutual agreement in writing between Mobimagic and PC Financial according
to the service content, complexity of services involved or arm's length principles. 4
<!-- page 5 -->
6.5 In case of any complaint about using the Services as set out in this Agreement PC Financial
shall raise the problems within 20 business days after getting Mobimaigc's invoice. Both Parties
shall engage in reasonable efforts to negotiate and solve the problems together. If the cause of the
difference remains undetermined after the aforesaid efforts of the Parties, an independent third
party, (e.g., external auditors) may be employed to give an inspection. The costs arising out of the
third- party inspection shall be borne by the Parties according to their respective faults. 7.
CONFIDENTIALITY & PUBLICITY Neither Party shall disclose the other Party's Confidential Information
to any third party or use Confidential Information for any purpose other than fur the proper
fulfillment of this Agreement. Each Party undertakes to safeguard the Confidential Information of
the other Party with the same degree of care as it would apply to Its own Confidential Information
and, in any case, with no less than reasonable care. Such obligations will survive the expiration of
this Agreement for a period of five (5) years. 8. INDEMNIFICATION 8.1 PC Financial shall defend at
its own expense and indemnify Mobimagic against any cost, loss or damage arising out of any claim,
demand, suit or action ("Action") brought against Mobimagic by a third party to the extent that such
Action is related to PC Financial's breach of this Agreement. Mobimagic will promptly inform PC
Financial in writing of any such Action and will co-operate in the defence and/or settlement of the
Action. PC Financial agrees that in negotiating any settlement, it shall act reasonably and shall
obtain Mobimagic's prior, written consent which consent shall not be unreasonably withheld. 8.2
Mobimagic shall indemnify and hold harmless PC Financial and its officers, direct0l8 and Affiliates,
("PCF Indemnified Parties") against any cost, penalty, loss or damage arising out of or related to
the Services, or Mobimagic's breach of this Agreement or applicable law. PC Financial will promptly
inform Mobimagic in writing of any such Action and will co-operate in the defence and/or settlement
of the Action. Mobimagic agrees that in negotiating any settlement, it shall act reasonably and
shall obtain PC Financial's prior, written consent which consent shall not be unreasonably withheld.
8.3 Neither Party shall be liable to the other Party in contract, tort or otherwise, whatever the
cause, for any loss of profit, business or goodwill or any indirect, incidental or consequential
costs, damages or expenses of any kind, except for such loss attributable to breach of
confidentiality. 9. TERM & TERMINATION 9.1 The Agreement shall commence on the Effective Date and
continue in effect for the Service Period, unless terminated earlier as provided in this Section.
This Agreement is a memorialization of an earlier oral Agreement and shall be deemed to apply for
the entire Service Period. The Agreement may be extended or renewed by the Parties in a writing
executed by authorized representatives of each of the Parties. 9.2 This Agreement may be terminated
by either Party prior to the end of the Service Period if the other Party is in material breach of
any tem, or condition of this Agreement and such breach la not remedied for a period of thirty (30)
days after the Party in breach has been notified In writing of such breach by the other Party. 9.3
This Agreement terminates automatically, with no further act or action of either Party, if: (a) so
required by applicable law or regulations; or (b) a receiver is appointed for a Party or its
property, a Party makes an assignment for the benefit of its creditors, goes bankrupt or is
liquidated or dissolved. 5
<!-- page 6 -->
9.4 Upon termination or expiration of this Agreement (i) Each Party shall return to the other Party
or destroy (If so authorized in writing by the other Party) any Confidential information in the
Party's possession or control, and cause an officer to certify in writing to the other Party that it
has done so; (ii) Each Party's rights to be paid and each Party's obligations to pay all amounts due
hereunder, as well as Sections 3 through 10 shall survive termination of this Agreement. 10.
MISCELLANEOUS 10.1 The Parties to this Agreement are independent contractors. Nothing in this
Agreement is intended or should be construed to create an agency, partnership, Joint venture, or
employer-employee relationship between PC Financial and Mobimagic. Either Party will represent
itself to be an employee or agent of the other Party or enter into any agreement on the other
Party's behalf or in the other Party's name. Each Party will retain full control over the manner and
means by which it conducts its business and neither Party will be entitled to waive any entitlement
to workers' compensation, disability, retirement, insurance, stock options or any other benefits
afforded to its employees. 10.2 IN NO EVENT WILL EITHER PARTY BE LIABLE FOR ANY CONSEQUENTIAL,
INDIRECT, EXEMPLARY, SPECIAL, OR INCIDENTAL DAMAGES ARISING FROM OR RELATING TO THIS AGREEMENT.
NEITHER PARTIES' TOTAL CUMULATIVE LIABILITY IN CONNECTION WITH THIS AGREEMENT, WHETHER IN AGREEMENT
OR TORT OR OTHERWISE, WILL NOT EXCEED THE AGGREGATE AMOUNT OF FEES AND EXPENSES OWED BY PC FINANCIAL
TO MOBIMAGIC FOR SERVICES PERFORMED UNDER THIS AGREEMENT. 10.3 This Agreement (and any question
about its subsistence, effect or termination) is to be interpreted in accordance with the laws of
India, save for that body of law which governs the conflict of laws. The courts of New Delhi shall
have exclusive jurisdiction to settle any dispute between the Parties whether arising In connection
with this agreement or otherwise. In the event of any dispute with respect to the construction,
execution and performance of the provisions of this Agreement, such dispute shall be settled by
arbitration in accordance with the Arbitration and Conciliation Act, 1996 and rules made thereunder
in force as on that date. The arbitration shall be carried out in English language and the
venue/seat of arbitration shall be New Delhi. The Arbitration award shall be final and binding on
the parties. 10.4 If any provision of this Agreement is, for any reason, held to be Invalid or
unenforceable, the other provisions of this Agreement will be unimpaired and the invalid or
unenforceable provision will be deemed modified so that it is valid and enforceable to the maximum
extent permitted by law. 10.5 This Agreement may not be assigned, delegated, or otherwise
transferred, in whole or in part, by operation of law or otherwise, by a Party without the other
Party's express prior written consent. Any attempted assignment, delegation, or transfer in
violation of the foregoing will be null and void. 10.6 All waivers must be in writing and signed by
the Party to be charged. Any waiver or failure to enforce any provision of this Agreement on one
occasion will not be deemed a waiver of any other provision or of such provision on any other
occasion. 6
<!-- page 7 -->
10.7 This Agreement is the final, complete, and exclusive agreement of the Parties with respect to
the subject matter hereof and supersedes and merges all prior or contemporaneous communications and
understandings between the Parties. No modification of or amendment to this Agreement will be
effective unless in writing and signed by the Party to be charged. IN WITNESS WHEREOF, the Parties
have executed this Agreement as of the Effective Date. PC Financial Services Private Limited
Mobimagic Co., Ltd. Signed:/s/ Mars Zhang Signed:/s/ Jiaojiao Liu Name: Mars Zhang Name: Jiaojiao
Liu Title: Chief Executive Officer Title: Authorized Signatory 7
