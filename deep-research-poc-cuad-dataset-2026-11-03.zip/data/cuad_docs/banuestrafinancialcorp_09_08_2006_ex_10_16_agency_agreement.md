<!-- page 1 -->
# AGENCY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Agency Agreement |
| SEC Filing Date | 2006-09-08 |
| Parties | El Banco Financial Corporation (the "Company"); sales agent (the "Agent" or "you") |
| Source | CUAD v1 / BANUESTRAFINANCIALCORP_09_08_2006-EX-10.16-AGENCY AGREEMENT |

QuickLinks -- Click here to rapidly navigate through this document

Exhibit 10.16

EL BANCO FINANCIAL CORPORATION

AGENCY AGREEMENT

, 2006

Ladies and Gentlemen:

El Banco Financial Corporation, a Georgia corporation (the "Company"), proposes, subject to the
terms and conditions stated herein, to engage the sales agent identified on the signature page to
this Agreement (the "Agent" or "you") to assist the Company on a "best efforts" basis in the sale of
the Company's common stock, $.01 par value per share (the "Shares").

1. The Offering. The Company is offering the Shares, in connection with the Company's initial public
offering (the "Offering").

The Company has prepared and filed, in accordance with the provisions of the Securities Act of 1933
and the rules and regulations thereunder (collectively, the "1933 Act"), with the Securities and
Exchange Commission (the "Commission") a registration statement on Form SB-2 (File No. 333-135900)
under the 1933 Act, including a prospectus, relating to the Shares. Except where the context
otherwise requires, "Registration Statement," as used herein, means the registration statement, as
amended at the time of such registration statement's effectiveness for purposes of Section 11 of the
1933 Act (the "Effective Time"), including (i) all documents filed as a part thereof, (ii) any
information contained in a prospectus subsequently filed with the Commission pursuant to Rule 424(b)
under the 1933 Act and deemed, pursuant to Rule 430A or Rule 430C under the 1933 Act, to be part of
the registration statement at the Effective Time, and (iii) any registration statement filed to
register the offer and sale of the Shares pursuant to Rule 462(b) under the 1933 Act.

Except where the context otherwise requires, a "Preliminary Prospectus," as used herein, means any
preliminary prospectus included in the Registration Statement or filed with the Commission pursuant
to Rule 424(a) under the Securities Act.

Except where the context otherwise requires, "Prospectus," as used herein, means the prospectus
filed by the Company with the Commission pursuant to Rule 424(b) under the 1933 Act on or before the
second business day after the Effective Time (or such earlier time as may be required under the
Act), or, if no such filing is required, the final prospectus included in the Registration Statement
at the Effective Time.

"Permitted Free Writing Prospectuses," as used herein, means the documents and each "road show" (as
defined in Rule 433(h)(4) under the 1933 Act), if any, related to the offering of the Shares
contemplated hereby that is a "written communication" (as defined in Rule 405 under the 1933 Act).

"Disclosure Package," as used herein, means any Preliminary Prospectus together with any combination
of one or more of the Permitted Free Writing Prospectuses, if any.

"Blue Sky Application," as used herein, means any instrument or document executed by the Company or
based upon written information supplied by the Company filed in any state or jurisdiction to
register or qualify any or all of the Shares or to claim an exemption therefrom or provided to any
state or jurisdiction to exempt the Company as a broker-dealer or the officers, directors or
employees as broker-dealers or agents of the Company under the securities laws thereof.

Any reference herein to the Registration Statement, any Preliminary Prospectus, the Prospectus or
any Permitted Free Writing Prospectus shall be deemed to refer to and include the documents, if any,
incorporated by reference, or deemed to be incorporated by reference, therein (the "Incorporated
Documents"), including, without limitation, unless the context otherwise requires, the documents, if
<!-- page 2 -->
any, filed as exhibits to such Incorporated Documents. Any reference herein to the terms "amend,"
"amendment" or "supplement" with respect to the Registration Statement, any Preliminary Prospectus,
the Prospectus or any Permitted Free Writing Prospectus shall be deemed to refer to and include the
filing of any document under the Securities Exchange Act of 1934 and the rules and regulations
thereunder (the "Exchange Act") on or after the Effective Time, or the date of such Preliminary
Prospectus, the Prospectus or such Permitted Free Writing Prospectus, as the case may be, and deemed
to be incorporated therein by reference.

2. Retention of Agent; Compensation; Sale and Delivery of the Shares. Subject to the terms and
conditions herein set forth, the Company hereby appoints the Agent as a placement agent, on a
non-exclusive basis, to utilize its "best efforts" to solicit subscriptions for the Shares and to
assist the Company with respect to the Company's sale of the Shares in the Offering.

On the basis of the representations and warranties and subject to the terms and conditions of this
Agreement, the Agent accepts such appointment. The Agent shall not be obligated to purchase any
Shares and shall not be obligated to take any action which Agent deems to be inconsistent with any
applicable law, regulation, decision or order. Subscriptions will be offered as described in the
Registration Statement. Except as otherwise provided in this Agreement, the appointment of the Agent
will terminate upon completion, expiration or termination of the Offering.

In the event the Company is unable to sell a minimum of 1,875,000 Shares on or before June 30, 2007,
this Agreement shall terminate and the Company shall cause the Escrow Agent (as defined below) to
refund to any persons who have subscribed for any of the Shares the full amount it received from
them, without interest, as set forth in the Prospectus; and none of the parties to this Agreement
shall have any obligation to the other parties hereunder, except as set forth in this Section 2 and
in Sections 8, 10, and 11.

In the event the Offering is terminated and the Closing (as defined below) does not occur, then the
Agent shall not receive the fees set forth in subparagraph (a) below (the "Fees"); provided,
however, regardless of whether or not the Closing occurs, the Agent shall be entitled to receive
reimbursement of its actual accountable out-of-pocket expenses, as set forth in subparagraph (b)
below.

If all conditions precedent to the consummation of the Offering are satisfied, the Company agrees to
issue, or have issued, the Shares sold in the Offering and to release for delivery certificates for
such Shares on the Closing Date (as defined below) against payment to the Company by any means
authorized pursuant hereto; provided, however, that no funds shall be released to the Company until
the conditions specified in Section 9 hereof shall have been complied with to the reasonable
satisfaction of the Company. The release of Shares against payment therefor shall be made on a date
or dates and at a place determined by the Company (each closing, a "Closing"). Certificates for
Shares shall be delivered directly to the purchasers in accordance with their directions. The date
upon which the Company shall release or deliver the Shares sold in the Offering, in accordance with
the terms herein, is called the "Closing Date." After the initial Closing, which may occur at any
time after the minimum of 1,875,000 Shares have been sold, the Company may continue the Offering and
the Agent may continue to solicit purchasers for the Shares up to the maximum amount of the Offering
or until the Offering expires or is closed by the Company as set forth in the Prospectus. Additional
Closings shall occur with respect to Shares sold after the initial Closing on dates and at locations
as determined by the Company after the initial Closing, each also considered a "Closing Date".

The Agent shall receive the following compensation for its services hereunder:

a. The fee shall be equal to 5.2% of the "gross proceeds" received in the Offering attributable to
the efforts of the Agent. At least 48 hours prior to each Closing, the Agent shall deliver a
schedule, identified as Appendix A, that lists each investor and the amount of investment.

2
<!-- page 3 -->
b. Agent shall be reimbursed for expenses as contemplated by Section 8 of this Agreement, regardless
of whether the Offering is successfully completed. Any out-of-pocket expenses or commissions payable
under this Agreement shall be paid in next day funds on the earlier of the initial Closing Date or a
determination by the Company to terminate or abandon the Offering, and on each subsequent Closing
Date thereafter.

3. Representations and Warranties of the Company. The Company represents and warrants to the Agent
that:

a. The Company has all such power, authority, authorizations, approvals and orders as may be
required to enter into this Agreement, to carry out the provisions and conditions hereof and to
issue and sell the Shares as contemplated herein and as described in the Registration Statement, any
Preliminary Prospectuses, the Prospectus or any Permitted Free Writing Prospectus. The consummation
of the Offering, the execution, delivery and performance of this Agreement and the consummation of
the transactions contemplated herein have been duly and validly authorized by all necessary
corporate action on the part of the Company and this Agreement has been validly executed and
delivered by the Company and is the valid, legal and binding agreement of the Company enforceable in
accordance with its terms, except to the extent, if any, that the provisions of Section 10 hereof
may be unenforceable as against public policy, and except to the extent that such enforceability may
be limited by bankruptcy laws, insolvency laws, or other laws affecting the enforcement of
creditors' rights generally.

b. The Registration Statement is effective under the 1933 Act; no stop order of the Commission
preventing or suspending the use of any Preliminary Prospectus or Permitted Free Writing Prospectus
or the effectiveness of the Registration Statement has been issued, and no proceedings for such
purpose have been instituted or, to the knowledge of the Company, are contemplated by the
Commission; the Registration Statement complied when it became effective, complies as of the date
hereof and, as amended or supplemented, at each time a subscription agreement of funds are submitted
by prospective investors to the Company during the Offering period (each such time referred to as a
"time of delivery"), at the Closing Date and at all times during which a prospectus is required by
the 1933 Act to be delivered (whether physically or through compliance with Rule 172 under the 1933
Act or any similar rule) in connection with any sale of Shares, will comply, in all material
respects, with the requirements of the 1933 Act; each Preliminary Prospectus complied, at the time
it was filed with the Commission, and complies as of the date hereof, in all material respects, with
the requirements of the 1933 Act; at no time during the period that begins on the earlier of the
date of such Preliminary Prospectus and the date such Preliminary Prospectus was filed with the
Commission and ends at the Closing Time (as defined herein) did or will any Preliminary Prospectus,
as then amended or supplemented, include an untrue statement of a material fact or omit to state a
material fact necessary in order to make the statements therein, in light of the circumstances under
which they were made, not misleading, and at no time during such period did or will any Preliminary
Prospectus, as then amended or supplemented, together with any combination of one or more of the
then issued Permitted Free Writing Prospectuses, if any, include an untrue statement of a material
fact or omit to state a material fact necessary in order to make the statements therein, in the
light of the circumstances under which they were made, not misleading; the Prospectus will comply,
as of its date, the date that it is filed with the Commission, each time of delivery, the Closing
Date and at all times during which a prospectus is required by the Act to be delivered (whether
physically or through compliance with Rule 172 under the 1933 Act or any similar rule) in connection
with any sale of Shares, in all material respects, with the requirements of the 1933 Act (including,
without limitation, Section 10(a) of the 1933 Act); at no time during the period that begins on the
earlier of the date of the Prospectus and the date the Prospectus is filed with the Commission and
ends at the later of the Closing Time and the end of the period during which a prospectus is
required by the 1933 Act to be delivered (whether physically or through compliance with Rule 172
under the 1933 Act or any similar rule) in connection with any sale of Shares did or will the
Prospectus, as then amended or

3
<!-- page 4 -->
supplemented, include an untrue statement of a material fact or omit to state a material fact
necessary in order to make the statements therein, in the light of the circumstances under which
they were made, not misleading; at no time during the period that begins on the date of such
Permitted Free Writing Prospectus and ends at the time of purchase did or will any Permitted Free
Writing Prospectus include an untrue statement of a material fact or omit to state a material fact
necessary in order to make the statements therein, in the light of the circumstances under which
they were made, not misleading; provided, however, that the Company makes no representation or
warranty with respect to any statement contained in the Registration Statement, any Preliminary
Prospectus, the Prospectus or any Permitted Free Writing Prospectus in reliance upon and in
conformity with information concerning the Agent and furnished in writing by or on behalf of the
Agent to the Company expressly for use in the Registration Statement, such Preliminary Prospectus,
the Prospectus or such Permitted Free Writing Prospectus, as applicable. All Permitted Free Writing
Prospectuses were preceded by, or accompanied with, a statutory prospectus meeting the requirements
of Section 10(a) of the Act as required by Rule 164 under the 1933 Act.

c. If a Permitted Free Writing Prospectus is sent or given after the Registration Statement is filed
with the Commission (and after such Permitted Free Writing Prospectus was, if required pursuant to
Rule 433(d) under the 1933 Act, filed with the Commission), the sending or giving, by the Agent, of
any Permitted Free Writing Prospectus will satisfy the provisions of Rule 164 or Rule 433 of the
1933 Act (without reliance on subsections (b), (c) and (d) of Rule 164); each of the Preliminary
Prospectuses is a prospectus that, other than by reason of Rule 433 or Rule 431 under the 1933 Act,
satisfies the requirements of Section 10 of the 1933 Act, including a price range where required by
rule; neither the Company nor the Agent is disqualified, by reason of subsection (f) or (g) of Rule
164 under the 1933 Act, from using, in connection with the offer and sale of the Shares, "free
writing prospectuses" (as defined in Rule 405 under the 1933 Act) pursuant to Rules 164 and 433
under the 1933 Act; the Company is not an "ineligible issuer" (as defined in Rule 405 under the 1933
Act) as of the eligibility determination date for purposes of Rules 164 and 433 under the 1933 Act
with respect to the offering of the Shares contemplated by the Registration Statement; the parties
hereto agree and understand that the content of any and all road shows related to the Offering is
solely the property of the Company.

d. No Blue Sky Application will include an untrue statement of a material fact or omits to state a
material fact necessary in order to make the statements therein, in the light of the circumstances
under which they were made, not misleading; provided, however, that the Company makes no
representation or warranty with respect to any statement contained in a Blue Sky Application in
reliance upon and in conformity with information concerning the Agent and furnished in writing by or
on behalf of the Agent to the Company expressly for use in the Blue Sky Application.

e. The Company has been duly incorporated and is validly existing as a corporation in good standing
under the laws of State of Georgia, and has corporate power and authority to own, lease or operate
its properties and to conduct its business as described in the Registration Statement, the
Preliminary Prospectuses, the Prospectus and the Permitted Free Writing Prospectuses, if any, and to
enter into and perform its obligations under this Agreement.

f. Since the respective dates as of which information is given in the Registration Statement, the
Preliminary Prospectuses, the Prospectus and the Permitted Free Writing Prospectuses, if any, except
as otherwise stated therein, there has been no material adverse change in the condition, financial
or otherwise, or in the earnings, business affairs or business prospects of the Company considered
as one enterprise, whether or not arising in the ordinary course of business (a "Material Adverse
Effect").

g. The Company has an authorized capitalization as set forth in the Registration Statement, the
Preliminary Prospectuses, the Prospectus and the Permitted Free Writing Prospectuses, if any.

4
<!-- page 5 -->
h. The Shares have been duly and validly authorized and, when issued and delivered against payment
therefor as provided herein, will be duly and validly issued and fully paid and nonassessable and
will conform to the description of the Shares contained in the Registration Statement, the
Preliminary Prospectuses, the Prospectus and the Permitted Free Writing Prospectuses, if any.

i. The issuance and sale of the Shares being issued at each Closing Date by the Company and the
performance of this Agreement and the consummation by the Company of the other transactions herein
contemplated will not conflict with or result in a breach or violation of any terms or provisions
of, or constitute a default under, any indenture, mortgage, deed of trust, loan agreement or other
agreement or instrument to which the Company is a party or by which any of the property or assets of
the Company is bound or to which any of the property or assets of the Company is subject, nor will
such action result in any violation of the provisions of the Articles of Incorporation, as amended,
or Bylaws, as amended, of the Company or any statute or any order, rule or regulation of any court
or governmental agency or body having jurisdiction over the Company or any of its properties; and no
consent, approval, authorization, order, registration or qualification of or with any such court or
governmental agency or body is required for the issuance and sale of the Shares or the consummation
by the Company of the transactions contemplated by this Agreement, except such consents, approvals,
authorizations, registrations or qualifications as may be required under the Act and under state
securities or Blue Sky laws in connection with the purchase and distribution of the Shares by the
Agent.

j. The Company owns its assets and has the right to conduct its business as currently conducted.

k. There is no litigation or governmental proceeding pending or threatened against, or involving the
properties or business of, the Company that might materially and adversely affect the value or the
operation of the any such properties or the business of the Company.

l. McNair, McLemore, Middlebrooks & Co., LLP, which has certified certain financial statements and
supporting schedules of the Company included in the Registration Statement, the Preliminary
Prospectus, the Prospectus and the Free Writing Prospectuses containing an audit report, are
independent public accountants as required by the Act and the rules and regulations of the
Commission thereunder.

m. The Company has not distributed, nor will it distribute, prior to the Closing Time any prospectus
(as defined under the 1933 Act) in connection with the Offering and sale of the Shares other than
the Registration Statement, any Preliminary Prospectuses, the Prospectus, any Permitted Free Writing
Prospectuses or other materials, if any, permitted by the 1933 Act, including Rule 134 promulgated
thereunder.

4. Representations and Warranties of the Agent.

a. The Agent has all such power, authority, authorizations, approvals and orders as may be required
to enter into this Agreement, to carry out the provisions and conditions hereof and to act as a
sales agent as contemplated herein and as described in the Registration Statement, any Preliminary
Prospectuses, the Prospectus or any Permitted Free Writing Prospectus. The consummation of the
Offering, the execution, delivery and performance of this Agreement by the Agent and the
consummation by the Agent of the transactions herein contemplated have been duly and validly
authorized by all necessary corporate action on the part of the Agent and this Agreement has been
validly executed and delivered by the Agent and is the valid, legal and binding agreement of the
Agent enforceable in accordance with its terms, except to the extent, if any, that the provisions of
Section 8 hereof may be unenforceable as against public policy, and except to the extent that such
enforceability may be limited by bankruptcy laws, insolvency laws, or other laws affecting the
enforcement of creditors' rights generally.

5
<!-- page 6 -->
b. The Agent is registered as a broker-dealer under applicable federal and state laws, is a member
in good standing of the National Association of Securities Dealers, Inc., and has met and will
continue to meet all registration, licensing, financial and reporting requirements it is required to
meet under applicable federal and state laws and regulations in order to provide the services the
Agent has agreed to provide, or that the Agent contemplates that it will provide, to the Company
under this Agreement or otherwise in connection with the Offering.

c. Each employee, agent, representative or affiliate of the Agent that provides any services to the
Company under this Agreement or otherwise in connection with the Offering will, at the time of
providing those services, meet all registration and licensing requirements he or it is required to
meet under applicable federal and state laws and regulations in order to provide those services.

5. Delivery and Payment.

An escrow procedure shall be established which shall comply with Commission Rule 15c2-4, promulgated
under the Exchange Act and applicable NASD rules and regulations, with Flag Bank as escrow agent
(the "Escrow Agent").

The Company and the Agent shall transmit all funds received from subscribers to the Escrow Agent by
noon of the next business day following receipt thereof. The Company shall direct the Escrow Agent
to make payment for Shares sold hereunder by wire transfer or certified or bank cashier's check
drawn to the order of the Company in next day funds. Such payment is to be made at the offices of
Flag Bank, at 10:00 a.m. local time, on each Closing Date or at another time agreed to by the Agent
and the Company. The time of such payment is referred to as the "Closing Time." The Company shall
direct the Escrow Agent to deliver payment of the fees due to the Agent pursuant to Section 2 hereof
(less any portion thereof previously paid to the Agent) to the Agent by wire transfer or certified
or bank cashier's check drawn to the order of the Agent in next day funds, to the Agent on each
Closing Date.

6. Covenants of the Company. The Company hereby covenants to the Agent as follows:

a. The Company has filed the Registration Statement with the Commission. The Company will use its
best efforts to cause any post-effective amendment to the Registration Statement to be declared
effective by the Commission, and will immediately upon receipt of any information concerning the
events listed below notify the Agent (i) when the Registration Statement, as amended, has become
effective; (ii) of any request by the Commission or any other governmental entity for any amendment
or supplement to the Registration Statement; (iii) of the issuance by the Commission or any other
governmental agency of any order or other action suspending the Offering or the use of the
Registration Statement, the Preliminary Prospectuses, the Prospectus or the Permitted Free Writing
Prospectuses, if any; or (iv) of the issuance by the Commission or any state authority of any stop
order suspending the effectiveness of the Registration Statement or of the initiation or threat of
initiation or threat of any proceedings for that purpose.

b. The Company will deliver to the Agent copies of the Registration Statement, as originally filed
and each amendment thereto. Further, the Company will deliver such additional copies of the
foregoing documents to counsel to the Agent as may be required for any NASD filings. The Company
will also deliver to the Agent such number of copies of the Prospectus, as amended or supplemented,
as the Agent may reasonably request.

c. The Company will comply in all material respects with any and all terms, conditions, requirements
and provisions with respect to the Offering and the transactions contemplated thereby imposed by the
Commission, by applicable state law and regulations, and by the 1933 Act, the Exchange Act and the
rules and regulations of the Commission promulgated under such statutes, to be complied with prior
to or subsequent to the Closing Date.

6
<!-- page 7 -->
d. If any event relating to or affecting the Company shall occur, as a result of which it is
necessary, in the reasonable opinion of counsel for the Company, to amend or supplement the
Registration Statement, any Preliminary Prospectus, the Prospectus or any Permitted Free Writing
Prospectus in order to make them not misleading in light of the circumstances existing at the time
of its use, the Company will, at its expense, prepare, file with the Commission, and furnish to the
Agent, a reasonable number of copies of an amendment or amendments of, or a supplement or
supplements to, the Registration Statement, any Preliminary Prospectus, the Prospectus or any
Permitted Free Writing Prospectus which will amend or supplement the Registration Statement,
Preliminary Prospectus, Prospectus or any Permitted Free Writing Prospectus so that as amended or
supplemented it will not contain an untrue statement of a material fact or omit to state a material
fact necessary in order to make the statements therein, in light of the circumstances existing at
the time, not misleading.

e. The Company will endeavor in good faith, in cooperation with the Agent, to register or to qualify
the Shares for offering and sale under the applicable securities laws of the jurisdictions in which
the Offering will be conducted; provided, however, that the Company shall not be obligated to file
any general consent to service of process or to qualify to do business in any jurisdiction in which
it is not so qualified. In each jurisdiction where any of the Shares shall have been registered or
qualified as above provided, the Company will make and file such statements and reports in each year
as are or may be required by the laws of such jurisdictions.

f. Prior to the Closing Date, the Company will inform the Agent of any event or circumstances of
which it is aware as a result of which the Registration Statement, any Preliminary Prospectus, the
Prospectus, or any Permitted Free Writing Prospectus as then supplemented or amended, would include
an untrue statement of a material fact or omit to state a material fact necessary in order to make
the statements therein not misleading.

g. The Company will distribute the Prospectus or other offering materials in connection with the
offering and sale of the Shares only as set forth in the Prospectus, and only in accordance with the
1933 Act and the Exchange Act and the rules and regulations promulgated under such statutes, and the
laws of any state in which the Shares are qualified for sale.

h. The Company will maintain appropriate arrangements with the Escrow Agent for depositing all funds
received from persons mailing subscriptions for or orders to purchase Shares in the Offering as
described in the Prospectus until the Closing Date and satisfaction of all conditions precedent to
the release of the Company's obligation to refund payments received from persons subscribing for or
ordering Shares in the Offering as described in the Prospectus.

i. The Company will take such actions and furnish such information as are reasonably requested by
the Agent in order for the Agent to ensure compliance with the NASD Rule 2790 "Restrictions on the
Purchase and Sale of Initial Equity Public Offerings of Equity Securities."

j. The Company will not deliver the Shares until the Company has satisfied or caused to be satisfied
each condition set forth in Section 9 hereof.

7. Covenants of the Agent.

a. The Agent will not provide any service or engage in any activity, and it will not permit the
Agent or any of its employees, agents, representatives or affiliates to provide any service or
engage in any activity, whether pursuant to this Agreement or otherwise in connection with the
Offering, for which it or he does not have in effect all registrations, licenses and approvals
necessary to cause that service or activity to comply with applicable federal and state laws and
regulations.

b. Notwithstanding anything contained in this Agreement to the contrary, the terms and conditions of
the Offering as described in the Prospectus shall control the conduct of the Offering, and

7
<!-- page 8 -->
neither the Agent nor any of its respective employees, agents, representatives or affiliates shall
take any action in connection with the Offering contrary to those terms and conditions.

c. In connection with or during the course of the Offering, neither the Agent nor any employee,
agent, representative or affiliate of the Agent will make any representation or provide any
information to any subscriber or potential subscriber for the Shares other the representations and
information contained in the Prospectus or other information specifically approved by the Company.

8. Payment of Expenses. The Company covenants and agrees with the Agent that it will pay or cause to
be paid the following: (i) the fees, disbursements and expenses of counsel to the Company and
accountants in connection with the registration of the Shares under the Act and all other expenses
in connection with the preparation, printing and filing of the Registration Statement, each
Preliminary Prospectus, the Prospectus, each Permitted Free Writing Prospectus and any amendments or
supplements thereto, and the mailing and delivering of copies thereof to the Agent and dealers; (ii)
the cost of printing or reproducing this agreement, the Blue Sky Survey, any dealer agreements and
any other documents in connection with the offering, purchase, sale and delivery of the Shares;
(iii) all expenses in connection with the qualification of the Shares for offering and sale under
state securities laws; (iv) the cost of preparing stock certificates; (v) all expenses related to
road shows; (vi) the costs or expenses of any transfer agent or registrar; and (vi) all reasonable
out-of-pocket fees and expenses of the Agent, including the reasonable fees and expenses of counsel
for the Agent related to the Offering and not otherwise specifically provided for in this Section;
the total for all such reasonable out-of-pocket fees and expenses shall not exceed $5,000 without
the consent of the Company (exclusive of any blue sky-related fees if the Agent's counsel is
requested to complete such services by the Company).

9. Conditions to Closing. The Closing of the Offering is subject to the following conditions:

a. The Registration Statement and any registration statement required to be filed, prior to the sale
of the Shares, under the Act pursuant to Rule 424(b) shall have been filed and shall have become
effective under the 1933 Act.

b. (i) No stop order with respect to the effectiveness of the Registration Statement shall have been
issued under the Act or proceedings initiated under Section 8(d) or 8(e) of the 1933 Act; (ii) the
Registration Statement and all amendments thereto shall not contain an untrue statement of a
material fact or omit to state a material fact required to be stated therein or necessary to make
the statements therein not misleading; (iii) none of the Preliminary Prospectuses or the Prospectus,
and no amendment or supplement thereto, shall include an untrue statement of a material fact or omit
to state a material fact necessary in order to make the statements therein, in the light of the
circumstances under which they are made, not misleading; (iv) no Disclosure Package, and no
amendment or supplement thereto, shall include an untrue statement of a material fact or omit to
state a material fact necessary in order to make the statements therein, in the light of the
circumstances under which they are made, not misleading; and (v) none of the Permitted Free Writing
Prospectuses, if any, shall include an untrue statement of a material fact or omit to state a
material fact necessary in order to make the statements therein, in the light of the circumstances
under which they are made, not misleading.

c. The Company and Agent agree that Appendix A is accurate and complete.

d. The NASD has confirmed that it has not raised any objection with respect to the fairness and
reasonableness of the terms of this Agreement and Agent's compensation hereunder.

10. Indemnification by the Company.

a. The Company agrees to indemnify and hold harmless the Agent, and its officers, directors, agents,
representatives and affiliates and any other person, if any, who controls the Agent or its

8
<!-- page 9 -->
affiliates within the meaning of the 1933 Act (these parties together with the Agent are hereinafter
referred to as the "Agent Indemnitees") against any and all losses, claims, damages, liabilities and
expenses (including reasonable costs of investigation and counsel's fees) arising out of or based
upon the actions of the Company or any of its employees, agents, representatives or affiliates (i)
that constitute bad faith or gross negligence on the part of the Company or its employees, agents,
representatives or affiliates, (ii) that constitute violations of applicable federal or state laws
or regulations on the part of the Company or its employees, agents, representatives or affiliates,
or (iii) that constitute a violation of any of the Company's agreements, representations or
warranties contained in this Agreement. The Company will reimburse the Agent and the Agent
Indemnitees for any legal or other expenses reasonably incurred (individually or collectively) by it
or them in connection with investigating or defending any such loss, claim, damage, liability or
action. However, the Company will not be responsible for (i) any losses, claims, damages,
liabilities or expenses that result from bad faith or gross negligence on the part of the Agent or
any of its employees, agents, representatives or affiliates, or on the part of the Agent Indemnitee,
(ii) that arise out of actions or conduct by the Agent or any of its employees, agents,
representatives or affiliates, or by any Agent Indemnitee, that constitute a violation of any
applicable federal or state law or regulation, or (iii) that arise out of actions or conduct by the
Agent or any of its employees, agents, representatives or affiliates, or by any Agent Indemnitee,
that constitutes a violation of any of Agent's agreements, representations or warranties contained
in this Agreement.

b. If any action or claim shall be brought or asserted against an Agent Indemnitee in respect of
which indemnity may be sought from the Company, it or he shall promptly notify the Company in
writing, enclosing copies of all papers served on or delivered to such party. A failure to notify or
delay in notifying the Company shall not affect the right of the Agent Indemnitee to be indemnified
or reimbursed hereunder except to the extent the Company is shown to have been materially prejudiced
as a result of such failure. No Agent Indemnitee shall settle, compromise or consent to the entry of
any judgment with respect to any litigation, investigation or proceeding commenced or threatened by
any person or entity, including any governmental agency or body, or any claim whatsoever in respect
of which indemnification or contribution can be sought under this Section 10 (whether or not the
Agent Indemnitees are actual or potential parties thereto), unless the Agent or the Agent Indemnitee
obtains the prior written consent of the Company.

11. Indemnification by the Agent.

a. The Agent agrees to indemnify and hold harmless the Company, and its officers, directors, agents,
organizers, representatives and affiliates and any other person, if any, who controls the Company or
its affiliates within the meaning of the 1933 Act (these parties together with the Company are
hereinafter referred to as the "Company Indemnitees") against any and all losses, claims, damages,
liabilities and expenses (including reasonable costs of investigation and counsel's fees) arising
out of or based upon the actions of the Agent or any of its respective employees, agents,
representatives or affiliates (i) that constitute bad faith or gross negligence on the part of the
Agent or any of its employees, agents, representatives or affiliates, (ii) that constitute
violations of applicable federal or state laws or regulations on the part of the Agent or any of its
employees, agents, representatives or affiliates, or (iii) that constitutes a violation of any of
the Agent's agreements, representations or warranties contained in this Agreement. The Agent will
reimburse the Company and the Company Indemnitees for any legal or other expenses reasonably
incurred (individually or collectively) by it or them in connection with investigating or defending
any such loss, claim, damage, liability or action. However, the Agent will not be responsible for
(i) any losses, claims, damages, liabilities or expenses that result from bad faith or gross
negligence on the part of the Company or any of its employees, agents, representatives or
affiliates, or on the part of the Company Indemnitee, (ii) that arise out of actions or conduct by
the Company or any of its employees, agents, representatives or affiliates, or by the Company, that
constitute a violation of any applicable federal or state law or regulation, or

9
<!-- page 10 -->
(iii) that constitutes a violation of any of the Company's agreements, representations or warranties
contained in this Agreement.

b. If any action or claim shall be brought or asserted against a Company Indemnitee in respect of
which indemnity may be sought from the Agent, it shall promptly notify the Agent in writing,
enclosing copies of all papers served on or delivered to such party. A failure to notify or delay in
notifying the Agent shall not affect the right of the Company Indemnitee to be indemnified or
reimbursed hereunder except to the extent the Agent is shown to have been materially prejudiced as a
result of such failure. No Company Indemnitee shall settle, compromise or consent to the entry of
any judgment with respect to any litigation, investigation or proceeding commenced or threatened by
any person or entity, including any governmental agency or body, or any claim whatsoever in respect
of which indemnification or contribution can be sought under this Section 11 (whether or not the
Company Indemnitees are actual or potential parties thereto), unless the Company obtains the prior
written consent of the Company.

c. The Agent agrees to indemnify and hold harmless the Company Indemnitees against any and all
losses, liabilities, claims, damages and expenses to which it or they may become subject if such
losses, liabilities, claims, damages or expenses arise solely out of, or are based solely on, (i)
any untrue or alleged untrue statement of material fact contained in the Prospectus or any amendment
or supplement thereto, or the omission of a material fact required to be stated therein, or
necessary to make the statements therein not misleading, but only if such untrue statement or
omission or alleged omission was made in the Prospectus (as amended or supplemented) based upon and
in conformity with written information concerning the Agent furnished to the Company by the Agent
specifically for use in the Prospectus or (ii) any untrue or alleged untrue statement of material
fact contained in any other information (whether oral or in writing) provided by the Agent or any of
its respective employees, agents, representatives or affiliates to the Company or any other person
in the course of providing services pursuant to this Agreement or otherwise in connection with the
Offering.

12. Representations and Indemnities to Survive. All representations, warranties and agreements
contained in this Agreement of the Company and the Agent shall remain in full force and effect,
regardless of any termination or cancellation of this Agreement, and shall survive delivery of and
payment for the Shares.

13. Termination and Payment of Expenses. This Agreement shall become effective on the date hereof
and shall terminate upon the termination of the Offering. If for any reason any Shares are not
delivered by or on behalf of the Company as provided herein, the Company will reimburse the Agent
for all actual and accountable out-of-pocket expenses, including fees and disbursements of counsel,
reasonably incurred by the Agent in making preparations for the purchase, sale and delivery of the
Shares not so delivered, but the Company shall then be under no further liability to the Agent
except as provided in Section 8 and Section 10 hereof.

10
<!-- page 11 -->
14. Notices. All statements, requests, notices and agreements hereunder shall be in writing and
shall be sufficient in all respects if delivered or sent by reliable courier, first class mail, or
facsimile transmission to:

Agent: As set forth on the signature page to this agreement

Company: El Banco Financial Corporation 623 Holcomb Bridge Road Roswell, Georgia 30076 Facsimile:
(678) 352-1514

With a copy to: Nelson Mullins Riley & Scarborough LLP 999 Peachtree Street, Suit 1400 Atlanta,
Georgia 30309 Attention: Rusty Pickering Facsimile: (404) 817-6050

Any such statements, requests, notices or agreements shall take effect upon receipt thereof.

15. Non-Exclusive. This Agreement does not create an exclusive arrangement for the Agent to provide
services to the Company, and nothing in this Agreement shall preclude the Company from contracting
or entering into an arrangement with any other sales agent, consultant, broker-dealer or other
person for such other person or entity to provide services to the Company as agent in the Offering
and to receive compensation from the Company in connection with the Offering.

16. Successors. This Agreement shall be binding upon, and inure solely to the benefit of, the Agent
and the Company, and to the extent provided in Sections 10, 11 and 12 hereof; the officers and
directors of the Company and each person who controls the Company, or the Agent, and their
respective heirs, executors, administrators, successors and assigns, and no other person shall
acquire or have any right under or by virtue of this agreement. No purchaser of any of the Shares
from the Agent shall be deemed a successor or assign by reason merely of such purchase.

17. Time of the Essence. Time shall be of the essence in this Agreement.

18. Business Day. As used herein, the term "business day" shall mean any day when the Commission's
office in Washington, D.C. is open for business.

19. Applicable Law. THIS AGREEMENT IS TO BE CONSTRUED IN ACCORDANCE WITH AND GOVERNED BY THE LAWS OF
THE STATE OF GEORGIA (WITHOUT REGARD TO THOSE LAWS RELATING TO CHOICE OF LAW) APPLYING TO CONTRACTS
ENTERED INTO AND TO BE PERFORMED WITHIN THE STATE OF GEORGIA. VENUE FOR ANY CAUSE OF ACTION ARISING
FROM THIS AGREEMENT WILL LIE IN FULTON COUNTY, GEORGIA.

20. Captions. The captions included in this Agreement are included solely for convenience of
reference and shall not be deemed to be a part of this Agreement.

21. Counterparts. This Agreement may be executed by any one or more of the parties in any number of
counterparts, each of which shall be deemed to be an original, but all such counterparts shall
together constitute one and the same instrument.

22. Pronouns. All pronouns used herein shall be deemed to refer to the masculine, feminine or neuter
gender as the context requires.

[Signatures on Following Page]

11
<!-- page 12 -->
IN WITNESS WHEREOF, each of the Parties has caused this Agreement to be executed on its behalf by
its duly authorized officers as of the day and year first above written.

EL BANCO FINANCIAL CORPORATION

By: Name: Its:

(SALES AGENT) By: Name: Its: Address:

12
<!-- page 13 -->
Appendix A

Name of Investor

Amount of Investment

13
<!-- page 14 -->
QuickLinks

EL BANCO FINANCIAL CORPORATION AGENCY AGREEMENT Appendix A
