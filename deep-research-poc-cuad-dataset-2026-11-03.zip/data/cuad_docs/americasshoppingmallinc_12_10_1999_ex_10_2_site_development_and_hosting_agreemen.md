<!-- page 1 -->
# SITE DEVELOPMENT AND HOSTING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Hosting Agreement |
| Agreement Date | 1999-08-09 |
| Parties | Hanover Direct, Inc. ("HDI"); The Deerskin Companies, Inc. ("Company") |
| Source | CUAD v1 / AMERICASSHOPPINGMALLINC_12_10_1999-EX-10.2-SITE DEVELOPMENT AND HOSTING AGREEMENT |

EXHIBIT 10.2

SITE DEVELOPMENT AND HOSTING AGREEMENT

This SITE DEVELOPMENT AND HOSTING AGREEMENT (the "Agreement") dated as of August 9, 1999 is made
between Hanover Direct, Inc. ("HDI"), a New Jersey Corporation, located at 1500 Harbor Boulevard,
Weehawken, NJ 07087, and The Deerskin Companies, Inc. (the "Company"), a Nevada corporation, located
at 2500 Arrowhead Drive, Carson City, NV 89706. Each of the parties hereto shall be referred to as a
"Party".

In consideration of the mutual promises and covenants set forth below, HDI and the Company agree as
follows:

1. HDI's Responsibilities.

1.1 HDI shall design, develop, implement, operate, maintain and manage, and enable the Company to
establish a presence on the World Wide Web ("Site") to make available to Internet users on demand,
men's and women's apparel and accessories from the Deerskin Catalog ("Deerskin Products"). As used
in this Agreement, "Deerskin Products" shall not include (i) closeout merchandise which the Company
may identify as "Deerskin" branded items, if such is the case, nor (ii) products from the Company's
Joan Cook Catalog.

1.2 HDI shall bear all costs associated with the design, development, implementation, operation,
maintenance and management of the Site, including, without limitation, technology and labor.

1.3 HDI shall host and maintain the Site on a server provided by HDI.

1.4 HDI shall provide the Company with access to, and

the right to use, a computer system on which the Site will be stored and operated, with a direct
Internet connection of shared but greater than T-1 bandwidth, plus capacity to process continuously
during burst periods. HDI shall also provide the Company with access to HDI's software and Content
administration tools for purposes of allowing the Company to monitor current catalog information.

1.5 For the purposes of collecting orders for Deerskin Products from the Site and to communicate to
the Site the unavailability of certain Deerskin Products, HDI shall provide export files in the
format provided by the Company. HDI shall bear the programming and software costs relating to
efforts required to create order export files and receive and process import files of the Company's
inventory information.

1.6 HDI shall have the Site fully operational and accessible on demand by users of the Internet no
later than sixty (60) days from the date this Agreement has been executed by both Parties. In the
event that HDI fails to have the Site fully operational within seventy (70) days from the date of
this Agreement, the Company shall have the right to terminate this Agreement without penalty.

1.7 HDI shall distribute the Site through the world wide protocol of the Internet using distribution
channels used by HDI sites and other similar distribution channels.

1.8 HDI agrees that it shall promote the Site and Deerskin Products no less favorably than it
promotes HDI's

-2-

catalog titles. HDI's promotion of the Site and Deerskin Products shall include, but not be limited
to, the incorporation of the Site and Deerskin Products into HDI's promotion calendars with Xoom.com
and Excite for the term of this Agreement. HDI agrees that the costs of any such promotions shall be
borne by HDI.

2. Company's Responsibilities.

2.1 The Company shall provide all Content to HDI to be included in the Site no later than ten (10)
days from the date this Agreement has been executed by both Parties.

2.2 The Company shall bear all costs associated with the processing of customer orders.

3. Fees; Payment.

3.1 The Company shall pay HDI thirty percent (3016) of the Net Sales in excess of Eleven Thousand
Dollars ($11,000) per calendar month. "Net Sales" shall mean all revenues from the sale of Deerskin
Products on the Site including shipping and handling charges, minus refunds and exchanges.
<!-- page 2 -->
3.2 Payments to HDI shall be due monthly within thirty (30) days of the end of each calendar month
and shall be accompanied by documentation reasonably detailing the calculation of the payment.

3.3 Quarterly reconciliation of payments shall be conducted within thirty (30) days of the end of
each calendar quarter to adjust for refunds and exchanges not taken into account in payments made to
HDI.

-3-

3.4 HDI's General Manager (as hereinafter defined), may upon no less than thirty (30) days prior
written notice to the Company, have the right to inspect the records of the Company's General
Manager reasonably related to the calculation of such payments during the Company's normal business
hours. The fees incurred by HDI in connection with the inspection shall be borne by HDI.

4. Term; Termination; Termination Payment.

4.1 Term; Termination. This Agreement shall be effective as of that date (the "Effective Date") the
Site becomes fully operational as set forth in writing and executed by both Parties and shall
continue for a period of one (1) year from the Effective Date. This Agreement shall be automatically
renewed for an additional one year period on each anniversary of the Effective Date, unless
terminated by either Party hereto upon ninety (90) days written notice to the other. Such notice
shall specify the date on which this Agreement is to be terminated (the "Termination Date").

4.2 Termination Payment.

(a) In the event the Company terminates this Agreement, the Company shall pay to HDI a termination
payment, (the "Termination Payment") the amount of which shall be an amount equal to the aggregate
Net Sales for the twelve (12) months preceding the Termination Date less $800,000, the balance of
which shall be divided by two.

(b) In the event that the amount of the Termination

-4-

Payment is determined pursuant to this Section 4.2 to be less than or equal to zero, then no
Termination Payment shall be due to HDI nor shall HDI be required to make any termination payment to
the Company if the amount is determined to be less than zero.

(c) The Termination Payment, if any, shall be payable by the Company in eight (8) equal payments to
be made quarterly, commencing thirty (30) days after the termination date.

5. Site; Site Management.

5.1 URL. The Uniform Resource Locator, or address on the World Wide Web for the Site ("URL") shall
be as mutually agreed by the Parties and shall be established and registered as necessary by HDI at
no cost to the Company.

5.2 The Company shall have exclusive artistic and editorial control over the Site, including,
without limitation, the implementation of the Content on the Site and the design and look and feel
of the Site. Neither the Site nor any portion of thereof shall be deemed accepted and approved by
the Company unless and until the Company accepts and approves same in writing to HDI. No portion of
the Site shall be made available on the Internet without the consent of the Company.

5.3 The Company shall be deemed the "merchant of record" for all commercial transactions on the Site
related to Deerskin Products. Until the sale of the Deerskin Products to the consumer from the Site
all title to the Deerskin Products shall remain with the Company.

5.4 Each of HDI and the Company shall appoint a

-5-

General Manager of its own to act as liaison with the other Party for the Site (each a "General
Manager") who shall bear sole responsibility for bookkeeping and business operations of the Site on
a day-today basis. Each General Manager shall have the authority to make and convey decisions on
behalf of each Party and to be the liaison with the other Party for all production and Content
matters.

6. Exclusivity.

6.1 Except as provided in Section 6.2, during the term of this Agreement, the Company shall not
participate in any project similar to the Site on the Internet with respect to Deerskin Products or
products substantially similar to Deerskin Products (including, without limitation, the products of
Wilson's House of Leather, Excelled and companies similar to Wilson's House of Leather and Excelled)
and HDI shall have the exclusive right to use of the "Deerskin" brand for a self-contained web site
for the offering of Deerskin Products directly to the consumer on the Internet.

The Company hereby grants to HDI a non-exclusive, limited, non-transferable license to use the
Company's "Deerskin" trademarks, service
<!-- page 3 -->
marks, and logos (collectively, "Marks") solely for the purpose of carrying out its obligations
under this Agreement. Except as provided herein, no licenses of the Company's Marks are granted or
implied under this Agreement.

6.2 The Company retains the right to establish a web site on the Internet for the purpose of
offering closeout

-6-

merchandise which may be identified as "Deerskin" branded products, if such is the case.

6.3 During the term of this Agreement and for a period of two years after the expiration date of
this Agreement, HDI shall not participate in any project similar to the Site on the Internet from
which products substantially similar to Deerskin Products (including, without limitation, the
products of Wilson's House of Leather, Excelled and and companies similar to Wilson's House of
Leather and Excelled) are offered for sale to consumers on the Internet.

7. Cross-Promotions.

7.1 Joint Efforts. The Parties agree to cross-promote one another's products through the use of
their respective customer e-mail lists on a reciprocal and equitable basis. The Parties specifically
agree that the form, content and design of any and all advertisements or promotional materials
featuring the other Party or such Party's products shall continue to be developed by or on behalf of
such Party and shall be subject to such Party's final approval. The Parties agree further that any
promotions or advertisements involving the use of a Party's customer e-mail list by the other Party
shall be subject to the prior approval of such Party.

7.2 Mutual Covenants as to Advertisements. The Parties hereby covenant and agree that their
respective marketing and advertising efforts provided for herein shall at all times comply with all
applicable laws rules and regulations and will

-7-

not contain any material which is obscene, threatening, fraudulent, harassing, libelous, infringing
of third party intellectual property rights, otherwise illegal or, in the reasonable judgment of the
Party required to display or transmit the advertisement, offensive.

8. Confidentiality.

8.1 Unless otherwise agreed to in writing by the Company, HDI shall maintain the strict
confidentiality and shall not disclose to any third party the existence of, or terms and conditions
of this Agreement. In addition, HDI, in performing the Services for the Company hereunder, may have
access to or be exposed to, directly or indirectly, Content, user information, data, knowledge and
proprietary and trade secret information of the Company in oral, graphic, written, electronic or
machine readable form (hereinafter collectively referred to as "Confidential Information").
Confidential Information shall not include information which can be demonstrated: (a) to have been
rightfully in the possession of HDI from a source other than the Company prior to the time of
disclosure of said information to HDI hereunder ("Time of Receipt"); (b) to have been in the public
domain prior to the Time of Receipt; (c) to have become part of the public domain after the Time of
Receipt by a publication or by any other means except an unauthorized act or omission or breach of
this Agreement on the part of HDI, its employees, or agents; or (d) to have been supplied to HDI
after the Time of Receipt by a third party who is under no obligation to the

-8-

Company to maintain such information in confidence.

8.2 HDI Obligations. All Confidential Information of the Company shall be held in strict confidence
by HDI and shall not be disclosed or used without express written consent of the Company, except as
may be required by law. HDI shall use reasonable measures and reasonable efforts to provide
protection for Confidential Information, including measures at least as strict as those HDI uses to
protect its own Confidential Information.

8.3 Company's Obligations. The Company acknowledges that it may receive confidential information of
HDI relating to its technical, marketing, product and/or business affairs. All such confidential
information of HDI shall be-held in strict confidence by the Company and shall not be disclosed or
used without express written consent of HDI, except as may be required by law. The Company shall use
reasonable measures and reasonable efforts to provide protection for such confidential information
of HDI, including measures at least as strict as those the Company uses to protect its own
Confidential Information.

-9-

9. Warranties.

(a) Each Party represents and warrants to the other Party that (1) it is a corporation organized,
validly existing and in goodstanding under the laws of the state of its incorporation; (2) it has
the full right power and authority to enter into, and to perform the obligations contemplated in
this Agreement, and the person signing on its behalf has the full right,
<!-- page 4 -->
power and authority to enter into this Agreement on behalf of the Party; (3) this Agreement
constitutes a legal valid and binding obligation of the Party, enforceable in accordance with its
terms; and (4) the execution of this Agreement will not conflict in any way with any pre-existing
agreements or understandings of the Party with any person or entity.

-10-

(b) HDI acknowledges that the Company is currently a party to a web-hosting agreement with Globix
Corporation (the "Globix Agreement") for the Company's web site offering Deerskin Products to
Internet customers. HDI agrees that the Company shall not be deemed in breach of any provision of
this Agreement by virtue of the Globix Agreement remaining in effect after this Agreement has been
executed by both Parties, provided, that the Globix Agreement is terminated on or prior to the
Effective Date

10. General Provisions.

10.1 Notices. Any notice under this Agreement will be in writing and delivered by personal delivery,
express courier, confirmed facsimile, or certified or registered mail, return receipt requested and
will be deemed given upon personal delivery, one (1) day after deposit with express courier, upon
confirmation of receipt of facsimile or five (5),days after deposit in the mail. Notices will be
sent to a Party at its address set forth above or such other address as that Party may specify in
writing pursuant to this Section.

10.2 No Joint Venture. The Parties agree that and acknowledge that the relationship of the Parties
is in the nature of an independent contractor. This Agreement shall not be deemed to create a
partnership or joint venture and neither Party is the other's agent, partner, employee or
representative. Neither Party shall have any right, power or authority to enter into any agreement
for or on behalf of, or to assume or create any obligation, liability, or responsibility on behalf
of the other.

-11-

This Agreement will not be construed to create or imply an association, joint venture, co-ownership,
or partnership between the Parties or to impose any partnership obligation or liability upon either
Party.

10.3 Assignment. This Agreement shall be binding upon, and shall inure to the benefit of and be
enforceable by, the parties hereto and their respective legal representatives, successors and
assigns, but no other person shall acquire or have any rights under this Agreement.

10.4 Waiver of Breach. The failure of either Party at any time to enforce any of the provisions of
this Agreement shall not be deemed or construed to be a waiver of any such provisions, or in any way
to affect the right of any Party hereto to thereafter enforce each and every provision of this
Agreement. No waiver of any breach of any provisions of this Agreement shall be effective unless set
forth in writing and executed by the Party against which enforcement of such waiver is sought; and
no waiver of any such breach shall be construed or deemed to be a waiver of any other or subsequent
breach.

10.5 Governing Law. This Agreement shall be governed and construed and enforced in accordance with
the laws of the State of New York applicable to contracts made and to be performed exclusively in
that State without giving effect to the principles of conflict of laws.

10.6 Severability. If any provision of this Agreement is declared invalid or otherwise determined to
be unenforceable

-12-

for any reason, such provision shall be deemed to be severable from the remaining provisions of this
Agreement, which shall otherwise remain in full force and effect.

10.7 Survival. Sections 6.3, 7, 9 and 10 of this Agreement shall survive and continue in full force
and effect for a period of two years from the expiration or termination of this Agreement.

10.7 Entire Agreement. This Agreement is the complete and exclusive agreement between the Parties
with respect to the subject matter hereof, superseding any prior agreements and communications (both
written and oral) regarding such subject matter. This Agreement may only be modified, or any rights
under it waived, by a written document executed by both Parties.

10.8 Headings; Counterparts. The section headings in this Agreement are for reference purposes only
and shall not define, limit or affect the meaning or interpretation of this Agreement. This
Agreement is being executed in two or more counterparts, each of which shall be deemed an original
but all of which shall constitute one and the same instrument.

IN WITNESS WHEREOF, the parties have duly executed this Agreement as of the date first above
written.

THE DEERSKIN COMPANIES, INC. HANOVER DIRECT, INC.

By By ------------------------------ --------------------------
<!-- page 5 -->
Name: Irwin Schneidmill Name: Rakesh K. Kaul Tilte: President Title:President

-13-
