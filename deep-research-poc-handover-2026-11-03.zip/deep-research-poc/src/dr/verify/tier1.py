"""Tier-1 deterministic citation alignment.

For each EvidenceItem: tokenize the quote and the cited page (or, if no page markers, the
cited line window ±20 lines); compute the fraction of the quote's n-grams present in the
source. Decide keep / truncate / drop. Zero-overlap quotes trigger a search of the other
workspace documents for the true source (EvidenT), which is reported, not silently applied.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from ..config import DEFAULT, Config
from ..models import EvidenceItem
from ..workspace import Workspace

_TOKEN_RE = re.compile(r"[a-z0-9]+(?:[.,][0-9]+)?")


def tokens(s: str) -> list[str]:
    return _TOKEN_RE.findall(s.lower())


def ngrams(toks: list[str], n: int) -> list[tuple[str, ...]]:
    if len(toks) < n:
        return [tuple(toks)] if toks else []
    return [tuple(toks[i : i + n]) for i in range(len(toks) - n + 1)]


@dataclass
class Alignment:
    status: str                 # keep | truncate | drop
    score: float                # fraction of quote n-grams found in source
    aligned_quote: str | None   # longest aligned span when truncating
    relocated_doc_id: str | None = None   # best other doc if zero overlap in the cited one
    relocated_score: float | None = None


def _source_text(ws: Workspace, it: EvidenceItem, pad: int = 20) -> str:
    if it.page is not None:
        txt = ws.page_text(it.doc_id, it.page)
        if txt:
            return txt
    lines = ws.lines(it.doc_id)
    s = max(0, it.start_line - 1 - pad)
    e = min(len(lines), it.end_line + pad)
    return "\n".join(lines[s:e])


def align_quote(quote: str, source: str, n: int, keep_thr: float, trunc_thr: float) -> tuple[str, float, str | None]:
    q = tokens(quote)
    s = set(ngrams(tokens(source), n))
    qg = ngrams(q, n)
    if not qg:
        return "drop", 0.0, None
    hits = [g in s for g in qg]
    score = sum(hits) / len(hits)
    if score >= keep_thr:
        return "keep", score, None
    if score >= trunc_thr:
        # longest run of aligned n-grams -> aligned token span
        best_len, best_start, cur_len, cur_start = 0, 0, 0, 0
        for i, h in enumerate(hits):
            if h:
                if cur_len == 0:
                    cur_start = i
                cur_len += 1
                if cur_len > best_len:
                    best_len, best_start = cur_len, cur_start
            else:
                cur_len = 0
        span = q[best_start : best_start + best_len + n - 1]
        return "truncate", score, " ".join(span) if span else None
    return "drop", score, None


def verify_item(ws: Workspace, it: EvidenceItem, config: Config = DEFAULT) -> Alignment:
    p = config.verify
    src = _source_text(ws, it)
    status, score, aligned = align_quote(it.quote, src, p.NGRAM, p.ALIGN_THRESHOLD, p.TRUNCATE_THRESHOLD)
    al = Alignment(status=status, score=score, aligned_quote=aligned)
    if status == "drop" and score == 0.0:
        # EvidenT: look for the true source among the other documents (report, don't rewrite)
        best_id, best_score = None, 0.0
        for other in ws.doc_ids():
            if other == it.doc_id:
                continue
            st, sc, _ = align_quote(it.quote, "\n".join(ws.lines(other)), p.NGRAM, p.ALIGN_THRESHOLD, p.TRUNCATE_THRESHOLD)
            if sc > best_score:
                best_id, best_score = other, sc
        if best_id and best_score >= p.TRUNCATE_THRESHOLD:
            al.relocated_doc_id, al.relocated_score = best_id, best_score
    return al


def verify_bank(ws: Workspace, items: list[EvidenceItem], config: Config = DEFAULT) -> dict[str, Alignment]:
    """Run tier 1 over all items; mutate `tier1_status`/`tier1_score` in place and return alignments."""
    out: dict[str, Alignment] = {}
    for it in items:
        al = verify_item(ws, it, config)
        it.tier1_status = al.status  # type: ignore[assignment]
        it.tier1_score = round(al.score, 3)
        out[it.id] = al
    return out
