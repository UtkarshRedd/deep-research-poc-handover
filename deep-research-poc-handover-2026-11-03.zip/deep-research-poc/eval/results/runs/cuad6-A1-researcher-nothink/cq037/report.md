# When does the Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONA...

*Question:* When does the Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONAL TEST SYSTEMS, INC. (filed 2000-07-26) expire, according to its term clause?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Determine the expiration date

The Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONAL TEST SYSTEMS, INC. defines the Initial Distribution Period as April 15, 2000 through October 15, 2000. [ce581d56506a6a52 p.1] The term clause states that this period covers 6 Months from the Effective Date. [ce581d56506a6a52 p.1] The agreement expires on October 15, 2000. [ce581d56506a6a52 p.1]

## Not established by the evidence

[GAP] No evidence was found for: Establish that the document filed 2000-07-26 between COMWARE TECHNICAL SERVICES and INTERNATIONAL TEST SYSTEMS, INC. is the Distributor Agreement in question.

## Verification appendix

Claims: 4 · supported: 3 · partially: 0 · dropped: 0 · gaps: 1 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Locate the Distributor Agreement

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s2.1 | s2 | keep | 1.00 | e1→[ce581d56506a6a52 p.1] |  |
| s2.2 | s2 | keep | 1.00 | e1→[ce581d56506a6a52 p.1] |  |
| s2.3 | s2 | keep | 1.00 | e1→[ce581d56506a6a52 p.1] |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [ce581d56506a6a52 p.1 L25-26] keep (1.0): "INITIAL DISTRIBUTION PERIOD: April 15, 2000 through October 15, 2000 (6 Months from the Effective Date)"
