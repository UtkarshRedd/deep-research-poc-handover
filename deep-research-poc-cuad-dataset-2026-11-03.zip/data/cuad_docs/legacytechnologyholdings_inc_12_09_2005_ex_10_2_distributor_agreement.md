<!-- page 1 -->
# EXCLUSIVE DISTRIBUTOR AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| Agreement Date | 2005-12-08 |
| Parties | LifeUSA/ Envision Health, Inc. ("ENVISION"); Sierra Mountain Minerals, Inc. ("SIERRA") |
| Source | CUAD v1 / LEGACYTECHNOLOGYHOLDINGS,INC_12_09_2005-EX-10.2-DISTRIBUTOR AGREEMENT |

EXHIBIT 10.2

DISTRIBUTOR AGREEMENT

EXHIBIT 10.2

EXCLUSIVE DISTRIBUTOR AGREEMENT

THIS EXCLUSIVE DISTRIBUTOR AGREEMENT (the "Agreement") shall be effective as of _Dec. 8, 2005
(hereinafter "Effective Date"), by and between LifeUSA/ Envision Health, Inc., a corporation
(hereinafter collectively "ENVISION"), and Sierra Mountain Minerals, Inc., a Canadian company
(hereinafter "SIERRA"), is made with reference to the following facts:

Recitals

A. SIERRA is the manufacture and producer of a joint health product called "SierraSil" (hereinafter
"the Product") for human use.

B. ENVISION is the manufacturer of certain nutritional supplements and is desirous of becoming an
exclusive distributor for the Product in any blend with Krill Oil (hereinafter "the Finished
Product") in all distribution channels in the Territory on the terms and conditions set forth
herein.

C. SIERRA is desirous of having ENVISION act as its exclusive distributor for the Product in any
blend with Krill Oil in all distribution channels in the Territory on the terms and conditions set
forth herein.

NOW, THEREFORE, it is hereby agreed as follows:

1. Incorporation of Recitals. The Recitals set forth in Paragraphs A through C, above, are
incorporated herein as though set forth in full.

2. Appointment. SIERRA hereby appoints ENVISION as its exclusive distributor for the Product in any
blend with Krill Oil within the Territory subject to ENVISION fulfilling the terms and conditions of
the best efforts marketing requirements set forth herein in Sections 4, 5, and 9. SIERRA shall cease
making sales to any customer or distributor who, during the term of this Agreement, violates
ENVISION's exclusivity.

3. Territory. The Territory shall be the entire world.

4. Prices and Terms. The price for the Product as set forth in Section 9 herein, sold by SIERRA to
ENVISION, shall be subject to change due to changes in manufacturing costs and so as to maximize
profits; any changes in price for the Product shall not be applicable to previously accepted orders
and shall be made with at least ninety (90) days advance notice in writing and in good faith by
conference of the parties. ENVISION shall not resell the Product alone. Terms of payment will be 1/3
upon placement of order and 2/3 balance net thirty (30) days or as mutually agreed upon in writing
between the parties. Delivery will be F.O.B. ENVISION shall be responsible for all costs of shipping
from SIERRA to ENVISION.

5. Product Support. ENVISION will use its best efforts to market and sell the Finished Product
throughout the Territory. The parties also agree that:

o If SIERRA customers are interested in purchasing the Product in any blend with Krill Oil, SIERRA
will refer them to ENVISION.

o ENVISION will be responsible for all costs associated with developing and manufacturing the
Finished Product.

6. Sales Disclosures. ENVISION will provide SIERRA with demand projections for the Product and
SIERRA will produce enough Product to meet such demand projections. ENVISION will inform SIERRA of
committed sales and SIERRA will increase or scale up its production of the Product accordingly.
SIERRA will not unreasonably withhold the Product, but shall not be liable for unfulfilled or
partially fulfilled orders given just cause for such action.

7. Term. The term of this Agreement shall be two (2) years from the Effective Date with automatic
annual renewals thereafter provided either party does not provide sixty (60) days notice of
termination prior to the renewal date or the Agreement is not otherwise terminated as set forth in
Section 8.

8. Termination. (a) Upon the occurrence of a material breach or default as to any obligation, term
or provision contained herein by either party and the failure of the breaching party to promptly
pursue (within thirty (30) days after receiving written notice thereof from the non-breaching party)
a reasonable remedy designed to cure (in the reasonable judgment of the non-breaching party) such
material breach or default, this Agreement may be terminated by the non-breaching party by giving
written notice of termination to the breaching party, such termination
<!-- page 2 -->
being immediately effective upon the giving of such notice of termination.

(b) Upon the occurrence of bankruptcy of the other party, breach of confidentiality, government
legislative interference, or force majeure extending beyond sixty (60) days, either party may
immediately terminate the Agreement.

9. Purchase Requirements. During the term of this Agreement, ENVISION will exclusively purchase the
Product from SIERRA. The parties mutually agree to the Purchase Price of:

Product Purchase Price ----------------------------------------------- A. SierraSil Per Sierra Sil's
wholesale price list.

10. Intellectual Property. SIERRA is responsible for all Patent costs for the Product. SIERRA
warrants it owns pending patents for the Product in the U.S. and internationally. SIERRA hereby
grants ENVISION an exclusive, royalty-free sub-license of the Product's future patents, and patent
applications to distribute, sell and market the Finished Product. SIERRA hereby agrees to indemnify,
defend and hold ENVISION harmless from any claims that the Product infringes upon any other patent.

11. Trademarks SIERRA is the owner of the trademark&sbsp; "SierraSil". This Agreement grants
ENVISION a non-exclusive and non-royalty bearing license to use the mark "SierraSil". SIERRA shall
at all times be the owner of the trademark and ENVISION shall acquire no rights thereto. Upon
termination, ENVISION shall have eighteen (18) months to exhaust any inventories, packaging and
advertising materials bearing the "SierraSil" trademark and SIERRA shall have first option to buy
back any inventory at ENVISION's net purchase price.

12. Independent Contractor Status. The parties acknowledge that ENVISION is an independent
contractor and shall not be deemed to be an employee, agent, or joint venturer of SIERRA for any
purpose, including federal tax purposes.

13. Warranty. SIERRA warrants that the Product shall be free from defects in material and
workmanship for the reasonable shelf life of the Product. In the event of any breach of this
warranty or in the event any user of Product makes a claim that the Product was the cause of
personal injury or property damage (product liability claim), SIERRA shall indemnify, defend and
hold ENVISION harmless from any liability occasioned by a breach of warranty or a product liability
claim. SIERRA warrants that it carries general liability insurance of not less than $2 million per
occurrence and product liability insurance of not less than $5 million per occurrence and that, upon
the execution of this Agreement, it will name ENVISION as an additional insured on such policies.
SIERRA further warrants that the Product will not be adulterated or misbranded within the meaning of
any federal, state, or local law or regulation or other applicable law. SIERRA agrees to promptly
notify ENVISION of any problem, anomaly, defect or condition which would reasonably cause ENVISION's
concern relative to stability, reliability, form, fit, function or quality of the Product.

ENVISION warrants that the Finished Product will not be adulterated or misbranded within the meaning
of any federal, state, or local law or regulation or other applicable law. In the event of any
breach of this warranty or in the event any user of the Finished Product makes a claim that the
Finished Product was the cause of personal injury or property damage (product liability claim),
ENVISION shall indemnify, defend, and hold SIERRA harmless from any liability occasioned by a breach
of warranty or a product liability claim. ENVISION warrants that it carries general liability
insurance of $1 million per occurrence and product liability insurance of not less than $2 million
per occurrence and that, upon execution of this Agreement, it will name SIERRA as an additional
insured on such policies.

14. Confidential Information. The parties acknowledge that, during the term of this Agreement, each
may receive certain Proprietary Information of the other. Proprietary Information includes, without
limitation, formula, scientific studies, processes, plans, formulations, technical information, new
product information, methods of product delivery, test procedures, product samples, specifications,
scientific, clinical, commercial and other information or data, customer lists, customer contacts,
and other distributors within the Territory which are considered confidential in nature whether
communicated in writing or orally. The parties agree that each will treat such information as
confidential. Neither party shall have the right to disclose the Proprietary Information to any
third party without the express written consent of the disclosing party. Neither party may use the
proprietary information except in furtherance of the goals of this Agreement and is further
prohibited from utilizing the Proprietary Information directly nor indirectly to engage in any
business activity which is competitive with the other.

15. Force Majeure. In no event shall any party be responsible for its failure to fulfill any of its
obligations under this Agreement when such failure is due to fires, floods, riots, strikes, freight
embargoes, acts of God or insurrection. In the event of a force majeure, the party affected thereby
shall give immediate written notice to the other. If the event of force majeure continues for longer
than
<!-- page 3 -->
sixty (60) days, the party not so affected shall have the right to terminate this Agreement.

16. Non-Waiver of Default. The failure of either party at any time to require the performance by a
party of any provision of this Agreement shall in no way affect the right to require performance at
any time after such failure. The waiver of either party of a breach of any provision of this
Agreement shall not be taken to be a waiver of any succeeding breach of the provision or as a waiver
of the provision itself.

17. Attorney's Fees. In the event either party is required to institute litigation to enforce any
provision of this Agreement, the prevailing party in such litigation shall be entitled to recover
all costs including without limitation, reasonable attorney's fees and expenses incurred in
connection with such enforcement and collection.

18. Venue. This Agreement is deemed to have been entered into in the State of Colorado, and its
interpretation, construction, and the remedies for its enforcement or breach are to be applied
pursuant to and in accordance with the laws of the State of Colorado.

19. Notices. Any and all notices or other communication required or permitted to be given pursuant
to this Agreement shall be in writing and shall be construed as properly given if mailed first
class, postage prepaid to the address specified herein. Either party may designate, in writing, a
change of address or other place to which notices may be sent.

If to SIERRA: If to LIFEUSA/ENVISION: Mr. Michael Bentley Mr. Michael Schuett Sierra Mountain
Minerals Inc. Envision Health, Inc. 1501 West Broadway, Suite 500 2475 Broadway, Suite 202 Vancouver
BC V6J4Z6 Boulder, CO 80304 Canada

20. Amendment. This Agreement shall not be modified or amended except by a written agreement
executed by both parties.

21. Entire Agreement. This Agreement constitutes the entire agreement between the parties with
respect to the subject matter thereof and supersedes all prior agreements, whether written or oral.

22. Assignment. The parties shall have the right to assign all, or part, of its rights under this
Agreement to any wholly owned subsidiary or affiliate without the consent of the other Party. Any
other assignment by the parties, requires the prior written consent of the other Party.

ACKNOWLEDGEMENTS

Each party acknowledges that he or she has had an adequate opportunity to read and study this
Agreement. The understanding of the aforesaid articles causes no difficulty whatsoever and each
party has retained a copy of this agreement immediately after the signing of it by all parties.

IN WITNESS WHEREOF, the parties have executed this Agreement effective as of the date and year first
written above.

SIERRA MOUNTAIN MINERALS LIFEUSA/ENVISION HEALTH

By: /s/ Michael Bentley By: /s/ Michael Schuett ----------------------- -------------------------
Michael Bentley Michael Schuett

December 8, 2005 December 7, 2005 ----------------------- ------------------------------ Date Date
