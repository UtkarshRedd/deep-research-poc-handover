<!-- page 1 -->
# Cooperation Agreement
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2014-06-25 |
| Parties | People’s Government of Fenyi County ("Party A"); Xinyu Xinwei New Energy Co., Ltd. ("Party B") |
| Source | CUAD v1 / SPIENERGYCO,LTD_07_10_2014-EX-10-Cooperation Agreement of 50MWp Photovoltaic Grid-connected Power Generation Project in Yangqiao of~1 |

Exhibit 10.47 Cooperation Agreement of 50MWp Photovoltaic Grid-connected Power Generation Project in
Yangqiao of Fenyi County Party A: People's Government of Fenyi County Party B: Xinyu Xinwei New
Energy Co., Ltd. Party A welcomes and supports Party B to invest and develop new energy project in
Fenyi County, and Party B is willing to invest and build 50MWp photovoltaic grid-connected power
generation project in Fenyi County; both parties, in the principle of equality, mutual benefits,
win-win cooperation and solid progress, reach the following cooperation agreement as for relevant
matters of the project: I. Party A supports and guarantees the project construction and development
of Party B, and will provide the most preferential policies and all- round service in the aspects of
preliminary work, construction and grid-connected of the project, and actively coordinate relevant
departments and units to help Party B accelerate project construction progress. Party B will give
full play to the advantages in funds, talents, technologies, and etc. to accelerate the preliminary
work progress of the project, ensure the early commencement of the project and produce benefits upon
early completion. II. As required by Party B building PV grid-connected power station project, Party
A accepts the Cooperation Agreement of 50MWp Photovoltaic Grid-connected Power Generation Project in
Yangqiao Town of Fenyi County signed by Party B and Yangqiao Town of Fenyi County, and actively
coordinates Yangqiao Town to perform relevant responsibilities. III. In the principle of win-win
cooperation, based on 50MWp photovoltaic grid-connected power generation project in Yangqiao Town,
Party B will vigorously promote the application of PV products, improve local energy-saving and
emission reduction benefits, increase local fiscal levy, enhance villagers' income and increase
villagers' employment. IV. Party B promises that land nature will not be changed for building
large-scale PV grid-connected power generation project in the plot; comprehensive development will
be carried out according to relevant national stipulations, such commercial crops will be
interplanted as agriculture and forestry as well as medicinal materials; local employees will enjoy
the priority to be employed; local building materials will be adopted and relevant expenses will be
paid on schedule. V. Party B will register a foreign-funded company in Fenyi County before
implementing the project; Party A will offer all the preferential policies to the company as per
local investment promotion policies for foreign investment introduction. Party A: People's
Government of Fenyi County (seal) Rao Cheng (signature) June 25, 2014 Party B: Xinyu Xinwei New
Energy Co., Ltd. (seal) Xiahou Min (signature) June 25, 2014
