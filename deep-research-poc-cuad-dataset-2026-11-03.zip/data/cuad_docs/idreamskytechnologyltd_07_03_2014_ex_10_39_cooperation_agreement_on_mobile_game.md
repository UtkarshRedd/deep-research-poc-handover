<!-- page 1 -->
# Cooperation Agreement
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2013-01-01 |
| Parties | Dazzle Interactive Network Technologies Co., Ltd. ("Party A"); Shenzhen iDreamSky Technology Co., Ltd. ("Party B") |
| Source | CUAD v1 / IDREAMSKYTECHNOLOGYLTD_07_03_2014-EX-10.39-Cooperation Agreement on Mobile Game Business |

Exhibit 10.39

English Translation

Jiangsu Telecom Contract No.: JSXCS1200166CC000

Cooperation Agreement on Mobile Game Business

Between

Dazzle Interactive Network Technologies Co., Ltd.

And

Shenzhen iDreamSky Technology Co., Ltd.

Party A: Dazzle Interactive Network Technologies Co., Ltd. Address: 4F, Han Zhong Hua Mansion, 268
Han Zhong Road, Gu Lou District, Nanjing Zip code: 210001 Contact person: Chen Xi Tel: Name of
account: Dazzle Interactive Network Technologies Co., Ltd Deposit Bank: China Merchants Bank,
Chengbei Sub-branch, Nanjing A/C:

Party B: Shenzhen iDreamSky Technology Co., Ltd. Address: 7F, EVOC Technology Building, No. 31
Gaoxin Central 4th Road, Nanshan District, Shenzhen Zip code: 518057 Contact person: Chen Zhiyu
Contact Tel: Name of account: Shenzhen iDreamSky Technology Co., Ltd. Deposit Bank: China Merchants
Bank Co., Ltd., CMB Shenzhen Sungang Sub-branch A/C:

Page 1 of 29
<!-- page 2 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 In order to provide Party A's users with better
value-added application services and satisfy the growing market demands, the Parties hereto, upon
thorough negotiations based on the principles of equality, mutual benefits, mutual supplementation
of advantages, joint development, and fully leveraging the advantages of the Parties hereto in their
respective areas of service, the Parties hereto have agreed as follows in respect of the cooperation
in mobile game services:

Article 1 Contents and Principles of Cooperation

1.1 Party A, as an Internet business provider, and Party B, as a mobile game content provider, will
establish a cooperation relationship in the area of mobile game service.

1.2 The details of the content and application services provided by Party B are: 1) Party B will
provide Party A with the mobile games that are developed by itself and have legitimate intellectual
properties, or third party mobile games that are acquired by Party B by way of authorization and
have been granted legitimate right of use; and 2) Party B will provide Party A the software and
hardware technical support (and the timely updates thereof) for game running to secure the stable
running of the games.

1.3 Party A shall provide, for a consideration, network resources, portals and such other
advertising resources, as well as connection services and business fee calculation/collection
service. Party A will charge relevant information fee from the users of Party B's mobile game
service, and will share such information fee with Party B as agreed herein.

1.4 Except otherwise agreed between the Parties, Party B will acknowledge and accept the changes in
cooperation business and mode proposed by Party A due to business development, and assist Party A in
effecting such changes.

1.5 Resources devoted by Party A: business connection platform, network resources, portals and other
advertising channels, etc.

1.6 Resources devoted by Party B: mobile game application system and relevant contents (including,
without limitation, copyright, right of portrait and such other lawful rights), etc.

1.7 Scope of cooperation service: all users of Party A's interactive platform.

Article 2 Rights and Obligations of Party A

2.1 Party A shall have a preemptive right to carry out mobile game services with Party B on a
nationwide basis.

2.2 Party A shall have the right to know and review the business license, relevant qualification
certificate, copyright ownership, business permits, bank account and such other information provided
by Party B. Page 2 of 29
<!-- page 3 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 2.3 Party A shall have the right to know the
legality of the mobile game information provided by Party B, provided, however, that Party A will
not take any responsibilities arising from any illegal or incorrect information provided by Party B.

2.4 Depending on the business and market development, Party A has the right to formulate or amend
the business standards, management measures, quality and/or service standards, and communicate the
same to Party B in an appropriate form for Party B to comply with. At the same time, these documents
will be used by Party A as basis to manage and assess Party B's business operations. The business
standards, management measures, quality and/or service standards so formulated or amended shall be
equally effective as this Agreement.

2.5 Party A shall be responsible for the day-to-day maintenance of the business billing platform,
and provide guidance and assistance to Party B in system connection, debugging and online work to
guarantee the stable running of the platform. Party A shall open the network management system and
other interface management tools to Party B to facilitate its checking of the charges to users and
relevant status of operation, so as to ensure that Party B can monitor the fee charge and operation
of its games in a convenient, true and valid manner.

2.6 Party A shall have the right to review the content and sources of the games put online by Party
B on the platform, and make confirmation on the business management system in an appropriate form,
provided, however, that Party A will not assume any responsibility arising from any illegal contents
provided by Party B.

2.7 According to Management Measures for Cooperation in Mobile Game Business (V1.0), Party A shall
have the right to review and assess Party B and its various business, select the superior and
eliminate the inferior based on Party B's performance in business development, credit points and
breaches, reward Party B's creative business and supervise Party B's customer service quality, and
may terminate this Agreement with Party B if it fails to reach Party A's standards. 2.8 Party A
shall be responsible for the overall advertising of the cooperation business.

2.9 If Party A is investigated by relevant national authority, consumers' association or any other
organization, or is claimed legal responsibilities, due to the users' browsing or use of the
contents and application services provided by Party B, Party A may unilaterally terminate this
Agreement by a written notice, and Party B shall bear any direct and indirect losses thus suffered
by Party A, including, without limitation:

(1) costs of preliminary input and preparatory work made by Party A for performance of this
Agreement;

(2) costs already paid by Party A for performance of this Agreement;

(3) anticipated gains for Party A's performance of this Agreement;

(4) costs, indemnities or other payables by Party A in relevant litigations incurred for reasons
attributable to Party B. Page 3 of 29
<!-- page 4 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 2.10 If Party A receives any complaint or notice
alleging that any content provided by Party B is involved in an infringement dispute, Party A may
suspend the connection of Party B's system, unilaterally terminate this Agreement and suspend the
settlement of relevant fees, and notify Party B to delete or shield such content involving
infringement. The business will be resumed upon confirmation by Party A after Party B notifies the
results to Party A.

2.11 Party A shall construct and maintain the business management system, use the business
management system to post notice/announcement, business management measures and relevant policies,
and shall inquire, manage and update the information regarding the cooperation. Party A shall
provide Party B with its user name and password on the business management system for Party B to log
on.

2.12 Party A shall test the business filed by Party B after approving it, and after the test is
passed, provide Party B with a written confirmation or otherwise confirm with appropriate forms in
the business management system. The official launch time of the business will be the time when Party
A officially launches the billing service.

2.13 During the term of cooperation, Party A may suspend its cooperation with Party B if there is
user complaint on Party B's service quality issue, which has resulted in adverse social impact; in
serious cases, Party A may unilaterally terminate this Agreement.

2.14 Party A may, as requested by customers and market orders, review the business contents and
prices filed by Party B, and may withhold the settlement of the information fee incurred by Party
B's discretional change of charges.

2.15 Any complaints made by users with respect to the fee charging activities by Party B (except
complaints attributable to Party A), once discovered, may be immediately notified by Party A in
writing to Party B for correction, and Party A may take measures of fee refunding or suspension of
fee charging according to relevant rules and as agreed herein. For complaints which Party B fail to
make reasonable explanation, Party A may require Party B to reduce and exempt information fee of
relevant users, and based on the seriousness of situation, require Party B to take relevant
liabilities for breach of contract in accordance with relevant business management measures.

2.16 Party A shall be entitled to supervise the business conduct of Party B, and Party B shall
assist Party A to avoid any adverse impact on Party A's normal business. If Party B's
businessconduct causes adverse impact on Party A's normal business in violation of this Agreement,
Party A may terminate this Agreement and Party B shall assume relevant liabilities for breach of
contract.

Article 3 Rights and Obligations of Party B

3.1 Party B shall be responsible for content development, platform building and maintenance,
marketing and customer service of the cooperation business.

3.2 Party B guarantees to have the legal permits and qualifications necessary for the performance of
the matters hereunder, including, without limitation, business license with legitimate business
scope, qualification for providing contents/application services; Party B shall provide Party A with
true and legitimate business permits for Internet information service and relevant business and such
other credentials, creditability certificate, certificate for legitimacy of copyright sources,
adequate after-sale service system, price approval, bank account and such other documents. Page 4 of
29
<!-- page 5 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 3.3 Party B must strictly comply with relevant
industry laws, rules and standards promulgated by the State, including, without limitation, the PRC
Telecommunications Regulations, Administrative Measures on Internet Information Service, Interim
Provisions on the Administration of Internet Publishing, Interim Provisions on the Administration of
Internet Websites' Engaging in News Publication Services, and such other laws, regulations, policies
and industry management rules, and shall not distribute and disseminate illegal, unhealthy,
reactionary information or advertisement or such other junk information on the Internet.

3.4 Party B guarantees that it enjoys the intellectual property and civil rights on all the
information/application service resources provided by it, has obtained the license and authorization
from relevant right owners, and does not infringe on any person's copyright, trademark right, patent
right, trade secrets or other intellectual property rights, other property rights, right of portrait
or other personal right.

3.5 Party B shall comply with the various rules and requirements in the business standards,
management measures, quality and/or service standards formulated or amended by Party A, which shall
be equally binding as this Agreement.

3.6 Party B guarantees that the prices of the various business it provides are in line with the
pricing policies of the State, and it will be responsible for any price complaints made by relevant
administrative authority or users.

3.7 Party B may negotiate the mode of cooperation with Party A, and may determine the operation
strategy for its mobile game service business, provided, however that the pricing of its business
shall be approved by Party A and filed to relevant authority for record.

3.8 In case of any issues of Party B's own systems (such as WAP website or game server) that affect
Party A's communications system, Party B shall submit to the connection control by Party A thereon,
and any consequence thus incurred shall be fully taken by Party B itself.

3.9 Party B shall undertake allliabilities arising from the wireless value-added business provided
by any third party to the users in any form whatsoever through Party B's maintenance interface.
Party B shall not transfer the business interface provided by Party A to a third party in any form
whatsoever, and Party A will not be responsible toward any users or third party with respect
thereto.

3.10 As required by relevant regulations of the State and as requested by Party A, Party B shall
provide relevant qualification certificates when applying to open and add business, to evidence that
it has sufficient qualification, capability and authority to conduct such business. Party B shall
guarantee that such qualification certificates are true and valid, while Party A is not obliged to
inspect the authenticity and validity of such qualification certificates. Page 5 of 29
<!-- page 6 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 3.11 Party B's conduct of value-added business has
to pass necessary technical test. If such business fails to pass the test as required by Party A for
reasons attributable to Party B as of the commencement date of such test period, the application of
such business shall be null and void, and the costs of such technical tests shall be borne by Party
B. Party B has to submit a new application for such business if it wishes to continue the
cooperation in this business.

3.12 Party B shall not carry out business testing or provide business to customers at its own
discretion without obtaining Party A's consent.

3.13 Party B shall make available to Party A the network access and authority for business inquiry
and cancellation and upon the request of Party A, may provide such data/reports on user development,
user classification, user habits and business outlook forecasts, and will convey to Party A in time
the user files that may be required for management of such business to ensure the real-time update
of Party A's user data room. At the same time, the Parties confirm that Party A shall have the
ownership of the user files, and the user files and information shall belong to Party A's
confidential information, for which Party B shall take the confidentiality obligation hereunder;
Party B shall not use such information for any purposes other than those agreed herein without
authorization, or provide such information to any third party in any manner whatsoever.

3.14 Party B shall resolve any disputes arising from the safety and legality of the information
contents or services it provides, and shall guarantee that the services it provides will not expose
Party A's communications network, value-added business platform or other third party interests to
any significant potential risks. Party B shall assume any losses thus incurred to Party A and/or any
third party and appropriately declare its responsibility in public and eliminate any adverse impact.

3.15 Without Party A's prior consent, Party B shall not imbed business at mobile terminal or
UTK/STK/OTA cards, whether on its own or together with other mobile terminal companies.

3.16 Party B shall mark the brand of "China Telecom Mobile Game" on the external promotion and
advertisement of the cooperation contents of the Parties; the name of Party A may, but neither the
logo of China Telecom nor the customer service number 10000 shall appear at such advertisements. The
contents of the business described by Party B in any media (e.g. newspaper, radio, TV, leaflets,
webpages, etc.) shall obtain the prior written consent of Party A, and Party B shall not post any
business content description to which Party A objects.

3.17 When providing services to users, Party B shall not, in any manner including but not limited to
coercion, cajole, fraud or cheat, in order to make users order tailored business and charge fees
therefor, or otherwise increase any unnecessary costs to users.

3.18 Party B shall not advertise, or make any statement favorable for, any competitor having the
same or similar business scope as Party A in the services it provides. Page 6 of 29
<!-- page 7 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 3.19 Party B may use its user name and passwords on
the business management system to log in, and effect such functions as application for value-added
business, company information maintenance, information exchange between the Parties regarding their
cooperation in value-added business. Party B shall truthfully register/update in time its name,
designated bank, account, contact person, customer service and such other information, and properly
keep and maintain any contract information, settlement information, information on handling of
complaints and breach of contract as generated by the business management system. Party B shall take
proper care of, and shall not allow any third party to use, its user name and password for the
business management system. Any losses incurred to either Party or users arising from other person's
knowledge of Party B's user name and password for reasons attributable to Party B shall be borne by
Party B on its own. 3.20 Party B shall have the right to obtain the information fee settled by Party
A.

3.21 Except otherwise expressly agreed between the parties or agreed by Party A beforehand, Party B
shall not transfer any cooperation business to a third party in any form whatsoever. Any transfer in
violation hereof shall be deemed as a breach by Party B, for which Party B shall take relevant
breaching liability and Party A may terminate this Agreement, suspend fee settlement and require
Party B to undertake any direct or indirect loss thus caused.

3.22 In case of subject change of Party B (the change of holding entity of its business license or
license for value-added telecommunications business (ISP Certificate)), Party B shall settle all
fees payable to Party A and if there is no pending breach to be resolved, provide the approving
notice on subject change issued by AIC, and may complete the relevant subject change procedures only
after approved by Party A. 3.23 Party B shall pay performance deposit to Party A on time and in full
amount as agreed herein.

Article 4 Standard Business Practices

4.1 Party A shall provide Party B with the interface parameters of WAP gateway, SMS gateway and
relevant platform, and assist Party B in business debugging, testing and opening.

4.2 The boundary to divide the respective areas of maintenance by the Parties shall be the gateway
equipment and the interface from telecommunication business platform to Party B's equipment. The
equipment on the inner side of the interface shall be maintained by Party A's maintenance
department, and the equipment on the outer side of the interface shall be maintained by Party B. If
Party B uses an exclusive line, then the interface cable and its connectivity shall be in the charge
of the applicant for such exclusive line and the other Party shall provide assistance.

4.3 Party B shall be responsible for the building and maintenance of its systems, including all
hardware equipment, system debugging, opening, and system maintenance work relating to the the
wireless value-added business under this Agreement and the costs of each of the foregoing .

4.4 Party B shall be responsible for the interconnection of Party B's systems with the various
gateways or servers of Party A and the application, renting and maintenance of relevant
communication circuit, and bear the corresponding costs. Page 7 of 29
<!-- page 8 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 4.5 Party B guarantees that the debugging,
connection and system maintenance work of its systems will not be carried out in the busy hours of
Party A's business, and all work that may have comparative big impact on the users must be done late
at night to minimize the impact on the users' use of wireless value-added business. Party B further
guarantees that such work will not impact the normal running of Party A's network and it will assume
relevant liabilities for malfunctions of Party A's network system thus incurred.

4.6 Any debugging, connection and system modification work by Party B to its systems must be
notified to Party A in advance and obtain Party A's confirmation, after which Party B should
announce to users via email, advertisement, SMS or other effective manner, so as to minimize the
impact on users.

4.7 Party B shall submit to any adjustment arrangement made by Party A to data traffic in urgent
cases for purposes of guaranteeing the normal stability of the various value-added business.

4.8 Party B guarantees to provide 24 hour non-interrupted system maintenance.

4.9 Party A shall define the scope of effective billing customers of mobile business, and the
information fee incurred by invalid user number or the user number not covered by business will not
be settled.

4.10 No fees will be charged to such numbers as provided by Party A that suspend service, that are
canceled or recovered from the following month. In case Party B fails to respond or respond in time,
Party A may claim breaching liabilities by Party B and deduct the corresponding amount at the time
of settlement.

4.11 Party B shall make sure that prior to its provision (including marketing and business
advertising) of any service to users (including paid service and free service), it will thoroughly
notify the users in a proper form, and ensure that the users are fully aware of, the content, means
of provision, standard fee rate (information fee and communication fee), frequency of transmission,
method of use, manner of cancellation, customer service call number and such other information users
need to know for ordering service and make payment for such service. Party B may provide such
service to users only upon obtaining the consent of users in a provable manner, and is prohibited to
provide services to users without users' proper knowledge. Party B shall not purposefully intercept
information, or discretionally send advertising information to users. In case of such breach by
Party B, it shall assmue all liabilities.

4.12 The business operated by Party B shall be confined to the category provided in Article 1
hereof. Any business beyond such scope shall be subject to an application filed by Party B to Party
A via facsimile affixed with official seal, and may be opened and put in practice only after it is
approved by Party A and has successfully passed the test. The application facsimile aforementioned
shall specify the reason, expected time for business opening and business description. If Party B is
discovered to have discretionally opened a business that fails to be approved by Party A, Party A
may refuse to settle all the fees and terminate the cooperation. Page 8 of 29
<!-- page 9 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 4.13 Party B must provide users with unified method
for inquiries and service cancellation.

4.14 For business that is officially opened after being approved by Party A, Party B may apply for
fee rate change at least three months after the date on which such business is opened. After
obtaining the approval from Party A and the official opening of the business, Party B shall
properlynotify the users about such information about the details of fee rate change, the way to
cancel the ordered service, customer service call number of Party B, and post the change notice
(which shall last for one month) at a prominent location on Party B's website; Party B may change
the rate of information fee for the business in close cooperation with a third party information
source only after such planned change has been announced simultaneously at the main advertising
media of such third party information source.

4.15 The Parties shall keep records of users' use of the business for at least 6 months, and shall
keep the record of user's customized business until more than 6 months after the business is
canceled by relevant user.

4.16 The Parties shall act according to the relevant policies promulgated by the competent industry
administration authority (if any).

4.17 The Parties confirm to initially adopt such billing modes as payment by month, by time or by
length of time for Party B's users; other more reasonable billing modes may be additionally adopted
upon negotiations between the Parties.

4.18 Party B shall establish a "black list" policy for customer service, based on which Party B will
include the users who maliciously owe fees or customize services into a "black list" for management,
and Party B shall well explain such policy to relevant users. Party B shall use technical means to
monitor the extraordinary traffic, and implement monitor alert and restriction on any owed fees that
may be produced by large amount of information fee (over RMB 150/day/user) arising from malicious
customization and ordering of services. Party B shall take restrictive measures on the canceled or
recovered user numbers provided by Party A every day, and take restrictive measures on the canceled
or empty numbers every month. In case Party B fails to take measures on such users, or fails to take
measures in time, it shall be responsible for all high-value maliciously owed fees or such other
owed fees arising from the using of mobile game services by the users with canceled or suspended
number, and Party A will deduct such amounts from the information fee to be settled.

4.19 Party B shall not discretionally provide inquiry services of detailed bills of information fee
to users, which shall be provided by Party A instead.

4.20 Users using services abroad may cancel the mobile game service already ordered, and Party B is
obliged to respond and confirm such request for cancellation in time. When the customer opens such
service, Party B has the duty to declare to the users that any international communication fee
incurred due to the customer's failure to cancel any ordered mobile game service or the customer's
continued use of any mobile game service in the roaming state will all be borne by users on their
own. Page 9 of 29
<!-- page 10 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 Article 5 Customer Service

5.1 Party A will use 4008289289, the technical support hotline of its customer service center as the
call center for receiving and handling complaints and superviing partner services. Party A will be
responsible for user inquiries, claims and complaints arising from network communication issues and
billing issues, and Party A's customer service center will allocate and distribute the complaints on
online complaint handling system.

5.2 Party B shall provide standardized and adequate customer service system to deal with the
consultation, claims and complaints by users with respect to the relevant application services or
contents it provides. Such system shall include, without limitation:

(1) Customer service call: 24 hours a day, 7 days a week in service, which shall be service numbers
starting with 800 or 4008, and shall notbe ordinary in-city number or mobile number;

(2) Platform functions: customer systems having such functions as exchange, automatic call
distribution, computer telephony integration,interactive voice response, manual agent, recording,
data base, business preposition, etc.;

(3) Business functions: customer service center will have mainly functions represented by in-calls
and manual service, such as informationinquiries, business cancellation, business consulting and
complaint handling;

(4) Seat placing: SP's customer service shall have at least 5 seats and 12 in-call customer service
staff;

(5) System performance and business targets: call completion rate by the system: 99% and level of
service (call completion rate by manualservice in 20 seconds): 80%;

(6) Email box for complaints.

5.3 Both Parties shall provide customers with multiple convenient means of business ordering inquiry
and business cancellation. Party A shall have the right to use technical and managerial methods to
control and manage Party B's ordering relationship and provide its own means for business inquiries
and cancellation.

5.4 Party B shall be responsible for all kinds of customer inquiries and complaints arising from
problems not related to Party A's network communication and platform during the cooperation. Party B
shall clearly specify and make public the channel and body by which the business consulting, claims
and complaints will be accepted. Party B shall be obliged to visit the online complaint handling
system every day and respond to the complaints within 24 hours.

5.5 The Parties agree that the complaints shall be resolved within 72 hours, and Party B shall
provide party A with the list of relevant persons and their respective details of contact and
guarantee smooth communications 24 hours a day.

5.6 The Parties will adopt the "first inquiry responsibility" system for user complaints, which
means that the party receiving the user complaint shall be responsible to coordinate and properly
resolve the questions raised by the users, regardless of which Party shall take the final
responsibility. If the issue does involve the other Party, such other Party shall assist Party
receiving the complaint ton resolve the issue. Page 10 of 29
<!-- page 11 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 5.7 For the consulting or complaints that can be
resolved by Party B only, Party A shall notify Party B by way of work order flow and Party B shall
respond within 24 hours and completely resolve such complaints within 72 hours. If Party B fails to
resolve the issue within 72 hours, or if any user refuses to pay the information fee due to reasons
attributable to Party B's services, Party B shall deduct or exempt relevant fees for such user. If a
fee refund is needed, the relevant amount will be deducted by Party A at the time of settlement with
Party B.

5.8 If neither Party is able to judge which Party shall be responsible for the consulting or
complaints it receives, it shall contact the other Party within 1 hour to find out the responsible
Party and help the customer to solve the problem as soon as practicable. Neither Party shall shuffle
its due responsibility to other Party.

5.9 For those customer complaints for which neither Party is able to give reasonable explanations,
Party B shall deduct or exempt relevant fees for such user upon the request of Party A. If a fee
refund is needed, the relevant amount will be deducted by Party A at the time of settlement with
Party B.

5.10 If any user complaint is caused due to the fact that a service fails to satisfy its advertised
quality commitments, then the Party making such commitments shall be responsible to reply to the
users and solve the complained issues, and the other Party shall give necessary assistance.

5.11 If Party B exits this Agreement due to poor management or is unable to continue providing
value-added business for other reasons of its own, Party B shall directly explain to users and
handle the after-exit arrangements. Except for the exit according to the exit mechanism provided
herein, Party B shall inform Party A and obtain its consent regarding the cease of value-added
business provision three months in advance; Party A shall timely terminate its service to collect
information fee on behalf of Party B, and assist Party B in making explanations and descriptions to
users.

5.12 The Parties shall strictly comply with the regulations of Ministry of Information Industry and
other relevant authorities, and adopt "compensation first" principle with respect to user
complaints, which means to first refund any amounts in respect of the complaint or objection to
users before finding out which Party shall be responsible. The amounts so refunded shall be deducted
from the settlement amounts between the Parties. If such user complaint is caused by any breach by
Party B hereunder, Party B shall undertake relevant breaching liabilities.

Article 6 Performance Bond

6.1 Upon negotiations between the Parties, Party B will pay Party A RMB three thousand (3,000) as
performance bond after this Agreement comes into force.

6.2 If Party A discovers in its spot checks conducted from time to time that any game, software,
business, works, content or service provided by Party B is not in compliance with laws, regulations,
industry rules, Party A's management measures or contractual agreement, Party B shall pay Party A
additional amount of performance bond at RMB5,000 per violation, or RMB10,000 per business, to be
payable to by Party B within 10 working days after the results of copyright spot checks are posted.
Page 11 of 29
<!-- page 12 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 6.3 If any game, software, business, works, content
or service provided by Party B has intellectual property defects or other right defects or other
illegal issues, or Party A or any of its relevant bodies faces accusation, lawsuit, complaint,
negative media report, administrative penalty, then Party A will temporarily withhold the settlement
payment during the period when such dispute is pending for at least RMB50,000 per violation
(business), and deduct from the performance bond already paid by Party B; at the same time, Party B
shall pay an additional performance bond at an amount equivalent to the original one, within 10
working days upon the occurrence of the dispute. For the second time of the aforementioned
violation, the amount of performance bond shall be additionally paid at RMB3,000 per time on the
basis of the amount previous paid. For the third time of the aforementioned violation, Party A will
withhold the full amount of the performance bond already paid by Party B, and terminate the
full-range business cooperation for one year.

6.4 If Party B fails to properly solve the accusation, lawsuit, complaint, negative media report,
administrative penalty and such other dispute, which has brought goodwill or economic loss to Party
A, Party A will withhold all amounts whose settlement has been suspended and full amount of the
performance bond already paid by Party B, and terminate the full-range business cooperation for one
year.

6.5 Within two years upon the termination of the cooperation between the Parties, if no legal
dispute involving Party B has occurred, Party A will refund (without interest) the performance bond
to Party B within 30 working days upon the day immediately following the 2nd anniversary of the
cooperation termination.

6.6 The correspondent bank account for performance bond:

Account name of Party A: Dazzle Interactive Network Technologies Co., Ltd. Deposit bank: Shanghai
Pudong Development Bank, Business Office of Nanjing Branch A/C:

Account name of Party B: Shenzhen iDreamSky Technology Co., Ltd. Deposit Bank: China Merchants Bank
Co., Ltd., CMB Shenzhen Sungang Sub-branch A/C:

6.7 This article shall be applied to all agreements executed by and between the Parties.

Article 7 Billing and Settlement

7.1 The prices of information fee shall be formulated by Party B and approved by Party A in
principle, provided that Party A may propose advice regarding fee rate and negotiate such proposal
with Party B. any changes to the prices of information fee (including the changes in means of fee
charging) may be implemented formally only after confirmed by Party A. All billing and settlement
shall be subject to the provisions of Management Measures for Cooperation in Mobile Game Business
(V1.0). Page 12 of 29
<!-- page 13 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 7.2 The successful charging bill collected on Party
A's billing system shall be used by the Parties as the basis for settlement of information fees; the
business billed by time shall be calculated based on the successful receipt of the business by the
customer; business subject to monthly payment shall be based on customer's true ordering. Party A
shall deduct from the payable information fee, the amount of information fee refused to be paid by
any users due to Party B's service quality.

7.3 Billing cycle: the statistic cycle of total amount of Party B's information fee on Party A's
billing system is normally based on calendar month, starting from 0 o'clock on the 1st day of a
calendar month and ending at 24 o' clock on the last day of such month.

7.4 Mode of distribution: the cooperation may be divided into two categories, content cooperation
and channel cooperation, according to the different rights and responsibilities of the Parties in
the cooperation.

7.4.1 Detailed rules for content cooperation settlement

7.4.1.1 All kinds of communication fee income incurred from the user's or Party B's use of
communication network shall belong to Party A in full amount.

7.4.1.2 8% (or the actual bad debt rate if such actual rate exceeds 8%) of the receivable
information fees in the corresponding month will be allocated and deducted as the provisions for bad
debts.

7.4.1.3

Party A will deduct the expenses for fee collection at the percentage provided in the agreement
executed with the fee collection agent (the current sharing percentage of China Telecom is 15%, and
the sharing percentage of other fee collection channels shall be calculated as actually incurred).

7.4.1.4

After the bad debt provisions and the part allocated to the fee collection agent are deducted from
the total revenue, Party B will obtain 70% of the remaining revenue (total revenue * (1 - bad debt
rate) * (1 - sharing percentage for fee collection channel) * 70%).

7.4.1.5

The Parties shall jointly determine the settlement amount according to system data records and
statement provided by Party A, provided that any expenses incurred by the testing account used by
the Parties for business testing shall not be included in settlement.

7.4.1.6 The detailed practices for settlement in content cooperation are set out in Management
Measures for Cooperation in Mobile Game Business (V1.0). Page 13 of 29
<!-- page 14 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 7.4.2 If Party B agrees to participate in the mode
of channel cooperation, details of settlement are listed as follows:

7.4.2.1 All kinds of communication fee income incurred from the user's or Party B's use of
communication network shall belong to Party A in full amount.

7.4.2.2 8% (or the actual bad debt rate if such actual rate exceeds 8%) of the receivable
information fees in the corresponding month will be allocated and deducted as the provisions for bad
debts.

7.4.2.3 Party A will deduct the expenses for fee collection at 15% (or the actual fee collection
expense rate if such actual rate exceeds 15%) as provided in the agreement executed with the fee
collection agent.

7.4.2.4

After the bad debt provisions and the part allocated to the fee collection agent are deducted from
the total revenue, Party B will obtain 40% of the remaining revenue (total revenue * (1 - bad debt
rate) * (1 - sharing percentage for fee collection channel) * 40%)

7.4.2.5

The Parties shall jointly determine the settlement amount according to system data records and
statement provided by Party A, provided that any expenses incurred by the testing account used by
the Parties for business testing shall not be included in settlement.

7.4.2.6 The detailed practices for settlement in content cooperation are set out in Management
Measures for Cooperation in Mobile Game Business (V1.0).

7.5 If Party B agrees to sign off Party A's access bundle sales or favorable package or such other
packaged promotional activities, the fee rate can be adjusted appropriately upon negotiations
between the Parties.

7.5.1 8% (or the actual bad debt rate if such actual rate exceeds 8%) of the receivable information
fees of the corresponding month will be allocated and deducted as the provisions for bad debts.

7.5.2 Party A will deduct the expenses for fee collection at the percentage provided in the
agreement executed with the fee collection agent (the current sharing percentage of China Telecom is
15%, and the sharing percentage of other fee collection channels shall be calculated as actually
incurred). Page 14 of 29
<!-- page 15 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 7.5.3 After the bad debt provisions and the part
allocated to the fee collection agent are deducted from the total revenue (total revenue * (1 - bad
debt rate) * (1 - sharing percentage for fee collection channel)), Party A, on the one side, and all
content providers participating in such access bundle sales, favorable package or other packaged
promotional activities, on the other side, shall share the income at a ratio of 50%:50% (Party A:
all content providers participating in such business). Party B and all the other content providers
participating in such business shall share such 50% of income according to the proportion of the
usage of their business to the total usage. The formula for calculation shall be:

(1) If the game package only includes multiple console games:

Based on the amount of downloads of the console games, the sharing percentage among all CSPs in the
package shall be calculated as follows:

Total income of game package * (1 - bad debt rate) * (1 - sharing percentage for fee collection
channel) *50% * (number of downloads of such CSP's online game/aggregate number of downloads of all
console games contained in the game package)

(2) If the game package only includes multiple WAP social online games:

Based on the amount of logons of the online games, the sharing percentage among all CSPs in the
package shall be calculated as follows:

Total income of game package * (1 - bad debt rate) * (1 - sharing percentage for fee collection
channel) *50% * (logons of such CSP's online game/sum of logons of all online games contained in the
game package)

The detailed practices are set out in Management Measures for Cooperation in Mobile Game Business
(V1.0).

7.6 The Parties shall settle the payment every month, and the initial settlement period shall be the
end of the third month, which means that the information service fee generated in the first month
shall be paid to the account of the partner by the end of the third month. When requesting payment
of relevant contract price from Party A, Party B has to:

(1) provide official invoices that are in compliance with the requirements of State tax laws by the
25t h of the second month (Party B, instead of any of its affiliates, shall be the invoice issuer);

(2) provide the payment request confirmed by the Parties; and

(3) pay the performance bond as required in Article 6 hereof.

7.7 The settlement shall be made based on Party A's data. If there is any discrepancy between the
billing data of the Parties, and such discrepancy reaches over 5% of Party A's data, Party B may
request account reconciliation via CSP management system within 5 working days after the settlement
information is posted, and shall deliver the account statement and invoices confirmed with a stamp
to the contact person of Party A by the 25th of the second month. If Party B fails to make such
account reconciliation request within such prescribed period of time, Party A may refuse to accept
and deal with such request. If Party B's billing data is confirmed as correct after investigation,
the relevant account will be adjusted in the following month. Any CSP's failure to request account
reconciliation in time shall be deemed as the tacit acceptance of the settlement data by such CSP,
and Party A may refuse to accept any further account reconciliation request made by such CSP for the
relevant settlement month. Page 15 of 29
<!-- page 16 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 7.8 All business revenue payable to Party B
calculated by Party A according to the sharing percentages for different business under cooperation
between the Parties, minus (or plus) other expenses payable (or receivable) by Party B, shall be the
revenue to be finally settled to Party B (the "Settled Information Service Dee"). The aforementioned
"other expenses" shall include, without limitation, penalty deducted for breach and co- location
fee. As agreed between the Parties, Party B's business revenue and other payable expenses may be
settled separately and apply different settlement process.

7.9 Party B shall make timely update of its information of bank account and such other information
necessary for payment as registered on the business management system. If Party B's failure to
update such payment information in time renders Party A's payment to be rejected by the bank, or
causes other difficulties that prevent Party A from making timely payment, then Party A will
postpone such payment till the June or December closest to the time when Party A learns about the
correct bank account of Party B without taking any breaching responsibility for overdue payment.

7.10 Any change of Party B's corporate name shall be notified to Party A in time via the business
management system or other appropriate means. After such change of Party B's corporate name, any
amounts payable by Party A to Party B, whether incurred before or after such change, shall all be
paid to the bank account with the changed name of Party B. If Party A fails to make the payment on
time due to Party B's failure to properly complete the name change procedures, Party A will postpone
such payment.

7.11 If Party B terminates this Agreement pursuant to its terms, the Parties will settle the
information service fee accrued prior to the termination. At the settlement, the Parties will
determine the settlement method, cycle and process and implement the settlement by reference to the
rules hereof regarding the deduction of information service fee or penalty fine in case of breach.
7.12 Each Party shall undertake its own due taxes.

7.13 Party A may refuse to settle the information fee incurred by stolen user numbers as proved by
public security department or acknowledged by both parties.

7.14 The abnormal consumption that may be written off with the help of Party B shall be deducted
from the Settled Information Service Fee of the current period after confirmed by the Parties, and
Party A shall refund such fee to the relevant users.

7.15 Party B shall be obliged to assist Party A in taking necessary effective steps to reduce the
number of abnormal deals.

7.16 Party B shall not make self-consumption and other violations detrimental to Party A's
interests. Such violating acts, once discovered, shall grant Party A with a right to deduct all
settlement amounts of the current month payable to Party B, and Party B will claim breaching
responsibility against Party B according to the extent of impact, including penalty fines,
suspension of settlement, suspension of business up to termination of cooperation. Page 16 of 29
<!-- page 17 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 Article 8 Relevant Undertakings

8.1 Party B undertakes that the games, software, business, works, contents or services it provides
are all in compliance with relevant laws, rules and regulations of the State and are free of any
ownership defect, and Party B has executed necessary authorization/license agreement with the right
owner and/or the agent thereof in accordance with applicable requirements.

8.2 Party B will be deemed to have committed a breach hereunder if a third person initiates any
legal or administrative proceedings (collectively the "Infringement Charges") alleging that Party A
or any of its affiliated companies or entities has infringed on the legitimate rights and interests
of such third person (including but not limited to intellectual property rights), or if Party A or
any of its affiliated companies or entities is threatened with administrative penalties. Upon a
notice to Party B, Party A shall have the right to freeze Party B's settlement account, and Party B
will take responsibilities toward such third person and indemnify Party A or any of its affiliated
companies or entities for all costs and expenses thus incurred, including, without limitation, any
and all litigation fees, travelling costs, attorney fees, amount of settlement or any compensation
provided in the final sentence. Such costs and expenses incurred may be deducted by Party A directly
from the performance deposit or any unsettled payment under this Agreement or other agreements; any
shortfall shall be paid by Party B within 3 working days upon the notice from Party A. This article
shall survive the termination of this Agreement.

8.3 The Parties may negotiate separately the terms regarding the use of Party A's enterprise name,
service brand, business brand, trademark, markings or logo, etc. in the business hereunder. Party B
shall not use any of the foregoing in any form whatsoever without reaching an agreement with Party A
or obtaining Party A's prior written confirmation; otherwise, an infringement will be constituted.
In such case, Party B shall eliminate the negative impact and compensate Party A for any losses thus
caused.

8.4 Party B shall not, in any manner whatsoever, mislead the users into believing that any game,
software, business, works, content or service it provides on its own is provided by Party A or by
both Parties.

8.5 Neither Party shall use or imitate the other Party's business name, trademark, patterns, service
logo, symbols, code, model or initials in its advertisements or in public places without the written
permit of such other Party; neither Party shall claim its ownership over such other Party's business
name, trademark, patterns, service logo, symbols, code, model or initials.

Article 9 Security and Confidentiality

9.1 Party A guarantees the completeness of all information/application service resources it
provides, and Party A undertakes not to sell, transfer, duplicate, lease or hand over any content or
app provided by Party B to any third party entity or individual in any form whatsoever (including in
edited, abridged or added version), unless otherwise provided by laws. Page 17 of 29
<!-- page 18 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 9.2 Neither Party shall divulge or disclose this
Agreement to any third party without written consent of the other Party.

9.3 Each Party shall have the obligation of confidentiality with respect to any and all information
and documents provided by the other Party over the course of business development and operation, and
neither Party may disclose such information to a third party, or use such information for any
purposes other than cooperation project development without the written consent of the other Party
(except for the disclosure made in response to the requirements of laws, regulations or relevant
regulators); otherwise, such Party shall assume relevant legal responsibility toward the other
Party; provided, however, that any information that has already been possessed by a Party, has been
obtained from a third party through lawful approaches, or has become publicly available prior to the
disclosure shall not belong to the aforementioned confidential information.

9.4 The obligation of confidentiality provided in this article shall survive the termination of this
Agreement.

Article 10 Liabilities for Breach of Agreement

10.1 Both Parties shall strictly comply with the terms of this Agreement; a Party's failure to
perform any of its own obligations, undertakings or covenants, or its violation of any of its
statements hereunder, which brings damage to the interests of the other Party or renders the
cooperation business impossible to be continued, shall be operated as a breach, and the breaching
Party shall assume the liabilities for breach by indemnifying the other Party for any loss thus
incurred and paying the penalty provided by relevant term hereof. In case of any damage to the other
Party's reputation, the breaching Party shall also undertake such liabilities as stopping damage,
making apologies and restoring reputation.

10.2 In case this Agreement and its appendices is unable to be performed or fully performed due to a
breach by a Party, the breaching Party shall assume the breaching liabilities and the non-breaching
Party may terminate the cooperation business, and may further claim legal and economic
responsibility from the breaching party if the breaching Party causes adverse social impact or
economic losses to the non-breaching Party. In case of breach by both Parties, the Parties shall
assume their respective due responsibilities according to the actual situation.

10.3 If Party B unilaterally terminates this Agreement, or is penalized with termination of
cooperation according to Management Measures for Game Partner Credit Points, or if Party A
terminates this Agreement pursuant to the terms hereof, Party B agrees:

(1) to offer one-month exit grace period during which Party B shall continue to provide services for
customers and publish announcementin respect of the cease of its services at its website;

(2) to pay off penalty fines and performance bond to Party A in full amount; and

(3) that Party A shall have the right not to settle the outstanding and unsettled payments. Page 18
of 29
<!-- page 19 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 10.4 Neither Party shall assume any breaching
liability if this Agreement is terminated due to the industry regulation by government (a written
document shall be provided) or other event of force majeure.

10.5 Party A will not be responsible to compensate Party A for any loss arising from the malfunction
caused by Party A's equipment, system or network and such other non-human caused reasons, but shall
be obliged to fix the malfunction as soon as possible.

10.6 Party A will not take any responsibility if the conduct of business agreed herein is impacted
when Party A is carrying out necessary construction or network building.

10.7 If Party A discovers that Party B has violated the Integrity Agreement attached hereto by
bribing Party A's working personnel, Party A may elect to impose a penalty of RMB10,000 to 100,000,
suspend cooperation for 1-3 years or terminate the cooperation depending on the seriousness of the
violation and the consequences thus brought about, and any loss thus incurred to Party A shall be
borne by Party B.

10.8 Any of the following acts by Party B shall constitute its breach hereunder, in which case Party
A shall have the right to immediately stop the interface of Party B's system, suspend settlement,
and require Party B to penalty at an amount equivalent to 100% of the total amount of its receivable
information fee of the then-current month or RMB3,000, whichever is higher. Any loss thus incurred
to party A shall be fully borne by Party B. If Party B manages to complete the remedy to the
satisfaction of Party A within 10 working days, Party A will resume the interface of Party B's
system and resume the settlement; if Party B fails to complete the remedy within such 10 working
days, or the completed remedy still fails to reach Party A's requirements, or Party B has committed
three breaches accumulatively, Party A may notify Party B to terminate this Agreement:

(1) Party B's service has any content that is illegal, in violation of rules, reactionary or against
the principle of public order and good socialcustoms;

(2) Party A has received from different users over 15 (included) justified complaints within one
day, or over 50 (included) justifiedcomplaints within 30 days about the same subject;

(3) The user complaints incurred due to reasons attributable to Party B have caused adverse social
impact, or have been reported to newsmedia, administration of telecommunication, AIC or other
relevant government agency;

(4) Party B is accused, or causes Party A to be accused of infringement, or Party or Party B is sued
by others, penalized or reported bymedia for reasons attributable to Party B; Page 19 of 29

Jiangsu Telecom Contract No.: JSXCS1200166CC000
<!-- page 20 -->
(5) Party B violates laws, rules or regulations of the sector, or any documents, management measures
or policies of telecommunication orrelevant industry authority;

(6) Any hardware, software, business or game provided by Party B in this business is held by Party A
to fail to satisfy the businessrequirements upon its testing, or is withdrawn by Party B earlier
than agreed;

(7) Party B fails to have the relevant qualification, or provide its services beyond the permitted
scope of its qualification;

(8) Party B discretionally discloses Party A's trade secrets, technical files, marketing plan,
customer files, cooperation agreement and otherkey secrets to any third party;

(9) Party B unilaterally amends, terminates or refuses to perform, this Agreement without justified
reason and without first reaching anagreement with Party A;

(10) Party B fails to obey the business supervision or management of Party A, or fails to remediate
as required by Party A;

(11) Party B infringes on the communication secrets or personal privacy of users or other persons;
(12) Party B delays or fails to fullyperform its obligations and duties hereunder;

(13) Party B breaches the Undertakings on Network Access Information Safety;

(14) Party B discretionally uses Party A's name, logo or other relevant information without Party
A's consent, which causes adverse impactor economic loss to Party A;

(15) Party B's illegal advertising or practices has resulted in indemnification or negative media
reports of Party A;

(16) Party B's 24-hour customer service call and other relevant information fails to match that
existing on the service system, or fails to beaccessed normally, or fails to make response for a
long time;

(17) Party B fails to provide the customer service support as required by this Agreement and
business management measures, shuffle responsibility to others, or fails to respond to any customer
claims or complaints transferred by Party A in time as required by its commitments hereunder or
Party A's management measures;

(18) Party B's other breach, or acts that are illegal, violating or detrimental to Party A's
interests. Page 20 of 29
<!-- page 21 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 10.9 In case of Party B's other breach of this
Agreement or of Party A's relevant management rules, Party A may claim breaching liability from
Party B pursuant to thereto, and may terminate this Agreement. At the same time, Party B shall take
full responsibilities to compensate any loss incurred to Party A due to Party B's such breach.

10.10 Notwithstanding anything herein is provided in contrary, Party A will not be responsible for
any loss of expected benefits, goodwill loss, and data damage or loss arising from acts of Party B
hereunder.

10.11 If Party B should pay penalty fines and/or assume compensation liability according to this
Agreement or Party A's relevant management rules, Party A shall have the right to deduct the
relevant amount directly from any settlement payment or performance bond.

Article 11 Force Majeure

11.1 In case this Agreement is unable to be performed or fully performed due to any accident or
event of force majeure, neither Party shall compensate the other Party for any economic loss thus
suffered. The Party encountering such event of force majeure shall immediately inform the
circumstances to the other Party in writing and within fifteen days, shall provide the detailed
information of the event and a valid document evidencing the reasons why this Agreement cannot be
performed or fully performed or the performance of this Agreement needs to be postponed. The Parties
shall negotiate to decide whether to continue the performance of this Agreement or terminate this
Agreement according to the extent of the effect on the performance hereof.

Article 12 Dispute Resolution

12.1 Any disputes between the Parties arising from the performance of this Agreement shall be
resolved through amicable negotiations; in case such negotiations fail, both Parties agree to submit
the dispute to the competent court where Party A is domiciled.

12.2 In case of disputes between the Parties over certain provisions hereof, or when any such
dispute is pending for resolution, the Parties shall continue to implement the other provisions
hereof except the disputed provisions.

Article 13 Effectiveness, Amendment and Termination of Agreement

13.1 This Agreement shall come into force as of January 1, 2013 and remain valid for 1 year. As of
the effective date hereof, the original cooperation of mobile game business executed between the
Parties shall terminate automatically. Upon the expiry of this Agreement, this Agreement may be
renewed automatically for one year (but can only be renewed once) if neither Party raises objection.
Except otherwise agreed between the parties, the contents of this Agreement shall remain binding
throughout the renewed period. Page 21 of 29
<!-- page 22 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 13.2 Throughout the effective term and renewed term
hereof, this Agreement may be revised or amended upon mutual consent. The Parties may execute a
supplemental agreement or execute a new agreement to reflect such revision or amendment.

13.3 Any business rules, management measures, quality standards and/or customer service standards
formulated by Party A during the term hereof shall be part of this Agreement, and if such rules,
measures and/or standards conflict with the terms hereof, such rules, measures and/or standards
shall prevail, unless the Parties deem it appropriate to apply this Agreement or deem it necessary
to execute a separate agreement for such conflicts.

13.4 Any Party who wishes to amend or revise this Agreement must provide a 30-day prior written
notice to the other Party, and the Parties shall negotiate to amend or revise this Agreement in
writing.

13.5 During the term hereof, Party A may, depending on the business development and needs of
management, evaluate and sort out Party B and its business according to unified rules. If Party B
fails to reach the requirements in Party A's evaluation, sorting or other business management
measures, Party A may terminate this Agreement.

13.6 Throughout the performance of this Agreement, except otherwise expressly provided herein,
neither Party may suspend or terminate the performance of this Agreement or unilaterally terminate
this Agreement without the consent of the other Party.

13.7 Any Party's failure to perform its obligations or duties hereunder, or serious violation of the
provisions hereof, which has made the other Party unable to operate or normally conduct business
cooperation hereunder, shall be deemed that such Party has unilaterally terminated this Agreement.
The non-breaching Party shall have the right to claim compensation from the breaching Party for any
economic loss incurred by its breach, and terminate this Agreement.

13.8 This Agreement shall automatically terminate if Party B:

(1) transfers or leases the numbers, trunk line, digital web address and such other resources
acquired from Party A without approval ofParty A;

(2) runs its business beyond the business operation area and business scope provided by its
qualification permit;

(3) has no qualification permit issued by the State competent authority but provides the content and
category of the business that needssuch qualification permit;

(4) provides fake copyright or qualification;

(5) fails to pass the assessment of "survival of the fittest" organized by Party A, in which case
this Agreement shall be automatically terminated. If Party B's receivable information fee of
accumulatively 3 months is zero, this Agreement shall be automatically terminated (except the free
games); Page 22 of 29
<!-- page 23 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 (6) disobeys Party A's business management or hurts
Party A's interests;

(7) otherwise disobeys the requirements of relevant authority or Party A's management.

13.9 During the term hereof, any division, merger, dissolution, liquidation, bankruptcy or other
events that lead to changes of Party B in the company nature, qualification and capacity for civil
acts shall be notified to Party A in time, and subject to the provisions hereunder about the exit
grace period. If Party B is deprived of the qualification or capacity to provide the wireless value
added business hereunder due to its dissolution, liquidation or bankruptcy, this Agreement shall
terminate accordingly. In case of division or merger of Party B, this Agreement shall terminate, and
the successor company (or other entity) to Party B's wireless value added business hereunder shall
re-apply for business opening to Party A, and timely modify Party B's enterprise identifier code and
other information existing on Party A's business system or other business management system.

13.10 In case of any change of Party B's company information, Party B shall go to the AIC, tax
authority, bank or information industry authority to complete the procedures of company information
change, exchange the original certificates for the valid ones, and submit the amended business
license, organization code certificate, tax registration certificate and such other relevant
documents and certificates to Party A for verification, the photocopies of which shall be filed for
record.

13.11 If Party B has to terminate this Agreement due to technical or operating difficulties, Party B
shall serve an at least 3 month prior written notice to Party A, and after approved by Party B,
offer a one-month exit grace period during which Party B shall continue to provide services for
users and publish announcement in respect of the cease of game services at its website (Web/WAP) or
through other channels at least 30 days in advance. Any loss thus incurred to Party A shall be
compensated by Party B.

13.12 During the effective term hereof, if the terms of this Agreement contravene any new fee rate
policy or new document published by the supervisory authority of the Parties, the Parties may
negotiate to amend or terminate this Agreement.

Article 14 Miscellaneous

14.1 Any matters not covered herein shall be subject to the relevant business standards, management
measures, quality standards and/or customer service standards, or subject to written supplementary
articles agreed by the Parties upon amicable negotiations, which shall be equally binding as this
Agreement.

14.2 If any term hereof becomes invalid at any time but will not fundamentally affect the validity
of this Agreement, the other terms hereof shall not be affected. Page 23 of 29
<!-- page 24 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 14.3 The headings hereof are inserted for reference
only. The contents of the terms shall be the basis to determine the rights and obligations of the
Parties.

14.4 Nothing herein shall be deemed or construed as joint venture, partnership or agency
relationship between the Parties.

14.5 This Agreement shall be made in four originals, two for each Party, which shall be equally
effective.

14.6 Any notices (information) between the Parties arising out of the implementation of this
Agreement, or in connection with this Agreement must be sent to the addresses expressly specified
herein in written form, including, without limitation, via facsimile, EMS or other form confirmed by
the Parties. (End of body text)

(The remainder of this page is intentionally left blank.) Page 24 of 29
<!-- page 25 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 [Signature and Stamp Page]

Party A: Dazzle Interactive Network Technologies Co., Ltd. By authorized representative: Zhang Peng
Signature and stamp:

[Company seal is affixed] /s/ Zhang Peng

Date: January 1, 2013

Party B: Shenzhen iDreamSky Technology Co., Ltd. By authorized representative: Chen Xiangyu
Signature and stamp:

[Company seal is affixed] /s/ Chen Xiangyu Date: January 1, 2013 Page 25 of 29
<!-- page 26 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 Appendix 1:

Integrity Agreement

In order to jointly safeguard the company interests of both Parties and cause the parties and their
respective working staff to practice in an integral manner, in accordance with relevant laws and
regulations, the Parties agree as follows:

1 The Parties and their respective working staff shall consciously comply with the laws and
regulations governing integral practices and prohibited commercial bribery of the State and
government.

2 Party A shall not privately ask for or accept any off-the-book rebates or other money or gifts
provided by Party B.

3 Party A's working staff shall not, in any form whatsoever, ask for or accept from Party B any
rebates, money, valuable securities, valuable properties or other articles; nor shall they reimburse
any expenses irrelevant to this project or request personal benefits from Party B.

4 Party A's working staff shall not attend any treats or entertainment that may affect Party A's
performance of its obligations and duties.

5 Party A's working staff shall not privately discuss this project with Party B or reach a tacit
understanding with Party B, nor disclose any bidding internal control information or corporate trade
secrets.

6 Party A's working staff shall not seek benefits for his/her family members, relatives or friends
in the project by taking advantage of his/her powers or official capacity.

7 Party B shall not privately offer Party A any off-the-book rebates or other money or gifts.

8 Party B's working staff shall not, in any name or form whatsoever, provide Party A's working staff
with any rebates, money, valuable securities, valuable properties or other articles; nor shall they
reimburse any expenses irrelevant to this project for Party A's working staff.

9 Party B shall not invite Party A's working staff to go trips or other luxury entertainment under
the name of discussing business or executing economic contracts.

10 If either Party discovers any violation hereof by any working staff of the other Party, it shall
report such violation to the supervisor or the disciplinary department of such staff, and the staff
so reported shall not retaliate to such Party under any excuses. Page 26 of 29
<!-- page 27 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 11 Liabilities for breach:

If Party A discovers that Party B violates this Agreement, bribes Party A's working staff, or has
committed any commercial bribery being investigated by judicial authority, Party A shall have the
right to suspend the agreement and depending on the actual situation and consequences thereof, claim
compensation from Party B for the economic loss thus incurred to Party A, record such bad acts of
Party B, disallow Party B the access to Party A's full corporate scope to engage in the various
services, supplies, construction and other project cooperation for 1 to 3 years,

Call number for each Party to accept violation reporting: Party A: 025-86588790 Party B:
0755-86110235 Page 27 of 29
<!-- page 28 -->
Jiangsu Telecom Contract No.: JSXCS1200166CC000 Appendix 2:

Undertakings on Network Access Information Safety

Each of the information source providers connected to the mobile communication network of Dazzle
Interactive Network Technologies Co., Ltd., CHINANET of China Telecom or relevant business platform
(including, without limitation, SMS gateway, WAP gateway, JAVA/BREW download server, location
business server, etc.) shall undertake that:

Article 1 it will comply with the relevant laws, administrative regulations and management rules of
the State, and strictly implement the information safety management rules.

Article 2 it will operate its business according to relevant laws, and provide the service only
after obtaining relevant business permits; the business operation without permit is prohibited.

Article 3 it will not make use of C114 or CHINANET of China Telecom or relevant business platform to
(i) engage any illegal or criminal activities that endanger the national safety or divulge the
secrets of the State, (ii) produce, consult, duplicate or disseminate any information that violates
the Constitution or laws, impedes social security, damages national unity or sabotages solidarity
among nationalities, or any pornographic or violent information, or (iii) post any information with
any content that:

1 is against the fundamental principles enshrined in the Constitution;

2 compromises State security, divulges State secrets, subverts State power or damages national
unity;

3 harms the dignity or interests of the State;

4 instigates hatred and discrimination among nationalities and sabotages solidarity among
nationalities;

5 sabotages State religious policy or propagates heretical teachings or feudal superstitions;

6 spreads rumors, disrupts social order or social stability;

7 propagates obscenity, pornographic, gambling, violence, murder and terror and instigates crimes;

8 insults or slanders a third party or infringes upon the lawful rights and interests of a third
party;

9 belongs to the thirteen vulgar online contents that violate social ethics and hurt the physical
and mental health of youngsters, whichare the contents that:

(a) depict or obscurely depict sex behavior, instigate sex association, or are provocative or
insulting;

(b) directly expose and describe the sex organ of human body;

(c) describe sex behavior, sex process or sex manner or contain sexually suggestive or provocative
language;

(d) describe or expose the sex organs, or only use very small covering;

(e) depict human body with the entire body or privacy places naked or only covered by limbs;

(f) contain pictures of careless bare, candid shot, privacy place exposure with a nature of
infringing personal privacy;

(g) attract clicks with provocative headings; Page 28 of 29

Jiangsu Telecom Contract No.: JSXCS1200166CC000
<!-- page 29 -->
(h) are pornographic, vulgar novels, audios and videos that are prohibited by relevant authority,
including the deleted portions ofsome movies;

(i) contain illegal social information about one-night stand, wife exchange or SM; (j) pornographic
comics;

(k) advertise bloody violence, malicious abuses, or insult others;

(l) contain illegal sex products advertisements and venereal disease treatment advertisements;

(m) maliciously disseminate others' privacy without permit from others or by using "Internet Mass
Hunting";

10 Otherwise prohibited by laws, administrative regulations, rules or relevant regulations.

Any of the abovementioned illegal or criminal activities and/or posting of any harmful information,
once discovered, shall be prevented by immediate measures and reported to relevant authority in
time.

Article 4 any information provided by it will comply with the relevant State laws, administrative
regulations, rules or policies governing intellectual property rights.

Article 5 it shall make sure, during its online testing and pilot running and after the business is
officially opened, that the contents of the business it provides are safe and stable, and will cause
damage to C114 or CHINANET of China Telecom or relevant business platform.

Article 6 It shall establish efficient information safety and confidentiality management policies
and technical protective measures, and accept the management, supervision and inspection of relevant
competent authority of the relevant business of Dazzle Interactive Network Technologies Co., Ltd.

Article 7 in case of any violations of the above, Dazzle Interactive Network Technologies Co., Ltd.
may take necessary actions, close relevant information source access; in case of serious violation,
Dazzle Interactive may terminate the cooperation business and claim legal responsibility from the
information source provider. These undertakings will take effect upon executed by the information
source provider and be kept in custody by Dazzle Interactive Network Technologies Co., Ltd.

Information source provider (stamp):

[Company seal is affixed] Responsible Person (signature):

/s/ Chen Xiangyu Page 29 of 29
