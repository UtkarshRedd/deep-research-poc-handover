<!-- page 1 -->
# Fee Letter — Corvallis Foods Group
| Field | Value |
|---|---|
| Document Type | Fee Letter |
| Effective Date | 2025-04-01 |
| Parties | Corvallis Foods Group LLC; Pacific Commerce Bank |
| Facility ID | FAC-2025-0108 |
| Version | Original (Execution Version) |

Reference: PCB-2025-FEE-0108
Pacific Commerce Bank
600 Montgomery Street, 30th Floor, San Francisco, California 94111

2025-04-01

Corvallis Foods Group LLC
455 Willamette Avenue, Corvallis, Oregon 97330

Re: Credit Agreement dated as of 2025-04-01 (facility FAC-2025-0108) — Fees

Ladies and Gentlemen:
This letter (this "Fee Letter") sets forth the fees payable by the Borrower in connection with the Credit Agreement. Capitalized terms used but not defined herein have the meanings given in the Credit Agreement. This Fee Letter is a Loan Document.
<!-- page 2 -->
## 1. Fees
(a) Upfront Fee. On the Effective Date, the Borrower shall pay to the Administrative Agent, for the account of each Lender, an upfront fee equal to 0.50% of such Lender's Commitment on the Effective Date.
(b) Agency Fee. The Borrower shall pay to the Administrative Agent, for its own account, an annual agency fee of $50,000, payable in advance on the Effective Date and on each anniversary thereof.
(c) Arrangement Fee. The Borrower shall pay to the Administrative Agent, for its own account, an arrangement fee as separately agreed in writing.
## 2. Payment
All fees are payable in immediately available funds, without setoff or counterclaim, to the Administrative Agent at Pacific Commerce Bank , Account No. 7730-114562, reference PCB-2025-FEE-0108.
Fees paid are non-refundable under all circumstances.
<!-- page 3 -->
## 3. Confidentiality; Governing Law
The Borrower shall keep this Fee Letter confidential and shall not disclose it to any person other than its officers, directors, advisors and the Lenders, except as required by law.
This Fee Letter shall be governed by the laws of the State of California.
Very truly yours,
Pacific Commerce Bank, as Administrative Agent — By: /s/ Authorized Signatory
Accepted and agreed: Corvallis Foods Group LLC — By: /s/ Authorized Signatory
