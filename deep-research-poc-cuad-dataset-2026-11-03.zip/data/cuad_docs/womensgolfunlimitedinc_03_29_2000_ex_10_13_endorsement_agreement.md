<!-- page 1 -->
# Endorsement Agreement
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 1999-10-13 |
| Parties | SQUARE TWO GOLF INC. ("Company"); KATHY WHITWORTH ("Professional") |
| Source | CUAD v1 / WOMENSGOLFUNLIMITEDINC_03_29_2000-EX-10.13-ENDORSEMENT AGREEMENT |

1

EXHIBIT 10.13

EXECUTION COPY

ENDORSEMENT AGREEMENT ---------------------

This Endorsement Agreement ("Agreement") is made this 13th day of October, 1999 by and between
SQUARE TWO GOLF INC., a New Jersey corporation (the "Company"), and KATHY WHITWORTH, an individual,
with an address at 302 La Mancha Court, Santa Fe, New Mexico, 87501 (the "Professional").

RECITALS --------

WHEREAS, the Company manufactures and sells women's golf clubs and other golf equipment;

WHEREAS, the Professional is a retired Ladies Professional Golf Association ("LPGA") Tour
Professional;

WHEREAS, the Company desires to utilize the services of the Professional in connection with the
promotion, marketing, and sale of a signature line of women's golf clubs and the Company's other
products and services; and

WHEREAS, the Company and the Professional desire to enter into an agreement pursuant to which the
Professional will serve the Company as an independent contractor, on the terms and subject to the
conditions set forth herein.

NOW, THEREFORE, in consideration of the mutual covenants and agreements contained herein, the
Company and the Professional hereby agree as follows:

1. TERM.

1.1 The term of this Agreement shall begin on January 1, 2000 and continue for an initial period of
five (5) years unless earlier terminated in accordance with Section 7 hereof, and may be renewed
under Section 8 hereof (the initial period plus any renewal period, the "Term").

2. ENDORSEMENT SERVICES.

During the Term, the Professional will provide the services described in this Section 2 (the
"Services"):

2.1 The Professional hereby grants to the Company an exclusive license to use her name, likeness,
image and personal identification, singly or in any combination, in connection with the production,
use, marketing and sale of a "Kathy Whitworth" signature line of women's golf clubs (the
"Products"), as described more fully in Section 3 below.

2

EXECUTION COPY

2.2 The Professional agrees to serve as a professional golf instructor during up to ten (10) golf
clinics hosted by the Company per calendar year at locations within the United States to be
determined by the Company. The golf clinics shall be one or two day events.

2.3 The Professional agrees to serve as a spokesperson for the Company at up to two (2) Professional
Golf Association merchandise shows, including but not limited to the PGA Merchandise Shows.

2.4 The Professional hereby grants to the Company the exclusive and worldwide right to use her name,
likeness, image and personal identification, singly or in any combination, during the Term and for a
period of six (6) months after the Term as provided in Section 2.8, in the creation of two (2) print
advertisements per year and one (1) television advertisement per year (together, the
"Advertisements") for any golf equipment, along with all rights in any images, videos, advertisement
copy or other materials created by the Professional or others. The Professional agrees that the
Company shall own all such materials and all intellectual property rights&bbsp;therein for use in
perpetuity in any media now known or hereafter devised or developed, including but not limited to
the internet. The Professional hereby grants to the Company the worldwide right during the Term and
for a period of six (6) months after the Term as provided in Section 2.8 to use, reproduce, print,
publish, distribute, broadcast, modify, edit, condense, or expand any materials containing her name,
image, likeness or personal identification that are created hereunder.

2.5 The Professional hereby grants to the Company an exclusive license to use her name, likeness,
image and personal identification in the Company's catalog of products.

2.6 The Professional agrees to participate in a minimum of five (5) other events per calendar year
to market and promote the Company's products,
<!-- page 2 -->
including but not limited to market consultations, each of which shall include meeting with the
Company executives to assist in the design, development, marketing and promotion of the Company's
products.

2.7 The Professional agrees to use only the golf clubs and golf bags of the Company in any golf
event, whether professional or social, during the Term. The Professional agrees (i) to use no golf
bag bearing any identification of a competitor of the Company and (ii) to wear no apparel bearing
any identification of a competitor of the Company, and will prohibit any caddy of hers from bearing
any such identification.

2.8 The Company shall cease use of the name, likeness, image or personal identification of the
Professional upon expiration or termination of this Agreement. However, the Company will have the
right to dispose of its inventory of Products existing at the time of termination or expiration of
this Agreement and the right to use the name, likeness, image and personal identification of the
Professional in connection with the disposition of such inventory. The right granted in this section
shall expire six (6) months after the termination or expiration of this Agreement. The Professional
understands and agrees that the Company shall have no obligation to take action against or attempt
to stop distributors, retailers and other third parties to this Agreement who have purchased
Products bearing the name, likeness, image or personal

-2- 3

EXECUTION COPY

identification of the Professional from any marketing, advertising, sale or other disposition of
such Products, regardless of any use they make of the name, likeness, image or personal
identification of the Professional.

3. LICENSE AND ENDORSEMENT FOR PRODUCTS.

3.1 The Professional hereby grants an exclusive, worldwide license to the Company to use the name,
likeness, image and personal identification of the Professional, during the Term and for a period of
six (6) months after the Term as provided in Section 2.8, in connection with the creation,
manufacture, marketing, sale and promotion of the Products. As a condition precedent to, and a
continuing precedent of, any obligations of the Company hereunder, the Professional hereby agrees to
use the Products upon their creation and to provide an unqualified and unequivocal endorsement
thereof during the Term at the request of the Company at any time or times during the Term in
verbal, written or recorded forms. If the Professional is unable at any time during the Term to
provide such endorsement of the Products, the Company shall be released from any of its obligations
under Sections 4.1, 4.2, and 4.3 hereof to pay any fees or royalties or to provide any stock options
to the Professional and may elect to terminate this Agreement without any further obligation to the
Professional.

4. COMPENSATION FOR ENDORSEMENT SERVICES.

4.1 The Company will pay the Professional a base fee of thirty-six thousand dollars ($36,000) per
year (the "Base Fee") for Services performed during the Term. The Company shall pay the Base Fee in
four (4) equal installments of nine thousand dollars ($9,000) each on March 15, June 15, September
15 and December 15 of each year during the Term commencing on January 15, 2000. The Professional
acknowledges that the Company is under no obligation to create or maintain the Products. The
Professional agrees that payment of the Base Fee shall satisfy all obligations of the Company
hereunder if it elects not to create or market and sell the Products.

4.2 If the Company elects to create and market the Products, the Company will pay to the
Professional a "Royalty Fee" on the sales of Products during the Term, except as provided in the
following sentence, of two percent (2%) of the "Royalty Base," which Royalty Base shall be
calculated as the wholesale selling price of all Products for which the Company actually receives
the proceeds of such net of returns, allowances, discounts, shipping, taxes, insurance and credits.
During the Term, the Company shall pay the Royalty Fee, earned for the preceding quarter, to the
Professional quarterly, within thirty (30) days of the end of the succeeding calendar year quarter.
If the Company decides not to renew this Agreement in accordance with the provisions of Section 8
below, the Company shall pay the Professional an amount equal to two percent (2%) of the net book
value of its unsold inventory of Products on December 31, 2004.

4.3 If the Company elects to create and market the Products, the Company will grant to the
Professional options to purchase shares of the Company's capital stock ("Options"), as provided in
this paragraph. On each March 31, June 30, September 30, and December 31 during the Term that the
Company elects to continue the marketing and sale of the Products, the Company will grant to the
Professional a number of Options (the "Quarterly Grant Number").

-3- 4

EXECUTION COPY

The Quarterly Grant Number shall be the nearest whole number that results from the division of the
number of dollars represented by one half of one percent
<!-- page 3 -->
(0.5%) of the Royalty Base by the closing price of the Company's stock on the grant date. The
exercise price of the Options shall be the closing price of the Company stock on the grant date. The
sum of the Quarterly Grant Numbers in each calendar year of the Term shall not exceed fifteen
thousand (15,000). The options will expire five (5) years after each grant date. The Options shall
not be assigned, transferred or alienated by the Professional. Any attempt to assign, transfer or
alienate the Options without the prior written consent of the Company shall be void.

4.4 The Company will reimburse the Professional for her reasonable and necessary travel expenses in
connection with her performance of the Services.

4.5 The Company shall be under no obligation to create, market, promote or sell the Products. There
shall be no minimum amounts due from the Company hereunder except as specified in Section 4.1 above.
The failure of the Company to create, market, promote or sell the Products or to reach any specific
sales volume shall not result in any liability of the Company or create any right for the
Professional to make a claim against the Company. The Company may elect to dispose of the Products
at any price or for no consideration in its sole discretion and shall not be obligated to the
Professional for any sale or transfer of the Products which does not produce compensation for the
Professional.

5. PROFESSIONAL'S CONDUCT.

5.1 The Professional shall at all times during the Term refrain from:

5.1.1 dishonest, fraudulent, illegal or unethical acts or omissions;

5.1.2 excessive use or abuse of alcohol;

5.1.3 use of controlled substances, except as prescribed by a licensed medical professional in the
treatment of illness or disease;

5.1.4 acts or omissions reasonably determined by the Company to be prejudicial or injurious to the
business or goodwill of the Company, its officers, employees, shareholders or products, the golf
industry or professional golf; and

5.1.5 conduct which could reasonably be expected to degrade the Professional, devalue the services
of the Professional or to bring the Professional into public hatred, contempt, scorn or ridicule, or
that could reasonably be expected to shock, insult or offend the community or to offend public
morals or decency.

6. INDEPENDENT CONTRACTOR.

6.1 With respect to all Services described in this Agreement, the Professional's status will be that
of an independent contractor and not a partner, employee or agent of the Company. The Professional
has no power or authority whatsoever to make binding commitments or

-4- 5

EXECUTION COPY

contracts on behalf of the Company. The Professional agrees that she will pay and hold the Company
harmless from any and all costs, expenses, fees, dues, pension contributions, benefit contributions
and fines associated with her present or future required membership in any trade association, union
or professional organization, including but not limited to LPGA, PGA, USGA, SAG or AFTRA, that may
be associated with her performance of this Agreement. The Professional represents that no agent or
representative fees, charges, rights or claims exist in connection with her execution or performance
of this Agreement, and the Professional shall hold harmless the Company from any such liability. Any
costs incurred by the Company to comply with any rule, contract, order or other requirement of SAG,
AFTRA or other union or professional organization having control or jurisdiction over the
Professional or her performance of the services required by this Agreement shall be deducted from
the sums due from the Company to the Professional. The Professional agrees that the compensation
provided to her under Section 4 of this Agreement shall be deemed compensation for purposes of
meeting any minimum pay requirements of any SAG or AFTRA agreement. If any of the above terms are
deemed to violate any SAG or AFTRA agreement, the Company shall have the option to terminate this
Agreement without liability.

6.2 The Professional shall have no authority to incur expenses on behalf of the Company without the
Company's prior written approval. The Professional shall submit to the Company for written approval
a description of anticipated expenses, other than those for reasonable and necessary travel, prior
to incurring such expenses. All statements submitted by the Professional for expenses that were not
pre-approved by the Company will be subject to review, approval or rejection by the Company in its
sole discretion.

6.3 The Professional will be solely responsible for withholding and paying any and all federal,
state and local taxes, including but not limited to payroll, unemployment, social security and
income taxes, and any other payments which may be due as a result of or in connection with payments
made by the Company for services rendered under this Agreement. The Professional acknowledges that
she is not qualified for and will not receive any Company employee benefits or other incidents of
employment.
<!-- page 4 -->
6.4 The Professional agrees to maintain at all times during the Term such insurance, including
without limitation, health insurance, workers' compensation, automobile and general comprehensive
liability coverage, as will protect and hold harmless the Company from any claims, losses, damages,
costs, expenses or liability arising out of the Services performed under this Agreement. The Company
may require the Professional to provide insurance certificates evidencing the same.

6.5 The Professional represents and warrants that:

6.5.1 The Professional has the right to enter into this Agreement;

6.5.2 By agreeing to perform or performing this Agreement, the Professional will not breach any
existing agreement; and

-5- 6

EXECUTION COPY

6.5.3 Neither the Professional's grant of rights to the Company under this Agreement nor the
Company's exercise of such rights will cause the infringement of any rights of third parties.

6.6 The Professional agrees not to enter into any other agreement the performance of which would or
could cause an infringement of the rights that the Professional grants to the Company under this
Agreement.

7. TERMINATION.

7.1 This Agreement shall terminate automatically if the Professional dies or becomes disabled, or
suffers illness, mental or physical disability to the extent that she is unable to perform the
obligations of the Professional under the terms of this Agreement.

7.2 Either the Company or the Professional may terminate this Agreement in the event of a
non-curable breach of this Agreement by the other party.

7.3 In case of a breach of the Agreement that is capable of being cured, the non-breaching party
shall, before terminating the Agreement, give the breaching party written notice of such breach, and
a thirty (30) day period in which to cure such breach.

7.4 The Professional's obligations under (i) Section 9 hereof and (ii) Exhibit A shall survive a
termination of this Agreement for the applicable periods set forth therein. The Company's obligation
to compensate the Professional pursuant to Section 4 of this Agreement shall cease on the effective
date of termination except as to amounts earned by the Professional and due from the Company
accruing prior to such date.

7.5 The right to terminate outlined in this section shall be in addition to, and not in lieu of, all
other remedies which may be available to the non-breaching party, whether at law or in equity, for a
breach of this Agreement.

8. RENEWAL.

8.1 The Company may renew this Agreement on the same terms and conditions for one (1) additional
five year period that shall begin on January 1, 2005 and end on December 31, 2009, by providing a
written notice of its intent to effect such renewal to the Professional by November 30, 2004.

9. NON-COMPETITION.

9.1 The Professional acknowledges that any use of her name, likeness, image or personal
identification by any third party in connection with the making, use, sale, marketing, promotion or
advertising of golf equipment, including but not limited to golf clubs and golf bags, would cause a
likelihood of confusion with the Products of the Company, during the Term and thereafter during the
time the Company disposes of inventory on hand at the expiration of this Agreement. The Professional
acknowledges that she will have a right, pursuant to and under the

-6- 7

EXECUTION COPY

conditions described in Section 4.2 above, to receive a specified royalty for inventory on hand at
the expiration of the initial term, and accordingly hereby grants to the Company the right to fill
any orders for, assemble components of, market, advertise, promote and sell any inventory of
Products in its inventory existing at the expiration or termination of this Agreement, for a period
not to exceed two (2) years after such expiration or termination of the original term. To avoid any
possibility of confusion of the public, trademark infringement or interference with the rights of
the Company, the Professional agrees not to endorse, license or otherwise authorize the use of her
name, likeness or image in connection with another company's golf clubs or golf-related clothing or
equipment during the Term and for a period of two (2) years thereafter.

9.2 The Professional agrees to divest herself of any management or control interest that she
currently has in any entity that is a competitor of
<!-- page 5 -->
the Company, and not to acquire any such interest during the Term.

10. RIGHT OF INJUNCTIVE RELIEF.

10.1 The Professional acknowledges and agrees that a breach of the covenants contained in Section 9
of this Agreement would actually or potentially deprive the Company of a substantial amount of sales
and business value and that the amount of injury would be impossible or difficult to ascertain
fully. The Company shall, therefore, be entitled to obtain an injunction against the Professional
restraining any violation, further violation, or threatened violation of Section 9 above, in
addition to any other remedies to which the Company may be entitled by law.

11. MISCELLANEOUS.

11.1. ENFORCEABILITY. The unenforceability or invalidity of any provision of this Agreement shall
not affect the enforceability or validity of the balance of the Agreement. In the event that any
such provision should be or becomes invalid for any reason, such provision shall remain effective to
the maximum extent permissible, and the parties shall consult and agree on a legally acceptable
modification giving effect to the commercial objectives of the unenforceable or invalid provision,
and every other provision of this Agreement shall remain in full force and effect.

11.2. ASSIGNABILITY. This Agreement is not assignable by the Professional but is assignable by the
Company to any affiliate or successor entity. Any attempted assignment by the Professional without
the prior written consent of the Company shall be void. As used in this Agreement, the term
"Company" shall include any entity to which this Agreement shall have been assigned by the Company,
in accordance with the preceding.

11.3. AMENDMENT/WAIVER.

11.3.1 This Agreement supersedes all prior and contemporaneous agreements and understandings between
the parties with respect to the subject matter hereof and may not be changed or amended orally.

-7- 8

EXECUTION COPY

11.3.2 No change, termination or attempted waiver of any of the provisions of this Agreement shall
be of any effect unless the same is set forth in writing and duly executed by the party against
which it is sought to be enforced.

11.3.3 The failure of any party at any time or from time to time to require performance of the other
party's obligations under this Agreement shall in no manner affect such party's right to enforce any
provisions of this Agreement at a subsequent time. The waiver by any party of any right arising out
of any breach by the other party shall not be construed as a waiver of any right arising out of a
subsequent breach.

11.4. GOVERNING LAW. The validity, interpretation, construction and performance of this Agreement
shall be governed in accordance with the laws of the State of New Jersey without giving effect to
the principles of conflicts of laws of such state.

11.5. NOTICES. Any communication (including any notice, consent, approval or instructions) provided
for under this Agreement may be given to the person to whom it is addressed by delivering the same
to or for such person at the address or facsimile number of such person as set out hereinafter or at
such other address or number as such person shall have notified to the other party hereto, provided
that a copy of any communication sent by fax shall be immediately deposited in the mail. Any
communication so addressed and delivered as aforesaid shall be deemed to have been sufficiently
given or made on the date on which it was delivered.

If to the Company: S2 GOLF INC. 18 Gloria Lane Fairfield, New Jersey 07004 Attention: Mr. Douglas A.
Buffington Facsimile number: (973) 227-7018

With a copy to: Mary Ann Jorgenson, Esq. Squire, Sanders & Dempsey L.L.P. 4900 Key Tower 127 Public
Square Cleveland, Ohio 44114 Facsimile number: (216) 479-8776

If to the Professional: Kathy Whitworth 1735 Mistletoe Flower Mound, Texas 75022 Facsimile number:
(792) 355-7021

With a copy to: Nick Lampros 16615 Lark Avenue Suite 101 Los Gatos, California 95032 Facsimile
number: (408) 358-2486

-8- 9
<!-- page 6 -->
EXECUTION COPY

11.6. COUNTERPARTS. This Agreement may be executed in two or more counterparts, each of which shall
be deemed an original, but all of which together shall constitute one and the same instrument.

11.7. INTELLECTUAL PROPERTY RIGHTS, CONFIDENTIALITY AND NON-USE. The Professional acknowledges her
obligations under the provisions of the Intellectual Property Rights Confidentiality and Non-Use
Obligations Agreement attached hereto as "Exhibit A" and made a part hereof by this reference. The
rights and obligations of the parties set forth in Exhibit A shall survive the termination or
expiration of this endorsement agreement, regardless of cause or circumstances of the termination or
expiration.

IN WITNESS WHEREOF, the parties have executed this Agreement as of the date first above written.

SQUARE TWO GOLF, INC.

By: /s/DOUGLAS A. BUFFINGTON --------------------------------- Douglas A. Buffington President

PROFESSIONAL

/s/ KATHY WHITWORTH ------------------------------ Kathy Whitworth

-9- 10

EXECUTION COPY

EXHIBIT A

Intellectual Property Rights Confidentiality and Non-Use Obligations Agreement

This Agreement by and between SQUARE TWO GOLF INC., a New Jersey corporation (the "Company") and
KATHY WHITWORTH, an individual residing at 302 La Mancha Court, Santa Fe, New Mexico 87501 (the
"Recipient"), is part of the Endorsement Agreement of the parties. In consideration of and as an
inducement for the Company entering into said Endorsement Agreement with Recipient:

(a) Recipient acknowledges and agrees that communications for the purpose of proposing to work for
or working for the Company have in the past or will entail the disclosure, observation and display
to Recipient of information and materials of the Company that are proprietary, confidential and
trade secret, which include, but are not limited to, golf equipment marketing plans, research,
development and designs, computer software, screens, user interfaces, systems designs and
documentation, processes, methods, fees, charges, know-how and any result from the work performed by
Recipient or the Company, new discoveries, Intellectual Property (as defined below) and improvements
to the Company's products made for or on behalf of the Company (all of which, singly and
collectively, "Information").

With regard to such Information, whether or not labeled or specified as confidential, proprietary or
trade secret, Recipient agrees:

(i) to use the Information solely for the purpose of making proposals to or working under contracts
with the Company; and

(ii) not to disclose or transfer the Information to others without the Company's written permission.

(b) Recipient will not be prevented from using or disclosing Information:

(i) which Recipient can demonstrate, by written records, was known to it before the disclosure or
display of the Information by the Company to Recipient; or

(ii) which is now, or becomes in the future, public knowledge other than by breach of this Agreement
or the endorsement agreement by Recipient, its employees or agents; or

(iii) that is lawfully obtained by Recipient from a source independent of the Company, which source
was lawfully in possession of the Information and which source had the unrestricted right to
disclose or display the Information to the Recipient; or

(iv) that is required by legal process to be disclosed, provided that Recipient will timely inform
the Company of the requirement for disclosure, will permit the Company to attempt, by appropriate
legal means, to limit such disclosure and will itself
<!-- page 7 -->
A-1

11

EXECUTION COPY

use appropriate efforts to limit the disclosure and maintain confidentiality to the extent possible.

(c) The confidentiality and non-use obligations of Recipient will remain in effect after all work
for the Company has been completed.

(d) All Information, including any copies thereof, in any media, in the possession or control of
Recipient and Information embodied or included in any software or data files loaded or stored on
computers in the possession or control of Recipient, its agents or employees, shall be removed and
returned to the Company upon demand, but no later than the completion of work for the Company.

(e) Recipient agrees that she will not copy the Information in whole or in part or use all or any
part of the Information to reverse engineer, duplicate the function, sequence or organization of the
Information for any purpose without the prior written permission of the Company.

(f) Recipient further acknowledges and agrees that all new discoveries, inventions, improvements,
processes, formulae, designs, drawings, training materials, original works of authorship, photos,
video tapes, electronic images, documentation, trademarks and copyrights (the "Intellectual
Property"), that may be developed, conceived, or made by Recipient, alone or jointly with others
during her work for the Company, shall be the exclusive property of the Company and shall be deemed
a work for hire. Recipient hereby assigns and agrees to assign all Recipient's rights in any
Intellectual Property to the Company. Recipient hereby grants to the Company power of attorney for
the purpose of assigning all Recipient's rights in Intellectual Property to the Company for the
purposes of filings, registrations and other formalities deemed necessary by the Company to
prosecute, protect, perfect or exploit its ownership and interests in Intellectual Property.
Recipient further agrees to execute, acknowledge and deliver any documentation, instruments,
specifications or disclosures necessary to assign, prosecute, protect, perfect or exploit the
Company ownership of Intellectual Property.

(g) Recipient acknowledges and agrees that the Company possesses valuable know-how, proprietary,
confidential and trade secret Information that has been procured or developed by the Company at
great expense and that its unauthorized disclosure would result in substantial damages to the
Company that may not be adequately compensated by monetary relief. Accordingly, Recipient hereby
consents to the jurisdiction of the Federal and County Courts in Essex County, New Jersey and agrees
that the Company may seek temporary restraining orders against it or other extraordinary relief
necessary to protect the Information.

A-2
