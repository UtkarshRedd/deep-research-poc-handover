<!-- page 1 -->
# CO-BRANDING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Co-Branding Agreement |
| Agreement Date | 1999-06-08 |
| Parties | Snap Technologies, Inc. ("Snap"); United Airlines, Inc. ("Sponsor") |
| Source | CUAD v1 / EmbarkComInc_19991008_S-1A_EX-10.10_6487661_EX-10.10_Co-Branding Agreement |

Exhibit 10.10

CERTAIN INFORMATION IN THIS EXHIBIT HAS BEEN OMITTED AND FILED SEPARATELY WITH THE COMMISSION.
CONFIDENTIAL TREATMENT HAS BEEN REQUESTED WITH RESPECT TO THE OMITTED PORTIONS.

CO-BRANDING AGREEMENT

This Co-Branding Agreement (this "Agreement"), dated as of June 8, 1999, is made by and between Snap
Technologies, Inc. a California corporation having its principal place of business at 111 Townsend
St., San Francisco, CA 94107 ("Snap"), and, United Airlines, Inc., a Delaware corporation having its
principal place of business at 1200 E. Algonquin Road, Elk Grove Township, IL 60007 ("Sponsor").

RECITALS

A. Snap provides access to applications and other information and content regarding selecting and
applying to and attending colleges and graduate and professional degree programs to end users via
the World Wide Web; and

B. Sponsor wishes to obtain sponsorship placement on Snap's web site and access to certain
information pertaining to Snap's end users.

AGREEMENT

NOW, THEREFORE, the parties agree as follows:

SECTION 1. DEFINITIONS

Wherever used in this Agreement with initial terms capitalized, the following terms shall have the
following defined meanings:

"CO-BRANDED PAGES" means pages of the Snap Web Site, to be developed pursuant to Section 2.2
[CO-BRANDED PAGES] and hosted on the Snap Web Site, that display both the Snap Brand Features and
the Sponsor Brand Features, along with such Sponsor Content, Snap Content and other content as the
parties may agree upon.

"CONFIDENTIAL INFORMATION" means information of either party (whether of a technical, business or
other nature) which the other party knows or reasonably should know to be confidential or
proprietary information of such party.

"INTELLECTUAL PROPERTY RIGHTS" means any patent, copyright, rights in Trademarks, trade secret
rights, moral rights and other intellectual property or proprietary rights arising under the laws of
any jurisdiction.

"EXCLUSIVE CATEGORY" means those product and/or service categories identified on Exhibit A.

"SNAP BRAND FEATURES" means the Snap Marks and Snap's distinct brand elements that appear from time
to time in Snap's properties, ventures and services worldwide and are protected under U.S. copyright
law or for which Snap has established trademark, service mark or trade dress rights and any
modifications to the foregoing that may be created during the term of this Agreement.

CO-BRANDING AGREEMENT PAGE 1 SNAP CONFIDENTIAL

* Portions of this exhibit have been omitted and filed separately with the Commission pursuant to a
request for confidential treatment under Rule 406.

"SNAP CONTENT" means any information, materials or content developed by Snap for use on the Sponsor
Web Site.

"SNAP MARKS" means those Trademarks of Snap set forth on Exhibit B hereto and such other Trademarks
as Snap may from time to time notify Sponsor to be "Snap Marks" within the meaning of this
Agreement.

"SNAP WEB SITE" means that Web Site, the primary home page for which is located at URL
http://www.collegedge.com (and any successor or replacement thereof).

Source: EMBARK COM INC, S-1/A, 10/8/1999
<!-- page 2 -->
"SPONSOR CONTENT" means any information, materials or content supplied by or on behalf of Sponsor,
whether directly or indirectly, for use on the Co-Branded Pages.

"SPONSOR BRAND FEATURES" means the Sponsor Marks and Sponsor's distinct brand elements that appear
from time to time in Sponsor's properties, ventures and services worldwide and are protected under
U.S. copyright law or for which Sponsor has established trademark, service mark or trade dress
rights and any modifications to the foregoing that may be created during the term of this Agreement.

"SPONSOR MARKS" means those Trademarks of Sponsor set forth on Exhibit B hereto and such other
Trademarks (if any) as Sponsor may from time to time notify Snap in writing to be "Sponsor Marks"
within the meaning of this Agreement.

"SPONSOR WEB SITE" means that Web Site, the primary home page for which is located at URL
http://www.ual.com and any successor or replacement thereof.

"TERM" means the term of this Agreement as provided in Section 4.1 [TERM].

"TRADEMARKS" means any trademarks, service marks, trade dress, trade names, corporate names,
proprietary logos or indicia and other source or business identifiers.

"WEB SITE" means, with respect to any person or entity, all points of presence and/or services
maintained by such person or entity on the Internet (including, without limitation, the World Wide
Web) or on any successor public data network. With respect to any Web Site maintained on the World
Wide Web, such Web Site includes all HTML pages (or similar unit of information presented in any
relevant data protocol) that either (a) are identified by the same second-level domain (such as
.com) or by the same equivalent level identifier in any relevant address scheme, or (b) contain
branding, graphics, navigation or other characteristics such that a user reasonably would conclude
that the pages are part of an integrated information or service offering.

SECTION 2. CONTENT, CO-BRANDING AND LICENSES

2.1 CREATION OF CONTENT. Following the execution of this Agreement, Snap and Sponsor will work in
good faith to develop the content specified in Exhibit C. All content to be included on the
Co-Branded Pages shall be required to comply with Snap's generally applicable content and technical
guidelines.

2.2 CO-BRANDED PAGES. Following the execution of this Agreement, Snap and Sponsor will work in good
faith to develop the Co-Branded Pages which may include all or part of the

CO-BRANDING AGREEMENT PAGE 2 SNAP CONFIDENTIAL

* Portions of this exhibit have been omitted and filed separately with the Commission pursuant to a
request for confidential treatment under Rule 406.

Sponsor Content and/or the Snap Content. The Co-Branded Pages will have the specifications set forth
on Exhibit C. The Co-Branded Pages shall be required to comply with Snap's generally applicable
content and technical guidelines. Sponsor will supply Sponsor Content and Sponsor Brand Features as
agreed upon by the parties for inclusion in the Co-Branded Pages. Following the development thereof,
Snap shall use commercially reasonable efforts to post and maintain the Co-Branded Pages on the Snap
Web Site. Snap may from time to time, in consultation with Sponsor, update and modify the Co-Branded
Pages but may not change Sponsor content or Sponsor Brand Features, or do anything else with them,
without Sponsor's prior written consent.

2.3 LICENSES.

2.3.1 Subject to Section 2.4 [APPROVAL OF TRADEMARK USAGE], Sponsor hereby grants Snap a
non-exclusive, revocable nontransferable, royalty-free, worldwide license to: (a) use, reproduce,
publish, perform and display the Sponsor Marks and Sponsor Brand Features on the Co-Branded Pages;
(b) link to the Sponsor Web Site from the Co-Branded Pages and/or the Snap Web Site that contains
the Co-Branded Pages and (c) use, reproduce, publish, perform, and display the

Source: EMBARK COM INC, S-1/A, 10/8/1999
<!-- page 3 -->
Sponsor Content in and on the Co-Branded Pages. All goodwill arising out of Snap's use of any of the
Sponsor Marks shall inure solely to the benefit of Sponsor.

2.3.2 Subject to Section 2.4 [APPROVAL OF TRADEMARK USAGE], Snap hereby grants Sponsor a
non-exclusive, nontransferable, royalty-free, worldwide license to (a) use, reproduce, publish,
perform and display the Snap Marks and Snap Brand Features on the Sponsor Web Site in connection
with the logo link contemplated by Section 2.l, and in connection with its promotional and marketing
activities contemplated by Section 2.5 [PROMOTION OF SNAP SERVICES] and (b) use, reproduce, publish,
perform and display the Snap Content on the Sponsor Web Site or other Sponsor properties as mutually
agreed by the parties. All goodwill arising out of Sponsor's use of any of the Snap's Marks shall
inure solely to the benefit of Snap.

2.4 APPROVAL OF TRADEMARK USAGE. Snap shall not use or exploit in any manner any of the Sponsor
Marks or Sponsor Brand Features, and Sponsor shall not use or exploit in any manner any of the Snap
Marks or Snap Brand Features, except in such manner and media as may be specified in the other
party's trademark usage and branding guidelines or as the other party may consent to in writing.
Either party may revise such guidelines or revoke or modify any such consent upon written notice to
the other party.

2.5 PROMOTION OF SNAP SERVICES. Commencing upon the date of this Agreement and thereafter throughout
the Term Sponsor will use its commercially reasonable efforts (subject to the terms of this
Agreement) to generally promote and market Snap and the Snap Web Site. In addition, Sponsor will
perform those specific promotional and marketing services specified on Exhibit D.

2.6 EXCLUSIVE SPONSORSHIP. During the Term, Snap will not grant any third party any right to sponsor
any products or services in the Exclusive Category on or through the Snap Web Site. For the
avoidance of doubt, the parties acknowledge that the foregoing restriction applies only to
persistent sponsorship placement as judged by Sponsor at its discretion, and not to run-of-site
banner advertisements or other rotating promotional placements.

2.7 SNAP USER DATA. Snap will distribute marketing messages on behalf of Sponsor to Snap's end users
via electronic mail and other methods of communication as mutually agreed by the parties.
Furthermore, Snap will make available to Sponsor necessary end user data as reasonably

CO-BRANDING AGREEMENT PAGE 3 SNAP CONFIDENTIAL

* Portions of this exhibit have been omitted and filed separately with the Commission pursuant to a
request for confidential treatment under Rule 406.

appropriate for marketing purposes, including, without limitation, pre-populating end user data into
online frequent flier account applications. Sponsor acknowledges that all such end user data that is
generated by Snap is valuable proprietary information of Snap and Sponsor agrees that any use of
such end user data will limited solely to use for purposes of delivering superior travel values to
Snap end users and for no other purpose. Furthermore, Sponsor acknowledges that any use of Snap end
user data shall be limited to the extent allowed by and subject to Snap's agreement with such end
users; provided, however, that Snap represents and warrants that such agreements with its end users
will not increase Sponsor's duties or decrease its rights, nor reduce Snaps obligation to Sponsor
hereunder without Sponsor's prior written permission.

SECTION 3. COMPENSATION AND REPORTING

3.1 UP-FRONT PAYMENT. Upon execution of this Agreement, Sponsor will pay Snap the amounts set forth
on Exhibit A as the "Up-Front Fee" in consideration of Snap's development and integration of
travel-related content for use on the Co-Branded Pages and/or the Sponsor Web Site.

3.2 QUARTERLY FEE PAYMENTS. Sponsor will pay Snap the quarterly fees as set forth below on Exhibit A
hereto.

3.3 LAUNCH OF TRAVEL CO-BRANDED PAGES. After execution of this Agreement, the parties shall work
together cooperatively to determine a mutually agreeable timeline for the launch of the Co-Branded
Pages. If the parties determine that an adjustment to the timing of quarterly payments hereunder is

Source: EMBARK COM INC, S-1/A, 10/8/1999
<!-- page 4 -->
appropriate, the parties may amend the quarterly payment schedule set forth on Exhibit A hereto with
a written amendment signed by both parties.

SECTION 4. TERM AND TERMINATION

4.1 TERM. The Term shall commence on the date of this Agreement and, unless earlier terminated or
extended as provided below, shall end as of December 31, 2000.

4.2 TERMINATION. Either party may terminate the Term upon not less than sixty (60) days prior
written notice to the other party of any breach hereof by such other party. In addition, either
party may terminate the Term immediately upon written notice in the event that the other party shall
fail to do business in the normal course or become subject to any bankruptcy, assignment for
creditors, corporate dissolution or similar proceeding.

4.3 EFFECT OF TERMINATION. Upon termination or expiration of the Term for any reason, all rights and
obligations of the parties under this Agreement shall be extinguished, except that: (a) the rights
and obligations of the parties under Sections 5, 6, 7 and 8 of this Agreement, along with all
accrued payment obligations of Sponsor (i.e. the up-front payment referenced in Section 3.1
[UP-FRONT PAYMENT] and set forth in Exhibit A hereof), shall survive any termination or expiration
of the Term.

4.4 RIGHT OF FIRST REFUSAL. In the event of termination or expiration of this Agreement for other
than a material breach of this Agreement by Sponsor, upon notice from Sponsor delivered to Snap at
least forty-five (45) days prior to such expiration or termination, Snap shall negotiate in good
faith an agreement providing Sponsor with sponsorship rights similar to those described herein on
terms and conditions to be mutually agreed upon by the parties. In the event that an agreement

CO-BRANDING AGREEMENT PAGE 4 SNAP CONFIDENTIAL

* Portions of this exhibit have been omitted and filed separately with the Commission pursuant to a
request for confidential treatment under Rule 406.

between the parties is not executed within thirty (30) days following delivery, of such notice to
Snap, Snap shall be free thereafter to enter into an such an agreement with any third party.

SECTION 5. REPRESENTATIONS AND WARRANTIES; INDEMNITY

5.1 SNAP REPRESENTATIONS AND WARRANTIES. Snap represents and warrants to Sponsor that:

(a) it has full power and authority to enter into this Agreement;

(b) the execution, delivery and performance by Snap of this Agreement will not violate any law,
statute or other governmental regulation, and will not violate any other agreement or instrument to
which Snap is a party; and

(c) the use of the Snap Content will not violate or infringe any Intellectual Property Right or
other right of any third party.

5.2 SPONSOR REPRESENTATIONS AND WARRANTIES. Sponsor represents and warrants to Snap that:

(a) it has full power and authority to enter into this Agreement;

(b) neither the execution, delivery and performance by Sponsor of this Agreement, nor the
performance of ticketing services by Sponsor, in connection with the Co-Branded Pages, will violate
any law, statute or other governmental regulation or any other agreement or instrument to which
Sponsor is a party; and

(c) the use of the Sponsor Content will not violate or infringe any Intellectual Property Right or
other right of any third party.

SECTION 6. EXCLUSIONS; NO LIABILITY

Source: EMBARK COM INC, S-1/A, 10/8/1999
<!-- page 5 -->
6.1 WARRANTIES EXCLUDED. NEITHER PARTY MAKES ANY OTHER REPRESENTATIONS OR WARRANTIES OF ANY KIND,
EXPRESS OR IMPLIED, IN CONNECTION WITH THIS AGREEMENT OR THE TRANSACTIONS CONTEMPLATED HEREBY.
WITHOUT LIMITING THE GENERALITY OF THE FOREGOING: (A) SNAP MAKES NO REPRESENTATIONS OR WARRANTIES
WITH RESPECT TO THE SNAP WEB SITE, SNAP BRAND FEATURES OR ANY OTHER ITEMS OR SERVICES PROVIDED BY
SNAP, INCLUDING, WITHOUT LIMITATION, ANY IMPLIED WARRANTY ARISING BY USAGE OF TRADE, COURSE OF
DEALING OR COURSE OF PERFORMANCE, ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE AND ANY IMPLIED WARRANTY OF NON-INFRINGEMENT; (B) SPONSOR ACKNOWLEDGES THAT THE
SNAP WEB SITE (INCLUDING ANY SERVERS OR OTHER HARDWARE, SOFTWARE AND ANY OTHER ITEMS USED OR
PROVIDED BY SNAP IN CONNECTION WITH THE SNAP WEB SITE) AND SNAP BRAND FEATURES ARE PROVIDED "AS IS"
AND THAT SNAP MAKES NO WARRANTY THAT THE SNAP WEB SITE WILL BE FREE FROM BUGS, FAULTS, DEFECTS OR
ERRORS OR THAT ACCESS TO THE SNAP WEB SITE WILL BE UNINTERRUPTED; (C) SPONSOR MAKES NO
REPRESENTATIONS OR WARRANTIES WITH RESPECT TO THE SPONSOR WEB SITE,

CO-BRANDING AGREEMENT PAGE 5 SNAP CONFIDENTIAL

* Portions of this exhibit have been omitted and filed separately with the Commission pursuant to a
request for confidential treatment under Rule 406.

SPONSOR BRAND FEATURES OR ANY OTHER ITEMS OR SERVICES PROVIDED BY SPONSOR, INCLUDING, WITHOUT
LIMITATION, ANY IMPLIED WARRANTY ARISING BY USAGE OF TRADE, COURSE OF DEALING OR COURSE OF
PERFORMANCE, ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE AND ANY
IMPLIED WARRANTY OF NON-INFRINGEMENT; AND (D) SNAP ACKNOWLEDGES THAT THE SPONSOR WEB SITE (INCLUDING
ANY SERVERS OR OTHER HARDWARE, SOFTWARE AND ANY OTHER ITEMS USED OR PROVIDED BY SPONSOR IN
CONNECTION WITH THE SPONSOR WEB SITE) AND SPONSOR BRAND FEATURES ARE PROVIDED "AS IS" AND THAT
SPONSOR MAKES NO WARRANTY THAT THE SPONSOR WEB SITE WILL BE FREE FROM BUGS, FAULTS, DEFECTS OR
ERRORS OR THAT ACCESS TO THE SPONSOR WEB SITE WILL BE UNINTERRUPTED.

6.2 LIMITATION OF LIABILITY. NEITHER PARTY WILL HAVE ANY LIABILITY FOR, AND EACH PARTY HEREBY WAIVES
AND DISCLAIMS, ANY AND ALL CLAIMS AND CAUSES OF ACTION AGAINST THE OTHER PARTY, WHETHER IN CONTRACT,
TORT (INCLUDING, WITHOUT LIMITATION, NEGLIGENCE AND STRICT LIABILITY), WARRANTY OR OTHERWISE,
RELATING TO ANY INDIRECT, CONSEQUENTIAL OR EXEMPLARY DAMAGES, IN EACH CASE, ARISING OUT OF OR IN
CONNECTION WITH THIS AGREEMENT (INCLUDING ANY BREACH HEREOF) OR ANY OF THE TRANSACTIONS CONTEMPLATED
HEREBY.

SECTION 7. OWNERSHIP

7.1 SPONSOR. As between the parties, Sponsor retains all right, title and interest in and to the
Sponsor Web Site, the Sponsor Content and the Sponsor Marks and other Sponsor Brand Features, along
with all Intellectual Property Rights associated with any of the foregoing.

7.2 SNAP. As between the parties, Snap retains all right, title and interest in and to: (a) the Snap
Content, Snap Web Site (including, without limitation, any and all Snap Web Site content (other than
the Sponsor Content), Sponsor generated data, URLs, domain names, technology, hardware, software,
code, know-how, techniques, algorithms, processes, user interfaces, "look and feel", Trademarks and
any other items posted thereon or used in connection or associated therewith) and the Snap Marks and
other Snap Brand Features, along with all Intellectual Property Rights associated with any of the
foregoing.

7.3 OTHER TRADEMARKS. Snap shall not register or attempt to register any of the Sponsor Marks or any
Trademarks which Sponsor reasonably deems to be confusingly similar to any of the Sponsor Marks.
Sponsor shall not register or attempt to register any of the Snap Marks or any Trademarks which Snap
reasonably deems to be confusingly similar to any of the Snap Marks.

7.4 FURTHER ASSURANCES. Each party shall take, at the other party's expense, such action (including,
without limitation, execution of affidavits or other documents) as the other party may reasonably
request to effect, perfect or confirm such other party's ownership interests and other rights as set
forth above in this Section 7.

CO-BRANDING AGREEMENT PAGE 6 SNAP CONFIDENTIAL

Source: EMBARK COM INC, S-1/A, 10/8/1999

* Portions of this exhibit have been omitted and filed separately with the Commission pursuant to a
request for confidential treatment under Rule 406.
<!-- page 6 -->
SECTION 8. GENERAL PROVISIONS

8.1 CONFIDENTIALITY. During the Term, and for a period of five (5) years thereafter, the receiving
party will not disclose to others or use for any purpose of its own, other than in performance of
this Agreement, any Confidential Information of the other party. Each party shall take, at a
minimum, measures consistent with those taken to protect its own similar types of Confidential
Information (and in any event, at least reasonable measures) to protect the other's Confidential
Information against disclosures prohibited by this Agreement. Each party acknowledges that its
breach of the provisions of this Section 8.1 [CONFIDENTIALITY] will result in immediate and
irreparable harm to the other and that money damages alone would be inadequate to compensate such
party. Therefore, in the event of a breach of this Section 8.1 [CONFIDENTIALITY] by either party the
other party may, in addition to other remedies, immediately obtain and enforce injunctive relief
prohibiting the breach or threatened breach or compelling specific performance. Notwithstanding any
other provision of this Agreement, the restrictions set forth in this Section 8.1 [CONFIDENTIALITY]
shall not apply to any information that: (i) is in or enters the public domain through no fault of
the receiving party; (ii) is disclosed to the receiving party by a third party legally entitled to
make such disclosure; (iii) is independently developed by the receiving party without reference to
any Confidential Information of the other party; or (iv) is required to be disclosed by applicable
law, regulation or order of any governmental authority; provided, that in such event, the receiving
party shall provide the disclosing party with prior notice that is reasonable in the circumstances
of such disclosure and shall use reasonable efforts to cooperate with the disclosing party to
minimize the extent and scope of such disclosure.

8.2 INDEPENDENT CONTRACTORS. Sponsor and Snap are independent contractors under this Agreement, and
nothing herein shall be construed to create a partnership, joint venture, franchise or agency
relationship between Sponsor and Snap. Neither party has any authority to enter into agreements of
any kind on behalf of the other party.

8.3 ASSIGNMENT. Neither party may assign this Agreement or any of its rights or delegate any of its
duties under this Agreement without the prior written consent of the other party, not to be
unreasonably withheld; except that either party may, without the other party's consent, assign this
Agreement or any of its rights or delegate any of its duties under this Agreement: (a) to any
corporate affiliate of such party; or (b) to any purchaser of all or substantially all of such
party's assets or to any successor by way of merger, consolidation or similar transaction. Subject
to the foregoing, this Agreement will be binding upon, enforceable by, and inure to the benefit of
the parties and their respective successors and assigns.

8.4 CHOICE OF LAW; FORUM SELECTION. This Agreement shall be governed by, and construed in accordance
with, the laws of the State of California without reference to its choice of law rules. Sponsor
hereby irrevocably consents to personal jurisdiction and venue in the state and federal courts
located in San Francisco, California with respect to any actions, claims or proceedings arising out
of or in connection with this Agreement.

8.5 NONWAIVER. No waiver of any breach of any provision of this Agreement shall constitute a waiver
of any prior, concurrent or subsequent breach of the same or any other provisions hereof, and no
waiver shall be effective unless made in writing and signed by an authorized representative of the
waiving party.

CO-BRANDING AGREEMENT PAGE 7 SNAP CONFIDENTIAL

* Portions of this exhibit have been omitted and filed separately with the Commission pursuant to a
request for confidential treatment under Rule 406.

8.6 FORCE MAJEURE. Neither party shall be deemed to be in default of or to have breached any
provision of this Agreement as a result of any delay, failure in performance or interruption of
service, resulting directly or indirectly from acts of God, acts of civil or military authorities,
civil

Source: EMBARK COM INC, S-1/A, 10/8/1999
<!-- page 7 -->
disturbances, wars, strikes or other labor disputes, fires, transportation contingencies,
interruptions in telecommunications or Internet services or network provider services, other
catastrophes or any other occurrences which are beyond such party's reasonable control.

8.7 NOTICES. Any notice or other communication required or permitted to be given hereunder shall be
given in writing and delivered by first class U.S. mail, in person, or mailed via confirmed
facsimile or e-mail, or delivered by courier service, properly addressed and stamped with the
required postage, to the person signing this agreement on behalf of the applicable party at its
address specified above and shall be deemed effective upon receipt. Either party may from time to
time change the person to receive notices or its address by giving the other party notice of the
change in accordance with this section:

8.8 INTEGRATION. This Agreement contains the entire understanding of the parties hereto with respect
to the transactions and matters contemplated hereby, supersedes all previous agreements or
negotiations between Snap and Sponsor concerning the subject matter hereof, and cannot be amended
except by a writing signed by both parties. If any provision of this Agreement shall be adjudged by
any court of competent jurisdiction to be unenforceable or invalid, that provision shall be limited
or eliminated to the minimum extent necessary so that this Agreement shall otherwise remain in full
force and effect and enforceable.

IN WITNESS WHEREOF, the parties have duly executed and delivered this Agreement as of the date set
forth above.

SNAP: SPONSOR:

Snap Technologies United Airlines, Inc.

By: /s/ Howard Berman By: /s/ [*] ----------------------------------
-------------------------------------- Name: Howard Berman Name: [*]
-------------------------------- ------------------------------------ Title: Chief Operating Officer
Title: Director Electronic Distribution -------------------------------
----------------------------------- Date: June 8, 1999 Date: June 8, 1999
-------------------------------- ------------------------------------

CO-BRANDING AGREEMENT PAGE 8 SNAP CONFIDENTIAL

* Portions of this exhibit have been omitted and filed separately with the Commission pursuant to a
request for confidential treatment under Rule 406.

EXHIBIT A

PAYMENTS AND EXCLUSIVITY

1. The Exclusive Category is "PROVIDERS OF TRAVEL SERVICE".

2. The up-front payment called for by Section 3.1 will be [*].

3. Sponsor shall pay the following non-accrued obligation quarterly fees on or prior to the
following dates:

June 30, 1999 [*] September 30, 1999 [*] December 31, 1999 [*] March 31, 2000 [*] June 30, 2000 [*]
September 30, 2000 [*] December 31, 2000 [*]

CO-BRANDING AGREEMENT PAGE 9 SNAP CONFIDENTIAL

* Portions of this exhibit have been omitted and filed separately with the Commission pursuant to a
request for confidential treatment under Rule 406.

Source: EMBARK COM INC, S-1/A, 10/8/1999
<!-- page 8 -->
EXHIBIT B

TRADEMARKS

The following Trademarks of Sponsor as well as additional Trademarks of Sponsor added at a later
date related to the development of the United Student Travel Center are "Sponsor Marks" as that term
is used in this Agreement.

United Airlines logos (forthcoming)

CollegePlus logo (forthcoming)

The following Trademarks of Snap are "Snap Marks" as that term is used in this Agreement:

[LOGO]

CO-BRANDING AGREEMENT PAGE 10 SNAP CONFIDENTIAL

* Portions of this exhibit have been omitted and filed separately with the Commission pursuant to a
request for confidential treatment under Rule 406.

EXHIBIT C

SPECIFICATIONS OF CONTENT AND CO-BRANDED PAGES

SNAP CONTENT

The following content shall be developed by Snap (with input from Sponsor) and provided to Sponsor
for inclusion on the Sponsor Web Site:

- - Travel related content on the "Going to School" section of the Snap site for students seeking to
enter college, graduate school, professional schools or ESL programs. This content shall include but
not be limited to informational articles on how to pack for travel, frequent flyer programs, and
travel tips, etc. Content ideas or articles may be provided by Sponsor or by Snap. Snap will edit or
write these articles as necessary to fit the overall tone of the site.

- - As other areas of the Snap site are developed that may pertain to travel, Sponsor and Snap will
look to develop travel related content in a similar fashion as above.

- - Snap agrees to include Sponsor specials and e-fare related information in Snap's monthly
newsletter to Snap's registered users. The input will be provided by Sponsor but may be adjusted by
Snap to fit the overall tone of the newsletter. The Sponsor's input to the newsletter may include
buttons or links back to the Sponsor's booking engine or its E-Fares-Registered Trademark- so that
users may, for example, actually book tickets or sign-up for weekly E-Fare-Registered Trademark-
notifications.

SPONSOR CONTENT

The following content shall be developed by Sponsor (with input from Snap) and provided to Snap for
inclusion on the Co-Branded Pages:

- - The Sponsor shall develop a student travel site that will include a booking engine and
E-Fares-Registered Trademark- engine. Snap users may link to this site through the Snap store or
through any other relevant pages on the Snap site. Users who connect from the Snap site will be
linked to or from the Co-branded or Snap pages by a logo link containing the Snap Brand Features to
be supplied by Snap which links back to the Snap web site. This logo link will be placed in a
mutually acceptable "above the fold" location on the Sponsor site (based on a 640x450 pixels
screen).

- - Sponsor agrees that users who connect from the Snap site shall be at least one click away from
any page which mentions the CollegePlus or MileagePlus

Source: EMBARK COM INC, S-1/A, 10/8/1999
<!-- page 9 -->
First Card credit card.

- - Sponsor will work with Snap to develop content ideas and articles for the "Going to School" and
other areas on the Snap site as outlined above.

CO-BRANDING AGREEMENT PAGE 11 SNAP CONFIDENTIAL

* Portions of this exhibit have been omitted and filed separately with the Commission pursuant to a
request for confidential treatment under Rule 406.

EXHIBIT D

SPONSOR PROMOTIONAL ACTIVITIES

Sponsor and Snap shall work together to create mutually acceptable content for inclusion on the
"Going to School" section of the Snap Web Site.

On each page of the Sponsor Web Site linked to or from the Co-Branded Pages or containing any Snap
Content, Sponsor shall include, in a mutually acceptable "above-the-fold" location (based on a
640x480 pixels screen), a logo link containing the Snap Brand Features, to be supplied by Snap,
which links back to the Snap Web Site.

Sponsor shall make available to Snap [*] of advertising placements (based on Sponsor's standard
prices for the same or similar advertising) during each the calendar years 1999 and 2000 in
marketing vehicles owned or controlled by Sponsor as reasonably requested by Snap for the purpose of
marketing the Co-Branded Pages and the services provided on such pages. The parties acknowledge that
Snap has elected to use HEMISPHERES magazine as the initial marketing vehicle. Snap acknowledges
that marketing pieces included in Sponsor's marketing vehicles must be reasonably consistent with
the overall message delivered by such vehicle.

Sponsor shall develop a its new proprietary product category to be offered through the Co-Branded
Pages that shall represent a college-oriented electronic fare based on Sponsor's E-Fare-Registered
Trademark- product. It is the parties' expectations that the investment required of Sponsor to
deliver this new product category to the relationship described in this Agreement shall be
approximately [*].

Sponsor shall make available to Snap [*] worth of travel on Sponsor's airline ([*] in calendar 1999
and [*] in calendar 2000) to be given away by Snap through a sweepstakes process as a promotional
tool. Snap shall be free to elect to give away domestic or international travel in its sole election
and will be credited [*] per domestic roundtrip ticket given away and [*] per international
roundtrip ticket given away. In the event that the parties mutually determine that the sweepstakes
form of promotion is a valuable marketing tool, the parties may agree to make additional tickets
available to be given away.

CO-BRANDING AGREEMENT PAGE 12 SNAP CONFIDENTIAL

* Portions of this exhibit have been omitted and filed separately with the Commission pursuant to a
request for confidential treatment under Rule 406.

Source: EMBARK COM INC, S-1/A, 10/8/1999
