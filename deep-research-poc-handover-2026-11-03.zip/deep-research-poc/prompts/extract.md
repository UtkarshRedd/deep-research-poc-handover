You are extracting one fact from ONE document. Answer only from the text below; do not use outside
knowledge. The text shows the document's first lines and the passages most relevant to the question,
each line prefixed by its line number.

Question: {question}

Document {doc_id} — {title}
{text}

If the document contains the answer, copy the single most relevant sentence or clause EXACTLY as it
appears (verbatim, from one contiguous span of lines) and give its first and last line numbers.
If it does not, set found=false and leave quote empty. Never paraphrase inside `quote`.

Reply with ONLY a JSON object, no prose, no code fence:
{{"found": true, "answer": "short answer in your own words", "quote": "verbatim text", "start_line": 12, "end_line": 13}}
