<!-- page 1 -->
# NETWORK AFFILIATE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Affiliate Agreement |
| Agreement Date | 2011-03-14 |
| Parties | National CineMedia, LLC (“NCM”); Digital Cinema Destinations Corp.; “Network Affiliate” and with NCM, "Party" and collectively, the "Parties" |
| Source | CUAD v1 / DigitalCinemaDestinationsCorp_20111220_S-1_EX-10.10_7346719_EX-10.10_Affiliate Agreement |

DIGITAL CINEMA DESTINATIONS CORP. NETWORK AFFILIATE AGREEMENT THIS NETWORK AFFILIATE AGREEMENT (this
"Agreement") is made as of this 14th day of March, 2011 by and between National CineMedia, LLC, a
Delaware limited liability company ("NCM"), and Digital Cinema Destinations Corp., a Delaware
corporation ("Network Affiliate" and with NCM, each a "Party" and collectively, the "Parties").
BACKGROUND WHEREAS, NCM operates a "Digital Content Network" of proprietary and third-party hardware
and software pursuant to which the Service may be digitally transmitted to equipment and facilities
installed in, and displayed on movie screens, video display terminals and similar equipment located
in, movie theatres or other high traffic retail establishments, as further described herein;
WHEREAS, Network Affiliate owns and operates a theatre circuit with a patron base in excess of
400,000 patrons; and WHEREAS, both Network Affiliate and NCM want to expand NCM's advertising
"footprint" in the markets served by Network Affiliate; and WHEREAS, NCM and Network Affiliate want
to enter into a strategic alliance under which NCM will provide the Service to Network Affiliate,
and Network Affiliate will accept and display the Service in its theatres, all on the terms set
forth herein. NOW, THEREFORE, in consideration of the premises and mutual covenants in this
Agreement, and for other good and valuable consideration, the receipt and sufficiency of which are
hereby expressly acknowledged, and, intending to be legally bound hereby, the Parties agree as
follows: ARTICLE I DEFINITIONS The following terms shall have the following meanings: "Advertising
Revenue Share" has the meaning assigned to it in Section 7.1. "Advertising Services" means the
advertising and promotional services (including the Digital Content Service, the Digital Carousel,
the Traditional Content Program, Lobby Promotions and Event Sponsorships) as described in Part A of
Exhibit A. "Base Amount" has the meaning assigned to it in Section 7.2. "Beverage Agreement" means
that certain Beverage Agreement, Pepsi dated January 1, 2011. 1

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 2 -->
"Branded Slots" has the meaning assigned to it in Section 3.6(b). "Change of Control" has the
meaning assigned to it in Section 14.8. "Confidential Information" means any and all technical and
non-technical information of or related to either Party, including, without limitation, proprietary
information, know-how, the NCM Property and Derived Works, and information related to or regarding
either Party's research and development, finances, suppliers, customers, business forecasts, and
marketing plans, in whatever form disclosed or made available. Confidential Information does not
include information which: (i) the recipient can demonstrate was already known to it at the time of
its receipt hereunder; (ii) is or becomes generally available to the public other than by means of
the recipient's breach of its obligations under this Agreement; (iii) is independently obtained from
a third party whose disclosure violates no duty of confidentiality; or (iv) is independently
developed by or on behalf of the recipient without use of or reliance on any Confidential
Information furnished to it under this Agreement. "Costs" has the meaning assigned to it in Section
10.1. "Derived Works" has the meaning assigned to it in Section 12.2. "Digital Carousel" means a
loop of slide advertising with minimal branding and entertainment content which (i) is displayed
before the Pre-Feature Program in Digitized Theatres via the Digital Content Network and (ii) is
displayed before the Traditional Content Program in Non- Digitized Theatres via a non-digital slide
projector. "Digital Cinema Services" means services related to the digital playback and display of
feature films at a level of quality commensurate with that of 35 mm film release prints that include
high-resolution film scanners, digital image compression, high-speed data networking and storage,
and advanced digital projections. "Digital Content Network" means a network of Equipment and
third-party equipment and other facilities which provides for the electronic transmission of digital
content, directly or indirectly, from a centrally-controlled location to Theatres, resulting in the
"on-screen" exhibition of such content in such Theatres, either in Theatre auditoriums or on Lobby
Screens. "Digital Content Service" means the Pre-Feature Program, Policy Trailer and the Video
Display Program. "Digitized Theatres" means all Theatres that are connected to the Digital Content
Network as of the Effective Date and all Theatres that subsequently connect to the Digital Content
Network, as of the date such connection is established. "Dispositions" has the meaning assigned to
it in Section 2.6. "Effective Date" has the meaning assigned to it in Section 3.1. "Equipment" means
(a) the equipment and cabling which is necessary to schedule, distribute, play, reconcile and
otherwise transmit and receive transmission of the Digital Cinema Service, known as "small d
Equipment"; and (b) the equipment and cabling which is necessary to schedule, distribute, play,
reconcile and otherwise transmit and receive transmission of the Digital Cinema Service, known as
"Big D Equipment".

2

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 3 -->
"Excluded Theatres" has the meaning assigned to it in Section 3.10(a). "Exclusivity Exceptions" has
the meaning assigned to it in Section 6.1. "Flight" has the meaning assigned to it in Section
3.2(a). "IMAX Screens" has the meaning assigned to it in Section 3.10(b). "Infringement" has the
meaning assigned to it in Section 11.2. "Initial Term" has the meaning assigned to it in Section
8.1. "Inventory" means any advertising or other content. "Lobby Screen" means a plasma, LED or other
type of screen displaying digital or recorded content that is located inside a Theatre and outside
the auditoriums, or any other type of visual display mechanism that replaces such a screen. "Lobby
Promotions" has the meaning assigned to it in Part A of Exhibit A. "Marketing Materials" has the
meaning assigned to it in Section 5.3(a). "Minimum Fee" has the meaning assigned to it in Section
7.2. "NCM" has the meaning assigned to it in the preamble of this Agreement. "NCM Equipment" has the
meaning assigned to it in Section 2.3. "NCM Marks" means the trademarks, service marks, logos,
slogans and/or designs of NCM, each as identified on Exhibit C, in any and all forms, formats, and
styles. "NCM Property" has the meaning assigned to it in Section 12.1. "NCM Quality Standards" has
the meaning assigned to it in Section 5.3(a). "Net Revenue" has the meaning assigned to it in
Section 7.1(b). "Network Affiliate" has the meaning assigned to it in the preamble of this
Agreement. "Network Affiliate Marks" means the trademarks, service marks, logos, slogans and/or
designs of Network Affiliate, each as identified on Exhibit C, in and any and all forms, formats,
and styles, and including the Brand. "Network Affiliate Quality Standards" has the meaning assigned
to it in Section 5.4(c).

3

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 4 -->
"Non-Digitized Theatres" means Theatres that are not Digitized Theatres. "Party" or "Parties" has
the meaning assigned to it in the preamble of this Agreement. "Play List" has the meaning assigned
to it in Section 3.2(a). "Policy Trailer" has the meaning assigned to it in Section 3.6(a).
"Point-of-Sale Information" has the meaning assigned to it in Section 5.1. "Pre-Feature Program"
means a program of digital content of between twenty (20) and thirty (30) minutes in length which is
distributed by NCM through the Digital Content Network for exhibition in Digitized Theatres prior to
Showtime, or distributed non-digitally by some other means, including DVD, for exhibition prior to
Showtime in Non-Digitized Theatres. "Renewal Term" has the meaning assigned to it in Section 8.1.
"Representatives" has the meaning assigned to it in Section 10.1. "Service" means the Advertising
Services and the Video Display Program. "Showtime" means the advertised showtime for a feature film.
"Software" means the proprietary software owned and/or licensed by NCM or its affiliates and which
is installed on the Equipment and used in connection with delivery of the Service. "Term" has the
meaning assigned to it in Section 8.1. "Territory" means the United States of America, its
territories and possessions. "Theatre Advertising" means advertisement of one or more of the
following activities associated with operation of the Theatres: (A) Network Affiliate's gift cards,
loyalty programs and other items related to Network Affiliate's business in the Theatres (other than
film related) and (B) events presented by Network Affiliate. Additionally, Theatre Advertising shall
include advertising, marketing and promotion of a local radio station or stations (but with no
mentions or promotions of any third party) with which Network Affiliate has entered into a barter
transaction for advertising of one or more of the Theatres by the radio station(s) in exchange
solely for advertising the radio station or stations in one or more of the Theatres, entered into
for the purpose of generating increased attendance at the Theatres (the "Strategic Program"). Such
advertising for the Strategic Program may be placed in the Branded Slots, in Network Affiliate's
slides exhibited in the Digital Carousel and in that portion of the Video Display Program to which
Network Affiliate has access for advertising (but for no more than one minute of time for every 30
minutes of Video Display Program advertising). Strategic Programs may not be made on an exclusive
basis. No more than one Strategic Program may be run in any Theatre at any time.

4

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 5 -->
"Theatres" means the individual Network Affiliate theatres listed on Exhibit B, as such list may be
modified from time to time. "Traditional Content Program" means advertising and other promotional
content which is displayed on 35 mm film before Showtime. "Trailer" means a promotion secured by
Network Affiliate (which retains the exclusive rights to so secure for all of its Theatres) for a
feature film that is distributed by the distributor of the feature film for exhibition in the
Theatres after Showtime. "Video Display Program" means a program of digital content shown on Lobby
Screens which is distributed by NCM through the Digital Content Network for exhibition in Digitized
Theatres, and non-digitally by some other means, including DVD, for exhibition in Non-Digitized
Theatres. ARTICLE II EQUIPMENT Section 2.1 Equipment Purchase. (a) Traditional. For those theatres
listed on Exhibit B not equipped for Digital Content Service, NCM will promptly install a non-
digital slide projector in each auditorium necessary to exhibit the Traditional Content Program. (b)
small d. Not later than six (6) months after NCM shall first deliver the Service to the Theatres,
NCM will acquire the small d Equipment and shall install such Equipment in the Network Affiliate
Theatres indentified on Exhibit B, but NCM shall not be obligated to spend more than $9,000 per
screen. The cost of such small d Equipment shall be paid 100 percent (100%) by NCM. The type of
equipment and technology for such connectivity shall be at NCM's discretion. (c) Big D. Network
Affiliate, may at any time in its sole and absolute discretion, convert any of the Theatres so that
Digital Cinema Services can be provided, using technology commonly known Big D technology. Network
Affiliate shall purchase or lease and shall install such Big D Equipment in the Network Affiliate
Theatres. The cost of such Big D Equipment shall be paid 100 percent (100%) by Network Affiliate.
The type of equipment and technology for such connectivity shall be subject to NCM's approval which
shall not be unreasonably withheld, conditioned or delayed. Section 2.2 Operational Costs. All costs
associated with Network Affiliate's use of the Equipment, including the cost of electricity,
telephone lines and the like, will be borne exclusively by Network Affiliate. Section 2.3 Ownership
of small d Equipment. NCM will own the small d Equipment it has purchased pursuant to Section 2.1(b)
(the "NCM Equipment"). NCM shall depreciate the cost of the NCM Equipment on a calendar quarterly
basis, provided that the method used will result in full depreciation at the end of the five-year
period commencing on the Effective Date. Upon expiration or termination of the Agreement for any
reason, Network Affiliate shall pay NCM the value of the NCM Equipment, if any, that remains on
NCM's financial statements as of the time of such expiration or termination. Upon payment of such
amount to NCM by Network Affiliate at the time of such expiration or termination, NCM's ownership
interest in the NCM Equipment will transfer to Network Affiliate.

5

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 6 -->
Section 2.4 Ownership of Big D Equipment. Network Affiliate will own the Big D Equipment it has
purchased or leased pursuant to Section 2.1(c) (the "Network Affiliate Equipment") and NCM disclaims
any ownership interest, rights or liens in the Network Affiliate Equipment. Section 2.5
Installation. Except as otherwise provided herein, NCM and/or its subcontractors shall be solely
responsible for the installation of all Equipment purchased pursuant to Section 2.1(a) or 2.1(b),
and any Equipment necessary for connectivity under Section 2.1(c), as well as for ancillary services
such as software integration. The cost of such installation, including, without limitation, outside
labor costs and out- of-pocket costs (whether payable to outside labor or incurred by employees and
paid to third parties), shall be deemed capital investment costs and shall be paid for one hundred
percent (100%) by NCM. NCM shall use commercially reasonable efforts to install the Equipment in a
manner reasonably calculated not to disrupt Network Affiliate's operations, on such schedule as is
reasonably determined by NCM from time to time and reasonably agreed to in advance by Network
Affiliate. Network Affiliate shall be solely responsible for obtaining any consents required for the
installation or use of any Equipment at any Theatre, including without limitation, governmental and
landlord consents. Any relocation or repositioning of any Equipment installed in any Theatre shall
be performed only upon prior consultation with NCM. NCM and its subcontractors shall at all times be
provided reasonable access to the Theatres, as required to install the Equipment according to the
installation rollout schedule, and otherwise as reasonably necessary to perform its obligations
and/or enforce its rights under this Agreement. Network Affiliate shall use commercially reasonable
efforts to ensure that all Equipment delivered to any Theatre or otherwise in the possession,
custody or control of Network Affiliate is secure and not accessible by authorized third parties.
Section 2.6 Dispositions and Additions of Theatres. (a) Dispositions. Network Affiliate shall use
commercially reasonable efforts to provide NCM at least six (6) months advance written notice (or
such lesser time for notice as may be practicable based upon the date of execution of the agreement
for such disposition and the disposition date) of the sale or other disposition of a Theatre, the
loss of any Theatre lease, or its desire to permanently discontinue delivery of the Service to a
Theatre (collectively, a "Disposition"). Subject to the provisions of Section 2.3 with respect to
transfer of title to NCM Equipment, at least thirty (30) days prior to any Disposition, NCM shall be
permitted to enter the affected Theatre(s) and remove any NCM Property. Except in connection with a
Disposition, Network Affiliate shall not be permitted to permanently discontinue Service to any
Theatre without the prior written consent of NCM, which consent will not be unreasonably withheld,
conditioned or delayed. The costs of removal of NCM Equipment from any Theatre to which Service has
been permanently discontinued shall be borne by Network Affiliate.

6

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 7 -->
(b) Acquisitions. Any Network Affiliate theatre built or acquired following the Effective Date
shall, upon mutual agreement of the parties, become a Theatre, and the capital costs of equipping
all such new Theatres to receive the Service shall be as mutually agreed. Section 2.7 Training.
Network Affiliate agrees to permit NCM to provide training services to Network Affiliates' support
staff and customer service and other employees and agents. Network Affiliate shall cause its
employees to attend such training and to follow the instructions given by NCM in such training as
well as in follow-up instructions, guidelines and manuals of any kind provided to Network Affiliate
by NCM. ARTICLE III DELIVERY OF THE SERVICE Section 3.1 Transmission of the Service. On the
Effective Date (the date on which NCM first provides the Service to the Theatres) NCM shall provide
all aspects of the Service to Network Affiliate and Network Affiliate shall exhibit and otherwise
participate in such aspects of the Service, on the terms and conditions set forth herein. During the
Term, all Theatres will participate in the Service as either Digitized Theatres or Non-Digitized
Theatres. The Parties contemplate that the Effective Date will be on or about
__________________________. (a) Digitized Theatres. As of the Effective Date and during the Term,
pursuant to the terms of Section 3.2, NCM will provide the following Services to the Digitized
Theatres, and all Digitized Theatres will participate in (i) the Digital Carousel during the period
beginning after the preceding feature film (or, in the case of the first feature film of the day,
beginning after the opening of the auditorium doors for that film) until the beginning of the
Pre-Feature Program, (ii) the Pre-Feature Program, (iii) the Policy Trailer and (iv) the Video
Display Program. (b) Non-Digitized Theatres. As of the Effective Date and during the Term, pursuant
to the terms of Section 3.2, NCM will provide the following Services to the Non-Digitized Theatres,
and all Non-Digitized Theatres will participate in (i) the slide carousel during the period
beginning after the preceding feature film (or, in the case of the first feature film of the day,
beginning after the opening of the auditorium doors for that film) until the beginning of the
Traditional Content Program, (ii) the Traditional Content Program, (iii) the Policy Trailer and (iv)
the Video Display Program, but with respect to participation of Non-Digitized Theatre's
participation in the Video Display Program, only to the extent that a Non-Digitized Theatre has at
least one Lobby Screen and has the requisite equipment necessary to participate in the Video Display
Program. No Non-Digitized Theatre will be obligated to participate in, nor will NCM be obligated to
provide to any Non-Digitized Theatre, the Pre-Feature Program. (c) Lobby Promotions. NCM shall
provide Lobby Promotions to Theatres and Theatres shall participate in Lobby Promotions as described
in Section 3.3. (d) Conversion of Theatres. No Digitized Theatre shall become a Non-Digitized
Theatre without the mutual agreement of Network Affiliate and NCM.

7

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 8 -->
Section 3.2 Content and Distribution of the Digital Content Service and Traditional Content Program.
(a) Distribution. On the Effective Date, NCM will commence distribution of the Digital Carousel, the
Digital Content Service and the Traditional Content Program to the Digitized Theatres and
Non-Digitized Theatres, all as set forth above in Section 3.1. With respect to Digitized Theatres,
content shall be distributed through the Digital Content Network, via either NCM's satellite network
or by NCM's or Network Affiliate's landline network. Each of the Pre-Feature Program and the Video
Display Program shall consist of Inventory comprising a single play list ("Play List"). The Play
List will be refreshed during the Term when and as determined by NCM but not less frequently than 12
times per year (each a "Flight"). (b) Pre-Feature Program. As of the Effective Date, the Pre-Feature
Program shall consist of four (4) or more elements, including: (i) commercial advertising; (ii)
promotions for the Network Affiliate brand (including the Branded Slots), Concessions sold and
services used by Network Affiliate and other products and services in accordance with Section 3.6;
(iii) interstitial content; and (iv) other entertainment programming content which, while
promotional of businesses or products, shall be primarily entertaining, educational or informational
in nature, rather than commercially inspired. (c) Video Display Program. The elements of the Video
Display Program shall be, generally, the same as those for the Pre-Feature Program, and will include
the Branded Slots. NCM specifically agrees that the Video Display Program will contain only material
that has received, or had it been rated would have received, an MPAA "G" or "PG" rating. Lobby
Screens displaying the Video Display Program shall be located in areas of Theatres of NCM's choosing
(subject to Network Affiliate's reasonable consnent and operational constraints and provided
relocation of existing Lobby Screens is not required). Network Affiliate is obligated to provide a
location for at least one Lobby Screen per Digitized Theatre with ten or fewer screens, two Lobby
Screens per Digitized Theatre with eleven to twenty screens and three Lobby Screens per Digitized
Theatre with more than twenty screens; provided, however, that Network Affiliate shall have no
obligation to increase the number of Lobby Screens in any Theatre that has at least one Lobby Screen
that is capable of receiving the Video Display Program as of the Effective Date. Section 3.3
Delivery of Lobby Promotions. On the Effective Date, NCM will make available to the Theatres the
Lobby Promotions, and Network Affiliate will accept such Lobby Promotions on the terms and
conditions set forth herein. (i) The Inventory of Lobby Promotions for each Theatre that Network
Affiliate agrees to display pursuant to this Agreement is set forth in Exhibit A-1. NCM may provide
additional Lobby Promotions, subject to approval by Network Affiliate. NCM will take all other
actions necessary and prudent to ensure the delivery of Lobby Promotions as required under the terms
hereof. NCM will inform Network Affiliate of the length of time that Lobby Promotions and additional
Lobby Promotions, if any, are to be displayed.

8

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 9 -->
(ii) NCM covenants and agrees that Lobby Promotions provided pursuant to this Agreement will conform
to all standards and specifications of which Network Affiliate provides NCM reasonable notice during
the Term, including without limitation standards and specifications with respect to manufacturers
and suppliers, sizing (e.g., cup and popcorn tub sizing), timing of delivery of concession supplies
to Theatres, reimbursement of incremental costs (e.g., cups, floor mats, plates) and the like. Lobby
Promotions (i) will contain only material that has received, or had it been rated would have
received, an MPAA "G" or "PG" rating, (ii) that the only type of sampling that will be permitted is
exit sampling, (iii) to refrain from distributing chewing gum as part of any Lobby Promotion, other
than attended sampling as patrons are exiting the Theatre, (iv) not to permit a Lobby Promotion that
would distribute or sample any item that is the same as or substantially similar to any item sold at
the Theatre's concession stand and (v) not to permit a Lobby Promotion involving fund raising on
Theatre property. (iii) NCM will be responsible for all costs and expenses associated with sourcing,
production, delivery and execution of Lobby Promotions to the Theatres, including incremental costs
actually incurred by the Theatres in connection with Lobby Promotions. In its discretion, Network
Affiliate may make employees available to assist in Lobby Promotions requiring exit sampling;
provided that NCM shall reimburse Network Affiliate for the employees' time used to conduct the exit
sampling at their customary wage. Section 3.4 Content Standards. The Parties agree that (unless
mutually agreed by the Parties with respect to clauses (i), (iii), (iv), (v) or (vi)) all content
within the Service will not contain content or other material that: (i) has received, or had it been
rated would have received, an MPAA "X" or "NC-17" rating (or the equivalent), (ii) promotes illegal
activity, (iii) promotes the use of tobacco, sexual aids, birth control, firearms, weapons or
similar products; (iv) promotes alcohol, except prior to "R"-rated films in the auditorium; (v)
constitutes religious advertising (except on a local basis, exhibiting time and location for local
church services); (vi) constitutes political advertising or promotes gambling; (vii) promotes
theatres, theatre circuits or other entities that are competitive with Network Affiliate's theatre
operating business or NCM; or (viii) otherwise reflects negatively on Network Affiliate or adversely
affects Network Affiliate's attendance as determined in Network Affiliate's reasonable discretion.
Additionally, the service will not contain any material that depicts or advertises products
competitive to the Beverage Agreement (except as an incidental product placement in content not
created by NCM). Network Affiliate may, without liability, breach or otherwise, prevent and/or take
any other actions with respect to the use or distribution of content that violates the foregoing
standards; provided, that with respect to this Section 3.4(viii), Network Affiliate may opt out of
such advertising only with respect to Theatres in the geographic locations identified, which may
include all of Network Affiliate's Theatres. If the Digital Content Service contains any content
that violates the foregoing standards, NCM will use commercially reasonable efforts to remove such
content as soon as reasonably practical. If NCM fails to remove such content within a reasonable
time, Network Affiliate may discontinue the Digital Content Service in such auditoriums where such
content is shown until the violating content is removed and shall have no liability for such
discontinuation. If any other elements of the Service contain any content that violates the
foregoing standards, NCM shall at Network Affiliate's request, or Network Affiliate acting on its
own behalf may, upon giving written notice to NCM, remove such content immediately.

9

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 10 -->
Section 3.5 Development of the Program. All operational costs associated with NCM's procurement,
preparation and delivery of the Service (including Inventory and other promotional materials as
provided herein) to the Theatres shall be borne exclusively by NCM. Except as provided herein, all
in-Theatre operational costs associated with Network Affiliate's receipt and exhibition of the
Service within the Theatres shall be borne exclusively by Network Affiliate. NCM will provide at its
own expense all creative and post-production services necessary to ingest, encode and otherwise
prepare for distribution all other on-screen Inventory as part of the Digital Content Service. All
on-screen Inventory provided by Network Affiliate for inclusion in the Digital Content Service must
(i) be submitted to NCM for review for compliance with (ii) and (iii) below as NCM may reasonably
request, but in any event at least twenty (20) business days before scheduled exhibition (unless
otherwise previously approved by NCM), (ii) satisfy the content restrictions enumerated in Section
3.4, and (iii) be fully produced in accordance with NCM's technical specifications as promulgated by
NCM from time to time (all as provided in written or electronic form to Network Affiliate), ready
for exhibition, as well as in accordance with applicable NCM commercial standards and operating
policies, and all applicable federal, state and local laws and regulations. Any Inventory provided
by Network Affiliate for review and approval by NCM need not, once approved by NCM, be resubmitted
by Network Affiliate for approval in connection with any future use. Section 3.6 Policy Trailer;
Branded Slots. (a) Policy Trailer. The policy trailer will be (i) up to 60 seconds, (ii) exhibited
in the Theatres after Showtime, (iii) be customized to include the name of the Network Affiliates
Theatre business and (iii) used to feature content relating to Theatre policy and operations, and
may include (w) a policy service announcement that promotes appropriate theatre behavior, (x)
promotions of Network Affiliate Concessions, (y) upon prior written approval of Network Affiliate,
other promotional materials of third-party products for which NCM sells advertising and is paid a
fee (the "Policy Trailer"). All costs associated with producing the Policy Trailer shall be borne by
Network Affiliate. (b) Branded Slot. The Digital Content Service will feature (i) up to two (2)
minutes for Theatre Advertising (the "Branded Slots") in each Play List. Each Branded Slot may only
exhibit Theatre Advertising. NCM is required to include no less than forty-five (45) seconds of
Branded Slots within the final fifteen (15) minutes of the Play List, fifteen (15) seconds of which
shall be included within the final eleven (11) minutes of the Play List; provided, that NCM may
begin these Branded Slots up to one minute earlier when NCM expands the amount of advertising units
that follow these Branded Slots through the sale of additional advertising to third parties. (c)
Restrictions. Other than as permitted in Sections 3.6(a) or (b), neither the Policy Trailer nor the
Branded Slot will not include third-party advertising and/or third-party mentions for products and
services, without NCM's prior written approval. Section 3.7 Cooperation and Assistance. The Parties
agree that the effectiveness and quality of the Service as provided by NCM are dependent on the
cooperation and operational support of both Parties. (a) Network Affiliate agrees that it (and each
of the Theatres) shall at all times during the Term provide NCM, at Network Affiliate's own cost
except as otherwise provided in this Agreement, with the following:

10

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 11 -->
(i) internal resources and permissions as reasonably required to effectuate delivery of the Service,
including without limitation projection and sound technicians and other employees to assist with NCM
Equipment installation and Digital Content Service transmission; (ii) unless unavailable, 24 (hour)
by 7 (day) "real time" access via Network Affiliate's network assets in conformity with Network
Affiliate's network use and security policies (provided in advance to NCM and consistently applied
with respect to other Network Affiliate service providers) to the in-Theatre software and hardware
components of the Digital Content Network, so that NCM can monitor the distribution and playback of
the Service and the Parties will reasonably cooperate to ensure that corrections or changes are made
as required to deliver the Service; (iii) detailed playback information in a form, whether
electronic or hard copy, and at such times as either Network Affiliate or NCM shall reasonably
request; (iv) prompt notification of reception, playback or other technical problems associated with
receipt of the Service; (v) the results of quality audits performed by Network Affiliate
periodically during the Term upon NCM's request and at its direction to confirm playback compliance;
(vi) adequate opportunities to train Network Affiliate personnel, as provided in Section 2.7; (vii)
attendance data film-by-film, rating-by-rating and Theatre-by-Theatre for all Theatres, in an
electronic form and in a format agreed by the Parties, at such times as are consistent with Network
Affiliate's internal reporting systems but in any event at least weekly; (viii) at such times as NCM
shall reasonably request but no more often than on a quarterly basis, a list of all Theatres,
including (i) identification of which Theatres are Digitized Theatres, (ii) the number of screens at
each Theatre, and (iii) identification of any Theatres that are not equipped with at least one Lobby
Screen to display the Video Display Program; and (ix) such other information regarding the Services
as NCM may reasonably request from time to time; (b) For the avoidance of doubt, information made
available subject to this Section 3.7 shall be subject to the provisions of Section 13.1
(Confidential Treatment). Network Affiliate agrees to be included in any compliance reporting NCM
provides to its advertisers and other content providers for proof of performance. (c) NCM and
Network Affiliate shall use commercially reasonable efforts to ensure that the Digital Content
Network will be integrated with any network for the delivery of Digital Cinema Services such that
the Services can be delivered over such network.

11

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 12 -->
Section 3.8 Trailers. Trailers that are exhibited in the Theatres shall not include the exhibition
or display of any trademark, service mark, logo or other branding of a party other than the film
studio(s), distributor(s), production company(ies); provided, however, Trailers may include
incidental images of products or services which appear in the motion picture (e.g., product
placements). Section 3.9 Customer Access to Pre-Feature Program. Network Affiliate shall use its
reasonable efforts to provide audiences access to the Theatre auditorium for the Pre-Feature Program
or Traditional Content Program, as applicable. Section 3.10 Excluded Theatres; IMAX Screens. (a)
Excluded Theatres. Network Affiliate shall have the right to designate art house and draft house
theatres that for purposes of this Agreement shall be "Excluded Theatres". The list of Excluded
Theatres identified as of the Effective Date is set forth on Exhibit D. Network Affiliate shall
provide written or electronic notice to NCM, in the form specified by NCM, each time there is a
change in its list of Excluded Theatres. Excluded Theatres shall not be deemed Theatres for purposes
of this Agreement. Excluded Theatres will not receive Advertising Services. Excluded Theatres will
not be considered for purposes of the calculation of Advertising Revenue Share. Notwithstanding the
foregoing, Excluded Theatres will be subject to the exclusivity obligations of Network Affiliate, as
set forth in Section 6.1, to the same extent as a Theatre hereunder. With respect to any Theatre
subsequently designated as an Excluded Theatre, the parties will negotiate in good faith terms for
the discontinuation of delivery of the Service to such Excluded Theatre. (b) IMAX Screens. All
Theatre screens dedicated to the exhibition of films using "IMAX" technology shall be deemed "IMAX
Screens." IMAX Screens will not receive, and Network Affiliate will have no duty to exhibit on any
IMAX Screen, the Digital Carousel, the Pre- Feature Program or the Traditional Content Program;
provided however, that Network Affiliate may elect to exhibit the Digital Carousel, the Pre- Feature
Program or the Traditional Content Program on its IMAX Screens in its sole discretion.
Notwithstanding the foregoing, all IMAX Screens will be subject to the exclusivity obligations of
Network Affiliate, as set forth in Section 6.1 to the same extent as a Theatre hereunder. Network
Affiliate will provide NCM prompt written notice of any additions to or deletions from its list of
IMAX Screens, which list appears on Exhibit D. Network Affiliate shall provide written or electronic
notice to NCM, in the form specified by NCM, each time there is a change in its list of IMAX
Screens. Section 3.11 Grand Openings; Employee Uniforms. Notwithstanding anything herein to the
contrary, Network Affiliate shall not be prohibited from: (i) promoting the grand opening of a
Theatre or an Excluded Theatre, provided such promotional activity (x) may occur only for the thirty
(30) day period immediately preceding the opening of the theatre to the general public through the
thirty (30) day period immediately following the opening of the theatre to the general public, and
(y) includes local advertising of such opening in exchange for the advertising of local businesses
only, provided any on-screen advertising related thereto shall be subject to availability of
on-screen Inventory and limited to one (1) advertisement thirty (30) seconds in length; and (ii)
allowing advertising for the supplier of Network Affiliate employee uniforms to appear on such
uniforms, provided that not more than two individual instances of such advertising ,may appear on
any such uniform at any one time.

12

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 13 -->
Section 3.12 License. NCM hereby grants to Network Affiliate at no cost a limited, non-exclusive,
non-transferable, non-sublicenseable, royalty-free license in the Territory during the Term only to
receive, store, convert or otherwise manage, display and exhibit the Service on the Equipment at
Theatres solely in connection with its performance of and subject to all of the terms and conditions
of this Agreement. Network Affiliate may not materially alter the Service or otherwise exhibit the
Service in a manner resulting in a material change in an average viewer's perception of the Service
or any Service content, nor may Network Affiliate use or make the Service available for any purpose,
at any location, or in any manner not specifically authorized by this Agreement, including without
limitation recording, copying or duplicating the Service or any portion thereof. Network Affiliate
shall at all times use the NCM Equipment and the Service in accordance with such policies and
procedures of NCM as NCM may reasonably impose from time to time. Each party shall be solely
responsible for obtaining and providing all rights, licenses, clearances and consents necessary for
the use of any content it provides, or that is prepared or provided on its behalf, as contemplated
herein, except as may otherwise be agreed by the parties in writing; provided, however, that,
notwithstanding anything herein that might be construed to the contrary, NCM shall not be obligated
to provide any right, license, clearance or consent necessary to permit the public exhibition of
music in the Theatres (except with respect to background music provided by NCM or its affiliates).
ARTICLE IV MAINTENANCE AND SUPPORT; MAKE GOODS Section 4.1 Maintenance Obligation. (a) At any time
that NCM Equipment is installed in any Theatre, Network Affiliate shall use its reasonable efforts
to ensure there is no loss or damage to such NCM Equipment as a result of the standard or
foreseeable operations of the Theatres, and to prevent piracy or other theft of inventory exhibited
through the use of the NCM Equipment or otherwise in its possession or control. Network Affiliate
further agrees to keep all NCM Equipment, including without limitation video display terminals,
clean, and to promptly notify NCM if any NCM Equipment is not functioning properly. For any NCM
Equipment located in Theatres or otherwise in Network Affiliate's possession or control, Network
Affiliate shall be responsible for any loss, theft or damage of or to NCM Equipment to the extent
attributable to the negligence or wrongdoing of Network Affiliate. (b) Subject to the foregoing, NCM
and/or its subcontractors shall keep and maintain Equipment installed in the Theatres in good
condition and repair. Network Affiliate shall provide NCM and/or its subcontractor's access to the
Equipment and such other support services as NCM and/or its subcontractors reasonably require to
provide, or have provided, installation, maintenance and repair services as required hereunder.
Network Affiliate further agrees to require Theatre operations personnel to perform, at NCM's
direction, reasonable basic daily verification of on-screen performance (including written
confirmation of on-screen image and audio clarity). More detailed quality audits may be performed by
NCM personnel. NCM will provide Network Affiliate copies of all audit report reconciliations.

13

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 14 -->
Section 4.2 Software Support. Provided that Network Affiliate is not in breach of this Agreement,
NCM shall make available to Network Affiliate at no cost pursuant to the terms of the license in
Section 5.1 below all Software updates and upgrades to the extent such updates and upgrades have
been or are being made generally commercially available by NCM. Unless otherwise agreed to in
writing by NCM, Network Affiliate shall not permit any third party to perform or provide any
maintenance or support services with respect to the Digital Content Network or the Software. Section
4.3 Service Level Agreement. Network Affiliate agrees to take all actions during the Term that are
within its control and reasonably necessary to permit delivery of the Service to the Theatres as
contemplated by this Agreement. Section 4.4 Make Goods. In the event either Party fails to satisfy
its obligation or other agreement to provide Inventory, the Inventory provided by either Party
deviates from the standards imposed under this Agreement, or Inventory is not transmitted or
exhibited as part of the Service due to the inadvertence, negligence or fault of either Party (as
may result, for example, from the failure by either party to supply or maintain equipment or other
technology necessary for transmission of the Service as required hereunder), then the Party not at
fault may, as its sole and exclusive remedy therefor, require that the other Party, at its sole
expense, deliver "make goods" sufficient to achieve the level of Inventory content impressions which
would have occurred but for the inadvertence, negligence or fault of the other Party. The parties
agree that this exclusive remedy is essential to the smooth operation of the Service and the
consistent performance of the parties under this Agreement. The type and placement of make goods
shall be as mutually agreed, it being the intent of the parties that the value of the make goods
shall be substantially the same as that which the party not at fault would have ordinarily received
under this Agreement. All make goods shall be provided in the Theatre in which the corresponding
Inventory would have been exhibited. ARTICLE V INTELLECTUAL PROPERTY Section 5.1 Software License.
Subject to the terms and conditions of this Agreement, NCM hereby grants to Network Affiliate, and
Network Affiliate hereby accepts, a non-exclusive, non-transferable, non-sublicenseable,
royalty-free limited license to the object code version of the Software on Equipment at Theatres
solely for the limited purpose of performing this Agreement. The parties agree that, as part of the
set-up services NCM will establish one or more connections between the Software and Network
Affiliate's point-of-sale software and such other software of Network Affiliate as is required to
deliver the Service. The parties agree that NCM will have "real-time" access through the connections
to Network Affiliate's point-of-sale software to Network Affiliate's ratings, show-time, and
attendance information, as shall be mutually determined by the parties (the "Point-of-Sale
Information"). The Point-of-Sale Information shall be deemed the Confidential Information of Network
Affiliate for all purposes of this Agreement. The parties will cooperate to ensure that NCM does not
receive access through Network Affiliate's point-of- sale software to any information of Network
Affiliate other than the Point-of-Sale Information.

14

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 15 -->
Section 5.2 Software Restrictions. Network Affiliate acknowledges that the Software and any and all
components thereof constitute valuable trade secrets of NCM or its affiliates or licensors.
Accordingly, except as may be expressly permitted under this Agreement, Network Affiliate shall not,
nor shall it permit, cause, or authorize any other person or entity to: (a) Use the Software for any
purpose, at any location, or otherwise access the Software in any manner not specifically authorized
by this Agreement; (b) Make or retain any copy of the Software, except as specifically authorized by
this Agreement; (c) Re-engineer, reverse engineer, decompile, or disassemble the Software or create
or recreate the source code for the Software; (d) Modify, adapt, translate, or create derivative
works based upon the Software, or combine or merge any part of the Software with or into any other
software or documentation; (e) Refer to or otherwise use the Software as part of any effort to
develop a program having any functional attributes, visual expression, or other features similar to
those of the Software or to compete with NCM or its affiliates; (f) Remove, erase, or tamper with
any copyright or other proprietary notice printed or stamped on, affixed to, or encoded or recorded
in the Software, or fail to preserve all copyright and other proprietary notices in any copy of the
Software made by Network Affiliate to the extent copying is permitted by this Agreement; (g) Sell,
market, license, sublicense, distribute, or otherwise grant to any person or entity any right to use
the Software or Documentation; (h) Use the Software to conduct any type of service bureau or
time-sharing operation or to provide remote processing, network processing, network
telecommunications, or similar services to any person or entity, whether on a fee basis or
otherwise; or (i) Attempt to do any of the foregoing. Section 5.3 License of the NCM Marks. (a)
Subject to the terms and conditions of this Agreement and such other standards, trademark usage
guidelines and specifications as are prescribed by NCM during the term of this Agreement (the "NCM
Quality Standards"), NCM hereby grants to Network Affiliate, and Network Affiliate hereby accepts, a
non-exclusive, non-transferable (except in connection with an assignment of this Agreement in
accordance with Section 14.8 hereof), non-sublicenseable, limited license (i) to use the NCM Marks
solely in connection with its receipt and exhibition of the Service, as approved by NCM in writing
in advance, and (ii) to use the NCM Marks in marketing or advertising materials ("Marketing
Materials") that have been approved by NCM pursuant to the terms hereof. Network Affiliate
acknowledges that NCM is and shall remain the sole owner of the NCM Marks, including the goodwill of
the business symbolized thereby. Network Affiliate recognizes the value of the goodwill associated
with the NCM Marks and acknowledges and agrees that any goodwill arising out of the use of the NCM
Marks or any of them by Network Affiliate shall inure to the sole benefit of NCM for all purposes
hereof.

15

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 16 -->
(b) Prior to using any Marketing Materials or depicting or presenting any NCM Mark in or on any
Marketing Materials or otherwise, Network Affiliate shall submit a sample of such Marketing
Materials or other material to NCM for approval. NCM shall exercise commercially reasonable efforts
to approve or reject any such Marketing Materials or other material submitted to it for review
within thirty (30) days from the date of receipt by NCM. Network Affiliate shall not use, publish,
or distribute any Marketing Materials or other material unless and until NCM has approved it in
writing. Upon receipt of such approval from NCM for a particular Marketing Materials or other
material, Network Affiliate shall not be obligated to submit to NCM substantially similar material
for approval; provided, however, Network Affiliate shall timely furnish samples of all such material
to NCM. For the avoidance of doubt, nothing in this Subsection 5.3(b) shall limit or affect Network
Affiliate's obligations set forth in any other subsection of this Section 5.3 or any other provision
of this Agreement. (c) Any and all use or exercise of rights by Network Affiliate with respect to
the NCM Marks shall be subject to and in accordance with the NCM Quality Standards, and, without
limiting such standards, subject to and in accordance with standards of quality and specifications
that conform to or exceed the highest quality standards and specifications achieved by NCM and its
licensees in their use and exercise of rights with respect to the NCM Marks. NCM shall have the
right to change the NCM Quality Standards from time to time upon notice to Network Affiliate. (d)
Network Affiliate shall cause the appropriate designation "(TM)" or "(SM)" or the registration
symbol "(R)" to be placed adjacent to the NCM Marks in connection with the use thereof and to
indicate such additional or alternative information as NCM shall specify from time to time
concerning the use by Network Affiliate of the NCM Marks. (e) Network Affiliate shall not use any
NCM Mark in any manner that may reflect adversely on the image or quality symbolized by the NCM
Mark, or that may be detrimental to or tarnish the image or reputation of NCM. Notwithstanding
anything herein to the contrary, NCM shall have the right, at its sole option, to terminate or
suspend the trademark license grant provided herein if NCM, in its sole discretion, determines that
Network Affiliate's use of the NCM Marks or any of them is in violation of the terms of this
Agreement or of the NCM Quality Standards, or is otherwise disparaging to NCM's image or reputation,
and such use is not conformed to the terms of this Agreement of the NCM Quality Standards within ten
(10) days of receipt of written notice thereof. NCM's obligation to provide any Services dependant
upon the use of the NCM Marks will be suspended during the period of any such suspension or
termination, and NCM will have no liability for any failure to perform such Services during such
time period. (f) Network Affiliate agrees not to use or adopt (i) any trademark or service mark
which is confusingly similar to, or a colorable imitation of, any NCM Mark or any part thereof, (ii)
any trademark or service mark in combination with any NCM Mark, or (iii) any NCM Mark in connection
with or for the benefit of any product or service of any other person or entity. Network Affiliate
shall not engage in any conduct which may place NCM or any NCM Mark in a negative light or context,
and shall not represent that it owns or has any interest in any NCM Mark other than as expressly
granted herein, nor shall it contest or assist others in contesting the title or any rights of NCM
(or any other owner) in and to any NCM Mark.

16

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 17 -->
Section 5.4 License of the Network Affiliate Marks. (a) Subject to the terms and conditions of this
Agreement, Network Affiliate hereby grants to NCM, and NCM hereby accepts, a non-exclusive,
non-transferable (except in connection with an assignment of this Agreement in accordance with
Section 14.8 hereof), non- sublicenseable, limited license (i) to use the Network Affiliate Marks
solely in connection with its delivery of the Service, as approved by Network Affiliate in writing
in advance, and (ii) to use the Network Affiliate Marks in Marketing Materials that have been
approved by Network Affiliate pursuant to the terms hereof. NCM acknowledges that Network Affiliate
is and shall remain the sole owner of the Network Affiliate Marks, including the goodwill of the
business symbolized thereby. NCM recognizes the value of the goodwill associated with the Network
Affiliate Marks and acknowledges and agrees that any goodwill arising out of the use of the Network
Affiliate Marks by NCM shall inure to the sole benefit of Network Affiliate for all purposes hereof.
(b) Prior to using any Marketing Material or depicting or presenting any Network Affiliate Mark in
or on any marketing or advertising material or otherwise, NCM shall submit a sample of such
Marketing Material or other material to Network Affiliate for approval. Network Affiliate shall
exercise commercially reasonable efforts to approve or reject any such Marketing Material or other
material submitted to it for review within thirty (30) days from the date of receipt by Network
Affiliate. NCM shall not use, publish, or distribute any Marketing Material or other material unless
and until Network Affiliate has approved it in writing. Upon receipt of such approval from Network
Affiliate for a particular Marketing Material or other material, NCM shall not be obligated to
submit to Network Affiliate substantially similar material for approval; provided, however, NCM
shall timely furnish samples of all such material to Network Affiliate. For the avoidance of doubt,
nothing in this Subsection 5.4(b) shall limit or affect NCM's obligations set forth in any other
subsection of this Section 5.4 or any other provision of this Agreement. (c) Any and all use or
exercise of rights by NCM with respect to the Network Affiliate Marks shall be in accordance with
standards of quality and specifications that conform to or exceed the highest quality standards and
specifications achieved by Network Affiliate and its licensees in their use and exercise of rights
with respect to the Network Affiliate Marks, as well as, without limiting the foregoing, such other
standards, trademark usage guidelines, and specifications as are prescribed by Network Affiliate
(the "Network Affiliate Quality Standards"). Network Affiliate shall have the right to change the
Network Affiliate Quality Standards from time to time upon notice to NCM. (d) NCM shall cause the
appropriate designation "(TM)" or "(SM)" or the registration symbol "(R)" to be placed adjacent to
the Network Affiliate Marks in connection with the use thereof and to indicate such additional or
alternative information as Network Affiliate shall specify from time to time concerning the use by
NCM of the Network Affiliate Marks.

17

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 18 -->
(e) NCM shall not use any Network Affiliate Mark in any manner that may reflect adversely on the
image or quality symbolized by the Network Affiliate Mark, or that may be detrimental to the image
or reputation of Network Affiliate. Notwithstanding anything herein to the contrary, Network
Affiliate shall have the right, at its sole option, to terminate or suspend the trademark license
grant provided herein if it determines that NCM's use of the Network Affiliate Marks or any of them
is in violation of its trademark usage guidelines or is otherwise disparaging to its image or
reputation, and such use is not conformed to such guidelines and other reasonable requests of
Network Affiliate within ten (10) days of receipt of written notice thereof. NCM's obligation to
provide any Services dependant upon the use of the Network Affiliate Mark will be suspended during
the period of any such suspension or termination, and NCM will have no liability for any failure to
perform such Services during such time period. (f) NCM agrees not to use (i) any trademark or
service mark which is confusingly similar to, or a colorable imitation of, any Network Affiliate
Mark or any part thereof, (ii) any trademark or service mark in combination with any Network
Affiliate Mark, or (iii) any Network Affiliate Mark in connection with or for the benefit of any
product or service of any other person or entity. NCM shall not engage in any conduct which may
place Network Affiliate or any Network Affiliate Mark in a negative light or context, and shall not
represent that it owns or has any interest in any Network Affiliate Mark other than as expressly
granted herein, nor shall it contest or assist others in contesting the title or any rights of
Network Affiliate (or any other owner) in and to any Network Affiliate Mark. ARTICLE VI MANDATORY
PARTICIPATION AND EXCLUSIVITY Section 6.1 Mandatory Participation and Exclusivity. During the Term,
except as expressly provided in this Agreement, including Section 3.6 (Policy Trailer; Branded
Slots); those provisions of Part A of Exhibit A that permit Network Affiliate to engage in certain
Lobby Promotions; Section 3.11 (Grand Openings, Employee Uniforms), collectively, the "Exclusivity
Exceptions", Network Affiliate shall subscribe for and NCM shall be the exclusive provider to the
theatres of the services specifically set forth in the definition of the "Service." Except as
permitted by the Exclusivity Exceptions, during the Term, Network Affiliate shall neither engage nor
permit a third party (excluding third party designees of NCM as provided hereunder) to provide, or
itself provide, to any of Network Affiliate's theatres any of the services specifically set forth in
the definition of Service. Subject only to the Exclusivity Exceptions, NCM shall be Network
Affiliate's exclusive representative with respect to the procurement of Inventory (including without
limitation all on-screen advertising) for the Advertising Services. NCM shall be responsible, at its
own expense, for the coordination and administration of Inventory placement, whether nationally,
regionally or locally, including without limitation the acceptance of insertion orders, invoicing
advertisers and other content providers, and the acceptance and collection of payments therefrom.
Any Inventory which has not been sold as of the date for its scheduled exhibition shall be allocated
to make goods, remnant advertising, and other revenue- generating advertising. Nothing in this
Agreement shall limit or affect (i) NCM's ability to contract or enter into any relationship with
any Person or entity for any product, service, or otherwise, whether or not similar to any products
or services provided by NCM under this Agreement, or (ii) Network Affiliate's ability to contract or
enter into any relationship with any Person or entity for any product, service, or otherwise, other
than the services that will be provided exclusively by NCM as set forth in this Section 6.1 and
meetings promoted and scheduled by Network Affiliate theatre personnel as previously referenced in
this Section 6.1. All rights with respect to advertising and promotions not explicitly granted
hereunder are reserved to Network Affiliate, including without limitation Network Affiliate's
ability to offer and sell advertising to any third party on any website on the Internet, its
telephone ticketing service or other alternative media sources used for ticketing.

18

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 19 -->
ARTICLE VII FEES Section 7.1 Access Fee (a) Digital Screen Usage Fee. On or before sixty (60) days
after the end of each month during the Term, NCM shall pay to Network Affiliate $30.00 per digitized
screen (i.e., a screen connected to the Digital Content Network), provided Network Affiliate
provides the required attendance and screen count information as such information time frames are
established by NCM on a monthly basis. (b) Revenue Sharing. Each Party shall receive 50% of all Net
Revenue derived from the sale of advertising Inventory that is exhibited in the Theatres (the
"Advertising Revenue Share"). For purposes of this Agreement, "Net Revenue" shall mean gross
revenues from the sale of advertising Inventory exhibited in the Theatres which is actually
collected less refunds and any similar disbursements and any applicable taxes or governmental
charges other than ordinary income tax. Net Revenue shall include any revenue received by Network
Affiliate, directly or indirectly, through its use of or otherwise in connection with the Service
and alternative or independent digital film distribution. Each party shall render an accounting to
the other on a monthly basis substantiating the calculation of Net Revenue payable during such month
pursuant to Section 8.3. Section 7.2 Minimum Fee. For each twelve-month period following the
Effective Date during the Term, and as long as Network Affiliate's attendance base in the Theatres
for the twelve (12) month period is equal to or greater than 400,000 patrons (the "Base Amount"),
the amount paid by NCM pursuant to Section 7.1(b) shall be not less than $ .17 per Theatre patron
during such period with such amount increasing by 5% on each anniversary of the Effective Date (the
"Minimum Fee"). The Minimum Fee shall be prorated to account for (i) any periods during which
Network Affiliate's annual attendance base in the Theatres is lower than the Base Amount, and (ii)
reductions in revenue associated with Network Affiliate's rejection of content as permitted under
Section 3.4. Any payments made in order to satisfy the "Minimum Fee" which can be characterized as
an advance of amounts due from advertising clients which is "earned but not yet paid" shall be
deducted from the following year's payments when such amounts have in fact been collected. Section
7.3 Payment. Except as otherwise specifically provided in this Agreement, all amounts due by one
Party to the other under this Agreement, less any permitted deductions, shall be paid in full within
sixty (60) days after the fiscal month in which such amounts were received by the paying Party, or
the receipt by the paying Party of an invoice therefore, as applicable.

19

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 20 -->
Section 7.4 Audit. Each Party shall keep and maintain accurate books and records of all matters
relating to the performance of its obligations hereunder, including without limitation the sale of
advertising, in accordance with generally accepted accounting principles. During the Term and for a
period of three (3) years thereafter, each Party, at its sole expense, shall, upon reasonable
advance notice from the other party, make such books and records available at its offices for
inspection and audit by the other party, its employees and agents. Any audit with respect to amounts
payable by either party to the other party under this Agreement shall be limited to an audit with
respect to amounts to be paid in the current calendar year and immediately preceding calendar year
only. Any period that has been audited pursuant to this Section shall not be subject to any further
audit. In the event an audit of the books and records of a party reveals an underpayment to the
other party, the audited party shall pay to the other party the amount of such underpayment. Any
disputes between the Parties relating to the calculation of amounts owed shall be referred to a
mutually satisfactory independent public accounting firm that has not been employed by either party
for the two (2) year period immediately preceding the date of such referral. The determination of
such firm shall be conclusive and binding on each party, and judgment upon any such determination
can be entered in any court having jurisdiction over the matter. Each Party shall bear one-half of
the fees of such firm. If the Parties cannot select such accounting firm, then the selection of such
accounting firm shall be made by the American Arbitration Association located in Denver, Colorado.
In addition to the foregoing audit rights of the parties, during the Term, NCM and its authorized
agents shall have the right, upon reasonable advance notice, to inspect any Network Affiliate
premises or facilities involved in the performance of this Agreement to confirm the performance and
satisfaction of Network Affiliate's obligations hereunder. ARTICLE VIII TERM AND TERMINATION Section
8.1 Term. Unless earlier terminated as provided below, the term of this Agreement shall begin on the
Effective Date and shall continue for a period of five (5) years from the Effective Date (the
"Initial Term") after which this Agreement may be extended on mutual agreement of the parties (a
"Renewal Term," and together with the Initial Term, the "Term"). If either party wishes to extend
the Initial Term it shall provide notice to the other not later than 180 days, nor sooner than 270
days, before the end of the Initial Term. The parties shall then engage in discussions regarding
renewal for a period of 30 days. If no agreement is reached during that 30-day period, then neither
party shall have any obligation to extend this Agreement beyond the Initial Term. Section 8.2
Termination by Either Party. Either Party may terminate this Agreement, immediately, by giving
written notice of termination to the other, and without prejudice to any other rights or remedies
the terminating party may have, if:

20

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 21 -->
(a) The other Party breaches any material provision of this Agreement, other than any provision of
Section 14.8 or Articles V or XIII, and fails to cure such breach within thirty (30) days after
receipt from the terminating party of written notice of the breach. (b) The other Party breaches any
provision of Section or 14.8 or Articles V or XIII, and, to the extent such breach is susceptible to
cure, fails to cure such breach within five (5) days after receipt from the terminating party of
written notice of the breach. Notwithstanding anything else to the contrary herein, if the breach is
not susceptible to cure, this Agreement will terminate immediately as of such breach, with or
without any notice from the terminating party. (c) (i) A voluntary petition is commenced by the
other Party under the United States Bankruptcy Code, as amended, 11 U.S.C. § 101 et seq., (ii) the
other Party has an involuntary petition commenced against it under the Bankruptcy Code and such
petition is not dismissed within sixty (60) days after filing, (iii) the other Party becomes
insolvent, (iv) any substantial part of the other Party's property becomes subject to any levy,
seizure, assignment, application, or sale for or by any creditor or governmental agency, or (v) the
other Party liquidates or otherwise discontinues all or most of that portion of its business
operations which are related to this Agreement. Section 8.3 Termination by NCM. NCM may terminate
this Agreement upon thirty (30) days written notice to Network Affiliate in the event that
distribution of the Service to all of the Theatres listed on Exhibit B is permanently discontinued.
Section 8.4 Survival. Sections 2.3, 5.2, 5.3, 5.4, 8.4, 8.5, 11.1, 11.2, 11.3 and 11.6 and Articles
VII, IX, X, XII, and XV shall survive any expiration or termination of this Agreement. Section 8.5
Effect of Termination. Upon termination or expiration of this Agreement, and upon reasonable prior
notice to Network Affiliate, NCM shall be entitled to enter the Theatres upon reasonable prior
written notice, and any other premises of Network Affiliate where any NCM Property may be located,
and recover any and all NCM Property, unless Network Affiliate chooses to purchase such Property
based on a straight line five year depreciated value. In addition, each Party shall promptly deliver
to the other or, at the other Party's option, permit the other Party to enter its premises and
recover any Equipment in the first Party's possession, custody or control which may be owned by the
other Party pursuant to Section 2.3 hereof. Each Party shall fully cooperate in this effort. NCM
shall be obligated to restore all premises from which it removes NCM Property or Equipment to its
previous condition, reasonable wear and tear excepted. In addition, any and all licenses granted by
either party to the other under this Agreement shall immediately terminate, and NCM shall be
entitled to immediately discontinue the Service. Notwithstanding termination of this Agreement, each
party shall pay to the other, within five (5) days after the effective date of such termination, any
and all fees (including costs and expenses) owed hereunder as of such termination. Section 8.6
Suspension of Services. On the occurrence of any event which would permit NCM to terminate this
Agreement, in addition to any and all other rights and remedies to which NCM may be entitled at law
or in equity, NCM may, without terminating this Agreement, and in its sole discretion and without
further notice to Network Affiliate, suspend performance of any or all of its obligations under this
Agreement (including, without limitation, by activating internal controls in systems or software
that are designed to deny Network Affiliate use of or access to NCM Property) until and unless NCM
determines, in its sole discretion and upon whatever conditions NCM chooses to impose on Network
Affiliate, to resume performance of some or all of the suspended obligations.

21

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 22 -->
ARTICLE IX REPRESENTATIONS AND WARRANTIES Section 9.1 Representations and Warranties. Each party
represents and warrants that: (a) It (i) is duly formed and organized, validly existing, and in good
standing under the laws of the jurisdiction of its formation and incorporation and has the power and
authority to carry on its business as carried on, and (ii) has the right to enter into this
Agreement and to perform its obligations under this Agreement and has the power and authority to
execute and deliver this Agreement. (b) Any registration, declaration, or filing with, or consent,
approval, license, permit or other authorization or order by, any governmental or regulatory
authority, domestic or foreign, that is required to be obtained by it in connection with the valid
execution, delivery, acceptance and performance by it under this Agreement or the consummation by it
of any transaction contemplated hereby has been completed, made, or obtained, as the case may be.
(c) Each party is the exclusive owner of, or otherwise has or will have timely obtained all rights,
licenses, clearances and consents necessary to make the grants of rights made or otherwise perform
its obligations under this Agreement. (a) Neither party will at any time, except to the extent
necessary to assert or defend its rights under this Agreement: (i) challenge or otherwise do
anything inconsistent with the other party's right, title or interest in its property, (ii) do or
cause to be done or omit to do anything, the doing, causing or omitting of which would contest or in
any way impair or tend to impair the rights of the other party in its property, or (iii) assist or
cause any person or entity to do any of the foregoing. Section 9.2 Disclaimers. (a) Equipment
Disclaimer. EXCEPT AS EXPRESSLY AND EXPLICITLY SET FORTH IN THIS ARTICLE, INCLUDING, WITHOUT
LIMITATION, ANY REPRESENTATIONS AND WARRANTIES SET FORTH IN SECTION 9.1(c), ANY AND ALL INFORMATION,
PRODUCTS, AND SERVICES, INCLUDING, WITHOUT LIMITATION, THE NCM PROPERTY, IS PROVIDED "AS IS" AND
"WITH ALL FAULTS" AND NCM MAKES NO REPRESENTATIONS OR WARRANTIES, AND DISCLAIMS ALL REPRESENTATIONS
AND WARRANTIES, EXPRESS OR IMPLIED, WRITTEN OR ORAL, ARISING FROM COURSE OF DEALING, COURSE OF
PERFORMANCE, USAGE OF TRADE, OR OTHERWISE INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
TITLE, NON- INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE. NCM MAKES NO
REPRESENTATION THAT THE SERVICE WILL BE UNINTERRUPTED OR ERROR-FREE.

22

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 23 -->
(b) Services Disclaimer. NCM DISCLAIMS ALL REPRESENTATIONS AND WARRANTIES THAT THE SERVICE WILL BE
UNINTERRUPTED OR ERROR-FREE AND DISCLAIMS ANY WARRANTIES OF FITNESS FOR A PARTICULAR PURPOSE WITH
REGARD TO THE SERVICES. ARTICLE X INDEMNIFICATION Section 10.1 Network Affiliate Indemnification.
Network Affiliate shall defend, indemnify, and hold harmless NCM and its officers, directors,
shareholders, contractors, employees, representatives, agents, successors, and assigns
(collectively, "Representatives") from and against any and all losses, obligations, risks, costs,
liabilities, settlements, damages, judgments, awards, fines, penalties, and expenses (including,
without limitation, reasonable attorneys' fees) (collectively, "Costs") suffered or incurred in
connection with or as a result of, and from and against any and all third party claims, suits,
actions, or proceedings actually or allegedly arising out of, based upon, or relating to, (i) any
breach by Network Affiliate of Article IX, (ii) infringement by any information, content or other
materials supplied by or on behalf of Network Affiliate hereunder (including the Brand) of any third
party U.S. patent, trademark, or copyright right arising from NCM's use of such materials in
accordance and compliance with this Agreement, provided such Costs have been finally awarded by a
court of competent jurisdiction or approved by Network Affiliate as part of a settlement, (iii) any
use of any NCM Property other than as authorized by this Agreement, or (iv) Network Affiliate's
fraud, willful misconduct, or noncompliance with law. Section 10.2 NCM General Indemnification. NCM
shall defend, indemnify, and hold harmless Network Affiliate and its Representatives from and
against any and all Costs suffered or incurred in connection with or as a result of, and from and
against any and all third party claims, suits, actions, or proceedings actually or allegedly arising
out of, based upon, or relating to, (i) any breach by NCM of Article IX, or (ii) NCM's fraud,
willful misconduct, or noncompliance with law. Section 10.3 NCM Infringement Indemnification. (a)
Indemnifications Obligations. NCM shall defend, indemnify and hold harmless Network Affiliate and
its Representatives from and against any and all Costs suffered or incurred arising from any and all
third party claims, suits, actions, or proceedings to the extent actually or allegedly arising out
of, based upon, or relating to any infringement by the NCM Property (but excluding any Equipment) of
any third party U.S. trademark, copyright, or patent issued as of the Effective Date, arising from
Network Affiliate's use of the NCM Property in accordance and compliance with this Agreement.

23

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 24 -->
(b) Additional Remedies. In addition to, but not in limitation of, NCM's obligations under Section
10.3 (a) above, NCM may, at its sole option, in the event that any claim, suit, proceeding, or
action is brought or threatened for which NCM may be obligated under Section 10.3 (a) to indemnify
Network Affiliate: (i) replace or modify the NCM Property to render it non-infringing; (ii) secure
for Network Affiliate the right to use the NCM Property; or (iii) terminate this Agreement under the
provisions of Article X. In the event NCM chooses to terminate this Agreement under Article X
hereof, NCM shall refund to Network Affiliate the portion (if any) of the total amount of license
fees actually paid to NCM by Network Affiliate hereunder during the two-year period immediately
preceding the date of the claim for indemnification, depreciated according to a five-year straight
line depreciation. (c) Limitations of Obligations. NCM shall not have any liability to Network
Affiliate under this Section 10.3 for any alleged infringement based in any part on: (i) any Service
content or Confidential Information supplied by or on behalf of Network Affiliate; (ii) the combined
use of the NCM Property with software or hardware products or other technology or materials not
provided or owned by NCM; (iii) additions or modifications to the NCM Property not made by NCM; (iv)
use or installation of the NCM Property in accordance with designs or specifications not provided by
NCM; or (v) use of any legacy or superseded version of NCM Property if such infringement would have
been avoided by use of a more recent version of the NCM Property made available to Network
Affiliate. The obligations under this Section 10.3 state the entire liability of NCM and are Network
Affiliate's sole and exclusive remedies, with respect to intellectual property infringement. Section
10.4 Defense of Action. A Party offering indemnification or defense under this Article X (each, an
"Indemnitor") shall have the right to control the defense and settlement of any and all claims,
suits, proceedings, and actions for which such Indemnitor is obligated to indemnify, hold harmless,
and defend hereunder, but the Party or Representative of a Party receiving such indemnification or
defense under this Article X (each, the "Indemnitee") shall have the right to participate in such
claims, suits, proceedings, and actions at its own cost and expense. An Indemnitor shall have no
liability under this Article unless the Indemnitee gives notice of such claim to the Indemnitor
promptly after the Indemnitee learns of such claim so as to not prejudice the Indemnitor. Under no
circumstance shall either party hereto settle or compromise or consent to the entry of any judgment
with respect to any claim, suit, proceeding, or action that is the subject of indemnification
hereunder without the prior written consent of the other party, which consent shall not be withheld
or delayed unreasonably. Section 10.5 Limitations. (a) EXCEPT IN CONNECTION WITH A BREACH OF ARTICLE
XIII OF THIS AGREEMENT AND WITH THE EXCEPTION OF THE INDEMNIFICATION OBLIGATIONS OF THE PARTIES
UNDER ARTICLE X, IN NO EVENT SHALL EITHER PARTY BE LIABLE TO THE OTHER PARTY OR ANY OTHER PERSON OR
ENTITY FOR ANY INDIRECT, INCIDENTAL, CONSEQUENTIAL, SPECIAL, PUNITIVE, EXEMPLARY, OR
EXTRA-CONTRACTUAL DAMAGES OF ANY KIND WHATSOEVER ARISING FROM OR CONNECTED WITH THIS AGREEMENT,
INCLUDING, BUT NOT LIMITED TO, LOST PROFITS, LOST REVENUES, OR LOSS OF BUSINESS, REGARDLESS OF LEGAL
THEORY, WHETHER OR NOT FORESEEABLE, EVEN IF EITHER PARTY HERETO HAS BEEN ADVISED OF THE POSSIBILITY
OR PROBABILITY OF SUCH DAMAGES AND EVEN IF THE REMEDIES OTHERWISE PROVIDED BY THIS AGREEMENT FAIL OF
THEIR ESSENTIAL PURPOSE. THE REMEDIES PROVIDED BY THIS AGREEMENT AND THE PROVISIONS OF THIS
AGREEMENT ALLOCATE THE RISKS OF THIS AGREEMENT BETWEEN THE PARTIES, SOME OF WHICH MAY BE UNKNOWN OR
UNDERMINABLE. THESE LIMITATIONS ARE A MATERIAL INDUCEMENT FOR THE PARTIES TO THIS AGREEMENT TO ENTER
INTO THIS AGREEMENT, AND THE PARTIES TO THIS AGREEMENT HAVE RELIED UPON THESE PROVISIONS IN
DETERMINING WHETHER OR NOT TO ENTER INTO THIS AGREEMENT.

24

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 25 -->
(b) EXCEPT IN CONNECTION WITH A BREACH OF ARTICLE XIV HEREUNDER, AND WITH THE EXCEPTION OF THE
INDEMNIFICATION OBLIGATIONS OF THE PARTIES UNDER ARTICLE X, THE AGGREGATE TOTAL LIABILITY OF EITHER
PARTY TO THE OTHER PARTY AND TO ALL OTHER PERSONS AND ENTITIES UNDER THIS AGREEMENT SHALL UNDER NO
CIRCUMSTANCES EXCEED THE AMOUNT OF THE NET REVENUE RECEIVED BY NCM PURSUANT TO SECTION 7.2 OF THIS
AGREEMENT DURING THE FIVE (5) YEAR PERIOD PRECEDING SUCH LIABILITY, LESS IN ANY CASE THE AGGREGATE
OF ANY AMOUNTS PAID BY NCM HEREUNDER ON ACCOUNT OF PREVIOUS EVENTS OF LIABILITY. ARTICLE XI
ADDITIONAL RIGHTS AND OBLIGATIONS Section 11.1 Assistance. Each Party, upon the request of the
other, shall perform any and all further acts and execute, acknowledge, and deliver any and all
documents which the other party determines in its sole reasonable judgment may be necessary,
appropriate, or desirable to carry out the intent and purposes of this Agreement, including without
limitation to document, perfect, or enforce NCM's right, title, or interest in and to any NCM
Property or Derived Works. Section 11.2 Infringement. Network Affiliate shall notify NCM promptly,
in writing, of any alleged, actual or threatened infringement, violation, misappropriation,
imitation, simulation, or misuse of or interference with ("Infringement") any NCM Property or
Derived Work of which Network Affiliate knows or which Network Affiliate has reason to suspect. NCM
has the sole and exclusive right to determine whether to take any action on or related to any such
Infringements. NCM has the sole right to employ counsel of its choosing and to direct any litigation
and settlement of Infringement actions. Any recoveries, damages and costs recovered through such
proceedings, suits, or hearings shall belong exclusively to NCM. Section 11.3 Non-Competition and
Non-Solicitation. (a) During the Term, except as otherwise provided in this Agreement, Network
Affiliate and its affiliates agree not to engage or participate in any business, hold equity
interests, directly or indirectly, in another entity, whether currently existing or hereafter
created, or participate in any other joint venture that competes or would compete with any business
that NCM is authorized to conduct in the Territory pursuant to this Agreement, whether or not NCM is
actually conducting such business in a particular portion of the Territory. The foregoing
restrictions shall not apply (i) in the event Network Affiliate or its affiliate acquires a
competing business as an incidental part of an acquisition of any other business that is not
prohibited by the foregoing, if Network Affiliate disposes of the portion of such business that is a
competing business as soon as commercially reasonable, (ii) to any direct or indirect ownership or
other equity investments by Network Affiliate or its affiliates in such other competing business
that represents in the aggregate less than 10% of the voting power of all outstanding equity of such
business, or (iii) in the event Network Affiliate enters into any agreement for the acquisition or
installation of equipment or the provision of services on customary terms that does not violate the
exclusivity of NCM hereunder with any entity that has other businesses and provides other services
that may compete with NCM.

25

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 26 -->
(b) During the Term and for a period of twelve (12) months thereafter Network Affiliate will not,
without NCM's prior written consent, either alone or in concert with others directly or indirectly
solicit, entice, induce, or encourage: (i) any employee, contractor or agent of NCM to terminate his
or her employment, contractor or agency relationship with NCM, (ii) any client of NCM to discontinue
using NCM's services or products, (iii) any client of NCM to refer prospective clients to one or
more competitors of NCM or to discontinue referring prospective clients to NCM, (iv) any NCM
employee, client, or prospective client to breach any agreement with NCM, or (v) any existing or
proposed arrangement or other community or institutional affiliation to discontinue the affiliation
or relationship with NCM. For purposes of this Section 11.3 the term NCM shall include NCM and its
affiliates. Section 11.4 Theatre Passes. Network Affiliate shall provide to NCM during each month of
the Term 25 complimentary Theatre passes that will not expire any earlier than 120 days from the
date of issuance. The passes shall be provided to NCM at least 30 days prior to the month in which
such passes first become valid. Section 11.5 Compliance with Law. Network Affiliate and NCM shall at
all times operate and conduct its business, including, without limitation, exercising its rights
under this Agreement, in compliance with all applicable international, national, state, and local
laws, rules, and requirements. Section 11.6 Insurance. Network Affiliate shall maintain with
financially sound and reputable insurance companies insurance on the Theatres and the Equipment in
such amounts and against such perils as Network Affiliate deems adequate for its business. NCM shall
maintain with financially sound and reputable insurance companies insurance for its business and
Equipment in such amounts and against such perils as NCM deems adequate for its business, including
the installation services set forth in Section 2.2 herein. Each Party will name the other Party
(including its agents, officers, directors, employees and affiliates) as an additional insured on
such policies of insurance. ARTICLE XII OWNERSHIP Section 12.1 NCM Property. As between NCM and
Network Affiliate, NCM owns, solely and exclusively, any and all right, title, and interest in and
to the Service (including all Service content supplied by or on behalf of NCM, but excluding any
Service content supplied by or on behalf of Network Affiliate), the Marks, the Software, NCM's
Confidential Information, the Digital Content Network, and any and all other data, information,
equipment (excluding any rights to Equipment held by Network Affiliate pursuant to Article II),
material, inventions, discoveries, processes, methods, technology, know-how, written works,
software, works of visual art, audio works, and multimedia works provided, developed, created,
reduced to practice, conceived, or made available by or on behalf of NCM to Network Affiliate or
used by NCM to perform any of its obligations under or in connection with this Agreement, as well as
any and all translations, improvements, adaptations, reproductions, look-and- feel attributes, and
derivates thereof (collectively, the "NCM Property"), and, except as expressly and explicitly stated
in this Agreement, reserves all such right, title, and interest.

26

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 27 -->
Section 12.2 Derived Works. Any and all data, information, and material created, conceived, reduced
to practice, or developed by or on behalf of either Party, whether alone, in connection with the
other Party or any third party, including, without limitation, written works, processes, methods,
inventions, discoveries, software, works of visual art, audio works, look-and-feel attributes, and
multimedia works, based on, using, or derived from, in whole or in part, any NCM Property, whether
or not done on NCM's facilities, with NCM's equipment, or by NCM personnel, and any and all right,
title, and interest therein and thereto (including, but not limited to, the right to sue for past
infringement) (collectively, "Derived Works"), shall be owned solely and exclusively by NCM, and
Network Affiliate agrees to and hereby does assign, transfer, and convey to NCM (and will ensure
than any third party acting with or on behalf of Network Affiliate assigns, transfers, and conveys
to NCM any and all right, title, or interest in or to any Derived Work which it may at any time
acquire by operation of law or otherwise. To the extent any Derived Works are included in the
Service, NCM hereby grants to Network Affiliate during the Term a non-exclusive, non-transferable,
non-sublicenseable license to such Derived Works solely for use in connection with the Service as
expressly provided by this Agreement. The restrictions on use of the Software set forth in Section
5.2 shall apply with equal force to Network Affiliate's use of any Derived Works, and such
restrictions are hereby incorporated in and made a part of this Section 12.2. Section 12.3 No Title.
This Agreement is not an agreement of sale, and no title or ownership interest in or to any NCM
Property is transferred to Network Affiliate as a result of or pursuant to this Agreement. Further,
Network Affiliate acknowledges that its exercise of rights with respect to the NCM Property shall
not create in Network Affiliate any right, title or interest in or to any NCM Property and that all
exercise of rights with respect to the NCM Property and the goodwill symbolized thereby or connected
therewith will inure solely to the benefit of NCM. ARTICLE XIII CONFIDENTIALITY Section 13.1
Confidential Treatment. Each party acknowledges that the other's Confidential Information contains
valuable trade secret and proprietary information of that party. Each party agrees to permanently
hold, and cause its personnel to hold, all Confidential Information of the other party in strict
confidence, except that each party may: (i) disclose the Confidential Information of the other party
that is required to be disclosed by governmental agencies, regulatory authorities, or pursuant to
court order, but only to the extent such disclosure is required by law and only if such party
provides prompt prior written notice to the other party of the disclosure, and (ii) subject to the
terms and conditions of this Agreement, use the Confidential Information of the other party only to
the extent necessary to perform its obligations under this Agreement. Except as specifically
permitted by this Agreement, neither party shall duplicate or use, or permit the duplication or use
of, any Confidential Information of the other party or disclose or permit the disclosure of such
Confidential Information to any person or entity. Each party shall limit use, possession, and
disclosure of, and shall limit access to, the Confidential Information of the other party only to
those of its employees or representatives whose performance under this Agreement requires such use,
possession, disclosure, or access and who have signed confidentiality and non-disclosure agreements
protecting the confidentiality of the Confidential Information at least to the same extent as such
information is protected under this Agreement. Any duplication, use, disclosure, or other act or
omission by any person or entity that obtains access to or possession of Confidential Information
through the receiving party that would be a breach of this Agreement if committed by the receiving
party shall be a breach of this Agreement by the receiving party for which the receiving party shall
be responsible. For the avoidance of doubt, neither party shall issue any press release or other
public announcement concerning this Agreement, including without limitation its existence, without
the prior written approval of the other party. It shall not be a violation of this XIII for a party
to disclose to any person or entity the tax treatment and tax structure of the transactions
contemplated under this Agreement and all materials of any kind (including without limitation
opinions or other tax analyses) relating to such tax treatment or tax structure.

27

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 28 -->
Section 13.2 Point-of-Sale Information. Due to the sensitive nature of the Point-of-Sale
Information, NCM will establish a "Chinese Wall" around the Point-of-Sale Information to prevent the
disclosure of the Point-of-Sale Information under any circumstances to any theatre operator that is
a competitor of Network Affiliate, any employees or agents of any affiliate of NCM, including the
board of directors thereof and employees thereof with operational responsibility, except to the
extent such employees or agents have a need to know such information to permit NCM's performance
under this Agreement. Notwithstanding the preceding sentence, but subject to the confidentiality
restrictions of Section 13.1, NCM shall be permitted to disclose the Point-of-Sale Information in
aggregate form. Section 13.3 Injunctive Relief. Due to the unique and proprietary nature of the NCM
Property, the Derived Works and the Confidential Information, it is understood and agreed that each
party's remedies at law for a breach of this Article XIII will be inadequate and that each party
shall, in the event of any such breach or the threat of such breach, be entitled to equitable relief
(including without limitation provisional and permanent injunctive relief and specific performance).
In addition, Network Affiliate hereby expressly waives the right to a hearing prior to the issuance
of any order by a court of competent jurisdiction granting possession of any NCM Property or Derived
Work to NCM. The parties shall be entitled to the relief described in this Section 13.3 without the
requirement of posting a bond. Nothing stated herein shall limit any other remedies provided under
this Agreement or available to the parties at law. ARTICLE XIV MISCELLANEOUS Section 14.1 Notices.
All notices, consents, and other communications between the parties under or regarding this
Agreement shall be in writing and shall be sent to the recipient's address set forth in this
section. Such communications shall be deemed to have been received on the date actually received.

28

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 29 -->
Either party may change its address for notices by giving written notice of the new address to the
other party in accordance with this section, but any element of such party's address that is not
newly provided in such notice shall be deemed not to have changed. Section 14.2 Waiver; Remedies.
The waiver or failure of either party to exercise any right provided hereunder shall not be deemed a
waiver of such right in the future or a waiver of any other rights established under this Agreement.
All remedies available to either party hereto for breach of this Agreement are cumulative and may be
exercised concurrently or separately, and the exercise of any one remedy shall not be deemed an
election of such remedy to the exclusion of other remedies. Section 14.3 Severability. Should any
term or provision of this Agreement be held to any extent unenforceable, invalid, or prohibited
under law, then such provision shall be deemed restated to reflect the original intention of the
parties as nearly as possible in accordance with applicable law and the remainder of this Agreement.
The application of any term or provision restated pursuant hereto to persons, property, or
circumstances other than those as to which it is invalid, unenforceable, or prohibited, shall not be
affected thereby, and each other term and provision of this Agreement shall be valid and enforceable
to the fullest extent permitted by law. Section 14.4 Integration; Headings. This Agreement and the
exhibits hereto (each of which is made a part hereof and incorporated herein by this reference)
constitute the complete and exclusive statement of the agreement between the parties with respect to
the subject matter of this Agreement, and this Agreement supersedes any and all other prior or
contemporaneous oral or written communications, proposals, representations, and agreements, express
or implied. This Agreement may be amended only by mutual agreement expressed in writing and signed
by both parties. Headings used in this Agreement are for reference only and shall not affect the
interpretation of this Agreement. Section 14.5 Construction. The parties hereto have participated
jointly in the negotiation and drafting of this Agreement. In the event an ambiguity or question of
intent or interpretation arises, this Agreement shall be construed as if drafted jointly by the
parties and no presumption or burden of proof shall arise favoring or disfavoring any party by
virtue of the authorship of any of the provisions of this Agreement. Section 14.6 Non-Recourse.
Notwithstanding anything contained in this Agreement to the contrary, it is expressly understood and
agreed by the parties hereto that each and every representation, warranty, covenant, undertaking and
agreement made in this Agreement was not made or intended to be made as a personal representation,
undertaking, warranty, covenant, or agreement on the part of any individual or of any partner,
stockholder, member or other equity holder of either party hereto, and any recourse, whether in
common law, in equity, by statute or otherwise, against any such individual or entity is hereby
forever waived and released.

NCM: National CineMedia, LLC 9110 E. Nichols Ave., Suite 200 Centennial, CO 80112 Attention: Gene
Hardy, Esq., EVP and General Counsel

Network Affiliate: Digital Cinema Destinations Corp. 250 Broad Street Westfield, New Jersey 07090
Attention: Bud Mayo, Chairman/CEO

29

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 30 -->
Section 14.7 Dispute Resolution. (a) Governing Law. This Agreement shall be binding on the Parties
as of the date hereof and is to be construed in accordance with and governed by the internal laws of
the State of Delaware without giving effect to any choice of law rule that would cause the
application of the laws of any jurisdiction other than the internal laws of the State of Delaware to
the rights and duties of the Parties. (b) Jurisdiction. Each Party hereto agrees that any legal
action or other legal proceeding relating to this Agreement or the enforcement of any provision of
this Agreement shall be brought or otherwise commenced exclusively in any state or federal court
located in New York, New York. Subject to the preceding sentence, each Party hereto: (i) expressly
and irrevocably consents and submits to the jurisdiction of each state and federal court located in
New York, New York (and each appellate court located in the State of New York) in connection with
any such legal proceeding, including to enforce any settlement, order or award; (ii) consents to
service of process in any such proceeding in any manner permitted by the laws of the State of New
York, and agrees that service of process by registered or certified mail, return receipt requested,
at its address specified pursuant to Section 15.01 is reasonably calculated to give actual notice;
(iii) agrees that each state and federal court located in New York, New York shall be deemed to be a
convenient forum; (iv) waives and agrees not to assert (by way of motion, as a defense or
otherwise), in any such legal proceeding commenced in any state or federal court located in New
York, New York, any claim that such Party is not subject personally to the jurisdiction of such
court, that such legal proceeding has been brought in an inconvenient forum, that the venue of such
proceeding is improper or that this Agreement or the subject matter hereof or thereof may not be
enforced in or by such court; and (v) agrees to the entry of an order to enforce any resolution,
settlement, order or award made pursuant to this Section by the state and federal courts located in
New York, New York and in connection therewith hereby waives, and agrees not to assert by way of
motion, as a defense, or otherwise, any claim that such resolution, settlement, order or award is
inconsistent with or violative of the laws or public policy of the laws of the State of New York or
any other jurisdiction. (c) Costs and Expenses. In the event of any action or other proceeding
relating to this Agreement or the enforcement of any provision of this Agreement, the prevailing
party (as determined by the court) shall be entitled to payment by the non-prevailing party of all
costs and expenses (including reasonable attorneys' fees) incurred by the prevailing party,
including any costs and expenses incurred in connection with any challenge to the jurisdiction or
the convenience or propriety of venue of proceedings before any state or federal court located in
New York, New York.

30

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 31 -->
Section 14.8 Assignment. Network Affiliate may not assign or transfer, by operation of law or
otherwise, any of its rights under this Agreement or delegate any of its duties under this Agreement
to any third party without NCM's prior written consent, which consent shall not be unreasonably
withheld, conditioned or delayed. For the purposes of this Agreement, any change of control, merger,
consolidation, or acquisition of all or substantially all of the assets of Network Affiliate
(collectively, a "Change of Control") shall be deemed an assignment. This Agreement shall not be
assignable by either party unless the assignee expressly assumes in writing the obligations of the
assignor hereunder. Any attempted assignment in violation of this section shall be void. Section
14.9 Force Majeure. Any delay in the performance of any duties or obligations of either party
(except the payment of money owed) will not be considered a breach of this Agreement if such delay
is caused by a labor dispute, shortage of materials, fire, earthquake, flood, or any other event
beyond the control of such party, provided that such party uses reasonable efforts, under the
circumstances, to notify the other party of the circumstances causing the delay and to resume
performance as soon as possible. Section 14.10 Third Party Beneficiary. The parties hereto do not
intend, nor shall any clause be interpreted, to create under this Agreement any obligations or
benefits to, or rights in, any third party from either NCM or Network Affiliate. Neither party
hereto is granted any right or authority to assume or create any obligation or responsibility,
express or implied, on behalf of, or in the name of, the other party, or to bind the other party in
any matter or thing whatever. No affiliate of NCM shall have any liability or obligation pursuant to
this Agreement. NCM shall be solely responsible, and Network Affiliate agrees to look solely to NCM,
for the satisfaction of NCM's obligations under this Agreement. Section 14.11 Export. Network
Affiliate acknowledges that the Software and the Confidential Information of NCM are subject to the
export controls of the United States. Network Affiliate acknowledges that it has no right to, and
further agrees that it will not, export or otherwise transfer or permit the transfer of any Software
or Confidential Information of NCM outside the United States. Network Affiliate will defend,
indemnify, and hold harmless NCM from and against all fines, penalties, liabilities, damages, costs,
and expenses incurred by NCM as a result of any failure to comply with the preceding sentence.
Section 14.12 Independent Contractors. Network Affiliate's relationship to NCM is that of an
independent contractor, and neither party is an agent or partner of the other. Network Affiliate
will not have, and will not represent to any third party that it has, any authority to act on behalf
of NCM. Section 14.13 Counterparts. This Agreement may be executed in any number of separate
counterparts each of which when executed and delivered to the other party hereto shall be an
original as against the party whose signature appears thereon, but all such counterparts shall
together constitute one and the same instrument.

31

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 32 -->
IN WITNESS WHEREOF, the parties have executed this Agreement as of the day and year first above
written.

DIGITAL CINEMA DESTINATIONS CORP. By: /s/ A. Dale Mayo By: A. Dale Mayo Name: Title:

NATIONAL CINEMEDIA, LLC By: /s/ Robert W. Brouillette Name: Robert W. Brouillette Title: Senior Vice
President

32

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 33 -->
EXHIBIT A Services

All lobby promotions and other in-theatre promotional activities (excluding the Digital Content
Service, the Traditional Content Program and other on-screen content), but specifically excluding
the following promotional activities (which Network Affiliate shall retain the right to perform and
have performed on its behalf): promotional activities arising under the Beverage Agreement with
Pepsi dated January 1, 2011 . (1) poster case advertising and other lobby or in-theatre promotions
for (w) film festivals or events organized by Network Affiliate (unless such poster cases have been
sold by NCM), (x) fundraising programs conducted by Network Affiliate for any non-profit
organizations, (y) full-length theatrical productions, and (z) Theatre Advertising; (2) logos for
Network Affiliate, beverage and concession suppliers on digital menu boards at the concession stand
or digital displays at the box office of manufacturers of such products; (3) advertising and/or
signage pursuant to the IMAX agreement (if applicable); (4) any trademark, service mark, logo or
other branding of Network Affiliate (or its theatre-operating Affiliates), film studio(s),
distributors and production companies; and (5) advertising in the proposed "playbill type" Box
Office magazine that may be distributed at the Theatres; provided, however, that Network Affiliate
shall insure that the restrictions and standards, including, without limitations those such as are
set forth in Article III of this Agreement, are imposed by Network Affiliate on or respect to any
such advertising.

The Digital Content Service (which includes the Pre-Feature Program, Policy Trailer and the Video
Display Program), the Digital Carousel and the Traditional Content Program, and all other on-screen
content which is exhibited in Theatre auditoriums prior to the feature film presentation, but
specifically excluding Trailers.

A. Advertising Services consist of the following:

Lobby Promotions means as follows:

Digital Content Service, Digital Carousel and Traditional Content Program

A-1

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 34 -->
EXHIBIT A-1 Network Affiliate Inventory For Lobby Promotions The Inventory of Lobby Promotions for
each Theatre to which NCM has "pre-approved" access is as listed below. Per Flight (unless otherwise
specified below), NCM may provide each Theatre with any combination of Lobby Promotions as described
below.

*Pre approved vehicle list theatres onl y **Background music optional

Item Inventory per Flight Quantity Spec Box Office Handout 2 programs per Theatre Same 3"x5" 2-sided
(1 handout per transaction) Exit Sampling 1 program per Theatre Same Poster Case 1 program per
Theatre varies (below) 27"x40" Live Area 24"x38" (1-11 screens: 1 poster; 12 screens: 2 posters;
13-20 screens: 3 posters; 21+ screens: 4 posters) Tabling/Demo 1 program per Theatre 1 per client
4-6' table (No active "recruitment" of patrons) Vehicle/Motorcycle* 1 program per Theatre 1 per
client Background Music** 1 program per Theatre N/A N/A Counter Cards 2 programs per Theatre 2-3 per
client 13"x16.5"x4" Static Clings 1 program per Theatre 2-3 per client 4"x6" per quarter Lobby
Display 2 programs per Theatre 1 per client 4'x6' Lobby Standee 2 programs per Theatre 1 per client
3'x5' Floor Mats 1 program per Theatre 1 per client 4"x6' per quarter

A-1-1

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 35 -->
EXHIBIT B Theatres Rialto Theater 250 East Broad Street Westfield, NJ 07090 Cranford Theater 25
North Avenue West Cranford, NJ 07016 Bloomfield 8 863 Park Avenue Bloomfield, CT 06002

B-1

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 36 -->
EXHIBIT C Marks NCM Marks National CineMedia FirstLook NCM Network Affiliate Marks DIGITAL CINEMA
DESTINATIONS CORP. Digiplex Destinations Cinema Reinvented

C-1

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
<!-- page 37 -->
EXHIBIT D Excluded Theatres and IMAX Screen None

D-1

Source: DIGITAL CINEMA DESTINATIONS CORP., S-1, 12/20/2011
