"""ModelCaller: JSON with one repair, per-call timeouts bounded by the stage deadline."""
import time

import pytest
from langchain_core.messages import AIMessage, HumanMessage
from pydantic import BaseModel

from dr.llm import endpoint_for, get_scripted_llm
from dr.structured import ModelCaller, extract_json


class Pair(BaseModel):
    a: int
    b: str


def test_json_repairs_once_then_gives_up():
    llm = get_scripted_llm([AIMessage(content='{"a": "x"}'), AIMessage(content='ok: {"a": 1, "b": "y"}')])
    got = ModelCaller(llm, None, "s", "r").json([HumanMessage(content="q")], Pair)
    assert got == Pair(a=1, b="y") and "did not match" in llm.seen[1][-1].content
    llm2 = get_scripted_llm([AIMessage(content="nope"), AIMessage(content="still nope")])
    assert ModelCaller(llm2, None, "s", "r").json([HumanMessage(content="q")], Pair) is None
    assert extract_json("```json\n{\"k\": [1]}\n```") == {"k": [1]} and extract_json("[1]") is None


def test_timeout_is_bounded_by_deadline_and_skipped_when_past():
    llm = get_scripted_llm([AIMessage(content="hi")])
    caller = ModelCaller(llm, None, "s", "r", deadline_ts=time.time() + 30)
    assert caller.text([HumanMessage(content="q")]) == "hi"
    assert 25 < llm.last_kwargs["timeout"] <= 30
    late = ModelCaller(get_scripted_llm([AIMessage(content="never")]), None, "s", "r", deadline_ts=time.time() - 1)
    assert late.text([HumanMessage(content="q")]) is None and late.errors == ["deadline passed before the call"]
    nodeadline = ModelCaller(get_scripted_llm([AIMessage(content="x")]), None, "s", "r")
    assert nodeadline.text([HumanMessage(content="q")]) == "x" and nodeadline.llm.last_kwargs == {}


def test_endpoint_timeout_and_retries_from_env(monkeypatch):
    import dr.llm as llm_mod
    monkeypatch.setattr(llm_mod, "_dotenv_done", True)
    for k in list(llm_mod.os.environ):
        if k.startswith("DR_"):
            monkeypatch.delenv(k)
    assert endpoint_for("writer").timeout_s == 90 and endpoint_for("writer").max_retries == 1
    monkeypatch.setenv("DR_TIMEOUT_WRITER", "20")
    monkeypatch.setenv("DR_RETRIES_DEFAULT", "0")
    monkeypatch.setenv("DR_MAX_TOKENS_WRITER", "900")
    monkeypatch.setenv("DR_THINKING_WRITER", "0")
    w = endpoint_for("writer")
    assert w.timeout_s == 20 and w.max_retries == 0 and w.max_tokens == 900 and not w.thinking
    assert endpoint_for("researcher").max_tokens is None and endpoint_for("researcher").thinking
    from dr.llm import get_llm
    llm = get_llm("writer")                     # constructs the client only, no network
    assert llm.extra_body == {"chat_template_kwargs": {"enable_thinking": False}} and llm.max_tokens == 900
    assert get_llm("researcher").extra_body is None


def test_invoke_with_backoff_waits_on_429_then_succeeds(monkeypatch):
    from dataclasses import replace

    from dr.config import DEFAULT
    from dr.structured import invoke_with_backoff, is_rate_limit

    class RateLimitError(Exception):
        status_code = 429

    class Plain(Exception):
        pass

    assert is_rate_limit(RateLimitError()) and not is_rate_limit(Plain())
    calls = []
    monkeypatch.setattr("dr.structured.time.sleep", lambda s: calls.append(("sleep", s)))

    def boom(messages):
        raise RateLimitError("429")

    llm = get_scripted_llm([boom, boom, AIMessage(content="ok")])
    cfg = replace(DEFAULT, RATE_LIMIT_RETRIES=3, RATE_LIMIT_BACKOFF_S=2.0)
    waits = []
    out = invoke_with_backoff(llm, [HumanMessage(content="q")], {}, cfg, on_wait=lambda a, w: waits.append((a, w)))
    assert out.content == "ok" and waits == [(1, 2.0), (2, 4.0)] and [s for _, s in calls] == [2.0, 4.0]
    # waits double and are capped per wait
    waits.clear()
    cfg_cap = replace(cfg, RATE_LIMIT_RETRIES=4, RATE_LIMIT_BACKOFF_MAX_S=5.0)
    invoke_with_backoff(get_scripted_llm([boom, boom, boom, AIMessage(content="ok")]), [HumanMessage(content="q")], {}, cfg_cap,
                        on_wait=lambda a, w: waits.append((a, w)))
    assert waits == [(1, 2.0), (2, 4.0), (3, 5.0)]
    # a plain error is not retried; retries are bounded; the deadline caps the wait
    with pytest.raises(Plain):
        invoke_with_backoff(get_scripted_llm([lambda m: (_ for _ in ()).throw(Plain())]), [HumanMessage(content="q")], {}, cfg)
    with pytest.raises(RateLimitError):
        invoke_with_backoff(get_scripted_llm([boom] * 4), [HumanMessage(content="q")], {}, cfg)
    with pytest.raises(RateLimitError):
        invoke_with_backoff(get_scripted_llm([boom, AIMessage(content="late")]), [HumanMessage(content="q")], {}, cfg, deadline_ts=time.time() + 3)


def test_rate_limiter_paces_requests(monkeypatch):
    from dr.ratelimit import RateLimiter, limiter_for, pace
    lim = RateLimiter(rpm=3)
    t = [1000.0]
    monkeypatch.setattr("dr.ratelimit.time.time", lambda: t[0])
    slept = []

    def fake_sleep(s):
        slept.append(s)
        t[0] += s

    monkeypatch.setattr("dr.ratelimit.time.sleep", fake_sleep)
    assert [lim.acquire() for _ in range(3)] == [0.0, 0.0, 0.0]   # three fit in the window
    waited = lim.acquire()                                        # the fourth waits for the window to roll
    assert waited > 59 and slept and t[0] >= 1060.0
    monkeypatch.delenv("DR_RPM_LIMIT", raising=False)
    assert limiter_for("x") is None and pace("x") == 0.0          # off when unset
    monkeypatch.setenv("DR_RPM_LIMIT", "12")
    assert limiter_for("y").rpm == 12 and limiter_for("y") is limiter_for("y")
