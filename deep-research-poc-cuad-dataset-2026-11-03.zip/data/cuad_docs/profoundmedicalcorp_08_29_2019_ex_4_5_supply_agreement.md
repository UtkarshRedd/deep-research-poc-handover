<!-- page 1 -->
# SUPPLY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Supply Agreement |
| Agreement Date | 2017-07-31 |
| Parties | Profound Medical Inc. ("Customer"); Philips Medical Systems Nederland B.V. ("Philips"); (Customer and Philips hereinafter also collectively referred to as the “Parties” and individually as a “Party”) |
| Source | CUAD v1 / PROFOUNDMEDICALCORP_08_29_2019-EX-4.5-SUPPLY AGREEMENT |

Exhibit 4.5 SUPPLY AGREEMENT between PROFOUND MEDICAL INC. and PHILIPS MEDICAL SYSTEMS NEDERLAND
B.V.
<!-- page 2 -->
THIS AGREEMENT is made July 31, 2017 BETWEEN: PROFOUND MEDICAL INC., a company incorporated under
the laws of the province of Ontario and having its registered address at 2400 Skymark, Unit 6,
Mississauga, Ontario L4W 5K5, Canada (hereinafter referred to as "Customer") - and - PHILIPS MEDICAL
SYSTEMS NEDERLAND B.V., a company incorporated under the laws of the Netherlands with its principal
place of business at Veenpluis 4-6 5684 PC Best, the Netherlands (hereinafter referred to as
"Philips") Customer and Philips hereinafter also collectively referred to as the "Parties" and
individually as a "Party". WHEREAS: A. Pursuant to the Asset and Share Purchase Agreement (the
"Purchase Agreement") entered into on June 30, 2017 by Customer, Koninklijke Philips NV ("Philips
NV") N.V. and Customer agreed to execute and deliver (or cause to be executed and delivered) certain
ancillary agreements one of which is this Agreement; B. Prior to the consummation of the
transactions contemplated by the Purchase Agreement, Philips manufactured the Product in-house and
did not outsource the manufacturing to an independent facility, and as a result, Philips has
intimate knowledge of the manufacturing process and requirements for the Product; C. Customer
originally desired to take over responsibility for the manufacture of the Product immediately upon
closing of the transactions contemplated by the Purchase Agreement; D. As Philips historically
manufactured the Product in-house, to enable Customer to prepare for and realize the transition of
the manufacturing of the Product to Customer's organization, Customer requires the assistance of
Philips to continue manufacturing the Product until such time as the manufacturing process can be
transitioned to Customer hereunder; E. Until such time as the manufacturing of the Product can be
transitioned to Customer in accordance with the terms of this Agreement, Philips agrees to supply,
as a contract manufacturer to Customer, on a temporary basis for the Term (as defined herein), the
Product, and Customer wishes to buy such Products from Philips under this Agreement;
<!-- page 3 -->
F. Customer acknowledges and agrees that it assumes all obligations and liabilities as the legal
manufacturer of the Product as from the Effective Date, on the terms and conditions set out in this
Agreement. NOW IT IS HEREBY AGREED as follows: 1. DEFINITIONS The following terms used in this
Agreement shall have the meaning set forth below: "Affiliate" means, with respect to any Person, any
other Person that directly, or indirectly through one or more intermediaries, controls, is
controlled by or is under common control with the specified Person. As used in this definition,
"control", "controlled by" and "under common control with" means possession, directly or indirectly,
of power to direct or cause the direction of management or policies of such Person (whether through
ownership of securities or other partnership or ownership interests, as trustee, personal
representative or executive or by contract, credit agreement or otherwise), provided that in any
event, any Person which owns directly, indirectly or beneficially 50% or more of the securities
having voting power for the election of directors or other governing body of a corporation or 50% or
more of the partnership interests or other ownership interests of any other Person will be deemed to
control such Person. "Agreement" means this Supply Agreement including any and all of its Schedules
as attached hereto and as may be amended or supplemented from time to time in accordance with the
provisions hereof. "Business Day" means any day other than a Saturday, Sunday or statutory holiday,
in the Province of Ontario or the Netherlands. "Claim" means any claim, action, cause of action,
demand, lawsuit, arbitration, inquiry, audit, notice of violation, proceeding, litigation, citation,
summons, subpoena or investigation of any nature, civil, criminal, administrative, regulatory or
other, whether at Law, in equity or otherwise. "Confidential Information" means any information,
provided in whatever form (including in written, electronic or oral form) or medium, which relates
to either Party's or its Affiliates' business, products (hardware and software), technology,
business plans, product plans, customers, customer information, specifications, designs, costs,
prices, business opportunities, Know How, trade secrets, inventions, techniques, processes,
algorithms, software programs, schematics and any other business or technical information disclosed
by the Disclosing Party to the Receiving Party in connection with this Agreement. "Confirmation" has
the meaning ascribed thereto in clause 4.4. "Contract Year" means the twelve (12) month period
beginning on the Effective Date, and each subsequent twelve (12) month period during the Term.

- 3 -
<!-- page 4 -->
"Customer" has the meaning ascribed thereto in the Preamble. "Customer Indemnified Parties" has the
meaning ascribed thereto in clause 10.1. "Delivery" means the actual delivery of the Product to
Customer and the acceptance by Customer of the Product in accordance with clause 7.1. "Disclosing
Party" as the meaning ascribed thereto in clause 14.1. "DMR" has the meaning ascribed thereto in
clause 5.3. "EDI" means electronic data interchange. "Effective Date" means the Completion Date as
defined in the Purchase Agreement. "Encumbrance" means any charge, claim, community property
interest, pledge, condition, equitable interest, lien (statutory or other), option, security
interest, mortgage, easement, encroachment, right of way, right of first refusal, or restriction of
any kind, including any restriction on use, voting, transfer, receipt of income or exercise of any
other attribute of ownership. "Export Regulations" has the meaning ascribed thereto in clause 16.1.
"Factory Test Report" means the report, the content of which is set forth in Schedule 4, that
Philips shall prepare and maintain, identifying the factory tests Philips completes on the Product
prior to Delivery to support its compliance with the Specifications. "Force Majeure" has the meaning
ascribed thereto in clause 0. "Forecasts" means those documents setting out anticipated demand for
the Product as to be more particularly described in clause 3.2. "Governmental Authority" means any
federal, state, local or foreign government or political subdivision thereof, or any agency or
instrumentality of such government or political subdivision, or any self-regulated organization or
other non-governmental regulatory authority or quasi-governmental authority (to the extent that the
rules, regulations or orders of such organization or authority have the force of Law), or any
arbitrator, court or tribunal of competent jurisdiction. "Intellectual Property Rights" means, in
any and all jurisdictions, all: (a) patents and applications therefor, including all continuations,
continuations-in-part and provisionals and patents issuing thereon, and all reissues,
re-examinations, substitutions, renewals and extensions thereof (collectively, "Patents"); (b)
trademarks, service marks, trade names, trade dress, logos, corporate names, Internet domain names
or uniform resource locators used in connection with any global computer or electronic network,
together with all translations, adaptations, derivations and combinations thereof, and other source
or business identifiers, together with the goodwill associated with any of the foregoing, and all
applications, registrations, renewals and extensions thereof; (c) industrial designs, designs and
design rights; (d) copyrights, works of authorship and moral rights, and all registrations,
applications, renewals, extensions and reversions thereof; (e) trade secrets, discoveries, concepts,
ideas, research and development, Know How, formulae, inventions, compositions, manufacturing and
production processes and techniques, technical data, quality data, procedures, designs, drawings,
specifications, databases, and other proprietary or confidential information, including customer
lists, supplier lists, pricing and cost information, and business and marketing plans and proposals,
which would constitute a "trade secret" under applicable Law, in each case excluding any rights in
respect of any of the foregoing that comprise or are protected by Patents ("Trade Secrets"); (f)
inventions, processes and designs; and (g) software, and all source code, object code, data and
documentation relating thereto.

- 4 -
<!-- page 5 -->
"Know How" means any and all concepts, ideas, information, data and documents of whatever nature,
including, without limitation, drawings, methods, techniques, designs, specifications, photographs,
samples, models, processes, procedures, reports, particulars of a technical nature (including,
without limitation, any know how related to the manufacturing or design of Products and technical
and commercial know how). "Law" means all laws, statutes, ordinances, decrees, judgments, codes,
standards, acts, orders, by-laws, rules, regulations, permits, legally binding policies and
guidelines and legally binding requirements of all Governmental Authorities. "Lead-Time" means, as
applicable, the minimum number of days required between the date of the Purchase Order and the date
of Delivery requested in a Purchase Order as such number is listed in Schedule 2. "Losses" has the
meaning ascribed thereto in clause 10.1. "New Technology" has the meaning ascribed thereto in clause
13.3. "Other Transaction Documents" has the meaning ascribed thereto in clause 6.6. "Parties" and
"Party" have the meaning ascribed thereto in the Preamble. "Permit" has the meaning ascribed thereto
in clause 8.2(c). "Person" includes any individual, sole proprietorship, partnership, unincorporated
association, unincorporated syndicate, unincorporated organization, trust, body corporate and a
natural person in his or her capacity as trustee, executor, administrator or other legal
representative. "Project Manager" has the meaning ascribed thereto in clause 12.8(a). "Project Team"
has the meaning ascribed thereto in clause 12.8. "Quality Agreement" has the meaning ascribed
thereto in clause 8.1. "Philips" has the meaning ascribed thereto in the Preamble.

- 5 -
<!-- page 6 -->
"Philips Indemnitees" has the meaning ascribed thereto in clause 10.1(ii) "Product" means the
Sonalleve MR-guided HIFU device which Philips shall manufacture and supply according to this
Agreement as specified in Schedule 1,including spare parts. "Production Plan" means the production
plan setting forth the delivery limitations as specified in Schedule 3, and as may be updated in
accordance with clause 3.1. "Purchase Order" means an order for Products as may be submitted by
Customer in accordance with clause 3. "Quality Agreement" means the Quality Agreement as described
further in clause 8.1 of this Agreement, as the same may be amended or supplemented from time to
time in accordance with the terms thereof. "Receiving Party" as the meaning ascribed thereto in
clause 14.1. "Regulatory Transfer Date" has the meaning ascribed to such term in clause 2.3.
"Representatives" has the meaning ascribed to such term in clause 14.2. "Required Jurisdictions"
[Redacted - Commercially Sensitive] "RPA" means the resale purchasing agreement between the Parties,
dated as of the Effective Date. "Specifications" means the specifications for the Product as set out
in Schedule 1, as such specifications be amended from time to time in accordance with the terms of
the quality agreement (the "Quality Agreement"). "Term" has the meaning ascribed thereto in clause
12.1. "Third Parties" means a Person who is not a Party or an Affiliate of a Party. "Transferred
Confidential Information" has the meaning ascribed thereto in clause 14.4. "Transition Plan" has the
meaning ascribed thereto in clause 12.8. "VAT" has the meaning ascribed thereto in clause 6.1. 2.
GENERAL, SCOPE 2.1 During the Term, Philips shall manufacture and supply and Customer shall purchase
the Products ordered by Customer pursuant to Purchase Orders (issued by Customer and accepted by
Philips) in accordance with the terms and conditions of this Agreement.

- 6 -
<!-- page 7 -->
2.2 The Parties intend for the express terms and conditions contained in this Agreement, including
the Quality Agreement and any Schedules and Exhibits hereto or thereto, and in any Purchase Order
that are consistent with the terms and conditions of this Agreement to exclusively govern and
control each of the Parties' respective rights and obligations regarding the manufacture, purchase
and sale of the Products, and the Parties' agreement is expressly limited to such terms and
conditions. Notwithstanding the foregoing, if any terms and conditions contained in a Purchase Order
conflict with any terms and conditions contained in this Agreement, the applicable term or condition
of this Agreement will prevail and such additional, contrary or different terms will have no force
or effect. Except for such additional and contrary terms, the terms and conditions of all Purchase
Orders are incorporated by reference into this Agreement for all applicable purposes hereunder.
Without limitation of anything contained in this clause 2.2, any additional, contrary or different
terms contained in any Confirmation (as defined below) or any of Philips's invoices or other
communications between the Parties, and any other attempt to modify, supersede, supplement or
otherwise alter this Agreement, are deemed rejected by Customer and will not modify this Agreement
or be binding on the Parties unless such terms have been fully approved in a signed writing by
authorized by both Parties. 2.3 On the Effective Date, Philips (or its Affiliate, Philips Oy) is the
legal manufacturer of the Product. Customer hereby covenants and agrees to file with all applicable
notified bodies and Governmental Authorities, including but not limited to BSI, Notified Body and
ISO Registrar, on a jurisdiction-by-jurisdiction basis, within the applicable time periods for each
jurisdiction outlined in the "Transitional Service Level Agreement" (TSLA Number: QR01, TSLA Title:
Transfer of Legal Manufacturers), all documentation required or necessary to change the legal
manufacturer of the Product in each Required Jurisdiction from Philips Oy to Customer for all
applicable regulatory purposes. In order to expedite and achieve such change of legal manufacturer
and to achieve the required changes outlined in such Transitional Service Level Agreement, Customer
shall fully cooperate with as required by and actively facilitate the above registration process by
the applicable notified bodies and Governmental Authorities in each Required Jurisdiction. On a
jurisdiction-by-jurisdiction basis, from the date that the legal manufacturer is updated to Customer
in such jurisdiction, Philips will supply the Products in such jurisdiction as contract manufacturer
of Customer under this Agreement. 2.4 Philips shall provide such reasonable support, assistance and
information reasonably requested by Customer and as outlined in the above referenced Transitional
Service Level Agreement (including, to achieve the required changes outlined in such Transitional
Service Level Agreement) in connection with Customer's transfer of the registrations in respect of
the Product from Philips to Customer (as contemplated by clause 2.3 above), including, those
services outlined in the Transitional Service Level Agreement, participating in any meeting with the
applicable Governmental Authority reasonably requested by Customer and subject to the limitations
and the obligations of the Parties under the "Transitional Service Level Agreement" (TSLA Number:
QR01, TSLA Title: Transfer of Legal Manufacturers) concluded by the Parties in conjunction with the
Purchasing Agreement. 3. DELIVERY CAPACITY, FORECAST 3.1 Philips shall maintain a delivery capacity,
which allows Philips to deliver the Products in accordance with the Lead Times, Forecasts and
Purchase Orders, but always subject to the supply limitations, if any, outlined in the Production
Plan. Such Production Plan may be updated, and the production capacity may be increased only by the
Parties' written agreement and any reasonable additional incremental (and documented) investment
required to exclusively satisfy such increase shall be borne by Customer. Philips shall not be held
liable for rejecting any Purchase Order through which the volume in any Contract Year or the
relevant quarter exceeds the volume indicated in the Production Plan.

- 7 -
<!-- page 8 -->
3.2 Customer shall provide Philips in good faith on a monthly basis, on the later of (i) seven (7)
days prior to the beginning of each calendar month a rolling [Redacted - Commercially Sensitive]
forecast for the Products (including the major configuration of each Product such as field strength)
("Forecast") it expects to purchase during such [Redacted - Commercially Sensitive] period. Such
Forecast shall be provided in writing or in any other mutually agreed manner of communication (e.g.,
EDI or email). Notwithstanding any other obligation set forth herein, Customer shall give Philips at
least [Redacted - Commercially Sensitive] prior written notice if, during the Term, it intends to
discontinue the purchase of any Products hereunder, or if it intends to substantially decrease,
versus the Forecast, its purchase demand hereunder. For greater certainty, if Philips (or an
Affiliate of Philips) is delayed in delivering any "Forecast" contemplated by the RPA, the
Customer's obligations to deliver the Forecast hereunder (solely in respect of that portion of the
Forecast that corresponds to the volume of Product to be sold to Philips (or an Affiliate of
Philips) pursuant to the RPA) shall be tolled until Philips (or an Affiliate of Philips) delivers
the corresponding "Forecast" under the RPA. 3.3 Notwithstanding Customer's obligations pursuant to
clauses 3.1 and 3.4, the first [Redacted - Commercially Sensitive] of each Forecast shall constitute
a binding commitment of Customer to purchase the quantities of Products set forth in the relevant
Forecast for such [Redacted - Commercially Sensitive] period. The Forecast for the period beyond
this two (2) month period shall be non-binding except to the extent otherwise provided in clause
3.4. Only Purchase Orders as accepted by Philips, as set forth in clause 3.4 below, constitute an
obligation for Philips to actually produce the so ordered Products and no quantities of Products in
the Forecast provided by Customer shall constitute an accepted Purchase Order. 3.4 Customer shall
have the right to increase or decrease, as the case may be, the [Redacted- Commercially Sensitive]
Forecast only within the limitations set forth in the Production Plan per quarter. 3.5 The
reasonable and documented costs of all materials, parts and components which have been purchased and
paid for by Philips in order to meet Customer's demand as may be concluded, based on the historical
operations of Philips in the ordinary course of business, on the basis of Customer's Forecast, shall
be reimbursed, at inventory value without additional mark up by Customer against invoice in
accordance with the payment terms of this Agreement in such instance where any such materials are
not used in the production of any Products to meet any Purchase Orders of Customer within [Redacted
- Commercially Sensitive] of the purchase of such materials. The same reimbursement obligation shall
apply at the end of the Term for materials, parts and components then available at Philips. Such
materials, parts and/or components shall be delivered to Customer [Redacted - Commercially
Sensitive]. Upon payment the title of the materials, parts and/or components shall transfer to
Customer.

- 8 -
<!-- page 9 -->
4. PURCHASE ORDERS 4.1 Customer shall place Purchase Orders in writing (or any other mutually agreed
manner of communication, e.g. email or EDI) within the Lead-Time and in accordance with the Forecast
provided to Philips in accordance with clause 3. 4.2 Each Purchase Order shall be given in writing
(or such other manner of communication (e-mail) as may be mutually agreed from time to time) and
shall specify: (a) Purchase Order number; (b) the type (including Product name and codes) and
quantity of Products ordered; (c) the requested date of Delivery; (d) destination - ship to address;
(e) the services ordered for the ordered Product; and (f) such other information as Philips may
reasonably request from time to time. 4.3 No Purchase Order shall be deemed to be accepted by
Philips until accepted in writing (including by email or another agreed manner of communication) by
Philips or as otherwise contemplated by clause 4.4 below. Philips shall not reject any Purchase
Order which is placed in accordance with the Forecast, the Lead Time and otherwise in accordance
with this Agreement, unless Philips is entitled to reject on the basis of clause 3.1 or 4.4. 4.4
Philips shall confirm to Customer the receipt of each Purchase Order issued hereunder (each, a
"Confirmation") within seven (7) days following Philips's receipt thereof in writing or in any other
mutually agreed manner of communication (e.g., EDI or email). Each Confirmation must reference
Customer's Purchase Order number, confirm acceptance of the Purchase Order, include a confirmed date
of Delivery (which may differ from the requested one in the Purchase Order) or, solely if permitted
under this clause 4.4, advise Customer of Philips's rejection of such Purchase Order, the date of
acceptance or rejection and the basis for rejection, if applicable. If Philips commences performance
under such Purchase Order, Philips will be deemed to have accepted the Purchase Order. Customer may
withdraw any Purchase Order prior to Philips' acceptance thereof. Philips may only reject a Purchase
Order if (a) the quantity ordered by Customer in such Purchase Order is inconsistent with the
quantity in the applicable Forecast in accordance with clause 3.2 (as amended pursuant to clause
3.4), (b) Philips has sent Customer a Notice of termination pursuant to clause 12 or (c) the
applicable Purchase Order includes terms and conditions that supplement those contained in this
Agreement, which Philips is unwilling to accept. Philips may not cancel any previously accepted
Purchase Order hereunder. Customer may not cancel a previously accepted Purchase Order .

- 9 -
<!-- page 10 -->
5. DELIVERY, TRANSFER OF RISK AND OWNERSHIP 5.1 [Redacted - Commercially Sensitive - Delivery
Details] 5.2 If Customer fails to take Delivery of ordered Products at the date of Delivery
acknowledged by Philips, then Philips may deliver the Products in consignment and at Customer's risk
and cost. 5.3 Philips will manufacture, handle, properly pack, mark and ship the Products in
accordance with Customer's instructions provided to Philips in writing as part of the Device Master
Record ("DMR") or as otherwise set forth in the Quality Agreement. The purchase price for the
Product includes the costs of packaging as defined in the DMR, but any additional costs resulting
from compliance with non-standard packaging specifications (i.e., different from as defined in the
DMR) shall be added to the Price. 5.4 [Redacted - Commercially Sensitive - Delivery Details] 6.
PRICE AND PAYMENT 6.1 Prices are exclusive of any federal, state or local sales, use or excise taxes
and any, value added tax imposed solely as a result of the sale and transfer of the Products (VAT).
Philips will list separately on its invoice any tax lawfully applicable to the relevant Purchase
Order and payable by Customer, if any, with respect to which Customer does not furnish evidence of
exemption. Philips is responsible for remitting any applicable VAT, sales tax, consumption tax, or
any other similar tax, in each instance, that were charged to Customer under an applicable Purchase
Order, to the appropriate tax authorities in accordance with applicable Laws and required timelines.
Philips will issue an invoice containing wording that will allow Customer to take advantage of any
applicable "input" tax deduction. 6.2 Purchase prices for the Products are set out in Schedule 1.
Prices are firm and fixed for the Term and shall include all costs for work performed, Delivery
according to this Agreement and packaging as set forth in clause 5.3 above. 6.3 Any invoices
provided by Philips shall refer to the Purchase Order number and any other details required by
applicable Law. Philips shall invoice for the purchase prices set out in Schedule 1 on or at any
time after Delivery. 6.4 Philips invoices, compliant with the requirements of this Agreement, will
be payable within [Redacted - Commercially Sensitive] following the end of the month of the date of
invoice. Customer shall make all payments in Euros by check, wire transfer or automated clearing
house to the bank account designated by Philips. 6.5 [Redacted - Commercially Sensitive - Late
Payment Details] 6.6 [Redacted - Commercially Sensitive]

- 10 -
<!-- page 11 -->
7. CONFORMITY OF PRODUCTS 7.1 Philips represents and warrants to Customer that all Products
delivered and any services provided hereunder: i. conform to the Specifications on the Delivery Date
[Redacted - Commercially Sensitive]; ii. unless otherwise agreed with Customer in writing, are new
(do not contain any used or reconditioned parts or materials) and fit for the purposes for which
they are intended; iii. are of sound workmanship, good quality and free from defects in
construction, manufacture and material [Redacted - Commercially Sensitive]; iv. the manufacturing
and shipment of the Product comply in all respects with applicable Laws, regulations, certification
requirements, including health and safety standards and all other applicable regulatory requirements
for the manufacture and shipment of Products; v. are free and clear of all liens, encumbrances, and
other Claims against title; and vii. comply in all respects with the terms of this Agreement and the
applicable Purchase Orders. 7.2 [Redacted - Commercially Sensitive] 7.3 [Redacted - Commercially
Sensitive] the foregoing warranties will survive any inspection, delivery, acceptance, or payment by
Customer and will be enforceable by Customer and its Affiliates, and their successors, assigns,
subcontractors, distributors, dealers, agents and customers and all other entities combining,
selling or using Products or goods into which Products have been incorporated (together, the
"Customer Parties"), for the period set forth in clause 7.4. 7.4 Without prejudice to any other
rights accruing under this Agreement or law, the warranties set forth in clause 7.1 will extend for
a period of [Redacted - Commercially Sensitive - Warranty Details]. Products repaired or replaced by
Philips within the Warranty Term are warranted for the remainder of the original Warranty Term of
said Products. 7.5 In respect of failure to meet the Specifications, if Products do not comply with
the warranties set forth in clause 7.1, Customer may then, after having consulted Philips as to the
most appropriate remedy, elect reasonably to have Products: i. returned to Philips for repair or
replacement; ii. repaired or replaced by Philips in the field; or iii. repaired or replaced by
Customer in the field, including Products in distributor inventory and Customer's installed base; or

- 11 -
<!-- page 12 -->
iv. returned to Philips in exchange for a full refund of the purchase price for the non-conforming
Products paid under this Agreement. 7.6 Philips will bear all costs, including transportation and
labor costs, in connection with the repair or replacement of, and all other costs or damages
Customer may incur as a result of Products not complying with clause 7.1. If Philips agrees that
Customer performs the repair, Philips will provide Customer free of charge with any replacement
Product or upgrade necessary, and will reimburse Customer for all costs relating to such repair,
including any related labor costs. 7.7 If Customer or any relevant Governmental Authority determines
that a recall campaign is necessary, Customer will implement such recall campaign at Customer's sole
cost and risk. Customer hereby covenants and agrees that it shall bear all costs and expenses
related to the implementation of any such recall. In case of a recall of the Product, Philips shall
at its sole cost provide full cooperation to Customer in order to achieve an efficient and effective
recall by Customer. Philips shall provide such cooperation at its own costs, including internal
organizational costs but not including the costs of repair, replacement, installation of Products
and logistics related to the recall [Redacted - Commercially Sensitive]. For greater certainty, the
obligations of the Parties pursuant to this clause 7.6 shall only apply in respect of Products sold
or distributed on or after the Effective Date, and for clarity, to thwe extent there is a recall
that involves any Product sold or distributed prior to the Effective Date, the covenants and
obligations of the Parties pursuant to this clause 7.6 shall not apply (and shall be addressed by
the terms of the Purchase Agreement). 7.8 [Redacted - Commercially Sensitive - Warranty Details] 8.
QUALITY AND REGULATORY AND COMPLIANCE WITH LAWS 8.1 The Parties have entered into a Quality
Agreement on or around the Effective Date, detailing Customer's requirements, as the legal
manufacturer of the Product, with respect to the manufacturing of the Product by Philips as the
contract manufacturer. . The Quality Agreement is deemed to be incorporated into this Agreement by
reference and made a part hereof, and to the extent of a conflict between the terms of the Quality
Agreement and this Agreement, the terms and provisions of this Agreement shall prevail. 8.2 Until,
on a jurisdiction by jurisdiction basis, the Regulatory Transfer Date, Philips shall (a) remain the
legal manufacturer of the Product according to its own quality management systems. (b) comply, in
all material respects, with all applicable Laws, Philips' operation of its business and the exercise
of its rights and performance of its obligations hereunder (including, the manufacture of the
Product). Without limitation of the foregoing, Philips shall ensure the Product is manufactured in
accordance with applicable Laws.

- 12 -
<!-- page 13 -->
(c) obtain and maintain all Permits necessary for the exercise of its rights and performance of
Philips' obligations under this Agreement, including any Permits required for the manufacture of the
Product and the import or any materials and other manufacturing parts used in the production and
manufacture of the Product, and the shipment of hazardous materials, as applicable. For purposes of
this Agreement, "Permit" means any permits, licenses, franchises, approvals, authorizations,
registrations, certificates, variances and similar rights obtained or required to be obtained, from
any Governmental Authority. 9. CHANGES TO PRODUCT 9.1 Any changes to the Product proposed by Philips
shall be discussed and handled by the Parties as described in the Quality Agreement. Until execution
of the Quality Agreement, the provisions of this clause 9 shall apply. 9.2 Philips shall be entitled
to make changes to the Products to comply only with any applicable Laws. Without prejudice to the
foregoing, it is understood and agreed that Customer (and not Philips) shall be responsible to
notify Philips of any changes required to comply with any applicable Laws, as long as such
applicable Laws concern the Products. 9.3 Customer may reasonably request and Philips may propose,
in writing, that Philips makes a change to the method of packing, a change to the packaging, or the
Products. Such request or proposal (as applicable) will include a description of the
requested/proposed change sufficient to allow Philips, using commercially reasonable efforts, to
evaluate the feasibility and impact on costs and other terms of such requested change, it being
understood that Customer shall pay for any reasonable incremental and documented costs incurred by
Philips in connection with such evaluation. All such changes are subject to Philips's written
approval (and in case of a change proposal by Philips, Customer's written approval), which cannot
unreasonably withheld, conditioned or delayed, it being understood that, if technically feasible and
commercially reasonable, Philips shall make any changes required to comply with any applicable Laws
upon Customer's written request. Philips will not be obligated to agree or accept any such request
for a change nor to proceed with the requested change until the Parties have mutually agreed upon
the changes to the Product's Specifications, the price, the implementation costs to be borne by
Customer including, without limitation, development and other non-recurring expenses, the cost of
inventory and materials that may become obsolete, and any other terms of this Agreement. 9.4 The
incremental and documented costs of any changes (including any non-recurring costs such as
development and re-engineering costs, as well as costs of changes to the tools used to manufacture
the changed Products) shall be borne by Customer. All such charges will be charged to Customer at
cost, without any additional markup. 10. INDEMNIFICATION AND LIMITATION OF LIABILITY 10.1
Indemnification by Philips (i) Philips will defend, indemnify and hold harmless Customer and its
Affiliates and their respective directors, officers, employees and agents, and their successors,
heirs and assigns (the "Customer Indemnitees") from and against all liabilities, costs, damages,
Claims and expenses, including reasonable attorney's fees, arising from or related to any actual or
alleged [Redacted - Commercially Sensitive - Indemnification Details].

- 13 -
<!-- page 14 -->
(ii) Customer will defend, indemnify and hold harmless Philips and its Affiliates and their
respective directors, officers, employees and agents, and their successors, heirs and assigns (the
"Philips Indemnitees") from and against all liabilities, costs, damages, Claims and expenses,
including reasonable attorney's fees, arising from or related to any actual or alleged [Redacted -
Commercially Sensitive - Indemnification Details] 10.2 [Redacted - Commercially Sensitive -
Indemnification Details] 10.3 [Redacted - Commercially Sensitive - Indemnification Details] 10.4 The
limitations and exclusions set forth above in this clause 10 shall apply to the fullest extent
permitted by applicable Law. 11. TOOLS 11.1 The Parties will conclude contract(s) managing the
ownership and use of tools and equipment needed for the manufacturing of the Products. 12. TERM AND
TERMINATION AND TRANSITION 12.1 This Agreement shall come into force on the Effective Date and shall
remain in force and effect for a period of [Redacted - Commercially Sensitive - Term Details] ,
unless this Agreement is extended or previously terminated in accordance with this clause 12,
pursuant to clause 15.1 (Force Majeure), or (ii) by the mutual written consent of the Parties (the
"Term"). 12.2 Customer, in its sole discretion, may terminate this Agreement, without cause, by
providing six (6) months prior written notice to Philips. Philips may terminate this Agreement with
immediate effect by written notice to Customer, should Customer not have filed with the specified
bodies to transfer the applicable registrations within the time period specified in clause 2.3. 12.3
Without prejudice to any other right or remedy a Party may have against the other Party for breach
or non-performance of this Agreement, Each Party may suspend performance of its obligations under
the Agreement or terminate this Agreement upon written notice to the other Party if: (a) the other
Party files a voluntary petition in bankruptcy or any voluntary proceeding relating to insolvency,
receivership, liquidation, assignment for the benefit of creditors or similar proceeding; (b) the
other Party becomes the subject of a petition in bankruptcy or any proceeding relating to
insolvency, receivership, liquidation, assignment for the benefit of creditors or similar proceeding
and such petition or proceeding is not dismissed within thirty (30) days from filing of such
petition or proceeding;

- 14 -
<!-- page 15 -->
(c) the other Party materially breaches any of its obligations under the Agreement, and the
breaching failures to cure such breach within [Redacted - Commercial Sensitive - Termination Timing]
after it receives written notice from the non-breaching Party to cure same; (d) [Redacted -
Commercially Sensitive - Termination Timing] (e) conviction of, or commission by, the other Party or
any principal officer, shareholder, employee or any partner of the other Party of any crime or
immoral act which may adversely affect the goodwill or reputation of Customer or Philips; 12.4 If
Philips causes the Agreement to be terminated, directly or indirectly, then Philips undertakes to
sell all Products which have been ordered by Customer but not yet delivered at the date of
termination upon the terms and conditions of this Agreement. 12.5 On termination or expiry of this
Agreement, each Party shall promptly: (a) return to the other Party all equipment, materials and
property belonging to the other Party that the other Party had supplied to the other Party (or its
Affiliates) in connection with the supply and purchase of the Products under this Agreement; (b)
cooperate with the other Party to arrange for the sale and purchase of the materials, parts and
components as referred to in clause 3.4; (c) return to the other Party all documents and materials
(and any copies) containing the other party's Confidential Information; (d) erase all the other
party's Confidential Information from its computer systems (to the extent possible); and (e) on
request, certify in writing to the other Party that it has complied with the requirements of this
clause. On termination or expiry of this Agreement Philips shall facilitate an orderly transition of
suppliers from Philips to Customer in accordance with the requirements outlined in Section 5.4
(Material Supplier Contracts) of the Purchase Agreement, including using commercially reasonable
best efforts to assist Customer to enter into supply agreements directly with the counterparties to
the Material Supplier Contracts (as defined in the Purchase Agreement) on terms that are
satisfactory to the Customer, acting reasonably.

- 15 -
<!-- page 16 -->
12.6 Termination of this Agreement in accordance with this clause 12, is without prejudice to any
right to claim for amounts or interest accrued prior to the date of such termination under this
Agreement. 12.7 All terms and conditions of this Agreement which are intended (whether expressed or
not) to survive the duration or termination of this Agreement will so survive, including, for
greater certainty, clauses 2.3, 2.4, 6, 10, 12, 13, 14, and 18. 12.8 Within [Redacted - Commercially
Sensitive - Time Period] of the Effective Date, the parties shall negotiate, acting reasonably and
in good faith, a transition plan (the "Transition Plan") to provide for a smooth transfer and
transition of the manufacturing activities under this Agreement to Customer, an Affiliate of
Customer or a third party manufacturer designated by Customer. The Transition Plan shall be
negotiated based on the key transition terms outlined in Schedule 5 hereto (the "Transition Plan
Term Sheet"). In connection with the negotiation and ultimately implementation of the Transition
Plan, Parties shall install a project team which: (a) shall have a manager ("Project Manager"), one
from Philips, who has experience in transferring manufacturing actives, and one from Customer, who
has experience in setting up manufacturing activities; (b) shall be committed with sufficient
capacity - made available by both Parties - to execute the Transition Plan within the given time
frame (quantity), and the Parties shall ensure that sufficient and reasonable organizational
resources are provided to each such Project Manager to ensure a smooth, uninterrupted and efficient
transition of the manufacturing of the Product; (c) shall be sufficiently skilled and experienced
with the activities under this Agreement (quality); (d) shall be fully dedicated to the timely and
adequate execution of the Transition Plan. 12.9 The Parties shall perform such activities as set
forth in the Transition Plan and shall otherwise perform all such obligations in good faith to
ensure a smooth transfer of the manufacturing activities under this Agreement to Customer. In
connection with the Transition Plan, Customer will pay all reasonable freight cost and any Philips'
employee (or third parties engaged by Philips) at [Redacted - Commercial Sensitive - Billing Rate],
as needed, in connection with the implementation of the Transition Plan. For greater certainty,
Philips will only engage third party support to assist with the transition if such additional
support is required in order to implement the Transition Plan and such additional support is
previously approved by Customer in writing (not to be unreasonably withheld). If to the opinion of
the Project Team, circumstances occur in which the timely and/or proper execution of the Transition
Plan is obstructed, this shall be immediately reported to the relevant executive officers of both
Parties for immediate resolution.

- 16 -
<!-- page 17 -->
13. INTELLECTUAL PROPERTY RIGHTS 13.1 Customer grants to Philips, during the Term, a non-exclusive,
royalty-free, non-transferrable right to make, have made, use, sell, reproduce, adapt, distribute,
or otherwise use or practice Customer's Intellectual Property Rights solely in connection with
manufacturing of the Products and packaging to Customer pursuant to this Agreement. 13.2 Customer
represents and warrants that any Product manufactured by Philips under this Agreement in accordance
with the Specifications does not infringe, misappropriate, or otherwise violate any third party
Intellectual Property Rights. 13.3 All right, title and interest in any and all Intellectual
Property Rights and Know How resulting or based on any services by Philips or its Affiliates
hereunder or enhancements carried out or technology developed during manufacture of the Products and
that relate specifically and solely to the manufacture of the Product ("New Technology"), in each
case, that were developed for the Product, will be owned exclusively by Customer. Philips hereby
assigns and shall cause its Affiliates to assign all right title and interest in New Technology to
Customer, and shall cause all employees or service providers to assign all right title and interest
and waive any moral rights in New Technology. For greater certainty, "New Technology" shall exclude
any (x) modification to Philips pre-existing Intellectual Property Rights (which, shall exclude any
Intellectual Property Rights forming part of the "Purchased Assets" under the Purchase Agreement)
and (y) developments developed not for the Products (collectively, "Philips Retained Product IP'),
provided that Philips and its Affiliates hereby grant to Customer under any such Intellectual
Property Rights, which are applicable or used for the manufacturing of the Product, a non-
exclusive, non-transferable (except in accordance with clause 18.4 (Assignment)), irrevocable,
world-wide, fully paid-up license, without the right to grant sub-licenses, to make, have made, sell
or commercialize in any other way the Product. 13.4 The sale of any Products under this Agreement
shall not constitute the transfer of any ownership rights or title in any Intellectual Property
Rights or Know How in or to such Products. 14. CONFIDENTIALITY 14.1 Confidential Information may be
disclosed by or on behalf of a Party or its Affiliates (the "Disclosing Party") to the other Party
or its Affiliates (the "Receiving Party") in connection with this Agreement. Each Party agrees to
keep the other Party's (and its Affiliates) Confidential Information confidential and not to
reproduce or disclose such Confidential Information to any third party, or to use it for any purpose
other purpose than for the purposes of this Agreement. Each Party shall protect any Confidential
Information of the other Party (and its Affiliates) with the same degree of care used in protecting
its own Confidential Information, but no less than a reasonable degree of care. Unless otherwise
mutually agreed in writing, the Confidential Information shall remain the property of the Disclosing
Party. Each party's obligation to protect the Confidential Information of the other Party shall
continue for a period of [Redacted - Commercial Sensitive - Time Period] following the date of
termination of this Agreement.

- 17 -
<!-- page 18 -->
14.2 Each Party may disclose the other Party's Confidential Information to its and its Affiliates'
employees, officers, lawyers, accountants, professional advisers, consultants and sub-contractors
(collectively, "Representatives") or financing sources (both debt and equity) or any prospective
acquirer of a Party (or substantially all of the assets related to the Products)(collectively,
"Other Recipients") on a strict need to know basis, provided that such Representatives and Other
Recipients are subject to confidentiality obligations and/or agreements at least as stringent as the
confidentiality restrictions imposed by this clause 14 on the Receiving Party. 14.3 The
confidentiality obligations set out in this clause 14 shall not apply to any information (but only
to the extent that such information) and the definition of "Confidential Information" shall not be
deemed to include any information that: (a) is generally available from public sources or in the
public domain through no fault or breach of the Receiving Party or any of its Representatives; (b)
becomes available to the Receiving Party (or any of its Affiliates) unless the Receiving Party (or
such Affiliate) is aware that such source was bound by a confidentiality agreement with the
Disclosing Party or any or its Representatives or otherwise under a contractual, legal, fiduciary or
other obligation of confidentiality with respect such information; (c) developed independently by
the Receiving Party or any of its Affiliates without use of or reliance on the Disclosing Party's
(or any of its Affiliates') Confidential Information as demonstrated by written records; or (d) was
known or in the possession of the Receiving Party (or any of its Affiliates) prior to its disclosure
by the Disclosing Party unless the Receiving Party (or such Affiliate) is aware that the source of
such information was bound by a confidentiality undertaking to the Disclosing Party (or its
Affiliates) or any or its Representatives or otherwise under a contractual, legal, fiduciary or
other obligation of confidentiality with respect to such information.

- 18 -
<!-- page 19 -->
14.4 Notwithstanding any of the carve outs to the definition of "Confidential Information" contained
in clause 14.3, any Confidential Information in respect of the "Purchased Assets" and the "Business"
(each, as defined under the Purchase Agreement) shall be deemed the Confidential Information of
Customer (the "Transferred Confidential Information"), and, in respect of Philips, the carve out to
the definition of "Confidential Information" contained in clause 14.3 shall not apply to any
Transferred Confidential Information, notwithstanding the fact that Philips was aware, had
possession of, or independently developed any such Transferred Confidential Information prior to the
Effective Date 14.5 Clause 14 does not prohibit disclosure or use of any Confidential Information if
and to the extent that the disclosure or use is required by applicable Law, any judicial or
administrative proceedings, or the rules of any recognized stock exchange on which the shares of any
Party are listed, provided that prior to such disclosure, the Receiving Party promptly notifies the
Disclosing Party of such requirement with a view to providing the Disclosing Party with the
opportunity to contest such disclosure or use and/or to obtain a protective order or otherwise to
agree to the timing and content of such disclosure or use and the Receiving Party shall at the
request of the Disclosing Party, assist the Disclosing Party in contesting such disclosure and/or
obtaining a protective order; provided further that the Receiving Party shall only disclose such
portions of the Confidential Information that are strictly required to be disclosed by applicable
Law, and if permitted by applicable Law, the Disclosing Party shall be provided with the opportunity
to review and comment on the disclosure to be made. 14.6 Each Party reserves all rights in its and
its Affiliates' Confidential Information. No rights or obligations in respect of a Party's
Confidential Information other than those expressly stated in this Agreement are granted to the
other Party or to be implied from this Agreement. Each Party, and its Representatives shall protect
and keep confidential and shall not use, publish or otherwise disclose to any Third Party, except as
permitted by this Agreement, or with the other Party's written consent, the other Disclosing Party's
Confidential Information. 15. FORCE MAJEURE Notwithstanding any provision to the contrary contained
in this Agreement, the Parties shall be excused from the consequences of any breach of this
Agreement if and to the extent that such breach was caused in whole or in part by a Force Majeure
event, provided that (a) the affected Party shall not in any material way have caused or contributed
to such Force Majeure event, (b) the Force Majeure event could not have been prevented by reasonable
and ordinary precautions (as would be employed by a reasonably prudent person in the position of the
affected party), and (c) the Force Majeure event could not reasonably have been circumvented by the
affected Party by reasonable and ordinary commercial means, such as the use of alternate suppliers
or subcontractors. Notwithstanding the foregoing: (a) the existence or occurrence of a Force Majeure
event shall excuse a breach of this Agreement only for such period of time as the Force Majeure
event remains in existence and only to the extent that such Force Majeure event has caused in whole
or in part the breach of this Agreement;

- 19 -
<!-- page 20 -->
(b) the existence of a Force Majeure event that has caused a breach of this Agreement shall not
prevent a Party from asserting and acting upon a breach of this Agreement that has not been caused
by a Force Majeure event; (c) If a Party is not or is not expected to be able to perform any
material obligation under this Agreement due to a Force Majeure event for a period of [Redacted -
Commercial Sensitive - Time Period] or more, the other Party may terminate this Agreement without
liability. (d) Notwithstanding the foregoing, Customer may cancel without liability any affected
Purchase Orders if the Force Majeure event would result in a delay in delivery of more than
[Redacted - Commercial Sensitive - Time Period]. For the purposes of this clause 15, "Force Majeure"
means any prevention, delay, stoppage or interruption in the performance of any obligation or the
occurrence of any event due to an act of God, the occurrence of enemy or hostile actions, sabotage,
war, blockades, terrorist attacks, insurrections, riots, epidemics, nuclear and radiation activity
or fall-out, civil disturbances, explosions, fire or other casualty, failure of energy sources, any
industry-wide material shortage and changes in governmental or regulatory action or legislation or
regulation, third party labour disputes or strikes or any other similar causes beyond the control of
the Party seeking relief from its obligations as a result of such event, but not including, for
clarity, any financial inability of Philips or any of its Affiliates or the failure of any
subcontractor to perform obligations owed to Philips unless when those are caused by Force Majeure.
16. EXPORT CONTROL 16.1 Customer understands that certain transactions of Philips are subject to
export control Laws and regulations, such as but not limited to the UN, EU and the USA export
control Laws and regulations, ("Export Regulations") which prohibit export or diversion of certain
products and technology to certain countries. Any and all obligations of Philips to export,
re-export or transfer Products as well as any technical assistance, training, investments, financial
assistance, financing and brokering will be subject in all respects to such Export Regulations and
will from time to time govern the license and Delivery of Products and technology abroad by persons
subject to the jurisdiction of the relevant authorities responsible for such Export Regulations. If
the Delivery of Products, services and/or documentation is subject to the granting of an export or
import license by certain governmental authorities or otherwise restricted or prohibited due to
export/import control regulations, Philips may suspend its obligations and Customer's and/or
end-user's rights until such license is granted or for the duration of such restrictions or
prohibitions. Furthermore, Philips may even terminate the relevant order in all cases without
incurring any liability towards Customer or end-user. 16.2 Philips undertakes to provide Customer on
request and in a timely fashion, with the following information in relation to the Products: (a) The
country of origin of items to be supplied; and

- 20 -
<!-- page 21 -->
(b) The applicable export control classification number of items known by Philips to be so subject
to control. 16.3 Each Party will provide the other with reasonable assistance when applying for
export licences for the Product. 16.4 Customer warrants that it will comply in all respects with the
export, re-export and transfer restrictions set forth in such Export Regulations or in export
licenses (if any) for every Product. Customer will not re-export the Product to any Third Parties
unless Customer first obtains the same warranty as Customer is providing in the first sentence of
this clause 16.4 from such third party. 16.5 Customer shall take all commercially reasonable actions
in a manner consistent with industry practice, that are within its reasonable control to help
minimize the risk of a customer/purchaser or end-user contravening such Export Regulations. 17.
REGULATORY MATTERS Until execution of the Quality Agreement, the following provision shall govern
the regulatory aspects of the activities under this Agreement. 17.1 Regulatory Actions Customer and
Philips agree to notify each other within two (2) Business Days of any regulatory action affecting
the Product. 17.2 Government Inspections, Compliance Review and Inquiries Upon request of any
Governmental Authority or any third party entity authorized by a Governmental Authority, such entity
shall, for the purpose of regulatory review and compliance, have access to observe and inspect the:
(i) facilities of Philips; and (ii) manufacturing, testing, storage and preparation for shipment of
Product, including development operations in respect of manufacturing, and auditing the Philips
facility for compliance with applicable Laws. Philips shall give Customer prompt written notice of
any upcoming inspections or audits by a Governmental Authority, governmental entity or any third
party entity authorized by a Governmental Authority of the Philips facility or any of the foregoing,
shall provide Customer with a written summary of such inspection or audit within five (5) Business
Days following completion thereof. Philips agrees to use commercially reasonable efforts to promptly
rectify or resolve any deficiencies (consisting of any failure to meet applicable regulatory
requirements under applicable Law then in force) noted by a Governmental Authority, governmental
entity or any third party entity authorized by a Governmental Authority in a report or
correspondence issued to Philips or Customer. Subject to any specific arrangements agreed upon by
the parties and subject to any limitations due to the fact (and until) Philips is the legal
manufacturer, Customer shall be responsible for communicating with any Governmental Authority
concerning the Product or the marketing, distribution, sale use of the Product, and Philips shall
provide Customer with such assistance as Customer may reasonably require to assist it in such
communications. Philips shall have no such communications specifically related to the Product,
except to the extent (and notwithstanding its confidentiality undertakings in this Agreement) that
they relate to Philips's manufacture, testing, storage and preparation for shipment of Product under
this Agreement or as required of Philips directly by the Governmental Authority (including but not
limited to due to the fact (and until) Philips is the legal manufacturer of the Product), in which
case Philips shall be responsible for such communications. Notwithstanding the foregoing and except
to the extent that an immediate or urgent communication is necessary under the circumstances or
required by applicable Law, Philips in good faith shall consult in advance with Customer regarding
all communications with any Governmental Authority that relate to Product or to Philips' ability to
manufacture the Product pursuant to this Agreement.

- 21 -
<!-- page 22 -->
17.3 Complaints and Adverse Events Philips and Customer shall fully comply with the terms of the
Quality Agreement regarding their respective obligations and responsibilities with respect to any
complaints or adverse events regarding the Product and other activities related to this Agreement.
17.4 Records Philips shall maintain, and provide Customer reasonable access to, all records, both
during and after the termination or expiration of this Agreement, in accordance with the Quality
Agreement. The cost of any off-site storage of such records after the Term of this Agreement shall
be borne by Customer and invoiced on a calendar quarter basis. After the Term, Customer may elect to
have such records delivered to it upon reimbursing Philips for its reasonable costs of such
transfer. 17.5 Testing, Documentation, and Quality Assurance Philips shall maintain, and provide
Customer reasonable access to, accurate and complete production records with respect to the
manufacture of the Product in accordance with the Quality Agreement. The Parties agree to execute,
and shall comply with their respective obligations and duties set forth in, the Quality Agreement.
To the extent that there is any conflict between the terms of this Agreement and the Quality
Agreement, the terms of this Agreement shall govern. 17.6 Cooperation as to Adverse Events, Product
Inquiries and Recalls Each Party shall provide to each other in a timely manner all information
which the other party reasonably requests regarding the Product in order to enable the other party
to comply with all applicable Laws. Without limiting the foregoing, each Party will cooperate fully
with the other party in connection with any recall efforts and mandatory problem reporting to
Governmental Authorities as more fully detailed in the Quality Agreement.

- 22 -
<!-- page 23 -->
18. MISCELLANEOUS 18.1 Entire Agreement This Agreement, together with the Quality Agreement and the
Purchase Order, contains the entire agreement between the Parties relating to the subject matter of
this Agreement, to the exclusion of any terms implied by applicable Law which may be excluded by
contract, and supersedes any previous written or oral agreement between the Parties in relation to
the matters dealt with in this Agreement. Each Party acknowledges that it has not been induced to
enter into this Agreement by any representation, warranty or undertaking not expressly set out in
this Agreement. 18.2 Severability If any provision in this Agreement is held to be illegal, invalid
or unenforceable, in whole or in part, under any applicable Law, then: (a) such provision or part
shall to that extent be deemed not to form part of this Agreement but the legality, validity or
enforceability of the remainder of this Agreement shall not be affected; (b) the Parties shall use
reasonable efforts to agree a replacement provision that is legal, valid and enforceable to achieve
so far as possible the intended effect of the illegal, invalid or unenforceable provision. 18.3
Notices Any notice or other communication required or permitted to be given to any Party hereunder
shall be in writing and shall be given to such Party at such Party's address set forth below, or
such other address as such Party may hereafter specify by notice in writing to the other Party. Any
such notice or other communication shall be addressed as aforesaid and given by: (a) delivered
personally; (b) sent by an internationally recognized overnight courier service such as Federal
Express; or (c) e-mail transmission, Philips' details: PHILIPS MEDICAL SYSTEMS NEDERLAND B.V.
Address: PHILIPS MEDICAL SYSTEMS NEDERLAND B.V. P.O. Box 10.000 5680 DA Best, The Netherlands

- 23 -
<!-- page 24 -->
Attention: [Redacted - Personal Information], Operations Manager MR Best Email: [Redacted - Personal
Information] With copy to: Legal Department PMSN BV Veenpluis 4-6 5684 PC Best Building QX2 Email:
The Company's details: PROFOUND MEDICAL INC. Address: Profound Medical Inc. 2400 Skymark Avenue,
Unit #6 Mississauga, ON, L4W 5K5, Canada Attention: Arun Menawat E-mail: [Redacted - Personal
Information] With copy to: Torys LLP Suite 3000, P.O. Box 270 79 Wellington Street West TD Centre
Toronto, ON M5K 1N2 Attention: Cheryl Reicin Any notice or other communication will be deemed to
have been duly given: (A) on the date of service if served personally; (B) on the Business Day after
delivery to an international overnight courier service, provided receipt of delivery has been
confirmed; or (C) on the date of transmission if sent via e-mail transmission, provided confirmation
of receipt is obtained promptly after completion of transmission and provided that transmission via
e-mail is followed promptly by delivery via one of the methods in Clause 18.3(a) or (b) above. 18.4
Assignment This Agreement will be binding upon and inure to the benefit of the Parties and their
respective successors and permitted assigns. This Agreement may not be assigned by either Party, in
whole or in part, to any Third Party without the prior written consent of the other Party, except
that either Party may assign this Agreement as a whole, and all of its rights and obligations
hereunder, without the consent of the other Party, but upon written notice to the other Party (a) to
an Affiliate, or (b) in case of a transfer of all, or substantially all, stock or assets of such
Party or the relevant business activity through which such Party acts in this Agreement to a Third
Party or to any partnership or other venture in which such business activity is to participate.
Except as provided above, without prior written consent of the other Party, any assignment or pledge
of rights under this Agreement by a Party to a Third Party shall have no effect vis-à-vis such Third
Party.

- 24 -
<!-- page 25 -->
18.5 Independent Contractors The Parties to this Agreement are independent contractors and nothing
in this Agreement shall operate to create a relationship of agency, partnership or employment
between the Parties and neither Party shall have any right or authority to act on behalf of the
other nor to bind the other by contract or otherwise (except as expressly permitted by the terms of
this Agreement). 18.6 Headings Headings used in this Agreement are for convenience only and shall
not affect the interpretation. 18.7 Amendments and Waiver No amendment of this Agreement shall be
effective unless such amendment is in writing and signed by or on behalf of each of the Parties. No
waiver of any provision of this Agreement shall be effective unless such waiver is in writing and
signed by or on behalf of the Party entitled to give such waiver. 18.8 Disputes and Applicable Law
This Agreement (including any dispute hereunder) and the documents to be entered into pursuant to
it, save as expressly otherwise provided therein, will be governed by and construed in accordance
with the Laws of the Netherlands. The applicability of the UN Convention on Contracts for the
International Sale of Goods (Vienna convention) is explicitly excluded. Any dispute arising out of
or in connection with this Agreement shall be resolved in the manner provided in Sections 12.1 and
12.2 of the Purchase Agreement. 18.9 Counterparts This Agreement may be executed in multiple
counterparts, each of which shall be deemed an original. Signatures submitted by facsimile and
electronically transmitted signatures as to which authenticity can reasonably be confirmed, shall be
valid. 18.10 Third Party Rights Save as expressly otherwise stated, this Agreement does not contain
a stipulation in favour of a Third Party.

- 25 -
<!-- page 26 -->
18.11 Costs Except as otherwise provided in this Agreement, all costs which a Party has incurred or
shall incur in preparing, concluding or performing this Agreement are for that Party's own account.
18.12 Insurance Philips shall fully comply with the terms of the Quality Agreement regarding its
obligations and responsibilities with respect to maintaining the required level of insurance. 18.13
Further Assurances Each Party shall at its own costs and expenses from time to time execute such
documents and perform such acts and things as the other Party may reasonably require to give the
other Party the full benefit of this Agreement.

- 26 -
<!-- page 27 -->
IN WITNESS WHEREOF, this Agreement has been duly executed and delivered by the duly authorized
representatives of the parties as of the dates set forth below. PHILIPS MEDICAL SYSTEMS PROFOUND
MEDICAL INC. NEDERLAND B.V. By: /s/ Iwald Mons By: /s/ Arun Menawat Name: Iwald Mons Name: Arun
Menawat Title: M&A Project Leader Title: Chief Executive Officer Date: July 31, 2017 Date: July 31,
2017
<!-- page 28 -->
[Redacted - Commercially Sensitive - Schedules concerning Product specifications, details, pricing,
lead times, production plan and transition details]
