<!-- page 1 -->
# Cooperation Agreement (2014 Amendment)
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2014-01-24 |
| Parties | Nanjing Tuniu Technology Co., Ltd. ("Party A"); Beijing Tuniu Technology Co., Ltd. ("Party B") |
| Source | CUAD v1 / TUNIUCORP_03_06_2014-EX-10-COOPERATION AGREEMENT |

Exhibit 10.4

COOPERATION AGREEMENT

(2014 Amendment)

This Cooperation Agreement (2014 Amendment) (this "Agreement") is entered into on January 24, 2014
in Beijing by and between:

(1) Nanjing Tuniu Technology Co., Ltd., with its registered address at 3-5/F Building No.6,
Southeast University Science Park, 6 Changjianghou Street, Xuanwu District, Nanjing and its legal
representative being Yu Dunde ("Party A");

(2) Beijing Tuniu Technology Co., Ltd., with its registered address at R1006 10/F Building No.4,
Yard No.1 of Shangdishi Street, Haidian District, Beijing and its legal representative being Yu
Dunde ("Party B").

WHEREAS

1. Party A is a company with exclusively domestic capital incorporated under the laws of the
People's Republic of China, mainly engaged in the internet-based sale, promotion of tour products,
room reservation and conference affairs services.

2. Party B is a limited liability company incorporated under the laws of the People's Republic of
China, mainly engaged in research and development of computer software technology, technology
transfer, technical consultancy and technical services, computer technology training, technical
services and business consultancy services in relation to the internet-based sale and promotion of
tour products.

3. Party A intends to authorize Party B to provide to Party A and its subsidiaries the technical
services and business consultancy services in relation to the internet-based sale and promotion of
tour products, including but not limited to development, operation, maintenance of internet
technology platform as well as consultancy services relating to sale and promotion of tour products
or cooperation provided by Party B in other forms as required under this Agreement, and Party B
agrees to accept such authorization.

4. After an amiable consideration, the Parties unanimously agree that the establishment of a
long-term and close cooperation relationship is in the best interests of the Parties and their
beneficiaries.

5. The Parties have entered into the Cooperation Agreement on September 17, 2008 in respect of the
aforementioned cooperative matters (the "Original Cooperation Agreement").
<!-- page 2 -->
The Parties unanimously agree to amend and restate the Original Cooperation Agreement through
friendly negotiation and the Original Cooperation Agreement is amended and restated as follows:

1. Business Cooperation

Party A and Party B unanimously agree that the proposed cooperation shall be the internet-based sale
and promotion of tour products conducted by Party A and its subsidiaries or other value-added
business carried out by Party A. Party B shall provide the business consultancy and technical
services as well as the technical consultancy as set forth in Article 3 hereinafter to Party A and
its subsidiaries to facilitate them to conduct the aforementioned business and supply relevant
products and services.

2. Exclusive Cooperation

2.1 Party A irrevocably undertakes that Party A will take Party B as its exclusive and sole partner
to provide the business consultancy and technical services as well as technical consultancy to Party
A and its subsidiaries. Party A shall not establish any same or similar cooperative relationship
with any third party in respect of such businesses nor shall it make any same or similar
arrangement, unless with the prior written consent of Party B.

2.2 Party A irrevocably undertakes that it will make best efforts to assist and endeavor to achieve
the exclusive operation of thecooperative business to the extent permitted by laws.

2.3 Party A irrevocably undertakes that, without Party B's consent, Party A shall not conduct any
other business or make any commercial arrangement, including without limitation being engaged in or
otherwise participating in any commercial activities and businesses independently or together with
any other person or entity, nor shall it carry out any activities that may be competitive with or
cause adverse effect to Party B's business.

3. Party B's Services

Party B undertakes to provide the following technical consultancy and services to Party A and its
subsidiaries in respect of the cooperative business (collectively referred to as "Party B's
Services"):

3.1 Research, development, production, test, operation and maintenance, upgrade and other services
of relevant technology;

3.2 Development, construction, operation and maintenance, upgrade and other services of relevant
internet platform and system;

3.3 Design the relevant tour products plan, and provide relevant training, implementation and
upgrade and other services;
<!-- page 3 -->
3.4 Consultancy services related to sale and promotion of tour products;

3.5 Other services as agreed by the Parties.

Party A agrees that Party B may, at its own discretion, provide the aforementioned Party B's
Services to Party A and its subsidiaries, or purchase the required services from any third party and
provide the services to Party A and its subsidiaries.

Party A shall cause its subsidiaries to accept Party B's Services. The Parties agree that the
subsidiaries of Party A may otherwise enter into an agreement with Party B in respect of Party B's
Services in accordance with this Agreement.

4. Cooperation Remuneration

4.1 Party A and Party B unanimously agree that they will allocate the proceeds generated from
cooperation in accordance with thefollowing provisions:

Party B shall have the right to charge, on a quarterly basis, the service fee ("Service Fee") from
Party A or its subsidiaries who have accepted Party B's Services, or designate another person to
charge Service Fee from Party A or its subsidiaries who have accepted Party B's Services. The total
sum of Service Fee shall be equal to the amount of profits gained by Party A or its subsidiaries who
have accepted Party B's Services. Party B shall have the right to adjust the amount of Service Fee
at its own discretion, without the prior consent of Party A or its subsidiaries.

Party A shall cause its subsidiaries to pay the Service Fee in respect of Party B's Services
provided to such subsidiaries.

4.2 The Service Fee of the last quarter shall be paid prior to the seventh business day following
the commencement of the next quarter. Such Service Fee shall be paid to the bank account designated
by Party B in writing. If Party B intends to change its bank account, it shall send a written notice
to Party A seven business days in advance.

4.3 Except as otherwise agreed hereunder, if Party A or its subsidiaries fail to pay the Service Fee
in full on schedule according to provisions of Article 4.1 and Article 4.2, then Party A or its
subsidiaries shall, in addition to the continuance of the payment of Service Fee in full, it shall
pay Party B the liquidated damages at a daily interest rate of 0.03% in respect of the outstanding
Service Fee.

5. Term of Cooperation

Party A and Party B agree and confirm that the term of cooperation under this Agreement shall
commence from the execution date hereof and end on the expiration date of the operation term of
Party B ("Term of Cooperation").
<!-- page 4 -->
6. Termination

6.1 Prior to the expiration of the Term of Cooperation , this Agreement shall only be terminated
upon occurrence of the followingcircumstances:

6.1.1 Party B shall have the right to terminate this Agreement in advance without the prior written
consent from Party A, bysending a written notice to Party A but Party A may not terminate or rescind
this Agreement;

6.1.2 One Party requests to terminate this Agreement when the other Party is declared bankrupt in
accordance with the laws;

6.1.3 Party B fails to provide Party B's Services to Party A for more than three consecutive years
due to the force majeure event.

6.2 Rights and Obligations of the Parties upon Termination

6.2.1 If this Agreement is terminated according to the aforementioned Article 6.1.1, neither Party
shall assume any obligations or liabilities to the other Party as of the termination hereof, unless
as otherwise agreed by the Parties, provided that the liabilities for breach occurring prior to the
termination shall not be exempted;

6.2.2 If this Agreement is terminated according to the aforementioned Article 6.1.2, the rights and
obligations of the Parties at thetime of termination hereof shall be subject to the relevant
bankruptcy laws;

6.2.3 If this Agreement is terminated according to the aforementioned Article 6.1.3, neither Party
shall assume any obligations or liabilities to the other Party as of the termination hereof,
provided that the liabilities for breach that occured prior to the force majeure event shall not be
exempted.

6.3 Each Party hereby irrevocably waives other rights to terminate this Agreement it may have under
any applicable laws, except for therights of the Parties agreed under this Article 6.

6.4 Party A hereby expressly undertakes that it waives the right to request amendment and revocation
of any term of this Agreement on the ground of material misunderstanding or unconscionability,
regardless of whether such request is based on the percentage and amount of payment specified
hereunder or the quantity and quality of any service provided by Party B, or is raised against the
provisions under which Party A is prohibited from having any cooperation with a third party and
conducting any businesses other than those agreed hereunder.

7. Representations and Warranties
<!-- page 5 -->
7.1 Each Party hereby represents and warrants to the other Party that:

7.1.1 It has sufficient capacity for action, power and authorization (including necessary government
approval and internal permit ofcorporation) to execute and perform this Agreement;

7.1.2 This Agreement shall be legally binding on the Parties as of the execution date hereof; and

7.1.3 There is no outstanding litigation, arbitration or other legal or governmental proceedings, or
to the knowledge of that Party, there is no litigation, arbitration or other legal or governmental
proceedings threatening or affecting the performance of obligations of that Party hereunder.

7.2 Each Party shall be responsible for and hold the other Party harmless from any loss, damages and
claim arising out of violation of anyrepresentations and warranties hereunder.

8. Breach

The Parties agree and acknowledge that:

8.1 If any Party commits any act in violation of this Agreement, such Party shall assume the
liabilities for breach according to this Agreement and applicable laws. If both Parties breach this
Agreement, they shall each assume their own liabilities for breach respectively. Notwithstanding the
foregoing provisions, neither Party shall be responsible to the other Party in respect of any
indirect loss or damage caused hereunder.

8.2 The demand for liquidated damages and specific performance in respect of any breach during the
Term of Cooperation are all remedies that the non-breaching Party shall have under this Agreement.
The non-breaching Party shall waive the right to request termination of this Agreement it may have
according to any applicable laws as a result of the violation acts committed by the breaching Party.

9. Governing Law

This Agreement shall be governed by and interpreted pursuant to the laws of the People's Republic of
China that are promulgated and are publicly available, provided that the general international
business practices shall apply if the laws of the People's Republic of China that are promulgated
and are publicly available do not involve any matter in relation to this Agreement.
<!-- page 6 -->
10. Force Majeure

The force majeure hereunder shall mean the natural disaster, war, political event, and adjustment of
laws, regulations and state policies. If the performance of this Agreement by one Party or the
Parties according to provisions agreed hereunder is directly affected by the force majeure event,
the affected Party shall immediately notify the other Party or its attorney-in-fact of the situation
of the force majeure event, and shall, within fifteen (15) days, provide the detailed information of
the force majeure event or the reason for non-performance or partial performance or delay of
performance of this Agreement as well as valid evidence thereof (which shall be issued by the
notarization authority at the place where the force majeure event occurs). The Parties shall
negotiate to decide the performance of this Agreement depending on to what degree the performance of
this Agreement is influenced by the force majeure, and decide on whether the affected Party may
partially perform or postpone the performance of its obligations hereunder. Except as provided for
under Article 6.1.3 hereof, neither Party shall exercise the right to termination this Agreement
that it may have under any applicable laws on the ground of occurrence of force majeure event.

11. Dispute Resolution

11.1 Any dispute arising out of performance of this Agreement or in connection with this Agreement
shall be resolved by the Partiesthrough friendly negotiation.

11.2 If the dispute cannot be resolved through negotiation within thirty (30) days after a Party
sends the written notice to the other Party stating its opinions on this dispute, either Party may
submit the dispute to China International Economic and Trade Commission for arbitration in Beijing
according to its arbitration rules then in effect. The arbitration award shall be final and binding
on each Party.

12. Miscellaneous

12.1 This Agreement shall take effect as of the date when the authorized representatives of the
Parties sign hereon. The Parties agree and confirm that this Agreement shall constitute all
understanding, interpretation and intentions of the Parties in respect of the cooperative business.
This Agreement shall be taken as an amendment and restatement of the Original Cooperation Agreement
and supersede the Original Cooperation Agreement in all respects.

12.2 The rights and obligations of each Party under this Agreement shall not be transferred, except
for the transfer by Party B to its affiliates.
<!-- page 7 -->
12.3 The Parties agree that any and all intellectual property researched and developed, created and
invented by the Parties (including their employees) in the course of performance of this Agreement
shall be owned by Party B. For the purpose of this Article 12.3, "Intellectual Property" means the
patent, patent application right, trademark, service mark, logo, image, trade name, internet domain
name, design right, copyright (including copyright of computer software) and moral rights, database
right, right of semiconductor design drawing, utility model, proprietary technology and other
intellectual property that are registered and unregistered including those that have applied for
registration, as well as all other rights or protection methods with same or similar effect on a
global scope.

12.4 To the extent permitted under the laws of the People's Republic of China, the failure or delay
of performance of any right under this Agreement by any Party shall not be deemed as a waive of such
right, and any single or partial exercise of any right shall not preclude the further exercise of
such right in the future.

12.5 This Agreement shall constitute an entire agreement between the Parties in respect of the
subject matter of this Agreement and supersede any and all prior expression of intention or
understanding reached by the Parties in relation to this Agreement. This Agreement shall not be
amended or modified unless the authorized representatives of the Parties sign a written agreement
thereof.

12.6 This Agreement shall be executed in two (2) copies, each of which shall have the same legal
effect.

12.7 Any notice or written communication sent by a Party to the other Party under this Agreement
shall be made in writing and delivered by courier service or by facsimile accompanied with a
confirmation hard copy delivered by courier service. The notice, communication or letter sent under
this Agreement shall be deemed as effectively received on the seventh (7) day after sending to the
courier service, or shall be deemed as effectively received on the first (1) day after delivered by
facsimile, which shall be evidenced by the transmission confirmation. All notice and communication
shall be sent to the following addresses until a Party notify the other Party in writing to change
such addresses:

Party A: Nanjing Tuniu Technology Co., Ltd. Address: Tuiniu Building, 699-32Xuanwu Avenue, Xuanwu
District, Nanjing Fax No.: (86 25) 86853999 Attention: General Manager

Party B: Beijing Tuniu Technology Co., Ltd. Address: Tuiniu Building, 699-32Xuanwu Avenue, Xuanwu
District, Nanjing Fax No.: (86 25) 86853999 Attention: General Manager
<!-- page 8 -->
12.8 Confidentiality Obligations

12.8.1 Neither Party shall disclose the financial and technical information obtained in the course
of conclusion of this Agreement to any third party nor use such information for matters irrelevant
to this Agreement, regardless of written or oral information, unless the other Party gives a prior
written consent thereto.

12.8.2 The Parties shall be obligated to take measures (including without limitation preparing the
confidentiality rules, entering into the confidentiality agreement, establishing the archive
management system and etc.) to ensure their respective employees will observe the confidentiality
obligations specified hereunder.

(The remaining of this page is intentionally left blank)
<!-- page 9 -->
In witness whereof, this Agreement has been executed by the duly authorized representatives of the
Parties on the date first mentioned above. Party A: Nanjing Tuniu Technology Co., Ltd.

By: /s/ Yu Dunde Name: Yu Dunde Title: Chairman

Party B: Beijing Tuniu Technology Co., Ltd.

By: /s/ Yu Dunde Name: Yu Dunde Title: Chairman
