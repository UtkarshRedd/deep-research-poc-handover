"""Agents (LangGraph). Each module is a stage; `dr/graph.py` wires them.

Phase 2  researcher.py   Approach 2 — single ReAct agent over filesystem tools
Phase 3  writer.py       outline-first, fact-bound report from the evidence bank
Phase 4  first_move.py   Approach 1 — clue decomposition + BM25/grep union + opening observation
Phase 4  router.py       single | breadth | long_context
Phase 5  fanout.py       Approach 3 — context-isolated researchers + extract grid
"""
