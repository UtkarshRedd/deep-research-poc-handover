<!-- page 1 -->
# CO-BRANDING AND ADVERTISING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Co-Branding Agreement |
| Agreement Date | 1999-06-21 |
| Parties | I-ESCROW, INC. ("i-Escrow" ); 2THEMART.COM, INC. ("2TheMart") |
| Source | CUAD v1 / 2ThemartComInc_19990826_10-12G_EX-10.10_6700288_EX-10.10_Co-Branding Agreement_ Agency Agreement |

CO-BRANDING AND ADVERTISING AGREEMENT

THIS CO-BRANDING AND ADVERTISING AGREEMENT (the "Agreement") is made as of June 21, 1999 (the
"Effective Date") by and between I-ESCROW, INC., with its principal place of business at 1730 S.
Amphlett Blvd., Suite 233, San Mateo, California 94402 ("i-Escrow"), and 2THEMART.COM, INC. having
its principal place of business at 18301 Von Karman Avenue, 7th Floor, Irvine, California 92612
("2TheMart").

1. DEFINITIONS.

(a) "CONTENT" means all content or information, in any medium, provided by a party to the other
party for use in conjunction with the performance of its obligations hereunder, including without
limitation any text, music, sound, photographs, video, graphics, data or software. Content provided
by 2TheMart is referred to herein as "2TheMart Content" and Content provided by i-Escrow is referred
to herein as "i-Escrow Content."

(b) "CO-BRANDED SITE" means the web-site accessible through Domain Name, for the Services
implemented by i-Escrow. The homepage of this web-site will visibly display both 2TheMart Marks and
i-Escrow Marks.

(c) "CUSTOMERS" means all users who access Co-Branded Site.

(d) "DOMAIN NAME" means www.iescrow.com/2TheMart.

(e) "ESCROW SERVICES" means services for auction sellers and high bidders whereby an agent holds a
buyer's money in trust until the buyer approves the applicable item that was physically delivered,
at which time the agent releases the buyer's money to seller, after subtracting the escrow fees.

(f) "INFORMATION TRANSFER MECHANISM" means the mechanism by which 2TheMart transfers to i-Escrow
information to populate the applicable i-Escrow transaction and user registration forms.

(g) "LAUNCH DATE" means the first date on which the Co-Branded Site is pointed to in all references
to i-Escrow from 2TheMart auction site, and the Information Transfer Mechanism is publicly deployed
(post-beta).

(h) "MARKS" means all domain names, trademarks and logos designated by a party for the other party's
use in conjunction with such other party's performance under this Agreement. Marks designated by
2TheMart for i-Escrow's use are referred to herein as "2TheMart Marks" and Marks designated by
i-Escrow for 2TheMart' use are referred to herein as "i-Escrow Marks."

(i) "SERVICES" means i-Escrow's implementation and performance of the Escrow Services as of the
Effective Date, as modified over time.

(j) "SHADOW SITE" means the site where Co-Branded Site is made available for 2TheMart's testing of
the Information Transfer Mechanism prior to being made publicly available.

(k) "TRANSACTION" means a transaction utilizing the Services that actually closes and that was
initiated by a Transaction Inquiry from a Customer.

(l) "TRANSACTION INQUIRY" means a Customer's submission of i-Escrow's standard New Transaction
Inquiry form (or its successor) on or through the Co-Branded Pages. Currently this means entry of a
description and price of merchandise by a user (buyer or seller) who agrees to abide by the terms
and conditions of the Services, together with email address of the other party, regardless of
whether or not any Transaction is completed.

Source: 2THEMART COM INC, 10-12G, 8/26/1999
<!-- page 2 -->
2. DEVELOPMENT AND IMPLEMENTATION.

2.1 OVERVIEW. As set forth herein, 2TheMart will promote Services to its auction users (buyers and
sellers), and i-Escrow shall develop Co-Branded Site, and develop the Information Transfer Mechanism
working with 2TheMart to make Services available seamlessly to Customers. Unless otherwise
specified, each party shall be responsible for all development, hosting and other costs associated
with the pages resident on their servers and all emails to users they send.

2.2 INITIAL INFORMATION TRANSFER MECHANISM DEVELOPMENT. The parties shall negotiate in good faith to
determine the initial operation of the Information Transfer Mechanism and to describe such operation
and development fees, in a statement of work ("SOW"). Each party shall make available sufficient and
qualified engineers to negotiate the SOW. No SOW shall be binding on the parties unless mutually
approved by both parties. In the event that the parties are unable to agree to an SOW within 2
months following the Effective Date, either party may, in its sole discretion, terminate this
Agreement by providing written notice.

Once approved, the parties shall use commercially reasonable efforts to diligently implement their
respective obligations under the SOW. Upon completion of its duties under the SOW, a party shall
notify the other party and provide the other party with the opportunity to test and evaluate its
work. i-Escrow shall make available the Shadow Site for such testing in a timely manner. Each party
shall reasonably cooperate with the other party in effectuating their respective duties under the
SOW. The Information Transfer Mechanism shall not go live until its operation has been approved
("Approval Date") by both parties, such approval not to be unreasonably withheld.

2.3 LAUNCH TIMING. Each party shall use good faith and reasonable efforts to expeditiously develop
the Co-Branded Pages and the Information Transfer Mechanism. In the event that, after using such
efforts, the Launch Date has not occurred within 4 months following the Effective Date, either party
may terminate this Agreement by providing written notice. If

only one party has used good faith and reasonable development efforts, only that party may exercise
the foregoing right to terminate.

2.4 RESTRICTIONS ON COMMUNICATIONS. i-Escrow may place banner advertising on the Co-Branded Site
upon prior written approval of 2TheMart, which shall be at the discretion of 2TheMart. All
advertising revenue arising from the banner ads shall be solely i-Escrow's. i-Escrow shall not run
banner advertisements on the Co-Branded Site for any of 2TheMart's competitors. 2TheMart shall
provide in writing, a list of companies they would like to exclude, including every time they wish
to change this list.

2.5 SERVICE PERFORMANCE OF INFORMATION TRANSFER MECHANISM. The parties each shall in good faith work
to provide reasonable service levels with respect to the operation of the portions of the
Information Transfer Mechanism in their control.

Source: 2THEMART COM INC, 10-12G, 8/26/1999
<!-- page 3 -->
2.6 PROGRAM REVIEW MEETINGS. The parties shall meet, at least once per month either in person, or by
telephone, to coordinate the implementation of this agreement over time.

3. PROMOTION.

After Launch Date, 2TheMart will widely promote the Services:

(a) To every seller and high bidder through means including, but not limited to, end of auction
emails containing links, such that, it shall be possible for the buyer or seller to initiate a
Transaction Inquiry with i-Escrow, without having to re-enter all their personal or transaction
related information.

(b) By adding links to Co-Branded Site in FAQ section of 2TheMart auctions.

(c) By adding links to Co-Branded Site on the seller listing pages of 2TheMart auctions.

(d) By displaying a text or graphic link to a page containing information about Services on all
auction item pages and bidding pages to educate bidders about i-Escrow. 2TheMart may use the "Escrow
Services Description" attached in Exhibit A for creating such a page.

5. PAYMENT.

5.1 ADVERTISING FEES. After the Launch Date, i-Escrow shall pay 2TheMart advertising fees based on
the number of Transaction Inquiries. This advertising fees shall consist of a per Transaction
Inquiry amount calculated by multiplying 0.025% by the amount of the average Transaction from all
Customers in the preceding quarter. The formula for arriving at the per Transaction Inquiry amount
may be revised from time to time during the term of this Agreement to reflect present market
conditions ("the Adjusted Rate"), but only by mutual

consent of the parties after good faith discussions. The Adjusted Rate shall be added as an addendum
to this Agreement.

5.2 REPORTING. Within two (2) weeks following the end of each calendar quarter, i-Escrow shall
provide to 2TheMart a report, describing for each quarter: the number of new registrations through
the Co-Branded Pages; the number of Transaction Inquiries from Customers; the total number of
Transactions from such inquiries; the total dollar value of the Transactions.

5.3 AUDIT RIGHTS. i-Escrow shall keep for one (1) year proper records and books of account relating
to the computation of advertising payments owed to 2TheMart (including, as appropriate, the
computation of the size of average Transaction). Once every twelve (12) months, 2TheMart through a
CPA may inspect and audit such records to verify reports. Any such inspection will be conducted in a
manner that does not unreasonably interfere with i-Escrow's business activities and with no less
than fifteen (15) days notice. i-Escrow shall within two (2) weeks make any overdue payments
disclosed by the audit. Such inspection shall be at 2TheMart's expense; however, if the audit
reveals overdue payments in excess of ten percent (10%) of the payments owed to date, i-Escrow shall
immediately pay all cost of such audit.

6. RIGHTS AND STANDARDS.

Source: 2THEMART COM INC, 10-12G, 8/26/1999
<!-- page 4 -->
6.1 CONTENT. 2TheMart hereby grants to i-Escrow a worldwide, non-exclusive right to use, reproduce,
distribute, publicly perform, publicly display and digitally perform the 2TheMart Content soley with
respect to and in conjunction with the Co-Branded Site all with the prior written consent of
2TheMart, for the term of this Agreement. i-Escrow hereby grants to 2TheMart a worldwide,
non-exclusive right to use, reproduce, distribute, publicly perform, publicly display and digitally
perform the i-Escrow Content on or in conjunction with 2TheMart auctions.

6.2 CONTENT OWNERSHIP. Except as otherwise provided in this Agreement, as between 2TheMart and
i-Escrow: (a) 2TheMart and its suppliers retain all rights, title and interest in and to all
intellectual property rights embodied in or associated with the 2TheMart Content, and b) i-Escrow
and its suppliers retain all rights, title and interest in and to all intellectual property rights
embodied in or associated with the i-Escrow Content and Co-Branded Site. There are no implied
licenses under this Agreement, and any rights not expressly granted are reserved. Neither party
shall exceed the scope of the rights granted hereunder.

6.3 TRADEMARKS. Subject to the terms and conditions of this Agreement: (a) i-Escrow hereby grants to
2TheMart a non-exclusive, nontransferable right to use the i-Escrow Marks (including without
limitation the Domain Name) in links to and advertisements and promotions for the Co-Branded Pages
or the Services; and (b) 2TheMart hereby grants to i-Escrow a non-exclusive, nontransferable right
to use 2TheMart Marks (including without limitation the Domain Name) on the Co-Branded Pages, and
for the performance of Services.

6.4 TRADEMARK RESTRICTIONS. The Mark owner may terminate the foregoing rights if, in its reasonable
discretion, the other party's use of the Marks tarnishes, blurs or dilutes the quality associated
with the Marks or the associated goodwill and such problem is not cured within ten (10) days of
notice of breach; alternatively, instead of terminating the right in total, the

owner may specify that certain pages of the other party's web-site may not contain the Marks. Title
to and ownership of the owner's Marks shall remain with the owner. The receiving party shall use the
Marks exactly in the form provided and in conformance with any trademark usage policies. The other
party shall not take any action inconsistent with the owner's ownership of the Marks, and any
benefits accruing from use of such Marks shall automatically vest in the owner. The other party
shall not form any combination marks with the other party's Marks. Notwithstanding the foregoing, to
the extent that the Domain Name is deemed a combination mark, neither party shall use the Domain
Name for any purpose except as expressly provided herein or attempt to register the Domain Name, and
the parties will jointly cooperate on any enforcement action of infringement of the Domain Name.

6.5 LIMITS ON SUBLICENSING. All rights (under any applicable intellectual property right) granted
herein are not sublicenseable,

Source: 2THEMART COM INC, 10-12G, 8/26/1999
<!-- page 5 -->
transferable or assignable. Notwithstanding the foregoing, either party may use a third party web
host, but all actions or failures to act of the web host that would be a breach of this Agreement,
were the actions or failures to act taken by the applicable party, shall be deemed a breach of this
Agreement. In addition, 2TheMart may grant sublicenses to companies that 2TheMart has a business
relationship with to the extent that 2TheMart Content is visible from such company's web-site
through a link or other means.

6.6 CONTENT STANDARDS. 2TheMart shall not provide any 2TheMart Content, and i-Escrow shall not
provide any i-Escrow Content, that: (a) infringes any third party's copyright, patent, trademark,
trade secret or other proprietary rights or rights of publicity or privacy; (b) violates any law,
statute, ordinance or regulation (including without limitation the laws and regulations governing
export control, unfair competition, antidiscrimination or false advertising); (c) is defamatory,
trade libelous, unlawfully threatening or unlawfully harassing; (d) is obscene, harmful to minors or
child pornographic; (e) contains any viruses, Trojan horses, worms, time bombs, cancelbots or other
computer programming routines that are intended to damage, detrimentally interfere with,
surreptitiously intercept or expropriate any system, data or personal information; and (f) is
materially false, misleading or inaccurate.

6.7 SERVICE STANDARDS. i-Escrow will comply with all laws and regulations and act as an Independent
Escrow Agent as per the guidelines of California Escrow Law (California Financial Code Section17000
et seq., or its successor). Should any of the terms, conditions or provisions of this Agreement
conflict with the California Escrow Law, its rules or regulations, which govern i-Escrow's business
practices, the California Escrow Law shall prevail. Notwithstanding the foregoing, at any time that
i-Escrow reasonably believes such a conflict exists, i-Escrow will give 2TheMart written notice of
such conflict and the parties will use their best efforts to resolve such conflict.

7. DISCLAIMER OF WARRANTIES. EACH PARTY PROVIDES ALL MATERIALS AND SERVICES TO THE OTHER PARTY "AS
IS." EACH PARTY DISCLAIMS ALL WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED OR STATUTORY, INCLUDING
WITHOUT LIMITATION THE IMPLIED WARRANTIES OF TITLE, NON-

INFRINGEMENT, MERCHANTABILITY ANDFITNESS FOR A PARTICULAR PURPOSE. Each party acknowledges that it
has not entered into this Agreement in reliance upon any warranty or representation except those
specifically set forth herein.

8. TERM AND TERMINATION.

8.1 TERM. The term of this Agreement shall continue for one (1) year following the Launch Date,
unless earlier terminated as provided herein. This Agreement may be renewed for any number of
successive one (1) year terms by mutual written agreement of the parties prior to the conclusion of
the term of this Agreement. A party wishing to renew this Agreement shall give the other party
notice thereof no less than thirty (30) days before the expiration of the term then in effect. In
the event that either party does not give such notice, the term of this Agreement shall be
automatically renewed for another one (1) year.

Source: 2THEMART COM INC, 10-12G, 8/26/1999
<!-- page 6 -->
8.2 TERMINATION FOR BREACH. In addition to other remedies that may be available to it, by providing
written notice, a party may immediately terminate this Agreement: (a) if the other party materially
breaches this Agreement and fails to cure that breach within sixty (60) days after receiving written
notice of the breach, or (b) as provided in Sections 2.2 [INITIAL INFORMATION TRANSFER MECHANISM
DEVELOPMENT], 2.4 [RESTRICTIONS ON COMMUNICATIONS], or 12.4.

8.3 TERMINATION FOR CHANGE IN COMPANY STRUCTURE. If a majority of the equity securities of either
2TheMart or i-Escrow, Inc. (except that i-Escrow may sell all or a majority of its equity securities
or voting interests to i-Escrow.com, and i-Escrow.com may sell all or a majority of its equity
securities or voting interests to i-Escrow's existing shareholders, without triggering the
foregoing) are acquired by another company during the term of this Agreement either company may
terminate this Agreement, without liability, by giving a thirty (30) days written notice to the
other party.

8.4 TERMINATION FOR BANKRUPTCY. Either party may terminate or suspend this Agreement effective
immediately and without liability upon written notice to the other party if any one of the following
events occurs:

(a) the other party files a voluntary petition in bankruptcy or otherwise seeks protection under any
law for the protection of debtors;

(b) a proceeding is instituted against the other party under any provision of any bankruptcy laws
which is not dismissed within ninety (90) days;

(c) the other party is adjudged bankrupt;

(d) a court assumes jurisdiction of all or a substantial portion of the assets of the other party
under a reorganization law;

(e) a trustee or receiver is appointed by a court for all or a substantial portion of the assets of
the other party;

(f) the other party becomes insolvent, ceases or suspends all or substantially all of its business;
or

(g) the other party makes an assignment of the majority of its assets for the benefit of its
creditors.

8.5 EFFECTS OF TERMINATION. Upon expiration or termination of this Agreement for any reason: (a) all
rights granted herein shall terminate, (b) i-Escrow shall pay all amounts owed to 2TheMart within
six (6) weeks of termination, and (c) each party shall remove the other party's content and Marks
from their servers. Notwithstanding the foregoing, unless this Agreement was terminated for a
material breach, all provisions of this Agreement shall survive to the extent necessary for i-Escrow
to complete any Customer transactions which are pending at the time of expiration or termination.
Sections 1, 7, 8.5 [EFFECTS OF TERMINATION], 9, 10, 11 and 12 shall survive expiration or
termination of this Agreement.

9. INDEMNITY. Each party (the "Indemnifying Party") shall indemnify the other party (the
"Indemnified Party") against any and all claims, losses, costs and expenses, including reasonable
attorneys' fees, which the Indemnified Party may incur as a result of claims in any form by third
parties arising from the Indemnifying Party's acts, omissions or misrepresentations to the extent
that the Indemnified Party is deemed a principal of the Indemnifying Party. In addition, 2TheMart
shall indemnify i-Escrow against any and all claims, losses, costs and expenses, including
reasonable attorneys' fees, which i-Escrow may incur as a result of claims in any form by third
parties arising from 2TheMart Content. In addition, i-Escrow shall indemnify 2TheMart against any
and all claims, losses, costs and expenses, including reasonable attorneys' fees, which 2TheMart may
incur as a result of claims in any form by third parties arising from i-Escrow

Source: 2THEMART COM INC, 10-12G, 8/26/1999
<!-- page 7 -->
Content and or the Services provided to Customers. The foregoing obligations are conditioned on the
Indemnified Party: (i) giving the Indemnifying Party notice of the relevant claim, (ii) cooperating
with the Indemnifying Party, at the Indemnifying Party's expense, in the defense of such claim, and
(iii) giving the Indemnifying Party the right to control the defense and settlement of any such
claim, except that the Indemnifying Party shall not enter into any settlement that affects the
Indemnified Party's rights or interest without the Indemnified Party's prior written approval. The
Indemnified Party shall have the right to participate in the defense at its expense.

10. LIMITATION ON LIABILITY. EXCEPT IN THE EVENT OF A BREACH OF SECTION 11, NEITHER PARTY SHALL BE
LIABLE FOR SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES OR LOST PROFITS (HOWEVER ARISING, INCLUDING
NEGLIGENCE) ARISING OUT OF OR IN CONNECTION WITH THIS AGREEMENT, EVEN IF THE PARTIES ARE AWARE OF
THE POSSIBILITY OF SUCH DAMAGES.

11. CONFIDENTIAL INFORMATION. A party's "Confidential Information" is defined as any confidential or
proprietary information of a party which is disclosed to the other party in a writing marked
confidential or, if disclosed orally, is identified as confidential at the time of disclosure and is
subsequently reduced to a writing marked confidential and delivered to the

other party within ten (10) days of disclosure. Each party shall hold the other party's Confidential
Information in confidence and shall not disclose such Confidential Information to third parties nor
use the other party's Confidential Information for any purpose other than as required to perform
under this Agreement. Such restrictions shall not apply to Confidential Information which (a) is
already known by the recipient, (b) becomes, through no act or fault of the recipient, publicly
known, (c) is received by recipient from a third party without a restriction on disclosure or use,
or (d) is independently developed by recipient without reference to the Confidential Information.
The restriction on disclosure shall not apply to Confidential Information which is required to be
disclosed by a court or government agency. Upon expiration or termination of this Agreement, within
fourteen (14) days of the other party's request, each party will return all Confidential Information
and other deliverables to the requesting party.

12. GENERAL PROVISIONS.

12.1 GOVERNING LAW. This Agreement will be governed and construed in accordance with the laws of the
State of California without giving effect to conflict of laws principles. Both parties submit to
personal jurisdiction in California and further agree that any cause of action arising under this
Agreement shall be brought in a court in Orange County, California.

12.2 SEVERABILITY; HEADINGS. If any provision herein is held to be invalid or unenforceable for any
reason, the remaining provisions will continue in full force without being impaired or invalidated
in any way. The parties agree to replace any invalid provision with a valid provision that most
closely approximates the intent and economic effect of the invalid provision. Headings are for
reference purposes only and in no way define, limit, construe or describe the scope or extent of
such section.

12.3 PUBLICITY. Prior to the release of any press releases or other similar promotional materials
related to this Agreement, the releasing party shall submit a written request for approval to the
other party with a copy of the materials to be released, which

Source: 2THEMART COM INC, 10-12G, 8/26/1999
<!-- page 8 -->
request shall be made no less than three (3) business days prior to the requested release date. A
party shall not unreasonably withhold or delay the granting of its approval of such materials, and
such approval shall be provided to the other party within one (1) business day of receipt

12.4 FORCE MAJEURE. Except as otherwise provided, if performance hereunder (other than payment) is
prevented, restricted or interfered with by any act or condition whatsoever beyond the reasonable
control of a party (a "force majeure event"), the party so affected, upon giving prompt notice to
the other party, shall be excused from such performance to the extent of such prevention,
restriction or interference. However, if a force majeure event interferes with the operation of this
Agreement for sixty (60) days or more, either party can terminate this Agreement, without penalty.
Notwithstanding the foregoing, the occurrence of any force majeure event shall not limit either
party's obligations under Section 9 with respect to any third party claim as to which the other
party seeks indemnification.

12.5 INDEPENDENT CONTRACTORS. The parties are independent contractors, and no agency, partnership,
joint venture, employee- employer or franchisor-franchisee relationship is

intended or created by this Agreement. Neither party shall make any warranties or representations on
behalf of the other party.

12.6 NOTICE. Any notices hereunder shall be given to the appropriate party at the address specified
below or at such other address as the party shall specify in writing. Notice shall be deemed given:
upon personal delivery; if sent by fax, upon confirmation of receipt; or if sent by a reputable
overnight courier with tracking capabilities, one (1) day after the date of mailing: To i-Escrow:
i-Escrow, Inc. 1730 South Amphlett Blvd., #215 San Mateo, CA 94402 Fax no. (650) 638-7890 Attention:
President

With copy to: Fred M. Greguras, Esq. Legal Counsel of i-Escrow Fenwick & West LLP Two Palo Alto
Square Palo Alto, CA 94306

To 2TheMart: Dominic J. Magliarditi President 18301 Von Karman Avenue, 7th Floor Irvine, CA 92612
Fax no. (949) 477-1221

11.7 COUNTERPARTS. This Agreement may be executed in one or more counterparts, each of which shall
be deemed an original and all of which shall be taken together and deemed to be one instrument.

12.8 GOOD FAITH. The parties agree to act in good faith with respect to each provision of this
Agreement and any dispute that may arise related hereto.

12.9 ADDITIONAL DOCUMENTS/INFORMATION. The parties agree to sign and/or provide such additional
documents and/or information as may reasonably be required to carry out the intent of this Agreement
and to effectuate its purposes.

12.10 RIGHTS AND REMEDIES CUMULATIVE. The rights and remedies provided herein will be cumulative and
not exclusive of any other rights or remedies provided by law or otherwise.

12.11 NONWAIVER. No failure or forbearance by either party to exercise any right or insist upon or
enforce performance of any obligation hereunder shall be deemed a waiver or relinquishment to any
extent of that or any other right or obligation, in that or any other instance; rather, the

Source: 2THEMART COM INC, 10-12G, 8/26/1999
<!-- page 9 -->
same shall be and shall remain in full force and effect. Any waiver of any right of a party or any
obligation of the other party hereunder must be made in a writing signed by the arty waiving such
right or obligation.

12.12 ENTIRE AGREEMENT. This Agreement contains the entire understanding of the parties hereto with
respect to the transactions and matters contemplated hereby, supersedes all previous Agreements
between i-Escrow and 2TheMart concerning the subject matter (except for the Confidential Agreement
Dated January 4 1999, which shall survive this Agreement). No amendments or supplements to this
Agreement will be effective for any purpose except by a written Agreement signed by the parties. No
party hereto has relied on any statement, representation or promise of any party or with any other
officer, agent, employee or attorney for the other party in executing this Agreement except as
expressly stated herein.

2THEMART.COM, INC.: I-ESCROW, INC.:

By:/s/Dominic J. Magliarditi By:/s/Sanjay Bajaj Name: Dominic J. Magliarditi Name: Sanjay Bajaj
Title: President Title: VP Business Development Date: 6/21/99 Date: 6/11/99

EXHIBIT A

ESCROW SERVICES DESCRIPTION

Successful completion of a transaction involves exchange of merchandise with payment. The buyer has
to be satisfied he/she received what they thought they were getting and the seller has to be sure
he/she gets paid. i-Escrow holds payment from the buyer in trust until the seller sends the
merchandise to the buyer. Once the buyer accepts the merchandise, i-Escrow forwards the payment to
the seller by writing a check. A typical escrow transaction: When an auction ends, your end of
auction email contains links to i-Escrow. Once you have signed up with i-Escrow you go through the
following steps to complete your transaction. 1. Start a transaction by entering the description and
price of the merchandise along with email address of the other party. 2. The other party receives an
email from i-Escrow requesting an acknowledgement of the terms of the transaction. 3. Once the
transaction is acknowledged by the other party, the buyer pays i-Escrow the agreed upon price, by
credit card or other means. 4. i-Escrow informs the seller that payment has been received,
requesting them to ship the merchandise directly to the buyer. 5. The seller provides i-Escrow with
the tracking number of the shipment. 6. The buyer receives and accepts the merchandise. 7. i-Escrow
sends the check to the seller.

For more information about I-Escrow, visit their web-site at www.iescrow.com

Source: 2THEMART COM INC, 10-12G, 8/26/1999
