# What law governs the Corvallis Foods Group Credit Agreement

*Question:* What law governs the Corvallis Foods Group Credit Agreement?

## Identify governing law clause

Section 10.3 of the Corvallis Foods Group Credit Agreement states that the Agreement shall be governed by, and construed in accordance with, the laws of the State of California. [12b8df2880fdff86 p.12]

## Verify applicable law

The First Amendment governing law clause confirms that California law governs the amendment. [9b369d1baefec8c4 p.3] The clause states that the amendment shall be governed by the laws of the State of California. [9b369d1baefec8c4 p.3]

[GAP] Evidence does not establish that the identified governing law provision is valid and enforceable under the agreement's terms.

## Verification appendix

Claims: 4 · supported: 3 · partially: 0 · dropped: 0 · gaps: 1 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[12b8df2880fdff86 p.12] |  |
| s2.1 | s2 | keep | 1.00 | e2→[9b369d1baefec8c4 p.3] |  |
| s2.2 | s2 | keep | 1.00 | e2→[9b369d1baefec8c4 p.3] |  |
| s2.3 | s2 | gap |  |  |  |

### Evidence

- e1 [12b8df2880fdff86 p.12 L102-102] keep (1.0): "Section 10.3 Governing Law. This Agreement shall be governed by, and construed in accordance with, the laws of the State of California."
- e2 [9b369d1baefec8c4 p.3 L31-31] keep (1.0): "This Amendment shall be governed by the laws of the State of California. Notices hereunder shall be given in the manner set forth in Section 10.1 of the Credit Agreement."
