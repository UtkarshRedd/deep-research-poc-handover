<!-- page 1 -->
# Support and Maintenance Agreement
| Field | Value |
|---|---|
| Document Type | Maintenance Agreement |
| Parties | XACCT Technologies, Inc. ("XACCT"); [] ("Licensee") |
| Source | CUAD v1 / XACCT Technologies, Inc.SUPPORT AND MAINTENANCE AGREEMENT |

EXHIBIT 10.16

DRAFT (Americas) 1/12/00 (Rev 1) SUPPORT AND MAINTENANCE AGREEMENT

This Support and Maintenance Agreement ("Agreement") is entered into and is effective as of the ____
day of _______________2000 (the "Effective Date") by and between XACCT Technologies, Inc., a
Delaware corporation ("XACCT") with its principal place of business at 2900 Lakeside Drive, Suite
100, Santa Clara, California 95054 and ________________________________, a
_______________corporation ("Licensee") with its principal place of business at
_________________________________.

This Agreement sets forth the terms and conditions under which XACCT will provide Product
Maintenance (as defined below) and Support Services (as defined below) for the Product which is
licensed by Licensee pursuant to XACCT's End User Software License Agreement ("License Agreement").
Except where superseded by this Agreement, all other terms and conditions of the License Agreement
are incorporated by reference. Capitalized terms that are not defined in Section 1. below or
elsewhere in this Agreement have the same meaning as in the License Agreement.

1. DEFINITIONS

1.1 "Designated Support Contact " means Licensee's employee who is authorized to contact the XACCT
support center.

1.2 "Incident" means a single, discrete, malfunction or other problem which may require more than
one (1) response before it is closed.

1.3 "Major Release" means a version of the Product containing significant changes in functionality
which usually will be designated with a whole number product version change such as 3.x to 4.x.

1.4 "Minor Release" means a version of the Product containing minor improvements which usually will
be designated with a one (1) decimal version change such as 3.x to 3.x; also sometimes referred to
as "dot releases."

1.5 "Product Maintenance" means the Product updates and revisions that are available from XACCT and
selected by Licensee, as further referenced herein and the attachments hereto as may be amended from
time to time.

1.6 "Support Services" means the software support services that are available from XACCT and
selected by Licensee, as further referenced herein and the attachments hereto as may be amended from
time to time.

2. COVERAGE AND PAYMENT OF FEES

Licensee may purchase the level of Product Maintenance and Support Services set forth in Attachment
1 to this Agreement. XACCT will provide the Product Maintenance and Support Services purchased by
Licensee subject to the terms and conditions of this Agreement and the License Agreement. Fees shall
be payable within thirty (30) days of invoice which shall be exclusive of any applicable local,
state, federal, use, excise, value added, GST or other taxes imposed on the fees payable for the
Product Maintenance and Support Services which shall be the responsibility of Licensee.

3. SUPPORT SERVICES

3.1 XACCT will provide reasonable commercial efforts to provide the appropriate solutions for
reported Incidents. Initial response times for reported Incidents are as set forth in Attachment 1.

3.2 In order for Licensee to receive the Support Services referenced above, Licensee must:

(a) Appoint Designated Support Contact(s), trained and qualified, who will maintain the integrity of
the&sbsp;Product and who will act as Licensee's liaison for all technical communications with XACCT.
The number of Designated Support Contact(s) will be determined by the level of Support Services
purchased by Licensee set forth in Attachment 1referenced in Section 2. Names of Designated Support
Contact(s) must be provided to XACCT prior to initial contact with the XACCT support center. All
technical communications by Licensee to XACCT shall only be made by the Designated Support
Contact(s). All information and materials provided to Licensee by XACCT pursuant to this Agreement
will be routed to the Designated Support Contact(s). Licensee may change the Designated Support
Contact(s) upon written notice to XACCT;

(b) Promptly obtain training on the use of the Product for the Designated Support Contact(s), and
any other employee substituting or replacing the Designated Support Contact(s);

(c) Subject to Licensee's applicable security requirements, provide XACCT with access to and use of
all information and
<!-- page 2 -->
system facilities including but not limited to a modem connection to Licensee's systems determined
necessary by XACCT to provide timely Support Services pursuant to this Agreement;

(d) Follow operating instructions and procedures as specified in, but not limited to, XACCT's
documentation and other correspondence related to the Product;

(e) Follow procedures and recommendations provided by the XACCT support center in an effort to
correct problems; or

(f) Notify XACCT of a malfunction or other problem in accordance with XACCT's then current problem
reporting procedures and as provided in Attachment 1. If XACCT determines that a problem reported by
Licensee is not due to an error in the Product, XACCT will so notify Licensee. XACCT may in its sole
discretion charge additional fees for time and materials for the resolution of problems that are not
attributable to an error in the Product or which are excluded from XACCT's support obligations as
set forth below.

3.5 XACCT shall have no obligation to support:

(a) altered, damaged or Licensee-modified Product, or any portion of the Product incorporated with
or into other software other than as contemplated by XACCT's documentation or as otherwise expressly
approved by XACCT in writing;

(b) any version of the Product other than the current version of the Product, the immediately
previous version and the version preceding the immediately previous version; XACCT's obligation to
support the version prior to the immediately previous version shall not extend beyond six (6) months
after the release of the current Major Release of the Product;

(c) Product problems caused by Licensee's negligence, abuse or misapplication, use of Product other
than as specified in the XACCT documentation, or other causes beyond the reasonable control of
XACCT;

(d) Product installed on any hardware, operating system version or network environment that is not
supported by XACCT; or

(e) Incidents if XACCT makes a good faith determination that the primary cause of the problem
results from the failure or malfunction of any system, equipment, facilities or devices not
furnished by XACCT.

3.6 Any obligation for Support for non-standard versions of the Product or portions thereof
developed for Licensee on a customized basis shall be only as set forth in an amendment or other
supplement to this Agreement.

4. PRODUCT MAINTENANCE

4.1 XACCT will use reasonable commercial efforts to provide maintenance releases and Minor Releases
to the then-current embodiment of the Product that it provides to its customers generally.
Maintenance Releases and Minor Releases may also include one copy of revisions to the documentation
applicable to such maintenance releases and Minor Releases.

4.2 From time to time XACCT in its sole discretion may develop and provide Major Releases which will
be made available to Licensee with or without additional fees according to the level of Support
Services purchased by Licensee as set forth in Attachment 1 referenced in Section 2.

4.3 THE TERMS OF THE LICENSE AGREEMENT PERTAINING TO LIMITED WARRANTY, DISCLAIMERS OF WARRANTY AND
LIMITATION OF LIABILITY SHALL APPLY TO THE MAJOR AND MINOR RELEASES OF PRODUCT DELIVERED ACCORDING
TO THIS AGREEMENT.

5. TERM AND TERMINATION

5.1 The initial term of this Agreement is one (1) year from the date of delivery of the Product to
Licensee unless earlier terminated in accordance with this Agreement. The Agreement will be
automatically renewed for additional one (1) year terms (subject to applicable fee adjustments)
unless thirty (30) days prior to the anniversary of the Effective Date Licensee gives written notice
to XACCT of its intention not to renew.

5.2 XACCT may suspend or terminate Product Maintenance and Support Services if Licensee fails to
timely pay Product Maintenance and Support Service fees as provided in this Agreement. XACCT may
also terminate Support Services if Licensee breaches any provision of this Agreement or the License
Agreement and such breach is not remedied within thirty (30) days after Licensee receives written
notice of the breach. XACCT shall also have the right not to renew this Agreement with respect to
any Product by providing written notice of such election at least sixty (60) days prior to the
termination of Support Services for such Product, provided that XACCT no longer generally provides
Support Services for such Product, or no longer provides the specific Support
<!-- page 3 -->
Services previously offered.

5.3 Product Maintenance and Support Services shall automatically terminate upon termination of the
License Agreement.

6. REINSTATEMENT OR RENEWAL OF PRODUCT MAINTENANCE AND SUPPORT SERVICES

In the event Product Maintenance and Support Services are terminated by Licensee by notice of
non-renewal, Product Maintenance and Support Services shall be discontinued at the end of the then
current term. If Product Maintenance and Support Services are terminated for any reason, at XACCT's
sole option, Licensee may reinstate or renew Product Maintenance and Support Services by paying
XACCT all applicable Product Maintenance and Support Services and reinstatement fees.

7. LIMITATION OF LIABILITY

7.1 Direct Damages. XACCT'S SOLE LIABILITY AND LICENSEE'S EXCLUSIVE REMEDY FOR DAMAGES WITH RESPECT
TO THE SUPPORT SERVICES UNDER ANY CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY OR OTHER
THEORY, SHALL BE LIMITED TO THE AMOUNT PAID BY LICENSEE FOR THE SUPPORT SERVICES FOR THE PRIOR 12
MONTHS. XACCT'S SOLE LIABILITY AND LICENSEE'S EXCLUSIVE REMEDY FOR DAMAGES WITH RESPECT TO PRODUCT
MAINTENANCE SHALL BE AS SET FORTH IN THE LICENSE AGREEMENT.

7.2 Consequential Damages. UNDER NO CIRCUMSTANCES, INCLUDING NEGLIGENCE, SHALL XACCT BE LIABLE FOR
ANY SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOST
PROFITS, LOSS OF DATA, OR COSTS OF PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES, ARISING IN ANY WAY
OUT OF THIS AGREEMENT OR THE USE OF THE PRODUCT AND DOCUMENTATION EVEN IF XACCT HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGES OR LOSSES.

8. GENERAL

This Agreement, the attachments and the License Agreement constitute the entire agreement between
the parties regarding Product Maintenance and Support Services and supersede all previous agreements
or

representations, oral or written, regarding the subject matter. This Agreement may not be modified
or amended except in a writing signed by a duly authorized representative of each party. Both
parties acknowledge having read the terms and conditions set forth in this Agreement and attachments
hereto, understand all terms and conditions, and agree to be bound thereby. The laws of the State of
California shall govern all issues arising under or relating to this Agreement, without giving
effect to the conflict of laws principles thereof. All disputes arising under or relating to this
Agreement shall be resolved exclusively in the appropriate state court in Santa Clara County,
California or in the federal court in the Northern District of California, and it is explicitly
agreed that no other court shall have such jurisdiction. This Agreement shall not be governed by the
United Nations Convention on Contracts for the International Sale of Goods

IN WITNESS WHEREOF, the parties have caused this Agreement to be executed by their duly authorized
representatives:

LICENSEE XACCT TECHNOLOGIES, INC.

By: By: --------------------------------- -----------------------------------

Name: Name: ------------------------------- ---------------------------------

Title: Title: ------------------------------ --------------------------------

Date: Date: ------------------------------- ---------------------------------
