"""The ONLY module that knows endpoint URLs and model ids.

All three available models (GPT-OSS, Nemotron Nano, Gemma) are assumed to be served as
OpenAI-compatible endpoints (vLLM / NIM). Configure per role via environment variables:

    DR_ENDPOINT_PLANNER=https://.../v1   DR_MODEL_PLANNER=gpt-oss-120b   DR_API_KEY_PLANNER=...
    DR_ENDPOINT_RESEARCHER=...           DR_MODEL_RESEARCHER=gpt-oss-120b
    DR_ENDPOINT_EXTRACTOR=...            DR_MODEL_EXTRACTOR=nemotron-nano
    DR_ENDPOINT_VERIFIER=...             DR_MODEL_VERIFIER=nemotron-nano
    DR_ENDPOINT_WRITER=...               DR_MODEL_WRITER=gemma
    DR_ENDPOINT_JUDGE=...                DR_MODEL_JUDGE=gemma

Unset roles fall back to the DEFAULT role. Run `scripts/probe_endpoints.py` first and record
tool-calling / parallel-call / JSON support per model in docs/endpoints.md.

A `.env` file (repo root or current directory; see `.env.example`) is loaded into the process
environment on first use without overriding variables that are already set. Values are never
logged or printed by this module.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import BaseMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import Field

Role = Literal["planner", "router", "researcher", "writer", "verifier", "extractor", "judge"]

# Default role -> intended model family (see CLAUDE.md). Override with env vars.
ROLE_DEFAULTS: dict[str, str] = {
    "planner": "gpt-oss",
    "router": "gpt-oss",
    "researcher": "gpt-oss",
    "extractor": "nemotron-nano",
    "verifier": "nemotron-nano",
    "writer": "gemma",
    "judge": "gemma",
}


@dataclass(frozen=True)
class EndpointConfig:
    base_url: str
    model: str
    api_key: str
    supports_tools: bool = True          # from probe; writer/judge may be False (Gemma)
    supports_parallel_tools: bool = True  # from probe
    max_context: int = 128_000
    temperature: float = 0.0
    reasoning_effort: str | None = None  # GPT-OSS: low|medium|high
    timeout_s: float = 90.0              # per request (DR_TIMEOUT_<ROLE>); stage deadlines cap it further
    max_retries: int = 1                 # client-side retries (DR_RETRIES_<ROLE>); a dead endpoint costs ~2x timeout
    max_tokens: int | None = None        # per-reply cap (DR_MAX_TOKENS_<ROLE>); bounds reasoning models' thinking
    thinking: bool = True                # DR_THINKING_<ROLE>=0 disables a reasoning model's thinking (vLLM/NIM
                                         # chat_template_kwargs.enable_thinking); writer/judge: 88 s -> 3 s per call


_REPO_ROOT = Path(__file__).resolve().parents[2]
_dotenv_done = False


def load_dotenv(path: Path | None = None, override: bool = False) -> list[str]:
    """Load KEY=VALUE lines from a .env file into os.environ. Returns the keys it set.

    With no `path`, tries `<repo>/.env` then `./.env`. Blank lines and `#` comments are
    skipped, a leading `export ` and surrounding quotes are tolerated. Existing variables
    win unless `override=True`. No dependency, and values are never echoed.
    """
    candidates = [path] if path else [_REPO_ROOT / ".env", Path.cwd() / ".env"]
    for p in candidates:
        if p is None or not p.is_file():
            continue
        set_keys: list[str] = []
        for raw in p.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            line = line.removeprefix("export ")
            key, value = line.split("=", 1)
            key, value = key.strip(), value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
                value = value[1:-1]
            if key and (override or key not in os.environ):
                os.environ[key] = value
                set_keys.append(key)
        return set_keys
    return []


def _ensure_dotenv() -> None:
    global _dotenv_done
    if not _dotenv_done:
        _dotenv_done = True
        load_dotenv()


def endpoint_for(role: str) -> EndpointConfig:
    _ensure_dotenv()
    r = role.upper()
    base = os.getenv(f"DR_ENDPOINT_{r}") or os.getenv("DR_ENDPOINT_DEFAULT", "http://localhost:8000/v1")
    model = os.getenv(f"DR_MODEL_{r}") or os.getenv("DR_MODEL_DEFAULT", ROLE_DEFAULTS.get(role, "gpt-oss"))
    key = os.getenv(f"DR_API_KEY_{r}") or os.getenv("DR_API_KEY_DEFAULT", "EMPTY")
    tools = os.getenv(f"DR_TOOLS_{r}", "1") != "0"
    par = os.getenv(f"DR_PARALLEL_TOOLS_{r}", "1") != "0"
    effort = os.getenv(f"DR_EFFORT_{r}") or None
    timeout = float(os.getenv(f"DR_TIMEOUT_{r}") or os.getenv("DR_TIMEOUT_DEFAULT") or 90)
    retries = int(os.getenv(f"DR_RETRIES_{r}") or os.getenv("DR_RETRIES_DEFAULT") or 1)
    mt = os.getenv(f"DR_MAX_TOKENS_{r}") or os.getenv("DR_MAX_TOKENS_DEFAULT")
    thinking = (os.getenv(f"DR_THINKING_{r}") or os.getenv("DR_THINKING_DEFAULT") or "1") != "0"
    return EndpointConfig(base_url=base, model=model, api_key=key, supports_tools=tools,
                          supports_parallel_tools=par, reasoning_effort=effort,
                          timeout_s=timeout, max_retries=retries, max_tokens=int(mt) if mt else None,
                          thinking=thinking)


def get_llm(role: Role, **overrides):
    """Return a LangChain chat model for `role`. Imported lazily."""
    from langchain_openai import ChatOpenAI

    cfg = endpoint_for(role)
    kwargs = {"base_url": cfg.base_url, "model": cfg.model, "api_key": cfg.api_key,
              "temperature": cfg.temperature, "timeout": cfg.timeout_s, "max_retries": cfg.max_retries}
    if cfg.reasoning_effort:
        kwargs["reasoning_effort"] = cfg.reasoning_effort  # top-level ChatOpenAI field (model_kwargs warns)
    if cfg.max_tokens:
        kwargs["max_tokens"] = cfg.max_tokens
    if not cfg.thinking:
        kwargs["extra_body"] = {"chat_template_kwargs": {"enable_thinking": False}}
    kwargs.update(overrides)
    return ChatOpenAI(**kwargs)


def get_fake_llm(responses: list[str]):
    """Deterministic stand-in for tests (no network)."""
    from langchain_core.language_models.fake_chat_models import FakeListChatModel

    return FakeListChatModel(responses=responses)


class ScriptExhausted(RuntimeError):
    """A ScriptedChatModel ran out of scripted replies: a test-script bug, never a model error."""


class ScriptedChatModel(BaseChatModel):
    """Deterministic chat model for harness tests (no network).

    `script` items are AIMessages (with or without tool_calls) or callables
    `(messages) -> AIMessage` for replies that depend on the transcript. `bind_tools` records the
    tool names and returns self, so loop code that binds tools runs unchanged. Every prompt the
    model saw is kept in `seen` for assertions. Create a fresh AIMessage per script item: the
    harness assigns message ids in place.
    """

    script: list[Any] = Field(default_factory=list)
    seen: list[list[BaseMessage]] = Field(default_factory=list)
    bound_tools: list[str] = Field(default_factory=list)
    last_kwargs: dict[str, Any] = Field(default_factory=dict)   # e.g. the per-call timeout a caller passed
    model_name: str = "scripted"
    timeout: float | None = None                                # mirrors ChatOpenAI's client timeout for tests

    @property
    def _llm_type(self) -> str:
        return "scripted"

    def bind_tools(self, tools, **kwargs):  # mirrors BaseChatModel's loose signature
        self.bound_tools = [getattr(t, "name", getattr(t, "__name__", str(t))) for t in tools]
        return self

    def _generate(self, messages, stop=None, run_manager=None, **kwargs) -> ChatResult:
        if not self.script:
            raise ScriptExhausted("ScriptedChatModel: no scripted reply left for this call")
        item = self.script.pop(0)
        msg = item(messages) if callable(item) else item
        self.seen.append(list(messages))
        self.last_kwargs = dict(kwargs)
        return ChatResult(generations=[ChatGeneration(message=msg)])


def get_scripted_llm(script: list[Any]) -> ScriptedChatModel:
    """Chat model that replays `script` in order; see ScriptedChatModel."""
    return ScriptedChatModel(script=list(script))
