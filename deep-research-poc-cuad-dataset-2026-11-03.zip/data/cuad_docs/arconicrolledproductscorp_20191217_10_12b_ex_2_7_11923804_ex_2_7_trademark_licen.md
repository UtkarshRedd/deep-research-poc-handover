<!-- page 1 -->
# FORM OF TRADEMARK LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| SEC Filing Date | 2019-12-17 |
| Parties | ARCONIC INC. ("Licensee"); ARCONIC ROLLED PRODUCTS CORP. ("Licensor") |
| Source | CUAD v1 / ArconicRolledProductsCorp_20191217_10-12B_EX-2.7_11923804_EX-2.7_Trademark License Agreement |

Exhibit 2.7 FORM OF TRADEMARK LICENSE AGREEMENT THIS TRADEMARK LICENSE AGREEMENT (this "Agreement"),
made and entered into as of the [ ] day of [ ], 2020 (the "Effective Date"), by and between ARCONIC
INC., a corporation organized under the laws of Delaware ("Licensee") and ARCONIC ROLLED PRODUCTS
CORP., a corporation organized under the laws of Delaware ("Licensor"). WHEREAS, Licensor and
Licensee entered into a Separation and Distribution Agreement having an effective date of the [ ]
day of [ ], 2020 ("Separation and Distribution Agreement"); unless specifically defined in this
Agreement, any capitalized term in this Agreement shall have the meaning set forth in the Separation
and Distribution Agreement. WHEREAS, Licensor formerly operated as a business unit of Licensee;
WHEREAS, as part of and further to the Separation and Distribution Agreement: (a) Licensor and
Licensee are now two separate publicly traded companies; and (b) Licensor was assigned all right,
title, and interest to the trademark "ARMX" (the "Licensed Mark"); WHEREAS, Licensee wishes to
license from Licensor the right to the Licensed Mark as hereinafter defined below; WHEREAS, Licensee
wishes to obtain from Licensor, subject to the terms and conditions set forth in this Agreement, the
right and license to use, have used, manufacture, have manufactured, sell, have sold, advertise,
have advertised, import, have imported, export, have exported, offer for sale, and have offered for
sale the Licensed Products (later defined) using the Licensed Mark (the "Licensed Purpose");
WHEREAS, Licensor is willing to grant such rights, upon the terms and subject to the conditions set
forth in this Agreement. NOW, THEREFORE, in consideration of the mutual agreements, provisions and
covenants contained in this Agreement, and for other good and valuable consideration, the receipt
and sufficiency of which are hereby acknowledged, the parties, intending to be legally bound, hereby
agree as follows:

1

Source: ARCONIC ROLLED PRODUCTS CORP, 10-12B, 12/17/2019
<!-- page 2 -->
1. GRANT AND SCOPE OF LICENSE. 1.1 Grant of License. Licensor on behalf of itself and its Affliates
hereby grants to Licensee the limited licenses to use and have used the Licensed Mark: (i) for the
Licensed Products as set forth on Schedule 2; and (ii) as set forth on Schedule 1, concerning
agreements entered into by Licensee prior to the Effective Date ("Existing Agreements"). For the
avoidance of doubt, Licensor also grants to Licensee and its subsidiaries and affiliates a
non-exclusive, worldwide royalty-free license for continued use of the Licensed Mark for the
production and sale of inventory containing the Licensed Mark applied to such products during the
Transition Period as set forth in section 8.2 of the Separation and Distribution Agreement and in
Schedule 2 of this Agreement. Licensee will not, however, use the Licensed Mark except for the
production and sale of inventory as provided in this Section 1.1 and in Section 8.2 of the
Separation and Distribution Agreement and Schedule 2 of this Agreement. For avoidance of doubt, to
the extent that any of the licenses granted by the terms of this Agreement include any right to
sublicense, such right to sublicense shall extend to Licensee's subsidiaries and joint venturers.
1.2 Goodwill. Licensee expressly recognizes and acknowledges that its use of the Licensed Mark shall
inure solely to the benefit of Licensor, and shall not confer on Licensee any ownership rights to
the Licensed Mark. Licensee agrees and covenants that it shall not challenge, contest, or take any
actions inconsistent with Licensor's exclusive rights of ownership of the Licensed Mark. 1.3
Trademark Notices. All print and electronic displays of the Licensed Mark by Licensee shall include
at Licensor's option, a notice to the effect that the Licensed Mark are owned by Licensor and used
by Licensee under license from Licensor. 1.4 Licensee Cooperation. Licensee agrees to reasonably
cooperate with Licensor in achieving registration of the Licensed Mark worldwide, and in maintaining
and protecting existing registrations therefor at Licensor's sole expense. Licensee shall execute
any and all documents which Licensor may reasonably request in support of such registrations, and,
at Licensor's request, Licensee shall provide use evidence, testimony, and documentation that may be
required in any ex parte or inter partes administrative proceedings and prosecutions, maintenance
and renewals involving registrations of the Licensed Mark, at Licensee's sole expense. 1.5 Quality
Control, Licensor Approvals. Licensor, as owner of the Licensed Mark, shall have the right at all
times to control and approve the nature and quality of the Licensed Products (and the Licensed Mark
thereon), and to inspect Licensee's business operations upon reasonable prior notice for the purpose
of ensuring that a high level of quality of the Licensed Products is being maintained by Licensee.
At Licensor's reasonable request during each calendar year, Licensee shall submit samples to
Licensor, at no cost to Licensor, and shall not materially depart therefrom without Licensor's prior
express written consent. The Licensed Products, as well as all promotional, packaging and
advertising material relative thereto, shall include all appropriate legal notices as required by
Licensor. No more frequently than once per year, a third party auditor chosen by Licensor and
approved by Licensee, such approval not to be unreasonably withheld, shall be entitled at any time
on reasonable notice to the Licensee to enter, during regular business hours, any premises used by
the Licensee or its manufacturers for the manufacture, packaging or storage of the Licensed
Products, to inspect such premises, all plant, workforce and machinery used for manufacture,
packaging or storage of Licensed Products and all other aspects of the manufacture, packaging and
storage of Licensed Products ("Access Rights"). Prior to exercising such Access Rights, the third
party auditor shall enter into a nondisclosure agreement with Licensee that, among other terms
deemed acceptable by Licensee and such third party auditor, shall: (a) limit the content of any
report made by the third party auditor to Licensor to a description of the manner in which, and the
conditions under which, the Licensed Mark are used by Licensee or its manufacturers; and (b) prevent
the disclosure of any of Licensee's trade secrets and/or Confidential Information. To the extent
reasonably practicable, all Licensed Products shall include notices on labeling and packaging for
the Licensed Products stating that the Licensed Mark is owned by Licensor and used by Licensee under
license from Licensor. The Licensed Products shall be of a quality commensurate with previous
production or the samples approved by Licensor. If the quality of a class of the Licensed Products
falls below such standards, Licensee shall use commercially reasonable efforts to restore such
quality. In the event that Licensee has not taken appropriate steps to restore such quality within
one-hundred twenty (120) days after notification by Licensor, Licensor shall have the right to
terminate this Agreement.

2

Source: ARCONIC ROLLED PRODUCTS CORP, 10-12B, 12/17/2019
<!-- page 3 -->
1.6 Compliance with Trademark Usage Guidelines. Licensee agrees to comply with Licensor's trademark
usage guidelines and any other policies and requirements applicable to the Licensed Mark. 2.
ENFORCEMENT OF INTELLECTUAL PROPERTY. If legally able and without breaching any confidentiality
provisions of a contract with a third party, in the event that Licensee becomes aware that any third
party is infringing the Licensed Mark, Licensee shall promptly notify Licensor and provide pertinent
details. Licensor shall have the right in its sole discretion to bring a legal action for
infringement against the third party, together with the right to enforce and collect any judgment
thereon. If Licensor elects to exercise such right, Licensee shall, at Licensor's request, provide
reasonable assistance to Licensor, at the sole expense of Licensor. 3. INDEMNIFICATION. Licensee
shall defend, indemnify and hold harmless Licensor and its officers, directors, employees, agents,
corporate subsidiaries, parents, and affiliates ("Licensor Indemnitees") from and against any and
all demands, claims, actions or causes of action, assessments, deficiencies, damages, losses,
liabilities and expenses (including, without limitation, reasonable expenses of investigation and
attorneys' fees and expenses), incurred in conjunction with or arising out of or relating to any
third-party claim concerning the Licensed Products and any acts or omissions of Licensee with
respect to the Licensed Mark, including without limitation Licensee's performance of its obligations
under this Agreement. The Licensor Indemnitees agree to cooperate with Licensee, at Licensee's
expense, to provide copies of any documents or materials reasonably requested by Licensee in support
of its defense of the Licensor Indemnitees. 4. TERM AND TERMINATION. 4.1 Term. The Term of this
Agreement will commence on the Effective Date and shall continue for the time periods set forth in
Schedules 1 and 2 unless sooner terminated in accordance with the terms of this Agreement. 4.2
Termination for Breach. Licensor and Licensee will be entitled to terminate this Agreement by
written notice to the other party in the event the other party is in material breach of any of its
obligations hereunder and shall fail to remedy any such default within one hundred twenty (120) days
after notice thereof by the non-breaching party. 4.3 Termination Upon Bankruptcy. Either party may
terminate this Agreement by written notice to the other in the event of: (a) the other party's
making assignment for the benefit of its creditors or filing a voluntary petition under any
bankruptcy or insolvency law, under the reorganization or arrangement provisions of the United
States Bankruptcy Code, or under the provisions of any law of like import; or (b) the filing of an
involuntary petition against the other party under any bankruptcy or insolvency law, under the
reorganization or arrangement provisions of the United States Bankruptcy Code, or under any law of
like import; or (c) the appointment of a trustee or receiver for the party or its property.

3

Source: ARCONIC ROLLED PRODUCTS CORP, 10-12B, 12/17/2019
<!-- page 4 -->
4.4 Survival of Obligations; Return of Confidential Information. Notwithstanding any expiration or
termination of this Agreement, Sections 1.4, 3, 4.4, 5.1, 5.2, and 6.1 through 6.11 shall survive
and continue to be enforceable as set forth herein. Upon any expiration or termination of this
Agreement, Licensee shall promptly return to Licensor, or at Licensor's direction, destroy all
Licensor confidential information and all copies thereof in Licensee's possession. 5.
REPRESENTATIONS AND WARRANTIES. 5.1 Licensor represents and warrants to Licensee that Licensor's
performance of its obligations under this Agreement is not in conflict with, and will not result in
a breach of or constitute a default under, any other contract, instrument, rule of law or order of
any court or governmental agency to which Licensor is a party or by which Licensor is bound. 5.2
Licensee represents and warrants to Licensor that Licensee's performance of its obligations under
this Agreement are not in conflict with, and will not result in a breach of or constitute a default
under, any other contract, instrument, rule of law or order of any court or governmental agency to
which Licensee is a party or by which Licensee is bound. 5.3 No Warranty. But for the warranty set
forth in section 5.1., supra, Licensor, by this Agreement, makes no warranties or guarantees, either
express or implied, arising by law or otherwise with regard to the Licensed Mark and/or the Licensed
Products. In particular, Licensor assumes no obligation and makes no representations or warranties
hereunder, express or implied, in law or in fact, with respect to: (i) the utility, quality or
characteristics of the Licensed Mark or any use, embodiment, or modification thereof; (ii) the use
of any Licensed Product, embodiments, or modifications thereof, or (iii) whether such Licensed
Products, or any use, embodiments, or modifications thereof, would be in compliance with any
federal, state or local laws, regulations, standards or criteria with respect to any claim which may
arise in connection with any sale or use of Licensed Products. LICENSOR SPECIFICALLY DISCLAIMS, AND
WILL HAVE NO OBLIGATION OR LIABILITY FROM THIS AGREEMENT WITH REGARD TO THE LICENSED MARK FOR ANY:
(1) IMPLIED WARRANTY OF MERCHANTABILITY; (2) IMPLIED WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE;
(3) IMPLIED WARRANTY OF NONINFRINGEMENT; AND (4) IMPLIED WARRANTY OF ANY OTHER TYPE. 6.
MISCELLANEOUS. 6.1 Governing Law. This Agreement shall be governed by and interpreted in accordance
with the laws of the State of Delaware without regard to its conflicts of law principles. 6.2
Jurisdiction and Venue. Each of the parties: (a) submits to the exclusive jurisdiction of any state
or federal court sitting in Wilmington, Delaware for any action or proceeding arising out of, or
relating to, this Agreement; (b) agrees that all claims in respect of the action or proceeding may
be heard and determined in any such court; and (c) agrees not to bring any action or proceeding
arising out of, or relating to, this Agreement in any other court. Each of the parties hereto waives
any defense of inconvenient forum to the maintenance of any action or proceeding so brought and
waives any bond, surety or other security that might be required of any other party with respect
thereto. Each party agrees that a final judgment in any action or proceeding so brought will be
conclusive and may be enforced by suit on the judgment or in any other manner provided by law or at
equity.

4

Source: ARCONIC ROLLED PRODUCTS CORP, 10-12B, 12/17/2019
<!-- page 5 -->
6.3 Waiver. The waiver by one party of a breach or a default of any provision of this Agreement by
the other party shall not be construed as a waiver of any succeeding breach of the same or any other
provision, nor shall any delay or omission on the part of a party to exercise or avail itself of any
right, power or privilege that it has or may have hereunder operate as a waiver of any right, power
or privilege by such party. 6.4 Waiver of Jury Trial. TO THE FULLEST EXTENT PERMITTED BY APPLICABLE
LAW EACH PARTY HEREBY IRREVOCABLY WAIVES ALL RIGHT OF TRIAL BY JURY IN ANY ACTION, PROCEEDING,
CLAIM, OR COUNTERCLAIM ARISING OUT OF OR IN CONNECTION WITH THIS AGREEMENT OR ANY MATTER ARISING
HEREUNDER. 6.5 Notices. Any notice or other communication under this Agreement shall be effective
when: (a) delivered in person; (b) if mailed, when deposited in the mail by registered or certified
mail, return receipt requested; or (c) if delivered by overnight mail by a recognized overnight
carrier (e.g., FedEx, UPS, DHL). All such notices and other communications shall be addressed to the
other party as follows: If to Licensor: If to Licensee: Arconic Inc. Arconic Rolled Products Corp.
201 Isabella Street 201 Isabella Street Pittsburgh, PA 15212 Pittsburgh, PA 15212 Attn.: General
Counsel Attn: General Counsel 6.6 No Agency. Nothing herein shall be deemed to constitute Licensor,
on the one hand, or Licensee, on the other hand, as the agent or representative of the other, or as
joint venturers or partners for any purpose. Neither Licensor, on the one hand, nor Licensee, on the
other hand, shall be responsible for the acts or omissions of the other. No party will have
authority to speak for, represent or obligate the other party in any way without prior written
authority from such other party. 6.7 Entire Agreement. This Agreement and the Separation and
Distribution Agreement together contain the full understanding of the parties with respect to the
subject matter hereof and supersedes all prior understandings and writings relating thereto. No
waiver, alteration or modification of any of the provisions hereof shall be binding unless made in
writing and signed by the parties. 6.8 Headings. The headings contained in this Agreement are for
convenience of reference only and shall not be considered in construing this Agreement.

5

Source: ARCONIC ROLLED PRODUCTS CORP, 10-12B, 12/17/2019
<!-- page 6 -->
6.9 Severability. In the event that any provision of this Agreement is held by a court of competent
jurisdiction to be unenforceable because it is invalid or in conflict with any law of any relevant
jurisdiction, the validity of the remaining provisions shall not be affected and the invalid
provision shall be severed herefrom. 6.10 Assignment. This Agreement may not be assigned by Licensee
without the consent of Licensor which consent shall not be unreasonably withheld. Notwithstanding
the foregoing, no such consent of Licensor is required under this Agreement in the event of a Change
of Control of Licensee so long as: (a) the resulting, surviving or transferee Person assumes all the
obligations of the Licensee by operation of Law or pursuant to an agreement in form and substance
reasonably satisfactory to the Licensor; and (b) the licenses granted herein shall not be
transferrable or sublicensable to Affiliates of such Person unless such Affiliates were Affiliates
of Licensee prior to such Change of Control. 6.11 Counterparts; Images Signatures. This Agreement
may be executed in any number of counterparts, each of which shall be deemed an original but all of
such together shall constitute one and the same instrument. Scanned PDF copies of signatures and
facsimile copies of signatures may be deemed original signatures. IN WITNESS WHEREOF, the parties
have caused this Agreement to be executed by their respective authorized officers as of the
Effective Date. ARCONIC INC. By Name: Title: ARCONIC ROLLED PRODUCTS CORP. By Name: Title:

6

Source: ARCONIC ROLLED PRODUCTS CORP, 10-12B, 12/17/2019
