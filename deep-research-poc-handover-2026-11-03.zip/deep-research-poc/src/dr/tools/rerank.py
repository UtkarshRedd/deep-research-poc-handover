"""Optional local cross-encoder rerank for the first move (PLAN open decision 4, TODO.md item 4).

No-op unless `Config.ENABLE_LOCAL_RERANK` is set AND `sentence-transformers` is installed
(extra `rerank`). There is no embedding or rerank endpoint, so this is the only rerank path.
Returns hits in a new order; never adds or removes hits.
"""
from __future__ import annotations

from ..config import DEFAULT, Config
from ..models import SearchHit

_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"


def rerank(query: str, hits: list[SearchHit], config: Config = DEFAULT, top_n: int = 50) -> list[SearchHit]:
    if not config.ENABLE_LOCAL_RERANK or len(hits) < 2:
        return hits
    try:
        from sentence_transformers import CrossEncoder
    except ImportError:
        return hits
    head, tail = hits[:top_n], hits[top_n:]
    scores = CrossEncoder(_MODEL).predict([(query, h.snippet) for h in head])
    order = sorted(range(len(head)), key=lambda i: -float(scores[i]))
    reranked = [head[i].model_copy(update={"rank": r + 1, "score": round(float(scores[i]), 3)}) for r, i in enumerate(order)]
    return reranked + tail
