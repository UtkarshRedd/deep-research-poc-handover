# Under which jurisdiction's law is the agreement between Premier Biomedical, Inc. and Te...

*Question:* Under which jurisdiction's law is the agreement between Premier Biomedical, Inc. and Technology Health, Inc. governed?

## Identify Governing Law Clause

The agreement between Premier Biomedical, Inc. and Technology Health, Inc. is an Intellectual Property Agreement entered into on May 12, 2020. [f57b577c0db58ef4 p.1] Section 8 of the agreement states that the agreement and the rights of the parties shall be governed by and construed in accordance with the laws of the Commonwealth of Pennsylvania. [f57b577c0db58ef4 p.5] The governing law provision specifies that this applies to all matters of construction, validity, performance, and enforcement without giving effect to the principles of conflict of laws. [f57b577c0db58ef4 p.5]

## Not established by the evidence

[GAP] No evidence was found for: Extract the exact jurisdiction named in the governing law clause to determine the applicable legal framework.

## Verification appendix

Claims: 4 · supported: 3 · partially: 0 · dropped: 0 · gaps: 1 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Extract Jurisdiction

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e2→[f57b577c0db58ef4 p.1] |  |
| s1.2 | s1 | keep | 1.00 | e1→[f57b577c0db58ef4 p.5] |  |
| s1.3 | s1 | keep | 1.00 | e1→[f57b577c0db58ef4 p.5] |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [f57b577c0db58ef4 p.5 L219-222] keep (1.0): "8. VENUE. This Agreement and the rights of the Parties hereunder shall be governed by and construed in accordance with the laws of the Commonwealth of Pennsylvania including all matters of construction, validity, performance, and enforcemen…"
- e2 [f57b577c0db58ef4 p.1 L10-18] keep (1.0): "This Intellectual Property Agreement (this "Agreement") is entered into on May 12, 2020 ("Effective Date"), concerning the pursuits set forth herein for the collective development, implementation and commercialization of a potential treatme…"
