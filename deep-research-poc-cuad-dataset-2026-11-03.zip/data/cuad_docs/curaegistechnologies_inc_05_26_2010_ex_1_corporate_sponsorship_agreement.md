<!-- page 1 -->
# CORPORATE SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 2010-05-18 |
| Parties | Phoenix Performance, LLC ("Vendor"); Torevic Inc. ("Torvec") |
| Source | CUAD v1 / CURAEGISTECHNOLOGIES,INC_05_26_2010-EX-1-CORPORATE SPONSORSHIP AGREEMENT |

CORPORATE SPONSORSHIP AGREEMENT

This agreement (the "Agreement") is entered into as of May 18, 2010, (the "Effective Date") by and
between Phoenix Performance, LLC, 481 Schuylkill Road, Phoenixville, PA 19460 ("Vendor") and Torvec
Inc.., a New York corporation with its principal place of business located at 1999 Mt Read Blvd,
Building 3, Rochester, NY. 14615 (Torvec).

RECITALS

WHEREAS, the parties desire to enter into an agreement regarding promotional, marketing and
sponsorship activities designed to be of mutual benefit as described herein; and

NOW, THEREFORE, for and in consideration of the mutual covenants, rights and obligations set forth
in this Agreement, the parties agree as follows:

1. Term

The term of this Agreement (the "Term") shall commence on the Effective Date and conclude on October
31, 2010, unless renewed by agreement or sooner terminated in accordance with this Agreement.

2. Termination

(a) Either party may terminate this Agreement immediately if the other party (i) files a petition
commencing a voluntary case under the Bankruptcy Code; (ii) makes a general assignment for the
benefit of creditors; (iii) admits in writing its inability to pay its debts as they become due;
(iv) seeks, consents to or acquiesces in the appointment of any trustee, receiver or liquidator of
it or any part of its property; or (v) has commenced against it an involuntary case under the
Bankruptcy Code or a proceeding under any receivership, composition, readjustment, liquidation,
insolvency, dissolution or like law or statute, which case or proceeding is not dismissed or vacated
within sixty (60) days.

(b) Upon termination of this Agreement, NEITHER PARTY SHALL BE LIABLE TO THE OTHER FOR ANY
CONSEQUENTIAL, EXEMPLARY, SPECIAL, INCIDENTAL OR PUNITIVE DAMAGES, EVEN IF IT HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGES, WHICH ARE RELATED TO THE AGREEMENT OR ITS BREACH.

Preparation, maintenance and running of one (1) T-1 C5 Corvette race vehicle to race in:

a. 1 round of the World Challenge series in the GTS class (Mosport Double);

b. 4 rounds of SCCA National Racing (events to be finalized but at this time expected to be NJMP,
Road America, Watkins Glen Double);

c. the SCCA runoffs at Road America.

.

5. Payment and Other Consideration

As consideration for the benefits it receives under this Agreement, Torvec shall provide the
following to Vendor:

See Exhibit A

The schedule set forth in Exhibit A will constitute invoicing for the events. Notwithstanding the
above, Torvec may, in its sole discretion, cancel its participation in any of the above-referenced
events by notifying Vendor of such cancellation not later than two weeks prior to the due date(s)
for payment hereunder. All checks shall be made payabe to: Phoenix Performance, LLC and mailed to
481, Schuylkill Rd, Phoenixville, Pa. 19460.

(b) Equipment

3. Responsibilities and Benefits

Vendor shall be responsible for the following in 2010:

4. Torvec Benefits

During the Term of this Agreement, Torvec shall be entitled to the following sponsorship benefits:

a) Primary sponsorship rights to all of Vendor's participation efforts in the above race events.

b) The right to specify and approve all team sponsorship identification markings, logos, graphics,
etc. for vehicle livery, team equipment and uniforms.

c) Sole right to disapprove any driver selected by Vendor for any reason. The driver for these
events will be John Heinricy.

(a) Payment Schedule
<!-- page 2 -->
Torvec will provide to Vendor the use of up to 2 Differential units to be used in the T-1 C5
Corvette for testing, evaluation and racing purposes..

6. Grant of License

Each party shall have a non-exclusive, royalty free, non-transferable license to use the name, logo,
any item used in connection with that name or logo, and the registered symbols and trademarks of the
other party (the "Trademarks") only for the purposes set forth in this Agreement. Neither party will
use the other's Trademarks without obtaining the prior approval of the other party. Any materials
using Trademarks which are submitted to one party by the other are deemed to be approved if the
receiving party has not disapproved the material in writing within ten (10) business days after it
receives a request for approval. The parties shall not unreasonably disapprove any material. If any
material is disapproved by one party, it will advise the other of the specific reasons for the
disapproval. Once materials are approved by one party, the other party may make multiple uses of
those approved materials and any images, likenesses, and photographs contained therein in the same
or substantially similar media without seeking the other party's further approval.

The approval by a party to use its registered symbols or trademarks does not convey any rights,
title or interest to the other party in and to such registered symbols and trademarks. The party
receiving permission to use a registered symbol or trademark will (i) follow all reasonable
instructions from the

owner regarding that symbol or trademark; and (ii) take all reasonable steps to protect it,
including, when appropriate, using the symbols "®" or "™". The rights granted under this Section 6
cease upon the expiration or termination of this Agreement.

7. Confidentiality

It is recognized that Torvec is a public company and as such, will file this Agreement with the
United States Securities and Exchange Commission in accordance with rules and regulations
promulgated by the Commission. It is also recognized that Torvec is entering into this Agreement in
order to promote the aftermarket sale of its IsoTorque differential and to that end, either party
may issue press and other informational releases, announcements, promotional programs, packages and
materials relating to the subject matter of this Agreement without the other party's approval,
provided that both parties shall have the right to comment upon and offer suggestions with respect
to such releases,

programs, etc. prior to their actual release.

8. Insurance

Vendor shall maintain insurance for not less than the following limits and coverage with duly
licensed insurance companies having an A.M. Best rating of A-, X or better. In addition to covering
all of the normal operations of Vendor, this insurance shall cover all of the activities and events
described under this Agreement.

9. Representations

Vendor represents and warrants to Torvec the following: (i) it has the authority to enter into this
Agreement and to perform hereunder in accordance with its provisions; (ii) no other person or entity
has the right to be the exclusive automotive sponsor of the activities and the events set forth in
this Agreement; and (iii) it will perform its obligations under this Agreement in compliance with
all applicable laws, rules and regulations.

10. Notices

All notices provided herein shall be in writing and are effective upon receipt if hand delivered,
sent by overnight courier (with ability to confirm receipt), by fax or by registered or certified
mail, return receipt requested, addressed to the respective parties hereto as follows:

Either party may change its address for notice by giving written notice to the other party.

11. Amendments

This Agreement shall not be altered or amended, nor any rights hereunder waived, except by written
agreement between both parties. No waiver of any term, provision or condition of this Agreement, in
any one or more instances, shall be deemed to be or construed as a further or continuing waiver of
any other term, provision or condition.

12. Assignment

Neither party may assign its rights or powers under this Agreement without the express written
consent of the other, which consent shall

• General Liability: Vendor shall maintain commercial general liability (CGL) insurance with a limit
of not less than $1 million each occurrence. CGL coverages shall be written on ISO occurrence form
CG 00 01 or a substitute form providing equivalent coverage and shall cover liabilities arising from
events, premises, operations, independent contractors, products-completed operations, personal
injury and advertising injury, and liability assumed under an insured contract. Subaru of America,
Inc., its parent and subsidiaries shall be included as additional insureds under the CGL using ISO
additional insured endorsement CG 20 10 or a substitute providing equivalent coverage.

If to Vendor(s): If to Torvec: Phoenix Performance, LLC Torvec, Inc.. 481 Schuylkill Road 1999 Mt
Read Blvd Phoenixville, PA 19460 Building 3 ATTN: JOE AQUILANTE Rochester, NY. 14615 Fax:
610.482.0142
<!-- page 3 -->
not be unreasonably withheld. Any attempt to assign without the other party's consent will be null
and void and will afford the non-assigning party the right to immediately cancel and terminate this
Agreement.

13. No Joint Venture

This Agreement does not constitute and may not be construed as constituting a partnership or joint
venture between the parties. Neither party may obligate or bind the other in any manner whatsoever,
and nothing in this Agreement gives any rights to any third person. At all times, the parties are
independent contractors.

14. Survival

Those provisions of this Agreement which by their nature extend beyond termination or expiration of
this Agreement will survive such termination or expiration.

15. Waiver

No waiver of a breach of any provision of this Agreement is effective unless approved in writing by
the waiving party. If a party at any time fails to demand strict performance by the other of any of
the terms, covenants or conditions set forth in this Agreement, that waiver does not constitute a
waiver of any prior, concurrent, or subsequent breach of the same or any other provision of this
Agreement.

16. Other Instruments

The parties will execute and deliver such other and further instruments and documents as are or may
become necessary to effectuate and carry out the rights, responsibilities, and obligations created
by this Agreement.

17. Paragraph Headings

Paragraph headings in this Agreement are for convenience only. They form no part of this Agreement
and shall not affect its interpretation.

18. Governing Law, Jurisdiction and Venue

This Agreement is to be governed and construed according to the laws of the State of New York
without regard to conflicts of law. The parties agree that each of them hereby submits to the
jurisdiction of the New York State and federal courts for the purpose of resolving any dispute
arising under this Agreement and that the exclusive venue for resolution of such disputes shall be
state or federal courts located in Monroe County, New York.

20. Entire Agreement

This Agreement contains the entire agreement between the parties with respect to the subject matter
herein and supercedes all prior understandings, written or oral, between the parties with respect to
this subject matter. No variations, modifications, or changes in this Agreement are binding upon any
party to the Agreement unless set forth in a document duly executed by or on behalf of such parties.

21. Force Majeure

Neither party will hold the other liable for failure to comply with any of the terms or conditions
of this Agreement when such failure to comply has been caused by fire, weather, labor dispute,
strike, war, insurrection, terrorism, government restriction or acts of God beyond the reasonable
control of the parties, provided the party failing to comply uses all reasonable diligence to remedy
such failure as promptly as practicable.

22. Severability

If for any reason one or more provisions of this Agreement are held to be invalid, illegal or
unenforceable in any respect, such provision will be deemed deleted, and the deletion will not
affect the validity of other provisions of this Agreement.

23. Construction

The rule of construction to the effect that any drafting ambiguities are to be resolved against the
drafting party will not be employed in the interpretation of this Agreement or any amendments or
exhibits thereto.

IN WITNESS WHEREOF, and intending to be legally bound hereby, the parties have caused this Agreement
to be executed and delivered by their proper and duly authorized officers or representatives as of
the date first above written.

Signature Signature

FOR VENDOR: FOR TORVEC.:

Joseph F. Aquilante, President Print Name and Title of person above

Keith E. Gleasman, President Print Name and Title of person above
