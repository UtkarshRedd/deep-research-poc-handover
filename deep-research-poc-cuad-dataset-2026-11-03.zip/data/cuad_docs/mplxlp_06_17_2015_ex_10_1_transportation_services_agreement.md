<!-- page 1 -->
# TRANSPORTATION SERVICES AGREEMENT
| Field | Value |
|---|---|
| Document Type | Transportation Agreement |
| Agreement Date | 2015-06-11 |
| Parties | Marathon Petroleum Company LP ("Shipper"); Marathon Pipe Line LLC ("MPL"); Marathon Petroleum Company LP and Marathon Pipe Line LLC (jointly as "Parties" and individually as a "Party") |
| Source | CUAD v1 / MPLXLP_06_17_2015-EX-10.1-TRANSPORTATION SERVICES AGREEMENT |

Exhibit 10.1

TRANSPORTATION SERVICES AGREEMENT

THIS TRANSPORTATION SERVICES AGREEMENT (this "Agreement") is dated as of June 11, 2015, by and
between Marathon Petroleum Company LP ("Shipper") and Marathon Pipe Line LLC, a Delaware limited
liability company ("MPL"), both referred to jointly as the "Parties" and each individually as a
"Party".

WITNESSETH

WHEREAS, MPL owns and operates a common carrier pipeline system originating in Ohio, as further
depicted on Exhibit A, that will provide both interstate and intrastate common carrier
transportation services; and

WHEREAS, MPL also operates the assets of Ohio River Pipe Line LLC, a Delaware limited liability
company ("ORPL") and an affiliate of MPL. ORPL is the owner of a common carrier pipeline system
originating in Ohio, as further depicted on Exhibit A, that provides common carrier transportation
services; and

WHEREAS, MPL and ORPL desire to combine their systems (together referred to as the "Pipeline") under
a Joint Agreement (as defined below) in order to undertake certain improvements to provide expanded
capacity on portions of the Pipeline and install additional infrastructure to other portions of the
Pipeline pursuant to a multi-phase capital project (the "Project"); and

WHEREAS, MPL and ORPL conducted a joint binding open season with the understanding that MPL will
file a joint tariff, commencing approximately 30 days prior to the in-service date of the Project,
seeking binding commitments on the Pipeline; and

WHEREAS, Shipper responded to the binding open season and desires to commit to transport a specified
volume of Product (as defined below) on the Pipeline over a multi-year period to destinations as
provided in Exhibit C, subject to and upon the terms and conditions of this Agreement; and

WHEREAS, in exchange for the commitment by Shipper to transport a specific volume of Product on the
Pipeline over a multi-year period, MPL will charge the rates as provided for in Exhibit B; and

NOW THEREFORE, in consideration of the premises and mutual covenants set forth hereinafter, MPL and
Shipper agree as follows:

1. Definitions

"Affiliate" means, with respect to any Person, any other Person that directly or indirectly through
one or more intermediaries' controls, is controlled by or is under common control with, the Person
in question.

"Applicable Law" means any applicable statute, law, regulation, ordinance, rule, determination,
judgment, rule of law, order, decree, permit, approval, concession, grant, franchise, license,
requirement, or any similar form of decision of, or any provision or condition of any permit,
license or other operating authorization issued by any Governmental Authority having or asserting
jurisdiction over the matter or matters in question, whether now or hereafter in effect. "Barrel"
means forty-two (42) U.S. gallons measured at sixty (60) degrees Fahrenheit.

1
<!-- page 2 -->
"Change in Law" means the adoption, implementation or amendment of any Applicable Law by any
Governmental Authority after the Effective Date that causes MPL to incur additional expenses in
order to operate the Pipeline in compliance with such Applicable Law.

"Change in Law Event" means the occurrence of a Change in Law that necessitates the expenditure of
Compliance Costs.

"Compliance Costs" means the expenses in excess of $1,000,000 for a Change in Law Event, related
specifically to the Department of Transportation, Pipeline and Hazardous Materials Safety
Administration or Homeland Security, incurred by MPL to comply with a Change of Law, irrespective of
whether such expenses are to be incurred as a onetime expenditure or periodically for an extended
period. The definition for "Compliance Costs" shall in no way revise or modify the definitions of
Change in Law or Change in Law Event.

"Contract Year" means the period beginning on the project in-service date in conjunction with the
FERC tariff filing, and ending 365 days later (366 days later for any such period that includes a
February 29.)

"Confidential Information" means any proprietary or confidential information that is competitively
sensitive material or otherwise of value to a Party or its Affiliates and not generally known to the
public, including trade secrets, scientific or technical information, design, invention, process,
procedure, formula, improvements, product planning information, marketing strategies, financial
information, information regarding operations, consumer and/or customer relationships, consumer
and/or customer identities and profiles, sales estimates, business plans, and internal performance
results relating to the past, present or future business activities of a Party or its Affiliates and
the consumers, customers, clients and suppliers of any of the foregoing. Confidential Information
includes such information as may be contained in or embodied by documents, substances, engineering
and laboratory notebooks, reports, data, specifications, computer source code and object code, flow
charts, databases, drawings, pilot plants or demonstration or operating facilities, diagrams,
specifications, bills of material, equipment, prototypes and models, and any other tangible
manifestation (including data in computer or other digital format) of the foregoing; provided,
however, that Confidential Information does not include information that a receiving Party can show
(a) has been published or has otherwise become available to the general public as part of the public
domain without breach of this Agreement, (b) has been furnished or made known to the receiving Party
without any obligation to keep it confidential by a third party under circumstances which are not
known to the receiving Party to involve a breach of the third party's obligations to a Party or (c)
was developed independently of information furnished or made available to the receiving Party as
contemplated under this Agreement.

"Construction Costs" means all costs and expenses incurred by MPL in connection with the Project,
including, without limitation, those costs relating to design, asset modification or enhancement and
developmental costs, whether internal or external. Such costs include all expenditures that have
been committed to by MPL via purchase order, contract or otherwise, even if MPL has not remitted
funds for the goods or services that are the subjects thereof.

"Construction Cost Reimbursement" has the meaning set forth in Section 10.5.

"Day" means a period of twenty-four (24) consecutive hours commencing 12:00 a.m. Central Standard
Time, or such other period upon which the Parties may agree.

2
<!-- page 3 -->
"Deficiency Volume" has the meaning set forth in Section 3.5.

"Deliveries" means the volume of Product delivered through the Pipeline.

"Effective Date" has the meaning set forth in Section 2.1.

"Election Deadline" has the meaning set forth in Section 6.6.

"Expansion Notice" has the meaning set forth in Section 6.6.

"Expansion Volume Commitment" has the meaning set forth in Section 6.6.

"Extension Period" has the meaning set forth in Section 2.2.

"FERC" means the Federal Energy Regulatory Commission.

"Force Majeure" means acts of God, fires, floods, storms; compliance with orders of courts or
Governmental Authorities; explosions, wars, terrorist acts, riots, strikes, lockouts or other
industrial disturbances; accidental disruption of service; breakdown of machinery, storage tanks or
pipelines and inability to obtain or unavoidable delays in obtaining material or equipment; and
similar events or circumstances, so long as such events or circumstances are beyond the affected
Party's reasonable control and could not have been prevented by the affected Party's due diligence;
provided, however, that a Party's failure to pay any amounts due hereunder shall not constitute an
event of Force Majeure.

"Force Majeure Notice" has the meaning set forth in Section 5.1.

"Force Majeure Period" has the meaning set forth in Section 5.1.

"Governmental Authority" means any federal, state, local or foreign government or any provincial,
departmental or other political subdivision thereof, or any entity, body or authority exercising
executive, legislative, judicial, regulatory, administrative or other governmental functions or any
court, department, commission, board, bureau, agency, instrumentality or administrative body of any
of the foregoing.

"Initial Term" has the meaning set forth in Section 2.2.

"Joint Agreement" means the agreement between ORPL and MPL to undertake certain improvements to
provide expanded capacity on portions of the ORPL systems and install additional infrastructure to
portions of the MPL systems pursuant to a multi-phase capital project. This agreement will also
establish a joint tariff between ORPL and MPL, which derives both entities local movements and
rates. MPL will ultimately file the joint tariff.

"Monthly Commitment" has the meaning set forth in Section 3.6.

"Person" means any individual, partnership, limited partnership, joint venture, corporation, limited
liability company, limited liability partnership, trust, unincorporated organization or Governmental
Authority or any department or agency thereof.

"Pre-Service Increase Request" has the meaning set forth in Section 3.9.

"Prepaid Transportation Credits" has the meaning set forth in Section 3.6.

3
<!-- page 4 -->
"Product" means the commodities commonly associated as specialty petroleum products, specifically
condensate, natural gasoline, and diluent. Product may also include liquefied petroleum gas
commodities such as butane. Product, as designed in this Agreement, does not refer to finished
gasoline and diesel products.

"Project Capacity" means the aggregate of each system's total capacity that is made available for
Product movements by means of the Project, by either expanding existing pipelines or building new
pipelines.

"Proportionate Share" means, at any given time, the percentage equal to Shipper's volume commitment
divided by the total volume commitments at such time.

"Quarter" means the three (3) calendar month periods, or portion thereof, commencing January 1,
April 1, July 1 and October 1 of each year during Term hereof.

"Quarterly Volume Commitment" means Shipper's commitment to ship, or otherwise pay for, each
Contract Year of the fifteen (15) year term of this Agreement, at posted Pipeline Tariff Rates as
set forth in Exhibit B, which equals a total annual Product volume as determined from Exhibit C.
With respect to the required quarterly volume, the volume of Product is equal to: (a) volume per day
multiplied by; (b) the number of Days in such Quarter. The Quarterly Volume Commitment will be
reduced proportionately for any partial Quarter during the Term.

"Representatives" has the meaning set forth in Section 7.1.

"Requested Expansion Volume Commitment" has the meaning set forth in Section 6.6.

"Shipper Deliveries" means the volume of Product that Shipper as the shipper of record delivered
through the Pipeline.

"Termination Notice" has the meaning set forth in 5.1.

"Tariff" means the intrastate and/or interstate tariffs that set forth the rules, regulations and
rates for services on the Pipeline, including supplements thereto and reissues thereof, under which
Product is transported through the Pipeline.

"Tariff Rates" means the rates set forth in the Tariffs for transportation of Product on the
Pipeline.

"Term" has the meaning set forth in Section 2.2.

"Unsubscribed Capacity" has the meaning set forth in Section 3.9.

1.1 The following Exhibits are attached to and incorporated into this Agreement: Exhibit A - Common
Carrier Pipeline, including Origins and Destinations Exhibit B - Rate and Volume Commitment Table
Exhibit C - Shipper's Submitted Capacity Request Form

2. Effective Date and Term

2.1 This Agreement is effective June 11, 2015 (the "Effective Date"). The Agreement shall continue
through the project's in-service date and for a period of fifteen (15) years after the project's
in-service date ("Initial Term"). MPL shall provide written notice to Shipper

4
<!-- page 5 -->
confirming the project's in-service date. Shipper acknowledges that the overall Project will be
completed in several phases. New infrastructure will be completed first, with additional build-out
projects and expansions completed in succession. MPL will provide a thirty (30) day notice to
Shipper, notifying it of the actual in-service date for the included projects.

2.2 This Agreement shall be binding upon the Parties under the same conditions and provisions for a
time period commencing on the Effective Date and shall continue through the Initial Term. This
Agreement will automatically renew for up to two (2) renewal terms of five (5) years each (each, an
"Extension Period") unless either Party provides the other Party with written notice of its intent
to terminate this Agreement at least six (6) months prior to the end of the Initial Term or the then
current Extension Period. The Initial Term and Extension Period, if any, shall be referred to in
this Agreement as the "Term".

2.3 In the event Shipper does not wish to renew after the Initial Term or Extension Period or
chooses to terminate the Agreement by written notice pursuant to Section 2.2, MPL reserves the
option and right to hold a subsequent open season in which interested shippers can have opportunity
to contract for resulting available volume, rate, and terms.

3. Volume Commitment and Quarterly Deficiency Charges

3.1 Shipper guarantees that during each Contract Year, Shipper will meet its Quarterly Volume
Commitment or, in the event it fails to do so, shall remit to MPL the Quarterly Deficiency Payment
pursuant to Section 3.5. All volumes moved by Shipper on the Pipeline will be subject to the
applicable Tariff Rates and proration policies, as may be amended from time to time in accordance
with FERC methodologies and as provided herein.

3.2 Shipper will have the opportunity to fulfill its Quarterly Volume Commitment on a calendar
quarter basis for condensate, natural gasoline, and diluent service. These three Products are
interchangeable from a volume commitment standpoint and shipping a total volume of any one or
combination of these Products will be applied towards the Quarterly Volume Commitment. Should MPL
proceed with butane service, Shipper will also have the opportunity to fulfill its Quarterly Volume
Commitment on a calendar quarter basis for butane service, separate from condensate, natural
gasoline, and diluent service.

3.3 Shipper shall be deemed to have shipped its Quarterly Volume Commitment on the Pipeline if the
quantity of Product that Shipper ships on the Pipeline in any Quarter equals at least the Quarterly
Volume Commitment for such Quarter.

3.4 Shipper agrees to pay MPL monthly: (a) the Tariff Rates in effect for all Shipper Deliveries
transported by MPL on the Pipeline during such month; and (b) any loading, handling, transfer and
other charges incurred with respect to such Shipper Deliveries for such month in accordance with the
provisions as set forth in the Tariffs (or any other tariffs that may be applicable to such Shipper
Deliveries). If the amount owed by Shipper is the subject of a good faith dispute, Shipper shall be
obligated to pay only the undisputed portion of such amount pending the resolution of such dispute
in accordance with this Agreement. Late payments of undisputed amounts shall accrue interest at a
rate equal to two percent (2%) per annum, until paid. Such payments will be paid by Shipper to MPL
within fifteen (15) Days of the invoice date or resolution of any dispute, if applicable.

5
<!-- page 6 -->
3.5 Subject to the provisions of Section 5 of this Agreement, if the volume of each Product shipped
by Shipper on the Pipeline during the Quarter is less than the applicable Quarterly Volume
Commitment for that Product then, in addition to paying any amounts incurred by Shipper pursuant to
Section 3.4 with respect to Shipper Deliveries for such Quarter, Shipper shall also pay MPL a
deficiency payment (the "Quarterly Deficiency Payment"); equal to the product of:

(a) the difference between the applicable Quarterly Volume Commitment for that Product for such
Quarter and the volume of Shipper Deliveries of that Product on the Pipeline for such Quarter (the
"Deficiency Volume"); and

(b) the applicable Tariff Rate for that Product for such Quarter.

Each Product to which the Shipper is obligated to move as part of its committed volumes will be
added together for one total Quarterly Deficiency Payment.

Shipper's transportation of commodities outside this Agreement's definition of Product will not
satisfy the obligation to move committed Product volume. All Product barrels moved by Shipper in
excess of its Quarterly Volume Commitment will be attributed to Shipper's movements on the Pipeline
as a Regular Shipper, subject to the applicable Rules & Regulations of the Tariff.

3.6 The dollar amount of any Quarterly Deficiency Payment paid by Shipper shall constitute
prepayment for transportation of Product by Shipper on the Pipeline and will posted as a credit
("Prepaid Transportation Credits") to Shipper's account for that type of Product. If, during any
Quarter of the Contract Year, Shipper deliveries on the Pipeline exceed the applicable Quarterly
Volume Commitment requirements, Shipper shall be permitted to apply Prepaid Transportation Credits
against any amount due from Shipper and payable to MPL with respect to the transportation of volumes
on the Pipeline for such Quarter. Any Prepaid Transportation Credits that are not used by Shipper
during the four (4) Quarters immediately following the Quarter for which said Prepaid Transportation
Credits were posted to Shipper's account (the "Credit Period") will expire. Those Prepaid
Transportation Credits that are in payment dispute in accordance with Section 3.4, shall be posted
as a credit on the date the payment dispute is resolved. If during any such four (4) Quarter period
the nominated volume on the Pipeline for any month equals or exceeds the applicable portion in the
Quarterly Volume Commitment for the Pipeline for such month (the "Monthly Commitment"), but Shipper
is prevented from shipping volumes in excess of the Monthly Commitment because of lack of available
capacity, either because (a) the Pipeline is in allocation and Shipper is specifically subject to
allocation per Exhibit C, (b) the Pipeline is undergoing testing, maintenance or repair, or (c) a
Force Majeure has occurred that prevents MPL from transporting Shipper volumes on the Pipeline in
excess of the Monthly Commitment, then the Credit Period shall be extended by an equivalent time
period for which Shipper has been prevented from shipping volumes in excess of the Monthly
Commitment. For the purposes of this Section 3.6, during the Term, if the Pipeline is in allocation
for any portion of the month, the Pipeline will be considered to be in allocation for the entirety
of such month.

3.7 Notwithstanding anything in Section 3.5 to the contrary, upon the expiration or termination of
this Agreement for any reason to the extent that Shipper, at the time of such expiration or
termination, holds any unused Prepaid Transportation Credits, Shipper shall be permitted to apply
such Prepaid Transportation Credits against any amounts incurred by Shipper and

6
<!-- page 7 -->
payable to MPL with respect to any Shipper deliveries on the Pipeline until the expiration of the
applicable Credit Period with respect to such Prepaid Transportation Credits. This Section 3.7 shall
survive the expiration or termination of this Agreement.

3.8 Shipper may not apply Prepaid Transportation Credits on differing types of Products; i.e, a
Shipper may not use Prepaid Transportation Credits received for butane service on condensate,
natural gasoline, or diluent service, or vice versa. Condensate, natural gasoline, and diluent are
interchangeable from a volume commitment standpoint and shipping a total volume of any one or
combination of these Products will be applied towards the Quarterly Volume Commitment. Should MPL
proceed with butane service, Shipper will also have the opportunity to fulfill its Quarterly Volume
Commitment on a calendar quarter basis for butane service, separate from condensate, natural
gasoline, and diluent service.

3.9 If, following the binding open season and prior to the in-service date of the Tariff, MPL
determines that it has available capacity not subscribed to during the binding open season, not to
exceed 90% of Project Capacity ("Unsubscribed Capacity"), to the extent permitted by Governmental
Authority; MPL will provide Shipper the right to increase its Quarterly Volume Commitment as
submitted on its Capacity Request Form on Exhibit C. MPL will provide at least sixty (60) days'
advance written notice, simultaneously, to all shippers (including Shipper) who have executed a
transportation service agreement during the binding open season of the availability and volume of
Unsubscribed Capacity for additional volume commitments (the "Additional Volume Commitments"). No
later than thirty (30) days following the date of MPL's written notice, Shipper must provide MPL
with a written binding commitment identifying the additional volumes to be added to its Quarterly
Volume Commitment ("Pre-Service Increase Request"). In the event MPL receives Pre-Service Increase
Requests that are, in aggregate, less than or equal to the Unsubscribed Capacity, each shipper's
volume commitment shall be increased by the volume of its Pre-Service Increase Request. In the event
MPL receives Pre-Service Increase Requests that would, in aggregate, exceed the Unsubscribed
Capacity, all Shippers will be allocated their Pre-Service Increases pro rata based on their then-
current volume commitments. If Shipper makes a Pre-Service Increase Request, MPL shall notify
Shipper of its new Quarterly Volume Commitment within thirty (30) days following receipt of
Shipper's Pre-Service Increase Request, and Exhibit C shall be deemed revised to reflect Shipper's
new volume commitment, which shall equal the sum of its original Capacity Request Form volume
commitment and its Pre-Service Increase Request or its allocated portion thereof pursuant to this
Section 3.9. If there is still Unsubscribed Capacity after shippers (including Shipper) exercise
Additional Volume Commitments as set forth above, MPL may conduct a second open season to obtain
additional volume commitments for any remaining Unsubscribed Capacity.

4. Transportation Charges

4.1 Shipper shall pay MPL a transportation charge for each Barrel of Product shipped under the terms
of this Agreement and Exhibit C, at the rates provided for in Exhibit B, which shall be the Tariff
Rates for the volume commitment on the Day of delivery of Product.

4.2 The rates in Exhibit B will be adjusted annually in accordance with the standard FERC annual oil
pipeline indexing methodology in effect at the time of the escalation. There shall be no downward
adjustment of the Rates in the event the annual FERC oil pipeline index rate is negative. Rates will
typically be indexed during July of each year and would be first indexed in July of the year
following project completion.

7
<!-- page 8 -->
4.3 If during the term of this Agreement, MPL becomes obligated as a result of a Change in Law Event
to bear Compliance Costs, MPL shall have the right to increase the Tariff Rates on the Pipeline,
including Shipper's committed rate as originally executed on Exhibit B in this Agreement or to
impose a surcharge on its shippers (including Shipper) to recover such Compliance Costs. If MPL
determines to recover any Compliance Costs from its shippers, it will do so in a manner that is
reasonable and equitable to all shippers on the Pipeline.

4.4 A "Committed Priority Shipper" will receive transportation service exempt from prorationing
provisions under normal operating conditions for its contractually committed volumes, in exchange
for a commitment to transport (or pay for) those volumes, pursuant to the terms of this Agreement
executed during the open season process. The rates vary depending upon project options, but in all
instances will be $0.01 per barrel above the rates for uncommitted service for the same origin and
destination points. A Committed Priority Shipper will have the same rates as the Committed
Non-Priority Shipper (as defined below), unless the system in under prorationing. When under
prorationing, the Committed Priority Shipper's rate will be charged the premium rate of $0.01 above
the posted uncommitted rate. Shipper shall not be a Committed Priority Shipper solely through this
Agreement. Shipper must submit a Capacity Request Form during MPL's binding open season (Exhibit C)
which confirms the Shipper has elected Committed Priority Shipper Status.

4.5 A "Committed Non-Priority Shipper" will receive transportation service subject to prorationing
provisions for its contractually committed volumes, in exchange for a commitment to transport (or
pay for) those volumes, pursuant to the terms of this Agreement executed during the open season
process. Those who elect to become a Committed Non-Priority Shipper will receive the benefit of
discounted rates that will not be available to the Committed Priority Shippers or the uncommitted
shippers. The rates will vary depending upon project options and commitment duration. MPL will not
presume Shipper to be a Committed Non-Priority Shipper solely through this Agreement, unless the
Capacity Request Form submitted by Shipper during MPL's binding open season (Exhibit C) shows the
Shipper has elected Committed Non-Priority Shipper Status.

5. Force Majeure

5.1 As soon as possible upon the occurrence of a Force Majeure event, the affected Party shall
provide the other Party written notice of the occurrence of such Force Majeure event (a "Force
Majeure Notice"). A Party shall identify the full particulars and the approximate length of time
that the Party reasonably believes in good faith such Force Majeure event shall continue (the "Force
Majeure Period"). If a Party advises in any Force Majeure Notice that it reasonably believes in good
faith that the Force Majeure Period shall continue for more than twelve (12) consecutive months,
then, subject to Section 10 below, at any time after a Party delivers such Force Majeure Notice,
either Party may terminate this Agreement, but only upon delivery to the other Party of a notice (a
"Termination Notice") at least twelve (12) months prior to the expiration of the Force Majeure
Period; provided, however, that such Termination Notice shall be deemed canceled and of no effect if
the Force Majeure Period ends prior to the expiration of such twelve (12) months period. For the
avoidance of doubt, neither Party may exercise its right under this Section 5.1 to terminate this
Agreement as a result of a Force Majeure event with respect to any machinery, storage, tanks, lines
of pipe or other equipment that has been unaffected by, or has been restored to working order since,
the applicable Force Majeure event.

8
<!-- page 9 -->
5.2 Notwithstanding the foregoing, if Shipper delivers a Termination Notice to MPL and, within
thirty (30) days after receiving such notice, MPL notifies Shipper that MPL reasonably believes in
good faith that it shall be capable of fully performing under its obligations under this Agreement
within a reasonable period of time, then the Shipper Termination Notice shall be deemed revoked and
the applicable portion of this Agreement shall continue in full force and effect as if such Shipper
Termination Notice had never been given.

5.3 Subject to Section 6 of this Agreement, MPL's obligation to transport on the Pipeline may be
temporarily suspended during occurrences of, and for the entire duration of, a Force Majeure event
that prevents MPL from transporting on the Pipeline. If MPL is unable to transport due to a Force
Majeure event or otherwise, then Shipper's obligation to ship the applicable Quarterly Volume
Commitment and pay the applicable Quarterly Deficiency Payment shall be reduced to the extent that
MPL is prevented from shipping the full applicable Quarterly Volume Commitment. At such time as MPL
is capable of transporting volumes equal to the full applicable Quarterly Volume Commitment on the
Pipeline, Shipper's obligation to ship the full Quarterly Volume Commitment shall be restored.

6. Capabilities of the Pipeline System

6.1 MPL shall use reasonable commercial efforts to minimize the disruption of service on the
Pipeline and any portion thereof. MPL shall promptly inform Shipper of any anticipated partial or
complete disruption of service on the Pipeline, including relevant information about the nature,
extent, cause and expected duration of the disruption and the actions MPL is taking to resume full
operations, provided that MPL shall not have any liability for any failure to notify, or delay in
notifying, Shipper of any such matters except to the extent Shipper has been materially prejudiced
or damaged by such failure or delay.

6.2 Subject to Force Majeure, disruptions for routine repair and maintenance consistent with
pipeline industry standards and any requirements of Applicable Law, MPL shall accept for shipment on
the Pipeline in accordance with pipeline industry standard Product. Further, MPL shall maintain and
repair all portions of the Pipeline in accordance with pipeline industry standards and in a manner
which allows the Pipeline to be capable, subject to Force Majeure or temporary shutdown for pipeline
testing and maintenance, of shipping, storing and delivering volumes of Product.

6.3 If the Shipper has agreed to pay, pursuant to Exhibit B and Exhibit C, a premium rate for
transportation of Product on the Pipeline, the Shipper Deliveries shall not be reduced under normal
operating conditions if the capacity for Product shipments is otherwise subject to prorationing in
accordance with the prorationing provisions in MPL's Rules and Regulations Tariff.

6.4 If, for any reason, including without limitation a Force Majeure event, the capacity of the
Pipeline is reduced, then (a) during such period of reduced capacity, Shipper's obligation shall be
reduced as described above in this Section 6; and (b) within a reasonable period of time after
commencement of such reduction, MPL shall make repairs to and/or replace the affected portion of the
Pipeline to restore capacity. MPL shall use commercially reasonable efforts to continue to provide
transportation of Product tendered by Shipper under the Tariffs while restoration is being
completed. Any work performed by MPL pursuant to this Section 6.4

9
<!-- page 10 -->
shall be performed and completed in a good and workmanlike manner consistent with applicable
pipeline industry standards and in accordance with all applicable laws.

6.5 Expansion of Pipeline. MPL reserves the right, at its sole discretion, to expand the capacity of
the Pipeline at any time or from time to time.

6.6 Right of Shipper to Secure Expansion Capacity. In the event that MPL decides in its sole
discretion to expand the capacity of the Pipeline, then:

(a) MPL will provide each Shipper with notice of such proposed expansion not less than one hundred
and eighty (180) days prior to the expected in-service date of such proposed expansion ("Expansion
Notice") and such Expansion Notice shall include:

(i) the amount of the proposed expansion capacity;

(ii) the expected rates and rules and regulations that will apply to such expansion capacity;

(iii) the expected in-service date of such expansion/extension.

The costs of any expansion shall not be rolled into the rates associated with any Pipeline capacity
existing prior to such expansion.

(b) To the extent permitted by Governmental Authorities, MPL will provide to each Shipper a first
right, on terms and conditions specified by MPL that is consistent with this first right, to submit
a binding nomination to ship, or otherwise pay for, a committed volume of Product on the expansion
capacity ("Requested Expansion Volume Commitment"). The amount of expansion capacity available for
volume commitments pursuant to this Section 6.6 shall not exceed ninety percent (90%) of the total
expansion capacity. No later than sixty (60) days following the date of MPL's Expansion Notice,
Shipper must commit to, in a form acceptable to MPL in MPL's sole discretion, its Requested
Expansion Volume Commitment ("Election Deadline"). In the event that, pursuant to this first right,
MPL receives binding commitments for volumes that exceed the expansion capacity available for
committed volumes, each Shipper that submitted a binding commitment pursuant to this first right
procedure shall be allocated the lesser of: (i) its Requested Expansion Volume Commitment, or (ii)
the Shipper's pro-rata share of the expansion capacity available for committed volumes, which shall
be calculated by multiplying (1) the Shipper's Proportionate Share, times (2) the expansion capacity
available for committed volumes ("Expansion Volume Commitment"). MPL shall notify Shipper of its
Expansion Volume Commitment within thirty (30) days following the Election Deadline, and the Parties
shall promptly execute a new and separate transportation service agreement reflecting Shipper's
Expansion Volume Commitment. Any calculation of an Expansion Volume Commitment shall be without
regard to and shall not affect any Volume Commitment on pre-existing capacity.

(c) In the event that any expansion capacity available for committed volumes remains after the
procedure set forth in Section 6.6 is completed, MPL has the right, in its sole discretion, to offer
such committed capacity pursuant to an open season in which all interested shippers will be given an
opportunity to commit to transport a specified volume of Product on such remaining expansion
capacity, subject to the terms and conditions specified by MPL pursuant to or in connection with
such open season.

10
<!-- page 11 -->
7 Confidentiality

7.1 From and after the Effective Date, each Party shall hold, and shall cause its Affiliates and its
and their respective directors, managers, officers, employees, agents, consultants, advisors,
contractors, and other representatives (collectively, "Representatives") to hold all Confidential
Information of the other Party in strict confidence, with at least the same degree of care that
applies to such Party's confidential and proprietary information and shall not use such Confidential
Information except in connection with its performance or acceptance of services hereunder and shall
not release or disclose such Confidential Information to any other Person, except its
Representatives. Each Party shall be responsible for any breach of this Section 7 by any of its
Representatives.

7.2 If a Party receives a subpoena or other demand for disclosure of Confidential Information
received from any other Party or must disclose to a Governmental Authority any Confidential
Information received from such other Party in order to obtain or maintain any required governmental
approval, the receiving Party shall, to the extent legally permissible, provide notice to the
providing Party before disclosing such Confidential Information. Upon receipt of such notice, the
providing Party shall promptly either seek an appropriate protective order, waive the receiving
Party's confidentiality obligations hereunder to the extent necessary to permit the receiving Party
to respond to the demand, or otherwise fully satisfy the subpoena or demand or the requirements of
the applicable Governmental Authority. If the receiving Party is legally compelled to disclose such
Confidential Information or if the providing Party does not promptly respond as contemplated by this
Section 7, the receiving Party may disclose that portion of Confidential Information covered by the
notice or demand.

7.3 Each Party acknowledges that the disclosing Party would not have an adequate remedy at law for
the breach by the receiving Party of any one or more of the covenants contained in this Section 7
and agrees that, in the event of such breach, the disclosing Party may, in addition to the other
remedies that may be available to it, apply to a court for an injunction to prevent breaches of this
Section 7 and to enforce specifically the terms and provisions of this Section 7. Notwithstanding
any other section hereof, the provisions of this Section 7 shall survive the termination of this
Agreement.

8. Assignment

8.1 Neither Party may assign its rights under this Agreement without prior written consent from the
other Party, which consent shall not be unreasonably withheld; provided, however, that either Party
may assign its rights under this Agreement to a successor in interest resulting from any merger,
reorganization, consolidation or as part of a sale of all or substantially all of its assets.
Subject to the foregoing, this Agreement shall bind and inure to the benefit of the successors and
assigns of the Parties hereto.

9. Representations and Warranties

9.1 Each Party to this Agreement represents and warrants to the other that it is an entity duly
organized, validly existing and in good standing under the laws of the state of its organization and
has all requisite corporate power and corporate authority to enter into this Agreement and to carry
out the terms and provisions hereof.

11
<!-- page 12 -->
9.2 MPL shall take reasonable steps to obtain all necessary approvals, and authorizations of all
Governmental Authorities to modify and operate the Pipeline, including approval by FERC of the rate
structure and any premium service, and all other approvals and authorizations necessary, in MPL's
sole opinion, desirable in connection with the provision of Product transportation, in each case, in
form and substance acceptable to MPL in its sole discretion.

9.3 Shipper hereby agrees (a) to take all such actions and do all such things as MPL reasonably
requests in connections with its application for, and the processing of necessary approvals and
authorizations of the FERC and other governmental authorities, (b) at all times to support the rate
and (c) to not, directly or indirectly, take any action that is designed to or may delay review or
approval of the applications to FERC or any other Governmental Authority or indicate a lack of
support for the modifications of the Pipeline or the rate.

10. Termination and Amendment

10.1 This Agreement may not be terminated, except as expressly provided herein, nor may any of its
provisions be amended or waived without prior written consent of both Parties hereto.

10.2 Neither failure nor delay by MPL or Shipper to exercise any right or remedy provided herein
shall operate as a waiver with respect to a future exercise thereof, nor shall any single or partial
exercise of any such right or remedy preclude any other or further exercise thereof or the exercise
of any other right or remedy.

10.3 Except as otherwise provided in Section 10.5, in the event of any breach of a term or condition
of this Agreement by either Party, the other Party's remedy shall be limited to the direct damages
caused thereby and in no event shall a Party be liable to the other Party for any consequential,
indirect, pecuniary, punitive, or economic damages, howsoever caused.

10.4 Upon termination of this Agreement for reasons other than a default by Shipper, pursuant to any
provisions of this Agreement or any other termination of this Agreement initiated by Shipper
pursuant to Section 5, Shipper shall have the right to require MPL to enter into a new
transportation service agreement with Shipper that (a) is consistent with the terms and objectives
set forth in this Agreement and (b) has commercial terms that are, in the aggregate, equal to or
more favorable to Shipper than fair market value terms as would be agreed by similarly-situated
parties negotiating at arm's length provided.

10.5 Shipper acknowledges that MPL will incur certain building, expansion and improvement costs
associated with its performance under this Agreement prior to the commencement of transportation
service on the Pipeline. Shipper also acknowledges that MPL relied on the volume commitments
received from Shipper on its Capacity Request Form in Exhibit C as part of an aggregate volume
commitment received from all committed shippers during the binding open season to finalize the
Project's ultimate scope, including but not limited to, pipe size, routing and destinations. If MPL
is in compliance with the terms and conditions of this Agreement, and Shipper decides to terminate
this Agreement after the Effective Date but prior to the commencement of transportation service on
the Pipeline, Shipper shall notify MPL of its decision to terminate within one hundred and eighty
(180) days of the Project's in-service date to allow MPL the opportunity to provide Shipper's
unwanted capacity to other interested shippers as Unsubscribed Capacity as set forth in Section 3.8.
If Shipper fails to notify MPL within one hundred and eighty (180) days of the Project's in-service
date or if MPL is unsuccessful in obtaining additional volume commitments as provided for in Section
3.8 to

12
<!-- page 13 -->
fully replace Shipper's original volume commitment as submitted in its Capacity Request Form in
Exhibit C, Shipper will reimburse MPL for Shipper's pro rata portion of actual and committed
Construction Costs, plus, an administrative fee of ten (10) percent of said costs (such
reimbursement is hereinafter referred to as the "Construction Cost Reimbursement"). The Parties
agree that the Construction Cost Reimbursement shall be deemed liquidated damages and that such
amount shall not be deemed a penalty, but rather represents a reasonable amount of liquidated
damages in light of the anticipated or actual harm caused by Shipper's termination of this Agreement
as stated, the difficulties of proof of loss, and the inconvenience or non- feasibility of otherwise
obtaining an adequate remedy, and that the payment of such amount shall be MPL's sole and exclusive
remedy for such termination by Shipper.

10.6 The Parties acknowledge and agree that this Agreement may be contingent on the Shipper
executing a reasonably acceptable commodity supply agreement. Shipper must notify MPL if it is
unable to execute a reasonably acceptable commodity supply agreement within one hundred and eighty
(180) days of the Project in-service date. Furthermore, Shipper must make commercially reasonable
efforts to enter into a commodity supply agreement within the one hundred and eighty (180) days.
Provided, however, that Shipper acknowledges and agrees that Shipper remains responsible for the
Construction Cost Reimbursement provided for in Section 10.5 of this Agreement if it is unable to
reach and execute a commodity supply agreement within the required timeframe. 11. Conditions
Precedent

Notwithstanding anything in this Agreement to the contrary, this Agreement is subject to the receipt
by MPL of:

11.1 All certificates, approvals and authorizations of any Governmental Authority deemed necessary
or desirable by MPL in connection with this Agreement and, in each case, in form and substance
acceptable to MPL in its sole discretion.

11.2 Executed Transportation Service Agreements, in form and substance acceptable to MPL in its sole
discretion, as MPL shall deem sufficient in its sole discretion to support the economic viability of
the costs associated with the Project.

11.3 Executed Transportation Service Agreements, in form and substance acceptable to both MPL and
Shipper.

If any terms of this Agreement are required to be modified in accordance with a decision, approval
or authorization from FERC or any other governmental authority, the Parties agree to reasonably
cooperate with one another in amending this Agreement to align with those decisions, approvals and
authorizations from FERC or any other governmental agencies. If these conditions precedent are not
satisfied for MPL after exercising commercially reasonable efforts to meet such condition precedent,
MPL shall have the right to terminate this Agreement by written notice to Shipper. If this Agreement
is terminated pursuant to this Section 11, MPL and Shipper shall be released from any and all
obligations under this Agreement.

12. Offer

12.1 The submission of an unexecuted copy of this Agreement by MPL to Shipper shall not constitute
an offer.

13
<!-- page 14 -->
12.2 Shipper acknowledges that, upon closing of the open season described in the notice of open
season, MPL will undertake significant alterations and improvements and will incur significant
expense in connection with the Project. In consideration of the foregoing and other good and
valuable consideration, the receipt and sufficiency of which are hereby acknowledged by Shipper,
Shipper agrees that the submission of an executed Agreement to MPL shall constitute an offer by
Shipper. Shipper further agrees that its offer shall remain irrevocable; provided, however, that if
Shipper has not received an executed copy of this Agreement from MPL within sixty (60) days after
the close of the Binding Open Season, Shipper may revoke its offer thereafter by written notice to
MPL, and upon such revocation, this Agreement will become null and void.

13. Notices

13.1 Any notice, statement, or invoice provided for in this Agreement shall be in writing and shall
be considered as having been given if hand carried, facsimiled, emailed, or if mailed by United
States mail, postage prepaid, to the following address, respectively:

Shipper : Name: Marathon Petroleum Company LP Address: 539 South Main Street Findlay, OH 45840
Attention: Optimization LP Manager Fax: (419) 421-4232

MPL : Name: Craig O. Pierson Address: 539 South Main Street Findlay, OH 45840 Attention: President
Fax: (419) 421-3125

or to such other address as such Party may indicate by a notice delivered in accordance with this
Section 13.

14. Governing Law

This Agreement shall be construed and interpreted in accordance with the laws of the State of Ohio,
without recourse to any principles of law governing conflicts of law, which might otherwise be
applicable.

15. Severability

In the event any provision of this Agreement is held to be invalid, illegal or unenforceable in any
respect by a court of competent jurisdiction, or by an empowered government agency, such findings
shall not affect the remaining provisions of this Agreement, which are not found to be invalid,
illegal or unenforceable, unless such construction would be unreasonable.

14
<!-- page 15 -->
16. Default

16.1 Either Party hereunder shall be in default if such Party: (a) materially breaches any provision
of this Agreement and such breach is not cured within fifteen (15) Days after notice thereof (which
notice shall describe such breach in reasonable detail) is received by such Party; (b) becomes
insolvent, enters voluntary or involuntary bankruptcy or makes an assignment for the benefit of
creditors; (c) fails to pay any undisputed sums due hereunder; or (d) fails to provide satisfactory
financial assurance as provided for in Section 17.

16.2 If either Party is in default as described above, then the non-defaulting Party may: (a)
terminate this Agreement upon notice to the defaulting Party; (b) withhold any payments due to the
defaulting Party under this Agreement; and/or (c) pursue any other remedy at law or in equity if
such breach is not remedied as provided for in Section 14.1.

17. Credit Requirements and Financial Assurances

17.1 Financial Information. Shipper shall provide to MPL, at any time: (i) upon MPL's request,
information ("Financial Information") that will allow MPL to assess (or reassess) and establish
creditworthiness and Shipper's capacity to perform any financial obligations that could arise from
the transportation of Shipper's Crude Petroleum on the Pipeline; and (ii) upon MPL's good faith
determination (which shall be no less than industry standards) of non-creditworthiness, MPL may
request, financial assurance in respect of transportation or other services ("Financial
Assurances"). Financial Assurances shall be limited to a guarantee from the parent company of
Shipper in a form and substance acceptable to MPL and sufficient in amount to cover 6-months of
Shipper's obligations to MPL so long as the guarantor has sufficient creditworthiness as set forth
in this Section; and if not, MPL may then request an irrevocable standby letter of credit in a form
and from an issuer acceptable to MPL, and in an amount no greater than 6-months of tolls based on
the Quarterly Volume Commitment, plus all applicable taxes.

17.2 As of the Project's in-service date, Shipper shall comply with the credit requirements and
provide the financial assurances required in the Tariff so long as the Tariff is consistent with the
terms of this Agreement. 17.3 Any failure of Shipper to comply with the provisions of this Section
17 will constitute an Event of Default under Section 16 of this Agreement.

18. Miscellaneous

18.1 Wherever possible, each provision hereof shall be interpreted in such a manner as to be
effective and valid under Applicable Law, but in case any one or more of the provisions contained
herein shall, for any reason, be held to be invalid, illegal or unenforceable in any respect, such
provision or provisions shall be ineffective to the extent, but only to the extent, of such
invalidity, illegality or unenforceability without invalidating the remainder of such provision or
provisions or any other provisions hereof, unless such a construction would be unreasonable.

18.2 This Agreement shall be binding upon and inure to the benefit of the Parties and their
successors and permitted assigns; provided, however, that the rights and obligations of any Party
under this Agreement shall not be assignable by such Party without the prior written consent of the

15
<!-- page 16 -->
other Party pursuant to Section 8.1. A Party's successors and permitted assigns shall include any
permitted assignee as well as the successors in interest to such permitted assignee whether by
merger, liquidation (including successive mergers or liquidations) or otherwise.

18.3 No provision of this Agreement is intended to confer upon any third party any remedy, claim,
liability, reimbursement or other right in excess of those existing without reference to this
Agreement.

18.4 Neither Party shall, without the approval of the other Party, make any press release or other
public announcement concerning the transactions contemplated by this Agreement, except as and to the
extent that either Party shall be so obligated by Applicable Law or the rules of any regulatory
body, stock exchange or quotation system.

18.5 EACH PARTY WAIVES, TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW, ANY RIGHT IT MAY HAVE TO
A TRIAL BY JURY IN RESPECT OF ANY PROCEEDINGS RELATING TO THIS AGREEMENT OR ANY PERFORMANCE OR
FAILURE TO PERFORM OF ANY OBLIGATION HEREUNDER.

16
<!-- page 17 -->
IN WITNESS WHEREOF, MPL and Shipper have caused this Agreement to be duly executed, all as of the
date set forth above.

MARATHON PIPE LINE LLC By: /s/ Craig Pierson 6/11/15 Name: Craig Pierson Title: President

MARATHON PETROLEUM COMPANY LP By: MPC Investment LLC, its General Partner By: /s/ C. M. Palmer
4/13/15 Name: C. Michael Palmer Title: Sr. Vice President, Supply Distribution & Planning

17

EXHIBIT A Common Carrier Pipeline, including Origins and Destinations
<!-- page 18 -->
Pipeline System New/Existing Pipeline Pipeline Owner Cornerstone Pipeline New MPL East Sparta to
Lima Pipeline New MPL East Sparta to Heath Existing (Expansion) ORPL Heath to Findlay Existing
(Expansion) ORPL RIO Existing (Reversal & Expansion) MPC Two Rivers Existing MPL Wabash Existing MPL

The MPC RIO system is an existing private pipeline owned by Marathon Petroleum Company, LP (MPC).
MPL may purchase the RIO system, with the intent to reverse and repurpose the system from common
carrier movements.

18
<!-- page 19 -->
EXHIBIT B

Tariff Rates

19
<!-- page 20 -->
EXHIBIT C

Include copy of Shipper's submitted Capacity Request Form (CFR) indicating desired routes and
destinations.

Capacity Request Forms follow this page

20

Appendix 5 - Capacity Request Form (CRF) - Ratable Volume(1) Please complete one form for each
product type per delivery location

Name of Shipper: Marathon Petroleum Company LP
<!-- page 21 -->
Term/Service [Priority, (5,10, 15 Year) Non-Priority] Priority 15 Year

Product Type [Condensate, Natural Gasoline, Diluent or Butane]: Condensate

Year Desired Volume Origination Location Delivery Location Rate 1 20,000 BPD Cadiz/Scio MPC Canton $
2.26 2 20,000 BPD Cadiz/Scio MPC Canton $ 2.26 3 20,000 BPD Cadiz/Scio MPC Canton $ 2.26 4 20,000
BPD Cadiz/Scio MPC Canton $ 2.26 5 20,000 BPD Cadiz/Scio MPC Canton $ 2.26 6 20,000 BPD Cadiz/Scio
MPC Canton $ 2.26 7 20,000 BPD Cadiz/Scio MPC Canton $ 2.26 8 20,000 BPD Cadiz/Scio MPC Canton $
2.26 9 20,000 BPD Cadiz/Scio MPC Canton $ 2.26 10 20,000 BPD Cadiz/Scio MPC Canton $ 2.26 11 20,000
BPD Cadiz/Scio MPC Canton $ 2.26 12 20,000 BPD Cadiz/Scio MPC Canton $ 2.26 13 20,000 BPD Cadiz/Scio
MPC Canton $ 2.26 14 20,000 BPD Cadiz/Scio MPC Canton $ 2.26 15 20,000 BPD Cadiz/Scio MPC Canton $
2.26 (1) - Assumes shipper transports the same volume on a per day basis each month of the year
Notes: Deliveries to Canton will begin in late 2016 and deliveries to other locations will begin in
mid-2017 The tariff rate for the first year of movements can be found in Appendix 4 The tariff rate
will be adjusted annually in accordance with the standard FERC annual oil pipeline indexing
methodology

Marathon Pipe Line LLC & Ohio River Pipe Line LLC CONFIDENTIAL AND PROPRIETARY

Appendix 5 - Capacity Request Form (CRF) - Ratable Volume(1) Please complete one form for each
product type per delivery location

Name of Shipper: Marathon Petroleum Company LP

Term/Service [Priority, (5,10, 15 Year) Non-Priority] Priority 5 Year
<!-- page 22 -->
Product Type [Condensate, Natural Gasoline, Diluent or Butane]: Natural Gasoline

Year Desired Volume Origination Location Delivery Location Rate 1 10 MBPD Cadiz/Scio Hammond $ 6.96
2 10 MBPD Cadiz/Scio Hammond $ 6.96 3 10 MBPD Cadiz/Scio Hammond $ 6.96 4 10 MBPD Cadiz/Scio Hammond
$ 6.96 5 10 MBPD Cadiz/Scio Hammond $ 6.96 6 0 MBPD Cadiz/Scio Hammond $ 6.96 7 0 MBPD Cadiz/Scio
Hammond $ 6.96 8 0 MBPD Cadiz/Scio Hammond $ 6.96 9 0 MBPD Cadiz/Scio Hammond $ 6.96 10 0 MBPD
Cadiz/Scio Hammond $ 6.96 11 0 MBPD Cadiz/Scio Hammond $ 6.96 12 0 MBPD Cadiz/Scio Hammond $ 6.96 13
0 MBPD Cadiz/Scio Hammond $ 6.96 14 0 MBPD Cadiz/Scio Hammond $ 6.96 15 0 MBPD Cadiz/Scio Hammond $
6.96 (1) - Assumes shipper transports the same volume on a per day basis each month of the year
Notes: Deliveries to Canton will begin in late 2016 and deliveries to other locations will begin in
mid-2017 The tariff rate for the first year of movements can be found in Appendix 4 The tariff rate
will be adjusted annually in accordance with the standard FERC annual oil pipeline indexing
methodology

Marathon Pipe Line LLC & Ohio River Pipe Line LLC CONFIDENTIAL AND PROPRIETARY
<!-- page 23 -->
Appendix 5 - Capacity Request Form (CRF) - Non-Ratable Volume(2) Please complete one form for each
product type per delivery location

Name of Shipper: Marathon Petroleum Company LP

Term/Service [Priority, (5,10, 15 Year) Non-Priority] Priority 5 Year

Product Type [Condensate, Natural Gasoline, Diluent or Butane]: Normal Butane

(2) - Assumes shipper transports a different volume on a per day basis each month of the year Notes:
Deliveries to Canton will begin in late 2016 and deliveries to other locations will begin in
mid-2017 The tariff rate for the first year of movements can be found in Appendix 4 The tariff rate
will be adjusted annually in accordance with the standard FERC annual oil pipeline indexing
methodology

Marathon Pipe Line LLC & Ohio River Pipe Line LLC CONFIDENTIAL AND PROPRIETARY
<!-- page 24 -->
Appendix 5 - Capacity Request Form (CRF) - Non-Ratable Volume(2) Please complete one form for each
product type per delivery location

Name of Shipper: Marathon Petroleum Company LP

Term/Service [Priority, (5,10, 15 Year) Non-Priority] Priority 5 Year

Product Type [Condensate, Natural Gasoline, Diluent or Butane]: Normal Butane

(2) - Assumes shipper transports a different volume on a per day basis each month of the year

Notes: Deliveries to Canton will begin in late 2016 and deliveries to other locations will begin in
mid-2017 The tariff rate for the first year of movements can be found in Appendix 4 The tariff rate
will be adjusted annually in accordance with the standard FERC annual oil pipeline indexing
methodology

Marathon Pipe Line LLC & Ohio River Pipe Line LLC CONFIDENTIAL AND PROPRIETARY
<!-- page 25 -->
Appendix 5 - Capacity Request Form (CRF) - Non-Ratable Volume(2) Please complete one form for each
product type per delivery location

Name of Shipper: Marathon Petroleum Company LP

Term/Service [Priority, (5,10, 15 Year) Non-Priority] Priority 5 Year

Product Type [Condensate, Natural Gasoline, Diluent or Butane]: Normal Butane

(2) - Assumes shipper transports a different volume on a per day basis each month of the year Notes:
Deliveries to Canton will begin in late 2016 and deliveries to other locations will begin in
mid-2017 The tariff rate for the first year of movements can be found in Appendix 4 The tariff rate
will be adjusted annually in accordance with the standard FERC annual oil pipeline indexing
methodology
<!-- page 26 -->
Marathon Pipe Line LLC & Ohio River Pipe Line LLC CONFIDENTIAL AND PROPRIETARY
