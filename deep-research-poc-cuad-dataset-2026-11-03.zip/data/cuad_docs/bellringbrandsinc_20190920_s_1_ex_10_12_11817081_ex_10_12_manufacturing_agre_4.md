<!-- page 1 -->
# MANUFACTURING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Manufacturing Agreement |
| Agreement Date | 2019-07-03 |
| Parties | Stremicks Heritage Foods, LLC ("Heritage"); Premier Nutrition Corporation ("Premier") |
| Source | CUAD v1 / BellringBrandsInc_20190920_S-1_EX-10.12_11817081_EX-10.12_Manufacturing Agreement4 |

AMENDMENT NO. 3 TO STREMICK'S HERITAGE FOODS, LLC and PREMIER NUTRITION CORPORATION MANUFACTURING
AGREEMENT

This Amendment No. 3 (the "Third Amendment"), entered into by and between Stremicks Heritage Foods,
LLC ("Heritage") Premier Nutrition Corporation ("Premier") is effective as of July 3, 2019 ("Third
Amendment Effective Date") and amends that certain Manufacturing Agreement between Heritage and
Premier dated July 1, 2017 as amended ("Agreement"). Heritage and Premier are each referred to
herein as a "Party" and collectively as the "Parties."

WHEREAS, Heritage and Premier entered into the Agreement;

WHEREAS, the Parties wish to amend the Agreement in accordance with the terms and conditions set
forth herein.

NOW, THEREFORE, in consideration of the promises and of the mutual covenants, representations and
warranties contained in the Agreement and set forth herein, the Parties hereby agree that the
following changes shall be made to the Agreement:

1. The Parties hereby agree to remove Schedule C-1 in its entirety and replace it with the
following:

Schedule C-1. The following is attached to an incorporated into the Agreement as Schedule C-1:

Schedule C-1([***])

[***]

2. Except as otherwise specified above in this Amendment, all other terms, conditions and covenants
of the Agreement shall remain in full force and effect.

IN WITNESS WHEREOF, the Parties have caused this Amendment to be signed by their respective duly
authorized representatives as of the Amendment Effective Date. Premier Nutrition Corporation
Stremick's Heritage Foods, LLC.

By: /s/ Darcy Davenport By: /s/ Sam Stremick Name: Darcy Davenport Name: Sam Stremick Title:
President Title: President

Source: BELLRING BRANDS, INC., S-1, 9/20/2019
