### A3_grid_only

| slice | n | err | cand recall | opened/cited | gold page | support | gate fail | has answer | item recall | abstain ok | judge pass | judge ? | wall s p50 | calls p50 | tokens p50 | tok/correct |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| all | 1 | 0 | 1.0 | 0.0 | 0.0 |  | 0.0 |  | 1.0 | 1.0 | 0.0 | 0.0 | 128.8 | 0 | 17790 |  |
| coverage | 1 | 0 | 1.0 | 0.0 | 0.0 |  | 0.0 |  | 1.0 | 1.0 | 0.0 | 0.0 | 128.8 | 0 | 17790 |  |
