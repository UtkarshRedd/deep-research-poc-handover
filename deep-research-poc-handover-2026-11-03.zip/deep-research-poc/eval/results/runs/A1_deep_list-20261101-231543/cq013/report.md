# What cap on liability does the License and Development Agreement between Bioeq IP, AG a...

*Question:* What cap on liability does the License and Development Agreement between Bioeq IP, AG and Coherus BioSciences, Inc. (dated 2019-11-02) provide?

## Identify the liability cap provision

Section 13 of the License and Development Agreement is titled "INDEMNIFICATION AND LIMITATION OF LIABILITY". [35b8d42537824beb p.29] Section 13.1 states that Bioeq agrees to indemnify and hold Licensee harmless subject to Section 13.4. [35b8d42537824beb p.29] Section 13.4 specifies the limitation of liability applicable to the indemnification provisions. [35b8d42537824beb p.29]

[GAP] The specific cap or limitation amount in Section 13.4 is not included in the provided evidence.

## Not established by the evidence

[GAP] No evidence was found for: Establish the exact monetary or other cap on liability, the types of damages or claims it covers, and any exceptions or carve-outs stated in the agreement.

## Verification appendix

Claims: 5 · supported: 3 · partially: 0 · dropped: 0 · gaps: 2 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: State the cap amount and scope

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[35b8d42537824beb p.29] |  |
| s1.2 | s1 | keep | 1.00 | e1→[35b8d42537824beb p.29] |  |
| s1.3 | s1 | keep | 1.00 | e1→[35b8d42537824beb p.29] |  |
| s1.4 | s1 | gap |  |  |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [35b8d42537824beb p.29 L1559-1569] keep (1.0): "13.INDEMNIFICATION AND LIMITATION OF LIABILITY

13.1 Indemnification by Bioeq. Subject to Section 13.4, Bioeq agrees to indemnify and hold Licensee harmless from and against all claims, suits, actions, proceedings brought by a Third Party (…"
