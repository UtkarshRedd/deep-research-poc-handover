<!-- page 1 -->
# Outsourcing Agreement
| Field | Value |
|---|---|
| Document Type | Outsourcing Agreement |
| Agreement Date | 1998-02-16 |
| Parties | Tri City National Bank ("Customer"); Marshall & Ilsley Corporation ("M&I") |
| Source | CUAD v1 / TRICITYBANKSHARESCORP_05_15_1998-EX-10-OUTSOURCING AGREEMENT |

OUTSOURCING AGREEMENT

BY AND BETWEEN

TRI CITY NATIONAL BANK

and

MARSHALL & ILSLEY CORPORATION acting through its division M&I DATA SERVICES

DATED AS OF

February 16, 1998

TABLE OF CONTENTS

Page 1. DEFINITIONS 1.1 Background 1.2 Definitions 1.3 References 1.4 Interpretation 2. TERM 2.1
Initial Term 2.2 Extensions 3. APPOINTMENT 3.1 Performance by M&I Affiliates 3.2 Third Party
Services 3.3 Proper Instructions 4. CONVERSION 4.1 Banking Applications 4.2 Development of
Conversion Plan 4.3 Conversion Resources 4.4 Conversion Milestones 5. OUTSOURCING OF TRUST SERVICES
6. BANKING APPLICATIONS 6.1 Services to be Rendered 6.2 Banking Application Processing 6.3 Corporate
Support Services 6.4 Item Processing Services 6.5 Automated Clearing House Services 6.6 Home Banking
and Internet Services 6.7 Retail Delivery Systems 6.8 Visa Check/MasterMoney Card Services 6.9 EFT
Services 7. FACILITIES MANAGEMENT 8. FEES 8.1 Fee Structure 8.2 Conversion 8.3 Pricing and
Operational Assumptions 8.4 Banking Applications Services 8.5 Corporate Support Services 8.6 Item
Processing Services 8.7 Management Services 8.8 Visa Check/MasterMoney Card Services 8.9 EFT
Services 8.10 Training and Education 8.11 Excluded Costs 8.12 Disputed Amounts 8.13 Terms of Payment
8.14 Modification of Terms and Pricing 9. PERFORMANCE STANDARDS 9.1 General 9.2 Banking Applications
10. MODIFICATION OR TERMINATION OF SERVICES 10.1 Modifications to Services 10.2 Partial Termination
by M&I 10.3 Partial Termination by Customer 10.4 Development of Custom Software
<!-- page 2 -->
11. TERMINATION 11.1 For Convenience 11.2 For Cause 11.3 Following Change in Control of Customer
11.4 Termination Assistance 12. EVENTS OF DEFAULT; REMEDIES 12.1 By M&I 12.2 By Customer 12.3
Remedies 13. DAMAGES 13.1 Direct Damages 13.2 No Consequential Damages 13.3 Equitable Relief 13.4
Limitation of Liability 13.5 Liquidated Damages 14. INSURANCE AND INDEMNITY 14.1 Insurance 14.2
Indemnity 14.3 Indemnification Procedures 15. DISPUTE RESOLUTION 15.1 Representatives of Parties
15.2 Continuity of Performance 16. REPRESENTATIONS AND WARRANTIES 16.1 By M&I 16.2 By Customer 17.
CONFIDENTIALITY AND OWNERSHIP 17.1 Customer Data 17.2 M&I Systems 17.3 Confidential Information 17.4
Obligations of the Parties 17.5 Security 18. MANAGEMENT OF PROJECT 18.1 Account Representatives 18.2
Change Control Procedures 18.3 Reporting and Meetings 18.4 Development Projects and Technical
Support 19. REGULATORY COMPLIANCE 20. DISASTER RECOVERY 20.1 Disaster Recovery Plan 20.2 Relocation
20.3 Resumption of Services 20.4 Annual Test 21. GENERAL TERMS AND CONDITIONS 21.1 Force Majeure
21.2 Transmission of Data 21.3 Equipment and Network 21.4 Reliance on Data 21.5 Data Backup 21.6
Balancing and Controls 21.7 Use of Services 21.8 Regulatory Assurances 21.9 IRS Filing 21.10
Affiliates 21.11 Future Acquisitions 22. MISCELLANEOUS PROVISIONS 22.1 Governing Law 22.2 Venue and
Jurisdiction 22.3 Entire Agreement; Amendments 22.4 Assignment 22.5 Relationship of Parties 22.6
Notices 22.7 Headings 22.8 Counterparts 22.9 Waiver 22.10 Severability 22.11 Attorneys' Fees and
Costs 22.12 Financial Statements 22.13 Publicity 22.14 Solicitation 22.15 No Third Party
Beneficiaries 22.16 Construction 23. SOURCE CODE 23.1 Escrow 23.2 Copy of Source Code 23.3 Cost of
Escrow 23.4 Customer's Right to Obtain the Source Code 23.5 Use of Source Code

Schedules

4.2 Conversion Plan 6.2 Banking Application Services 8.1 Fee Schedule

Exhibits

A RDS Agreement B ACH Authorization Agreement C Attorney-in-Fact Appointment D Affidavit

OUTSOURCING AGREEMENT
<!-- page 3 -->
This Outsourcing Agreement ("Agreement") is made as of the 16th day of February, 1998, by and
between Tri City National Bank, a Wisconsin corporation (including its Affiliates, "Customer") and
Marshall & Ilsley Corporation, a Wisconsin corporation, acting through its division, M&I Data
Services ("M&I").

In consideration of the payments to be made and services to be performed hereunder, the parties
agree as follows:

1. DEFINITIONS

1.1 Background.

This Agreement is being made and entered into with reference to the following facts:

A. Customer provides, through its Information Systems Department, systems development and
operations, data processing, telecommunications and other information technology services for
itself, and on behalf of its customers.

B. M&I, through its divisions, subsidiaries and Affiliates, is a provider of data processing,
systems development and operations, corporate support and item processing, home banking, internet
banking, retail delivery services, trust data processing, and other services. M&I desires to perform
for Customer the outsourcing services described in this Agreement.

C. In reliance on its own independent analysis, and after careful evaluation of M&I's proposal and
other alternatives, Customer has selected M&I to provide the Services (as defined in Section 1.2) to
Customer. This Agreement documents the terms and conditions under which Customer agrees to purchase
and M&I agrees to provide the Services.

1.2 Definitions.

The following terms shall have the meaning ascribed to them in this Section 1.2:

A. "Affiliate" shall mean, with respect to a party, any entity at any time Controlling, Controlled
by or under common Control with, such party.

B. "Bank" shall mean each of the subsidiary financial institutions of Customer.

C. "Change in Control" shall mean any event or series of events by which (i) any person or entity or
group of persons or entities shall acquire Control of another person or entity or (ii) in the case
of a corporation, during any period of 12 consecutive months commencing before or after the date
hereof, individuals who at the beginning of such 12-month period were directors of such corporation
shall cease for any reason to constitute a majority of the board of directors of such corporation.

D. "Commencement Date" shall mean the date on which Conversion for all Banks has been completed. The
parties anticipate the Commencement Date to be November 16, 1998.

E. "Contract Year" shall mean a period commencing on the first day of the month in which the
Commencement Date occurs (and each anniversary thereof) and terminating on the last date of the
month occurring one (1) year thereafter.

F. "Control" shall mean the direct or indirect ownership of over 50% of the capital stock (or other
ownership interest, if not a corporation) of any entity or the possession, directly or indirectly,
of the power to direct the management and policies of such entity by ownership of voting securities,
by contract or otherwise. "Controlling" shall mean having Control of any entity and "Controlled"
shall mean being the subject of Control by another entity.

G. "Conversion" shall mean (i) the migration of Customer's data processing and other information
technology services to the M&I system; (ii) completion of upgrades of other software modifications
as set forth in this Agreement; and (iii) completion of all interfaces set forth in this Agreement
and full integration thereof such that Customer is able to receive the Services in accordance with
the criteria set forth in the Conversion Plan (as defined in Section 4.2 below).

H. "Conversion Date" for a particular Bank shall mean the date on which M&I has completed the
Conversion for the processing of the Services.

I. "Conversion Period" for a particular Bank shall mean that portion of the Term beginning on the
Effective Date and ending on the Conversion Date.

J. "Core Services" shall mean services provided by M&I's Deposit System, Loan System and Customer
Information System.

K. "Damages" shall mean all direct, actual and verifiable losses, liabilities, damages and claims
and related costs and expenses (including reasonable attorneys' fees and court costs, costs of
investigation, litigation, settlement, judgment, interest and penalties) but excluding any and all
consequential, incidental, punitive and exemplary damages.

L. "Effective Date" shall mean February 16, 1998.

M. "Effective Date of Termination" shall mean the last day on which M&I provides the Services to
Customer (excluding any Termination Assistance) following delivery of a notice of termination.
<!-- page 4 -->
N. "Estimated Remaining Value" shall mean the number of calendar months remaining between the
Effective Date of Termination and the last day of the Term, multiplied by the greater of (a) the
Monthly Base Fee (as defined in Section 8.1 below) plus any other minimum monthly fee set forth in
the Fee Schedule; and (b) the average monthly Fees payable by Customer during the three-month period
prior to the event giving rise to termination rights under this Agreement.

O. "Expenses" shall mean any and all direct, pass through expenses incurred by M&I for any
equipment, personnel, postage, supplies, materials, travel, lodging or services of any kind provided
to or for Customer under this Agreement; provided that Customer shall not be charged travel and
living expenses for M&I employees traveling to and from any site within Milwaukee, Waukesha, Ozaukee
and Racine Counties in Wisconsin, in connection with providing any services or training to Customer.

P. "Initial Services" shall mean those Services requested by Customer from M&I under this Agreement
as of the Effective Date.

Q. "Millennium Compliant" shall mean the compliance of the Services with the guidelines established
by the Federal Financial Institutions Examination Council ("FFIEC") issued in May, 1997 and any
subsequent guidelines issued by the FFIEC or the Federal Regulators (as defined in Section 21.8(A))
in connection with the identification and renovation of issues relating to the data processing of
the year 2000.

R. "Network" shall mean the data communication lines and related software, data circuits, cabling
and equipment which M&I is to install, manage or operate in accordance with the Systems Integration
Agreement.

S. "Operations Center" shall mean the datacenter used by M&I o provide some of the Services under
this Agreement.

T. "Performance Standards" shall mean those service levels set forth in Article 9.

U. "Proper Instructions" shall mean the manner in which Customer shall provide instructions to M&I,
as set forth in Section 3.3 below.

V. "Services" shall mean the services, functions and responsibilities described in this Agreement to
be performed by M&I during the Term following each Conversion Date.

W. "Taxes" shall mean any manufacturers, sales, use, gross receipts, excise, personal property or
similar tax or duty assessed by any governmental or quasi-governmental authority upon or as a result
of the execution or performance of any service pursuant to this Agreement or materials furnished
with respect to this Agreement, except any income, franchise, privilege or like tax on or measured
by M&I's net income, capital stock or net worth.

X. "Term" shall mean the period commencing on the Effective Date and terminating on the eighth
anniversary of the Commencement Date, unless the Agreement is extended in accordance with its
provisions.

Y. "User Manuals" shall mean the documentation provided by M&I to Customer which describes the
features and functionalities of each of the Accounts DP Services (defined in Section 6.2 below), as
modified and updated by the customer bulletins distributed by M&I from time to time.

1.3 References. In this Agreement and the schedules and exhibits attached hereto, which are hereby
incorporated and deemed a part of this Agreement, references and mention of the word "include" and
"including" shall mean "includes, without limitation" and "including, without limitation", as
applicable.

1.4 Interpretation. In the event of a conflict between this Agreement and the terms of any exhibits
and schedules attached hereto, the terms of the schedules and exhibits shall prevail and control the
interpretation of the Agreement and the exhibits and schedules as a single document.

2. TERM

2.1 Initial Term. The initial term of this Agreement shall be the Term, unless extended or earlier
terminated in accordance with this Agreement.

2.2 Extensions. Unless this Agreement has been earlier terminated, at least eighteen (18) months
prior to the expiration of the Term, M&I shall submit to Customer a written proposal for renewal of
this Agreement. Customer will respond to such proposal within six (6) months following receipt and
inform M&I in writing whether or not Customer desires to renew this Agreement. If M&I and Customer
are unable to agree upon the terms for renewal of this Agreement at least six (6) months prior to
the expiration of the Term, then Customer may, at its option, renew this Agreement for one (1)
twelve month period at the then-current terms and conditions of this Agreement. Customer shall
exercise its option, if at all, by delivering written notice to M&I at least five (5) months prior
to expiration of the Term.

3. APPOINTMENT

3.1 Performance by M&I Affiliates. Customer understands and agrees that Marshall & Ilsley
Corporation is a bank holding company and that the actual performance of the Services may be made by
the divisions, subsidiaries and/or Affiliates of Marshall & Ilsley Corporation. For purposes of this
<!-- page 5 -->
Agreement, performance of the Services by any division, subsidiary or Affiliate of Marshall & Ilsley
Corporation shall be deemed performance by Marshall & Ilsley Corporation itself. 3.2 Third Party
Services. The parties acknowledge that certain services and information necessary for the
performance of the Services may be provided by third parties. M&I agrees that the performance and
warranties contained in this Agreement shall apply to the Initial Services even if the same are to
be performed by third parties. Except as specifically stated in this Section 3.2, M&I shall have no
liability to Customer for information supplied by, or services performed by, third parties in
conjunction with the Services.

3.3 Proper Instructions.

A. M&I shall be deemed to have received "Proper Instructions" upon receipt of written or oral
instructions which M&I believes in good faith to be signed or given by any person(s) whose name(s)
and signature(s) are listed on the most recent certificate delivered by Customer to M&I which lists
those persons authorized to give orders, corrections and instructions in the name of and on behalf
of Customer.

B. Proper Instructions shall specify the action requested to be taken or omitted. Proper
Instructions shall include instructions sent to M&I or its agent(s) by letter, memorandum, telegram,
cable, telex, telecopy facsimile, video (CRT) terminal or other "on-line" system, or similar means
of communication, or given orally over the telephone or in person by a person authorized by Customer
pursuant to Section 3.4(A) to provide Proper Instructions. Proper Instructions shall include any
file transmission received by M&I from Customer, or any agent of Customer who is thereof authorized
in writing.

4. CONVERSION

4.1 Banking Applications. The parties agree to use their best efforts to perform the Conversion of
all Banks to M&I's service bureau system on or before November 16, 1998.

4.2 Development of Conversion Plan. M&I has, in consultation with Customer, begun developing a
detailed, customized plan for the Conversion (the "Conversion Plan"). The Conversion Plan includes
(i) a description of the tasks to be performed for the Conversion; (ii) allocation of responsibility
for each of such tasks; and (iii) the schedule on which each task is to be performed. The Conversion
project leaders for each party shall regularly communicate on the progress of the Conversion, the
feasibility of the Conversion Dates specified in the Conversion Plan, and such other matters which
may affect the smooth transition of the Services. Customer agrees to maintain an adequate staff of
persons who are knowledgeable with the systems currently used by Customer. Customer further agrees
to provide such services and to perform such obligations as are specified as Customer's
responsibility in the Conversion Plan and as necessary for Customer to timely and adequately meet
the scheduled dates set forth therein. Customer also agrees to cooperate fully with all reasonable
requests of M&I made necessary to effect the Conversion in a timely and efficient manner. The
Conversion Plan (as it exists on the date of this Agreement and as it may be amended from time to
time by the mutual agreement of the parties) is attached hereto as Schedule 4.2. Customer agrees to
pay M&I for the costs of the Conversion in accordance with the provisions of Section 8.1.

4.3 Conversion Resources. M&I and Customer will provide a team of qualified experts to assist in the
conversion effort. The team and their responsibilities are outlined below.

A. M&I Relationship Manager. This individual shall be responsible for the overall implementation of
all aspects of the Conversion and shall be the key liaison between Customer and M&I.

B. Conversion Project Manager. M&I will provide a team to the Conversion effort. The team members
and their responsibilities are defined as follows:

Conversion Project Manager - Will have the responsibility and accountability for the Bank Conversion
as assigned. The project manager will direct the effort of the Conversion team. He/she will be
responsible for managing the goals and will provide assessment of project risks.

Product Consultant - Will direct the efforts of the product team assigned by M&I. Areas the product
consultant is responsible for include: data mapping and conversion, development efforts, education
and training, and third party integration activities.

Technical Consultant - The technical consultant assigned manages the network implementation, the
operational set-up at M&I, coordination of the data from the existing processors, conversion
programmer development activities, and connectivity to third party processors.

Conversion Programmers and Representative - This team of conversion professionals will work with
Customer on the mapping of the data to be converted, development of program specifications and the
program development. This team will assist in building the processing parameters, and provide
assistance to Customer through the week of Conversion.

The Conversion will be supported by the development staff, the network planner and implementation
team, the branch automation team, and other resources within M&I that has responsibility for
components of the solution
<!-- page 6 -->
to be delivered to Customer.

C. Customer. Customer shall provide a Conversion team to complement the efforts of the M&I
Conversion team, and to provide some consistency and direction. The recommended team structure would
be as follows.

Conversion Project Coordinator - The coordinator would have responsibility for the overall
Conversion process and the management of the Conversion team. He/she would work to ensure that the
people are given proper direction, and that all Conversion events are executed to meet the
established goals, and to maintain consistency among the project teams.

Conversion Project Manager - A project manager would be assigned to complement the M&I conversion
project manager. The project manager would have a team assembled to work on the Conversion. The
Project manager would assist in ensuring that the tasks on the project plan are executed and that
the project remains on schedule. He/she would work with the M&I conversion manager to do risk
assessment and evaluate overall project status.

Conversion Representatives - Core teams of Conversion representatives shall be assigned to assist in
establishing consistency in approach and execution. These teams would work closely with the M&I
Conversion team. Primary areas of responsibility include: procedure development and adherence to the
procedure, assist in evaluating the readiness of the converting institution, assist in the data
mapping and test report review exercise, and work with the M&I Conversion team during the Conversion
week.

It is recommended that dedicated conversion representatives be established to support the following
applications: Deposits, Loans, General Ledger, CIS, and Branch Automation.

Conversion Trainers - The core group of trainers will be dedicated to the Conversion and shall be
responsible for development and execution of the training curriculum to Customer's staff. This group
will be trained by M&I using the train-the-trainer approach.

Bank Balancers - A core group of Customer's staff would be trained on balancing the M&I
applications. This group, in conjunction with M&I, would assist in providing support during
Conversion.

4.4 Conversion Milestones. During the conversion process for each of the Banks, M&I will analyze
Customer's products, the setup of bank control, analyze and verify Customer's test data, analyze
Customer's training needs and perform workflow analysis. During the next phase, Customer shall
verify the converted test data and identify any changes to the Conversion programs. A review
("Readiness Review") will then be performed as a dress rehearsal to ensure that M&I and Customer are
prepared to Convert. M&I and Customer shall mutually agree to and sign off on the Readiness Review
assuring the Bank is prepared to Convert to the Services. The stabilization phase takes place
approximately three (3) to four (4) weeks prior to Conversion, during which time software programs,
bank control and interface tables are completed and stabilized. Changes, if any, are managed and
require approval of both M&I and Customer. Finally, the Conversion phase includes the Conversion
weekend and Conversion week support. The M&I Project Team manages the Conversion weekend, working
with Customer's existing processors to meet targeted deadlines. During the Conversion week, M&I will
provide support on site for Customer. On a daily basis, M&I and Customer will have status update
meetings to understand levels of self sufficiency and areas requiring attention.

5. OUTSOURCING OF TRUST SERVICES INTENTIONALLY OMITTED

6. BANKING APPLICATIONS

6.1 Services to be Rendered. M&I agrees to provide Customer with the services set forth in this
Article.

6.2 Banking Application Processing. M&I agrees to provide Customer with the accounts data processing
services ("Accounts DP Services") set forth in attached Schedule 6.2, in accordance with the User
Manuals. Schedule 6.2 identifies certain Services which are included in the Monthly Base Fee (as
described in Section 8.2 below) as well as those Services to be charged to Customer based on the
actual usage of resources.

6.3 Corporate Support Services. INTENTIONALLY OMITTED

6.4 Item Processing Services. INTENTIONALLY OMITTED

6.5 Automated Clearing House Services. The following terms and conditions shall apply to the
provision of ACH Services:

A. Definitions. The following terms, as referenced from the NACHA Rules, shall have the following
meanings for the purposes of the Agreement:

1. "Applicable Law" means the NACHA Rules, the rules of local ACH Associations, the rules of any and
all ACH Operators, and other applicable law.

2. "Automated Clearing House Operator" or "ACH Operator" means the central clearing facility,
operated by a Federal Reserve Bank (FRB) or a private organization, which receives entries from the
ODFI or the third party processor acting as an agent for the ODFI, and distributes entries to the
appropriate RDFI or the third party processor acting as an agent for the RDFI, and performs the
settlement functions for the affected financial
<!-- page 7 -->
institutions.

3. "Originating Depository Financial Institution" or "ODFI" means the institution that receives the
payment instructions from the Originators and forwards the entries to the ACH Operator.

4. "Originator" means a person that has authorized an ODFI to transmit a credit or debit entry to
the deposit account of an RDFI.

5. "Receiving Depository Financial Institution" means the institution that receives ACH entries from
the ACH Operator and posts them to the accounts of its depositors.

B. General. Customer hereby authorizes M&I to initiate and receive automated clearing house ("ACH")
debit entries, adjustments to debit entries and credit entries to Customer's account indicated
below, to credit and/or debit the same to such account, and to provide various ACH services, as
described below, to Customer pursuant to the terms and conditions specified herein. The ACH entries
covered shall hereinafter be referred to as the "ACH Entries." Except as otherwise provided herein,
the terms used in this Section 6.5 shall have the same meanings as ascribed to such terms in the
Operating Rules of the National Automated Clearing House Association, as in effect from time to time
(the "NACHA Rules").

C. ACH Services.

1. M&I shall act as Customer's agent for initiating and transmitting ACH Entries to the appropriate
ACH Operator. In addition, M&I shall act as Customer's agent for receiving ACH Entries from an ACH
Operator. For all ACH Entries initiated by M&I pursuant to this Agreement, Customer, and not M&I,
shall be the ODFI when M&I receives payment instructions directed to Customer's routing number from
an Originator, or the RDFI when M&I receives ACH Entries directed to Customer's routing number from
an ACH Operator.

2. M&I shall transmit ACH Entries in accordance with the format requirements of the NACHA Rules to
an ACH Operator using Customer's Routing Number. M&I shall receive ACH Entries on behalf of Customer
that are transmitted to M&I by an ACH Operator. M&I shall provide reports to Customer, as described
in the M&I ACH Manual (the "Service Manual"). If agreed to between Customer and M&I, M&I shall
provide for the posting of ACH Entries to Customer deposit accounts.

3. All warranties of an ODFI or RDFI prescribed under Applicable Law shall be in effect and
applicable to Customer, and not M&I, with respect to all ACH Entries.

4. M&I may provide additional ACH services as requested by Customer and agreed to by M&I in writing.

D. M&I PC ACH Services. Customer may provide its business depositors with access to M&I's ACH
Services as provided in M&I's PC ACH User Manual (the "PC ACH Service"). Customer shall be
responsible for informing M&I prior to permitting a new depositor to begin using the PC ACH Service.
Customer also shall inform M&I whether any credit limit shall apply to the ACH Entries of a
depositor utilizing the PC ACH Service.

E. Customer Depositor Inquiries; Erroneous or Rejected ACH Entries.

1. Customer shall be responsible for handling all inquiries of its depositors regarding ACH Entries,
including but not limited to inquiries regarding credits or debits to a depositor's account
resulting from an ACH Entry. M&I agrees to reasonably assist Customer in responding to such
inquiries by providing information to Customer concerning ACH Entries.

2. As described in the Service Manual, M&I shall provide reports to Customer showing errors and
rejections resulting from ACH Entries transmitted on behalf of Customer during a particular day. It
shall be Customer's responsibility to research and correct such ACH Entries.

F. Credit Limits.

1. Customer may from time to time establish one or more credit limits applicable to ACH Entries
involving a particular depositor or all depositors of Customer. Such credit limits may be
established by written notice from Customer and shall be implemented by M&I as soon as reasonably
practicable.

2. In the event that an ACH Entry exceeds a credit limit established pursuant to this Section 6(F),
M&I shall promptly give oral or written notice to Customer. Customer may either approve the ACH
Entry as an exception to the credit limit, request that it be held over to the next day, or reject
such ACH Entry provided, however, that any exception to the credit limit must be approved in writing
by Customer.

G. Service Manuals; PC ACH User Manual.

1. M&I shall provide Customer with copies of M&I's current Service Manual and PC ACH User Manual and
any updates to such manuals. Customer agrees to comply with the requirements of such manuals.

2. It shall be Customer's responsibility, and Customer is authorized, to forward a copy of the PC
ACH User Manual, and any updates to the PC ACH User Manual, to Customer's depositors that utilize
the PC ACH Service.

H. Compliance With Applicable Law.
<!-- page 8 -->
1. Each party shall be bound by, and comply with, Applicable Law. Neither party shall have any
responsibility for the other's compliance with Applicable Law, nor any liability to any person for
the other's failure to comply with Applicable Law. Each party shall indemnify the other and hold it
harmless from any and all liabilities, claims, costs, expenses and damages of any nature (including
but not limited to reasonable attorney's fees, allocated costs of staff counsel, expenses of
litigation and any fees and expenses incurred in enforcing this provision) arising out of or related
to any dispute or legal action by any party alleging a violation of Applicable Law by the
indemnifying party.

2. Without limiting the generality of subsection 6.5(G)(1), prior to providing ACH origination
services, Customer shall enter into an agreement with the Originator in compliance with the NACHA
Rules, including but not limited to the requirement of the NACHA Rules that such agreement include a
provision whereby the Originator agrees to be bound by the NACHA Rules. M&I shall have no
responsibility for ensuring that such Originators have entered into such agreements.

I. Limitation On Liability.

1. M&I is acting solely in its capacity as agent for Customer in connection with the initiation,
transmission and receipt of ACH Entries on behalf of Customer. As agent, M&I shall be under no
obligation to provide funds to any party to settle for any ACH Entry received or initiated by M&I.
Upon notification from Customer of the occurrence of an error or omission with respect to an ACH
Entry, M&I shall promptly furnish corrected ACH Entry(ies) to an ACH Operator, unless the NACHA
Rules prohibit the processing of the correct ACH Entry(ies). Notwithstanding any provision in the
Agreement to the contrary, M&I's liability to Customer for claims arising out of the ACH Services
performed by M&I pursuant to this Section 6.5 shall be limited to errors and omissions which are
caused solely by M&I's gross negligence or willful misconduct and which cannot be remedied through
the processing of appropriate corrected ACH Entry(ies).

2. M&I shall make reasonable efforts to deliver ACH Entries to Customer or to an ACH Operator, as
appropriate, prior to any applicable deadline for such delivery. M&I does not guarantee timely
delivery. M&I shall have no liability to Customer as a result of any late delivery, unless such late
delivery is (i) caused solely by the gross negligence or wilful misconduct of M&I and (ii) made more
than 24 hours delayed from its scheduled deadline.

6.6 Home Banking and Internet Services. INTENTIONALLY OMITTED

6.7 Retail Delivery Systems. M&I agrees to provide the licenses, products, interfaces and network
management services associated with the PC Teller and Sales Partner/BankerInsight software, in
accordance with the Retail Delivery Systems Agreement ("RDS Agreement") set forth in attached
Exhibit A. Customer shall execute the RDS Agreement contemporaneously with execution of this
Agreement.

6.8 Visa Check/MasterMoney Card Services. M&I agrees to provide the Visa Check card ("Bankcard
Services") as further described on Schedule 6.2. Customer agrees to use M&I primarily for Customer's
Bankcard Services data processing.

A. Customer has membership in Visa U.S.A. Inc. Customer shall provide M&I with copies of its fully
executed Visa U.S.A. Inc. membership agreement promptly after execution of this Agreement by
Customer.

B. Customer shall comply with the articles, bylaws, operating regulations, rules, procedures and
policies of Visa U.S.A. Inc. and shall be solely responsible, as between Customer and M&I, for any
claims, liabilities, lawsuits and expenses arising out of or caused by Customer's failure to comply
with the same. Customer agrees to maintain an account at Tri City National Bank and Customer hereby
authorizes M&I to charge any amounts due to M&I, for Bankcard Services, against any credits due to
Customer to Customer's account whether or not such charges create overdrafts.

6.9 EFT Services. M&I agrees to provide the EFT services more particularly described on Schedule
6.2.

A. Customer understands and agrees that M&I may terminate EFT services immediately in the event
M&I's access to any shared electronic funds transfer system is terminated by the network provider.
Customer further agrees that the software used to provide the EFT services may not be available for
license by Customer.

7. FACILITIES MANAGEMENT INTENTIONALLY OMITTED

8. FEES

8.1 Fee Structure. Schedule 8.1 attached hereto (the "Fee Schedule") sets forth the costs and
charges to be paid by Customer for the Services. These costs and charges are included in one or more
of the following categories:

(i) one-time fees associated with Conversion, software licenses, interfaces and consulting fees;

(ii) a minimum monthly fee ("Monthly Base Fee") for certain bundled data processing Services, based
on the volume of resource units used to provide such Services. Increases in actual volumes shall
result in additional charges based on resource Units used, which charges are further
<!-- page 9 -->
described in the Fee Schedule; and

(iii) an hourly or daily fee for programming, training and related Services.

8.2 Conversion. Customer agrees to pay M&I the fees relating to the Conversion on the terms and
conditions set forth on the Fee Schedule ("Conversion Fees"). In addition to the Conversion Fees,
Customer agrees to (i) reimburse M&I for all Expenses reasonably incurred in connection with the
Conversion; (ii) for all Conversion charges of additional accounts as they are incurred or for the
Conversion of products not identified in the Conversion Plan; (iii) for M&I personnel or any
independent contractors who perform Conversion or related services which are identified as the
responsibility of the Customer in the Conversion Plan; and (iv) for Conversion charges which may
arise after the Conversion or with respect to accounts which are not currently Customer accounts
which are later converted to the M&I system.

8.3 Pricing and Operational Assumptions. The Fee Schedule sets forth the operational and pricing
assumptions made by M&I following completion of its preliminary due diligence of Customer's
requirements and its evaluation of information provided by Customer. If, prior to the Conversion
Date, the parties determine that one of more of the pricing or operational assumptions listed in the
Fee Schedule is inaccurate or incomplete in any material respect, the parties will negotiate in good
faith regarding an equitable adjustment to any materially and adversely impacted provisions of this
Agreement.

8.4 Banking Applications Services. Following the Conversion of the Accounts DP Services, Customer
agrees to pay to M&I the fees for the Accounts DP Services as set forth on the Fee Schedule.

8.5 Corporate Support Services. INTENTIONALLY OMITTED

8.6 Item Processing Services. INTENTIONALLY OMITTED

8.7 Management Services. INTENTIONALLY OMITTED

8.8 Visa Check/MasterMoney Card Services. Following commencement of the Bankcard Services, Customer
agrees to pay to M&I the fees set forth on the Fee Schedule. Notwithstanding any provision to the
contrary in the Agreement, or any general discount specified in the Fee Schedule, the fees for
Bankcard Services shall not be subject to any discounts. In addition to the charges specified on the
Fee Schedule, Customer shall be responsible for all interchange fees and all dues, fees and
assessments established by and owed to Visa U.S.A. Inc. and/or MasterCard International for the
processing of Customer's transactions.

8.9 EFT Services. Following the commencement of the EFT Services, Customer agrees to pay to M&I the
fees set forth on the Fee Schedule subject to the discounts specified in the Fee Schedule. Such
discount shall not apply to any EFT service which is not a part of M&I's 1997 standard published
priced list. In addition to the charges specified on the Fee Schedule, Customer shall be responsible
for all interchange and network provider fees for the processing of Customer's transactions.

8.10 Training and Education.

A. M&I shall provide training in accordance with the training schedule to be developed pursuant to
the Conversion Plan. The sessions shall be held at an M&I Datacenter location to be determined by
M&I. Customer shall be responsible for all Expenses incurred by the participants in connection with
such education and training.

B. M&I will provide two (2) copies each of the User Manuals (other than for branch systems covered
under the RDS Agreement) to Customer. When said manuals are updated M&I will provide two (2) copies
each of the replacement or additional pages. Additional copies of the User Manuals may be purchased
by Customer at M&I's then current published price list.

8.11 Excluded Costs. The fees set forth in the Fee Schedule do not include communication costs,
telecommunication charges, printline charges and other output costs, Expenses, third party pass-thru
charges, workshop fees, training fees and late fees or charges and Taxes.

8.12 Disputed Amounts. If Customer disputes any charge or amount on any invoice and such dispute
cannot be resolved promptly through good faith discussions between the parties, Customer shall pay
the amounts due under this Agreement less the disputed amount, and the parties shall diligently
proceed to resolve such disputed amount. An amount will be considered disputed in good faith if (i)
Customer delivers a written statement to M&I on or before the due date of the invoice, describing in
detail the basis of the dispute and the amount being withheld by Customer, (ii) such written
statement represents that the amount in dispute has been determined after due investigation of the
facts and that such disputed amount has been determined in good faith, (iii) such dispute has been
submitted by Customer for resolution to the proper party, and (iv) all other amounts due from
Customer that are not in dispute have been paid in accordance with the terms of this Agreement. If
agreement with respect to the disputed amount is not reached within thirty (30) days after the date
on which payment was due, Customer shall pay the disputed amount into an interest-bearing
independent escrow account for the benefit of the prevailing party, pending resolution of the
dispute.

8.13 Terms of Payment. All "one-time" fees shall be paid to M&I as
<!-- page 10 -->
set forth in the Fee Schedule. All minimum monthly fees (including the Monthly Base Fee) are due in
advance on the first day of the calendar month in which the Services are to be performed, prorated
for any partial month. To effect payment of such minimum monthly fees, Customer hereby authorizes
M&I to initiate debit entries from and, if necessary, initiate credit entries and adjustments to
Customer's account at the depository institution designated in the ACH Authorization Agreement
attached hereto as Exhibit B, which shall be executed by Customer contemporaneously with the
execution of this Agreement. All other amounts due hereunder shall be invoiced by M&I and shall be
payable within thirty (30) days of invoice, unless otherwise provided in the Fee Schedule. Customer
shall also pay any collection fees and Damages incurred by M&I in collecting payment of the charges
and any other amounts for which Customer is liable under the terms and conditions of this Agreement.

8.14 Modification of Terms and Pricing.

A. Following any Event of Default by Customer and pending completion of the dispute resolution
procedures set forth in Article 15, Customer agrees that all charges for Services shall be computed
using M&I's then-current standard published prices, paid in advance, as determined by M&I. Upon
Customer's cure of all such Event(s) of Default, the pricing terms shall revert to that which were
in place prior to the Event(s) of Default.

B. REDACTED

C. Customer shall be entitled to receive discounts on certain Services as specifically set forth in
the marked up price list made part of the Fee Schedule.

9. PERFORMANCE STANDARDS

9.1 General. Except as otherwise specified in this Agreement, M&I agrees to perform the Services in
accordance with the Performance Standards and, where there are no Performance Standards, in a
commercially reasonable manner and with no other or higher degree of care. M&I's performance under
this Agreement shall be excused to the extent any delays are caused by the occurrence of an event of
force majeure.

9.2 Banking Applications. Subject to the nonoccurrence of an event of force majeure as provided in
Section 21.1 of this Agreement and the performance of Customer's obligations essential to M&I's
performance of its obligations, M&I agrees that the Accounts DP Services will be provided in
accordance with the following standards (the "Performance Standards").

A. Batch Processing. M&I will initiate batch processing and have bank operations reports available
for transmission to Customer or make the processed item and reports available, within five (5) hours
on all (but two) processing days in a calendar month [fifteen (15) hours at year end] provided M&I
receives all input data from Customer at the Operations Center by 1:00 a.m. (local time of the
Operations Center).

B. On-line Availability. M&I will ensure that its on-line computing facilities are available for the
processing of Customer's on-line transactions at a minimum of ninety-seven point five percent
(97.5%) of the time, as prescribed by Customer, measured over a calendar month at the point of
departure from M&I's communications controller. The time prescribed by Customer for each banking day
for which on-line computing facilities shall be made available for each product or service is set
forth below. "Availability" for purposes of this paragraph shall be expressed as a percentage for
each calendar month and shall be the number 100 less the ratio of (i) time period of unscheduled
outages over (ii) total time prescribed less the time period of scheduled outages.

Service Availability ATM1 Monday-Thursday 12:01 a.m. - 12:00 midnight Friday 12:01 a.m. - 12:00
midnight Saturday 12:01 a.m. - 12:00 midnight Sunday 12:01 a.m. - 2:00 a.m. 6:00 a.m. 12:00 midnight

Cardbase Management System Monday - Thursday 7:00 a.m. - 12:00 midnight Friday 7:00 a.m. - 12:00
midnight Saturday 7:00 a.m. - 12:00 midnight Sunday 7:00 a.m. - 12:00 midnight

CIS & Deposit System Monday - Thursday 7:00 a.m. - 12:00 midnight Friday 7:00 a.m. - 12:00 midnight
Saturday 7:00 a.m. - 12:00 midnight Sunday 7:00 a.m. - 12:00 midnight

Loan System Monday - Thursday 7:00 a.m. - 12:00 midnight Friday 7:00 a.m. - 12:00 midnight Saturday
7:00 a.m. - 12:00 midnight Sunday 7:00 a.m. - 12:00 midnight

General Ledger Monday - Thursday 7:00 a.m. - 12:00 midnight Friday 7:00 a.m. - 12:00 midnight
Saturday 7:00 a.m. - 12:00 midnight

Sunday 7:00 a.m. - 12:00 midnight
<!-- page 11 -->
Information Desktop Monday - Thursday 7:00 a.m. - 12:00 midnight Friday 7:00 a.m. - 12:00 midnight
Saturday 7:00 a.m. - 12:00 midnight Sunday 7:00 a.m. - 12:00 midnight

Teller System Monday - Thursday 6:45 a.m. - 12:00 midnight Friday 6:45 a.m. - 12:00 midnight
Saturday 6:45 a.m. - 12:00 midnight Sunday 6:45 a.m. - 12:00 midnight

IRS Government Reporting System Monday - Thursday 7:00 a.m. - 12:00 midnight Friday 7:00 a.m. -
12:00 midnight Saturday 7:00 a.m. - 12:00 midnight Sunday 7:00 a.m. - 12:00 midnight

Account Analysis Monday - Thursday 7:00 a.m. - 12:00 midnight Friday 7:00 a.m. - 12:00 midnight
Saturday 7:00 a.m. - 12:00 midnight Sunday 7:00 a.m. - 12:00 midnight

Safe Box Monday - Thursday 7:00 a.m. - 12:00 midnight Friday 7:00 a.m. - 12:00 midnight Saturday -
Sunday 7:00 a.m. - 12:00 midnight

VRU 1 Monday - Thursday 12:01 a.m. - 12:00 midnight Friday 12:01 a.m. - 12:00 midnight Saturday
12:01 a.m. - 12:00 midnight Sunday 12:01 a.m. - 2:00 a.m. 6:00 a.m. 12:00 midnight

Bank Control Monday - Thursday 7:00 a.m. - 12:00 midnight Friday 7:00 a.m. - 12:00 midnight Saturday
7:00 a.m. - 12:00 midnight Sunday 7:00 a.m. - 12:00 midnight

Account Reconciliation Monday - Thursday 7:00 a.m. - 6:45 p.m. Friday 7:00 a.m. - 9:30 p.m. Saturday
7:00 a.m. - 4:30 p.m.

Deposit Teller1 Monday - Thursday 12:01 a.m. - 12:00 midnight Friday 12:01 a.m. - 12:00 midnight
Saturday 12:01 a.m. - 12:00 midnight Sunday 12:01 a.m. - 2:00 a.m. 6:00 a.m. 12:00 midnight

_____________________

1 M&I's objective is to provide 24 x 7 hour availability for these systems. M&I does however need to
perform regular technical maintenance (e.g., NCP maintenance), CPU IPLs, DASD installs, IHS gens,
etc.). This type of maintenance is performed between 2:00 a.m. and 6:00 a.m. CST/CDT. These
activities may result in system downtime during this window.

C. Processing Time. M&I will process transactions in an average of 2.5 seconds for teller
transactions (not to exceed six (6) seconds for five percent (5%) of all transactions per month) and
in an average of three point five (3.5) seconds (not to exceed seven (7) seconds for five percent
(5%) of all transactions per month) for bank operations CRT transactions as measured over a calendar
month, from the time the transaction is sent by the Customer's controller or gateway to the time the
processed data is returned to the Customer's controller or gateway. Should M&I not be able to
perform in accordance with the Performance Standards because Customer failed to acquire network or
equipment recommended by M&I, or such additional network or equipment as may be reasonably necessary
based on the circumstances, M&I shall notify Customer in writing and Customer shall either acquire
such network and/or equipment or accept the response time that is achieved.

D. Service Level Credits. REDACTED

10. MODIFICATION OR TERMINATION OF SERVICES

10.1 Modifications to Services. M&I may modify, amend, enhance, update, or provide an appropriate
replacement for the software used to provide the Services, or any element of its systems at any time
to: (i) improve the Services or (ii) facilitate the continued economic provision of the Services to
Customer or M&I, provided that the functionality of the Services is not materially adversely
affected.

10.2 Partial Termination by M&I. M&I may, at any time, withdraw any of the Services (other than the
Core Services) upon providing ninety (90) days' prior written notice to Customer. M&I may also
terminate any of the Services immediately upon any final regulatory, legislative, or judicial
<!-- page 12 -->
determination that providing such Services is inconsistent with applicable law or regulation or upon
imposition by any such authority of restrictions or conditions which would detract from the economic
or other benefits to M&I or Customer to any element of the Services. In the event a Service provided
as part of the monthly Base Fee is terminated by M&I, the parties agree to negotiate in good faith
an appropriate reduction in the monthly Base Fee.

10.3 Partial Termination by Customer.

A. Customer acknowledges and agrees that the Monthly Base Fee pricing offered to Customer by M&I is
based on certain services provided by M&I's Integrated Banking System. Customer agrees that, during
the Term, Customer shall be required to obtain from M&I all of those Services which are included in
the Monthly Base Fee, as set forth on Schedule 6.2.

REDACTED

10.4 Development of Custom Software. M&I reserves the right to determine the programming (whether
hardware or software) utilized by M&I with the equipment used in fulfilling its duties under this
Agreement. All programs (including ideas and know-how and concepts) developed by M&I are and shall
remain M&I's sole property. Any writing or work of authorship created by M&I in the course of
performing the Services under this Agreement, even if paid for by Customer, shall be the property of
M&I ("Developed Software"). M&I may make such Developed Software available to any of its other
customers; provided, however, if Customer has paid for such Developed Software and M&I offers, as
part of M&I's standard price list, a separate service resulting exclusively from such Developed
Software, M&I will refund, or credit, to Customer a portion of any amounts paid for such Developed
Software on terms and conditions agreed to by the parties prior to commencement of work on the
Developed Software.

11. TERMINATION

11.1 For Convenience. Customer may terminate this Agreement during the Term upon at least one (1)
years' written notice to M&I, provided that Customer pays M&I an early termination fee ("Termination
for Convenience Fee") in an amount equal to REDACTED of the Estimated Remaining Value. The
Termination for Convenience Fee shall apply to any early termination of this Agreement other than
pursuant to an Event of Default on the part of Customer or M&I or pursuant to Section 11.3 below.
Fifty percent of the Termination for Convenience Fee shall be paid to M&I within thirty (30) days
following the date of Customer's notice and the remaining 50% shall be paid to M&I within thirty
(30) days prior to the Effective Date of Termination. In addition to the foregoing, Customer shall
pay to M&I, any unamortized Conversion or other costs, reasonable Expenses in connection with the
disposition of equipment, facilities and contracts related to M&I's performance of the Services on
behalf of Customer. The Termination for Convenience Fee shall not be subject to the limitations set
forth in Section 13.4.

11.2 For Cause.

A. If M&I terminates this Agreement following an Event of Default on the part of Customer, or if
Customer terminates this Agreement in accordance with Section 11.1 above without complying with the
notification requirements set forth in Section 11.1, then Customer shall pay M&I a termination fee
("Termination for Cause Fee") in an amount equal to REDACTED of the Estimated Remaining Value,
payable as set forth in Section 11.1 above. In addition to the foregoing, Customer shall pay to M&I,
reasonable Expenses in connection with the disposition of equipment, facilities and contracts
related to M&I's performance of the Services on behalf of Customer. The Termination for Cause Fee
shall not be subject to the limitations set forth in Section 13.4.

B. If Customer terminates this Agreement following an Event of Default on the part of M&I, Customer
shall not be responsible for any termination fees or charges as a result thereof.

REDACTED

11.4 Termination Assistance. Commencing six (6) months prior to the expiration of the Term of this
Agreement, or upon any termination of this Agreement for any reason, M&I shall provide Customer, at
Customer's expense, all necessary assistance to allow the Services to continue without interruption
or adverse affect to Customer and to facilitate the orderly transition of Services to Customer or
its designee ("Termination Assistance"). At the written request of Customer, given at least 100 days
prior to expiration of the Term of the Agreement, M&I shall continue to provide Customer all
Services at the rates set forth in this Agreement, for a maximum period of six (6) months. As part
of the Termination Assistance, M&I shall assist Customer to develop a plan for the transition of all
data processing services from M&I to Customer or its designee on a reasonable schedule developed by
Customer. Prior to providing any Termination Assistance, M&I shall deliver to Customer a good faith
estimate of all such Expenses and charges including, without limitation, charges for custom
programming services. Customer understands and agrees that all Expenses and charges for Termination
Assistance shall be computed in accordance with M&I's then-current rates for such products,
materials and services. Nothing contained herein shall obligate Customer to receive Termination
Assistance from M&I.

12. EVENTS OF DEFAULT; REMEDIES
<!-- page 13 -->
12.1 By M&I. It shall be an Event of Default on the part of M&I if: (i) M&I becomes insolvent, or a
receiver of conservator shall be appointed with respect to M&I; or (ii) M&I shall fail to perform
any of its obligations under this Agreement which have a material adverse effect on Customer, and
such failure is not cured within 30 days after written notice from Customer; or (iii) M&I fails to
meet any Performance Standard and such failure is not cured within ninety (90) days after written
notice from Customer.

12.2 By Customer. It shall be an Event of Default on the part of the Customer if: (i) Customer
becomes insolvent, or a receiver of conservator shall be appointed with respect to the Customer; or
(ii) Customer shall fail to pay any sum due M&I within the prescribed time period, and such failure
continues for ten days after written notice thereof from M&I; or (iii) Customer shall fail to
perform any of its other obligations under this Agreement which have a material adverse effect on
M&I, and such failure is not cured within 30 days after written notice from M&I.

12.3 Remedies. Following an Event of Default, the non-defaulting party shall have the right to and
commence the dispute resolution procedures set forth in Article 15 or to terminate this Agreement
and collect its Damages.

13. DAMAGES

13.1 Direct Damages. Customer and M&I shall be liable to the other only for direct damages arising
out of or relating to their respective performance or non-performance of obligations under this
Agreement; provided, however, that the following shall be considered direct damages for the purposes
of this Agreement:

A. Costs of recreating or reloading any of Customer's information that is lost or damaged;

B. Costs of implementing a work-around in respect of a failure to provide the Services;

C. Costs of replacing lost or damaged equipment, software, and materials;

D. Costs and expenses incurred by Customer to correct errors in software maintenance and
enhancements provided as part of the Services;

E. Costs and expenses incurred by Customer to procure the Services from an alternate source, to the
extent in excess of M&I's charges under this Agreement; and

F. Straight time, overtime, or related expenses incurred by Customer, including overhead allocations
of Customer for Customer's employees, wages and salaries of additional employees, travel expenses,
overtime expenses, telecommunication charges, and similar charges, due to failure of M&I to provide
the Services or incurred in connection with subsections (A) through (E) above, to the extent that
such straight time, overtime, or related expenses exceed what Customer would have paid to M&I if M&I
were providing the Services, and limited to the amount that M&I would have paid to Customer under
subsection (E) above if Customer chose to procure the Services from an alternate source.

13.2 No Consequential Damages. Neither Customer nor M&I shall be liable for, nor will the measure of
any damages in any event include, any indirect, incidental, punitive, special or consequential
damages or amounts for loss of income, profits or savings arising out of or relating to performance
or non-performance under this Agreement.

13.3 Equitable Relief. Either party may seek equitable remedies, including specific performance and
injunctive relief, for a breach of the other party's obligations under this Agreement.

13.4 Limitation of Liability. Notwithstanding any provision in this Agreement, M&I's total liability
under this Agreement shall not exceed payments made to M&I by Customer under this Agreement during
the three (3) months prior to the event. No lawsuit or other action may be brought by either party
hereto, or on any claim or controversy based upon or arising in any way out of this Agreement be
brought, after one (1) year from the date on which the cause of action arose; provided, however, the
foregoing limitation shall not apply to the collection of any amounts due under this Agreement.

13.5 Liquidated Damages. Customer acknowledges that M&I shall suffer a material adverse impact on
its business if this Agreement is terminated pursuant to Sections 11.1 or 11.2(A) and that the
resulting damages may not be susceptible of precise determination. Customer acknowledges that the
Termination for Convenience Fee and the Termination for Cause Fee are each a reasonable
approximation of such damages and shall be deemed to be liquidated damages and not a penalty.

14. INSURANCE AND INDEMNITY

14.1 Insurance.

A. Throughout the Term of this Agreement, M&I shall maintain at all times at its own cost and
expense:

1. Commercial General Liability Insurance covering its premises, including bodily injury, property
damage, broad form contractual
<!-- page 14 -->
liability and independent contractors, with primary limits of not less than two million dollars
($2,000,000).

2. Fidelity Insurance covering employee dishonesty with respect to all aspects of the Services, in
an amount not less than ten million dollars ($10,000,000).

3. Workers' Compensation Insurance as mandated or allowed by the state in which the Services are
being performed, including at least five hundred thousand dollars ($500,000) coverage for Employer's
Liability.

4. All Risk Property Insurance in an amount adequate to cover the cost of replacement of all
equipment, improvements, and betterments at M&I locations in the event of loss or damage.

B. All policies of such insurance shall be written by a carrier or carriers rated "A" or above by
Best, shall contain a clause requiring the carrier to give Customer at least thirty (30) days' prior
written notice of any material change or cancellation of coverage for any reason, and simultaneously
with M&I's execution of this Agreement, and annually thereafter, at Customer's request, M&I shall
deliver to Customer original Certificates of Insurance evidencing the coverage required by this
Section.

14.2 Indemnity.

A. By Customer. Customer shall indemnify M&I from, and defend M&I against, any liability or expenses
arising out of or relating to (i) the inaccuracy or untruthfulness of any representation or warranty
made by Customer to M&I, (ii) a violation of Federal, state, or other laws or regulations for the
protection of persons or members of a protected class or category of persons by Customer or its
employees or agents, (iii) sexual discrimination or harassment by Customer or its employees or
agents, (iv) work-related injury or death caused by Customer or its employees or agents, (v)
tangible personal or real property damage or financial or monetary loss incurred by M&I resulting
from Customer's acts or omissions, or those of its employees or agents and (vi) those matters
included in Section 6.6(B) above. Customer shall be responsible for any costs and Expenses incurred
by M&I in connection with the enforcement of this Paragraph A.

B. By M&I. M&I shall indemnify Customer from, and defend Customer against, any liability or expenses
arising out of or relating to (i) any claim by a third party that the Services or M&I's software
infringe upon any United States patent, copyright or trademark of a third party, (ii) any claim by a
third party in respect of services or systems provided by M&I to a third party, (iii) the inaccuracy
or untruthfulness of any representation or warranty made by M&I to Customer, (iv) a violation of
Federal, state, or other laws or regulations for the protection of persons or members of a protected
class or category of persons by M&I or its employees or agents (v) sexual discrimination or
harassment by M&I, its employees, or agents, (vi) work-related injury or death caused by M&I, its
employees, or agents, and (vii) tangible personal or real property damage or financial or monetary
loss incurred by Customer resulting from M&I's acts or omissions or those of its employees or
agents. M&I shall be responsible for any costs and Expenses incurred by Customer in connection with
the enforcement of this Paragraph B.

14.3 Indemnification Procedures. If any third party makes a claim covered by this Section against an
indemnitee with respect to which such indemnitee intends to seek indemnification under this Section,
such indemnitee shall give notice of such claim to the indemnifying party, including a brief
description of the amount and basis therefor, if known. Upon giving such notice, the indemnifying
party shall be obligated to defend such indemnitee against such claim, and shall be entitled to
assume control of the defense of the claim with counsel chosen by the indemnifying party, reasonably
satisfactory to the indemnitee. Indemnitee shall cooperate fully with, and assist, the indemnifying
party in its defense against such claim in all reasonable respects. The indemnifying party shall
keep the indemnitee fully apprised at all times as to the status of the defense. Notwithstanding the
foregoing, the indemnitee shall have the right to employ its own separate counsel in any such
action, but the fees and expenses of such counsel shall be at the expense of such indemnitee;
provided, however (1) if the parties agree that it is advantageous to the defense for the indemnitee
to employ its own counsel or (2) in the reasonable judgment of the indemnitee, based upon an opinion
of counsel which shall be provided to the indemnifying party, representation of both indemnifying
party and the indemnitee would be inappropriate under applicable standards of professional conduct
due to actual or potential conflicts of interest between them, then reasonable fees and expenses of
the indemnitee's counsel shall be at the expense of the indemnifying party, provided that the
indemnifying party approves such counsel. Neither the indemnifying party nor any indemnitee shall be
liable for any settlement of action or claim effected without its consent. Notwithstanding the
foregoing, the indemnitee shall retain, assume, or reassume sole control over all expenses relating
to every aspect of the defense that it believes is not the subject of the indemnification provided
for in this section. Until both (a) the indemnitee receives notice from indemnifying party that it
will defend, and (b) the indemnifying party assumes such defense, the indemnitee may, at any time
after ten (10) days from the date notice of claim is given to the indemnifying party by the
indemnitee, resist or otherwise defend the claim or, after consultation with and consent of the
indemnifying party, settle or otherwise compromise or pay the claim. The indemnifying party shall
pay all costs of indemnity arising out of or relating to that defense and any such settlement,
compromise, or payment. The indemnitee shall keep the indemnifying party fully apprised at all times
as to the status of the defense. Following indemnification as
<!-- page 15 -->
provided in this Section, the indemnifying party shall be subrogated to all rights of the indemnitee
with respect to the matters for which indemnification has been made.

15. DISPUTE RESOLUTION

15.1 Representatives of Parties. All disputes arising under or in connection with this Agreement
shall initially be referred to the Account Representatives (as defined in Section 18.1). If the
Account Representatives are unable to resolve the dispute within five (5) business days after
referral of the matter to them, the managers of the Account Representatives shall attempt to resolve
the dispute. If, after five (5) days they are unable to resolve the dispute, senior executives of
the parties shall attempt to resolve the dispute. If, after give (5) days they are unable to resolve
the dispute, the parties shall submit the dispute to the chief executive officers of the parties for
resolution.

15.2 Continuity of Performance. M&I acknowledges that the provision of the Services is critical to
the business and operations of Customer. Accordingly, in the event of a dispute between Customer and
M&I, during the pendency of the dispute resolution proceedings described in this Article 15, M&I
shall continue to provide the Services and Customer shall continue to pay any undisputed amounts to
M&I.

16. REPRESENTATIONS AND WARRANTIES

16.1 By M&I. M&I represents and warrants that:

A. Capability of Computer Systems and Software. M&I's computer systems (hardware and software) are
capable of performing the Services in accordance with the provisions of this Agreement.

B. User Manuals. The reports made available to Customer shall be in substantial conformity with the
customer bulletins and the User Manuals, as amended from time to time, copies of which have been, or
will be, provided to Customer.

C. Rights. M&I has the right to provide the Services hereunder, using all computer software required
for that purpose.

D. Organization and Approvals. M&I is a validly organized corporate entity with valid authority to
enter into this Agreement. This Agreement has been duly authorized by all necessary corporate
action.

E. Millennium Compliance. The Services, including any software interfaces and enhancements created
by M&I, shall be Millennium Compliant on or before December 31, 1998. Any modification to make the
Services Millennium Compliant shall be made by M&I at no additional charge.

F. Disclaimer of Warranties. EXCEPT AS SPECIFICALLY SET FORTH IN THIS SECTION 16.1, M&I DISCLAIMS
ALL OTHER WARRANTIES, WHETHER WRITTEN, ORAL, EXPRESSED OR IMPLIED INCLUDING, WITHOUT LIMITING THE
GENERALITY OF THE FOREGOING, ANY WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.

16.2 By Customer. Customer represents and warrants that:

A. Organization. It is a corporation validly existing and in good standing under the laws of the
State of its incorporation;

B. Authority. It has all the requisite corporate power and authority to execute, deliver and perform
its obligations under this Agreement, the execution, delivery and performance of this Agreement has
been duly authorized by Customer and this Agreement is enforceable in accordance with its terms
against Customer;

C. Approvals. No approval, authorization or consent of any governmental or regulatory authorities
required to be obtained or made by Customer in order for Customer to enter into and perform its
obligations under this Agreement; and

D. Compliance. In connection with its obligations under this Agreement, Customer shall comply with
all applicable federal, state and local laws, rules and regulations and shall obtain all applicable
permits and licenses.

17. CONFIDENTIALITY AND OWNERSHIP

17.1 Customer Data. Customer shall remain the sole and exclusive owner of all Customer Data and
other Confidential Information (as hereinafter defined), regardless of whether such data is
maintained on magnetic tape, magnetic disk, or any other storage or processing device. All such
Customer Data and other Confidential Information shall, however, be subject to regulation and
examination by the appropriate auditors and regulatory agencies to the same extent as if such
information were on Customer's premises. "Customer Data" means any and all data and information of
any kind or nature submitted to M&I by Customer, or received by M&I on behalf of Customer, in
connection with the Services.

17.2 M&I Systems. Customer acknowledges that it has no rights in any software, systems,
documentation, guidelines, procedures and similar related materials or any modifications thereof
provided by M&I, except with respect to Customer's use of the same during the Term to process its
data. 17.3 Confidential Information. "Confidential Information" of a party
<!-- page 16 -->
shall mean all confidential or proprietary information and documentation of such party, whether or
not marked as such, including without limitation with respect to Customer, all Customer Data.
Confidential Information shall not include: (i) information which is or becomes publicly available
(other than by the person or entity having the obligation of confidentiality) without breach of this
Agreement; (ii) information independently developed by the receiving party; (iii) information
received from a third party not under a confidentiality obligation to the disclosing party; or (iv)
information already in the possession of the receiving party without obligation of confidence at the
time first disclosed by the disclosing party. The parties acknowledge and agree that the substance
of the negotiations of this Agreement, and the terms of this Agreement are considered Confidential
Information subject to the restrictions contained herein. Neither party shall use, copy, sell,
transfer, publish, disclose, display, or otherwise make any of the other party's Confidential
Information available to any third party without the prior written consent of the other.

17.4 Obligations of the Parties. M&I and Customer shall hold the Confidential Information of the
other party in confidence and shall not disclose or use such Confidential Information other than for
the purposes contemplated by this Agreement, and shall instruct their employees, agents, and
contractors to use the same care and discretion with respect to the Confidential Information of the
other party or of any third party utilized hereunder that M&I and Customer each require with respect
to their own most confidential information, but in no event less than a reasonable standard of care,
including but not limited to, the utilization of security devices or procedures designed to prevent
unauthorized access to such materials. Each party shall instruct its employees, agents, and
contractors of its confidentiality obligations hereunder and not to attempt to circumvent any such
security procedures and devices. Each party's obligation under the preceding sentence may be
satisfied by the use of its standard form of confidentiality agreement, if the same reasonably
accomplishes the purposes here intended. All such Confidential Information shall be distributed only
to persons having a need to know such information to perform their duties in conjunction with this
Agreement.

17.5 Security. M&I shall be responsible for, and shall establish and maintain safeguards against, a
disaster, loss or alteration of the Customer Data in the possession of M&I. Such safeguard shall be
no less rigorous than that M&I uses to protect its own data of a similar nature.

18. MANAGEMENT OF PROJECT

18.1 Account Representatives. Each party shall cause an individual to be assigned to the position of
Account Representative to devote time and effort to management of the Services under this Agreement.
Neither party shall reassign or replace its Account Representative during the first year of his or
her assignment without the consent of the other party, except if such individual voluntarily
resigns, is dismissed for cause, or is unable to work due to his or her death or disability.

18.2 Change Control Procedures. On or prior to the Conversion Date, M&I shall deliver to Customer
the Change Control Procedures to be used by M&I to perform the Services. At a minimum, the Change
Control Procedures shall provide for prior notice to Customer of changes which materially adversely
effect the quality or timeliness of the Services, in which case such change shall be made only on a
temporary basis. M&I agrees to schedule projects and changes so as to not unreasonably interrupt
Customer's business operations.

18.3 Reporting and Meetings. Within sixty (60) days after the Effective Date, the parties shall
mutually agree upon an appropriate set of periodic reports to be issued by M&I to Customer during
the Conversion Period and during the remainder of the Term. Within sixty (60) days after the
Effective Date, the parties will mutually agree on an appropriate set of periodic meetings to be
held between the Account Representatives during the Conversion Period and the remainder of the Term.
Meetings shall be held to review performance, changes, resource utilization and such other matter as
appropriate.

18.4 Development Projects and Technical Support. Upon Customer's written request, M&I will develop
and provide to Customer a good faith estimate of any additional charges which Customer may incur in
connection with the operation of any new software, major modification or enhancements developed by
M&I or the acquisition of third party software. Customer agrees that M&I will have the opportunity
to bid on and be considered for all software development, maintenance and other technology projects
related to the Services that Customer wishes to implement.

19. REGULATORY COMPLIANCE

A. M&I shall comply with, and M&I shall provide Customer with data and reports necessary for
Customer to comply with, all federal laws applicable to the transactions or accounts processed by
M&I. Customer shall have the right to notify M&I of any requirements or changes in state law which
affect the provision of the Services. Thereafter, M&I shall schedule implementation of the changes
prior to the deadline imposed by the regulatory or other governmental agency having jurisdiction for
such change. M&I's obligation to meet the compliance deadline shall be contingent upon M&I receiving
timely notice from Customer or any other service bureau customer of M&I so as to enable M&I to
schedule and implement such change prior to the regulatory deadline. M&I shall implement such change
at Customer's sole cost and expense (shared equitably among all of M&I's other service bureau
customers who are affected by such change).
<!-- page 17 -->
B. Provided that such enactments or regulations do not prohibit M&I from performing the Services for
Customer, M&I shall use commercially reasonable efforts to perform the Services regardless of
changes in legislative enactments or regulatory requirements. If such changes prevent M&I from
performing its obligations under this Agreement, M&I shall, when appropriate, make commercially
reasonable efforts to develop and implement a suitable work around until such time as M&I can
perform its obligations under this Agreement without such work around.

20. DISASTER RECOVERY

20.1 Disaster Recovery Plan. M&I shall maintain throughout the term of the Agreement a Disaster
Recovery Plan in compliance with all regulatory requirements, which Disaster Recovery Plan shall
cover all the Services. For the purposes of this Agreement, "Disaster" means any unplanned
interruption of operations which materially affects the ability of M&I to provide Services, or as
otherwise provided in the Disaster Recovery Plan. Review and acceptance of any Disaster Recovery
Plan as may be required by any such regulatory organizations shall be the responsibility of
Customer, provided that M&I provides Customer and any such regulatory organizations such cooperation
and assistance in conducting such reviews as Customer or such regulatory organizations may from time
to time reasonably request. Any Disaster Recovery Plan shall provide, at a minimum, for M&I to
provide alternate electrical power supplies for uninterrupted service. The Disaster Recovery Plan
shall also designate one or more facilities (each a "Disaster Recovery Site") or separate computer
resources to which M&I shall move the affected portion of any Services upon the declaration of a
Disaster (as provided in the Disaster Recovery Plan) requiring such a relocation. Any Disaster
Recovery Site must be appropriately equipped with data processing resources sufficient to provide
all Services in compliance with regulatory requirements. Any Disaster Recovery Plan must also
specify all procedures for the determination or declaration of a Disaster, which determination or
declaration may not be unreasonably withheld or delayed by either party. A detailed Executive
Summary of the Disaster Recovery Plan, as amended from time to time, shall be provided to Customer
without charge.

20.2 Relocation. M&I shall relocate all affected Services to the Disaster Recovery Site as
expeditiously as possible after declaration of a Disaster (as provided in the Disaster Recovery
Plan), and shall coordinate with Customer all requisite telecommunications modifications necessary
to achieve full connectivity to the Disaster Recovery Site in material compliance with all
regulatory requirements.

20.3 Resumption of Services. The Disaster Recovery Plan shall provide that, in the event of a
Disaster, M&I is able to resume all Services in accordance herewith utilizing the Disaster Recovery
Site within a commercially reasonable period following the declaration of any Disaster as provided
in the Disaster Recovery Plan. In the event M&I is unable to resume all Services to Customer within
thirty (30) days following the declaration of any Disaster, Customer shall have the right to
terminate this Agreement without penalty upon written notice to M&I delivered within forty-five (45)
days after declaration of such Disaster.

20.4 Annual Test. M&I shall test its Disaster Recovery Plan by conducting one (1) test annually and
shall provide Customer with a description of the test results in accordance with applicable laws and
regulations.

21. GENERAL TERMS AND CONDITIONS

21.1 Force Majeure. Notwithstanding any provision contained in this Agreement, neither party shall
be liable to the other to the extent fulfillment or performance of any terms or provisions of this
Agreement is delayed or prevented by revolution or other civil disorders; wars; acts of enemies;
strikes; lack of available resources from persons other than parties to this Agreement; labor
disputes; electrical equipment or availability failure; fires; floods; acts of God; federal, state
or municipal action; statute; ordinance or regulation; or, without limiting the foregoing, any other
causes not within its control, and which by the exercise of reasonable diligence it is unable to
prevent, whether of the class of causes hereinbefore enumerated or not. This clause shall not apply
to the payment of any sums due under this Agreement by either party to the other.

21.2 Transmission of Data. The responsibility and expense for transportation and transmission of,
and the risk of loss for, data and media transmitted between M&I and Customer shall be borne by
Customer. Data lost by M&I following processing, including loss of data transmission, shall either
be restored by M&I from its back-up media or shall be reprocessed at no charge.

21.3 Equipment and Network. Customer shall obtain and maintain at its own expense its own data
processing and communications equipment as may be necessary or appropriate to facilitate the proper
use and receipt of the Services. Customer shall pay all installation, monthly, and other charges
relating to the installation and use of communications lines in connection with the Services. M&I
maintains and will continue to maintain a network control center with diagnostic capability to
monitor communication line reliability and availability. M&I shall not be responsible for the
continued availability or reliability of the communications lines used by Customer in accessing the
Services. M&I agrees to perform reasonable diagnostic services and communicate to vendors any
deficiencies of which M&I is, or becomes, aware.

21.4 Reliance on Data. M&I will process Items and data and perform
<!-- page 18 -->
those Services described in this Agreement on the basis of information furnished by Customer. M&I
shall be entitled to rely upon any such data, information, or instructions as provided by Customer.
If any error results from incorrect input supplied by Customer, Customer shall be responsible for
discovering and reporting such error and supplying the data necessary to correct such error to M&I
for processing at the earliest possible time. Customer will indemnify and hold M&I harmless from any
cost, claim, damage, or liability (including attorneys' fees) whatsoever arising out of such data,
information or instructions, or any inaccuracy or inadequacy therein.

21.5 Data Backup. In the event Customer does not receive Item Processing Services from M&I, Customer
shall maintain adequate records for at least ten (10) business days including (i) microfilm images
of items being transported to M&I or (ii) backup on magnetic tape or other electronic media where
transactions are being transmitted to M&I, from which reconstruction of lost or damaged items or
data can be made. Customer assumes all responsibility and liability for any loss or damage resulting
from failure to maintain such records.

21.6 Balancing and Controls. Customer shall (a) on a daily basis, review all input and output,
controls, reports, and documentation, to ensure the integrity of data processed by M&I; and (b) on a
daily basis, check exception reports to verify that all file maintenance entries and nondollar
transactions were correctly entered. Customer shall be responsible for initiating timely remedial
action to correct any improperly processed data which these reviews disclose.

21.7 Use of Services. (A) Customer assumes exclusive responsibility for the consequences of any
instructions Customer may give M&I, for Customer's failure to properly access the Services in the
manner prescribed by M&I, and for Customer's failure to supply accurate input information; (B)
Customer agrees that, except as otherwise permitted in this Agreement or in writing by M&I, Customer
will use the Services only for its own internal business purposes to service its banking customers
and clients and will not sell or otherwise provide, directly or indirectly, any of the Services or
any portion thereof to any third party; and (C) Customer agrees and represents that (i) the
performance of this Agreement by the Customer will not affect the safety or soundness of the
Customer or any of its affiliates, and (ii) this Agreement, and the obligations evidenced hereby,
will be properly reflected on the books and records of the Customer, and the Customer will provide
evidence of the same to M&I upon request.

21.8 Regulatory Assurances. M&I and Customer acknowledge and agree that the performance of these
Services will be subject to regulation and examination by Customer's regulatory agencies to the same
extent as if such Services were being performed by Customer. Upon request, M&I agrees to provide any
appropriate assurances to such agency and agrees to subject itself to any required examination or
regulation. Customer agrees to reimburse M&I for reasonable costs actually incurred due to any such
examination or regulation that is performed solely for the purpose of examining Services used by
Customer.

A. Notice Requirements. The Customer shall be responsible for complying with all regulatory notice
provisions to any applicable governmental agency, which shall include providing timely and adequate
notice to the Chief Examiner of the Federal Home Loan Bank Board, the Office of Thrift Supervision,
the Office of the Comptroller of the Currency, The Federal Deposit Insurance Corporation, the
Federal Reserve Board, or their successors, as applicable (collectively, the "Federal Regulators"),
as of the effective date of Services under this Agreement, identifying those records to which this
Agreement shall apply and the location at which such Services are to be performed.

B. Examination of Records. The parties agree that the records maintained and produced under this
Agreement shall, at all times, be available for examination and audit by governmental agencies
having jurisdiction over the Customer's business, including any Federal Regulator. The Director of
Examinations of any Federal Regulator or his or her designated representative shall have the right
to ask for and to receive directly from M&I any reports, summaries, or information contained in or
derived from data in the possession of M&I related to the Customer. M&I shall notify Customer as
soon as reasonably possible of any formal request by an authorized governmental agency to examine
Customer's records maintained by M&I, if M&I is permitted to make such a disclosure to Customer
under applicable law or regulations. Customer agrees that M&I is authorized to provide all such
described records when formally required to do so by a Federal Regulator.

C. Audits. M&I shall cause a third party review of its data processing center, the Operations
Center, and related internal controls to be conducted annually by its independent auditors. M&I
shall provide without charge to Customer, upon written request, one copy of the audit report
resulting from such review. M&I agrees to promptly implement any changes recommended as a result of
such audit.

21.9 IRS Filing. Customer represents it has complied with all laws, regulations, procedures, and
requirements in attempting to secure correct tax identification numbers (TINs) for Customer's payees
and customers and agrees to attest to this compliance by an affidavit provided annually. Customer
authorizes M&I to act as Customer's agent and sign on Customer's behalf the Affidavit required by
the Internal Revenue Service on Form 4804, or any successor form. Exhibit C (Attorney-in-Fact
Appointment) and Exhibit D (Affidavit) shall be executed by Customer contemporaneously with the
execution of this Agreement. Customer acknowledges that M&I's execution of the Form 4804 Affidavit
on Customer's behalf does not relieve Customer of responsibility to provide accurate TINs or
liability for any
<!-- page 19 -->
penalties which may be assessed for failure to comply with TIN requirements. Customer agrees to hold
M&I harmless from any liabilities, claims, expenses, penalties, or damages (including attorneys'
fees) which may be assessed or incurred as a result of the failure to comply with TIN requirements.

21.10 Affiliates. All processing for Customer and Customer's subsidiaries and Affiliates which M&I
does shall be included as part of the Services provided under this Agreement and shall be done in
accordance with the terms and conditions of this Agreement. Customer agrees that it is responsible
for assuring compliance with the Agreement by its affiliates and subsidiaries. Customer agrees to be
responsible for the submission of its affiliates' data to M&I for processing and for the
transmission to Customer's affiliates of such data processed by and received from M&I. Customer
agrees to pay any and all fees owed under this Agreement for Services rendered to it and its
subsidiaries and other Affiliates.

21.11 Future Acquisitions. Customer acknowledges that M&I has established the Fee Schedule and
enters into this Agreement on the basis of M&I's understanding of the Customer's current need for
Services and Customer's anticipated future need for Services as a result of internally generated to
include additional branch locations which Customer may open and other operations Customer may
commence. If the Customer expands it operations by acquiring Control of additional financial
institutions or the Customer experiences a Change in Control (as hereinafter defined), the following
provisions shall apply:

A. Acquisition of Additional Financial Institutions. If Customer acquires Control after the date
hereof of one or more bank holding companies, banks, savings and loan associations or other
financial institutions that are not currently Affiliates, M&I agrees to provide Services for such
new Affiliates and such Affiliates shall automatically be included in the definition of "Customer";
provided that (a) the Conversion of each new Affiliate must be scheduled at a mutually agreeable
time (taking into account, among other things, the availability of M&I Conversion resources) and
must be completed before M&I has any obligation to provide Services to such new Affiliate; (b) the
Customer will be liable for any and all Expenses in connection with the Conversion of such new
Affiliate and (c) Customer shall pay Conversion Fees in an amount to be mutually agreed upon with
respect to each new Affiliate.

B. Change in Control of Customer. If a Change in Control occurs with respect to Customer, M&I agrees
to continue to provide Services under this Agreement; provided that (a) M&I's obligation to provide
Services shall be limited to the entities comprising the Customer prior to such Change in Control
and (b) M&I's obligation to provide Services shall be limited in any and all circumstances to the
number of accounts and items processed in the 3-month period prior to such Change in Control
occurring plus 25%.

22. MISCELLANEOUS PROVISIONS

22.1 Governing Law. The validity, construction and interpretation of this Agreement and the rights
and duties of the parties hereto shall be governed by the internal laws of the State of Wisconsin,
excluding its principles of conflict of laws.

22.2 Venue and Jurisdiction. In the event of litigation to enforce the terms of this Agreement, the
parties consent to venue in an exclusive jurisdiction of the courts of Milwaukee County, Wisconsin
and the Federal District Court for the Eastern District of Wisconsin. The parties further consent to
the jurisdiction of any federal or state court located within a district which encompasses assets of
a party against which a judgment has been rendered, either through arbitration or litigation, for
the enforcement of such judgment or award against such party or the assets of such party.

22.3 Entire Agreement; Amendments. This Agreement, together with the exhibits and schedules hereto,
constitutes the entire agreement between M&I and the Customer with respect to the subject matter
hereof. There are no restrictions, promises, warranties, covenants or undertakings other than those
expressly set forth herein and therein. This Agreement supersedes all prior negotiations,
agreements, and undertakings between the parties with respect to such matter. This Agreement,
including the exhibits and schedules hereto, may be amended only by an instrument in writing
executed by the parties or their permitted assignees.

22.4 Assignment. This Agreement may not be assigned by either party, by operation of law or
otherwise, without the prior written consent of the other party, which consent shall not be
unreasonably withheld, provided that (a) M&I's consent need not be obtained in connection with the
assignment of this Agreement pursuant to a merger in which Customer is a party and as a result of
which the surviving corporation becomes an Affiliate of another bank holding company, bank, savings
and loan association or other financial institution having a capital and surplus of at least
$100,000,000 so long as the provisions of Section 21.11 are complied with and (b) M&I may freely
assign this Agreement (i) in connection with a merger, corporate reorganization or sale of all or
substantially all of its assets, stock or securities, or (ii) to any entity which is a successor to
the assets or the business of the M&I Data Services division of M&I.

22.5 Relationship of Parties. The performance by M&I of its duties and obligations under this
Agreement shall be that of an independent contractor and nothing contained in this Agreement shall
create or imply an agency's relationship between Customer and M&I, nor shall this Agreement be
<!-- page 20 -->
deemed to constitute a joint venture or partnership between Customer and M&I.

22.6 Notices. Except as otherwise specified in the Agreement, all notices, requests, approvals,
consents and other communications required or permitted under this Agreement shall be in writing and
shall be personally delivered or sent by (i) first class U.S. mail, registered or certified, return
receipt requested, postage pre-paid; or (ii) U.S. express mail, or other, similar overnight courier
service to the address specified below. Notices shall be deemed given on the day actually received
by the party to whom the notice is addressed.

In the case of Customer: Tri City National Bank 6400 South 27th Street Oak Creek, WI 53154 Attn: Mr.
Ronald K. Puetz Executive Vice President

In the case of M&I: M&I Data Services 4900 West Brown Deer Road Brown Deer WI 53223 Attn: Mr. Thomas
R. Mezera Vice President Sales & Marketing

22.7 Headings. Headings in this Agreement are for reference purposes only and shall not effect the
interpretation or meaning of this Agreement.

22.8 Counterparts. This Agreement may be executed simultaneously in any number of counterparts, each
of which shall be deemed an original but all of which together constitute one and the same
agreement.

22.9 Waiver. No delay or omission by either party to exercise any right or power it has under this
Agreement shall impair or be construed as a waiver of such right or power. A waiver by any party of
any breach or covenant shall not be construed to be a waiver of any succeeding breach or any other
covenant. All waivers must be in writing and signed by the party waiving its rights.

22.10 Severability. If any provision of this Agreement is held by court or arbitrator of competent
jurisdiction to be contrary to law, then the remaining provisions of this Agreement will remain in
full force and effect. Articles 11, 13 and 17 shall survive the expiration or earlier termination of
this Agreement for any reason.

22.11 Attorneys' Fees and Costs. If any legal action or arbitration proceeding has commenced in
connection with the enforcement of this Agreement or any instrument or agreement required under this
Agreement, the prevailing party shall be entitled to attorneys' fees actually incurred, costs and
necessary disbursements incurred in connection with such action or proceeding, as determined by the
court or arbitrator.

22.12 Financial Statements. M&I agrees to furnish to the Customer copies of the then-current annual
report for the Marshall & Ilsley Corporation, within 45 days after such document is made publicly
available.

22.13 Publicity. Neither party shall use the other parties' name or trademark or refer to the other
party directly or indirectly in any media release, public announcement or public disclosure relating
to this Agreement or its subject matter, in any promotional or marketing materials, lists or
business presentations, without consent from the other party for each such use or release. Customer
agrees that neither it, its directors, officers, employees or agents shall disclose this Agreement
or any of the terms or provisions of this Agreement to any other party.

22.14 Solicitation. Neither party shall solicit the employees of the other party during the Term of
this Agreement, for any reason.

22.15 No Third Party Beneficiaries. Each party intends that this Agreement shall not benefit, or
create any right or cause of action in or on behalf of, any person or entity other than the Customer
and M&I.

22.16 Construction. M&I and Customer each acknowledge that the limitations and exclusions contained
in this Agreement have been the subject of active and complete negotiation between the parties and
represent the parties' agreement based upon the level of risk to Customer and M&I associated with
their respective obligations under this Agreement and the payments to be made to M&I and the charges
to be incurred by M&I pursuant to this Agreement. The parties agree that the terms and conditions of
this Agreement shall not be construed in favor of or against any party by reason of the extent to
which any party or its professional advisors participated in the preparation of this document.

23. SOURCE CODE

23.1 Escrow. M&I has entered into a Master Preferred Escrow Agreement ("Escrow Agreement") with Data
Securities International, Inc. ("DSI"), Account no. 1309046-0001, pursuant to which M&I has
deposited with DSI the source code for the IBS Licensed Software (the "IBS Software").

23.2 Copy of Source Code. M&I agrees that Customer shall have the right to obtain a copy of the
source code for the IBS Software pursuant to the terms and conditions of this Article 23.

23.3 Cost of Escrow. M&I shall be responsible for the cost of maintaining and updating the source
code escrow including any fees to be
<!-- page 21 -->
paid to DSI. M&I shall have the right to change escrow agents and shall promptly notify Customer of
such change during the Term.

23.4 Customer's Right to Obtain the Source Code. M&I hereby grants to Customer a non-exclusive,
non-transferable license, through the end of the Term, to use the source code (including the right
to make modifications thereto) on the terms and conditions set forth in this Article 23, upon
payment of the then current license fees and the occurrence of the following events:

A. M&I ceases to do business or refuses to provide the Services to Customer; or

B. A voluntary or involuntary petition is commenced by or against M&I under any federal or state
bankruptcy law, or a trustee in bankruptcy fails to timely assume this Agreement as an executory
contract, or a substantial part of M&I's property or assets become subject to levy or seizure by any
creditor and, in the case of an involuntary petition, the same is not dismissed within sixty (60)
days after filing.

23.5 Use of Source Code. In the event Customer obtains a copy of the source code pursuant to Section
23.4 above, Customer (or its designee) shall use the source code during the term of the license
granted herein solely for Customer's own internal processing and computing needs and to process the
Customer Data, but shall not (1) distribute, sell, transfer, assign or sublicense the source code or
any parts thereof to any third party, (2) use the source code in any manner to provide service
bureau, time sharing or other computer services to third parties, or (3) use any portion of the
source code to process data under any application or functionality other than those applications or
functionalities which were being provided by M&I to Customer at the time Customer became entitled to
receive a copy of the source code.

IN WITNESS WHEREOF, the parties have caused this Agreement to be executed in their names as of the
date first above written.

MARSHALL & ILSLEY CORPORATION ("M&I") 4900 W. Brown Deer Road Brown Deer, WI 53223

By: Name: Patrick C. Foy Title: President, Outsourcing Business Group

By: Name: Thomas R. Mezera Title: Vice President, Sales & Marketing

TRI CITY NATIONAL BANK ("Customer") 6400 South 27th Street Oak Creek, WI 53154

By: Name: Ronald K. Puetz Title: Executive Vice President
