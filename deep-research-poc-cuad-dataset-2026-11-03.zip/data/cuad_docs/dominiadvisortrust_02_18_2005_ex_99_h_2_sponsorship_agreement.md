<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 2005-02-04 |
| Parties | Domini Advisor Trust ("Trust"); Domini Social Investments LLC ("Domini" or the "Sponser") |
| Source | CUAD v1 / DOMINIADVISORTRUST_02_18_2005-EX-99.(H)(2)-SPONSORSHIP AGREEMENT |

Exhibit h(2) SPONSORSHIP AGREEMENT

SPONSORSHIP AGREEMENT, dated as of February 4, 2005, by and between Domini Advisor Trust, a
Massachusetts business trust (the "Trust"), and Domini Social Investments LLC, a Massachusetts
limited liability company ("Domini" or the "Sponsor").

W I T N E S S E T H:

WHEREAS, the Trust is engaged in business as an open-end investment company registered under the
Investment Company Act of 1940, as amended, and consists of one or more series; and

WHEREAS, the Trust desires to enter into this Agreement with respect to its current and future
series; and

WHEREAS, the Trust wishes to engage Domini to provide certain oversight, administrative and
management services, and Domini is willing to provide such oversight, administrative and management
services to the Trust on the terms and conditions hereinafter set forth;

NOW, THEREFORE, in consideration of the mutual covenants and agreements of the parties hereto as
herein set forth, the parties covenant and agree as follows:

1. Duties of the Sponsor. Subject to the direction and control of the Board of Trustees of the
Trust, the Sponsor shall perform such oversight, administrative and management services as may from
time to time be reasonably requested by the Trust, which shall include without limitation: (a)
maintaining office facilities (which may be in the office of Domini or an affiliate) and furnishing
clerical services necessary for maintaining the organization of the Trust and for performing the
oversight, administrative and management functions herein set forth; (b) arranging, if desired by
the Trust, for directors, officers or employees of the Sponsor to serve as Trustees, officers or
agents of the Trust if duly elected or appointed to such positions and subject to their individual
consent and to any limitations imposed by law; (c) supervising the overall administration of the
Trust, including the updating of corporate organizational documents, and the negotiation of
contracts and fees with and the monitoring and coordinating of performance and billings of the
Trust's transfer agent, shareholder servicing agents (if any), custodian, administrator,
subadministrator (if any) and other independent contractors or agents; (d) overseeing (with advice
of the Trust's counsel) the preparation of and, if applicable, filing all documents required for
compliance by the Trust with applicable laws and regulations (including state "blue sky" laws and
regulations), including registration statements on Form N-1A, prospectuses and statements of
additional information, or similar forms, as applicable, semi-annual and annual reports to
shareholders and proxy statements, and reviewing tax returns; (e) preparation of agendas and
supporting documents for and minutes of meetings of Trustees, committees of Trustees and preparation
of notices, proxy statements and minutes of meetings of shareholders; (f) arranging for maintenance
of books and records of the Trust; (g) maintaining telephone coverage to respond to shareholder
inquiries regarding matters to which this Agreement pertains to which the transfer agent is unable
to respond; (h) providing
<!-- page 2 -->
reports and assistance regarding each series' compliance with securities and tax laws and each
series' investment objectives; (i) arranging for dissemination of yield and other performance
information to newspapers and tracking services; (j) arranging for and preparing annual renewals for
fidelity bond and errors and omissions insurance coverage; (k) developing a budget for the Trust,
establishing the rate of expense accruals and arranging for the payment of all fixed and management
expenses; and (l) answering questions from the general public, the media and investors in the Trust
regarding (i) the securities holdings of the Trust; (ii) any limits in which the Trust invests;
(iii) the social investment philosophy of the Trust; and (iv) the proxy voting philosophy and
shareholder activism philosophy of the Trust. Notwithstanding the foregoing, the Sponsor shall not
be deemed to have assumed, pursuant to this Agreement, any duties with respect to, and shall not be
responsible for, the management of the Trust's assets or the rendering of investment advice and
supervision with respect thereto or the distribution of shares of any series, nor shall the Sponsor
be deemed to have assumed or have any responsibility with respect to functions specifically assumed
by any transfer agent, custodian, fund accounting pricing agent or shareholder servicing agent of
the Trust.

2. Allocation of Charges and Expenses. Domini shall pay the entire salaries and wages of all of the
Trust's Trustees, officers and agents who devote part or all of their time to the affairs of Domini
or its affiliates, and the wages and salaries of such persons shall not be deemed to be expenses
incurred by the Trust for purposes of this Section 2. The Trust shall pay all of its operating
expenses, including but not limited to fees due the Sponsor under this Agreement, compensation of
Trustees not affiliated with the Sponsor, governmental fees, including but not limited to Securities
and Exchange Commission fees and state "blue sky" fees; interest charges; taxes and related charges;
membership dues of the Trust in the Investment Company Institute and other professional or industry
associations; fees and expenses of the Trust's independent auditors and accountants, of legal
counsel and any transfer agent, distributor, shareholder servicing agent, recordkeeper, registrar or
dividend disbursing agent of the Trust; expenses of distributing, issuing and redeeming shares and
servicing shareholder accounts; expenses of preparing, printing and mailing prospectuses and
statements of additional information, reports, notices, proxy statements and reports to shareholders
and governmental officers and commissions; expenses connected with the execution, recording and
settlement of portfolio security transactions; insurance premiums; fees and expenses of the Trust's
custodian for all services to the Trust, including safekeeping of funds and securities and
maintaining required books and accounts; expenses of calculating the net asset value of shares of
the Trust; expenses of shareholder meetings; and expenses relating to the issuance, registration and
qualification of shares of any series of the Trust.

3. Compensation of the Sponsor. For the services to be rendered and facilities to be provided by the
Sponsor hereunder, the Trust shall pay Domini a fee accrued daily and payable monthly at an annual
rate equal to 0.50% of the Trust's average daily net assets for the Trust's then current fiscal
year. If Domini serves as the Sponsor for less than the whole of any period specified in this
Section 3, the compensation to Domini, as Sponsor, shall be prorated. For purposes of computing the
fees payable to the Sponsor hereunder, the value of the Trust's net assets shall be computed in the
manner specified in the Trust's then-current prospectus and statement of additional information.

2
<!-- page 3 -->
4. Limitation of Liability of the Sponsor. The Sponsor shall not be liable for any error of judgment
or mistake of law or for any act or omission in the oversight, administration or management of the
Trust or the performance of its duties hereunder, except for willful misfeasance, bad faith or gross
negligence in the performance of its duties, or by reason of the reckless disregard of its
obligations and duties hereunder. As used in this Section 4, the term "Sponsor" shall include Domini
and/or any of its affiliates and the directors, officers and employees of Domini and/or any of its
affiliates.

5. Activities of the Sponsor. The services of the Sponsor to the Trust are not to be deemed to be
exclusive, Domini being free to render oversight, administrative and/or other services to other
parties. It is understood that Trustees, officers and shareholders of the Trust are or may become
interested in the Sponsor and/or any of its affiliates as directors, officers, employees or
otherwise and that directors, officers and employees of the Sponsor and/or any of its affiliates are
or may become similarly interested in the Trust and that the Sponsor and/or any of its affiliates
may be or become interested in the Trust as a shareholder or otherwise.

6. Duration, Termination and Amendments of this Agreement. This Agreement shall become effective as
of the day and year first above written and shall govern the relations between the parties hereto
thereafter, unless terminated as set forth in this Section 6.

This Agreement may not be altered or amended, except by an instrument in writing and executed by
both parties. This Agreement may be terminated at any time, without the payment of any penalty, with
respect to any series or the Trust, by the Board of Trustees of the Trust, or by the Sponsor, in
each case on not less than 60 days' written notice to the other party.

7. Subcontracting by Domini. Domini may subcontract for the performance of some or all of Domini's
obligations hereunder with any one or more persons; provided, however, that Domini shall not enter
into any such subcontract unless the Trustees of the Trust shall have found the subcontracting party
to be qualified to perform the obligations sought to be subcontracted; and provided, further, that,
unless the Trust otherwise expressly agrees in writing, Domini shall be as fully responsible to the
Trust for the acts and omissions of any subcontractor as it would be for its own acts or omissions.

8. Severability. If any provision of this Agreement shall become or shall be found to be invalid by
a court decision, statute, rule or otherwise, the remainder of this Agreement shall not be affected
thereby.

9. Notice. Any notices under this Agreement shall be in writing addressed and delivered personally,
by telecopy or mailed postage-paid to the other party at such address as such other party may
designate in accordance with this Section 9 for the receipt of such notice. Until further notice to
the other party, it is agreed that the address of the Trust shall be 536 Broadway, 7th Floor, New
York, New York 10012, and the address of Domini shall be 536 Broadway, 7th Floor, New York, New York
10012.

3
<!-- page 4 -->
10. Miscellaneous. Each party agrees to perform such further actions and execute such further
documents as are necessary to effectuate the purposes hereof. This Agreement shall be construed and
enforced and interpreted in accordance with and governed by the laws of the Commonwealth of
Massachusetts without reference to principles of conflicts of law. The captions in this Agreement
are included for convenience only and in no way define or delimit any of the provisions hereof or
otherwise affect their construction or effect. This Agreement may be executed in any number of
counterparts, each of which shall be deemed to be an original, but such counterparts shall,
together, constitute only one instrument.

IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be executed and delivered in
their names and on their behalf by the undersigned, thereunto duly authorized, all as of the day and
year first above written. The undersigned Trustee of the Trust has executed this Agreement not
individually but as a Trustee under the Trust's Declaration of Trust, dated October 6, 2004, as
amended, and the obligations of this Agreement are not binding upon any of the Trustees or
shareholders of the Trust individually but bind only the Trust estate.

DOMINI ADVISOR TRUST

By: /s/ Amy L. Domini --------------------------------- Amy L. Domini Trustee

DOMINI SOCIAL INVESTMENTS LLC

By: /s/ Amy L. Domini --------------------------------- Amy L. Domini Chief Executive Officer

4
