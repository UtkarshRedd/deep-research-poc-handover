<!-- page 1 -->
# Software License, Customization and Maintenance Agreement
| Field | Value |
|---|---|
| Document Type | Maintenance Agreement |
| Agreement Date | 2010-11-04 |
| Parties | Cardlytics, Inc. (“Supplier”); Bank of America, N.A. (“Bank of America”); |
| Source | CUAD v1 / CardlyticsInc_20180112_S-1_EX-10.16_11002987_EX-10.16_Maintenance Agreement1 |

Exhibit 10.16

[***] = CERTAIN CONFIDENTIAL INFORMATION CONTAINED IN THIS DOCUMENT, MARKED BY BRACKETS, HAS BEEN
OMITTED AND FILED SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION PURSUANT TO RULE 406 OF THE
SECURITIES ACT OF 1933, AS AMENDED.

Software License, Customization and Maintenance Agreement Agreement Number: CW251207

Effective Date: 11/4/10

Company Name: Cardlytics, Inc.

Company Address: 621 North Avenue NE Suite C-30 Atlanta, GA 30308

Company Telephone: 888.798.5802 This SOFTWARE LICENSE, CUSTOMIZATION AND MAINTENANCE AGREEMENT
("Agreement") is entered into as of the Effective Date by and between Bank of America, N.A. ("Bank
of America"), a national banking association, and the above-named Supplier, a corporation, and
consists of this signature page and the attached Terms and Conditions, Schedules, and all other
documents attached hereto, which are incorporated in full by this reference. ("Supplier") Bank of
America, N.A.

By: /s/ Scott Grime By: /s/ Chandra Torrence Name: Scott Grime Name: Chandra Torrence Title: Chief
Executive Officer Title: V.P., Sourcing Manager Date: 11/8/10 Date: 11/4/10

Address for Notices:

Cardlytics, Inc. 621 North Ave NE Suite C-30 Atlanta, GA 30030 ATTN: Scott Grimes Telephone:
888.798.5802 Email: [***]

Address for Notices: (Supply Chain Management Contact) Mailcode NC1-023-09-01 Bank of America 625 N
Tryon St Charlotte, NC 28255 ATTN: Chandra Torrence Telephone: [***] Email: [***]

With a copy to:

Bank of America Legal Department 101 S. Tryon Street Charlotte, NC 28255 Proprietary to Bank of
America vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 2 -->
Software License, Customization and Maintenance Agreement Table of Contents Page 1.0 DEFINITIONS 1
2.0 LICENSE 4 3.0 RELATIONSHIP MANAGER 6 4.0 TERM 7 5.0 TERMINATION 7 6.0 ORDERING, DELIVERY AND
INSTALLATION 8 7.0 CUSTOMIZATIONS 9 8.0 SOURCE CODE CUSTODY 10 9.0 DOCUMENTATION 11 10 ACCEPTANCE 11
11.0 MAINTENANCE SERVICES 12 12.0 UPGRADES 12 13.0 NON-MAINTENANCE SERVICES SUPPORT 12 14.0 TRAINING
12 15.0 PRICING/FEES 13 16.0 INVOICES TAXES/PAYMENT 13 17.0 EXPORT LAWS 15 18.0 MUTUAL
REPRESENTATIONS AND WARRANTIES 15 19.0 REPRESENTATIONS AND WARRANTIES OF SUPPLIER 15 20.0 DELETION
OF FUNCTIONS 17 21.0 DISABLEMENT OF SOFTWARE AND HARDWARE 17 22.0 FINANCIAL RESPONSIBILITY 17 23.0
BUSINESS CONTINUITY 17 24.0 RELATIONSHIP OF THE PARTIES 18 25.0 SUPPLIER PERSONNEL 18 26.0 INSURANCE
19 27.0 CONFIDENTIALITY AND INFORMATION PROTECTION 20 28.0 INDEMNITY 23 29.0 LIMITATION OF LIABILITY
24 30.0 DAMAGE TO BANK OF AMERICA SYSTEMS 24 31.0 SUPPLIER DIVERSITY 25 32.0 ENVIRONMENTAL
INITIATIVE 26 33.0 AUDIT 26 34.0 NON-ASSIGNMENT 27 35.0 GOVERNING LAW 27 37.0 MEDIATION/ARBITRATION
28 38.0 NON-EXCLUSIVE NATURE OF AGREEMENT 29 39.0 OWNERSHIP OF WORK PRODUCT 29 40.0 MISCELLANEOUS 30
41.0 ENTIRE AGREEMENT 32 SCHEDULE A PRODUCT LICENSE SCHEDULE TEMPLATE SCHEDULE B CUSTOMIZATION
SCHEDULE SCHEDULE C CHANGE ORDER REQUEST FORM SCHEDULE D MAINTENANCE SERVICES SCHEDULE E INFORMATION
SECURITY SCHEDULE F BACKGROUND CHECKS SCHEDULE G RECOVERY Proprietary to Bank of America ii vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 3 -->
1.0 DEFINITIONS

1.1 All defined terms In this Agreement not otherwise defined in this Section shall have the
meanings assigned in the part of this Agreement in which they are defined.

1.2 Acceptance Date - the first Business Day after the day Bank of America accepts the Software or
it is deemed accepted pursuant to the Section entitled "Acceptance."

1.3 Acceptance Period - the period commencing on the Installation Date and continuing for the number
of days specified in each Product License Schedule, as such period may be extended pursuant to the
Section entitled "Acceptance."

1.4 Affiliate - a business entity now or hereafter controlled by, controlling or under common
control with a Party. Control exists when an entity owns or controls directly or indirectly 50% or
more of the outstanding equity representing the right to vote for the election of directors or other
managing authority of another entity.

1.5 Associate Information - any non-public information about a Bank of America Representative,
whether in paper, electronic, or other form that is maintained by or on behalf of Bank of America
for a business purpose.

1.6 Bank of America Customizations - Customizations listed on a Customization Schedule, which shall
be owned by Bank of America and subject to the Marketing Restrictions outlined in the Section
entitled "Customizations."

1.7 Bank Security Requirements- all bank security requirements as described in SCHEDULE E and the
Bank of America Service Provider Security Requirements document provided separately.

1.8 Business Continuity Plan - the policies and procedures that describe contingency plans, recovery
plans, and proper risk controls to ensure Supplier's continued performance under this Agreement.

1.9 Business Day - Monday through Friday, excluding days on which Bank of America is not open for
business in the United States of America.

1.10 Consumer Information - any record about an individual, whether in paper. electronic. or other
form, that is a consumer report as such term is defined in the Fair Credit Reporting Act (15 USC
1681 et seq.) or is derived from a consumer report and that is maintained or otherwise possessed by
or on behalf of Bank of America for a business purpose. Consumer Information also means a
compilation of such records. The term does not include any record that does not identify an
individual.

1.11 Correction - a modification to Software to resolve one (1) or more Errors.

1.12 Customer Information - any record containing information about a customer, its usage of Bank of
America's services, or about a customer's accounts, whether in paper, electronic, or other form that
is maintained by or on behalf of Bank of America for a business purpose.

1.13 Customizations - modifications to the Licensed Programs and new coding made at the request or
Bank of America.

1.14 Customization Schedule - a document substantially In the form of SCHEDULE B attached hereto.

1.15 Customization Status Report - a written report prepared by Supplier that describes the status
of the development and implementation, describes problems and the steps underway to resolve them,
provides a report of hours expended to date for each Customization, and reports all other
information necessary or desirable for Bank of America management to understand the status of the
project to develop Customizations. Proprietary to Bank of America Page 1 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 4 -->
1.16 Delivery Date - the date on which Bank of America actually receives the Software from Supplier.

1.17 Documentation - any and all: (i) materials created by or on behalf of Supplier that describe or
relate to the functional, operational or performance capabilities of the Software, regardless of
format; (ii) user, operator, system administration, technical, support and other manuals, including
but not limited to functional specifications, help files, flow charts, logic diagrams, programming
comments, acceptance plan, if any, and portions of licensor's web site that in any way describe the
Software; (iii) responses and other materials submitted by Supplier in response to any Bank of
America Request for Information ("RFI"), Request for Proposal ("RFP") or Request for Quotation
("RFQ"); and (iv) updates, changes and corrections to any of the forgoing that may be made during
the Term of this Agreement.

1.18 Effective Date - the date set forth on the signature page on which this Agreement takes effect.

1.19 Error - an instance of failure of Software to be Operative. An Error is a Class 1 Error if it
renders the Software unusable for its intended purpose. An Error is a Class 2 Error if the Software
is still usable for its intended purpose, but such use is seriously inconvenient and the value to
Bank of America of the use of the Software is substantially reduced. All other Errors are Class 3
Errors.

1.20 Information Security Program - the documents that describe how Supplier will provide services
to Bank of America in a manner that complies with the confidentiality and information security
requirements of this Agreement and all pertinent Schedules and Exhibits hereto. Such information
security program must be approved by Supplier's board of directors or equivalent executive
management prior to the Effective Date thereof and annually thereafter. It must describe Supplier's
network infrastructure and security procedures and controls that protect Confidential Information on
a basis that meets or exceeds the Bank Security Requirements.

1.21 Installation Date - the date the Software has been properly installed.

1.22 Installation Site - the building or complex of buildings at which Bank of America installs the
Software.

1.23 Intellectual Property Rights - all intellectual property rights throughout the world, including
copyrights, patents, mask works, trademarks, service marks, trade secrets, inventions (whether or
not patentable), know how, authors' rights, rights of attribution, and other proprietary rights and
all applications and rights to apply for registration or protection of such rights.

1.24 Licensed Programs - the computer programs and all Documentation for such computer programs
described in each Product License Schedule (including Source Code for such computer programs unless
expressly stated otherwise in such Product License Schedule).

1.25 Maintenance Fees - the fees for Maintenance Services set forth in each Product License
Schedule.

1.26 Maintenance Period - unless otherwise specified in a Product License Schedule, the Maintenance
Period shall be twenty-four (24) hours per day, seven (7) per week, including Bank of America
holidays.

1.27 Maintenance Services - the services described in SCHEDULE D or in any Product License Schedule
or Order with respect to any Licensed Program including telephone consultation, online and on-site
technical support, Error correction and the provision of Updates. Proprietary to Bank of America
Page 2 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 5 -->
1.28 Object Code - machine-readable computer instructions that can be executed by a computer.

1.29 Operative - conforming in all material respects to performance levels and functional
specifications described in the Program Materials and in this Agreement.

1.30 Order - Product License Schedule, purchase order, work order, Customization Schedule or other
written instrument executed, or electronic transmissions originated by, an authorized officer of
Bank of America Supply Chain Management directing Supplier in the provision of services
substantially conforming to a form provided to Supplier by Bank of America. Unless otherwise
provided in writing, the business terms in each Order relating to description of the Licensed
Program, pricing, and performance standards shall apply only to such Order.

1.31 Party - Bank of America or Supplier.

1.32 Platform - the computer equipment and operating system which can execute the Object Code.

1.33 Product or Products equipment, Software, firmware, system designs, Program Materials,
Customizations, Maintenance Services, Documentation, training and any other goods or services this
Agreement calls for Supplier to furnish or Supplier furnishes. Unless expressly otherwise provided,
Product or Products shall also mean any separate portion or part of the Product or Products that
Supplier furnishes.

1.34 Product License Schedule - a document substantially in the form of SCHEDULE A attached hereto.

1.35 Production Installation Date - the fifth consecutive Business Day upon which the Software has
been used successfully to process Bank of America's work commercially in production.

1.36 Program Materials - Supplier's proposals to Bank of America, Documentation, specifications and
any other Documentation delivered in connection with the Software, including without limitation
materials described in each Product License Schedule.

1.37 Records - documentation of facts that include normal and customary documentation of facts or
events for an industry, specific deliverables as designated, emails determined to be "records"
because of the business or litigation purpose, any records documenting legal, regulatory, fiscal or
administrative requirements.

1.38 Relationship Manager(s) -the employee designated by a Party to act on its behalf with regard to
matters arising under this Agreement who shall be the person the other Party shall contact in
writing regarding matters concerning this Agreement.

1.39 Repair Period - the time period commencing when Bank of America reports an Error to Supplier
and continuing for four (4) hours or such other period as may be specified In a Product License
Schedule.

1.40 Representative an employee, officer, director, or agent of a Party.

1.41 Software - the Licensed Programs and Object Code licensed by Supplier pursuant to a Product
License Schedule that produces the results described in the Program Materials, together with the
Documentation, all Corrections, Customizations and Updates and any Upgrades acquired by Bank of
America pursuant to this Agreement, and, if licensed to Bank of America in this Agreement, the
Source Code or other software programs offered by Supplier to the public on Supplier's Web site and
used by Bank of America, notwithstanding any associated EULA, GPL or other license terms, any
Updates thereto, and any related user manuals or Documentation. Proprietary to Bank of America Page
3 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 6 -->
1.42 Source Code - the human-readable code from which a computer can compile or assemble the Object
Code of a computer program, together with a description of the procedure for generating the Object
Code.

1.43 Subcontractor - a third party to whom Supplier has delegated or subcontracted any portion of
its obligations set forth herein.

1.44 Supplier Customizations - Customizations listed on a Customization Schedule, which Supplier
shall own and license to Bank of America under the terms of this Agreement.

1.45 Supplier Security Controls those controls implemented by Supplier as part of its Information
Security Program that address each of the Bank Security Requirements, as modified from time to time.

1.46 Term - the initial term of the Agreement or any renewal or extension.

1.47 Time and Materials Rates - the rates specified in each Product License Schedule [or Order] that
Supplier may charge for services provided under this Agreement which are not covered by the
Maintenance Fee, or if not so specified, supplier's standard rates for such services.

1.48 Update - a set of procedures or new program code that Supplier implements to correct Errors and
which may include modifications to improve performance or a revised version or release of the
Software which may incidentally improve its functionality, together with related Documentation.

1.49 Upgrade - a new version or release of computer programs licensed hereunder which Supplier makes
generally available to its customers to improve the functionality of, or add functional capabilities
to such computer programs, together with related Documentation. Upgrades shall include new programs
which replace, or contain functionality similar to, the Software already licensed to Bank of America
hereunder.

1.50 Warranty Period - the time period specified in each Product License Schedule commencing on the
Acceptance Date of the applicable Software component as extended pursuant to the Section entitled
"Acceptance."

1.51 Work in Progress - all plans, systems designs, Documentation, working materials,
specifications, flow charts source code, documented test results and other Work Product prepared by
Supplier pursuant to this Agreement or during development of the Customizations.

1.52 Work Product all information, data. materials, discoveries, inventions, drawings, works of
authorship, documents, documentation, models, software, computer programs, software (including
source code and object code), firmware, designs, specifications, processes, procedures, techniques,
algorithms, diagrams, methods, and all tangible embodiments of each of the foregoing (in whatever
form and media) conceived, created, reduced to practice or prepared by or for Supplier at the
request of Bank of America within the scope of services provided under this Agreement, whether or
not prepared on Bank of America's premises and all Intellectual Property Rights therein.

2.0 LICENSE

2.1 Supplier hereby grants Bank of America a nonexclusive, worldwide, irrevocable, perpetual license
to install, use, execute and copy the Software described in each Product License Schedule as
necessary to conduct Bank of America business in accordance with the terms and restrictions of this
Section and any special terms and restrictions stated on the applicable Product License Schedule.
Proprietary to Bank of America Page 4 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 7 -->
2.2 In addition, Bank of America may, at no additional charge other than the Software license fees
specified in each Product License Schedule, (i) install, use, execute and copy the Software for any
backup, archival and emergency purposes and any internal, non-production Bank of America purpose
including for test, development, and training; (ii) allow a third party outsourcer or service
provider to install, use, execute and copy the Software solely in connection with its provision of
services to Bank of America, provided that such use does not extend to providing services to others;
and (iii) transfer the Software to any other Platform or Installation Site replacing that on which
it was previously installed.

2.3 Bank of America may transfer the Software to other server operating systems or database
platforms, whether or not in existence as of the effective date of this Agreement, but on which the
Software is subsequently certified to operate, and Supplier shall provide Bank of America with any
generally available versions of the Software, including required passwords or keys, that are
reasonably necessary to accomplish such transfer, all at no additional charge.

2.4 Bank of America may for a reasonable period of time after the sale of a Affiliate of Bank of
America or a division of Bank of America, provide to such divested entity, processing services
and/or similar activities which are or become incidental to Bank of America's business, at no
additional charge or fee. All restrictions set forth in this Agreement on Bank of America's use of
the Software shall be deemed also to apply to any divested entity's use of the Software.

2.5 The license is subject to the following restrictions: (a) Title to and ownership of the Software
(except the Bank of America Customizations) shall remain with Supplier or its licensors; (b) Bank of
America shall not reverse engineer, reverse compile or disassemble any part of the Software without
the prior written consent of Supplier: and (c) Bank of America shall not remove, obscure or deface
any proprietary legend relating to the Software and shall include in each copy all proprietary
notices contained in the Software.

2.6 The licenses set forth above shall include the right to install, use, execute and copy the
Source Code for test and development purposes. to modify it, to compile it into Object Code and to
prepare from it derivative works for internal use only. Bank of America must keep the Source Code at
the Source Code Installation Site named in SCHEDULE A. Bank of America may transfer Source Code to
an alternate source code installation site if Supplier is notified promptly after such relocation.
Other copies may be made for backup and archival purposes and may be transferred to Bank of
America's off-site backup storage and contingency operations sites only. Any additional charge for
the Source Code Is specified in SCHEDULE A.

2.7 If Bank of America is not in default of its obligations under this Agreement or the General
Services Agreement of even date between Supplier and Bank of America, then at Bank of America's
request, Supplier shall deliver the then existing compiled and Source Code Software for the
Cardlytics Software and any Improvements of thereto subject to the payment schedule to Supplier as
outlined in Schedule A, Section B. Upon delivery, Bank of America will have all license right
outlined in Section 2.7.1:

2.7.1 Supplier hereby grants Bank of America a nonexclusive, worldwide, irrevocable, perpetual
license to: (a) any patents related to or necessary or desirable to use the Software to the extent
such patents are now held, licensed to or hereafter acquired by Supplier, for the purpose of
allowing Bank of America and its Affiliates and permitted assigns to install, copy, use, execute,
modify, distribute (as necessary or useful for Bank of America and its Affiliates and permitted
assigns to enjoy their rights as set forth in the Agreement), make, have made, enhance, improve and
alter the Software (both in Object Code and Source Code form) as necessary to conduct Bank of
America business in accordance with the terms and restrictions or this Section; (b) any Copyrights
now held, licensed to or hereafter acquired by Supplier in the Software for the purpose of allowing
Bank of America and its Affiliates an permitted assigns to install, copy, use, execute, modify,
distribute (as necessary or useful for Bank of America and its Affiliates and permitted assigns to
enjoy their fights as set forth In the Agreement, produce derivative works from and Proprietary to
Bank of America Page 5 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 8 -->
display such Software (both in Object Code and Source Code for ); any (c) other Intellectual
Property Rights or Supplier in the Software as are necessary or useful for Bank of America, its
Affiliates and permitted assigns to install, copy, use, execute, modify, distribute, enhance,
improve and alter and copy the Software (both in Object Code and Source Code form) for the purpose
of conducting Bank of America business in accordance with the terms and restrictions of this
Section. Without limiting the foregoing, but subject to the restrictions set forth in Section 2.5
hereof, Bank of America may: (x) sublicense its rights granted herein to its third party contractors
for the purpose of their performing services for Bank of America and its Affiliates (which services
may include, without limitation, altering, modifying, enhancing and improving the Software and
creating derivatives to the Software), provided that such third party contractors have entered into
a written agreement containing commercially standard confidentiality provisions requiring them to
maintain the Source Code to the Licensed Programs securely and in confidence (subject to
commercially standard exceptions), prior to having access to the Source Code for the Software: (y)
sublicense its rights in the Software excluding any rights in the Source Code, to its end user
customers as necessary for Bank of America to provide services to such end user customers; and (z)
host the Software on its systems (or allow a third party to host the Software on its behalf) and
make the Software available for use by its end user customers through the internet or other similar
means. Any derivative works of or alterations, enhancements, modifications, or improvements to the
Software created by Bank of America, its Representatives and Affiliates or their third party
contractors shall be owned, and be freely assignable, by Bank of America, and Supplier shall have no
rights therein (subject to Supplier's ownership of the underlying software). Without limiting the
foregoing, Bank of America may freely transfer such Software to any other Platform or Installation
Site replacing that on which it was previously installed.

2.8 Supplier expressly acknowledges and agrees that the rights of Bank of America set forth in this
Agreement shall inure to all Bank of America Affiliates, provided that Bank of America shall be
responsible for the obligations of its Affiliates under this Agreement. Such Affiliates may execute
Orders and purchase Licensed Programs hereunder.

2.9 No Shrink Wrap Licenses. Supplier and Bank of America agree that no so-called "shrink wrap" or
"click wrap" license terms shall apply to any Licensed Programs licensed to Bank of America
hereunder. In the event that licenses or versions of the Licensed Programs that are packaged with
any such "shrink wrap" or "click wrap" license are delivered to Bank of America hereunder. the terms
and conditions of this Agreement and the applicable Order shall apply and not the terms of the
"shrink wrap" or "click wrap" license.

3.0 RELATIONSHIP MANAGER

3.1 Each Party shall designate an employee Relationship Manager(s) to act on its behalf with regard
to matters arising under this Agreement and shall notify the other Party in writing of the name of
its Relationship Manager; however, the Relationship Manager shall have no authority to alter or
amend any term, condition, or provision of this Agreement. Either Party may change its Relationship
Manager(s) by providing the other Party prior written notice. The Relationship Manager must be
identified in a writing delivered to the other Party at least one (1) week prior to the commencement
of any work under this Agreement.

3.2 The Relationship Manager(s) shall meet via conference call with such frequency as Bank of
America's Relationship Manager shall reasonably request. Bank of America may require meetings in
person at a site designated by Bank of America.

3.3 Supplier shall provide the Bank of America Relationship Manager a Customization Status Report by
the first and fifteenth day of each month until all Customizations are accepted. Proprietary to Bank
of America Page 6 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 9 -->
4.0 TERM

4.1 This Agreement shall apply and remain in effect from the Effective Date and perpetually
thereafter unless terminated pursuant to the Section entitled "Termination."

5.0 TERMINATION

5.1 Bank of America may terminate this Agreement, an Order and/or any Customization Schedule(s) for
its convenience, without cause, at any time without further charge or expense upon at least
forty-five (45) calendar days prior written notice to Supplier. Termination of one Order shall not
cause a termination of this Agreement or any other Order, unless otherwise specified by Bank of
America.

5.2 In addition to any other remedies available to either Party, upon the occurrence of a
Termination Event (as defined below) with respect to either Party, the other Party may immediately
terminate this Agreement, the applicable Order or any Customization Schedule that is subject of the
Termination Event by providing written notice of termination. A Termination Event shall have
occurred if: (a) a Party materially breaches its obligations under this Agreement, an Order or any
Customization Schedule under this Agreement and the breach is not cured within thirty (30) calendar
days after written notice of the breach and intent to terminate is provided by the other Party; (b)
a Party becomes insolvent (generally unable to pay its debts as they became due) or the subject of a
bankruptcy, conservatorship, receivership or similar proceeding, or makes a general assignment for
the benefit of its creditors; (c) Supplier either: (i) merges with another entity, (ii) suffers a
transfer involving fifty (50%) percent or more of any class of its voting securities or (iii)
transfers all, or substantially all, of its assets; (d) in providing services hereunder, Supplier
violates any law or regulation governing the financial services Industry, or causes Bank of America
to be in material violation of any law or regulation governing the financial services industry; (e)
Bank of America has the right to terminate under the Section entitled "Pricing/Fees"; or (f) a Party
attempts to assign this Agreement in breach of the Section entitled "Non-Assignment." In the event
of a Termination Event described in item (a) above with respect to an Order, only the applicable
Order shall be subject to termination. Breach of one Order shall not constitute a default of any
other Order, unless otherwise agreed in writing between the Parties.

5.3 In addition to the Termination Events above, if the Services Schedule A of the General Services
Agreement of even date between the parties to this Agreement expires, does not renew or terminates
for any reason within the initial term and the Parties have not reached agreement on the delivery of
the Software herein, then Cardlytics may terminate this Software License, Customization and
Maintenance Agreement, including without limitation the Term License, shall terminate at the same
time.

5.4 The Parties agree that all Software delivered pursuant to this Agreement and the documentation
therefore constitute "intellectual property" under Section 101(35A) of the Code (11 U.S.C. section
101(35A)). Supplier agrees that if it, as a debtor-in-possession, or if a trustee in bankruptcy for
Supplier, in a case under the Code, rejects this Agreement, Bank of America may elect to retain its
rights under this Agreement as provided in Section 365(n) of the Code. Bank of America, and any
Intellectual Property Rights, licenses or assignments from Supplier of which Bank of America may
have the benefit, shall receive the full protection granted to Bank of America by applicable
bankruptcy law.

5.5 The licenses granted in this Agreement with respect to any Licensed Program shall not terminate
for any reason unless Supplier terminates the applicable Product License Schedule pursuant to
Section 5.2 after Bank of America fails to pay in full the undisputed portion of license fees
payable with respect to such Licensed Program under such Product License Schedule.

5.6 In addition to the rights of Bank of America set forth in this Section, (a) If Bank of America
terminates any Product License Schedule for material default by Supplier prior to the Acceptance
Date of the Software, Bank of America shall be entitled to a full refund, within thirty (30)
calendar days after notice of termination, of all license fees, Maintenance Fees and other fees paid
Proprietary to Bank of America Page 7 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 10 -->
hereunder; and (b) Bank of America may terminate Maintenance Services under any Product License
Schedule or Order for convenience at any time, and Bank of America shall then have no obligation to
pay any additional Maintenance Fees, other than for Maintenance Services performed through the date
of termination. Bank of America may terminate the Maintenance Services under any Product License
Schedule or Order for material default by Supplier, upon Bank of America's termination of such
Maintenance Services for default, Bank of America shall be entitled to a pro rata refund of all
prepaid Maintenance Fees for the period after the date of termination.

5.7 Supplier shall deliver all Work in Progress relating to Bank of America Customizations to Bank
of America within five (5) calendar days after the effective date of termination under Sections 5.1,
5.2, and 5.3 above. All right, title and interest in such Work in Progress relating to Bank of
America Customizations (including copyright) shall be deemed assigned to and vested in Bank of
America.

5.8 In the event of expiration or termination of this Agreement, an Order or of Maintenance Services
under this Agreement, Supplier agrees that upon the request of Bank of America, Supplier will, at no
additional cost to Bank of America and through the period of paid up Maintenance Services, continue
uninterrupted operations, conclude and cooperate with Bank of America in the transition of the
business at Bank of America's direction and in a manner that causes no material disruption to Bank
of America business and operations. The fees associated with such transition shall be in accordance
with the fees in effect at the expiration or termination of this Agreement. In no event shall the
transition exceed one hundred eighty [180] calendar days from the date of termination unless the
Parties otherwise agree in writing. For the avoidance of doubt, Bank of America agrees to pay
Supplier all undisputed fees for Maintenance Services rendered up to the date of termination or
expiration pursuant to the related terms hereunder. Reimbursement of all extraordinary costs and
expenses incurred outside of the Agreement terms and conditions will be agreed upon by Supplier and
Bank of America in writing prior to their incurrence.

5.9 The rights and obligations of the Parties which by their nature must survive termination or
expiration of this Agreement in order to achieve its fundamental purposes including, without
limitation, the provisions of the following Sections, "AUDIT, "CONFIDENTIALITY AND INFORMATION
PROTECTION," "INDEMNITY," "LICENSE,'' "LIMITATION OF LIABILITY. "MEDIATION/ARBITRATION," "OWNERSHIP
OF WORK PRODUCT" and "MISCELLANEOUS" shall survive in perpetuity any termination of this Agreement.

6.0 ORDERING, DELIVERY AND INSTALLATION

6.1 To order Product(s), Bank of America or any of its Affiliates shall Issue Supplier an Order or
other written authorization delivered in hard copy, via facsimile or other form of electronic
communication referring to this Agreement. Bank of America shall not be obligated to pay for Product
in the absence of such an Order. Supplier shall not deliver software not licensed to Bank of
America.

6.2 Supplier shall, at Bank of America's election, either (i) electronically deliver the Software
and Documentation to Bank of America premises from a remote location via electronic transmission,
such as over telecommunications networks (e.g., file transfer protocol), by granting Bank of America
downloading access through a secured web site, without Bank of America receiving or retaining
possession of the Software and Documentation in the form of tangible personal property, such as
tapes, disks or printed materials ("Electronic Delivery"), or (ii) deliver to and install the
Software and Documentation at a Bank of America facility and depart the facility with all storage
devices and resources used to deliver and install the Software and Documentation ("Load and Leave").
If the Software and Documentation are received through Electronic Delivery or through a Load and
Leave exchange, no tangible personal property will transfer to or come into the possession of Bank
of America from Supplier in fulfillment of Bank of America's entitlements to the Software and
Documentation. Shipment and delivery of the Software shall be deemed Proprietary to Bank of America
Page 8 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 11 -->
complete upon Supplier transmitting the Software to Bank of America or Supplier making it accessible
by Bank of America for downloading, whichever Is applicable. Any other delivery method shall be by
exception only and shall be clearly documented in the applicable Product License Schedule. If there
is not a preference to delivery in such Product License Schedule, then ii is assumed that all
Software and all Updates are by Electronic Delivery or by Load and Leave delivery to Bank of
America.

6.3 Supplier shall be responsible for and shall bear any and all risk of loss or disclosure of, or
damage to, Software until delivery to the Installation Site.

6.4 After delivery of Software, Bank of America shall attempt diligently to install it on the
Platform using adequate numbers of technically skilled personnel, and shall notify Supplier promptly
after the Software has been properly installed. Alternatively, Bank of America may request Supplier
in writing to install the Software at the Time and Material Rates, unless otherwise expressly agreed
in an Order.

6.5 Supplier shall provide at, no additional charge, installation Documentation and reasonable
telephonic off site consultation and assistance as necessary for Bank of America to install the
Software, together with the installation support, if any, described in an Order.

7.0 CUSTOMIZATIONS

7.1 Supplier shall provide Bank of America, within twenty-one (21) calendar days after receipt of
the Bank of America's request setting forth the relevant requirements, with a written estimate of
the cost of the Customizations. Bank of America may direct Supplier to provide such written estimate
on a time and materials basis or a fixed price basis, and Supplier shall comply with such direction.
Supplier's response shall set forth the Delivery Target Date for such Customizations.

7.2 Bank of America may submit to Supplier an Order or other written authorization for
Customizations, stating Bank of America's preferred Delivery Target Date for Customizations and the
terms for the Customizations, as proposed by Supplier pursuant to the preceding paragraph. Unless
Supplier notifies Bank of America of its rejection of Bank of America's written order within five
(5) Business Days after its receipt, it shall be deemed accepted. Bank of America shall not be
obligated to pay for Customizations or time and materials supplied in the absence of an Order or
written authorization. The parties shall execute a Customization Schedule for each Customization.

7.3 Bank of America and Supplier shall agree in writing on the functional, technical and performance
specifications of any Customizations. The specifications for each customization shall be described
in a Customization Schedule. Such specifications shall be subject to the Section entitled
"Acceptance" and Supplier shall make such reasonable changes to the specifications or such
preliminary documents as Bank of America may request. In accordance with Section 7.4, if applicable,
at Bank of America's written request, accompanied by an Order or other written authorization.
Supplier shall prepare functional. technical and performance specifications for Customizations prior
to undertaking Customizations. Supplier shall deliver to Bank of America the Source Code and Object
Code for Bank of America Customizations.

7.4 Change Orders;

A. If Bank of America requests a material change in the Customization specifications prior to
acceptance of the Customizations, Supplier shall prepare revised specifications within fifteen (15)
calendar days reflecting the price effect of Bank of America's request. Bank of America shall accept
or reject Supplier's proposal within fifteen (15) calendar days after receipt thereof. The Parties
shall make any appropriate amendment to the Customization Schedule. Proprietary to Bank of America
Page 9 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 12 -->
B. Unless otherwise directed by Bank of America, Supplier shall continue to develop the
Customizations using the Customization specifications in effect at the time Bank of America requests
the change. Supplier may amend Customization specifications at no charge at its option, provided
that Supplier shall obtain Bank of America's written consent to such amendment. At Supplier's
option, Supplier may use the Change Order form to obtain Bank of America's consent.

7.5 Supplier shall provide Bank of America sufficient access to the development site and Supplier
personnel so that Bank of America may have a reasonable opportunity to evaluate the status of any
Customizations. Suppler shall notify Bank of America of, and Bank of America may at its request
participate in, alpha, beta and quality assurance tests for the Customizations.

7.6 Commencing upon the Customization Delivery Date, Bank of America shall perform acceptance tests
on the Customizations, following the procedure set forth in the Section entitled "Acceptance." If
Bank of America rejects Customizations in accordance with the procedure set forth in the Section
entitled "Acceptance," Bank of America has no further obligation to pay Supplier for them and shall
receive a full refund of all amounts previously paid for that Customization.

7.7 Marketing Restrictions. Unless specified in the applicable customization Schedule or otherwise
agreed, all Customizations shall be deemed Bank of America Customizations. Bank of America shall own
all right, title, and interest in and to the Bank of America Customizations as Work Product in
accordance with Section 39.0. Supplier shall not provide a Bank of America Customization to any
third party. In the event that any Bank of America Customization is furnished or plan, design or
specification for producing the same has been specifically designed, developed or modified for or by
Bank of America, then no such Bank of America Customization, plan, design or specification shall be
duplicated or furnished to others by Supplier without the prior written consent of Bank of America.

8.0 SOURCE CODE CUSTODY

8.1 The provisions of this Section shall apply only to the Source Code for the Licensed Programs.
The Source Code for the Bank of America Customizations may be use by Bank of America without any of
the restrictions set forth in this Section.

8.2 With each delivery of Software to Bank of America hereunder, Supplier shall deliver to Bank of
America the Source Code for all Software and for all Updates, Upgrades and new releases of the
Software. Until a Release Condition (as defined in Section 8.6) occurs and the conditions of Section
8.7 have been satisfied, Bank of America shall not permit access to or use of the Source Code,
except as expressly provided herein.

8.3 Bank of America shall establish a secure receptacle in which it shall place the Source Code and
shall put the receptacle under supervision of one or more of its officers, whose identity shall be
available to Supplier at all times. Bank of America shall exercise the degree of care in carrying
out its obligations hereunder that Bank of America then exercises with respect to Bank of America
proprietary data of a similar nature, but not less than reasonable care. Bank of America
acknowledges that the Source Code is proprietary data, and Bank of America shall have an obligation
to preserve and protect the confidentiality of the Source Code.

8.4 Supplier grants Bank of America the right to duplicate the Source Code only as necessary to
preserve and safely store the Source Code and as expressly permitted in this Section. Bank of
America shall reproduce in all copies of the Source Code made by Bank of America any proprietary or
confidentiality notices contained in the Source Code when originally delivered by Supplier.
Proprietary to Bank of America Page 10 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 13 -->
8.5 Upon delivery of the Source Code to Bank of America by Supplier, including in connection with
any Upgrade, Update or new release, Bank of America shall have the right to verify the Source Code
for accuracy, completeness and sufficiency, and to confirm that it compiles to the pertinent object
code of the Software. Bank of America shall notify Supplier of the dates on which any such
verification will be conducted, and the results thereof. Bank of America may temporarily release the
Source Code for this purpose only, but all copies of the Source Code shall be returned to the
designated storage location as soon as the verification is completed. Supplier may elect to observe
the verification process at its own expense.

8.6 Any or the following events shall be Release Conditions for purposes of this Section: (a)
Supplier defaults on any of its maintenance obligations herein; (b) Supplier ceases to provide
maintenance for the Software; (c) Supplier ceases doing business in the ordinary course, files or
has filed against it a petition under bankruptcy Code, becomes insolvent or has a receiver appointed
for all or a substantial part of its business; or (d) Bank of America terminates this Agreement for
cause pursuant to the terms hereof.

8.7 If a Release Condition has occurred, Bank of America may immediately release the Source Code for
the purposes described in Section 8.8, following the issuance of a written statement to Supplier by
Bank of America's executive management, stating that a Release Condition has occurred.

8.8 Supplier hereby grants to Bank of America a nonexclusive, fully paid, irrevocable, royalty-free,
world-wide license to use, modify, copy, produce derivative works from, display, disclose to persons
who have entered into a written agreement containing substantially the same confidentiality
provisions as in this Agreement for the purpose of maintaining the Software for Bank of America, and
otherwise to utilize the Software and the Source Code and other materials necessary to maintain and
improve the Software for use by Bank of America, subject always to the limitations In this Agreement
on reproduction and use of the Software.

9.0 DOCUMENTATION

9.1 At no additional charge and in accordance with the delivery method specified in each Product
License Schedule, Supplier shall deliver a complete set of Documentation for the Software at the
same time as the Software is delivered and for every Customization and Upgrade delivered to Bank of
America. The Documentation shall describe fully the proper procedure for using the Software and
provide sufficient information to enable Bank of America to operate all features and functionality
of the Software on the Platform. Supplier shall deliver reasonable Documentation to allow Bank of
America to install and use each Update. Except as otherwise provided in Section 39.0, "Ownership of
Work Product", Bank of America may use and reproduce for internal purposes all Documentation
furnished by Supplier, including displaying the Documentation on Bank of America's intranet or other
internal electronic distribution system, in part or in whole. Documentation for Customizations,
Updates and Upgrades shall meet or exceed the level of quality, form and completeness of the
Documentation for the Licensed Programs.

9.2 Supplier shall, in accordance with the delivery method specified in each Product License
Schedule, deliver updated Documentation to Bank of America concurrently with delivery of any
Upgrades or Customizations or any other occasion of issuance of updated Documentation.

10.0 ACCEPTANCE

10.1 During the Acceptance Period, Bank of America shall perform whatever acceptance tests on the
Software it may wish to confirm that the Software is Operative. If Bank of America discovers during
the Acceptance Period that any Software is not Operative, Bank of America shall notify Supplier of
the deficiencies. Supplier, at its own expense, shall modify, repair, adjust or replace the Software
to make it Operative within fifteen (15) calendar days after the date of Bank of America's
deficiency notice. Bank of America may perform additional acceptance tests during a Proprietary to
Bank of America Page 11 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 14 -->
period commencing when Supplier has delivered revised Software correcting all the deficiencies Bank
of America has noted. This restarted Acceptance Period shall have a duration equal to that of the
initial Acceptance Period, unless Bank of America earlier accepts the Software in writing. If the
Software, at the end of the Acceptance Period as so extended, still is not Operative in Bank of
America's judgment after consultation with Supplier, Bank of America may reject the Software and
terminate this Agreement for material breach or, at its option, repeat the procedure of this
paragraph as often as it determines is necessary. If Bank of America does not notify Supplier of
acceptance or rejection of the Software, it shall be deemed accepted at the end of the Acceptance
Period extended pursuant to this paragraph. If not previously accepted, the Software shall also be
deemed accepted upon the Production Installation Date.

10.2 Bank of America shall use the procedure in this Section to determine acceptance of
Customizations and Upgrades. If Bank of America finds an Upgrade not to be Operative and rejects it,
Bank of America shall have no obligation to pay for such Upgrade if Supplier provided the Upgrade to
Bank of America for an additional charge above Maintenance Services, and Supplier shall continue to
support the version or release of the Software that Bank of America has installed.

11.0 MAINTENANCE SERVICES

11.1 Supplier shall provide the Maintenance Services attached hereto as SCHEDULE D.

12.0 UPGRADES

12.1 Supplier shall offer Upgrades to Bank of America whenever Supplier makes Upgrades generally
available to its other customers. Unless otherwise agreed to in a Product License Schedule, Supplier
shall deliver by Electronic Delivery or by Load and Leave delivery each Upgrade to Bank of America
at no additional charge as part of Maintenance Services.

12.2 Supplier shall notify Bank of America as far in advance as reasonably possible, but in no event
less than six (6) months prior to release, of all Upgrades and Software replacements/ phase-outs,
and shall provide Bank of America all relevant release notes and other Documentation as soon as
possible after notification.

12.3 Supplier shall continue to provide Maintenance Services on the terms and conditions of this
Agreement for the version of Software Bank of America has installed for at least twenty-four (24)
months after Supplier makes an Upgrade generally available to its customers.

13.0 NON-MAINTENANCE SERVICES SUPPORT

13.1 If Supplier agrees to perform non-Maintenance Services support services at Bank of America's
request in connection with the implementation of the Software, such services shall be performed in a
workmanlike and professional manner by qualified personnel at the Time and Materials Rates set forth
in SCHEDULE A.

14.0 TRAINING

14.1 Supplier shall provide, at the rates and fees specified in an Order, if any, the training
classes called for in an Order in use, operation and maintenance of the Software for Bank of America
personnel on Bank of America premises on dates to be specified by Bank of America. Supplier shall
provide training Documentation for each attendee at any classes Supplier conducts. Prices for
additional classes, if any, shall be specified in an Order. If Supplier agrees to allow Bank of
America to train Bank of America personnel, Supplier shall provide Bank of America, at the rates and
fees specified in an Order, if any, all trainer/class leadership materials Supplier has available or
used in connection with the classes conducted for Bank of America. Bank of America may duplicate
these materials for Bank of America's use exclusively and use them to conduct other classes at Bank
of America's convenience. Proprietary to Bank of America Page 12 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 15 -->
15.0 PRICING/FEES

15.1 Software license fees, Maintenance Fees and the method of payment shall be set forth in each
Order or the applicable Order. Fees for additional services not listed on an Order shall be as
mutually agreed in writing between Bank of America and Supplier prior to performance.

15.2 If the Order is for Customizations, fees and the method of payment are set forth in the
applicable Customization Schedule.

15.3 Fees for services, other than Maintenance Services listed in SCHEDULE A, B and D or an Order
are subject to the standard of measurement or evaluation applicable to the commercial production and
sale of similar Products and services provided by Supplier under this Agreement ("Industry
Benchmarking") at any time at Bank of America's option, and may be reduced based on the results.
Bank of America shall give notice to Supplier of any proposed fee reduction including the effective
date of such fee reduction. Supplier shall notify Bank of America of its acceptance or rejection of
the proposed fee reduction within fifteen (15) calendar days of Supplier's receipt of notice. If
Supplier does not give notice to Bank of America, such fee reduction shall be deemed accepted and
invoices shall be adjusted accordingly. If Supplier rejects a proposed fee reduction, Bank of
America may terminate the services engagement with no further liability.

16.0 INVOICES TAXES/PAYMENT

16.1 Supplier shall submit invoices, in accordance with the timeframes specified in SCHEDULE A, to
the address set forth in SCHEDULE A or the applicable Order. Bank of America requires Suppliers to
accept payment through electronic media in one of the following agreed upon methods; credit card
using the Bank of America ePayables process, ACH, or electronic check. In the event that the agreed
upon method of payment is through the Bank of America ePayables process using purchase cards, the
Supplier shall, at no additional cost to Bank of America, ensure Supplier has the capability to
process purchasing cards, prior to submitting invoices to Bank of America. Supplier shall
electronically invoice Bank of America using the Bank of America designated e-Procurement tool. Each
invoice shall specify the amount for each item on the invoice and include the following: (i) the
slate where Supplier will electronically deliver the Software and Documentation to Bank of America,
(ii) the method of electronic delivery, (iii) the state where services are to be performed, (iv) the
Agreement reference number as Indicated on the signature page of this Agreement), and (v) the Order
number if applicable.

16.2 The items listed on Supplier's invoice must appear in the same sequence as listed on the Order.

16.3 Invoices that omit the state of Electronic Delivery. the method of Electronic Delivery, the
state where services are to be performed, the Agreement reference number and Order number of
applicable, or that fail to list Products and services separately, or that are incorrect, incomplete
or list Products or services that were not requested in writing by Bank of America will not be paid.
The Relationship Manager for Bank of America will contact the Supplier Relationship Manager to
address the situation informally prior to initiating the dispute resolution process under this
Agreement.

16.4 Bank of America shall pay Supplier for all services and applicable taxes invoiced In arrears in
accordance with the terms of this Agreement, within sixty (60) calendar days of the date of receipt
of a valid and correct invoice by Bank of America. Bank of America reserves the right to pay prior
to the expiration of the sixty (60) day period. If Bank of America pays within thirty (30) calendar
days of receipt of a valid invoice by Bank of America, a discount of two percent (2%) will be
subtracted from the total invoice amount for Services. Proprietary to Bank of America Page 13
vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 16 -->
16.5 Unless otherwise agreed upon by Bank of America, (i) all charges for Maintenance Services shall
be invoiced in accordance. with the terms specified in the applicable Order, (ii) charges for
Software shall be invoiced on the Acceptance Date, and (iii) all other charges shall be invoiced
when incurred. Invoices shall contain such detail as Bank of America may reasonably require from
time to time. Amounts not invoiced by Supplier to Bank of America within three (3) months after such
amounts could first be invoiced under this Agreement may not thereafter be invoiced, and Bank of
America shall not be required to pay such amounts.

16.6 Invoices shall include and list all applicable sales, use, or excise taxes that are a statutory
obligation of Bank of America as separate line items identifying each separate tax category and
taxing authority. Bank of America will reimburse Supplier for all sales, use or excise taxes levied
on amounts payable by Bank of America to Supplier pursuant to this Agreement, however, Bank of
America shall not be responsible for remittance of such taxes to applicable tax authorities.

16.7 Bank of America shall not be responsible for any ad valorem, income, gross receipts, franchise,
privilege, value added or occupational taxes of Supplier. Bank of America and Supplier shall each
bear sole responsibility for all taxes, assessments and other real or personal property- related
levies on its owned or leased real or personal property.

16.8 Supplier shall be responsible for the payment of all taxes, interest and penalties related to
any assessment by a taxing authority as contemplated by Section 16.6 to the extent that Supplier
fails to accurately and timely invoice Bank of America for such taxes and remit such taxes directly
to the applicable taxing authority. In the event that a taxing authority performs a sample and
projection audit on Bank of America, then Supplier shall be responsible for the payment of all
projected tax amounts including all interest and penalties on any projected taxes assessed resulting
from taxing errors identified by such taxing authority on Supplier's Invoices, provided however,
that Supplier shall receive timely notice that such invoice is included In a tax authority's audit
and Supplier has the right to produce documentation to support that the tax was satisfied. In the
event Supplier voluntarily registers to collect sales tax at some future date, and wishes to remit
historical taxes Supplier deems due, Bank of America will only be responsible for the taxes due for
the time period that Bank of America is statutorily obligated to the tax authorities in each state.

16.9 Supplier shall fully cooperate with Bank of America's efforts to identify taxable and
nontaxable portions of amounts payable pursuant to this Agreement (including segregation of such
portions on invoices) and to obtain refunds of taxes paid, where appropriate. Bank of America may
furnish Supplier with certificates or other evidence supporting applicable exemptions from sales,
use or excise taxation. If Bank of America pays or reimburses Supplier under this Section, Supplier
hereby assigns and transfers to Bank of America all of its right, title and interest in and to any
refund for taxes paid. Any claim for refund of taxes against the assessing authority may be made in
the name of Bank of America or Supplier, or both, at Bank of America's option. Bank of America may
initiate and manage litigation brought in the name of Bank of America or Supplier, or both, to
obtain refunds of amounts paid under this Section. Supplier shalt cooperate fully with Bank of
America in pursuing any refund claims, including any related litigation or administrative
procedures.

16.10 Supplier shall keep and maintain complete and accurate accounting Records in accordance with
generally accepted accounting principles consistently applied to support and document all amounts
becoming payable to Supplier hereunder. Upon request from Bank of America, Supplier shall provide to
Bank of America (or a Representative designated by Bank of America) access to such Records for the
purpose of auditing such Records during normal business hours. Supplier shall retain all Records
required under this Section in accordance with the Section entitled "Audit" of this Agreement, after
the amounts documented In such Records become due. Supplier shall Proprietary to Bank of America
Page 14 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 17 -->
cooperate fully with Bank of America and any taxing authority involving any audit of sales, use or
excise taxes. Upon request from Bank of America, Supplier will provide copies of invoices in
electronic form that have been selected for review by any taxing authority, together with documents
supporting the identification of taxable and nontaxable portions of amounts reflected on such
invoices as contemplated by Section 16.9..

17.0 EXPORT LAWS

17.1 Export of Software. To the extent the Software contains any cryptographic functionality that
would subject it to the provisions of the United States Export Administration Regulations (the
"EAR"), Supplier hereby represents and warrants that: (a) the Export Control Classification Number
("ECCN") for such Software is set forth on the applicable Product License Schedule; and (b) Supplier
has obtained all necessary licenses, if any, and submitted all necessary prior notifications and
review requests (without receipt of any objection) to the Bureau of Industry and Security ("BIS'')
and the National Security Agency (the "NSA), which are required to be made under the EAR in order
for Bank of America to be able to use such Software as contemplated hereunder and in accordance with
(and subject to) the provisions of the Agreement and the applicable Product License Schedule,
outside of the United States, subject to the following: (i) Bank of America may not export such
Software to any countries (or the nationals thereof) in Country Group E:1 on Supplement No. 1 to
Part 740 of the EAR (as such provision may be hereafter amended); (ii) Bank of America may not
export such Software in violation of any prohibitions of EAR Parts 744 and 746 (as such provisions
may be amended from time to time); and (iii) Bank of America may have obligations to make periodic
reports to BIS and/or the NSA (unless such exports are made to Bank of America Affiliates which are
classified as "U.S. Subsidiaries" under Part 772 of the EAR), and to the extent such reports are
required, Supplier has provided, or will provide, a brief summary of such requirements, as given to
the best of its knowledge, on the applicable Product License Schedule. Supplier will hereafter
communicate to Bank of America any additional laws and regulations relevant to Bank of America's
export, reexport, sale or other disposition of Product pursuant to this Agreement

18.0 MUTUAL REPRESENTATIONS AND WARRANTIES

18.1 Each Party represents and warrants the following: (a) the Party's execution, delivery and
performance of this Agreement (i) have been authorized by all necessary corporate action, (ii) do
not violate the terms of any law, regulation, or court order to which such Party is subject or the
terms of any material agreement to which the Party or any of its assets may be subject and (iii) are
not subject to the consent or approval of any third party; (b) this Agreement is the valid and
binding obligation of the representing Party, enforceable against such Party in accordance with its
terms; and (c) such Party is not subject to any pending or threatened litigation or governmental
action which could interfere with such Party's performance of its obligations hereunder.

19.0 REPRESENTATIONS AND WARRANTIES OF SUPPLIER

19.1 In rendering its obligations under this Agreement, without limiting other applicable
performance warranties, Supplier represents and warrants to Bank of America as follows: (a) Supplier
is in good standing in the state of its incorporation and is qualified to do business as a foreign
corporation in each of the other states in which it is providing Products or services hereunder; (b)
Supplier shall secure or has secured all permits, licenses, regulatory approvals and registrations
required to deliver Products or render services set forth herein, including without limitation,
registration with the appropriate taxing authorities for remittance of taxes; and (c) Supplier
shall, and shall be responsible for ensuring that Supplier's Representatives and Subcontractors
shall, perform all obligations of Supplier under this Agreement in compliance with all laws, rules,
regulations and other legal requirements. Proprietary to Bank of America Page 15 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 18 -->
19.2 Supplier represents and warrants that it shall perform the Maintenance Services in a timely and
professional manner using competent personnel having expertise suitable to their assignments.
Supplier represents and warrants that the services shall conform to or exceed, in all material
respects, the specifications described herein, as well as the standards generally observed in the
industry for similar services. Supplier represents and warrants that neither performance nor
functionality of the services, Products or systems is or will be affected by dates prior to, during
and after the year 2000. Supplier represents and warrants that services supplied hereunder shall be
reasonably free of defects in workmanship, design and material. Supplier represents and warrants
that sale, licensing or use of any Product, Work Product and service furnished under this Agreement,
including but not limited to Software, system design, equipment or Documentation, do not and shall
not infringe, misappropriate or otherwise violate any Intellectual Property Rights or any other
rights of any third party.

19.3 As of the Effective Date, there are no actions, suits or proceedings pending, or to the
knowledge of Supplier threatened, against Supplier, Supplier's Representatives and Subcontractors
alleging infringement, misappropriation or other violation of any Intellectual Property Rights
related to any product, Work Product or Service contemplated by this Agreement.

19.4 Supplier warrants that it shall develop any Customizations in a professional workmanlike
manner, using qualified personnel familiar with the Software and its operation.

19.5 Supplier hereby represents and warrants that the Software shall be and shall remain Operative,
from the Delivery Date through the end of the Warranty Period. Following expiration of the Warranty
Period and for so long as Bank of America has contracted Supplier to provide Maintenance Services,
Supplier represents and warrants that the Software shall remain Operative. If the Software is not
Operative at the expiration of the initial Warranty Period, the Warranty Period shall be extended
until Supplier makes the Software Operative. This warranty shall not be affected by Bank of
America's modification of the Software so long as Supplier can discharge its warranty obligations
notwithstanding such modifications or following their removal by Bank of America.

19.6 Supplier warrants that during the term of this Agreement, Bank of America may use Product
without disturbance, subject only to Bank of America's obligations to make the payments required by
this Agreement. Supplier represents that this Agreement, the Products and the Intellectual Property
Rights in the Products are not subject or subordinate to any right of Supplier's creditors, or if
such subordination exists, the agreement or instrument creating it provides for non-disturbance of
Bank of America.

19.7 Supplier represents and warrants that it is familiar with all applicable domestic and foreign
antibribery or anticorruption laws, including those prohibiting Supplier, and, if applicable, its
officers, employees, agents and others working on its behalf, from taking corrupt actions in
furtherance of an offer, payment, promise to pay or authorization of the payment of anything of
value, including but not limited to cash, checks, wire transfers, tangible and Intangible gifts,
favors, services, and those entertainment and travel expenses that go beyond what is reasonable and
customary and of modest value, to: (i) an executive, official, employee or agent of a governmental
department, agency or instrumentality, (ii) a director, officer, employee or agent of a wholly or
partially government-owned or -controlled company or business, (iii) a political party or official
thereof, or candidate for political office, or (iv) an executive, official, employee or agent of a
public international organization (e.g., the International Monetary Fund or the World Bank)
("Government Official'); while knowing or having a reasonable belief that all or some portion will
be used for the purpose of: (a) influencing any act, decision or failure to act by a Government
Official In his or her official capacity, (b) inducing a Government Official to use his or her
influence with a government or instrumentality to affect any act or decision of such government or
entity, or (c) securing an Improper advantage; in order to obtain, retain, or direct business.

19.8 Supplier represents and warrants that it would now be in compliance with all applicable
domestic or foreign antibribery or anticorruption laws, including those prohibiting the bribery of
Government Officials, and will remain in compliance with all applicable laws; that it will not
authorize, offer or Proprietary to Bank of America Page 16 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 19 -->
make payments directly or indirectly to any Government Official; and that no part of the payments
received by it from Bank of America willbe used for any purpose that could constitute a violation of
any applicable laws.

19.9 THE WARRANTIES CONTAINED IN THIS AGREEMENT ARE IN LIEU OF ALL OTHER WARRANTIES, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THOSE OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

20.0 DELETION OF FUNCTIONS

20.1 In the event that Supplier deletes functions from the Software and transfers or offers those
functions in other or new products (whether directly or Indirectly or through an agreement with a
third party), the portion of those other or new products that contain the functions in question, or
the entire product, if the functions cannot be separated out, shall be provided to Bank of America
under the terms of this Agreement, at no additional charge and shall be covered under Maintenance
Services for such Software.

21.0 DISABLEMENT OF SOFTWARE AND HARDWARE

21.1 Except during and in conjunction with maintenance or any other authorized servicing or support,
in no event shall Supplier, its Representatives or Subcontractors or anyone acting on its behalf,
disable (or permit or cause any embedded mechanism to disable) the Software or hardware owned or
utilized by Bank of America without the prior written permission of an officer of Bank of America.
Disablement shall also apply to all instances of Software installed, used, and executed in support
of disaster recovery activities or the non-emergency tests of such activities.

22.0 FINANCIAL RESPONSIBILITY

22.1 Upon Bank of America's request, Supplier shall promptly furnish its financial statements as
prepared by or for Supplier in the ordinary course of its business. If Supplier is subject to laws
and regulations of the U.S. Securities & Exchange Commission (SEC), the financial reporting and
notification requirements contained herein shall be limited to all information that can be provided
and in accordance with timelines which are legally permitted. Financial information provided
hereunder shall be used by Bank of America solely for the purpose of determining Supplier's ability
to perform its obligations under this Agreement. To the extent any such financial information ls not
otherwise publicly available, it shall be deemed Confidential Information (as defined in Section
27.1) of Supplier. If Bank of America's review of financial statements causes Bank of America to
question Supplier's ability to perform its duties hereunder, Bank of America may request, and
Supplier shall provide to Bank of America, reasonable assurances of Supplier's ability to perform
its duties hereunder. Failure by Supplier to provide such reasonable assurances to Bank of America
shall be deemed a material breach of this Agreement. Furthermore, Supplier shall notify Bank of
America immediately In the event there is a change of control or material adverse change in
Supplier's business or financial condition.

23.0 BUSINESS CONTINUITY

23.1 Supplier agrees to establish, maintain and implement per the terms thereof, a Business
Continuity Plan. The Business Continuity Plan must be in place and delivered to Bank of America
within forty-five (45) calendar days after the Effective Date of this Agreement. The Business
Continuity Plan shall be delivered annually thereafter and shall include, but not be limited to, the
items called for in SCHEDULE G entitled "Recovery," as applicable. If Bank of America objects in
writing to any provision of such plans and controls, Supplier shall respond in writing within thirty
(30) calendar days, explaining, among other matters Supplier wishes to include in its response, the
actions Supplier intends to take to cure Bank of America's objection. Proprietary to Bank of America
Page 17 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018

24.0 RELATIONSHIP OF THE PARTIES
<!-- page 20 -->
24.1 The Parties are independent contractors. Nothing in this Agreement or in the activities
contemplated by the Parties hereunder shall be deemed to create an agency, partnership, employment
or joint venture relationship between the Parties or any of their Subcontractors or Representatives.

25.0 SUPPLIER PERSONNEL

25.1 Bank of America shall provide Supplier, if necessary and at a mutually agreed upon time,
reasonable access to Bank of America to provide its services, subject to the existing security
regulations at Bank of America.

25.2 Supplier's personnel are not eligible to participate in any of the employee benefit or similar
programs of Bank of America. Supplier shall inform all of its personnel providing services pursuant
to this Agreement that they will not be considered employees of Bank of America for any purpose, and
that Bank of America shall not be liable to any of them as an employer for any claims or causes of
action arising out of or relating to their assignment.

25.3 Upon the request of Bank of America, Supplier shall immediately remove any of Supplier's
Representatives or Subcontractors performing services under this Agreement and replace such
Representative or Subcontractor as soon as practicable. Upon the request of Bank of America,
Supplier shall promptly, and after consultation with Bank of America, address any concerns or issues
raised by Bank of America regarding any of Supplier's Representatives or Subcontractors performing
services under this Agreement which may include, as appropriate, replacing such Representative or
Subcontractor from the Bank of America account.

25.4 The engagement of a Subcontractor by Supplier shall be subject to Bank of America's prior
written consent, which shall not be unreasonably withheld, and shall not relieve Supplier of any of
its obligations under this Agreement. Supplier shall be responsible for the performance or
nonperformance of its Subcontractors as if such performance or nonperformance were that of Supplier.
Supplier shall require all Subcontractors, as a condition to their engagement, to agree to be bound
by provisions substantially the same as those included in this Agreement particularly the Sections
entitled "Supplier Personnel," "Insurance," "Confidentiality and Information Protection," "Audit"
and "Business Continuity."

25.5 Supplier shall comply and shall cause its Representatives and Subcontractors to comply with all
personnel, facility, safety and security policies, rules and regulations and other instructions of
Bank of America, when performing work at a Bank of America facility or accessing any Bank of America
systems or data, and shall conduct its work at Bank of America facilities or on Bank of America
systems in such a manner as to avoid endangering the safety, or interfering with the convenience of,
Bank of America Representatives or customers. Supplier understands that Bank of America operates
under various laws and regulations that are unique to the security-sensitive banking industry. As
such, persons engaged by Supplier to provide services under this Agreement are held to a higher
standard of conduct and scrutiny than in other industries or business enterprises. Supplier agrees
that its Representatives and Subcontractors providing services hereunder shall possess appropriate
character, disposition and honesty. Supplier shall, to the extent permitted by law, exercise
reasonable and prudent efforts to comply with the security provisions of this Agreement.

25.6 Supplier shall not knowingly permit a Representative or Subcontractor to have access to the
Confidential Information, premises, records or data of Bank of America when such Representative or
Subcontractor: (a) has been convicted of a crime or has agreed to or entered into a pretrial
diversion or similar program in connection with: (i) a dishonest act or a breach of trust, as set
forth in Section 19 of the Federal Deposit Insurance Act, 12 U.S.C. 1829(a); or (ii) a felony: or
(b) uses illegal drugs. Notwithstanding anything in this Agreement to the contrary, Proprietary to
Bank of America Page 18 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 21 -->
Supplier shall conduct at its expense background checks on its employees and those of its
Subcontractors who will have access (whether physical, remote, or otherwise and whether on or off
Bank of America premises) to Bank of America facilities, equipment, systems or data and such
background checks shall comply with Bank of America procedures and requirements as set forth in
SCHEDULE F to this Agreement and updated in writing delivered to Supplier from time to time.
Supplier shall report to Bank of America on background checks done, in accordance with the
requirements of SCHEDULE F and prior to such employee being granted such access.

25.7 Supplier represents that it maintains comprehensive hiring policies and procedures which
include, among other things, a background check for criminal convictions, and if requested by Bank
of America, drug testing, all to the extent permitted by law. Supplier further represents that
through its hiring policies and procedures including background checks, it endeavors to hire the
best candidates with appropriate character, disposition, and honesty. In the event that supplier
employs non-U.S. citizens to provide services hereunder, Supplier shall ensure that all such persons
have and maintain appropriate visas to enable them to provide the services.

25.8 Bank or America shall notify Supplier of any act of dishonesty or breach of trust committed
against Bank of America. which may involve a Supplier Representative, or Subcontractor of which Bank
of America becomes aware, and Supplier shall notify Bank of America if it becomes aware of any such
offense. Following such notice, at the request of Bank of America and to the extent permitted by
law, Supplier shall cooperate with investigations conducted by or on behalf of Bank of America.

26.0 INSURANCE

26.1 Supplier shall at its own expense secure and continuously maintain, and shall require its
Subcontractors to secure and continuously maintain, throughout the Term, the following insurance
with companies qualified to do business in the jurisdiction in which the services will be performed
and rating A-VII or better in the current Best's Insurance Reports published by A M. Best Company
and shall, upon Bank of America's request, be furnished to Bank of America certificates and required
endorsements evidencing such insurance. Bank of America shall be named as an ''Additional Insured"
to the coverages described in Sections 26.2.3, 26.2.4, and 26.2.5 below for the purpose of
protecting Bank of America from any expense and/or liability arising out of, alleged to arise out
of, related to or connected with the Products provided by Supplier and/or its Subcontractors. The
certificates shall state the amount of all deductibles and self-insured retentions and shall contain
evidence that the policy or policies shall not be canceled or materially altered without at least
thirty (30) calendar days prior written notice to Bank of America. Supplier and its Subcontractors
shalt pay any and all costs which are incurred by Bank of America as a result of any such
deductibles or self-insured retentions to the extent that Bank of America is named as an "Additional
Insured," and to the same extent as if the policies contained no deductibles or self-insured
retention. The insurance coverages and limits required to be maintained by Supplier and its
Subcontractors shall be primary and non-contributory to insurance coverage, if any, maintained by
Bank of America. Supplier and Proprietary to Bank of America its Subcontractors and their
underwriters shall waive subrogation against Bank of America and shall cause their insurer(s) to
waive subrogation against Bank of America.

26.2 Insurance Coverages

26.2.1 Worker's Compensation Insurance which shall fully comply with the statutory requirements of
all applicable state and federal laws.

26.2.2 Employers' Liability Insurance which limit shall be $1,000,000 per accident for Bodily injury
and $1,000,000 per employee/aggregate for disease. Proprietary to Bank of America Page 19 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 22 -->
26.2.3 Commercial General Liability Insurance with a minimum combined single limit of liability of
$1,000,000 per occurrence and $2,000,000 aggregate for bodily Injury, death, property damage and
personal injury, and specifically covering infringement of Intellectual Property Rights. This policy
shall include products/completed operations coverage and shall also include contractual liability
coverage.

26.2.4 Business Automobile Liability Insurance covering all owned, hired and non-owned vehicles and
equipment used by Supplier with a minimum combined single limit of liability of $1,000,000 for
injury and/or death and/or property damage.

26.2.5 Excess coverage with respect to Sections 26.2.2, 26.2.3 and 26.2.4 above with a per
occurrence limit of $5,000,000. The limits of liability required In subsections 26.2.2, 26.2.3 and
26.2.4 may be satisfied by a combination of those policies with an Umbrella/Excess Liability policy.

26.2.6 Technology Errors and Omissions Insurance with minimum limits of not less than $5,000,000,
covering liabilities arising from errors, omission, etc., in rendering computer or information
technology services including but not limited to (1) systems analysis (2) systems programming (3)
data processing (4) systems integration (5) outsourcing including outsourcing development and design
(6) systems design, consulting, development and modification (7) training services relating to
computer software or hardware (8) management, repair and maintenance of computer products, networks
and systems (9) marketing, selling, servicing, distributing, installing and maintaining computer
hardware or software (10) data entry, modification, verification, maintenance, storage, retrieval or
preparation of data output.

26.2.7 Supplier shall be responsible for loss to bank property and customer property, directly or
indirectly, and shall maintain Fidelity Bond or Crime coverage for the dishonest acts of its
employees in a minimum amount of $5,000,000. Supplier shall endorse such policy to include a "Client
Coverage" or "Joint Payee Coverage" endorsement Bank of America shall be named as "Loss Payee, As
Their Interest May Appear'' in such Fidelity Bond.

26.3 The failure of Bank of America to obtain certificates, endorsements, or other forms of
insurance evidence from Supplier and its Subcontractors is not a waiver by Bank of America of any
requirements for the Supplier and its Subcontractors to secure and continuously maintain the
specified coverages. Supplier shall notify and shall advise its Subcontractors to notify insurers of
the coverages required hereunder. Bank of America's acceptance of certificates and/or endorsements
that in any respect do not comply with the requirements of this Section does not release the
Supplier and its Subcontractors from compliance herewith. Should Supplier and/or its Subcontractors
fail to secure and continuously maintain the insurance coverage required under this Agreement,
Supplier shall itself be responsible to Bank of America for all the benefits and protections that
would have been provided by such coverage, including without limitation, the defense and
indemnification protections.

27.0 CONFIDENTIALITY AND INFORMATION PROTECTION

27.1 The term "Confidential Information" shall mean this Agreement and all data, trade secrets,
business information and other information of any kind whatsoever that a Party ("Discloser'')
discloses, in writing, orally, visually or in any other medium, to the other Party ("Recipient") or
to which Recipient obtains access and that relates to Discloser or, in the case of Supplier, to Bank
of America or its Representatives, customers, third-party vendors or licensors. Confidential
Information includes Associate Information, Customer information and Consumer information, as
defined in the Section entitled ''Definitions." A "writing" shall include an electronic transfer of
information by e-mail, over the internet or otherwise.

27.2 Supplier acknowledges that Bank of America has a responsibility to its customers and other
consumers using Its services to keep Associate Information, Customer Information and Consumer
Information strictly confidential. Each of the Parties, as Recipient, hereby agrees that it will
not, and will cause its Representatives, consultants, Affiliates and independent contractors not to
disclose Confidential Information of the other Party, including Associate Information, Proprietary
to Bank of America Page 20 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 23 -->
Customer Information and Consumer Information, during or after the Term of this Agreement, other
than on a "need to know" basis and then only to: (a) Affiliates of Bank of America; (b) Recipient's
employees or officers; (c) Affiliates of Recipient, its independent contractors at any level, agents
and consultants, provided that all such persons are subject to a written confidentiality agreement
that shall be no less restrictive than the provisions of this Section; (d) pursuant to the
exceptions set forth in 15 U.S.C 6802(e) and accompanying regulations, which disclosures are made in
the ordinary course of business and (e) as required by law or as otherwise expressly permitted by
this Agreement. Recipient shall not use or disclose Confidential Information of the other Party for
any purpose other than to carry out this Agreement. Recipient shall treat Confidential Information
of the other Party with no less care than it employs for its own Confidential Information of a
similar nature that it does not wish to disclose, publish or disseminate, but not less than a
reasonable level of care. Upon expiration or termination of this Agreement for any reason or at the
written request of Bank of America during the Term of this Agreement. Supplier shall promptly return
to Bank of America or destroy according to the Information Destruction Requirements described within
SCHEDULE E, "Information Security . at Bank of America's election, all Bank of America Confidential
Information in the possession of Supplier or Supplier's Subcontractors, subject to and in accordance
with the terms and provisions of this Agreement.

27.3 To the extent legally permitted, Recipient shall notify Discloser of any actual or threatened
requirement of law to disclose Confidential Information promptly upon receiving actual knowledge
thereof and shall cooperate with Discloser's reasonable, lawful efforts to resist, limit or delay
disclosure. Nothing in this Section shall require any notice or other action by Bank of America in
connection with requests or demands for Confidential Information by bank examiners.

27.4 Supplier shall not remove or download from Bank of America's premises or systems, the original
or any reproduction of any notes, memoranda, files, records, or other documents, whether in tangible
or electronic form, containing Bank of America's Confidential Information or any document prepared
by or on behalf of Supplier that contains or is based on Bank of America's Confidential Information,
without the prior written consent of an authorized Representative of Bank of America. Any document
or media provided by an authorized Bank of America Representative or notes taken to document
discussions with Bank of America Representatives pertaining to the Products provided hereunder will
be deemed to fall outside this consent requirement unless otherwise stated by the Bank of America
Representative.

27.5 With the exception of Associate Information, Customer Information and Consumer Information, the
obligations of confidentiality in this Section shall not apply to any information that (i) Recipient
rightfully has in its possession when disclosed to it, free of obligation to Discloser to maintain
its confidentiality; (ii) Recipient independently develops without access to Discloser's
Confidential Information; (iii) is or becomes known to the public other than by breach of this
Section or (iv) is rightfully received by Recipient from a third party without the obligation of
confidentiality. Any combination of Confidential Information disclosed with information not so
classified shall not be deemed to be within one of the foregoing exclusions merely because
individual portions of such combination are free of any confidentiality obligation or are separately
known in the public domain.

27.6 Bank of America may disclose Confidential Information of Supplier to independent contractors
for the purpose of further handling, processing, modifying and adapting the Products for use by or
for Bank of America, provided that such independent contractors have agreed to observe in substance
the obligations of Bank of America set forth in this Section.

27.7 All Confidential Information disclosed by Bank of America and any results of processing such
Confidential Information or derived in any way therefrom shall at all times remain the property of
Bank of America. Supplier shall have the responsibility for and bear all risk of loss or damage to
Confidential Information and damages resulting from improper or inaccurate processing of such data
arising from the negligence or willful misconduct of Supplier, its Representatives or
Subcontractors. Proprietary to Bank of America Page 21 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 24 -->
27.8 Supplier acknowledges that Bank of America is required to comply with the information security
standards required by the Gramm-Leach- Bliley Act (15 U.S.C. 6801, 6805(b)(1)) and the regulations
issued thereunder (12 C.F.R. Part 40), the Fair and Accurate Credit Transactions Act (15 U.S.C.
1681, 1681w) and the regulations issued thereunder (12 C.F.R. Parts 30 and 41) and with other
statutory, legal and regulatory requirements (collectively, "Privacy Laws'') If applicable, Supplier
shall make commercial best efforts to assist Bank of America to so comply and shall comply and
conform with applicable Privacy Laws, as amended from time to time, and with the Bank of America
policies for information protection as modified by Bank of America from time to time.

27.9 Bank of America may, in its sole discretion and at any time during the Term of this Agreement,
suspend, revoke or terminate Supplier's right to receive Confidential Information upon written
notice to Supplier. Upon receipt of that notice, Supplier shall (i) immediately stop accessing
and/or accepting Confidential Information and (ii) promptly return to Bank of America or destroy
according to the Information Destruction Requirements described within SCHEDULE E, "Information
Security," at Bank of America's election, all Bank of America Confidential Information in the
possession of Supplier or Suppliers Subcontractors, subject to and in accordance with the terms and
provisions of this Agreement.

27.10 As a condition of access to the Confidential Information of Bank of America, Supplier shall
make available to Bank of America a copy of its written Information Security Program for evaluation.
The program shall be designed to:

A. Ensure the security, integrity and confidentiality of Confidential Information;

B. Protect against any anticipated threats or hazards to the security or integrity of such
Confidential Information;

C. Protect against unauthorized access to or use of such Confidential Information that could result
in substantial harm orinconvenience to the person or entity that is the subject of such Confidential
Information; and

D. Ensure the proper disposal of such Confidential Information.

27.11 At the request of Bank of America, Supplier shall make commercially reasonable modifications
to its Information Security Program or to the procedures and practices thereunder to conform at
least to the Bank Security Requirements. Supplier shall require any Subcontractors and other persons
or entities who provide services to Supplier for delivery to Bank of America directly or indirectly
or who hold Confidential Information to implement and administer an information protection program
and plan that complies with Bank Security Requirements. Supplier shall include or shall cause to be
included in written agreements with such Subcontractors or other persons or entities substantially
the terms of this Section and the provisions of SCHEDULE E.

27.12 One aspect of the determination of Supplier compliance with Bank Security Requirements is a
review of Supplier Security Controls. As a condition precedent to performance under this Agreement,
Supplier agrees to satisfy the following validation requirements:

A. Participation in Bank of America's Supplier testing and assessment process including the
completion of online and/or on-siteassessment(s), as appropriate, and remediation of any findings;
Proprietary to Bank of America Page 22 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 25 -->
B. Periodic discussions between Bank of America personnel and Supplier Information Technology
security personnel to reviewSupplier Security Controls; and

C. Delivery to Bank of America of network diagrams depicting Supplier perimeter controls and
security policies and processes relevant to the protection of Confidential Information. Examples of
these policies include, but are not limited to, access control, physical security, patch management.
password standards, encryption standards, and change control.

27.13 During the course of performance under this Agreement, Supplier shall ensure the following:

A. Adequate governance and risk assessment processes are in place to maintain controls over
Confidential Information. A security awareness program must be in place or implemented that
communicates security policies to all Supplier (and Supplier Subcontractor(s)) personnel having
access to Confidential Information.

B. Notification to Bank of America of changes that may impact the security of Confidential
Information. Such changes requiring notification include, by way of example and not limitation,
outsourcing of computer networking, data storage, management and processing or other information
technology functions or facilities and the implementation of external web-enabled (internet) access
to Confidential Information.

C. Use of strong, industry-standard encryption of Confidential Information transmitted over public
networks (e.g. internet,non-dedicated leased lines) and backup tapes residing at off-site storage
facilities.

27.14 Bank of America reserves the right to monitor Supplier-maintained platforms that reside on the
Bank of America network. The Supplier may be required, at the expense of Bank of America, to assist
with installation, support and problem resolution of Bank of America owned equipment or processes,
or to provide an information feed from the Supplier Platform to the Bank of America monitoring
processes.

27.15 Supplier shall deliver an updated information Security Program or confirm that no changes have
been made to the Information Security Program annually.

27.16 Supplier understands and acknowledges its obligation to adhere to the Payment Card Industry
Data Security Standards (PCI DSS) for the protection of cardholder data throughout the Term of the
contract and any Renewal Terms. The PCI DSS may be found at www.pcisecuritystandards.org. Supplier
further understands that it is responsible for the security of cardholder data In its possession or
control or in the possession or control of any Subcontractors that it engages to perform under this
contract. Such Subcontractors must be identified to and approved by Bank of America in writing prior
to sharing cardholder data with the Subcontractor. In support of this obligation, Supplier shall
provide appropriate documentation to demonstrate compliance with PCI DSS standards by Supplier and
all identified Subcontractors. Failure to discharge this obligation may be considered by Bank of
America to be a Termination Event under (a) of subsection 5.2.

28.0 INDEMNITY

28.1 Supplier shall indemnify, defend, and hold harmless Bank of America and its Representatives,
successors, permitted assigns and customers from and against any and all claims or legal actions of
whatever kind or nature that are made or threatened by any third party and an related losses,
expenses, damages, costs and liabilities, including reasonable attorneys' fees and expenses incurred
in investigation, defense or settlement ("Damages"), which arise out of, are alleged to arise out
of, or relate to the following: (a) any negligent act or omission or willful misconduct by
Proprietary to Bank of America Page 23 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 26 -->
Supplier, its Representatives or any Subcontractor engaged by Supplier in the performance of
Supplier's obligations under this Agreement;or (b) any breach in a representation, covenant or
obligation of Supplier contained in this Agreement

28.2 Supplier shall defend or settle at its expense any threat, claim, suit or proceeding arising
from or alleging infringement, misappropriation or other violation of any Intellectual Property
Rights or any other rights of any third party by Products, Work Product or services furnished under
this Agreement Supplier shall indemnify and hold Bank of America, its Affiliates and each of their
Representatives, successors, permitted assigns and customers harmless from and against and pay any
Damages. including royalties and license fees attributable to such threat, claim, suit or
proceeding.

A. If any Product, Work Product or service furnished under this Agreement, including, without
limitation, software, system design, equipment or Documentation, becomes, or in Bank of America's or
Supplier's reasonable opinion is likely to become, the subject of any claim, suit, or proceeding
arising from or alleging facts that if true would constitute infringement, misappropriation or other
violation of, or in the event of any adjudication that such Work Product or Product infringes,
misappropriates or otherwise violates any Intellectual Property Rights or any other rights of a
third party, Supplier shall promptly notify Bank of America and, at Supplier's expense, Supplier
shall take the following actions in the listed order of preference: (i) secure for Bank of America
the right to continue using the Work Product or Product; or if commercially reasonable efforts are
unavailing, (ii) replace or modify the Work Product or Product to make it noninfringing; provided,
however, that such modification or replacement shall not degrade the operation or performance of the
Work Product or Product.

B. The indemnity in the preceding provision shall not extend to any claim of infringement resulting
solely from Bank of America'sunauthorized modification or use of the Work Product or Product.

28.3 Bank of America shall give Supplier notice of, and the Parties shall cooperate in, the defense
of any such claim, suit or proceeding, including appeals, negotiations and any settlement or
compromise thereof, provided that Bank of America must approve the terms of any settlement or
compromise that may impose any unindemnified or nonmonetary liability on Bank of America.

29.0 LIMITATION OF LIABILITY

29.1 Neither Party shall be liable to the other for any special, indirect, incidental,
consequential, punitive or exemplary damages, including, but not limited to, lost profits, even if
such Party alleged to be liable has knowledge of the possibility of such damages, provided, however,
that the limitations set forth in this Section shall not apply to or in any way limit the
obligations of the Section entitled "Indemnity," the Section entitled "Confidentiality and
Information Protection," or Supplier's gross negligence or willful misconduct.

30.0 DAMAGE TO BANK OF AMERICA SYSTEMS

30.1 Supplier represents and warrants that the Product and any media used to distribute it contain
no computer instructions, circuitry or other technological means ("Harmful Code") whose purpose is
to disrupt, damage or interfere with Bank of America's use of its computer and telecommunications
facilities for their commercial, test or research purposes. Harmful Code shall include, without
limitation, any automatic restraint, time-bomb, trap-door, virus, worm, Trojan horse or other
harmful code or instrumentality that will cause the Products or any other Bank of America software,
hardware or system to cease to operate or to fail to conform to its specifications. Supplier shall
indemnify Bank of America and hold Bank of America harmless from all claims, losses, damages and
expenses, including attorneys' fees, arising from the presence of Harmful Code in or with the
Product or contained on media delivered by Supplier. Supplier further represents and warrants that
it will not introduce any Harmful Code, into any computer or electronic data storage system used by
Bank of America. Proprietary to Bank of America Page 24 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 27 -->
31.0 SUPPLIER DIVERSITY

31.1 Supplier acknowledges and supports the Bank of America Supplier Diversity efforts supporting
minority, woman and disabled-owned business enterprises and its commitment to the participation of
minority, woman and disabled-owned business enterprises in its procurement of goods and services.

31.2 Definitions: For purposes of this Agreement, the following are the definitions of
"Minority-Owned Business Enterprise," "Minority Group," "Woman-Owned Business Enterprise,"
"Disabled-Veteran-Owned Business Enterprise" and "Disabled-Owned Business Enterprise."

A. "Minority-Owned Business Enterprise" is recognized as a "for profit" enterprise, regardless of
size, physically located in the United States or its trust territories, which is at least fifty-one
(51%) percent owned, operated and controlled, by one or more member(s) of a Minority Group who
maintain United States citizenship.

B. "Minority Group" means African Americans, Hispanic Americans, Native Americans (American Indians,
Eskimos, Aleuts, and native Hawaiians), Asian-Pacific Americans, and other minority group as
recognized by the United States Small Business Administration Office of Minority Small Business and
Capital ownership Development.

C. "Woman-Owned Business Enterprise" is recognized as a "for profit" enterprise, regardless of size,
located in the United States or itstrust territories, which is at least fifty-one (51%) percent
owned, operated and controlled by a female of United States citizenship.

D. "Disabled Veteran-Owned Business Enterprise" is recognized as a "for profit" enterprise,
regardless of size, located In the United States or its trust territories, which is at least
fifty-one (51%) percent owned, operated, and controlled by a disabled veteran. The disabled
veteran's ownership and control shall be real and continuing and not created solely to take
advantage of special or set aside programs aimed at supplier diversity. The Association of Service
Disabled Veterans, www.asdv.org provides certification for this category of business owners
throughout the United States.

E. "Disabled-Owned Business Enterprise" is recognized as a "for profit" enterprise, regardless of
size, located in the United States or its trust territories, which is at least fifty-one (51%)
percent owned, operated and controlled, by an individual of United States citizenship with a
permanent mental or physical impairment that substantially limits one or more of the major life
activities and which has a significant negative impact upon the company's ability to successfully
compete. The ownership and control shall be real and continuing and not created solely to take
advantage of special or set aside programs aimed at supplier diversity. Due to the absence of a
certifying agency for this category of business owners, the Disabled-Owned Business Enterprise must
complete an affidavit and provide supporting documentation to be eligible for consideration towards
diverse supplier participation.

31.3 In addition to the above criteria to qualify as a Minority, Woman or Disabled-Owned Business
Enterprise under this Agreement, the diverse supplier must be certified by an agency acceptable to
Bank of America.

31.4 Participation Representation: Supplier represents it is not a Minority-, Woman-, Disabled- or
Veteran- Disabled Owned Business Enterprise. Proprietary to Bank of America Page 25 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018

32.0 ENVIRONMENTAL INITIATIVE
<!-- page 28 -->
32.1 Supplier acknowledges that Bank of America encourages each supplier with which it enters into
an agreement for the provision of goods or services to use, consistent with the efficient
performance of such agreements, recycled paper goods and other environmentally preferable products,
and to implement and adhere to other environmentally beneficial policies and practices. Supplier
represents and warrants that Supplier uses environmentally beneficial practices specific to its
industry that meet at least the minimum standard recommended for its industry. Upon Bank of
America's request, Supplier will provide written information on its environmental policies and
procedures.

33.0 AUDIT

33.1 Supplier shall maintain at no additional cost to Bank of America, in a reasonably accessible
location, all Records pertaining to its Products and services provided to Bank of America under this
Agreement for a period of seven (7) years or as required by law, if longer. Such Supplier Records
referenced above may be inspected, audited and copied by Bank of America, its Representatives or by
federal or state agencies having jurisdiction over Bank of America, during normal business hours and
at such reasonable times as Bank of America and Supplier may determine. Records available for review
shall exclude any records pertaining to Supplier's other customers deemed proprietary and
confidential and Supplier confidential and proprietary records not associated with the Products and
services provided under this Agreement. Supplier will give prior notice to Bank of America of
requests by federal or state authorities to examine Supplier's Bank of America Records. At Bank of
America's written request, Supplier shall reasonably cooperate with Bank of America in seeking a
protective order with respect to such Records.

33.2 Supplier shall provide at its expense on an annual basis, a copy of the latest SAS70 (Statement
on Auditing Standards No. 70, Service Organizations) Type II independent audit firm report for
facilities not managed by Bank of America that are used to provide Products under this Agreement. If
not available, Supplier, at its sole cost and expense, will engage a nationally recognized certified
public accounting firm to conduct the audit and prepare applicable reports. Each report will cover a
minimum six (6) calendar month period each calendar year during the Term. Bank of America reserves
the right to expand the scope of the controls to be covered in any SAS70-Type II audit report
prepared during the Term. Supplier shall provide Bank of America with the scope of the audit and a
complete copy of each report prepared in connection with each such audit within thirty (30) calendar
days after it receives such report.

33.3 Supplier shall provide a copy of the latest operational audit for facilities not managed by
Bank of America that are used to provide services under this Agreement. If necessary, Supplier, at
its sole cost and expense, will engage a nationally recognized certified public accounting firm to
conduct the audit and prepare applicable reports. Each report will cover a minimum six (6) calendar
month period each calendar year during the Term. Such audits may be on a rotating site basis where
operations and procedures of Supplier services provided to Bank of America are in multiple locations
in order to confirm that Supplier is in compliance in all aspects of the Agreement Supplier shall
provide Bank of America with a copy of each report prepared in connection with each such audit
within thirty (30) calendar days after it receives such report.

33.4 During regular business hours but no more frequently than once a year, Bank of America may, at
Its sole expense, perform a confidential audit of Supplier's operations as they pertain to the
Products or services provided under this Agreement. Such audits shall be conducted on a mutually
agreed upon date (which shall be no more than ten (10) Business Days after Bank of America's written
notice of time, location and duration), subject to reasonable postponement by Supplier upon
Supplier's reasonable request, provided, however, that no such postponement shall exceed twenty (20)
Business Days. Bank of America will provide Supplier a summary of the findings from each report
prepared in connection with any such audit and discuss results, including remediation plans. If
audit results find Supplier Is not in substantial compliance with the Proprietary to Bank of America
Page 26 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 29 -->
requirements of this Agreement, then Bank of America shall be entitled, at Supplier's expense, to
perform up to two (2) additional such audits in that year in accordance with the procedure set forth
in this Section. Supplier agrees to promptly take action at Its expense to correct those matters or
items identified in any such audit that require correction. Failure to correct such matters shall be
considered a material breach of this Agreement.

33.5 Supplier will provide reasonable access to Bank of America's federal and state governmental
regulators (at a minimum, to the extent required by law), at Bank of America's expense, to Bank of
America's Records held by Supplier and to the procedures and facilities of Supplier relating to the
Products and services provided under this Agreement Pursuant to 12 U.S.C. 1867(c), the performance
of such services will be subject to regulation and examination by the appropriate federal banking
agency to the same extent as if the services were being performed by Bank of America itself.
Supplier acknowledges and agrees that regulatory agencies may audit Supplier's performance at any
time during normal business hours and that such audits may include both methods and results under
this Agreement.

33.6 Upon prior written notice and at a mutually acceptable time, Bank of America personnel or its
Representatives (e.g., external audit consultants) may audit, test or inspect Supplier's Information
Security Program and its facilities to assure Bank of America's data and Confidential Information
are adequately protected. This right to audit is in addition to the other audit rights or
assessments granted herein. Bank of America will determine the scope of such audits, tests or
inspections, which may extend to Supplier's Subcontractors and other Supplier resources (other
systems, environmental support, recovery processes, etc.) used to support the systems and handling
of Confidential Information. Supplier will inform Bank of America of any internal auditing
capability it possesses and permit Bank of America's personnel to consult on a confidential basis
with such auditors at all reasonable times. Bank of America may provide Supplier a summary of the
findings from each report prepared in connection with any such audit and discuss results, including
any remediation plans. Without limiting any other rights of Bank of America herein, if Supplier is
In breach or otherwise not compliant with any of the provisions set forth in the Section of this
Agreement entitled "Confidentiality and Information Protection" and/or SCHEDULE E, then Bank of
America may conduct additional audits.

33.7 In addition to the requirements under this Section 33.0 and upon Bank of America's request,
Supplier shall deliver to Bank of America, within thirty (30) calendar days after its receipt by its
board of directors or senior management. a copy of any preliminary or final report of audit of
Supplier by any third-party auditors retained by Supplier, including any management letter such
auditors submit, and on any other audit or inspection upon which Bank of America and Supplier may
mutually agree.

34.0 NON-ASSIGNMENT

34.1 Neither Party may assign this Agreement or any of the rights hereunder or delegate any of its
obligations hereunder, without the prior written consent of the other Party, and any such attempted
assignment shall be void, except that Bank of America or any permitted Bank of America assignee may
assign any of its rights and obligations under this Agreement (including, without limitation, any
individual Order) to any Bank of America Affiliate, the surviving corporation with or into which
Bank of America or such assignee may merge or consolidate or an entity to which Bank of America or
such assignee transfers all, or substantially all, of its business and assets. Bank of America may
not unreasonably withhold its consent of assignment in the event the supplier merges or consolidates
with another entity.

35.0 GOVERNING LAW

35.1 This Agreement shall be governed by the internal laws, and not by the laws regarding conflicts
of laws, of the State of North Carolina. Each Party hereby submits to the exclusive jurisdiction of
the courts of such state, and waives any objection to venue with respect to actions brought in such
courts. This provision shall not be construed to conflict with the provisions of the Section
entitled "Mediation/Arbitration." Proprietary to Bank of America Page 27 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 30 -->
36.0 DISPUTE RESOLUTION

36.1 The following procedure will be adhered to in all disputes arising under this Agreement which
the Parties cannot resolve informally through their Relationship Managers. The aggrieved Party shall
notify the other Party in writing of the nature of the dispute with as much detail as possible about
the deficient performance of the other Party. The Relationship Managers shall meet (in person or by
telephone) within seven (7) calendar days (or other mutually agreed upon date) after the date of the
written notification to reach an agreement about the nature of the deficiency and the corrective
action to be taken by the respective Parties. If the Relationship Managers do not meet or are unable
to agree on corrective action, senior managers of the Parties having authority to resolve the
dispute without the further consent of any other person ("Management") shall meet or otherwise act
to facilitate an agreement within fourteen (14) calendar days (or other mutually agreed upon date)
of the date of the written notification. If Management do not meet or cannot resolve the dispute or
agree upon a written plan of corrective action to do so within seven (7) calendar days (or other
mutually agreed upon date) after their initial meeting or other action, or if the agreed-upon
completion dates in the written plan of corrective action are exceeded, either Party may request
mediation and/or arbitration as provided for in this Agreement. Except as otherwise specifically
provided, neither Party shall initiate arbitration, mediation or litigation unless and until this
dispute resolution procedure has been substantially compiled with or waived. Failure of a Party to
fulfill its obligations in this Section, including failure to meet timely upon the other Party's
notice, shall be deemed such a waiver.

37.0 MEDIATION/ARBITRATION

37.1 If the Parties are unable to resolve a dispute arising out of or relating to this Agreement in
accordance with the Section entitled "Dispute Resolution," the Parties will in good faith attempt to
resolve such dispute through non-binding mediation. The mediation shall be conducted before a
mediator acceptable to both sides, who shall be an attorney or retired judge practicing in the areas
of banking and/or information technology law. The mediation shall be held In Charlotte, N.C.,
provided, however, a dispute relating to infringement of Intellectual Property Rights or the Section
entitled "Confidentiality and Information Protection" shall not be subject to this Section entitled
"Mediation/Arbitration."

37.2 Any controversy or claim, other than those specifically excluded, between or among the Parties
not resolved through mediation under the preceding provision, shall at the request of a Party be
determined by arbitration. The arbitration shall be conducted by one independent arbitrator who
shall be an attorney or retired judge practicing in the areas of banking and/or Information
technology law. The arbitration shall be held in Charlotte, N.C. in accordance with the United
States Arbitration Act (9 U.S.C. 1 et seq.), notwithstanding any choice of law provision in this
Agreement, and under the auspices and the Commercial Arbitration Rules of the American Arbitration
Association.

37.3 Consistent with the expedited nature of arbitration, each Party will, upon the written request
of the other Party, promptly provide the other with copies of documents relevant to the issues
raised by any claim or counterclaim on which the producing Party may rely in support of or in
opposition to any claim or defense. At the request of a Party, the arbitrator shall have the
discretion to order examination by deposition of witnesses to the extent the arbitrator deems such
additional discovery relevant and appropriate. Depositions shall be limited to a maximum of three
(3) per Party and shall be held within thirty (30) calendar days of the making of a request.
Additional depositions may be scheduled only with the permission of the arbitrator, and for good
cause shown. Each deposition shall be limited to a maximum of three (3) hours duration. All
objections are reserved for the arbitration hearing except for objections based on privilege and
proprietary or confidential information. Any dispute regarding discovery, or the relevance or scope
thereof, shall be determined by the arbitrator, which determination shall be conclusive. All
discovery shall be completed within sixty (60) calendar days following the appointment of the
arbitrator. Proprietary to Bank of America Page 28 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 31 -->
37.4 The arbitrator shall give effect to statutes of limitation in determining any claim, and any
controversy concerning whether an issue is arbitrable shall be determined by the arbitrator. The
arbitrator shall follow the law in reaching a reasoned decision and shall deliver a written opinion
setting forth findings of fact, conclusions of law and the rationale for the decision. The
arbitrator shall reconsider the decision once upon the motion and at the expense of a Party. The
Section of this Agreement entitled "Confidentiality and Information Protection" shall apply to the
arbitration proceeding, all evidence taken, and the arbitrator's opinion, which shall be
Confidential Information of both Parties. Judgment upon the decision rendered by the arbitrator may
be entered in any court having jurisdiction.

37.5 No provision of this Section shall limit the right of a Party to obtain provisional or
ancillary remedies from a court of competent jurisdiction before, after, or during the pendency of
any arbitration. The exercise of a remedy does not waive the right of either Party to resort to
arbitration. The institution and maintenance of an action for judicial relief or pursuit of a
provisional or ancillary remedy shall not constitute a waiver of the right of either Party to submit
the controversy or claim to arbitration if the other Party contests such action for judicial relief.

38.0 NON-EXCLUSIVE NATURE OF AGREEMENT

38.1 Supplier agrees that it shall not be considered Bank of America's exclusive provider of any
goods or services provided hereunder. Bank of America retains the unconditional right to utilize
other vendors in the provision of services and products whether or not similar to the services and
Products described in this Agreement.

39.0 OWNERSHIP OF WORK PRODUCT

39.1 Bank of America will own exclusively all Work Product and Supplier hereby assigns to Bank of
America all right, title and interest (including all Intellectual Property Rights) in the Work
Product. Work Product, to the extent permitted by law, shall be deemed "works made for hire" (as
that term is defined in the United States Copyright Act). Supplier shall provide Bank of America
upon request with all assistance reasonably required to register, perfect or enforce such right,
title and interest, including providing pertinent information and, executing all applications,
specifications, oaths, assignments and all other instruments that Bank of America shall deem
necessary. Supplier shall enter into agreements with all of its Representatives and Subcontractors
necessary to establish Bank of America's sole ownership in the Work Product. Bank of America
acknowledges Supplier's and its licensors' claims of proprietary rights in preexisting works of
authorship and other intellectual property ("Pre-existing IP") Supplier uses in its work pursuant to
this Agreement. Bank of America does not claim any right not expressly granted by this Agreement in
such Pre-existing IP, which shall not be deemed Work Product, even if incorporated with Work Product
in the Product Supplier delivers to Bank of America. Unless otherwise agreed in an Order, Supplier
grants Bank of America a perpetual, worldwide, irrevocable, nonexclusive royalty free license to any
Pre-existing IP embedded in the Work Product, which shall permit Bank of America and any transferee
or sublicensee of Bank of America, subject to the restrictions in this Agreement, to make, use,
import, reproduce, display, distribute, make derivative works and modify such Pre-existing IP as
necessary or desirable for the use of the Work Product.

39.2 Supplier shall promptly notify Bank of America in writing, of any threat, or the filing of any
action, suit or proceeding, against Supplier, its Affiliates, Subcontractors or Representatives, (i)
alleging infringement, misappropriation or other violation of any Intellectual Property Right
related to any Product, Work Product or service furnished under this Agreement, or (ii) in which an
adverse decision would reasonably be expected to have a material adverse effect on the Supplier or
the use by Bank of America of the Products, Work Product or services furnished under this Agreement.
Proprietary to Bank of America Page 29 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 32 -->
39.3 At all times during the Term, upon request from Bank of America and upon termination of this
Agreement for any reason, Supplier shall provide immediately to Bank of America the then-current
version of any Work Product in Supplier's possession.

39.4 Supplier understands and acknowledges that Bank of America may (i) manage, modify, maintain and
update pre-existing data and information, and (ii) generate, manage, modify, maintain and update
additional data and information (collectively, "Bank of America Data") using the Software. Bank of
America Data will be treated as Bank of America Confidential Information and Bank of America shall
retain all right, title and interest in and to all Bank of America Data.

39.5 Bank of America shall have the right to interface the Software and to use it in conjunction
with other software, programs, routines and subroutines developed or acquired by Bank of America.
Supplier shall have no ownership interest in any other software, program, routine or subroutine
developed by Bank of America or acquired by Bank of America from a third party by virtue of its
having been interfaced with or used in conjunction with any Software.

40.0 MISCELLANEOUS

40.1 Bank of America and Supplier represent that they are equal opportunity employers and do not
discriminate in employment of persons or awarding of subcontracts because of a person's race, sex,
age, religion, national origin, veteran or handicap status. Supplier is aware of and fully informed
of Supplier's responsibilities and agrees to the provisions under the following: (a) Executive Order
11246, as amended or superseded in whole or in part, and as contained in Section 202 of the
Executive Order as found at 41 C.F.R. § 60-1.4(a)(1-7); (b) Section 503 of the Rehabilitation Act of
1973 as contained in 41 C.F. R. § 60- 741.4; and (c) The Vietnam Era Veterans' Readjustment
Assistance Act of 1974 as contained in 41 C.F.R. § 60-250.4.

40.2 Section headings are included for convenience or reference only and are not intended to define
or limit the scope of any provision of this Agreement and should not be used to construe or
interpret this Agreement.

40.3 No delay, failure or waiver of either Party's exercise or partial exercise of any right or
remedy under this Agreement shall operate to limit, impair, preclude, cancel, waive or otherwise
affect such right or remedy. Any waiver by either Party of any provision of this Agreement shall not
imply a subsequent waiver of that or any other provision of this Agreement.

40.4 If any provision of this Agreement is held invalid, illegal or unenforceable, the validity,
legality or enforceability of the remaining provisions shall in no way be affected or impaired
thereby.

40.5 No amendments of any provision of this Agreement shall be valid unless made by an instrument in
writing signed by both Parties specifically referencing this Agreement. Notwithstanding anything
therein to the contrary, the terms of any Order to this Agreement shall supplement and not replace
or amend the terms or provisions of this Agreement and the terms and provisions of this Agreement
shall control in the event of any conflict between such terms thereof and the terms and provisions
of this Agreement and such conflict shall be resolved in favor of the express terms and provisions
of this Agreement. The terms and provisions of this Agreement shall be incorporated by reference
into any Order to this Agreement.

40.6 Anything in this Agreement to the contrary notwithstanding, the Parties hereby agree that
thirty (30) calendar days after written notice by Bank of America of any amendment to this Agreement
for compliance with a change in federal law, rule or regulation affecting financial services
companies or the suppliers of financial services companies, this Agreement shall be amended by such
notice and the amendment contained therein and without need for further action of the Parties, and
the Agreement as amended thereby, shall be enforceable against the Parties, their successors and
assigns. The notice provided hereunder shall set forth such change and provide Proprietary to Bank
of America Page 30 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 33 -->
the relevant amendment to the Agreement. Bank of America shall have the right to terminate
immediately the Agreement, without furtherliability to Supplier, in the event of Supplier's failure
to comply with the terms and conditions of any such amendment to the Agreement.

40.7 This Agreement may be executed by the Parties in one or more counterparts, and each of which
when so executed shall be an original but all such counterparts shall constitute one and the same
instrument.

40.8 The remedies under this Agreement shall be cumulative and are not exclusive. Election of one
remedy shall not preclude pursuit of other remedies available under this Agreement or at law or in
equity. In arbitration a Party may seek any remedy generally available under the governing law.

40.9 To the maximum extent permitted by the governing law, this Agreement and the transactions
called for herein shall not be governed or affected by any version of the Uniform Computer
Information Transactions Act enacted in any jurisdiction.

40.10 Notwithstanding the general rules of construction, both Bank of America and Supplier
acknowledge that both Parties were given an equal opportunity to negotiate the terms and conditions
contained in this Agreement, and agree that the identity of the drafter of this Agreement is not
relevant to any interpretation of the terms and conditions of this Agreement.

40.11 All notices or other communications required under this Agreement shall be given to the
Parties in writing to the applicable addresses set forth on the signature page, or to such other
addresses as the Parties may substitute by written notice given in the manner prescribed in this
Section as follows: (a) by first class, registered or certified United States mail, return receipt
requested and postage prepaid, (b) over-night express courier or (c) by hand delivery to such
addresses, Such notices shall be deemed to have been duly given (i) five (5) Business Days after the
date of mailing as described above, (ii) one (1) Business Day after being received by an express
courier during business hours, or (iii) the same day if by hand delivery.

40.12 Wherever this Agreement requires either Party's approval or consent such approval or consent
shall not be unreasonably withheld or delayed.

40.13 Unless the Parties otherwise agree in writing, all services to be provided hereunder shall be
processed and/or provided, whether in part or in whole, by Supplier, its employees, Representatives
and/or Subcontractors on and from a location or locations in one (1) or more of the fifty (50)
states of the United States of America only, all subject to applicable laws and regulations.

40.14 This Agreement shall be binding upon, and inure to the benefit of, the Parties and their
respective permitted successors and assigns. Except as expressly set forth in this Agreement and
with the exception of the Affiliates of Bank of America, the Parties do not intend the benefits of
this Agreement to inure to any third party, and nothing contained herein shall be construed as
creating any right, claim or cause of action in favor of any such other third party, against either
of the Parties hereto.

40.15 Neither Party shall issue any media releases, public announcements and public disclosures,
relating to this Agreement or use the name or logo of the other Party, including, without
limitation, in promotional or marketing material or on a list of customers, provided that nothing in
this paragraph shall restrict any disclosure required by legal, accounting or regulatory
requirements beyond the reasonable control of the releasing Party. Proprietary to Bank of America
Page 31 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 34 -->
41.0 ENTIRE AGREEMENT

41.1 This Agreement, the Schedules, and other documents Incorporated herein by reference, is the
final, full and exclusive expression of the agreement of the Parties and supersedes all prior
agreements, understandings, writings, proposals, representations and communications, oral or
written, of either Party with respect to the subject matter hereof and the transactions contemplated
hereby. The Parties agree to accept a digital image of this Agreement, as executed, as a true and
correct original and admissible as best evidence to the extent permitted by a court with proper
jurisdiction. Proprietary to Bank of America Page 32 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018

Software License, Customization and Maintenance Agreement
<!-- page 35 -->
SCHEDULE C

Bank of America Change Order Request Form Bank of America - Change number: Project

Software and Hardware Change Order Request and Authorization

Requested by: (please print) Date of request: Name: Date required: Dept. #: Priority: Phone #: ○ Low
○ Medium ○ High

Description of change: - -

See Attachment ○ Response: ○ Bank of America or ○ Supplier Enhancement See Attachment ○ Estimated
effort (to be filled in by Systems Analyst) Estimate for CO Request Only ○

Function Hours required Estimated Cost Target date Comments Analysis/Design Programming Testing
Implementation

Estimated by: Date: Approved by:

Bank of America Project Manager Date

Supplier Project Manager Date

Proprietary to Bank of America C-1 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018

Change Control Procedures
<!-- page 36 -->
The procedure steps In Table 1 shall be employed to achieve the desired objectives for this Change
Order.

Table 1 Change Control Procedure Steps

Step Individual Sub- step Action 1) Originator a) Fills out Change Order Request & Authorization
Form b) Submits form to Bank of America Project Administrator

2) Bank of America Project Administrator a) Assign unique Change number to form log.

b) Logs from into CO log. c) Make one copy of form and attachments. d) File copy in "In
Process-Review" CO file. e) Deliver form (with attachments, if any) to Supplier Project Manager

3) Supplier Project Manager a) Reviews form b) Arranges for Analyst to review form

4)

Analyst

a)

Reviews form and analyzes changes required. If time to evaluate CO is more than four hours, returns
form to Supplier Project Manager with estimate of number of hours required (including expected
additional participants and their respective hours) to evaluate the CO Request. Check "Estimate for
CO Request Only" box on form. (Supplier Project Manager will get prior approval for Bank of America
funding cost of CO Request evaluation, before Systems Analyst begins actual review.) b) Fills out
"Responses" section of form including "Estimated effort" c) Returns form to Supplier Project
Manager.

5) Supplier Project Manager a) Review form for completeness of response, evaluates available
resources. b) Signs & dates form at bottom signifying approval. c) Returns form to Project
Administrator. Proprietary to Bank of America C-2 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 37 -->
6) Bank of America Project Administrator a) Makes two copies of CO form

b) c) d) e)

Files one copy in CO "Returned" file. Removes and destroys "In Process" copy. Returns a copy to
Supplier Project Manager. Returns originals CO form to Originator.

7) Bank of America Project Manager a) Evaluates CO Response.

b) Negotiates with Supplier any differences regarding licensing status of deliverables.

c) Signs & dates form at bottom signifying approval. If declined, writes "Cancelled" in "Bank of
America Project Manager" signature area of form. d) Makes appropriate copies for Bank of America use
(to TAM, etc.) e) Returns original signed copy to Project Administrator.

8) Project Administrator a) If CO approved, makes two copies: one to Supplier Project Manager, one
for person to be assigned. Delivers both to Supplier Project Manager. Updates log.

b) If CO cancelled, original from is filed in CO "Cancelled" file, updates log, removes copy from
"Returned to Bank of America" file.

9) Supplier Project Manager a) b) Reviews form, arranges for Supplier to assign Systems Analyst
Updates project plan (may be done by Implementation Manager)

10) Supplier's Analyst When CO completed, form is returned to Supplier Project Manager

11) Supplier Project Manager a) Reviews the results of the CO (deliverables, activities …) and
concurs that CO was completed. Signs form. b) Returns form to Project Administrator.

12)

Project Administrator

a) b) c) d) e)

Makes two copies of completed form. Sends one copy to Supplier Accounting. Files one copy in "CO
Completed" file. Sends original back to Bank of America Project Manager. Updates log.

13)

Bank of America Project Manager

a)

b)

Reviews form and results.

Files in Bank of America's "CO Completed" file. Proprietary to Bank of America C-3 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 38 -->
SCHEDULE D Maintenance Services

MAINTENANCE SERVICES

A. During the Warranty Period, Supplier shall provide Bank of America Maintenance Services at no
additional charge, provided that if a Customization is not Operative at the end of the applicable
Warranty Period, Maintenance Services shall continue to be provided without additional charge until
the Customization is Operative.

B. Supplier shall provide the Maintenance Services described in this for Software, Updates and
Upgrades provided to Bank of America pursuant to this Agreement.

C. As part of Maintenance Services, Supplier shall provide the following:

(1) help desk support available twenty-four (24) hours a day, seven (7) days a week via toll-free
telephone number with help desk technicians sufficiently trained and experienced to identify or
resolve most support issues and who shall respond to all Bank of America requests for support within
fifteen (15) minutes after receiving a request for assistance;

(2) a current list of persons and telephone numbers. including pager numbers, (the "Calling List")
for Bank of America to contact to enable Bank of America to escalate its support requests for issues
that cannot be resolved by a help desk technician or for circumstances where a help desk technician
does not respond within the time specified.

D. Supplier shall deliver to Bank of America and keep current a list of persons and telephone
numbers ("Calling List") for Bank of America to contact in order to obtain answers to questions
about the Equipment or to obtain Corrections. The Calling List shall include (1) the first person to
contact if a question arises or problem occurs and (2) the persons in successively more responsible
or qualified positions to provide the answer or assistance desired. If Supplier does not respond
promptly to any request by Bank of America for telephone consultative service, then Bank of America
may attempt to contact the next more responsible or qualified person on the Calling List until
contact is made and a designated person responds to the call.

ERROR CORRECTION

A. Supplier shall make reasonable efforts to respond within two (2) hours to Bank of America's
initial request for assistance in correcting or creating a workaround for an Error. Supplier's
response shall include assigning fully-qualified technicians to work with Bank of America to
diagnose and correct or create a workaround for the Error and notifying the Bank of America
Representative making the initial request for assistance of Supplier's efforts, plans for resolution
of the Error, and estimated time required to resolve the Error. Supplier shall correct Errors caused
by the Object Code by modifying Source Code and distributing the modified Software to Bank of
America on the schedule called for in this Section.

B. For Class 1 Errors, Supplier shall provide a Correction or workaround reasonable in Bank of
America's judgment within the Repair Period after Bank of America reports the Error, or within four
(4) hours after Bank of America first reports the Error if no other Repair Period is specified.
These steps shall include assigning fully-qualified technicians to work with Bank of America without
interruption or additional charge, twenty-four (24) hours per day, until Supplier provides a
Correction or workaround reasonable in Bank of America's judgment.

C. For Class 2 Errors, Supplier shall take reasonable steps to provide a Correction or a workaround
reasonable in Bank of America's judgment by the opening of business on the second Business Day after
Bank of America reports the Error. These steps shall include assigning fully- qualified Proprietary
to Bank of America D-4 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 39 -->
technicians to work with Bank of America during Bank of America's regular business hours until
Supplier provides a workaround reasonable in Bank of America's judgment or a Correction or Bank of
America determines after consultation with Supplier that such a workaround or Correction cannot be
produced by Supplier's technicians. Supplier shall provide a Correction within thirty (30) calendar
days after Bank of America's report of the Error.

D. For Class 3 Errors, Supplier shall correct the Errors by all reasonable means. Supplier shall
correct the Errors and distribute the modified Software to Bank of America no later than the next
Update, unless Supplier has scheduled release of such Update less than thirty (30) calendar days
after Bank of America's notice, in which case Supplier shall correct the Error no later than the
following Update.

E. Without limiting Supplier's obligations under this Section, if Supplier does not deliver a
Correction for an Error within the times allowed by this Section (whether Supplier has delivered a
reasonable workaround or not), Supplier shall provide a written analysis of the problem and a
written plan to supply Bank of America with a Correction.

PRODUCTION ERRORS

Notwithstanding the previous Section, "Error Correction," if an Error prevents Bank of America from
making productive use of the Software, Supplier shall use its best efforts to provide an effective
workaround or a Correction by the time Bank of America opens for business on the Business Day after
the Business Day on which Bank of America first reports the Error.

REMEDIES

A. Without limitation of Supplier's obligations above, Bank of America may fall back, at its option,
to any previous version or release of the Software in which a Class 1 or Class 2 Error does not
occur or can be worked around, and Supplier shall provide Maintenance Services at no charge, with
respect to that version until Supplier provides a Correction.

DIAGNOSTIC INFORMATION

Bank of America shall submit to Supplier a listing of output and such other data as Supplier
reasonably may request in order to reproduce operating conditions similar to those present when Bank
of America detected the Error.

BANK OF AMERICA MODIFIED SOFTWARE

If Bank of America modifies the Software under the terms hereof, any additional maintenance costs or
expenses to Supplier which result directly from such modification may be billed to Bank of America
at the Time and Materials Rates.

UPDATES

Supplier shall provide all Updates to Bank of America at no additional charge when Updates are made
generally available to Supplier's other customers.

Supplier will complete two (2) dedicated releases/year for Bank of America during the initial Term.
The parties will work together every 6 months during the Term to define and agree upon the timelines
and features for the next dedicated release. During the Term, six (6) weeks prior to each release.
Cardlytics will provide Bank of America with code release notes or other technical documentation
(describing features and functionality). Proprietary to Bank of America D-5 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 40 -->
Supplier's TMS provides marketing services across multiple financial Institutions in addition to
Bank of America. For the TMS service to function properly, the OPS system must be upgraded
periodically. The supplier will provide no more than two major code releases of OPS during a
calendar year without Bank of America's consent. Bank of America may implement these releases when
appropriate and convenient for Bank of America. However, The TMS will support the current and
previous release of OPS. If Bank of America does not upgrade to the current or previous release of
OPS, some or all of TMS functionality may be impacted. Proprietary to Bank of America D-6 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 41 -->
SCHEDULE E Information Security

INFORMATION SECURITY PROGRAM

Bank of America shall have the opportunity to evaluate the Supplier's Information Security Program
and Supplier Security Controls to ensure Supplier's Compliance with the Section entitled
"Confidentiality and Information Protection." The Supplier's Information Security Program (the
"Program") shall address the Bank Security Requirements described below. This Program shall, at a
minimum, prescribe the architecture of Supplier's system, Confidential Information placement within
the system, the security controls in place (e.g. firewalls, web page security, intrusion detection,
incident response process, etc.) and contain the information called for in the Subsection entitled
"Security Program Features" below. The Program shall also describe physical security measures in
place to protect Confidential Information received or processed by Supplier, including those that
will protect Confidential Information that has been printed or otherwise displayed in forms
perceptible with or without the aid of equipment. Bank of America shall provide Supplier with the
Service Provider Security Requirements document outlining such Bank Security Requirements and
Supplier Security Controls which shall be deemed a part of Bank of America's Confidential
Information under this Agreement Supplier acknowledges that upon request in order to be allowed
continued access to Confidential Information, it will make modifications to its Information Security
Program to add additional measures necessary to retain Information Security standards consistent
with the Bank Security Requirements.

PRIVACY POLICY

With respect to Confidential Information and the services provided to or on behalf of Bank of
America, Supplier promptly shall conform its publicly available privacy and security policies, in
Bank of America's reasonable judgment, to those of Bank of America, as they may exist from time to
time.

PROTECTION

Supplier shall install and use a reasonable change control process to ensure that access to its
systems and to Confidential Information is controlled and recorded. Supplier shall notify Bank of
America of any planned system configuration changes or other changes affecting the Program
applicable to Confidential Information, setting forth how such change will impact the security and
protection of Confidential Information. No such change, which could reasonably be expected by Bank
of America to have a material adverse impact on the security and protection of Confidential
Information, may be implemented without the prior written consent of a Bank of America security
representative. Bank of America may approve these types of changes prior to their becoming
effective, such approval not to be unreasonably withheld or delayed.

Supplier shall permit Bank of America, at the election of Bank of America, to conduct security
vulnerability (penetration) testing on those portions of the Supplier network, and any application
servers that Supplier hosts on behalf of Bank of America, on which Confidential Information is
stored or processed. Such vulnerability testing shall be conducted in a non-production environment
with production equivalent security controls and with prior notice to Supplier. Supplier also agrees
to make available to Bank of America the results of any vulnerability testing conducted by Supplier
or a qualified third party provider of this service.

Supplier shall permit Bank of America to inspect the physical system equipment, operational
environment, and Confidential Information handling procedures. Supplier's agreement with any
independent contractor to provide services to Bank of America in support of this Agreement shall
likewise permit Bank of America to conduct the same inspections. Proprietary to Bank of America E-1
vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 42 -->
Subject to the terms of this Agreement and the Schedules attached hereto, Supplier will take
commercial best measures to prevent the unintended or malicious loss, destruction or alteration of
Bank of America's files, Confidential Information, software and other property received and held by
Supplier. Supplier shall maintain back-up files (including off-site back-up copies) thereof and of
resultant output to facilitate their reconstruction in the case of such loss, destruction or
alteration, in order to ensure uninterrupted services in accordance with the terms of this
Agreement, its Schedules, Bank of America's written policies and Supplier's disaster recovery plans.

DETECTION AND RESPONSE

Supplier shall notify Bank of America immediately (within 24 hours or as soon thereafter as
practicable) following discovery of any suspected breach or compromise of the security,
confidentiality, or integrity of nonpublic personal information of any current or former Bank of
America employee or customer (''Affected Persons") or otherwise provided to Supplier by Bank of
America under this agreement through the defined security escalation channel of Bank of America, the
Bank of America Incident Response Team ("InfoSafe") by calling (800) 207-2322, option 1. Callers
will be asked to identify themselves as Supplier. Such notification to Bank of America shall precede
notifications to any other party. Supplier shall cooperate fully with all Bank of America security
investigation activities consistent with the lnfoSafe guidelines for escalation and control of
significant security incidents.

Bank of America reserves the right in its sole discretion to make appropriate privacy breach
notifications to Affected Persons and regulators pursuant to federal or state guidelines, including
but not limited to the Interagency Guidance on Response Programs for Unauthorized Access to Customer
Information and Customer Notice. To assist Bank of America in such notifications, Supplier shall
include a brief summary of the available facts, the status of any investigation, and, if known, the
potential number of Affected Persons. Supplier agrees to provide at no charge, to Affected Persons
appropriate credit monitoring services for two years. All costs associated with any security breach,
including but not limited to, the costs of the notices to, and credit monitoring for, Affected
Persons shall be the sole responsibility of Supplier. Supplier agrees that it shall not communicate
with any third party, including, but not limited to the media, vendors, consumers. and Affected
Persons regarding any security breach without the express written consent of Bank of America.

Supplier shall maintain for a mutually agreed-upon length of time, and afford Bank of America
reasonable access to, all records and logs of that portion of Supplier's network that stores or
processes Confidential Information. Bank of America may review and Inspect any record of system
activity or Confidential Information handling upon reasonable prior notice. Supplier acknowledges
and agrees that records of system activity and of Confidential Information handling may be evidence
(subject to appropriate chain of custody procedures) in the event of a Security Breach or other
inappropriate activity. Upon the Bank of America, Supplier shall deliver the original copies of such
records to Bank of America for use in any legal, investigatory or regulatory proceeding.

Supplier shall monitor industry-standard information channels (bugtraq, CERT, OEMs, etc.) for newly
identified system vulnerabilities regarding the technologies and services provided to Bank of
America and fix or patch any identified security problem in an adequate and timely manner. Unless
otherwise expressly agreed in writing, "timely" shall mean that Supplier shall Introduce such fix or
patch as soon as commercially reasonable after Supplier becomes aware of the security problem. This
obligation extends to all devices that comprise Supplier's system, e.g., application software,
databases, servers, firewalls, routers and switches, hubs, etc., and to all of Supplier's other
Confidential Information handling practices.

Bank of America may perform vulnerability testing of Supplier's system to test the remediation
measures implemented after a security incident or event to protect Confidential Information.

SECURITY PROGRAM FEATURES

At the request of Bank of America, Supplier shall meet with the Bank of America information security
team to discuss information security issues In much greater detail at mutually agreeable times and
locations. Proprietary to Bank of America E-2 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 43 -->
Bank of America acknowledges and agrees that the information Supplier so provides is Supplier's
Confidential Information, as defined In this Agreement, and is valuable proprietary information of
Supplier. Supplier shall provide detailed information including, but not limited to, the following
topics, which also shall be addressed in Supplier's Program.

1. Diagrams. The diagrams shall show the detail of the system architecture including, without
limitation, the logical topology of routers, switches, internet firewalls, management or monitoring
firewalls, servers (web, application and database), intrusion detection systems, network and
platform redundancy. The diagrams shall include all hosting environments including those provided by
Supplier's Subcontractors.

2. Firewalls. Slate the specifications of the firewalls in use and who manages them. Specify the
services, tools and connectivity requiredto manage the firewalls.

3. Intrusion Detection Systems. Describe the intrusion detection system ("lDS") environment and the
Security Breach and event escalation process. Indicate who manages the IDS environment. Specify the
services, tools and connectivity required to manage the IDS environment, and if the IDS network is
host based.

4. Change Management. Describe the change management process for automated systems used to provide
services. Describe theprocess for information handling policies and practices.

5. Business Continuity. Describe the business and technical disaster recovery management process.

6. System Administration Access Control. Describe the positions that perform administration
functions on servers, firewalls or other devices within the application and network infrastructure.
Detail level of access needed to perform functions. Explain the access control mechanisms. Describe
the process by which recurring access of the system(s) is conducted to ensure permissions are
granted on a "need to know" basis. Detail access reports generated and when reports are reviewed
periodically. Describe methods used to track/log the usage of each account.

7. Customer Access Control. Describe each logon process to be followed by Bank of America Customers
(including Bank of America employees) to obtain access to services Supplier provides to Bank of
America. Describe the initial enrollment process for such Customers. Describe the password policies
and procedures Supplier's system enforces, including, without limitation, password expiration,
length of password, password revocation, invalid logon attempt threshold, etc. Describe methods used
to track/log the usage of each account Supplier shall demonstrate how a customer or end user
authenticates to each application.

8. Access to Confidential Information in Human-Perceptible Forms. Describe policies, procedures and
controls used to protect Confidential Information when it is printed or in other perceptible forms;
how and how often these policies and procedures are reviewed and tested; and what methods are used
to ensure destruction of Confidential Information on hard copy.

9. Operating System Baselines. Describe Supplier's operating system security controls and
configurations. Examples: Operating system services that have been removed because not required by
Supplier's services to Bank of America. Identify and provide current operating system fixes that
have not been applied, if any. Proprietary to Bank of America E-3 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 44 -->
10. Encryption. Describe in detail the technology and usage of encryption for protecting
Confidential Information, including passwordsand authentication information, during transit and in
all forms and locations where it may be stored.

11. Application and Network Management. Specify the services, tools and connectivity required to
manage the application and networkenvironments: who carries out the management functions; and what
level of physical security applies to managed devices.

12. Physical Security. For each location where Confidential Information will be processed or stored
or services for Bank of Americaproduced by Supplier, describe in detail the arrangements in place
for physical security.

13. Privacy: Describe Supplier's privacy and security policies; indicate if they are in writing; and
whether they are compatible with Bankof America's policies.

14. Location of Servers. Are web servers on a separate segment of the network from the application
and database servers? If not, explainthe reason this has not been done. At Bank of America's
request, Supplier shall make reasonable efforts to create this separation.

15. Portable Media and Devices. Bank of America's Confidential Information shall not be stored on
any portable media or devices to include notebook/laptop computers, USB storage devices, approved by
Bank of America and security precautions such as encryption of data and remote network connectivity
will be addressed in the Supplier's Information Security Program. Proprietary to Bank of America E-4
vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018

INFORMATION DESTRUCTION REQUIREMENTS
<!-- page 45 -->
Overall Requirements

At Bank of America's direction, Supplier shall destroy all Confidential Information at all locations
where it is stored after it is no longer needed for performance under this Agreement or to satisfy
regulatory requirements. Supplier must have in place or develop information destruction schedules
and processes that meet Bank of America standards and that must be used in all cases when
Confidential Information is no Longer needed. These information destruction requirements are to be
applied to paper, microfiche, disks, disk drives, tape and other destroyable electronic or digital
media containing Confidential Information.

Paper and Other Shreddable Media

Paper and other shreddable media includes paper, microfiche, microfilm, compact disks (CDs) and any
other media that can be shredded. This media must be shredded using shredding techniques or machines
such that Confidential Information in this media is completely destroyed as set forth herein when
Supplier is finished with the Confidential Information contained thereon and it is no longer needed.
This media may be shredded immediately or temporarily stored In a highly secured, locked container.
The media may be shredded at a location other than Supplier's facilities; however it must be
transferred in a highly secured. locked container. Supplier is responsible for supervising the
shredding regardless of where the shredding activity occurs and by whom the shredding is performed.
Confidential Information In this media must be completely destroyed by shredding such that the
results are not readable or useable for any purpose.

Electronic Media

Electronic media includes, but Is not limited to, disk drives, diskettes. tapes, universal serial
bus (USB) and other media that is used for electronic recording and storage. This media is to be
wiped or degaussed using a Bank of America approved wipe or degaussing tool. Wiping uses a program
that repeatedly writes data to the media and thereby destroys the original content. Degaussing
produces an electronic field that electronically eliminates the original data and clears the media.
These techniques must meet Bank of America standards and baselines. The resulting media must be free
from any machine or computer content readable for any purpose.

Certification

These processes must be documented as a procedure by Supplier and should outline the techniques and
methods to be used. The procedure must also indicate when and where Confidential Information is to
be destroyed. Supplier shall keep records of all Confidential Information destruction completed and
provide such records to Bank of America upon demand. Proprietary to Bank of America E-5 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 46 -->
SCHEDULE F Background Checks

BACKGROUND SCREENING GUIDELINES

In accordance with and subject to the terms and conditions of this Agreement, prior to any person
being assigned and beginning work for Bank of America under this Agreement, the following background
screening guidelines must be administered and successfully passed by that person ("Contract
Person"):

1. Search of the Contract Person's social security number to verify the accuracy of the individual's
identity and current and previousaddresses.

2. A criminal background search of all court records in each venue of the Contract Person's current
and previous addresses over thepast ten (10) years.

3. A minimum of at least two (2) confirmed work references prior to assignment at Bank of America.

4. Verification of any post high school education or degrees, i.e. B.A.. B.S., Associate, or
professional certifications.

5. Validate authorization to work in the United States in compliance with I-9 requirements.6. Where
required by state and/or federal law. enroll in and participate in a federal work authorization
program and process employee information according to all applicable E-Verify rules and procedures.

Supplier shall keep copies of background screening documentation and provide certification of their
completion to Bank of America when requested. Proprietary to Bank of America F-1 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
<!-- page 47 -->
SCHEDULE G Recovery

1. Supplier shall establish, maintain and implement per the terms thereof, a Business Continuity
Plan. The Business Continuity Plan must be in place within forty-five (45) calendar days after the
assumption of Service and shall include, but not be limited to, recovery strategy, loss of critical
personnel, documented recovery plans covering all areas of operations necessary to delivering
Supplier's services pursuant to this Agreement, vital records protection and testing plans. The
plans shall provide, without limitation, for off-site backup of critical data files, Confidential
Information, software, documentation, forms and supplies as well as alternative means of
transmitting and processing Confidential Information.

2. The recovery strategy shall provide for recovery after both short and long term disruptions in
facilities, environmental support, workforce availability, and data processing equipment. Although
short term outages can be protected with redundant resources and network diversity, the long term
strategy must allow for total destruction of Supplier's business operations for a period of six (6)
months or longer and set forth a recovery strategy.

3. Supplier's recovery objectives shall not exceed the following during any recovery period:

A. Time to Full Restoration from time of disruption event: 4 hours

B. Maximum Data Loss (stated in hours) from time of disruption event: 24 hours

C. Percentage Reduction of Service levels: 50% during the 24 hour recovery period

In the event of a change, Bank of America agrees to work with Supplier to determine a mutually
agreeable date for Supplier to match the new objectives if necessary.

4. Supplier shall continue to provide service to Bank of America if Bank of America activates its
contingency plan or moves to an interim site to conduct its business, including during tests of Bank
of America's contingency operations plans.

5. Supplier shall furnish contingency recovery plans, contingency exercise and testing schedules
annually or upon request. Supplier shall provide to Bank of America, annually, or upon request,
copies of all contingency exercise final reports and shall Include, but not be limited to, disaster
scenario description, exercise scope and objectives, detailed tasks, exercise issues list and
remediation, and exercise results. If requested, Supplier shall allow Bank of America, at its own
expense, to observe a contingency test.

6. If Supplier provides electronic interchange of data with Bank of America, Supplier shall
participate, if requested, in the recovery exercise of Bank of America to validate recovery
capability.

7. Supplier must provide evidence of capability to meet any applicable regulatory requirements
concerning business continuity.

8. Supplier shall be required to participate, if requested by Bank of America, in recovery testing
of a mutually agreed upon scope and frequency. Proprietary to Bank of America G-1 vTIP2010

Source: CARDLYTICS, INC., S-1, 1/12/2018
