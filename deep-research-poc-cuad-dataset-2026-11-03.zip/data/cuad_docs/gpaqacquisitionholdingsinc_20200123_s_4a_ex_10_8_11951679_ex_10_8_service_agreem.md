<!-- page 1 -->
# SPONSORSHIP AND SERVICES AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2018-12-19 |
| Parties | HOF Village, LLC ("HOFV"); National Football Museum, Inc. d/b/a Pro Football Hall of Fame ("PFHOF"(“PFHOF” and, together with HOFV, the “HOF Entities”); Constellation NewEnergy, Inc., on behalf of itself and its retail affiliates and subsidiaries (collectively, “Constellation”); HOFV and/or PFHOF, and Constellation, (“Party” and, collectively, as the “Parties”) |
| Source | CUAD v1 / GpaqAcquisitionHoldingsInc_20200123_S-4A_EX-10.8_11951679_EX-10.8_Service Agreement |

Exhibit 10.8 EXECUTION COPY CERTAIN INFORMATION HAS BEEN EXCLUDED FROM THIS EXHIBIT BECAUSE IT IS
NOT MATERIAL AND WOULD LIKELY CAUSE COMPETITIVE HARM TO THE REGISTRANT IF PUBLICLY DISCLOSED. [***]
OR [REDACTED] INDICATES THAT INFORMATION HAS BEEN REDACTED. SPONSORSHIP AND SERVICES AGREEMENT This
SPONSORSHIP AND SERVICES AGREEMENT (the "Agreement") is made and entered into as of the 19t h day of
December, 2018, by and among HOF Village, LLC, a Delaware limited liability company ("HOFV"),
National Football Museum, Inc., d/b/a Pro Football Hall of Fame, an Ohio corporation ("PFHOF" and,
together with HOFV, the "HOF Entities") and Constellation NewEnergy, Inc., a Delaware corporation,
on behalf of itself and its retail affiliates and subsidiaries (collectively, "Constellation"). HOFV
and/or PFHOF, on the one hand, and Constellation, on the other hand, are referred to herein as a
"Party" and, collectively, as the "Parties". WITNESSETH: WHEREAS, Constellation desires to provide
to the HOF Entities, and the HOF Entities desire to obtain from Constellation, certain of
Constellation's products and services listed and described in Exhibit A (collectively, the "Products
& Services") for use in connection with the Johnson Controls Hall of Fame Village in Canton, Ohio
(the "Village"); and WHEREAS, Constellation desires to become a sponsor of the Village and to obtain
the rights set forth herein in connection with such sponsorship. NOW, THEREFORE, in consideration of
the promises herein contained, the Parties hereto agree as follows: ARTICLE 1

SUPPLY OF PRODUCTS & SERVICES 1.1 Sale of Products & Services. (a) The HOF Entities shall consult
with Constellation to develop a comprehensive energy strategy with respect to the Products &
Services listing in Exhibit A, which reflects sustainable product solutions, competitive market
pricing (incorporating completion of the Supplier Component Questionnaire in the form of Exhibit B
hereof for the applicable HOF Entity or affiliate), periodic reporting and analytics,
regulatory/market intelligence and infrastructure services and equipment.

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 2 -->
(b) The HOF Entities or their affiliates shall, during the Term (as defined below), purchase from
Constellation, and Constellation shall sell to the HOF Entities and/or their affiliates, as
applicable, such Products & Services as shall be requested by an HOF Entity or its affiliates, in
each case at the applicable Market Prices for such Products & Services and on competitive terms. For
purposes of this Section 1.1(b), (i) the "Market Price" of any Products & Services shall mean the
price for such Products & Services established by Constellation as the competitive market price at
which such Products & Services are to be made available to Constellation's customers with a similar
anticipated load profile within a specified utility service territory. Constellation shall invoice
the applicable HOF Entity or its appropriate affiliate for all Products & Services purchased by such
HOF Entity or its appropriate affiliate pursuant to the applicable Second Level Agreement (as
defined below). In the event that the purchaser of Products & Services pursuant to this Article 1 is
an affiliate of an HOF Entity (but not an HOF Entity), such affiliate shall be subject to
Constellation's credit approval of such affiliate as the contracting entity. In the event that such
affiliate does not meet Constellation's credit requirements (and in the event that such affiliate
still desires to purchase such Products & Services), such affiliate shall provide to Constellation a
surety bond reasonably acceptable to Constellation from a provider rated than A- (or an equivalent
rating from S&P, Moody's, Fitch or AM Best) or better prior to the purchase of such Products &
Services. (c) The Parties agree and acknowledge that neither HOF Entity or any of its respective
affiliates shall be subject to any individual minimum purchase requirement (whether in terms of
price, quantity or any other criteria) under this Agreement with respect to the Products & Services,
but the HOF Entities and their respective affiliates remain subject to the aggregate EME financing
pursuant to Section 2.4 during the Term. (d) All purchases of Products & Services from Constellation
by the HOF Entities or their respective affiliates pursuant to this Agreement shall be made pursuant
to a separate agreement executed between an HOF Entity or affiliate and Constellation which may
include a master retail electricity supply agreement in substantially the form of Exhibit C-1,
master retail natural gas supply agreement in substantially the form of Exhibit C-2, transaction
confirmation in substantially the form of Exhibit C-3 or similar document or agreement (each, a
"Second Level Agreement"). In the event of any conflict or inconsistency between this Agreement and
any Second Level Agreement negotiated after execution of this Agreement and not substantially in the
form attached hereto, this Agreement shall control except to the extent that the Second Level
Agreement expressly refers to this Agreement and states that the specific provision thereof shall be
deemed to amend and supersede a specifically identified provision hereof (in which case such
specific provision of the Second Level Agreement shall control over such specifically identified
provision hereof). 1.2 Title and Risk of Loss. With respect to the Products & Services delivered by
Constellation to an HOF Entity (or its affiliates), title and risk of loss will pass as set forth in
the applicable Second Level Agreements. 1.3 Delivery; Acceptance. With respect to the Products &
Services delivered by Constellation to an HOF Entity (or its affiliates), delivery and acceptance
will be governed by the applicable Second Level Agreements. 1.4 Warranty. Constellation's standard
warranty as stated in the applicable Second Level Agreement (the "Warranty") shall apply to all
purchases of Products & Services made pursuant to this Agreement. Without limiting the Warranty,
Constellation represents, warrants and covenants that all Products & Services delivered in
connection with this Agreement or any Second Level Agreement will be and will have been produced
and/or provided in compliance with all applicable laws.

2

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 3 -->
1.5 Replacement Products & Services. In the event that Constellation shall fail to timely provide to
the HOF Entities or any of their respective affiliates any Products & Services in accordance with
the terms of this Agreement, the default and remedies provisions of the applicable Second Level
Agreement shall govern. 1.6 Impact of Construction Delays. In the event that the issuance of a
certificate of substantial completion for a facility listed on Exhibit D is delayed by a period of 6
months or longer from the last day of the quarter indicated on Exhibit D for that facility, the HOF
Entities will provide prompt written notice to Constellation of such delay, and the Sponsorship Fees
will be reduced, to the extent applicable, as set forth in Exhibit H. Any construction delay shall
not impact the HOF Entities' contractual commitment or timelines as it relates to the obligations
set forth in this Agreement related to EME financing. Any commodity supply agreements with the HOF
Entities related to the delayed facility shall be extended in term by the number of months of the
certificate of substantial completion delay at then current market pricing, except to the extent
that an existing agreement is in place with respect to such delayed facility or supply quantity
purchased. ARTICLE 2

PROVISION OF SERVICES 2.1 Services. (a) Throughout the Term, Constellation shall provide to the HOF
Entities and/or their respective affiliates the Products & Services. All Products & Services shall
be delivered to the account(s) or facilit(y)(ies) identified in the applicable Second Level
Agreement, or performed at the Village or at such other location upon which the Parties may mutually
agree in the applicable Second Level Agreement. (b) All Services included in the Products & Services
shall be performed with at least the level of service, quality and care provided by Constellation to
other third parties receiving the same or substantially similar services. Constellation will
provide, or cause to be provided, all of the Services included in the Products & Services in
compliance in all material respects with all applicable laws, rules, regulations, codes, orders,
treaties and other requirements of federal/national, state/provincial and local governments and
agencies thereof, including but not limited those relating to labor, health, safety and the
environment. 2.2 Exclusivity. Provided that Constellation is not then in breach of its obligations
pursuant to this Agreement, including without limitation Section 2.1 hereof, and provided that
Constellation has available for purchase a product or service which meets the needs of the HOF
Entities at competitive market pricing, (a) neither of the HOF Entities shall purchase, at any time
during the Term, any commodity electricity or gas from any person or entity other than Constellation
and its affiliates and (b) in the event and to the extent mutually agreed by the Parties, neither of
the HOF Entities shall grant or award to any company designated by Constellation (and mutually
agreeable to the HOF Entities) any project which the Parties mutually agree shall not be granted or
awarded to such company. Notwithstanding the foregoing, this Section 2.2 shall not be deemed to
apply to agreements executed prior to the date of this Agreement between the HOF Entities and
Johnson Controls, Inc. or any of its affiliates.

3

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 4 -->
2.3 Costs and Expenses for Services. All up-front costs of providing the services included in the
Products & Services, excluding costs of consumption of energy and energy-related services, shall be
borne by Constellation. Costs of consumption of energy, energy-related services and EME services
provided pursuant to this Agreement shall be borne by the HOF Entities. 2.4 EME Financing. A minimum
of [***] in mutually agreed upon EME financing will be contracted for by the Parties, with a minimum
of [***] of such aggregate amount to be contracted for in each of [***] and [***]. ARTICLE 3

SPONSORSHIP RIGHTS AND BENEFITS 3.1 Sponsorship Rights. Subject to the terms of this Agreement, the
HOF Entities hereby grant to Constellation, for the entire Term (except as otherwise set forth on
Exhibit E), the sponsorship rights, advertising rights and other benefits described on Exhibit E
(the "Sponsorship Rights"). 3.2 Production and Execution of Sponsorship Rights. (a) The design,
layout, content and copy of all advertising signs and/or promotional materials covered by this
Agreement, including any subsequent changes at Constellation's expense, are subject to prior written
approval by the HOF Entities, which approval shall not be unreasonably withheld (provided, however,
that a rejection or denial of approval shall not be considered unreasonable if the HOF Entities, in
their sole discretion, determine that an advertising sign or promotional material covered by this
Agreement is used in any manner that is contrary to public morals, could be deceptive or misleading
or could reflect unfavorably on the good name, goodwill, reputation or image of the HOF Entities or
their respective affiliates). (b) Constellation agrees, at its sole cost and expense, to supply the
HOF Entities with camera-ready artwork required for the production of advertising signs and/or
promotional materials covered by this Agreement and to be produced by or on behalf of the HOF
Entities at least thirty (30) days before such material is scheduled to be produced. Constellation
hereby specifically authorizes the HOF Entities to use such artwork in the production of such
advertising signs and/or promotional materials and represents and warrants that all of its
advertising copy shall comply with all applicable federal, state and local laws pertinent to the
advertising of its products. Constellation represents and warrants that it shall own all
intellectual property and related rights or shall otherwise have the right to use and authorize the
HOF Entities' use of same as it relates to any such artwork and advertising copy.

4

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 5 -->
(c) Constellation shall be solely responsible for all costs and expenses incurred in connection with
the creation and/or production of all advertising signs and/or promotional materials covered by this
Agreement unless otherwise specifically noted on Exhibit E, and such costs and expenses shall be
borne by Constellation in addition to any amounts due under this Agreement. Constellation shall be
invoiced by the HOF Entities for any such materials at the retail cost charged to the HOF Entities
(or either of them) by the supplier, without mark-up. Payment with respect to such invoice will be
due thirty (30) days following receipt by Constellation of such invoice. Constellation shall be
solely responsible for the initial cost of installation of all advertising signs covered by this
Agreement, and Constellation shall be responsible for the cost of installation of each advertising
sign which is changed as a result of a change in the artwork desired by Constellation during the
Term subsequent to its initial installation except in the case of temporary signs planned for
eventual replacement with permanent signs. Constellation shall be invoiced by the HOF Entities for
any installation costs incurred as a result of such advertising signage change at the retail cost
charged to the HOF Entities (or either of them) by the installer, without additional markup. Payment
with respect to such invoice will be due thirty (30) days following receipt. The HOF Entities shall
be solely responsible for the maintenance of the advertising signs covered by this Agreement during
the Term. (d) The HOF Entities have the right to refrain from displaying or illuminating
Constellation's advertising panels in Tom Benson Stadium when required to do so by agreements with
[***] or any other professional sports league or by television network commitments of the
aforementioned leagues. 3.3 Intellectual Property Rights. (a) Reservation of Rights. The HOF
Entities and Constellation acknowledge that each Party owns or has rights in certain names, logos,
trademarks, service marks, copyrights and other intellectual property (the "Marks"), and owns or has
certain merchandising rights in and to its Marks, and all goodwill associated with or symbolized by
its Marks. Subject to the license granted hereunder, each Party reserves all right, title and
interest in and to its Marks and any merchandising rights in and to such Marks, and all goodwill
associated with or symbolized by such Marks. Constellation shall have no right to use the Marks of
the HOF Entities (or either of them), the Village or Johnson Controls, Inc. without the prior
written consent of the HOF Entities (or the applicable HOF Entity), which shall not be unreasonably
withheld, and/or, if applicable, Johnson Controls, Inc. Each Party will be solely responsible for
taking such actions as it deems appropriate to obtain and maintain trademark, service mark, or
copyright registration for its own Marks and each Party will have the exclusive right to enforce its
own Marks, including the right to assert, defend or settle any allegations or claims of
infringement, dilution, misappropriation or similar violation of same. (b) Grant of Rights by HOF
Entities. The HOF Entities grant to Constellation a nonexclusive, nontransferable, royalty-free
license to use the marks set forth on Exhibit F ("HOF Entity Marks") in the United States or online
during the Term solely in connection with (i) Constellation's use and promotion of the designations
set forth on Exhibit E in connection with commercial activations, marketing promotions, commercial
programs and marketing programs related to the Village, (ii) B2B-related and B2C-related marketing
activities approved by the HOF Entities and (iii) as otherwise expressly contemplated by this
Agreement. This license expressly prohibits any pass-through rights or the use of the HOF Entity
Marks by any third party, except (x) to Constellation's subsidiaries and brands for use in a manner
consistent with clauses (i) through (iii) hereof or (y) with the express written consent of the HOF
Entities (or the appropriate HOF Entity). On termination or expiration of this Agreement,
Constellation shall cease all use of the HOF Entity Marks as soon as practicable, but in any event
within thirty (30) days unless the particular media which has been approved requires a longer lead
time, but in no event longer than ninety (90) days.

5

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 6 -->
(c) Quality Control - Marks. (i) Each licensee Party agrees, in connection with its use of any of
the licensor Party's Marks, to comply with any quality-control standards as such licensor Party may
provide hereunder from time to time and which may be revised by the Party owning the Marks from time
to time. Each Party shall take such actions as the Party owning the Marks may reasonably request to
ensure compliance with such quality-control standards in connection with the licensee Party's use of
any of the Marks. (ii) Each licensee Party shall comply with all applicable laws and regulations and
shall obtain all necessary licenses, permits, and governmental approvals, in connection with the
manufacture, promotion, advertising, distribution, and sale of any products and/or services
utilizing any of the licensor Party's Marks. (iii) A licensee Party shall not change in any way or
in any manner the licensor Party's Marks in any use on any products or any advertisements or other
marketing materials therefor, unless any such proposed change is first approved in writing by the
Party owning the Mark(s) in question. Any changes made by a licensee Party to the licensor Party's
Marks will be owned by the applicable Party owning the underlying Marks (which ownership will be
confirmed or otherwise documented by the licensee Party in writing, at the request of the Party
owning the Marks) and, where approved by the Party owning the Marks pursuant to this subsection
(iii), made automatically subject to the terms of this Agreement. (iv) Each licensee Party
acknowledges, understands, and agrees that it shall not perform, do, or cause any act to be done, or
fail to take any action, during or after the Term, or assist any third party in performing, doing,
and/or causing any act to be done, which would in any way or manner be detrimental to, injure or
impair, in any way or to any degree: (A) the licensor Party's Marks (or any of them); (B) any
applications for registration and/or registrations therefor; (C) the goodwill related to the
licensor Party's Marks (or any of them); (D) a licensor Party's federal, state and/or common law and
other rights in or to the licensor Party's Marks; (E) a licensor Party's right, title, interest, and
ownership in and to the licensor Party's Marks; and/or (F) the validity or enforceability of the any
of the foregoing. (d) Grant of Rights by Constellation. Constellation grants to the HOF Entities a
nonexclusive, nontransferable, royalty-free license to use the marks set forth on Exhibit G
("Constellation's Marks") in the United States or online throughout the Term solely in connection
with the Sponsorship Rights, the advertising and promotion of the Village, including any musical,
athletic or other live performance events at the Village, in connection with the name of the Center
for Excellence and/or any Co-Branded Center for Excellence Logos and otherwise as expressly
contemplated by this Agreement. The HOF Entities shall identify Constellation as a sponsor of the
Village and shall have the right to use Constellation's Marks in connection with television, radio
and print advertising of the Village and events held at the Village. This license expressly
prohibits any pass-through rights or the use of Constellation's Marks by any third party, without
the express written consent of Constellation, except where sublicensing of Constellation's Marks is
necessary or desirable to provide for the Sponsorship Rights and/or the advertising and promotion of
the Village. On termination or expiration of this Agreement, the HOF Entities shall cease all use of
the Constellation Marks as soon as practicable, but in any event within thirty (30) days unless the
particular media which has been approved requires a longer lead time, but in no event longer than
one hundred eighty (180) days.

6

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 7 -->
(e) Limitations on Rights. Each Party agrees it will not use the Sponsorship Rights or any license
granted under or in connection with this Agreement in any manner which could reasonably be expected
to (i) infringe upon the intellectual property or other propriety rights or rights of publicity or
privacy of a Party to this Agreement or any third party, (ii) violate any law, statute, regulation,
or ordinance applicable to it, including, without limitation, laws regarding obscenity,
discrimination, unfair competition and false advertising, or (iii) be defamatory or trade libelous.
The HOF Entities may remove any content, Marks, data or other materials from the HOF Entities'
property and refuse to provide the Sponsorship Rights with respect to any content, Marks, data or
other materials which the HOF Entities determine will (x) infringe upon the intellectual property or
other propriety rights or rights of publicity or privacy of a Party to this Agreement or any third
party, (y) violate any law, statute, regulation, or ordinance, including, without limitation, laws
regarding obscenity, discrimination, unfair competition and false advertising, or (z) be defamatory
or trade libelous. 3.4 Sponsorship Fees. For the advertising and other rights described herein,
Constellation shall pay to the HOF Entities total combined sponsorship fees (the "Sponsorship Fees")
and total combined annual activation fund proceeds (the "Annual Activation Fund Proceeds") in the
amounts and on the dates set forth on Exhibit H, in addition to any other amounts required by the
terms of this Agreement. Annual Activation Funds are to be used in each calendar year. Unused funds
are not rolled into future contract years. In the event Constellation fails to pay to the HOF
Entities when due any sum required by this Agreement to be paid, whether pursuant to this Section
3.4 or otherwise, interest shall accrue from the date due on the unpaid amount at the rate of [***]
per month or, if less, the highest rate permitted by law. ARTICLE 4

TERM AND TERMINATION 4.1 Term. The term of this Agreement (the "Term"), unless mutually extended by
written agreement of the Parties or unless sooner terminated as provided herein, shall commence
effective as of the date hereof and shall expire on December 31, 2028.

7

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 8 -->
4.2 Termination; Available Remedies. (a) Right to Terminate for Default. A Party shall be in default
hereunder if any of the following events shall occur (each of such events being an "Event of
Default"): (i) Such Party fails to perform timely any of its material obligations hereunder and such
default shall continue for a period of sixty (60) days following receipt by such Party of written
notice from the other Party specifying such default; provided that, if the default specified in such
notice is curable but of a nature such that it cannot be cured through the exercise of reasonable
diligence within the sixty (60) day cure period, then such sixty (60) day cure period shall be
extended to a period as is reasonable (but in no event more than sixty (60) days, subject to delay
due to force majeure) to cure such default pursuant to a mutually agreed plan of cure, provided that
the non-performing Party has proceeded at all times and is continuing to proceed in a diligent and
reasonable manner to cure; (ii) Such Party becomes insolvent, or takes the benefit of any present or
future insolvency or bankruptcy statute, or makes a general assignment for the benefit of creditors,
or files a voluntary petition in bankruptcy or a petition or answer seeking an arrangement,
reorganization or readjustment of its indebtedness under the Federal bankruptcy laws or under any
law or statute of the United States or any state thereof, or consents to the appointment of a
receiver, trustee or liquidator of all or substantially all of its property; (iii) By court order or
decree such Party is adjudged bankrupt or an order is made approving a petition filed by any of its
creditors or by any of its stockholders or partners seeking its reorganization or the readjustment
of its indebtedness under the Federal bankruptcy laws or under any law or statute of the United
States or any state thereof; (iv) An involuntary petition under any bankruptcy or insolvency law, or
an action under present or future insolvency law or statute, is filed against such Party and is not
dismissed or stayed within sixty (60) days after the filing thereof; or (v) Such Party sells,
conveys, assigns or otherwise transfers all or substantially all of its assets (other than to one of
its affiliates in the case of an HOF Entity) in breach of Section 6.2. If either Party is in default
under this Section 4.2(a) beyond the applicable grace or cure periods, then the other Party shall be
entitled to terminate this Agreement and to seek such other remedies as are described in Section
4.2(d). (b) Right to Terminate for Potential Reputational Damage. Each of the HOF Entities or
Constellation may terminate this Agreement at any time without liability if association with another
Party could, in such Party's reasonable opinion, materially damage its reputation or image or in the
event a Party breaches Section 3.3 hereof, which breach is not cured within sixty (60). days of
receipt of notice of such breach.

8

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 9 -->
(c) Right to Terminate for Failure to Recover Investment. Constellation may terminate this
Agreement, effective as of December 31, 2023, in the event that (i) on or prior to December 1, 2022,
Constellation shall have provided to the HOF Entities written notice of its election to terminate
this Agreement pursuant to this Section 4.2(c) and (ii) during the period commencing on the date
hereof and concluding on December 1, 2022, Constellation shall not have accrued (or been required to
accrue in accordance with U.S. generally accepted accounting principles) an amount of New Business
(as defined below) of not less than the amount of Sponsorship Fees actually paid by Constellation to
the HOF Entities prior to December 1, 2022. [***] Constellation will provide a monthly report to the
HOF Entities as to all New Business contracted from the previous month and a pipeline of all active
and lost opportunities. In January of each calendar year Constellation shall allow, at the written
request and expense of the HOF Entities, the HOF Entities the right to audit during normal business
hours all relevant Constellation records related to New Business generated during the immediately
preceding calendar year. (d) Remedies; Effect of Termination or Expiration. (i) HOF Entity Remedies.
In the event of an Event of Default by Constellation which is not cured within the applicable grace
or cure period, the HOF Entities shall have the right, in their sole discretion, (A) to terminate
this Agreement, (B) to remove immediately any advertising signs and/or promotional materials covered
by this Agreement, and/or (C) to assert any and all other remedies which the HOF Entities may have
under this Agreement and/or pursuant to law and/or equity. (ii) Constellation Remedies. In the event
of an Event of Default by the HOF Entities (or either of them) which is not cured within the
applicable grace or cure period, Constellation shall have the right, in its sole discretion, (A) to
terminate this Agreement and/or (B) to assert any and all other remedies which Constellation may
have under this Agreement and/or pursuant to law and/or equity. (iii) Effect of Termination or
Expiration. In the event of a termination of this Agreement by either Party for any reason, or upon
the expiration of the Term, the Parties agree that all representations and warranties made under
this Agreement and the indemnification provisions set forth in Section 5.2 for any claims, demands,
causes of action, suits or judgments by third parties or losses, liabilities, costs or expenses
which may arise on or before the effective date of termination shall survive. In the event of any
termination of this Agreement, this Agreement shall forthwith become wholly void and of no further
force and effect and there shall be no liability on the part of the HOF Entities (or either of them)
or Constellation, except that the provisions of Section 3.3(a), this Section 4.2(d), Section 5.2
(with respect to the period prior to termination) and Article 6 (other than Section 6.7 and Section
6.9) shall survive any such termination of this Agreement. ARTICLE 5

REPRESENTATIONS AND WARRANTIES; INDEMNIFICATION 5.1 Representations and Warranties. (a) Each of the
HOF Entities and Constellation represents and warrants that: (i) such Party has the requisite right
and authority to enter into this Agreement;

9

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 10 -->
(ii) such Party has duly authorized the execution and delivery of this Agreement, and such execution
and delivery and the performance by such Party of its obligations hereunder does not and will not
violate or cause a breach of any other agreements or obligations to which such Party is a party or
by which such Party is bound, and no approval or other action by any governmental authority or
agency is required in connection herewith; (iii) such Party is duly organized and in good standing
under the laws of its state of organization; (iv) this Agreement is a legal, valid and binding
obligation of such Party and is enforceable against such Party in accordance with its terms, except
to the extent that enforcement thereof may be limited by bankruptcy, insolvency or other similar
laws affecting creditors' rights generally; (v) no consent of any other person or entity is required
for execution by such Party of this Agreement and/or performance by such Party under this Agreement;
and (vi) there is no litigation pending or, to the knowledge of such Party, threatened against such
Party which would prevent or hinder the consummation of the transactions contemplated by this
Agreement or its obligations hereunder or relative to any of the matters which are the subject of
this Agreement. (b) Constellation represents and warrants that, to Constellation's knowledge as of
the date of this Agreement: (i) except with respect to the HOF Entity Marks (other than the name of
the Center for Excellence and each of the Co- Branded Center for Excellence Logos), the use or other
exploitation of any of Constellation's Intellectual Property (as defined below) pursuant to this
Agreement shall not infringe or otherwise violate the rights of any person or entity at any time,
either during the Term or thereafter; (ii) no other person or entity is infringing the rights of
Constellation with respect to Constellation's Marks, or any copyrights and/or other intellectual
property owned by, licensed to or used by Constellation (collectively "Constellation's Intellectual
Property"); and (iii) no claims against Constellation have been asserted in writing by any person or
entity with respect to the ownership, validity, enforceability, misappropriation or use of any of
Constellation's Intellectual Property or challenging or questioning the validity or effectiveness of
Constellation's Intellectual Property.

10

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 11 -->
5.2 Indemnification. (a) By Constellation. Constellation agrees to defend, indemnify and hold
harmless the HOF Entities and their respective shareholders, partners, officers, directors,
employees, successors, assigns, representatives, servants and agents (collectively, the "HOF Entity
Indemnified Persons") from and against, and Constellation waives any claim for contribution or
indemnity against any HOF Entity Indemnified Person with respect to, any and all claims, suits,
actions, claims, monetary damages, losses, liabilities, fines, fees, penalties, costs and expenses
("Losses"), and all reasonable attorneys' fees and expenses, including court costs and expert
witness fees and costs, incurred in connection with Losses and/or enforcement of this Agreement
("Indemnified Losses") resulting from or arising out of (i) the use or display by the HOF Entities
(or either of them) of Constellation's Marks or the Co-Branded Center for Excellence Logos (in each
case, as permitted by this Agreement); (ii) the promotion, advertising, distribution and/or sale of
any Products & Services by Constellation pursuant to any license granted by the HOF Entities (or
either of them) herein; (iii) any breach by Constellation of its representations, warranties and/or
obligations under this Agreement; or (iv) the subject matter, content or copy contained in any
advertising material, promotional material, signage or intellectual property furnished by
Constellation in accordance with this Agreement, including any and all claims for infringement of
trademark rights, copyrights, testimonials, rights of publicity, or the rights to use names,
likenesses, slogans, photographs or patents. Indemnity for Products & Services provided by
Constellation hereunder shall be governed by the terms of the applicable Second Level Agreement(s).
(b) By the HOF Entities. Each HOF Entity agrees, on a several but not joint basis, to defend,
indemnify and hold harmless Constellation, and its shareholders, partners, officers, directors,
employees, successors, assigns, representatives, servants and agents (collectively, the
"Constellation Indemnified Persons") from and against, and the HOF Entities waive any claim for
contribution or indemnity against any Constellation Indemnified Person with respect to, any and all
Indemnified Losses resulting from or arising out of (i) the use or display by Constellation of HOF
Entity Marks as permitted by this Agreement or (ii) any breach by such HOF Entity of its
representations, warranties and/or obligations under this Agreement. (c) Notice of Claim. In the
event that an HOF Entity seeks indemnification on behalf of an HOF Entity Indemnified Person, or
Constellation seeks indemnification on behalf of a Constellation Indemnified Person, such Party
seeking indemnification (the "Indemnified Party") shall give reasonably prompt notice to the
indemnifying Party (the "Indemnifying Party") specifying the facts constituting the basis for such
claim and the amount, to the extent known, of the claim asserted; provided, however, that the right
of a person or entity to be indemnified hereunder shall not be adversely affected by a failure to
give such notice unless, and then only to the extent that, any Indemnifying Party is actually
irrevocably and materially prejudiced thereby. Subject to the terms hereof, the Indemnifying Party
shall pay the amount of any valid claim not more than ten (10) days after the Indemnified Party
provides notice to the Indemnifying Party of such amount.

11

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 12 -->
(d) Right to Contest Claims of Third Persons. If an Indemnified Party is entitled to indemnification
hereunder because of a claim asserted by any claimant (other than a Constellation Indemnified Person
or HOF Entity Indemnified Person) (a "Third Person"), the Indemnified Party shall give the
Indemnifying Party reasonably prompt notice thereof after such assertion is actually known to the
Indemnified Party; provided, however, that the right of a person or entity to be indemnified
hereunder in respect of claims made by a Third Person shall not be adversely affected by a failure
to give such notice unless, and then only to the extent that, an Indemnifying Party is actually
irrevocably and materially prejudiced thereby. The Indemnifying Party shall have the right, upon
written notice to the Indemnified Party, and using counsel reasonably satisfactory to the
Indemnified Party, to investigate, contest or settle the claim alleged by such Third Person (a
"Third Person Claim"), provided that the Indemnifying Party has unconditionally acknowledged to the
Indemnified Party in writing its obligation to indemnify the persons and entities to be indemnified
hereunder with respect to such Third Person Claim and to discharge (and does in fact so discharge)
any cost or expense arising out of such investigation, contest or settlement. The Indemnified Party
may thereafter participate in (but not control) the defense of any such Third Person Claim with its
own counsel at its own expense, unless separate representation is necessary to avoid a conflict of
interest, in which case such representation shall be at the expense of the Indemnifying Party.
Unless and until the Indemnifying Party so acknowledges its obligation to indemnify, the Indemnified
Party shall have the right, at its option, to assume and control defense of the matter and to look
to the Indemnifying Party for the full amount of the reasonable costs of defense. The failure of the
Indemnifying Party to respond in writing to the aforesaid notice of the Indemnified Party with
respect to such Third Person Claim within thirty (30) days after receipt thereof shall be deemed an
irrevocable election not to defend the same. If the Indemnifying Party does not so acknowledge its
obligation to indemnify and assume the defense of any such Third Person Claim, (i) the Indemnified
Party may defend against such claim using counsel of its choice, in such manner as it may reasonably
deem appropriate, including, but not limited to, settling such claim, after giving notice of the
same to the Indemnifying Party, on such terms as the Indemnified Party may reasonably deem
appropriate, and (ii) the Indemnifying Party may participate in (but not control) the defense of
such action, with its own counsel at its own expense. If the Indemnifying Party thereafter seeks to
question the manner in which the Indemnified Party defended such Third Person Claim or the amount or
nature of any such settlement, the Indemnifying Party shall have the burden to prove by clear and
convincing evidence that conduct of the Indemnified Party in the defense and/or settlement of such
Third Person Claim constituted gross negligence or willful misconduct. The Parties shall make
available to each other all relevant information in their possession relating to any such Third
Person Claim and shall cooperate in the defense thereof. ARTICLE 6

MISCELLANEOUS 6.1 Notices. All notices, requests, demands, and other communications required or
permitted under this Agreement shall be in writing and shall be deemed to have been duly given and
made upon being delivered either by courier or overnight delivery, or deposited, postage prepaid,
certified or registered mail, return receipt requested, in the United States Mail to the Party for
whom it is intended, bearing the address shown below for such Party or such other address as may be
designated in writing hereafter by such Party: All such notices to the HOF Entities (or either of
them) shall be sent to: National Football Museum, Inc. d/b/a Pro Football Hall of Fame 2121 George
Halas Drive Northwest Canton, Ohio 44708 Attention: David Baker and Pat Lindesmith

12

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 13 -->
and HOF Village, LLC c/o IRG Realty Advisors 4020 Kinross Lakes Parkway, Suite 200 Richfield, Ohio
44286 Attention: Brian Parisi and Carol Smith with a copy to: Bryan Cave Leighton Paisner LLP One
Metropolitan Square 211 N. Broadway, Suite 3600 St. Louis, Missouri 63102 Attention: Ryan S. Davis
All such notices to Constellation shall be sent to: Constellation NewEnergy, Inc. 1310 Point Street
Baltimore, Maryland 21231 Attention: Kristina Gregory with a copy to: Constellation NewEnergy, Inc.
4 Houston Center 1221 Lamar Street, Suite 750 Houston, Texas 77010 Attention: Nina Jezic 6.2
Assignment. Neither this Agreement nor any right or obligation hereunder may be assigned or
otherwise transferred by either Party without the prior written consent of the other Party;
provided, however, that each HOF Entity may, upon written notice to Constellation but without a
requirement to obtain Constellation's consent, transfer, assign, convey, pledge or encumber, in
whole or in part, any and all of its rights under this Agreement as security in connection with a
loan transaction. Assignment of Second Level Agreements will be governed by the terms of the
respective Second Level Agreement. 6.3 Entire Agreement. This Agreement, together with the Exhibits
attached hereto, which are hereby incorporated herein by this reference, constitutes the entire
agreement with respect to the subject matter hereof between the Parties and shall become a binding
and enforceable agreement among the Parties and their respective successors and permitted assigns
commencing as of the date hereof. No prior verbal or written agreement between the Parties with
respect to the subject matter hereof shall survive the execution of this Agreement.

13

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 14 -->
6.4 Modifications. No amendment or modification of any of the terms and conditions of this Agreement
shall be effective unless such modification is expressed in writing and executed by each of the
Parties. 6.5 Governing Law; Venue. This Agreement shall be governed by and construed in accordance
with the laws of the State of Ohio, without reference to principles of conflicts of law. Any suit or
action filed or otherwise commenced in connection with this Agreement must be filed and litigated in
an appropriate court located in the City of Canton, Ohio (provided, however, that if the suit or
action involves a claim for which federal courts have exclusive jurisdiction, then such suit or
action must be filed in the U.S. District Court for the Northern District of the State of Ohio in
Akron, Ohio), or such other venue as deemed appropriate by the HOF Entities. In the event of a
dispute between an HOF Entity and Constellation regarding their rights and duties hereunder, the
non-prevailing Party in any ensuing litigation shall pay the reasonable attorneys' fees and expenses
of the prevailing Party (including costs of discovery and expert witness fees). 6.6 Subordination.
This Agreement shall in all respects be subordinate to any and all agreements executed prior to the
date of this Agreement between the HOF Entities and Johnson Controls, Inc. or any of its affiliates.
In the event of any conflict between the terms of this Agreement and the terms of any such
agreement, this Agreement shall be deemed superseded by such conflicting provision of such other
agreement. 6.7 Force Majeure. (a) Fire or Other Damage to Village. If the Village is damaged by
fire, earthquake, act of God, the elements or other casualty or is condemned by an authority
exercising the powers of eminent domain or the Village is transferred in lieu of the exercise of
such power so as to render the Village unusable for its intended purpose at any time during the
Term, then the HOF Entities shall have the option, but not the obligation, to repair the damage or
loss. The HOF Entities shall notify Constellation as to whether the HOF Entities shall effect such
repair and restoration within thirty (30) days after the casualty. If the HOF Entities notify
Constellation that the HOF Entities are electing to effect such repairs and restoration, this
Agreement shall continue in full force and effect; provided, however, that the Term shall be
extended by such number of days as equals the length of the period from the date of the event until
such repairs and restoration are complete. If the HOF Entities notify Constellation that the HOF
Entities are electing not to effect such repairs and restoration, then this Agreement and all rights
granted hereunder shall terminate as of the date of such fire or other casualty. (b) Other. Except
as otherwise set forth herein, neither Party shall be liable or responsible for any failure to
perform its obligations hereunder, which failure is caused or brought about in any manner beyond the
control of such Party, including, but not limited to, the breakdown or failure of apparatus,
equipment, or machinery employed in its supply of said services, any temporary stoppage for the
repair, improvement or enlargement thereof, or any other act or condition beyond its reasonable
control, other than such Party's inability to perform payment obligations.

14

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 15 -->
(c) Tolling. In the event that, after the construction and development of the Village has been
substantially completed, the Village is not usable for a period of at least thirty (30) days as a
result of the events described under this Section 6.7 and unless this Agreement shall have been
terminated in accordance with its terms, the Term shall be extended for that period of time (after
substantial completion) which the Village was not usable and the start and end dates of each period
shall be adjusted to reflect the number of days (after substantial completion) in which the Village
was not usable for all purposes of this Agreement, including without limitation the expiration date
of the Term. 6.8 Not a Lease or License of the Village. This Agreement will not constitute a lease
or license of any part of the Village. It will represent solely a contractual obligation of the HOF
Entities to provide to Constellation certain other benefits hereunder. 6.9 Insurance. Constellation
shall, at its own expense, secure and maintain in full force and effect throughout the Term (a)
insurance coverage for defamation, trademark and service mark infringement, unfair competition,
copyright infringement, and infringement of a person's right of publicity and right of privacy from
a carrier with an A.M. Best rating of A10 or better in an amount not less than [***] per occurrence;
and (b) a general liability insurance policy from a carrier with an A.M. Best rating of A10 or
better in an amount not less than [***] in aggregate. The liability limits may be met with any
combination of primary and excess or umbrella insurance policy limits. Constellation shall provide
the HOF Entities with certificates of insurance, naming each HOF Entity as an additional insured,
evidencing the existence of such insurance policies within ten (10) days after execution of this
Agreement. 6.10 Confidentiality. Without limiting the generality of the obligations set forth in the
Mutual Confidentiality Agreement between Constellation and HOFV dated as of April 28, 2018 (which
shall survive in accordance with its terms), the Parties hereto agree to maintain in confidence the
terms and conditions of this Agreement (except with respect to their owners, lenders and advisors,
each of whom is to be made aware of and instructed to comply with this confidentiality provision)
unless the proposed disclosure of specific terms or conditions hereof is authorized in advance by
the other Party or is otherwise required by law. In the event that either Party or any of its
representatives becomes legally compelled to disclose any of the terms or conditions of this
Agreement, such Party shall, to the extent reasonably practicable, provide the other Party with
prompt written notice before such disclosure, sufficient to enable such other Party either to seek a
protective order, at its expense, or another appropriate remedy preventing or prohibiting such
disclosure or to waive compliance with the provisions of this Section, or both. 6.11 Press Releases.
The HOF Entities and Constellation shall consult with each other before issuing any press release or
scheduling any press conference or conference call with media members or other third parties with
respect to this Agreement or the transactions contemplated hereby. The HOF Entities and
Constellation shall mutually agree on the content of any such press release prior to its
publication. 6.12 No Defamation or Disparagement. No Party will make, issue or release any statement
which results in any defamation or disparagement of the Village, the City of Canton, the other
Party, or any team, person, performer or organization involved in events at the Village.

15

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 16 -->
6.13 Independent Contractor. The Parties shall be and act as independent contractors, and under no
circumstances shall this Agreement be construed as one of agency, partnership, joint venture or
employment among the Parties. 6.14 Headings. The headings used in this Agreement are solely for
convenience and shall not affect the meaning or interpretation of the provisions set forth herein.
6.15 Counterparts. This Agreement may be executed in multiple counterparts, and on separate
counterparts, each of which shall be deemed an original, but all of which taken together shall
constitute one and the same instrument. 6.16 Waiver. No action, other than a notice by a Party to
another Party specifically stating that such notice has the effect of waiver, shall constitute a
waiver of any particular breach or default of such other Party. No such waiver notice from a Party
shall waive any other Party's failure to fully comply with any other term, condition, or provision
of this Agreement, irrespective of any knowledge any HOF Entity or Constellation officer, manager,
employee, or agent may have of any breach or default of, or noncompliance with, such other term,
condition, or provision. No waiver of full performance by a Party shall be construed, or operate, as
a waiver of any subsequent default of any of the terms, covenants and conditions of this Agreement.
The payment or acceptance of fees or charges for any period after a default shall not be deemed a
waiver of any right or acceptance of defective performance. 6.17 Severability. If any provision of
this Agreement shall be determined to be contrary to law and unenforceable by any court of law, all
other conditions and provisions of this Agreement shall nevertheless remain in full force and effect
so long as the economic or legal substance of the transactions contemplated hereby are not affected
in any manner materially adverse to any Party. Upon such determination that any term or other
provision is invalid, illegal or incapable of being enforced, the Parties shall negotiate in good
faith to modify this Agreement so as to effect the original intent of the Parties as closely as
possible in an acceptable manner to the end that the transactions contemplated hereby are fulfilled
to the extent possible. 6.18 Third Party Beneficiaries. Except for the HOF Entity Indemnified
Persons and Constellation Indemnified Persons, (i) this Agreement is intended only for the benefit
of the Parties hereto, the affiliates of the HOF Entities and any successors, permitted assigns or
substitutes as expressly provided for in this Agreement, (ii) no other person or entity is intended
to be benefited in any way by this Agreement and (iii) this Agreement shall not be enforceable by
any other person or entity. 6.19 Cost and Expenses. Except as otherwise set forth in this Agreement,
each Party shall bear its own costs and expenses in connection with the preparation, negotiation and
execution of this Agreement and the consummation of the transactions contemplated hereby. 6.20 HOF
Entity Rights and Obligations. The Parties acknowledge and agree that rights vested in the HOF
Entities collectively under this Agreement shall be deemed vested in each HOF Entity and its
affiliates and that obligations of the HOF Entities collectively under this Agreement may be
satisfied by either HOF Entity or any of their affiliates. Without limiting the generality of the
foregoing, while certain rights set forth in this Agreement may be contemplated to be provided by
HOFV and other rights set forth in this Agreement may be contemplated to be provided by PFHOF (or by
both HOF Entities), each of such rights may be provided by HOFV, PFHOF and/or any of their
respective affiliates. [Signature Page Follows]

16

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 17 -->
IN WITNESS WHEREOF, the undersigned have caused this Agreement to be duly executed as of the date
first set forth above. HOFV: HOF VILLAGE, LLC By: /s / Brian Parisi Name: David Baker Title: Chief
Financial Officer PFHOF: NATIONAL FOOTBALL MUSEUM, INC., D/B/A PRO FOOTBALL HALL OF FAME By: /s /
Brian Parisi Name: David Baker Title: President & CEO CONSTELLATION NEWENERGY, INC. By: /s/ Mark P.
Huston Name: Mark P. Huston Title: President & Constellation Retail President / CEO CNE

17

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 18 -->
EXHIBIT A PRODUCTS & SERVICES [Redacted]

Exh. A-1

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 19 -->
EXHIBIT B FORM OF SUPPLIER COMPONENT QUESTIONNAIRE [Redacted]

Exh. B-1

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 20 -->
EXHIBIT C FORMS OF SECOND LEVEL AGREEMENTS [Redacted]

Exh. C-1

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 21 -->
EXHIBIT D CONSTRUCTION SCHEDULE National Youth Football & Sports Complex 4t h Quarter 2019 The
Center for Excellence 3rd Quarter 2020 Hall of Fame Hotel & Conference Center 4t h Quarter 2020 Hall
of Fame Promenade (restaurants, retail & residential) 4t h Quarter 2020 Player Care Center including
Legends Landing/Residential 2nd Quarter 2021 The Center for Athletic Performance & Safety 2nd
Quarter 2021 Hall of Fame Experience (amusement/water park recreation) 2nd Quarter 2021

Exh. D-1

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 22 -->
EXHIBIT E SPONSORSHIP RIGHTS [Redacted]

Exh. E-1

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 23 -->
EXHIBIT F HOF ENTITY MARKS JOHNSON CONTROLS HALL OF FAME VILLAGE PRO FOOTBALL HALL OF FAME
CONSTELLATION CENTER FOR EXCELLENCE All Co-Branded Center for Excellence Logos

Exh. F-1

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 24 -->
EXHIBIT G CONSTELLATION'S MARKS CONSTELLATION

AMERICA'S ENERGY CHOICE

Exh. G-1

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
<!-- page 25 -->
EXHIBIT H SPONSORSHIP FEES AND ACTIVATION FUND PROCEEDS [Redacted] EXH. H-1

Source: GPAQ ACQUISITION HOLDINGS, INC., S-4/A, 1/23/2020
