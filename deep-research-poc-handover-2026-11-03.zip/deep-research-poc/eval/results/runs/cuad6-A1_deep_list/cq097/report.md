# What non-compete clause does the Exclusive Distributor Agreement between WATER NOW, INC...

*Question:* What non-compete clause does the Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc. (dated 2019-11-12) contain? Quote the clause and cite its page.

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Locate the Exclusive Distributor Agreement

The Exclusive Distributor Agreement between WATER NOW, INC. and Hydraspin USA, Inc. dated 2019-11-12 is present in the fixed set. [c3ea62bed0707060 p.4] Section 2.3 Noncircumvention states: "2.3 Noncircumvention. [uncited] Hydraspin certifies, stipulates, and agrees that the Hydraspin will deal exclusively with and through the Distributor in relation to the distribution of the Products in the Territory. [uncited] Hydraspin will not in any way or in any capacity, either directly or indirectly (including without limitation acting by, with or through one or more Persons in which the Hydraspin has an interest and/or with whom Hydraspin has a relationship): except pursuant to an agreement with the Distributor, (a) contact, approach or negotiate with any Customer outside of the Distributor, or (b) contact,…". [c3ea62bed0707060 p.4] This clause is located on page 4. [c3ea62bed0707060 p.4]

## Not established by the evidence

[GAP] No evidence was found for: Establish the exact text of the non-compete clause and the page number on which it appears.

## Verification appendix

Claims: 6 · supported: 3 · partially: 0 · dropped: 0 · gaps: 3 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Identify the non-compete clause

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[c3ea62bed0707060 p.4] |  |
| s1.2 | s1 | gap |  |  | no evidence cited |
| s1.3 | s1 | gap |  |  | no evidence cited |
| s1.4 | s1 | keep | 1.00 | e1→[c3ea62bed0707060 p.4] |  |
| s1.5 | s1 | keep | 1.00 | e1→[c3ea62bed0707060 p.4] |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [c3ea62bed0707060 p.4 L129-141] keep (1.0): "2.3 Noncircumvention. Hydraspin certifies, stipulates, and agrees that the Hydraspin will deal exclusively with and through the Distributor in relation to the distribution of the Products in the Territory. Hydraspin will not in any way or i…"
