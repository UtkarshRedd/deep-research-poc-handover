"""Structured calls for tool-free roles (writer, judge, planner): ask for a JSON object, extract
it from the reply, validate with pydantic, and retry ONCE with the validation error
(small-model rule: flat schemas + one repair). Every call is traced.
"""
from __future__ import annotations

import json
import time
from typing import Any, TypeVar

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage
from pydantic import BaseModel, ValidationError

from .config import DEFAULT, Config
from .llm import ScriptExhausted
from .prompts import load
from .ratelimit import pace
from .trace import Trace

T = TypeVar("T", bound=BaseModel)


def is_rate_limit(e: Exception) -> bool:
    return "RateLimit" in type(e).__name__ or getattr(e, "status_code", None) == 429


def invoke_with_backoff(llm: Any, messages: list[BaseMessage], kwargs: dict, config: Config = DEFAULT,
                        deadline_ts: float | None = None, on_wait=None) -> AIMessage:
    """`llm.invoke` with bounded waits on HTTP 429 (a rate-limited endpoint must delay a call, not
    lose the question). A shared endpoint sheds load per request and a rejected call usually succeeds
    seconds later (NVIDIA Build probe, docs/endpoints.md), so waits start small and double:
    BACKOFF * 2**attempt, capped at BACKOFF_MAX and by the stage deadline. The last error is raised."""
    # pacing applies to real endpoint clients only (keyed by their base URL); scripted/fake models are never paced
    key = getattr(llm, "openai_api_base", None) or getattr(llm, "base_url", None)
    for attempt in range(config.RATE_LIMIT_RETRIES + 1):
        paced = pace(str(key)) if key else 0.0   # client-side pacing (DR_RPM_LIMIT); avoids tripping 429 at all
        if paced > 0 and on_wait:
            on_wait(0, paced)
        try:
            return llm.invoke(messages, **kwargs)
        except Exception as e:
            if not is_rate_limit(e) or attempt >= config.RATE_LIMIT_RETRIES:
                raise
            wait = min(config.RATE_LIMIT_BACKOFF_S * (2 ** attempt), config.RATE_LIMIT_BACKOFF_MAX_S)
            if deadline_ts is not None:
                wait = min(wait, deadline_ts - time.time() - 5.0)
                if wait <= 0:
                    raise
            if on_wait:
                on_wait(attempt + 1, wait)
            time.sleep(wait)
    raise RuntimeError("unreachable")


def extract_json(text: str) -> dict | None:
    """First `{` to last `}`; tolerates prose and code fences around the object."""
    s, e = text.find("{"), text.rfind("}")
    if s < 0 or e <= s:
        return None
    try:
        obj = json.loads(text[s : e + 1])
    except json.JSONDecodeError:
        return None
    return obj if isinstance(obj, dict) else None


class ModelCaller:
    """A chat model plus tracing, for roles that do not use tools."""

    def __init__(self, llm: Any, trace: Trace | None, stage: str, role: str, deadline_ts: float | None = None,
                 config: Config = DEFAULT):
        self.llm, self.trace, self.stage, self.role = llm, trace, stage, role
        self.deadline_ts = deadline_ts
        self.config = config
        self.model_name = getattr(llm, "model_name", None) or getattr(llm, "model", None) or type(llm).__name__
        self.errors: list[str] = []

    def _call_kwargs(self) -> dict | None:
        """Per-call timeout bounded by the stage deadline AND the client's own timeout; None when
        the deadline has passed. (A deadline-sized timeout must never exceed the endpoint timeout:
        one extractor call once ran 110 s against a 90 s client setting.)"""
        if self.deadline_ts is None:
            return {}
        remaining = self.deadline_ts - time.time()
        if remaining <= 1.0:
            return None
        own = getattr(self.llm, "request_timeout", None) or getattr(self.llm, "timeout", None)
        cap = remaining if not isinstance(own, (int, float)) else min(remaining, float(own))
        return {"timeout": max(5.0, cap)}

    def text(self, messages: list[BaseMessage]) -> str | None:
        kwargs = self._call_kwargs()
        if kwargs is None:
            self.errors.append("deadline passed before the call")
            if self.trace:
                self.trace.event("model_skip", stage=self.stage, role=self.role, reason="deadline")
            return None
        t0 = time.perf_counter()

        def _waited(attempt: int, wait: float) -> None:
            if self.trace:
                self.trace.event("rate_limit_wait", stage=self.stage, role=self.role, attempt=attempt, wait_s=round(wait, 1))

        try:
            ai: AIMessage = invoke_with_backoff(self.llm, messages, kwargs, self.config, self.deadline_ts, _waited)
        except ScriptExhausted:
            raise
        except Exception as e:  # noqa: BLE001 - endpoint failure after the client's retries; recorded, never silent
            self.errors.append(f"{type(e).__name__}: {e}"[:300])
            if self.trace:
                self.trace.event("model_error", stage=self.stage, role=self.role, model=self.model_name,
                                 error=self.errors[-1], ms=int((time.perf_counter() - t0) * 1000))
            return None
        if self.trace:
            usage = getattr(ai, "usage_metadata", None) or {}
            self.trace.model_call(self.stage, self.role, self.model_name, usage.get("input_tokens"),
                                  usage.get("output_tokens"), int((time.perf_counter() - t0) * 1000))
        return ai.content if isinstance(ai.content, str) else str(ai.content)

    def json(self, messages: list[BaseMessage], model_cls: type[T]) -> T | None:
        """Validated object or None after one repair attempt."""
        history = list(messages)
        for attempt in range(2):
            text = self.text(history)
            if text is None:
                return None
            obj = extract_json(text)
            error = "no JSON object found in the reply"
            if obj is not None:
                try:
                    return model_cls.model_validate(obj)
                except ValidationError as e:
                    error = "; ".join(f"{'.'.join(str(x) for x in err['loc'])}: {err['msg']}" for err in e.errors()[:3])
            if self.trace:
                self.trace.event("json_invalid", stage=self.stage, role=self.role, attempt=attempt + 1, error=error[:200])
            if attempt == 0:
                history = history + [AIMessage(content=text), HumanMessage(content=load("json_repair", error=error))]
        return None
