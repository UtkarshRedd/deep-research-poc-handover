<!-- page 1 -->
# PRODUCT DEVELOPMENT AND CO-BRANDING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Co-Branding Agreement |
| Agreement Date | 2000-01-10 |
| Parties | INTEGRITY INCORPORATED ("Integrity"); TIME LIFE, INC. d/b/a Time Life Music ("TL") |
| Source | CUAD v1 / IntegrityMediaInc_20010329_10-K405_EX-10.17_2373875_EX-10.17_Co-Branding Agreement |

1 EXHIBIT 10.17

PRODUCT DEVELOPMENT AND CO-BRANDING AGREEMENT

"SONGS 4 WORSHIP SERIES"

EXCLUDING CONFIDENTIAL PORTIONS

/1/ Indicates information which has been redacted pursuant to a request for confidential treatment.

2

INDEX TO THE CONFIDENTIAL PORTIONS

PAGE SECTION LINE(S) ---- ------- ------- 1 1(c) 3, 4, and 5 3 3(a) 4, 5, 10, 11, 12 and 13 4 4(c)
2, 4 and 5 4 4(d) 2, 3, 4 and 5 5 5 2

3

PRODUCT DEVELOPMENT AND CO-BRANDING AGREEMENT "SONGS 4 WORSHIP SERIES"

This Agreement, entered into this the 10th day of January 2000, by and between INTEGRITY
INCORPORATED, a Delaware corporation with principal offices at 1000 Cody Road, Mobile, Alabama
("Integrity") and TIME LIFE, INC., a Delaware corporation d/b/a Time Life Music, with principal
offices located at 2000 Duke Street, Alexandria, Virginia 22314 ("TL"). The parties wish to produce
a series of recorded compilations and companion song books featuring praise and worship repertoires,
which will be co-branded and co-marketed throughout the world. Now, therefore, the parties agree as
follows:

1. Product Concept and Creation.

a. Product description. The product to be created under the series trade name "Songs 4 Worship" will
be a praise and worship continuity series, with each volume in the series containing approximately
22 songs. Each volume will be manufactured in Double CD, Double Cassette, and song book formats,
with standard double jewel boxes, inlays, booklets and j-cards (the "Product"). TL and Integrity
will jointly develop the repertoire, and all repertoire selections are subject to master, mechanical
and print rights clearance in accordance with the financial terms established below. The exact
songbook format, song selection and number of songbook volumes has not yet been determined, and TL
has no obligation to sell any songbooks produced pursuant to this Agreement.

b. Branding. The Product will prominently display the "Songs 4 Worship" logo and trademark (or other
logo as mutually approved) and will also bear the labels of "Time Life Music" and "Integrity Music"
in equal proportion on the exterior of Product packaging. The "Integrity Music" and "Time Life
Music" logos will be used on advertising whenever possible, and it is understood that neither logo
will be used without the other with reference to the Product.

c. Integrity's responsibilities. Integrity will obtain master lease and print agreements with all
third party owners of masters embodied in the Product at its own expense. Mechanical rates will not
exceed [**]/1/ percent ([**]/1/%) of the then-current statutory rate, and Print licenses will not
exceed a prorated portion of [**]/1/ percent ([**]/1/%) of the retail selling price, Integrity will
also manufacture the Product and sell to TL its requirements for resale.

--------------- /1/ Indicates information which has been redacted pursuant to a request for
confidential treatment.

4

Source: INTEGRITY MEDIA INC, 10-K405, 3/29/2001
<!-- page 2 -->
d. TL's responsibilities. At its sole expense, TL will create all artwork for Product covers and
packaging, and furnish Integrity with the same for manufacturing of the Products. All such artwork
will be subject to Integrity's reasonable approval. (Integrity agrees to respond to any request for
approval within five (5) business days after Integrity's receipt of request and samples.) In
addition, TL will pay all mastering expense required in preparation for manufacturing.

e. Shared expenses. The parties agree to share equally in costs of additional products created
(excluding the Product, and song books, which such song books shall be created at Integrity's sole
discretion and expense), by mutual agreement under the "Songs 4 Worship" branding.

2. Marketing and Distribution.

a. Time Life Distribution. TL will hold exclusive worldwide rights to promote and sell the product
through the following distribution channels: Outgoing telemarketing, General Market retail, and
General Market catalogs, and exclusive rights within the United States for Television Direct
response. TL will have Internet and e-commerce rights with respect to its own web site and other
General Market e-commerce. In addition, TL may cross-sell the products to its internal list by
inserts placed in mailings for other TL products and services (but excluding direct mail campaigns
for the Product.) TL may obtain television and/or direct response rights in certain international
territories upon Integrity's agreement.

b. Integrity Distribution. Integrity will hold exclusive worldwide rights to promote and sell the
product to/through the following distribution channels: Christian retail (CBA or Christian
Booksellers Association markets), direct mail (including continuity sales, church sales, digital and
e-commerce sales.) Integrity will have Internet and e-commerce rights with respect to its own web
site and other Christian e-commerce. Integrity shall have the right to license distribution of the
Product through all channels of distribution throughout the remainder of the world.

c. Selling Price. The parties agree that the initial suggested retail selling price for the products
will be $19.95 for CD's, $17.95 for Cassettes, and $19.95 for song books. Any change in the
suggested retail selling price will be mutually agreed by the parties. The parties acknowledge that
they cannot control the prices set by independent retailers and resellers, but agree that sales by
the parties hereto via e-commerce will be the same, and such will be mutually agreed.

2

5

d. Mailing Lists. The parties hereby agree that they will mutually share mailing list data of
purchasers of the products created hereunder in exchange for names of equal value, (i.e., an expired
name for an expired name, active buyer for active buyer.) TL specifically agrees to supply Integrity
with data on former subscribers to its "Songs 4 Life" series, who have subsequently canceled for the
express purpose of soliciting Product continuity subscriptions.

e. Retail release. The, parties will mutually agree upon the date the products shall be released to
retail (General Market and CBA); and it is hereby agreed that such release shall be simultaneous
(i.e., television and direct response will have a period of exclusivity before the products are
available at retail).

3. Product sales to TL.

a. Integrity will, upon receipt of approved purchase orders from TL, sell to TL in non-returnable
box lot quantities, TL's requirements products rates calculated on the following basis (plus
freight). The copyright royalty on recorded products is based on [**]/1/% of the then current
statutory mechanical rate, and on song books, [**]/1/ percent ([**]/1/%) of the retail selling price
(prorated to each copyright holder). Integrity may adjust the prices charged to TL on each volume to
accurately reflect the then-current royalty obligation to all parties, including Integrity.

CD Cassette Song book

Source: INTEGRITY MEDIA INC, 10-K405, 3/29/2001
<!-- page 3 -->
--------- -------- --------- Manufacturing $ [**]/1/ $ [**]/1/ $ [**]/1/ (May be adjusted if actual
costs exceed above amounts)

Master Lease royalty [**]/1/ [**]/1/ -None-

Copyright royalty [**]/1/ [**]/1/ [**]/1/ (Based on 75% of $.075 statutory rate X 22) ----- -----
-----

Approximate Total $ [**]/1/ $ [**]/1/ $ [**]/1/

b. In consideration of the above pricing, TL guarantees to purchase from Integrity a minimum of ten
thousand (10,000) units of each recorded Product during the first thirty-two (32) months of release.
TL's initial order for each recorded Product shall be a minimum of five thousand (5,000) units.

--------------- /1/ Indicates information which has been redacted pursuant to a request for
confidential treatment.

3

6

c. TL may purchase from Integrity limited quantities of the Product for its promotional use, at the
Manufacturing cost set forth in paragraph 3(a) above, provided the quantity of such purchases does
not exceed seven percent (7%) of the total royalty bearing units of such Product title purchased by
TL, TL warrants that any units so purchased, whether or not labeled "promotional only" or cut-out,
will be given away for purposes of promotion of the Products, and will not be sold. If for any
reason, Integrity and TL are subject to lower "free goods" limits by any third party license, the
foregoing shall be adjusted to comply with any such license(s).

4. Royalties payable by Integrity.

a. Integrity will pay and be responsible for all royalties due to owners of the recorded masters,
which such royalties will be inclusive of all performer, artist, producer and other fees.

b. Integrity will pay and be responsible for all royalties to the copyright owners of the
compositions embodied in the recorded masters (or song books), such royalties commonly known as
mechanical royalties or print royalties.

c. On sales of recorded products pursuant to this Agreement (less any returns) Integrity will pay to
TL royalties in the amount of [**]/1/ ($[**]/1/) for each and every unit of the product sold by
Integrity in the United States pursuant to this Agreement, and [**]/1/ the foregoing rate or [**]/1/
percent ([**]/1/%) of Integrity's net receipts, whichever is less, on subject products outside the
United States. For purposes of this Agreement, "net receipts" shall be the amount received by a
party in the United States, after deduction of any exchange fees, commissions, or expenses to
collect.

d. On sales of printed products (song books) pursuant to this Agreement (less any returns) Integrity
will pay to TL royalties in the amount of [**]/1/ ($[**]/1/) for each and every unit of the product
sold by Integrity in the United States pursuant to this Agreement, and [**]/1/ the foregoing rate or
[**]/1/ percent ([**]/1/%) of Integrity's net receipts, whichever is less, on subject products
outside the United States. No royalties will be paid to TL on printed products, until Integrity
shall have recouped its out-of-pocket production costs from such royalties payable to TL pursuant to
this subparagraph.

--------------- /1/ Indicates information which has been redacted pursuant to a request for
confidential treatment.

4

7

5. Royalties payable by TL. On sales of products pursuant to this Agreement (less any returns) TL
will pay to Integrity royalties in the amount of [**]/1/ ($[**]/1/) for each and every unit of the
product sold by it pursuant to this Agreement.

Source: INTEGRITY MEDIA INC, 10-K405, 3/29/2001
<!-- page 4 -->
6. Accountings. Accounting statements and, if applicable, royalty payments for products sold will be
rendered by each party quarterly within sixty (60) days after the expiration of each calendar
quarter. Only products which have been paid or credited to the account of the seller shall be deemed
sold. No royalties will be payable on the sales of any products by any third-party distributors or
licensees until such time as accountings and payment or final credit therefor has been received by
the paying party. Either party, at its sole expense, upon at least thirty (30) days written notice
(and not more than once in respect of any accounting period) will have the right to inspect the
other party's books regarding the obligations hereunder for a period of two (2) years from the date
on which any statement is rendered. Such auditing party must make specific written objection within
such two (2) year period. Thereafter, it will be deemed to have consented to any such statements or
accountings which will then be considered an account stated as between the parties, not subject to
any objection for any reason whatsoever. Provided the objecting party has made timely written
objection, as aforesaid, such party may file an action regarding same within two (2) years and six
(6) months after the applicable statement is rendered, after which time any such action will be
deemed barred.

7. Sound Recording Copyright and Trademark License.

a. Integrity Trademarks. Integrity hereby grants to TL the right to use its "Integrity Music" name
and logo ("the Integrity Trademarks') in connection with the products produced during the Term of
this Agreement for as long as the parties continue to sell and distribute such products at no
additional cost to TL, and in accordance with the terms and conditions contained herein. TL will
honor the notice requirement relating to the Integrity Trademarks and will place such trademarks on
all products and advertising produced hereunder in accordance with the applicable regulations and
Integrity guidelines. Integrity warrants that it has all rights to grant TL the right to use the
Integrity Trademarks and will indemnify and hold TL harmless with respect thereto. TL recognizes
Integrity's title to the Integrity Trademarks and will not at any time do or suffer to be done any
act or thing which will in any way impair Integrity's rights in and to the Integrity Trademarks. It
is understood that TL will not acquire and will not claim any title to the Integrity Trademarks
adverse to Integrity by virtue of this license, or through TL's use of the Integrity Trademarks.

--------------- /1/ Indicates information which has been redacted pursuant to a request for
confidential treatment.

5

8

b. TL Trademarks. TL hereby grants to Integrity the right to use its "TL Music" name and logo ("the
TL Trademarks") in connection with the products produced during the Term of this Agreement for as
long as the parties continue to sell and distribute such products at no additional cost to
Integrity, and in accordance with the terms and conditions contained herein. Integrity will honor
the notice requirement relating to the Integrity Trademarks and will place such trademarks on all
products and advertising produced hereunder in accordance with the applicable regulations and TL
guidelines. TL warrants that it has all rights to grant Integrity the right to use the TL Trademarks
and will indemnify and hold Integrity harmless with respect thereto. Integrity recognizes TL's title
to the TL Trademarks and will not at any time do or suffer to be done any act or thing which will in
any way impair TL's rights in and to the TL Trademarks. It is understood that Integrity will not
acquire and will not claim any title to the TL Trademarks adverse to TL by virtue of this license,
or through Integrity's use of the TL Trademarks.

c. Sound Recording Copyright. The parties hereby agree that the copyright in the Product sound
recording compilation will be jointly registered by Integrity in the names of Integrity and TL.

d. Series Trademark. TL will trademark the series name in joint names of TL and Integrity.

8. Term. This agreement shall commence as of date first above written, and shall Continue through
December 31, 2004 ("the Term"). Thereafter, the parties must mutually agree in writing to extend the
term for additional periods of time.

Source: INTEGRITY MEDIA INC, 10-K405, 3/29/2001
<!-- page 5 -->
9. Warranties; Suspension, Termination

a. Each party hereto warrants, represents, covenants and agrees that it has the right and power to
enter into this Agreement, to grant the rights herein granted by it, and to perform the services
agreed to be performed by it hereunder, and that no materials, ideas or other properties furnished
or designated by it is subject to any restriction whatsoever, or is violative of the rights of any
person, firm or corporation, including, without limitation, contract rights, copyrights and rights
of privacy.

b. If, because of an act of God, inevitable accident, fire, lockout, strike or other labor dispute,
riot or civil commotion, act of public enemy, enactment, rule, order or act of any government or
governmental instrumentality (whether federal, state, local or foreign), failure of technical
facilities, failure or delay of transportation facilities, illness or incapacity of any performer or
producer, or other cause of a similar or

6

9

different nature not reasonably within either party's control, such party is materially hampered in
the recording, manufacture, distribution or sale of phonograph records, or its normal business
operations become commercially impractical, then without limiting its rights, it will have the
option upon notice to suspend the Term of this Agreement for the duration of any such contingency.
In the event of a suspension owing to a "force majeure," which suspension exceeds six (6)
consecutive months, the non-suspending party may terminate this Agreement upon ten (10) days written
notice to other, but only if such "force majeure" does not affect a substantial portion of the
United States recording industry or the suspension is not lifted by the suspending party within ten
(10) days of the receipt of the written notice from the other party.

10. Indemnification. Each party hereto agrees to indemnify the other party and save and hold the
other harmless from any and all claims, causes of action, damages, liabilities, costs, losses, and
expenses (including legal costs and attorneys' fees) arising out of or connected with any claim,
demand or action which is inconsistent with any of the warranties, representations, covenants or
agreements which the indemnifying party has made in this Agreement. Pending the determination and
settlement of any such claim, demand or action, the non-indemnifying party will have the right, at
its election, to withhold payment to you of any monies otherwise payable hereunder, in an amount
reasonably related to that claim, demand or action, and its estimated costs and expenses (including
legal costs and attorneys' fees) in connection therewith.

11. Notices. The respective addresses for each party for all purposes hereunder are set forth on
page 1 hereof, unless and until notice of a different address is received by the party being
notified of a change of address. All notices will be in writing and will either be served by
personal delivery (to an officer of each company), by mail or by telegraph, in each case with all
charges prepaid. Notices will be deemed effective when personally delivered, mailed certified mail
or similar delivery requiring a signature upon delivery, all charges prepaid, except for notice of
change of address, which will be effective only when received by the party notified. A copy of each
notice to Integrity will be simultaneously sent to Business & Legal Affairs, Integrity Incorporated,
1000 Cody Road, Mobile, AL 36695, and a copy of each notice to TL will be simultaneously sent to Law
and Business Affairs, Time Life Music, 2000 Duke Street, Alexandria, VA 22314. The failure to send
courtesy copies of notices will not be deemed a breach of this Agreement nor will it diminish the
effectiveness of such notice.

12. Assignment. Either party may, at its election, assign this Agreement or any of its rights or
delegate any of its obligations hereunder, in whole or in part, to any person, firm or corporation
owning or acquiring all or a substantial portion of its assets, to any person, firm or corporation
that is related to it as an affiliate,

7

10

subsidiary or otherwise, or to any person, firm or corporation into which or with it might merge or
consolidate. In the event of such an

Source: INTEGRITY MEDIA INC, 10-K405, 3/29/2001
<!-- page 6 -->
assignment by either party of its rights to an unrelated third party, the other party shall be given
written notice, then in such event the other party may upon six-months (6-months) written notice
terminate this Agreement.

13. Miscellaneous

a. This Agreement contains the entire understanding of the parties hereto relating to the subject
matter hereof and cannot be changed or terminated except by an instrument signed by the party to be
bound. A waiver by either party of any term or condition of this Agreement in any instance will not
be deemed or construed as a waiver of such term or condition for the future, or of any subsequent
breach thereof. All remedies, rights, undertakings, obligations, and agreements contained in this
Agreement will be cumulative and none of them will be in limitation of any other remedy, right,
undertaking, obligation or agreement of either party. The headings of the paragraphs hereof are for
convenience only and will not be deemed to limit or in any way affect the scope, meaning or intent
of this Agreement or any portion thereof.

b. This Agreement has been entered into in the State of Tennessee, and the validity, interpretation
and legal effect of this Agreement will be governed by the laws of the State of Tennessee applicable
to contracts entered into and performed entirely within the State of Tennessee. The venue for any
controversy or claim arising out of or relating to this Agreement or breach thereof, shall be the
appropriate state and federal courts located in Nashville, Tennessee. Accordingly, each party hereto
consents and submits to the jurisdiction of such courts. The prevailing party in any such dispute
arising hereunder will be entitled to recover from the other party its reasonable attorneys' fees in
connection therewith in addition to the costs thereof.

c. If any part of this Agreement will be determined to be invalid or unenforceable by a court of
competent jurisdiction or by any other legally constituted body having jurisdiction to make such
determination, the remainder of this Agreement will remain in full force and effect.

d. EACH PARTY HAS BEEN REPRESENTED BY INDEPENDENT LEGAL COUNSEL OR HAS HAD THE UNRESTRICTED
OPPORTUNITY TO BE REPRESENTED BY INDEPENDENT LEGAL COUNSEL OF ITS CHOICE FOR PURPOSES OF ADVISING IT
IN CONNECTION WITH THE NEGOTIATION AND EXECUTION OF THIS AGREEMENT. IF EITHER PARTY HAS NOT BEEN

8

11

REPRESENTED BY INDEPENDENT LEGAL COUNSEL OF ITS CHOICE IN CONNECTION WITH THIS AGREEMENT, SUCH PARTY
ACKNOWLEDGES AND AGREES THAT ITS FAILURE TO BE REPRESENTED BY INDEPENDENT LEGAL COUNSEL IN
CONNECTION WITH THIS AGREEMENT WAS DETERMINED SOLELY BY IT.

IN WITNESS WHEREOF, the parties have signed below.

INTEGRITY INCORPORATED TIME LIFE, INC. Tax ID#63-0952549 Tax ID# -----------------------------

By: /s/ Jerry W. Weimer By: /s/ Mark Stevens -----------------------------------
-------------------------------- Jerry W. Weimer, Ex. Vice President Mark Stevens, President Chief
Operating Officer

By: /s/ Don Mayes ----------------------------------- Don Mayes, Director Business and Legal Affairs

9

Source: INTEGRITY MEDIA INC, 10-K405, 3/29/2001
