<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2003-04-04 |
| Parties | Movado Group, Inc. ("Company"); Trustees of the Grinberg Family Trust ("Trust") |
| Source | CUAD v1 / MOVADOGROUPINC_04_30_2003-EX-10.28-ENDORSEMENT AGREEMENT |

EXHIBIT 10.28

MOVADO GROUP, INC.

ENDORSEMENT AGREEMENT

WHEREAS, Movado Group, Inc. (the "Company") and the Trustees of the Grinberg Family Trust (the
"Trust") entered into a Policy Collateral Assignment And Split Dollar Agreement, dated as of
December 5, 1995 (the "Split Dollar Agreement"); and

WHEREAS, pursuant to the Split Dollar Agreement, life insurance protection is provided to the
beneficiaries of the Trust, upon the of the death of the survivor of Gedalio Grinberg ("Executive")
and Sonia Grinberg (Executive and Sonia Grinberg are collectively referred to as the "Insureds")
under a life insurance policy issued to the Trust by the New York Life Insurance Company, Policy No.
45660373 (hereinafter referred to as the "Policy"); and

WHEREAS, pursuant to the Split Dollar Agreement, the Policy is owned by the Trust and collaterally
assigned by it to the Company in order to secure the repayment of the amounts due to the Company in
respect of the Company's loans to the Trust which have been used by the Trust to pay the premiums on
the Policy (such loans totaling $5,186,860 on the date hereof and being represented by a Demand
Note, dated December 5, 1995, between the Company and the Trust (the "Demand Note")); and

WHEREAS, Section XIII of the Split Dollar Agreement provides that it may be amended at any time and
from time to time by a written instrument by the parties thereto; and

WHEREAS, Section 402 of the Sarbanes-Oxley Act of the 2002 (the "Act") prohibits certain public
companies (including the Company) from directly or indirectly making or arranging for an extension
of credit in the form of a personal loan to its executive officers on or after July 30, 2002; and

WHEREAS, Executive and a Trustee and a beneficiary of the Trust are executive officers of the
Company; and

WHEREAS, counsel to the Company has advised the Company that the collateral assignment split-dollar
life insurance arrangement reflected in the Split Dollar Agreement may violate the aforementioned
prohibition on personal loans to executive officers set forth in Section 402 of the Act, in respect
of loans made to the Trust on or after July 30, 2002, although there exists no authority on point
and reasonable arguments may be made to the contrary; and

WHEREAS, in order to best ensure that the Company does not violate the aforementioned prohibition on
personal loans to executive officers set forth in Section 402 of the Act, the parties hereto wish to
(i) amend and restate the Split Dollar Agreement, (ii) rename the amended and restated Split Dollar
Agreement the "Movado Group, Inc. Endorsement Agreement" (hereinafter referred to as the
"Endorsement Agreement" or the "Agreement"), and (iii) transfer the Policy to the Company in partial
repayment of the outstanding $5,186,860 principal balance of the Demand Note, with such repayment
being in an amount equal to the cash

2

surrender value of the Policy on the date hereof ($4,595,591), and with the remaining principal
balance of the Demand Note ($591,269) continuing to be subject to the terms and conditions of the
Demand Note.

NOW, THEREFORE, in consideration for the mutual promises contained herein, the parties hereto agree
to amend and restate the Split Dollar Agreement in its entirety as follows:

1. Transfer of Policy; Partial Repayment of Demand Note. The Trustees of the Trust hereby agree to
promptly execute any and all documents required by the New York Life Insurance Company (the
"Insurer") and the Company to transfer ownership of the Policy from the Trust to the Company in
exchange for the Company's agreement to promptly execute any and all documents required to reflect
the partial repayment of the outstanding principal balance of the Demand Note, as described in the
recitals above.

2. Ownership of Policy. Except as otherwise provided in this Agreement, the Company shall be the
sole and exclusive owner of the Policy.

3. Surrender, Withdrawals, Loans; Etc. Other than as specifically allowed herein, the Company shall
not borrow from, hypothecate, withdraw cash value from, surrender in whole or in part, cancel, or in
any other manner encumber the Policy without the prior written consent of the Trustees of the Trust.
Unless the Company and the Trustees of the Trust otherwise agree, in the event there is a complete
or partial surrender or cancellation of the Policy, the proceeds payable as a result of the
surrender, cancellation, withdrawal or loan shall be paid to the Company in an amount equal to the
aggregate premiums paid under the Policy since inception, and any remaining proceeds shall be
payable to the Trust.

4. Investment of Cash Values. If the Policy provides the policy owner with a choice of investment
funds for the Policy cash values, the Company shall select the funds in which to invest such cash
values.

5. Payment of Premiums. Subject to the terms of this Agreement, the Company agrees to pay premiums
on the Policy as provided under the Policy. In
<!-- page 2 -->
the event this Agreement is terminated in accordance with terms of Section 11, the Company shall not
be liable for any premiums owed on the Policy after the date of termination.

6. Payment of Death Benefits. Upon the death of the survivor of the Insureds, the death benefit
under the Policy (including any interest payable under the Policy in respect of such death benefit
for the period from the date of death of such survivor until the payment of the death benefit) shall
be divided as follows:

(a) The Company shall be entitled to receive an amount equal to the aggregate premiums paid under
the Policy since inception less the amount of the then outstanding principal balance of the Demand
Note (the "Company Death Benefit"). (If the Policy provides for a death benefit equal to the sum of
the face amount of the Policy and any cash account or accumulation value, the Company Death Benefit
shall first be paid from the cash account or accumulation value portion of the death benefit.)

3

(b) The Trust shall be entitled to receive the excess, if any, of the Policy's death benefit over
the Company Death Benefit.

(c) If any interest is payable under the Policy in respect of the death benefit for the period from
the date of death of such survivor until the payment of the death benefit, the Company and the Trust
shall share in such interest in proportion that their respective share of such death benefit (as
determined under Section 6(a) and (b) hereof) bears to the total death benefit, excluding any
interest thereon.

7. Company Default. In the event of a "Company Default" (as defined below), the Trust shall have the
right to require the Company to cure the Company Default by notifying the Company in writing within
sixty (60) days after its receipt of notice of a Company Default, or if later, within thirty (30)
days after a Trustee becomes aware of the Company Default. If the Company fails to cure the Company
Default within sixty (60) days after being notified by the Trust of the Company Default, the Trust
shall have the right to require the Company to transfer its interest in the Policy to the Trust. The
Trust may exercise this right by notifying the Company, in writing, within sixty (60) days after the
Company Default occurs. Upon receipt of such notice, the Company shall immediately transfer
ownership of the Policy to the Trust and the Company shall thereafter have no rights with respect to
the Policy. The Trust's failure to exercise its rights under this Section 7 shall not be deemed to
release the Company from any of its obligations under this Agreement, and shall not preclude the
Trust from seeking other remedies with respect to the Company Default. For purposes of this
Agreement, a "Company Default" shall be deemed to have occurred with respect to the Policy if the
Company fails to pay a premium on the Policy as required under the terms of this Agreement within
sixty (60) days after the due date for such premium, or if the Company processes or attempts to
process a policy loan, or a complete or partial surrender, or a cash value withdrawal without prior
written approval from the Trustees of the Trust. The Company shall notify the Trustees of the Trust
within five (5) business days of any event which constitutes a Company Default.

8. Notice. All notices hereunder shall be in writing and sent by certified mail with postage
prepaid. Any notice to the Company shall be addressed to the attention of the General Counsel, with
a copy to the Chief Executive Officer, at the principal office of the Company at 650 From Road;
Paramus, New Jersey 07652. Any notice to the Trustees of the Trust shall be addressed to the
Trustees of the Trust, 115 Central Park West, Apt. 4D, New York, New York 10023, with a copy to
Andrew W. Regan, Esq. c/o Shearman & Sterling, 599 Lexington Avenue, New York, New York 10022. Any
party may change his or its address by giving written notice of such change to the other party
pursuant to this Section 8.

9. Entire Agreement. This Agreement is the entire agreement between the Company and the Trust with
respect to the subject matter hereof and contains all of the agreements, whether written, oral,
express or implied, between the Company and the Trust and supersedes any other agreement by and
between the Company and the Trust except to the extent specifically set forth herein.

10. Amendment. The Company may amend or modify this Agreement at any time, but any such amendment or
modification that would adversely affect the rights of the Trust

4

under this Agreement shall not be effective without the prior written consent of the Trustees of the
Trust.

11. Termination. Notwithstanding any provisions of this Agreement to the contrary, this Agreement
shall terminate upon the Trust's payment to the Company of the sum of the aggregate amount of the
premiums paid under the Policy since inception (which amount includes the outstanding principal
balance of the Demand Note). In the event this Agreement is terminated in accordance with this
Section 11, the Company shall transfer the Policy to the Trust as soon as is administratively
practicable. Payment of the foregoing amounts by the Trust to the Company will be full repayment of
the Demand Note.

12. Governing Law. Except to the extent preempted by Employee Retirement Income Security Act of
1974, as amended ("ERISA"), all rights hereunder shall be governed by and construed in accordance
with the laws of the State of New York without regard to its rules governing conflicts of laws, or
the rules of any other jurisdiction which would cause the laws of any
<!-- page 3 -->
jurisdiction other than the State of New York to apply. If this Agreement is determined to be
subject to ERISA, it is intended to be exempt from the reporting and disclosure provisions of ERISA
pursuant to Section 104(a)(3) of ERISA and Department of Labor Regulation Section 2520.104-24.

13. Administration. If this Agreement is determined to be subject to ERISA, it shall be administered
by the Company, or its designee (the "Plan Administrator"), which shall be the "named fiduciary" of
this Agreement for purposes of ERISA. The Plan Administrator shall have the authority to make,
amend, interpret, and enforce all rules and regulations for the administration of this Agreement and
decide or resolve any and all questions, including interpretations of the Agreement, as may arise in
connection with this Agreement. In the administration of this Agreement, the Plan Administrator from
time to time may employ agents and delegate to them or to others (including executives of the
Company) such administrative duties as it sees fit. The Plan Administrator from time to time may
consult with counsel, who may be counsel to the Company. The decision or action of the Plan
Administrator (or its designee) with respect to any question arising out of or in connection with
the administration, interpretation and application of this Agreement shall be final and conclusive
and binding upon all persons having any interest in this Agreement. The Company shall indemnify and
hold harmless the Plan Administrator and any Company employee to whom administrative duties under
this Agreement are delegated, against any and all claims, loss, damage, expense or liability arising
from any action or failure to act with respect to this Agreement, except in the case of gross
negligence or willful misconduct by the Plan Administrator or any such employee.

14. Claims Procedures. If this Agreement is subject to ERISA, any controversy or claim arising out
of or relating to this Agreement shall be filed with the Plan Administrator or its designee which
shall make all determinations concerning such claim. Any decision by the Plan Administrator denying
such claim shall be in writing and shall be delivered to all parties in interest in accordance with
the notice provisions of Section 8 hereof. Such decision shall set forth the reasons for denial in
plain language. Pertinent provisions of the Agreement shall be cited and, where appropriate, an
explanation as to how the claimant can perfect the claim will be provided. This notice of denial of
benefits will be provided within ninety (90) days of the Plan Administrator's receipt of the claim
for benefits. If the Plan

5

Administrator fails to notify the claimant of its decision regarding the claim, the claim shall be
considered denied, and the claimant then shall be permitted to proceed with an appeal as provided
for in this Section 14.

A claimant who has been completely or partially denied a benefit shall be entitled to appeal this
denial of his or her claim by filing a written statement of his or her position with the Plan
Administrator no later than sixty (60) days after receipt of the written notification of such
denial. The Plan Administrator shall schedule an opportunity for a full and fair review of the issue
within thirty (30) days of receipt of the appeal. The decision on review shall set forth specific
reasons for the decision, and shall cite specific references to the pertinent provisions of the
Agreement on which the decision is based.

Following the review of any additional information submitted by the claimant, either through the
hearing process or otherwise, the Plan Administrator shall make its decision regarding the merits of
the denied claim within sixty (60) days following receipt of the request for review (or within 120
days after such receipt, in a case where there are special circumstances requiring extension of time
for reviewing the appealed claim). The Plan Administrator shall deliver the decision to the claimant
in writing. If an extension of time for reviewing the appealed claim is required because of special
circumstances, written notice of the extension shall be furnished to the claimant prior to the
commencement of the extension. If the decision on review is not furnished within the prescribed
time, the claim shall be deemed denied on review.

15. Successors. The terms and conditions of this Agreement shall inure to the benefit of and bind
the Company, the Trust and their respective successors, assignees and representatives.

16. Gender. The masculine pronoun includes the feminine and the singular includes the plural where
appropriate for valid construction.

17. No Contract of Employment. This Agreement shall not be deemed to constitute a contract of
employment between Executive and the Company, nor shall any provision restrict the right of the
Company to discharge Executive, or to restrict the right of Executive to terminate employment with
the Company.

18. Counterparts. This Agreement may be executed by one or more of the parties hereto on any number
of separate counterparts and all such counterparts shall be deemed to be one and the same
instrument. Each party hereto confirms that any facsimile copy of such party's executed counterpart
of this Agreement (or its signature page thereof) shall be deemed to

6

be an executed original thereof.

IN WITNESS WHEREOF, the parties hereto have executed this Agreement as of this 4th day of April,
2003.

MOVADO GROUP, INC.
<!-- page 4 -->
By: /s/ Timothy F. Michno ------------------------------ Name: Timothy F. Michno Title: General
Counsel

THE GRINBERG FAMILY TRUST

By: /s/ Efraim Grinberg ------------------------------------ Efraim Grinberg, Trustee

By: /s/ Miriam G. Phalen ------------------------------------ Miriam G. Phalen, Trustee

By: /s/ Alexander Grinberg ------------------------------------ Alexander Grinberg, Trustee
