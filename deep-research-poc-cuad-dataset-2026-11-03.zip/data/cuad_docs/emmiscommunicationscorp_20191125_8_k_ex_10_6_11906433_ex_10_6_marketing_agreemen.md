<!-- page 1 -->
# LOCAL PROGRAMMING AND MARKETING AGREEMENT (WQHT HD2)
| Field | Value |
|---|---|
| Document Type | Marketing Agreement |
| Agreement Date | 2019-11-25 |
| Parties | MediaCo Holding Inc. (“Licensee”); WBLS-WLIB LLC (“Programmer”) |
| Source | CUAD v1 / EmmisCommunicationsCorp_20191125_8-K_EX-10.6_11906433_EX-10.6_Marketing Agreement |

Exhibit 10.6 LOCAL PROGRAMMING AND MARKETING AGREEMENT (WQHT HD2)

THIS LOCAL PROGRAMMING AND MARKETING AGREEMENT (this "Agreement") is made as of November 25, 2019 by
and between MediaCo Holding Inc., an Indiana corporation (the "Licensee"), and WBLS-WLIB LLC, an
Indiana limited liability company ("Programmer"). Recitals

A. Licensee owns and operates the following radio station (the "Station") pursuant to licenses
issued by the Federal Communications Commission ("FCC"): WQHT-FM, New York, NY (Facility ID No.
19615). The Station has the capability to transmit an in-band, on-channel ("IBOC") digital broadcast
signal.

B. Programmer desires to have radio broadcast station WLIB-AM, New York, NY (Facility ID No. 28204)
("WLIB") rebroadcast on the Station's HD-2 channel (the "HD2 Channel") at a bandwidth of 24kbps.

C. Licensee has agreed to make available to Programmer airtime on the HD2 Channel and accept for
rebroadcast the programs of WLIB on the terms and conditions set forth in this Agreement.

Agreement

NOW, THEREFORE, taking the foregoing recitals into account, and in consideration of the mutual
covenants and agreements contained herein and for other good and valuable consideration, the receipt
and sufficiency of which are hereby acknowledged, the parties, intending to be legally bound, agree
as follows:

1. Agreement Term. The term of this Agreement (the "Term") will begin on the date hereof (the
"Commencement Date"), and will continue until the earlier of (i) December 31, 2022, (ii) the
termination or expiration of the Studio Lease (defined below), (iii) election to terminate and
notice thereof given by Programmer to Licensee, and (iv) mutual written consent of Licensee and
Programmer (the "Term"), unless extended or earlier terminated pursuant to Section 11 hereof. The
term "Studio Lease" means that certain Lease dated as of February 23, 1996 of certain real estate
located on the 7th Floor of an office building located at 395 Hudson St., New York, New York.

2. Programmer's Use of Airtime and Provision of Programming. During the Term, and subject in all
respects to Section 6 hereof, Programmer shall be entitled to simulcast the programming of WLIB (the
"WLIB Programs") on the HD2 Channel, excluding the period from 6:00 a.m. to 8:00 a.m. each Sunday
morning, on the terms specified below, and shall transmit to Licensee the WLIB Programs for
broadcast on the HD2 Channel twenty-four (24) hours per day, seven (7) days per week, excluding the
period from 6:00 a.m. to 8:00 a.m. each Sunday morning (the "Broadcasting Period"). Programmer will
transmit, at its own cost, the WLIB Programs to the Station's transmitting facilities via a mode of
transmission (e.g., satellite facilities, microwave facilities and/or telephone lines) that will
ensure that the WLIB Programs meet technical and quality standards at least equal to those of the
HD2 Channel's broadcasts prior to commencement of the Term.

Source: EMMIS COMMUNICATIONS CORP, 8-K, 11/25/2019
<!-- page 2 -->
3. Broadcasting Obligations. During the Term, Licensee shall broadcast on the HD2 Channel the WLIB
Programs delivered by Programmer during the Broadcasting Period specified in Section 2 above,
subject to the provisions of Section 6 below.

4. Advertising Sales. Programmer shall not separately sell advertising time on the HD2 Channel but
may market the WLIB Programs as being rebroadcast on the HD2 Channel.

5. Term Payments. No payment is due from Programmer to Licensee for broadcast of the Programs
pursuant to this Agreement.

6. Operation, Ownership and Control of the Station. Notwithstanding anything to the contrary in this
Agreement Licensee will have full authority, power and control over the operation of the Station,
including the HD2 Channel, and over all persons working at the Station's facilities during the Term.
Licensee will bear the responsibility for the Station's compliance with all applicable provisions of
the rules and policies of the FCC. Nothing contained herein shall prevent Licensee from (a)
rejecting or refusing programs which Licensee believes to be contrary to the public interest, or (b)
substituting programs which Licensee believes to be of greater local or national importance or which
are designed to address the problems, needs and interests of the local communities. Licensee
reserves the right to refuse to broadcast any WLIB Program containing matter which violates any
right of any third party or which constitutes a personal attack. Licensee also reserves the right to
refuse to broadcast any WLIB Program which does not meet the requirements of the rules, regulations,
and policies of the FCC or the regulations and restrictions set forth in Section 8. Licensee further
reserves the right to preempt any WLIB Program in the event of a local, state, or national
emergency. Licensee agrees that its right of preemption shall not be exercised in an arbitrary or
unreasonable manner, or for commercial advantage. Licensee reserves the right to delete any
commercial announcements that do not comply with the requirements of the FCC's sponsorship
identification policy. Programmer will immediately serve Licensee with notice and a copy of any
letters of complaint it receives concerning any WLIB Program for Licensee review. Licensee's rights
under this Section 6 and its decisions regarding whether to exercise such rights in any particular
circumstance shall not in any way affect Programmer's obligations under Section 12 hereunder.
Pursuant to Note 2 to Section 73.3555 of the FCC's rules, Licensee certifies that it maintains
ultimate control over WQHT(FM)'s finances, personnel and programming, and Programmer certifies that
this Agreement complies with Section 73.3555(b) of the FCC's rules.

7. Music Licenses. During the Term, Programmer will obtain and maintain in full force and effect in
its own name all necessary or appropriate music licenses with respect to the WLIB Programs
rebroadcast on the HD2 Channel. Programmer represents and warrants to Licensee that Programmer has
all rights in and to the WLIB Programs necessary or appropriate to rebroadcast such WLIB Programs on
the HD2 Channel.

- 2 -

Source: EMMIS COMMUNICATIONS CORP, 8-K, 11/25/2019
<!-- page 3 -->
8. Programs.

8.1 Production of the Programs. Programmer agrees that the contents of the WLIB Programs it
transmits to Licensee shall conform to all FCC rules, regulations and policies. Programmer shall
provide only the WLIB Programs, and not any other programming, for broadcast on the HD2 Channel.

8.2 Political Time. Licensee shall oversee and take ultimate responsibility with respect to the
provision of equal opportunities, lowest unit charge, and reasonable access to political candidates,
and compliance with the political broadcast rules of the FCC. During the Term, Programmer shall
cooperate with Licensee as Licensee complies with its political broadcast responsibilities, and
shall supply such information promptly to Licensee as may be necessary to comply with the political
advertising time record keeping, reasonable access, and lowest unit charge requirements of federal
law. Programmer shall release advertising availabilities to Licensee during the Broadcasting Period
as necessary to permit Licensee to comply with the political broadcast rules of the FCC and the
Communications Act of 1934, as amended.

9. Expenses. During the Term, Programmer will be responsible for (i) the salaries, taxes, insurance
and related costs for all personnel used in the production of the WLIB Programs, (ii) all other
costs associated with the production of the WLIB Programs supplied to Licensee, and (iii) the costs
of delivering the WLIB Programs to Licensee.

10. Call Signs. During the Term, Licensee will retain all rights to the call letters of the Station
or any other call letters which may be assigned by the FCC for use by the Station. Programmer shall
include in the WLIB Programs it delivers for broadcast an announcement at the beginning of each hour
of such WLIB Programs to identify such call letters, as well as any other announcements required by
the rules and regulations of the FCC. Programmer is specifically authorized to use such call letters
in its WLIB Programs and in any promotional material, in any media, used to promote the WLIB
Programs.

11. Events of Default; Termination.

11.1 Programmer's Events of Default. The occurrence of any of the following will be deemed an Event
of Default by Programmer under this Agreement: (a) Programmer fails to observe or perform its
obligations contained in this Agreement in any material respect; or (b) Programmer breaches the
representations and warranties made by it under this Agreement in any material respect.

11.2 Licensee Events of Default. The occurrence of the following will be deemed an Event of Default
by Licensee under this Agreement: (a) Licensee fails to observe or perform its obligations contained
in this Agreement in any material respect; or (b) Licensee breaches the representations and
warranties made by it under this Agreement in any material respect.

11.3 Cure Period. Notwithstanding the foregoing, any Event of Default will not be deemed to have
occurred until fifteen (15) days after the non-defaulting party has provided the defaulting party
with written notice specifying the Event of Default and such Event of Default remains uncured.

- 3 -

Source: EMMIS COMMUNICATIONS CORP, 8-K, 11/25/2019
<!-- page 4 -->
11.4 Termination in the Event of Default. Upon the occurrence of an Event of Default, and in the
absence of a timely cure pursuant to Section 11.3, the non-defaulting party may terminate this
Agreement, effective immediately upon written notice to the defaulting party.

11.5 Cooperation Upon Termination. If this Agreement is terminated for any reason, the parties agree
to cooperate with one another and to take all actions necessary to rescind this Agreement and return
the parties to the status quo ante.

12. Indemnification. Programmer shall indemnify and hold Licensee harmless against any and all
liability arising from Programmer's use of Licensee's facilities, if any, or from the broadcast of
the WLIB Programs on the HD2 Channel, including without limitation for libel, slander, illegal
competition or trade practice, infringement of trademarks, trade names, or program titles, violation
of rights of privacy, and infringement of copyrights and proprietary rights or any other violation
of third party rights or FCC rules or other applicable law. The obligations under this Section shall
survive any termination of this Agreement.

13. Authority. Programmer and Licensee each represent and warrant to the other that (i) it has the
power and authority to enter into this Agreement and to consummate the transactions contemplated
hereby, (ii) it is in good standing in the jurisdiction of its organization and is qualified to do
business in all jurisdictions where the nature of its business requires such qualification, (iii) it
has duly authorized this Agreement, and this Agreement is binding upon it, and (iv) the execution,
delivery, and performance by it of this Agreement does not conflict with, result in a breach of, or
constitute a default or ground for termination under any agreement to which it is a party or by
which it is bound.

14. Modification and Waiver; Remedies Cumulative. No modification of any provision of this Agreement
will be effective unless in writing and signed by all parties. No failure or delay on the part of
Programmer or Licensee in exercising any right or power under this Agreement will operate as a
waiver of such right or power, nor will any single or partial exercise of any such right or power or
the exercise of any other right or power preclude any other or further exercise thereof or the
exercise of any other right, power or privilege hereunder. Except as otherwise provided in this
Agreement, the rights and remedies provided in this Agreement are cumulative and are not exclusive
of any other rights or remedies which a party may otherwise have.

15. Assignability; No Third-Party Rights. Programmer may not assign this Agreement without the prior
written consent of Licensee, which shall not be unreasonably withheld, conditioned, or delayed. No
transfer or assignment shall relieve Programmer of any obligation or liability under this Agreement.
The covenants, conditions and provisions hereof are and shall be for the exclusive benefit of the
parties hereto and their successors and permitted assigns, and nothing herein, express or implied,
is intended or shall be construed to confer upon or to give any person or entity other than the
parties hereto and their successors and permitted assigns any right, remedy or claim, legal or
equitable, under or by reason of this Agreement.

16. Construction. This Agreement will be construed in accordance with the laws of the State of
Indiana without regard to principles of conflicts of laws.

17. Counterpart Signatures. This Agreement may be signed in one or more counterparts, each of which
will be deemed a duplicate original.

- 4 -

Source: EMMIS COMMUNICATIONS CORP, 8-K, 11/25/2019
<!-- page 5 -->
18. Notices. Any notice pursuant to this Agreement shall be in writing and shall be deemed delivered
on the date of personal delivery or confirmed delivery by a nationally-recognized overnight courier
service, or on the third day after prepaid mailing by certified U.S. mail, return receipt requested,
and shall be addressed as follows (or to such other address as any party may request by written
notice): If to Licensee, then to: MediaCo Holding Inc. C/O SG Broadcasting LLC 767 Fifth Ave, 12th
Floor New York, NY 10153 Attention: Gail Steiner, General Counsel Facsimile: (212) 257-4709 with a
copy (which shall not Morgan, Lewis & Bockius LLP constitute notice) to: 1701 Market Street
Philadelphia, PA 19103 Attention: Justin W. Chairman Facsimile: (215) 963-5001 if to Programmer,
then to: WBLS-WLIB LLC c/o EMMIS Communications Corporation One EMMIS Plaza 40 Monument Circle,
Suite 700 Indianapolis, IN 46204 Attention: J. Scott Enright, General Counsel with a copy (which
shall not Edinger Associates PLLC constitute notice) to: 1725 I Street, N.W., Suite 300 Washington,
D.C. 20006 Attention: Brook Edinger 19. Entire Agreement. This Agreement embodies the entire
agreement, and supersedes all prior oral or written understandings, between the parties with respect
to the subject matter of this Agreement.

- 5 -

Source: EMMIS COMMUNICATIONS CORP, 8-K, 11/25/2019
<!-- page 6 -->
20. Relationship of Parties. Neither the Programmer nor Licensee will be deemed to be the agent,
partner, or representative of the other party to this Agreement, and neither party is authorized to
bind the other to any contract, agreement, or understanding.

21. Force Majeure and Facilities Upgrades. The failure of either party hereto to comply with its
obligations under this Agreement due to (i) facility maintenance, repair or modification at a
transmitter site or to move a transmitter site in response to FCC authorization of an improvement to
or modification of the Station's operating parameters, or (ii) with respect to a failure to comply
with an obligation under this Agreement, acts of God, strikes or threats thereof or a force majeure
event or due to causes beyond such party's reasonable control, will not constitute an Event of
Default under Section 11 of this Agreement and neither party will be liable to the other party
therefor. Programmer and Licensee each agrees to exercise its commercially reasonable efforts to
remedy the conditions described in parts "(i)" and "(ii)" of this Section as soon as practicable.

22. Subject to Laws; Partial Invalidity. The obligations of the parties under this Agreement are
subject to the rules, regulations and policies of the FCC and all other applicable laws. The parties
agree that Licensee may file a copy of this Agreement with the FCC. If any provision in this
Agreement is held to be invalid, illegal, or unenforceable, so long as no party is deprived of the
benefits of this Agreement in any material respect, such invalidity, illegality, or unenforceability
will not affect any other provision of this Agreement, and this Agreement will be construed as if it
did not contain such invalid, illegal, or unenforceable provision.

23. Headings. The headings of the various provisions of this Agreement are included for convenience
only, and no such heading shall in any way affect or alter the meaning of any provision.

24. Successors and Assigns. Subject to the provisions of Section 15 above, this Agreement shall be
binding and inure to the benefit of Licensee and its successors and assigns and Programmer and its
permitted successors and assigns.

[SIGNATURE PAGE FOLLOWS]

- 6 -

Source: EMMIS COMMUNICATIONS CORP, 8-K, 11/25/2019
<!-- page 7 -->
SIGNATURE PAGE TO LOCAL PROGRAMMING AND MARKETING AGREEMENT

IN WITNESS WHEREOF, the parties have duly executed this Agreement as of the date first above
written. LICENSEE: MEDIACO HOLDING INC. By: /s/ J. Scott Enright Name: J. Scott Enright Title:
Executive Vice President, General Counsel & Secretary PROGRAMMER: WBLS-WLIB LLC By: /s/ J. Scott
Enright Name: J. Scott Enright Title: Executive Vice President, General Counsel & Secretary

Source: EMMIS COMMUNICATIONS CORP, 8-K, 11/25/2019
