<!-- page 1 -->
# AGENCY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Agency Agreement |
| Agreement Date | 1999-03-29 |
| Parties | Biopure Corporation ("Company"); Agent ("Agent") |
| Source | CUAD v1 / BIOPURECORP_06_30_1999-EX-10.13-AGENCY AGREEMENT |

1 EXHIBIT 10.13

2

BIOPURE CORPORATION AGENCY AGREEMENT

This "Agency" Agreement is made as of March 29, 1999, by and between Biopure Corporation, a Delaware
corporation (the "Company") and the Agent named on the signature page hereof (the "Agent").

WHEREAS, the Company is preparing to manufacture and sell Oxyglobin(R) brand veterinary products
("Products") enumerated on the Company's veterinary products agency price list (Exhibit A)(as such
list may be changed by the Company from time to time, the "Price List"); and

WHEREAS, the Agent and the Company wish to enter into an arrangement wherein the Agent would
promote, sell, and collect payment for, such Products for the Company as a representative ("Agent")
of the Company within the United States of America to duly licensed veterinarians (the "Customers")
on the terms provided herein;

NOW, THEREFORE, in consideration of the premises and of the mutual promises and covenants contained
herein, the parties hereby agree as follows:

1. APPOINTMENT AND ACCEPTANCE.

1.1. Appointment. Subject to the terms and conditions of this Agreement, the Company hereby appoints
the Agent, and the Agent hereby accepts appointment, as an authorized distributor agent within the
Territory, (Territory as outlined in section 1.2), for the promotion, sale and collection of payment
for, the Products to Customers. The Company has appointed a limited number of Agents; however, the
Company retains the right to itself, and/or appoint others to, promote, sell, and collect payment
for, and distribute, the Products to Customers in the Territory.

1.2. Territory. The Territory is defined as that geographical area in which said Agent is
represented by a full time field sales representative, and of which assigned Distributor agrees to
be responsible for mutually agreed upon quarterly and annual sales objectives as described in the
"Business Plan". Compensation by the Company to the Agent will be limited to the area stated as
follows:

The 48 Continental United States (including DC) plus Alaska 3

-2-

No compensation will be earned by the Agent for sales generated from customers in geographical areas
not indicated in this section 1.2.

1.3. Business Plan. The Company and the Agent will jointly develop a written business plan for the
promotion, distribution and sale of the Products to Customers in the Territory for each year (Nov 1
- Oct 31) during the term of this Agreement (a "Contract Year") and, on a nonbinding preliminary
basis, for the next succeeding Contract Year (a "Business Plan"). Each Business Plan will include,
among other things, sales and marketing strategies, advertising and promotion plans, financial
projections (including projected sales, expenses and other customary items) and Agent performance
criteria (including, but not limited to, market penetration, sales promotion execution, Product
availability/accessibility and trade support). In the event of any conflict between this Agreement
and a Business Plan, this Agreement will govern. The Business Plan relating to Contract Year ending
Oct 31, 1999 will be agreed upon at least thirty (30) days after the Agent Launch Date (as defined
below) or at a mutually agreed upon date and location. The Business Plan relating to all Contract
Years thereafter will be agreed upon not less than sixty (60) days (or at a mutually agreed upon
date and location) prior to the start of the Contract Year to which it relates. The Company and the
Agent will negotiate the terms and conditions of each Business Plan in good faith, using their
respective best efforts to agree upon such terms and conditions. The parties will review each
then-current Business Plan quarterly and update such Business Plan from time to time as may be
mutually agreed upon in writing. For purposes of this Agreement, "Agent Launch Date" means the date
specified by the Company to the Agent in writing upon which the Agent is to begin promotion, sale,
and collection of payment for, the Products to Customers in the Territory (which date is currently
anticipated to be March 29, 1999).

1.4. Agent Obligations. Except as otherwise expressly provided in the Business Plan, the Agent will
at its sole expense:

(a) meet the Agent's performance criteria set forth in the Business Plan;

(b) use its reasonable best efforts to market and promote the sale of the Products to Customers
throughout those portions of the Territory in which the Agent has field sales representatives on and
after the Agent Launch Date, through direct sales calls, advertising and other appropriate means
(all such marketing and promotional activities to be in accordance with the Business Plan or as
otherwise expressly proposed by the Agent and approved in writing by the Company); 4

-3-
<!-- page 2 -->
(c) immediately forward to the Company's Technical Service Department for response, in accordance
with any procedures described in the Business Plan and in a mutually agreed upon format, (i) all
complaints and inquiries relating to the Products (including, but not limited to, Product safety,
quality and packaging, Customer satisfaction and Customer services) received by the Agent from
Customers and consumers within the Territory except inquiries relating solely to Product
availability, pricing, billing and/or delivery and (ii) all other inquiries relating to the Products
received by the Agent from outside the Territory;

(d) maintain a suitable staff in the Territory to enable the Agent for the proper promotion, sale,
and merchandising of the Products and for seeking to assure Customer and consumer satisfaction with
the Products;

(e) not solicit or accept orders for the Products other than from Customers within the Territory
after the Agent Launch Date; and not knowingly, or knowingly permit others to, distribute or resell
Products outside the Territory or for end use by other than duly licensed veterinarians;

(f) meet with the Company at least once each quarter (starting with the quarter in which the Agent
Launch Date occurs), at a mutually agreeable time and place to discuss and review the Agent's
activities hereunder, at which meeting the Agent will make available to the Company information
concerning the Agent's sale and marketing of the Products in the Territory during the quarter and
year-to-date, such information to include details of sales efforts, Product sales volume and such
other information as may be mutually agreed upon in each Business Plan;

(g) at least thirty (30) days prior to use or distribution of any sales, promotion or training
materials relating to the Products (other than materials provided to the Agent by the Company for
such purpose), submit such materials to the Company for review, give due consideration to any
comments received from the Company with respect to such materials, and not use or distribute any
such materials without the express prior written consent of the Company (which consent will not be
unreasonably withheld or delayed); and

(h) make all field sales personnel of the Agent available for at least four (4) hours, and telesales
personnel available for at least one (1) hour, of initial Products sales and marketing training by
the Company, and for such supplemental training by the Company as the Company may deem appropriate
from time to time, in each case, at such times and locations as may be mutually agreed upon by the
Company and the Agent. 5

-4-

(i) make all field sales representatives of the Agent available to work with field sales
representatives of the Company at least two (2) full business days per agreement year.

(j) maintain sales and promotion of the Company's Products so as to meet or exceed the previous
years annual sales within the same competitive environment.

(k) cooperate and participate in any national or area promotional program offered by the company for
any Products covered by this agreement.

(l) follow the Company's credit policy (See Paragraph 2.3 Payment Terms) or program terms promptly
in payment of goods shipped to the Customer. Product(s) shipped to the Customer will be billed to
the Agent at the price stated on a current price list or according to the current price program
minus a ten (10) percent discount as outlined in Paragraph 1.5(d). It is the responsibility of the
Agent to evaluate the credit worthiness of the Customer. Upon transmitting an order for shipment to
the Company, the Agent accepts full responsibility for payment of the product from the Customer.

(m) transmit all orders, taken from the Customer for Product(s), a minimum of once daily basis, by
either fax, electronic mail, or other agreed upon means of transmission so as to afford the Company
time to process and ship said orders in an expediant manner.

(n) sell products only at the Company's current stated list or promotional price.

1.5 Company Obligations. Except as otherwise expressly provided in the Business Plan, the Company
will at its sole expense:

(a) use its reasonable best efforts to fill and ship all accepted orders for Products received from
the Agent on a daily basis so as to be shipped no later than the next business day. Orders received
on Fridays or the day before holidays will not be shipped until the next business day unless special
arrangements have been made at the customers expense. The Company will supply a list confirming such
order shipments to the Agent by the end of the next business day. If orders exceed the available
inventory levels, the Company will use reasonable efforts to inform the Agent and ship the remaining
inventory in a manner that the Company deems as being fair and equitable. If product becomes
available during a backorder, the Company will ship orders on a first-come, first-serve basis, but
can, at its

6

-5-
<!-- page 3 -->
own discretion, give partial shipments to large orders. In no event will the Company be obligated to
provide Products to the Agent in excess of one hundred and twenty percent (120%) of any maximum
quantity specified in the applicable Business Plan;

(b) provide to the Agent's field sales personnel at least four (4) hours of initial Products sales
and marketing training, and Agent telesales personnel at least one (1) hour of initial Product sales
and marketing training, and such supplemental training, if any, as the Company may deem appropriate,
in each case, at such times and locations as may be mutually agreed upon by the Company and the
Agent.

(c) supply such literature, ad reprints and other promotional aids and furnish Agent with other
information that in the opinion of the Company may be helpful in the sale of listed Product(s).

(d) compensate the Agent through a discount of eight (8) percent off of the current price of the
Product times the total monthly units shipped at that price to the Customer in the Agent's Territory
excluding any taxes, and/or shipping and handling charges incurred by the Company. The Company will
compensate the Agent an additional two (2) percent through a discount off of the current price or
promotional price of the Product times the total monthly units shipped at that price to the Customer
excluding any taxes, and/or shipping and handling charges incurred by the Company, so as to
compensate the Agent's sales representatives. Therefore, a total of ten (10) percent discount off of
the current price list or promotional price times the total monthly units shipped at that price to
the Customer will be applied as payment for services from the Agent including, but not limited to,
the promotion, sales, and collection of payment from the Customer for Product shipped by the
Company. In addition the Company will compensate the Agent quarterly an additional two (2) percent
commission (incentive), exclusive of taxes, and /or shipping and handling charges incurred by the
Company, based upon the attainment of mutually agreed upon quarterly goals. One (1) percent of this
incentive is additional compensation for the Agent, and one (1) percent is for additional
compensation of the Agency sales force. In the event the Agent fails to achieve these goals during
any given quarter yet is able to achieve the overall annual goals, then the Agent will receive the
incentive commission for that quarter at the conclusion of the fiscal year. These goals are outlined
in exhibit B.

(e) will replace, any unit of Product to the Customer which has outdated (provided the Product is
not outdated more than ninety (90) days) with equal Product. 7

-6-

2. PRODUCTS PURCHASE AND SALE.

2.1. Orders. Each order for Products taken by the Agent from the Customer will be subject to
acceptance by the Company and will not be binding upon the Company unless and until so accepted. The
Company reserves the right, in its sole discretion, to accept or reject, in whole or in part, any
Product order. All orders will be shipped to the Customer in minimum quantities of one box (two (2)
bags).

2.2. Prices. Prices for the Products will be as set forth on the Price List. The current Price List
is attached hereto as Exhibit A. Any deviation from current pricing as indicated by the Company is a
violation of this contract. All prices are F.O.B. the Customer's facility and are exclusive of any
federal, state or local sales, use, privilege, excise or similar taxes or duties levied upon any
party. The Company will give the Agent at least ten (10) days prior written notice of any price
change. In the event of a price change, orders will be invoiced at the prices in effect at the time
of the Company's receipt of the order.

2.3. Payment Terms. Terms of payment by the Agent to the Company for Products shipped to the
Customer will be net thirty (30) days from the date of statement unless the Agent chooses to pay the
Company via electronic funds transfer in which case the terms of payment will be net forty-five (45)
days. All payments will be made in United States Dollars without set-off or counterclaim, free and
clear of (and without deduction for) any taxes, duties, charges, withholdings, restrictions or
conditions of any nature imposed or levied by any political, taxing or other authority.

2.4. Taxes. The Customer will bear all taxes and duties which may be levied with respect to the
purchase of the Products by the Agent (excluding any taxes on the Company's income therefrom), and
the Company will bear all taxes and duties which shall be levied upon any of the Products if
incidental to the Company's production of such Product or any component thereof. The Company will
supply the Agent with such reasonable and necessary documents as may be required to carry out these
provisions.

2.5. Claims. Any claim for shortage in Product delivery must be made within ten (10) business days
after the Customer's receipt of shipment. See attachment "C", "General Information", for specific
sales, shipping, and return policies.

2.6. Warranty. The Company hereby warrants that all Products sold to the
<!-- page 4 -->
Customer hereunder, at the time of shipment to the Customer, (a) will be merchantable and of
generally commercially salable quality; and (b) will have a then remaining shelf life of at least
twelve (12) months. The Company further 8

-7-

warrants that the Products have been manufactured, labeled and packaged, and when in the Company's
possession or under its control, have been handled, stored and shipped, in compliance with all
applicable federal, state and local laws. The Customer's exclusive remedy for a breach of any of the
foregoing warranties will be the replacement, at the delivery point thereof, freight prepaid, of any
Product furnished hereunder that fails to meet the foregoing standards. In no event will the Company
be liable for incidental or consequential damages. All claims by the Customer and/or Agent under
this Paragraph 2.6 must be submitted in accordance with the Company's published bulletins concerning
such claims, as such bulletins may be amended by the Company from time to time and furnished to the
Agent.

THE COMPANY MAKES NO WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE OR ANY OTHER
WARRANTIES RELATING TO THE PRODUCTS, WHETHER EXPRESS OR IMPLIED, OTHER THAN THE WARRANTIES EXPRESSED
IN THIS PARAGRAPH 2.6. ANY STATEMENTS MADE BY REPRESENTATIVES OF THE COMPANY WITH RESPECT TO THE
PRODUCTS DO NOT CONSTITUTE WARRANTIES AND SHOULD NOT BE RELIED UPON BY THE AGENT. 9

-8-

3. COVENANTS.

3.1. Purchaser Guarantees, Instructions. The Agent will not furnish to any purchaser or user of the
Products, or to any other third party, any guarantee or warranty with respect to the Products or any
instructions for their use or maintenance, except as expressly approved in writing by the Company or
as expressly stated on the Products' labeling and/or in materials provided by the Company to the
Agent for such purpose.

3.2. Trademarks. The Agent will promote and sell the Products to Customers in the Territory only
under such trademarks, copyrights, brand names and product names as the Company may have registered,
or as the Company has otherwise requested be used on or in respect of Products sold within the
Territory (together, the "Trademarks"). The Agent will use the Trademarks only in such fashion as
has been expressly authorized by the Company in writing. Such use will not give the Agent any
interest in the Trademarks, except the right to display the Trademarks as expressly provided herein.
The Agent will not use any Trademark in connection with any products other than the Products. Upon
the expiration or any termination of this Agreement, the Agent will immediately cease all use of the
Trademarks.

3.3. Insurance. The Company and the Agent will each maintain, at their own expense, insurance with
reputable insurers, such insurance to be in such form and amounts as are customary in the case of
entities of established reputation engaged in the same or similar businesses and similarly situated,
provided that such insurance will in any event include commercial general liability and umbrella
liability insurance (including product liability coverage) for property damage, bodily injury and
personal injury in an amount not less than Five Million Dollars ($5,000,000) combined single amount
per occurrence and in the aggregate. Each such liability insurance policy of the Agent will name the
Company (as its interest may appear) as an additional insured under the policy and provide for at
least thirty (30) days prior written notice to the Company of any cancellation, modification or
amendment of the policy. Each product liability insurance policy of the Company will name the Agent
(as its interest may appear) as an additional insured under the policy and provide for at least
thirty (30) days prior written notice to the Agent of any cancellation, modification, or amendment
of this policy. Each party will furnish to the other upon request a Certificate of Insurance or
other documentation reasonably satisfactory to the other evidencing compliance with this Paragraph
3.3. 10

-9-

3.4. Notice of Certain Events. The Agent will promptly notify the Company in the event the Agent
becomes aware of any of the following events: alleged infringement of the Trademarks by any third
party; alleged infringement of the trademark or proprietary rights of others in connection with
actions taken hereunder; liability claims relating to the Products and any other event that may
reasonably be expected to have a material adverse effect upon the sale or distribution of the
Products in the Territory.

3.5. Indemnification.

(a) Subject to Subparagraph (c) below, the Agent will indemnify the Company (and its officers,
directors, employees, agents and affiliates) and hold it (and them) harmless from and against all
loss, damage, liability, cost or expense of any nature whatsoever, including, without limitation,
any and all reasonable attorneys fees and court costs (together, a "Loss"), arising out of or in
connection with (i) the inaccuracy or breach of any representation, warranty or obligation of the
Agent hereunder and/or (ii) the activities of the Agent in connection with the promotion, sale or
collection of payment of the Products in violation of this Agreement, law or any other duty or
obligation of the Agent. In no way should the Agent be liable for incidental or consequential
damages.
<!-- page 5 -->
(b) Subject to Subparagraph (c) below, the Company will indemnify the Agent (and its officers,
directors, employees, agents and affiliates) and hold it (and them) harmless from and against any
Loss arising out of or in connection with the inaccuracy or breach of any representation, warranty
or obligation of the Company hereunder.

(c) Each party (the "Notifying Party") will promptly notify the other party (the "Indemnifying
Party") of the existence of any third party claim, demand or other action giving rise to a claim for
indemnification under this Paragraph 3.5 (a "Third Party Claim") and will give the Indemnifying
Party a reasonable opportunity to defend the same at its own expense and with its own counsel
provided that the Notifying Party will at all times have the right to participate in such defense at
its own expense. If, within thirty (30) days after receipt of a notice of a Third Party Claim the
Indemnifying Party fails to undertake to so defend, the Notifying Party will have the right, but not
the obligation, to defend and to compromise or settle (exercising reasonable business judgment) the
Third Party Claim for the account and at the risk and expense of the Indemnifying Party subject to
the Indemnifying Party's prior written approval (such approval not to be unreasonably withheld or
delayed). Each party will make available to the other, at the other's reasonable expense, such
information and assistance as 11

-10-

the other may reasonably request in connection with the defense of a Third Party Claim.

3.6. Assistance with Claims. Subject to Paragraph 3.5 hereof, each party will, at the request and
expense of the other, furnish such reasonable assistance as may be required to enable the other
party to defend itself against third party claims threatened or filed in connection with the
manufacture, distribution, sale or use of the Products.

3.7. Confidential Information and Publicity. From time to time during the term of this Agreement
either party may disclose or make available to the other Confidential Information (as defined below)
in connection with activities contemplated hereunder. Except as may be required by law or as may be
reasonably necessary to enforce rights hereunder, each party agrees that during the term of this
Agreement and thereafter (a) it will use Confidential Information belonging to the other solely for
the purpose(s) of this Agreement and (b) it will not disclose Confidential Information belonging to
the other to any third party (other than its employees and/or consultants reasonably requiring such
Confidential Information for purposes of this Agreement who are bound by obligations of
nondisclosure and limited use at least as stringent as those contained herein) without the express
prior written consent of the disclosing party. Each party further agrees that except as reasonably
necessary for performance hereunder or otherwise expressly required by law, it will not publicly
announce or otherwise disclose any of the terms and conditions of this Agreement without the express
prior written consent of the other. Except as may be otherwise expressly provided in the Business
Plan, or as may be required by law or reasonably necessary to enforce rights hereunder, neither
party will use the name of the other in any advertising, promotional or sales materials relating to
the Products, in any press release, or in any other manner whatsoever without the express prior
written consent of the other. Each party will promptly return to the other upon request any
Confidential Information of the other party then in its possession or under its control. The
provisions of this Paragraph 3.7 will survive the expiration or any termination of this Agreement.
For purposes of this Agreement, "Confidential Information" means, with respect to either party, any
and all information (including, but not limited to, financial data and information concerning
products, customers and business operations) in any form belonging to such party except information
which at the relevant time is (a) known to the public through no act or omission in violation of
this Agreement, (b) furnished to the receiving party by a third party having the lawful right to do
so, (c) known to the receiving party prior to disclosure hereunder (as established by written
documentation thereof) or (d) independently developed by the receiving party without reference to
the Confidential Information. 12

-11-

4. TERM AND TERMINATION.

4.1. Term. This Agreement will become effective as of the date first written above and will continue
in effect thereafter until terminated pursuant to Paragraph 4.2 below.

4.2. Termination. This Agreement may be terminated as follows:

(a) In the event that either party fails in any material respect to observe or perform any of its
obligations under this Agreement (with respect to the Agent, including but not limited to Agent
performance criteria set forth in each Business Plan), which failure is not remedied within thirty
(30) days (or, in the case of payments due, within five (5) business days), after receipt of written
notice from the other party specifying such failure, this Agreement shall automatically terminate.

(b) In the event of any material change in the organization, ownership, management or control of the
business of the Agent, the Company may, at its option, terminate this Agreement upon giving written
notice of termination to the Agent. The Agent will promptly advise the Company in writing of any
event described in this Paragraph 4.2(b).
<!-- page 6 -->
(c) Either party may, at its option, terminate this Agreement without cause, effective at any time
after January 31, 1999, upon giving at least ninety (90) days prior written notice of such
termination to the other party.

(d) If after exercise of good faith efforts, the parties fail to timely agree upon a Business Plan
for any Contract Year before the start of such year (with respect to the Business Plan for Contract
Year ending October 31, 1999, at least thirty (30) days or on a mutually agreed upon date after the
Agent Launch Date), this Agreement may be terminated by either party upon giving at least thirty
(30) days prior written notice of such termination to the other party.

(e) In the event of any publicity concerning the Agent which the Company reasonably believes to have
a material adverse affect upon the status or reputation of the Agent and/or the Products, the
Company may, at its option, terminate this Agreement upon giving at least five (5) days prior
written notice of such termination to the Agent.

(f) In the event the Company terminates, sells or otherwise transfers its veterinary products
business in its entirety, the Company may 13

-12-

terminate this Agreement upon giving at least ninety (90) days prior written notice of such
termination to the Agent.

4.3. Effect of Termination. Upon the termination of this Agreement for any reason:

(a) the Agent will immediately discontinue making any representations regarding its status as an
agent for the Company and will immediately cease conducting any activities with respect to the
promotion, sale or distribution of the Products;

(b) all amounts owed by either party to the other will become immediately due and payable as
indicated in section 2.3;

(c) any then unfulfilled Product orders hereunder may be completed by the Company or transferred to
another Agent in the Company's discretion. Any termination of this Agreement will be without
prejudice to the settlement of the rights created and obligations incurred hereunder prior to the
time of such termination. In no event will either party be liable for special or consequential
damages arising out of the breach or the termination of this Agreement. The provisions of this
Paragraph 4.3 and of Paragraphs 3.5, 3.6, and 3.7 will survive the termination of this Agreement.

5. MISCELLANEOUS.

5.1. Notices. All notices and other communications between the parties given pursuant to this
Agreement will be deemed to have been sufficiently given when delivered by personal service or sent
by recognized overnight courier service, telecommunication or registered U.S. Mail to the recipient
at the address indicated on the signature page hereof. All such communications will be deemed
effective on the earlier of (a) actual receipt or (b) if sent by courier service, on the next
business day following the date delivered to the courier service (the courier service's receipt
being evidence of the date of such delivery), or (c) if sent by telecommunication on the next
business date (subject to confirmation of receipt in complete readable form), or (d) if sent by
registered U.S. Mail, five (5) business days after delivery to the U.S. Postal Service, postage
prepaid. Either party may give to the other written notice of change of address, in which event any
communication will thereafter be given to such party at such changed address.

5.2. Assignment. This Agreement will be binding upon and inure to the benefit of the parties hereto
and their respective successors and permitted assigns. 14

-13-

Neither party will not assign or otherwise transfer any of its rights or obligations under this
Agreement without the express prior written consent of the other party.

5.3. Waivers. Any waiver by either party of any rights arising from a breach of any covenants or
conditions of this Agreement must be in writing and will not be construed as a continuing waiver of
other breaches of the same nature or other covenants or conditions of this Agreement.

5.4. Relationship of Parties This Agreement is not intended to create, nor should it be construed as
creating, a joint venture, partnership or similar relationship between the parties. The Agent will
act solely as an independent agent and will have no right to bind the Company in any way or to
represent that the Company is in any way responsible for any acts or omissions of the Agent.

5.5. Force Majeure. Notwithstanding any other provision of this Agreement, if either the Company or
the Agent is delayed in or prevented from fulfilling any of its obligations hereunder by reason of
any cause beyond its reasonable control (including, but not limited to acts of God, fire, third
party strike,
<!-- page 7 -->
flood, delay of transportation or inability to obtain necessary raw materials through normal
commercial channels), then that party will not be liable under this Agreement for damages resulting
from such delay or failure. Each party will promptly notify the other upon becoming aware of the
occurrence of any such cause and will use its reasonable best efforts to minimize any resulting
delay in or interference with the performance of its obligations hereunder.

5.6. Governing Law; Jurisdiction. This Agreement and all related business transactions will be
governed by the laws of the Commonwealth of Massachusetts (without reference to principles of
conflicts or choice of law which would cause the application of the internal laws of any other
jurisdiction). The courts of or in the Commonwealth of Massachusetts will have nonexclusive
jurisdiction over any disputes hereunder. Service of any action or proceeding in any such courts by
either party may be made upon the other by registered mail, return receipt requested, at its address
given herein.

5.7. Amendments. Neither this Agreement nor any provision hereof may be amended except by a writing
duly signed on behalf of each party.

5.8. Remedies. All remedies available to either party for breach of this Agreement are cumulative
and may be exercised concurrently or separately. The exercise of one remedy will not be deemed an
election of such remedy to the exclusion of other remedies.

5.9. Severability. In the event any provision of this Agreement, in whole or in part, is invalid,
unenforceable or in conflict with the applicable laws or 15

-14-

regulations of any jurisdiction, such provision will be replaced, to the extent possible, with a
provision which accomplishes the original business purposes of the provision in a valid and
enforceable manner, and the remainder of this Agreement will remain unaffected and in full force
provided, however, that if without such invalid or unenforceable provision the fundamental mutual
objectives of the parties cannot be achieved, either party may terminate this Agreement without
penalty by written notice to the other.

5.10. Interest. Any overdue amounts payable hereunder will bear interest, payable on demand (whether
before or after judgment), from due date to date of payment, at an annual rate of two percent (2%)
above the prime rate of Citibank, N.A. in effect on the due date or, if lower, the maximum rate
permitted by applicable law.

5.11. Miscellaneous. Each party will bear its own expenses in connection with the negotiation,
preparation and execution of this Agreement. The headings of the paragraphs and subparagraphs of
this Agreement have been added for the convenience of the parties and are not be deemed a part
hereof. This Agreement may be executed in any number of counterparts, all of which together
constitute a single agreement. In proving this Agreement, it will not be necessary to produce or
account for more than one counterpart signed by the party with respect to which proof is sought.
This Agreement is the sole understanding and agreement of the parties with respect to its subject
matter and supersedes all other such prior or contemporaneous oral and written agreements and
understandings.

Signed, sealed and delivered by a duly authorized representative of each party hereto as of the date
first written above.

THE BUTLER COMPANY BIOPURE CORPORATION

By: By: -------------------------------- -------------------------------- Andrew W. Wright, Title:
Vice President, Veterinary ----------------------------- Products

Address: Address: 11 Hurley Street --------------------------- Cambridge, MA 02141 Telecopy No.:
(617) 234-6507 ---------------------------

--------------------------- 16

EXHIBIT A

BIOPURE CORPORATION

Oxyglobin(R) Brand Products Price List (Introductory Promotional Pricing*)

Each Box contains two 125 ml bags of Oxyglobin(R) Brand Veterinary Product.

Retail Price Retail Price Per Bag ------------ -------------------- 1 Box of 2 Bags $279.90 $139.95
2 Boxes of 2 Bags $499.80 $124.95 3 Boxes of 2 Bags $749.70 $124.95 4 Boxes of 2 Bags $999.60
$124.95 5 Boxes of 2 Bags $1099.50 $109.95

- ----------
<!-- page 8 -->
*May be changed with 30 days written notice.

Effective Date: January 5, 1999 17

EXHIBIT B

OXYGLOBIN(R) BUSINESS PLAN FISCAL YEAR 1999 (Nov 1, 1998 through Oct 31, 1999)

AGENT: THE BUTLER COMPANY FY: 1999

QUARTERLY GOALS

1st Quarter (Nov 1 - Jan 31): N/A units

2nd Quarter (Feb 1 - Apr 30): 3,500 units

3rd Quarter (May 1 - Jul 31): 7,000 units

4th Quarter (Aug 1 - Oct 31): 8,400 units

Fiscal Year Total: 18,900 units

Unit = 1 Bag of Oxyglobin Solution 125 ml

PROMOTIONAL ACTIVITIES

Sales Meetings: Anticipated Dates ______________________________________________

________________________________________________________________________________

________________________________________________________________________________

Ride Withs (# Per Quarter) 1st Qtr ____________

2nd Qtr ____________

3rd Qtr ____________

4th Qtr ____________

Total for Year ____________ 18

Conferences with Display of Biopure Product:____________________________________

________________________________________________________________________________

________________________________________________________________________________

________________________________________________________________________________

Agent Monthly Flyer, Catalog, Other ____________________________________________

________________________________________________________________________________

________________________________________________________________________________

________________________________________________________________________________

Other Activities (Dinner Meeting Support, Advertising, Mailings, etc)___________

________________________________________________________________________________

________________________________________________________________________________

________________________________________________________________________________

THE BUTLER COMPANY: BIOPURE CORPORATION:

- ---------------------------- ---------------------------- Name Name

- ---------------------------- ---------------------------- Title Title

- ---------------------------- ---------------------------- Date Date
