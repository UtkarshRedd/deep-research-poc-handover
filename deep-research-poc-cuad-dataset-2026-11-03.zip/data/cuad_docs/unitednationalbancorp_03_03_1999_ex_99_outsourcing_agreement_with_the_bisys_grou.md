<!-- page 1 -->
# United National Bancorp Enters Into Outsourcing Agreement with the BISYS Group, Inc
| Field | Value |
|---|---|
| Document Type | Outsourcing Agreement |
| Agreement Date | 1999-02-18 |
| Parties | United National Bancorp ("UNBJ"); United National Bank; BISYS Group, Inc. ("BISYS") |
| Source | CUAD v1 / UNITEDNATIONALBANCORP_03_03_1999-EX-99-Outsourcing Agreement with the BISYS Group, Inc. |

United National Bancorp Enters Into Outsourcing Agreement with the BISYS Group, Inc.

Bridgewater, NJ -- February 18, 1999 -- United National Bancorp (Nasdaq: UNBJ) announced today that
its principal subsidiary, United National Bank, has entered into a multi-year agreement with the
BISYS Group, Inc. whereby BISYS will provide integrated information processing services, as well as
item processing and deposit services, for United National.

"We are excited about the opportunities available to us as a result of our new partnership with
BISYS," stated Thomas C. Gregor, chairman and chief executive officer of United National. "During
the past year we completed an assessment of our information processing needs going forward into the
next century. After evaluating a number of different options, we determined that the flexibility and
quality of BISYS' TOTALPLUS (R) system would best serve our needs today and for years to come."

United Financial Services, a third party services provider that United National Bancorp owns with
another joint venture partner, currently handles the Bank's information processing services, item
processing and deposit services. As a result of its planned move to BISYS, United National will be
liquidating its interest in United Financial Services during the first half of 1999 after it goes
live with BISYS.

"Our investment in United Financial Services has made a great deal of sense since we established it
in 1995," said Mr. Gregor. "United Financial Services has allowed United National to realize
significant efficiencies through the sharing of technology and processing costs. Nevertheless, we
believe that the enhanced capabilities which BISYS offers are better matched to the future direction
of our Bank."

Contact: media, Donald Reinhard, 908-429-2370 or investors, Donald Malwitz, 908-429-2405, both of
United National.
