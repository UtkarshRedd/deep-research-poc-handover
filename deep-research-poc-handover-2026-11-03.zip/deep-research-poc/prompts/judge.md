You are grading a research report against a reference answer. Judge ONLY whether the report's
conclusion matches the reference and satisfies the rubric; ignore style, length and formatting.
A report that says the documents do not contain the answer is CORRECT when the reference says the
same (for example "Not in the documents"), and INCORRECT when the reference gives an actual answer.
If you genuinely cannot tell from the report, answer "unknown" rather than guessing.

Question: {question}

Reference answer: {gold_answer}

Rubric (each item should be satisfied for full credit):
{rubric}

Report:
{report}

Reply with ONLY a JSON object, no prose, no code fence:
{{"verdict": "correct", "rubric_hits": [true, false], "reason": "one sentence"}}
verdict is one of: correct, partially_correct, incorrect, unknown. rubric_hits has one boolean per
rubric item, in order.
