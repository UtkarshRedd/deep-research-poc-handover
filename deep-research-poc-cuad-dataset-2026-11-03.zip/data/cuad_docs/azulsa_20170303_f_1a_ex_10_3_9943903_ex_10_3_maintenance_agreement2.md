<!-- page 1 -->
# Amendment n° 01 to the Global Maintenance Agreement ref. DS/C-3957/14 Issue 7
| Field | Value |
|---|---|
| Document Type | Maintenance Agreement |
| Agreement Date | 2016-01-06 |
| Parties | AZUL LINHAS AÉREAS BRASILEIRAS S/A ("Company", "AZUL"); AVIONS DE TRANSPORT REGIONAL, G.I.E. (“Repairer”, “ATR”); AZUL LINHAS AÉREAS BRASILEIRAS and AVIONS DE TRANSPORT REGIONAL, G.I.E. (individually referred to as the “Party” or collectively as the “Parties”) |
| Source | CUAD v1 / AzulSa_20170303_F-1A_EX-10.3_9943903_EX-10.3_Maintenance Agreement2 |

Execution version

Amendment n° 01 to the Global Maintenance Agreement ref. DS/C-3957/14 Issue 7 dated March 9t h ,
2015

BETWEEN

AZUL LINHAS AÉREAS BRASILEIRAS S/A

AND

AVIONS DE TRANSPORT REGIONAL, G.I.E. AZUL-ATR Amendment N° 1 Global Maintenance Agreement Page 1/9

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 2 -->
Execution version TABLE OF CONTENTS: CLAUSE PAGE

1. DEFINITIONS 4

2. AMENDMENT 4

3. EFFECTIVE DATE AND DURATION 5

4. CONFIDENTIALITY 5

5. GOVERNING LAW - ARBITRATION 7

6. MISCELLANEOUS 8 AZUL-ATR Amendment N° 1 Global Maintenance Agreement Page 2/9

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 3 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED This amendment (hereinafter referred to as the
"Amendment") is entered into on January 6th, 2016.

BETWEEN:

AZUL LINHAS AÉREAS BRASILEIRAS S/A, a company incorporated under the laws of Brazil, the registered
office of which is located at Avenida Marcos Penteado de Ulhôa Rodrigues, 939 - Edif. Castello
Branco Office Park - Torre Jatobá - 9° andar - CEP 06460-040 - Alphaville Industrial - Barueri - São
Paulo - Brazil, identified under Cadastro Nacional de pessoa Juridica (CNPJ) number
09.296.295/0001-60.

Hereafter referred to as the "Company" or "AZUL",

On the one part,

AND:

AVIONS DE TRANSPORT REGIONAL, G.I.E., a French groupement d'intérêt économique established under
articles L.251-1 to L251-23 of the French Commercial Code, whose registered office is at 1 allée
Pierre Nadot, 31712 Blagnac, France identified under Corporate and Trade Register of Toulouse number
323 932 236,

Hereafter referred to as the "Repairer' or "ATR", On the other part.

Hereinafter individually referred to as the "Party" or collectively as the "Parties"

RECITALS:

WHEREAS the Repairer and the Company entered into a Global Maintenance Agreement as referenced here
above (as amended and supplemented from time to time, hereafter referred to as the "GMA") for the
purpose of providing the Company with Services for the maintenance of the Aircraft; and,

WHEREAS in consideration of modification of the operations, the Repairer and the Company agree to
amend the GMA in order to update the number of [*****] required for the invoicing; and,

WHEREAS the Parties wish to amend certain provisions of the GMA upon the terms and conditions set
out below.

NOW THEREFORE, IT IS HEREBY AGREED AS FOLLOWS: [*****] Confidential material redacted and filed
separately with the Securities and Exchange Commission. AZUL-ATR Amendment N° 1 Global Maintenance
Agreement Page 3/9

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED
<!-- page 4 -->
1. DEFINITIONS

Unless otherwise defined, capitalised terms, singular or plural, used in this Amendment, shall have
the same meaning ascribed thereto in the GMA.

2. AMENDMENT

The following Clauses, sentences or words of the GMA are amended as follows: 2.1 Clause 12 -
INVOICING AND PAYMENT TERMS (i) Clause 12.1(ii) of the GMA shall be cancelled and substituted as
follow: [*****] [*****] [*****] [*****] [*****] [*****] [*****] [*****] (ii) Any other provision of
Clause 12 shall remain in full force and effect. 2.2 Exhibit 14 - PRICE CONDITIONS (i) Clause 3.2 of
the Exhibit 14 of the GMA shall be cancelled and substituted as follow: "3.2 Technical conditions
for prices adjustment

The prices set out in this Exhibit 14 shall be modified every [*****] at the occasion of the
invoicing reconciliation pursuant to Clause 11 ("Reconciliation") if the Standard Operations of the
[*****] Confidential material redacted and filed separately with the Securities and Exchange
Commission. AZUL-ATR Amendment N° 1 Global Maintenance Agreement Page 4/9

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 5 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED Aircraft, analyzed at the time of the adjustment
(all calculations are made with figures corresponding to [*****], change by more or less [*****]
with respect to the estimated values of the same parameters, considered at the time of commencement
of the Term.

As from the date this Agreement enters into force, the Parties agree to take into account the
following basic operating parameters (the "Standard Operations") as a reference for the above
calculation:

(i) [*****]

- [*****]

(ii) [*****]

- [*****]

(ii) Any other provision of the Exhibit 14 shall remain in full force and effect.

3. EFFECTIVE DATE AND DURATION

This Amendment shall enter into force on the date of its signature by both Parties and, unless
otherwise agreed upon in writing by the Parties through a subsequent amendment to the GMA, shall
remain in force for the term of the referenced GMA.

4. CONFIDENTIALITY

4.1 Confidentiality obligations

Unless otherwise provided in this Amendment, any Confidential Information released by either of the
Parties (the "Disclosing Party") to the other Party (the "Receiving Party") shall not be released in
whole or in part to any third party.

In particular, the Receiving Party undertakes:

- to keep the Confidential Information strictly confidential, not to deliver, disclose or publish it
to any third party including subsidiarycompanies and companies having an interest in its capital,
except as otherwise agreed in writing by the Disclosing Party;

- to use the Confidential Information solely for the purpose of this Amendment and except as
otherwise expressly agreed in writing bythe Disclosing Party, not to use the same or permit its use
for any other purpose;

- to disclose the Confidential Information only to those of its direct employees having a need to
know such Confidential Information in order to make permitted use thereof, after having beforehand
clearly informed such employees of the strictly confidential nature of the Confidential Information
and caused them to observe said conditions of confidentiality. The Receiving Party shall be
responsible for the correct performance of said obligations of confidentiality by its employees and
shall keep up to date the list of its personnel, to whom Confidential Information is communicated,
which list shall be made available to the Disclosing Party at its request;

- not to duplicate the Confidential Information nor to copy or reproduce the same beyond the purpose
of the Amendment;

- not to disclose Confidential Information to any third party, unless such third party is acting at
the instruction of the Receiving Party and such disclosure is reasonably necessary to accomplish the
purpose of the Amendment, provided however, that prior to any such disclosure both of the following
conditions are satisfied: [*****] Confidential material redacted and filed separately with the
Securities and Exchange Commission. AZUL-ATR Amendment N° 1 Global Maintenance Agreement Page 5/9

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 6 -->
Execution version

(i) each of such third parties, shall have signed an acknowledgement to keep such Confidential
Information as strictly confidential;and,

(ii) the Receiving Party shall have obtained written prior approval of the Disclosing Party of such
proposed disclosure, whichapproval may be not unreasonably withheld or delayed.

- promptly notify the Disclosing Party if a disclosure of Confidential Information is required by a
Government Entity or by Law and to useall reasonable effort to assist the Disclosing Party in
limiting such disclosure to the extent permitted by Law;

- upon discovery of any disclosure of Confidential Information, regardless of whether such discovery
is intentional or inadvertent, the Receiving Party shall promptly notify the Disclosing Party and
take all reasonable actions (i) to retrieve the disclosed Confidential Information, (ii) to destroy
any unauthorized copies thereof and (iii) to stop further disclosure.

4.2 Non application of confidentiality obligations

The obligations of Receiving Party with respect to Confidential Information as set forth in this
Clause 4.1 above shall not be applicable to information which:

(a) upon the Signing Date was part of the public domain or became part of the public domain after
the disclosure, other than by a violationof the Amendment or any other non-disclosure Amendment or
the applicable Law of any jurisdiction; or

(b) was already lawfully known by the Receiving Party, as evidenced by written records bearing an
unquestionable date, prior the SigningDate by the Disclosing Party and was unrestricted; or

(c) was lawfully disclosed to the Receiving Party subsequently to the signature of the Amendment by
a third party which had not receivedthe same directly or indirectly from the Disclosing Party and
that such disclosure does not violate any non-disclosure Amendment.

4.3 Permitted disclosure of Confidential Information

Notwithstanding any provision to the contrary in the Amendment, the Receiving Party shall be
entitled to disclose Confidential Information if required to do so:

(a) by order of a court or government agency of competent jurisdiction; or

(b) by any applicable Law,

provided, however, that prior to making such disclosure, the Receiving Party shall if possible
advise the Disclosing Party of the circumstances requiring such disclosure in order to afford the
Disclosing Party sufficient advance notice to permit to raise any objections that it may deem
appropriate.

4.4 Disclosing Party's proprietary rights

Any Confidential Information shall remain the property of the Disclosing Party. The Amendment shall
not be construed as granting or conferring to the Receiving Party, either expressly or by
implication, any license or proprietary interest in or to any Confidential Information nor any right
of use beyond the purpose of this Amendment.

The Repairer, its Affiliates and/or its Subcontractors as applicable shall remain the exclusive
owner of any intellectual property right related to the Services including: design of the LRUs, Main
Elements, job cards, task cards, operating manual or industrial process, as relevant. No title to or
other ownership interest in AZUL-ATR Amendment N° 1 Global Maintenance Agreement Page 6/9

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 7 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED the Confidential Information is transferred
except as specifically stated in the Amendment, and the Receiving Party hereby expressly disclaims
any such rights or interests.

The Receiving Party hereby acknowledges and recognises that Confidential Information is protected by
copyright Laws and related international treaty provisions, as the case may be.

4.5 For the sake of clarity, and for the purpose of this Clause 4 and this Amendment, any of the
receiving Party's Affiliates and their Subcontractors shall not be considered as third party and
shall be entitled to have access to any Confidential Information disclosed by the disclosing Party
in connection with this Amendment. 4.6 This Clause 4 shall survive termination or expiry of this
Amendment for a period of five (5) years following such End Date.

5. GOVERNING LAW - ARBITRATION

5.1 Governing law:

Pursuant to and in accordance with Section 5-1401 of the New York General Obligations Law, the
Parties hereto agree that this Amendment in all respects, and any claim or cause of action based
upon or arising out of this Amendment, or any dealing between the Parties relating to the subject
matter of this Amendment or the transactions contemplated hereby or the Company/Repairer
relationship being established, shall be governed by, and construed in accordance with, the laws of
the State of New York, U.S.A. as applied to contracts to be performed wholly within the State of New
York (Exclusive of Section 7-101 of the New York General Obligations Law which is inapplicable to
this Amendment).

5.2 Arbitration: in the event of a dispute arising out of or relating to this Amendment, including
without limitation disputes regarding the existence, validity or termination of this Amendment (a
"Dispute"), either Party may notify such Dispute to the other through service of a written notice
(the "Notice of Dispute"). The Parties shall make their reasonable endeavours to settle the Dispute
amicably by a committee composed of one (1) management representative of each Party (the
"Representatives"). Such committee shall be created by the Parties within [*****] from the date of
receipt of the Notice of Dispute.

5.2.1 Subject to sub-Clause 5.2.5 below and in the event the Representatives (i) fail to create such
committee or (ii) do not agree on an amicable settlement within [*****] from the date the committee
referred to in this sub-Clause 5.2 has been created or such longer period as may be agreed upon in
writing by the Representatives (the "Amicable Settlement Period"), the Dispute shall be exclusively
and finally settled under the Rules and Conciliation of Arbitration of the International Chamber of
Commerce (the "ICC") by an arbitral tribunal composed of three (3) arbitrators; each Party shall
then appoint one (1) arbitrator within [*****]from the last day of the Amicable Settlement Period
and the third arbitrator, who will act as President, will be appointed by the other two (2)
arbitrators. In case the two (2) arbitrators appointed by the Parties do not agree on this choice
with [*****] from the date the last arbitrator is appointed, the third arbitrator will be appointed
by the ICC Court.

5.2.2 The arbitration, and any proceedings, and meetings incidental to or related to the arbitration
process, shall take place in New York, U.S.A, and the language to be used in the arbitral
proceedings shall be English; arbitral award shall be final and binding upon the Parties.

5.2.3 The arbitration shall be kept confidential and the existence of the proceeding and any element
of it shall not be disclosed to any third party. Any information relating to and/or documents
generated for the purpose of or produced in the arbitration, including any awards, shall remain
confidential [*****] Confidential material redacted and filed separately with the Securities and
Exchange Commission. AZUL-ATR Amendment N° 1 Global Maintenance Agreement Page 7/9

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 8 -->
Execution version between the Parties, the arbitrators and any other Person involved in the
arbitration proceedings, except to the extent that disclosure may be required pursuant to any order
of court or other competent authority or tribunal, or to protect or pursue a legal rights or to
enforce or challenge an award in bona fide legal proceedings before a state court or other judicial
authority.

5.2.4 During any period of negotiation or arbitration, the Parties shall continue to meet their
respective obligations in accordance with theprovisions of the Amendment.

5.2.5 Notwithstanding any provision of this Clause 5.2 the Parties may, at any time, seek and decide
to settle a Dispute either throughdirect negotiations or in accordance with the ICC rules in respect
of the alternative dispute resolution.

5.3 Judgment upon any award may be entered in any court having jurisdiction or application may be
made to the court for a judicial recognition of the award or an order of enforcement, as the case
may be.

5.4 Recourse to jurisdictions is expressly excluded except as provided for in the ICC Rules of
Conciliation and Arbitration concerning Conservatory and Interim measures.

6. MISCELLANEOUS

6.1 This Amendment contains the entire agreement between the Parties regarding the subject-matter
and shall supersede any previous understandings, commitments and/or representations whatsoever oral
or written.

6.2 In case of any inconsistency between the terms of the GMA and this Amendment regarding the
subject-matter, the latter shall prevail.

To the extent not inconsistent with this Amendment, all terms and conditions of the GMA shall remain
valid and binding.

6.3 This Amendment shall not be varied or modified except by a written document duly signed by duly
authorized representatives of both Parties. AZUL-ATR Amendment N° 1 Global Maintenance Agreement
Page 8/9

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 9 -->
Execution version IN WITNESS WHEREOF, the duly authorized representatives of the Parties hereto have
agreed to execute this Amendment in two (2) original copies in the English language. On behalf of:
/s/ Renato Covelo On behalf of:

AZUL LINHAS AÉREAS BRASILEIRAS S/A (the Company)

AVIONS DE TRANSPORT REGIONAL (the Repairer)

Signed by: Renato Covelo Signed by: M. Castoriwa Function: Attorney In Fact Function: VP Commercial
Date: December 18th, 2015 Date: January 6th, 2016 AZUL-ATR Amendment N° 1 Global Maintenance
Agreement Page 9/9

Source: AZUL SA, F-1/A, 3/3/2017
