<!-- page 1 -->
# Executive Employment Agreement — Keswick Logistics Partners LP
| Field | Value |
|---|---|
| Document Type | Employment Agreement |
| Effective Date | 2025-10-01 |
| Parties | Keswick Logistics Partners LP; Dana Whitfield |

THIS EXECUTIVE EMPLOYMENT AGREEMENT is entered into as of 2025-10-01 between Keswick Logistics Partners LP (the "Company") and Dana Whitfield (the "Executive").
<!-- page 2 -->
## 1. Position and Duties
The Executive shall serve as Chief Financial Officer of the Company, reporting to the Chief Executive Officer, and shall devote substantially all business time to the Company.
## 2. Compensation
Base salary of $425,000 per year, subject to annual review; target annual bonus of 60% of base salary.
<!-- page 3 -->
## 3. Term and Termination
The initial term is three (3) years. Either party may terminate upon ninety (90) days' written notice; termination by the Company without Cause entitles the Executive to twelve (12) months of base salary as severance.
## 4. Restrictive Covenants
During employment and for twelve (12) months thereafter, the Executive shall not solicit employees or customers of the Company.
<!-- page 4 -->
## 5. Governing Law
This Agreement is governed by the laws of the State of Tennessee.
Keswick Logistics Partners LP — By: /s/ Authorized Signatory
Dana Whitfield — /s/
