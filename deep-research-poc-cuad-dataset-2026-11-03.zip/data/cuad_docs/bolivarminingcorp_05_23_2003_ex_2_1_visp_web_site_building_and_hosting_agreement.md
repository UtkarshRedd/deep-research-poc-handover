<!-- page 1 -->
# VISP WEB SITE BUILDING AND HOSTING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Hosting Agreement |
| Agreement Date | 2003-05-12 |
| Parties | YourNetPlus.com, Inc. ("Provider"); Kingdom Connect, Inc. ("KCI") |
| Source | CUAD v1 / BOLIVARMININGCORP_05_23_2003-EX-2.1-VISP WEB SITE BUILDING AND HOSTING AGREEMENT |

VISP WEB SITE BUILDING AND HOSTING AGREEMENT

This Agreement is made on this 12th day of May 2003 by and between YourNetPlus.com, Inc., a New York
Corporation; with its principle office located at 501 Route 208, Monroe, NY 10950 ("Provider") and
Kingdom Connect, Inc., a Corporation with its principle office located at 1045 Stephanie Way,
Minden, NV 89423 ("KCI").

Whereas, Provider is in the business of providing websites and internet connectivity which may be
Private Labeled or offered as same service.

Whereas KCI wishes to purchase the services of Provider on behalf of KCI's customers.

Whereas, Provider agrees to provide VISP setup, maintenance, and technical support services for five
thousand (5,000) websites for KCI's customers over the next five years.

Be it agreed on this day that the following agreement will govern the relationship between our two
companies.

1 TERM

This agreement shall be for a term of five years from the date of this document. This agreement
shall renew automatically each year thereafter, unless either party serves written notice of its
intention not to renew, on the other at least 90 days prior to the expiration of the then current
term of this agreement.

2 PROVIDER'S REPRESENTATIONS

Yournetplus, one of the largest private label internet service providers in the United States agrees
to allow us to prepay for our customers all set up, development, maintenance, and service fees
associated with five thousand VISP websites for the customers of KCI at no charge to the customer
(churches). Provider represents that these fees normally are charged to the customer according to
the following schedule:

$299.00 one time start-up and developmental fee due at contract signing

$29.95 monthly maintenance and service fee

24/7 "800" Number Customer Service / Tech Support $25.00 per month for private labeled service and
Free for the first 90 days for generic service. If the ISP does not have 250 users within the first
90 days we will charge $25.00 each month thereafter.

3 PROVIDER'S RESPONSIBILITIES

Provider agrees to provide KCI with VISP Private labeled website building and maintenance
capabilities. Deliverables shall include: Sales collateral materials including brochures and flyers
to help KCI sign customers to the service. A fully staffed back end including; Billing, real time
credit card transactions, administrative reports, Customer and technical support, Online Customer
Account Maintenance, Private labeled E-Mail Server, Administrative E-Mail Addresses, vacation
e-mail, Web based and POP Access, Online Interfaces, a private labeled Internet portal for KCI and
include an affiliate program.

KCI's Customers will receive an initial VISP web site setup including 5Mbs of storage space,
maintenance of the site, technical support, and any services necessary for use of the site for no
charge.

4 KCI'S RESPONSIBILITIES

To market Private Labeled Service to retail and wholesale clients of KCI.

KCI, its officers, directors, employees and any authorized sub-licensee will (I) conduct their
business in an honest, professional and ethical manner and (ii) not commit any action or omission to
act which could adversely affect PROVIDER, its name, reputation or ability to conduct its business.
KCI shall promptly and fully cooperate with Provider to address and resolve all issues, problems,
administrative procedures, End User complaints, regulatory investigations or inquiries or any other
circumstances arising from KCI's use of Provider's services.

5 PROPRIETARY INFORMATION

The parties understand and agree that the terms and conditions of this Agreement, all documents and
invoices and all communications between the parties regarding this Agreement or the Service to be
provided as well as such information relevant to any other agreement between the parties
(collectively "Confidential Information"), are strictly confidential between KCI and Provider. For
purposes of this Agreement, "Confidential Information" shall mean information in written or other
tangible form specifically labeled as such when disclosed by a Party. Confidential Information shall
remain the property of the disclosing Party. A Party receiving Confidential Information shall: (1)
use or reproduce such information only when necessary to perform this Agreement; (2) provide at the
least the same care to avoid disclosure or unauthorized use of such information as it provides to
protect it's own Confidential Information and; (3) limit access to such information to it's
employees or agents who need
<!-- page 2 -->
such information to perform this agreement. Not withstanding anything to the contrary contained
herein, a Party shall be allowed to disclose Confidential Information pursuant to judicial or
governmental order or if otherwise required to do so by law.

KCI pledges that it will not circumvent the relationships among venders, providers and clients
developed by Provider either directly or indirectly, during the contract period and for a period of
up to 2 (two) years following termination of this contract

7 CONSIDERATION TO PROVIDER

Seven hundred fifty thousand (750,000) shares of Kingdom Connect, Inc. Series A Preferred Stock.
Such stock issued assuming ten million (10,000,000) shares total issued and outstanding and to be
adjusted accordingly to represent the same percentage should a different number be outstanding. Once
the common stock has been registered, or, after the one year period applicable under Rule 144,
whichever occurs first, the Company at its sole cost and expense have its attorney issue an opinion
letter for removal of the legend and release all stock transfer instructions on the common stock,
except as maybe required under Rule 144. In the event the Company fails to have its attorney issue
the required opinion letter within 20 days of a written request from YourNetPlus.com or its nominee,
the Company shall be liable for liquidated damages in the amount of 10% interest per 30 days on the
value of the shares based on the closing bid price of the Company's common stock on the 20th
business day following the date it receives written notice from YourNetPlus.com or their nominee.
The damages shall accrue until the transfer agent receives the opinion letter

8 ASSIGNMENT

This Agreement shall be binding upon the parties and their respective successors and assigns;
provided, however, that no rights or obligations hereunder, including but not limited to Licensee's
Subscriber accounts, shall be assigned or transferred, in whole or in part, by either of the parties
hereto to any person, firm or corporation without prior written consent by the other party, which
consent shall not be unreasonably withheld or delayed.

Notwithstanding the foregoing, either party may assign this Agreement, without the prior consent of
the other party, to any person, partnership, firm or corporation affiliated by common ownership with
the assigning party, acquiring all or substantially all of such party's assets or, in the case of
PROVIDER, acquiring any assets of PROVIDER associated with its wholesale Internet access and
services business.

9 ENTIRE AGREEMENT

The parties have read this Agreement and all of its Schedules, Exhibits and attachments and agree to
be bound by its terms, and further agree that it constitutes the complete statement of the Agreement
between them which supersedes all other agreements, covenants, representations or proposals, oral or
written, and all other communications between them relating to the subject matter of this Agreement.
In the event of a conflict between the terms and conditions of this Agreement and any Amendments to
this Agreement, the terms and conditions of the Amendment(s) shall prevail. In the event of a
conflict between the terms and conditions of this Agreement and any Schedules to this Agreement, the
terms and conditions of this Agreement shall prevail.

10 SEVERABILITY

Should any part of this Agreement for any reason be declared invalid by order of any court or
regulatory agency, such order shall not affect the validity of any remaining portion, which shall
remain in force and effect as if this Agreement had been executed with the invalid portion
eliminated, and it is hereby declared the intention of the parties that they would have executed the
remaining portion of this Agreement without including therein any such part or portion which may,
for any reason, be hereafter declared invalid.

11 CONTROLLING LAW AND ARBITRATION

All questions regarding the validity, interpretation, performance and enforcement of the provisions
of this Agreement shall be governed by the laws of the state of New York. Any controversy or claim
arising out of, relating to or in connection with this Agreement that has not been resolved through
the informal mediation of the parties shall be resolved through arbitration pursuant to the
Commercial Arbitration Rules of the American Arbitration Association then in effect, as modified by
the terms set forth below: (a) the arbitration shall be conducted in New York state; (b) the
arbitration shall be conducted by a single arbitrator selected by the parties; (c) the parties shall
act in a commercially reasonable manner and speedily select and then conduct the arbitration within
45 days with the expenditure of minimal discovery efforts and expense which shall be determined, if
necessary, by the arbitrator. The agreement to arbitrate shall be specifically enforceable under
prevailing New York law. Any award rendered by the arbitrator shall be binding and enforceable by
any party to the arbitration and judgment shall be rendered upon it in a court of competent subject
matter jurisdiction located in New York.

12 REGULATION FD

Regulation FD's public disclosure requirements include that material information must be disclosed
to all shareholders at the same time. Both companies recognize that the signing of this Agreement
creates a relationship that may be considered material news to both companies' shareholders. For
full compliance with Reg. FD, an issuance of a news release may be required. By signing this
agreement, both parties authorize a nationally recognized wire service to
<!-- page 3 -->
distribute a release regarding this agreement, drafted by Kingdom Ventures. Yournetplus shall have
the opportunity to review and approve any press release before it is distributed.

13 KCI AUTHORIZATION KCI represents that the person executing this Agreement has been duly
authorized by KCI to execute KCI to the terms and conditions contained herein. KCI, with full
knowledge of all terms and conditions herein, are not in conflict with any law or the terms of any
charter or bylaw or any agreement to which KCI is a party or by which it is bound or affected.

IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be executed on behalf of each
other by a person with full power and authority to bind such party.

Kingdom Connect, Inc. YourNetPlus.com

"KCI" "PROVIDER"

By: /s/ Gene Jackson By /s/ Vince Dim -------------------------------
------------------------------- Print Name: Gene Jackson Print Name: Vince Dima

Title: CEO Title: President ----------------------------

Date: 5/12/03 Date: 5/12/03 ----------------------------- -----------------------------
