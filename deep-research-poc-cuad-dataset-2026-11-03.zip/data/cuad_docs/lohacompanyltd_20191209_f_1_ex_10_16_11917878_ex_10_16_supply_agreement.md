<!-- page 1 -->
# SUPPLY CONTRACT
| Field | Value |
|---|---|
| Document Type | Supply Agreement |
| SEC Filing Date | 2019-12-09 |
| Parties | Shenzhen LOHAS Supply Chain Management Co., Ltd. ("buyer","End-User"); the seller |
| Source | CUAD v1 / LohaCompanyltd_20191209_F-1_EX-10.16_11917878_EX-10.16_Supply Agreement |

Exhibit 10.16 SUPPLY CONTRACT Contract No: Date: The buyer/End-User: Shenzhen LOHAS Supply Chain
Management Co., Ltd. ADD: Tel No. : Fax No. : The seller: ADD: The Contract is concluded and signed
by the Buyer and Seller on , in Hong Kong. 1. General provisions 1.1 This is a framework agreement,
the terms and conditions are applied to all purchase orders which signed by this agreement
(hereinafter referred to as the "order"). 1.2 If the provisions of the agreement are inconsistent
with the order, the order shall prevail. Not stated in order content will be subject to the
provisions of agreement. Any modification, supplementary, give up should been written records, only
to be valid by buyers and sellers authorized representative signature and confirmation, otherwise
will be deemed invalid. 2. The agreement and order 2.1 During the validity term of this agreement,
The buyer entrust SHENZHEN YICHANGTAI IMPORT AND EXPORT TRADE CO., LTD or SHENZHEN LEHEYUAN TRADING
CO, LTD (hereinafter referred to as the "entrusted party" or "YICHANGTAI" or "LEHEYUAN"), to
purchase the products specified in this agreement from the seller in the form of orders. 2.2 The
seller shall be confirmed within three working days after receipt of order. If the seller finds
order is not acceptable or need to modify, should note entrusted party in two working days after
receipt of the order, If the seller did not confirm orders in time or notice not accept orders or
modifications, the seller is deemed to have been accepted the order. The orders become effective
once the seller accepts, any party shall not unilaterally cancel the order before the two sides
agreed . 2.3 If the seller puts forward amendments or not accept orders, the seller shall be in the
form of a written notice to entrusted party, entrusted party accept the modified by written consent,
the modified orders to be taken effect. 2.4 Seller's note, only the buyer entrust the entrusted
party issued orders, the product delivery and payment has the force of law.

1

Source: LOHA CO. LTD., F-1, 12/9/2019
<!-- page 2 -->
3. GOODS AND COUNTRY OF ORIGIN: 4. Specific order: The products quantity, unit price,
specifications, delivery time and transportation, specific content shall be subject to the purchase
order issued by entrusted party which is commissioned the buyer. 5. PACKING: To be packed in new
strong wooden case(s) /carton(s), suitable for long distance transportation and for the change of
climate, well protected against rough handling, moisture, rain, corrosion, shocks, rust, and
freezing. The seller shall be liable for any damage and loss of the commodity, expenses incurred on
account of improper packing, and any damage attributable to inadequate or improper protective
measures taken by the seller in regard to the packing. One full set of technical All wooden material
of shipping package must be treated as the requirements of Entry-Exit Inspection and Quarantine
Bureau of China, by the agent whom is certified by the government where the goods is exported. And
the goods must be marked with the IPPC stamps, which are certified by the government agent of
Botanical-Inspection and Quarantine Bureau. 6. SHIPPING MARK: The Sellers shall mark on each package
with fadeless paint the package number, gross weight, net weight, measurements and the wordings:
"KEEP AWAY FROM MOISTURE","HANDLE WITH CARE" "THIS SIDE UP" etc. and the shipping mark on each
package with fadeless paint. 7. DATE OF SHIPMENT: According to specific order by YICHANGTAI or
LEHEYUAN. 8. PORT OF SHIPMENT:

2

Source: LOHA CO. LTD., F-1, 12/9/2019
<!-- page 3 -->
9. PORT OF DESTINATION: SHENZHEN, GUANGDONG, CHINA 10. INSURANCE: To be covered by the Seller for
110% invoice value against All Risks and War Risk. 11. PAYMENT: Under Letter of Credit or T/T: Under
the Letter of Credit: The Buyer shall open an irrevocable letter of credit with the bank within 30
days after signing the contract, in favor of the Seller, for 100% value of the total contract value.
The letter of credit should state that partial shipments are allowed. The Buyer's agent agrees to
pay for the goods in accordance with the actual amount of the goods shipped. 80% of the system value
being shipped will be paid against the documents stipulated in Clause 12.1. The remaining 20% of the
system value being shipped will be paid against the documents stipulated in Clause 12.2. The Letter
of Credit shall be valid until 90 days after the latest shipment is effected. Under the T/T The
trustee of the buyer remitted the goods to the seller by telegraphic transfer in batches as agreed
upon after signing each order. 12. DOCUMENTS: 12.1 (1) Invoice in 5 originals indicating contract
number and Shipping Mark (in case of more than one shipping mark, the invoice shall be issued
separately). (2) One certificate of origin of the goods. (3) Four original copies of the packing
list. (4) Certificate of Quality and Quantity in 1 original issued by the agriculture products base.
(5) One copy of insurance coverage (6) Copy of cable/letter to the transportation department of
Buyer advising of particulars as to shipment immediately after shipment is made.

3

Source: LOHA CO. LTD., F-1, 12/9/2019
<!-- page 4 -->
12.2 (1) Invoice in 3 originals indicating contract number and L/C number. (2) Final acceptance
certificate signed by the Buyer and the Seller. 13. SHIPMENT: CIP The seller shall contract on usual
terms at his own expenses for the carriage of the goods to the agreed point at the named place of
destination and bear all risks and expenses until the goods have been delivered to the port of
destination. The Sellers shall ship the goods within the shipment time from the port of shipment to
the port of destination. Transshipment is allowed. Partial Shipment is allowed. In case the goods
are to be dispatched by parcel post/sea-freight, the Sellers shall, 3 days before the time of
delivery, inform the Buyers by cable/letter of the estimated date of delivery, Contract No.,
commodity, invoiced value, etc. The sellers shall, immediately after dispatch of the goods, advise
the Buyers by cable/letter of the Contract No., commodity, invoiced value and date of dispatch for
the Buyers. 14. SHIPPING ADVICE: The seller shall within 72 hours after the shipment of the goods,
advise the shipping department of buyer by fax or E-mail of Contract No., goods name, quantity,
value, number of packages, gross weight, measurements and the estimated arrival time of the goods at
the destination. 15. GUARANTEE OF QUALITY: The Sellers guarantee that the commodity hereof is
complies in all respects with the quality and specification stipulated in this Contract. 16. CLAIMS:
Within 7 days after the arrival of the goods at destination, should the quality, specification, or
quantity be found not in conformity with the stipulations of the Contract except those claims for
which the insurance company or the owners of the vessel are liable, the Buyers, on the strength of
the Inspection Certificate issued by the China Commodity Inspection Bureau, have the right to claim
for replacement with new goods, or for compensation, and all the expenses (such as inspection
charges, freight for returning the goods and for sending the replacement, insurance premium, storage
and loading and unloading charges etc.) shall be borne by the Sellers. The Certificate so issued
shall be accepted as the base of a claim. The Sellers, in accordance with the Buyers' claim, shall
be responsible for the immediate elimination of the defect(s), complete or partial replacement of
the commodity or shall devaluate the commodity according to the state of defect(s). Where necessary,
the Buyers shall be at liberty to eliminate the defect(s) themselves at the Sellers' expenses. If
the Sellers fail to answer the Buyers within one weeks after receipt of the aforesaid claim, the
claim shall be reckoned as having been accepted by the Sellers.

4

Source: LOHA CO. LTD., F-1, 12/9/2019
<!-- page 5 -->
17. FORCE MAJEURE: The Sellers shall not be held responsible for the delay in shipment or
non-delivery, of the goods due to Force Majeure, which might occur during the process of
manufacturing or in the course of loading or transit. The Sellers shall advise the Buyers
immediately of the occurrence mentioned above and within fourteen days thereafter, the Sellers shall
send by airmail to the Buyers a certificate of the accident issued by the competent government
authorities, Chamber of Commerce or registered notary public of the place where the accident occurs
as evidence thereof. Under such circumstances the Sellers, however, are still under the obligation
to take all necessary measures to hasten the delivery of the goods. In case the accident lasts for
more than 10 weeks, the Buyers shall have the right to cancel the Contract. 18. LATE DELIVERY AND
PENALTY: Should the Sellers fail to make delivery on time as stipulated in the Contract, with
exception of Force Majeure causes specified in Clause 17 of this Contract, the Buyers shall agree to
postpone the delivery on condition that the Sellers agree to pay a penalty which shall be deducted
by the paying bank from the payment. The penalty, however, shall not exceed 5% of the total value of
the goods involved in the late delivery. The rate of penalty is charged at 0.5% for every seven
days, odd days less than seven days should be counted as seven days. In case the Sellers fail to
make delivery ten weeks later than the time of shipment stipulated in the Contract, the Buyers have
the right to cancel the contract and the Sellers, in spite of the cancellation, shall still pay the
aforesaid penalty to the Buyers without delay, the seller should refund the money received and pay
the 30% of the total goods price of the penalty 19. ARBITRATION: All disputes in connection with
this Contract or the execution thereof shall be settled friendly through negotiations. In case no
settlement can be reached, the case may then be submitted for arbitration to the Foreign Economic
and Trade Arbitration Committee of the China Beijing Council for the Promotion of International
Trade in accordance with its Provisional Rules of Procedures by the said Arbitration Committee. The
Arbitration shall take place in Beijing and the decision of the Arbitration Committee shall be final
and binding upon both parties; neither party shall seek recourse to a law court nor other
authorities to appeal for revision of the decision. Arbitration fee shall be borne by the losing
party. 20. This final price is the confidential information. Dissemination, distribution or
duplication of this price is strictly prohibited.

5

Source: LOHA CO. LTD., F-1, 12/9/2019
<!-- page 6 -->
21. Law application It will be governed by the law of the People's Republic of China ,otherwise it
is governed by United Nations Convention on Contract for the International Sale of Goods. 22.
<<Incoterms 2000>> The terms in the contract are based on (INCOTERMS 2000) of the International
Chamber of Commerce. 23. The Contract is valid for 5 years, beginning from and ended on . This
Contract is made out in three originals in both Chinese and English, each language being legally of
the equal effect. Conflicts between these two languages arising there from, if any, shall be subject
to Chinese version. One copy for the Sellers, two copies for the Buyers. The Contract becomes
effective after signed by both parties. THE BUYER: THE SELLER: SIGNATURE: SIGNATURE: 6

Source: LOHA CO. LTD., F-1, 12/9/2019
