<!-- page 1 -->
# Supply Agreement
| Field | Value |
|---|---|
| Document Type | Supply Agreement |
| Agreement Date | 2001-01-11 |
| Parties | MediWound Ltd. ("MediWound"); Challenge Bioproducts Corporation Ltd. ("CBC") |
| Source | CUAD v1 / MEDIWOUNDLTD_01_15_2014-EX-10.6-SUPPLY AGREEMENT |

Exhibit 10.6 MediWound Ltd. and Challenge Bioproducts Corporation Ltd. Supply Agreement — As amended
on February 28, 2010

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission.
<!-- page 2 -->
SUPPLY AGREEMENT This Supply Agreement ("Agreement") was made and entered into as of the 11 day of
January, 2001 by and between MediWound Ltd., a corporation organized and existing under the laws of
Israel (hereinafter referred to as "MediWound") and Challenge Bioproducts Corporation Ltd., a
corporation organized and existing under the laws of the Republic of China (hereinafter referred to
as "CBC") and amended by the parties on February 28, 2010 ("Amendment Effective Date"). WITNESSETH:
THAT Whereas MediWound and CBC have originally entered into this Agreement on the date stated above
(copy of which shall be attached hereto as Exhibit A); and Whereas, the parties hereto have agreed
to amend and add certain terms and conditions to this Agreement as of the Amendment Effective Date,
all as set forth and marked herein; and Whereas, CBC has invented and developed methods, processes
and equipment to manufacture, and produce Bromelain SP (as such term is defined below), specially
processed for transformation into a Bromelain-based pharmaceutical product derived from pineapple
stems, known as Debridase (the "Product"); and Whereas, subject to the going into effect of a
License Agreement dated September 27, 2000 between MediWound and Mark Klein (respectively, the
"Klein Agreement" and "Klein") as amended on June 19, 2007, MediWound shall have an exclusive
license under patents and other intellectual property, to develop, use, manufacture, market and sell
the Product for burn treatment in humans; and Whereas, MediWound desires to utilize Bromelain SP in
the development and commercialization of the Product and to subsequently purchase Bromelain SP in
bulk form to make and have made Product and pharmaceutical preparations thereof; and Whereas, CBC is
willing to supply Bromelain SP to MediWound for such purpose on the terms and conditions set forth
hereunder. NOW THEREFORE IN CONSIDERATION OF THE MUTUAL PROMISES AND COVENANTS SET FORTH HEREIN IT
IS HEREBY AGREED AS FOLLOWS:

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 2
<!-- page 3 -->
1. Definitions Terms defined in this Section 1 and elsewhere, parenthetically, in this Agreement,
shall have the same meaning throughout this Agreement. 1.1 "Affiliate" means any firm, person or
company which controls, is controlled by or is under common control with a party to this Agreement
and for the purpose of this definition the term "control" means the possession, directly or
indirectly of the power to direct or cause the direction of the management and policies of such
firm, person or company whether through the ownership of voting securities, by contract or otherwise
or the ownership either directly or indirectly of 20% (twenty percent) or more of the voting
securities of such firm, person or company. 1.2 "Approval" means the grant of all necessary
governmental and regulatory approvals required for the marketing, distribution and sale of a
pharmaceutical product in any particular country, by a Regulatory Authority, and approvals required
for pricing and reimbursements (if appropriate). 1.3 "Bromelain SP" means material derived from
pineapple stems, [having the specification as presented in exhibit 1.13] presently manufactured by
CBC at the Facility by a special process and used as a raw material in the production of the
Product. 1.4 "Conditions Precedent" means the cumulative conditions listed in Section 2.1. 1.5
"Effective Date" shall have the meaning ascribed to such term in Section 2.2. 1.6 "Facility" means
CBC's production facility in Tou-Liu City, Yun-Lin Hsien, Taiwan, R.O.C. 1.7 "FDA" means the Food
and Drug Administration of the United States Government or any successor thereto. 1.8 "Klein" means
Mr. Mark C. Klein. 1.9 "LR" means either or both of L.R. R & D Ltd. and/or Professor Lior Rosenberg.
1.10 "Major Country" means the USA, and the major European and Asian countries listed in Exhibit
1.10 attached hereto. 1.11 "MOU" means the Memorandum of Understanding of January 18, 2000 between
MediWound (as assignee of Clal Biotechnology Industries Ltd.), Klein and CBC. 1.12 "Regulatory
Authority" means the FDA or similar governmental or other agency in any country having authority to
grant Approval. 1.13 "Specifications" means the specifications for Bromelain SP set forth as Exhibit
1.13 hereto, as the same may be amended with the consent of both parties hereto, it being agreed
that no amendment may be made thereto or refused which would

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 3
<!-- page 4 -->
render Product incapable of application on humans or the use, supply or sale thereof in breach of
any regulations. 1.14 "Sub-Contractor" means any firm or company whose services are retained by
MediWound to transform Bromelain SP into Product and to package, label and deliver pharmaceutical
preparations of the Product in finished form to MediWound and its sub- licensees. All references to
"MediWound" under Sections 3.1, 5, 6 and 7.1 shall be construed as being inclusive of Sub-
Contractors, unless the context dictates otherwise. 1.15 "Technical Information" means that
information in use at the Facility during the term of this Agreement, relating to the manufacture of
Bromelain SP meeting the Specifications, in bulk, as more comprehensively described in Section 1.15
of the TT Agreement. 1.16 "TT Agreement" means the Technology Transfer Agreement dated January 11,
2001 between the parties hereto, whereby CBC undertakes to transfer the Technical Information to
MediWound. 2. Conditions Precedent 2.1 Conditions Precedent to the provisions of this Agreement
becoming effective shall be all of the following: 2.1.1 Execution of a License Agreement between
MediWound and LR whereby MediWound shall license certain Product-related know-how from LR; and 2.1.2
Execution of the TT Agreement. 2.2 The date upon which MediWound shall have acknowledged in writing
to CBC that the Conditions Precedent have all been met shall be the "Effective Date". Where the
Conditions Precedent have not been met by January 31, 2001, for any reason whatsoever, then this
Agreement and the MOU shall be deemed terminated as of that date with no further liability of either
party, except for the obligation of confidentiality, as set forth in the MOU. 3. Grant of Rights 3.1
As from and subject to the Effective Date, and subject to the terms and conditions of this
Agreement, CBC shall supply Bromelain SP to MediWound and MediWound shall acquire Bromelain SP from
CBC, for transformation into the Product. 3.2 MediWound's rights as per Section 3.1 will be
exclusive in the sense that CBC shall not nor shall permit any Affiliate or third party to
manufacture, use, supply

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 4
<!-- page 5 -->
or sell Bromelain SP for utilization as an ingredient of any product which directly or indirectly
competes with the Product. 4. Financial Provisions 4.1 In consideration for CBC's undertaking to
supply Bromelain SP to MediWound and other obligations of CBC pursuant to this Agreement, MediWound
has paid to CBC US$ [***] (US Dollars [***]) within 3 (three) business days of the Effective Date.
4.2 Payments for supply of Bromelain SP by CBC to MediWound as of the Amendment Effective Date shall
be made in accordance with the following provisions: 4.2.1 The price of [***] Kg of an accepted
batch of Bromelain SP (by MediWound pursuant to Section 6.4) shall be in accordance with the price
per annual quantity table in Exhibit 4.2 attached hereto. The price used for invoicing during the
year shall be based on the quantity in the Annual Forecast. At the end of each year the parties
shall recalculate the amounts to be paid pursuant to the actual quantities purchased throughout the
passing year and adjust the payments accordingly (for example: if the actual quantity purchased
during the past year was higher than the Annual Forecast and such higher quantity should have been
invoiced as per a lower price per Kg of Bromelain SP in accordance with price per annual quantity
table in Exhibit 4.2, CBC shall recalculate the invoices for the past year as per the actual price
that should have been invoiced and credit MediWound for the balance within [***] days accordingly.
If the actual quantity purchased during the past year was lower than the Annual Forecast and such
lower quantity should have been invoiced as per a higher price per Kg of Bromelain SP in accordance
with price per annual quantity table in Exhibit 4.2, CBC shall recalculate the invoices for the past
year as per the actual price that should have been invoiced and invoice MediWound for the balance
within [***] days accordingly). 4.2.2 CBC may increase the prices only pursuant to an increase in
its cost of manufacturing of the Bromelain SP. Any such increase shall be subject to MediWound's
pre-approval, and no increase shall be executed more often than once every [***] months and any
changes thereto shall be in-line with current market prices for Bromelain manufacturing except that
(i) there is a change of cost of manufacturing of Bromelain SP due to a change requested by
regulatory agency and confirmed by MediWound; and (ii) the Taiwan official Wholesale Price Index
varies over [***]% within [***] months. When such exceptional situations arise, an increase

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 5
<!-- page 6 -->
of price shall be considered by MediWound at CBC's written request without the limit of no more
often than once every [***] months. 4.2.3 MediWound shall make payment for each Bromelain SP batch
that was supplied by CBC on a [***] days basis as of the date of delivery of the applicable batch at
MediWound, provided that MediWound has provided CBC with an Acceptance Batch Notice for such
purchased batch pursuant to Section 6.4. Payment for each purchase batch shall be effected by
MediWound by swift to a bank account designated by CBC, or by other requested method as agreed
between the parties. MediWound shall make down payment of USD[***]/kg for the [***]% of the amount
of Annual Forecast before Dec.31 of the respective year for the insurance of components and
materials and maintenance of manufacture and supply capacity of the requested [***]% of the next
calendar year's Annual Forecast. The down payment will be then deducted respectively as every
shipment is made to MediWound and listed in CBC's Invoice to MediWound. 4.2.4 Payment shall be made
directly to CBC for payment for each order of Bromelain SP or, at CBC's written request, to Golden
Life International Co., Ltd. on CBC's behalf, for payments other than any order of Bromelain SP
("Payee"); provided however, that any such payment to the Payee shall be considered as valid payment
to CBC (as if made directly to CBC) in accordance with this Agreement, and that so long as such
payment is made in accordance with CBC's said request, CBC shall have no claims or demands against
MediWound for non-payment or in any other respect whatsoever in this regard. CBC solely shall be
responsible to ensure that payment by MediWound to the Payee pursuant to CBC's request does not
violate any applicable laws and regulations. Any tax implications due to payment to the Payee in
accordance with CBC's request shall be borne by CBC. For avoidance of doubt, it is clarified that
the Payee shall not be considered as a third party beneficiary under this Agreement and shall not
have any rights to enforce payment or any other rights of CBC under this Agreement. 4.2.5 Invoices
shall only be issued upon delivery of the Bromelain SP batch which shall take place only after CBC's
quality control department has completed its testing and authorized delivery to MediWound, and
MediWound's quality control department has provided CBC with an Acceptance Sample Notice for that
batch and that the batch itself can be delivered.

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 6
<!-- page 7 -->
4.2.6 The consideration to be paid pursuant to this Agreement is final and inclusive of all taxes
and/or duties, of whatsoever nature. If applicable laws require the withholding of taxes, MediWound
will deduct the taxes from the related payment otherwise due to CBC, and such taxes shall be paid to
the proper taxing authority. For avoidance of doubt, payments will be made only after receiving
exemption from tax deduction approval from the tax authority in Israel. Delay in payment as a result
of not receiving such exemption will not constitute late payment or breach hereunder. 5. Manufacture
of Bromelain SP 5.1 Without derogating from CBC's representations and warranties herein, CBC and
MediWound shall work together in order to enable the CBC facility to accomplish all required
standards, related to the manufacturing, packaging and delivering of Bromelain SP in accordance with
the Specifications, GACP (Good Agricultural and Collection Practice) and cGMP (Current Good
Manufacturing Practice) standards, ISO 22000 and all other applicable laws and regulations. For such
purpose, and without derogating from other terms herein, CBC shall permit MediWound, and/or a
consultant on MediWound's behalf, to access and inspect the CBC facility and advise MediWound and/or
CBC on such actions to be taken for accomplishing such compliance. Such mutual regulatory
preparations shall begin no later than the finalization of MediWound's current phase III clinical
trial. CBC warrants and represents that all Bromelain SP shall be manufactured and supplied in
compliance with the Specifications, quality control methods and test methods, all applicable SOP's
and all applicable laws, and in accordance with GACP, cGMP, including the relevant guidelines,
policies, codes, requirements, regulations, approvals and/or standards from time to time promulgated
or issued by any relevant governmental and/or regulatory authority which relate to the manufacture
of the Bromelain SP to be used for the production of a pharmaceutical agent as the Product. CBC
warrants further that CBC has, and will for the duration of this Agreement retain, all applicable
regulatory approvals required for the carrying out of its obligations hereunder, including without
limitation the manufacturing, packaging and supply of the Bromelain SP. 5.2 All manufacturing,
packaging and labeling activities done at CBC will be performed according to the pre-approved batch
records. If CBC wishes to make changes to the Specifications, the production and/or packaging batch
records, the SOPs related to the Bromelain SP, or the design of the manufacturing process or any
other change during production which would effect the quality of the

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 7
<!-- page 8 -->
Bromelain SP or of the Product and/or otherwise would effect the Bromelain SP in any way or which
might effect the regulatory approvals of the Product, then CBC shall (i) notify MediWound in writing
at least 6 months in advance regarding such proposed changes, and (ii) represent that such change
will not adversely effect the quality of the Bromelain SP or of the Product in any way, and (iii)
not make such changes without MediWound's prior written approval, and (iv) will assure that such
change will not delay or in any way effect any open orders for Bromelain SP. 5.3 MediWound shall
participate and support the upgrade of the Facility and the generation of documentation for
submission to the relevant Regulatory Authorities, all as may be determined to be necessary and
appropriate, by independent regulatory consultants, designated by mutual consent. Such participation
and support shall be in the form of an investment made by MediWound in the CBC facility, not to
exceed $[***] (US Dollars [***]). 5.4 CBC undertakes to keep all records reasonably required by
MediWound relating to the manufacture, quality control and testing of Bromelain SP. Such records
shall include, but not be limited to, all records required by applicable laws and regulations, of
the territories in which the Product is marketed and sold. MediWound (itself or through anyone on
its behalf) or any relevant regulatory authority shall have the right to audit any such records
and/or the relevant facilities of CBC (or any facilities of any CBC third party or subcontractor
involved in the manufacture, quality control and/or supply of the Bromelain SP) with reasonable
prior notice, during regular business hours, including the right to ask CBC to provide any relevant
documents. CBC shall inform MediWound of any announced regulatory inspections that directly involve
the Bromelain SP or the Product within 48 hours of the notification to CBC of such an inspection.
5.5 During the term of this Agreement, CBC shall make available to MediWound any and all information
and data which it generates or which comes into its possession relating to any improvements in the
manufacture and supply of the Bromelain SP. CBC shall, throughout the term of this Agreement, assist
MediWound in all respects with regard to regulatory submission including but not limited to
providing any information, data or documents in its possession. If any regulatory agency requests
any changes to the Specifications or the manufacturing process, (including but not limited to any
changes as a result of an audit performed) CBC shall (i) inform MediWound in advance and in writing
of the changes needed to be made, and (ii) promptly advise MediWound as to any lead-time changes or
other terms which may result therefrom, and (iii) make such changes, in coordination with MediWound
as soon as possible.

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 8
<!-- page 9 -->
5.6 Sampling and Testing Procedures 5.6.1 The sampling procedures of incoming raw materials,
packaging materials, in process control and released Bromelain SP shall be agreed between CBC and
MediWound and conducted by CBC as per CBC's signed SOP as approved by MediWound. 5.6.2 MediWound and
CBC will jointly agree and update from time to time as applicable the incoming raw materials,
in-process and release testing methods applicable to the Bromelain SP. 5.6.3 CBC will test each
batch of Bromelain SP for conformance with the batch Specifications, and for each batch of the
Bromelain SP supplied by CBC, CBC will provide a certificate of analysis signed and dated by the
responsible person at CBC, who has released the batch. 5.6.4 For each batch provided, CBC shall
provide to MediWound a copy of the batch production and packaging execution records and shall retain
such original records for one (1) year beyond the shelf-life of the Bromelain SP unless required by
MediWound or under applicable laws and regulations to maintain the records for a longer period of
time. 5.7 Quality Assurance — Investigations 5.7.1 Any deviation from the production process during
the manufacture thereof shall be explained and documented in batch records. Any deviation that may
impact on the safety/quality of the Bromelain SP or the Products and on other related issues will be
investigated by CBC, and communicated to MediWound within 48 hours from the time of discovery.
Following the investigation, the relevant corrective actions shall be taken and implemented. 5.7.2
CBC shall perform an out-of-specifications investigation in respect of batches that do not meet the
batch Specifications. 5.7.3 Each investigation shall be reviewed by a CBC designated quality
representative, and will follow the procedures recommended by regulatory agencies and as set out in
relevant CBC SOP's. All completed investigation reports and other written documentation relating to
all investigations shall be provided to MediWound and shall be included in the applicable released
and executed batch records. Any corrective actions shall be discussed and agreed by the parties
before being executed by CBC.

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 9
<!-- page 10 -->
5.8 Quality Complaints; Recall 5.8.1 MediWound and CBC shall notify each other immediately by an
e-mail, of any information concerning the quality and/or malfunction of the Bromelain SP. The
parties will investigate all complaints, and shall respond in accordance with mutually agreed SOP's.
Both parties shall comply with requirements of all regulatory authorities in dealing with
complaints. MediWound shall have the right to determine whether any adverse event should be reported
to any applicable regulatory authority. All quality assurance and/or quality complaints shall be
handled in accordance with this section above. 5.8.2 In the event that CBC has any reason to believe
that the Bromelain SP or one or more Products should be recalled or withdrawn from distribution, CBC
shall immediately notify MediWound in writing. In such event MediWound shall, at MediWound's sole
discretion, determine whether to recall or withdraw the Product from the market. 5.8.3 If a recall
of the Product is due to CBC or the Bromelain SP, then the recall shall be conducted by MediWound at
CBC's expense, and CBC shall replace such Bromelain SP at no charge to MediWound or shall provide
MediWound with a credit or refund of same, at MediWound's election. 5.9 Storage CBC shall store, in
accordance with the applicable CBC SOP, free of charge, Bromelain SP batches at its premises in
appropriate storage conditions, for up to ninety (90) days from the day of the Acceptance Sample
Notice for the respective batch or longer if CBC was unable to deliver such batch to MediWound
earlier following the Acceptance Sample Notice. The Bromelain SP shelf life and designated packaging
shall be in accordance with CBC SOP and subject to the supportive results of a proper stability
study. 5.10 Retention of Samples CBC shall retain samples of Bromelain SP stored at their original
package from each batch for the duration of the Products' shelf- life and for a period of one (1)
additional year thereafter, in quantities sufficient to enable the performance of two (2) CBC's full
release tests in accordance with the CBC's release specifications and release methods. 6. Supply of
Bromelain SP 6.1 MediWound undertakes to purchase, and CBC undertakes to furnish, supply and deliver
Bromelain SP to MediWound, in bulk, on the terms and conditions hereinafter set forth.

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 10

6.2 MediWound shall furnish CBC with a non-binding forecast of its anticipated annual requirements
of Bromeline SP by no later than November 1 of each year ("Annual Forecast"), for the next calendar
year. Notwithstanding the foregoing, the first forecast for the calendar year that commenced on
January 1, 2001, was furnished by MediWound to CBC by March 15, 2001. MediWound undertakes to order
at least [***]% of the Annual Forecast per each year. CBC shall maintain, at all times, manufacture
and supply capacity of at least [***]% of the Annual Forecast and shall maintain, in coordination
with MediWound, inventory of Bromelain SP at its premises of (i) at least [***]% of the applicable
Annual Forecast; and (ii) all Bromelain SP components and materials ("the BSP Components and
Materials") needed for the manufacture and supply of the Bromelain SP such that CBC can guarantee
continuous supply of the Bromelain SP in accordance with MediWound's complete Annual Forecasts. In
addition, the inventory of the BSP Components and Materials shall not be less than needed to
manufacture [***] months stock of Bromelain SP (compared to the open purchase orders and the
applicable Annual Forecast) or longer (respectively) for BSP Components and Materials having a lead
time of more than [***] months. CBC shall provide MediWound with quarterly inventory and production
reports for Bromelain SP and BSP Components and Materials. Purchase orders issued by MediWound to
CBC for quantities within the [***]% of the Annual Forecast shall be binding upon CBC and shall be
deemed accepted upon delivery of the purchase order to CBC. Such purchase orders shall be supplied
on the date specified in the applicable purchase order provided that the lead time in any purchase
order shall be at least [***] days as of the purchase order's date. Purchase orders issued by
MediWound to CBC during a certain year for quantities exceeding [***]% of the applicable Annual
Forecast shall be binding upon CBC, except that with respect to any amounts exceeding [***]% of the
applicable Annual Forecast, CBC's obligation to provide such exceeding quantities shall be based on
best efforts and CBC shall have an extended lead time for delivery as shall be agreed upon by the
parties on a case by case basis. CBC shall confirm in writing, within 5 days of its acceptance of
such exceeding purchase order, and shall state the anticipated delivery date for the exceeding
amounts. Without derogating from CBC's obligations under this Agreement, in the event that CBC is
unable to supply all the Bromelain SP covered under any purchase order on the dates specified in the
applicable supply plans, CBC shall promptly notify MediWound in writing in a separate notice to
MediWound of such delay or noncompliance. In such event, and without prejudice to any other
<!-- page 11 -->
remedies

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 11
<!-- page 12 -->
available to MediWound, CBC shall use its best efforts to fully comply with the purchase order as
soon as possible. 6.3 CBC shall be responsible to prepare the shipment of Bromelain SP in accordance
with a shipment SOP. Such shipment SOP shall comply with the regulatory requirements as well as
specify the documents that should accompany any shipment (i.e. pro forma invoice, value for customs,
specific declaration, and specific requirement for investigational products). CBC shall provide
MediWound with copies of documents and reports with respect to each shipment of Bromelain SP, for
quality assurance, quality control and regulatory purposes. 6.4 Prior to delivery of each batch of
Bromelain SP, CBC shall submit a batch sample to MediWound for inspection and approval. MediWound
shall have the right, for a period of [***] days following receipt, to reject any Bromelain SP
sample which: 6.4.1 fails to comply with MediWound's purchase order; or 6.4.2 fails to comply with
the sample incoming inspection Specifications. Within the said [***] days, MediWound shall notify
CBC of either: (i) its approval and acceptance of such batch sample ("Acceptance Sample Notice"); or
(ii) its rejection of the batch sample in which case MediWound shall detail the reason(s) for the
rejection of any such Bromelain SP sample. In the event of rejection by MediWound, CBC shall deliver
complying Bromelain SP sample to MediWound within [***] days of rejection, free of cost (including
transportation, duty, handling and insurance costs). For clarification purposes, MediWound's
Acceptance Sample Notice in accordance with this section above shall in no event derogate from CBC's
responsibilities hereunder. After CBC receives MediWound's Acceptance Sample Notice, CBC shall
deliver the corresponding batch to MediWound for inspection and approval. MediWound shall have the
right, for a period of [***] days following receipt, to reject any Bromelain SP batch which: 6.4.3
fails to comply with MediWound's purchase order; or 6.4.4 fails to comply with the batch incoming
inspection Specifications. Within the said [***] days, MediWound shall notify CBC of either: (i) its
approval and acceptance of such batch ("Acceptance Batch Notice"); or (ii) its rejection of the
batch in which case MediWound shall detail the reason(s) for the rejection of any such Bromelain SP
batch. In the event of rejection by MediWound, at CBC's request and expense, MediWound shall return
any such Bromelain SP batch to CBC and CBC shall deliver complying Bromelain SP

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 12
<!-- page 13 -->
batch to MediWound within [***] days of rejection, free of cost (including transportation, duty,
handling and insurance costs). For clarification purposes, MediWound's Acceptance Batch Notice in
accordance with this section above shall in no event derogate from CBC's responsibilities hereunder.
6.5 If there is a dispute between the parties as to whether any Bromelain SP sample or batch
complies with the sample or batch Specifications respectively and/or with the quality requirements
set forth herein and/or under the law, then, without derogating from MediWound's remedies under this
Agreement or at law, such dispute shall be resolved by mutual investigation of the parties which
shall be conducted in good faith. If the parties are still unable to resolve such dispute, an
independent, mutually agreed third party shall be retained as a consultant to review batch records
and related documentation. Such consultant's determination in respect of the conformity of a sample
or batch shall be binding upon the parties. The non-prevailing party shall bear the costs of
consultant's services as well as for the production of the batch and corrective actions. If
appropriate, pursuant to such investigation and/or consultant's determination, CBC shall replace the
non-complying Bromelain SP within 30 (thirty) days thereafter, free of cost (including
transportation, duty, handling and insurance costs). 6.6 CBC, at its own cost, shall obtain and
shall cause to remain in effect, such licenses, permits, approval and consents as may be required
for its performance hereunder, including, without limitation, export of Bromelain SP from the
Republic of China. 7. Liability and Indemnity 7.1 CBC shall defend and assume responsibility for any
suit, claim or other action by a third party alleging that MediWound's use of Bromelain SP infringes
any patents or other rights of such third party. 7.2 MediWound shall be solely responsible for the
commercialization of the Product, e.g. the completion of development, final formulation, the conduct
of clinical trials (as necessary), labeling and packaging, as well as the due preparation and
submission of all documentation required for the prosecution of registration and Approval of the
Product in each of the countries in the Territory. MediWound shall assume all liabilities arising
from the development, commercialization, use, offer for sale, sale or supply by, through or on
behalf of MediWound or its Affiliates, of the Product (and related materials). 7A. Insurance In
order to provide insurance coverage for CBC responsibilities, obligations and undertakings as set
out under this Agreement and/or as required under any law with

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 13
<!-- page 14 -->
respect to the manufacturing of Bromelain SP, CBC undertakes, at its sole cost and expense, to take
out and maintain an "All risk" insurance against loss of and destruction or damage to the Facility
(including fire, theft and vandalism, etc.), third party liability insurance, product liability
insurance for the Bromelain SP and employers liability insurance. Without prejudice to the above,
CBC shall maintain, or shall cause to be maintained with respect to itself and each of its
Affiliates, such types and levels of insurance (including, without limitation, third party and
product liability insurance), as are customary in the pharmaceutical or manufacturing industry to
provide coverage for their activities contemplated hereby. Upon request of MediWound, CBC shall keep
MediWound informed of the general parameters of its liability insurance program and any proposed
substantive changes therein. Upon request, CBC shall furnish MediWound certification of insurance
(and/or true copies of policies) showing the above coverage, signed by an authorized agent of the
insurance company, certifying that liability assumed under this Agreement is fully insured without
exception, and providing for at least thirty (30) days prior written notice. 7B. Limitation of
Consequential Damages EXCEPT FOR BREACH OF CONFIDENTIALITY OBLIGATION HEREUNDER, AND TO THE EXTENT
PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL EITHER PARTY BE LIABLE FOR SPECIAL, PUNITIVE,
INDIRECT, INCIDENTAL OR CONSEQUENTIAL DAMAGES, INCLUDING WITHOUT LIMITATION LOSS OF USE, DATA OR
LOST PROFITS, EVEN IF IT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, WHETHER UNDER THIS
AGREEMENT, IN TORT OR OTHERWISE. 8. Confidentiality 8.1 CBC and MediWound undertake to each other to
keep, and shall procure that their respective Affiliates, employees, directors, officers,
consultants and contractors (including those of any Affiliate) shall keep, confidential all
information received from each other during or in anticipation of this Agreement however obtained
and in whatever form (the "Confidential Information"). For clarification purposes, any information,
materials and know-how related to the Product and/or provided by MediWound in connection with this
Agreement including any related intellectual property rights, shall be owned solely by MediWound and
shall constitute MediWound's Confidential Information which may be used by CBC solely for the
purpose of manufacturing and supply of Bromelain SP to MediWound. Confidential Information shall not
include the following:

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 14
<!-- page 15 -->
8.1.1 information which at the time of disclosure by one party to the other is in the public domain;
8.1.2 information which after disclosure by one party to the other becomes part of the public domain
by publication except by breach of this Agreement; 8.1.3 information which the receiving party can
establish by competent proof was already in its possession at the time of its receipt and was not
acquired directly or indirectly from the other party; and 8.1.4 information received from third
parties who were lawfully entitled to disclose such information. 8.2 Any Confidential Information
received from the other party shall not be disclosed or used for any purpose other than as provided
or anticipated under this Agreement. 8.3 The confidentiality and non-use obligations contained in
this Agreement shall continue for the duration of this Agreement and for a period of 5 (five) years
after termination or expiry of this Agreement, provided however that any Confidential Information
with respect to the Product, including without limiting, such information with respect to
intellectual property rights in connection with and/or related to the Products shall remain
confidential in perpetuity. 8.4 The provisions of this Section 8 shall in no event prevent MediWound
from disclosing any Technical Information to Regulatory Authorities or other governmental agencies
in support of any application for regulatory approvals of the Product or any amendments thereof or
in general whenever required to disclose such information under any applicable law or regulation.
MediWound shall make reasonable efforts to notify CBC of its intention and the identity of the
intended recipient as soon as reasonably practicable and if possible, prior to the date of
disclosure. 9. Duration This Agreement shall come into force on the Effective Date and the
amendments herein shall be in effect as of the Amendment Effective Date. This Agreement as amended
shall continue in force until terminated in accordance with the provisions of Section 10. 10.
Termination 10.1 MediWound may terminate this Agreement at any time, by 6 (six) months prior notice
in writing.

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 15
<!-- page 16 -->
10.2 CBC may terminate this Agreement by no less than 24 (twenty four) months notice given in
writing by CBC to MediWound, or such greater period as may be reasonable for MediWound to establish
an alternative source of manufacture of Bromelain SP and/or to acquire sufficient inventory of
Bromelain SP for a 24 (twenty four) months period. 10.3 In the event of any breach of this Agreement
at any time, if the breach complained of shall not be corrected by the breaching party within 90
(ninety) days of the other party's notice, either party hereto may, at its option: 10.3.1 by giving
90 (ninety) days written notice, specifying the breach complained of, terminate this Agreement, and
the party asserted to be in breach shall have the right to treat the alleged breach as a dispute
under Section 15; or 10.3.2 regard the breach and any failure to cure as the basis for a dispute and
proceed to dispute resolution under Section 15 and such legal or equitable remedy as shall be
applicable. 11. Effects of Termination 11.1 Upon termination of this Agreement, the parties shall
abide by and uphold any and all rights or obligations accrued or existing as of the termination
date, including, without limitation with respect to outstanding orders for Bromelain SP placed
hereunder. 11.2 Any rights or remedies of either party arising from any breach of this Agreement
shall continue to be enforceable after termination of this Agreement, unless previously waived in
writing. 12. Assignment 12.1 Subject to Section 12.2, neither party shall assign its rights or
obligations hereunder, in whole or in part, except with the prior written consent of the other
party, except to a party acquiring all of the business of the assigning party to which this
Agreement relates. Prior to any such permitted assignment the party wishing to effect the
transaction shall procure that the third party concerned covenants directly with the other party to
this Agreement to comply with the provisions of this Agreement, which shall be binding on it as the
successor and assign of such party. 12.2 MediWound may assign all of its rights and obligations
under this Agreement or perform some or all of its obligations under this Agreement through its
Affiliates and Sub-Contractors, provided that MediWound shall remain solely responsible for and be
guarantor of the performance by its Affiliates and Sub-Contractors and

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 16
<!-- page 17 -->
procure that its Affiliates and Sub-Contractors comply fully with the provision of this Agreement in
connection with such performance. 13. Miscellaneous 13.1 Failure or delay by either party in
exercising or enforcing any right or remedy under this Agreement in whole or in part shall not be
deemed a waiver thereof or prevent the subsequent exercise of that or any other rights or remedy.
13.2 CBC and its employees and MediWound and its employees shall at all times be considered as
independent contractors of each other, and at no time or under any circumstances shall they be
considered employees, representatives, partners or agents of each other. 13.3 This Agreement shall
constitute the entire agreement and understanding of the parties relating to the subject matter of
this Agreement and supersede all prior oral or written agreements, understandings or arrangements
between them relating to such subject, except for the TT Agreement. The MOU shall be deemed so
superseded by this Agreement only upon the Effective Date. 13.4 Other than as explicitly amended and
marked herein, all applicable terms and conditions of the Agreement as originally executed by the
parties shall remain without change and shall continue to be binding and in full force and effect.
No change or addition may be made to this Agreement except in writing signed by the duly authorized
representatives of both parties. 13.5 The provisions intended by their nature to survive the
termination or expiration of this Agreement shall so survive including without limiting Sections 1,
3.2, 5.1, 5.2, 5.4, 5.8, 5.10, 7, 7A, 7B, 8, 11, 13 (as amended), 14 and 15. Without derogating from
the foregoing, it is clarified that the restriction with respect to MediWound's intellectual
property and CBC's obligations under the TT Agreement as well as MediWound's exclusive rights under
this Agreement (as amended) shall continue to apply and survive the termination or expiration of the
Agreement. 14. Notices 14.1 Any notice or other document given under this Agreement shall be in
writing in the English language and shall be given by hand or sent by prepaid airmail, by facsimile
transmission or electronic mail to the address of the receiving party as set out below unless a
different address, facsimile number or e-mail address has been notified to the other in writing for
this purpose. 14.2 MediWound's address for service of notices and other documents shall be:-

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 17
<!-- page 18 -->
MediWound Ltd. 42 Hayarkon St., 81227 Yavne Israel Tel: +972 8 932 4010 Fax: +972 8 932 4011 E-Mail:
[***] 14.3 CBC's address for service of notices and other documents shall be:- Challenge Bioproducts
Corporation, Ltd. 17 Tou-Kong 12 Rd., Tou-Liu City, Yun-Lin Hsien, Taiwan, R.O.C., ("CBC")
Facsimile: +55-5572-045 E-Mail: [***] 15. Governing Law and Disputes 15.1 This Agreement is made
under and subject to the provision of the substantive laws of the State of New York, without giving
effect to its conflict of law rules. 15.2 Any disputes relating to this Agreement of whatever nature
that cannot be resolved by negotiation between the parties shall be referred for final resolution to
arbitration in New York City by 3 (three) Arbitrators under the Rules of the American Arbitration
Association. The arbitration proceedings shall be conducted in English. The decision of the
arbitrators shall be final and binding upon the parties and their legal successors. The arbitrators
may at their discretion, provide for discovery by the parties not to exceed 4 (four) months from the
date of notice of arbitration and the arbitrators shall notify the parties of their decision in
writing within 30 (thirty) days of the completion of the final hearing. The arbitrators may at their
discretion award costs and expenses in respect of the arbitration. 15.3 The parties submit to the
exclusive jurisdiction of the courts of the State of New York.

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 18

IN WITNESS WHEREOF, the parties, each by its duly authorized signatory, have caused this Agreement
to be executed as of the date first above- mentioned.

/s/ Gal Cohen

/s/ Ching-Kuan Lin

MediWound Ltd.

Challenge Bioproducts Corporation Ltd.

By: Gal Cohen

By: Ching-Kuan Lin

Its: Chief Executive Officer

Its: President

MediWound Ltd.

Challenge Bioproducts Co., Ltd.

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 19
<!-- page 19 -->
List of Exhibits Exhibit 1.13 - Current Bromelain SP Specifications Exhibit 4.2 - Price list per
annual quantity Exhibit A - a copy of this Supply Agreement as originally signed on 11/1/2001

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 20
<!-- page 20 -->
Exhibit 1.13 — Current Bromelain SP Specifications [***]

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission.

Exhibit 4.2 — Price list per annual quantity
<!-- page 21 -->
MediWound Ltd. 42 Hayarkon Street, Yavne, Israel Tel: 972-8-9324010 www.mediwound.com

Supply Agreement as amended on Feb 28 2010. Exhibit 4.2 — Price list per annual quantity The price
of [***]Kg of released BSP below an annual ordered quantity of [***] Kg shall be USD[***]/Kg [***].
The price of [***]Kg of released BSP above an annual ordered quantity of [***] Kg shall be between
USD[***]/Kg [***], as jointly agreed and set between CBC and MW, once the forecasted annual ordered
quantity exceeds [***] Kg of released BSP. Challenge Bioproducts Corporation Ltd: Date: 2011.10.12

Signature: /s/ Ching-Kuan Lin

MediWound Ltd.

Date:

Signature: /s/ Gal Cohen

Chief Executive Officer

MediWound, Ltd.

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission.

th
<!-- page 22 -->
Exhibit A - a copy of this Supply Agreement as originally signed on 11/1/2001 [Omitted: Agreement no
longer in effect]

*** Confidential treatment has been requested for redacted portions of this exhibit. This copy omits
the information subject to the confidentiality request. Omissions are designated as [***]. A
complete version of this exhibit has been provided separately to the Securities and Exchange
Commission. 1
