<!-- page 1 -->
# Second Amendment to Credit Agreement — Halvorsen Marine Holdings
| Field | Value |
|---|---|
| Document Type | Amendment |
| Effective Date | 2026-01-20 |
| Parties | Halvorsen Marine Holdings, Inc.; Meridian Trust Bank, N.A. |
| Facility ID | FAC-2025-0042 |
| Version | Second Amendment |

THIS SECOND AMENDMENT TO CREDIT AGREEMENT (this "Amendment") is entered into as of 2026-01-20 (the "Second Amendment Effective Date") among Halvorsen Marine Holdings, Inc. (the "Borrower"), the Lenders party hereto and Meridian Trust Bank, N.A., as Administrative Agent.

## Recitals
WHEREAS, the Borrower, the Lenders and the Administrative Agent are parties to that certain Credit Agreement dated as of 2025-02-14, as amended by the First Amendment dated as of 2025-07-31 (the "Credit Agreement"; facility FAC-2025-0042);
WHEREAS, the Borrower has requested an increase in the Aggregate Commitment and an extension of the Maturity Date;
NOW, THEREFORE, the parties agree as follows.
<!-- page 2 -->
## Section 1 — Amendments to the Credit Agreement
Effective as of the Second Amendment Effective Date, the Credit Agreement is amended as follows:
1.1 Section 2.1 and the definition of "Aggregate Commitment" are amended by replacing "$150,000,000" with "$175,000,000", so that the Aggregate Commitment is $175,000,000.
1.2 The definition of "Maturity Date" in Section 1.1 is amended by replacing "2030-02-14" with "2031-02-14", so that the Maturity Date is 2031-02-14.

## Section 2 — Conditions to Effectiveness
This Amendment becomes effective on the date the Administrative Agent receives counterparts hereof executed by the Borrower and the Required Lenders and each Lender, together with an amendment fee for the account of each consenting Lender equal to 0.25% of such Lender's Commitment.
<!-- page 3 -->
## Section 3 — Representations; Reaffirmation
The Borrower represents that no Default has occurred and is continuing and that the representations in Article V of the Credit Agreement are true and correct in all material respects on the date hereof.
Each Guarantor, by its acknowledgment below, reaffirms its obligations under the Guarantee and the Security Agreement after giving effect to this Amendment.
## Section 4 — Effect; Governing Law
Except as expressly amended hereby, the Credit Agreement and the other Loan Documents remain in full force and effect and are hereby ratified and confirmed. This Amendment is a Loan Document.
This Amendment shall be governed by the laws of the State of New York. Notices hereunder shall be given in the manner set forth in Section 10.1 of the Credit Agreement.
Halvorsen Marine Holdings, Inc., as Borrower — By: /s/ Authorized Signatory
Meridian Trust Bank, N.A., as Administrative Agent — By: /s/ Authorized Signatory
