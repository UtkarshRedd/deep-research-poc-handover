<!-- page 1 -->
# MANUFACTURING AND SUPPLY AGREEMENT
| Field | Value |
|---|---|
| Document Type | Manufacturing Agreement |
| SEC Filing Date | 2020-01-21 |
| Parties | Pifzer Inc. ("Manufacturer"); Upjohn Inc. ("Customer")("Party" or collectively as the "Parties") |
| Source | CUAD v1 / UpjohnInc_20200121_10-12G_EX-2.6_11948692_EX-2.6_Manufacturing Agreement_ Supply Agreement |

Exhibit 2.6

FINAL VERSION

FORM OF

MANUFACTURING AND SUPPLY AGREEMENT

BY AND BETWEEN

PFIZER INC.

AND

UPJOHN INC.

DATED AS OF [●]

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 2 -->
TABLE OF CONTENTS Page 1. DEFINITIONS 1

2. SUPPLY OF PRODUCT 13

2.1 Agreement to Supply 13 2.2 Use of Facility, Equipment, Molds and Tooling 15 2.3 Capacity 15 2.4
Forecasts and Purchase Orders 16 2.5 Failure to Supply 19 2.6 Delivery; Risk of Loss 21 2.7
Procurement of Materials 22 2.8 Product Samples 23 2.9 Storage 23 2.10 Transitional Support 24

3. PRICE; PAYMENT; PRICE ADJUSTMENTS; TAXES 26

3.1 Price 26 3.2 Price Adjustment 27 3.3 Cost Improvement 30 3.4 Price Review and Audit Procedure 31
3.5 Invoices and Payment 32 3.6 Taxes 33 3.7 No Duplicative Payments 35

4. MANUFACTURING STANDARDS AND QUALITY ASSURANCE 35

4.1 Quality Agreement 35 4.2 Manufacturing Standards 35 4.3 Manufacturing Changes 35 4.4 Pest
Control 36 4.5 Legal and Regulatory Filings and Requests 36 4.6 Quality Tests and Checks 37 4.7
Responsibility for Non-Complying Product 38 4.8 Rejection of Non-Complying Product 38 4.9 Disposal
of Rejected and Non-Complying Product 40 4.10 Maintenance and Retention of Records 40 4.11
Government Inspections, Seizures and Recalls 40 4.12 Inspections 41 4.13 Segregation of Restricted
Compounds 42 4.14 Packaging Material 43

5. COVENANTS 43

5.1 Mutual Covenants 43 5.2 Manufacturer Covenants 44 5.3 Manufacturer's Social Responsibility 46
-ii-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 3 -->
TABLE OF CONTENTS (continued) Page 5.4 Notice of Material Events 46 5.5 Disclaimer of Warranties 47

6. ENVIRONMENTAL COVENANTS 47

6.1 Compliance with Environmental Laws 47 6.2 Permits, Licenses and Authorization 47 6.3 Generation
of Hazardous Wastes 48 6.4 Environmental Sustainability Information 48 6.5 Environmental and Health
and Safety Reviews 48

7. TERM; TERMINATION 49

7.1 Term of Agreement 49 7.2 Term of Facility Addendum 50 7.3 Termination for Cause 50 7.4
Termination for Disposition of Facility 50 7.5 Termination in Event of Insolvency 51 7.6 Termination
for Breach of Anti-Bribery Representation 51 7.7 Termination for Convenience by Customer 52 7.8
Effect of Termination or Expiration 52 7.9 Unused Materials 53 7.10 Return of Materials, Tools and
Equipment 54

8. INTELLECTUAL PROPERTY 55

8.1 Customer's Intellectual Property 55 8.2 Improvements and Developments 55 8.3 Ownership of Other
Property 56 8.4 Limited Right to Use 56

9. JOINT ADVISORY COMMITTEE 56

9.1 Formation and Role 56 9.2 Membership; Chairs 57 9.3 Meetings 57 9.4 Areas of Responsibility 58
9.5 Advisory Role; No Decision-Making Authority 58

10. INDEMNIFICATION; LIMITATIONS OF LIABILITY 58

10.1 Indemnification of Customer 58 10.2 Indemnification of Manufacturer 59 10.3 Indemnification
Procedures 60 10.4 Limitations on Liability 62 10.5 Indemnification Obligations Net of Insurance
Proceeds and Other Amounts 63 10.6 Additional Matters 64 -iii-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 4 -->
TABLE OF CONTENTS (continued) Page 11. INSURANCE 65

11.1 Requirements to Maintain 65 11.2 Amounts and Limits 65

12. CUSTOMER-SUPPLIED MATERIALS; BUY-SELL MATERIALS; TRANSITION 66

12.1 Supply; Rejection; Transition 66 12.2 Title and Risk of Loss 68 12.3 Reimbursement for Loss of
Customer-Supplied Materials 68

13. CONFIDENTIALITY 69

14. SUPPLY CHAIN SECURITY 69

14.1 Supply Chain Representations 69 14.2 C-TPAT 69

15. RECORDS AND AUDITS 70

15.1 Records 70 15.2 Audits 70

16. NOTICES 71

17. MISCELLANEOUS 71

17.1 Negotiations of Dispute 71 17.2 Publicity 72 17.3 Governing Law and Venue 72 17.4 Relationship
of the Parties 73 17.5 Assignment; Binding Effect 73 17.6 Force Majeure 74 17.7 Severability 75 17.8
Non-Waiver; Remedies 75 17.9 Further Documents 75 17.10 Forms 75 17.11 Headings; Interpretation 76
17.12 Rules of Construction 77 17.13 Counterparts 77 17.14 Amendments 77 17.15 Entire Agreement 77
Attachment A Form of Facility Addendum Attachment B Quality Agreement Attachment C Monthly Inventory
Report Attachment D Anti-Bribery and Anti-Corruption Principles Attachment E Policies Attachment F
Example Product Materials Adjustment Calculation Attachment G Example Price Calculation of Volume
Change Pricing Adjustment -iv-

Source: UPJOHN INC, 10-12G, 1/21/2020

MANUFACTURING AND SUPPLY AGREEMENT
<!-- page 5 -->
THIS MANUFACTURING AND SUPPLY AGREEMENT (this "Agreement"), dated as of [●] (the "Effective Date"),
is by and between Pfizer Inc., a Delaware corporation (hereinafter "Manufacturer"), and Upjohn Inc.,
a Delaware corporation (hereinafter "Customer"). Manufacturer and Customer may be referred to herein
individually as a "Party" or collectively as the "Parties".

W I T N E S S E T H:

WHEREAS, Pfizer Inc. ("Pluto") and Upjohn Inc. ("Spinco") have entered into a Separation and
Distribution Agreement, dated as of July 29, 2019 (as amended, modified or supplemented from time to
time in accordance with its terms, the "Separation Agreement"), pursuant to which Pluto and Spinco
have agreed to separate the Spinco Business from the Pluto Business so that, as of the Distribution
Date, the Spinco Business shall be held by members of the Spinco Group and the Pluto Business is
held by members of the Pluto Group (the "Separation");

WHEREAS, after the Separation, Spinco shall become a standalone publicly traded company, pursuant to
the terms of the Separation Agreement and a Business Combination Agreement, dated as of July 29,
2019 (the "Business Combination Agreement"), by and among Pluto, Spinco, Mylan N.V., a public
company with limited liability incorporated under the laws of the Netherlands, and certain of their
Affiliates; and

WHEREAS, in connection with the Separation, the Parties are entering into this Agreement, pursuant
to which Customer desires to procure from Manufacturer, and Manufacturer desires to supply or cause
one of its Affiliates to supply to Customer, Products for sale by Customer or its Affiliates in the
Territory during the Term, upon the terms and subject to the conditions set forth herein.

NOW, THEREFORE, in consideration of these premises and the covenants and agreements set forth
herein, and intending to be legally bound thereby, the Parties hereby agree as follows: 1.
Definitions.

As used in this Agreement, the following capitalized terms shall have the meanings set forth below.
Capitalized terms not otherwise defined in this Agreement shall have the meanings ascribed to such
terms in the Separation Agreement. 1.1 "Accounting Method" means U.S. Generally Accepted Accounting
Principles (GAAP) or, if otherwise agreed by the Parties, an alternative accounting method used in
the ordinary course of business. 1.2 "Act" means the U.S. Federal Food, Drug, and Cosmetic Act, as
amended. 1.3 "Action" means any demand, action, claim, dispute, suit, countersuit, arbitration,
inquiry, subpoena, proceeding or investigation of any nature (whether criminal, civil, legislative,
administrative, regulatory, prosecutorial or otherwise) by or before any federal, state, local,
foreign or international Governmental Authority or any arbitration or mediation tribunal.

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 6 -->
1.4 "Additional Quantities" shall have the meaning set forth in Section 2.4(c). 1.5 "Affected
Products" shall have the meaning set forth in Section 10.4(a). 1.6 "Affiliate(s)" means, when used
with respect to a specified Person, a Person that controls, is controlled by, or is under common
control with such specified Person. As used herein, "control" (including, with correlative meanings,
"controlled by" and "under common control with"), when used with respect to any specified Person
shall mean the possession, directly or indirectly, of the power to direct or cause the direction of
the management and policies of such Person, whether through the ownership of voting securities or
other interests, by contract, agreement, obligation, indenture, instrument, lease, promise,
arrangement, release, warranty, commitment, undertaking or otherwise. It is expressly agreed that,
from and after the Effective Date, solely for purposes of this Agreement (a) each member of the
Spinco Group shall be deemed to not be an Affiliate of any member of the Pluto Group and (b) each
member of the Pluto Group shall be deemed to not be an Affiliate of any member of the Spinco Group.
1.7 "Agreement" shall have the meaning set forth in the Preamble. 1.8 "API" means active
pharmaceutical ingredient. 1.9 "Batch Size" shall have the meaning set forth in Section 2.4(e)(ii).
1.10 "Binding Forecast Period" shall have the meaning set forth in Section 2.4(b). 1.11 "Bulk Drug
Product" means Product that has been manufactured into a final pharmaceutical product following a
specific formulation and set of specifications, including drug substance (e.g., tablets or granules)
for administration to humans but has not been packaged for use or for commercialization. 1.12
"Business Combination Agreement" shall have the meaning set forth in the Recitals. 1.13 "Business
Day" means (a) any day other than a Saturday, Sunday or a day on which banking institutions are
authorized or obligated by Law to be closed in New York, New York or (b) with respect to those
activities specific to a Facility, any day other than any day on which banks located in the city and
country in which the Facility is located are authorized or obligated to be closed. 1.14 "Buy-Sell
Materials" means the materials that Customer sells to Manufacturer for use in manufacturing Product
for Customer under the terms of this Agreement and as set forth in the applicable Facility Addendum.
For the avoidance of doubt, Buy-Sell Materials are distinguishable from and exclusive of both
Product Materials and Customer-Supplied Materials. -2-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 7 -->
1.15 "Conflict Minerals" shall have the meaning set forth in Section 5.3(c). 1.16 "Conversion Cost
Markup" shall have the meaning set forth in Section 2.5(e). 1.17 "Conversion Costs" means, with
respect to a given Product, (a) direct and indirect labor costs, (b) equipment costs, including
depreciation, (c) laboratory and quality control costs at the applicable Facility, including Product
testing and on-going stability studies, (d) quality assurance costs, (e) general site and
manufacturing support costs for resources that support the manufacture of the applicable Product
(including utilities, warehousing, consumables, maintenance, engineering, safety, human resources,
finance, information technology, plant management and other similar activities, capital improvements
in the form of depreciation, an allocation of costs for above site services provided to the
applicable Facility for resources that support the manufacture of the applicable Product and an
allowance for inventory loss, in each case, at the Facility-level), (f) costs paid to Third Party
manufacturers for the manufacture and supply of such Product (or components thereof), (g) all costs
associated with the performance of Manufacturer's obligations under Section 4.6, including all
activities, tests and checks set forth therein, and (h) costs paid to Third Party contractors for
services provided in connection with the manufacture and supply of such Product, in each case
associated with such Product. 1.18 "CPP" shall have the meaning set forth in Section 4.5(a). 1.19
"C-TPAT" means the Customs-Trade Partnership Against Terrorism program of the U.S. Bureau of Customs
and Border Protection. 1.20 "C-TPAT Benefits" means the expected benefit afforded to importers that
have joined C-TPAT related to substantially fewer of their imports being inspected and, hence, fewer
supply chain delays. 1.21 "Current Good Manufacturing Practices" or "cGMP" means all applicable
standards and applicable Laws (as defined below) relating to manufacturing practices for products
(including ingredients, testing, storage, handling, intermediates, bulk and finished products)
promulgated by the FDA or any other applicable Governmental Authority (including, without
limitation, EU or member state level) having jurisdiction, including, but not limited to, standards
in the form of applicable Laws, guidelines, advisory opinions and compliance policy guides and
current interpretations of the applicable authority or agency thereof (as applicable to
pharmaceutical and biological products and ingredients), as the same may be updated, supplemented or
amended from time to time. 1.22 "Customer" shall have the meaning set forth in the Preamble. 1.23
"Customer Indemnified Party" shall have the meaning set forth in Section 10.1(a). 1.24
"Customer-Owned Improvements and Developments" shall have the meaning set forth in Section 8.2(b).
-3-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 8 -->
1.25 "Customer Property" means all Intellectual Property, together with all materials, data,
writings and other property in any form whatsoever, which is (a) owned or controlled by Customer or
its Affiliates as of and following the Effective Date and (b) provided to Manufacturer by or on
behalf of Customer or its Personnel under this Agreement. 1.26 "Customer-Supplied Materials" means
the materials supplied by Customer to Manufacturer under the terms of this Agreement and as set
forth in the applicable Facility Addendum. For the avoidance of doubt, Customer-Supplied Materials
are distinguishable from and exclusive of both Product Materials and Buy-Sell Materials. 1.27
"Delivery" shall have the meaning set forth in Section 2.6(a). 1.28 "Developments" shall have the
meaning set forth in Section 8.2(a). 1.29 "Effective Date" shall have the meaning set forth in the
Preamble. 1.30 "Environmental Laws" means any Laws relating to (a) human or occupational health and
safety; (b) pollution or protection of the environment (including ambient air, indoor air, water
vapor, surface water, groundwater, wetlands, drinking water supply, land surface or subsurface
strata, biota and other natural resources); or (c) exposure to, or use, generation, manufacture,
processing, management, treatment, recycling, storage, disposal, emission, discharge, transport,
distribution, labeling, presence, possession, handling, Release or threatened Release of, any
hazardous or toxic material, substance or waste and any Laws relating to recordkeeping,
notification, disclosure, registration and reporting requirements respecting hazardous or toxic
materials, substances or wastes. 1.31 "Environmental Liability" means any Liability arising under
Environmental Laws. 1.32 "Exclusive Purchase Requirement" means, on a Product SKU-by-Product SKU and
country-by country basis within the applicable Territory, (a) in the first two (2) years of the
Initial Term, one hundred percent (100%) of Customer's total requirements for such Product SKU and
(b) in the third (3rd) year of the Initial Term, fifty percent (50%) of Customer's total
requirements for such Product SKU; provided, however, that (x) such quantities of Product reasonably
procured by Customer to qualify a back-up supplier for such Product shall be excluded from the
Exclusive Purchase Requirement, and (y) for the avoidance of doubt, Customer may commercialize such
quantities of Product procured under (x) above without violating the applicable Exclusive Purchase
Requirement or related provisions in Section 2.1(e). 1.33 "Exclusive Purchase Requirement Suspension
Period" shall have the meaning set forth in Section 2.5(b). -4-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 9 -->
1.34 "Exclusivity Period" means the three (3) year period immediately following the Effective Date,
as such period may be earlier terminated pursuant to this Agreement. 1.35 "Extension Period" shall
have the meaning (a) with respect to this Agreement, as set forth in Section 7.1 and (b) with
respect to a Facility Addendum, as set forth in Section 7.2. 1.36 "Facility" means, with respect to
a given Product, Manufacturer's manufacturing facility located at the address set forth in the
applicable Facility Addendum for such Product and such other facilities permitted pursuant to this
Agreement and any applicable Facility Addendum to be used by Manufacturer in the manufacture,
packaging or storage of (a) such Product or (b) materials utilized in the manufacture or storage of
such Product hereunder. 1.37 "Facility Addendum" means a document executed by the Parties or their
respective Affiliates for one or more Products to be manufactured in a Facility pursuant to this
Agreement, which shall be substantially in the form of Attachment A to this Agreement. 1.38
"Facility Conversion Cost" means, with respect to a given Facility and Fiscal Year, the sum of all
Product Conversion Costs for Products manufactured for Customer or the applicable Affiliate of
Customer at such Facility during such Fiscal Year. 1.39 "Facility Conversion Cost Adjustment Fiscal
Year" shall have the meaning set forth in Section 3.2(b)(i). 1.40 "Facility Conversion Cost Baseline
Fiscal Year" shall have the meaning set forth in Section 3.2(b)(i). 1.41 "Facility Conversion Cost
Threshold" shall have the meaning set forth in Section 3.2(b)(i). 1.42 "Facility Disposition" shall
have the meaning set forth in Section 7.4. 1.43 "Facility Actual Product Materials Cost" means, with
respect to a given Facility and Fiscal Year, the sum of all actual costs of Product Materials for
Products manufactured for Customer or the applicable Affiliate of Customer at such Facility during
such Fiscal Year. 1.44 "Facility Estimated Product Materials Cost" means, with respect to a given
Facility and Fiscal Year, the sum of all estimated costs, as determined in good faith by
Manufacturer and notified to Customer prior to the beginning of such Fiscal Year, of Product
Materials for Products manufactured for Customer or the applicable Affiliate of Customer at such
Facility during such Fiscal Year. 1.45 "Familial Relative(s)" means a parent, spouse, child or
sibling (including any such relationships formed by marriage). -5-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 10 -->
1.46 "FDA" means the U.S. Food and Drug Administration or any successor agency. 1.47 "Finished
Product" means Product that has been packaged for commercialization and distribution to patients
incorporating Bulk Drug Product. 1.48 "Firm Order" shall have the meaning set forth in Section
2.4(b). 1.49 "Fiscal Year" means each twelve-month fiscal period commencing on January 1 with
respect to Facilities located in the United States and December 1 for all other facilities, in each
case, during the Term. 1.50 "Force Majeure Event" shall have the meaning set forth in Section 17.6.
1.51 "Forecast" shall have the meaning set forth in Section 2.4(b). 1.52 "Forms" shall have the
meaning set forth in Section 17.10. 1.53 "Global Trade Control Laws" means all applicable economic
sanctions, export and import control laws, regulations and orders. 1.54 "Government" means all
levels and subdivisions of U.S. and non-U.S. governments (i.e., local, regional or national and
administrative, legislative or executive). 1.55 "Government Official" means (a) any elected or
appointed governmental official (e.g., a member of a ministry of health), (b) any employee or person
acting for or on behalf of a governmental official, agency or enterprise performing a governmental
function, (c) any candidate for public office, political party officer, employee or person acting
for or on behalf of a political party or candidate for public office or (d) any person otherwise
categorized as a Government Official under local Law. As used in this definition, "government" is
meant to include all levels and subdivisions of U.S. and non-U.S. governments (i.e., local, regional
or national and administrative, legislative or executive). 1.56 "Governmental Authority" means any
nation or government, any state, municipality or other political subdivision thereof, and any
entity, body, agency, commission, department, board, bureau, court, tribunal or other
instrumentality, whether federal, state, local, domestic, foreign or multinational, exercising
executive, legislative, judicial, taxing, regulatory, administrative or other similar functions of,
or pertaining to, government and any executive official thereof. 1.57 "Hazardous Materials" means
(a) any petroleum or petroleum products, radioactive materials, toxic mold, radon, asbestos or
asbestos- containing materials in any form, lead-based paint, urea formaldehyde foam insulation or
polychlorinated biphenyls; and (b) any chemicals, materials, substances, compounds, mixtures,
products or byproducts, biological agents, living or genetically modified materials, pollutants,
contaminants or wastes that are now or hereafter become defined, regulated or characterized as or
included in the definition of "hazardous substances," "hazardous wastes," "hazardous materials,"
"extremely hazardous wastes," "restricted hazardous wastes," "special waste," "toxic substances,"
"pollutants," "contaminants," "toxic," "dangerous," "corrosive," "flammable," "reactive,"
"radioactive," or words of similar import, under any Environmental Law. -6-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 11 -->
1.58 "Improvements" shall have the meaning set forth in Section 8.2(a). 1.59 "Increments" shall have
the meaning set forth in Section 2.4(e)(ii). 1.60 "Indemnifying Party" shall have the meaning set
forth in Section 10.3(a). 1.61 "Indemnitee" shall have the meaning set forth in Section 10.3(a).
1.62 "Indemnity Payment" shall have the meaning set forth in Section 10.5(a). 1.63 "In-Flight or
Shared Volume Product" means those Products identified as such in a Facility Addendum. 1.64 "Initial
Price" shall have the meaning set forth in Section 3.1(a). 1.65 "Initial Price Term" means, with
respect to a Product set forth in a Facility Addendum, the period of time beginning on the Effective
Date and ending on the last day of the first full Fiscal Year of the Term of such Facility Addendum.
1.66 "Initial Term" shall have the meaning (a) with respect to this Agreement, set forth in Section
7.1 and (b) with respect to a Facility Addendum, set forth in Section 7.2. 1.67 "Insolvent Party"
shall have the meaning set forth in Section 7.5. 1.68 "Insurance Proceeds" means those monies (a)
received by an insured from an insurance carrier; (b) paid by an insurance carrier on behalf of the
insured; or (c) received (including by way of setoff) from any Person in the nature of insurance,
contribution or indemnification in respect of any Liability, in each of cases (a), (b) and (c), net
of any applicable premium adjustments (including reserves or retentions and retrospectively rated
premium adjustments) and net of any costs or expenses incurred in the collection thereof. 1.69
"Intellectual Property" means all intellectual property rights throughout the world, including: (a)
patents and patent applications and all related provisionals, divisionals, continuations,
continuations-in-part, reissues, reexaminations, extensions and substitutions of any of the
foregoing; (b) trademarks, service marks, names, corporate names, trade names, domain names, social
media names, tags or handles, logos, slogans, trade dress, design rights, and other similar
designations of source or origin, together with the goodwill symbolized by any of the foregoing,
whether or not registered or applied for registration, including common law trademark rights; (c)
copyrights and copyrightable subject matter, whether or not registered or applied for registration;
(d) technical, scientific, regulatory and other information, designs, ideas, inventions (whether
patentable or unpatentable and whether or not reduced to practice), research and development,
discoveries, results, -7-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 12 -->
creations, improvements, know-how, techniques and data (including biological, chemical,
pharmacological, toxicological, pharmaceutical, physical and analytical, safety, quality control,
manufacturing and preclinical and clinical data), technology, algorithms, procedures, plans,
processes, practices, methods, trade secrets, instructions, formulae, formulations, compositions,
specifications, and marketing, pricing, distribution, cost and sales information, tools, materials,
apparatus, creations, improvements, works of authorship in any media, confidential, proprietary or
nonpublic information, and other similar materials, and all recordings, graphs, drawings, reports,
analyses and other writings, and other tangible embodiments of the foregoing in any form whether or
not listed herein, in each case, other than Software; (e) Software; and (f) applications,
registrations and common law rights for the foregoing. 1.70 "JAC Chair" shall have the meaning set
forth in Section 9.2(b). 1.71 "JAC Meeting" shall have the meaning set forth in Section 9.3(a). 1.72
"JAC Member" shall have the meaning set forth in Section 9.2(a). 1.73 "Joint Advisory Committee" or
"JAC" shall have the meaning set forth in Section 9.1. 1.74 "Late Payment Date" shall have the
meaning set forth in Section 3.5. 1.75 "Latent Defects" shall have the meaning set forth in Section
4.8(a). 1.76 "Laws" means any U.S. and non-U.S. federal, national, international, multinational,
supranational, state, provincial, local or similar law (including common law and privacy and data
protection laws), statute, ordinance, regulation, rule, code, order, treaty (including any tax
treaty on income or capital), binding judicial or administrative interpretation or other requirement
or rule of law or legal process, in each case, enacted, promulgated, issued, entered or otherwise
put into effect by a Governmental Authority or any rule or requirement of any securities exchange.
1.77 "Losses" means any and all damages, losses, deficiencies, Liabilities, Taxes, obligations,
penalties, judgments, settlements, claims, payments, fines, charges, interest, costs and expenses,
whether or not resulting from Third-Party Claims, including the costs and expenses of any and all
Actions and demands, assessments, judgments, settlements and compromises relating thereto and the
reasonable costs and expenses of attorneys', accountants', consultants' and other professionals'
fees and expenses incurred in the investigation or defense thereof or the enforcement of rights
hereunder. 1.78 "Make to Order Products" means all Products that are identified as "Make to Order
Products" in the applicable Facility Addendum. 1.79 "Manufacturer" shall have the meaning set forth
in the Preamble. -8-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 13 -->
1.80 "Manufacturer Indemnified Party" shall have the meaning set forth in Section 10.2(a). 1.81
"Manufacturer-Owned Improvements and Developments" shall have the meaning set forth in Section
8.2(c). 1.82 "Manufacturer Third Party Suppliers" shall have the meaning set forth in Section
2.7(a). 1.83 "Manufacturing Change" shall have the meaning set forth in Section 4.3(a). 1.84
"Minimum Order Quantity" shall have the meaning set forth in the applicable Facility Addendum with
respect to each Product. 1.85 "Non-Complying Buy-Sell Materials" means any Buy-Sell Material that,
as of or prior to its delivery by or on behalf of Customer or its Affiliate to Manufacturer or its
Affiliate or designee pursuant to this Agreement, does not comply in all material respects with, or
has not been used, handled or stored in all material respects in accordance with, the specifications
for such Buy-Sell Material, all applicable Laws, cGMP, the Quality Agreement, this Agreement or the
applicable Facility Addendum. 1.86 "Non-Complying Customer-Supplied Materials" means any
Customer-Supplied Material that, as of or prior to its delivery by or on behalf of Customer or its
Affiliate to Manufacturer or its Affiliate or designee pursuant to this Agreement, does not comply
in all material respects with, or has not been used, handled or stored in all material respects in
accordance with, the specifications for such Customer-Supplied Material, all applicable Laws, cGMP,
the Quality Agreement, this Agreement or the applicable Facility Addendum. 1.87 "Non-Complying
Product" shall have the meaning set forth in Section 4.7. 1.88 "Party" or "Parties" shall have the
meaning set forth in the Preamble. 1.89 "Person" means an individual, a general or limited
partnership, a corporation, a trust, a joint venture, an unincorporated organization, a limited
liability entity, any other entity and any Governmental Authority. 1.90 "Personnel" means, with
respect to a Party, such Party's Affiliates, contractors and agents together with such Party's and
its Affiliates', contractors' and agents' respective individual employees, contractors and other
agents. 1.91 "Pluto" shall have the meaning set forth in the Recitals. 1.92 "Price" means, with
respect to a Product: (a) during the Initial Price Term, the Initial Price of such Product; and -9-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 14 -->
(b) after the Initial Price Term, the adjusted price for such Product, as calculated on a Fiscal
Year basis, in accordance with Section 3.2. 1.93 "Product" means a product specified in the
applicable Facility Addendum which, for the avoidance of doubt, includes all applicable SKUs of such
product, in each case, as the same may be amended from time to time by the mutual written agreement
of the Parties. 1.94 "Product Conversion Cost" means, with respect to a given Product, the total
units of such Product anticipated to be shipped or actually shipped, as applicable, during a given
Fiscal Year (determined in a manner consistent with Manufacturer's customary practices) multiplied
by the per-unit Conversion Cost for such Product for such Fiscal Year. 1.95 "Product Materials"
means all raw materials (including, without limitation, active pharmaceutical ingredients and
excipients), labeling or packaging materials and components needed for the manufacture and supply of
a given Product. For the avoidance of doubt, Product Materials are distinguishable from and
exclusive of both Buy-Sell Materials and Customer-Supplied Materials. 1.96 "Product SKU" means the
specific Stock Keeping Unit (SKU) number for a given Product supplied for sale in a given country or
region in the applicable Territory, in each case, as such SKU number may be updated from time to
time. 1.97 "Purchase Order" means a written or electronic order form submitted by Customer in
accordance with the terms of this Agreement to Manufacturer authorizing the manufacture and supply
of a given Product. 1.98 "Quality Agreement" means those supplemental quality provisions set forth
in any Quality Agreement between Manufacturer and Customer relating to a Facility, as the same may
be amended or modified from time to time by mutual written agreement of the Parties. The form of
Quality Agreement for each Facility is attached hereto as Attachment B. 1.99 "Recall" means a
"recall", "correction" or "market withdrawal" and shall include any post-sale warning or mailing of
information. 1.100 "Receiving Site" shall have the meaning set forth in Section 2.10(a). 1.101
"Record Retention Period" shall have the meaning set forth in Section 15.1. 1.102 "Records" means
any books, documents, accounting procedures and practices and other data, regardless of type or
form, of all matters relating to Manufacturer's performance of its obligations under this Agreement
that enable Manufacturer to demonstrate compliance with such obligations, including, without
limitation, Manufacturer's compliance with applicable Laws. -10-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 15 -->
1.103 "Regulatory Approvals" means the permit, approval, consent, registration, license,
authorization or certificate of a Governmental Authority necessary for the manufacturing,
distribution, use, promotion and sale of a Product for one or more indications in a country or other
regulatory jurisdiction, including approval of New Drug Applications and Biologics License
Applications (each as defined by applicable Law) in the United States and Marketing Authorizations
(as such term is defined by applicable Law) in the European Union. 1.104 "Release" means any
release, spill, emission, leaking, dumping, pumping, injection, pouring, deposit, disposal,
discharge, dispersal, leaching or migration into or through the indoor or outdoor environment
(including ambient air, surface water, groundwater, land surface or subsurface strata, soil and
sediments) or into, through or within any property, building, structure, fixture or equipment. 1.105
"Restricted Markets" means, as applicable and as may be updated from time to time, in each case,
under Global Trade Control Laws, the Crimean Peninsula, Cuba, the Donbass Region, Iran, North Korea,
and Syria. 1.106 "Restricted Party" means any: (a) individual or entity placed on lists maintained
by an applicable Governmental Authority, including those established under the Act, the List of
Excluded Individuals / Entities published by the U.S. Health and Human Services Office of Inspector
General, the regulations administered by the U.S. Department of the Treasury Office of Foreign
Assets Control, the U.S. Department of Commerce Bureau of Industry and Security, or similar lists of
restricted parties maintained by the Governmental Authorities of the countries that have
jurisdiction over the activities conducted under this Agreement; (b) individual or entity suspended
or debarred from contracting with the U.S. government; or (c) any entity in the aggregate owned or
controlled, directly or indirectly, fifty percent (50%) or greater by one or more such individuals
or entities described in clause (a). 1.107 "Separation" shall have the meaning set forth in the
Recitals. 1.108 "Separation Agreement" shall have the meaning set forth in the Recitals. 1.109
"Serialization" means the assigning of a unique identification code on a given Product unit or
Product units of sale at the primary, secondary and/or tertiary level for the purpose assuring
authenticity and/or tracking and tracing of the movement of a given Product through the entire
supply chain. 1.110 "Service Taxes" shall have the meaning set forth in Section 3.6(b). 1.111
"Specifications" means the specifications for the manufacture, processing, packaging, labeling,
testing and testing procedures, shipping, storage and supply of a given Product, including all
formulae, know-how, raw materials requirements, analytical procedures and standards of quality
control, quality assurance and sanitation, set forth with respect to such Product in the applicable
Regulatory Approval(s) and provided by Customer to Manufacturer. -11-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 16 -->
1.112 "Spinco" shall have the meaning set forth in the Recitals. 1.113 "Standard Cost" means, with
respect to a given Product in a given Fiscal Year, an amount equal to: (a) the cost of Product
Materials (including the cost of active ingredients, intermediates, semi-finished materials,
excipients and primary and secondary packaging) associated with such Product ("Standard Product
Materials Cost"); and (b) the Conversion Costs for such Product ("Standard Conversion Cost"),

in each case of clauses (a) and (b), calculated in accordance with Manufacturer's accounting
policies in effect as of the Effective Date and applied consistently across Manufacturer's entire
manufacturing operations for the full applicable Facility. Depreciation will be based on original
acquisition cost of fixed assets, and not impacted by fair value accounting for business
transactions. 1.114 "Technical Support" shall have the meaning set forth in Section 2.10(a). 1.115
"Term" shall have the meaning (a) with respect to this Agreement, as set forth in Section 7.1 and
(b) with respect to a Facility Addendum, as set forth in Section 7.2. 1.116 "Territory" means, with
respect to a given Product, the countries set forth in the applicable Facility Addendum for such
Product. 1.117 "Third Party" means a Person other than Manufacturer, Customer or their respective
Affiliates. 1.118 "Third-Party Claim" shall have the meaning set forth in Section 10.3(a). 1.119
"Triggering Event" shall have the meaning set forth in Section 2.5(a). 1.120 "VAT" means (A) any Tax
imposed in compliance with the council directive of 28 November 2006 on the common system of value
added tax (EC Directive 2006/112); and (B) any other Tax of a similar nature, however denominated,
to the Taxes referred to in clause (A) above, whether imposed in a member state of the European
Union in substitution for, or levied in addition to, the Taxes referred to in clause (A) above, or
imposed elsewhere (including goods and services Taxes, but excluding transfer Tax, stamp duty and
other similar Taxes). 1.121 "VMR Products" means all Products that are identified as "VMR Products"
in the applicable Facility Addendum. 1.122 "Waste" means all wastes that arise from the manufacture,
handling or storage of Product hereunder, or which is otherwise produced through the implementation
of this Agreement, including Hazardous Materials. -12-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 17 -->
2. Supply of Product. 2.1 Agreement to Supply. (a) Affiliates and Facility Addenda. Either the
entity designated above as Customer or any Affiliate of Customer and either the entity designated
above as Manufacturer or any Affiliate of Manufacturer may enter into Facility Addenda under this
Agreement. The entities that execute a Facility Addendum are also deemed to be "Customer" and
"Manufacturer" (respectively) for all purposes of the Facility Addendum and this Agreement (with
respect to the applicable Facility Addendum). (b) Supply Pursuant to Facility Addenda. During the
Term of each Facility Addendum, Manufacturer shall manufacture and supply Product to Customer for
the Territory applicable to such Product on the terms and subject to the conditions of this
Agreement and the applicable Facility Addendum. The terms of this Agreement shall be incorporated by
reference into each Facility Addendum that may be executed by the Parties or, as described in
Section 2.1(a), their respective Affiliates. During the term of this Agreement, Customer may request
that Manufacturer manufacture and supply to Customer clinical trial material, and the Parties shall
negotiate in good faith the terms and conditions of such manufacturing and supply arrangement
applying the terms and conditions of this Agreement to the extent mutually agreeable. (c) Hierarchy
of Terms; Effect of Amendments. In the event of a conflict between the terms of any Facility
Addendum and the terms of this Agreement, the terms of this Agreement shall govern and control,
except to the extent that the applicable Facility Addendum expressly and specifically states an
intent to supersede a specific section of this Agreement on a specific matter. Any amendment to the
terms of this Agreement contained in a Facility Addendum shall be effective solely with respect to
such Facility Addendum, and not with respect to this Agreement or any other Facility Addendum. Any
amendment to the terms of this Agreement shall be effective with respect to all Facility Addenda.
Except to the extent otherwise expressly stated in this Agreement, in the event of a conflict
between the terms of this Agreement and the terms of the Separation Agreement, the terms of the
Separation Agreement shall govern and control. (d) Use of Subcontractors. Subject to Section 2.2(a),
Manufacturer shall manufacture and supply Product itself or through its Affiliates, in each case, at
the applicable Facilities (and such other facilities as may be specified in the applicable Facility
Addendum with respect to applicable Products). With respect to those Third-Party contractors,
subcontractors or service providers used by Manufacturer or its Affiliates in the manufacturing or
supply of a given Product immediately prior to the Effective Date, Manufacturer may engage such
Third-Party contractors, subcontractors or -13-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 18 -->
service providers to perform the same activities for such Product under this Agreement without first
obtaining Customer's prior written consent. For the avoidance of doubt, the use of any Third-Party
contractors, subcontractors or service providers other than in the manner expressly permitted
pursuant to this Section 2.1(d) must be approved in advance in writing by Customer, such approval
not to be unreasonably withheld, conditioned or delayed. Manufacturer shall be liable for all
actions and omissions of its contractors, subcontractors and service providers, and any breach of
the terms and conditions of this Agreement by such contractors, subcontractors or service providers
shall be deemed a breach of the terms and conditions by Manufacturer under this Agreement. For the
avoidance of doubt, as of the Effective Date, as between Manufacturer and Customer, Manufacturer
will be solely responsible for maintaining and establishing relationships with the Third-Party
contractors, subcontractors or service providers used in the manufacturing or supply of Product
(other than the manufacturing or supply of Buy-Sell Materials or Customer-Supplied Materials). (e)
Exclusivity. (i) Customer Exclusivity. During the Exclusivity Period, on a Product SKU-by-Product
SKU and country-by-country basis within the applicable Territory, Customer shall purchase from
Manufacturer, in accordance with the terms and conditions of this Agreement, at least the Exclusive
Purchase Requirement of its requirements for such Product SKU in such country; provided, however,
that In-Flight or Shared Volume Products shall be excluded from the exclusivity requirements set
forth in this Section 2.1(e)(i). Following the Exclusivity Period (and during the Exclusivity
Period, with respect to Product SKU quantities in excess of the Exclusive Purchase Requirement in
accordance with the preceding sentence), nothing in this Agreement shall prevent Customer or any of
its Affiliates from manufacturing Product for itself, or having Product manufactured by a Third
Party, including in amounts in addition to the Purchase Orders for Product issued to Manufacturer in
accordance with this Agreement. For clarity and notwithstanding anything contained herein, nothing
in this Section 2.1(e)(i) (A) is intended to be inconsistent with Section 2.4(e)(i) or to otherwise
indicate that Customer is subject to any requirement to purchase Product under this Agreement or (B)
is intended to prevent Customer from qualifying a back-up supplier for any Product during the
Exclusivity Period. -14-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 19 -->
(ii) Upon request by Manufacturer, which Manufacturer may make from time to time during the Term but
not more than once during any quarter of a Fiscal Year, Customer shall provide to Manufacturer
within thirty (30) days of such request a certification attesting to Customer's compliance with its
Exclusive Purchase Requirement obligations pursuant to Section 2.1(e)(i) and signed by a
representative of Customer with a title of Vice President or more senior. 2.2 Use of Facility,
Equipment, Molds and Tooling. (a) Facilities. For each Product, Manufacturer shall perform all
manufacturing activities and all storage activities at the Facilities set forth in the Facility
Addendum applicable to such Product. Manufacturer may use any other facility for the manufacture and
storage of Products if (i) such facility has been approved for such manufacture by all applicable
Governmental Authorities and (ii) Manufacturer obtains Customer's prior written consent with respect
to the use of such other facility as set forth in Section 4.3(a) (such approval not to be
unreasonably withheld, conditioned or delayed). The Parties shall agree to either execute a new
Facility Addendum or amend an existing Facility Addendum in order to include such facility.
Manufacturer shall notify Customer of its intent to use any alternate facility as soon as reasonably
practicable. (b) Purchase and Installation of Equipment, Dedicated Change Parts and Tooling. Subject
to this Section 2.2(b), Manufacturer shall be responsible for (i) purchasing, installing and
validating at the Facilities all new equipment, dedicated change parts and tooling; (ii)
modifications to existing equipment, dedicated change parts and tooling necessary for the
manufacture, packaging, labeling and Delivery of Product hereunder; and (iii) maintenance of all
such equipment, dedicated change parts and tooling, and all costs and expenses associated therewith;
provided that in no event shall Manufacturer be required to purchase any new equipment, install any
equipment purchased or requested by Customer or add (or, for clarity, allocate or dedicate) any
additional manufacturing or storage capacity in connection with Customer's requests for additional
capacity for manufacturing or for other activities to be carried out by Manufacturer hereunder not
otherwise expressly provided for hereunder or in an applicable Facility Addendum. If Customer makes
such a request for additional equipment or capacity, then the Parties shall promptly meet and
discuss Customer's request in good faith, including an appropriate allocation of costs between the
Parties with respect thereto. 2.3 Capacity.

Subject to Section 2.2(b), Manufacturer shall devote adequate manufacturing capacity to be capable
of manufacturing and supplying Product to Customer in accordance with the provisions of this
Agreement and the Facility Addenda. Manufacturer shall promptly notify Customer if Manufacturer
reasonably believes its existing capacity and demands thereon would prevent it from meeting
Customer's anticipated Product requirements as set forth in any Forecast that conforms to the
requirements set forth in Section 2.4. -15-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 20 -->
2.4 Forecasts and Purchase Orders. (a) VMR Products Forecasting and Purchase Orders. With respect to
the VMR Products, the processes and mechanisms by which Forecasts are prepared and Purchase Orders
are issued shall be as set forth in the applicable Facility Addenda and the remainder of this
Section 2.4 shall not apply with respect to such VMR Products as applicable. (b) Make to Order
Product Forecasts. Except as otherwise set forth in a Facility Addendum, in each calendar month
during the Term of a Facility Addendum, Customer shall provide to Manufacturer a rolling Product
SKU-level forecast of its estimated requirements of Make to Order Products for the eighteen
(18)-month period commencing with the month in which such forecast is provided (each, a "Forecast").
In the event Customer delivers a Forecast where the allocation of Product requirements over the time
period of the Forecast are not consistent with historical trends, at Manufacturer's request, the
Parties will meet to discuss the Forecast in good faith in the context of previous allocations of
Product requirements. Such Forecasts represent Customer's reasonable estimates of the quantity of
Products it will require during the applicable period covered by each such Forecast. Except as
otherwise set forth in a Facility Addendum, each Forecast shall be a non-binding forecast and for
informational purposes only, except that: (i) the portion of such Forecast covering the first three
(3) calendar months reflected therein (the "Binding Forecast Period") shall be binding and shall
constitute a firm order for the quantity of each Product specified therein (each, a "Firm Order"),
(ii) each of months four (4) through six (6) of a given Forecast may not differ by more than
twenty-five percent (25%) (whether positive or negative) from the quantity of such Product set forth
in those months in the previous Forecast, and (iii) each of months seven (7) through twelve (12) of
a given Forecast may not differ by more than fifty percent (50%) (whether positive or negative) from
the quantity of such Product set forth in those months in the previous Forecast. For the avoidance
of doubt, (1) this subsection (b) applies to Forecasts for API and Bulk Drug Product and (2) the
Forecast with respect to Finished Product shall apply to the roll-up level of the Bulk Drug Product
that is incorporated into the Finished Product. (c) Make to Order Purchase Orders. Manufacturer
shall provide Product to Customer pursuant to Purchase Orders issued by Customer to Manufacturer,
which Purchase Orders will be issued on a Product SKU-by-Product SKU basis, not to exceed one (1)
Purchase Order per Product SKU per calendar month unless otherwise agreed between the Parties in
advance in writing. No verbal communications or e-mail shall be construed to mean a commitment to
purchase Product. Customer shall be required to order -16-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 21 -->
pursuant to a Purchase Order at least the amount of Product set forth in the Firm Order for such
Product in the applicable calendar month. Manufacturer shall provide to Customer such quantities of
Product as may be ordered by Customer pursuant to such Purchase Orders, up to one hundred ten
percent (110%) of the quantity set forth in the most recent Forecast for the applicable period. In
the event that Customer orders quantities of Product above one hundred ten percent (110%) of the
quantity set forth in the most recent Forecast for the applicable period (such quantities above one
hundred ten percent (110%) referred to as "Additional Quantities"), Manufacturer shall use its
commercially reasonable efforts, but shall not be obligated, to supply such Additional Quantities.
For purposes of this paragraph, the most recent Forecast for any given month shall mean the Forecast
submitted by Customer in the month prior to the month in which the applicable Purchase Order is
issued. All Purchase Orders shall specify the quantity and description of Products ordered, the
applicable Facility where such Products will be Delivered, the required delivery date (subject to
the provisions of Section 2.4(d)), and the manner of Delivery (including the carrier to be used).
(d) Delivery Date. Unless expressly set forth to the contrary in a Facility Addendum, Customer will
issue Purchase Orders for Product no later than a period equal to the Binding Forecast Period prior
to the required delivery date. By way of example only, if the Binding Forecast Period is the first
three (3) months of a Forecast with respect to a Product, then Customer will issue Purchase Order
for such Product no later than three (3) months prior to the required delivery date. (e) No Minimum
Purchase Obligation; Minimum Order Quantities. (i) No Obligation. Without limiting Customer's
obligations under Section 2.1(e), 2.4(b), 2.4(c), 2.4(d) or 2.4(e)(ii), Manufacturer hereby
acknowledges and agrees that Customer is not otherwise obligated to purchase any minimum or specific
quantity, volume or dollar amount of Product under any Facility Addendum unless expressly set forth
in the applicable Facility Addendum. (ii) Minimum Order Quantities. Notwithstanding Section
2.4(e)(i), Customer acknowledges and agrees that (A) each Purchase Order Customer places hereunder
for Product that is either API or Bulk Drug Product shall be equal to, or a whole multiple of, the
Batch Size for such applicable Product as set forth in the applicable Facility Addendum and (B) each
Purchase Order that Customer places hereunder for Product that is Finished Product shall be equal to
or greater than the Minimum Order Quantity for such applicable Product as set forth in the
applicable Facility Addendum; provided that, where Customer places Purchase Orders under (B) above
that exceed the applicable Minimum Order Quantity, Customer shall -17-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 22 -->
place such Purchase Orders for such excess quantities in Increments above the Minimum Order Quantity
as specified in the applicable Facility Addendum. As used herein, "Batch Size" means the production
quantity for a given run of a Product SKU and "Increments" means the quantity step change above the
applicable Minimum Order Quantity, in each case, as specified in the applicable Facility Addendum.
(f) Acceptance and Rejection of Orders. Within ten (10) Business Days of receipt of a Purchase
Order, Manufacturer may reject such Purchase Order by written notice to Customer only on the basis
that it is inconsistent with the terms of this Agreement, including a Purchase Order containing (i)
a delivery schedule that is inconsistent with Section 2.4(d), (ii) a Product quantity that is
inconsistent with Section 2.4(e)(ii), (iii) a Product quantity that is less than the Firm Order for
the applicable period or (iv) subject to Section 2.4(c), a Product quantity that is more than one
hundred ten percent (110%) of the Forecast for the applicable period. Manufacturer shall be deemed
to have accepted Customer's Purchase Order for Products in the event it either (a) indicates its
acceptance of Customer's Purchase Order in writing or (b) does not indicate its rejection of a
Purchase Order within ten (10) Business Days of receipt pursuant to this Section 2.4(f). (g) Changes
to Purchase Orders. Purchase Orders, once submitted to Manufacturer, may be amended only by mutual
written agreement of the Parties; provided that Manufacturer shall exercise its commercially
reasonable efforts to comply with proposed amendments to Purchase Orders that Customer may request
after sending a Purchase Order to Manufacturer. (h) Cancellations. In the event that Customer
cancels all or part of a Purchase Order (provided that a cancellation shall be deemed to have
occurred to the extent that Customer fails to issue a Purchase Order with respect to the full amount
of Product contemplated by any portion of a Forecast with respect to the Binding Forecast Period)
and such cancellation is not due to Manufacturer's breach of this Agreement or any Facility
Addendum, Manufacturer will use good faith efforts to reallocate capacity and mitigate any resultant
costs of such cancellation and, unless otherwise set forth with respect to the relevant cancelled
Product under the applicable Facility Addendum, Customer will be charged for one hundred percent
(100%) of any and all non-cancellable Third-Party costs actually and reasonably incurred by
Manufacturer in accordance with this Agreement prior to cancellation for materials or services
related to the cancelled portion of the Purchase Order for which reasonably acceptable documentation
is submitted by Manufacturer to Customer. -18-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 23 -->
(i) Conflicts. In the event of any conflict between the provisions of this Agreement and any
Customer Purchase Order, Manufacturer's acceptance form or Manufacturer's invoice form or any
similar such forms, the provisions of this Agreement shall govern and control. (j) Product Inventory
as of Effective Date. Promptly following the Effective Date, Manufacturer shall provide Customer
with a Product inventory report organized by Facility, lot number, remaining shelf life, and such
other data points with respect to such Product inventory as Customer may request. For the avoidance
of doubt, (i) Manufacturer shall be entitled to fill Purchase Orders with such inventory that
complies with the terms and conditions of this Agreement, including Section 5.2, and (ii) the
Parties shall meet to discuss in good faith the disposition of all such Product inventory that does
not meet the criteria set forth in (i) above. 2.5 Failure to Supply. (a) Capacity Allocation. In the
event that Manufacturer fails to manufacture and deliver Product in accordance with accepted
Purchase Orders or applicable Specifications, Manufacturer shall notify Customer promptly, including
details of the reasons for the failure and Manufacturer's estimated timeline of when the failure
will be corrected. Manufacturer shall be solely responsible for undertaking commercially reasonable
measures to minimize any shortage of Product delivered to Customer as a result of such manufacturing
issues. If Manufacturer fails to manufacture and deliver Product in accordance with accepted
Purchase Orders or applicable Specifications by the delivery date specified in the applicable
Purchase Order(s) in accordance with Section 2.4(d), other than due to a Force Majeure Event, (i)
for a period of two (2) or more months past such delivery date four (4) or more times in any rolling
twelve (12) month period, or (ii) for a period of four (4) or more months past such delivery date on
one occasion (each of (i) and (ii), a "Triggering Event"), then Manufacturer shall use its best
efforts to allocate on a quarterly basis its manufacturing capacity and Product Materials to the
manufacture and supply of Products for Customer on a ratable basis based on the use of each during
the twelve (12)-month period immediately preceding such Triggering Event (or either (1) the Term of
the applicable Facility Addendum, if the Term is less than twelve (12) months, or (2) such other
period set forth in the applicable Facility Addendum); provided that (A) if Customer's Minimum Order
Quantity for the applicable Product(s) exceeds its ratable allocation of manufacturing capacity or
Product Materials (as applicable) for the applicable quarter, Customer shall continue to accrue its
allocation of capacity until such quarter when Customer's allocation of capacity is equal to or
greater than its accrued allocation of capacity and (B) this Section 2.5(a) shall not apply to the
extent that Customer fails to timely provide adequate Customer-Supplied Materials or Buy-Sell
Materials to Manufacturer in accordance with Section 12. For the avoidance of doubt, Manufacturer
shall notify Customer promptly in writing of any anticipated Triggering Event when Manufacturer has
reason to believe that such Triggering Event is likely to occur and provide such information with
respect to such anticipated Triggering Event as Customer may reasonably request. -19-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 24 -->
(b) Suspension of the Exclusive Purchase Requirement. In the event of a Triggering Event, Customer's
Exclusive Purchase Requirement with respect to each and every Product that is the subject of the
Triggering Event shall be temporarily suspended until such time as Manufacturer notifies Customer
that Manufacturer is able to resume the manufacture and supply of the subject Product(s) on the
terms and conditions of this Agreement (such period referred to as the "Exclusive Purchase
Requirement Suspension Period"); provided that, (i) during such Exclusive Purchase Requirement
Suspension Period, Customer shall use commercially reasonable efforts to limit its orders for the
subject Product(s) to the quantities specified in the last Forecast that preceded the Triggering
Event for the applicable period(s) and promptly notify Manufacturer in the event and to the extent
that Customer's orders exceed such quantities specified in such Forecast and (ii) Customer shall be
entitled to take delivery of Product(s) ordered during the Exclusive Purchase Requirement Suspension
Period even if such delivery is scheduled for or actually occurs subsequent to the Exclusive
Purchase Requirement Suspension Period. (c) Modification of the Exclusive Purchase Requirement. Upon
the expiration of the Exclusive Purchase Requirement Suspension Period, Customer shall use
commercially reasonable efforts to resume ordering from Manufacturer, on a Product-by-Product basis,
the subject Product(s) in accordance with Customer's Exclusive Purchase Requirement during the
Exclusivity Period. (d) Business Continuity. Manufacturer shall maintain a written business
continuity plan to be able to assure supply of Product to Customer in the event of a disruption to
supply from the primary location or Facility of manufacture, including any disruption resulting from
a Force Majeure Event and make such plan available from time to time upon Customer's request. (e)
Remedies. Customer shall have the right to terminate this Agreement on an affected
Product-by-affected Product basis immediately upon written notice to Manufacturer in the event a
Triggering Event (under clause (ii) thereof) continues for more than one hundred and eighty (180)
days. Customer shall also have the right to cancel orders for any quantities of Product affected by
any Triggering Event effective upon notice to Manufacturer, and Customer shall have no further
obligations to purchase any such cancelled quantities of Product. In the event a Triggering Event
occurs during the Exclusivity Period, Manufacturer shall, at Manufacturer's cost and expense,
provide such assistance as is reasonably requested by Customer to assist any alternate manufacturer
in meeting Customer's requirements for the Product until Manufacturer has remedied the cause of such
Triggering Event and is -20-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 25 -->
able to supply Product to Customer in its requested quantities. Such assistance shall include
providing, subject in all cases to Section 2.10(h), Technical Support in respect of the affected
Product(s). In the event of a Triggering Event, Manufacturer shall be liable for any actual amounts
that Customer is contractually required to pay to any Third-Party customer of Customer that result
from Customer's inability to supply the affected Product to such Third-Party customer as a direct
result of such Triggering Event; provided that (1) Customer shall provide to Manufacturer
appropriate evidence of such amounts (including invoices from the applicable customers) and the
applicable contractual requirements (redacted, in each case, of information pertaining to pricing
and other commercial terms that are not directly related to the claimed amounts), it being
understood and agreed that, upon request, Manufacturer will enter into customary confidentiality
arrangements prior to such information being shared and (2) Manufacturer shall not be liable for any
such amounts in the aggregate in any Fiscal Year in excess of the aggregate Conversion Cost Markup
during such Fiscal Year with respect to all Products manufactured at the Facility that is the
subject of the applicable Triggering Event. "Conversion Cost Markup" means, for a Product for any
Fiscal Year, ten percent (10%) of the product of (A) Manufacturer's Standard Conversion Cost for
such Product for such Fiscal Year and (B) the quantity of such Product ordered by Customer for
delivery during such Fiscal Year. The rights of Customer set forth in this paragraph are in addition
to any other rights set forth in this Agreement. 2.6 Delivery; Risk of Loss. (a) Delivery. Unless
otherwise set forth in the applicable Facility Addendum, Manufacturer shall deliver Product to
Customer FCA (Incoterms 2010) at the applicable Facility, and all Purchase Orders will be deemed to
have been completed when the quantity of Product made available to Customer at the applicable
Facility is between ninety percent (90%) and one hundred and ten percent (110%) of the quantity of
Product set forth in any accepted Purchase Order (each such event, a "Delivery"). Delivery shall
occur by or within the delivery date(s) set forth in the applicable Purchase Order or such other
date as may be agreed to in writing by the Parties from time to time. Without limiting Customer's
rights and remedies under Section 4.8, Manufacturer acknowledges and agrees that, unless such early
Delivery was agreed upon by the Parties in writing, Manufacturer shall provide Customer with such
data as Customer may reasonably request from time to time for measures of key performance indicators
(KPI). (b) Certificates of Compliance. Manufacturer shall include certificates of compliance and
certificates of analysis with all Delivery of Product or prior to Delivery upon reasonable request
of Customer. -21-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 26 -->
(c) Title. Unless otherwise set forth in the applicable Facility Addendum, title to Product and risk
of loss or damage shall pass to Customer upon Delivery to Customer pursuant to Section 2.6(a). 2.7
Procurement of Materials. (a) Manufacturer shall order and maintain sufficient quantities of all
Product Materials, including safety stock as required by the applicable Facility Addendum, to enable
Manufacturer to manufacture and Deliver Product in accordance with its Delivery obligations under
this Agreement and the applicable Facility Addendum. With respect to those Third Party suppliers of
Product Materials used by Manufacturer or its Affiliates in the ordinary course in the manufacturing
or supply of a given Product immediately prior to the Effective Date ("Manufacturer Third Party
Suppliers"), Manufacturer shall be permitted to purchase solely the same Product Materials from such
Manufacturer Third Party Suppliers in connection with its activities under this Agreement without
first obtaining Customer's prior written consent. Any other Third-Party supplier for Product
Materials (or procurement of a different Product Material from any Third-Party supplier) must be
approved in advance in writing by Customer (such approval not to be unreasonably withheld,
conditioned or delayed). For the avoidance of doubt, as of the Effective Date, as between
Manufacturer and Customer, Manufacturer will be solely responsible for maintaining and establishing
relationships with the Third-Party suppliers of Product Materials. The costs of all such Product
Materials shall be included in the Price of the applicable Product. (b) Unless otherwise set forth
in the applicable Facility Addendum for a specific Product, Customer shall have no liability for
excess or obsolete Product Materials purchased by Manufacturer, (x) except as set forth in Section
2.4(h) or Section 7.9 or (y) unless the excess or obsolescence is caused by a change to the
specifications for such Product Materials or the Specifications of a given Product in accordance
with this Agreement after such Product Materials have been purchased by Manufacturer based upon a
Firm Order or accepted Purchase Order). (c) Customer understands and acknowledges that (i) certain
Product Materials have a limited shelf-life, are long lead time items, and are subject to minimum
order quantities specified by the applicable supplier and (ii) Manufacturer will rely on the Firm
Orders and Forecasts to order Product Materials required to meet the Firm Orders (plus safety stock
for certain Product Materials of a Product as reasonably determined by Manufacturer). In addition,
Customer understands that, to ensure an orderly supply of the Product Materials, Manufacturer may
elect to purchase the Product Materials in sufficient volumes to meet the production requirements
for Products during part or all of the forecasted periods; provided, however, that Customer shall
not have any liability with respect to any purchase by Manufacturer or any of its Affiliates of
labeling or packaging materials (including labels, cartons and leaflets) in excess of the amount
required to meet the Firm Order applicable at such time plus the amount of applicable Product
forecasted to be ordered in months four (4) through six (6) of the Forecast applicable at such time.
-22-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 27 -->
(d) Manufacturer must review with Customer any assessment made (or related action proposed to be
taken) by Manufacturer related to rejection or destruction of any Customer-Supplied Materials,
Buy-Sell Materials, Product, or Product Materials intended for Customer's Product to discuss
viability for commercial use. 2.8 Product Samples.

If representative lot samples of production batches of Product are requested by Customer in order to
satisfy its obligations under applicable Law, including any regulatory requirements, or to any
Governmental Authority, then Manufacturer shall provide Customer (or any such Third Party as
Customer shall designate) with representative lot samples of each production batch of Product
promptly upon Customer's request. Customer shall be entitled to review, upon reasonable prior
written notice, all manufacturing Records relating to such samples, including all analytical
procedures and cleaning validation relating to the equipment used in connection with the manufacture
of the samples. Such Product samples shall be Delivered to Customer (or such Third Party as Customer
shall designate) in accordance with the provisions set forth in Section 2.6(a) and at the Price as
determined in accordance with the terms of Section 3. Customer shall pay for such samples when
invoiced in accordance with Section 3.5. 2.9 Storage.

Manufacturer will store Products, Buy-Sell Materials, Product Materials, and Customer-Supplied
Materials in accordance with the requirements of the Quality Agreement. With respect to those
Third-Party warehouses used by Manufacturer or its Affiliates in the ordinary course for the storage
of a given Product, Buy-Sell Materials, Product Materials, or Customer-Supplied Materials
immediately prior to the Effective Date, Manufacturer may engage such Third-Party warehouse to
perform the solely same activities for such Product, Buy- Sell Materials, Product Materials, and
Customer-Supplied Materials under this Agreement without first obtaining Customer's prior written
consent. The use of any Third Party warehouse for the storage of any Product, Buy-Sell Materials,
Product Materials, or Customer- Supplied Materials other than in the manner expressly permitted
pursuant to this Section 2.9 must be approved in advance in writing by Customer, such approval not
to be unreasonably withheld, conditioned or delayed. Manufacturer shall obtain the right for
Customer to audit, at Customer's expense, any such Third-Party warehouse upon reasonable prior
advance written notice and during normal business hours. Manufacturer has no obligation to store
Product more than fifteen (15) Business Days following the requested delivery date for such Product;
provided that (a) Manufacturer shall be obligated to store Product for such longer -23-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 28 -->
period as may be reasonably necessary for Customer to arrange transportation for such Product in the
event that Manufacturer experiences delays in the manufacture, release, or supply of a particular
Product that results in the delivery of a quantity of Product that exceeds historical or Forecast
quantities of Product for the applicable period and; (b) with respect to any Product that Customer
reasonably believes should not be released by Manufacturer, Manufacturer shall store such Product
until the Parties' definitive resolution pursuant to this Agreement and the Quality Agreement as to
whether such Product should be released. At the expiration of the applicable time frame in the
preceding sentence, notwithstanding any provision of this Section 2.9 to the contrary, Manufacturer
may transport and store the subject Product at a Third-Party warehouse at Customer's expense. 2.10
Transitional Support. (a) On a Product-by-Product basis, Customer may elect, upon written notice to
Manufacturer, for Manufacturer to provide Customer with reasonable technical support, as more fully
set forth in this Section 2.10, to transfer production of a given Product or Products to a Customer
facility or a facility of an alternative source of supply as designated by Customer (such support,
"Technical Support" and such facility, the "Receiving Site"). Customer may make such election for
Technical Support at any time during the Term (including in the event of a Triggering Event under
Section 2.5(a) or in advance of any expiration of this Agreement) or promptly after the termination
or expiration of this Agreement but in no event more than ninety (90) days following the effective
date of such termination or expiration. Such reasonable Technical Support shall consist of: (i)
supply of a technical package to facilitate the transfer of all relevant manufacturing information
for such Product(s) to the Receiving Site, including formulation descriptions, manufacturing
instructions, Specifications, methods, data required for applicable regulatory submissions and
facility qualification, and material supplier information, as applicable, except for any information
that is subject to confidentiality obligations owing to a Third Party; provided that the technical
package will not include any manufacturing information, including formulation descriptions,
manufacturing instructions, Specifications, methods and material supplier information, that is
generally available to or known by the public, can be obtained on reasonable terms from Third
Parties or is already available or being utilized by Customer or its Affiliate at one of Customer's
or its Affiliate's facilities; (ii) host site visits to the Manufacturer's Facility by Customer to
observe production of the applicable Product or Products, in each case, at a mutually agreed date
and subject to confidentiality procedures or requirements as may be requested or implemented by
Manufacturer; provided that the request for each such visit shall be made so as to allow for
sufficient advance preparation time and can be accommodated in the requested timeframe without
interruption to Manufacturer's routine production or operations; -24-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 29 -->
(iii) performance of high-level consultation and answering reasonable queries for Customer through
the transfer process; and (iv) provision of reasonable Product samples required under applicable Law
for transfer activities. (b) Customer shall be responsible for identifying and requesting any and
all Technical Support that is required from Manufacturer to assure such technology transfer is
successful. (c) The Parties shall reasonably cooperate and mutually agree to facilitate the
provision of any additional reasonable Technical Support with respect to the applicable Product or
Products to Customer, including assistance through the transfer process, Manufacturer Personnel
visits to the Receiving Site and training and troubleshooting during the Receiving Site's first
production run of the applicable Product or Products, in each case, as and to the extent reasonably
agreed by Manufacturer in each instance (and subject to Sections 2.10(d), 2.10(e) and 2.10(f)). (d)
The Parties will work together in good faith to plan for upcoming and ongoing Technical Support
needs and to accommodate such plans in order to maintain ongoing business continuity. In addition,
Manufacturer shall have no obligation to hire or retain any individuals or make any capital
expenditures in connection with Technical Support, and Manufacturer's obligation to provide
Technical Support is contingent upon the continued employment by Manufacturer of those individuals
capable of providing such Technical Support. Manufacturer may terminate its obligation to provide
any Technical Support with respect to the applicable Product under this Agreement if Customer or any
of its Affiliates hires any Manufacturer Personnel involved in providing Technical Support to
Customer hereunder (without limiting any applicable non-solicitation obligations of Customer
pursuant to the Business Combination Agreement). (e) Customer shall be solely responsible for any
and all regulatory or other Governmental Authority requirements, activities and related costs and
expenses that arise in conjunction with any Technical Support, technology transfer of production or
production of each Product to or at the Receiving Site. These activities may also include, but are
not limited to, creation of additional data or technical information, analytical method
modifications or other work of a technical nature required to support regulatory queries or
contemporary standards and guidelines driven by the manufacturing transfer (subject to Section 8.2).
-25-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 30 -->
(f) Subject to Section 2.5(e), Customer is responsible for, and shall promptly reimburse
Manufacturer for, any and all reasonable out-of- pocket costs and expenses incurred by or on behalf
of Manufacturer in connection with any Technical Support provided to Customer under this Agreement,
including employee costs to be charged at a rate that reasonably approximates the cost of providing
the Technical Support, without any intent to cause Manufacturer to make profit or incur loss. (g)
With respect to each Product for which Manufacturer provides Technical Support under this Agreement,
Manufacturer shall provide to Customer any analytical materials and methods in Manufacturer's
possession or control that are required in connection with disclosures to any applicable
Governmental Authority to qualify the applicable Product Materials, Buy-Sell Materials, or Customer-
Supplied Materials for such Product or such Product itself for release testing to meet the
then-current applicable marketing authorization, in each case, subject to Section 13. (h) Nothing in
this Agreement shall require Manufacturer to provide more than 75 hours per calendar year per
Product in connection with any Technical Support. Notwithstanding anything to the contrary herein,
except as expressly provided in Section 2.10(g), Manufacturer shall have no obligation to disclose,
license or otherwise provide confidential or proprietary information of Manufacturer, its Affiliates
or any Third Party in connection with this Agreement or any Technical Support or technology transfer
therein. 3. Price; Payment; Price Adjustments; Taxes. 3.1 Price. (a) Initial Price. On a Fiscal
Year-by-Fiscal Year basis, Customer shall purchase each Product from Manufacturer at the Price for
such Product for such Fiscal Year, as determined in accordance with the terms of this Section 3. The
Price for each Product during the Initial Price Term (such Price, the "Initial Price" for such
Product) is set forth in the Facility Addendum for such Product. Following the Initial Price Term,
the Price of such Product may be adjusted only as set forth in Section 3.1(b) and Section 3.2. (b)
Price in Extension Periods. In the event that Customer elects to extend the Initial Term of the
Agreement or of a Facility Addendum, the Price for each applicable Product in any Extension Period
shall be one hundred percent (100%) of Manufacturer's Standard Product Materials Cost plus one
hundred and ten percent (110%) of Manufacturer's Standard Conversion Cost of such Product, each for
the initial Fiscal Year of the first Extension Period with respect to such Product. During each
Extension Period, the Price of such Product may be adjusted as set forth in Section 3.2; provided
that the initial Fiscal Year of the first Extension Period shall operate as the Facility Conversion
Cost Baseline Fiscal Year (as defined below). -26-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 31 -->
(c) Subject to the limitations and conditions set forth in this Agreement, it is the intention of
the Parties that the Price of each Product reflects one hundred percent (100%) of Manufacturer's
Standard Product Materials Cost plus one hundred and ten percent (110%) of Manufacturer's Standard
Conversion Cost of such Product. The Price for each Product will be set forth in the currency
specified in the applicable Facility Addendum. (d) Changes to the Standard Cost Methodology.
Manufacturer shall have the right to change the Standard Cost methodology once per Fiscal Year;
provided that any change shall be consistent with the Accounting Method and applied across all
products manufactured at the applicable Facility. If Manufacturer elects to change the Standard Cost
methodology, Manufacturer shall calculate both (i) the revised Standard Cost using the methodology
effective during the then-current Fiscal Year of the Term of the applicable Facility Addendum and
(ii) the percentage change in Standard Cost caused by the change in methodology relative to the
former methodology. If such Standard Cost methodology change results in an increase of Facility
Conversion Cost for Products manufactured for Customer of more than two percent (2%), then
Manufacturer shall revert to the former methodology for purposes of the calculation of Price during
such Fiscal Year. 3.2 Price Adjustment. (a) Product Materials Adjustment. (i) On a
Facility-by-Facility basis, with respect to each full Fiscal Year of the Term of the applicable
Facility Addendum, the Price of each Product manufactured at the applicable Facility will be updated
to reflect one hundred percent (100%) of the full estimated amount of the increase or decrease in
the cost of Product Materials for each such Product. (ii) In each Fiscal Year of the Term of this
Agreement, Manufacturer shall submit a report to Customer by no later than the end of the first
quarter of such Fiscal Year setting out the Facility Actual Product Materials Cost with respect to
each Facility for the prior Fiscal Year. In the event that the Facility Actual Product Materials
Cost differs from the Facility Estimated Product Materials Cost, when adjusted to reflect actual
volume, then Manufacturer shall issue either (A) an invoice to Customer for any amounts owed by
Customer to Manufacturer or (B) a credit memo for amounts owed by Manufacturer to Customer
reflecting the difference between the Price as invoiced and an adjusted Price for such Fiscal Year;
-27-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 32 -->
provided, however, that any such adjustment made in accordance with the foregoing shall be subject
in all cases to the provisions of Section 3.2(e). Customer shall pay all undisputed amounts due in
the currency specified in the applicable Facility Addendum within sixty (60) calendar days from the
date of the invoice. If Customer disputes all or any portion of an invoice, it shall be required to
pay only the amount not in dispute, and in such event Customer shall notify Manufacturer of the
amount and nature of the dispute. Payment by Customer of any amount reflected in any invoice shall
not result in a waiver of any of Customer's rights under this Agreement. (b) Conversion Cost
Adjustments. (i) Subject to the remainder of this Section 3.2(b), on a Facility-by-Facility basis,
if the Facility Conversion Costs of a Facility during any Fiscal Year following the first full
Fiscal Year of the Term of the applicable Facility Addendum (such Fiscal Year, a "Facility
Conversion Cost Adjustment Fiscal Year") are estimated to be (a) less than seventy-five percent
(75%) of the Facility Conversion Costs for the Facility Conversion Cost Baseline Fiscal Year (as
defined below) or (b) greater than one hundred and twenty-five percent (125%) of the Facility
Conversion Costs for the Facility Conversion Cost Baseline Fiscal Year (clauses (a) and (b) referred
to collectively as the "Facility Conversion Cost Threshold"), when adjusted to reflect a constant
volume between the Facility Conversion Cost Adjustment Fiscal Year and the Facility Conversion Cost
Baseline Fiscal Year, then the Price for such Product will be updated beginning with such Facility
Conversion Cost Adjustment Fiscal Year to reflect one hundred and ten percent (110%) of the increase
or decrease in Facility Conversion Costs. An example calculation of the foregoing Price adjustment
is attached hereto as Attachment G. Subject to the last sentence of Section 3.1(b), the "Facility
Conversion Cost Baseline Fiscal Year" shall be, as of the Effective Date, 2019 budget volumes and
costs as summarized in the applicable Facility Addenda; provided that in each instance in which the
Price is adjusted in accordance with the immediately preceding sentence of this Section 3.2(b)(i),
the Facility Conversion Cost Baseline Fiscal Year shall be the applicable Facility Conversion Cost
Adjustment Fiscal Year. (ii) In the event that Price is adjusted as a result of a change to Facility
Conversion Cost under Section 3.2(b)(i), the Facility Conversion Cost Threshold for all remaining
Fiscal Years in the Initial Term (or Extension Periods as appropriate) will be reduced such that if
Facility Conversion Costs of a Facility during any Facility Conversion Cost Adjustment Fiscal Year
are estimated to be (a) less -28-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 33 -->
than eighty percent (80%) of the Facility Conversion Costs for the Facility Conversion Cost Baseline
Fiscal Year or (b) greater than one hundred and twenty percent (120%) of the Facility Conversion
Costs for the Facility Conversion Cost Baseline Fiscal Year, then the Price for such Product will be
updated beginning with such Facility Conversion Cost Adjustment Fiscal Year to reflect the full
estimated amount of the increase or decrease in Conversion Cost. (iii) Notwithstanding anything to
the contrary in this Section 3.2(b), Manufacturer shall not have the ability to adjust the Price to
reflect actual volume for Products in a Facility to the extent that Customer has reduced its demand
for one or more Products in such Facility due to Manufacturer's breach of or other failure to supply
under this Agreement or the applicable Facility Addendum. (iv) In each Fiscal Year following the
first full Fiscal Year of the Term of this Agreement, Manufacturer shall submit a report to Customer
by no later than the end of the first quarter of such Fiscal Year setting out the actual volume of
Product for each Facility for the prior Fiscal Year. In the event that the actual Facility
Conversion Costs demonstrate that the then applicable Facility Conversion Cost Threshold has been
exceeded, and Manufacturer had not previously adjusted the applicable Price in accordance with this
Section 3.2(b) to account for such adjustment, then Manufacturer shall either issue (A) an invoice
to Customer for any amounts owed by Customer to Manufacturer or (B) a credit memo for amounts owed
by Manufacturer to Customer reflecting the difference between the Price as invoiced and the adjusted
Price for such Fiscal Year; provided, however, that any such adjustment made in accordance with the
foregoing shall be subject in all cases to the provisions of Section 3.2(b)(iii). For clarity, any
amount owed by Customer to Manufacturer or owed by Manufacturer to Customer shall be one hundred and
ten percent (110%) of Manufacturer's Conversion Cost, reduced by a 20% allowance for variable costs.
Customer shall pay all undisputed amounts due in the currency specified in the applicable Facility
Addendum within sixty (60) calendar days from the date of the invoice. If Customer disputes all or
any portion of an invoice, it shall be required to pay only the amount not in dispute, and in such
event Customer shall notify Manufacturer of the amount and nature of the dispute. Payment by
Customer of any amount reflected in any invoice shall not result in a waiver of any of Customer's
rights under this Agreement. (c) Notwithstanding the above, the price for Buy-Sell Materials will be
updated annually in each year following the first Fiscal Year to reflect one hundred percent (100%)
of the full estimated amount of the cost of Buy-Sell Materials to Manufacturer. Customer may not
change the price of Buy-Sell -29-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 34 -->
materials during any Fiscal Year. Upon any notification by Customer to Manufacturer of any reduction
in the price of Buy-Sell Materials for the upcoming Fiscal Year, Manufacturer shall submit to
Customer an inventory of such Buy-Sell Materials on hand and a calculation of the positive
difference between the aggregate price for such Buy-Sell Materials applying the price for the
current Fiscal Year and the aggregate price for such Buy-Sell Materials applying the price for the
upcoming Fiscal Year. Customer shall promptly and in no event later than sixty (60) days issue to
Manufacturer a credit memo in the amount of such positive difference reflected in Manufacturer's
notice. (d) The increases or decreases described in this Section 3.2 shall be determined by
Manufacturer in a manner consistent with the accounting methodologies used by Manufacturer as of the
Effective Date and shall be based on the applicable Forecasts provided by Customer in July of the
applicable Fiscal Year and applied consistently across Manufacturer's entire manufacturing
operations for the full Facility. (e) Manufacturer shall notify Customer of any estimated expected
changes to Prices for the upcoming Fiscal Year by no later than June 1 of the then-current Fiscal
Year and shall notify Customer of any actual changes to Prices for the upcoming Fiscal Year by no
later than October 30 of the then-current Fiscal Year. Between June 1 and October 30, the Parties
will engage in ongoing discussions to ensure that any final changes to Prices for the applicable
Fiscal Year conform to the terms and conditions of this Agreement. Manufacturer will promptly
respond to Customer's inquiries regarding any proposed changes to the Price of Products and provide
reasonable documentation to Customer supporting the estimated or actual change in such Prices. Any
actual, adjusted Price of each Product shall become effective on the first day of the first month of
such upcoming Fiscal Year. (f) Any disputes relating to changes in Price for a given Product will be
resolved pursuant to Section 3.4. 3.3 Cost Improvement.

At Customer's reasonable request, Manufacturer and Customer agree to discuss in good faith the
implementation of possible cost reduction opportunities with the objective to reduce the net Price
of Product. Without limiting the generality of the foregoing, Manufacturer shall use commercially
reasonable efforts to reduce the price of Product Materials. -30-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 35 -->
3.4 Price Review and Audit Procedure. (a) Manufacturer shall maintain complete and accurate Records
that fairly reflect the relevant costs and calculations used to determine the Price of each Product
and shall retain such Records for a period of not less than three (3) years after the applicable
Product was manufactured and delivered hereunder. With respect to a Price change under Section 3.2
for any Product in an upcoming Fiscal Year, if Customer requests such a review in writing within
thirty (30) days following notice to Customer of such change, then: (i) the Parties shall reasonably
discuss and attempt to resolve any disagreement with respect thereto and (ii) if such disagreement
is not resolved within thirty (30) days following commencement of such discussions, Customer shall
have the right, no more than one (1) time per Fiscal Year each for the subject of (1) and (2) below
and on no less than thirty (30) days' notice to Manufacturer, to appoint a reputable and
internationally recognized independent Third-Party audit firm reasonably acceptable to Manufacturer
(and which agrees to be bound by Manufacturer's customary confidentiality agreement) to audit such
relevant Records, during normal business hours and on a confidential basis, to verify that, either
(1) the change in the relevant Products' Price for an applicable Facility for the upcoming Fiscal
Year, as applicable, or (2) the true-up determination with respect to (x) the estimated and actual
Facility Conversion Costs of a Facility with respect to any Fiscal Year or (y) the Facility
Estimated Product Materials Cost and the Facility Actual Product Materials Cost with respect to any
Fiscal Year, was accurately and equitably calculated by Manufacturer in accordance with this
Agreement; provided that Customer shall be deemed to have waived its right for such a review if
Customer does not make such request within thirty (30) days following delivery of Manufacturer's
notice to Customer of such increase. For the avoidance of doubt, any such audit initiated by
Customer in accordance with clause (ii) above shall include in the scope of audit all of the
Products manufactured at the applicable Facility, and not be limited in scope to the discrete
Product(s) in question. Subject to Section 3.4(b)(2), Customer shall bear all costs and expenses of
conducting such an audit, and such accounting firm shall work on an hourly or flat fee basis without
a contingency fee or other performance or bonus fee. Such accounting firm shall, as promptly as
practicable, provide in writing (I) a detailed report of such audit to Manufacturer and (II) a
separate report limited to the Price for the subject Products in the relevant Fiscal Year as
calculated by such accounting firm in accordance with this Agreement to Manufacturer and Customer.
The Price for the Products during a Fiscal Year, as calculated by such accounting firm, absent any
manifest error, shall be binding upon the Parties with respect to such increase or required payment,
as applicable; provided that, within fifteen (15) days of receipt of the audit report, Manufacturer
shall have the right to dispute such Price or calculation thereof by submitting written notice to
Customer and the accounting firm accompanied by information supporting Manufacturer's position.
Within thirty (30) days of receipt of Manufacturer's notice of dispute, the accounting firm shall
issue its final findings with respect to the Price for the relevant Product in the relevant Fiscal
Year and such decision, absent manifest error, shall be binding upon the Parties. -31-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 36 -->
(b) If, as a result of any audit by Customer pursuant to Section 3.4(a), the aggregate Price
calculated by the accounting firm with respect to all Products manufactured at the applicable
Facility for a Fiscal Year is: (i) less than ninety-five percent (95%) of the aggregate Price for
all such Products established by Manufacturer pursuant to Section 3.2 for such Products during such
Fiscal Year, then, if Customer has made payments to Manufacturer for such Products at the higher
Price established by Manufacturer during such Fiscal Year, Manufacturer shall refund to Customer the
overpayment made by Customer; or (ii) more than one hundred and five percent (105%) of the aggregate
Price for all such Products established by Manufacturer pursuant to Section 3.2 for such Products
during such Fiscal Year, then, if Customer has made payments to Manufacturer for such Products at
the lower Price established by Manufacturer for such period, Customer shall promptly pay
Manufacturer for the amount of the underpayment that should have been paid by Customer;

in each case of clauses (i) and (ii), (1) such payment to be made within sixty (60) days of the
owing Party's receipt of the relevant detailed report and final Price pursuant to Section 3.4(a) and
(2) Manufacturer shall be responsible for payment of the applicable accounting firm's reasonable and
actual fees in connection with such audit. 3.5 Invoices and Payment.

Manufacturer shall submit invoices to Customer upon Delivery of Product. All invoices for Products
will be in functional currency unless otherwise specified in the applicable Facility Addendum, and
all undisputed payments hereunder shall be in full and be made without any withholding, offset or
any other deductions. Manufacturer shall include the following information on all invoices: (a) the
applicable Purchase Order number and billing address; (b) the quantity of Product delivered (and
where applicable, the type, description or part number, if any); (c) the required delivery date
specified in the applicable Purchase Order; (d) the actual date of Delivery; (e) the Price; (f) any
applicable Taxes, transportation charges or other charges provided for in the applicable Purchase
Order; (g) the applicable invoice number; and (h) the Delivery Facility, unless otherwise specified
in the Facility Addendum. Subject to Customer's rights under Section 4.8 to reject Non-Complying
Product or Product that is not otherwise Delivered in accordance with the terms of and conditions of
this Agreement, Manufacturer shall invoice Customer for Product upon Delivery of the applicable
Product in accordance with Section 2.6(a). Customer shall be obligated to pay only for actual
quantities of -32-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 37 -->
Product delivered. Unless otherwise set forth in the applicable Facility Addendum with respect to a
particular Product or Products, Customer shall pay all undisputed amounts due in the currency
specified in the applicable Facility Addendum within sixty (60) calendar days from the date of the
invoice. If Customer disputes all or any portion of an invoice, it shall be required to pay only the
amount not in dispute, and in such event Customer shall notify Manufacturer of the amount and nature
of the dispute. Payment by Customer of any amount reflected in any invoice shall not result in a
waiver of any of Customer's rights under this Agreement. If any payment required to be made under
this Agreement is not made within twenty (20) days of the applicable date when such payment is due
(the "Late Payment Date"), interest shall accrue on such past due amount from the Late Payment Date
until the date payment is actually made at a quarterly rate equal to the lesser of (i) the
Three-Month U.S. dollar LIBOR (Reuters Page LIBOR01) on the Late Payment Date (or the next Business
Day if such Late Payment Date is not a Business Day), and (ii) the maximum rate permitted by
applicable Law. Time for any payments hereunder shall be of the essence. 3.6 Taxes. (a) All sums
payable under this Agreement are exclusive of any amount in respect of VAT. If any action of one
Party (the "Supplier") under this Agreement constitutes, for VAT purposes, the making of a supply to
another Party (or a member of that Party's Group) (the "Recipient") and VAT is or becomes chargeable
on that supply, the Recipient shall pay to the Supplier, in addition to any amounts otherwise
payable under this Agreement by the Recipient, a sum equal to the amount of the VAT chargeable on
that supply against delivery to the Recipient of a valid VAT invoice issued in accordance with the
laws and regulations of the applicable jurisdiction. (b) Without duplication of amounts covered by
Section 3.6(a), Customer (or the applicable Affiliate) shall be responsible for all VAT, sales,
goods and services, use, gross receipts, transfer, consumption and other similar Taxes (excluding,
for clarity, Taxes imposed on net income, profits and gains and franchise Taxes), together with
interest, penalties and additions thereto ("Service Taxes"), imposed by applicable taxing
authorities on the direct sale of Products to Customer or any of its Affiliates or any payment
hereunder; provided that such Service Taxes are shown on a valid invoice. If Manufacturer or any of
its Affiliates is required to pay any part of such Service Taxes, Manufacturer shall provide
Customer with evidence that such Service Taxes have been paid, and Customer (or its applicable
Affiliate) shall reimburse Manufacturer for such Service Taxes. Manufacturer shall, upon the
reasonable request of Customer, promptly revise any invoice to the extent such invoice was
erroneously itemized or categorized. Each Party shall, and shall cause its Affiliates to, use
commercially reasonable efforts to (i) minimize the amount of any Service Taxes imposed on the
provision of Services hereunder, including by availing itself of any available exemptions from or
reductions to any such -33-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 38 -->
Service Taxes, and (ii) cooperate with the other Party in providing any information or documentation
that may be reasonably necessary to minimize such Service Taxes or obtain such exemptions or
reductions. If at any time Manufacturer (or any of its Affiliates) receives a refund (or credit or
offset in lieu of a refund) of any Service Taxes borne by Customer (or any of its Affiliates), then
Manufacturer or its Affiliate receiving such refund or utilizing such credit or offset shall
promptly pay over the amount of such refund, credit or offset (net of all reasonable related
out-of-pocket costs, expenses and Taxes incurred in respect thereof) to Customer or its applicable
Affiliate, it being understood that Customer and its applicable Affiliate shall be liable for (x)
any subsequent disallowance of such refund, credit or offset and any related interest, penalties or
additions thereto and (y) any reasonable out-of- pocket costs and expenses related to such
disallowance. (c) The Parties and their Affiliates shall reasonably cooperate to determine whether
any Tax withholding applies to any amounts paid under this Agreement and, if so, shall further
reasonably cooperate in (i) minimizing the amount of any such withholding Taxes, including by
availing itself of any available exemptions from or reductions to any such withholding Taxes, (ii)
providing any information or documentation that may be reasonably necessary to minimize such
withholding Taxes or obtain such exemptions (including, without limitation, pursuant to any
applicable double taxation or similar treaty) or (iii) receiving a refund of such withholding Taxes
or claiming a Tax credit therefor. If any such withholding is required by applicable Law, the paying
Party (or its applicable Affiliate) shall properly and timely withhold and remit such Taxes to the
applicable taxing authority and use reasonable efforts to provide the other Party with a copy of any
receipt (where it is common practice for the applicable taxing authority to provide such a receipt)
or other documentation confirming such payment, and such withheld amounts shall be treated for all
purposes of this Agreement as having been paid to the receiving Party (or its applicable Affiliate).
The paying Party (or its applicable Affiliate) shall not be required to "gross up" any amounts
invoiced to the paying Party to account for, or otherwise compensate the receiving Party (or its
applicable Affiliate) for, any Taxes that are required to be withheld under applicable Law. (d)
Where a Party or any member of its Group is required by this Agreement to reimburse or indemnify the
other Party or any member of its Group for any cost or expense, the reimbursing or indemnifying
Party (or the applicable member of its Group) shall reimburse or indemnify the other Party (or the
applicable member of its Group) for the full amount of the cost or expense, inclusive of any amounts
in respect of VAT imposed on that amount to the extent properly reflected on a valid invoice, except
to the extent that the reimbursed or indemnified Party reasonably determines that it (or such member
of its Group), or a member of the same group as it (or such member of its Group) for VAT purposes,
is entitled to credit for or repayment of that VAT from any relevant taxing authority. -34-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 39 -->
(e) For purposes of this Agreement, and except as otherwise specifically provided in this Agreement,
Tax matters shall be exclusively governed by the Tax Matters Agreement, and in the event of any
inconsistency between the Tax Matters Agreement and this Agreement with respect to Tax matters, the
Tax Matters Agreement shall control. 3.7 No Duplicative Payments. Notwithstanding anything to the
contrary in this Agreement, no Party (or Affiliate thereof) shall enjoy a duplicative right,
entitlement, obligation, or recovery with respect to any matter arising out of the same facts and
circumstances. 4. Manufacturing Standards and Quality Assurance. 4.1 Quality Agreement.

On a Facility-by-Facility and Product-by-Product basis, the Parties will comply with the
requirements and provisions set forth in the Quality Agreement applicable to the applicable Facility
and Product, the form of which has been attached hereto as Attachment B and, through such
attachment, made a part hereof. In the event of a conflict between the terms of the applicable
Quality Agreement and the terms of this Agreement, the terms of the Quality Agreement shall govern
and control for all quality and regulatory compliance matters and the terms of this Agreement shall
govern and control for all other matters. 4.2 Manufacturing Standards.

Manufacturer shall manufacture and supply each Product (including disposing of all Waste and other
materials) in accordance with all applicable Specifications, applicable Laws, requirements under the
applicable Quality Agreement, and this Agreement. 4.3 Manufacturing Changes. (a) Discretionary
Changes. Subject to Section 4.3(b), in the event that either Party desires to change, revise, modify
or otherwise alter the Specifications, manufacturing processes, Product Materials, Buy-Sell
Materials, Customer-Supplied Materials, or Facilities with respect to a given Product in any manner
(each, a "Manufacturing Change"), the Party desiring the Manufacturing Change shall notify the other
Party in writing of the proposed Manufacturing Change and the Parties will promptly meet to discuss,
in good faith, the feasibility of implementing such Manufacturing Change and the allocation of costs
between the Parties for such Manufacturing Change; provided that the requested Manufacturing Change
will not be implemented unless and until the Parties mutually agree in writing to implement such
Manufacturing Change. Unless otherwise agreed upon by the Parties, the Party requesting the
Manufacturing Change will be responsible for, and will bear the costs of, any filings or other
actions that either Party must take with the applicable Governmental Authority as a result of such
Manufacturing Change. -35-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 40 -->
(b) Required Changes. If, at any time, a Manufacturing Change is required by a Governmental
Authority in a country in which Regulatory Approval for a given Product has been granted, a
Governmental Authority in a country in which Customer seeks to obtain Regulatory Approval for a
given Product, or a Governmental Authority in the country in which the Facility that manufactures a
given Product is located, then the Party that first has knowledge of the required Manufacturing
Change shall notify the other Party in writing of such required Manufacturing Change, and
Manufacturer will review such Manufacturing Change with Customer. Manufacturer will bear all costs
and expenses associated with implementing the Manufacturing Change, unless such Manufacturing Change
relates solely to a Product or Products manufactured for Customer (including any required labeling
changes), in which case Customer will bear all costs and expenses associated with implementing such
Manufacturing Change for such Product, including any changes to labeling or packaging, but only to
the extent such costs are reasonable and documented. 4.4 Pest Control.

Manufacturer shall manufacture all Products, and Manufacturer shall store all Product Materials,
Buy-Sell Materials, Customer-Supplied Materials, and all Products, in a clean, dry area, free from
insects and rodents, in a manner to prevent entry of foreign materials and contamination of Product.
Manufacturer's pest control measures shall include the adequate cleaning of the Facility, control of
food and drink, protection of Product from the environment, monitoring of flying and crawling pests
and logs detailing findings and actions taken. Manufacturer's pest control program shall be detailed
in a written procedure which complies with applicable Laws, including cGMPs, and which shall be
subject to review and approval by Customer. If Customer has specific concerns about procedures in
place at any Facility, Customer will present such issues in its audit findings and the Parties will
discuss in good faith a mutually agreeable plan for resolution of such issues. Failure of
Manufacturer to comply with this Section 4.4 shall be deemed a material breach of this Agreement.
4.5 Legal and Regulatory Filings and Requests. (a) Manufacturer shall reasonably cooperate with
Customer in responding to all requests for information from, and in making all legally required
filings with, Governmental Authorities in the Territory having jurisdiction to make such requests or
require such filings. Manufacturer shall: (a) obtain and comply with all licenses, consents and
permits required under applicable Laws in the Territory (and Manufacturer shall provide Customer
with a -36-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 41 -->
copy of all such licenses, consents and permits that are material upon Customer's reasonable
request); and (b) comply with all applicable Laws in the Territory with respect to its manufacturing
and packaging processes, the Facility or otherwise, to permit the performance of its obligations
hereunder. Upon Customer's request, Manufacturer shall apply for and obtain Certificates of
Pharmaceutical Production ("CPP") from the Governmental Authorities of the country where the
Facility is located, such CPPs to be issued to countries where CPPs according to Customer's opinion
are required. Manufacturer shall pay all reasonable costs necessary to obtain such CPPs and be
entitled to be reimbursed against invoice by Customer at cost; provided that Manufacturer shall make
good faith efforts to consolidate its invoices for such reimbursement for CPPs and submit to
Customer on a Fiscal Year quarterly basis. (b) In the event that Customer wishes to extend the
Territory with respect to a certain Product, Customer shall notify Manufacturer of such request and
Manufacturer shall consider Customer's request in good faith. For the avoidance of doubt, in the
event that the Parties agree to extend the Territory with respect to a certain Product, any
resulting Manufacturing Change shall be treated as a discretionary Manufacturing Change and governed
by Section 4.3(a). 4.6 Quality Tests and Checks.

Manufacturer shall perform all bulk holding stability, manufacturing trials, validation (including,
but not limited to, method, process and equipment cleaning validation), raw material, in-process,
bulk finished product and stability (chemical and/or microbial) tests or checks required to assure
the quality of a given Product and any tests or checks required by the Specifications, the Quality
Agreement, applicable Facility Addendum or applicable Laws. With respect to any Product manufactured
prior to Closing or located at a Facility as of Closing, Manufacturer shall maintain, continue and
complete any and all such activities, tests and checks, including, without limitation, all ongoing
stability testing. All costs associated with the performance of Manufacturer's obligations under
this Section 4.6 (including with respect to any Product manufactured prior to Closing or located at
a Facility as of Closing) are included in the Price of each Product and, accordingly, Manufacturer
shall perform the foregoing at its cost and expense, without further reimbursement from Customer.
Manufacturer shall obtain Product for these tests from batches of Product manufactured under this
Agreement, and Manufacturer is responsible for providing all necessary technical, quality and
operational resources. All tests and test results shall be performed, documented and summarized by
Manufacturer in accordance with the Specifications, Quality Agreement, applicable Facility Addendum,
applicable Laws and reasonable quality assurance requirements provided by Customer to Manufacturer
in writing. Manufacturer shall maintain all production Records and disposition of each batch of
Product. -37-

Source: UPJOHN INC, 10-12G, 1/21/2020

4.7 Responsibility for Non-Complying Product.
<!-- page 42 -->
Manufacturer shall not release any Product for Delivery to Customer that does not conform to the
covenants set forth in Section 5.2(e) (such non-conforming Product, "Non-Complying Product"),
without the prior written approval of Customer. Manufacturer shall quarantine all such Non-Complying
Products and shall promptly submit to Customer a report detailing the nature of such non-compliance
and Manufacturer's recommended disposition, including the investigation and testing done.
Manufacturer shall also provide any additional information regarding such Non-Complying Product as
may reasonably be requested by Customer. Customer shall not be required to pay for any Non-Complying
Product or for the destruction or other disposition thereof (unless an investigation determines that
the root cause for such Product being Non-Complying Product is Non-Complying Buy-Sell Materials or
Non-Complying Customer-Supplied Material). 4.8 Rejection of Non-Complying Product. (a) Customer's
Ability to Reject. Customer may reject any Non-Complying Product or Product that is not delivered to
Customer in accordance with this Agreement by providing written notice of such rejection to
Manufacturer within seventy-five (75) days following Customer's receipt of any Delivery of Product
hereunder; provided, however, that Customer may, until the expiry date for a Product, provide notice
of rejection of any Delivery of such Product having (i) latent defects, (ii) any defects that are
not reasonably discoverable by Customer through standard inspection and testing of Products or (iii)
defects caused by the breach by Manufacturer of any of its representations or warranties under this
Agreement (collectively, "Latent Defects"); provided, further, that, and notwithstanding the
foregoing, Customer shall notify Manufacturer within sixty (60) days after Customer first becomes
aware of any such Latent Defect. (b) Manufacturer's Ability to Reject. Manufacturer may reject any
Non-Complying Product by (i) providing Customer with no less than sixty (60) days' prior written
notice of Manufacturer's intention to reject such Non-Complying Product along with the documentation
set forth in Section 4.7, (ii) meeting with Customer at Customer's request to discuss the basis for
the proposed rejection of the subject Non-Complying Product, and (iii) providing Customer with
notice of rejection in the event that Manufacturer rejects the subject Non- Complying Product at the
end of such sixty (60) day period (or such other time frame as the parties may agree upon). (c)
Manufacturer's Obligation; Replacement. Manufacturer shall respond to any rejection, defect notice
or any quality-related complaint from Customer pursuant to Section 4.8(a) in a timely manner or such
other time frame as may be specified in the applicable Quality Agreement. Manufacturer shall conduct
an analysis of the causes of any such complaint, shall report to Customer on any corrective action
taken and shall reasonably consider -38-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 43 -->
Customer's suggestions related to such corrective action or other quality-related matters. Customer
shall promptly return any Product (or portions thereof) rejected pursuant to Section 4.8(a) to
Manufacturer at Manufacturer's expense. With respect to any Non- Complying Product rejected by
Customer, in addition to any other rights or remedies of Customer hereunder, Customer may elect, in
its sole discretion, upon written notice to Manufacturer to either (i) have Manufacturer replace any
Non-Complying Product as soon as practicable at no additional charge to Customer; provided that (A)
the Manufacturer shall replace such Non-Complying Product within a period of ninety (90) days
beginning on the date that the Manufacturer confirms or a Third-Party laboratory determines that the
subject Product is a Non-Complying Product, and (B) if Manufacturer fails to replace such
Non-Complying Product within such ninety (90) day period, then a Triggering Event shall be deemed to
have occurred and the provisions of Section 2.5 shall apply; or (ii) be reimbursed for the Price of
the Non-Complying Product actually paid. Manufacturer shall reimburse Customer for the cost of all
Customer-Supplied Materials used to manufacture any Non-Complying Product (unless such Product is a
Non-Complying Product due to any Non-Complying Customer-Supplied Material, as applicable). (d)
Independent Testing. If the Parties are unable to agree on whether Product rejected by Customer is
Non-Complying Product, then Manufacturer may hire an independent Third-Party laboratory, subject to
Customer's prior written approval of such laboratory, not to be unreasonably withheld, conditioned
or delayed, to perform testing on such rejected Product in accordance with the Specifications,
applicable Laws and the Quality Agreement, which Third Party laboratory shall promptly provide the
results thereof to Customer and Manufacturer. Manufacturer must engage such Third-Party laboratory
within the thirty (30) day period following Manufacturer's receipt of Customer's rejection notice.
If Manufacturer fails to engage such Third-Party laboratory during such thirty (30) day period, then
Manufacturer will be deemed to have waived its right to engage such Third-Party laboratory. The
determination of such tests shall be binding upon the Parties for all purposes hereunder; provided
that, if such tests are unable to determine whether or not such rejected Product is Non-Complying
Product, or if Manufacturer does not engage such Third-Party laboratory within the thirty (30) day
period, then such Product shall be deemed to be Non-Complying Product. If such tests determine that
the rejected Product is, or such Product is so deemed to be, Non-Complying Product, then
Manufacturer shall bear the costs of such tests and Customer's remedies with respect to
Non-Complying Product as set forth in this Agreement shall apply to such Non-Complying Product.
Otherwise, Customer shall (i) bear the costs of such tests and shall remain obligated to pay
Manufacturer the Price for such Product in accordance with Section 3 and (ii) reimburse Manufacturer
for any shipping charges paid by Manufacturer pursuant to Section 4.8(c) with respect to the return
of such -39-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 44 -->
Product to Manufacturer. Without limiting the foregoing obligations, if Customer reasonably requests
in writing, then Manufacturer shall use commercially reasonable efforts to re-deliver such Product
to Customer at Customer's expense. For the avoidance of doubt, provided that the Product conforms to
the minimum shelf-life dating set forth in Section 5.2(e)(v) upon initial Delivery, such minimum
shelf-life dating requirement shall not apply to the subject Product upon re-delivery in accordance
with the immediately preceding sentence. (e) Survival. The provisions of this Section 4.8 shall
survive termination or expiration of this Agreement or the applicable Facility Addendum. 4.9
Disposal of Rejected and Non-Complying Product.

All Non-Complying Product and Product rejected pursuant to this Agreement shall be removed (if
applicable) and disposed of by Manufacturer in accordance with all applicable Laws, and as approved
in advance by Customer in writing (such disposal cost to be at Manufacturer's expense, unless it is
subsequently determined that Customer wrongly rejected such Product pursuant to Section 4.8).
Manufacturer shall make documentation relating to such disposition available to Customer upon
Customer's reasonable request. Manufacturer shall not sell for salvage or for any other purpose any
rejected or Non-Complying Product, without the prior written approval of Customer. Manufacturer
shall destroy all Non-Complying Product prior to disposal and Manufacturer shall deface and render
unreadable all words or symbols that identify Customer, including Customer's trademarks and
logotypes that adorn any packaging containing such Product, prior to disposal of such Product. 4.10
Maintenance and Retention of Records.

Manufacturer shall maintain detailed Records with respect to Product Materials, Buy-Sell Materials,
and Customer-Supplied Materials usage and finished Product production in accordance with the Quality
Agreement. 4.11 Government Inspections, Seizures and Recalls. (a) Notification; Initiation of
Recalls. If (i) Manufacturer determines or comes to learn that a Product distributed to the market
contains a latent defect or (ii) the FDA or any other Governmental Authority conducts an inspection
at Manufacturer's Facility, seizes any Product, Buy-Sell Materials, Customer-Supplied Materials, or
Product Materials, requests a Recall of any Product, Buy-Sell Materials, Customer-Supplied
Materials, or Product Materials, or otherwise notifies Manufacturer of any violation or potential
violation of any applicable Law at the Facility, or (iii) Customer notifies Manufacturer of its
intent to initiate a Recall, then, with respect to each ((i)- (iii)), Manufacturer shall promptly
notify Customer (as applicable) and shall take such actions as may be required under the
Specifications or Quality -40-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 45 -->
Agreement. As applicable, Manufacturer shall promptly send any reports relating to such inspections,
Recalls, violations or potential violations of applicable Law to Customer; provided that
Manufacturer may reasonably redact any such reports to protect its confidential and proprietary
Information that does not relate to Products. In the event that any such Governmental Authority
requests, but does not seize, a given Product in connection with any such inspection, Manufacturer
shall, to the extent reasonably practicable and permitted by applicable Law (1) promptly notify
Customer of such request, (2) satisfy such request only after receiving Customer's approval, (3)
follow any reasonable procedures instructed by Customer in responding to such request and (4)
promptly send any samples of the applicable Product requested by the Governmental Authority to
Customer. Manufacturer shall give and permit full and unrestricted access to all or any of its
premises at any time to any authorized representative of any Governmental Authority or any of its
agents or advisers and shall cooperate fully with any such representatives, in each case, relating
to any such inspection. Manufacturer shall not initiate any Recall of Product, except as provided in
the Quality Agreement, without the prior written agreement by Customer. (b) Costs. In the event a
Recall results from any breach by Manufacturer of this Agreement, including Recalls on account of a
given Product containing a latent defect, in addition to any other rights or remedies available to
Customer under this Agreement, Manufacturer shall reimburse Customer for Customer's costs and
expenses associated with such Recall, including costs of materials supplied by Customer (including
Customer-Supplied Materials), shipping costs, administrative costs associated with arranging and
coordinating the Recall and all actual Third Party costs associated with the distribution of
replacement Product; provided that Customer shall be solely responsible for all, and shall reimburse
Manufacturer for Manufacturer's costs and expenses associated with any Recall to the extent such
Recall does not result from a breach by Manufacturer of this Agreement (e.g., is due to any Non-
Complying Customer-Supplied Material or Non-Complying Buy-Sell Material). 4.12 Inspections.

Subject to the remainder of this Section 4.12, no more than once per calendar year, upon thirty (30)
days' advance written notice to Manufacturer, Customer may physically inspect or audit (consistent
with Section 15.2) the Facilities under this Section 4.12; provided that Customer will use good
faith efforts to choose dates of inspection or audit that do not unreasonably interfere with the
operation of Manufacturer's business; provided, further, that Customer shall consider in good faith
any alternative dates of inspection or audit proposed by Manufacturer within five (5) days of
Manufacturer's receipt of such notice (it being understood that nothing in this Section 4.12 shall
require Customer to accept any such proposed alternative dates of inspection or audit).
Notwithstanding the limits set forth in the -41-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 46 -->
foregoing sentence, Customer may more frequently conduct "for cause" physical inspections or audits
of a Facility with five (5) days' advance written notice to Manufacturer if Customer has reasonable
cause to believe that an inspection or audit of such Facility is warranted because Manufacturer's
activities with respect to such Facility are in breach of this Agreement, applicable Laws, the
Quality Agreement or the applicable Facility Addendum. Any such inspection or audit shall include
access to relevant Records (subject to the terms of Section 15.2) and Personnel and being present
during, as applicable, start-up manufacturing operations, validation, cleaning, sampling, laboratory
testing, warehouse receiving and storage, pack out and shipping. Manufacturer shall provide
technical assistance and direction to Customer and its representatives at the Facility. Subject to
the terms and conditions set forth herein, Customer may conduct, at its own expense, periodic
quality audits, to ensure Manufacturer's compliance with the terms of this Agreement. Manufacturer
shall cooperate with Customer's representatives for all of these purposes, and shall promptly
correct any deficiencies noted during the audits. Any Records or information accessed or otherwise
obtained by Customer or its representatives during any such inspection or audit or any visit at any
Facility shall be deemed Manufacturer's confidential and proprietary Information and each
representative of Customer will be subject to non-use and other confidentiality obligations
substantially comparable to those set forth herein for Customer. 4.13 Segregation of Restricted
Compounds.

Unless otherwise set forth in a Facility Addendum with respect to a Product, Manufacturer shall not
manufacture a Product using facilities or equipment shared with the following classes of product
without prior consultation and agreement with Customer: (a) steroids, hormones, or otherwise highly
active or toxic products that carry a likelihood of a serious adverse effect (e.g., carcinogenicity;
anaphylaxis; reproductive and/or developmental toxicity; serious target organ toxicity) following a
potential product cross-contamination or carry-over scenario, particularly at low exposure
concentrations (i.e., with reference to an acceptable daily exposure (ADE) value or permitted daily
exposure (PDE) value < 10 µg/day); (b) immunosuppressors where the ADE or PDE value < 10 µg/day; (c)
live or infectious biological agents; (d) live or attenuated vaccines; (e) biotherapeutics where the
ADE or PDE value < 10 µg/day and sufficient deactivation cannot be demonstrated; (f) products
exclusive for animal use; (g) non-medicinal products; or (h) radiopharmaceuticals. Manufacturer
shall not manufacture any highly sensitizing products, including beta-lactam antibiotics, as well as
certain non-beta-lactam antibiotics, or otherwise highly sensitizing products that can elicit an
immediate hypersensitivity reaction (Type I hypersensitivity; immunoglobulin E-mediated) in the same
Facility as a Product. -42-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 47 -->
4.14 Packaging Material.

Unless otherwise provided in the applicable Facility Addendum, Customer shall determine and be
responsible for the text (including any logos or other graphics) for all packaging material used in
connection with Product. Manufacturer shall assure that all packaging materials are accurate and
consistent with Customer's specifications for such text or graphics, including such matters as
placement, size and colors. Manufacturer shall promptly notify Customer of any errors or
deficiencies in such provided packaging materials. 5. Covenants. 5.1 Mutual Covenants. Each Party
hereby covenants to the other Party that it will perform its activities under this Agreement in full
compliance with all applicable Global Trade Control Laws, including as follows: (a) unless a license
or other authorization is first obtained, the issuance of which is not guaranteed, neither Party
will knowingly transfer to the other Party any goods, software, technology or services that are (1)
controlled at a level other than EAR99 under the U.S. Export Administration Regulations; (2)
controlled under the U.S. International Traffic in Arms Regulations; (3) specifically identified as
an E.U. Dual Use Item; or (4) on an applicable export control list of a foreign country; (b) prior
to engaging in any activities in a Restricted Market, involving individuals ordinarily resident in a
Restricted Market or including companies, organizations, or Governmental Authorities from or located
in a Restricted Market in each case in connection with this Agreement, each Party must first notify
the other Party (which notice, notwithstanding Section 17, shall be addressed to (a) Pluto at
gtc@pfizer.com and (b) Spinco at [●]), who will review and, if compliant with Global Trade Control
Laws, approve (subject to any appropriate conditions) such activities (such approval not to be
unreasonably withheld or delayed), within five (5) Business Days of such notification; provided that
(1) to the extent relating to U.S. sanctions or export controls, such notification and approval
shall not be required if the activity contemplated would be permissible for U.S. persons subject to
U.S. sanctions (including without limitation under a U.S. Department of the Treasury Office of
Foreign Assets Control general license), and (2) once notification is made and approval is granted
with respect to a specific counterparty in a Restricted Market, further notification and approval
will not be required for future transactions or activities with the same counterparty (unless there
is a change in circumstances, processes or intermediate parties, including, but not limited to,
carriers, or otherwise a change to Global Trade Control Laws relevant to that Restricted Market or
counterparty); provided that, notwithstanding the foregoing, neither Party shall undertake any of
the activities described in this clause (2) without the prior written approval of the other Party;
and -43-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 48 -->
(c) notwithstanding anything set forth in Section 4.14 to the contrary, for the purposes of any and
all packaging and shipping of any goods, software, technology or services pursuant to the activities
contemplated under this Agreement, Manufacturer will determine: (i) a classification under relevant
import and export laws; (ii) the country of origin; and (iii) a value for customs;

provided, however, that the Party acting as the importer of record (IOR) or exporter of record (EOR)
shall have the right to request a review of any determination contemplated by clause (i), (ii) or
(iii) above; provided, further, that if the IOR or EOR (as applicable) disagrees with such
determination, then such Party shall maintain the right to refuse to export or import the applicable
goods, software, technology or services. 5.2 Manufacturer Covenants. Manufacturer hereby covenants
to Customer that: (a) The Facility and all equipment, tooling and molds utilized in the manufacture
and supply of Product hereunder by or on behalf of Manufacturer shall, during the Term of this
Agreement, be maintained in good operating condition and shall be maintained and operated in
accordance with all applicable Laws. The manufacturing and storage operations, procedures and
processes utilized in manufacture and supply of Product hereunder (including the Facility) shall be
in full compliance with all applicable Laws, including cGMP and health and safety laws. (b)
Manufacturer shall perform all of its obligations under this Agreement in compliance with the
applicable Laws in the Territory. Manufacturer is in compliance and shall continue to comply, and
shall cause its Personnel to comply, with all applicable Laws, including Laws requiring
Serialization; provided that, with respect to compliance with Laws requiring Serialization, Customer
shall reimburse Manufacturer for all investments made or costs incurred by Manufacturer in
connection with any Serialization requirements specific to a given Product or Products (which, for
clarity, shall not include Serialization requirements applicable to both Products and other products
produced by Manufacturer in the Facility), but only to the extent such costs are reasonable and
documented and are directed specifically with respect to a Product or Products. Manufacturer has and
shall continue to have, and shall cause its Personnel to have, all professional licenses, consents,
authorizations, permits, and certificates, and shall have and shall cause its Personnel to have
completed all registrations and made such notifications as required by applicable Law for its
performance of the services under this Agreement. (c) Manufacturer shall hold during the Term of
this Agreement all licenses, permits and similar authorizations required by any Governmental
Authority in the Territory for Manufacturer to perform its obligations under this Agreement. -44-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 49 -->
(d) Manufacturer shall have good title to all Product supplied to Customer pursuant to this
Agreement and shall pass such title to Customer (or its designee) free and clear of any security
interests, liens, or other encumbrances. (e) Products furnished by Manufacturer to Customer under
this Agreement: (i) shall be manufactured, packaged, labeled, handled, stored and Delivered in
accordance with, shall be of the quality specified in, and shall conform upon Delivery to Customer
(or its designee) to, the Specifications; (ii) shall be manufactured, packaged, labeled, handled,
stored and Delivered in compliance with all applicable Laws including, without limitation, cGMPs,
and in accordance with the Quality Agreement, this Agreement and the applicable Facility Addendum;
(iii) shall not contain any Product Material that has not been used, handled or stored by or on
behalf of Manufacturer in accordance with the Specifications, all applicable Laws, the Quality
Agreement, this Agreement and the applicable Facility Addendum; (iv) shall not be adulterated or
misbranded within the meaning of Sections 501 and 502, respectively, of the Act or any other
applicable Law; and (v) shall, at the time Delivered, have at least a remaining shelf-life as
specified in the applicable Facility Addendum.

Notwithstanding the foregoing clauses (i) through (v) of this Section 5.2(e) or anything else
contained in this Agreement or any Facility Addendum or Quality Agreement, Manufacturer shall have
no liability under this Agreement (including under Section 4.11(b) or Section 10.1) or any Facility
Addendum or Quality Agreement for any Non-Complying Product which is non-complying due to any
Non-Complying Customer-Supplied Materials or Non-Complying Buy-Sell Materials. (f) Manufacturer has
not and will not directly or indirectly offer or pay, or authorize such offer or payment, of any
money or anything of value or improperly or corruptly seek to influence any Government Official or
any other Person in order to gain an improper business advantage, and, has not accepted, and will
not accept in the future, such a payment. Manufacturer will comply with the Anti-Bribery and
Anti-Corruption Principles set forth in Attachment D. (g) Manufacturer shall ensure that it and its
Personnel comply with the standard policies, regulations and directives listed on Attachment E and
incorporated herein. -45-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 50 -->
5.3 Manufacturer's Social Responsibility. (a) Manufacturer covenants that it shall not, during the
Term of this Agreement (i) use involuntary or underage labor (defined in accordance with applicable
Laws) at the Facilities where its performance under this Agreement will occur or (ii) maintain
unsafe or unhealthy conditions in any dormitories or lodging that it provides for its employees.
Manufacturer agrees that during the Term of this Agreement, it shall promptly correct unsafe or
unhealthy conditions in any dormitories or lodging that it provides for its employees. (b)
Manufacturer covenants that it will perform its obligations under this Agreement in a manner
consistent with all of the Pharmaceutical Industry Principles for Responsible Supply Chain
Management, as codified as of the Effective Date at http://www.pharmaceuticalsupplychain.org. (c)
Manufacturer shall not use, and shall not allow to be used, any (i) cassiterite,
columbite-tantalite, gold, wolframite, or the derivatives tantalum, tin or tungsten that originated
in the Democratic Republic of Congo or an adjoining country or (ii) any other mineral or its
derivatives determined by the Secretary of State to be financing conflict pursuant to Section 13(p)
of the Securities Exchange Act of 1934 ((i)-(ii) collectively, "Conflict Minerals"), in the
production of any Product. Notwithstanding the foregoing, if Manufacturer uses, or determines that
it has used, a Conflict Mineral in the production of any Product, Manufacturer shall immediately
notify Customer, which notice shall contain a written description of the use of the Conflict
Mineral, including, without limitation, whether the Conflict Mineral appears in any amount in the
applicable Product (including trace amounts) and a valid and verifiable certificate of origin of the
Conflict Mineral used. Manufacturer must be able to demonstrate that it undertook a reasonable
country of origin inquiry and due diligence process in connection with its preparation and delivery
of the certificate of origin. (d) Manufacturer will provide Customer with periodic access, upon
reasonable notice, to any of its Facilities where it is performing under this Agreement, to its
employees and Records and to any associated dormitories or lodging that Manufacturer provides to its
employees, to permit Customer to determine Manufacturer's compliance with this Section 5.3. Customer
may exercise its inspection rights under this Section 5.3(d) upon receipt of any information that
would suggest to a reasonable Person that Manufacturer is not fulfilling its obligations under this
Section 5.3. 5.4 Notice of Material Events.

Manufacturer will promptly notify Customer of any actual or anticipated events of which Manufacturer
is aware that have or would be reasonably expected to have a material effect on any Product or on
its ability to manufacture or supply any Product in accordance with the provisions set forth herein,
including any labor difficulties, strikes, shortages in materials, plant closings, interruptions in
activity and the like. -46-

Source: UPJOHN INC, 10-12G, 1/21/2020

5.5 Disclaimer of Warranties.
<!-- page 51 -->
EXCEPT AS EXPRESSLY PROVIDED IN THIS AGREEMENT, NEITHER PARTY MAKES NOR RECEIVES ANY WARRANTY OF ANY
KIND, EXPRESS, IMPLIED, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES OF MERCHANTABILITY, SUITABILITY
OR FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT OF ANY FIRMWARE, SOFTWARE OR
HARDWARE PROVIDED OR USED HEREUNDER, AND ANY REPRESENTATIONS OR WARRANTIES ARISING FROM COURSE OF
DEALING, COURSE OF PERFORMANCE OR TRADE USAGE, AND ALL SUCH REPRESENTATIONS AND WARRANTIES ARE
HEREBY EXPRESSLY DISCLAIMED. 6. Environmental Covenants. 6.1 Compliance with Environmental Laws. (a)
Manufacturer shall perform all of its obligations herein in compliance with all Environmental Laws
and all licenses, registrations, notifications, certificates, approvals, authorizations or permits
required under Environmental Laws. (b) Manufacturer shall be solely responsible for all
Environmental Liabilities arising from its performance of this Agreement. 6.2 Permits, Licenses and
Authorization. (a) Manufacturer shall be solely responsible for obtaining, and shall obtain in a
timely manner, and maintain in good standing, all licenses, registrations, notifications,
certificates, approvals, authorizations or permits required under Environmental Laws, whether de
novo documents or modifications to existing documents, which are necessary to perform the services
hereunder, and shall bear all costs and expenses associated therewith. (b) Manufacturer shall
provide copies of all material items referenced in Section 6.2(a) to Customer upon request by
Customer and shall operate in compliance therewith. (c) Manufacturer shall provide Customer with
reasonably prompt verbal notice, confirmed in writing within twenty-four (24) hours, in the event of
any major incident, which shall include any event, occurrence, or circumstance, including any
governmental or private action, which materially impacts or could materially impact Manufacturer's
ability to fulfill its obligations under this Agreement. These include, but are not limited to: (i)
material revocation or modification of any of the documents described in Section 6.2(a), -47-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 52 -->
(ii) any action by Governmental Authorities that may reasonably lead to the material revocation or
modification of Manufacturer's required permits, licenses, or authorizations, as listed above, (iii)
any Third Party Claim against the management or ownership of the Facility that could reasonably
materially impact Manufacturer's obligations under this Agreement, (iv) any fire, explosion,
significant accident, or catastrophic Release of Hazardous Materials, or significant "near miss"
incident, (v) any significant non-compliance with Environmental Laws and (vi) any environmental
condition or operating practice that may reasonably be believed to present a significant threat to
human health, safety or the environment. (d) Notwithstanding the requirements noted above, each
Party, whether Customer or Manufacturer, is required to create and maintain: (i) required licenses,
permits and agreements, including those necessary to affect imports, exports, and activities covered
by economic sanctions regulations, including annual agreements for activities involving Restricted
Markets; (ii) policies, procedures, controls, and systems to support compliance with Global Trade
Control Laws; and (iii) agreements with Customs Brokers, freight forwarders, financial institutions,
and other third parties, as necessary. 6.3 Generation of Hazardous Wastes.

Without limiting other legally applicable requirements, Manufacturer shall prepare, execute and
maintain, as the generator of Waste, all registrations, notices, shipping documents and manifests
required under applicable Environmental Laws and in accordance therewith. Manufacturer shall utilize
only reputable and lawful Waste transportation and disposal vendors, and shall not knowingly utilize
any such vendor whose operations endanger human health or the environment. 6.4 Environmental
Sustainability Information.

Manufacturer will disclose to Customer, on an annual basis, its results with respect to any efforts
to reduce greenhouse gas emissions, water consumption or the generation of waste associated with the
performance of this Agreement, to the extent Manufacturer otherwise prepares such results. 6.5
Environmental and Health and Safety Reviews. (a) Manufacturer covenants that it will, to the
Manufacturer's knowledge, completely and accurately disclose to Customer all material environmental
and health and safety information regarding its Products (including an obligation to supplement this
information, as necessary) during the Term of this Agreement, as reasonably requested by Customer.
-48-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 53 -->
(b) Manufacturer shall permit Customer (at Customer's expense) to conduct reasonable annual reviews
of the environmental and health and safety practices and performance of the Facilities with respect
to the Products where Manufacturer's performance under this Agreement is occurring; provided that
such review shall not include any invasive sampling at such Facilities and shall not unreasonably
interfere with Manufacturer's operation of such Facilities. In connection with such reviews,
Manufacturer shall reasonably assist in the completion of an environmental health and safety survey
of Manufacturer or the scheduling of an environmental health and safety audit of the Facility, as
applicable, in each case with respect to the Products. Customer shall share its findings (including
any deficiencies) with Manufacturer as soon as practicable, Manufacturer shall have the sole right
to report any such deficiencies to third parties and Manufacturer shall use commercially reasonable
efforts to correct, at no expense to Customer, such deficiencies in its environmental and health and
safety management practices with respect to the Products that are not in compliance with applicable
Law or create significant risk to human health or the environment. Manufacturer acknowledges that
such reviews conducted by Customer are for the benefit of Customer only; they are not a substitute
for Manufacturer's own environmental and health and safety management obligations under this
Agreement and accordingly, Manufacturer may not rely upon them. 7. Term; Termination. 7.1 Term of
Agreement.

Unless otherwise provided in the applicable Facility Addendum, this Agreement (a) shall commence on
the Effective Date and shall continue for a period of four (4) years from such date (the "Initial
Term" of this Agreement), unless sooner terminated pursuant to Section 7.3, 7.4, 7.5, 7.6 or 7.7,
and (b) may be extended for up to three (3) additional periods of twelve (12) months (each, an
"Extension Period") by written notice given by Customer to Manufacturer not less than twelve (12)
months prior to the expiration of the Initial Term or the applicable Extension Period, as the case
may be. The Initial Term and all Extension Periods shall be referred to collectively as the "Term"
of this Agreement. For the avoidance of doubt, the Term of this Agreement shall continue until all
Facility Addenda hereunder expire or otherwise terminate, unless this Agreement or such Facility
Addenda are sooner terminated pursuant to Section 7.3, 7.4, 7.5, 7.6 or 7.7. -49-

Source: UPJOHN INC, 10-12G, 1/21/2020

7.2 Term of Facility Addendum.
<!-- page 54 -->
Unless otherwise provided in the applicable Facility Addendum, each Facility Addendum shall commence
on the Effective Date and shall continue for a period of four (4) years from such date (the "Initial
Term" of the Facility Addendum), unless extended or terminated pursuant to Section 7.3, 7.4, 7.5,
7.6 or 7.7. A Facility Addendum may be extended for up to three (3) additional periods of twelve
(12) months (each, an "Extension Period") by written notice given by Customer to Manufacturer not
less than twelve (12) months prior to the expiration of the Initial Term or the applicable Extension
Period, as the case may be. The Initial Term and all Extension Periods shall be referred to
collectively as the "Term" of the Facility Addendum. 7.3 Termination for Cause. (a) Either Party may
terminate this Agreement and the applicable Facility Addendum, on a Product-by-Product basis, with
respect to a particular Product, upon written notice to the other Party in the event of a material
breach by the other Party of any term of this Agreement or Facility Addendum with respect to such
Product, which breach remains uncured for ninety (90) calendar days following written notice to such
breaching Party of such material breach. (b) Either Party may terminate this Agreement and the
applicable Facility Addendum, on a Facility Addendum-by-Facility Addendum basis, with respect to a
particular Facility, upon written notice to the other Party in the event of a material breach by the
other Party of any term of this Agreement or Facility Addendum with respect to such Facility, which
breach remains uncured for ninety (90) calendar days following written notice to such breaching
Party of such material breach. (c) For clarity, in the event that multiple Products are manufactured
by or on behalf of Manufacturer under this Agreement in the same Facility, a material breach by
Manufacturer of this Agreement or Facility Addendum that is an act or omission specific to one or
more Products in a Facility, but not all Products in such Facility, shall give rise to an ability of
Customer to terminate this Agreement solely with respect to the affected Product(s) under Section
7.3(a) but shall not give rise to an ability of Customer to terminate the relevant Facility Addendum
under Section 7.3(b). 7.4 Termination for Disposition of Facility.

In the event that Manufacturer or any of its Affiliates, directly or indirectly, sells, assigns,
leases, conveys, transfers or otherwise disposes of any Facility (a "Facility Disposition"), then
Manufacturer shall immediately notify Customer of such event and Customer shall be entitled for a
period of six (6) months after the receipt of such notice to terminate any Facility Addendum with
respect to such Facility for cause immediately upon written notice to Manufacturer and, in the event
Customer decides not to terminate the Facility Addendum for cause, Customer shall be entitled for a
period of two (2) years (or such longer period in order to obtain approval for manufacture from all
applicable Governmental Authorities) after -50-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 55 -->
receipt of such notice to receive Technical Support at Manufacturer's sole cost to enable Customer
to orderly transfer production of affected Product or Products to a Customer facility or an
alternative facility as designated by Customer; provided that Manufacturer shall notify Customer of
any proposed or planned Facility Disposition by Manufacturer or any of its Affiliates as soon as
reasonably practicable and in any event no later than the date that is three (3) months prior to the
effective date of such Facility Disposition. 7.5 Termination in Event of Insolvency.

In the event that a Party hereto (a) becomes insolvent, or institutes or has instituted against it a
petition for bankruptcy or is adjudicated bankrupt, (b) executes a bill of sale, deed of trust, or a
general assignment for the benefit of creditors, (c) is dissolved or liquidated or (d) has a
receiver appointed for the benefit of its creditors, or has a receiver appointed on account of
insolvency (in the case of clauses (a)-(d), such Party shall be referred to as the "Insolvent
Party"), then the Insolvent Party shall immediately notify the other Party of such event and such
other Party shall be entitled to (i) terminate this Agreement or any and all Facility Addenda for
cause immediately upon written notice to the Insolvent Party or (ii) request that the Insolvent
Party or its successor provide adequate assurances of continued and future performance in form and
substance acceptable to such other Party, which shall be provided by the Insolvent Party within ten
(10) calendar days of such request, and the other Party may terminate this Agreement and any or all
Facility Addenda for cause immediately upon written notice to the Insolvent Party in the event that
the Insolvent Party fails to provide such assurances acceptable to the other Party within such ten
(10) day period. 7.6 Termination for Breach of Anti-Bribery Representation.

Customer may terminate this Agreement and any and all Facility Addenda effective immediately upon
notice to Manufacturer, if Manufacturer (a) breaches any of the representations and warranties set
forth in Section 5.2(f) or (b) Customer learns (i) that improper payments are being or have been
made or offered to any Government Official or any other Person by Manufacturer or those acting on
behalf of Manufacturer with respect to any obligations performed hereunder or (ii) that Manufacturer
or those acting on behalf of Manufacturer with respect to the performance of any obligations
hereunder has accepted any payment, item, or benefit, regardless of value, as an improper inducement
to award, obtain or retain business or otherwise gain or grant an improper business advantage from
or to any other Person or entity. Further, in the event of such termination, Manufacturer shall not
be entitled to any further payment, regardless of any activities undertaken or agreements with
additional Third Parties entered into by Manufacturer prior to such termination, and Manufacturer
shall be liable for damages or remedies as provided by this Agreement, at Law or in equity. -51-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 56 -->
7.7 Termination for Convenience by Customer. (a) This Agreement and/or any or all Facility Addendum
(unless otherwise specified in the applicable Facility Addendum) may be terminated on a
Product-by-Product basis by Customer immediately upon written notice to Manufacturer, if Customer
cannot continue to distribute, use, market or sell such Product supplied under this Agreement or the
relevant Facility Addendum without violating any then-current Laws. (b) This Agreement and/or any or
all Facility Addenda shall be deemed to be terminated by Customer on a Product-by-Product basis
without any further action of either Customer or Manufacturer in the event that Customer fails to
order a Product during any rolling eighteen (18) month period; provided that this subsection (b)
shall not apply with respect to API as Product. 7.8 Effect of Termination or Expiration. (a) The
termination or expiration of this Agreement (whether in its entirety or with respect to any Product
or Facility) or any Facility Addendum for any reason shall not release any Party hereto of any
liability which at the time of termination or expiration had already accrued to the other Party in
respect to any act or omission prior thereto. (b) Upon termination of this Agreement by Customer in
whole or in part or upon the termination of any Facility Addendum, in each case, pursuant to Section
7.3, 7.4, 7.5 or 7.6, and on a terminated-Product-by-terminated-Product basis, at Customer's option
and pursuant to Customer's instructions, Manufacturer shall provide Customer with sufficient
inventory of such terminated Product to ensure business continuity according to then-current terms
and pricing (subject to Section 3) until the earlier of: (i) Customer's identification of, and
securing of Regulatory Approval for, another supplier of such terminated Product or (ii) unless
otherwise set forth in the applicable Facility Addendum as the "Inventory Tail Period" for such
Product, a time period that reflects Customer's reasonable needs of such Product as mutually agreed
upon by the Parties in good faith. Manufacturer shall take such further action, at Manufacturer's
expense, that Customer may reasonably request to minimize delay and expense arising from termination
or expiration of this Agreement. For the avoidance of doubt, Manufacturer's obligation to supply
Product pursuant to this Section 7.8(b) shall be subject to and governed by the terms of this
Agreement, including terms pertaining to Forecasts and Purchase Orders and payment terms. (c) Upon
Customer's request at any time during the Term, Manufacturer shall promptly notify Customer of any
material contracts, licenses, permits, and other material documents, in each case, that are specific
to, and are used solely in connection with, a Product or Facility Addendum and provide copies or
access thereto subject to any restrictions on the provision of copies -52-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 57 -->
or access. Upon termination or expiration of this Agreement in whole or in part or any Facility
Addendum, if requested by Customer within ninety (90) days immediately following the effective date
of such expiration or termination of this Agreement and pursuant to Customer's reasonable request
and instructions, Manufacturer shall use commercially reasonable efforts to, as applicable, make
assignments or partial assignments of such material contracts, licenses, permits, and other material
documents, as applicable, in each case subject to any restrictions on assignment, or as may
otherwise be set forth in any Contract relating thereto. Customer shall reimburse Manufacturer for
all out-of-pocket costs reasonably incurred by Manufacturer in activities conducted pursuant to this
Section 7.8(c), unless this Agreement has been terminated by Customer pursuant to Section 7.3, 7.4,
7.5 or 7.6, in which case Manufacturer shall bear all such reasonable expenses. (d) The termination
or expiration of this Agreement shall not affect the survival and continuing validity of Section
2.10 (Transitional Support) (with respect to Manufacturer's obligations and to the extent Technical
Support has been requested prior to, or within ninety (90) days following, the effective date of
termination or expiration), Section 3.5 (Invoices and Payment), Sections 4.1, 4.5, 4.6, 4.8, 4.10,
4.11, 4.12 and 4.13 (Manufacturing Standards and Quality Assurance), Section 5 (Covenants), Section
6 (Environmental Covenants), Section 7.8 (Effect of Termination or Expiration), Section 7.9 (Unused
Materials), Section 7.10 (Return of Materials, Tools and Equipment), Section 8 (Intellectual
Property), Section 10 (Indemnification; Limitations of Liability), Section 11 (Insurance), Section
13 (Confidentiality), Section 15 (Records and Audits), Section 16 (Notices), Section 17
(Miscellaneous), or of any other provision which is expressly intended to continue in force after
such termination or expiration. 7.9 Unused Materials.

In the event of the expiration of this Agreement or termination of this Agreement in whole or in
part (including the termination of any Facility Addendum) by Customer in accordance with Section
7.3, 7.4, 7.5 or 7.6, Customer may, at its option within ninety (90) days immediately following the
effective date of the expiration or termination of this Agreement, purchase any work in process
and/or Product Materials that Manufacturer has purchased exclusively for Customer in accordance with
this Agreement for the production of any terminated Product. Customer shall pay Manufacturer's
direct cost for works in process, and Manufacturer's purchase price from its suppliers for Product
Materials. In the event of the termination of this Agreement by Customer in accordance with Section
7.7 or the termination of this Agreement by Manufacturer in accordance with Section 7.3, 7.4, 7.5 or
7.6, Customer shall purchase at cost all Product Materials purchased in accordance with Customer's
Purchase Orders and on reasonable reliance upon Customer's Forecast; provided that Manufacturer uses
its reasonable commercial efforts to exhaust existing stocks of such Product Materials prior to the
date of -53-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 58 -->
termination. In the event of the termination or expiration of this Agreement for any other reason,
Customer shall have no obligation to purchase any Product Materials. Any Product Materials that are
not purchased or required to be purchased by Customer pursuant to this Section 7.9 shall be disposed
of or destroyed in accordance with Customer's instructions, which costs shall be borne by
Manufacturer. 7.10 Return of Materials, Tools and Equipment. (a) Upon termination or expiration of
this Agreement in whole or in part or, with respect to any Product, Facility or any Facility
Addendum for any reason whatsoever, at Customer's request, Manufacturer shall, as promptly as
practicable given relevant circumstances, deliver to Customer in accordance with Customer's
reasonable instructions all Specifications (and copies thereof), artwork, labels, bottles, all
premiums and packaging materials purchased by Customer and all Product Materials, Buy-Sell
Materials, Customer-Supplied Materials, and equipment, molds, tablet press tooling or proprietary
materials in Manufacturer's possession and control that during the Term had, pursuant to this
Agreement or a Facility Addendum, either (i) been provided by Customer to Manufacturer, or (ii)
purchased by Manufacturer (and reimbursed by Customer), in each case, that are used and held for use
exclusively for the manufacture for Customer of Product or Products impacted by such termination or
expiration; provided that Manufacturer shall not be so required to deliver any materials, tools or
equipment that are fixtures or fittings or any items the removal of which from the Facility using
good faith diligent efforts would be reasonably likely to disrupt in any material respect, or cause
damage to, the Facility or its operations or any materials, tools or equipment owned, leased or
otherwise controlled by Manufacturer or any of its Affiliates or any material expense. At Customer's
request, Manufacturer shall, as promptly as reasonably practicable given relevant circumstances and
in accordance with Customer's reasonable instructions, remove all such equipment, molds and tablet
press tooling from the Facility and make such equipment, molds and tooling available for pickup at
the Facility by a carrier designated by Customer. All delivery, removal and transportation costs
reasonably incurred in connection with this Section 7.10(a) shall be borne by Customer, except in
the event Customer terminates this Agreement pursuant to Section 7.3, 7.4, 7.5 or 7.6, in which case
all such reasonable costs shall be borne by Manufacturer. (b) Any Product quarantined at the time of
expiration or termination of this Agreement shall be disposed of or destroyed by Manufacturer in
accordance with Customer's instructions and at Customer's cost; provided that, to the extent (i)
such quarantine is the result of Manufacturer's gross negligence, fraud, willful misconduct or
breach of this Agreement or (ii) this Agreement is terminated in whole or in part with respect to
such Product (including the termination of the applicable Facility Addendum) by Customer in
accordance with Section 7.3, 7.4, 7.5 or 7.6, then Manufacturer shall be responsible for all costs
incurred by Manufacturer in connection with disposing and destroying such quarantined Product. -54-

Source: UPJOHN INC, 10-12G, 1/21/2020

8. Intellectual Property. 8.1 Customer's Intellectual Property.
<!-- page 59 -->
Customer hereby grants to Manufacturer a non-exclusive license during the Term to use any Customer
Property and Customer-Owned Improvements and Developments solely in connection with Manufacturer
performing its obligations under this Agreement or the Facility Addendum in accordance with the
terms hereof or thereof, as applicable. Manufacturer shall not acquire any other right, title or
interest in or to the Customer Property or Customer-Owned Improvements and Developments as a result
of its performance hereunder, and any and all goodwill arising from Manufacturer's use of any
Customer Property or Customer-Owned Improvements and Developments shall inure to the sole and
exclusive benefit of Customer. 8.2 Improvements and Developments. (a) Each Party acknowledges and
agrees that improvements or modifications to Customer Property may be made by or on behalf of
Manufacturer ("Improvements"), and creative ideas, proprietary information, developments, or
inventions may be developed under or in connection with this Agreement by or on behalf of
Manufacturer ("Developments"), in each case either alone or in concert with Customer or Third
Parties. (b) Manufacturer acknowledges and agrees that, as between the Parties, any Improvements or
Developments that are specific to and otherwise solely relate to, the manufacturing, processing or
packaging of Products (such Improvements and Developments, collectively, "Customer-Owned
Improvements and Developments") shall be the exclusive property of Customer, and Customer shall own
all rights, title and interest in and to such Customer-Owned Improvements and Developments.
Manufacturer agrees to and hereby does irrevocably transfer, assign and convey, and shall cause its
Personnel to irrevocably transfer, assign and convey, all rights, title and interest in and to each
of the Customer-Owned Improvements and Developments to Customer free and clear of any encumbrances,
and Manufacturer agrees to execute, and shall cause its subcontractors and Personnel to execute, all
documents necessary to do so. All such assignments shall include existing or prospective
Intellectual Property rights therein in any country. -55-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 60 -->
(c) Customer acknowledges and agrees that, as between the Parties, all Improvements and Developments
made by or on behalf of Manufacturer in the conduct of activities under this Agreement or a Facility
Addendum other than Customer-Owned Improvements and Developments (such Improvements and
Developments, collectively, "Manufacturer-Owned Improvements and Developments") shall be the
exclusive property of Manufacturer, and Manufacturer shall own all rights, title and interest in and
to such Manufacturer- Owned Improvements and Developments. Customer agrees to and hereby does
irrevocably transfer, assign and convey, and shall cause its Personnel to irrevocably transfer,
assign and convey, all rights, title and interest in and to each of the Manufacturer-Owned
Improvements and Developments to Manufacturer free and clear of any encumbrances, and Customer
agrees to execute, and shall cause its Personnel and subcontractors to execute, all documents
necessary to do so. All such assignments shall include existing or prospective Intellectual Property
rights therein in any country. 8.3 Ownership of Other Property.

Unless otherwise agreed by the Parties or specified in the Separation Agreement, Customer is the
sole owner of any and all tools, specifications, blueprints and designs directly owned and supplied
or paid for by Customer (i.e., not any materials that are included in the Price of Product), and
Manufacturer shall not use, transfer, loan or publicize any of the above, except as necessary for
its performance under this Agreement. 8.4 Limited Right to Use.

Subject to the provisions of Section 8.1, nothing set forth in this Agreement shall be construed to
grant to Manufacturer any title, right or interest in or to any Intellectual Property controlled by
Customer or any of its Affiliates. Use by Manufacturer of any such Intellectual Property shall be
limited exclusively to its performance of this Agreement. 9. Joint Advisory Committee. 9.1 Formation
and Role.

The Parties shall, as soon as practicable but not later than within ninety (90) days after the
Effective Date, form a joint advisory committee (the "Joint Advisory Committee" or "JAC"). The JAC
will provide a forum for the good faith discussion of major matters related to this Agreement,
including in particular (but not limited to) matters of commercial performance, supply, overall
performance, capital investment and business planning (strategy and management), and the transition
to Customer-Supplied Materials arrangements contemplated by Section 12.1(f), but also any other
items, matters or activities, including with respect to any Facility. -56-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 61 -->
9.2 Membership; Chairs. (a) Membership. The JAC shall consist of up to five (5) representatives
appointed by each Party in writing, or such other number of representatives as the Parties may agree
in writing from time to time (each, a "JAC Member"). Either Party may invite any person that is not
a JAC Member (including consultants and advisors of a Party) to participate in meetings of the JAC,
without a right to participate in the discussions of the JAC, so long as (i) such person is under an
appropriate obligation of confidentiality, (ii) the inviting Party provided at least three (3)
Business Days' prior notice to the other Party identifying such person and (iii) the non- inviting
Party does not reasonably object to such person participating in the discussions of the JAC prior to
such meeting. (b) JAC Chairs. The JAC shall be co-chaired by one JAC Member of each Party (each, a
"JAC Chair"), to be elected by the respective Party when naming its JAC Members. The JAC Chairs
shall cooperate in good faith to: (i) notify the JAC Members of each Party of each JAC Meeting,
which notice shall be provided at least thirty (30) calendar days in advance of such meeting (to the
extent practicable) with respect to the ordinary quarterly JAC Meetings; (ii) collect and organize
agenda items for each JAC Meeting, and circulate such agenda to all JAC Members at least two (2)
Business Days prior to each meeting date; provided, however, that any JAC Member shall be free to
propose additional topics to be included on such agenda, either prior to or in the course of any JAC
Meeting; (iii) preside at JAC Meetings; and (iv) prepare the written minutes of each JAC Meeting and
circulate such minutes for review and approval by the JAC Members of each Party, and identify action
items to be carried out. 9.3 Meetings. (a) Ordinary JAC Meetings. During the Term of this Agreement,
the JAC shall meet on a quarterly basis or as otherwise determined in writing by the Parties, and
such meetings may be conducted in person, by videoconference or by telephone conference (each such
meeting, a "JAC Meeting"). In-person meetings of the JAC will alternate between appropriate venues
of each Party, as reasonably determined by the Parties. The Parties shall each bear all expenses of
their respective representatives relating to their participation on the JAC. The members of the JAC
also may convene or be polled or consulted from time to time by means of telecommunications, video
or telephone conferences, electronic mail or correspondence, as deemed necessary or appropriate. (b)
Additional JAC Meetings. Either Party may call an additional meeting of the JAC at any time upon
twenty (20) Business Days' prior written notice if such Party reasonably determines that there is a
need for discussions at the level of a JAC Meeting on top of the ordinary quarterly JAC Meetings,
and reasonably specifies such grounds in its notice to the other Party. -57-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 62 -->
(c) Provision of Information. Upon the request of the JAC Chairs or at least four (4) members of the
JAC, each Party will provide written materials and information relating to matters within the
purview of the JAC in advance of a JAC Meeting. In addition, the JAC shall be informed by each Party
in good faith about any matters or issues within the purview of the JAC which a Party should
reasonably deem to be of high importance for the other Party. 9.4 Areas of Responsibility.

Subject to the terms of this Agreement, the JAC shall act as a forum to discuss in good faith in
particular the following major items, matters and areas of interest: (a) Oversee, review and
coordinate the activities of the Parties under this Agreement; (b) Each Facility's overall
performance under this Agreement; and (c) Any other major matters, roles, obligations and
responsibilities under this Agreement, to the extent any Party reasonably provides such matter to
the JAC for discussion. 9.5 Advisory Role; No Decision-Making Authority. (a) Advisory Role. The JAC
and its members shall only have an advisory role and shall discuss in good faith and provide to the
Parties its opinion on the matters in its purview. The Parties agree to reasonably take into account
the opinions and views expressed by the JAC and its members for performing their respective
obligations under this Agreement. (b) No Decision-Making Authority. The JAC shall have no
decision-making authority over the matters in its purview unless the Parties mutually decide in
writing to delegate the decision-making authority on such specific item or matter to the JAC.
Moreover, it shall not be within the authority of the JAC to (i) directly impose on either Party or
its Affiliates any additional obligation(s) or a resolution on the Parties with respect to any
dispute regarding the existence or extent/amount of any obligation, including payments obligations,
under this Agreement, or to (ii) amend, modify or waive compliance with this Agreement. 10.
Indemnification; Limitations of Liability. 10.1 Indemnification of Customer. (a) Subject to the
provisions of this Section 10 and, for clarity, without limiting anything in the Separation
Agreement or any other Ancillary Agreements, Manufacturer shall indemnify, defend and hold harmless
Customer, its Affiliates and its and their respective directors, officers, managers, members,
employees and agents, and each of the heirs, executors, successors and assigns of any of the
foregoing (each, a "Customer Indemnified Party") from and against any and all Losses of such
Customer -58-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 63 -->
Indemnified Parties to the extent relating to, arising out of or resulting from any Action of a
Third Party arising out of or resulting from any of the following items (without duplication): (i)
any breach by Manufacturer or its Personnel of this Agreement or any Facility Addendum; (ii) any
injury or death of any Person due to any breach by Manufacturer or its Personnel of this Agreement
or any Facility Addendum; (iii) the infringement or misappropriation of a Third Party's Intellectual
Property by the use or practice by Manufacturer or its Affiliate of any Product manufacturing
process that has been changed (including as to the facility in which such manufacturing process
takes place) on or following the Effective Date without the written approval of Customer to make
such change; (iv) Manufacturer's supply of Non-Complying Product under this Agreement; or (v) the
gross negligence, fraud or willful misconduct of Manufacturer or its Personnel in connection with
the performance or non-performance of this Agreement. (b) Notwithstanding the foregoing,
Manufacturer shall not be liable for Losses described in Section 10.1(a) to the extent such Losses
are: (i) caused by the gross negligence, fraud or willful misconduct of a Customer Indemnified Party
in connection with the performance or non-performance of this Agreement; (ii) caused by the breach
of any of the terms of this Agreement or a Facility Addendum by a Customer Indemnified Party,
including in connection with the performance or non-performance of this Agreement or (iii) subject
to Customer's indemnification obligations pursuant to Section 10.2. 10.2 Indemnification of
Manufacturer. (a) Subject to the provisions of this Section 10 and, for clarity, without limiting
anything in the Separation Agreement or any Ancillary Agreements, Customer shall indemnify, defend
and hold harmless Manufacturer, its Affiliates and its and their respective directors, officers,
managers, members, employees and agents, and each of the heirs, executors, successors and assigns of
any of the foregoing (each, a "Manufacturer Indemnified Party") from and against any and all Losses
of such Manufacturer Indemnified Parties to the extent relating to, arising out of or resulting from
any Action of a Third Party arising out of or resulting from any of the following items (without
duplication): (i) any breach by Customer or its Personnel of this Agreement or any Facility
Addendum; (ii) the gross negligence, fraud or willful misconduct of Customer or its Personnel in
connection with the performance or non-performance of this Agreement; (iii) the infringement or
misappropriation of a Third Party's Intellectual Property by the use or practice by Manufacturer or
its Affiliate in performance of this Agreement of any Product manufacturing process that has been
changed with the written approval of Customer to make such change; (iv) Customer's supply of
Non-Complying Customer-Supplied Materials or Non-Complying Buy- Sell Materials under this Agreement;
or (v) the use, sale, offer for sale, import or other commercialization of any Product (including
any injury or death of any Person due to any of the foregoing in this clause (v)). -59-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 64 -->
(b) Notwithstanding the foregoing, Customer shall not be liable for Losses described in Section
10.2(a) to the extent such Losses are: (i) caused by the gross negligence, fraud or willful
misconduct of a Manufacturer Indemnified Party in connection with the performance or non-performance
of this Agreement; (ii) caused by the breach of any of the terms of this Agreement or any Facility
Addendum by a Manufacturer Indemnified Party or (iii) are subject to Manufacturer's indemnification
obligation pursuant to Section 10.1. Furthermore, Customer shall not be liable for Losses pursuant
to Section 10.2(a)(iii) above to the extent such infringement or misappropriation is caused by
Manufacturer's unauthorized use or unauthorized modification of any Customer Property, Customer-
Owned Improvements and Developments, Buy-Sell Materials or Customer-Supplied Materials. 10.3
Indemnification Procedures. (a) If, at or following the date of this Agreement, any Person entitled
to be indemnified under this Section 10 (the "Indemnitee") shall receive notice or otherwise learn
of the assertion by a Person (including any Governmental Authority) who is not a member of the Pluto
Group or the Spinco Group of any claim or of the commencement by any such Person of any Action with
respect to which the Party from whom indemnification may be sought under this Section 10 (the
"Indemnifying Party") (such claim, a "Third-Party Claim"), such Indemnitee shall give such
Indemnifying Party written notice thereof as promptly as practicable, but in any event within thirty
(30) days (or sooner if the nature of the Third-Party Claim so requires) after becoming aware of
such Third-Party Claim. Any such notice shall describe the Third-Party Claim in reasonable detail,
including the facts and circumstances giving rise to such claim for indemnification, and include
copies of all notices and documents (including court papers) received by the Indemnitee relating to
the Third-Party Claim. Notwithstanding the foregoing, the failure of any Indemnitee to provide
notice as provided in this Section 10.3(a) shall not relieve an Indemnifying Party of its
obligations under this Section 10, except to the extent, and only to the extent, that such
Indemnifying Party is materially prejudiced by such failure to give notice in accordance with this
Section 10.3(a). (b) An Indemnifying Party may elect (but shall not be required) to defend (and seek
to settle or compromise), at such Indemnifying Party's own expense and by such Indemnifying Party's
own counsel (which counsel shall be reasonably satisfactory to the Indemnitee), any Third-Party
Claim; provided that the Indemnifying Party shall not be entitled to defend such Third-Party Claim
and shall pay the reasonable fees and expenses of one separate -60-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 65 -->
counsel for all Indemnitees if the claim for indemnification relates to or arises in connection with
any criminal action, indictment or allegation or if such Third-Party Claim seeks an injunction or
equitable relief against the Indemnitee (and not any Indemnifying Party or any of its Affiliates).
Within thirty (30) days after the receipt of notice from an Indemnitee in accordance with Section
10.3(a) (or sooner, if the nature of such Third-Party Claim so requires), the Indemnifying Party
shall notify the Indemnitee of its election whether the Indemnifying Party will assume
responsibility for defending such Third-Party Claim, which election shall specify any reservations
or exceptions to its defense. After notice from an Indemnifying Party to an Indemnitee of its
election to assume the defense of a Third-Party Claim, such Indemnitee shall have the right to
employ separate counsel and to participate in (but not control) the defense, compromise, or
settlement thereof, but the fees and expenses of such counsel shall be the expense of such
Indemnitee; provided, however, in the event that the Indemnifying Party has elected to assume the
defense of the Third-Party Claim but has specified, and continues to assert, any reservations or
exceptions in such notice, then, in such case, the reasonable fees and expenses of one separate
counsel for all Indemnitees shall be borne by the Indemnifying Party; and provided further that the
Indemnifying Party will pay the reasonable fees and expenses of such separate counsel if, based on
the reasonable opinion of legal counsel to the Indemnitee, a conflict or potential conflict of
interest exists between the Indemnifying Party and the Indemnitee which makes representation of both
parties inappropriate under applicable standards of professional conduct. (c) If an Indemnifying
Party elects not to assume responsibility for defending a Third-Party Claim, or fails to notify an
Indemnitee of its election as provided in Section 10.3(b), then the applicable Indemnitee may defend
such Third-Party Claim at the cost and expense of the Indemnifying Party to the extent
indemnification is available under the terms of this Agreement. If an Indemnifying Party elects not
to assume responsibility for defending a Third-Party Claim, or fails to notify an Indemnitee of its
election as provided in Section 10.3(b), then, it shall not be a defense to any obligation of the
Indemnifying Party to pay any amount in respect of such Third-Party Claim that the Indemnifying
Party was not consulted in the defense thereof, that such Indemnifying Party's views or opinions as
to the conduct of such defense were not accepted or adopted, that such Indemnifying Party does not
approve of the quality or manner of the defense thereof or, subject to Section 10.3(d), that such
Third-Party Claim was incurred by reason of a settlement rather than by a judgment or other
determination of liability. (d) Neither Party may settle or compromise any Third-Party Claim for
which either Party is seeking to be indemnified hereunder without the prior written consent of the
other Party, which consent may not be unreasonably withheld, conditioned or delayed, unless such
settlement or compromise is solely for monetary damages that are fully payable by the settling or
compromising party, does not involve any admission, finding or determination of wrongdoing or
violation of Law by the other Party and provides for a full, unconditional and irrevocable release
of the other Party from all Liability in connection with the Third-Party Claim. -61-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 66 -->
10.4 Limitations on Liability. (a) Except in the event of (i) Third Party Claims subject to a
Party's indemnification obligations pursuant to Section 10.1, (ii) Third Party Claims subject to a
Party's indemnification obligations pursuant to Section 10.2, (iii) the gross negligence, fraud or
willful misconduct of a Party or its Personnel, (iv) a Party's willful breach of this Agreement, (v)
a breach of Section 13 or (vi) customer liabilities pursuant to, and subject to the limitations set
forth in, Section 2.5(e), neither Party's aggregate liability to the other Party (or its Personnel
that are indemnitees under Section 10.1 or Section 10.2, as applicable) under this Agreement for the
initial twelve (12) month period immediately following the Effective Date, and for any twelve (12)
month period thereafter during the Term, shall exceed, on a cumulative basis, the amount that is one
and one half (11∕2) times the aggregate amounts paid or payable pursuant to this Agreement in the
preceding twelve (12) month period preceding the loss date by Customer to Manufacturer but solely
with respect to the supply hereunder of Product (or Products) for which such corresponding liability
arose (the "Affected Products") and not any other Products (or if, as of the time the liability
arises, this Agreement has not been in effect for twelve (12) months, then the amounts paid or
payable by Customer to Manufacturer hereunder during the period from the Effective Date until such
time the liability arises, shall be annualized to a full twelve (12) months but solely with respect
to the supply hereunder of the Affected Product(s) and not any other Products). (b) NOTWITHSTANDING
ANY OTHER PROVISION OF THIS AGREEMENT TO THE CONTRARY, EXCEPT FOR DAMAGES OR CLAIMS ARISING OUT OF
(I) A BREACH OF SECTION 13 OF THIS AGREEMENT, (II) CUSTOMER LIABILITIES PURSUANT TO, AND SUBJECT TO
THE LIMITATIONS SET FORTH IN, SECTION 2.5(E), (III) A PARTY'S OR ITS PERSONNEL'S GROSS NEGLIGENCE,
FRAUD OR WILLFUL MISCONDUCT, (IV) A PARTY'S WILLFUL BREACH OF THIS AGREEMENT, OR (V) A PARTY'S
INDEMNIFICATION OBLIGATION WITH RESPECT TO THIRD PARTY CLAIMS UNDER SECTION 10.1 OR SECTION 10.2, IN
NO EVENT SHALL EITHER PARTY BE LIABLE TO THE OTHER PARTY OR ANY INDEMNIFIED PARTY HEREUNDER FOR ANY
CONSEQUENTIAL DAMAGES, SPECIAL DAMAGES, INCIDENTAL OR INDIRECT DAMAGES, LOSS OF REVENUE OR PROFITS,
DIMINUTION IN VALUE, DAMAGES BASED ON MULTIPLE OF REVENUE OR EARNINGS OR OTHER PERFORMANCE METRIC,
LOSS OF BUSINESS REPUTATION, PUNITIVE AND EXEMPLARY DAMAGES OR ANY SIMILAR DAMAGES ARISING OR
RESULTING FROM OR RELATING TO THIS AGREEMENT, WHETHER SUCH ACTION IS BASED ON WARRANTY, CONTRACT,
TORT (INCLUDING NEGLIGENCE OR STRICT LIABILITY) OR OTHERWISE. -62-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 67 -->
10.5 Indemnification Obligations Net of Insurance Proceeds and Other Amounts. (a) The Parties intend
that any Loss subject to indemnification or reimbursement pursuant to this Section 10 will be net of
Insurance Proceeds or other amounts actually recovered (net of any out-of-pocket costs or expenses
incurred in the collection thereof) from any Person by or on behalf of the Indemnitee in respect of
any indemnifiable Liability. Accordingly, the amount that any Indemnifying Party is required to pay
to any Indemnitee will be reduced by any Insurance Proceeds or other amounts actually recovered (net
of any out-of-pocket costs or expenses incurred in the collection thereof) from any Person by or on
behalf of such Indemnitee in respect of the related Loss. If an Indemnitee receives a payment (an
"Indemnity Payment") required by this Agreement from an Indemnifying Party in respect of any Loss
and subsequently receives Insurance Proceeds or any other amounts in respect of the related Loss,
then the Indemnitee will pay to the Indemnifying Party an amount equal to the excess of the
Indemnity Payment received over the amount of the Indemnity Payment that would have been due if the
Insurance Proceeds or such other amounts (net of any out-of-pocket costs or expenses incurred in the
collection thereof) had been received, realized or recovered before the Indemnity Payment was made.
(b) An insurer that would otherwise be obligated to pay any claim shall not be relieved of the
responsibility with respect thereto or, solely by virtue of any provisions contained in this
Agreement, have any subrogation rights with respect thereto, it being expressly understood and
agreed that no insurer or any other Third Party shall be entitled to a "wind-fall" (i.e., a benefit
that such insurer or other Third Party would not be entitled to receive in the absence of the
indemnification provisions) by virtue of the indemnification provisions hereof. Each Party shall,
and shall cause the members of its Group to, use commercially reasonable efforts (taking into
account the probability of success on the merits and the cost of expending such efforts, including
attorneys' fees and expenses) to collect or recover any Insurance Proceeds that may be collectible
or recoverable respecting the Liabilities for which indemnification may be available under this
Section 10. Notwithstanding the foregoing, an Indemnifying Party may not delay making any
indemnification payment required under the terms of this Agreement, or otherwise satisfying any
indemnification obligation, pending the outcome of any Action to collect or recover Insurance
Proceeds, and an Indemnitee need not attempt to collect any Insurance Proceeds prior to making a
claim for indemnification or receiving any Indemnity Payment otherwise owed to it under this
Agreement or any Ancillary Agreement. -63-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 68 -->
10.6 Additional Matters. (a) Indemnification payments in respect of any Liabilities for which an
Indemnitee is entitled to indemnification under this Section 10 shall be paid reasonably promptly
(but in any event within sixty (60) days of the final determination of the amount that the
Indemnitee is entitled to indemnification under this Section 10) by the Indemnifying Party to the
Indemnitee as such Liabilities are incurred upon demand by the Indemnitee, including reasonably
satisfactory documentation setting forth the basis for the amount of such indemnification payment,
documentation with respect to calculations made and consideration of any Insurance Proceeds that
actually reduce the amount of such Liabilities. (b) If (i) a Party incurs any Liability arising out
of this Agreement or any Ancillary Agreement; (ii) an adequate legal or equitable remedy is not
available for any reason against the other Party to satisfy the Liability incurred by the incurring
Party; and (iii) a legal or equitable remedy may be available to the other Party against a Third
Party for such Liability, then the other Party shall use its commercially reasonable efforts to
cooperate with the incurring Party, at the incurring Party's expense, to permit the incurring Party
to obtain the benefits of such legal or equitable remedy against the Third Party. (c) If payment is
made by or on behalf of any Indemnifying Party to any Indemnitee in connection with any Third-Party
Claim, such Indemnifying Party shall be subrogated to and shall stand in the place of such
Indemnitee as to any events or circumstances in respect of which such Indemnitee may have any right,
defense or claim relating to such Third-Party Claim against any claimant or plaintiff asserting such
Third-Party Claim or against any other Person. Such Indemnitee shall cooperate with such
Indemnifying Party in a reasonable manner, and at the cost and expense of such Indemnifying Party,
in prosecuting any subrogated right, defense or claim. (d) In the event of an Action in which the
Indemnifying Party is not a named defendant, if either the Indemnitee or Indemnifying Party shall so
request, the Parties shall endeavor to substitute the Indemnifying Party for the named defendant or
otherwise add the Indemnifying Party as party thereto, if at all practicable. If such substitution
or addition cannot be achieved for any reason or is not requested, the named defendant shall allow
the Indemnifying Party to manage the Action as set forth in this Section 10, and the Indemnifying
Party shall fully indemnify the named defendant against all costs of defending the Action (including
court costs, sanctions imposed by a court, attorneys' fees, experts fees and all other external
expenses), the costs of any judgment or settlement, and the cost of any interest or penalties
relating to any judgment or settlement with respect to such Third-Party Claim. -64-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 69 -->
11. Insurance. 11.1 Requirements to Maintain. During the Term, Manufacturer shall self-insure or
shall provide and maintain such insurance coverage, in minimum types and amounts as described below
in this Section 11. (a) Any and all deductibles or retentions for such insurance policies shall be
assumed by, for the account of, and at Manufacturer's sole risk. (b) To the extent of the
liabilities assumed by Manufacturer under this Agreement, such insurance policies of Manufacturer
shall be primary and non-contributing with respect to any other similar insurance policies available
to Customer or its Affiliates. (c) Manufacturer shall furnish to Customer certificates of insurance
(electronic is acceptable), evidencing the required insurance coverage, upon execution of this
Agreement and annually, thereafter. 11.2 Amounts and Limits. The insurance required under this
Section 11 shall be written for not less than any limits of liability specified herein or as
required by applicable Law, whichever is greater. All insurance carriers shall have a minimum of
"A-" A.M. Best rating. Manufacturer shall have the right to provide the total limits required by any
combination of self-insurance, primary and umbrella/excess coverage; said insurance to include the
following: (a) Insurance for liability under the workers' compensation or occupational disease Laws
of any state of the United States (or be a qualified self-insurer in those states of the United
States) or otherwise applicable with respect to Persons performing the services and employer's
liability insurance covering all claims by or in respect to the employees of Manufacturer,
providing: (i) Coverage for the statutory limits of all claims under the applicable State Workers'
Compensation Act or Acts. If a Facility Addendum will result in exposures under the U.S. Longshore
and Harbor Workers' Compensation Act and its amendments (work dockside or on water), the Jones Act
(involving seamen, masters and crew of vessels) or the Federal Employers' Liability Act (railroad
exposure), coverage shall be extended to include insurance coverages mandated thereby; (ii)
Employer's liability insurance with a limit of not less than $1,000,000; (iii) Manufacturer warrants
that all of its employees involved in this Agreement are covered by statutory workers' compensation;
and -65-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 70 -->
(iv) Where allowed by Applicable Law, Customer and its Affiliates shall be provided a waiver of
subrogation, except for losses due to the sole negligence of Manufacturer. (b) Commercial general
liability insurance with the following limits and forms/endorsements:

Each Occurrence: $2,000,000 (i) Occurrence form including premises and operations coverage, property
damage, liability, personal injury coverage, products and completed operations coverage, and
transit. (ii) To the extent of Manufacturer's indemnification obligations, Customer and its
Affiliates shall be additional insureds via ISO form CG20101185 or its equivalent. (c) Automobile
and Truck Liability Insurance: $2,000,000 combined single limit for bodily injury and property
damage arising out of all owned, non- owned and hired vehicles, including coverage for all
automotive and truck equipment used in the performance of this Agreement and including the loading
and unloading of same. (d) Umbrella (excess) liability coverage in an amount not less than
$3,000,000 per occurrence and in the aggregate. (e) If Manufacturer has care, custody or control of
Customer-Supplied Material, Manufacturer shall be responsible for any loss or damage to it and
provide all risk property coverage at full replacement cost for property and at the costs-per-unit
as specified in the Facility Addendum for inventory. 12. Customer-Supplied Materials; Buy-Sell
Materials; Transition. 12.1 Supply; Rejection; Transition. (a) Customer shall at its own expense
supply Manufacturer with the Customer-Supplied Materials identified in the applicable Facility
Addendum. Customer shall supply Manufacturer with the Buy-Sell Materials at a price that Customer
determines, subject to Section 3.2(c), and communicates to Manufacturer. At Customer's option, the
Customer-Supplied Materials and Buy-Sell Materials may be delivered directly from Customer's
Third-Party vendor to Manufacturer at the vendor's or Customer's expense. Customer or its vendor
shall supply Manufacturer with a copy of the certificate of analysis for the Customer-Supplied
Materials and Buy-Sell Materials no later than delivery of the Customer-Supplied Materials or
Buy-Sell Materials to Manufacturer. Customer hereby covenants to Manufacturer that each
Customer-Supplied Material and Buy-Sell Materials furnished by or on behalf of Customer to
Manufacturer or its Affiliate or designee under -66-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 71 -->
this Agreement will, upon delivery by Customer to Manufacturer pursuant to this Agreement, comply
with, and have been used, handled and stored in accordance with, the specifications for such
Customer-Supplied Materials or Buy-Sell Materials (as applicable), all applicable Laws, the Quality
Agreement, this Agreement and the applicable Facility Addendum and otherwise have no defects.
Manufacturer's obligations to manufacture and supply Product under this Agreement are subject to and
conditioned upon Customer's timely delivery of Customer-Supplied Material and Buy-Sell Materials in
accordance with this Section 12. (b) Manufacturer shall provide to Customer a monthly rolling
forecast of its requirements for Customer-Supplied Materials and Buy-Sell Materials based upon
Customer's Forecasts for Products, and Manufacturer shall issue to Customer "pro forma" purchase
orders for Customer-Supplied Materials and actual purchase orders for Buy-Sell Materials, in each
case, according to parameters included in the applicable Facility Addendum, including safety stock
and lead time requirements. Manufacturer shall be responsible to receive, sample, store and maintain
the inventory of such ordered Customer-Supplied Materials and Buy-Sell Materials at Manufacturer's
Facility. (c) Within each calendar month during the Term, Manufacturer will provide a monthly
inventory report of Customer-Supplied Materials substantially in the format attached as Attachment C
to this Agreement. The Parties acknowledge and agree that the Manufacturer's timely providing the
referenced monthly inventory report is a critical component of the Customer's Customer-Supplied
Materials management program and further that any such failure on the part of Manufacturer to timely
provide such monthly inventory report shall be addressed at the immediately following scheduled JAC
Meeting. (d) Manufacturer may reject any Non-Complying Buy-Sell Materials or Non-Complying
Customer-Supplied Materials by (i) providing Customer with no less than sixty (60) days' prior
written notice of Manufacturer's intention to reject along with the documentation setting forth in
reasonable detail the basis for rejection, (ii) meeting with Customer at Customer's request to
discuss the basis for the proposed rejection, and (iii) providing Customer with notice of rejection
in the event that Manufacturer rejects the subject Non- Complying Buy-Sell Materials or
Non-Complying Customer-Supplied Materials (as applicable) at the end of such sixty (60) day period
(or such other time frame as the Parties may agree upon). (e) Customer shall submit invoices to
Manufacturer upon delivery to Manufacturer or its applicable Affiliate of Buy-Sell Materials, and
Manufacturer shall make payments with respect thereto, in accordance with the invoice and payment
requirements set forth in Section 3.5, applied correlatively, and the parties shall discuss in good
faith further requirements with respect to the supply of Buy-Sell Materials. -67-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 72 -->
(f) Customer shall use its commercially reasonable efforts to convert all Buy-Sell Materials
arrangements to Customer-Supplied Materials arrangements as promptly as practicable after the
Effective Date; provided that Customer shall provide updates with respect to such efforts at each
JAC Meeting until all such Buy-Sell Materials arrangements shall have been converted to
Customer-Supplied Materials arrangements. 12.2 Title and Risk of Loss. (a) Title to the
Customer-Supplied Materials supplied by Customer to Manufacturer shall remain with Customer;
provided, however, that risk of loss shall pass to Manufacturer at the time Customer-Supplied
Materials are delivered to the Manufacturer DDP (Incoterms 2010) at the applicable Facility.
Manufacturer shall not use Customer-Supplied Materials for any purposes other than those related to
the manufacture of a Product pursuant to this Agreement. (b) The risk of loss or damage to
Customer-Supplied Materials during the possession thereof by Manufacturer shall be solely with
Manufacturer. (c) Manufacturer shall insure or self-insure the Customer-Supplied Materials and
Products while such is in Manufacturer's possession at an agreed-upon value. (d) The title and risk
of loss for Buy-Sell Materials shall pass to Manufacturer upon delivery to the Manufacturer DDP
(Incoterms 2010) at the applicable Facility. 12.3 Reimbursement for Loss of Customer-Supplied
Materials. Manufacturer shall reimburse Customer for excess Customer-Supplied Materials used as a
result of Manufacturer's failure to achieve the minimum average yield or usage (as applicable) set
forth in the applicable Facility Addendum. During the first quarter of each Fiscal Year during the
Term of this Agreement, Manufacturer will report to Customer the actual yield achieved for all
Customer-Supplied Materials used during the previous calendar year on a Facility-by-Facility basis.
If the achieved yield is lower than the minimum average yield specified in the applicable Facility
Addendum on an aggregated basis for all Customer- Supplied Materials for each applicable Facility
Addendum, then Manufacturer will reimburse to Customer the actual cost of the excess
Customer-Supplied Materials used as set forth in the applicable Facility Addendum. For the avoidance
of doubt, (a) rejected batches and all Customer-Supplied Material that is, for any reason other than
a determination that such Customer-Supplied Materials are non-conforming, not incorporated into
Product delivered hereunder, shall be included in the annual yield calculation and (b)
Customer-Supplied Materials for which Manufacturer is responsible for reimbursing Customer pursuant
to Section 4.11(b) shall not be included in the annual yield calculation. -68-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 73 -->
13. Confidentiality.

The confidentiality obligations of the Parties and their respective Groups with respect to
disclosures of information hereunder shall be governed, mutatis mutandis, by Section 6.08, Section
6.09 and Section 6.10 of the Separation Agreement. 14. Supply Chain Security. 14.1 Supply Chain
Representations.

Manufacturer represents, warrants and covenants to Customer that:

Manufacturer has reviewed its supply chain security procedures and that these procedures and their
implementation are, and shall remain during the Term of this Agreement, in accordance with the
importer security criteria set forth by the "C-TPAT." Manufacturer represents and warrants that it
has developed and implemented, or shall develop and implement within sixty (60) calendar days of its
execution of this Agreement, procedures for periodically reviewing and, if necessary, improving its
supply chain security procedures to assure compliance with C-TPAT minimum security criteria. 14.2
C-TPAT.

Manufacturer acknowledges that Customer is a certified member of C-TPAT. As a C-TPAT member,
Customer is required to make periodic assessment of its international supply chain based upon C-TPAT
security criteria. Manufacturer agrees to conduct and document an annual security audit at each of
its Facilities and to take all necessary corrective actions to ensure the continued participation of
Customer in C- TPAT. Manufacturer agrees to share with Customer the results of such annual audits
and agrees to prepare and submit to Customer a report on the corrective actions taken in response
thereto. In addition, Customer may audit Manufacturer's Records and Facilities for the purpose of
verifying that Manufacturer's procedures are in accordance with the C-TPAT security criteria, and
Manufacturer shall provide Customer with access to Manufacturer's Records and Facilities reasonably
necessary for the purpose of conducting such audit. Manufacturer agrees to notify Customer of any
event that has resulted in or threatens the loss of its C-TPAT Benefits (if it is a member of the
C-TPAT program) or alternatively jeopardizes Customer's retention of its own C-TPAT Benefits. In an
effort to secure each part of the supply chain, Manufacturer agrees to work in good faith to become
a member of the C-TPAT program, if Manufacturer is organized or incorporated in the United States,
Mexico or Canada, or the equivalent supply chain security program criteria administered by the
customs administration in Manufacturer's home country if Manufacturer is not organized or
incorporated in the United States, Mexico or Canada. -69-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 74 -->
15. Records and Audits. 15.1 Records.

Manufacturer will maintain complete and accurate Records. Any Records that are financial in nature
such as, but not limited to, time sheets, billing Records, invoices, payment applications, payments
of consultants and subcontractors and receipts relating to reimbursable expenses shall be maintained
in accordance with applicable Law in the jurisdiction in which the applicable Facility is located.
Manufacturer shall maintain such Records for a period equal to the later of (x) three (3) years
after the expiration or termination of this Agreement or the applicable Facility Addendum, (y) the
expiration of the statute of limitation for the Tax period applicable to such Records, or (z) for
such period as otherwise may be required by applicable Law (the "Record Retention Period"). 15.2
Audits.

Customer or its representatives, including its external auditors, may audit such Records of
Manufacturer, including all Records related to Manufacturer's compliance with applicable Laws, at
any time during the Term of this Agreement or applicable Facility Addendum or the Record Retention
Period, during normal business hours and upon reasonable advance written notice to Manufacturer (but
in no event more than one (1) time per year except "for cause"). Manufacturer shall make such
Records readily available for such audit. Any Records or information accessed or otherwise obtained
by Customer or its representatives in connection with any audit (including any audit pursuant to
Section 3.4) shall be deemed Manufacturer's confidential and proprietary Information and each
representative of Customer will be subject to non-use and other confidentiality obligations
substantially comparable to those set forth herein for Customer. Except as otherwise provided in
Section 3.4, if any financial audit reveals that Manufacturer has overcharged Customer, Manufacturer
shall reimburse Customer for such overcharge within thirty (30) days of Manufacturer's receipt of
the relevant audit results, and in the event that any such overcharge equals an amount equal to or
greater than five percent (5%) of the total amounts invoiced during the period under such audit,
then Manufacturer shall promptly reimburse Customer for all reasonable Third Party costs and
expenses actually incurred in the conduct of such audit. If any financial audit reveals that
Customer has underpaid Manufacturer, Customer shall reimburse Manufacturer for such underpayment
within thirty (30) days of Customer's receipt of the relevant audit results. For clarity, if there
is a conflict between Section 3.4(a) and this Section 15.2 with respect to the review of a Price
increase, Section 3.4(a) shall govern and control. -70-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 75 -->
16. Notices.

All notices or other communications hereunder shall be deemed to have been duly given and made if in
writing and (a) when served by personal delivery upon the Party for whom it is intended; (b) one (1)
Business Day following the day sent by overnight courier, return receipt requested; (c) when sent by
facsimile; provided that the facsimile is promptly confirmed; or (d) when sent by e-mail; provided
that a copy of the same notice or other communication sent by e-mail is also sent by overnight
courier, return receipt requested, personal delivery, or facsimile as provided herein, on the same
day as such e-mail is sent, in each case to the Person at the address, facsimile number or e-mail
address set forth below, or such other address, facsimile number or e-mail address as may be
designated in writing hereafter, in the same manner, by such Person: If to Customer: [INSERT NAME]
[INSERT ADDRESS] ATTENTION: [INSERT NAME/TITLE] EMAIL ADDRESS: [INSERT E-MAIL ADDRESS]

with copy (which shall not constitute notice) to:

[INSERT NAME] [INSERT ADDRESS] ATTENTION: [INSERT NAME/TITLE] EMAIL ADDRESS: [INSERT E-MAIL ADDRESS]

If to Manufacturer: [INSERT NAME] [INSERT ADDRESS] ATTENTION: [INSERT NAME/TITLE] EMAIL ADDRESS:
[INSERT E-MAIL ADDRESS]

with a copy (which shall not constitute notice) to:

[INSERT NAME] [INSERT ADDRESS] ATTENTION: [INSERT NAME/TITLE] EMAIL ADDRESS: [INSERT E-MAIL ADDRESS]

Either Party may, by notice to the other Party, change the addresses and names applicable to such
Party given above. 17. Miscellaneous. 17.1 Negotiations of Dispute.

The dispute resolution procedures set forth in Article VII of the Separation Agreement shall apply
mutatis mutandis with respect to any controversy, claim, counterclaim, dispute, difference or
misunderstanding arising out of or relating to the interpretation or application of any term or
provisions of this Agreement, a Purchase Order or Facility Addendum. Further, the requirement to
attempt to resolve a dispute in accordance with this Section 17.1 does not affect a Party's right to
terminate this Agreement or a Purchase Order as provided in Section 7 hereof, and neither Party
shall be required to follow these procedures prior to terminating this Agreement. -71-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 76 -->
17.2 Publicity.

Manufacturer shall not use the name, trade name, service marks, trademarks, trade dress or logos of
Customer (or any of its Affiliates) in publicity releases, advertising or any other publication, nor
identify Customer as a customer, without Customer's prior written consent in each instance. Customer
shall not use the name, trade name, service marks, trademarks, trade dress or logos of Manufacturer
(or any of its Affiliates) in publicity releases, advertising or any other publication, without
Manufacturer's prior written consent in each instance. Nothing in this Section 17.2 shall or is
intended to limit any Party's rights under the Separation Agreement or any Ancillary Agreement. 17.3
Governing Law and Venue. (a) This Agreement and all Actions (whether in contract or tort) that may
be based upon, arise out of or relate to this Agreement or the negotiation, execution or performance
hereof or thereof shall be governed by and construed in accordance with the Law of the State of
Delaware, without regard to any Laws or principles thereof that would result in the application of
the Laws of any other jurisdiction. The Parties expressly waive any right they may have, now or in
the future, to demand or seek the application of a governing Law other than the Law of the State of
Delaware. (b) Each of the Parties hereby irrevocably and unconditionally submits to the exclusive
jurisdiction of the Court of Chancery of the State of Delaware or, if such court shall not have
jurisdiction, the United States District Court for the District of Delaware, and any appellate court
from any appeal thereof, in any Action arising out of or relating to this Agreement or the
transactions contemplated hereby, and each of the Parties hereby irrevocably and unconditionally (i)
agrees not to commence any such Action except in such courts, (ii) agrees that any claim in respect
of any such Action may be heard and determined in the Court of Chancery of the State of Delaware or,
to the extent permitted by Law, in such other courts, (iii) waives, to the fullest extent it may
legally and effectively do so, any objection which it may now or hereafter have to the laying of
venue of any such Action in the Court of Chancery of the State of Delaware or such other courts,
(iv) waives, to the fullest extent permitted by Law, the defense of an inconvenient forum to the
maintenance of such Action in the Court of Chancery of the State of Delaware or such other courts
and (v) consents to service of process in the manner provided for notices in Section 16. Nothing in
this Agreement will affect the right of any Party to serve process in any other manner permitted by
Law. -72-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 77 -->
(c) EACH PARTY ACKNOWLEDGES AND AGREES THAT ANY CONTROVERSY WHICH MAY ARISE UNDER THIS AGREEMENT IS
LIKELY TO INVOLVE COMPLICATED AND DIFFICULT ISSUES, AND THEREFORE IT HEREBY IRREVOCABLY AND
UNCONDITIONALLY WAIVES ANY RIGHT IT MAY HAVE TO A TRIAL BY JURY IN RESPECT OF ANY ACTION DIRECTLY OR
INDIRECTLY ARISING OUT OF OR RELATING TO THIS AGREEMENT, ANY OF THE OTHER ANCILLARY AGREEMENTS OR
THE TRANSACTIONS CONTEMPLATED HEREBY OR THEREBY (INCLUDING THE FINANCING). EACH PARTY CERTIFIES AND
ACKNOWLEDGES THAT (I) NO REPRESENTATIVE, AGENT OR ATTORNEY OF ANY OTHER PARTY HAS REPRESENTED,
EXPRESSLY OR OTHERWISE, THAT SUCH OTHER PARTY WOULD NOT, IN THE EVENT OF LITIGATION, SEEK TO ENFORCE
SUCH WAIVERS, (II) IT UNDERSTANDS AND HAS CONSIDERED THE IMPLICATIONS OF SUCH WAIVERS, (III) IT
MAKES SUCH WAIVERS VOLUNTARILY AND (IV) IT HAS BEEN INDUCED TO ENTER INTO THIS AGREEMENT BY, AMONG
OTHER THINGS, THE MUTUAL WAIVERS AND CERTIFICATIONS IN THIS SECTION 17.3(C). 17.4 Relationship of
the Parties.

The relationship hereby established between Customer and Manufacturer is solely that of independent
contractors. Manufacturer has no authority to act or make any agreements or representations on
behalf of Customer or its Affiliates. This Agreement is not intended to create, and shall not be
construed as creating, between Manufacturer and Customer, the relationship of fiduciary, principal
and agent, employer and employee, joint venturers, co-partners, or any other such relationship, the
existence of which is expressly denied. No employee or agent engaged by Manufacturer shall be, or
shall be deemed to be, an employee or agent of Customer and shall not be entitled to any benefits
that Customer provides to its own employees. 17.5 Assignment; Binding Effect. (a) Except as
otherwise provided in this Section 17.5, neither Party shall assign this Agreement or any rights,
benefits or obligations under or relating to this Agreement, in each case whether by operation of
law or otherwise, without the other Party's prior written consent (not to be unreasonably withheld,
conditioned or delayed). (b) Either Party may assign its rights and obligations under this Agreement
to one or more of its Affiliates without the other Party's consent; provided that such Affiliate
remains at all times during the Term an Affiliate of such Party; provided, further, that no such
assignment shall release such Party from its obligations under this Agreement. -73-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 78 -->
(c) Customer may, without Manufacturer's consent, assign the rights and obligations of this
Agreement (i) on a Product-by-Product basis, to a Third Party in connection with a bona fide
transfer, sale or divestiture of all or substantially all of its business to which such Product
relates or in the event of such business's spin-off, merger or consolidation with another company or
business entity or (ii) to any Third Party which acquires or succeeds to all or substantially all of
the assets of the business of Customer to which this Agreement and the Facility Addenda relate
(including in connection with such business's spin-off, merger or consolidation with another company
or business entity). (d) Subject to Section 7.4, Manufacturer may, without Customer's consent,
assign the rights and obligations of this Agreement (i) on a Facility-by-Facility basis, to a Third
Party in connection with a bona fide transfer, sale or divestiture of such Facility or (ii) to any
Third Party which acquires or succeeds to all or substantially all of the assets of the business of
Manufacturer to which this Agreement and the Facility Addendum relates (including in connection with
such business's spin-off, merger or consolidation with another company or business entity). (e)
Notwithstanding anything to the contrary in this Agreement, neither Party may assign this Agreement
in whole or in part to a Restricted Party. (f) In the event of a permitted assignment, this
Agreement shall be binding upon and inure to the benefit of the Parties and their respective
permitted successors and permitted assigns. Any attempted assignment that contravenes the terms of
this Agreement shall be void ab initio and of no force or effect. Notwithstanding anything contained
in this Agreement, each Party hereby acknowledges and agrees that the other Party may perform any of
its obligations, and exercise any of its rights, under this Agreement, any Facility Addendum and
Quality Agreement through any of its Affiliates. 17.6 Force Majeure.

Subject to Manufacturer's obligations under Section 2.5(a), no Party shall be liable for any failure
to perform or any delays in performance, and no Party shall be deemed to be in breach or default of
its obligations set forth in this Agreement, if, to the extent and for so long as, such failure or
delay is due to any causes that are beyond its reasonable control and not to its acts or omissions,
including, without limitation, such causes as acts of God, natural disasters, hurricane, flood,
severe storm, earthquake, civil disturbance, lockout, riot, order of any court or administrative
body, embargo, acts of Government, war (whether or not declared), acts of terrorism, or other
similar causes ("Force Majeure Event"). For clarity, raw material price increases, unavailability of
raw materials, and labor disputes shall not be deemed a Force Majeure Event. In the event of a Force
Majeure Event, the Party prevented from or delayed in performing shall promptly give notice to the
-74-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 79 -->
other Party and shall use commercially reasonable efforts to avoid or minimize the delay. In the
event that the delay continues for a period of at least sixty (60) calendar days, the Party affected
by the other Party's delay may elect to (a) suspend performance and extend the time for performance
for the duration of the Force Majeure Event or (b) cancel all or any part of the unperformed part of
this Agreement or any Purchase Orders. 17.7 Severability.

If any provision of this Agreement or the application of any provision thereof to any Person or
circumstance, is held invalid or unenforceable by any court of competent jurisdiction, the other
provisions of this Agreement shall remain in full force and effect. The Parties further agree that
if any provision contained herein is, to any extent, held invalid or unenforceable in any respect
under the Laws governing this Agreement, they shall take any actions necessary to render the
remaining provisions of this Agreement valid and enforceable to the fullest extent permitted by Law
and, to the extent necessary, shall amend or otherwise modify this Agreement to replace any
provision contained herein that is held invalid or unenforceable with a valid and enforceable
provision giving effect to the intent of the Parties. 17.8 Non-Waiver; Remedies.

Waiver by any Party of any default by the other Party of any provision of this Agreement shall not
be deemed a waiver by the waiving Party of any subsequent or other default, nor shall it prejudice
the rights of the other Party. No failure or delay by a Party in exercising any right, power or
privilege under this Agreement shall operate as a waiver thereof, nor shall a single or partial
exercise thereof prejudice any other or further exercise thereof or the exercise of any other right,
power or privilege.

All remedies specified in this Agreement shall be cumulative and in addition to any other remedies
provided at Law or in equity. 17.9 Further Documents.

Each Party hereto agrees to execute such further documents and take such further steps as may be
reasonably necessary or desirable to effectuate the purposes of this Agreement. 17.10 Forms.

The Parties recognize that, during the Term of this Agreement, a Purchase Order acknowledgment form
or similar routine document (collectively, "Forms") may be used to implement or administer
provisions of this Agreement. The Parties agree that the terms of this Agreement shall govern and
control in the event of any conflict between terms of this Agreement and the terms of such Forms,
and any additional or different terms contained in such Forms shall not apply to this Agreement.
-75-

Source: UPJOHN INC, 10-12G, 1/21/2020

17.11 Headings; Interpretation.
<!-- page 80 -->
(a) The captions in this Agreement are for convenience only and shall not be considered a part of or
affect the construction or interpretation of any provision of this Agreement.

(b) The definitions in Section 1 shall apply equally to both the singular and plural forms of the
terms defined.

(c) Unless the context of this Agreement otherwise requires:

(i) (A) words of any gender include each other gender and neuter form; (B) words using the singular
or plural number also include the plural or singular number, respectively; (C) derivative forms of
defined terms will have correlative meanings; (D) the terms "hereof," "herein," "hereby," "hereto,"
"herewith," "hereunder" and derivative or similar words refer to this entire Agreement; (E) the
terms "Section" and "Attachment" refer to the specified Section or Attachment of this Agreement and
references to "paragraphs" or "clauses" shall be to separate paragraphs or clauses of the Section or
subsection in which the reference occurs; (F) the words "include," "includes" and "including" shall
be deemed to be followed by the phrase "without limitation"; (G) the word "or" shall be disjunctive
but not exclusive; and (H) the word "from" (when used in reference to a period of time) means "from
and including" and the word "through" (when used in reference to a period of time) means "through
and including";

(ii) references to any federal, state, local, or foreign statute or Law shall (A) include all rules
and regulations promulgated thereunder and (B) be to that statute or Law as amended, modified or
supplemented from time to time; and

(iii) references to any Person include references to such Person's successors and permitted assigns,
and in the case of any Governmental Authority, to any Person succeeding to its functions and
capacities.

(d) Whenever this Agreement refers to a number of days, such number shall refer to calendar days
unless Business Days are specified. If any action is to be taken or given on or by a particular
calendar day, and such calendar day is not a Business Day, then such action may be deferred until
the next Business Day.

(e) The phrase "to the extent" shall mean the degree to which a subject or other thing extends, and
such phrase shall not mean simply "if."

(f) The terms "writing," "written" and comparable terms refer to printing, typing and other means of
reproducing words (including electronic media) in a visible form.

(g) All monetary figures shall be in United States dollars unless otherwise specified.

(h) All references to "this Agreement" or any "Facility Addendum" shall include any amendments,
modifications or supplements thereto. -76-

Source: UPJOHN INC, 10-12G, 1/21/2020

17.12 Rules of Construction.
<!-- page 81 -->
The language used in this Agreement shall be deemed to be the language chosen by the Parties to
express their mutual intent. The Parties acknowledge that each Party and its attorney has reviewed
and participated in the drafting of this Agreement and that any rule of construction to the effect
that any ambiguities are to be resolved against the drafting Party, or any similar rule operating
against the drafter of an agreement, shall not be applicable to the construction or interpretation
of this Agreement. 17.13 Counterparts.

This Agreement may be executed in two (2) or more counterparts (including by electronic or .pdf
transmission), each of which shall be deemed an original, but all of which together shall constitute
one and the same instrument. Delivery of any signature page by facsimile, electronic or .pdf
transmission shall be binding to the same extent as an original signature page. 17.14 Amendments.

No provisions of this Agreement shall be deemed waived, amended, supplemented or modified by any
Party, unless such waiver, amendment, supplement or modification is in writing and signed by the
authorized representative of the Party against whom it is sought to enforce such waiver, amendment,
supplement or modification. 17.15 Entire Agreement.

This Agreement, the Separation Agreement, the other Ancillary Agreements, including any related
annexes, exhibits, schedules and attachments, as well as any other agreements and documents referred
to herein and therein, shall together constitute the entire agreement between the Parties relating
to the transactions contemplated hereby and supersede any other agreements, whether written or oral,
that may have been made or entered into by or among any of the Parties or any of their respective
Affiliates relating to the transactions contemplated hereby.

[Signature Page Follows] -77-

Source: UPJOHN INC, 10-12G, 1/21/2020
<!-- page 82 -->
IN WITNESS WHEREOF, the Parties hereto have caused this Agreement to be duly executed and delivered
as of the date first written above. UPJOHN INC. PFIZER INC.

By: By: Name: Name: Title: Title:

[Signature Page to Manufacturing and Supply Agreement]

Source: UPJOHN INC, 10-12G, 1/21/2020
