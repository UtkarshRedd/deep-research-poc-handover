# Which agreement in the corpus was entered into between Holiday RV Superstores, Inc. and...

*Question:* Which agreement in the corpus was entered into between Holiday RV Superstores, Inc. and Affinity Group, Inc.? Give its title and date.

## Identify agreement between Holiday RV Superstores, Inc. and Affinity Group, Inc.

The document lists Holiday RV Superstores, Inc. d/b/a Recreation USA ("Company") and Affinity Group, Inc. [uncited] ("AGI") as parties to the agreement. [dac76ece63f3755d p.1] The agreement is made as of the 20th day of March 2002, by and between Holiday RV Superstores, Inc., d/b/a Recreation USA (the "Company") and Affinity Group, Inc. [uncited] ("AGI"). [dac76ece63f3755d p.1]

## Extract title and date

[DROPPED: claim s2.1 could not be verified against its cited source.] It was entered into between Holiday RV Superstores, Inc. and Affinity Group, Inc. on 2002-03-20. [dac76ece63f3755d p.1]

## Verification appendix

Claims: 6 · supported: 3 · partially: 0 · dropped: 1 · gaps: 2 · tier-1 support rate: 0.75

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  | no evidence cited |
| s1.2 | s1 | keep | 1.00 | e3→[dac76ece63f3755d p.1] |  |
| s1.3 | s1 | gap |  |  | no evidence cited |
| s1.4 | s1 | keep | 1.00 | e4→[dac76ece63f3755d p.1] |  |
| s2.1 | s2 | drop | 0.00 | e1→[dac76ece63f3755d p.1] |  |
| s2.2 | s2 | keep | 1.00 | e2→[dac76ece63f3755d p.1] |  |

### Evidence

- e1 [dac76ece63f3755d p.1 L2-2] drop (0.0): "# ENDORSEMENT AGREEMENT"
- e2 [dac76ece63f3755d p.1 L6-6] keep (1.0): "| Agreement Date | 2002-03-20 |"
- e3 [dac76ece63f3755d p.1 L7-7] keep (1.0): "| Parties | Holiday RV Superstores, Inc. d/b/a Recreation USA ("Company"); Affinity Group, Inc. ("AGI"); Company and AGI (each a "Party" and collectively the "Parties") |"
- e4 [dac76ece63f3755d p.1 L14-18] keep (1.0): "This Agreement is made as of the 20th day of March 2002, by and between Holiday RV Superstores, Inc., d/b/a Recreation USA (the "Company"), a Delaware corporation having its principal office at 200 East Broward Boulevard, Suite 920, Ft. Lau…"
