<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 1997-12-19 |
| Parties | SABCO RACING, INC. ("Sabco"); Prolong Super Lubricants ("Prolong") |
| Source | CUAD v1 / PROLONGINTERNATIONALCORP_03_23_1998-EX-10.16-SPONSORSHIP AGREEMENT |

CONFIDENTIAL PORTIONS OMITTED

EXHIBIT 10.16

[LOGO OF TEAM SABCO APPEARS HERE]

SPONSORSHIP AGREEMENT

THIS SPONSORSHIP AGREEMENT (hereinafter the "Agreement) is made and entered into this 19th day of
December 1997, by and between SABCO RACING, INC., a North Carolina corporation with a place of
business in Iredell County, North Carolina (hereinafter Sabco), and Prolong Super Lubricants,
Anaheim, Calif. (Hereinafter to be referred to as "Prolong");

WITNESSETH:

WHEREAS, Sabco is engaged in the business of operating NASCAR Winston Cup Series race cars and
wishes to provide advertising space and advertising, promotional and marketing assistance to
Prolong; and

WHEREAS, Prolong desires to become a major associate sponsor of all three Sabco entries during the
1998, 1999 and year-2000 NASCAR Winston Cup Series racing seasons. These entries shall mean the
Sabco No. 40, all NASCAR Winston Cup Series races during this three-year period; the Sabco No. 42,
all NASCAR Winston Cup Series races during this three-year period; and Sabco No. 46, all NASCAR
Winston Cup Series races during this three-year period. Prolong shall use its sponsorship of the
Sabco entries for advertising, promoting and marketing itself. WHEREAS, the parties desire to set
forth in this Agreement their respective rights and obligations;

NOW, THEREFORE, in consideration of the mutual promises and agreements set forth herein, and for
other good and valuable consideration, the parties hereto agree as follows:

1. Term. The term of this Agreement shall commence with the first race ----- of the 1998 Winston Cup
season and shall continue until the final race of the year-2000 Winston Cup season.

2. Services to be provided by Sabco. Sabco shall perform the following
--------------------------------- services for Prolong during the term hereof:

A. Drivers. The drivers for the 33 Winston Cup events to be held -------- during the 1998 season in
which Prolong is an associate sponsor shall be Sterling Marlin (40), Joe Nemechek (42) and Wally
Dallenbach Jr. (46), unless due to injury or for some unforeseeable reason, either is unable to
drive, in which event Sabco shall choose a substitute driver to drive their respective
Sabco/Prolong-sponsored entry. For the duration of this agreement, Sabco reserves the right to
substitute or replace any of the aforementioned drivers listed without prior notice to Prolong or
prior approval from Prolong.

B. Decal location. Sabco will designate Prolong as an associate sponsor --------------- on its No.
40, No. 42 and No. 46 Winston Cup race cars in the aforementioned 33 events. Sabco shall cause each
car to be painted with paint schemes approved by each's primary sponsor and shall cause to display
Prolong associate sponsor decal signage upon the middle side panel (between car number and rear
tire; both sides of car) with dimensions of approximately 6

inches high by 16 inches long. In addition, Sabco shall provide, subject to Prolong's approval,
drive, pit crew, team uniforms, team pit equipment, team race car transporter, show car and show car
transporter bearing prominent Prolong associate sponsor identification as well as team pit equipment
with size and placement commensurate with level of sponsorship

3. Driver Appearances. Sabco shall provide unto Prolong five aggregate ------------------ driver
appearances (2) two-hours each at no fee. Prolong shall be responsible for all first class travel
expenses relating to each driver appearance, i.e. hotel, airfare, meals, etc. Additional appearances
by Sabco drivers shall be at the discounted rate of [ * ] ($[ * ]) Dollars per day per driver, [ *
].

Sabco shall further provide the services of each driver for one free day for commercial use (up to
six hours each) for still photo shoot, TV and radio/commercial production. Prolong shall be
responsible for all first class travel expenses relating to each driver appearance, i.e. hotel,
airfare, meals, etc.

All Sabco drivers, while under contract with Team SABCO, shall allow their likeness, voice, picture
and signature to be used for commercial purposes endorsing Prolong at no additional costs during the
term of this agreement.

4. Compensation. Prolong agrees to pay unto Sabco the sum [ * ] [ * ] ------------ Dollars ($[ * ])
for services to be provided by Sabco over this three year period of 1998, 1999 and year-2000. This
sponsorship fee of $ [ * ] shall be
<!-- page 2 -->
paid to Sabco in the following installments: Year One (1998): $ [ * ] (four equal installments of $
[ * ] to be paid on 3/15/98, 6/15/98, 8/15/98 and 10/15/98); Year Two (1999): $ [ * ] (four equal
installments of $ [ * ] to be paid on 3/15/99, 6/15/99, 8/15/99 and 10/15/99); Year Three
(year-2000): $ [ * ] (four equal installments of $ [ * ] to be paid on 3/15/2000,
6/15/2000,8/15/2000 and 10/15/2000).

5. Show Car. Sabco agrees to provide at no expense to Prolong for its use -------- in promoting its
sponsorship, five (5) free show car appearance days whereas Prolong can deem which of the Sabco show
cars to use. This shall mean that Prolong may schedule any combination of Sabco's three show cars
(based on availability) not to exceed a total of five show days (travel days are considered a "show
date"). Sabco will provide transportation of show car and will provide an attendant to stay with the
car during its display period. For any show car appearance requested by Prolong over and above the
five (5) free appearances, Sabco will make available unto Prolong a show car at a discounted rate of
[ * ] Dollars ($ [ * ]) per day. All travel days to and from the site of a show car appearance, as
well as the actual day upon which show car is on display will be charged as a "show date". It is
further understood that the parties will agree in advance upon a schedule of places and events for
the show car to be displayed at such times as will not interfere with Sabco's racing schedule.

6. Media, Public Relations and Sponsor Communications. Sabco will use its
-------------------------------------------------- best efforts to obtain favorable exposure for
Prolong and will be available to assist Prolong with public relations activities to a reasonable
extent. This shall include making members of Sabco available for media interviews, press conferences
or other public relations activity, as reasonably requested by Prolong, at or near race sites on
dates Sabco is at race sites pursuant to their obligations hereunder. Sabco shall provide at its
expense a staff member to handle race team's media and public relations needs and shall cause
Prolong to receive prominent mention and display within press kits featuring the Sabco No. 40, 42
and 46 race cars. In each of the 1998, 1999 and year-2000 races in which Prolong is designated as an
associate sponsor, Sabco shall fax to Prolong officers on the Monday following the race, race
results and a summary of the prior weekend activities.

* CONFIDENTIAL PORTIONS OMITTED AND FILED SEPARATELY WITH THE COMMISSION.

7. Exclusivity. During the term of this Agreement, Sabco will not ----------- represent or accept as
a primary, secondary, or associate sponsor any other company reasonably deemed to be competitive
with Prolong products.

8. Confidentiality. During and after the term of this Agreement, each --------------- party hereto,
its employees and agents agree not to disclose any business results, trade practices or other
business information of the other party, its employees or agents, which they may learn as a result
of the performance of this Agreement.

9. Indemnification. --------------- A. Sabco shall indemnify, defend and hold harmless Prolong, its
officers, directors, employees and representatives from and against any and all losses, claims,
suits, damages, liabilities, costs and expenses, including attorney fees and count costs incurred by
any of them arising out of:

(i) Any breach of any warrant made by Sabco herein;

(ii) Any acts done or words spoken

(iii) Any claims by any persons arising from acts or omissions of any nature by Sabco, its employees
or agents, including but not limited to, claims arising during the court of competition or practice
in the performance of this Agreement.

B. Prolong shall indemnify, defend and hold harmless Sabco, its officers, directors, employees and
representatives, from and against any and all losses, claims, suits, damages, liabilities, costs and
expenses, including attorney fees and court costs incurred by any of them, arising out of:

(i) The use of any logo, design or materials furnished to Sabco by Prolong hereunder;

(ii) Any breach of any warranty made by Prolong herein;

(iii) Any acts done or words spoken by Prolong, its officers, directors, agents, employees and
representatives;

(iv) Any claims by any persons arising from acts of omissions of any nature by Prolong, its
officers, directors, agents, employees or representatives, including, but not limited to, claims
arising under any product liability theory with respect to Prolong's products.

10. Nature of Relationship. The parties expressly acknowledge and agree ---------------------- that
Sabco is acting as an independent contractor. Each party is responsible for all taxes relating to
its operation, including payroll taxes for its employees, and nothing in this Agreement is intended
to create a relationship, express or
<!-- page 3 -->
implied, of employer-employee between Sabco and Prolong. Except as expressly authorized herein,
neither party may contract for or otherwise obligate the other party without the party's prior
express written consent.

11. Insurance. Sabco shall provide at its expense and maintain throughout --------- the term of this
Agreement and any option period spectator liability insurance in an amount not less than $1 million
single limit coverage with respect to any liability relating to the activities of Sabco in the
performance of this Agreement. Sabco shall, within 90 days of the execution of this Agreement,
supply Prolong with a copy of such policy of insurance or a certificate thereof, and such policies
shall be cancelable only upon 10 days written notice to Prolong.

12. Notices, Statements and Payments. All notices, statements and --------------------------------
payments required under this Agreement shall be sent to the parties at the following addresses:

SABCO RACING, INC. 114 Meadow Hill Circle Mooresville, North Carolina 28115 Attn: Felix Sabates

PROLONG SUPER LUBRICANTS 1210 North Barsten Way Anaheim, California 92806 Attn: Jerry Grant

All notices, statements and payments shall be deemed delivered when deposited in the United States
mail postage prepaid, when hand delivered if delivered personally, when telecopied if the sender's
telecopier confirms transmission (with respect to notices and statements) or when wire transferred
in federal funds (with respect to payments).

13. Waivers. A waiver of any provision of this Agreement shall be -------- enforceable only if the
waiver is in writing signed by the party against whom the waiver is sought to be enforced. A failure
by a party at any time to exercise any rights hereunder shall not constitute a waiver of such rights
at another time.

14. Entire Agreement. This Agreement contains the entire agreement and ----------------
understanding between the parties with respect to the subject matter hereof and supersedes all prior
written or oral agreements between them with respect to the subject matter hereof.

15. Assignment. This Agreement may not be assigned by either party ---------- without the prior
written consent of the other party.

16. Significance of Headings. Paragraph headings contained herein are ------------------------
solely for the purpose of aiding the speedy location of subject matter and are not in any sense to
be given weight in the construction of this Agreement. Accordingly, in case of any question with
respect to the construction of this Agreement, it is to be construed as though paragraph headings
had been omitted.

17. Governing Law, Jurisdiction and Venue. This Agreement shall be
------------------------------------- governed by and construed in accordance with the substantive
laws of the State of North Carolina. The parties hereto hereby submit to jurisdiction and venue in
any state or federal court located in North Carolina as well as any other jurisdiction having venue
and competent jurisdiction of any law suit arising out of or relating to this Agreement; provided,
however, if any

proceedings are instituted in a jurisdiction other than North Carolina, any party may remove such
proceeding to any State or Federal Court in North Carolina.

18. Further Execution; Cooperation. The parties agree to execute and ------------------------------
deliver such further agreements, instruments and other documents as the other party may reasonably
deem necessary to effectuate the purposes and provisions of this Agreement. The parties further
agree to cooperate with each other in any manner reasonably requested by the other party to
effectuate the purposes and provisions of this Agreement.

19. Counterparts. This Agreement may be executed in counterparts and the ------------ signature page
of any party, and photocopies and facsimiles thereof, may be appended to any counterpart and when so
appended shall constitute an original signature.

IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be executed by their duly
elected officers as of the day and year first above written.
<!-- page 4 -->
SABCO RACING, INC. ATTEST: BY /s/ Armando Fitz -------------------------------- /s/ Jerry Grant
Armando Fitz - Vice President Business Operations - -------------------------- Jerry Grant -
Secretary

PROLONG SUPER LUBRICANTS ATTEST:

BY /s/ Elton Alderman /s/ ILLEGIBLE --------------------------------- - --------------------------
Elton Alderman - President Secretary
