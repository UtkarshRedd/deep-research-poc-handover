"""Phase 7: provenance gate (deterministic) and tier-2 grouped review (scripted verifier)."""
import json
import uuid
from dataclasses import replace
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage

from dr.config import DEFAULT
from dr.eval.metrics import hallucination_gate
from dr.evidence import EvidenceBank
from dr.graph import Pipeline
from dr.ingest.load import load_dir
from dr.llm import get_scripted_llm
from dr.models import Claim, OutlineSection, Report, VerifyResult
from dr.trace import Trace
from dr.verify.provenance import (
    cluster_all,
    clusters_for,
    shingles,
    signature,
    similarity,
    source_clusters,
)
from dr.verify.report import finalize_report, verify_report
from dr.verify.tier2 import (
    _perturb,
    group_claims,
    render_group,
    seeded_check,
    select_claims,
    verify_tier2,
)
from dr.workspace import Workspace

SAMPLE = Path(__file__).resolve().parents[1] / "data" / "sample_docs"
QUOTE = "Borrower shall maintain a Leverage Ratio not exceeding 3.50 to 1.00."
AMEND = "Section 3 is amended to read: Borrower shall maintain a Leverage Ratio not exceeding 4.00 to 1.00."


@pytest.fixture()
def ws(tmp_path):
    return Workspace.materialize(load_dir(SAMPLE), tmp_path / "ws")


@pytest.fixture()
def ids(ws):
    by_title = {m.title: d for d, m in ws.manifest.items()}
    return {"a": by_title["Credit Agreement — Acme Industrial LLC"],
            "c": next(d for t, d in by_title.items() if "conformed" in t),
            "m": next(d for t, d in by_title.items() if t.startswith("First Amendment"))}


@pytest.fixture()
def bank(ws, ids):
    b = EvidenceBank(ws)
    b.add(ids["a"], 17, 17, QUOTE, "original")          # e1
    b.add(ids["c"], 15, 15, QUOTE, "conformed copy")     # e2 (same words, other document)
    b.add(ids["m"], 9, 9, AMEND, "amendment")            # e3
    return b


def verdicts(*pairs):
    return AIMessage(content=json.dumps({"verdicts": [{"claim_id": cid, "verdict": v, "reason": f"{v} because"} for cid, v in pairs]}))


# --------------------------------------------------------------------------- provenance

GOLDEN_DOCS = Path(__file__).resolve().parents[1] / "data" / "golden_docs"


def test_minhash_clusters_conformed_copies_but_not_templated_siblings(tmp_path):
    """Calibrated on the synthetic corpus: a conformed copy (same parties, >= 0.97) joins its
    original; agreements for different borrowers built from the same template (~0.92) do not."""
    assert shingles("a b c d e f", 5) == shingles("a b c d e f", 5) and len(shingles("a b c d e f", 5)) == 2
    ws = Workspace.materialize(load_dir(GOLDEN_DOCS), tmp_path / "g")
    by = {m.title: d for d, m in ws.manifest.items()}
    orig = by["Credit Agreement — Brightwater Renewables"]
    conf = next(d for t, d in by.items() if t.startswith("Credit Agreement — Brightwater Renewables (Conf"))
    other = by["Credit Agreement — Halvorsen Marine Holdings"]
    amend = next(d for t, d in by.items() if t.startswith("First Amendment") and "Brightwater" in t)
    so, sc, sh = (signature(ws, d) for d in (orig, conf, other))
    assert similarity(so, sc) >= 0.95 and 0.85 <= similarity(so, sh) < 0.95
    cl = clusters_for(ws, [orig, conf, other, amend])
    assert cl[orig] == cl[conf] and cl[orig] != cl[other] and cl[orig] != cl[amend]
    full = cluster_all(ws)
    assert full[orig] == full[conf] and full[orig] != full[other]
    assert source_clusters([orig, conf], cl) == 1 and source_clusters([orig, other], cl) == 2 and source_clusters([orig, "zzz"], cl) == 2
    assert signature(ws, orig) is signature(ws, orig)                 # cached


def test_same_parties_rule_on_the_tiny_sample(ws, ids):
    """The 3-doc sample is too small for shingle similarity (the conformed copy drops a third of
    its lines: ~0.5), so only the same-parties rule with a low bar joins it to the original."""
    a, c, m = ids["a"], ids["c"], ids["m"]
    assert clusters_for(ws, [a, c, m])[a] != clusters_for(ws, [a, c, m])[c]        # default thresholds: distinct
    loose = replace(DEFAULT, verify=replace(DEFAULT.verify, NEAR_DUP_SAME_PARTIES_THRESHOLD=0.4))
    cl = clusters_for(ws, [a, c, m], loose)
    assert cl[a] == cl[c] != cl[m]                                                  # same parties + 0.5 similarity


def test_verify_report_marks_near_duplicate_sources(ws, bank, ids):
    loose = replace(DEFAULT, verify=replace(DEFAULT.verify, NEAR_DUP_SAME_PARTIES_THRESHOLD=0.4))
    sec = OutlineSection(section_id="s1", title="t", intent="i", evidence_ids=["e1", "e2", "e3"])
    claims = [Claim(claim_id="s1.1", section_id="s1", text="Cap 3.50.", evidence_ids=["e1", "e2"]),
              Claim(claim_id="s1.2", section_id="s1", text="Cap raised to 4.00.", evidence_ids=["e1", "e3"]),
              Claim(claim_id="s1.3", section_id="s1", text="[GAP] nothing", evidence_ids=[], is_gap=True)]
    results = verify_report(ws, bank, Report(question="q", title="t", sections=[sec], claims=claims), loose)
    by = {r.claim_id: r for r in results}
    assert by["s1.1"].source_clusters == 1 and "near-duplicates" in by["s1.1"].note
    assert by["s1.2"].source_clusters == 2 and by["s1.2"].note is None
    assert by["s1.3"].source_clusters is None


# --------------------------------------------------------------------------- tier 2 plumbing

def test_select_group_and_render(ws, bank):
    claims = [Claim(claim_id="s1.1", section_id="s1", text="a", evidence_ids=["e1"]),
              Claim(claim_id="s1.2", section_id="s1", text="b", evidence_ids=["e1", "e3"]),
              Claim(claim_id="s2.1", section_id="s2", text="c", evidence_ids=["e2"]),
              Claim(claim_id="s2.2", section_id="s2", text="d", evidence_ids=["e3"]),
              Claim(claim_id="s2.3", section_id="s2", text="[GAP] e", evidence_ids=[], is_gap=True)]
    report = Report(question="q", title="t", sections=[], claims=claims)
    results = [VerifyResult(claim_id="s1.1", tier1="keep", tier1_score=1.0),
               VerifyResult(claim_id="s1.2", tier1="keep", tier1_score=1.0),
               VerifyResult(claim_id="s2.1", tier1="truncate", tier1_score=0.5),
               VerifyResult(claim_id="s2.2", tier1="drop", tier1_score=0.1),
               VerifyResult(claim_id="s2.3", tier1="gap", tier1_score=None)]
    none = replace(DEFAULT, verify=replace(DEFAULT.verify, TIER2_SAMPLE_RATE_CLEAN=0.0))
    assert [c.claim_id for c in select_claims(report, results, none)] == ["s1.2", "s2.1"]   # multi-source + truncate; never drop/gap
    full = replace(DEFAULT, verify=replace(DEFAULT.verify, TIER2_SAMPLE_RATE_CLEAN=1.0))
    assert [c.claim_id for c in select_claims(report, results, full)] == ["s1.1", "s1.2", "s2.1"]
    groups = group_claims(claims[:4], size=8)
    assert [[c.claim_id for c in g] for g in groups] == [["s1.1", "s1.2"], ["s2.1", "s2.2"]]      # split by section
    assert len(group_claims(claims[:2] * 5, size=3)) == 4
    text = render_group(ws, bank, claims[:2])
    assert "[s1.1] CLAIM: a" in text and 'EVIDENCE e1 (' in text and "CONTEXT L" in text and "17| " in text


def test_verify_tier2_applies_verdicts_and_never_overrides_drop(ws, bank, tmp_path):
    claims = [Claim(claim_id="s1.1", section_id="s1", text="Cap 3.50.", evidence_ids=["e1", "e2"]),
              Claim(claim_id="s1.2", section_id="s1", text="Cap 9.99.", evidence_ids=["e1", "e3"]),
              Claim(claim_id="s1.3", section_id="s1", text="dropped", evidence_ids=["e1"])]
    report = Report(question="q", title="t", sections=[], claims=claims)
    results = [VerifyResult(claim_id="s1.1", tier1="keep", tier1_score=1.0),
               VerifyResult(claim_id="s1.2", tier1="keep", tier1_score=1.0),
               VerifyResult(claim_id="s1.3", tier1="drop", tier1_score=0.0)]
    llm = get_scripted_llm([verdicts(("s1.1", "supported"), ("s1.2", "unsupported"))])
    tr = Trace(tmp_path / "t.jsonl", "t")
    verify_tier2(ws, bank, report, results, llm=llm, trace=tr)
    by = {r.claim_id: r for r in results}
    assert by["s1.1"].tier2 == "supported" and by["s1.2"].tier2 == "unsupported" and "tier 2 unsupported" in by["s1.2"].note
    assert by["s1.3"].tier1 == "drop" and by["s1.3"].tier2 == "skipped"
    assert hallucination_gate(results) is True
    assert len(llm.seen) == 1 and "[s1.3]" not in llm.seen[0][-1].content
    ev = [json.loads(ln) for ln in (tmp_path / "t.jsonl").read_text().splitlines()]
    assert ev[-1]["stage"] == "verify_tier2" and ev[-1]["n_checked"] == 2 and ev[-1]["n_unsupported"] == 1
    # a failed verifier call leaves claims skipped, never flagged
    results2 = [VerifyResult(claim_id="s1.1", tier1="keep", tier1_score=1.0), VerifyResult(claim_id="s1.2", tier1="keep", tier1_score=1.0)]
    verify_tier2(ws, bank, report, results2, llm=get_scripted_llm([AIMessage(content="no"), AIMessage(content="no")]))
    assert all(r.tier2 == "skipped" for r in results2)
    off = replace(DEFAULT, verify=replace(DEFAULT.verify, TIER2_ENABLED=False))
    assert verify_tier2(ws, bank, report, results2, llm=get_scripted_llm([]), config=off) is results2


def test_finalize_report_flags_tier2_in_markdown_and_appendix(ws, bank):
    sec = OutlineSection(section_id="s1", title="Covenant", intent="i", evidence_ids=["e1", "e3"])
    claims = [Claim(claim_id="s1.1", section_id="s1", text="The cap is 3.50 to 1.00.", evidence_ids=["e1"]),
              Claim(claim_id="s1.2", section_id="s1", text="The amendment lowers the cap.", evidence_ids=["e3"])]
    report = Report(question="q", title="t", sections=[sec], claims=claims)
    full = replace(DEFAULT, verify=replace(DEFAULT.verify, TIER2_SAMPLE_RATE_CLEAN=1.0))
    llm = get_scripted_llm([verdicts(("s1.1", "supported"), ("s1.2", "unsupported"))])
    report, _results = finalize_report(ws, bank, report, full, llm=llm)
    md = report.markdown
    assert "The amendment lowers the cap. [unsupported by review]" in md and "[unsupported by review]" not in md.split("amendment")[0]
    assert "tier 2 checked: 2 (unsupported 1, partially 0)" in md and "| s1.2 | s1 | keep | 1.00 | unsupported | 1 |" in md
    assert json.loads((ws.root / "verify.json").read_text())[1]["tier2"] == "unsupported"


def test_seeded_check_measures_flag_rate(ws, bank):
    assert _perturb("not exceeding 3.50 to 1.00") == "not exceeding 8.00 to 1.00"
    assert _perturb("Borrower shall maintain it") == "Borrower shall not maintain it"
    assert _perturb("plain words only").startswith("It is not the case that")
    script = [verdicts(("t.1", "supported"), ("t.2", "supported"), ("t.3", "unsupported")),     # group t
              verdicts(("f.1", "unsupported"), ("f.2", "partially"), ("f.3", "unsupported"))]   # group f
    out = seeded_check(ws, bank, get_scripted_llm(script), n=3)
    assert out["planted"] == 3 and out["flagged"] == 3 and out["flag_rate"] == 1.0 and out["false_flags"] == 1
    assert len(out["details"]) == 6


# --------------------------------------------------------------------------- graph

def tc(name, args):
    return {"name": name, "args": args, "id": f"call_{uuid.uuid4().hex[:8]}", "type": "tool_call"}


def ai(*calls):
    return AIMessage(content="", tool_calls=list(calls))


def test_pipeline_runs_tier2_only_when_a_verifier_is_in_the_roster(ids, tmp_path):
    docs = load_dir(SAMPLE)
    a = ids["a"]
    cfg = replace(DEFAULT, agents=replace(DEFAULT.agents, RESEARCH_MIN_CALLS=1, RESEARCH_MAX_CALLS=6),
                  verify=replace(DEFAULT.verify, TIER2_SAMPLE_RATE_CLEAN=1.0))

    def llms(with_verifier: bool):
        d = {
            "researcher": get_scripted_llm([ai(tc("grep", {"pattern": "Leverage"})),
                                            ai(tc("add_evidence", {"doc_id": a, "start_line": 17, "end_line": 17, "quote": QUOTE, "note": "cap"}),
                                               tc("submit", {"sub_question": "q", "answer": "3.50 [e1]", "evidence_ids": ["e1"]}))]),
            "writer": get_scripted_llm([
                AIMessage(content=json.dumps({"sections": [{"section_id": "s1", "title": "Covenant", "intent": "ratio"}]})),
                AIMessage(content=json.dumps({"sections": [{"section_id": "s1", "title": "Covenant", "intent": "ratio", "evidence_ids": ["e1"]}]})),
                AIMessage(content="The cap is 3.50 to 1.00 {{CITE:e1}}."),
            ]),
        }
        if with_verifier:
            d["verifier"] = get_scripted_llm([verdicts(("s1.1", "partially"))])
        return d

    s1 = Pipeline(cfg, llms(True)).run("cap?", docs, root=tmp_path / "with")
    assert s1["verify"][0]["tier2"] == "partially" and "[partially supported by review]" in s1["report_md"]
    assert any('"stage": "verify_tier2"' in ln for ln in (tmp_path / "with" / "trace.jsonl").read_text().splitlines())
    s2 = Pipeline(cfg, llms(False)).run("cap?", docs, root=tmp_path / "without")
    assert s2["verify"][0]["tier2"] == "skipped" and "by review" not in s2["report_md"]


def test_perturb_targets_substantive_values_not_section_numbers():
    assert _perturb("Section 7.1 Maximum Leverage Ratio. The Borrower shall not permit the ratio to exceed 4.00 to 1.00.") == \
        "Section 7.1 Maximum Leverage Ratio. The Borrower shall not permit the ratio to exceed 9.00 to 1.00."
    assert _perturb("Section 2.3 The Applicable Margin is 2.25% per annum.") == "Section 2.3 The Applicable Margin is 5.50% per annum."
    assert _perturb("1.1 The Revolving Commitment is $25,000,000 as of 2025-02-14.") == "1.1 The Revolving Commitment is $25,001,000 as of 2025-02-14."
    assert _perturb("Effective Date: 2025-02-14") == "Effective Date: 2025-02-29"
    assert _perturb("terminate upon ninety (90) days written notice") == "terminate upon ninety (181) days written notice"
    assert _perturb("Section 7.7 applies to Schedule 3 items") == "Section 7.7 applies to Schedule 7 items"
