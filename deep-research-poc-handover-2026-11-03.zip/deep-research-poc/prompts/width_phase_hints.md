## early
Start wide: different clues, different documents.
## mid
Narrow: read the highest-count documents around the matches; save evidence with add_evidence.
## late
Confirm and fill gaps; check for amendments or later versions; then submit.
## deadline
About {remaining_s} s remain; submit before time runs out.
