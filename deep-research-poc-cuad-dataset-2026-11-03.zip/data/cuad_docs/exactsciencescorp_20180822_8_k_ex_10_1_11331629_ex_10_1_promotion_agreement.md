<!-- page 1 -->
# COLOGUARD® PROMOTION AGREEMENT
| Field | Value |
|---|---|
| Document Type | Promotion Agreement |
| Agreement Date | 2018-08-21 |
| Parties | Pfizer Inc. (“Pfizer”); Exact Sciences Corporation ("Exact") ("Party" and collectively as the "Parties") |
| Source | CUAD v1 / ExactSciencesCorp_20180822_8-K_EX-10.1_11331629_EX-10.1_Promotion Agreement |

Exhibit 10.1 COLOGUARD® PROMOTION AGREEMENT BY AND BETWEEN EXACT SCIENCES CORPORATION AND PFIZER
INC. August 21, 2018

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 2 -->
TABLE OF CONTENTS Page 1. DEFINITIONS 1 2. GOVERNANCE 10 2.1 Joint Steering Committee 10 2.2 Joint
Operations Committee 13 2.3 Joint Review Committee 14 2.4 Finance Representative 15 2.5 Alliance
Managers 15 2.6 Compliance Managers 16 3. APPOINTMENT; PRODUCT OWNERSHIP; MARKETING AND SALES 17 3.1
Appointment 17 3.2 Responsibility for Product 19 3.3 Annual Marketing Plan 26 3.4 Sales Promotion,
Detailing Efforts and IDN Promotion 27 3.5 Pfizer Investment and Support 28 3.6 Exact Investment and
Support 29 3.7 Changes in Shared M&P Expenses 30 4. ACCOUNTING 30 4.1 Responsibility for Shared M&P
Expenses 30 4.2 Promotion Fee 31 4.3 Fee Statements and Payments 33 4.4 Taxes and Withholding 34 4.5
No Partnership Provision 35 4.6 Payments; Currency 35 4.7 Maintenance of Records; Audits 35 5.
REPRESENTATIONS, WARRANTIES AND COVENANTS 37 5.1 Mutual Representations and Warranties 37 5.2
Representations and Warranties of Exact 38 5.3 Covenants 39 5.4 Compliance with Law and Ethical
Business Practices 40 5.5 Notice of Investigations 43 5.6 Representation by Legal Counsel 43 5.7 No
Inconsistent Agreements 43 5.8 Disclaimer 44 6. INDEMNIFICATION; LIMITATION OF LIABILITY AND
INSURANCE 44 6.1 Indemnification 44 6.2 Insurance Requirements 45 6.3 Limitation of Liability 46

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 3 -->
7. CONFIDENTIALITY; PUBLICITY 46 7.1 Confidentiality 46 7.2 Authorized Disclosure and Use 47 7.3
Certain Regulatory Filings 47 7.4 Public Announcements 47 7.5 Use of Names 48 8. TERM AND
TERMINATION 48 8.1 Term 48 8.2 Renewal 48 8.3 Termination for Cause 48 8.4 Termination Without Cause
49 8.5 Mutual Termination 49 8.6 Termination for Change of Control 49 8.7 Royalty Upon Expiration 49
8.8 Consequences of Termination 50 8.9 Survival of Certain Obligations 50 9. MISCELLANEOUS 51 9.1
Interpretation 51 9.2 Assignment 51 9.3 Further Actions 51 9.4 Force Majeure 51 9.5 Notices 52 9.6
Amendment 53 9.7 Waiver 53 9.8 Severability 53 9.9 Descriptive Headings 53 9.10 Governing Law 53
9.11 Dispute Resolution 53 9.12 Entire Agreement of the Parties 54 9.13 Independent Contractors 54
9.14 No Legal Advice 54 9.15 Counterparts 54 EXHIBITS Exhibit 1.24 - Cost of Sales Exhibit 1.39 -
Exact Trademarks Exhibit 2.2(c)(iv) - Calendar Quarter Performance Metrics Exhibit 3.2(c)(i) - Sales
Deployment Plan Exhibit 3.3(b) - Annual Marketing Plan Outline Exhibit 3.4(a) - Promotion Fee
Reduction Exhibit 7.4 - Press Release

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 4 -->
Exhibit 8.8(b) - Tail Period Advertising Services ii

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 5 -->
AGREEMENT This Agreement (the "Agreement") is made and entered into as of August 21, 2018 (the
"Effective Date"), by and between Pfizer Inc. ("Pfizer"), a Delaware corporation, with a principal
place of business at 235 East 42nd Street, New York, New York 10017 and Exact Sciences Corporation
("Exact"), a Delaware corporation with a principal place of business at 441 Charmany Drive, Madison,
Wisconsin 53719. Pfizer and Exact may each be referred to herein individually as a "Party" and
collectively as the "Parties". WHEREAS, Exact has marketing and proprietary rights to the Product
(as defined below) in the United States; WHEREAS, Pfizer has sales, marketing, analytical, and other
core capabilities and competencies to promote and market branded prescription products; and WHEREAS,
Exact desires to work with Pfizer to leverage Pfizer's expertise in sales, marketing, analytical,
and other core capabilities and competencies for the Product in the United States and Pfizer desires
to provide such expertise, including through its Sales Representatives, and to invest in Exact's
Promotion of the Product in the United States. NOW THEREFORE, in consideration of the mutual
promises and covenants set forth below and other good and valuable consideration, the receipt and
sufficiency of which is hereby acknowledged, the Parties hereby agree as follows: 1. DEFINITIONS.
1.1 "AdvaMed Code" shall have the meaning set forth in Section 3.2(c)(ii). 1.2 "Advertising" shall
mean the paid advertising, planning, purchasing and placement of advertising for a prescription
medical device subject to pre-market approval in the Territory through any means, including
television, print, radio/audio, in-office/placed- based, digital, web, search (SEM/SEO), social
media, mobile and any and all new and emerging media channels for consumers, healthcare institutions
and healthcare providers. 1.3 "Affiliate(s)" shall mean, with respect to any Party, any other Person
which controls, is controlled by or is under common control with such Party. A Person shall be
regarded as in control of another Person if it owns or controls at least fifty percent (50%) of the
equity securities of such other Person entitled to vote in the election of directors (or, in the
case of an entity that is not a corporation, for the election of the corresponding managing
authority); provided, however, that the term "Affiliate" shall not include subsidiaries or other
entities in which a Party or its Affiliates owns a majority of the ordinary voting power necessary
to elect a majority of the board of directors or other governing board, but is restricted from
electing such majority by contract or otherwise, until such time as such restrictions are no longer
in effect. 1.4 "Agreement" shall have the meaning set forth in the preamble. 1

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 6 -->
1.5 "Alliance Manager" shall have the meaning set forth in Section 2.5. 1.6 "Annual Marketing Plan"
shall mean the plan for the Marketing and Promotion of the Product in the Territory for each full or
partial Calendar Year as described in Section 3.3, as prepared and updated from time to time
pursuant to Section 3.3. 1.7 "Annual Supplemental Promotion Fee" shall have the meaning set forth in
Section 4.2(c)(i). 1.8 "Applicable Compliance/Review Policies" shall mean, with respect to Pfizer,
its written Code of Ethics and Professional Conduct and, with respect to Exact, its written Code of
Business Conduct and Ethics, and such policies and standard operating procedures that are adhered to
by such Party in connection with the Product and any payments or services contemplated by this
Agreement, as the same may be amended from time to time. 1.9 "Applicable Law" shall mean any law,
statute, rule, regulation, order, judgment, ordinance, administrative code, decree, directive,
injunction or permit (including Regulatory Approvals) of any court, arbitral body, agency,
department, authority or other instrumentality of any national, state, county, city or other
political subdivision applicable to a Party's activities to be performed under this Agreement. For
the avoidance of doubt, any specific references to any Applicable Law or any portion thereof, shall
be deemed to include all amendments, replacements or successors thereto. 1.10 "Audited Party" shall
have the meaning set forth in Section 4.7(b)(i). 1.11 "Auditing Party" shall have the meaning set
forth in Section 4.7(b)(i). 1.12 "Baseline Laboratory Service Revenue" shall mean, with respect to a
particular Calendar Year during the Term, the amounts set forth in Section 4.2(b). 1.13 "Baseline
M&P Expense" shall have the meaning set forth in Section 3.6. 1.14 "Business Day" shall mean any day
other than a Saturday, Sunday, or a bank or other public holiday in New York, New York, United
States. 1.15 "Calendar Quarter" shall mean the respective periods of three (3) consecutive calendar
months ending on March 31, June 30, September 30 or December 31. 1.16 "Calendar Year" shall mean the
respective periods of twelve (12) calendar months, each such period ending on December 31 of the
applicable year for as long as this Agreement is in effect. 1.17 "Calendar Year Baseline Laboratory
Service Revenue" shall have the meaning set forth in Section 4.2(b). 1.18 "Change of Control" shall
mean, with respect to a Party: (a) the sale of all or substantially all of such Party's assets or
business relating to the subject matter of this Agreement; (b) a merger, reorganization, or
consolidation involving such Party in which the holders of voting securities of such Party
outstanding immediately 2

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 7 -->
prior thereto cease to hold at least fifty percent (50%) of the combined voting power of the
surviving entity or acquiring entity (or its parent) immediately after such merger, reorganization,
or consolidation; or (c) the acquisition of more than fifty percent (50%) of the voting equity
securities of such Party as a result of a single transaction or a series of related transactions.
1.19 "CIA" shall have the meaning set forth in Section 5.4(j). 1.20 "Claims" shall have the meaning
set forth in Section 6.1(a). 1.21 "Compliance Manager" shall have the meaning set forth in Section
2.6. 1.22 "Confidential Information" shall have the meaning set forth in Section 7.1. 1.23
"Co-Promote Field" shall mean those physicians and practices customarily considered primary care or
gastroenterology providers and practices and, subject to Sections 3.1(c)(ii) and 4.2(d), the OB/Gyn
Field, in the Territory. For clarity, if Exact, either through its own Sales Representative or by
agreement with a Third Party, launches the Product in the OB/Gyn Field, the Co-Promote Field shall
not include the OB/Gyn Field. 1.24 "Cost of Sales" shall mean the direct and indirect costs
attributable to sales of the Product Laboratory Services, as calculated in accordance with Exhibit
1.24, and as consistently determined in accordance with GAAP. 1.25 "Debarred/Excluded" shall have
the meaning set forth in Section 5.1(g). 1.26 "Detail" shall mean a customary face-to-face or
non-face-to-face contact of a Sales Representative of a Party with an Eligible Prescriber during
which such Sales Representative makes a presentation of certain of the Product's attributes, such as
describing the FDA-approved indicated uses, safety, effectiveness, or other relevant characteristics
of the Product, in a fair and balanced manner and in accordance with the requirements of this
Agreement and Applicable Law and in a manner that is customary for the purpose of Promoting a
prescription medical device subject to pre-market approval, but excluding: (a) any activities
performed by any Representative other than a Sales Representative who is not conducting a
face-to-face or non-face- to-face sales call, (b) presentations made at conventions or (c) mere
delivery of savings cards, coupons or similar items without discussions with an Eligible Prescriber
about the Product; provided that, such measurement shall be on the same basis as the recording
Party's measurement for its Sales Representatives' detailing of its other medical devices subject to
pre-market approval or prescription pharmaceutical products (as applicable), consistently applied
throughout the Term. For clarity, non- face-to-face contact shall mean e-detailing, video detailing
or other presentation of Promotional Material by a Sales Representative to an Eligible Prescriber
via audio, video, internet, using webex or other similar live conference applications, and in all
instances that allows for real time, detailed and substantive communication between the Sales
Representative and the Eligible Prescriber regarding the Product and would be considered a Detail by
Pfizer for its own products under its own guidelines, but shall exclude any such communications,
such as telephone calls, during which such detailed and visual 3

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 8 -->
exchanges of information do not occur. "Detail," when used as a verb, and "Detailing" shall have
correlative meanings. 1.27 "Disclosing Party" shall have the meaning set forth in Section 7.1. 1.28
"Disputed JOC Matter" shall have the meaning set forth in Section 2.2(d). 1.29 "Disputed JRC Matter"
shall have the meaning set forth in Section 2.3(d). 1.30 "Disputed JSC Matter" shall have the
meaning set forth in Section 2.1(e). 1.31 "Effective Date" shall have the meaning set forth in the
preamble. 1.32 "Eligible Prescriber" shall mean (a) a health care provider who has the authority to
prescribe the Product under Applicable Law and (b) any other health care professional without
prescribing authority but who (i) is reasonably believed to assist with patient care and
reimbursement for healthcare service in the office of a health care provider who has authority to
prescribe the Product under Applicable Law, and (ii) is allowed to receive Promotion. 1.33 "Exact"
shall have the meaning set forth in the preamble. 1.34 "Exact Copyrights" shall mean all statutory
and common law copyrights owned by Exact in and to the Promotional Materials, Advertising materials
or Product Label used in the Territory. 1.35 "Exact House Marks" shall mean the Exact trade name and
logo, including all registrations and applications for registration of any of the foregoing in the
Territory. 1.36 "Exact Indemnitee" shall have the meaning set forth in Section 6.1(b). 1.37 "Exact
JSC Members" shall have the meaning set forth in Section 2.1(a). 1.38 "Exact Patent Rights" shall
mean the Patent Rights owned or controlled by Exact as of the Effective Date. 1.39 "Exact
Sponsorships and Related Activities" shall have the meaning set forth in Section 3.2(d)(i). 1.40
"Exact Trademarks" shall mean (a) the Trademarks listed on Exhibit 1.39 and the registrations
thereof, (b) any pending or future trademark registration applications owned or controlled and used
in connection with or intended for use in connection with the Product in the Territory, (c) any
unregistered trademark rights used in connection with the Product as may exist through use in the
Territory, (d) any current or future modifications or variants of any of the foregoing rights, and
(e) any future Trademarks adopted by Exact or its Affiliates for use in connection with the Product
in the Territory. 1.41 "Excluded Channel" shall have the meaning set forth in Section 4.2(d). 1.42
"Ex-US Commercial Rights" shall have the meaning set forth in Section 3.1(c)(i). 4

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 9 -->
1.43 "Ex-US Commercial Rights Transfer Notice" shall have the meaning set forth in Section
3.1(c)(i). 1.44 "FDA" shall mean the United States Food and Drug Administration or any successor
agency thereto. 1.45 "FD&C Act" shall mean the United States Federal Food, Drug, and Cosmetic Act,
as amended, and the rules and regulations promulgated thereunder. 1.46 "Finance Representative"
shall have the meaning set forth in Section 2.4. 1.47 "First Promotion Fee Period" shall have the
meaning set forth in Section 4.2(c)(i). 1.48 "First Supplemental Promotion Fee" shall have the
meaning set forth in Section 4.2(c)(i). 1.49 "GAAP" shall mean United States generally accepted
accounting principles, consistently applied. 1.50 "Governmental Authority" to be broadly interpreted
and includes: (a) any national, federal, state, local, regional, or foreign government, or level,
branch, or subdivision thereof; (b) any multinational or public international organization or
authority; (c) any ministry, department, bureau, division, authority, agency, commission, or body
entitled to exercise any administrative, executive, judicial, legislative, police, regulatory, or
taxing authority or power; (d) any court, tribunal, or governmental arbitrator or arbitral body; (e)
any government-owned or controlled institution or entity; (f) any enterprise or instrumentality
performing a governmental function; and (g) any political party. 1.51 "Government Official" to be
broadly interpreted, shall mean (a) any elected or appointed government official (e.g., a member of
a ministry of health); (b) any employee or person acting for or on behalf of a government,
government-controlled entity or enterprise performing a governmental function; (c) any political
party, candidate for public office, officer, employee, or person acting for or on behalf of a
political party or candidate for public office; (d) any employee or person acting for or on behalf
of a public international organization (e.g., the United Nations); or (e) any individual who holds
himself or herself out to be the authorized intermediary of any of the foregoing. For clarity,
healthcare providers employed by government-owned hospitals shall be considered Government
Officials. 1.52 "Gross Margin" shall mean Laboratory Services Revenue less Cost of Sales. 1.53
"Gross Margin Percent" shall mean the percentage as determined by multiplying (a) the fractional
value of Gross Margin divided by Laboratory Service Revenue by (b) one hundred percent (100%). 1.54
"IDN" shall mean an integrated healthcare delivery network. 1.55 "Incentive Compensation" shall mean
the compensation paid by or under the 5

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 10 -->
authority of Pfizer or any of its Affiliates to a Sales Representative involved in the Promotion of
the Product under this Agreement based directly or indirectly on the sales of the products
(including the Product) being Promoted by such Sales Representative in the Territory, including any
target bonus, award or other incentive, but excluding (i) base salary and (ii) single product ad hoc
awards or other similar individual product incentives, such as "special incentive plans" that, in
the aggregate, do not exceed $2,000 per Calendar Year. 1.56 "Included Revenue Percentage" shall have
the meaning set forth in Section 4.2(d). 1.57 "Incremental Laboratory Service Revenue" shall have
the meaning set forth in Section 4.2(a). 1.58 "Indemnified Party" shall have the meaning set forth
in Section 6.1(c)(i). 1.59 "Indemnifying Party" shall have the meaning set forth in Section
6.1(c)(i). 1.60 "JOC" shall have the meaning set forth in Section 2.2(a) 1.61 "JOC Co-Chair" shall
have the meaning set forth in Section 2.2(a). 1.62 "JRC" shall have the meaning set forth in Section
2.3(a). 1.63 "JSC" shall have the meaning set forth in Section 2.1(a). 1.64 "JSC Co-Chair" shall
have the meaning set forth in Section 2.1(b). 1.65 "JSC Members" shall have the meaning set forth in
Section 2.1(a). 1.66 "KAM Team" shall have the meaning set forth in Section 3.4(c). 1.67 "Laboratory
Service Revenue" shall mean, with respect to a particular Calendar Quarter, as applicable, Exact's
revenue earned from performing the Product Laboratory Service in the Territory with regard to
patient samples collected in the Territory, subject to Section 4.2(d), as calculated by Exact in
accordance with GAAP consistently applied, less the following deductions: (i) trade, quantity or
cash discounts, credits, adjustments or allowances, including without limitation those granted in
connection with managed care network agreements and those granted on account of price adjustments,
billing errors, rejected goods, damaged goods or incomplete tests or other services; (ii) rebates
and chargebacks allowed, given or accrued (including, but not limited to, cash, governmental and
managed care rebates, hospital or other buying group chargebacks, and governmental taxes in the
nature of a rebate based on usage levels or sales of the Product Laboratory Service); and (iii)
patient compliance incentives that are treated as a reduction in revenue in accordance with GAAP,
including without limitation gift cards to patients. 1.68 "Launch Date" shall mean October 1, 2018.
1.69 "Marketing" shall mean, with respect to a medical device subject to pre-market 6

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 11 -->
approval, Advertising, public relations, medical education activities, market research, creation,
development, and distribution of Advertising and Promotional materials, field literature, direct or
indirect educational campaigns, and exhibits at seminars and conventions. When used as a verb,
"Market" means to engage in Marketing. 1.70 "OB/Gyn Commercial Rights" shall have the meaning set
forth in Section 3.1(c)(ii). 1.71 "OB/Gyn Commercial Rights Transfer Notice" shall have the meaning
set forth in Section 3.1(c)(ii). 1.72 "OB/Gyn Field" shall mean those healthcare professionals and
practices customarily considered OB/Gyn providers and practices. 1.73 "Occurrence" shall have the
meaning set forth in Section 2.6(c). 1.74 "Party" or "Parties" shall have the meaning set forth in
the preamble. 1.75 "Patent Rights" shall mean any and all (a) issued patents, (b) pending patent
applications, including all provisional applications, substitutions, continuations,
continuations-in-part, divisionals, and renewals, and all patents granted thereon, (c) patents of
addition, reissues, reexaminations and extensions or restorations by existing or future extension or
restorations mechanisms, including patent term adjustments, patent term extensions, supplementary
protection certificates or the equivalent thereof, (d) inventor's certificates, (e) other forms of
government issued rights substantially similar to the foregoing and (f) United States and foreign
counterparts of any of the foregoing. 1.76 "Payer" shall mean a Third Party entity that pays a
portion or all of the cost of the Product Laboratory Service performed with respect to a given
patient using the Product. For clarity, a patient who pays for the cost of his or her own Product
Laboratory Service, in whole or in part, shall not be included in this definition of "Payer" and a
"Payer" may include government entities or agencies, managed care organizations, and health or
prescription insurance providers. 1.77 "Person" shall mean an individual, sole proprietorship,
partnership, limited partnership, limited liability partnership, corporation, limited liability
company, business trust, joint stock company, trust, incorporated association, joint venture or
similar entity or organization, including a government or political subdivision or department or
agency of a government. 1.78 "Pfizer" shall have the meaning set forth in the preamble. 1.79 "Pfizer
Indemnitee" shall have the meaning set forth in Section 6.1(a). 1.80 "Pfizer JSC Members" shall have
the meaning set forth in Section 2.1(a). 1.81 "Pfizer Trainers" shall have the meaning set forth in
Section 3.2(e)(i). 1.82 "PhRMA Code" shall have the meaning set forth in Section 3.2(c)(ii). 7

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 12 -->
1.83 "Pre-Launch Meeting" shall have the meaning set forth in Section 3.2(e)(v). 1.84 "Product"
shall mean the medical device subject to pre-market approval currently commercialized under the
brand name "COLOGUARD" and indicated for the qualitative detection of colorectal neoplasia
associated DNA markers and for the presence of occult hemoglobin in human stool. 1.85 "Product
Label" shall mean the labels and labeling documents approved on August 11, 2014 by the FDA under the
Premarket Approval P130017, , and any supplements, extensions or changes thereto. 1.86 "Product
Laboratory Service" shall mean the colorectal cancer screening test performed on a specimen provided
by a patient using the Product, including specimen collection, laboratory testing, data handling and
analysis, interpretation of results, patient compliance (including call center activity) and billing
to be provided by Exact or its Affiliates according to the "Laboratory Instruction for Use" in the
Product Label, wherein the Laboratory Instructions for Use are further subject to any changes as
required by any pre-market approval supplements approved by the FDA. 1.87 "Product Training" shall
mean, with respect to the Product, the Product-specific training program conducted in accordance
with the applicable Annual Marketing Plan and Applicable Laws, which may include training concerning
(a) the scientific basis for the Product, (b) permissible communications regarding safety and
efficacy claims relating to the Product, (c) permissible communications related to the Product in
accordance with the Product Label, (d) use of Promotional Materials by the Sales Representatives,
and (e) other appropriate topics relevant to the Promotion of the Product as determined by Exact in
consultation with Pfizer. 1.88 "Promotion" shall mean (a) those activities customarily undertaken by
a Party's field sales representatives in the Territory to encourage the approved use of a particular
prescription medical device (or prescription pharmaceutical medicine as applicable) subject to
pre-market approval (or other regulatory approval, as applicable), including detailing, and (b) any
other activities customarily undertaken by a Party aimed at encouraging the approved use of a
particular prescription medical device subject to pre-market authorization approval, including
without limitation, healthcare professional peer-to-peer communication, communications of product
benefits to IDNs, the creation and use of promotional materials, Marketing, meetings and events
(including without limitation speaker bureau events), trade shows, advocacy activities, including
with respect to guideline organizations, and sponsorships. The terms "Promote", "Promoting" and
"Promotional" shall have corresponding meanings. 1.89 "Promotion Fee" shall have the meaning set
forth in Section 4.2(a). 1.90 "Promotional Materials" shall mean, with respect to the Product, all
written, printed, graphic, electronic, audio, video or other materials (such as a journal reprint)
other than the Product Label, provided by Exact, with respect to currently 8

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 13 -->
developed materials, or developed by the Parties, in each case, for use by a Party's Sales
Representatives during Details or other Representatives in the Territory. 1.91 "QSR" shall mean the
Quality System Regulation, 21 C.F.R. Part 820, as may be amended from time to time and any successor
thereto. 1.92 "Receiving Party" shall have the meaning set forth in Section 7.1. 1.93 "Regulatory
Approval" shall mean, with respect to a prescription medical device subject to pre-market
authorization approval in any jurisdiction in the Territory for a given indication, all technical,
medical and scientific licenses, registrations, authorizations and approvals of pre-market approval
application, supplements and amendments, and pre- and post- approvals of the FDA, sufficient for the
manufacture, distribution, use and sale of such prescription medical device, including any services
associated with such medical device, in such jurisdiction in the Territory for such indication in
accordance with Applicable Law, excluding any pricing and reimbursement approvals. 1.94 "Renewal
Term" shall have the meaning set forth in Section 8.2. 1.95 "Representatives" shall mean, with
respect to a Party, such Party's employees, agents or independent contractors, and such Party's
Affiliates and their respective employees, agents or independent contractors, including Sales
Representatives, in each case who are performing services under the Annual Marketing Plan. 1.96
"Sales Deployment Plan" shall have the meaning set forth in Section 3.2(c)(i). 1.97 "Sales
Representative" shall mean an internal or field sales representative employed by a Party full-time
who details products or services for human use in the Territory. For clarity, Sales Representative
excludes sales managers such as district business managers and above. 1.98 "Senior Officers" shall
mean, with respect to Exact, the Chief Executive Officer of Exact and, with respect to Pfizer,
Regional President, North America, Internal Medicine, Pfizer Innovative Health. 1.99 "Shared M&P
Expense" shall mean the incremental investment in Promotion expense above the Baseline M&P Expenses
agreed to by the Parties, as set forth in Sections 3.5 and 3.6. 1.100 "Tail Period" shall have the
meaning set forth in Section 8.7. 1.101 "Term" shall have the meaning set forth in Section 8.1.
1.102 "Territory" shall mean the fifty (50) states of the United States and the District of Columbia
and includes Puerto Rico. 1.103 "Third Party" shall mean any Person other than Exact, Pfizer or
their respective Affiliates. 1.104 "Trademark" shall mean any registered word, name, symbol, color,
designation or 9

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 14 -->
device or any combination thereof, including any trademark, trade dress, brand mark, service mark,
trade name, brand name, logo or business symbol. 1.105 "Training Materials" shall mean, with respect
to the Product, the materials (which may include written or other recorded, videotaped or web-based
training materials or online training programs) to be used in Product Training for a Party's Sales
Representatives regarding the Product. 1.106 "VAT" shall have the meaning set forth in Section 4.4.
1.107 "Violating Party" shall have the meaning set forth in Section 8.3(d). 2. GOVERNANCE. 2.1 Joint
Steering Committee. (a) Composition. Promptly following the Effective Date, the Parties will
establish a Joint Steering Committee ("JSC"), comprised of three (3) Representatives of Exact and
three (3) Representatives of Pfizer. The JSC Representatives for each of Exact and Pfizer will be
referred to herein as the "Exact JSC Members" and the "Pfizer JSC Members", respectively, and the
Exact JSC Members and the Pfizer JSC Members will be referred to herein as the "JSC Members". Each
Party may replace any of its JSC Members at any time upon notice to the other Party and the Parties
may increase or decrease the number of its JSC Members on the JSC; provided that at all times an
equal number of JSC Members from each Party are appointed to the JSC. (b) Committee Chair. The JSC
will be co-chaired by a Pfizer JSC Member and an Exact JSC Member (each, a "JSC Co-Chair"). Each
Party may replace its JSC Co-Chair at any time upon notice to the other Party. The role of secretary
of the JSC shall rotate each meeting between the JSC Co-Chairs (or any JSC Member who is appointed,
by mutual agreement of both JSC Co-Chairs, as secretary of the JSC). The secretary of the JSC shall:
(i) notify each Party at least fifteen (15) days (or as much notice as is reasonably possible) in
advance of each JSC meeting; (ii) collect and organize agenda items from each Party for each JSC
meeting; (iii) prepare and circulate to JSC Members each JSC meeting agenda no later than five (5)
Business Days (or as far in advance as is reasonably possible) prior to the scheduled date for each
JSC meeting; and (iv) prepare the written minutes of each JSC meeting and, within fifteen (15) days
after such meeting, circulate such minutes for review and approval by the Parties. 10

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 15 -->
(c) Meetings. The JSC will meet no less than once each Calendar Quarter (or less frequently upon
mutual agreement of the Parties) either in-person or by audio or video teleconference. Meetings of
the JSC will occur at such times and places in the Territory as mutually agreed to by the Parties;
provided, however, that no more than half of the meetings will be required to be held in-person in
any Calendar Year. Meetings of the JSC will only occur if at least one JSC Member of each Party is
present at the meeting or participating by teleconference or videoconference. Each Party will be
solely responsible for, and will not be entitled to any reimbursement from the other Party with
respect to, any and all personnel costs or expenses (including travel expenses) incurred by or on
behalf of its Representatives in connection with participation in any JSC meetings or sub-committee
or working group meetings, or any other travel required to be undertaken by either Party's personnel
in connection with the performance of the Agreement. The Parties will endeavor to schedule meetings
of the JSC at least fifteen (15) days in advance. The Parties shall approve the minutes of each
meeting promptly, but in no event later than the next meeting of the JSC. (d) JSC Responsibilities.
The JSC shall: (i) review, discuss, and approve each Annual Marketing Plan for a Calendar Year,
including the quarterly baseline budget amounts contained therein, no later than the applicable date
set forth in Section 3.3(a); (ii) oversee the implementation of each Annual Marketing Plan; (iii)
review, discuss, and approve any modifications to the Annual Marketing Plan submitted by the JOC;
(iv) oversee the JOC and JRC and each committee's activities; (v) act as the first level escalation
to resolve disputes between the Parties, any resolution of dispute brought before the JSC shall be
by the unanimous consent of both JSC Co-Chairs; (vi) form and oversee any sub-committee or working
group in furtherance of activities contemplated in the Annual Marketing Plan; (vii) form and oversee
any sub-committee or working group as determined by the JSC to be necessary to review and discuss
specific matters related to the subject matter of this Agreement, but not enumerated as a specific
responsibility of the JSC, JOC, JRC, or any other properly formed and constituted sub-committee;
(viii) review, discuss and approve the allocation of Baseline M&P Expenses and Shared M&P Expenses
submitted by the JOC; 11

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 16 -->
(ix) review all reports, including sales performance data and other key performance indicators,
submitted by the JOC; and (x) escalate any Disputed JSC Matter, as defined in Section 2.1(e), to the
Alliance Managers and Senior Officers. (e) Decision Making. Regardless of the number of Pfizer JSC
Members or Exact JSC Members, decisions by the JSC will be made by unanimous agreement. The JSC will
use good faith efforts to reach agreement on any and all matters properly brought before it. If,
despite such good faith efforts, the JSC is unable to reach a decision on a particular matter within
the JSC's responsibilities (each such matter, a "Disputed JSC Matter"), within five (5) Business
Days after the JSC first meets to consider such matter, or such later date as may be mutually agreed
by the Parties in writing, then either Party may refer such Disputed JSC Matter for resolution to
the Alliance Managers. Within three (3) Business Days after such Disputed JSC Matter is referred to
the Alliance Managers, the Alliance Managers shall determine whether the Disputed JSC Matter
requires the involvement of the Senior Officers. Should the Alliance Managers refer the Disputed JSC
Matter to the Senior Officers, then the Senior Officers will promptly initiate good faith
discussions to resolve such Disputed JSC Matter. If the Senior Officers are unable to resolve such
Disputed JSC Matter within five (5) Business Days of it being referred to them, then, Exact, after
having considered, in good faith, the advice and input from Pfizer, will have final decision-making
authority with respect to such Disputed JSC Matter where the subject matter of the Disputed JSC
Matter substantially relates to (i) Product pricing, including any rebates or discounts; (ii)
manufacturing; (iii) research and development, including any trials; and (iv) engagement with
Governmental Authorities; provided, however, that Exact will not have final decision making
authority to require Pfizer to conduct any activities that Pfizer, in good faith, believes violate
Applicable Law or Pfizer's Applicable Compliance/Review Policies. For all Disputed JSC Matters that
are not resolved by the Senior Officers and are not subject to Exact's final decision-making
authority, neither Party will take any action on such Disputed JSC Matter until resolution can be
reached in accordance with this Section 2.1(e), and, except in the case of a potential violation of
Applicable Law, pending such resolution the Parties shall continue to carry out activities under
this Agreement in accordance with the then-current Annual Marketing Plan. (f) Limits on JSC
Authority. Notwithstanding any provision of this Section 2.1 to the contrary, (i) each Party will
retain the rights, powers and discretion granted to it under this Agreement consistent with Section
3.2(a), and no such rights, powers, or discretion will be delegated to or vested in the JSC unless
such delegation or vesting of rights is expressly provided for in this Agreement or the Parties
expressly so agree in writing, (ii) the JSC will not have the power to amend this Agreement or
terminate or otherwise modify or waive compliance with this Agreement in any manner and (iii)
neither Party will require the other Party to (A) breach any obligation or agreement that 12

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 17 -->
such other Party may have with or to a Third Party or (B) perform any activities that are materially
different, greater in scope or more costly than those provided for in the Annual Marketing Plan then
in effect. 2.2 Joint Operations Committee. (a) Composition. Promptly following the Effective Date,
the Parties will establish a Joint Operations Committee ("JOC"), comprised of marketing, sales,
medical, finance, and such other Representatives of each Party as necessary. The JOC shall be
co-chaired by each Party's marketing Representative on the JOC, as designated by the JSC Co-Chair of
each Party (each, a "JOC Co-Chair"). Each JOC Co-Chair shall (i) have knowledge and expertise in the
commercialization of prescription products and services in the Territory, (ii) have sufficient
seniority within the applicable Party to make decisions arising within the scope of the JOC's
responsibilities, and (iii) be authorized under such Party's internal governance procedures to make
decisions or carry out the activities given to such Party under this Agreement. (b) Meetings. The
JOC shall meet once each month (or more or less frequently upon mutual agreement of the Parties)
either in- person or by audio or video teleconference. Meetings of the JOC will occur at such times
and places in the Territory as mutually agreed to by the Parties. Each Party will be solely
responsible for, and will not be entitled to any reimbursement from the other Party with respect to,
any and all personnel costs or expenses (including travel expenses) which are incurred by or on
behalf of its Representatives in connection with participation in any JOC meetings or sub-committee
or working group meetings, or any other travel required to be undertaken by either Party's personnel
in connection with the performance of the Agreement. (c) JOC Responsibilities. The JOC shall: (i)
prepare the Annual Marketing Plan for review and approval by JSC; (ii) prepare and review Product
Marketing strategies and tactics; (iii) prepare allocation of Baseline M&P Expenses and Shared M&P
Expense for JSC review and approval; (iv) prepare reports, including sales performance data and
other key performance indicators for JSC review in accordance with Exhibit 2.2(c)(iv); (v) execute
and monitor the strategies and tactics in the Annual Marketing Plan; 13

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 18 -->
(vi) monitor Product supply and Product Laboratory Service capacity to ensure they are sufficient to
meet the demand forecast in the Annual Marketing Plan; (vii) establish key supply, capacity,
inventory, and such other metrics to inform the JSC; (viii) prepare any revision to the Annual
Marketing Plan as directed by the JSC or otherwise proposed pursuant to Section 3.3(a); (ix) provide
consent to materials for reconsideration by the JSC pursuant to Section 2.3(d); and (x) with respect
to the Annual Marketing Plan, ensure that a consultation with the Compliance Managers is completed
and appropriate compliance measures are incorporated into the Annual Marketing Plan. (d) Decision
Making. Decisions by the JOC will be made by unanimous agreement. If a unanimous decision cannot be
reached, then any disputed matter within the JOC's responsibilities (the "Disputed JOC Matter") may
be escalated by either Party to the JSC for resolution in accordance with Section 2.1(e). Unless and
until resolved by the JSC in accordance with Section 2.1(e), neither Party shall take any action
with respect to such Disputed JOC Matter and, except in the case of a potential violation of
Applicable Law, pending such resolution the Parties shall continue to carry out the activities under
this Agreement in accordance with the then-current Annual Marketing Plan. 2.3 Joint Review
Committee. (a) Composition. Promptly following the Effective Date (and in any event, within thirty
(30) days of the Effective Date), under the supervision of the JSC, the Parties will establish a
Joint Review Committee ("JRC"), comprised of marketing, medical, legal, and regulatory
Representatives of the Parties. Each Party may appoint one medical, legal and regulatory
Representative member to the JRC. The marketing Representatives from the Parties shall coordinate
administration and operation of the JRC meetings, including setting agendas, recording decisions
regarding materials reviewed, and coordinating review to ensure timely review and approval of
Promotional Materials. The Representatives from the Parties on the JRC shall coordinate operational
support including scheduling of JRC meetings, timely distribution of materials for review, recording
and archiving of approved materials, and other such activities to ensure operational efficiency of
JRC meetings. It is the expectation of the Parties that the JRC will utilize Exact's review and
approval system to review and approve materials, including Promotional Materials that are subject to
JRC review under Section 2.3(c). 14

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 19 -->
(b) Meetings. The JRC shall meet no less than once each month (or more frequently upon mutual
agreement of the members of the JRC) either in-person or by audio or video teleconference. Meetings
of the JRC will occur at such times and places in the Territory as mutually agreed to by the
Parties. Each Party will be solely responsible for, and will not be entitled to any reimbursement
from the other Party with respect to, any and all personnel costs or expenses (including travel
expenses) which are incurred by or on behalf of its Representatives in connection with participation
in any JRC meetings, or any other travel required to be undertaken by either Party's personnel in
connection with the performance of the Agreement. (c) JRC Responsibilities. The JRC shall be
responsible for review and approval of all Product or related disease education materials,
Promotional Materials and other communication to a Third Party, including pharmaco-economic data,
that may be used in Promotion, medical to medical communication, patient education, press release or
any other form of external communication intended for healthcare professionals, healthcare organized
customers (such as IDNs and hospitals), and Payer organizations, patients or others who are
reasonably likely to influence the prescription, use, reimbursement, or purchase of the Product. The
JRC shall also ensure that all such materials are in compliance with Applicable Law and each Party's
Applicable Compliance/Review Policies. Any conflict between the Parties' Applicable
Compliance/Review Policies will be discussed by the JRC and the Compliance Managers to determine an
appropriate resolution of such conflict. (d) Decision Making. Decisions by the JRC will be made by
unanimous agreement. If a unanimous decision cannot be reached, then the disputed matter (the
"Disputed JRC Matter") can be escalated by either Party to the JSC for resolution in accordance with
Section 2.1(e). Unless and until resolved by the JSC in accordance with Section 2.1(e), neither
Party shall take any action with respect to such Disputed JRC Matter and, except in the case of a
legal or ethical issue, the Parties shall continue to carry out the activities under this Agreement
in accordance with the then-current Annual Marketing Plan. A Disputed JRC Matter that is
substantially similar in subject matter of a prior Disputed JRC Matter shall not be resubmitted for
JSC review and resolution under this Section 2.3(d). 2.4 Finance Representative. Each Party shall
appoint a finance contact to oversee all financial reporting and communications under this Agreement
during the Term (each, a "Finance Representative"). Each Party may change its designated Finance
Representative at any time upon written notice to the other Party. Each Finance Representative will
coordinate the efforts of its respective Party in conducting finance activities, including all
financial reporting and financial communications between the Parties, under this Agreement during
the Term. 2.5 Alliance Managers. Each Party shall appoint an employee of such Party who shall
oversee interactions between the Parties for all matters related to this Agreement, the 15

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 20 -->
Annual Marketing Plan and any related agreements between the Parties or their Affiliates (each an
"Alliance Manager"). The Alliance Managers shall endeavor to ensure clear and responsive
communication between the Parties and the effective exchange of information, and shall serve as a
single point of contact for any matters arising under this Agreement. The Alliance Managers shall
have the right to attend all JSC and subcommittee meetings as non-voting participants and may bring
to the attention of the JSC or subcommittee any matters or issues either of them reasonably believes
should be discussed, and shall have such other responsibilities as the Parties may mutually agree in
writing. Each Party may designate different Alliance Managers by notice in writing to the other
Party. 2.6 Compliance Managers. Within thirty (30) days after the Effective Date, Pfizer and Exact
each agrees to appoint a Representative who (a) has received compliance training by such Party and
(b) is routinely responsible for advising such Party on compliance matters to act as its Compliance
Manager (each, a "Compliance Manager"). The Compliance Managers shall support the JSC. (a)
Responsibilities. Compliance Managers shall resolve discrepancies between the Parties' respective
Applicable Compliance/Review Policies, ensure that each Party has a process to monitor the
activities under this Agreement for compliance with Applicable Laws and Applicable Compliance/Review
Polices, serve as a key point of contact between the Parties for compliance-related matters, and
review the Annual Marketing Plan for compliance with Applicable Compliance/Review Policies and shall
promptly notify the JSC of any compliance issues in such Annual Marketing Plan. The JOC shall
promptly notify the Compliance Managers of any material revisions to the Annual Marketing Plan. Each
Compliance Manager shall facilitate the resolution of any compliance issue with the Compliance
Manager of the other Party. (b) Notification. Subject to the terms of this Agreement, the Compliance
Manager of a Party shall promptly notify the other Party's Compliance Manager in the event that it
becomes aware of a potential violation by the other Party of: (i) the other Party's policies or
procedures; (ii) any criminal, civil, or administrative laws or regulations applicable to any
federal health care program or for which penalties or exclusions may be authorized; or (iii) the
requirements under the FD&C Act, or relevant FDA guidance documents related to the Products,
payments, or services under this Agreement. (c) Investigations. If a Party finds, following an
investigation, credible evidence of a significant violation of any applicable policies and
procedures that are designed to ensure compliance with: (i) any criminal, civil, or administrative
laws or regulations applicable to any federal health care program or for which penalties or
exclusions may be authorized; or (ii) the requirements under the FD&C Act, or relevant FDA guidance
documents related to the Products, payments, or services under this Agreement (an "Occurrence"), the
Party's Compliance Manager shall promptly inform the other Party of the Occurrence and steps taken
by the Party to remediate the Occurrence, except 16

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 21 -->
to the extent that the disclosing Party's counsel reasonably believes that such disclosure to the
other Party could violate Applicable Law (including privacy laws) or have a significant adverse
impact on the disclosing Party's legal position or defense (including the loss of attorney-client
privilege) with respect to any such Occurrence. In the event that either Party determines that
disclosure of relevant factual information regarding an Occurrence could violate Applicable Laws
(including privacy laws) or have a significant adverse impact on its legal position or defense
(including the loss of attorney-client privilege), the determining Party shall promptly notify the
other Party in writing that the determining Party is exercising its right not to disclose relevant
factual information regarding an Occurrence. (d) Each Party shall follow its Applicable
Compliance/Review Policies subject to specific exceptions explicitly determined by the Compliance
Managers. 3. APPOINTMENT; PRODUCT OWNERSHIP; MARKETING AND SALES. 3.1 Appointment. (a) Exclusive
Arrangement. Commencing on the Launch Date, Exact and its Affiliates hereby grant to Pfizer and its
Affiliates, on an exclusive basis for the Co-Promote Field (except as to Exact and its Affiliates),
and Pfizer accepts, the right and obligation to Promote and Detail the Product in the Territory
during the Term jointly with Exact, in accordance with the terms and conditions of this Agreement,
all Applicable Laws and the applicable Annual Marketing Plan. Except as set forth in this Agreement,
such right shall be non-transferable and non-sublicensable. In implementing its obligations under
this Agreement, Pfizer, without charge or expense to Exact (other than as expressly set forth in
Sections 3.6 and 4.2(c) of this Agreement), shall provide facilities, personnel (including
management and Sales Representatives) and other resources as Pfizer, in its reasonable discretion
but not inconsistent with the express terms of this Agreement, believes necessary. The Parties
specifically agree that Exact shall not use the Pfizer name, logo or any Trademarks of Pfizer on any
materials, including Promotional Materials, without the express written consent of Pfizer.
Notwithstanding this Section 3.1 to the contrary, Exact retains the right to Promote the Product on
its own behalf in the Co-Promote Field and, subject to Section 3.1(c), Pfizer shall not Promote or
Detail the Product outside the Territory or outside the Co- Promote Field. (b) Grant of License to
Pfizer. Subject to the terms of this Agreement, Exact on behalf of itself and its Affiliates, hereby
grants to Pfizer a non-exclusive, royalty free license, with the right to sublicense to one or more
of its Affiliates, under the Exact House Marks, the Exact Trademarks and the Exact Copyrights,
during the Term, to the extent necessary or appropriate to allow Pfizer and its Affiliates to carry
out activities under this Agreement including to Promote and Detail the Product in the Co-Promote
Field in the Territory. Such license shall be non-transferable and non-sublicensable 17

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 22 -->
(except as provided in this Agreement) and shall automatically terminate upon the expiration or
earlier termination of this Agreement. (c) Right of First Negotiation. (i) During the Term, if Exact
(i) enters a formal process authorized or directed by its board of directors or CEO to seek and
enter into an arrangement or (ii) intends to agree to a term sheet or seeks to sign a letter of
intent or similar arrangement to grant an exclusive commercial license to a Third Party solely to
promote or sell the Product outside the Territory ("Ex-US Commercial Rights"), Exact shall first
notify Pfizer of such intent (a "Ex-US Commercial Rights Transfer Notice") and Pfizer shall have
thirty (30) days thereafter to notify Exact of its desire to obtain the Ex-US Commercial Rights that
are the subject of the Ex-US Commercial Rights Transfer Notice. Promptly upon receipt of notice from
Pfizer, Exact and Pfizer shall engage in exclusive good faith negotiations to enter into a
definitive written agreement for the Ex-US Commercial Rights. If Pfizer and Exact are unable to
reach agreement on the terms of such Product rights within forty-five (45) days of the commencement
of negotiations, Exact shall be free to enter into negotiations and consummate an agreement with any
Third Party regarding such Ex-US Commercial Rights; provided that the economic terms of such
agreement shall be no more favorable to such Third Party than those last offered to Pfizer. (ii)
During the Term, if Exact desires to grant an exclusive commercial license to a Third Party solely
to Promote or sell the Product in the OB/Gyn Field in the Territory (the "OB/Gyn Commercial
Rights"), Exact shall first notify Pfizer of such intent (a "OB/Gyn Commercial Rights Transfer
Notice") and Pfizer shall have thirty (30) days thereafter to notify Exact of its desire to obtain
the OB/Gyn Commercial Rights that are the subject of the OB/Gyn Commercial Rights Transfer Notice.
Promptly upon receipt of notice from Pfizer, Exact and Pfizer shall engage in exclusive good faith
negotiations to enter into a definitive written agreement for the OB/Gyn Commercial Rights. If
Pfizer and Exact are unable to reach agreement on the terms of such Product rights within forty-five
(45) days of the commencement of negotiations, then Exact shall be free to enter into negotiations
and consummate an agreement with any Third Party regarding such OB/Gyn Commercial Rights; provided
that the economic terms of such agreement shall be no more favorable to such Third Party than those
last offered to Pfizer. (iii) Notwithstanding the foregoing, this Section 3.1(c) shall not apply to
(i) any transfer of rights to the Product in the ordinary course of business of Exact, (ii) the sale
of the Product within and outside of the Territory, of all or substantially all of the assets of
Exact, or sale 18

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 23 -->
of capital stock of Exact, whether in connection with a merger, acquisition or other similar
transaction or (iii) any agreements with Third Parties in territories for which Exact has an
existing distribution or other similar agreement. 3.2 Responsibility for Product. (a) Retained
Rights; Ownership of Product. Except as specifically set forth in this Agreement, Pfizer shall have
no other rights with respect to the Product, and shall not Promote, Market or otherwise
commercialize the Product except as expressly authorized under this Agreement. Exact retains, and at
all times during the Term shall retain, all rights in and relating to the Product not expressly
granted to Pfizer under this Agreement, including all proprietary and property interests in and to
the Product. In furtherance of the foregoing, Exact retains all rights of and responsibility for (i)
Product pricing, including any rebates or discounts; (ii) manufacturing; (iii) research and
development, including any trials; (iv) intellectual property defense and enforcement related to the
Product; (v) product liability claims and related litigation related to the Product; (vi) government
investigations related to the Product; (vii) the day-to-day operations and management of Exact's
Representatives; and (viii) engagement with Governmental Authorities with respect to the Product.
Pfizer will neither have, nor represent that it has, any control over or proprietary or property
interests in the Product. Nothing contained in this Agreement shall be deemed to grant to Pfizer or
its Affiliates any license, right, title or interest in or to any patent, Trademark, copyright,
trade secret or other similar property of Exact, except as provided for in Section 3.1(b), Section
5.3(c) or otherwise authorized in writing by Exact for Pfizer to perform its obligations under this
Agreement. Likewise, nothing contained in this Agreement shall be deemed to grant to Exact or its
Affiliates any license, right, title or interest in or to any patent, Trademark, copyright, trade
secret or other similar property of Pfizer or its Affiliates except as may be authorized in writing
by Pfizer for Exact to perform its obligations under this Agreement. (b) Exact Product
Responsibilities. During the Term, as between the Parties, Exact shall remain solely responsible, at
its expense , except as expressly otherwise provided in this Agreement, for all activities and
liabilities that the owner and Regulatory Approval holder of an FDA approved medical device would
normally have, including, in each case with respect to the Territory, the following: (i)
manufacturing, in accordance with the QSR and Applicable Law (including conducting all quality
assurance testing) sufficient quantities of Product to meet market demand therefore; (ii) processing
and having sufficient laboratory and manufacturing capacity to process Product Laboratory Services
to meet demand, including return receipt and laboratory processing of patient samples; 19

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 24 -->
(iii) ensuring all laboratory processing of patient samples are conducted in accordance with CLIA
Certificate of Accreditation and patient results are provided to ordering healthcare providers in a
timely manner; (iv) ensuring that the Product is not misbranded, as defined in the FD&C Act; (v)
handling all customer service activities relating to the Product, including responding in an
appropriate and timely fashion to all medical and other inquiries and complaints regarding the
Product in accordance with its Applicable Compliance/Review Policies; (vi) contracting with Payers,
including entering into contracts for reimbursement of the Product Laboratory Services; (vii) using
commercially reasonable efforts to maintain the Exact Trademarks listed on Exhibit 1.39; (viii)
setting the price of the Product Laboratory Services, including establishing, processing and paying
for any rebates, discounts, chargebacks or other sales incentives associated with the sale of the
Product Laboratory Services; (ix) subject to Section 6.1, handling all product liability claims or
other claims associated with or arising out of the manufacture, distribution, sale or use of the
Product, including managing any litigation associated therewith and paying any damages, fines or
other compensation that may be awarded by any Government Authority or that are due as a result of
any settlement of any such claim; (x) handling, in a timely and appropriate manner, all government
inquiries related to the Product Laboratory Services and the manufacture, distribution, Marketing,
Promotion, sale or use of the Product; and (xi) preparing and submitting in a timely manner and in a
manner consistent with Applicable Law all reports and information that are required to be submitted
to any Government Authority relating to the Product and Product Laboratory Services. (c) Exact and
Pfizer Product Responsibilities. During the Term, without limiting either Party's other
responsibilities under this Agreement, the Parties shall: (i) establish and maintain a sufficient
number of Sales Representatives Promoting the Product to perform the obligations hereunder per the
Annual Marketing Plan and consistent with the sales deployment plan included in the Annual Marketing
Plan, which initial sales deployment plan for the six-month period beginning on and 20

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 25 -->
immediately following the Launch Date, is attached hereto as Exhibit 3.2(c)(i) (the "Sales
Deployment Plan"); (ii) Market, Promote and Detail the Product in the Co-Promote Field in accordance
with the Annual Marketing Plan, Applicable Laws, all regulatory and professional requirements
including FDA's regulations and guidelines concerning the Advertising of prescription medical
devices subject to pre-market approval, and each Party's Applicable Compliance/Review Policies and,
with respect to Exact, the AdvaMed Code of Ethics on Interactions with Health Care Professionals
(revised as of July 2009 and as further revised from time to time) (the "AdvaMed Code") and, with
respect to Pfizer, the Pharmaceutical Research and Manufacturers of America Code on Interactions
with Healthcare Professionals (the "PhRMA Code"); provided that if there is any conflict between the
AdvaMed Code and the PhRMA Code in connection with the implementation of the Annual Marketing Plan,
the Compliance Managers shall review and use commercially reasonable efforts to resolve such
conflict; (iii) review customer target lists for all Sales Representatives in accordance with the
Annual Marketing Plan to ensure that their Promotion is directed to those Eligible Prescribers who
are likely to prescribe, recommend or purchase the Product consistent with the approved Product
Label and all Applicable Laws and its Applicable Compliance/Review Policies; provided that each
Party has the sole discretion to select their target customers from the target lists included in the
Annual Marketing Plan and the Party's Sales Representatives shall have authority to Promote and
Detail to the Eligible Prescribers on the target lists in their reasonable discretion, in accordance
with each Party's respective internal policies and practices; (iv) work collaboratively with the
other Party in developing, preparing and generating specific tactics and activities in the Annual
Marketing Plan, which shall include supporting the development of all Promotional Materials,
Training Materials and other materials generated pursuant to any Annual Marketing Plan; and (v)
provide investment and support consistent with Sections 3.5, 3.6 and 4.1, as applicable. (d)
Advertising. (i) Subject to the provisions of Section 3.2(d)(ii) with respect to the remainder of
Calendar Year 2018 and for Calendar Year 2019, Exact and Pfizer shall develop an annual Advertising
plan for the Product as part of the Annual Marketing Plan. The annual Advertising plan shall include
the targets for such Advertising, 21

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 26 -->
which shall be updated on an annual basis at the same time and in the same manner as the Annual
Marketing Plan. In accordance with each such approved Advertising plan, Pfizer shall develop and
execute all media planning and buying of Advertising consistent with its practice for its own
product portfolio. (ii) The provisions of this Section 3.2(d) shall have no impact on Exact's
Advertising plan for the Product for 2018. The Advertising plan for Calendar Year 2019 shall be
Exact's Advertising plan; provided, Pfizer may review and make recommendations on such Advertising
plan for Calendar Year 2019 and Exact shall consider such recommendations in good faith and use
commercially reasonable efforts to incorporate agreed-upon Pfizer recommendations. It is
acknowledged by the Parties that as of the Effective Date Pfizer has executed its television/video
media buying on its own behalf for broadcast year 2019 (4Q2018-3Q2019). With respect to broadcast
year 2019, Pfizer shall use commercially reasonable efforts and in good faith execute the
television/video buy plan in the Calendar Year 2019 Advertising plan in the "scatter" market. Exact
acknowledges that pricing and inventory for buy placement in the scatter market may not have the
pricing advantage or delivery guarantees. For media buying of non-television/video in the Calendar
Year 2019 Advertising plan, Pfizer shall in good faith integrate the Product into Pfizer portfolio
media planning and buying for non-television/video. (iii) The cost of all media buying of
Advertising for the Product by or through Pfizer shall be equal to the actual cost of such
activities billed to Pfizer (including any third party service fees incurred by Pfizer) and shall
not include any markup, administrative fee or service charge. (iv) Subject to compliance by Pfizer
with the terms of this Section 3.2(d), during the Term, Exact agrees (A) not to enter into any new
binding arrangement with any media vendor for Advertising of the Product without the written consent
of Pfizer, which consent shall not be unreasonably withheld, (B) not to meet with any advertising
agency or media vendor to discuss any Advertising proposals for content development and creative
direction of the Product, without providing Pfizer with a reasonable opportunity for a
representative of Pfizer present and participate and (C) to promptly inform Pfizer if it enters into
any arrangement with any advertising agency with respect to the Product. (v) Exact agrees that any
binding commitment made by Pfizer pursuant to this Section 3.2(d) for media buying for the Product
shall also be binding to Exact; provided that such commitment is consistent with the applicable
Annual Marketing Plan and the 22

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 27 -->
budget included therein. (vi) After the Effective Date, the Parties will mutually agree to a process
by which Pfizer will interact with Exact with respect to the activities undertaken by Pfizer
pursuant to this Section 3.2(d). (vii) Notwithstanding the foregoing, Exact may continue any binding
commitments as of the Effective Date, including Advertising purchasing and placement activities,
related to and in connection with the sponsorship of sporting events (e.g., golf tournaments),
celebrity sponsorships (e.g., Harry Connick serving as a Product spokesperson) and those other
activities set forth in the Annual Marketing Plan (the "Exact Sponsorships and Related Activities");
provided, that Pfizer shall use commercially reasonable efforts to take responsibility of
television/video and media buying related to such Exact Sponsorships and Related Activities
following the Effective Date. The Exact Sponsorships and Related Activities may, as mutually agreed
by the Parties, be included in the applicable annual Advertising plan. (viii) Following the Term and
during the Tail Period subject to Sections 8.7 and 8.8(b), at the request of Exact, Pfizer shall,
based on an agreed Advertising plan, plan and execute the media planning and buying plan in a
substantially similar manner as it did during the Term, as such plan is updated on an annual basis
during the Tail Period. Pfizer shall provide Exact with invoicing of Advertising buying during the
Tail Period consistent with its invoicing practice during the Term. This invoice shall be provided
within five (5) days of the end of each month during the Tail Period and shall set forth all
Advertising costs, including any Pfizer's internal and overhead costs attributable to media buying
for the Product, during month preceding the month that the invoice is delivered. Exact shall pay the
invoice provided by Pfizer within five (5) days of the date that it receives the invoice. (ix)
Within forty-five (45) calendar days after the end of each Calendar Quarter, Pfizer will deliver to
Exact a report describing in reasonable detail the media buying activities for the just completed
Calendar Quarter and any material deviations from the approved Advertising plan that occurred during
such Calendar Quarter. (x) Except for Calendar Year 2018 and 2019 Advertising plan, the Parties
shall mutually agree to the Advertising plan and any dispute with respect to such Advertising plan
or arising out of material deviation of media buying by Pfizer shall be considered a Disputed JOC
Matter and subject to escalation to the JSC under Section 2.3(d). Until such Disputed JOC Matter is
resolved, the Parties will continue to operate under the then-current Advertising plan. Without
limiting the foregoing, a deviation from the media 23

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 28 -->
buying obligations under an Advertising plan by twenty percent (20%) or more shall be deemed to be
material. (e) Product Training. (i) Promptly (and in any event within twenty (20) days) following
the Effective Date, Exact shall be responsible for providing Product Training and Training Materials
to Pfizer sales trainers (the "Pfizer Trainers") who shall then train Pfizer's Sales Representatives
who shall Promote the Product using a training program relating solely to the Product and the
Product Laboratory Service (including Training Materials). After the initial training, Exact shall
periodically provide additional Product Training and the Parties shall agree to the frequency, time
and place such additional Product Training will be rolled out to Sales Representatives. (ii) Exact
shall bear all costs and expenses of training its Sales Representatives, its training facilities and
the cost of developing Training Materials and the training of Pfizer Trainers with respect to the
Product and the Product Laboratory Service. Pfizer shall be responsible for all travel, lodging,
meal and other expenses and out-of- pocket expenses incurred by Pfizer's Sales Representatives in
connection with such Product Training. (iii) Upon termination or expiration of this Agreement, at
Exact's election, Pfizer either shall (A) return to Exact or (B) destroy and certify to the Exact
such destruction, all Training Materials in the possession of, or under the control of, Pfizer. (iv)
Pfizer shall ensure that no Pfizer Representative shall Promote the Product or Product Laboratory
Service unless he or she demonstrates sufficient knowledge by meeting the validation requirements of
Exact. Pfizer shall maintain, and make available upon request by Exact, records of all testing or
certification results, including copies thereof. (v) The Parties shall cooperate in good faith to
schedule, plan and conduct a pre-launch meeting for all Sales Representatives Detailing the Product
(the "Pre-Launch Meeting"), which shall occur promptly following training of the Pfizer Sales
Representatives in accordance with this Section 3.2(e). The Parties shall use commercially
reasonable efforts to conduct the Pre-Launch Meeting as an in-person meeting by the first week of
October 2018. (f) Promotional Materials. During the Term, the Parties agree to develop Promotional
Materials together in accordance with the Annual Marketing Plan for use in Promoting the Product in
the Territory. Each Party shall: 24

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 29 -->
(i) only use and distribute the Promotional Materials for use in Promoting the Product; provided,
however, that Exact may continue to utilize any remaining promotional materials for the Product
created prior to the Effective Date, but Exact will not create any new promotional materials other
than the Promotional Materials; (ii) instruct its Representatives to use, and will use commercially
reasonable efforts to train and monitor its Representatives to ensure that such Representatives use,
only Promotional Materials approved by the JRC; (iii) not, and shall ensure that its Affiliates and
agents do not, change or alter any Promotional Materials in any way prior to their distribution or
use by such Party or its Sales Representatives without JRC approval; and (iv) (A) use commercially
reasonable efforts to train its Representatives with respect to, (B) instruct its Representatives
to, and (C) establish appropriate internal systems, policies and procedures for the monitoring of
its Representatives with the goal of ensuring that such Representatives will: (A) limit claims of
efficacy and safety for the Product to those that are (1) consistent with approved Promotional
claims in, and not add, delete or modify claims of efficacy and safety in the Promotion of the
Product in any respect from those claims of efficacy and safety that are contained in, the
then-effective Annual Marketing Plan, (2) consistent with Applicable Law and (3) consistent with the
Product Label; (B) not make any changes or alterations to Promotional Materials; and (C) use
Promotional Materials only in a manner that is consistent with this Agreement, Applicable Law and
the Product Label. For clarity, the foregoing restrictions shall not apply to Exact Sciences
Laboratories, LLC or any Representative of Exact or any of its Affiliates on the customer care team
or market access team. (g) Representatives. Each Party shall be legally responsible and liable for
the actions, omissions and conduct of their respective Sales Representatives and other
Representatives performing activities hereunder. Each Party shall ensure that all Persons for whom
they have legal responsibility and liability in accordance with the foregoing sentence comply with
all Applicable Laws, the AdvaMed Code or the PhRMA Code, as applicable, Applicable Compliance/Review
Polices, and all requirements of this Agreement, and shall implement and maintain policies and
procedures to ensure such compliance. 25

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 30 -->
(h) Marketing Authorization. Exact shall have the sole right and responsibility between the Parties
to take, and shall take, all actions with respect to the Product reasonably necessary in order to
maintain the Regulatory Approvals permitting the Marketing and sale of the Product in the Territory
throughout the Term. (i) Withdrawal. Exact shall have sole authority to determine whether to recall
or withdraw any Product in the Territory; provided, however, Exact shall notify Pfizer of its
decision, including the reasons therefore, regarding any such recall or withdrawal promptly after
such decision is made. Exact shall be solely responsible for and shall bear all costs associated,
directly or indirectly, with any recalls or withdrawals of the Product. (j) Customer Service
Activities; Safety Reporting. Exact shall have sole authority to handle all customer service
activities regarding the Product in accordance with Section 3.2(b)(v). Promptly upon receipt (and in
any event within one Business Day), Pfizer shall refer all customer service inquiries regarding the
Product, including all medical and other inquiries and complaints, to Exact for resolution.
Following the Effective Date but before the Launch Date, the Parties shall discuss and agree to a
procedure by which Product inquiries to, or by, Pfizer will be sent to Exact to comply with
applicable safety reporting requirements and obligations for the Product. 3.3 Annual Marketing Plan.
(a) General. Promptly following the Effective Date, Exact and Pfizer shall develop an Annual
Marketing Plan for the Product. Unless otherwise agreed by the Parties, the JOC shall prepare each
Annual Marketing Plan and submit it for review and approval by the JSC by no later than October 1 of
the then-current Calendar Year so that the JSC shall have a reasonable opportunity to review, revise
and approve such Annual Marketing Plan by no later than October 31 of the Calendar Year preceding
the Calendar Year to which such Annual Marketing Plan relates; provided that the Annual Marketing
Plan for the 2019 Calendar Year shall be finalized by the JOC and submitted to the JSC promptly
following the Effective Date, and in any event no later than December 1, 2018. It is the intent of
the Parties that the Annual Marketing Plan for the remainder of 2018 will be approved by the JSC no
later than October 1, 2018. If either Party desires to revise or update an approved Annual Marketing
Plan prior to the end of a Calendar Year, it shall notify the JOC of such desired revision, and the
JOC shall review any such proposed revision and determine whether to submit such revision to the JSC
for review and approval. (b) Plan Contents. The Annual Marketing Plan for each Calendar Year
beginning with the 2019 Calendar Year shall contain at a minimum the categories set forth in Exhibit
3.3(b) and such other information that the JOC or JSC believes is necessary. The 2018 Annual
Marketing Plan shall contain 26

s t

s t

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 31 -->
a high-level summary of the Sales Deployment Plan and use of Shared M&P Expenses for the remainder
of 2018. 3.4 Sales Promotion, Detailing Efforts and IDN Promotion. (a) Sales Promotion. Commencing
on the Launch Date, each of Exact and Pfizer shall implement the sales Detailing plan set forth in
the applicable Annual Marketing Plan and the Sales Deployment Plan. In the case of Pfizer, Pfizer
shall ensure that (i) the number of Details in a Calendar Year by Pfizer Sales Representatives is
not less than six hundred twenty-five thousand (625,000) Details (for the remainder of 2018 Calendar
Year following the Launch Date, Pfizer shall deliver one hundred forty thousand (140,000) Details)
and (ii) if the Product is Promoted by Pfizer Sales Representatives (A) in position 2 or higher, the
Incentive Compensation weighting directly tied to the Product shall not be less than thirty percent
(30%) of Incentive Compensation available to be earned by such Sales Representative in the
applicable Calendar Quarter and (B) in position 3 or lower, the Incentive Compensation weighting
directly tied to the Product shall not be less than twenty-five percent (25%) of Incentive
Compensation available to be earned by such Sales Representative in the applicable Calendar Quarter.
If Pfizer delivers less than five hundred sixty-two thousand five hundred (562,500) Details in a
Calendar Year, then the Promotion Fee due Pfizer for such Calendar Year shall be reduced by the
applicable percentage set forth in the table on Exhibit 3.4(a), with such reduction to be deducted
from remittance of the Promotion Fee for the last Calendar Quarter of such Calendar Year; provided
that if such deduction exceeds the amount payable for such Calendar Quarter then Exact shall apply
any such remaining deduction to the Promotion Fee for the next Calendar Quarter or Calendar
Quarters, as necessary until the total deduction has been applied. If Pfizer delivers less than four
hundred fifty thousand (450,000) Details in a Calendar Year, in addition to percentage reduction of
the Promotion Fee set forth in the table on Exhibit 3.4(a), Exact shall have the right to terminate
this Agreement under Section 8.3(b), which termination shall not be subject to the right of Pfizer
to cure such breach. In no event shall Pfizer owe any monies to Exact for Detail shortfalls under
this Agreement other than to refund the Promotion Fee owed to Exact due to Detail shortfall in
accordance with this Section 3.4(a). Each Party shall be responsible for its own Sales
Representatives costs attributable to the Product, including base salary and Incentive Compensation,
normal travel and entertainment expenses, cost of fleet vehicles and other expenses normally
associated with Promotion of products and services similar to the Product. (b) Detailing Efforts and
Costs. Each Party shall have sole and exclusive control of all Detailing efforts and activities by
its Sales Representative and Representatives, and shall be solely responsible for the costs thereof.
Notwithstanding anything to the contrary in this Agreement or the 27

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 32 -->
Annual Marketing Plan, any Detailing costs incurred by a Party or its Affiliates in delivering the
Details assigned to such Party shall be the sole responsibility of such Party or Affiliate and shall
not be a Baseline M&P Expense or Shared M&P Expense or otherwise a shared cost pursuant to this
Agreement. (c) IDN Promotion. As part of this Agreement, Pfizer agrees to deploy its IDN Key Account
Managers (or successor team with similar responsibilities, the "KAM Team") to support understanding
and uptake of the Product by IDN customers in accordance with the Annual Marketing Plan. In
furtherance, prior to the beginning of each Calendar Year, Pfizer shall discuss and agree with Exact
on the defined goals and key performance indicators for the KAM Team. Pfizer and Exact shall agree
to execution goals and deliverables of resources, subject to review and approval of the JRC, to be
used by the KAM Team with IDN customers, and the tracking of such execution goals and deliverables
using a scorecard. (d) Reporting. Within fifteen (15) Business Days after the end of each month
during the Term, each Party shall provide to the other Party a written report setting forth (i) the
number of Details completed during such month and (ii) any changes to Incentive Compensation or
selling position of the Product by Sales Representatives during such month. Exact shall provide to
Pfizer a weekly report detailing, on an Eligible Prescriber-by-Eligible Prescriber basis, the
Product Laboratory Services activity, including but not limited to, the number of orders received,
number of shipments sent to patients, and number of results sent back to prescriber. 3.5 Pfizer
Investment and Support. Pfizer shall make financial investment in Marketing and Promoting the
Product in accordance with and in all cases subject to the budget in the applicable Annual Marketing
Plan (as the same may be adjusted as provided in Section 3.3) and shall be equal to fifty percent
(50%) of Shared M&P Expense, in the amounts set forth in the chart below. Pfizer, at its own
expense, shall use commercially reasonable efforts to carry out Pfizer's responsibilities under the
Annual Marketing Plan, which commercially reasonable efforts shall include committing the
appropriate resources to assist in the implementation of the Annual Marketing Plan and to carry out
the activities Pfizer is responsible for thereunder and hereunder. Pfizer will make investments as
set forth in the chart below. Notwithstanding the above, Pfizer agrees to invest its portion of
Shared M&P Expense each Calendar Year subject to, (a) Exact spending at least twelve million dollars
($12,000,000) in Baseline M&P Expense each Calendar Quarter (provided, that notwithstanding Exact's
quarterly spend for Baseline M&P Expense, Exact shall spend a total of eighty million dollars
($80,000,000) in Baseline M&P Expense each Calendar Year measured as of the end of each Calendar
Year), (b) an amount equal to the total Shared M&P Expense contributed by both Parties is used for
Marketing and Promotion and (c) a total sum of not less than eighty million dollars ($80,000,000) of
Baseline M&P Expense is used for Marketing and Promotional activities, including the costs of Exact
Sponsorships and Related Activities; provided, however, the Parties may agree to reallocate Shared
M&P Expenses by 28

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 33 -->
mutual written consent. Pfizer agrees to match dollar for dollar Exact's Shared M&P Expense for a
Calendar Year to up to the amounts specified in the chart below. Calendar Year Pfizer's Shared M&P
Expense 2018 $24 million 2019 $22 million 2020 $21 million 2021 $20 million For any investment
period less than a full Calendar Year (other than 2018), Pfizer's Shared M&P Expense investment
shall be adjusted pro rata based on the number of months remaining until the end of the Calendar
Year. For Calendar Year 2018, Pfizer's Shared M&P Expense shall be adjusted to equal the number of
months remaining from the Launch Date to December 31, 2018 divided by twelve (12) multiplied by
twenty-four million dollars ($24,000,000); provided the requirements of this Section 3.5 are
satisfied. Pfizer shall have no obligation to incur Shared M&P Expenses in excess of the amount in
the above chart for the given Calendar Year, unless the Parties mutually agree to increase their
portion of the Shared M&P Expense. 3.6 Exact Investment and Support. Exact shall commit, at its sole
cost and expense and not subject to reimbursement by Pfizer, to maintaining its originally planned
out-of-pocket Marketing and Promotional spends of eighty million dollars ($80,000,000) in each of
the 2018, 2019, 2020, and 2021 Calendar Years, including the Exact Sponsorships and Related
Activities (the "Baseline M&P Expense"). In addition to Baseline M&P Expense, Exact shall invest
Shared M&P Expense in amounts to be matched by Pfizer pursuant to Section 3.5 above. Exact, at its
own expense, shall use its commercially reasonable efforts to carry out Exact's responsibilities
under the Annual Marketing Plan, which commercially reasonable efforts shall include committing the
appropriate resources to assist in the implementation of the Annual Marketing Plan and to carry out
the activities Exact is responsible for thereunder. In addition, except as provided for in Section
3.2(d), Exact shall be responsible for contracting with agencies and vendors who are or will be
providing services (including the development of Promotional Materials and Training Materials)
associated with the execution of the Annual Marketing Plan, shall timely pay all amounts due to such
agencies and vendors for such services and shall authorize Pfizer to interact directly with and
instruct such agencies and vendors in connection with such services as necessary and appropriate
under this Agreement. Calendar Year Exact's Baseline M&P Expense Exact's Shared M&P Expense 2018 $80
million $24 million 2019 $80 million $22 million 2020 $80 million $21 million 2021 $80 million $20
million 29

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 34 -->
For any investment period less than a full Calendar Year (other than 2018), Exact's Baseline M&P
Expense and Shared M&P Expense investment shall be adjusted pro rata based on the number of months
remaining until the end of the Calendar Year. For Calendar Year 2018, Exact's Baseline M&P Expense
and Shared M&P Expense shall be adjusted to equal the number of months remaining from the Launch
Date to December 31, 2018 divided by twelve (12) multiplied by eighty million dollars ($80,000,000)
or twenty-four million dollars ($24,000,000), as applicable; provided that the requirements of this
Section 3.6 are satisfied. Exact shall have no obligation to incur Shared M&P Expenses in excess of
the amount in the above chart for the given Calendar Year, unless the Parties each agree to increase
their portion of the Shared M&P Expense. 3.7 Changes in Shared M&P Expenses. In the event the
Parties agree to not implement or to discontinue implementation of a strategy or tactic included in
any Annual Marketing Plan, the applicable Shared M&P Expense investment set forth above shall be
either (a) adjusted if, during good faith discussions at the JSC, the Parties agree on the
implementation of a substitute strategy or tactic in place of the strategy or tactic that was not
implemented or was discontinued, which adjustment will reflect any difference in cost of such
substitute strategy or tactic or (b) reduced by the amount(s) allocated in the applicable budget for
such strategy or tactic under the applicable Annual Marketing Plan, if the Parties, during good
faith discussions at the JSC, agree not to implement a substitute strategy or tactic in place of the
strategy or tactic that was not implemented or which was discontinued. Any amount saved as result of
this Section 3.7 shall be re-deployed to other expenses associated with the Marketing of the
Product, unless otherwise determined by the JSC. 4. ACCOUNTING. 4.1 Responsibility for Shared M&P
Expenses. (a) General. Shared M&P Expenses contributed by Exact and Pfizer pursuant to Sections 3.5
and 3.6 shall be used solely to fund activities pursuant to the Annual Marketing Plan. The Parties
shall agree to Calendar Quarter phasing of Baseline M&P Expenses and Shared M&P Expenses for
budgeting purposes. The Parties will spend amounts contributed to Baseline M&P Expenses and Shared
M&P Expenses simultaneously throughout each Calendar Year, in a manner consistent with the approved
budget set forth in the Annual Marketing Plan. Any Baseline M&P Expenses and Shared M&P Expenses
budgeted but not spent in Calendar Quarter may be rolled over into the next Calendar Quarter. For
the avoidance of doubt, Pfizer will match dollar for dollar Exact's Shared M&P Expense for a
Calendar Year to up to the amounts set forth in Section 3.5. (b) Remainder of 2018. Promptly after
the Effective Date, Exact shall discuss with Pfizer its planned Marketing and Promotional spend
associated with the Product for the period beginning on the Effective Date and ending on December
31, 2018, so that Pfizer may understand and recommend 30

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 35 -->
reallocation of all or any portion of such planned Marketing and Promotional spend associated with
the Product. Budget phasing of 2018 pro-rated Baseline M&P Expenses and pro-rated Shared M&P
Expenses shall be done on the Calendar Quarter basis. Exact agrees it shall spend at least eighty
million dollars ($80,000,000) toward Marketing and Promotion (including any amounts spent between
January 1, 2018 and the Effective Date) and the pro-rated Shared M&P Expense for 2018. (c)
Reporting. Within fifteen (15) Business Days after the end of each month during the Term beginning
with October, 2018, Exact shall provide to Pfizer a written report setting forth the amount of
Baseline M&P Expenses and Shared M&P Expenses incurred and paid for by Exact during such month,
which report shall also provide sufficient itemization and detail related to such expenses in order
for Pfizer to confirm that such Baseline M&P Expenses and Shared M&P Expenses were incurred pursuant
to the Annual Marketing Plan. Pfizer, within fifteen (15) Business Days after the end of each month
during the Term, beginning with October, 2018, shall prepare and provide to Exact a written report
setting forth the aggregate amount of Shared M&P Expenses incurred and paid for by Pfizer during
such month, along with sufficient itemization and detail related to such expenses in order for Exact
to confirm that such Shared M&P Expenses were incurred pursuant to the Annual Marketing Plan. 4.2
Promotion Fee. (a) Calculation of Promotion Fee. From the Launch Date and ending on the last day of
the next Calendar Quarter and each subsequent Calendar Quarter during the Term, Exact shall owe
Pfizer a service fee equal to fifty percent (50%) of the product of: Laboratory Service Revenue
minus Baseline Laboratory Service Revenue ("Incremental Laboratory Service Revenue") for the
Calendar Quarter multiplied by Gross Margin Percent for the Calendar Quarter (such product, the
"Promotion Fee"). In no event shall the Gross Margin Percent used in the calculation of the
Promotion Fee be less than sixty-eight percent (68%) or more than seventy-four percent (74%). The
calculation of the Promotion Fee pursuant to this Section 4.2(a) is subject to Section 4.2(c) below.
Promotion Fee(s) and all compensation paid by Exact to Pfizer under this Agreement, even where
calculated as a percentage of sales, is intended to compensate Pfizer a fair market value for the
entirety of services that Pfizer is providing to Exact hereunder. The formula for the calculation of
the Promotion Fee is as follows: A = Laboratory Service Revenue B = Baseline Laboratory Service
Revenue C = Gross Margin Percent Promotion Fee = 0.5 * (A-B) * C 31

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 36 -->
(b) Baseline Laboratory Service Revenue. The chart below sets forth the Baseline Laboratory Service
Revenue for the Product for each Calendar Year during the Term (the "Calendar Year Baseline
Laboratory Service Revenue"). In the Annual Marketing Plan the appropriate Calendar Year Baseline
Laboratory Service Revenue shall be allocated among each Calendar Quarter during such Calendar Year,
taking into consideration seasonality or other sales demand variables. For 2018, the first Calendar
Quarter shall be from the Launch Date to December 31, 2018 and the Calendar Year Baseline Laboratory
Service Revenue allocated to that Calendar Quarter shall be $130 million.

Calendar Year Baseline Laboratory Service Revenue 2018 $441 million 2019 $622 million 2020 $861
million 2021 $1.191 billion (c) Supplemental Promotion Fee. (i) Subject to Pfizer's compliance with
Sections 3.4(a)(i) and 3.4(a)(ii), (A) Exact shall pay Pfizer the amount, if any, by which the
aggregate amount of the Promotion Fee incurred by Exact to Pfizer during the remainder of 2018
Calendar Year and 2019 Calendar Year (the "First Promotion Fee Period") is less than $37.5 million
(the "First Supplemental Promotion Fee"), and (B) Exact shall pay Pfizer the amount, if any, by
which the aggregate Promotion Fee incurred by Exact to Pfizer during each of Calendar Year 2020 and
2021 is less than $30 million ("Annual Supplemental Promotion Fee"), in each case to compensate
Pfizer for the sales, Marketing and other performance provided by Pfizer under this Agreement. (ii)
As of June 30 of each Calendar Year during the Term, Exact shall calculate a partial-period amount
to be paid toward the potential First Supplemental Promotion Fee or the potential Annual
Supplemental Promotion Fee, as the case may be. With regard to the First Supplemental Promotion Fee,
the partial-period payment shall be equal to the amount by which the Promotion Fee for 2018, and the
first six (6) months of Calendar Year 2019, is less than $22.5 million, and with regard to each
Annual Supplemental Promotion Fee, the partial-period payment shall be equal to the amount by which
the Promotion Fee for the six-month (6-month) period through June 30 is less than $15 million. (iii)
As of December 31 of each Calendar Year during the Term, Exact shall calculate the First
Supplemental Promotion Fee or the Annual Supplemental Promotion Fee, as the case may be, if any, for
the entirety of the applicable period. Exact shall pay Pfizer the First 32

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 37 -->
Supplemental Promotion Fee or the Annual Supplemental Promotion Fee, as the case may be, if any,
less any partial-period payment made by Exact during the applicable period pursuant to Section
4.2(c)(ii). (iv) To the extent the amount of the Promotion Fee for the First Promotion Fee Period
exceeds the First Supplemental Promotion Fee, Exact shall be entitled to a credit of such excess
amount up to the amount of any partial-period payment made by Exact during such First Promotion Fee
Period pursuant to Section 4.2(c)(ii), and Exact shall apply such credit toward the Promotion Fee
payment due Pfizer for the fourth Calendar Quarter of 2019 (or due for subsequent Calendar Quarters
until such credit is fully exhausted). To the extent the amount of the Promotion Fee for any
Calendar Year after 2019 exceeds the Annual Supplemental Promotion Fee for such Calendar Year, Exact
shall be entitled to a credit of such excess amount up to the amount of any partial-period payment
made by Exact during such Calendar Year pursuant to Section 4.2(c)(ii), and Exact shall apply such
credit toward the Promotion Fee payment due Pfizer for the fourth Calendar Quarter of such Calendar
Year (or due for subsequent Calendar Quarters until such credit is fully exhausted). (v) Any amounts
due under Sections 4.2(c)(i) and (ii) shall be payable within thirty (30) days after each of June 30
, and December 31 of each Calendar Year, beginning with June 30, 2019, as applicable. (d) OB/Gyn
Sales. If Exact (i) grants OB/Gyn Commercial Rights to a Third Party in accordance with Section
3.1(c) or (ii) launches its own sales channel in the OB/Gyn Field (as applicable, the "Excluded
Channel"), then the Laboratory Service Revenue used to perform the calculation set forth in Section
4.2(a) and to determine royalty payments pursuant to Section 8.7 shall exclude all Laboratory
Service Revenue attributable to the Excluded Channel except a mutually agreed percentage of
Laboratory Service Revenue during the applicable period attributable to such Excluded Channel (the
"Included Revenue Percentage"); provided, that (A) such Included Revenue Percentage will reflect the
anticipated relative contribution of the Parties with regard to the Excluded Channel after such
launch, and (B) the Included Revenue Percentage shall not be less than the revenue percentage
attributable to the OB/Gyn Field as of the date of such launch, calculated on the same basis that
revenue from the OB/Gyn Field is calculated by Exact on the Effective Date. 4.3 Fee Statements and
Payments. (a) Monthly and Quarterly Financial Deliverables. Exact shall on a monthly basis, not
later than fifteen (15) Business Days after the end of the month, deliver to Pfizer a full suite of
performance data, including Product Laboratory Services completed, average selling price per unit,
Laboratory Service Revenue, rebates, net revenue and a detailed Cost of Sales schedule 33

th

s t

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 38 -->
(consisting of collection kits distributed to patients, royalties paid, shipping costs, lab
operating expenses and reagent costs). Not later than fifteen (15) Business Days after the end of
the Calendar Quarter, Exact shall deliver to Pfizer a rolling sales forecast and an estimate, for
the remaining Calendar Quarters in the Calendar Year, of the Promotion Fee as set forth in Section
4.2. (b) Payment of Promotion Fee. Exact, within thirty (30) days after the end of each Calendar
Quarter of the Term, shall deliver to Pfizer a consolidated report in the form of and containing the
information necessary to confirm the calculation of the Promotion Fee for such Calendar Quarter,
together with the underlying spreadsheets with respect to such Calendar Quarter. The Promotion Fee
due with respect to such Calendar Quarter and reflected on the consolidated report shall be remitted
at the time such report is made. 4.4 Taxes and Withholding. It is understood and agreed between the
Parties that any payments made under this Agreement are exclusive of any value added or similar tax
("VAT"), and that no such VAT shall apply to the payments made under this Agreement. In the event
any payments made pursuant to this Agreement become subject to withholding taxes under the laws or
regulation of any jurisdiction, the Party making such payment shall deduct and withhold the amount
of such taxes for the account of the payee to the extent required by Applicable Law and such amounts
payable to the payee shall be reduced by the amount of taxes deducted and withheld. Any such
withholding taxes required under Applicable Law to be paid or withheld shall be an expense of, and
borne solely by, the payee. To the extent that the Party making a payment is required to deduct and
withhold taxes on any payments under this Agreement, the Party making such payment shall pay the
amounts of such taxes to the proper Governmental Authority in a timely manner and promptly transmit
to the payee an official tax certificate or other evidence of such withholding sufficient to enable
the payee to claim such payments of taxes. The payee shall provide any tax forms to the Party making
such payment that may be reasonably necessary in order for such Party not to withhold tax or to
withhold tax at a reduced rate under an applicable bilateral income tax treaty. The payee shall use
commercially reasonable efforts to provide any such tax forms to the Party making the payment at
least thirty (30) days prior to the due date for any payments for which the payee desires that the
Party making the payment apply a reduced withholding rate. Each Party shall provide the other with
reasonable assistance to enable the recovery, as permitted by Law, of withholding taxes, VAT, or
similar obligations resulting from payments made under this Agreement, such recovery to be for the
benefit of the Party bearing such withholding tax or VAT. Notwithstanding anything in this Agreement
to the contrary, (a) if an action (including any assignment or sublicense of its rights or
obligations under this Agreement, or any failure to comply with Applicable Law or filing or record
retention requirements) by a Party leads to the imposition of withholding tax liability or VAT on
the other Party that would not have been imposed in the absence of such action or in an increase in
such liability above the liability that would have been imposed in the absence of such action, then
the sum payable by that Party (in respect of which such deduction or withholding is required to be
made) shall be increased to the extent necessary to ensure that the other Party 34

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 39 -->
receives a sum equal to the sum which it would have received had no such action occurred, (b)
otherwise, the sum payable by that Party (in respect of which such deduction or withholding is
required to be made) shall be made to the other Party after deduction of the amount required to be
so deducted or withheld, which deducted or withheld amount shall be remitted in accordance with
Applicable Law. 4.5 No Partnership Provision. It is expressly agreed that Pfizer and Exact shall be
independent contractors and that the relationship between Pfizer and Exact shall not constitute a
partnership, joint venture or agency. The Parties agree that the rights and obligations under this
Agreement are not intended to constitute a partnership or similar arrangement that will require
separate reporting for tax purposes consistent with the intent reflected in the foregoing sentence
and agree that they shall not file any reports, documents or other item relating to taxes or state
or acknowledge to any tax authority that such relationship is a partnership or similar arrangement
unless required by Applicable Law. 4.6 Payments; Currency. All payments due by one Party to the
other Party hereunder shall be paid by wire transfer in immediately available funds from the account
or accounts of a Party and/or its Affiliates to an account or accounts of the receiving Party and/or
its Affiliates designated in writing by the receiving Party. All amounts payable and calculations
hereunder shall be in United States dollars. 4.7 Maintenance of Records; Audits. (a) Record Keeping.
Each Party shall keep and shall cause its Affiliates to keep accurate books and accounts of record
in connection with (i) its Marketing and Promotion of the Product, (ii) (with respect to Exact)
performance of Product Laboratory Services, and (iii) its activities under this Agreement and any
Annual Marketing Plan, in sufficient detail to permit accurate determination of all figures
necessary for verification of (A) amounts to be paid hereunder and (B) compliance with the terms of
this Agreement. Each Party shall, and shall cause its Affiliates to, maintain such records for a
period of at least three (3) years after the end of the Calendar Year to which they pertain. (b)
Financial Audits. (i) Audit Right. Upon thirty (30) days prior written notice from a Party (the
"Auditing Party"), the other Party (the "Audited Party") shall permit an independent certified
public accounting firm of nationally recognized standing selected by the Auditing Party and
reasonably acceptable to the Audited Party, to examine, at the Auditing Party's sole expense, the
relevant books and records of the Audited Party and its Affiliates as may be reasonably necessary to
verify the accuracy of the reports submitted by the Audited Party in accordance with Sections
3.4(d), 4.1(c) and 4.3(a) and the payment of Promotion Fees hereunder. An examination by the
Auditing Party under this Section 4.6(b) shall occur not more than once in any Calendar Year and
shall 35

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 40 -->
be limited to the pertinent books and records for any Calendar Year during the Term ending not more
than twenty-four (24) months before the date of the request. The accounting firm shall be provided
access to such books and records at the Audited Party's facility(ies) in the Territory where such
books and records are normally kept and such examination shall be conducted during the Audited
Party's normal business hours. The Audited Party may require the accounting firm to sign a standard
non-disclosure agreement before providing the accounting firm access to the Audited Party's
facilities or records. Upon completion of the audit, the accounting firm shall provide both Pfizer
and Exact a written report disclosing whether the reports submitted by the Audited Party are correct
or incorrect, whether the Promotion Fees paid during the audited period or Baseline M&P Expenses or
Shared M&P Expenses incurred during the audited period are correct or incorrect, and, in each case,
the specific details concerning any discrepancies. No other information shall be provided to the
Auditing Party. The decision of the accounting firm will be final and unappealable absent manifest
error. (ii) Underpayments/Overpayments. If such accounting firm concludes that additional Promotion
Fees were due to Pfizer, Exact shall pay to Pfizer an amount equal to the actual Promotion Fee due
minus the Promotion Fee paid within thirty (30) days of the date Exact receives such accountant's
written report so concluding. If such accounting firm correctly concludes that Promotion Fees paid
to Pfizer were in excess of the amount properly due, Pfizer shall pay or refund to Exact an amount
equal to the Promotion Fee paid minus the actual Promotion Fee due within thirty (30) days of the
date Exact receives such accountant's written report so concluding. (c) Compliance Audit. Upon
thirty (30) days prior written notice from an Auditing Party, the Audited Party shall permit the
Auditing Party's external auditors access to any relevant books documents, papers, and records of
the Party involving any report delivered pursuant to Sections 3.2(d), 3.4(d) and 4.3(a) of this
Agreement and the activities performed under this Agreement, if the other Party has credible
evidence that the other Party violated terms of this Agreement, including with respect to Product
Training under Section 3(e). An examination by a Party under this Section 4.6(c) shall (i) occur not
more than once in any Calendar Year, (ii) be limited to the pertinent books and records for any
Calendar Year during the Term ending not more than twenty-four (24) months before the date of the
request and (iii) be at the sole expense of the Auditing Party. The external auditors of the
Auditing Party shall be provided access to such books and records at the Audited Party's
facility(ies) in the Territory where such books and records are normally kept and such examination
shall be conducted during the Audited Party's normal business hours. The Audited Party may require
any external auditors to sign a standard non-disclosure agreement before providing the accounting
firm access to the Audited Party's facilities or records. 36

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 41 -->
(d) Confidentiality. All financial and other confidential information of the Audited Party which is
subject to review under this Section 4.6 shall be deemed to be the Audited Party's Confidential
Information and, subject to the provisions of Article 6 hereof, the Auditing Party shall not
disclose such Confidential Information to any Third Party or use such Confidential Information for
any purpose other than verifying compliance with this Agreement. 5. REPRESENTATIONS, WARRANTIES AND
COVENANTS. 5.1 Mutual Representations and Warranties. Each of Exact and Pfizer hereby represents and
warrants to the other Party as of the Effective Date that: (a) it is duly organized, validly
existing and in good standing under the laws of the jurisdiction of its organization; (b) the
execution, delivery and performance of this Agreement by such Party has been duly authorized by all
requisite action under the provisions of its certificate of incorporation, bylaws and other
organizational documents, and does not require any action or approval by any of its shareholders or
other holders of its voting securities or voting interests that has not been taken; (c) it has the
power and authority to execute and deliver this Agreement and to perform its obligations hereunder;
(d) this Agreement has been duly executed by an appropriate representative of such Party and is a
legal, valid and enforceable against such Party in accordance with its terms; (e) the execution,
delivery and performance by such Party of this Agreement and its compliance with the terms and
provisions hereof does not and will not conflict with or result in a breach of or default under (i)
any oral or written agreement that binds such Party's operations or property, including any
assignment, license agreement, loan agreement, guaranty or financing agreement, (ii) the provisions
of such Party's certificate of incorporation, bylaws or other organizational documents, or (iii) any
order, writ, injunction, decree or judgment of any court or Governmental Authority entered against
such Party or by which any of such Party's operations or property are bound; (f) all material
written information provided by each Party in the virtual data room maintained for the purposes of
the proposed transactions under this Agreement is complete, truthful and accurate in all material
respects; and (g) neither it, nor any of its Affiliates, nor, to such Party's knowledge, any of
their respective Representatives has been debarred or suspended under 21 U.S.C. § 335(a) or (b),
excluded from a federal health care program, debarred from federal contracting, or convicted of or
pled nolo contendere to any felony, or to any federal or state legal violation (including
misdemeanors) relating to medical devices or fraud ("Debarred/Excluded"). 37

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 42 -->
5.2 Representations and Warranties of Exact. Exact hereby represents and warrants to Pfizer as of
the Effective Date that: (a) no consent is required from any Third Party for Exact to enter into, or
to exercise its rights and perform its obligations under, this Agreement; (b) in connection with the
development, manufacturing and Promotion of the Product, except as would not reasonably be expected
to have a material adverse effect on the Promotion of the Product in the Territory, Exact has
complied and will continue to comply in all material respects with Applicable Law, including the
FD&C Act, the Anti-Kickback Statute (42 U.S.C. § 1320a-7b), Civil Monetary Penalty Statute (42
U.S.C. § 1320a-7a), the False Claims Act (31 U.S.C. § 3729 et seq.), comparable state statutes, the
regulations promulgated under all such statutes, and the regulations issued by the FDA; (c) with
respect to the development, manufacturing and Promotion of the Product, Exact has not taken and will
not take any action directly or indirectly to offer, promise or pay, or authorize the offer or
payment of, any money or anything of value in order to improperly or corruptly seek to influence any
Government Official in order to gain an improper advantage; (d) in connection with Exact's
manufacturing and Promotion of Product or Exact's performance of the Product Laboratory Service in
the Territory or directly relating to the transactions contemplated by this Agreement, except as
would not reasonably be expected to have a material adverse effect on the Promotion of the Product
in the Territory, (i) no written claim, demand, suit, investigation or other legal action of any
nature, civil, criminal, regulatory or otherwise, has been filed and received by Exact, and is
pending in any court, arbitration or government agency proceeding nor, to the knowledge of Exact,
has any claim, demand, suit, investigation or other legal action of any nature, civil, criminal,
regulatory or otherwise been threatened in writing, to be filed against Exact in any court,
arbitration or government agency proceeding; and (ii) there is no judgment or settlement against or
owed by Exact; (e) Exact has not received written notice from any Third Party claiming that the
manufacture, use, sale or importation by or on behalf of Exact of the Product in the Territory or
the performance of any Product Laboratory Service by or on behalf of Exact (i) infringes any issued
patent or intellectual property right of such Third Party in the Territory or (ii) will infringe any
claim of any published patent application of such Third Party in the Territory when and if such
claim issues; (f) to Exact's knowledge, the manufacture, use, sale or importation by or on behalf of
Exact of the Product in the Territory or the performance of any Product Laboratory Service by or on
behalf of Exact (i) does not infringe any issued patent or intellectual property right of any Third
Party in the Territory 38

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 43 -->
or (ii) will not infringe any claim of any published patent application of any Third Party in the
Territory when and if such claim issues; and (g) Exact is not presently engaged in any discussions
with any Third Party with respect to the grant to any Third Party of and does not currently have any
agreement with any Third Party to grant any right or license to make, use, import, offer for sale or
sell any Product, in the Territory, in each case, which would constitute a grant of Ex-US Commercial
Rights or OB/Gyn Commercial Rights. 5.3 Covenants. (a) Each Party hereby covenants to the other
Party that, during the Term in the Territory: (i) it will immediately remove any Sales
Representative from having any responsibilities relating to Promotion of the Product under this
Agreement if required by Applicable Laws, including if such Party determines that such Sales
Representative is Debarred/Excluded; (ii) it will promptly remove any Sales Representative from
having any responsibilities relating to the Promotion of the Product under this Agreement if,
following an investigation, it is determined that there has been a significant violation of any
Applicable Laws, or the Party's Applicable Compliance/Review Policies by such Sales Representative;
and (iii) it will not knowingly make any untrue or misleading statements or comments about the
Product. (b) Pfizer hereby covenants to Exact that, during the Term in the Territory, it, its
Affiliates and its Sales Representatives will not (i) Promote the Product outside of the Territory
or the Co-Promote Field; or (ii) disparage or present in a negative light the Product in the
performance of its obligations hereunder; provided that nothing herein shall be interpreted to
preclude Pfizer from (A) describing any risks of a Product set forth in the Product Label or (B)
making truthful statements about the Products to the extent required by Applicable Laws, in
connection with any litigation or in response to any question, inquiry or request for information
when required by legal process (e.g., a valid subpoena or other similar compulsion of law) or as
part of a government investigation. (c) Exact hereby covenants that neither Exact nor its Affiliates
shall sue Pfizer and its Affiliates under any Exact Patent Rights solely with respect to any
activities carried out by Pfizer or its Affiliates under, and to the extent in compliance with, this
Agreement, including its and their activities to Promote and Detail the Product in the Co-Promote
Field in the Territory during the Term of this Agreement and in compliance with this Agreement. 39

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 44 -->
5.4 Compliance with Law and Ethical Business Practices. In addition to the other representations,
warranties and covenants made by each Party under this Agreement, each Party hereby represents,
warrants and covenants to the other Party that, during the Term in the Territory: (a) it is, and
will remain during the Term, licensed, registered and/or qualified under Applicable Law to do
business, and has obtained such licenses, consents, authorizations or completed such registration or
made such notifications as may be necessary or required by Applicable Law to perform its obligations
under this Agreement; (b) it will perform its obligations under this Agreement in material
compliance with this Agreement and any applicable Annual Marketing Plan, its Applicable
Compliance/Review Policies and Applicable Laws (including the FD&C Act, the Anti- Kickback Statute
(42 U.S.C. § 1320a-7b), Civil Monetary Penalty Statute (42 U.S.C. § 1320a-7a), the False Claims Act
(31 U.S.C. § 3729 et seq.), comparable state statutes, the regulations promulgated under all such
statutes, and the regulations issued by the FDA); (c) in connection with the activities contemplated
by this Agreement, to each Party's knowledge, it has been, and during the Term will be, in
compliance with all applicable U.S. trade laws, including those related to, import controls, export
controls, or economic sanctions; (d) it will ensure its own compliance with all Applicable Laws; (e)
with respect to the Product and any payments or services provided under this Agreement, such Party
has not taken, and during the Term will not take, any action, directly or indirectly, to offer,
promise or pay, or authorize the offer or payment of, any money or anything of value in order to
improperly or corruptly seek to influence any Government Official in order to gain an improper
advantage, and has not accepted, and will not accept in the future such payment; (f) each Party
hereby certifies that it has implemented and will maintain and enforce a compliance and ethics
program designed to prevent and detect violations of Applicable Laws throughout its operations
(including Affiliates) and the operations of its Representatives that have responsibility for
Product, payments, or services provided under the Agreement, including by implementing policies and
procedures setting out rules governing interactions with healthcare professionals and Government
Officials; the engagement of third parties, and where appropriate, due diligence; and the
investigation, documentation, and remediation of any allegations, findings, or reports related to a
potential violation of its Applicable Compliance/Review Policies. Such compliance program shall
include at a minimum, compliance officer, compliance committee(s), policies and procedures relating
to (i) sales, medical, Promotional and Marketing activities for the Product, (ii) regular auditing
and monitoring, (iii) training 40

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 45 -->
on sales, medical, Promotional and Marketing activities and the relevant legal requirements
regarding such activities, (iv) methods to raise questions or concerns internally (e.g., via a
hotline) without fear of retribution or retaliation, (v) processes for investigating and documenting
any compliance concerns or allegations raised, findings or reports related to a potential violation
of Applicable Laws, and (vi) taking remedial, corrective action and/or disciplinary action, as
appropriate; (g) has implemented, and will maintain and enforce, a system of internal accounting
controls designed to ensure the making and keeping of fair and accurate books, records, and accounts
with respect to products, payments, or services provided under this Agreement, and regularly
monitors and audits its business activities to ensure compliance with its Applicable
Compliance/Review Policies and the adequacy of internal controls, and implements remediation in
response to identified issues; (h) it will (A) maintain truthful and complete documentation
supporting, in reasonable detail, the work performed and any expenses incurred in connection with
this Agreement and any products, payments, or services provided under this Agreement and (B)
maintain financial books and records that timely, fairly, accurately, and completely reflect all
financial transactions, in accordance with all Applicable Laws (for example, invoices, reports,
statements, books, and other records), and shall maintain such books and records during the Term of
the Agreement and for three years after final payment has been made under the Agreement; (i) it
provides, and during the Term will provide, training to Representatives providing services in
connection with this Agreement; (j) every year of this Agreement that coincides with the term of the
Corporate Integrity Agreement ("CIA") entered into on May 23, 2018 between Pfizer and the United
States Department of Health and Human Services, Office of Inspector General, Pfizer will send a
letter to Exact that: (A) summarizes Pfizer's obligations under the CIA, (B) expresses Pfizer's
commitment to full compliance with all federal health care program requirements, (C) describes the
Pfizer Compliance Program and (D) includes a copy of (or includes a link to) Pfizer's code of
conduct (referred to as the Blue Book). Within thirty (30) days of receipt of this letter, Exact
shall respond in writing to the contact information included in Pfizer's letter that Exact shall:
(1) make Pfizer's code of conduct and a description of the Pfizer Compliance Program available to
its employees engaged in activities related to the Agreement or (2) represent to Pfizer that it has
and enforces a substantially comparable code of conduct and compliance program for its employees who
have responsibilities related to the Agreement; and (k) with respect to the Product and any payments
made or services provided under this Agreement: 41

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 46 -->
(i) in the event that such Party receives a report of or otherwise becomes aware of a potential
violation of its Applicable Compliance/Review Policies, the Party will perform an investigation in
accordance with its established policies and procedures and will take all necessary and appropriate
responsive, and corrective actions, including disciplinary actions (up to and including termination
of any employee, contractor, agent, sub-contractor, customer, vendor or other Person that the Party
believes was responsible); (ii) such Party has implemented, and will at all times during the Term
maintain, adequate policies and procedures describing the materials and information that may be
distributed or discussed by the Party's Sales Representatives related to the Product and the manner
in which such Persons should handle unsolicited requests for information related to off-label uses
of the Product, which policies and procedures shall be designed to ensure compliance with Applicable
Laws and regulations; (iii) such Party regularly reviews its Applicable Compliance/Review Policies
as part of its internal processes of improvement, and, from time to time, benchmarks them against
the standards of the industry; (iv) such Party has implemented, and will at all times during the
Term maintain, adequate systems, policies, and procedures to screen before hire and annually
thereafter all prospective and current Representatives conducting activities with respect to the
Product against (A) the List of Excluded Individuals/Entities compiled by the Office of the
Inspector General in the Department of Health and Human Services and (B) the General Services
Administration's List of Parties Excluded from Federal Programs, which policies and procedures
require each Party's prospective and current Representatives conducting activities with respect to
the Product to disclose immediately to the Party that such Representative is or may become
Debarred/Excluded; (v) neither Party shall provide funding to the other Party for charitable
donations to independent charities that provide financial assistance to patients, including sharing
costs associated with such donations; provide information to the other Party concerning its own such
donations; or seek to obtain information about such donations from the other Party. Each Party shall
have appropriate policies and procedures to ensure that such donations comply with Applicable Law
and current government guidance, including without limitation guidance issued by the U.S. Department
of Health and Human Services, Office of Inspector General, and shall operate consistent with those
policies and procedures. Unless a Party does not and will not make such donations during the Term of
the Agreement, if a Party does not have appropriate policies and procedures in place on 42

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 47 -->
the Effective Date, the Party must implement such policies and procedures within thirty (30) days of
the Effective Date. Either Party may request copies of such policies and procedures of the other
Party in order to confirm compliance with the requirements of this Section; (vi) certifies that in
connection with this Agreement, such Party's compensation system for its Representatives that
perform any Marketing, Promotion, or sales activities related to the Product is designed to ensure
that financial incentives do not inappropriately motivate such Representative to engage in improper
or illegal Promotion, sales or Marketing of the Product (including off-label Promotion of the
Product), and excludes from Incentive Compensation sales that may be attributable to the off-label
use of the Product; and (vii) in connection with this Agreement, each Party's call planning system
for its Sales Representatives that call upon health care professionals or health care institutions
for any Promotional or sales activities related to the Product is designed to ensure that such Sales
Representatives do not call upon health care professionals or health care institutions that are not
likely to prescribe or use the Product for an on-label use. 5.5 Notice of Investigations. Each Party
shall promptly notify the other Party in the event that it becomes subject to or aware of any FDA or
other Governmental Authority inspection, investigation, or other inquiry or a FDA warning letter,
untitled letter, or other material governmental notice or communication relating to the services or
products covered by this Agreement promptly after the Party becomes aware of such inspection,
investigation, inquiry, letter, notice, or communication, except to the extent that the disclosing
Party's counsel reasonably believes that such disclosure to the other Party could violate Applicable
Laws (including privacy laws) or have a significant adverse impact on the disclosing Party's legal
position or defense (including the loss of attorney-client privilege) with respect to any such
inspection, investigation or other inquiry. In the event that the Party determines that disclosure
could violate Applicable Laws (including privacy laws) or have a significant adverse impact on the
disclosing Party's legal position or defense (including the loss of attorney-client privilege), the
Party shall promptly notify the other Party that it is exercising its right not to make such
disclosure. 5.6 Representation by Legal Counsel. Each Party hereto represents that it has been
represented by legal counsel in connection with this Agreement and acknowledges that it has
participated in the drafting hereof. In interpreting and applying the terms and provisions of this
Agreement, the Parties agree that no presumption shall exist or be implied against the Party which
drafted such terms and provisions. 5.7 No Inconsistent Agreements. Neither Party shall enter into
any oral or written agreement or arrangement that would be inconsistent with its obligations under
this Agreement. 43

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 48 -->
5.8 Disclaimer. THE FOREGOING WARRANTIES OF EACH PARTY ARE IN LIEU OF ANY OTHER WARRANTIES, EXPRESS
OR IMPLIED, INCLUDING ANY IMPLIED WARRANTIES OF NONINFRINGEMENT, ANY IMPLIED WARRANTIES OF
MERCHANTABILITY OR ANY IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR PURPOSE ALL OF WHICH ARE
HEREBY SPECIFICALLY EXCLUDED AND DISCLAIMED. 6. INDEMNIFICATION; LIMITATION OF LIABILITY AND
INSURANCE. 6.1 Indemnification. (a) Indemnification by Exact. Exact shall indemnify, defend and hold
Pfizer, its Affiliates and their respective Representatives (the "Pfizer Indemnitees") harmless from
any claims, damages, actions, liabilities, losses, costs and expenses, including attorneys' fees
incurred in defending against them, (hereinafter "Claims") of a Third Party arising out of (A) the
manufacture, Marketing, education, Promotion, importation or use of the Product or the performance
of the Product Laboratory Service by Exact or its Representatives; (B) any breach by Exact of any of
its representations, warranties or obligations under this Agreement; or (C) any negligent or
wrongful act or omission of Exact; and (D) any alleged patent infringement, regardless of direct,
contributory or inducement, by Pfizer, its Affiliates or their respective Representatives, as a
result of the performance of Pfizer's obligations under this Agreement; except, in each case (A) -
(D), to the extent such Claims arise out of any breach by any Pfizer Indemnitee of any of its
obligations under this Agreement, or any negligent or wrongful act or omission of any Pfizer
Indemnitee. (b) Indemnification by Pfizer. Pfizer shall indemnify, defend and hold Exact, its
Affiliates and their respective Representatives (the "Exact Indemnitees"), harmless from any Claims
of a Third Party, to the extent arising out of (i) any breach by Pfizer of any of its
representations, warranties, or obligations under this Agreement or (ii) any negligent or wrongful
act or omission of Pfizer, except to the extent such Claims arise out of any breach by any Exact
Indemnitee of any of its obligations under this Agreement, or any negligent or wrongful act or
omission of any Exact Indemnitee; provided that in no event shall Pfizer have any obligation to
indemnify Exact for any product liability claim arising out of bodily injury or death arising from
the use of the Product. (c) Procedure. (i) A Party believing that it is entitled to indemnification
under Section 6.1 (an "Indemnified Party") shall give prompt written notification to the other Party
(the "Indemnifying Party") of the commencement of any Claim by a Third Party for which
indemnification may be sought or, if earlier, upon the assertion of any such Claim by a Third Party
(it being understood and agreed, however, that the failure by an Indemnified Party to give notice of
a Third Party Claim as provided 44

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 49 -->
in this Section 6.1(c) shall not relieve the Indemnifying Party of its indemnification obligation
under this Agreement except and only to the extent that such Indemnifying Party is actually
materially prejudiced as a result of such failure to give notice). Within thirty (30) days after
delivery of such notification, the Indemnifying Party may, upon written notice thereof to the
Indemnified Party, assume control of the defense of such Claim with counsel reasonably satisfactory
to the Indemnified Party. If a Party believes that a Claim presented to it for indemnification is
one as to which the Party seeking indemnification is not entitled to indemnification under Section
6.1, it shall so notify the Party seeking indemnification. (ii) If the Indemnifying Party elects to
assume the defense of such Claim, the Indemnified Party may participate in such defense at its own
expense; provided that if the Indemnified Party reasonably concludes, based on advice from counsel,
that the Indemnifying Party and the Indemnified Party have conflicting interests with respect to
such Claim, the Indemnifying Party shall be responsible for the reasonable fees and expenses of
counsel to the Indemnified Party solely in connection therewith. (iii) The Indemnifying Party shall
keep the Indemnified Party advised of the status of such Claim and the defense thereof and shall
consider recommendations made by the Indemnified Party with respect thereto. (iv) The Indemnified
Party shall not agree to any settlement of such Claim without the prior written consent of the
Indemnifying Party, which shall not be unreasonably withheld. The Indemnifying Party shall not agree
to any settlement of such Claim or consent to any judgment in respect thereof that does not include
a complete and unconditional release of the Indemnified Party from all liability with respect
thereto or that imposes any liability or obligation on the Indemnified Party or adversely affects
the Indemnified Party without the prior written consent of the Indemnified Party, which shall not be
unreasonably withheld. 6.2 Insurance Requirements. Each Party agrees to obtain and maintain, during
the Term and for five (5) years after the Term, commercial general liability insurance, including
products liability insurance, with minimum "A-" AM Best rated insurance carriers, in each case with
limits of not less than five million dollars ($5,000,000) per occurrence and in the aggregate. All
deductibles/retentions will be the responsibility of the named insured. Pfizer and its Affiliates
will be an additional insured on Exact's commercial general liability and products liability
policies, and be provided with a waiver of subrogation. To the extent of its culpability, all
coverages of Exact will be primary and non-contributing with any similar insurance carried by
Pfizer. Notwithstanding any provision of this Section 6.2 to the contrary, Pfizer may meet its
obligations under this Section 6.2 through self-insurance. 45

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 50 -->
Neither Party's insurance will be construed to create a limit of liability with respect to its
indemnification obligations under this Section 6. 6.3 Limitation of Liability. NOTWITHSTANDING
ANYTHING TO THE CONTRARY IN THIS AGREEMENT, EXCEPT FOR (A) INDEMNIFICATION OBLIGATIONS OF A PARTY
UNDER SECTION 6.1, (B) A BREACH OF SECTION 7 BY A PARTY OR (C) THE WILLFUL MISCONDUCT OR GROSS
NEGLIGENCE OF A PARTY, NEITHER PARTY NOR ANY OF ITS AFFILIATES SHALL BE LIABLE TO THE OTHER PARTY OR
ANY OF ITS AFFILIATES FOR ANY SPECIAL, PUNITIVE, INDIRECT, INCIDENTAL OR CONSEQUENTIAL DAMAGES,
INCLUDING LOST PROFITS, LOST REVENUES OR PENALTIES ARISING FROM OR RELATING TO ANY BREACH OF THIS
AGREEMENT, REGARDLESS OF ANY NOTICE OF THE POSSIBILITY OF SUCH DAMAGES. 7. CONFIDENTIALITY;
PUBLICITY. 7.1 Confidentiality. Except to the extent expressly authorized by this Agreement or
otherwise agreed in writing, the Parties agree that, for the term of this Agreement and for five (5)
years thereafter, each Party (the "Receiving Party"), receiving any Confidential Information of the
other Party (the "Disclosing Party") hereunder shall keep such Confidential Information confidential
and shall not publish or otherwise disclose or use such Confidential Information for any purpose
other than as provided for in this Agreement. "Confidential Information" means any technical,
scientific, regulatory, commercial, business or other information provided by or on behalf of the
Disclosing Party to the Receiving Party pursuant to this Agreement or otherwise relating to or
disclosed during any transaction contemplated hereby (including information disclosed prior to the
Effective Date under a confidentiality agreement in contemplation of this Agreement), including
information relating to the terms of this Agreement or the Product, and the scientific, regulatory
or business affairs or other activities of either Party; provided that, Confidential Information
shall not include any information that the Receiving Party can establish: (a) was already known to
the Receiving Party (other than under an obligation of confidentiality), at the time of disclosure
by the Disclosing Party and such Receiving Party has documentary evidence to that effect; (b) was
generally available to the public or otherwise part of the public domain at the time of its
disclosure to the Receiving Party; (c) became generally available to the public or otherwise part of
the public domain after its disclosure or development, as the case may be, and other than through
any act or omission of a Party in breach of this confidentiality obligation; (d) was disclosed to
that Party, other than under an obligation of confidentiality, by a Third Party who had no
obligation, directly or indirectly, to the Disclosing Party, not to disclose such information to
others; or 46

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 51 -->
(e) was independently discovered or developed by or on behalf of the Receiving Party without the use
of the Confidential Information belonging to the other Party and the Receiving Party has documentary
evidence to that effect. 7.2 Authorized Disclosure and Use. (a) Disclosure. Notwithstanding the
foregoing Section 7.1, each Party may disclose to Third Parties Confidential Information belonging
to the other Party to the extent such disclosure is reasonably necessary to: (i) prosecute or defend
litigation, (ii) exercise or enforce rights hereunder; provided that such disclosure is covered by
terms of confidentiality no less stringent than those set forth herein, and (iii) comply with
inquires by a Governmental Authority or subpoena issued by a Governmental Authority or a court of
competent jurisdiction. In the event a Party shall deem it necessary to disclose pursuant to this
Section 7.2 Confidential Information belonging to the other Party, the Disclosing Party shall to the
extent possible give reasonable advance notice of such disclosure to the other Party and take
reasonable measures to ensure confidential treatment of such information. (b) Use. Notwithstanding
the foregoing Section 7.1, during the Term, each Party shall have the right to use the other Party's
Confidential Information in carrying out its respective responsibilities under this Agreement. 7.3
Certain Regulatory Filings. Either Party may disclose the terms of this Agreement to the extent
required, in the reasonable opinion of such Party's legal counsel, to comply with Applicable Laws,
including the rules and regulations promulgated by the United States Securities and Exchange
Commission or by any stock exchange or regulatory body to which the Party is subject. Before
disclosing this Agreement or any of the terms hereof pursuant to this Section 7.3, the Parties will
consult with one another regarding the terms in this Agreement to be redacted in making any such
disclosure. If a Party discloses this Agreement or any of the terms hereof in accordance with this
Section 7.3, such Party agrees, at its own expense, to seek confidential treatment of portions of
this Agreement or such terms, as may be reasonably requested by the other Party. 7.4 Public
Announcements. The Parties shall agree upon a joint press release to announce the execution of this
Agreement, a copy of which is attached as Exhibit 7.4.Neither Party shall issue any news release or
other public announcement relating to this Agreement except as set forth in Exhibit 7.4, including
any of its terms, or to the performance of either Party hereunder, without the prior written
approval of the other Party; provided that nothing in this Agreement shall prohibit Exact from
making required disclosures or filings required by Applicable Law or by the rules 47

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 52 -->
and regulations of any securities exchange. Once the text or substance of any announcement has been
so approved, it may be repeated without further approval. 7.5 Use of Names. Except as described in
this Agreement and as may be required by Applicable Law, neither Party shall distribute or have
distributed any publicity or information which bears the name of the other without the prior written
approval of the other. 8. TERM AND TERMINATION. 8.1 Term. This Agreement shall be effective as of
the Effective Date and shall continue in effect through December 31, 2021 and any Renewal Term (the
"Term"), unless terminated earlier as set forth herein. 8.2 Renewal. This Agreement may be renewed
for an additional one year term ("Renewal Term") upon mutual written agreement of the Parties.
Ninety (90) days prior to the beginning of the Renewal Term, or as far in advance as practicable if
the Parties agree to a Renewal Term less than ninety (90) days prior the commencement of such
Renewal Term, the Parties shall agree to a Baseline Laboratory Service Revenue, Baseline M&P
Expenses and Shared M&P Expenses for the Renewal Term. All other terms of this Agreement shall
remain the same through the Renewal Term. 8.3 Termination for Cause. This Agreement may be
terminated at any time by either Party effective: (a) upon thirty (30) days prior written notice if
the other Party fails to make the required investments pursuant to Sections 3.5 or 3.6, as
applicable, or pay any amount properly due under this Agreement; provided that neither Party may
terminate if the failure of the other Party to meet the investment requirements under Sections 3.5
or 3.6, as applicable, is de minimis or not material; provided, further, that any such termination
shall only become effective if the allegedly breaching Party fails to remedy or cure such breach or
default prior to the end of such thirty (30) day period. If, prior to the end of such thirty (30)
day period, the allegedly breaching Party remedies or cures such breach or default to the reasonable
satisfaction of the non-breaching Party, this Agreement shall remain in full force and effect; (b)
upon sixty (60) days prior written notice if the other Party materially breaches its
representations, warranties or obligations under this Agreement; provided, however, that any such
termination shall only become effective if the allegedly breaching Party fails to remedy or cure
such breach or default prior to the end of such sixty (60) day period. If, prior to the end of such
sixty (60) day period, the allegedly breaching Party remedies or cures such breach or default to the
reasonable satisfaction of the non-breaching Party, this Agreement shall remain in full force and
effect; 48

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 53 -->
(c) immediately upon the filing or institution of bankruptcy, reorganization, liquidation or
receivership proceedings, or upon an assignment of a substantial portion of the assets for the
benefit of creditors by the other Party; provided, however, that in the case of any involuntary
bankruptcy proceeding such right to terminate shall only become effective if the Party consents to
the involuntary bankruptcy; or (d) immediately upon notice to the other Party, if such Party (the
"Violating Party") is convicted of violating any Applicable Law, including applicable
anti-corruption laws, bribery and corruption of public officials as well as private persons and
entities, in connection with its activities under this Agreement and such violation materially
adversely affects the ability of either Party to perform its obligations under this Agreement. The
Violating Party shall be liable for damages or remedies as provided by law. 8.4 Termination Without
Cause. After the date that is eighteen (18) months after the Effective Date, either Party may
terminate this Agreement upon six (6) months prior written notice to the other Party. 8.5 Mutual
Termination. This Agreement may be terminated at any time by mutual written consent of the Parties.
8.6 Termination for Change of Control. This Agreement may be terminated by either Party upon six (6)
months written notice following a Change of Control of Exact; provided that such notice is given
within thirty (30) days of the consummation of such Change of Control. 8.7 Royalty Upon Expiration.
After the expiration of the Term or termination pursuant to Section 8.4 by either Party or Section
8.6 by Exact, based on cumulative Incremental Laboratory Services Revenue achieved during the Term
or up to the termination date, Exact agrees to pay Pfizer the applicable royalty payment set forth
below for twelve (12) consecutive Calendar Quarters following the expiration of the Term (the "Tail
Period"); provided, however, the Tail Period shall be reduced to the number of full Calendar
Quarters completed during the Term if less than twelve (12) Calendar Quarters if either Party
terminates the Agreement without cause pursuant to Section 8.4 or Exact terminates as a result of a
Change of Control pursuant to Section 8.6. Such royalty payment shall be payable to Pfizer within
thirty (30) days of the end of each Calendar Quarter. Royalty payments shall be determined by
multiplying the Laboratory Services Revenue and the applicable royalty rate from the chart below.
Cumulative Incremental Laboratory Services Revenue during the Term Applicable Royalty Rate If < $200
million 0% If > $200 million and < $400 million 1% If > $400 million and < $600 million 2% If > $600
million 3% 49

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 54 -->
For example, if the cumulative Incremental Laboratory Services Revenue achieved during the Term is
$500 million, the applicable royalty rate is 2%. The royalty payable by Exact to Pfizer at the end
of each Calendar Quarter after the Term is 2% of Laboratory Service Revenues for the applicable
Calendar Quarter. 8.8 Consequences of Termination. (a) In the event of any termination under this
Agreement, (i) Pfizer shall have no obligation to invest Shared M&P Expenses pursuant to Section 3.5
as of the effective date of the termination (except as set forth below), (ii) Pfizer shall cease to
make any commitments under Section 3.2(d) as of the date of notice of termination, unless Exact
notifies Pfizer pursuant to Section 8.8(b) and (iii) neither Party shall have any obligation to
reimburse the other Party for any expenses for activities conducted after the effective date of such
termination unless such expenses were incurred prior to termination. Notwithstanding the above,
Exact agrees to pay any financial commitment made by Pfizer pursuant to Section 3.2(d) and Exhibit
3.2(d) to Third Parties following the effective date of termination; provided that such amounts
conform with the then-current Annual Marketing Plan, including the budget. (b) Exact shall use
commercially reasonable efforts to provide six (6) month notice prior to the expiry of the Term, or
in the case of termination by Pfizer under Section 8.4, within the applicable notice period in
advance of the effective date of such termination, that Exact intends for Pfizer to continue
providing Advertising services for the Product pursuant to Section 3.2(d). Thereafter, the Parties
will use good faith efforts to agree to the Advertising services that will be provided by Pfizer
during the Tail Period in accordance with Section 3.2(d) and Exhibit 8.8(b). For clarity, Pfizer's
obligation to provide Advertising services during the Tail Period is limited to the expiry of the
Term or termination by Pfizer pursuant to Section 8.4, or termination by Exact pursuant to Section
8.3. (c) In the event Exact terminates this Agreement for cause pursuant to Section 8.3 or Pfizer
terminates this Agreement without cause pursuant to Section 8.4, Exact shall not be obligated to pay
Pfizer a supplemental Promotion Fee pursuant to Section 4.2(c) for the Calendar Year, or any portion
of such Calendar Year in which such termination occurs. 8.9 Survival of Certain Obligations.
Expiration or termination of the Agreement shall not relieve the Parties of any obligation accruing
before such expiration or termination, and the provisions of Sections 1 (Definitions), 2.5 (Alliance
Managers), 3.2(d) (Advertising), 3.2(e)(iii) (Return of Training Materials), 3.2(j) (Customer
Service Activities; Safety Reporting), 4.4 (Taxes and Withholding); 4.7 (Maintenance of Records;
Audits), 6 (Indemnification; Limitation of Liability; Insurance), 7 (Confidentiality; Publicity); 8
(Term and Termination) and 9 (Miscellaneous) inclusive, shall survive the expiration of the
Agreement. Any expiration or early termination of this Agreement shall be without prejudice to the
50

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 55 -->
rights of either Party against the other accrued or accruing under this Agreement before
termination. 9. MISCELLANEOUS. 9.1 Interpretation. Except where the context expressly requires
otherwise, (a) the use of any gender herein will be deemed to encompass references to either or both
genders, and the use of the singular will be deemed to include the plural (and vice versa), (b) the
words "include", "includes" and "including" will be deemed to be followed by the phrase "without
limitation", (c) the word "will" will be construed to have the same meaning and effect as the word
"shall", (d) any reference herein to any Person will be construed to include the Person's successors
and assigns, (e) the words "herein", "hereof" and "hereunder", and words of similar import, will be
construed to refer to this Agreement in its entirety and not to any particular provision hereof, (f)
all references herein to Sections or Exhibits will be construed to refer to Sections or Exhibits of
this Agreement, and references to this Agreement include all Exhibits hereto, (g) the word "notice"
means notice in writing (whether or not specifically stated) and will include notices, consents,
approvals and other written communications contemplated under this Agreement, (h) provisions that
require a Party, the Parties or any committee hereunder to "agree," "consent" or "approve" or the
like will require that such agreement, consent or approval be specific and in writing, whether by
written agreement, letter, approved minutes or otherwise (but excluding text and instant messaging),
(i) references to any specific law, rule or regulation, or article, section or other division
thereof, will be deemed to include any amendments thereto or any replacement or successor law, rule
or regulation thereof, and (j) the term "or" will be interpreted in the inclusive sense commonly
associated with the term "and/or." 9.2 Assignment. This Agreement may not be assigned or otherwise
transferred, nor may any right or obligation hereunder be assigned or transferred, by either Party
without the prior written consent of the other Party. Notwithstanding the foregoing, either Party
may, without consent of the other Party, assign this Agreement and its rights and obligations
hereunder in whole or in part to an Affiliate of such Party, or in whole to its successor in
interest in connection with the sale of all or substantially all of its stock or its assets to which
this Agreement relates, or in connection with a merger, acquisition or similar transaction. Any
attempted assignment not in accordance with the foregoing shall be null and void and of no legal
effect. Any permitted assignee shall assume all assigned obligations of its assignor under this
Agreement. The terms and conditions of this Agreement shall be binding upon, and shall inure to the
benefit of, the Parties and their respected successors and permitted assigns. 9.3 Further Actions.
Each Party agrees to execute, acknowledge and deliver such further instruments, and to do all such
other acts, as may be necessary or appropriate in order to carry out the purposes and intent of the
Agreement. 9.4 Force Majeure. Each Party will be excused from the performance of its obligations
under this Agreement to the extent that such performance is prevented by force 51

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 56 -->
majeure (defined below) and the nonperforming Party promptly provides notice of the prevention to
the other Party. Such excuse will be continued so long as the condition constituting force majeure
continues and the nonperforming Party takes commercially reasonable efforts to remove the condition;
provided that if any delay in performance due to force majeure continues for a period of six (6)
months or more, then the other Party will have the right to terminate this Agreement immediately
upon written notice. For purposes of this Agreement, "force majeure" will include conditions beyond
the control of the Parties, including an act of God, voluntary or involuntary compliance with any
regulation, law or order of any government, war, act of terror, civil commotion, labor strike or
lock-out, epidemic, failure or default of public utilities or common carriers, destruction of
production facilities or materials by fire, earthquake, storm or like catastrophe. 9.5 Notices. All
notices and other communications required or permitted hereunder (including any notice of force
majeure, breach, termination, change of address, etc.) shall be in writing and will be deemed given
(a) upon receipt if delivered personally or by facsimile transmission (receipt verified), (b) five
(5) days after being deposited in the mail if mailed by registered or certified mail (return receipt
requested) postage prepaid or (c) on the next Business Day if sent by overnight delivery using a
nationally recognized express courier service and specifying next Business Day delivery (receipt
verified), and will be sent to the Parties at the following addresses or facsimile numbers, as
applicable, (or at such other address or facsimile number for a Party as will be specified by like
notice; provided, however, that notices of a change of address will be effective only upon receipt
thereof): All correspondence to Pfizer shall be addressed as follows: Pfizer Inc. 235 East 42nd
Street New York, New York 10017 Attn: General Counsel Fax: (212) 309-0874 With a copy to: Pfizer
Inc. 235 East 42 Street New York, New York 10017 Attn: Regional President, North America, Internal
Medicine And Pfizer Inc. 235 East 42 Street New York, New York 10017 Attn: Chief Counsel, Internal
Medicine All correspondence to Exact shall be addressed as follows: 52

nd

nd

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 57 -->
Exact Sciences Corporation 441 Charmany Drive Madison, Wisconsin 53719 Attn: General Counsel Fax:
(608) 284-5701 With a copy to: Exact Sciences Corporation 441 Charmany Drive Madison, Wisconsin
53719 Attn: CEO 9.6 Amendment. No amendment, modification or supplement of any provision of this
Agreement shall be valid or effective unless made in a writing signed by a duly authorized officer
of each Party and delivered to each of the Parties. 9.7 Waiver. No provision of the Agreement shall
be waived by any act, omission or knowledge of a Party or its agents or employees except by an
instrument in writing expressly waiving such provision and signed by a duly authorized officer of
the waiving Party. The failure of either Party to require the performance of any term of this
Agreement, or the waiver of either Party of any breach of this Agreement, shall not prevent a
subsequent exercise or enforcement of such terms or be deemed a waiver of any subsequent breach of
the same or any other term of this Agreement. 9.8 Severability. If any clause or portion thereof in
this Agreement is for any reason held to be invalid, illegal or unenforceable, the same shall not
affect any other portion of this Agreement, as it is the intent of the Parties that this Agreement
shall be construed in such fashion as to maintain its existence, validity and enforceability to the
greatest extent possible. In any such event, this Agreement shall be construed as if such clause of
portion thereof had never been contained in this Agreement, and there shall be deemed substituted
therefor such provision as will most nearly carry out the intent of the Parties as expressed in this
Agreement to the fullest extent permitted by Applicable Law. 9.9 Descriptive Headings. The
descriptive headings of this Agreement are for convenience and reference purposes only, and shall be
of no force or effect in construing or interpreting any of the provisions of this Agreement. 9.10
Governing Law. This Agreement shall be governed by and interpreted in accordance with the
substantive laws of the State of New York, without regard to conflict of law principles thereof.
9.11 Dispute Resolution. The Parties recognize that a bona fide dispute as to certain matters may
from time to time arise during the term of this Agreement that relate to any Party's rights or
obligations hereunder. In the event of the occurrence of any dispute arising out of or relating to
this Agreement (other than a Disputed JSC 53

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 58 -->
Matter, which shall be resolved as provided in Section 2.1, a Disputed JOC Matter, which shall be
resolved as provided in Section 2.2 and Disputed JRC Matter, which shall be resolved as provided in
Section 2.3), including any question regarding its existence, validity or termination (a "Dispute"),
any Party may, by written notice to the other, have such Dispute referred to their respective Senior
Officer or such Senior Officer's designee, for attempted resolution by good faith negotiations
within thirty (30) days after such notice is received. Any negotiations regarding a Dispute are
confidential and shall be treated as compromise and settlement negotiations for purposes of the U.S.
Federal Rules of Evidence and any similar rules of evidence. 9.12 Entire Agreement of the Parties.
This Agreement constitutes and contains the complete, final and exclusive understanding and
agreement of the Parties and cancels and supersedes any and all prior negotiations, correspondence,
understandings and agreements, whether oral or written, among the Parties respecting the subject
matter hereof and thereof. 9.13 Independent Contractors. Both Parties are independent contractors
under this Agreement. Nothing herein contained shall be deemed to create an employment, agency,
joint venture or partnership relationship between the Parties hereto or any of their agents or
employees, or any other legal arrangement that would impose liability upon one Party for the act or
failure to act of the other Party. Neither Party shall have any express or implied power to enter
into any contracts or commitments or to incur any liabilities in the name of, or on behalf of, the
other Party, or to bind the other Party in any respect whatsoever. Neither Party shall have any
responsibility for the hiring, termination, compensation or benefits of the other Party's employees.
9.14 No Legal Advice. Each Party acknowledges and agrees that the other Party and the other Party's
attorneys are not representing such Party during the course of or in connection with any activities
under this Agreement and that, unless otherwise expressly agreed in writing by the other Party's
attorneys, any opinions expressed by the other Party or the other Party's attorneys with respect to
any marketing or promotional materials or the activities of either Party under this Agreement shall
not be considered to be legal advice regardless of whether or not related to a legal or regulatory
matter. 9.15 Counterparts. This Agreement may be executed in two (2) counterparts, each of which
will be an original and both of which will constitute together the same document. Counterparts may
be signed and delivered by facsimile or digital file, each of which will be binding when received by
the applicable Party. (remainder of page intentionally left blank) 54

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
<!-- page 59 -->
IN WITNESS WHEREOF, duly authorized representatives of the Parties have duly executed this Agreement
to be effective as of the Effective Date. PFIZER INC. EXACT SCIENCES CORPORATION By /s/ Michael
Gladstone By /s/ Kevin Conroy Name: Michael Gladstone Name: Kevin Conroy Title: Global President,
Internal Medicine Title: Chairman & Chief Executive Officer Pfizer Innovative Health Signature Page

Source: EXACT SCIENCES CORP, 8-K, 8/22/2018
