<!-- page 1 -->
# MASTER JOINT DEVELOPMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2018-08-08 |
| Parties | iBio Inc.; Beijing CC-Pharming Ltd. ("CC-Pharming") |
| Source | CUAD v1 / IbioInc_20200313_8-K_EX-10.1_12052678_EX-10.1_Development Agreement |

Exhibit 10.1 NOTE: Certain information indicated with [***] in this document has been omitted from
this exhibit because it is both (i) not material and (ii) would be competitively harmful if publicly
disclosed. MASTER JOINT DEVELOPMENT AGREEMENT This Master Joint Development Agreement ("Agreement")
is between iBio Inc., a Public corporation, with a location at iBio Inc., 600 Madison Ave, Suite
01601 NY, NY 10022-1735 and Beijing CC-Pharming Ltd. of Beijing, China ("CC-Pharming"), a Chinese
Corporation with a location at Shunyi District, Beijing, China, 101312, each of the foregoing being
individually referred to as a "Party" and collectively as the "Parties". WHEREAS, iBio and
CC-Pharming wish to establish a long-term working relationship for various joint research and
development projects ("Projects") related to the development of various products, with the work for
each Project to be described in a separate Statement of Work ("SOW") agreed by the Parties; WHEREAS,
iBio has developed and owns proprietary technology used to produce proteins using proprietary vector
systems that support transient gene expression and protein production in plants, and iBio has
developed and/or acquired additional proprietary biopharmaceutical technology, cGMP manufacturing
expertise ("iBio's Technology"), and a facility design team that provides capabilities for
application to the development of biotherapeutics; and WHEREAS, iBio and CC-Pharming, wish to
develop one or more biopharmaceuticals Product(s) (each a "Product") based on iBio's proprietary and
patented plant-based protein production technology and know-how; WHEREAS, iBio and CC-Pharming wish
to develop a long-term, mutually beneficial relationship for the production and sale of
biopharmaceuticals in China and to form a collaborative business venture to be majority owned and
controlled by CC-Pharming and minority owned by iBio; and NOW, THEREFORE, for good and valuable
consideration as stated herein, the sufficiency of which is hereby expressly acknowledged by each
Party, iBio and CC-Pharming agree as follows: 1.0 Limited Technology License 1.1 iBio hereby grants
to CC-Pharming for the term of this Agreement, a nonexclusive, non- assignable, non-sublicensable,
limited right and license to use iBio's Technology in order to manufacture, process, prepare, and
obtain regulatory approval for the development and production of Product(s) and work to be performed
under this Agreement. Each Product will be set forth in a separate Statement of Work in the form set
forth in Appendix A, which will be signed by representatives of each Party with signing authority.
Each phase of the project(s) will be subject to the terms and conditions set forth in this Agreement
unless otherwise provided for or in a Statement of Work ("SOW"), including but not limited to
project purpose, project phases, and a project budget.

Master Joint Development Agreement iBio CC-Pharming Page 1 of 12

Source: IBIO, INC., 8-K, 3/13/2020
<!-- page 2 -->
1.2 No right or license is being conveyed to CC-Pharming to export Products or to otherwise use the
Technology in any country other than China. 1.3 iBio will work with CC-Pharming to perform a
thorough Manufacturing Development Program based from an initial comprehensive two- day charrette to
be held at its subsidiary iBio CDMO LLC facility in Bryan, Texas with the goals of CC-Pharming
understanding the definitive capital expenditure necessary and initiating a preliminary design for
the first Product. iBio will provide an architect, construction supervisor, mechanical engineer and
process engineer with knowledge of the iBio CDMO facility currently in operation in Bryan, Texas.
1.4 CC-Pharming hereby expressly acknowledges the validity and highly confidential and proprietary
nature of iBio's Technology and technical information, know-how, documents, materials, software,
vectors, constructs, trade secrets, and other valuable business or scientific information that iBio
will share with CC-Pharming in order to fulfill the purpose of this Agreement, namely, to form a
legal structure for a collaborative business venture in which CC-Pharming and iBio shall share
revenue from product sales. iBio's double-digit percentage, minority interest in this structure will
provide compensation to iBio for providing CC-Pharming with a license to use iBio's Technology and
enabling know-how and will provide CC-Pharming with ongoing and mutually agreed technology transfer
services relevant to the evolving business and Product(s) of the collaborative venture. 1.5 The
parties agree that the first product focus of the joint business collaboration will be a bio-better
or bio-similar version of the therapeutic monoclonal antibody, rituximab. iBio will provide all
necessary gene expression and vector technology for the transient expression and cGMP manufacturing
of this protein in plants and will also provide pilot plant design services, construction
consulting, product and process development services, training, quality management system design,
and clinical planning and regulatory consulting. The tasks to be conducted in the first stage of the
joint business collaboration will apply specifically to the rituximab product candidate but will be
applicable, in part, to additional products to be selected by mutual agreement for development, with
the timeline for such work to be determined by CC-Pharming. 1.5 Any milestones or completion dates
set forth in a Statement of Work will be estimates only, and are not binding on the Parties. 2.0
Coordinators and Governance Terms 2.1 Project Technical Coordinators will be appointed by each the
Parties for each Statement of Work. The Project Technical Coordinators will be responsible for
exchanging information with the other Party, coordinating any visits and arranging all other matters
pertinent to that Statement of Work.

Master Joint Development Agreement iBio CC-Pharming Page 2 of 12

Source: IBIO, INC., 8-K, 3/13/2020
<!-- page 3 -->
2.2 Agreement Administration. The Agreement administrator for each Party must be contacted regarding
all business-related matters, including any proposed modifications to this Agreement, the phasing
plan of the SOW, for each project. An iBio Agreement Administrator is to be named on or before the
Effective Date of the First Phase of the SOW. A CC-Pharming Agreement Administrator is to be named
on or before the Effective Date of the First Phase of the SOW. 2.4 Governance Terms 2.4.1 The
Agreement Administrators shall oversee the overall direction and management of this Agreement and to
provide guidance and direction when needed, which agreement shall be unanimous. The responsibilities
of the Agreement Administrator for iBio and CC- Pharming will include the following: a) Perform
oversight for each of the ongoing projects, per phase, under the SOW's. b) Agreement on any
modifications to the tasks and responsibilities for an ongoing project under the SOW's, will fall
under the oversight of the Agreement Administrators. c) Neither Agreement Administrator is
authorized to modify or change any term or condition of the Agreement or the overall scope of work
for any SOW. d) Review any disputes between or among the Parties, and, if resolution of the dispute
cannot be achieved, escalate the dispute to the Designated Executives of iBio and CC-Pharming.
"Designated Executive" means the executive designated by iBio and by CC-Pharming, who will be
responsible for general oversight of the Agreement and for resolving issues that require escalation
under this Agreement. iBio and CC-Pharming shall each inform the other of the name and contact
information of their respective Designated Executives on or before the Effective Date of the first
SOW. 2.4.2 The Agreement Administrators may agree to change the tasks, task responsibilities and
milestones as set forth in a Statement of Work, provided the changes do not alter the overall scope
of work in a phase of the SOW, which agreement shall not be unreasonably withheld. Any modifications
to the overall scope of work of phase of the SOW must be reduced to writing as an amendment to the
SOW and signed by authorized representatives of iBio and CC-Pharming. 2.4.3 The Agreement
Administrators shall meet regularly as required during the term of this Agreement, but at least two
(2) times each calendar year, at a mutually agreeable location, which agreement shall not be
unreasonably withheld. The face-to-face meetings may be replaced with conference calls or video
conferences upon request by a Party. 2.4.4 The Parties shall be responsible for their own respective
costs incurred relating to their participation in oversight meetings.

Master Joint Development Agreement iBio CC-Pharming Page 3 of 12

Source: IBIO, INC., 8-K, 3/13/2020
<!-- page 4 -->
2.5 Each Party may change its Agreement Administrators, at any time, with written notice to the
other Party. 3.0 Costs and Expenses 3.1 Upon execution of this Agreement and acceptance of iBio's
proposal for the development of a Plant-Made Rituximab, and in consideration for providing the
technology transfer contemplated herein, CC-Pharming shall pay iBio [***], which shall be paid as
follows: 3.1.1 First payment of [***] is required to initiate the project: [***]. 3.1.2 Second
payment of [***]. Due upon presentation of the following deliverables: a) Detailed design drawings
of the pilot plant; b) Schematic design of the commercial facility; c) Purified antibody for
pre-clinical testing and development; and d) The quality management system (QMS) development up to
and including governance documents and governance standard operating procedures (SOP's). 3.1.3 Final
payment of [***], due upon presentation of the following deliverables: a) Detailed Design drawings
for the commercial facility; b) Completion of QMS documentation for rituximab including batch
records, release documents, and assay SOPs; c) Completion of all training sessions and training
documentation; d) Delivery of antibody drug substance for clinical trials; and e) Completion of a
chemistry, manufacturing, and controls (CMC) document to support an (investigational new drug
application (IND) or equivalent. 4.0 Inventions 4.1 Inventorship of inventions, developments, or
discoveries first conceived or actually reduced to practice under this Agreement ("Agreement
Inventions") will be determined under U.S. Patent Law. All inventions, developments, or discoveries
made solely by iBio prior to this Agreement is, and shall be, the sole property of iBio. All
inventions, developments, or discoveries made solely by CC- Pharming thereof prior to this Agreement
is, and shall be, the sole property of CC-Pharming. 4.2 All rights to inventions, patentable or
non-patentable, made solely by employees of iBio during the term of this Agreement shall belong
solely to iBio. All rights to inventions, patentable or non-patentable, made solely by employees of
CC-Pharming during the term of this Agreement shall belong solely to CC-Pharming. All rights to
Agreement Inventions, patentable or non-patentable, made jointly by employees of iBio and employees
of CC-Pharming ("Joint Inventions") will belong jointly to iBio and CC-Pharming, with inventorship
determined as described in 35 U.S.C. § 262 and (Chin Patent Law). The Parties contemplate that each
will benefit from Joint Inventions, as such, iBio will be responsible for direct control over the
drafting and prosecution of any patents to Joint Inventions, with copy to CC- Pharming. The parties
shall share equally in the costs of patent protection for Joint Inventions.

Master Joint Development Agreement iBio CC-Pharming Page 4 of 12

Source: IBIO, INC., 8-K, 3/13/2020
<!-- page 5 -->
4.3 Each Party shall promptly provide to the other Party a written invention disclosure of each
Agreement Invention made by its employees that results directly from the present Agreement for
worked performed under the SOWs herein. The other Party agrees to delay making public, by
publication or otherwise, until the earlier of (a) the first filing of a patent application claiming
the Agreement Invention by the Inventing Party; or (b) six months after the date the Agreement
Invention is disclosed to the other Party; or (c) mutual agreement of the Parties that neither will
pursue legal protection of an Agreement Invention. 4.5 Each disclosure shall be held in confidence
and not revealed to any third party without the written consent of the other Party. The other Party
must advise the Inventing Party in writing within 60 days of each disclosure to the other Party
whether or not the other Party elects to negotiate a license agreement to obtain commercial rights
to such Agreement Invention. In the event that the other Party elects to negotiate for a commercial
license to an Agreement Invention, the Parties must initiate negotiation of a license agreement,
with negotiations not to extend beyond ninety (90) days from notice of election without the consent
of both Parties. The Parties will negotiate in good faith a license containing reasonable business
terms common to the other party's field of commercial interest and proposed application. 5.0
Copyrights 5.1 Title to and the right to determine the disposition of any copyrights or
copyrightable material first produced or composed in the performance of this research program
("Copyright Materials") will remain with the Party whose employees solely created such materials or
works of authorship (the "Creating Party"). Copyright Materials that are jointly created by the
Parties shall be jointly owned. Either Party may license and assign its rights to jointly owned
Copyright Materials without the consent of or accounting to the other Party, subject to the
applicable confidentiality obligations set forth in Section 7 of this Agreement and/or a SOW. 5.2
The Creating Party grants to the other Party a time-limited first right to negotiate a commercial
license to use, reproduce, display, and perform commercially valuable Copyright Materials for
commercial purposes, and to distribute and/or sublicense such commercially valuable Copyright
Materials to third parties. The other Party must advise the Creating Party in writing within sixty
(60) days following disclosure or delivery of such commercially valuable Copyright Materials to the
other Party whether or not the other Party elects to negotiate a license agreement to obtain
commercial rights to the Copyright Materials. In the event that the other Party elects to negotiate
for a commercial license to Copyright Materials, the Parties must initiate negotiation of a license
agreement, the negotiations not to extend beyond ninety (90) days from notice of election without
the consent of both Parties. The Parties will negotiate in good faith a license containing
reasonable business terms common to the other Party's field of commercial interest and proposed
application.

Master Joint Development Agreement iBio CC-Pharming Page 5 of 12

Source: IBIO, INC., 8-K, 3/13/2020
<!-- page 6 -->
6.0 Term and Termination 6.1 The term of this Agreement ("Term") will begin on the date this
Agreement is signed by the last signatory ("Effective Date") and remain in effect for [***];
provided, however, that the terms of this Agreement shall remain applicable to any SOW that was
executed by the Parties prior to the expiration or termination of this Agreement but whose period of
performance extends beyond the expiration or termination of this Agreement. 6.2 The term of any SOW
will be as provided in the Statement of Work. 6.3 If either Party to this Agreement fails to perform
or violates any material obligation of this Agreement, then, upon thirty (30) days written notice to
the breaching Party specifying such failure or violation, the non-breaching Party may terminate this
Agreement without liability, unless: (a) the failure or violation specified in the default notice
has been cured within the thirty (30) day notice period; or (b) the failure or violation reasonably
requires more than thirty (30) days to correct, and the breaching Party has begun substantial
corrective action to remedy the failure or violation within the thirty (30) day notice period and
diligently pursues such action, in which event, termination shall not be effective unless sixty (60)
days has expired from the date of the default notice without such corrective action being completed
and the failure or violation remedied. 7.0 Confidentiality 7.1 Except as provided in a Statement of
Work and Article 5.3 regarding non-disclosure of Agreement Inventions, any information provided by
either Party under this Agreement or under any Statement of Work will be treated as follows. 7.2
"Confidential Information" includes but is not limited to, technologies, discoveries, inventions,
know-how, methods, procedures, trade secrets, business information and other proprietary
intellectual property ("Information"). All such Information is considered by the parties to be
secret and confidential and constitutes valuable commercial assets. 7.3 Each of the parties agrees
that for five (5) years from the date of disclosure, the receiving Party agrees to limit disclosure
of the disclosing Party's Confidential Information to those of the receiving party's employees and
contractors, and employees and contractors of its Subsidiaries, who have a need to know it, and the
receiving Party agrees to use the same care and discretion to avoid disclosure, publication or
dissemination outside of those employees and contractors as the receiving Party does with similar
information of its own which it does not desire to publish, disclose or disseminate. 7.4 The
receiving Party may disclose Confidential Information if the disclosure is required by law, but the
receiving Party must give the disclosing Party reasonably prior notice to allow the disclosing Party
an opportunity to obtain a protective order. The obligations of Article 7.3 will not apply to
information that is:

Master Joint Development Agreement iBio CC-Pharming Page 6 of 12

Source: IBIO, INC., 8-K, 3/13/2020
<!-- page 7 -->
a) already rightfully in the possession of the receiving Party or its Subsidiaries without an
obligation of confidence; b) independently developed by the receiving Party of its Subsidiaries as
evidenced by written documentation; c) publicly available when received by the receiving Party, or
becomes publicly available through no fault of the receiving Party or its Subsidiaries; d) disclosed
by the disclosing Party without obligation of confidence; or e) inherently disclosed by the
receiving Party or its Subsidiaries in the use, distribution or marketing of any product or service.
7.5 The Parties agree that the disclosure of Confidential Information under this Agreement does not
limit either Party from assigning or reassigning employees in any way. 7.6 Confidential Information
must be identified as Confidential at the time of disclosure, and all material containing
Confidential Information must have a restrictive marking. Any Confidential Information disclosed
orally or visually must be summarized by the disclosing Party in writing and the writing must be
provided to the receiving Party within twenty (20) days after the disclosure. In the case of
inadvertent disclosure of Confidential information that was not marked as Confidential, the
Disclosing Party has ten (10) business days from the time they discover that the information should
have been marked Confidential, to inform the other Party of such a designation, and the parties
agree to retroactively mark any such information as Confidential. 7.7 The parties agree that
limitations on disclosure of Confidential information under section 7.3 shall last 5 years from
signing date. 8.0 Representations, Warranties, Disclaimers and Limitation of Liability 8.1 ANY
PROTOTYPES, MATERIALS, COMPONENT PARTS, DESIGNS, SPECIFICATIONS, KNOW-HOW, PROCEDURES, PROCESSES,
DATA, INFORMATION, INVENTIONS AND WORK PERFORMED UNDER THIS AGREEMENT BY EITHER PARTY, ARE PROVIDED
"AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. EACH PARTY SPECIFICALLY DISCLAIMS THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, AND ANY WARRANTY OF
NONINFRINGEMENT OF PATENTS, COPYRIGHTS, OR ANY OTHER INTELLECTUAL PROPERTY RIGHT. 8.2 EACH PARTY
ALSO SPECIFICALLY DISCLAIMS ANY GUARANTEE THAT IT WILL BE ABLE TO SUCCESSFULLY ACHIEVE THE DESIRED
RESULTS REGARDING THE WORK UNDER ANY STATEMENT OF WORK, OR THAT ANY PROTOTYPE(S) WHICH MAY BE
DEVELOPED PURSUANT TO THIS AGREEMENT WILL MEET ANY DEVELOPMENT OBJECTIVES, OR ANY REQUIREMENTS OF
EITHER PARTY. THE FOREGOING NOTWITHSTANDING, EACH PARTY WILL MAKE REASONABLE GOOD FAITH EFFORTS TO
COMPLETE THE ACTIVITIES DESCRIBED IN THE STATEMENTS OF WORK. FAILURE TO ACHIEVE THE DESIRED RESULTS
UNDER A STATEMENT OF WORK DOES NOT CONSTITUTE BREACH OF CONTRACT.

Master Joint Development Agreement iBio CC-Pharming Page 7 of 12

Source: IBIO, INC., 8-K, 3/13/2020
<!-- page 8 -->
8.3 Except for claims arising out of Articles 4.3 and 7.0, or as may be set forth in a SOW, neither
Party will be liable for any consequential damages, lost profits, lost savings, loss of anticipated
revenue, or any exemplary, punitive, special or indirect damages, even if advised of their
possibility. 8.4 CC-Pharming represents and warranties that it shall maintain all of iBio's
Technology and technical information, how-how, documents, materials, software, vectors, constructs,
trade secrets, and other valuable business or scientific information strictly confidential at all
times, and shall take all steps necessary to safe-guard iBio's Technology and technical information
with reasonable business care and will be of the same types as currently practiced by iBio to
maintain its highly confidential information. 8.5 Equitable Relief for iBio. CC-Pharming
acknowledges that a breach by CC-Pharming of this Agreement shall cause iBio irreparable damages,
for which an award of damages would not be adequate compensation, and agrees that, in the event of a
breach or threatened breach, iBio will be entitled to seek equitable relief, including a restraining
order, injunctive relief, specific performance and any other relief that may be available from any
court, in addition to any other remedy to which iBio may be entitled at law or in equity. iBio's
equitable remedies are not exclusive but are in addition to all other remedies available at law or
in equity. 8.6 Attorney's Fees. In the event that any claim, suit, action or proceeding is
instituted or commenced by any Party hereto against any other Party arising out of or related to
this Agreement, the prevailing Party will be entitled to recover its reasonable attorneys' fees,
expert fees, expenses and court costs from the non-prevailing Party. 9.0 General Provisions 9.1
Independent Contractor. Each Party is an independent contractor. Neither Party is, nor will claim to
be, a legal representative, partner, franchisee, agent or employee of the other. Neither Party will
assume or create obligations for the other. Each Party is responsible for the direction and
compensation of its employees. 9.2 Trademarks. Except as otherwise provided herein, this Agreement
does not confer any rights to use in advertising, publicity or other marketing activities any name,
trade name, trademark, or other designation of either Party hereto, including any contraction,
abbreviation, or simulation of any of the foregoing, without prior written agreement, and each Party
agrees not to use or refer to this Agreement or its terms in any such activities without the express
written approval of the other Party.

Master Joint Development Agreement iBio CC-Pharming Page 8 of 12

Source: IBIO, INC., 8-K, 3/13/2020
<!-- page 9 -->
9.3 Publication. iBio and CC-Pharming jointly, may publish and present technical presentations
subject to Articles 5.2, 7.0 and this Article 9.2. 9.4 Notice. All notices shall be in writing and
shall be valid and sufficient if sent by: (a) registered or certified mail, return receipt required,
postage prepaid; (b) by facsimile (provided the receipt of the facsimile is evidenced by a printed
record of completion of transmission); or (c) by express mail or courier service providing a receipt
of delivery. Notice shall be effective upon receipt. The notices shall be addressed to: iBio, Inc.
Beijing CC-Pharming Ltd. Robert L. Erwin Kevin Y. Wang President Chairman 600 Madison Ave, Suit 1601
Shunyi Distict New York, NY 10022-1737 U.S.A Beijing, China, 101312 Attn: Rober L. Erwin Attn: Kevin
Y. Wang Either Party may change its address by a notice given to the other Party in the manner set
forth above. 9.5 Force Majeure. Neither Party shall be liable for any failure or delay in the
performance of its obligations under this Agreement if such failure or delay is due to acts of God,
acts of the other Party, fire, flood, natural catastrophe, acts of any government or of any civil or
military authority, national emergencies, riots, war, insurrection, strikes, or any occurrence
beyond the reasonable control of such Party. 9.6 Export Restrictions. Each Party agrees to comply
and to reasonably assist the other in complying with applicable government export and import laws
and regulations. Further, each Party agrees that unless authorized by applicable government license
or regulation, including but not limited to both US and China authorization, both Parties will not
directly or indirectly export or re-export, at any time, any technology, software and/or commodities
furnished or developed under this or any other, Agreement between the Parties, or its direct
product, to any prohibited country (including release of technology, software and/or commodities to
nationals, wherever they may be located, of any prohibited country) as specified in applicable
export, embargo, and sanctions regulations. This section will survive after termination or
expiration of this Agreement and will remain in effect until fulfilled. 9.7 No Implied Licenses.
Except as expressly set forth in this Agreement, no license is granted, either directly or
indirectly, by implication or estoppel or otherwise, to either Party under any patent, copyright or
other intellectual property right of the other Party. 9.8 Assignment. Neither Party may assign its
rights or delegate any of its duties under this Agreement without the prior written consent of the
other Party. Any unauthorized assignment of this Agreement is void. 9.9 Intent. Neither Party relies
on any promises, inducements, representations made by the other, or expectations of more business
dealings except as expressly provided in this Agreement. This Agreement accurately states the
Parties' agreement.

Master Joint Development Agreement iBio CC-Pharming Page 9 of 12

Source: IBIO, INC., 8-K, 3/13/2020
<!-- page 10 -->
9.10 Power to Enter Agreement. Each Party represents that it has, or will have, in place appropriate
agreements with its employees or others whose services the Party may require, sufficient to enable
such Party to comply with all the provisions of this Agreement. 9.11 Independent Parties. Each Party
may have similar agreements with others, and may design, develop, manufacture, acquire or market
competitive products and services, and conduct its business in whatever way it chooses. Each Party
will independently establish prices and terms for its products and services. 9.12 Severability. If
any provision of this Agreement is held to be invalid, illegal or unenforceable, the validity,
legality and enforceability of the remaining provisions shall in no way be affected or impaired
thereby so long as the intent of the Parties can be preserved. 9.13 Governing Law. This Agreement is
governed by the laws of the State of Texas, without regard to the conflict of laws provisions
thereof. Any proceedings to resolve disputes relating to this Agreement shall be brought only in the
State of Texas and in a U.S. federal court if there is jurisdiction. The United Nations' Convention
on International Sales of Goods does not apply. 9.14 Survival. Any rights and obligations which by
their nature survive and continue after any expiration or termination of this Agreement shall
survive and continue and shall bind the Parties and their successors and assigns, until such
obligations are fulfilled. 9.15 No Oral Modifications. Any amendment or modification of this
Agreement shall be in writing and shall be signed by authorized representatives of the Parties. No
approval, consent or waiver will be enforceable unless signed by the granting Party. Failure to
insist on strict performance or to exercise a right when entitled does not prevent a Party from
doing so later for that breach, or a future breach. 9.16 Incorporation. This Agreement, Appendix A
and SOW's added as Appendix A-x (where x is the sequential number of the respectively added SOW's)
are the complete and exclusive agreement between the Parties regarding the subject matter hereof and
supersedes any prior oral or written communications or understandings between the parties related to
the subject matter hereof. 9.17 Independent Judgment. The Parties acknowledge that: (a) they had
read this Agreement; (b) they understand the terms and conditions of this Agreement; (c) they have
had the opportunity to seek legal counsel and advice; (d) are of equal bargaining power; and (e)
they have relied on their own judgment in entering into this Agreement. Signature Page to Follow

Master Joint Development Agreement iBio CC-Pharming Page 10 of 12

Source: IBIO, INC., 8-K, 3/13/2020
<!-- page 11 -->
By signing below, the parties agree to the terms of this Agreement. iBio Inc. Beijing CC-Pharming
Ltd. /s/ Robert L. Erwin /s/ Kevin Yueju Wang Name: Robert L Erwin Name: Kevin Yueju Wang Title:
President Title: Chairman Date: August 07, 2018 Date: August 08, 2018

Master Joint Development Agreement iBio CC-Pharming Page 11 of 12

Source: IBIO, INC., 8-K, 3/13/2020
<!-- page 12 -->
APPENDIX A-1

Proposal to Beijing CC-Pharming Ltd. Development of a Plant-Made Rituximab Prepared by iBio, Inc.
for Beijing CC-Pharming Ltd., Beijing, China February 24, 2018 [***] Project Agreement
Administrators For iBio: Robert L. Erwin For CC-Pharming: Kevin Y. Wang By signing below, the
parties agree to the terms of this Statement of Work. IBio CC-Pharming /s/ Robert L. Erwin /s/ Kevin
Yueju Wang Name: Robert L. Erwin Name: Kevin Yueju Wang Title: President Title: Chairman Date:
August 7, 2018 Date: August 8, 2018

Master Joint Development Agreement iBio CC-Pharming Page 12 of 12

Source: IBIO, INC., 8-K, 3/13/2020
