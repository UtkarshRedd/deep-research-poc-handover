# Which jurisdiction's law governs the Cooperation Agreement between e.l.f. Beauty, Inc. ...

*Question:* Which jurisdiction's law governs the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01)?

## Identify the Cooperation Agreement

The Cooperation Agreement dated July 1, 2020 between e.l.f. [uncited] Beauty, Inc. and Marathon Partners Equity Management, LLC exists within the document set. [e42a4ef8cda58762 p.1] The agreement is entered into as of July 1, 2020, by and between e.l.f. [uncited] Beauty, Inc., a Delaware corporation, and Marathon Partners Equity Management, LLC. [e42a4ef8cda58762 p.1]

## Locate governing law provision

The Cooperation Agreement between e.l.f. [uncited] Beauty, Inc. and Marathon Partners Equity Management, LLC dated 2020-07-01 is governed by the internal laws of the State of Delaware applicable to agreements made and to be performed within that state, without giving effect to any law or principles of law that would result in the application of the laws of any other jurisdiction. [e42a4ef8cda58762 p.9]

## Verification appendix

Claims: 6 · supported: 3 · partially: 0 · dropped: 0 · gaps: 3 · tier-1 support rate: 1.00 · tier 2 checked: 1 (unsupported 0, partially 0)

| claim | section | tier 1 | score | tier 2 | clusters | sources | note |
|---|---|---|---|---|---|---|---|
| s1.1 | s1 | gap |  | skipped |  |  | no evidence cited |
| s1.2 | s1 | keep | 1.00 | supported | 1 | e1→[e42a4ef8cda58762 p.1] |  |
| s1.3 | s1 | gap |  | skipped |  |  | no evidence cited |
| s1.4 | s1 | keep | 1.00 | skipped | 1 | e1→[e42a4ef8cda58762 p.1] |  |
| s2.1 | s2 | gap |  | skipped |  |  | no evidence cited |
| s2.2 | s2 | keep | 1.00 | skipped | 1 | e2→[e42a4ef8cda58762 p.9] |  |

### Evidence

- e1 [e42a4ef8cda58762 p.1 L12-16] keep (1.0): "COOPERATION AGREEMENT

This Cooperation Agreement ("Agreement") is entered into as of July 1, 2020, by and between e.l.f.
Beauty, Inc., a Delaware corporation (the "Company"), and Marathon Partners Equity Management, LLC
("Marathon Partners…"
- e2 [e42a4ef8cda58762 p.9 L538-543] keep (1.0): "(g) Governing Law; Choice of Venue.

(i) This Agreement shall be governed by and construed in accordance with the internal laws of the
State of Delaware applicable to agreements made and to be performed within that state, without
giving eff…"
