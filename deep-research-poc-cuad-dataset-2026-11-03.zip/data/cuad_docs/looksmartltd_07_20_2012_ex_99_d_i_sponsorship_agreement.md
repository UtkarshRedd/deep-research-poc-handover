<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 2012-07-16 |
| Parties | PEEK Investments LLC ("Purchaser"); Platinum Partners Value Arbitrage Fund L.P ("Sponser"); Snowy August Fund ILP ("Sponser") |
| Source | CUAD v1 / LOOKSMARTLTD_07_20_2012-EX-99.(D)(I)-SPONSORSHIP AGREEMENT |

SPONSORSHIP AGREEMENT THIS SPONSORSHIP AGREEMENT ("Agreement") is entered into and effective as of
the date first written above ("Effective Date") by and among PEEK Investments LLC, a Delaware
limited liability company ("Purchaser"), and each other party hereto identified on the signature
page(s) hereto (each, a "Sponsor"). Each term used and not otherwise defined herein shall have the
meaning assigned to such term in the Offer. RECITALS WHEREAS, Purchaser is tentatively exploring,
among other potential alternatives, a possible third-party tender offer to purchase all outstanding
shares of common stock, $0.001 par value per share ("Shares"), of a Delaware corporation (the
"Company") upon the terms and subject to the conditions set forth in the Offer to Purchase, related
Letter of Transmittal, and other tender offer material provided by or on behalf of Purchaser to the
Sponsors (which, collectively, as amended or supplemented, constitute the "Offer"); WHEREAS, as
requested by Purchaser for purposes of the Offer, each Sponsor has provided to Purchaser, and
Purchaser has accepted from such Sponsor, a commitment letter providing for a possible equity
investment in Purchaser by such Sponsor (each, an "Equity Commitment Letter" and, with respect to
any Sponsor(s), the Equity Commitment Letter(s) of such Sponsor(s)), which evidences the commitment
of and by such Sponsor to contribute capital to Purchaser in amounts and proportions and upon the
terms and subject to the conditions and otherwise as contemplated by such Equity Commitment Letter
(each, a "Commitment" and, with respect to any Sponsor(s), the Commitment of such Sponsor (s));
WHEREAS, such capital contributions, if any, would be used to purchase Shares in the Offer and fund
the payment or reimbursement of fees, expenses, and costs related to the Offer (collectively,
"Transaction Costs"); and WHEREAS, each party hereto desires to establish certain terms and
conditions related to the Offer and relationship among the Sponsors, the related equity financing
commitments, and the Offer; NOW, THEREFORE, for good and valuable consideration, the receipt and
sufficiency of which is hereby acknowledged, each party hereto ("Party"), intending to be legally
bound, hereby agrees as follows: AGREEMENT 1. Pre-Acceptance Period. If and to the extent any such
decision would or could (or would or could be reasonably foreseeable to) adversely affect any
Sponsor in any manner, each decision to be made by or on behalf of Purchaser with respect to the
Offer (or any similar transaction), any agreements related thereto ("Related Agreements"), or any
transaction contemplated by the Offer or any Related Agreement ("Contemplated Transactions" and,
together with the Offer and Related Agreements, "Offer Matters"), or any Offer Matter or combination
of Offer Matters, in any case, on and from the Effective Date and until the Acceptance Time
("Pre-Acceptance Period") shall require the unanimous consent of the Sponsors, including, without
limitation, any (a) announcement of intention, commencement, amendment, supplement, termination,
extension, modification, or waiver of or related to the Offer or any term or condition thereof,
including, without limitation, with respect to any commencement date, initial offering period, offer
price, type or form of consideration to be offered or paid, timing or other term of acceptance for
payment or payment of any subject security, withdrawal right, expiration date, subsequent offering
period, or top-up option, (b) waiver of any condition to or of the Offer or determination as to
whether or not any such condition has been, is, or will be satisfied, (c) filing, dissemination, or
disclosure requirement or offering document or tender offer material, including, without limitation,
with respect to any filing or exhibit, schedule, attachment, amendment, or supplement thereto, (d)
agreement, instrument, document, or matter related to any borrowing, incurrence of indebtedness, or
equity, debt, or other financing, (e) litigation or other legal proceeding, including, without
limitation, with respect to any stockholder list or security holder listing or poison pill, rights
plan, or similar right, or derivative or other litigation or legal proceeding related to the
Company's capitalization, (f) designation, nomination, appointment, or election of any person as a
member of the board of directors of the Company, or (g) agreement, arrangement, or understanding
with the Company or any manager, director, officer, employee, stockholder, partner, affiliate,
associate, or related party of the Company.

Tender Offer Statement on Schedule TO - July 16, 2012 Exhibit (d)(i) Sponsorship Agreement - July
16, 2012
<!-- page 2 -->
2. Equity Commitments. Each Sponsor represents and warrants to each other Party that such Sponsor is
bound by and has complied with, and agrees that such Sponsor shall continue to be bound by and
comply with, the Equity Commitment Letter and that each other Sponsor (other than any Defaulting
Sponsor) shall be entitled to enforce, or direct the enforcement of, such Equity Commitment Letter
in accordance with this Agreement if and only if the Sponsors (other than any Defaulting Sponsor)
have determined by unanimous written consent that the conditions of the Offer have been satisfied or
to waive all such conditions remaining unsatisfied. No Party shall attempt to enforce any Equity
Commitment Letter until the conditions set forth in this Section have been satisfied. Purchaser
shall have no right to enforce any Equity Commitment Letter unless and until directed to do so by
the unanimous written consent of the Sponsors (other than any Defaulting Sponsor). 3. Defaulting and
Participating Sponsors. Each Sponsor that has complied with the Equity Commitment Letter and this
Agreement ("Participating Sponsor") may terminate the participation in the Offer of any Sponsor that
has not satisfied the funding requirements contemplated by the Equity Commitment Letter or otherwise
failed to comply with the Equity Commitment Letter and this Agreement ("Defaulting Sponsor");
provided, however, that such termination shall not affect any right of any Participating Sponsor as
against such Defaulting Sponsor with respect to such failure to fund or any such other
non-compliance. If the Participating Sponsors unanimously consent to proceed (and whether or not any
Participating Sponsor elects to seek specific performance as against any Defaulting Sponsor in
connection herewith), the amount of the commitment of each Defaulting Sponsor shall be offered,
first, to the Participating Sponsors pro rata (based on the commitments of such Participating
Sponsors), and, thereafter, as applicable, to one or more other co-investors, unanimously approved
by the Participating Sponsors. Notwithstanding anything herein to the contrary, from and after the
time any Sponsor becomes a Defaulting Sponsor, the approval or consent of such Defaulting Sponsor
shall not be required for any purpose hereunder; provided, however, that each Defaulting Sponsor
that ultimately participates in the Offer (as a result of any Participating Sponsor electing to seek
specific performance as against such Defaulting Sponsor) shall cease to be a "Defaulting Sponsor"
and shall have approval and consent rights hereunder. 4. Transfer Restrictions. During the
Pre-Acceptance Period, no Sponsor shall transfer any portion of the Commitment or any interest in
Purchaser ("Unit") other than to any investment fund affiliated with such Sponsor; provided,
however, that no such transfer shall relieve such Sponsor of any corresponding or other portion of
any obligation of such Sponsor under the Equity Commitment Letter or hereunder unless and until such
fund: (a) has committed equity or similar available capital in amounts sufficient to satisfy such
obligation; (b) executes and delivers to Purchaser an appropriate equity commitment letter, a
joinder signature page to this Agreement, and each other document reasonably requested by Purchaser
(collectively, the "New Sponsor Documents") and agrees to be bound hereby as a "Sponsor" hereunder;
(c) certifies to each Party that such fund is capable of performing the obligations of such fund
under each such New Sponsor Document; and (d) is approved by each non- transferring Participating
Sponsor, which approval may not be unreasonably withheld, conditioned, or delayed. 5. Interim Period
and Continuing Sponsors. Each Party shall use commercially reasonable efforts to negotiate and enter
into at or prior to the Acceptance Time: (a) an amended and restated limited liability company
agreement of Purchaser ("Purchaser LLC Agreement"); and (b) one or more definitive agreements with
the Participating Sponsors (collectively, "Security Holder Agreements") providing for the unanimous
consent of the Continuing Sponsors with respect to all decisions to be made by or on behalf of
Purchaser with respect to any Offer Matter or the Company or any security issued or to be issued by
the Company during the period on and from the Acceptance Date and until the time there ceases to be
at least two Continuing Sponsors ("Interim Period"), including without limitation, any matter
described in or contemplated by Section 1 hereof. For purposes hereof, "Continuing Sponsor" shall
mean and refer to each Participating Sponsor that becomes a member of Purchaser and a party to the
Purchaser LLC Agreement and Security Holder Agreements (collectively, the "Management-Ownership
Agreements"), in each case, as long as such Sponsor continues to be a member of Purchaser and comply
with the Management-Ownership Agreements. 6. Voting Agreements. Purchaser shall (and each Sponsor
shall cause each Unit owned by such Sponsor, if any, to be voted to cause Purchaser to) authorize,
issue, sell, or exchange, as applicable, Units to Participating Sponsors pro rata (based on the
Commitments of Participating Sponsors) and otherwise in accordance with the Equity Commitment
Letters and this Agreement; provided, however, that each Unit of any class or series shall be issued
at the same price(s) and in the same proportion(s) as all other Units of such class or series.

Tender Offer Statement on Schedule TO - July 16, 2012 Exhibit (d)(i) Sponsorship Agreement - July
16, 2012
<!-- page 3 -->
7. Distribution, Redemption, and Other Transfer Rights. Notwithstanding anything herein or in any
Management-Ownership Agreement to the contrary, each Continuing Sponsor may, at any time or from
time to time in such Sponsor's sole discretion, cause Purchaser to distribute or otherwise transfer
to such Sponsor all (but not less than all) of the amount of the Shares, if any, then owned by
Purchaser equal to such Sponsor's pro rata share thereof (based on the Units then owned by all
Sponsors) in redemption of or otherwise in exchange and as consideration for the Units then owned by
such Sponsor. 8. Termination Fee. An amount equal to any termination or similar fee received by
Purchaser, including, without limitation, any such fee paid by the Company or any affiliate,
associate, or related party of the Company pursuant to a merger agreement or otherwise, or portion
thereof remaining after making or confirming adequate provisions for the payment or reimbursement of
Transaction Costs, shall be promptly distributed or otherwise paid to the Sponsors (other than any
Defaulting Sponsor) or their designees, in any case, pro rata (based on the Commitments or Units of
such Sponsors, as applicable). 9. Expenses. To the extent Purchaser has available funds, Purchaser
shall promptly pay or reimburse, as applicable, all Transaction Costs incurred by or on behalf of
Purchaser or the Sponsors in connection with the Offer as follows: (a) first, all such Transaction
Costs reasonably incurred by or on behalf of Purchaser, including, without limitation, in connection
with the formation or organization of Purchaser; and (b) second, all such Transaction Costs
reasonably incurred by or on behalf of the Sponsors in connection with the Offer, which shall be
paid or reimbursed pro rata (based on the Commitments or Units of such Sponsors, as applicable).
Except as otherwise expressly provided hereby and to the extent Purchaser does not have available
funds, each Sponsor shall be responsible for any and all fees, expenses, and other costs incurred by
or on behalf of such Sponsor. 10. Disclosures; Legal Compliance. Each Party hereby represents and
warrants to, and agrees with, each other Party that: (a) in connection with the Offer and this
Agreement, such Party has not made, and shall not make, any untrue statement of a material fact or
omit to state a material fact necessary in order to make the statements made, in the light of the
circumstances under which they were made, not misleading; (b) all information provided by or on
behalf of such Party to any other Party for inclusion or incorporation by reference in any Schedule
TO or other filing with the Commission or any other tender offer material ("Provided Information")
was, when provided, true, accurate, correct, and complete in all material respects; provided
further, that such Sponsor shall cause such Provided Information and such filing and material, as
applicable, to be amended and supplemented, in each case, as required by law and otherwise promptly
and as necessary and appropriate to make the Provided Information and such filing and material, as
applicable, true, accurate, correct, and complete in all material respects; (c) such Party shall not
(and shall cause each related party of such Party not to) take any action or omit to take any action
that would violate, or cause Purchaser to be deemed in violation of, any securities or other law
applicable to the Offer, including, without limitation, (i) the U.S. Securities Exchange Act of
1934, as amended ("Exchange Act"), or Rule 14e-5 thereunder or (ii) with respect to tendering any
security of the Company in the Offer or paying any consideration to, or entering into any contract,
agreement, or arrangement with, any party in connection with or related to the Offer in violation of
Rule 14d-10 under the Exchange Act; and (d) such Party shall use commercially reasonable efforts to
cooperate with each other Party to establish protocols to ensure compliance with this Section. 11.
Termination. This Agreement shall automatically terminate at and as of (the first to occur of): (a)
12:00 midnight, New York City time, on the 30th day after the Effective Date (if Purchaser has not
commenced the Offer, with the unanimous consent of the Sponsors, by then); (b) the expiration of the
Offer (if the Offer is not consummated pursuant to the terms of the Offer), subject to any extension
or subsequent offering period; and (c) the expiration of the Interim Period (if the Offer is
consummated pursuant to the terms of the Offer), in any case, unless sooner terminated by unanimous
written consent of the Participating Sponsors; provided, however, that any liability for failure to
comply with this Agreement shall survive any such termination. Notwithstanding the foregoing, each
Section hereof (other than Sections 1 through 6 (inclusive) hereof) shall survive indefinitely
following the termination of this Agreement. 12. Amendment. This Agreement may be amended or
modified, and the provisions hereof may be waived, only by an agreement in writing signed by each of
the Sponsors.

Tender Offer Statement on Schedule TO - July 16, 2012 Exhibit (d)(i) Sponsorship Agreement - July
16, 2012
<!-- page 4 -->
13. Severability. In the event that any provision hereof would, under applicable law, be invalid or
unenforceable in any respect, such provision shall be construed by modifying or limiting it so as to
be valid and enforceable to the maximum extent compatible with applicable law. The provisions hereof
are severable, and any provision hereof being held invalid or unenforceable shall not invalidate,
render unenforceable or otherwise affect any other provision hereof. 14. Remedies. Except as
otherwise provided herein, this Agreement shall be enforceable by all available remedies at law or
in equity (including, without limitation, specific performance). Each Participating Sponsor shall be
entitled, in their discretion, to either (a) specific performance of this Agreement and the Equity
Commitment Letters, together with any costs of enforcement incurred by such Participating Sponsor in
seeking to enforce such remedy against any Defaulting Sponsor or (b) payment by the Defaulting
Sponsor in an amount equal to the out-of-pocket damages incurred by such Participating Sponsor. If
any Participating Sponsor elects to enforce the remedy described in the preceding sentence against
any Defaulting Sponsor, such Participating Sponsor shall do so against all Defaulting Sponsors. No
party shall be entitled to recover lost profits or benefit of the bargain damages. If more than one
Defaulting Sponsor is responsible for any damages, each such Defaulting Sponsor's liability for such
damages shall be determined pro rata (based on the Commitments of such Defaulting Sponsors). 15.
Indemnification. To the fullest extent permitted by law, each Sponsor shall indemnify, defend and
hold harmless each other Sponsor and any of its affiliates or any direct or indirect partner,
member, shareholder, employee, director, officer or agent of such Sponsor or any of its affiliates
from and against any and all losses, liabilities, damages, claims, judgments, awards, settlements,
demands, offsets, and expenses (including interest, penalties, court costs, arbitration costs and
fees, witness fees and reasonable fees and expenses of outside attorneys, investigators, expert
witnesses, accountants and other professionals) arising out of or relating to any material breach or
inaccuracy of the representations, warranties or covenants of such Sponsor contained herein. 16. No
Recourse. Notwithstanding anything that may be expressed or implied in this Agreement or any
document or instrument delivered in connection herewith, and notwithstanding the fact that certain
of the Sponsors may be partnerships or limited liability companies, by acceptance of the benefits of
this Agreement, Purchaser and each Sponsor acknowledges and agrees that no Person other than each
Party has any obligation hereunder and no Party has any right of recovery under this Agreement or in
any document or instrument delivered in connection herewith, or for any claim based on, in respect
of, or by reason of, such obligations or their creation, against, and no personal liability shall
attach to, the former, current and future equity holders, controlling persons, directors, officers,
employees, agents, affiliates, members, managers, general or limited partners or assignees of the
Sponsors or any former, current or future stockholder, controlling person, director, officer,
employee, general or limited partner, member, manager, affiliate, agent or assignee of any of the
foregoing (collectively, "Non-Recourse Parties"), through Purchaser or otherwise, whether by or
through attempted piercing of the corporate veil, by or through a claim by or on behalf of Purchaser
against any Non- Recourse Party, by the enforcement of any assessment or by any legal or equitable
proceeding, by virtue of any statute, regulation or applicable law, or otherwise. Nothing set forth
in this Agreement shall confer or give or shall be construed to confer or give to any party other
than the Parties any rights or remedies against any Person other than as expressly set forth herein.
17. Governing Law; Consent to Jurisdiction. This Agreement shall be governed by and construed in
accordance with, the laws of the State of New York applicable to contracts executed in and to be
performed in that State. All actions arising out of or relating to this Agreement shall be heard and
determined exclusively in any New York state or federal court sitting in the Borough of Manhattan of
The City of New York. The parties hereto hereby (a) submit to the exclusive jurisdiction of any
state or federal court sitting in the Borough of Manhattan of The City of New York for the purpose
of any action arising out of or relating to this Agreement brought by any party hereto, and (b)
irrevocably waive, and agree not to assert by way of motion, defense, or otherwise, in any such
action, any claim that it is not subject personally to the jurisdiction of the above-named courts,
that its property is exempt or immune from attachment or execution, that the action is brought in an
inconvenient forum, that the venue of the action is improper, or that this Agreement or the
transactions contemplated hereby may not be enforced in or by any of the above-named courts.

Tender Offer Statement on Schedule TO - July 16, 2012 Exhibit (d)(i) Sponsorship Agreement - July
16, 2012
<!-- page 5 -->
18. WAIVER OF JURY TRIAL. EACH PARTY HERETO HEREBY WAIVES TO THE FULLEST EXTENT PERMITTED BY
APPLICABLE LAW ANY RIGHT IT MAY HAVE TO A TRIAL BY JURY WITH RESPECT TO ANY LITIGATION DIRECTLY OR
INDIRECTLY ARISING OUT OF, UNDER OR IN CONNECTION WITH THIS AGREEMENT OR ANY OF THE TRANSACTIONS
CONTEMPLATED HEREBY. 19. Exercise of Rights and Remedies. No delay of or omission in the exercise of
any right, power or remedy accruing to any party as a result of any breach or default by any other
party under this Agreement shall impair any such right, power or remedy, nor shall it be construed
as a waiver of or acquiescence in any such breach or default, or of any similar breach or default
occurring later, nor shall any such delay, omission or waiver of any single breach or default be
deemed a waiver of any other breach or default occurring before or after such waiver. 20. Other
Agreements. This Agreement, together with the agreements referenced herein, constitutes the entire
agreement, and supersedes all prior agreements, understandings, negotiations and statements, both
written and oral, among the parties or any of their affiliates with respect to the subject matter
contained herein except for such other agreements as are referenced herein which shall continue in
full force and effect in accordance with their terms. 21. Cooperation. Each Party shall use
commercially reasonable efforts to: (a) amend, supplement, or modify each Management-Ownership
Agreement, as necessary or appropriate, to be consistent with, and provide for each transaction and
other matter contemplated by, this Agreement; and (b) cooperate with each other Party, including,
without limitation, as reasonably requested by any Party to jointly and mutually determine how best
to structure and facilitate the Offer Matters and each agreement and transaction contemplated hereby
and maximize value for all concerned Parties, taking into account speed, timing, deal certainty,
administrative convenience, and applicable tax, legal, and business considerations and all other
relevant issues. 22. Assignment. This Agreement may not be assigned by any party or by operation of
law or otherwise without the prior written consent of each of the other parties. Any attempted
assignment in violation of this Section shall be null and void. 23. No Representations or Duties.
Each Sponsor specifically understands and agrees that no other Sponsor has made or will make any
representation or warranty with respect to the terms, value or any other aspect of the transactions
contemplated hereby, and explicitly disclaims any warranty, express or implied, with respect to such
matters. In addition, each Sponsor specifically acknowledges, represents and warrants that it is not
relying on any other Sponsor (a) for its due diligence concerning, or evaluation of, the Company or
its assets or businesses, (b) for its decision with respect to making any investment contemplated
hereby or (c) with respect to tax and other economic considerations involved in such investment. In
making any determination contemplated by this Agreement, each Sponsor may make such determination in
its sole and absolute discretion, taking into account only such Sponsor's own views, self-interest,
objectives and concerns. No Sponsor shall have any fiduciary or other duty to any other Sponsor or
to Purchaser except as expressly set forth in this Agreement. 24. Counterparts. This Agreement may
be executed in one or more counterparts, and by the different parties hereto in separate
counterparts, each of which when executed shall be deemed to be an original but all of which taken
together shall constitute one and the same agreement. Remainder of Page Intentionally Left Blank.
Signature Page(s) to Follow.

Tender Offer Statement on Schedule TO - July 16, 2012 Exhibit (d)(i) Sponsorship Agreement - July
16, 2012

Remainder of Page Intentionally Left Blank.

Tender Offer Statement on Schedule TO - July 16, 2012 Exhibit (d)(i) Sponsorship Agreement - July
16, 2012
<!-- page 6 -->
IN WITNESS WHEREOF, this Agreement is executed and effective as of the Effective Date. PURCHASER:
PEEK Investments LLC Date: July 16, 2012 By: /s/ Michael Onghai Name: Michael Onghai Title:
President SPONSOR(S): Platinum Partners Value Arbitrage Fund L.P. By: Platinum Management (NY) LLC
Its: Sole General Partner Date: July 16, 2012 By: /s/ Mark Nordlicht Name: Mark Nordlicht Title:
Chief Investment Officer Snowy August Fund I LP Date: July 16, 2012 By: /s/ Michael Onghai Name:
Michael Onghai Title: President

Signature Page
