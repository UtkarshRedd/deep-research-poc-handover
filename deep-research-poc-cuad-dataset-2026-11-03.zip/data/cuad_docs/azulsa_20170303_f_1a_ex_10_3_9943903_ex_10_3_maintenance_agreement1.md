<!-- page 1 -->
# GLOBAL MAINTENANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Maintenance Agreement |
| Agreement Date | 2015-03-09 |
| Parties | AZUL LINHAS AÉREAS BRASILEIRAS S/A ("Company", "AZUL"); AVIONS DE TRANSPORT REGIONAL, G.I.E. (“Repairer”, “ATR”); AZUL LINHAS AÉREAS BRASILEIRAS and AVIONS DE TRANSPORT REGIONAL, G.I.E. (individually referred to as the “Party” or collectively as the “Parties”) |
| Source | CUAD v1 / AzulSa_20170303_F-1A_EX-10.3_9943903_EX-10.3_Maintenance Agreement1 |

Execution version

Exhibit 10.3

CONFIDENTIAL TREATMENT REQUESTED - REDACTED COPY Confidential Treatment has been requested for
portions of this Exhibit. Confidential portions of this Exhibit are designated by [*****]. A
complete version of this Exhibit has been filed separately with the Securities and Exchange
Commission.

GLOBAL MAINTENANCE AGREEMENT Contract No. DS/CS-3957/14 issue 7

Between

AZUL LINHAS AÉREAS BRASILEIRAS S/A (as Company)

and

AVIONS DE TRANSPORT REGIONAL, G.I.E. (as Repairer)

March 9th, 2015

AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 1/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 2 -->
Execution version CONTENTS Clause Page 1. SUBJECT-MATTER OF THE AGREEMENT 6 2. DEFINITIONS AND
INTERPRETATION 6 3. DURATION AND RENEWAL 15 4. EXCUSABLE DELAY 15 5. SERVICES, LEASE AND OBLIGATIONS
OF THE PARTIES 16 6. DELIVERIES 18 7. WORK ORDERS 20 8. INSURANCES 21 9. WARRANTIES 22 10. PRICES 22
11. RECONCILIATION 22 12. INVOICING AND PAYMENT TERMS 23 13. SECURITY DEPOSIT 26 14. DISCLAIMER 27
15. LIABILITY AND INDEMNITY 27 16. TERMINATION 28 17. CONDITIONS PRECEDENT 31 18. EXPORT CONTROL 31
19. NOTICES 31 20. CONFIDENTIALITY 32 21. TAXES 34 22. ASSIGNMENT 34 23. MISCELLANEOUS 35 24.
GOVERNING LAW AND ARBITRATION 37 AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7
Page 2/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 3 -->
Execution version EXECUTION PAGE 39 EXHIBIT 1 - LIST OF ATR AIRCRAFT COVERED UNDER THIS AGREEMENT 40
EXHIBIT 2 - LIST OF SERVICES PROVIDED UNDER THIS AGREEMENT 42 EXHIBIT 3 - MAIN ELEMENTS COVERED
UNDER THE AGREEMENT 43 EXHIBIT 4 - LIST OF LANDING GEAR ON CONDITION PARTS 44 EXHIBIT 5 - STOCK 45
EXHIBIT 6 - LRUS COVERED BY REPAIR AND STANDARD EXCHANGE SERVICES 61 EXHIBIT 7 - REPAIRER STANDARD
WORK ORDER FORMS 70 EXHIBIT 8 - LEASE OF THE STOCK 74 EXHIBIT 9 - SPARE PARTS STANDARD EXCHANGE
SERVICE 80 EXHIBIT 10 - LRUS REPAIR SERVICE 84 EXHIBIT 11 - MAIN ELEMENTS SERVICES 86 EXHIBIT 12 -
INTENTIONALLY LEFT BLANK 92 EXHIBIT 13 - FORM OF STANDBY LETTER OF CREDIT 93 EXHIBIT 14 - PRICE
CONDITIONS 94 EXHIBIT 15 - ADVANCED POOL SERVICE 101 EXHIBIT 16 - ADVANCED POOL STOCK 106 EXHIBIT 17
- INSURANCE CERTIFICATES 108 EXHIBIT 18 - NOTA FISCAL REPORTING 109 AZUL-ATR Global Maintenance
Master Agreement DS/CS-3957/14/Issue 7 Page 3/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 4 -->
Execution version THIS GLOBAL MAINTENANCE AGREEMENT (HEREINAFTER REFERRED TO AS THE "AGREEMENT" OR
"GMMA") IS MADE ON March 9th 2015:

BETWEEN:

AZUL LINHAS AÉREAS BRASILEIRAS S/A, a company incorporated under the laws of Brazil, the registered
office of which is located at Avenida Marcos Penteado de Ulhôa Rodrigues, 939 - Edif. Castello
Branco Office Park - Torre Jatobá - 9° andar - CEP 06460-040 - Alphaville Industrial - Barueri - São
Paulo - Brazil, identified under Cadastro Nacional de pessoa Juridica (CNPJ) number
09.296.295/0001-60.

Hereafter referred to as the "Company" or "AZUL",

on the one part,

AND:

AVIONS DE TRANSPORT REGIONAL, G.I.E., a French groupement d'intérêt économique established under
articles L.251-1 to L251-23 of the French Commercial Code, whose registered office is at 1 allée
Pierre Nadot, 31712 Blagnac, France identified under Corporate and Trade Register of Toulouse number
323 932 236,

Hereafter referred to as the "Repairer"or "ATR",

on the other part.

Hereinafter individually referred to as the "Party" or collectively as the "Parties", as the context
requires. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 4/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 5 -->
Execution version RECITALS:

1) WHEREAS AZUL and ATR have entered into a Global Maintenance Agreement ref DS/CC-2612/10 (dated
December 24t h, 2010) to support AZUL ATR aircraft fleet for operational support tasks as well as
scheduled and unscheduled maintenance, as amended from time to time ("GMA AZUL"); and,

2) WHEREAS TRIP and ATR have entered into a Global Maintenance Agreement ref DS/C- 2883/09 (dated
September 10t h, 2010) to support TRIP ATR aircraft fleet for operational support tasks as well as
scheduled and unscheduled maintenance, as amended from time to time ("GMA TRIP"); and,

3) WHEREAS pursuant to an investment agreement dated on May 25, 2012, entered into between Trip
shareholders and Azul S.A., TRIP became a wholly owned subsidiary of the latter, integrating the
Azul Group which already includes AZUL, an operating company, as duly approved in due time by their
respective corporate governing bodies and the relevant authorities (National Civil Aviation
Agency-"ANAC"-and Brazilian Antitrust Authority-"CADE"); and 4) WHEREAS further to operation as
detailed above in 3), AZUL progressively operated an enlarged fleet of Aircraft coming from
TRIP;and,

5) WHEREAS, in consideration of the local repair service in Brazil and the Aircraft fleet now solely
operated by AZUL, the Parties wish to terminate the GMA TRIP and the GMA AZUL, and to enter into
negotiation for a new GMLA between ATR and AZUL, on the terms and conditions set forth herein.

NOW THEREFORE, IT IS HEREBY AGREED AS FOLLOWS: AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 5/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 6 -->
Execution version

1. SUBJECT-MATTER OF THE AGREEMENT

This Agreement describes the terms and conditions according to which the Repairer (i) shall provide,
or cause its Subcontractors to provide, Services for the Company's Aircraft fleet; and (ii) agrees
to lease the Stock to the Company and the Company agrees to take the Stock on lease, subject to the
terms and conditions set forth on Exhibit 8.

2. DEFINITIONS AND INTERPRETATION

2.1 Unless otherwise defined, capitalised terms, singular or plural, used in this Agreement shall
have the meaning set out below: "Abnormal Use"

means any usage, maintenance, storage, handling of the Aircraft, or its sub-assemblies, or its
systems, or Items fitted on it including LRUs, Main Elements, Spare Main Elements, that does not
comply with all applicable technical documentation and any other instructions issued by the
manufacturers and which is not attributable to the Repairer or Subcontractors, including: (i) Any
failure by the Company to correctly comply with any Repairer and/or OEM instructions or
recommendations, technical directives, or any workmanship defect, lack of qualification, non-
approved repair and/or maintenance method; or, (ii) Any negligence or failure to exercise reasonable
effort(s) made to initiate corrective action(s), or lateness or total or partial failure in
undertaking corrective action(s), for Aircraft or LRU(s) or Main Element(s) malfunctions which
should have been reasonably identified by the Company; or, (iii) Any Aircraft, LRU(s) or Main
Element(s) suffering damage or premature removal arising out of or in connection with any defective
storage, inappropriate Packaging or transport by the Company or its forwarder agent, or gross
negligence or wilful misconduct of the Company(or its subcontractors or agents); or (iv) Any events
or circumstances, including: FOD, abnormal wear, hard contact, material drop or shock, engine fire
or submersion, lightning strike, hard landing, hail (including on storage position), partial or
total destruction or loss of Aircraft, LRU(s) or, Main Element(s);

"Affiliates" means with respect to any entity, any entity Controlled by, Controlling or under Common
Control with, the first entity, and/or their respective lawful successors and/or assigns;

"Agreement" has the meaning set forth in page four (4) here above;

"Aircraft"

means collectively or individually as the context requires the ATR aircraft listed in Exhibit 1
("List of ATR Aircraft covered under this Agreement"), amended from time to time by way of notice
sent to the Company , as relevant, by Repairer in order to cover any further ATR aircraft entering
the Company's fleet, including the airframe, engines, propellers and landing gears and parts
installed on the Aircraft, when solely operated by the Company ; AZUL-ATR Global Maintenance Master
Agreement DS/CS-3957/14/Issue 7 Page 6/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 7 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED "Airworthiness Authority"

means, in respect of any jurisdiction, the Government Entity, which under the laws of such
jurisdiction, has control over civil aviation or the registration, airworthiness, operation of
aircraft in such jurisdiction, including, in the European Union, the European Aviation Safety Agency
(the "EASA") and, in the United States of America, the Federal Aviation Administration (the "FAA");

"Airworthiness Directives" or "AD" means enforceable rules issued by the relevant Airworthiness
Authorities that have a mandatory impact on Aircraft operation and/or maintenance;

"Aircraft Maintenance Manual" or "AMM"

means the customized manual, drafted in compliance with the ATA100 specifications, issued by ATR, as
Aircraft manufacturer, and which is split into three (3) separate parts, namely: the Description and
Operation Manual, the Trouble Shooting Manual and the Job Instruction Cards; the purpose of which is
to provide all information required for Aircraft maintenance, while ensuring personnel and flight
safety;

"Aircraft On Ground" or "AOG"

means the highest priority designation to process a requirement for an LRU and/or maintenance
action; when applied to an Aircraft, such term indicates that such Aircraft is unable to continue or
to be returned to revenue service until that appropriate action is taken;

"ANAC" means Agência Nacional de Aviação Civil, the Brazilian Civil Aviation Authority;

"ATA" means Air Transport Association of America Inc.;

"ATA 300"

means documentation issued by ATA (as amended from time to time, or any other ATA's substituted
documentation) reviews the design, development and procurement of effective packaging of supplies
shipped by either Party to the other Party; it provides packaging instructions for repairable and
expendable units and components, included packaging standards for kits, preparation of hazardous
materials for shipment and handling of electrostatic discharge sensitive devices.

"BER" or "Beyond Economical Repair"

means the case in which the repair cost of any unserviceable Item is greater than [*****] of the
price for a brand new identical LRU and/or Main Element;

"BUR" or "Basic Unscheduled Removal"

means any basic unplanned removal, premature removal of a LRU or a Main Element, due to a sub-
component or accessory induced malfunction. Likewise, removal of a LRU and/or a Main Element,
component or accessory due to a problem which could have been rectified using troubleshooting and/or
corrective line maintenance actions as specified in the applicable AMM is not considered to be a
BUR;

"Business Day" means a day, other than a Saturday or a Sunday, on which banks are open for the
transaction of domestic and foreign exchange business in Paris (France) and São Paulo (Brazil);

"CMM" or "Component Maintenance Manuals"

means a manual issued either by any relevant OEM and containing instruction concerning the overhaul
and/or repair of components together with procedures for restoring such components to a fully
serviceable condition. These manuals shall be compliant with ATA100 Specification; [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 7/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 8 -->
Execution version "Confidential Information"

means all and/or any part of any information and/or data disclosed to and/or obtained by either
Party from the other Party during the Term relating to or in connection with the performance of this
Agreement; such information is conclusively considered as confidential without it being necessary to
mention at the moment of its disclosure, and includes: (i) technical information, such as
instructional know-how, academic and/or practical maintenance courses and/or aircraft piloting
courses, programs, software, manufacturing secrets, processes, prototypes, research work, studies,
plans, sketches, formulae, samples, specifications, diagrams, etc., (ii) commercial information,
such as list of customers, suppliers, etc., (iii) financial (tariffs, margins, market parts, etc.),
(iv) legal information, such as the Agreement, Exhibits, contracts, amendments, appendices,
contractual relations, negotiations, partners, etc. and (v) written, electronic or oral information
(hard copy, computer, digital, etc.);

Control", "Controlled", "Controlling" and "Common Control"

are to be interpreted as follows: "I. A company is deemed to control another company: (i) When it
directly or indirectly holds a fraction of the capital that gives it a majority of the voting rights
at that company's general meetings; (ii) When it alone holds a majority of the voting rights in that
company by virtue of an agreement entered into with other partners or shareholders and this is not
contrary to the company's interests; (iii) When it effectively determines the decisions taken at
that company's general meetings through the voting rights it holds; (iv) When it is a partner in, or
shareholder of, that company and has the power to appoint or dismiss the majority of the members of
that company's administrative, management or supervisory structures. II.—It is presumed to exercise
such control when it directly or indirectly holds a fraction of the voting rights above 40% and no
other partner or shareholder directly or indirectly holds a fraction larger than its own. III.—For
the purposes of the same sections of the present chapter, two or more companies acting jointly are
deemed to jointly control another company when they effectively determine the decisions taken at its
general meetings".

"Core Unit" means any unserviceable LRU returned by the Company to the Repairer as a counterpart to
standard exchange;

"Credit Note" "Credit Note" Means the credit note to be issued by the Repairer in accordance with
Clause 11 ("Reconciliation") of this Agreement.

"CSN" means the accrued Cycles Since New;

"CSO" means the accrued Cycles Since Overhaul;

"CY" or "Cycle" means a completed Aircraft takeoff and landing sequence;

"Day" means a calendar day; AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page
8/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 9 -->
Execution version "Default" means any failure by either Party to perform or observe any material
obligation under this Agreement, including as set forth with Clause 16.1 b) and including Abnormal
Use;

"Delivery" means the act of the Repairer putting at the Company's disposal any Item at Delivery
Location according to the terms of this Agreement;

"Delivery Location" means the Repairer's facility as defined under Clause 6 ("Deliveries") of this
Agreement;

"Early Event"

concerns LRU and/or Main Element and/or Aircraft airframe maintenance subject to Scheduled Event and
designates a situation where a Scheduled Event takes place before it is scheduled pursuant to
Exhibit 11 Clause 1.2 for the Main Element and/or to the CMM for the LRU when applicable;

"End Date"

means the date on which this Agreement is terminated or expires, and shall be the earlier to occur
of the following, as appropriate: (i) the end of the Initial Term as defined in Clause 3.1of this
Agreement; or, (ii) the end of the term of each annual renewal of this Agreement as per Clause 3.2
of this Agreement; or, (iii) the date on which all or part of this Agreement is terminated as per
Clause 16 ("Termination");

"Euros" or "€" designates the legal currency of the member countries of the European Union who have
adhered to the European Monetary Union;

"Excusable Delay" has the meaning set forth in Clause 4.1 of this Agreement;

"Fleet Turnover" means the amount normally invoiced under this Agreement using the Standard
Operations and all applicable prices in Exhibit 14 ("Price conditions");

"FH"or "Flight Hour" means airborne flight hour, the unit of measure of each Aircraft flight
activity for the time elapsed between Aircraft take-off and Aircraft landing;

"FOD"

stands for Foreign Object Damage and means any damage, whether direct or indirect, to any Item
and/or the airframe caused as a result of or related to any foreign object not forming part of any
Item and/or the airframe;

"Government Entity" means any national government, political subdivision thereof, or local
jurisdiction thereof;

"Incoterms" means the international rules for the interpretation of trade terms published by the
International Chamber of Commerce ("ICC"), 2000 edition;

"Initial Term" has the meaning set forth in Clause 3.1 of this Agreement;

"Item"

means, as the case may be, any LRU, Main Element, Spare Main Element, any of their sub- assembly or
sub-component, any part of the Stock, or for the sake of clarity any part covered under this
Agreement; AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 9/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 10 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED "Law" means any applicable law, order, statute,
statutory instrument, regulation, decree, directive or instrument of equivalent effect;

"LIBOR"

stands for "London Interbank Offered Rate", which designates the annual rate equal to one month in
Eurodollars quoted at 11:00 hours or approximately 11:00 hours (London time), as indicated on
"Reuters screen" LIBOR01page, for an amount and period selected by the Repairer, which is available
to the subscribers to the Telerate electronic display terminal, [*****] prior to the corresponding
period;

"LOC" or "StandBy Letter of Credit"

means an irrevocable letter of credit in the form or substantial form stipulated by Exhibit 13
("Form of StandBy Letter of Credit"), in accordance with Uniform Customs and Practice ("UCP") for
the documentary credit, 2007 revision, ICC publication n°600, issued by a major international bank,
confirmed by and domiciliated in NATIXIS, Paris, France, provided by the Company to the Repairer in
accordance with Clause 13 ("Security Deposit") of this Agreement;

"Loss"

means any and all losses, costs, charges, expenses, interests (including default interest), fees
(including legal fees and value-added tax thereon if applicable), payments, demands, liabilities,
claims, actions, proceedings (including stamp, documentary, registration or other duties, taxes or
any charges incurred by and/or in connection with proceedings), penalties, damages, adverse
judgments, orders or other sanctions;

"Lost Potential" with respect to LRU and/or Main Elements subject to Scheduled Events, designates,
in the case of an Early Event, [*****];

"LRU(s)" or "Line Replaceable Unit(s)"

means any equipment that can be replaced on line by the Company's technicians and listed into
Exhibit 6 ("LRUs covered by repair and standard exchange Services");

"Main Element"

means a propeller and/or a landing gear and/or an engine as listed in Exhibit 3 ("Main Elements and
part numbers covered by this Agreement") and/or in Exhibit 5 ("Stock"), or any of their respective
sub-assemblies;

"MMEL" or "Master Minimum Equipment List"

means a document provided by ATR providing operating and maintenance procedures for a categorized
list of systems, instruments and equipment on an ATR aircraft that may be inoperative for flight;

"Mean Time Between Unscheduled Removals" or "MTBUR"

means a figure for assessing performance calculated by dividing the total number of FH of the ATR
aircraft worldwide fleet during a given period, by the number of unscheduled removals of LRUs
recorded during the same period on the same fleet;

[*****] Confidential material redacted and filed separately with the Securities and Exchange
Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 10/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 11 -->
Execution version "MPD" or "Maintenance Planning Document"

means the documents issued by the Aircraft manufacturer, providing periodic maintenance requirements
data necessary to plan and conduct the Aircraft maintenance checks and inspections, in force on the
Signing Date;

"MRBR"

means the Maintenance Review Board Report, which outlines the initial minimum maintenance
requirements to be used in the development of an approved continuous airworthiness maintenance
program for the Aircraft, and which is issued by the Maintenance Review Board ("MRB");

"Measured Removal Rate(s)" or "MRR"

designates, for the Aircraft and depending on the Aircraft age, the quantity of LRU removals per one
thousand (1,000) FH, established in units and tens, to be measured during each period of three (3)
consecutive Months of Aircraft activity during the Term for all LRUs listed into Exhibit 6 ("LRUs
covered by repair and standard exchange Services") excluding Main Elements and/or Main Element
subassemblies, repair warranty and "Rogue" units;

"Month"

refers to a period starting on one day in a calendar month and ending on the numerically
corresponding day in the next calendar month (and references to months shall be construed
accordingly) save that, where any such period would otherwise end on a non-Business Day, it shall
end on the next Business Day, provided that if a period starts on the last Business Day in a
calendar month or if there is no numerically corresponding day in the month in which that period
ends, that period shall end on the last Business Day in that later month;

"NFF" or "No Fault Found"

means any event where an Item removed from an Aircraft by the Company and returned to the Repairer
for repair is declared serviceable with non-confirmed fault by the latter through strip report or
where a serviceable Item removed from the Pool by the Repairer and delivered to the Company under
the standard exchange Service set out in Exhibit 9 ("Spare parts standard exchange Service") is
returned by the Company to the Repairer unused;

"Notice"

means any notice or communication pertaining to this Agreement which shall be given in writing
delivered by hand and/or by courier service with proof of delivery and/or by fax, and: a) if
delivered by hand, shall have been deemed received when so delivered; or, b) if delivered by
registered mail, shall be deemed to have been received by the addressee on the Day on which it shall
have signed as received; or, c) if delivered by fax, shall be deemed to have been received by the
addressee on the next Business Day following electronic acknowledgement. In the event a Party
chooses to give a Notice by several of the aforesaid means, the earliest of the receipt dates will
be considered. In any case, any notice or communication shall be also transmitted by an e-mail with
attached copy of such (in format PDF or similar support)n, for courtesy purpose only. AZUL-ATR
Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 11/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 12 -->
Execution version "OEM" or "Original Equipment Manufacturer"

means a manufacturer of parts other than ATR manufactured parts including the engine manufacturer,
the propeller manufacturer, the landing gear manufacturer or an LRU manufacturer;

"Packaging" or "Packed"

means packaging of any Item or packed Item, as relevant, shipped by either Party to other Party
under the Agreement, in compliance with the following: (i) Repairer's and/or its suppliers' and/or
its Subcontractors' and/or OEM's recommendations, as relevant; and (ii) ATA 300 specifications for
air transport; and/or (iii) International Carriage Of Dangerous Goods By Road ("ADR") regulation for
good and reusable condition; and/or, (iv) International Air Transport Association ("IATA") Dangerous
Goods Regulations, for any shipment of dangerous Items. "Person" means any state, division of a
state, Government Entity, individual or corporate body or any association of any one or more of the
foregoing;

"Pool"

designates a stock of serviceable LRUs listed in Exhibit 6 ("LRUs covered by repair and standard
exchange Services"), available on a non-exclusive basis to the Company under standard exchange
Service as per Exhibit 9 ("Spare parts standard exchange Service"); such Pool may be amended from
time to time by the Repairer by way of Notice sent to the Company, in compliance with this
Agreement, subject to Company's approval.

"Repair Shop" means any FAA/EASA part 145 or ANAC approved repair shop selected by the Repairer and
acting as its Subcontractor;

"Repairer Indemnified Parties"

means the Repairer and/or ATR, as relevant, and/or their Affiliates and/or their respective lawful
successors and/or assigns and/or their respective subsidiaries, officers, directors, employees,
agents or Subcontractors;

"Reference Removal Rate(s)" or "RRR"

designates the standard reference rate of LRU removals per one thousand (1,000) FH, established in
units and tens, during each period of six (6) consecutive Months of Aircraft activity during the
Term for all LRUs listed into Exhibit 6 ("LRUs covered by repair and standard exchange Services")
excluding Main Elements and/or Main Element sub-assemblies, and indicated in Clause 1.3.1 of the
Exhibit 14 ("Price conditions");

"Rogue Units"

designates a LRU for which the same serial number has been removed from an Aircraft on three (3) or
more occasions for similar discrepancies (except regarding specific services not covered by the
Services and except to the extent caused by Company's Default), or four (4) NFF based on official
Repair Shop data within a twelve (12) Month period, with confirmation of approved trouble shooting
as per the CMM and/or the AMM; AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7
Page 12/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 13 -->
Execution version "Scheduled Event"

with respect to LRUs and/or Main Elements and/or Aircraft airframe that are subject to programmed
overhauls and/or inspections, designates such overhaul and/or inspections that shall take place
after a specified number of accrued FH and/or Cycles or Months as set out in Exhibit 11 ("Main
Elements Services") for the Main Elements and in the CMM for the relevant LRUs;

"Security Deposit"

designates the cash payment and/or the LOC issued, as security for the Company's performance of all
of its obligations under this Agreement, in compliance with Clause 13 ("Security Deposit") of this
Agreement;

"Service"

means any and all operational support tasks to be carried out by the Repairer and/or its
Subcontractors under this Agreement, as defined in Exhibit 2 ("List of Services provided under this
Agreement");

"Signing Date" means the date indicated on page four (4) of this Agreement and refers to the date on
which this Agreement is signed by both Parties;

"Spare Main Element" means the spare Main Element(s) the Repairer makes available to the Company
during Main Element maintenance according to Exhibit 11 ("Main Elements Services");

"Standard Operations" has the meaning set forth in Clause 3.2 of Exhibit 14 ("Price conditions");

"Start Date" means the date occurring thirty (30) Days after the Signing Date, subject to fulfilment
of the conditions set out in Clause 17 ("Conditions precedent");

"Stock" means all or part of the Items, as relevant, listed in Exhibit 5 ("Stock");

"Storage Location" means Company's facilities where the Stock is located as defined in Exhibit 8
("Lease of the Stock");

"Subcontractor" means any Person, including a Repair Shop, engaged by the Repairer to support the
Repairer in the performance of its contractual obligations under this Agreement;

"SWIFT" stands for the Society for Worldwide Interbank Financial Telecommunication;

"Taxe(s)"

mean any and all present or future fees (including license, recording, documentation and
registration fees), taxes [including income taxes, gross receipts taxes, capital taxes, franchise
taxes, net worth taxes, gross profits taxes, sales taxes, rental taxes, use taxes, turnover taxes,
value added taxes, ad valorem taxes, property taxes (tangible and intangible), excise taxes, customs
or import duty, documentary and stamp taxes], licenses, levies, imposts, duties, charges,
assessments or withholdings of any nature whatsoever, whether now existing or hereafter adopted,
enacted or amended, howsoever imposed, levied or asserted by any Government Entity or taxing
authority together with any and all penalties, fines, additions to tax and interest thereon;

"TBO" stands for Time Between Overhaul and means the FH or CY elapsed between two (2) consecutive
overhauls;

"Term" means the period of time starting from the Signing Date and ending on the End Date; AZUL-ATR
Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 13/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 14 -->
Execution version "Time and Material"

means any sale of goods and services, not covered by the scope of this Agreement and charged to the
Company, which is subject to the "ATR General Terms and Conditions for the Sale of Goods and
Services";

"TNR" or "Technically Non Reparable"

means where an unserviceable Item (i) is not repairable according to ATA 100 and/or (ii) for which
no technical repair can be considered;

"TSN" or "Time Since New" means the FH elapsed since new;

"TSO" or "Time Since Overhaul" means the FH elapsed since the last overhaul;

"US Dollar" or "$" designates the legal currency of the United States of America;

"Vendor Warranty Manual"

means the manual giving details of the warranties granted by an OEM with respect to certain parts of
Aircraft, provided by the said OEM;

"Week" means a period of seven (7) Days;

"Work Order" means any order issued by the Company to the Repairer for any of the Services and being
one of the forms set out in Exhibit 7 ("[Repairer standard Work Order forms"), as applicable.

2.2 In this Agreement, save as otherwise expressly indicated to the contrary, any reference to:
2.2.1 this Agreement or any other agreement or document shall be construed as a reference to this
Agreement or such other agreement ordocument as amended, novated or supplemented from time to time;
any reference to this Agreement includes its Exhibits; and, 2.2.2 any Clause shall be construed as a
reference to a clause of this Agreement and/or of an Exhibit to this Agreement, as relevant; and,
2.2.3 any Exhibit shall be construed as a reference to an Exhibit to this Agreement; and, 2.2.4
Headings: Clauses and Exhibits headings and sub-headings are used in this Agreement only for the
ease of reading. They are notintended to affect its meaning and should not be used for the sake of
its construction; and, 2.2.5 "including"shall be construed as a reference to "… including, without
limitation,…" or "… including but not limited to…"; and, 2.2.6 Singular and plural: wherever the
context so requires, the singular shall include the plural and vice versa; and, 2.2.7 a date will be
by reference to the Gregorian calendar; and, 2.2.8 "in writing" includes any modes of reproducing
words in a legible and non-transitory form but does not include e-mail (but caninclude the copy
"PDF" of any document sent AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page
14/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 15 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED by e-mail); and,

3. DURATION AND RENEWAL

3.1 The Agreement enters into force on the Signing Date; it will have a duration of [*****] as from
the Start Date (the "Initial Term"). 3.2 Upon expiry of the Initial Term, this Agreement [*****]
unless a Notice of non-renewal is given by either Party to the other Party [*****] prior to the
expiry of the Initial Term or the end of a renewal period, if any. 3.3 The Agreement shall end on
the End Date without any further action, unless otherwise provided under this Agreement.

4. EXCUSABLE DELAY

4.1 If a Party (the "Affected Party") is prevented, hindered or delayed from or in performing any of
its obligations under this Agreement by an event which is unpredictable and unavoidable, including
war or civil or foreign armed aggression, riots, fires, floods, explosions, earthquakes or
accidents, epidemics or quarantine restrictions, any act of a Government Entity, embargoes, export
prohibitions, failure by a subcontractor and/or vendor to furnish supplies or parts or delay the
same, strikes or labour troubles causing cessation of work, such event will be referred to as an
"Excusable Delay". 4.2 The Affected Party will give Notice to the other Party (the "Non-Affected
Party") of such Excusable Delay as soon as reasonably possible after it becomes aware thereof, and
the Affected Party will use its reasonable endeavours to mitigate the effects of such Excusable
Delay, without being obliged however to incur any unreasonable costs. 4.3 Neither Party shall be
held liable, or deemed to be in Default, if it fails to perform its obligations under this Agreement
due to an Excusable Delay; without prejudice to Clause 4.5 hereinafter, the time fixed for the
performance by the Affected Party of its obligations affected by the Excusable Delay shall be
equivalent to the time set out under this Agreement plus a grace period equivalent to the time lost
further to the occurrence of and because of the Excusable Delay. 4.4 As soon as reasonably possible
after the end of the Excusable Delay, the Affected Party shall give Notice to the Non-Affected Party
that the Excusable Delay has ended. 4.5 If the Excusable Delay continues for more than [*****] as
from the receipt by the Non-Affected Party of the Notice as per Clause 4.2, each Party shall be
entitled to terminate this Agreement according to the terms of Clause 16.4 hereof.

5. SERVICES AND OBLIGATIONS OF THE PARTIES

5.1 Services [*****] Confidential material redacted and filed separately with the Securities and
Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 15/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 16 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED The Repairer shall provide the Company with the
Services listed in Exhibit 2 ("List of Services provided under this Agreement"). 5.2 General
conditions of the Services

5.2.1 The Services shall comply with the applicable AMM, MRBR and MPD issued by ATR, as Aircraft
manufacturer, and the relevant CMM in force as of the Signing Date, and with the EASA and/or FAA or
ANAC regulations in force at the time of performance of such Services

5.2.2 Should the AMM, MRBR or the MPD be modified in a manner that is likely to modify or impact the
performance of the Services, the Parties hereby agree to negotiate in good faith the consequences of
such modifications and impacts on this Agreement (including on the prices set out in Exhibit 14
"Price conditions").

5.2.3 Audit of the Repair: Company shall have the right, under EUR OPS or PART M equivalent
applicable regulation approval, to audit the management and the performance of the Services provided
by the Repairer under this Agreement, subject to giving a [*****] prior Notice to the Repairer. The
cost of any such audits by the Company's representative(s) shall be borne by the Company unless if,
as a result of that audit, the Repairer is found to be in Default, in which cases the cost of such
audit will be borne by the Repairer. 5.2.4 Company's audit: at any time during the Term, the
Repairer may: (i) audit the management and the performance of the Company's maintenance activities
which are still under Company'sresponsibility; and/or, (ii) arrange for operational visits, in order
to check that the Company complies with its obligations under this Agreement; and/or, (iii)
investigate in any place, with the assistance of the Company, the causes of any abnormal removal or
failure rate of any Itemand/or Abnormal Use.

The Repairer shall give a Notice to the Company no later than [*****] prior to such audit or
operational visit.

The Company shall provide at no cost for the Repairer all necessary support to the Repairer's
representative(s) and give access to: (i) the Company's facilities or any other place where the
Aircraft and/or any data or document related to Aircraft maintenance andoperations that the Repairer
may require may be located; and, (ii) the exact number of accumulated FH and Cycles for any Aircraft
and Items operating or maintenance records.

Unless otherwise agreed between the Parties, any operational visit shall be conducted during the
scheduled operations of the Aircraft and the Repairer or its representative(s) shall use its
reasonable endeavors not to disrupt the Company's scheduled operations.

The cost incurred by the Repairer to conduct such audits and visits will be borne by the Repairer
unless (i) a Company's Default (as defined in Clause 16 "Termination") has occurred and/or (ii) as a
result of that audit or visit, the Company is found to be in Default, in which cases the cost of
such audit or operational visit will be borne by the Company .

The Repairer has no duty or obligation to perform any audit or operational visit and shall [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 16/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 17 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED not incur any obligation or liability if it does
not perform any of its audit or operational visit rights referred to in this Clause 5.2.4.

The Repairer shall notify the Company of the outcome of any such audit or operational visit and of
any remedial action that the Company shall perform to comply with its obligations under this
Agreement. The Company shall carry out all such remedial actions within a mutually agreed time
period , otherwise the Company shall be deemed in Default.

It is acknowledged and agreed that any audit or operational visit by the Repairer will be conducted
by the Repairer for its own purposes in connection with this Agreement and the Repairer shall have
no responsibility, liability or obligations with respect to the safety compliance with any AD,
operation or, except as otherwise provided herein, maintenance of any Aircraft, all of which shall
be the sole responsibility, liability and obligation of the Company. 5.3 Obligations of the Parties
5.3.1 Obligations of the Company

5.3.1.1 As a counterpart to the terms and conditions (including pricing conditions) agreed between
the Parties under this Agreement [*****]. In the event, the Company fails to do so, the Repairer
shall be entitled to revise such terms and conditions in order to take into account such failure.
5.3.1.2 During the Term, the Company shall: (i) operate and maintain the Aircraft in compliance with
all applicable technical documentation and any otherinstructions issued by ATR and the OEM; and,
(ii) remove and install LRUs and Main Elements from and on Aircraft; and,

(iii) comply with any AD, and order such incorporation or modifications from the Repairer; and
consequently manage the update of Aircraft, LRUs and Main Elements mandatory or regulatory technical
notices and log books and deliver to the Repairer a copy of such documentation upon each maintenance
event or upon Repairer's request; and, (iv) promptly inform the Repairer in case the Company or
their insurer intends to attend any LRU or Main Element tear-down at the Repair Shop; and,

(v) provide the Repairer not later than the tenth (10t h) Day of each Month with an activity report
relating to each Aircraft and each Main Element serial number, and containing at least FH and Cycles
performed during the preceding Month, the TSN, CSN, TSO, CSO, and the removals/installations events
during such Month; and, (vi) preserve the Aircraft, any Main Elements and/or any and all
sub-assemblies in accordance with the AMM in caseany Aircraft is temporarily unused by the Company
for any reason whatsoever. 5.3.2 Obligations of the Repairer

During the Term, the Repairer shall use its reasonable commercial endeavors, in accordance [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 17/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 18 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED with this Agreement: (i) to carry out the
Services pursuant to the Work Order(s) placed by the Company ; and, (ii) to ensure that the Services
provided to Company shall comply with EASA, FAA or ANAC regulations in force, as applicable (iii) in
the event of specific or exceptional circumstances affecting the Company or the Repairer, to obtain
the assistance of anyone or several third Parties servicers or suppliers of spare parts, subject to
the Company s prior approval; and (iv) to administer LRUs and Main Elements warranty claims issued
by the Company.

6. DELIVERIES

The Delivery Location shall be one of the addresses set out in Clauses 6.1 and 6.2 hereafter as the
context requires. 6.1 Items delivered by the Repairer to the Company

Unless otherwise set forth in this Agreement, the Repairer shall deliver to the Company: 6.1.1 any
Item as relevant in accordance with Exhibits 8 ("Lease of the Stock"), , 11 ("Main Elements
Services") and 15 ("Advanced PoolStock"), [*****] and Packed at the following address:

ATR Customer Support C/O DHL Solutions ZA du Pont Yblon 95500 Bonneuil en France

And;

any Item from the List A of the Exhibit 6 ("LRUs covered by repair and standard exchange services"),
as relevant in accordance with Exhibit 9 ("Spare parts standard exchange Service") and Exhibit 10
("LRUs repair Service"), [*****] and Packed at the following address:

ATR Customer Support C/O DHL Solutions ZA du Pont Yblon 95500 Bonneuil en France

And:

any Item from the List B of the Exhibit 6 ("LRUs covered by repair and standard exchange services"),
as relevant in accordance with Exhibit 9 ("Spare parts standard exchange Service") and Exhibit 10
("LRUs repair Service"), [*****] and Packed at the following address:

Helibras - Helicópteros do Brasil - Air Bus Helicopters Rodovia Dom Pedro I - Km 87 - Pista Norte
Condomínio Barão de Mauá - Atibaia - São Paulo [*****] Confidential material redacted and filed
separately with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 18/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 19 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED or at any other address the Repairer may from
time to time notify to the Company. 6.1.2 Intentionally left blank 6.2 Items returned by the Company
to the Repairer

The Company shall return to the Repairer: 6.2.1 any Item as relevant, in accordance with Exhibits 8
("Lease of the Stock"), 11 ("Main Elements Services") and 15 ("Advanced PoolStock"), [*****] and
Packed at the following address:

ATR Customer Support C/O DHL Solutions ZA du Pont Yblon 95500 Bonneuil en France

And;

any Item from the List A of the Exhibit 6 ("LRUs covered by repair and standard exchange services")
as relevant in accordance with Exhibit 9 ("Spare parts standard exchange Service") and Exhibit 10
("LRUs repair Service"), [*****] and Packed at the following address:

ATR Customer Support C/O DHL Solutions ZA du Pont Yblon 95500 Bonneuil en France

And:

any Item from the List B of the Exhibit 6 ("LRUs covered by repair and standard exchange services")
as relevant in accordance with 9 ("Spare parts standard exchange Service") and 10 ("LRUs repair
Service"), [*****] and Packed at the following address:

Helibras - Helicópteros do Brasil - Air Bus Helicopters Rodovia Dom Pedro I - Km 87 - Pista Norte
Condomínio Barão de Mauá - Atibaia - São Paulo

or at any other address the Repairer may from time to time notify to the Company. 6.2.2
Intentionally left blank 6.3 Nota fiscal reporting

Regarding the Items flow between the Stock and the Pool and vice et versa, as set forth under Clause
6 hereof, the Parties shall have the following obligations: - From Stock to Pool: the Company shall
issue in due time any necessary document or required by the Repairer, including the "NotaFiscal"
which shall comprise full, accurate [*****] Confidential material redacted and filed separately with
the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 19/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 20 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED and complete information (as further detailed
here below) and be in a form and substance compliant with applicable laws and regulations.

- From Pool to Stock: subject to receipt from the Company of any necessary document or required by
the Repairer as set forth here above, as relevant, the Repairer shall issue or have issued by third
party in due time any necessary document or required by the Company in the frame of the Services,
including the "Nota Fiscal" which shall comprise full, accurate and complete information (as further
detailed here below) and be in a form and substance compliant with applicable laws and regulations.
In addition, the Repairer shall provide or have provided by third party, a weekly reporting to the
Company regarding the traceability of the Items and promptly answer to any request from the Company
related thereto, in a form and substance in accordance with the form attached in Exhibit 18 ("Nota
fiscal reporting").

For the avoidance of doubt, each "Nota Fiscal" shall be established in compliance with the relevant
CFOP code according to the latest revision of SINIEF (Sistema Nacional Integrado de Informações
Econômico-Fiscais), the current version is 07/01, which shall notably comprise the following
element: - Seller of the goods: Name, address, contact information, Federal registration number,
State Registration number - Acquirer of the goods: Name, address, contact information, Federal
registration number, State Registration number - Transaction: type of transaction, nature of the
transaction, transaction code, date of the transaction - Product: description, code, quantity,
value, serial number of the relevant Item - Taxes : calculation basis, tax rate - Other information:
freight, insurance, other costs - Additional information: in case of special taxation"

7. WORK ORDERS

During the Term, the Company shall use the appropriate Work Order form (Exhibit 7 "Repairer Standard
Work Order Forms"), depending on the nature of the Service requested, and send the Work Order to the
Repairer according to the notice details below or any other contact the Repairer may from time to
time notify to the Company. For any Services ATR SPARES DISTRIBUTION DESK requested in standard Tel:
(33) 5 62 21 60 80 conditions (including Fax: (33) 5 62 21 62 80 routine and critical): e-mail:
spares.orders@atr.fr

For any Services A.O.G. DESK: requested in AOG Tel: (33) 5 62 21 62 00 conditions: Fax: (33) 5 62 21
62 62 e-mail: aog.toulouse@atr.fr 8. INSURANCES

8.1 Without prejudice to any term and condition under this Agreement, the Company shall maintain in
force, at all times during the Term and [*****], at its own costs and expenses, with insurers of
internationally recognized [*****] Confidential material redacted and filed separately with the
Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue
7 Page 20/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 21 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED reputation reasonably acceptable to the Repairer,
insurances in accordance with industry standards with respect to the undertakings of the Company in
Clause 15 ("Liability and Indemnity") of this Agreement including: (i) Aircraft Hull and Spares All
Risks Insurances (including, to the extent usually available war and allied perils); and,

(ii) Comprehensive General Third Party Legal Liability and Aircraft Passengers and Third Party Legal
Liability Insurance in respect of incidents involving Aircraft to the extent usually available,
having a Combined Single Limit of not less than [*****] any one occurrence; and, (iii) Employer's
liability insurance; and, (iv) Repairer's values to be insured, including: - Lease of Stock (Exhibit
8 Clause 2.2) and Advanced Pool Service (Exhibit 15): the Items of the Stock shall be insured by
theCompany under Spares All Risk Insurance for not less than the full replacement value; and,

- Main Elements Service (Exhibit 11): each Spare Main Element to be delivered by the Repairer to the
Company shall be insured by the Company, for not less than its full replacement value, under the
Hull Insurance when installed on the Aircraft in addition to the agreed value of such Aircraft and
under the Spares All Risk Insurance while in Stock prior to attachment or following removal and
replacement from the Aircraft, including transportation to and from the Company. 8.2 In respect of
Hull and Spares All Risk Insurances, the Repairer shall be named as additional insured and loss
payee for their respective rights and interests, to the extent required under Clause 15 ("Liability
and Indemnity") of this Agreement. 8.3 In respect of Liability Insurance, the Repairer shall be
named as additional insured and loss payee, as relevant, to the extent required under Clause 15
("Liability and Indemnity"), with severability of interest and confirmation that the Company policy
shall be primary without right of contribution. 8.4 In respect of all of the above insurances to
contain breach or warranty provisions and confirmation the policies shall not be cancelled or
materially changed without [*****] prior written notice [*****] or such lesser period in respect of
War and Allied Peril). 8.5 Any applicable deductible shall be borne by the Company with respect to
the above insurances. 8.6 At the latest upon the Signing Date, the Company shall provide the
Repairer with relevant insurance certificates, in English, evidencing insurance requirements of this
Clause 8, in a form reasonably acceptable to the Repairer, to be attached to this Agreement in the
Exhibit 17 ("Insurance certificates").

Upon each renewal of the relevant insurance policies, the Company shall on reasonable request
provide the Repairer with relevant insurance certificates in order to evidence insurance is
maintained in accordance with this Clause 8. The Company also agrees to promptly pay each premium in
respect of the aforesaid insurances and in the event of its failure to take out or maintain any such
insurance then, without prejudice to any other rights it may have in respect of such failure, the
Repairer may do so in its place and recover the cost [*****] Confidential material redacted and
filed separately with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master
Agreement DS/CS-3957/14/Issue 7 Page 21/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 22 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED of doing so from the Company.

8.7 The Repairer shall at its own expense procure and maintain in force, with insurers of
internationally recognized reputation acceptable to the Company an Aviation Liability insurance
which should include:

(i) Aviation Products Liability insurance: the Repairer shall maintain or shall cause its
Subcontractors to maintain a Products Liability Insurance during the performance of the Services up
to an amount not less than [*****] per occurrence and in the annual aggregate; and, (ii) Hangar
Keeper Liability insurance: the Repairer shall maintain or shall cause its Subcontractors to
maintain during the performance ofthe Services an Hangar Keeper Liability Insurance in an amount of
not less than [*****] any one occurrence.

The Repairer shall, at the latest upon the Signing Date, provide the Company with evidence of the
insurance maintained in accordance with this Clause 8.7.

9. WARRANTIES

Upon Delivery, and subject to the terms of this Agreement, including the disclaimers and limitations
on liability set forth in such warranties and in Clause 14 ("Disclaimer") of this Agreement, the
Company shall be entitled to the benefit of the following warranties: i) For new LRUs or Main
Elements, the terms and conditions set into the related Vendor Warranty Manual and in ATR72-600
Aircraft inthe relevant clauses of the relevant Aircraft sale and purchase agreement, shall apply.

ii) For used LRUs and Main Elements repaired and overhauled by the Repairer, the warranty period
shall start on the date of Delivery and shall end [*****] thereafter, whichever occurs the earliest,
and such warranty shall be subject to the exclusions of warranty set forth in Exhibit 10 ("LRUs
Repair Service") and in Exhibit 11 ("Main Elements Services").

10. PRICES

The Company shall pay to the Repairer the prices for the Services set out in Exhibit 14 ("Price
conditions").

11. RECONCILIATION

11.1 Reconciliation: Every [*****] as from the Start Date and throughout the Term, the Parties will
record the actual number of FH and Cycles [*****] of the preceding [*****] period, in order to
reconcile (i) the amount effectively due to the Repairer with (ii) the total amount already paid by
the Company , as relevant, as per Clause 12.1 (ii) hereafter, with respect of such period, as
follows: (i) In case the amount effectively due to the Repairer with respect of the number [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 22/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 23 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED of FH and Cycles accumulated during the
considered [*****] period is higher than the total amount already paid by the Company for the said
period, the Repairer shall then issue an additional invoice in an amount equal to the difference
between these amounts, to be paid by the Company as per Clause 12 ("Invoicing and payment terms");
or,

(ii) In case the amount effectively due to the Repairer with respect of the number of FH and Cycles
accumulated during the considered [*****] period is lower than the total amount already paid by the
Company for said period, the Repairer shall issue a credit in an amount equal to the difference
between these amounts; and/or,

(iii) In case MRR is above RRR, the Repairer shall invoice an amount equal to the price set out in
Clauses 2.2 and 3 of the Exhibit 14 ("Price conditions"), multiplied by the Aircraft fleet FH
accrued during the [*****] reference period, multiplied by the difference between the MRR and the
RRR; or,

(iv) In case MRR is less than RRR, the Repairer shall issue a credit in an amount equal to the price
set out in Clauses 2.2 and 3 of the Exhibit 14 ("Price conditions"), multiplied by the Aircraft
fleet FH accrued during the [*****] reference period, multiplied by the difference between the RRR
and the MRR, with a maximum allowed difference of [*****].

Each reconciliation shall be independent and shall have no impact on any subsequent reconciliation
and/or invoicing. 11.2 Final reconciliation: within [*****] as from the End Date and without
prejudice to Clause 6 of Exhibit 14 ("Price conditions") when applicable, a final reconciliation
shall be performed by the Repairer as per this Clause 11 ("Reconciliation").

Any Credit Note resulting from this final reconciliation and due by the Repairer to the Company
shall be issued within [*****] as from the effective End Date, subject to Clause 11.3 of this
Agreement. 11.3 Each time a Credit Note results from any reconciliation, the Repairer shall issue
such Credit Note to the Company, provided that the Company, is not in Default.

12. INVOICING AND PAYMENT TERMS

12.1 The Repairer shall invoice the Company: (i) [*****] (ii) [*****] [*****] Confidential material
redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 23/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 24 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] [*****] [*****] [*****] [*****] [*****]
[*****] [*****] [*****] [*****] [*****] [*****] [*****] (iii) [*****] (iv) [*****] (v) [*****] (vi)
[*****] (vii) [*****] [*****] Confidential material redacted and filed separately with the
Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue
7 Page 24/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED
<!-- page 25 -->
(viii) [*****] (ix) [*****] (x) [*****] (xi) [*****] 12.2 Unless otherwise set out herein, the
Company shall pay all invoices issued by the Repairer pursuant to this Agreement, as follows: (i)
within thirty (30) Days from the date of issuance of the Repairer's invoice; and, (ii) in US
Dollars; and, (iii) by SWIFT wire transfer; and, (iv) to the following bank account :

NATIXIS PARIS 30 Avenue Pierre Mendès-France - 75013 PARIS - FRANCE Bank Code: [*****] Branch Code:
[*****] Beneficiary: Avions de Transport Régional G.I.E. Bank Account: [*****] Key: [*****] IBAN
Code: [*****]

or such other account as the Repairer may from time to time notify to the Company.

For the sake of clarity, the Repairer shall issue any invoice at least ten (10) Days before the
first Day of the Month of reference for the Services. 12.3 Payments due to the Repairer herein shall
be made in full, without set-off, counterclaim, deduction or withholding of any kind. Consequently,
the Company shall procure that the sums received by the Repairer under this Agreement shall be equal
to the full amounts expressed to be due to the Repairer herein, without deduction or withholding on
account of and free from any and all Taxes (including all applicable sales, use, transfer and value
added taxes and any tax required to be deducted or paid under the Laws of the country the Services
are provided in respect of amounts paid by the Company to the Repairer), levies, imposts, dues or
charges of whatever nature. 12.4 If any payment due to the Repairer (the "Unpaid Amount") remains
unpaid after the date on which it is payable (the "Due Date"), without prejudice to any other rights
or remedies that it may have at Law and/or under this Agreement, the Repairer shall be entitled to
charge interests on such overdue sum from the Due Date until the actual date of payment of such sum
at a rate per annum equal to the aggregate of [*****], such interest being calculated on a monthly
basis. In any case, such interest rate shall not be lower than the highest of the three (3)
following rates: [*****] Confidential material redacted and filed separately with the Securities and
Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 25/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED
<!-- page 26 -->
(i) [*****] (ii) [*****] (iii) [*****]

In addition to the foregoing, and in compliance with Article L441-6 of the French Commercial Code,
the Company shall pay a minimum fixed sum of forty (40) euros for compensation of recovery costs and
reimburse all costs and expenses (including legal costs) incurred by the Repairer in the collection
of any Unpaid Amount. 12.5 Invoice dispute: any invoice disputed by the Company shall have to be
issued by Notice duly documented to the Repairer within [*****] from the date of its issuance. For
the sake of clarity, the undisputed portion of such invoice shall be paid pursuant to this
Agreement. Any invoice not disputed by the Company within said [*****] period, shall be deemed to be
accepted by the Company.

13. SECURITY DEPOSIT

13.1 As per provisions of Clause 17 ("Conditions precedent"), and unless otherwise agreed by the
Parties, the Company shall pay the Security Deposit to the Repairer in an amount equal to the
aggregate of: (i) [*****], as per Exhibit 14 ("Price conditions"); and, (ii) [*****] of the value of
the Stock.

For the sake of clarity, the global amount of Security Deposit payable at the time of the Signing
Date shall be [*****]. 13.2 Such Security Deposit shall be constituted either, as follows, at the
option of the Company: (i) a cash deposit by SWIFT wire transfer to the bank account indicated in
Clause 12.2 (iv); or,

(ii) one (1) LOC with a validity of at least [*****], acceptable to the Repairer acting reasonably.
Such LOC shall be renewed and its confirmation extended, at the latest [*****] before the expiry of
each previous LOC; all costs incurred as a result of the issuance and confirmation of the LOC shall
be borne by the Company.

It is agreed that the Security Deposit must be available for the period ending [*****] after the
Term; such Security Deposit shall be the property of the Repairer and shall be non-refundable except
as set out in this Agreement.

Provided the Company is not in Default under this Agreement and/or any other agreement entered into
between the Parties and subject to the prior written approval of the Repairer, the Company shall be
entitled to substitute the LOC by a cash deposit, and vice et versa, subject to the terms of this
Clause 13. 13.3 In the event that the LOC is not renewed or extended as per the terms of Clause 13.2
here above, the cash deposit shall become immediately due and payable and the Repairer shall be
entitled to draw such LOC, in order for the Repairer to receive an amount equal to the Security
Deposit. [*****] Confidential material redacted and filed separately with the Securities and
Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 26/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 27 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED 13.4 If, during the Term, the Company is in
Default under this Agreement or under any other agreement entered into between the Repairer and the
Company, and without prejudice to any rights and remedies available at Law and/or under this
Agreement, the Repairer shall be entitled to forthwith use, apply or retain all or any portion of
the Security Deposit, in order to remedy such Default, including the failure to pay any due sums,
the compensation or otherwise reimbursement of any sums which the Repairer may in its discretion
advance or expend as a result of said failure.

If the Repairer so uses, applies or retains all or any portion of the Security Deposit, such use,
application or retention shall not be deemed a cure or waiver of its rights hereunder and/or at Law
as a consequence of any such Default, unless such use, application or retention has discharged in
full the relevant sums then due and owed to the Repairer by the Company, and the Company shall
voluntarily or promptly upon written demand provide to the Repairer additional security in an amount
sufficient to restore the Security Deposit. 13.5 At the maximum at the end of the period of [*****]
following the Term, (or such early date as the Company has made all payments due hereunder at the
Repairer satisfaction), and provided that the Company is not in Default under this Agreement or any
other agreement entered into between the Parties, the Repairer shall pay to the Company an amount
equal to the balance of the Security Deposit, if any.

14. DISCLAIMER

TO THE EXTENT PERMITTED BY LAW, THE TERMS AND CONDITIONS SET OUT IN THIS AGREEMENT SET OUT THE
REPAIRER'S ENTIRE LIABILITY WITH RESPECT TO ALL GOODS AND SERVICES SUPPLIED HEREUNDER AND THE
COMPANY AGREES THAT ALL OTHER CONDITIONS, WARRANTIES AND TERMS EXPRESSED OR IMPLIED BY LAW, STATUTE
OR OTHERWISE, ARE HEREBY EXPRESSLY EXCLUDED.

15. LIABILITY AND INDEMNITY

15.1 SUBJECT TO CLAUSE 15.2 BELOW, THE REPAIRER, SHALL NOT BE LIABLE TO THE COMPANY FOR ANY OF THE
FOLLOWING TYPES OF LOSS OR DAMAGE ARISING UNDER OR IN RELATION TO THIS AGREEMENT (WHETHER ARISING
FOR BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), BREACH OF STATUTORY DUTY, MISREPRESENTATION OR
OTHERWISE):

[*****]

[*****] 15.2 NOTHING IN THIS AGREEMENT SHALL EXCLUDE OR RESTRICT ANY LIABILITY [*****] Confidential
material redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 27/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 28 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED OF THE REPAIRER FOR DEATH OR PERSONAL INJURY
ARISING OUT OF NEGLIGENCE OR MISCONDUCT,, OR FOR ANY OTHER LIABILITY WHICH CANNOT BE EXCLUDED OR
LIMITED BY LAW. 15.3 WITHOUT PREJUDICE TO CLAUSES 15.1 AND 15.2, THE COMPANY SHALL, EXCEPT IN CASE
OF GROSS NEGLIGENCE OR WILFUL MISCONDUCT OF THE REPAIRER, BE LIABLE FOR AND SHALL INDEMNIFY AND HOLD
HARMLESS THE REPAIRER INDEMNIFIED PARTIES FROM AND AGAINST ALL LIABILITIES, CLAIMS, DAMAGES, LOSSES,
SUITS, ACTIONS, PROCEEDINGS, JUDGEMENTS, COSTS AND EXPENSES INCIDENT THERETO (INCLUDING LEGAL
EXPENSES AND ATTORNEY FEES INCIDENT THERETO OR INCIDENT TO SUCCESSFULLY ESTABLISHING THE RIGHT TO
INDEMNIFICATION), FOR INJURY TO OR DEATH OF ANY PERSON AND/OR FOR LOSS OF OR DAMAGE TO ANY PROPERTY
AND/OR FOR LOSS OF USE THEREOF ARISING (INCLUDING THE AIRCRAFT), CAUSED BY OR IN ANY WAY CONNECTED
TO THE PERFORMANCE OF THIS AGREEMENT.

16. TERMINATION

16.1 Termination events: without prejudice to any other rights under this Agreement and/or at Law,
either Party shall be entitled to terminate all or part of this Agreement by Notice of termination,
as per Clauses 16.4 ("Termination procedure") and 16.6 ("Consequences of termination"), in the
following events:

a) Insolvency: the other Party becomes insolvent or goes into liquidation or ceases paying its debts
as they fall due or makes an assignment for the benefit of creditors or if such Party being a
limited Company passes a resolution for its winding up or if a petition for its winding up is
presented or it files for protection from its creditors under any applicable Law relating to
bankruptcy or insolvency or any analogous event in any jurisdiction shall take place; and/or b)
Default: the other Party is in Default and does not remedy the same within [*****], or such extended
period granted by the non-defaulting Party, from Notice of default specifying the failure and
requiring the remedy of such, from the non-defaulting Party.

For the purpose of this Clause 16.1.b), will be deemed as material obligations under this Agreement,
without the following being exhaustive: (i) the compliance by the Company with any of its payment
obligations; (ii) the compliance by the Company with the provisions of Clause 17 ("Conditions
precedent") of this Agreement; (iii) the operation by the Company of at least one (1) Aircraft;

(iv) the use by the Company of any Item, delivered by the Repairer to the Company pursuant to
Exhibits 8 ("Lease of the Stock"), 9 ("Spare parts standard exchange Service"), 10 ("LRU repair
Service"), 11 ("Main Elements Services") and 15 ("Advanced Pool Stock") exclusively on Aircraft and
to benefit of the Parties; (v) the return by the Company to the Repairer of any unserviceable Item
which should be exclusively removed from an Aircraft; (vi) the compliance by the Repairer with its
Delivery obligations; (vii) the compliance by the Parties with any of the insurance obligations as
per Clause 8 ("Insurances") of this Agreement; (viii) the compliance by either Party with any other
of its obligations which by its [*****] Confidential material redacted and filed separately with the
Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue
7 Page 28/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 29 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED nature and/or context is intended to be material.
c) Excusable Delay: an Excusable Delay event lasting for more than [*****] in accordance with Clause
4.5 of this Agreement. 16.2 Left intentionally blank 16.3 Suspension procedure: notwithstanding the
terms of Clause 16.4 below, in the event of a Company's Default as per Clause 16.1.b), the Repairer
shall be entitled to suspend all or part of this Agreement by way of Notice of suspension which
shall specify: (i) the Services for which such suspension shall be immediately effective until such
Company's Default is corrected; and (ii) that any pending Work Order and/or placed as from the
Notice of suspension will be provided upon specific commercial proposalsubject to "Payment In
Advance" procedure (and/or any additional conditions to be agreed upon by the Parties, as relevant).

For the sake of clarity, such Notice of suspension shall not be construed as a waiver by the
Repairer of its rights regarding (i) the obligation of the Company to perform each and every of its
obligations under this Agreement and/or (ii) the right of the Repairer to enforce each and every of
such Company's obligations and/or (iii) the right of the Repairer to terminate this Agreement, as
per this Clause 16 ("Termination") of this Agreement. 16.4 Termination procedure: to the fullest
extent permitted by Law and/or under this Agreement, the termination of all or part of this
Agreement, for any reason whatsoever, as per Clauses 3 ("Duration and renewal") and 16
("Termination"), shall become effective as from the receipt by the relevant Party of a Notice of
termination from the other Party, or any other period to be granted by such other Party, without it
being necessary to take any further action or to seek any consent from the relevant Party or any
court having jurisdiction.

The right of a Party to terminate all or part of this Agreement as per this Clause 16 shall be
without prejudice to its other rights and remedies available at Law and/or under this Agreement to
seek termination of all or part of this Agreement before any court having jurisdiction, following
arbitration proceedings consistent with Clause 24 ("Governing law and arbitration") of this
Agreement.

In case of termination of part of this Agreement, the Notice of termination shall specify the
Services that shall be terminated on the date of such termination.

Any Work Order placed prior to the termination of all or part of this Agreement shall remain valid,
provided that (i) any sum due by the Company to the Repairer under the Agreement and/or any other
agreement between (i) the Repairer and (ii) the Company has been paid and (ii) when applicable, the
Company having paid in advance the relevant Work Order price.

In the cases set forth within Clause 16.1.b) above, the non-defaulting Party shall be entitled to
proceed by appropriate court action or actions, following arbitration proceedings consistent with
Clause 24 ("Governing law and arbitration") of this Agreement., to enforce performance of this
Agreement, and/or to recover damages, without incurring any liability whatsoever and without
prejudice to any other rights it may have at Law and/or under this Agreement, and specifically its
right to terminate all or part of this Agreement. 16.5 Early termination fee: subject to not being
in breach of any of its obligation under the Agreement, the Company may terminate this Agreement for
convenience by way of Notice of termination; the Agreement shall be then terminated following a
[*****] period as from [*****] Confidential material redacted and filed separately with the
Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue
7 Page 29/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 30 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED the receipt of such Notice by the Repairer or any
other lesser period to be granted by the Repairer.

Notwithstanding this Clause 16 ("Termination"), upon receipt of such Notice of termination and
without prejudice to any rights it may have at Law, the Repairer shall invoice to the Company an
early termination fee equivalent to [*****], which shall be paid within [*****] as from the issuance
date of the said invoice and/or set off against any outstanding or due payment to the Company, at
the Repairer's discretion.

16.6 Consequences of termination

16.6.1 Upon the End Date and without prejudice to any right that either Party may have at Law and/or
under this Agreement [notably as perClause 13 ("Security Deposit")], the termination and/or expiry
of the Agreement shall have the following consequences:

a) Payment and reimbursement: subject to the provision of reasonable documentary evidence, any
outstanding and/or due amounts by either Party to the other Party under this Agreement shall be
promptly paid, and any and all legal fees and out- of-pocket expenses of the Party which terminates
this Agreement for the other Party's Default including stamp, documentary, registration or other
like duties, taxes or any charges incurred and/or in connection with enforcing, perfecting,
protecting or preserving (or attempting to enforce, perfect, protect or preserve) any of its rights,
or in suing for or recovering any sum, under this Agreement shall be forthwith reimbursed; and/or,
b) Return of the Items: the Repairer shall be entitled, in accordance with the terms and conditions
of this Agreement, includingClause 6 ("Deliveries"), to:

(i) direct the Company to forthwith return the Items (excluding the Stock which, for the sake of
clarity, shall be treated as per terms and conditions of Clause 6 ("Return of the Stock") of the
Exhibit 8 and Clause 7 ("Purchase or return of the Advanced Pool Stock) of the Exhibit 15 to the
address hereafter and/or any other address the Repairer may notify from time to time to the Company:
[*****] and/or; (ii) repossess the Items and the Company agrees that the Repairer may enter onto the
Company's premises where suchItems may be located; and/or, (iii) carry out any work, repair,
re-certification, overhaul or replacement required to put such Items in serviceablecondition.

In any case under this Clause 16.6.1.b) ("Return of the Items"), the Company shall forthwith
reimburse and pay any Loss incurred and/or suffered by the Repairer. c) Termination for Default: in
addition to the provisions of Clause 16.6.1.a) and b) here above, the defaulting Party
shallindemnify and/or pay any Loss the other Party may sustain and/or incur as a result of such
Default.

d) In addition to the provisions of Clause 16.6.1.a) and b) and 16.6.1.c) here above, in the event
the Repairer terminates the Agreement further to the occurrence of the event set out in Clause
16.1.b) (iii), the Company shall indemnify and/or pay for any Loss the [*****] Confidential material
redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 30/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 31 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED Repairer may sustain and/or incur as a result of
such termination 16.6.2 Mitigation

In case of termination of all or part for any reason whatsoever and/or expiry of this Agreement,
either Party shall use reasonable endeavours to mitigate its Loss (to the extent within its control
to do so), but it shall not be obliged to consult with the other Party concerning any proposed
course of action or to notify such other Party of the taking of any particular action.

17. CONDITIONS PRECEDENT

The Repairer's obligations under this Agreement shall be subject to each of the following conditions
precedent having been met (or expressly waived by the Repairer) to the Repairer's satisfaction at
the latest the [*****] Day from the Signing Date: (ii) the Security Deposit being available as per
Clause 13 ("Security Deposit");and, (iii) a statement signed by a duly authorized officer of AZUL
recording the status (serial number, TSN, TSO, CSN, CSO, as applicable) ofeach Main Element as of
the Signing Date; and, (iv) a fully executed original of this Agreement; (v) the phase-in as per
Clause 5 of the Exhibit 14 ("Price conditions").

18. EXPORT CONTROL

The Company warrants that the Items, the Aircraft and Services shall be used for commercial purposes
only, and shall be used and/or re- exported (where relevant) in compliance with all export control
laws and regulations (hereinafter referred to as "Export Laws"), including those applicable to parts
and components of the Items and the Aircraft. The Company acknowledges that the Repairer's
obligations under this Agreement are subject to all such Export Laws, and that the Repairer shall in
no event be liable in the event that the performance by the Repairer of any of its obligations under
this Agreement is affected or impaired by Export Laws.

19. NOTICES

No Notice shall be deemed to have been duly given by a Party to the other unless addressed as
follows or to such other place or Person as the Parties may respectively designate in writing.

The Repairer shall be addressed at:

AVIONS DE TRANSPORT REGIONAL, G.I.E. 1, allée Pierre Nadot 31712 Blagnac CEDEX France

Attention: Mr Cyril DUPUY

E-mail: cyril.dupuy@atr.fr

Fax +00 33 5 62 21 67 40 [*****] Confidential material redacted and filed separately with the
Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue
7 Page 31/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 32 -->
Execution version The Company shall be addressed at: AZUL

Avenida Marcos Penteado de Ulhoa Rodrigues, 939, Castello Branco Office - Park - Torre Jatobá - 9°
andar - CEP 06460-040 - Alphaville Industrial, Barueri, SaoPaulo, Brazil Attention Evandro Braga de
Oliveira- : Technical officer E-mail: evandro.oliveira@voeazul.com.br Fax 55 11 4134-9890

20. CONFIDENTIALITY

20.1 Confidentiality obligations

Unless otherwise provided in this Agreement, any Confidential Information released by either of the
Parties (the "Disclosing Party") to the other Party (the "Receiving Party") shall not be released in
whole or in part to any third party.

In particular, the Receiving Party undertakes: - to keep the Confidential Information strictly
confidential, not to deliver, disclose or publish it to any third party including
subsidiarycompanies and companies having an interest in its capital, except as otherwise agreed in
writing by the Disclosing Party;

- to use the Confidential Information solely for the purpose of this Agreement and except as
otherwise expressly agreed in writing by theDisclosing Party, not to use the same or permit its use
for any other purpose;

- to disclose the Confidential Information only to those of its direct employees having a need to
know such Confidential Information in order to make permitted use thereof, after having beforehand
clearly informed such employees of the strictly confidential nature of the Confidential Information
and caused them to observe said conditions of confidentiality. The Receiving Party shall be
responsible for the correct performance of said obligations of confidentiality by its employees and
shall keep up to date the list of its personnel, to whom Confidential Information is communicated,
which list shall be made available to the Disclosing Party at its request; - not to duplicate the
Confidential Information nor to copy or reproduce the same beyond the purpose of the Agreement;

- not to disclose Confidential Information to any third party, unless such third party is acting at
the instruction of the Receiving Party and such disclosure is reasonably necessary to accomplish the
purpose of the Agreement, provided however, that prior to any such disclosure both of the following
conditions are satisfied:

(i) each of such third parties, shall have signed an acknowledgement to keep such Confidential
Information as strictly confidential;and,

(ii) the Receiving Party shall have obtained written prior approval of the Disclosing Party of such
proposed disclosure, whichapproval may be not unreasonably withheld or delayed.

- promptly notify the Disclosing Party if a disclosure of Confidential Information is required by a
Government Entity or by Law and to useall reasonable effort to assist the Disclosing Party in
limiting such disclosure to the extent permitted by Law;

- upon discovery of any disclosure of Confidential Information, regardless of whether such discovery
is intentional or inadvertent, the Receiving Party shall promptly notify the Disclosing Party and
take all reasonable actions (i) to retrieve the disclosed Confidential Information, (ii) to destroy
any unauthorized copies thereof and (iii) to AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 32/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 33 -->
Execution version stop further disclosure. 20.2 Non application of confidentiality obligations

The obligations of Receiving Party with respect to Confidential Information as set forth in this
Clause 20.1 above shall not be applicable to information which: (a) upon the Signing Date was part
of the public domain or became part of the public domain after the disclosure, other than by a
violationof the Agreement or any other non-disclosure agreement or the applicable Law of any
jurisdiction; or (b) was already lawfully known by the Receiving Party, as evidenced by written
records bearing an unquestionable date, prior the SigningDate by the Disclosing Party and was
unrestricted; or (c) was lawfully disclosed to the Receiving Party subsequently to the signature of
the Agreement by a third party which had not receivedthe same directly or indirectly from the
Disclosing Party and that such disclosure does not violate any non-disclosure agreement. 20.3
Permitted disclosure of Confidential Information

Notwithstanding any provision to the contrary in the Agreement, the Receiving Party shall be
entitled to disclose Confidential Information if required to do so: (a) by order of a court or
government agency of competent jurisdiction; or (b) by any applicable Law,

provided, however, that prior to making such disclosure, the Receiving Party shall if possible
advise the Disclosing Party of the circumstances requiring such disclosure in order to afford the
Disclosing Party sufficient advance notice to permit to raise any objections that it may deem
appropriate. 20.4 Disclosing Party's proprietary rights

Any Confidential Information shall remain the property of the Disclosing Party. The Agreement shall
not be construed as granting or conferring to the Receiving Party, either expressly or by
implication, any license or proprietary interest in or to any Confidential Information nor any right
of use beyond the purpose of this Agreement.

The Repairer, its Affiliates and/or its Subcontractors as applicable shall remain the exclusive
owner of any intellectual property right related to the Services including: design of the LRUs, Main
Elements, job cards, task cards, operating manual or industrial process, as relevant. No title to or
other ownership interest in the Confidential Information is transferred except as specifically
stated in the Agreement, and the Receiving Party hereby expressly disclaims any such rights or
interests.

The Receiving Party hereby acknowledges and recognises that Confidential Information is protected by
copyright Laws and related international treaty provisions, as the case may be. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 33/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 34 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED 20.5 For the sake of clarity, and for the purpose
of this Clause 20 and this Agreement, any of the receiving Party's Affiliates and their
Subcontractors shall not be considered as third party and shall be entitled to have access to any
Confidential Information disclosed by the disclosing Party in connection with this Agreement. 20.6
This Clause 20 shall survive termination or expiry of this Agreement for a period of five (5) years
following such End Date.

21. TAXES

The prices set out in this Agreement [*****] and the [*****] shall not be required to pay and the
[*****] shall bear, any present or future Taxes in any country of the Delivery [*****] pursuant to
the requirements of this Agreement including the following: i) Taxes levied on goods imported into
or services to be delivered under this Agreement; and, ii) Taxes levied on materials, equipment,
tools and documentation imported temporarily which are required for the performance of
thisAgreement; and, iii) Taxes levied in Company's country for goods or services delivered by the
Repairer to the Company; and, iv) Value added taxes, sales tax, services tax, or any similar taxes
imposed in any country, on goods or services delivered to the Company.

In the event any of the Items above are levied upon the [*****], the [*****] shall promptly issue a
Notice to the [*****]. The [*****], within [*****] of receipt of such notification from the [*****]
shall either cause the charge to be waived or pay the charges directly. For those Items above that
the [*****] is required by Law to pay, the [*****] shall charge the [*****] and the [*****] shall
reimburse the [*****] in an amount which leaves the [*****] in the same economic situation as if
such payment of charges and reimbursement thereof had not been required.

If the Company is required by Law to make a withholding of taxes on the payments due to the Repairer
under this Agreement, the Company shall gross up the payment so that the payment received by the
Repairer after such withholding tax shall be the same amount of the prices described herein.

For sake of clarity, the Repairer shall bear income tax assessed on the Repairer's income and net
profits in its country.

For Items delivered by the Repairer to the Company, the final customs clearance on flow between any
Repairer's Affiliate located abroad and warehouse located in Brazil, as notably set forth in Clause
6, shall be borne by the Company. Customs duties, IPI, ISS, ICMS and other similar taxes shall be
paid by the Company.

In addition, the Company shall provide the Repairer with the << import declarations >> pertaining to
any import activities performed by the Company.

22. ASSIGNMENT

There are no beneficiaries of this Agreement other than the Parties hereto and their Affiliates and
Subcontractors to the extent provided herein. [*****] Confidential material redacted and filed
separately with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 34/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 35 -->
Execution version This Agreement shall be binding on the successors and permitted assignees of the
Parties hereto.

a) This Agreement has been entered into between the Parties in consideration of and based on
characteristics specific to the Parties. Consequently either this Agreement or any of the respective
rights or obligations of the Parties hereunder may be assigned or otherwise transferred, in whole or
in part, in any form whatsoever (including by way of change of Control), by either Party subject to
the prior written consent of the other Party, which consent shall not be unreasonably withheld or
delayed, and any attempt to do so without such consent shall be null and void. b) Notwithstanding
the above:

(i) the Parties may at any time assign or transfer all or part of its rights and obligations under
this Agreement to any of its Affiliates provided that such assignment or transfer is previously
notified to the other Party. In such event, any reference in this Agreement to the assigning Party
shall be deemed to constitute a reference to the assignee with respect to the part of this Agreement
that is assigned; and,

(ii) nothing in this Agreement shall in any way restrict any change in shareholding or control of
the Parties or its Affiliates or the Repairer's rights to delegate obligations of it hereunder to a
Subcontractor. provided that, in such case, the Repairer will remain responsible for the provision
of the Services in accordance with the terms of this Agreement.

provided such assignment or transfer, change in shareholding or control has no material adverse
effect on any of the Company's rights and obligations under this Agreement.

23. MISCELLANEOUS

23.1 The time stipulated in this Agreement for all payments by the Company to the Repairer under
this Agreement shall be of the essence. 23.2 Survival: notwithstanding anything to the contrary
stated in this Agreement, no termination or expiry of this Agreement shall affect the following
rights or obligations of any Party hereto: (a) with respect to any payment hereunder actually owed
by either Party to the other under this Agreement prior to the End Date; and/or,

(b) pursuant to Clauses 2 - "Definitions and interpretation", 4 - "Excusable Delay", 8 -
"Insurances", 9 - "Warranties", 14 - "Disclaimer", 15 - "Liability and indemnity", 16 -
"Termination", 20 - "Confidentiality", 23.2 - "Survival", 23.5 - "No waiver", 23.8 - "Severability",
and 24 - "Governing law and arbitration"; and/or, (c) pursuant to any other provisions of this
Agreement that, by their nature and context, are intended to survive termination of thisAgreement.
23.3 Representations: each Party represents to the other Party that: 23.3.1 It is a legal entity
duly incorporated and validly existing under the laws of the jurisdiction indicated in this
Agreement; AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 35/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED
<!-- page 36 -->
23.3.2 The entering into and performance by it of its obligations in this Agreement are within its
corporate powers and have been duly authorized by all necessary corporate action and are not in
violation of any applicable Law or documents, and do not require the consent or approval of, or
registration or filing with, any Government Entity other than those already obtained or effected;
23.3.3 The signatory executing this Agreement on such Party's behalf has been vested with the
necessary authority and power to enterinto this Agreement on its behalf; 23.3.4 This Agreement
constitutes the Parties' legal, valid and binding obligation; 23.3.5 Subject to Clause 20
("Confidentiality"), it will furnish all information relating to the provisions of the Services
hereunder reasonablyrequired by the other Party and/or any Government Entity; 23.4 Left
intentionally blank 23.5 No waiver: the failure by either Party to enforce at any time any of the
provisions of this Agreement, or to require at any time the performance by the other Party of any of
the provisions hereof, shall not be construed to be a waiver of such provisions, nor in any way
affect the validity of this Agreement or any part thereof, or the right of such Party thereafter to
enforce each and every such provision. 23.6 Independent contractors: neither Party is the
representative or agent of the other Party for the purposes of this Agreement and nothing herein
shall be construed as authorizing either Party to act as the other Party's representative or agent.
Notwithstanding any other provisions of this Agreement, this Agreement shall not be construed as a
joint venture, partnership, agency, incorporation or business association. Each Party hereto shall
remain an independent contractor. 23.7 Amendments: this Agreement shall only be varied or amended by
a written document duly signed by duly authorized representatives of both Parties. Notwithstanding
the foregoing, Exhibit 1 ("List of ATR aircraft covered under this Agreement") and the Pool may be
amended from time to time by the Repairer by way of Notice sent to the Company, unless, for LRU's
reference suppression/replacement, the Company does not agree the same by way of Notice within
[*****] as from the receipt date of the said Notice from the Repairer, in compliance with this
Agreement and provided that it has no material economic impact to the Company. 23.8 Severability: if
any term or provision of this Agreement is determined to be invalid, illegal or incapable of being
enforced by any rule of Law or public policy, all other terms and provisions hereof shall remain in
full force and effect, and the Parties shall negotiate in good faith in order to modify this
Agreement with a provision having substantially the same legal and commercial effect as the severed
provision. 23.9 Entire Agreement: this Agreement constitutes the entire agreement between the
Parties and supersedes and replaces all prior discussions, representations, understandings or
agreements whether verbal or written, between the Parties hereto or their agents with respect to or
in connection with the subject matter hereto, save and except for the provisions of any agreements
which by their nature or wording are intended to remain in full force and effect (including
pre-existing confidentiality or non-disclosure undertakings not otherwise covered herein). No other
documents and agreements, including either Party's standard terms and conditions, whether existing
or future, will apply between the Parties with respect to the subject matter of this [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 36/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 37 -->
Execution version Agreement, unless where otherwise expressly provided for in this Agreement.

Each Party acknowledges that, in entering into this Agreement, it has not relied on, and shall have
no right or remedy (other than for breach of contract) in respect of any statement, representation,
insurance or warranty (whether made negligently or innocently) other than as expressly set out in
this Agreement.

Nothing in this Clause shall limit or exclude any liability of either Party arising out of its
pre-contract fraudulent misrepresentation or fraudulent concealment. 23.10Language: the Parties
declare that they have requested and hereby confirm their express wish that this Agreement and any
and all related documents be drawn up in the English language (or, if not in English, with a
certified English translation). 23.11Costs and expenses: except where this Agreement provides
otherwise, each Party shall pay its own costs relating to the negotiation, preparation, execution
and implementation of this Agreement and of any document related hereto. 23.12Counterparts: this
Agreement shall be signed in several counterparts, each of such counterparts so signed shall
constitute an original, and all counterparts together shall constitute a single instrument. Any
executed version delivered via facsimile transmission or electronic mail ("PDF" format) shall be
binding to the same extent as an original. Any Party who delivers such an executed version agrees to
subsequently deliver an original counterpart to any Party that requests it. 23.13Publicity and
public announcements: the Parties shall not make public announcements, press releases and/or
advertise on the signature and/or the existence of this Agreement (but not its contents) without the
prior written consent of the other Party.

The Repairer is entitled to use the Company's name and associated logos as a business reference for
its marketing activities in relation with the Services, provided such use (i) has no adverse impact
on, such as but not limited to, Company's reputation and image and (ii) complies with graphic design
policy of the Company. 23.14Company's audited financial statements: during the Term of this
Agreement, the Company undertakes to provide promptly the Repairer with (i) its audited financial
statements and (ii) any other financial information it shall request, acting reasonably, for each
relevant financial year. It is hereby agreed that any such information shall be prepared in
accordance with the applicable accounting policies. 23.15For the sake of clarity and transparency,
the Services to be provided under this Agreement by the Repairer will not involve the transfer of
know-how to the Company by no means whatsoever. The Services shall be performed without the presence
of any Company's technician and no technical report shall be delivered by the Repairer in connection
therewith (except if expressly required by the Company, as foreseen on Clause 23.3.5).

24. GOVERNING LAW AND ARBITRATION

24.1 Governing law: Pursuant to and in accordance with Section 5-1401 of the New York General
Obligations Law, the Parties hereto agree that this Agreement in all respects, and any claim or
cause of action based upon or arising out of this Agreement, or any dealing between the Parties
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 37/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 38 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED relating to the subject matter of this Agreement
or the transactions contemplated hereby or the Company/Repairer relationship being established,
shall be governed by, and construed in accordance with, the laws of the State of New York, U.S.A. as
applied to contracts to be performed wholly within the State of New York (Exclusive of Section 7-101
of the New York General Obligations Law which is inapplicable to this Agreement). 24.2 Arbitration:
in the event of a dispute arising out of or relating to this Agreement, including without limitation
disputes regarding the existence, validity or termination of this Agreement (a "Dispute"), either
Party may notify such Dispute to the other through service of a written notice (the "Notice of
Dispute"). The Parties shall make their reasonable endeavours to settle the Dispute amicably by a
committee composed of one (1) management representative of each Party (the "Representatives"). Such
committee shall be created by the Parties within [*****] from the date of receipt of the Notice of
Dispute.

24.2.1 Subject to sub-Clause 24.2.5 below and in the event the Representatives (i) fail to create
such committee or (ii) do not agree on an amicable settlement within [*****] from the date the
committee referred to in this sub-Clause 24.2 has been created or such longer period as may be
agreed upon in writing by the Representatives (the "Amicable Settlement Period"), the Dispute shall
be exclusively and finally settled under the Rules and Conciliation of Arbitration of the
International Chamber of Commerce (the "ICC") by an arbitral tribunal composed of three (3)
arbitrators; each Party shall then appoint one (1) arbitrator within [*****] from the last day of
the Amicable Settlement Period and the third arbitrator, who will act as President, will be
appointed by the other two (2) arbitrators. In case the two (2) arbitrators appointed by the Parties
do not agree on this choice with [*****] from the date the last arbitrator is appointed, the third
arbitrator will be appointed by the ICC Court.

24.2.2 The arbitration, and any proceedings, and meetings incidental to or related to the
arbitration process, shall take place in New York, U.S.A, and the language to be used in the
arbitral proceedings shall be English; arbitral award shall be final and binding upon the Parties.

24.2.3 The arbitration shall be kept confidential and the existence of the proceeding and any
element of it shall not be disclosed to any third party. Any information relating to and/or
documents generated for the purpose of or produced in the arbitration, including any awards, shall
remain confidential between the Parties, the arbitrators and any other Person involved in the
arbitration proceedings, except to the extent that disclosure may be required pursuant to any order
of court or other competent authority or tribunal, or to protect or pursue a legal rights or to
enforce or challenge an award in bona fide legal proceedings before a state court or other judicial
authority. 24.2.4 During any period of negotiation or arbitration, the Parties shall continue to
meet their respective obligations in accordance with theprovisions of the Agreement. 24.2.5
Notwithstanding any provision of this Clause 24.2 the Parties may, at any time, seek and decide to
settle a Dispute either throughdirect negotiations or in accordance with the ICC rules in respect of
the alternative dispute resolution. 24.3 Judgment upon any award may be entered in any court having
jurisdiction or application may be made to the court for a judicial recognition of the award or an
order of enforcement, as the case may be. 24.4 Recourse to jurisdictions is expressly excluded
except as provided for in the ICC Rules of Conciliation and Arbitration concerning Conservatory and
Interim measures. [*****] Confidential material redacted and filed separately with the Securities
and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page
38/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 39 -->
Execution version AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 39/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 40 -->
Execution version EXECUTION PAGE

This Agreement has been executed in two (2) original copies in the English language on the Signing
Date. On behalf of: On behalf of: AZUL LINHAS AÉREAS BRASILEIRAS AVIONS DE TRANSPORT REGIONAL
(Company) (Repairer) Signed by: /s/ Amir Nasruddin Signed by: /s/ Massimo Castorina Function:
Attorney in fact Function: Vice-President Commercial Product Support & Services AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 40/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 1 - LIST OF ATR AIRCRAFT COVERED UNDER
THIS AGREEMENT
<!-- page 41 -->
[*****] [*****] Confidential material redacted and filed separately with the Securities and Exchange
Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 41/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED [*****]
<!-- page 42 -->
This list may be amended from time to time by way of Notice sent to the Company by Repairer in order
to cover any further ATR aircraft entering the Company's fleet, including the airframe, engines,
propellers and landing gears and parts installed on the Aircraft, when solely operated by the
Company.

ALL ITEMS, PARTS, COMPONENTS, SERVICES, WARRANTIES AND GUARANTEES PROVIDED HEREUNDER ARE PROVIDED
SUBJECT TO CLAUSE 14 OF THE AGREEMENT. [*****] Confidential material redacted and filed separately
with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 42/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 2 - LIST OF SERVICES PROVIDED UNDER THIS
AGREEMENT
<!-- page 43 -->
The Repairer shall provide the Company with the following Services:

[*****]

ALL ITEMS, PARTS, COMPONENTS, SERVICES, WARRANTIES AND GUARANTEES PROVIDED HEREUNDER ARE PROVIDED
SUBJECT TO CLAUSE 14 OF THE AGREEMENT. [*****] Confidential material redacted and filed separately
with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 43/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 3 - MAIN ELEMENTS COVERED UNDER THE
AGREEMENT

[*****]
<!-- page 44 -->
Part number of each assembly and subcomponent to be provided by the Company.

ALL ITEMS, PARTS, COMPONENTS, SERVICES, WARRANTIES AND GUARANTEES PROVIDED HEREUNDER ARE PROVIDED
SUBJECT TO CLAUSE 14 OF THE AGREEMENT. [*****] Confidential material redacted and filed separately
with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 44/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 4 - LIST OF LANDING GEAR ON CONDITION
PARTS

[*****]
<!-- page 45 -->
ALL ITEMS, PARTS, COMPONENTS, SERVICES, WARRANTIES AND GUARANTEES PROVIDED HEREUNDER ARE PROVIDED
SUBJECT TO CLAUSE 14 OF THE AGREEMENT. [*****] Confidential material redacted and filed separately
with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 45/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 46 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 5 - STOCK

The following Exhibit is composed of sixteen (16) pages, into which are listed [*****] part numbers.
[*****] DESCRIPTION [*****] [*****] EXCHANGER-HEAT,DUAL [*****] [*****] CONDENSER [*****] [*****]
COOLING UNIT [*****] [*****] VALVE-TURBINE INLET CONTROL [*****] [*****] FLIGHT DATA ACQUISITION
UNIT [*****] [*****] FLIGHT GUIDANCE CONTROL PANEL [*****] [*****] AUTO PILOT SERVO-ACTUATOR [*****]
[*****] AUTO PILOT CAPSTAN [*****] [*****] CVR-SOLID STATE [*****] [*****] CONTROL UNIT-CVR [*****]
[*****] AUDIO CONTROL PANEL [*****] [*****] AMPLIFIER-PASSENGER ADDRESS [*****] [*****] STARTER
GENERATOR-DC [*****] [*****] CONTROL UNIT-GENERATOR,AC [*****] [*****] CONTROL UNIT-BUS POWER,AC
[*****] [*****] CONTACTOR-ACW [*****] [*****] ATTENDANT PANEL [*****] [*****] ATTENDANT PANEL
[*****] [*****] ATTENDANT PANEL USB KEY [*****] [*****] HANDLE-ENG1 FIRE [*****] [*****]
ROD-DYNAMOMETRIC,ROLL [*****] [*****] SWITCH UNIT-FLAP CONTROL [*****] [*****] ACTUATOR-ELEVATOR
[*****] [*****] ACTUATOR-TRIM [*****] [*****] VALVE BLOCK-FLAP [*****] [*****] RESTRICTOR-FLAP VLV
BLOCK FLOW, EXTN LINE [*****] [*****] ACTUATOR-STICK PUSHER [*****] [*****] VALVE BLOCK-SPOILER
[*****] [*****] SHAKER-STICK [*****] [*****] ACTUATOR-SPOILER [*****] [*****] CABLE-TENSION
REGULATOR [*****] [*****] COUPLING-REFUEL/DEFUEL [*****] [*****] CONTROLLER-HORN ANTI ICING [*****]
[*****] RESISTOR-HORN ANTI ICING,LH ELEVATOR [*****] [*****] RESISTOR-HORN ANTI-ICING,RH ELEVATOR
[*****] [*****] RESISTOR-HORN ANTI-ICING,RUDDER [*****] [*****] RESISTOR-HORN ANTI ICING,LH AILERON
[*****] [*****] Confidential material redacted and filed separately with the Securities and Exchange
Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 46/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 47 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****] RESISTOR-HORN
ANTI ICING,RH AILERON [*****] [*****] VALVE-DE ICING DUAL DISTRIBUTOR [*****] [*****] PROBE-CCAS
ALPHA [*****] [*****] ACCELEROMETER-THREE AXIS [*****] [*****] TRANSMITTER-POSITION SYNCHRO [*****]
[*****] RESERVOIR-BRAKE [*****] [*****] CYLINDER-MASTER [*****] [*****] VALVE-SELECTOR,LG [*****]
[*****] ACCUMULATOR-PARKING [*****] [*****] ABSORBER-SHOCK [*****] [*****] VALVE-PARKING [*****]
[*****] VALVE-BRAKE [*****] [*****] VALVE-RELIEF,LOW PRESSURE [*****] [*****] VALVE-BRAKE [*****]
[*****] VALVE-DIFFERENTIAL CONTROL [*****] [*****] SELECTOR [*****] BOX-UPLOCK [*****] [*****] FLUX
VALVE [*****] [*****] VALVE-FEED STOP [*****] [*****] PUMP-PROPELLER FEATHERING [*****] [*****]
PUSH-PULL CABLE-PROP CONDITION [*****] [*****] PUMP GOVERNOR-PROPELLER [*****] OVERSPEED [*****]
[*****] EXCITER—IGNITION I.C. [*****] [*****] EJECTOR, FUEL WASTE [*****] [*****] SERVO VALVE
[*****] [*****] FUEL PUMP [*****] [*****] PUSH-PULL CABLE-PROPELLER POWER [*****] [*****]
ACTUATOR-OIL COOLER FLAP [*****] [*****] COOLER-OIL [*****] [*****] REFERENCE UNIT-ATTITUDE AND
HEADING [*****] [*****] GROUND COOLING FAN [*****] [*****] SMOKE DETECTOR [*****] [*****] TOTAL
[*****] [*****] [*****] Confidential material redacted and filed separately with the Securities and
Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 47/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 48 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****]
CONTROLLER-DIGITAL [*****] [*****] COOLING UNIT [*****] [*****] FAN-AIR EXTRACTION [*****] [*****]
VALVE-ELECTROPNEUMATIC OUTFLOW [*****] [*****] VALVE-PACK FLOW CONTROL [*****] [*****]
VALVE-PNEUMATIC OUTFLOW [*****] [*****] VALVE-SHUTOFF TURBOFAN [*****] [*****] VALVE-TRIM AIR
[*****] [*****] VALVE-TURBINE INLET CONTROL [*****] [*****] COUPLER HF ANTENNA [*****] [*****]
ECU-3000 [*****] [*****] HANDSET-CABIN ATTENDANT [*****] [*****] MANAGEMENT UNIT-ACARS [*****]
[*****] TRANSCEIVER-HF [*****] [*****] VHF/COMM TRANSCEIVER [*****] [*****] VHF-4000-8,33 KHZ
[*****] [*****] CONTROL UNIT-BUS POWER,DC [*****] [*****] CONTROL UNIT-GENERATOR,DC [*****] [*****]
GENERATOR-AC [*****] [*****] SENSOR-HALL EFFECT [*****] [*****] STATIC INVERTER [*****] [*****]
TRANSFORMER RECTIFIER UNIT [*****] [*****] TRANSMITTER-EMERGENCY LOCATOR [*****] [*****] DETECTOR
UNIT [*****] [*****] HANDLE-ENG2 FIRE [*****] [*****] ACTUATOR-FLAP [*****] [*****] DAMPER-RUDDER
[*****] [*****] REFUEL CONTROL PANEL [*****] [*****] INDICATOR LEVEL SWITCH [*****] [*****]
PUMP-ELECTRIC,AC [*****] [*****] DETECTOR-ICE [*****] [*****] VALVE-ANTI ICING PRESS REG AND [*****]
SHUTOFF [*****] [*****] VALVE-ANTI ICING SHUTOFF [*****] [*****] VALVE-DE ICING DUAL DISTRIBUTOR
[*****] [*****] CLOCK [*****] [*****] DIGITAL FLIGHT DATA RECORDER [*****] [*****] EFIS CONTROL
PANEL LH SIDE [*****] [*****] EFIS CONTROL PANEL RH SIDE [*****] [*****] INDEX CONTROL PANEL [*****]
[*****] INTEGRATED AVIONICS DISPLAY [*****] [*****] Confidential material redacted and filed
separately with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 48/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 49 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****] MPC-ED36
[*****] [*****] MULTIFUNCTION COMPUTER [*****] [*****] MULTI-FUNCTION CONTROL PANEL [*****] [*****]
MULTIPURPOSE CONTROL & DISPLAY UNIT [*****] [*****] SENSOR-WHEEL SPEED [*****] [*****]
VALVE-DIFFERENTIAL CONTROL SELECTOR [*****] [*****] VALVE-SELECTOR,SWIVEL [*****] [*****] EMERGENCY
LIGHTING POWER SUPPLY MODULE [*****] [*****] LIGHT-ANTICOLLISION,WHITE [*****] [*****] LIGHT-ANTI
COLLISION,RED [*****] [*****] LIGHT-LANDING [*****] [*****] LIGHT-STROBE [*****] [*****] POWER
SUPPLY-UNIT ANTI COLLISION LIGHT [*****] [*****] POWER SUPPLY-UNIT ANTI COLLISION LIGHT [*****]
[*****] AIR DATA COMPUTER [*****] [*****] ATC TRANSPONDER [*****] [*****] ATTITUDE HEADING REF UNIT
[*****] [*****] FLUX VALVE [*****] [*****] INTEGRATED ELEC STAND-BY EQUIP [*****] [*****]
INTERROGATOR-DME [*****] [*****] NAVIGATOR PROCESSOR UNIT (GPS RECEIVER) [*****] [*****] PROBE-AIR
TEMPERATURE [*****] [*****] PROBE-PITOT [*****] [*****] RADIO-ALTIMETER TRANSCEIVER [*****] [*****]
RECEIVER-VOR/ILS/MKR [*****] [*****] T2CAS COMPUTER [*****] [*****] TRANSCEIVER-WEATHER RADAR
[*****] [*****] VOR/ILS/MKR RECEIVER [*****] [*****] WX RADAR CONTROL PANEL [*****] [*****]
TRANSMITTER/REGULATOR—OXYGEN PRESS [*****] [*****] DUCT-DISCHARGE DOWNSTREAM VALVE [*****] [*****]
VALVE ASSY-SHUTOFF [*****] [*****] VALVE-XFEED,AIR BLEED [*****] [*****] CAC SWM [*****] [*****]
CORE AVIONICS CABINET I/P O/P MODULE AP [*****] [*****] CORE AVIONICS CABINET I/P O/P MODULE-S
[*****] [*****] CORE AVIONICS CABINET I/P O/P MODULE- DC [*****] [*****] INTEGRATED CORE PROCESSING
[*****] MODULE [*****] [*****] Confidential material redacted and filed separately with the
Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue
7 Page 49/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 50 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****] PROPELLER
BLADES [*****] [*****] PROPELLER ASSEMBLY [*****] [*****] BRUSH BLOCK ASSY [*****] [*****] CONTROL
ELECTRONIC-PROPELLER [*****] [*****] GOVERNOR-PROPELLER OVERSPEED [*****] [*****] MODULE VALVE
PROPELLER [*****] [*****] SWITCH-PRESSURE,HYDRAULIC [*****] [*****] PIPE-EXHAUST [*****] [*****]
TRANSMITTER-FUEL FLOW [*****] [*****] ENGINE ELECTRONIC CONTROL [*****] [*****] SENSOR TORQUE METER
[*****] [*****] VALVE ASSY,INTERCOMPRESS BLEED [*****] [*****] VALVE INTERCOMPRESSOR BLEED [*****]
MFC [*****] [*****] CONTROL,AUTOFEATHER [*****] [*****] COOLER - OIL [*****] [*****] FLOW DIVIDER &
DUMP VALVE [*****] [*****] FUEL HEATER [*****] [*****] TOTAL [*****] [*****] [*****] DESCRIPTION
[*****] [*****] COOLING UNIT [*****] [*****] EXCHANGER-HEAT,DUAL [*****] [*****] VALVE-PACK FLOW
CONTROL [*****] [*****] VALVE-PNEUMATIC OUTFLOW [*****] [*****] VALVE-TRIM AIR [*****] [*****]
VALVE-TURBINE INLET CONTROL [*****] [*****] AMPLIFIER-PASSENGER ADDRESS [*****] [*****] AUDIO
CONTROL PANEL [*****] [*****] COUPLER HF ANTENNA [*****] [*****] CVR-SOLID STATE [*****] [*****]
REMOTE CONTROL AUDIO UNIT [*****] [*****] Confidential material redacted and filed separately with
the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 50/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 51 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****]
TRANSCEIVER-HF [*****] [*****] CONTROL UNIT-BUS POWER,AC [*****] [*****] CONTROL UNIT-BUS POWER,DC
[*****] [*****] CONTROL UNIT-GENERATOR,AC [*****] [*****] CONTROL UNIT-GENERATOR,DC [*****] [*****]
GENERATOR-AC [*****] [*****] INVERTER-STATIC [*****] [*****] SENSOR-HALL EFFECT [*****] [*****]
STARTER GENERATOR-DC [*****] [*****] TRANSMITTER-EMERGENCY LOCATOR [*****] [*****] DETECTOR-SMOKE
[*****] [*****] ACTUATOR-TRIM [*****] [*****] VALVE BLOCK-FLAP [*****] [*****] VALVE BLOCK-SPOILER
[*****] [*****] PUMP-FUEL ELECTRIC [*****] [*****] PUMP-ELECTRIC,AUXILIARY,DC [*****] [*****]
DETECTOR-ICE [*****] [*****] VALVE-DE ICING DUAL DISTRIBUTOR [*****] [*****] MULTIFUNCTION COMPUTER
[*****] [*****] PROBE-CCAS ALPHA [*****] [*****] BOX-UPLOCK [*****] [*****] CONTROL UNIT-ANTISKID
SYSTEM [*****] [*****] SENSOR-WHEEL SPEED [*****] [*****] VALVE-SELECTOR,SWIVEL [*****] [*****]
EMERGENCY LIGHTING POWER SUPPLY MODULE [*****] [*****] LIGHT-ANTICOLLISION,WHITE [*****] [*****]
LIGHT-LANDING [*****] [*****] LIGHT-STROBE [*****] [*****] POWER SUPPLY UNIT-STROBE LIGHT [*****]
[*****] PROBE-PITOT [*****] [*****] TRANSMITTER/REGULATOR - OXYGEN PRESS [*****] [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 51/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 52 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****]
DUCT-DISCHARGE DOWNSTREAM VALVE [*****] [*****] VALVE ASSY-SHUTOFF [*****] [*****] VALVE-HP AIR
BLEED [*****] [*****] VALVE-HP AIR BLEED [*****] [*****] VALVE-XFEED,AIR BLEED [*****] [*****]
PUMP-PROPELLER FEATHERING [*****] [*****] SWITCH-PRESSURE,HYDRAULIC [*****] [*****] PIPE-EXHAUST
[*****] [*****] TRANSMITTER-FUEL FLOW [*****] [*****] PUSH-PULL CABLE-PROPELLER POWER [*****]
[*****] ACTUATOR-OIL COOLER FLAP [*****] [*****] COOLER-OIL [*****] [*****] BRAKE, PROPELLER [*****]
[*****] EXCITER—IGNITION I.C. [*****] [*****] EJECTOR, FUEL WASTE [*****] [*****] COOLER - OIL
[*****] [*****] SERVO VALVE [*****] [*****] VALVE INTERCOMPRESSOR BLEED [*****] [*****] FUEL HEATER
[*****] [*****] FUEL PUMP [*****] [*****] TOTAL [*****] [*****] [*****] DESCRIPTION [*****] [*****]
PROPELLER ASSY [*****] [*****] PROPELLER ASSY [*****] [*****] MULTIFONCTION COMPUTER [*****] [*****]
PROPELLER ASSY [*****] [*****] MFC [*****] [*****] MFC [*****] [*****] Confidential material
redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 52/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 53 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****] BRAKE,
PROPELLER [*****] [*****] BRAKE, PROPELLER [*****] [*****] AIR DATA COMPUTER [*****] [*****] STARTER
GENERATOR-DC [*****] [*****] BLADE PROPELLER [*****] [*****] TRANSCEIVER-TCAS [*****] [*****] BRAKE,
PROPELLER [*****] [*****] BRAKE, PROPELLER [*****] [*****] MODULE VALVE PROPELLER [*****] [*****]
MODULE VALVE PROPELLER [*****] [*****] ACTUATOR-NOSE [*****] [*****] FCU-HYDRO MECHANICAL [*****]
[*****] ELECTRONIC ENGINE CONTROL UNIT [*****] [*****] COMPUTER-AFCS [*****] [*****] REMOTE CONTROL
AUDIO UNIT [*****] [*****] REMOTE CONTROL AUDIO UNIT [*****] [*****] TRANSCEIVER-RADIO ALTIMETER
[*****] [*****] GROUND PROXIMITY WARNING [*****] COMPUTER [*****] [*****] VALVE-HP AIR BLEED [*****]
[*****] INDICATOR-VERTICAL SPEED [*****] [*****] GENERATOR-AC [*****] [*****] COOLER-OIL [*****]
[*****] REMOTE CONTROL AUDIO UNIT [*****] [*****] VALVE-DIFFERENTIAL CONTROL [*****] SELECTOR
[*****] [*****] VALVE INTERCOMPRESSOR BLEED [*****] [*****] FLIGHT DATA ACQUISITION UNIT [*****]
[*****] FLIGHT DATA ACQUISITION UNIT [*****] [*****] FLIGHT DATA ACQUISITION UNIT [*****] [*****]
ACTUATOR-MAIN [*****] [*****] ACTUATOR-MAIN RH [*****] [*****] ADVISORY DISPLAY UNIT-AFCS [*****]
[*****] VALVE ASSY-P2.5,P3 AIR PRESS.VALVE [*****] [*****] CONDENSER [*****] [*****] TRANSFORMER
RECTIFIER UNIT [*****] [*****] CONTROL,AUTOFEATHER [*****] [*****] VALVE BLOCK-FLAP [*****] [*****]
VALVE BLOCK-FLAP [*****] [*****] FUEL HEATER [*****] [*****] ACTUATOR-MAIN [*****] [*****]
PROBE-CCAS ALPHA [*****] [*****] Confidential material redacted and filed separately with the
Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue
7 Page 53/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 54 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****] PROBE-CCAS
ALPHA [*****] [*****] COUPLER-HF ANTENNA [*****] [*****] GOVERNOR-PROPELLER OVSP [*****] [*****]
DUCT-DISCHARGE DOWNSTREAM VALVE [*****] [*****] CONTROLLER-DIGITAL [*****] [*****]
RECEIVER-VOR/ILS/MKR [*****] [*****] FUEL PUMP [*****] [*****] VALVE-ELECTROPNEUMATIC OUTFLOW
[*****] [*****] MOUNT ANTENNA-WEATHER RADAR [*****] [*****] PUMP, HYDRAULIC, OVSP GOV [*****]
[*****] CONTROL ELECTRONIC-PROPELLER [*****] [*****] BOBBIN [*****] [*****] DATA COLLECTION UNIT
[*****] [*****] PUMP-ELECTRIC,AC [*****] [*****] TRANSCEIVER-HF [*****] [*****] RESISTOR-HORN ANTI
ICING,LH [*****] ELEVATOR [*****] [*****] RESISTOR-HORN ANTI-ICING,RH [*****] ELEVATOR [*****]
[*****] ACTUATOR-CARGO DOOR [*****] [*****] INTERROGATOR-DME [*****] [*****] INDICATOR-CAB PRESS
[*****] [*****] VALVE-ANTI ICING PRESS REGULATOR AND SHUTOFF [*****] [*****] VALVE-SELECTOR,SWIVEL
[*****] [*****] SOLID STATE FLIGHT DATA RECORDER [*****] [*****] ANTENNA-TCAS [*****] [*****]
CONTROL PANEL-AFCS [*****] [*****] PUMP-ELECTRIC,AUXILIARY,DC [*****] [*****] TRANSCEIVER-VHF
[*****] [*****] ASSISTER-FREE FALL,MLG [*****] [*****] CONTROLLER-INSTRUMENT REMOTE [*****] [*****]
COUPLER HF ANTENNA [*****] [*****] SEAT-DISABLED PASSENGER,RH [*****] [*****] SEAT-DISABLED
PASSENGER,LH [*****] [*****] CONTROLLER-INSTRUMENT REMOTE [*****] [*****] DAMPER-RUDDER [*****]
[*****] BAR ASSY-TORQUE [*****] [*****] HANDLE-ENG1 FIRE [*****] [*****] HANDLE-ENG2 FIRE [*****]
[*****] INDICATOR-TAS/TEMP [*****] [*****] CONTROL PANEL-EFIS [*****] [*****] PROBE-AIR TEMPERATURE
[*****] [*****] Confidential material redacted and filed separately with the Securities and Exchange
Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 54/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 55 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****] SENSOR-HALL
EFFECT [*****] [*****] HANDSET-CABIN ATTENDANT [*****] [*****] JOINT [*****] [*****] INDICATOR-FUEL
FLOW/FUEL USED,KG [*****] [*****] CLOCK [*****] [*****] VALVE-SELECTOR,LG [*****] [*****]
HOCKMOUNT-AFT LATERAL,RH [*****] [*****] EXCITER-IGNITION I.C. [*****] [*****] SENSOR TORQUE METER
[*****] [*****] SENSOR TORQUE METER [*****] [*****] INDICATOR-FUEL QUANTITY,KG [*****] [*****]
INDICATOR-FUEL QUANTITY,KG [*****] [*****] VALVE-DE ICING DUAL DISTRIBUTOR [*****] [*****] MASK
ASSY-REGULATOR,OXYGEN [*****] [*****] CONTROL BOX-WEATHER RADAR [*****] [*****] DETECTOR UNIT
[*****] [*****] TRANSCEIVER-VHF [*****] [*****] VALVE-DE ICING DUAL DISTRIBUTOR [*****] [*****]
BATTERY-MAIN [*****] [*****] ACCELEROMETER-THREE AXIS [*****] [*****] PUMP-PROPELLER FEATHERING
[*****] [*****] MOTOR-WIPER,F/O [*****] [*****] MOTOR-WIPER,CAPTAIN [*****] [*****]
INDICATOR-PRESSURE,TRIPLE [*****] [*****] ACTUATOR-UNLOCKING,MLG [*****] [*****] PANEL-ATTENDANT
[*****] [*****] SENSOR, TORQUE MONITOR [*****] [*****] INDICATOR-ITT [*****] [*****] CONTROL
UNIT-TCAS [*****] [*****] SWITCH-PROXIMITY [*****] [*****] SERVO VALVE [*****] [*****]
SWITCH-PROXIMITY [*****] [*****] VALVE-REFUEL/DEFUEL [*****] [*****] SWITCH-OVERTEMPERATURE [*****]
[*****] CYLINDER-MASTER [*****] [*****] INDICATOR-AIRSPEED,STANDBY [*****] [*****] COMPENSATOR-COLD
JUNCTION [*****] [*****] COMPENSATOR-COLD JUNCTION [*****] [*****] TRANSMITTER-FUEL FLOW [*****]
[*****] COMPENSATOR-COLD JUNCTION [*****] [*****] Confidential material redacted and filed
separately with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 55/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 56 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****] TANK-FUEL
DRAIN AND EJECTOR PUMP [*****] [*****] EJECTOR, FUEL WASTE [*****] [*****] SENSOR-WHEEL SPEED
[*****] [*****] CONTROL UNIT-DUAL ATC [*****] [*****] LEVER-CONTROL,L/G [*****] [*****] CONTROL
UNIT-OVEN [*****] [*****] INDICATOR-ITT [*****] [*****] CLOCK [*****] [*****] CLOCK [*****] [*****]
CONTROL UNIT-VHF [*****] [*****] VALVE-FLUX [*****] [*****] LIGHT-STROBE [*****] [*****] CONTROL
UNIT-VOR/ILS/DME [*****] [*****] CONTROL UNIT-ADF [*****] [*****] SWITCH-PRESSURE [*****] [*****]
MASK ASSY-REGULATOR,OXYGEN [*****] [*****] FLOW DIVIDER & DUMP VALVE [*****] [*****]
TRANSMITTER-EMERGENCY LOCATOR [*****] [*****] INDICATOR-OIL TEMP/PRESS [*****] [*****] VALVE-TWO WAY
AND WATER DRAIN [*****] [*****] SWITCH-PROXIMITY [*****] [*****] CONTACTOR-ACW [*****] [*****]
SWITCH-PROXIMITY [*****] [*****] ACTUATOR-OIL COOLER FLAP [*****] [*****] LIGHT-LANDING [*****]
[*****] EMERGENCY LIGHTING POWER SUPPLY MODULE [*****] [*****] SWITCH-OVERTEMPERATURE [*****]
[*****] SWITCH-PRESSURE,HYDRAULIC [*****] [*****] VALVE-CHECK [*****] [*****] PROBE-PITOT [*****]
[*****] INDICATOR-FUEL TEMPERATURE [*****] [*****] ANTENNA-RADIO-ALTIMETER RECEPTION [*****] [*****]
CONTROL UNIT-ATC [*****] [*****] CONTROL UNIT-VHF [*****] [*****] STATIC INVERTER [*****] [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 56/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 57 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****]
EXCHANGER-HEAT,DUAL [*****] [*****] TRANSCEIVER-TCAS [*****] [*****] PLAYER-CASSETTE [*****] [*****]
CONTROLLER-WINDSHIELD TEMPERATURE [*****] [*****] FAN-GROUND COOLING [*****] [*****]
FAN-RECIRCULATION [*****] [*****] TOTAL [*****] [*****] [*****] DESCRIPTION [*****] [*****] AUTO
PILOT CAPSTAN [*****] [*****] AUTO PILOT SERVO-ACTUATOR [*****] [*****] FLIGHT GUIDANCE CONTROL
PANEL [*****] [*****] VHF/COMM TRANSCEIVER [*****] [*****] POWER TRIM BOX [*****] [*****] CLOCK
[*****] [*****] DIGITAL FLIGHT DATA RECORDER [*****] [*****] EFIS CONTROL PANEL LH SIDE [*****]
[*****] EFIS CONTROL PANEL RH SIDE [*****] [*****] INDEX CONTROL PANEL [*****] [*****] INTEGRATED
AVIONICS DISPLAY [*****] [*****] MPC-ED36 [*****] [*****] MULTI-FUNCTION CONTROL PANEL [*****]
[*****] MULTIPURPOSE CONTROL & DISPLAY UNIT [*****] [*****] AIR DATA COMPUTER [*****] [*****] ATC
TRANSPONDER [*****] [*****] ATTITUDE HEADING REF UNIT [*****] [*****] FLUX VALVE [*****] [*****]
INTEGRATED ELEC.STAND-BY EQUIP [*****] [*****] INTERROGATOR-DME [*****] [*****] NAVIGATOR PROCESSOR
UNIT (GPS RECEIVER) [*****] [*****] RADIO-ALTIMETER TRANSCEIVER [*****] [*****] RECEIVER-VOR/ILS/MKR
[*****] [*****] T2CAS COMPUTER [*****] [*****] WX RADAR CONTROL PANEL [*****] [*****] CAC SWM
[*****] [*****] CORE AVIONICS CABINET INPUT OUPUT MODULE AUTO PILOT [*****] [*****] Confidential
material redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 57/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 58 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****] CORE AVIONICS
CABINET INPUT OUPUT MODULE-DC [*****] [*****] CORE AVIONICS CABINET INPUT OUTPUT MODULE-S [*****]
[*****] INTEGRATED CORE PROCESSING MODULE [*****] [*****] PRINTER [*****] [*****] ICP 110VM [*****]
[*****] ICP 111VM [*****] [*****] ICP 111VM [*****] [*****] ICP 112VM [*****] [*****] ICP 114VM
[*****] [*****] ICP 131VM [*****] [*****] ICP 131VM [*****] [*****] ICP 132VM [*****] [*****] ICP
400VM [*****] [*****] ICP 401VM [*****] [*****] ICP 402VM [*****] [*****] ICP 404VM [*****] [*****]
ICP 6VM [*****] [*****] ICP 811VM [*****] [*****] CENTRAL MAIN INSTRUMENT [*****] [*****] PANEL
LIGHT [*****] [*****] LIGHT MANAGEMENT UNIT [*****] [*****] TCAS DIRECTIONAL ANTENNA [*****] [*****]
TOTAL [*****] [*****] [*****] DESCRIPTION [*****] [*****] T2CAS Computer [*****] [*****] T2CAS
Computer [*****] [*****] TOTAL [*****] [*****] [*****] DESCRIPTION [*****] [*****] PROBE-PITOT
[*****] [*****] EJECTION DUCT [*****] [*****] BUS POWER CONTROL UNIT [*****] [*****]
BATTERY-EMERGENCY [*****] [*****] AFTER ROLLER BLIND [*****] [*****] Confidential material redacted
and filed separately with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master
Agreement DS/CS-3957/14/Issue 7 Page 58/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 59 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****] OXYGEN
CYLINDER ASSY [*****] [*****] DIGITAL FLT DATA RECORDER [*****] [*****] ATTITUDE HEADING REF UNIT
[*****] [*****] PCMCIA [*****] [*****] POWER SUPPLY UNIT [*****] [*****] FUSELAGE GROUND LIGHT
[*****] [*****] EMERGENCY POWER SUPPLY [*****] [*****] INTERCOMPRESSOR BLEED VALVE [*****] [*****]
BATTERY-MAIN [*****] [*****] MOTOR AND PUMP ASSEMBLY [*****] [*****] FIRE EXTINGUISHER [*****]
[*****] TRIM INDICATOR [*****] [*****] AISLE MARKING EMERGENCY [*****] [*****] INTERTURBINE
TEMP.INDICATOR [*****] [*****] INTERTURBINE TEMP.INDICATOR [*****] [*****] PROPELLER SPEED INDICATOR
[*****] [*****] VHF/COMM TRANSCEIVER [*****] [*****] STANDBY ALTIMETER [*****] [*****] AIR DATA
COMPUTER [*****] [*****] AIRSPEED INDICATOR [*****] [*****] REFUEL CONTROL PANEL [*****] [*****]
ELECTRONIC ENGINE [*****] CONTROL [*****] [*****] VHF/COMM CONTROL PANEL [*****] [*****] T2CAS
COMPUTER [*****] [*****] FWD SIDE LH ISOLATOR [*****] [*****] EFIS CONTROL PANEL RH [*****] [*****]
EFIS CONTROL PANEL LH [*****] [*****] INDEX CONTROL PANEL [*****] [*****] INTEGRATED CORE PROCESSING
MOD [*****] [*****] PROPELLER VALVE MODULE [*****] [*****] REMOTE CONTROL AUDIO UNIT [*****] [*****]
REMOTE CONTROL AUDIO UNIT [*****] [*****] LP CHECK VALVE [*****] [*****] MPC [*****] [*****]
EMERGENCY LOCATOR BEACON [*****] [*****] EMERGENCY POWER SUPPLY [*****] [*****] PRESSURE REG & S/O
VALVE [*****] [*****] PRESSURE REG & S/O VALVE [*****] [*****] HALL EFFECT CURRENT [*****] [*****]
TOTAL [*****] [*****] [*****] Confidential material redacted and filed separately with the
Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue
7 Page 59/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 60 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****] TRIM ACTUATOR
[*****] [*****] T.I.C. VALVE [*****] [*****] AIR CYCLE UNIT [*****] [*****] LP CHECK VALVE [*****]
[*****] DUAL DISTRIBUTOR VALVE [*****] [*****] HALL EFFECT CURRENT [*****] [*****] DESCRIPTION
[*****] [*****] AUTO PILOT SERVO-ACTUATOR [*****] [*****] EXCHANGER [*****] [*****] CHECK VALVE
[*****] [*****] PRESSURE REG AND S/O VALVE [*****] [*****] PRESSURE REG AND S/O VALVE [*****]
[*****] INTEGRATED CORE PROCESSING MOD [*****] [*****] TOTAL [*****] [*****] [*****] DESCRIPTION
[*****] [*****] VALVE BLOCK-FLAP [*****] [*****] DUCT-DISCHARGE DOWNSTREAM VALVE [*****] [*****]
DUCT-DISCHARGE DOWNSTREAM VALVE [*****] [*****] VALVE-SELECTOR,SWIVEL [*****] [*****]
VALVE-SELECTOR,SWIVEL [*****] [*****] JOINT [*****] [*****] LIGHT-LANDING [*****] [*****] ICP 112VM
[*****] [*****] ICP 114VM [*****] [*****] TCAS DIRECTIONAL ANTENNA [*****] [*****] TCAS DIRECTIONAL
ANTENNA [*****] [*****] SERVO VALVE [*****] [*****] TOTAL [*****] [*****] [*****] Confidential
material redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 60/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****] PROBE-PITOT
[*****]
<!-- page 61 -->
ALL ITEMS, PARTS, COMPONENTS, SERVICES, WARRANTIES AND GUARANTEES PROVIDED HEREUNDER ARE PROVIDED
SUBJECT TO CLAUSE 14 OF THE AGREEMENT. [*****] Confidential material redacted and filed separately
with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 61/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 6 - LRUs COVERED BY REPAIR AND STANDARD
EXCHANGE SERVICES
<!-- page 62 -->
The following Exhibit is composed of eight (8) pages, into which are listed [*****] part numbers. 1.
List A

The following list of LRUs contains [*****] part numbers. [*****] Description [*****] WATER
EXTRACTOR [*****] AIR CYCLE UNIT [*****] DIGITAL CONTROLLER [*****] CONDITIONED AIR CHECK VALVE
[*****] REGULATOR-PRESSURE [*****] PRESSURE REG AND S/O VALVE [*****] BUTTERFLY MODULATING VALVE
[*****] CHECK VALVE [*****] CHECK VALVE [*****] PRESSURIZATION INDICATOR [*****] DUAL TEMPERATURE
INDICATOR [*****] CONTROLLER-TEMP [*****] OVERTEMP. SWITCH [*****] VLV-U/FLOOR ISOL/VEN [*****]
CONDENSER [*****] CONTROLLER-MANUAL [*****] VLV-SHUTOFF TURBOFAN [*****] TEMPERATURE CONTROL VALVE
[*****] RECIRCULATION FAN ASSY [*****] GROUND COOLING FAN [*****] E/E COOLING FAN [*****] AMBIANT
PRESSURE UNIT [*****] UNDER FLOOR VALVE [*****] GND OUTFLOW VALVE [*****] ROD-DYNAMOMETRIC ELE
[*****] ROD-DYNAMOMTRC RUDDR [*****] FORCE DETECTOR ROD [*****] ROD-DYNAMOMETRIC ELE [*****]
AP.SERVO ACTUATOR [*****] ADVISORY DISPLAY [*****] AUTOPILOT COMPUTER [*****] AUTOPILOT COMPUTER
[*****] AP/FD CONTROL PANEL [*****] FLIGHT GUIDANCE CONTROL PANEL [*****] FLIGHT GUIDANCE CONTROL
PANEL [*****] FLIGHT GUIDANCE CONTROL PANEL [*****] Confidential material redacted and filed
separately with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 62/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 63 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] Description [*****] AUTO PILOT
SERVO-ACTUATOR [*****] CAPSTAN [*****] DIGITAL PLAYER [*****] MONITOR [*****] COCKPIT VOICE RECORDER
[*****] VHF/COMM TRANSCEIVER [*****] DUAL SYSTEM ADAPTER [*****] HF/COMM TRANSCEIVER [*****]
AUTOMATIC ANTENNA COUPLER [*****] HF/COMM CONTROL PANEL [*****] AUTOMATIC ANTENNA COUPLER [*****]
HF/COMM TRANSCEIVER [*****] VHF/COMM TRANSCEIVER [*****] VHF/COMM TRANSCEIVER [*****] VHF COMM
TRANSCEIVER [*****] VHF-4000-8,33 KHZ [*****] VHF 4000 [*****] MANAGEMNT UNIT-ACARS [*****] VHF/COMM
CONTROL PANEL [*****] VHF/COMM CONTROL PANEL [*****] ATTENDANT HANDSET [*****] ATTENDANT HANDSET
[*****] ATTENDANT HANDSET [*****] SELECTION PNL-SELCAL [*****] REMOTE CONTROL AUDIO UNIT [*****]
REMOTE CONTROL AUDIO UNIT [*****] REMOTE CONTROL AUDIO UNIT [*****] PASSENGER ADDRESS AMPLIFIER
[*****] SELCAL DECODER [*****] STATIC INVERTER [*****] TRANSFORMER RECTIFIER UNIT [*****] GENERATOR
CONTROL UNIT [*****] HALL EFFECT CURRENT [*****] CURRENT TRANSFORMER [*****] BATTERY
CH/DISCH.AMMETER [*****] GENERATOR CONTROL UNIT [*****] ELEC.POWER MESURING ASSY [*****] BUS POWER
CONTROL UNIT [*****] AC.CONTACTOR [*****] TRANSFORMER RECTIFIER UNIT [*****] DC CONTACTOR [*****]
EMERGENCY LOCATOR BEACON [*****] TOILET-PSU [*****] EMERGENCY LOCATOR BEACON [*****] Confidential
material redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 63/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 64 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] Description [*****] LF.FIRE-SHUT-OFF
CTL.PANEL [*****] RH.FIRE-SHUT-OFF CTL.PANEL [*****] FIRE DETECTION CONTROL UNIT [*****] FAN SMOKE
DETECTION [*****] SMOKE DETECTOR [*****] DETECTION BOX [*****] CONTROL BOX [*****] SMOKE DETECTOR
[*****] SMOKE DETECTOR [*****] POSITION TRANSMITTER [*****] RELEASABLE CENTRING UNIT [*****] CABLE
TENSION REGULATOR [*****] FLAPS POSITION INDICATOR [*****] FLAPS POSITION INDICATOR [*****] TRIM
INDICATOR [*****] TRIM INDICATOR [*****] SHAFT-FLEXIBLE [*****] FLAP CONTROL SWITCH UNIT [*****]
ELECTROMECHANICAL ACTUATOR [*****] STICK PUSHER [*****] FLAP VALVE BLOCK [*****] SPOILER VALVE BLOCK
[*****] ALPHA PROBE [*****] POWER TRIM BOX [*****] RUDDER DAMPER [*****] RESTRICTOR UNIT [*****]
RESTRICTOR UNIT [*****] RUDDER DAMPER [*****] FLAP ACTUATOR [*****] FLAP ACTUATOR [*****] STICK
SHAKER [*****] AILERON GUST-LOCK ACTUATOR [*****] SPOILER ACTUATOR [*****] FIRE SHUT-OFF VALVE
[*****] CROSSFEED VALVE [*****] MOTIVE FLOW VALVE [*****] ACTUATOR-FUEL LP VLV [*****] ACTUATOR-FUEL
CROSSF [*****] GRAVITY FILLER CAP [*****] FUEL TANK TEMP.INDICATOR [*****] FUEL CONTROL UNIT [*****]
REFUEL CONTROL PANEL [*****] FUEL QUANTITY REPEATER [*****] FUEL QUANTITY INDICATOR [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 64/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 65 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] Description [*****] FUEL QUANTITY
INDICATOR [*****] FUEL PROBE(N1) [*****] FUEL QUANTITY PRESELECTOR [*****] FUEL QUANTITY PRESELECTOR
[*****] CLINOMETER-ROLL ATT [*****] FUEL ELECTROPUMP [*****] FUEL ELECTROPUMP [*****] JET PUMP
[*****] ENGINE FEED JET PUMP [*****] FUEL PUMP CANISTER [*****] REFUEL/DEFUEL COUPLING [*****]
REFUELLING ASSEMBLY [*****] REFUELLING ASSEMBLY [*****] RESERVOIR [*****] LINE ACCUMULATOR [*****]
PRESSURE MODULE [*****] LOW LEVEL SWITCH [*****] AC MOTOR DRIVEN PUMP [*****] DC HYDRAULIC PUMP
[*****] TRIPLE INDIC [*****] ICE DETECTOR [*****] WIPER MOTOR CONVERTER [*****] WIPER MOTOR
CONVERTER [*****] MAIN WINDSHIELD CONTROLLER [*****] STBY DE ICING CTL UNIT [*****] DUAL DISTRIBUTOR
VALVE [*****] REGULATOR/SHUTOFF VALVE [*****] SHUT OFF VALVE [*****] ANTI-ICING CONTROLLER [*****]
LEFT ELEVATOR HORN [*****] RIGHT ELEVATOR HORN [*****] RUDDER HORN [*****] LEFT AILERON HORN [*****]
RIGHT AILERON HORN [*****] LEFT AILERON HORN [*****] RIGHT AILERON HORN [*****] ATTENDANT PANEL
[*****] QUICK ACCESS RECORDER [*****] APIU [*****] DIGITAL FLT DATA RECORDER [*****] DIGITAL FLT
DATA RECORDER [*****] LINEAR ACCELEROMETER [*****] MPC-ED36 [*****] ATTENDANT PANEL [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 65/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 66 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] Description [*****] ATTENDANT PANEL
[*****] ROD-DYNAMOMETRIC,ROL [*****] CREW ALERTING PANEL [*****] ENTRY PANEL-FLT DATA [*****] CLOCK
[*****] EFIS CONTROL PANEL RH SIDE [*****] EFIS CONTROL PANEL RH SIDE [*****] EFIS CONTROL PANEL LH
SIDE [*****] EFIS CONTROL PANEL LH SIDE [*****] INDEX CONTROL PANEL [*****] INDEX CONTROL PANEL
[*****] MULTI-FUNCTION CONTROL PANEL [*****] MULTI-FUNCTION CONTROL PANEL [*****] INTEGRATED
AVIONICS DISPLAY [*****] FDAU [*****] FDAU [*****] MPC [*****] CLOCK [*****] MULTIPURPOSE CONTROL &
DISPLAY UNIT [*****] MULTIFUNCTION COMPUTER [*****] CLOCK [*****] PARKING VALVE [*****] BRAKING
RESERVOIR [*****] MASTER CYLINDER [*****] LANDING GEAR CONTROL VALVE [*****] PARKING ACCUMULATOR
[*****] HYDRAULIC DUMPER [*****] NORMAL METERING VALVE [*****] WHEEL SPEED TRANSD ASSY [*****]
PARKING VALVE [*****] NORMAL METERING VALVE [*****] MODULE-ANTISKIP [*****] ANTISKID VALVE MANIFOLD
[*****] ANTISKID CONTROL UNIT [*****] ANTISKID CONTROL UNIT [*****] VLV-RELIEF LOW PRESS [*****]
RESTRICTOR VALVE [*****] SOLENOID VALVE NLG [*****] SWIVEL SELECTOR VALVE [*****] DIFF CONTROL
SELECT VALVE [*****] UP LOCK BOX [*****] LANDING GEAR SELECTOR [*****] ANTICOLL.LTG POWER SPLY UNIT
[*****] Confidential material redacted and filed separately with the Securities and Exchange
Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 66/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 67 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] Description [*****] TRANSFORMER-115V/5V-
[*****] LIGHT-LOGO [*****] WING-ENG SCAN LIGHT LH [*****] WING-ENG SCAN LIGHT LH [*****] WING-ENG
SCAN LIGHT RH [*****] WING-ENG SCAN LIGHT LH [*****] LANDING LIGHT [*****] ANTICOLL.LTG POWER SPLY
UNIT [*****] ANTICOLL. LIGHT [*****] TOTAL AIR TEMP SENSOR [*****] FLUX VALVE COMPENSATOR [*****]
FLUX VALVE [*****] ATTITUDE HEADING REF UNIT [*****] VSI/TCAS INDICATOR [*****] ALTIMETER [*****]
VSI/TCAS INDICATOR [*****] PROBE-PITOT [*****] RADIOMAGNETIC INDICATOR [*****] ADF.RECEIVER [*****]
VOR/ILS/MKR.RECEIVER [*****] DME RECEIVER [*****] ATC CONTROL PANEL [*****] DME INDICATOR [*****]
ADAPTER [*****] ATC TRANSPONDER [*****] ATC TRANSPONDER [*****] ATC TRANSPONDER [*****] IND-AIRSPEED
STDBY [*****] STANDBY ALTIMETER [*****] AIR DATA COMPUTER [*****] INDICATOR-TAS/TEMP [*****]
AIRSPEED INDICATOR [*****] ATTITUDE HEADING REF UNIT [*****] EFIS SYMBOL GENERATOR [*****]
EFIS.CONTROL PANEL [*****] CRS/HDG.REMOTE CONTROLLER [*****] CRS/ALT.REMOTE CONTROLLER [*****]
WX.RADAR CONTROL PANEL [*****] WX.RADAR CONTROL PANEL [*****] WX.RADAR CONTROL PANEL [*****] RADAR
RECEIVER TRANSCEIVER [*****] ATC TRANSPONDER [*****] MULTI. CONTROL & DISPLAY UNIT [*****]
TRANSCEIVER RECEIVER TCAS [*****] Confidential material redacted and filed separately with the
Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue
7 Page 67/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 68 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] Description [*****] VOR/ILS/MKR.RECEIVER
[*****] DME TRANSCEIVER [*****] VOR/ILS/MKR.RECEIVER [*****] ATC CONTROL PANEL [*****]
VOR/ILS/DME.CONTROL PANEL [*****] ADF.CONTROL PANEL [*****] TCAS CONTROL PANEL [*****] NAVIGATOR
PROCESSOR UNIT [*****] NAVIGATOR PROCESSOR UNIT [*****] T2CAS COMPUTER [*****] RADIO-ALTIMETER
TRANSCEIVER [*****] RADIO-ALTIMETER TRANSCEIVER [*****] EGPWS MK8 COMPUTER [*****] GPWS MK2 COMPUTER
[*****] INTEGRATED ELEC.STAND-BY EQUIP [*****] AIR DATA COMPUTER [*****] GPS RECEIVER [*****] GPS
RECEIVER [*****] STANDBY HORIZON [*****] RADAR RECEIVER TRANSCEIVER [*****] OXYGEN SOLENOID VALVE
[*****] OXYGEN REGULATOR MASK ASSY [*****] OXYGEN REGULATOR MASK ASSY [*****] OXYGEN PRESS.XMTR/REG
[*****] DUCT DISCHARGE DOWNSTREAM VALV [*****] CHECK VALVE [*****] PRESSURE REG & S/O VALVE [*****]
BLEED AIR SHUTOFF VALVE [*****] ISOLATION VALVE [*****] INTEGRATED CORE PROCESSING MOD [*****] IOM -
S [*****] CAC SWM [*****] IOM - DATA CONCENTRATOR [*****] CORE AVIONICS CABINET RACK [*****] IOM -
AUTO PILOT [*****] CARGO DOOR ACTUATOR [*****] COCKPIT DOOR CONTROL UNIT [*****] HYDRAULIC PRESSURE
SWITCH [*****] MOTOR AND PUMP ASSEMBLY [*****] PROPELLER COND.PUSH-PULL [*****] PROPELLER SPEED
INDICATOR [*****] OVERSPEED GOVERNOR [*****] OIL PUMP [*****] ELECTRONIC PROPELLER CONTROL [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 68/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 69 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] Description [*****] PROPELLER VALVE
MODULE [*****] ELECTROVALVE [*****] PROPELLER BLADE [*****] EJECTION DUCT [*****] EJECTION DUCT
[*****] IND-FUEL TEMP [*****] FUEL FLOW INDICATOR [*****] FUEL FLOW TRANSMITTER [*****] ENGINE POWER
PUSH-PULL [*****] HP SPEED INDICATOR [*****] TORQUE INDICATOR [*****] INTERTURBINE TEMP.INDICATOR
[*****] PROPELLER TORQUE INDICATOR [*****] OIL COOLER FLAP ACTUATOR [*****] THERMOSTATIC VALVE
[*****] OIL COOLER [*****] OIL TEMP/PRESS.INDICATOR [*****] OIL PRESSURE SENSOR [*****] CONTROL
ENGINE ELECTRONIC [*****] EXCITER-IGNITION [*****] EJECTOR-FUEL WASTE [*****] VALVE
ASSY-INTERCOMPRESSOR BLEED [*****] VALVE ASSY-INTERCOMPRESSOR BLEED [*****] AUTOFEATHER CONTROL
[*****] FUEL CONTROL-MECHANICAL [*****] COOLER-OIL, FUEL COOLED [*****] FLOW DIVIDER AND DUMP VALVE
[*****] VALVE ASSY-SERVO [*****] PUMP-FUEL [*****] BRAKE HYDROMECHANICAL ASSY [*****] EFIS.CATHODE
RAY TUBE [*****] Confidential material redacted and filed separately with the Securities and
Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 69/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED
<!-- page 70 -->
2. List B

The following list of LRUs contains [*****] part numbers. [*****] Description [*****] T.I.C. VALVE
[*****] EXCHANGER [*****] AUDIO CONTROL PANEL [*****] BUS POWER CONTROL UNIT [*****] AC GENERATOR
[*****] DC STARTER GENERATOR [*****] TRIM ACTUATOR [*****] DUAL DISTRIBUTOR VALVE [*****] ANTICOLL.
LIGHT [*****] STROBE LIGHTS [*****] POWER SUPPLY UNIT [*****] EMERGENCY POWER SUPPLY [*****]
HEATER-OIL TO FUEL

For sake of clarity, the above lists may be amended from time to time by way of Notice sent to the
Company by the Repairer.

ALL ITEMS, PARTS, COMPONENTS, SERVICES, WARRANTIES AND GUARANTEES PROVIDED HEREUNDER ARE PROVIDED
SUBJECT TO CLAUSE 14 OF THE AGREEMENT. [*****] Confidential material redacted and filed separately
with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 70/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 71 -->
Execution version EXHIBIT 7 - REPAIRER STANDARD WORK ORDER FORMS

7-1 Standard exchange order:

AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 71/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 72 -->
Execution version 7-2 Repair order:

Agreement ref.: code client-GMA-01 SHIPPING DATE: PAGE: 1 / 1

REPAIR ORDER

(THIS FORM MUST BE ENCLOSED INSIDE THE BOX WITH THE UNIT) FROM: TO (Shipping address): COMPANY NAME
Sender:

Tel: Fax:

ATR CUSTOMER SUPPORT c/o DHL Solutions ZA du Pont Yblon 95 500 Bonneuil en France FRANCE

REPAIR ORDER NUMBER : DATA RELATED TO REMOVED UNIT A/C DATA TYPE: MSN: FH: REGISTRATION: CY:

UNIT DATA

PART NUMBER: TSN: AMENDMENT: CSN: SERIAL NBR: TSO: DESIGNATION:PAGE: CSO: WARRANTY COVERAGE
INSTALLATION DATE: VENDOR (O.E.M.): YES NO REMOVAL DATE: A.C.S. REPAIR: YES NO REASON FOR REMOVAL
REQUESTED WORK REPAIR OVERHAUL BENCH TEST CALIBRATION

MODIFICATION

(Please indicate the requested SB and final PN)

OTHER WORKS TO INCORPORATE / REMARKS ATR—Global Maintenance Agreement ATR form ref. 7-2 AZUL-ATR
Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 72/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 73 -->
Execution version 7-3 Standard exchange Core Unit returned to ATR Pool:

Agreement ref.: code client-GMA-01 SHIPPING DATE: PAGE: 1 / 1

STANDARD EXCHANGE CORE UNIT RETURNED TO ATR POOL

(THIS FORM MUST BE ENCLOSED INSIDE THE BOX WITH THE UNIT) FROM: TO (Shipping address): COMPANY NAME

Sender: Tel: Fax:

ATR CUSTOMER SUPPORT c/o DHL Solutions ZA du Pont Yblon 95 500 Bonneuil en France FRANCE

EXCHANGE ORDER REFERENCE: UNIT DELIVERED BY ACS: PART NUMBER: SERIAL NBR: DATA RELATED TO REMOVED
UNIT A/C DATA TYPE: MSN: FH: REGISTRATION: CY:

CORE UNIT DATA

PART NUMBER: TSN: AMENDMENT: CSN: SERIAL NBR: TSO: DESIGNATION: CSO: WARRANTY COVERAGE INSTALLATION
DATE: VENDOR (O.E.M.): YES NO REMOVAL DATE: A.C.S. REPAIR: YES NO REASON FOR REMOVAL REMARKS ATR -
Global Maintenance Agreement ATR form ref. 7-3 AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 73/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 74 -->
Execution version

Agreement ref.: code client-GMA-01 DATE: PAGE: 1 / 1

LOAN ORDER

FOR MAIN ELEMENT AVAILABILTY UNDER GMA FROM: TO: COMPANY NAME:

Sender: Tel: Fax:

A.C.S.-ATR CUSTOMER SUPPORT Attn: Tel for routine orders: (33) 5 62 21 60 80 Tel for AOG orders:
(33) 5 62 21 62 00 Fax for routine orders: (33) 5 62 21 62 80 Fax for AOG orders: (33) 5 62 21 62 62

REQUEST FOR A/C TYPE: RGSTN: MSN: LOAN ORDER NUMBER DELIVERY LEAD TIME: A.O.G. CRITICAL REQUESTED
PART NUMBER DESCRIPTION REASON

DATA RELATED TO PART NUMBER REMOVED FROM AIRCRAFT

PART NUMBER S / N Removal date

COMMENTS SHIPPING ADDRESS IF SPECIFIC (Different from standard shipping address) REMARKS ATR -
Global Maintenance Agreement ATR form ref. 7-4 AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 74/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 8 - LEASE OF THE STOCK
<!-- page 75 -->
1. Lease of the Stock

The Repairer agrees to lease the Stock to the Company and the Company agree to take the Stock on
lease, subject to the terms and conditions of this Agreement.

2. Content and value of the Stock

2.1 Content: the Stock listed in Exhibit 5 ("Stock") contains serviceable Items, either brand new or
used, depending on availability of such Items by the Repairer at the time of their respective
Delivery. 2.2 Value: the Stock total value for brand new Items, under economic conditions prevailing
in two thousand fourteen (2014), shall be:

For the initial AZUL stock delivered under economic conditions 2010, [*****]

For the stock delivered under the AZUL amendment 3 under economic conditions 2011, [*****]

For the stock delivered under the AZUL amendment 4 under economic conditions 2011, [*****]

For the first batch, stock delivered under the GMA TRIP under economic conditions 2011 [*****]

For the second batch limited to the parts not recommended by the repairer, stock delivered under the
GMA TRIP under economic conditions 2011 [*****]

For the sake of clarity, parts of the Stock contained into the second batch that are recommended by
Repairer, are provided [*****] delivered under the GMA TRIP under economic conditions 2011 [*****]

For the batch related to the Amendment 5, stock delivered under economic conditions 2013 [*****]

For the batch related to the Amendment 6, stock delivered under economic conditions 2014 [*****]

For the batch related to the Amendment 7, stock delivered under economic conditions 2014 [*****]

For the batch related to the 2014 OSS replenishment, stock delivered under economic conditions 2014
[*****]

For the batch related to the Pitot exchange, stock delivered under economic conditions 2014 [*****]
[*****] Confidential material redacted and filed separately with the Securities and Exchange
Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 75/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED [*****]
<!-- page 76 -->
For the sake of clarity,

The total Stock value of Exhibit 5 list shall be:

[*****]

And the lease fee payable in Exhibit 14 ("Price conditions")shall be based on the value of [*****]
corresponding to parts of the Stock contained into the TRIP second batch that are recommended by
Repairer, i.e. [*****]

In the event the Repairer delivers used Items to the Company, the value of each such used Item shall
be quoted at [*****] of the brand new value indicated in Exhibit 5 ("Stock") and the total value of
the Stock shall be adjusted accordingly by way of Notice sent by the Repairer to the Company. 2.3
Modification of the Stock: on the first anniversary date of the Start Date, the Parties may review
the content of the Stock and shall, in case of a variation in the contents of the Stock, amend the
Agreement accordingly by way of Notice sent by the Repairer to the Company. Following such
amendment, the Company shall return to the Repairer any Item of the Stock, or request the Repairer
to replace any Item within the Stock subject to the following conditions: a) the Item returned by
the Company (i) has never been used by the Company since the Start Date, (ii) is in serviceable
condition, (iii) isdelivered in its original Packaging and with all appropriate airworthiness
documents; and,

b) the Item shall be returned as per Clause 6.2 of this Agreement; and,

c) if an Item is returned to the Repairer, the value of the Stock shall be modified by deduction of
the initial value of the relevant Itemapplicable at the time of its Delivery; and, d) if an Item is
added to the Stock, the value of the Stock shall be increased according to the ATR spare parts
catalogue price for the addedItem at the economic conditions corresponding to the time when the
Stock is modified.

The Company shall be responsible for and pay any costs incurred by and/or in connection with the
return to the Repairer and/or replacement of such Items of the Stock, including transportation
costs, customs duties, formalities and commissions, re-certification fees if documents are missing
or damages are found or the conditions of this Clause 2.3 are otherwise not complied with by the
Company. 2.4 Inventory of the Stock: the Repairer or any representative it designates shall have the
right to inspect the Stock and to audit any records relating thereto at any reasonable time upon
giving prior Notice to the Company, which shall provide full access to such Stock to enable the
Repairer to conduct periodic inventory inspections and/or any audit of the Stock.

Should any Item of the Stock be missing, partially or totally damaged, or not have its appropriate
airworthiness documentation at the time the Repairer or its representative carries out its
inspection and/or audit, and if the Company cannot justify such Item as being under repair, the
Company shall have [*****] to remedy the situation to the satisfaction of the Repairer, failing
which, the Repairer shall invoice the Company the price for any such lost or damaged Item at the ATR
spare parts catalogue price applicable on the date of such invoice for a new part initially
delivered by the Repairer. In the event the Repairer initially delivered used Items to the Company,
each such used lost Item shall be invoiced at [*****] [*****] Confidential material redacted and
filed separately with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master
Agreement DS/CS-3957/14/Issue 7 Page 76/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 77 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] of the brand new value at the ATR spare
parts catalogue price applicable on the date of such invoice.

3. Stock Delivery 3.1 Provided the Company has met each of the conditions precedent as per Clause 17
("Conditions precedent") of the Agreement, the Stock shall be delivered to the Company by the
Repairer with the relevant airworthiness documents (certificate of conformity, ANAC SEGVOO 003 or
EASA Form 1 or FAA Form 8130-3), [*****] to the Repairer stores located at the address set forth in
Clause 6.1 of this Agreement, or such other location as the Repairer may from time to time notify to
the Company . 3.2 The Repairer shall use its reasonable endeavours to deliver [*****] in quantity of
the Stock within [*****] as from the Start Date. 3.3 As from the Delivery of the Stock, the Company
is appointed as the custodian of the Stock and, all risks relating to or arising in connection with
the Stock shall be transferred to, vested in and borne by the Company, which shall promptly notify
the Repairer of any loss or damage to the Stock. 3.4 Within [*****] as from the date of Delivery of
any Item of the Stock, the Company shall be responsible for obtaining and shall provide the Repairer
with evidence in respect of (i) custom clearance, including payment fees, customs duties, and (ii)
customs declarations, with respect to the relevant Stock Item.

4. Storage Location of the Stock (i) The Storage Location shall be:

Rodovia Santos Dumont, Km 66, Jardim Itatinga, Campinas - São Paulo, Brazil CEP 13052-970.

And

Av Portugal, 5139, Itapoa - Belo Horizonte, Minas Genais, Brazil

or any other address notified from time to time by the Company to the Repairer, or by default the
address of the Company as indicated in page four (4) of this Agreement.

(ii) The Stock shall be kept with its corresponding documentation in secured warehouse facilities at
the Storage Location, which shall be separated from any area used to store any other equipment, and
each Item shall be clearly identified as belonging to the Repairer and/or the Stock owner with the
inscription "ATR PROPERTY".

(iii) The Company shall notify to the Repairer the name and address of the owner or landlord of the
Storage Location, if relevant, and each time such owner or landlord changes; the Company shall
notify the said new owner or landlord, if relevant, of the Repairer's property of the Stock and copy
the Repairer of such notification. (iv) The Company shall be liable for maintaining the Stock by
applying the best methods for storage and maintenance as required byapplicable EASA or [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 77/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 78 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED ANAC regulations at its own costs, particularly
for parts subject to limited shelf life or cure date. 5. Use and repair of the Stock

(i) Each Item listed in Exhibit 3 ("Main Elements covered under this Agreement") and Exhibit 6
("LRUs covered by repair and standardexchange Services") withdrawn from the Stock and used by the
Company shall be exclusively repaired by the Repairer.

(ii) The Company shall be entitled to withdraw and use Items from the Stock in accordance with its
operational needs, to remedy to any corresponding unserviceable Item fitted on the Aircraft covered
under this Agreement (Exhibit 1 "List of ATR Aircraft covered under this Agreement"). (iii) In such
case, the Company shall return to the Repairer such unserviceable Item removed from the Aircraft
with a Work Order for repairin the form set out in Exhibit 7-2 within [*****] from the withdrawal of
the corresponding Item from the Stock.

The Repairer shall then repair, as relevant, such unserviceable Item in accordance with the
provisions of Exhibits 10 and/or 11 and re- deliver to the Company a serviceable Item with the
relevant associated airworthiness documentation (i.e. a certificate of conformity, ANAC SEGVOO 003
and EASA Form 1 or FAA Form 8130-3,and when applicable the log book duly filled with any technical
information).

The Company shall then place such serviceable Item into the Stock.

(iv) In the event that the unserviceable Item removed from the Aircraft is declared BER or TNR (copy
of the Repair Shop report will be given to the Company ), and is not covered by Services as defined
in Exhibit 10 and/or Exhibit 11, the Repairer will invoice such unserviceable Item to the Company ,
except if the Company replaces such unserviceable Item with an equivalent serviceable Item which
shall be placed into the Stock.

(v) Should the Company place a standard exchange Work Order, as per Exhibit 9 to replace any Item
withdrawn from the Stock to replace an equivalent unserviceable Item removed from any Aircraft, then
after repair and/or overhaul of such unserviceable Item, the Repairer will place such repaired
and/or overhauled Item into the Pool and will not deliver it to the Company . (vi) [*****].

In the event the Company purchases any Item of the Stock, the Parties agrees to modify accordingly
the price indicated in Clause 1.1 of the Exhibit 14 ("Price conditions"), to take into account
monthly lease rental only for the remaining Items of the Stock. [*****] Confidential material
redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 78/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED
<!-- page 79 -->
6. Return of the Stock 6.1 Within [*****] as from the End Date, the Company shall notify the
Repairer of its decision to either: (a) [*****] and/or, (b) return the Stock to the Repairer as per
Clause 6.2 of the Agreement in accordance with the following terms and conditions; such returnshall
have to be performed within [*****] following such Notice.

If the Company fails to notify the Repairer as provided here above, the Repairer shall either (i)
invoice as per (a) here above and/or (ii) direct the Company to return the Stock within [*****]
following the term of the aforesaid [*****] period and/or (iii) repossess the Stock, at its
discretion. 6.2 If the Company fails to return the Stock as provided here above, the Company shall
be charged interest at a rate equal to [*****] of the value of the non-returned Items, per Day as
from the end of the aforesaid [*****] period, until the non-returned Items are duly received or
repossessed by the Repairer.

The Repairer shall be entitled to set off such late return interests with the Security Deposit
pursuant to Clause 13 ("Security Deposit"). 6.3 In the event any Item of the Stock is not returned
to or repossessed by the Repairer within [*****] period as from the End Date, the Repairer may
consider, at its discretion, such Item as lost and shall then invoice such Item to the Company at
the ATR spare parts catalogue price in force at the time of such invoice.

The Repairer shall be entitled, at its sole discretion, to set off the corresponding amount(s) with
the Security Deposit as specified in Clause 13 ("Security Deposit"). 6.4 In the event that (i) any
Item is returned to the Repairer without the appropriate airworthiness documentation, or (ii)
whenever the Items are returned without the original documents supplied by the Repairer, or (iii) if
the Repairer has to test, to replace or to repair such returned Item(s) due to damage or
deterioration as a result of incorrect storage, inappropriate Packaging and/or transport, or (iv)
for any other reason whatsoever, the Company shall bear any associated re-certification, repair,
overhaul, and/or replacement costs for such Items at the ATR spare parts catalogue prices applicable
on the date of return of such Item to the Repairer. 6.5 Conditions for the return of the Main
Elements: when returned or repossessed, if the TSO of the Main Element is different from the TSO at
the time of its Delivery, the Repairer shall invoice to the Company the Lost Potential as per the
conditions of this Agreement.

In case the maintenance of the Main Elements is not covered by this Agreement, the Company shall
return any Main Element with the same TSO as the one at the time of its Delivery. If such TSO is
higher, the Repairer shall invoice to the Company the works necessary to restore such TSO based on
Time and Material conditions. [*****] Confidential material redacted and filed separately with the
Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue
7 Page 79/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 80 -->
Execution version 7. Payment and transfer of the property title 7.1 Save as otherwise set out in
this Agreement, the purchase price for any Item of the Stock shall be paid in accordance with the
provisions of Clause 12 ("Invoicing and payment terms"). 7.2 Notwithstanding the provisions of
Clause 5 above, title to the Stock shall remain with Stock owner at all times until the Stock has
been purchased by the Company as per Clause 6 above and provided that any amount of the
corresponding invoice has been fully received by the Repairer in accordance with Clause 12
("Invoicing and payment terms").

The Company specifically agrees that it shall not acquire any interest, equity or share of the
Stock, or pledge or create any lien of any sort whatsoever prior to the transfer of title to the
Stock to it in accordance with this Agreement and shall fully indemnify the Stock Owner and/or the
Repairer with respect to any consequence of a non-compliance with its obligations under this Clause
7.2. 7.3 The Company may not, under any circumstances, perform or permit any action to be taken that
may be detrimental to the Repairer's and/or Stock owner's property title to the Stock, including: i)
The Company must not transfer, sell, charge, pawn, mortgage, negotiate, dispose of, or intend to
negotiate or dispose of the Stock; and,

ii) The Company shall take the necessary measures in order to prevent the Stock from being seized or
taken away, or to check the Stock in the event of a seizure by distress or any other similar legal
process. However, if the Stock is seized or taken away, the Company must immediately notify the
Repairer and indemnify the Repairer and/or the Stock owner for any Loss incurred by the Repairer
and/or the Stock owner as a result of the above-mentioned events, and shall mitigate any such Loss
by using its reasonable endeavours to re- possess the Stock or to re-acquire the Stock. 7.4 Case of
use of the Stock as per Clause 5 of the Exhibit 8 ("Lease of the Stock"): the title to the Item
withdrawn from the Stock shall pass to the Company upon installation of such Item on the Aircraft,
subject to (i) full and complete payment of any and all sums due by the Company in connection with
this Agreement and (ii) the completion of all of its obligations under Clause 5 of the Exhibit 8
("Lease of the Stock").

The title to the Item removed from the Aircraft and sent to the Repairer for repair as per Clause 5
hereof shall pass to the Repairer and/or the Stock owner, as relevant, upon such removal. AZUL-ATR
Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 80/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 9 - SPARE PARTS STANDARD EXCHANGE SERVICE
<!-- page 81 -->
The Company shall granted access to the Pool on a standard exchange basis where the Company may
order any LRU listed in Exhibit 6 and provide the Repairer in return with an equivalent (same part
number or same standard interchangeable) unserviceable LRU removed from the Aircraft. This right of
access to the Pool is not exclusive to the Company. 1. Pool content

The Pool is a set of serviceable LRUs listed in Exhibit 6 ("LRUs covered by repair and standard
exchange Services") available upon the Start Date, provided the Company has complied with its
obligations pursuant to Clause 17 ("Conditions precedent").

In the event of any Aircraft technical modification and upon the Company 's written request, the
Repairer may update the list set forth in Exhibit 6 ("LRUs covered by repair and standard exchange
Services"), in which case, the price set out in Clause 1.2 of the Exhibit 14 ("Price conditions")
shall be adjusted accordingly. 2. Access to the Pool

To access the Pool and take Delivery of the requested LRU, the Company must place a written standard
exchange Work Order (by filling the form ref 7-1 in Exhibit 7) with the Repairer. 3. Repairer's
obligations 3.1 Pool management

The Repairer shall be responsible for managing and maintaining the Pool at his own expense and in
compliance with the relevant OEM recommendations.

Any LRU from the Pool delivered to the Company by the Repairer or any Repair Shop shall comply with
the applicable Aircraft technical specifications. 3.2 Dispatching the Items

(i) Any LRU from the Pool shall be delivered to the Company pursuant to Clause 6.1 of the Agreement
within [*****] for routine orders, within [*****] for critical orders or within [*****] for AOG
orders (limited to classified "no-go and go if" LRUs according to MMEL) as the case may be, starting
from the Day of receipt by the Repairer of a standard exchange Work Order. (ii) The dispatch lead
times set forth in Clause 3.2 (i) above remain subject to: (a) reception by the Repairer of written
standard exchange Work Order 7.1 duly filled in by the Company; and, [*****] Confidential material
redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 81/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED
<!-- page 82 -->
(b) the availability in the Company 's facilities of a stock of critical Items at least at the level
of Repairer's recommendations for theAircraft fleet; and, (c) the number of AOG standard exchange
Work Orders being less than [*****] of the total number of standard exchange WorkOrders placed by
the Company over the last [*****]; and, (d) The Company not being in breach of any of its
obligations under this Agreement, including Clause 4.1 (i) of this Exhibit 9.

(iii) Provided the conditions set out in Clause 3.2 (ii) of this Exhibit 9 are met and the Company
placed an A.O.G. standard exchange Work Order with the Provider, should the Company be obligated,
after Provider's approval, to lease similar LRU from a third Party servicer due to the
unavailability of the requested LRU in the Pool, then the Provider will reimburse to the Company,
for [*****] until the date of delivery of the requested unit by the Provider to the Company. The
Provider shall not under any circumstances have any liability whatsoever (including liability of any
consequential loss or damage) in respect of any late delivery of any part other than the liability
set forth in this Clause 3.2(iii) . (iv) Any LRU of the Pool will be provided at its latest standard
or fully interchangeable standard with the relevant certificate of conformity and, ANAC SEGVOO 003
and EASA form 1/FAA form 8130-3 dual release. (v) LRUs delivered from the Pool are covered by the
provisions of Clause 9 ("Warranties"). (vi) Any LRU of the Pool subject to TBO event shall be
delivered to the Company with no less than [*****] of life remaining to the nextscheduled overhaul.
4. Core Unit return 4.1 Return lead time

(i) The Company shall return to the Repairer's facilities indicated in Clause 6 ("Deliveries") any
Core Unit with the Work Order form ref 7-3 duly filled-in, as standard exchange counterparts, within
a maximum [*****] as from the Delivery Date of the LRU from the Pool for any Items from the list A
of the Exhibit 6 ("LRUs covered by repair and standard exchange services") and within a maximum of
[*****] as from the Delivery Date of the LRU from the Pool for any Items from the list B of the
Exhibit 6 ("LRUs covered by repair and standard exchange services").

For sake of clarity, in the event a Core Unit is not returned by the Company to the right Delivery
Location as specified in the Clause 6 ("Deliveries"), the Repairer shall be entitled to charge the
Company transportation costs, associated taxes and Customs duties due to the re-exportation of such
Core Unit to the right Delivery Location. (ii) Prior to dispatching any Core Unit, the Company will
also send by fax or by email all the data related to the dispatch (including the dateof dispatch and
the carrier's name).

(iii) Notwithstanding the above provision in sub-clause 4.1 (i), in the event a Core Unit is not
received by the Repairer within [*****] after Delivery date of the LRU for by the Repairer to the
Company for any Items from the list A of the Exhibit 6 ("LRUs covered by repair and standard [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 82/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 83 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED exchange services") and within a maximum [*****]
as from the Delivery Date of the LRU from the Pool for any Items from the list B of the Exhibit 6
("LRUs covered by repair and standard exchange services"), the Repairer shall be entitled to charge
the Company , as the case may be, late fee equivalent to [*****] of the value of the part per Day
starting the [*****] up to maximum the [*****] for any Items from the list A of the Exhibit 6 ("LRUs
covered by repair and standard exchange services") and starting the [*****] up to maximum the
[*****] for any Items from the list B of the Exhibit 6 ("LRUs covered by repair and standard
exchange services") after the Company's standard exchange Work Order date, as the case may be. In
the event the Core Unit is not returned by the [*****] for any Items from the list A of the Exhibit
6 ("LRUs covered by repair and standard exchange services") or by the [*****] for any Items from the
list B of the Exhibit 6 ("LRUs covered by repair and standard exchange services") after the
Company's standard exchange Work Order date, as the case may be, the Repairer will declare the Core
Unit as lost in exchange as lost and shall be entitled to invoice to the Company , as the case may
be, the amount corresponding to the value of the serviceable LRU primarily delivered by the Repairer
according to spare parts catalogue price in force on the date of its Delivery. Title to such
serviceable LRU shall pass to the Company, as the case may be, upon full payment of the Repairer's
invoice. The Repairer shall be entitled to withdraw without delay the related amount from the
Security Deposit as per Clause 13 ("Security Deposit"). (iv) In case of accumulated not returned
Core Units pursuant to sub-clause 4.1 (iii) above, the Repairer shall be entitled, subject to a
[*****]prior Notice, to suspend the Company's Pool access. 4.2 Any Core Unit shall be repaired in
accordance with Exhibit 10 ("LRUs repair Service"). 5. Specific services not covered by standard
exchange Service

The following services and their related costs (labor and parts) are not eligible to the standard
exchange Service, and shall be managed on Time and Material conditions:

(i) services performed for LRU(s) fitted on Aircraft to comply with Aircraft redelivery conditions
or delivery conditions of a third party. For sake of clarity, Aircraft redelivery conditions or
delivery conditions of a third party will have to be declared by the Company to the Repairer in
anticipation [*****] before the stop of the Aircraft; (ii) services performed for any part of the
Company's own inventory if any, to be replaced, or maintained, re-certified, tested, checked,
forinventory management and/or maintenance reasons (shelf life, cure dates…). 6. Transfer of title
and risks 6.1 Title to the Items featured in the Pool, or in the Stock in the event of Clause 5 (v)
of the Exhibit 8 ("Lease of the Stock"), or the Advanced Pool Stock of Clause 7 of the Exhibit 15
("Advanced Pool Service"), remains at all times with the Repairer until: (a) receipt by the Repairer
of the corresponding Core Unit in compliance with Clause 4.1 of this Exhibit 9 and of a confirmation
from theRepair Shop that such Core Unit is repairable; and, (b) full and complete discharge of any
and all sums due by the Company under or in connection with this Agreement.

Title to the corresponding Core Unit shall pass to the Repairer and/or the Stock owner free from any
lien, security or other encumbrance upon removal of such Core Unit from the Aircraft. [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 83/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 84 -->
Execution version For the sake of clarity, in the event of Clause 5 (v) of the Exhibit 8 ("Lease of
the Stock") and Clause 7 of the Exhibit 15 ("Advanced Pool Service"), the Repairer and/or the Stock
Owner shall remain the owner of the serviceable LRU sent from the Pool to the Stock and to the
Advanced Pool Stock, as replacement. 6.2 Notwithstanding the above, in the event the Core Unit is
invoiced to the Company as per Clause 4.2 above, the transfer of title to the serviceable LRU
primarily delivered from the Pool shall take place upon receipt by the Repairer of the full payment
for the invoice relating to such serviceable LRU. 6.3 The Company hereby represents and warrants
that (i) it is the lawful owner of the Core Unit and/or (ii) it is duly entitled to transfer the
title to such Core Unit in accordance with Clause 6.1 above. 6.4 In any event, all risks whatsoever
and howsoever relating to or arising in connection with any serviceable LRU of the Pool shall be
transferred to, vested in and borne by the Company , as from Delivery thereof pursuant to Clause 6
("Deliveries"). 7. THIS EXHIBIT IS PART OF THE AGREEMENT AND ALL APPLICABLE PROVISIONS THEREOF ARE
APPLICABLE HERETO. WITHOUT LIMITING THE FOREGOING, ALL ITEMS, PARTS, COMPONENTS, SERVICES,
WARRANTIES AND GUARANTEES PROVIDED HEREUNDER ARE PROVIDED SUBJECT TO CLAUSE 14 OF THE AGREEMENT AND
TO THE DISCLAIMERS AND LIMITATIONS ON WARRANTIES AND DAMAGES, INCLUDING CONSEQUENTIAL DAMAGES, SET
FORTH THEREIN. 8. FURTHER ASSURANCES

The Repairer retains title to any serviceable LRU until payment therefor as provided above. As a
precautionary measure however, the Company agrees that the Repairer shall have all rights and
remedies afforded to a secured party upon the default of a debtor as provided in the UCC and grants
a security interest to the Repairer in all of the Company's right, title and interest in each
serviceable LRU and the proceeds thereof and all general (including payment) intangibles related
thereto or arising therefrom to secure the prompt and punctual payment and performance when due of
all obligations of the Company under this Agreement, including this Exhibit.

The Company shall do all acts and things necessary or advisable, including execute and deliver all
documents, to ensure that the Repairer's right, title and interest in and to the serviceable LRUs is
perfected in all applicable jurisdictions and otherwise protected against the current or future
claims of any third-party, including the Company's creditors, mortgagees, lessors, financing
parties, trade creditors, any owner of an aircraft and other Persons. Such acts and things shall
include obtaining such consents and approvals from, and execution, delivery, registration,
recordation and filing of such UCC financing statements (including continuation statements and
amendments), FAA mortgages and other documents with, such registries, governmental authorities and
third parties as the Repairer may reasonably request. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 84/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 85 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 10 - LRUs REPAIR SERVICE 1. Definition of
repair

Any unserviceable LRU, not declared BER or TNR, shall be repaired or overhauled by the Repairer in
compliance with the relevant CMM and according to ANAC or EASA/FAA part 145 regulations.

If the Company receives from the Repairer a LRU repaired or overhauled under ANAC regulation only
with associated ANAC SEGVOO 003 release, the Company may have the right in case of Aircraft
redelivery for replacement of such part by another one with relevant certificate of conformity EASA
form 1/FAA form 8130-3 dual release. The Repairer shall make its best efforts to provide to the
Company the Services in compliance with EASA and FAA for all LRU repaired or overhauled by the local
repair shops by end of December of 2015;

[*****].

If the Repairer receives from the Company an excessive number of unserviceable LRUs compared to the
MTBUR for such LRU, the Repairer may assist the Company in investigating the causes of such
situation, and each Party shall take all necessary corrective actions to the satisfaction of the
other Party acting reasonably. 2. Information concerning unserviceable LRUs returned to the Repairer

The Company shall send to the Repairer any unserviceable LRU, as relevant, with a Work Order in the
form set out in Exhibit 7-2 (for any single repair) or in the form attached as Exhibit 7-3 (for the
repair of any Core Unit). 3. Documents provided with the repaired or overhauled LRU

The following documents shall be provided by the Repairer to the Company with any repaired or
overhauled LRU under this Agreement: (i) EASA form 1 certificate or FAA form 8130-3 or, if
applicable, ANAC SEGVOO 003, (ii) Strip report issued by the Repair Shop, and (iii) An invoice, if
such repair service is not covered by the scope of this Agreement. 4. Specific services not covered
by LRU repair Service

The following repairs and their related costs (labor and parts) are not covered by the prices set
out in Clause 1.3.1 of the Exhibit 14 ("Price conditions") and shall be managed on Time and Material
conditions: (i) all costs of technical modifications that may be incurred due to the embodiment on
LRUs of Airworthiness Directives, service bulletins,optional or recommended modifications. (ii) the
repair of an unserviceable LRU or additional costs resulting from Items received in damaged
conditions due to Abnormal Use,mishandling, corrosion, abrasion, FOD and/or missing Items, [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 85/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED
<!-- page 86 -->
(iii) any additional costs in repairing or overhauling any unserviceable LRU due to Company's
failure to produce data as requiredhereunder,,

(iv) any cost and expense, direct and/or indirect, that may arise out of or connected with any
additional technical expertise and/or counter expertise to be performed on any LRU, at the Company's
request, in the event the Company challenges the Repairer's primary expertise, or repair cost
estimation, or repair solution, (v) replacement or repair of LRUs' sub-components unapproved by the
OEM, (vi) the maintenance costs relating to any failure of the Company to observe or comply with its
obligations under this Agreement, (vii) all battery repairs or replacements, (viii) propeller brake
disk replacements, (ix) CVR and DFDR memory and/or tape analysis and/or read outs. 5. Discarding the
LRUs

The Parties acknowledge that under normal operating conditions any unserviceable LRU may be BER or
TNR.

The Repairer shall notify the Company in case of BER or TNR status of any unserviceable LRU, and
shall request the Company's approval to discard such unserviceable LRU.

If the Company denies such approval, the unserviceable LRU shall be delivered back to it at the
[*****] costs and risks.

The Company's failure to respond to such Repairer's request within [*****] following the Repairer's
notification of BER or TNR shall constitute an approval for the Repairer to discard the relevant
unserviceable LRU.

If the discarded unserviceable LRU has been replaced with a serviceable LRU of the Pool or of the
Stock pursuant to the provisions of Exhibits 8 ("Lease of the Stock") or 9 ("Spare parts standard
exchange Service"), the Repairer shall invoice and the Company shall pay for the price of such
serviceable LRU of the Pool or of the Stock, based on the ATR spare parts catalogue sales price
applicable at the date of such invoice for brand new or used LRU, as the case may be.

ALL ITEMS, PARTS, COMPONENTS, SERVICES, WARRANTIES AND GUARANTEES PROVIDED HEREUNDER ARE PROVIDED
SUBJECT TO CLAUSE 14 OF THE AGREEMENT. [*****] Confidential material redacted and filed separately
with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 86/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 11 - MAIN ELEMENTS SERVICES
<!-- page 87 -->
1. Field of application

1.1 The Repairer shall provide the Company with a Main Elements' maintenance (as per Clause 2 of
this Exhibit 11) and availability (as per Clause 3 of this Exhibit 11) Service.

This Service is applicable to: a) Main Elements listed in Exhibit 3 ("Main Elements and parts
numbers covered by the Agreement") when installed on an Aircraft, and b) any Main Elements in the
Stock as relevant, and c) any Spare Main Element.

The Services provided to the Company by the Repairer in accordance with this Exhibit 11 cover
off-Aircraft tasks and works performed by the Repairer. For the sake of clarity and unless otherwise
agreed between the Parties, standard exchange Service shall not be available for Main Elements under
this Agreement, except for propeller blades and slip ring as per Clause 3 of this Exhibit 11. 1.2
Main Elements' maintenance program (Scheduled Events)

At the date of entry into force of this Agreement, the Parties acknowledge and agree that applicable
intervals for inspections / overhauls on Main Elements are: i) for propellers:

[*****]. ii) for landing gears:

[*****].

The Repairer reserves its rights to require the Company to modify the above Main Elements
maintenance program in accordance with the Aircraft manufacturer MRBR and/or MPD, to optimize the
Company 's Aircraft dispatch reliability, provided the Company's Airworthiness Authorities enable
so.

2. Main Elements' maintenance Service description

2.1 Any off-Aircraft maintenance task and work to be performed on Main Elements and Spare Main
Elements shall be carried out in accordance with the relevant CMM for each Main Element. Such
maintenance tasks with respect to each Aircraft comprise the following services [*****] Confidential
material redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 87/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 88 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED on which are based the prices set out in Clause
1.3.2 of the Exhibit 14 ("Price conditions"):

[*****] 2.2 Maintenance for Scheduled Events

The Repairer shall provide the maintenance Service for Scheduled Events, in accordance with the
applicable maintenance program of each Main Element described at Clause 1.2 of Exhibit 11.

In the event that the Main Element's maintenance program set out in Clause 1.2 of this Exhibit 11
shall be changed, the Parties hereby agree that the Repairer may modify the price conditions set out
in Clause 1.3.2 of the Exhibit 14 ("Price conditions"), as relevant. 2.3 Basic Unscheduled Removals

The repair of Main Elements due to BUR shall be performed by the Repairer according to the relevant
CMMV and provided that: - The Company has fulfilled its obligations as per Clause 5 of this Exhibit;
and, - the maintenance tasks are related to normal Aircraft operation in accordance with all
technical documentation and any otherinstructions issued by ATR or the OEM; and, - the maintenance
tasks are not related to specific conditions as per Clause 6 of this Exhibit.

3. Spare Main Elements availability Service description

3.1 With respect to each Aircraft, prices set out in Clause 1.3 of the Exhibit 14 ("Price
conditions") comprise the availability of Spare Main Element for Scheduled Events and BUR according
to the provisions of sub-clause 3.2 hereof.

For the sake of clarity, propeller blades and slip rings may be available through the standard
exchange Service, as per the Exhibit 9 ("Spare parts standard exchange Service").

. [*****] Confidential material redacted and filed separately with the Securities and Exchange
Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 88/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED
<!-- page 89 -->
3.2 Availability of Spare Main Element(s) for Scheduled Events and BUR: 3.2.1. Such Service
includes, at any time and for the entire fleet, - [*****] propellers, - [*****] landing gear,

In the event the Company requires any additional Spare Main Element, the Repairer will make a
proposal on Time and Material conditions. 3.2.2 Subject to the Company having complied with its
obligations as per Clause 5 of this Exhibit 11, the Repairer shall make available suchSpare Main
Element(s) during the period necessary for the maintenance for Scheduled Events and BUR of Aircraft
Main Element(s). 3.3 The Repairer will make Spare Main Element(s) available to the Company during
maintenance for BUR of Main Elements within [*****] from the date of receipt by the Repairer of the
Company's Work Order in the form set out in Exhibit 7-4.

4. Return to the Repairer of the Main Element or Spare Main Element

At the time the Repairer delivers to the Company a Spare Main Element or returns any repaired or
overhauled Main Element to the Company , for fitment on the Company 's Aircraft, the Company will
deliver back to the Repairer the Main Element removed for repair or overhaul or the Spare Main
Element previously obtained from the Repairer, with required technical documentation on a date (the
"Due Date") within a time period of [*****] starting from the Delivery date of the Spare Main
Element or the repaired or overhauled Main Element. When the Main Element removed for repair or
overhaul is replaced by a Spare Main Element of the Stock or a spare of the Company 's property, the
Company shall return to the Repairer or the designated Repair Shop such removed Main Element, with
required technical documentation within a time period of [*****], starting from the removal date of
the Spare Main Element.

For returning the Main Elements and Spare Main Elements to the Repairer, the Company shall use
adapted container or when applicable the containers received from the Repairer. Any container
received by the Repairer or its approved Repair Shop in incomplete or damaged condition from the
Company shall be subject to refurbishment or replacement at Company's cost and expense in addition
to the prices specified in the Exhibit 14 ("Price conditions").

Should the Company fail to deliver the Main Element removed for repair or overhaul or the Spare Main
Element(s) back to the Repairer or the Repair Shop on the above Due Date and without prejudice to
other rights the Repairer may have at Law and/or under this Agreement, the Repairer may charge late
return fees to the Company in an aggregate amount of: - [*****] - [*****]

per [*****] of delay, as from the Due Date until the Spare Main Element or the Main Element is duly
received by the Repairer or the Repair Shop. The Repairer shall be entitled to withdraw such late
return fees from the Security Deposit pursuant to Clause 13 ("Security Deposit").

5. Company's obligations

In order to allow the Repairer to perform the maintenance tasks defined in Clause 2.1 of this
Exhibit 11 in compliance with the relevant OEM's technical specifications, the Company [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 89/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 90 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED agrees: to provide the Repairer every [*****]
with a detailed status of the Main Elements showing the Scheduled Events for the next [*****]; to
send to the Repairer a Work Order for the Services at the latest [*****] before the event, either
for maintenance Service and/or foravailability Service; to send to the Repairer the log book, log
card and back to birth certificate of the landing gears removed for repair or overhaul or
sparelanding gear; that, to be eligible for availability Service, no Main Element within the Stock
pursuant to Exhibit 8 ("Lease of the Stock") and/or theCompany 's own on-site stock shall be
available in the Company s premises, as per the Repairer's initial provisioning recommendation.

Moreover, the Company shall: 5.1 In respect of the propellers: (i) perform line checks (not limited
to lubricant levels, blade balancing, blade anti-erosion film replacements, etc...) and the
requiredconsumable spare parts replacements during the Aircraft's entire service life; (ii) procure
all the tools necessary for the line maintenance of the propellers including the propeller balancing
tool; and (iii) initiate and pursue an efficient staggering program to ensure a smooth schedule
removal plan for shop maintenance. 5.2 In respect of the landing gears: (i) perform the line checks
(including Messier best practices service letter 631-32-218) and the required consumable spare
partsreplacements during the Aircraft's entire service life, on landing gears, wheels and tires; and
(ii) procure all the tools necessary for the line maintenance of the landing gear including the
appropriate tooling used for wheelsreplacement. If required, the Repairer will have to assist the
Company in procuring these tools (buying, hiring, etc.); and (iii) initiate and pursue an efficient
staggering program to ensure a smooth schedule removal plan for shop maintenance. 5.3 Left
intentionally blank 5.4 On-Aircraft tasks

All scheduled and unscheduled on-Aircraft maintenance activities, tasks and works and line
maintenance, including the following, are under and at the Company's responsibility, risks, costs
and expenses: (i) line maintenance tasks associated with engines, propellers, landing gears, wheels,
brakes and tires, (ii) Main Elements removals and installations for BUR and Scheduled Events, (iii)
Main Elements accessories removals and installations, (iv) Main Elements conditioning for storage,
(v) grease and lubricant refilling, seals, gaskets, hardware and consumable parts replacement, (vi)
propellers balancing, blades removals and installations, (vii) ensure that log books are reflecting
the updated maintenance status of each Main Element. (viii) engine fuel nozzles removals and
installations, (ix) engine control trend monitoring performance and analysis, [*****] Confidential
material redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 90/110

Source: AZUL SA, F-1/A, 3/3/2017

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 91 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED
<!-- page 92 -->
(x) regular cleaning of the engines, (xi) inspection of internal parts (boroscopic inspection).

6. Specific services not covered by Main Elements' Service

The following services and their related costs (labor and parts) are not covered by the prices set
out in Clause 1.3.2 of the Exhibit 14 ("Price conditions") and shall be managed on Time and Material
conditions: (i) all costs of technical modifications that may be incurred due to the embodiment on
Main Elements of Airworthiness Directives, servicebulletins, optional or recommended modifications,
(ii) replacement or repair of Main Elements' sub-Items costs relating to any failure of the Company
to comply with its obligations under thisAgreement, (iii) the replacement cost of a Main Element
and/or its sub-assemblies that is declared BER or TNR, (iv) any additional costs in connection with
the repair or overhaul of any Main Element serial number due to Company's failure to producedata as
required hereunder,

(v) Items and/or any sub-Items received in damaged conditions due to Abnormal Use, mishandling,
incorrect storage, lightning strike, FOD, corrosion, abrasion or erosion, dropped or water
immersion, over-torque condition or over-speed in excess of transient or over- temperature

(vi) Services performed on Main Element(s) fitted on Aircraft to comply with Aircraft redelivery
conditions or delivery conditions to a third party, . For sake of clarity, Aircraft redelivery
conditions or delivery conditions of a third party will have to be declared by the Company to the
Repairer in anticipation [*****] before the stop of the Aircraft, (vii) the replacement of missing
parts and parts unapproved by the OEM, (viii) the repair of damages or replacements resulting from
previous repair and/or overhaul not performed pursuant to this Agreement,

(ix) for the landing gears, the replacement of life limited parts, repair and/or replacement of On
Condition Parts listed in Exhibit 4, replacement of any part (including expendables) which vendor
price exceeds [*****] with the exception of parts listed in Exhibit 11 Clause 2.1 (ii), (x) for the
propellers, replacement of dome, repair of armbore, replacement of de-icer and replacement of nickel
sheath.

7. Discarding the Main Elements

The Parties acknowledge that under normal operating conditions any Main Element may be declared BER
or TNR.

The Repairer shall notify the Company in case of BER or TNR status of any Main Element, and shall
request the Companys approval to discard such Main Element.

If the Company denies such approval, the Main Element shall be delivered back to the Company at its
costs and risks.

The Parties agree that the absence of a response by the Company to such Repairer's request within
[*****] from the sending of the Repairer's notification of BER or TNR constitutes an approval for
the Repairer to discard the relevant Main Element. [*****] Confidential material redacted and filed
separately with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 91/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 93 -->
Execution version In the event the Repairer shall discard any unserviceable Main Element, the
Company shall pay the applicable price for test and/or scrap, as the case may be.

In case of the discarded Main Element is an unserviceable propeller blade that has been replaced
with a serviceable propeller blade of the Pool or of the Stock pursuant to the provisions of
Exhibits 8 ("Lease of the Stock") or 9 ("Spare parts standard exchange Service"), the Repairer shall
invoice and the Company shall pay for the price of such serviceable propeller blade of the Pool or
of the Stock, based on the ATR spare parts catalogue sales price applicable at the date of such
invoice for brand new or used, as the case may be. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 92/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 94 -->
Execution version EXHIBIT 12 - INTENTIONALLY LEFT BLANK AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 93/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 95 -->
Execution version EXHIBIT 13 - FORM OF STANDBY LETTER OF CREDIT

By swift message to our addressee BANK NATIXIS (SWIFT Code: CCBPFRPP)

Issuing Bank: (NAME AND ADDRESS) Issuing Bank SWIFT Code: Confirming Bank: Applicant: Beneficiary:
ATR

StandBy Letter of Credit reference:

By order of [AZUL NAME], located at [AZUL ADDRESS], we hereby issue our irrevocable and confirmed
StandBy Letter of Credit in favour of Avions de Transport Régional, located 1 allée Pierre Nadot
31712 Blagnac, France ("ATR"), for the aggregate amount of USD XXXX (XXX USD) available for the
period ending twelve (12) Months after the Term of the GMA (as defined below);

Available by payment at sight by NATIXIS against your written demand bearing the Clause drawn under
irrevocable StandBy Letter of credit (letter of credit reference) issued by (issuing bank name and
address) accompanied by the following document: - Beneficiary's signed certificate specifying the
amount drawn and stating: (1) that the amount claimed is due and payable by [AZUL NAME] in
connection with the Global Maintenance Agreement between ATR asthe Repairer and [AZUL NAME] as the
Company executed on (date) for the XXX [Services] (the "GMA"); and, (2) that the Beneficiary has
requested payment of the amount claimed from [AZUL NAME] who is in default.

Partial drawings are permitted.

The Beneficiary shall not be entitled to assign or transfer any right, title or interest in this
StandBy Letter of Credit to any other party.

All banking charges and commissions are for the account of the Applicant.

This StandBy Letter of Credit is subject to the 2007 revision of the Uniform Customs and Practices
for Documentary Credits of the International Chamber of Commerce Publication 600.

This StandBy Letter of Credit will take effect on the (date). AZUL-ATR Global Maintenance Master
Agreement DS/CS-3957/14/Issue 7 Page 94/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 14 - PRICE CONDITIONS
<!-- page 96 -->
1. Prices

The price payable for the Services shall be the sum of the prices set out in this Agreement and
established in accordance with the economic conditions prevailing in two thousand and fifteen
(2015). 1.1 The lease fee payable for the lease of the Stock (based on the Stock technical contents
defined in Exhibits 5 ["Stock"] and 8 ["Lease of the Stock"]), as from the Start Date is [*****]:
(i) an amount of [*****] corresponding to [*****] of the Stock value which is set in Exhibit 8
("Lease of the Stock"), Clause 2.2 ; or

(ii) in the event the Repairer delivers used Items to the Company as per Clause 2.2 of the Exhibit 8
("Lease of the Stock"), the [*****] set forth in 1.1 (i) here above shall be payable from the Start
Date until the date on which the last Item of the Stock is delivered. On such latter mentioned date,
the Repairer will notify to the Company the exact and definitive Stock value, and the accordingly
revised monthly lease payment based upon [*****] of such exact and definitive Stock value. Upon
Delivery of the last Item of the Stock, the Repairer shall issue a credit equal to the difference
between: a. the total amount of lease payments actually paid by the Company since the Start Date
according to Clause 1.1 (i) here above,and b. the price the Company should have paid for the used
Items delivered by the Repairer according to Clause 1.1 (ii) here above. 1.2 The price payable
[*****] per Aircraft by the Company to the Repairer for the standard exchange Service set out in
Exhibit 9 ("Spare parts standard exchange Service") is as follows (with unlimited POOL access):
[*****] [*****] [*****] [*****] [*****] 1.3 The prices per airborne FH per Aircraft payable by the
Company to the Repairer for the repairs and overhauls of the LRUs and the Main Elements set out in
this Agreement are:

1.3.1 For LRU repair and overhaul: [*****] Confidential material redacted and filed separately with
the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 95/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 97 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] [*****] [*****] [*****] [*****] [*****]
1.3.2 For the Main Element Services as per Exhibit 11 ("Main Elements Services"): i) propellers
[*****] per Aircraft): (a) For maintenance - [*****] - [*****]

The above propellers maintenance provisions and availability prices are defined as a result of the
following repartition related to the maintenance of the following propeller hub, actuator, transfer
tube and blades composing each propeller assembly:

Blades Hub Actuator Transfer Tube Adjusting Nut [*****]

[*****] [*****] [*****] [*****] [*****] [*****] [*****]

[*****] [*****] [*****] [*****] &bbsp; [*****] [*****] [*****] (b) For availability [*****] [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 96/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED
<!-- page 98 -->
ii) left intentionally blank iii) landing gears (per shipset):

For 42-500, 72-500, 72-600 landing gears: (a) For maintenance: [*****] [*****]

plus (b) For availability [*****] [*****]

The above landing gear maintenance provisions and availability prices are defined as a result of the
following repartition related to the maintenance of the following sub-assemblies composing each
landing gear assembly [*****] [*****] NLG [*****] [*****] Drag Brace [*****] [*****] MGL [*****]
[*****] Side Brace [*****] [*****]

Life limited parts repair or replacement will be subject to a case by case quotation. 1.3.3
Additional flat rates:

Additional flat rates here under shall be applied for the following operations, as applicable: a)
for [*****], a flat rate of :

For [*****]: [*****] b) for [*****], a flat rate of :

For [*****]: [*****] 2. Reconciliation conditions

2.1 Left intentionally blank 2.2 Price adjustment for LRUs removal rate reconciliation [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 97/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 99 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED Any difference, to be measured in units and tens,
between the RRR and the MRR pursuant to the conditions set out in Clause 11.1 (iii) and (iv) of the
Agreement, shall be invoiced or credited, provided the Company is not in Default of any of its
obligations pursuant to this Agreement, per airborne FH on the basis of:

for [*****]

[*****] [*****]

for [*****]

[*****] [*****]

for [*****] [*****]

[*****] [*****]

In addition, at each reconciliation based on the actual flown flight hours, the Repairer shall
credit back:

[*****] 2.3 Early Events

The Parties agree that the prices for each Service subject to Scheduled Events are based on the
achievement of the applicable maintenance program(s), expressed in [*****].

In case of deviation of the Scheduled Event maintenance program parameters by a number of [*****]
shall be considered an Early Event.

For any Early Event, whichever the context, the Repairer shall invoice the Company an amount equal
to the Lost Potential multiplied by the applicable price mentioned in Clause 1.3 of this Exhibit.
2.4 Calendar Limits

For propellers and landing gears, the prices given in Clause 1.3.2 of this Exhibit 14 are subject to
the achievement of the applicable [*****] specified in Clause 1.2 of Exhibit 11 ("Main Elements
Services") hereto. In case a maintenance event is necessary to comply with a calendar limit, the
Company shall settle the applicable prices in Clauses 1.3.2 and 3 of this Exhibit 14 at the time of
the event, multiplied by the full interval specified in Clause 1.2 of Exhibit 11 ("Main Elements
Services") hereto less the amount already paid by the Company to the Repairer for the number of
[*****] accrued since the last overhaul.

3. Prices adjustment

For the sake of clarity, the adjustment conditions set out in Clauses 3.1 and 3.2 below [*****]. 3.1
Commercial conditions for price adjustment 3.1.1 For Lease of the Stock, standard exchange Service
and LRUs repair Service

The prices set out in this Agreement will be increased, if applicable, [*****] in accordance with
the following adjustment formula:

[*****] [*****] Confidential material redacted and filed separately with the Securities and Exchange
Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 98/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 100 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED where:

[*****] is the [*****] for the year N+1, and [*****],

[*****]: is the [*****] as determined by economic conditions of year N (current year),

[*****]: is the [*****] in the year N,

[*****]: is the corresponding [*****] of the year N-1,

[*****]: is the [*****] in the year N,

[*****]: is the corresponding [*****] of the year N-1.

Escalation is subject to a [*****] for Stock, Clause 1.1 of the Exhibit 14, and Standard Exchange
services, Clause 1.2 of the Exhibit 14.

Escalation is subject to a [*****] for LRU repair service, Clause 1.3 and Clause 2.2 of the Exhibit
14.

Escalation is subject to a [*****]. 3.1.2 For Main Elements Services

The prices set out in this Agreement relative to the Main Elements will be [*****].

Escalation is subject to a [*****] for Main Elements repair service [*****] In any case the final
result of the applicable annual adjustment rate [*****] Clause 1.3 of the exhibit 14. 3.2 Technical
conditions for prices adjustment

The prices set out in this Exhibit 14 shall be modified [*****] at the occasion of the invoicing
reconciliation pursuant to Clause 11 ("Reconciliation") if the Standard Operations of the Aircraft,
analyzed at the time of the adjustment (all calculations are made with figures corresponding to
[*****]), change by more or less [*****] with respect to the estimated values of the same
parameters, considered at the time of commencement of the Term.

As from the date this Agreement enters into force, the Parties agree to take into account the
following basic operating parameters (the "Standard Operations") as a reference for the above
calculation: (i) [*****] - [*****] - [*****] - [*****] (ii) [*****] - [*****] [*****] Confidential
material redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 99/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED - [*****] - [*****]
<!-- page 101 -->
4. Specific conditions

4.1 Company's Aircraft fleet change(s)

[*****]. 4.2 Unused Aircraft

During the Term, should any Aircraft remain temporarily unused for less than [*****] by the Company
for whatever reason, the Company shall not request or obtain from the Provider a change in prices or
terms and conditions set out in this Agreement in Clause 12 ("Invoicing and Payment terms").

5. Phase-in:

As a condition precedent to the entry into force of this Agreement, as reflected in Clause 17
("Conditions Precedent"), the Company shall pay to the Repairer an amount corresponding for each
Main Element and/or any sub-assembly thereof, to the number of FH or CY accrued since the last
overhaul or since new as applicable, at the date of entry into force of the Agreement, multiplied by
the applicable rate defined in Clauses 1.3 and 3 of this Exhibit 14 and applicable at the date of
the first event.

6. Phase-out: Refundable maintenance provisions

6.1 Upon termination of this Agreement with respect to one or more Aircraft and/or Services in
accordance with the terms of this Agreement (except as a result of a Company Default) (the
"Termination Date"), the Repairer shall reimburse the Company Maintenance Provisions related to
landing gears maintenance services and/or their sub-component for ATR 72-600 only based on [*****]
of the amount set out in Clause 1.3.2 of the Exhibit 14 ("Price Conditions")for maintenance services
(the "Refund Amount"), taking into account the price applicable [*****] as per Clauses 3 of the
Exhibit 14 ("Price Conditions") and when applicable adjusted every [*****] as per Clause 10 and 11,
for [*****] for Main Elements: between the re-installation on such Aircraft after the last shop
repair or overhaul or exchange occurred under this Agreement, as evidenced in the relevant EASA,
FAA, TC, or ANAC release form and ending on the Termination Date.

For sake of clarity, since the Company will pay such service based on, [*****] Confidential material
redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 100/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED
<!-- page 102 -->
- for ATR 42-500, ATR 72-500 and ATR 72-600, [*****] of the price by the hours and [*****] - for ATR
72-600, [*****] of the price by the hours and [*****], - for ATR 42-500 and ATR 72-500 [*****] of
the price by the hours and [*****],

[*****]. In addition, it is agreed by the parties that [*****] out of [*****] of the maintenance
provision paid for the maintenance of the landing gears [*****].

Should any Aircraft be an ATR and/or ATR Affiliate's property, then Refund Amount shall be
reimbursed to the owner.

The Repairer will reimburse the Refund Rate provided that: (i) the Company has returned to the
Repairer all Spare(s), Main Element(s), Items of the Stock, Core Units and unserviceable LRUs
theRepairer may have delivered or to be returned to the Repairer according to the terms of this
Agreement, and (ii) The Company has paid to the Repairer all amounts due under this Agreement , and
(iii) The Company is not in Default of any of its obligations under this Agreement. 6.2 It is also
understood that [*****] to be taken into account for such a refund process are only those accrued
for the original Main Element(s) of Aircraft when fitted on Company's Aircraft or alternatively
spare(s) main elements of Company property. [*****] accrued on Spare Main Element(s) provided by the
Repairer to the Company under this Agreement and/or any Main Element(s) different from those
installed on Aircraft on the date they were originally delivered to the Company or not owned by the
Company shall not be taken into account in the calculation of the Refund Rate phase-out set out in
this Clause 6. 6.3 Such phase out shall occur simultaneously with the final reconciliation as per
Clause 11.2 of this Agreement. [*****] Confidential material redacted and filed separately with the
Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue
7 Page 101/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 15 - ADVANCED POOL SERVICE
<!-- page 103 -->
1. Advanced Pool Stock Availability

With the scope of further facilitating the maintenance operations of the Company, Repairer agrees to
make available the Advanced Pool Stock to the Company and Company agrees to store the Advanced Pool
Stock in a restricted area at the Storage Location. The provision, holding, use and disposal of the
Advanced Pool Stock and its review shall be subject to the terms and conditions of this Agreement.

2. Provision and value of the Advanced Pool Stock

2.1 The Advanced Pool Stock is composed of items defined in Exhibit 16 ("Advanced Pool Stock"),
which may be either brand new items or Used Serviceable Items depending on availability of each item
of the Advanced Pool Stock into Repairer's inventory at the time of their respective delivery. 2.2
The Advanced Pool Stock is governed by this Agreement until it is (i) either returned to the
Repairer at the Expiry Date, (ii) purchased by Company in accordance with Clause 6 hereunder, or
(iii) upon redelivery of the Advanced Pool Stock to Repairer after the termination of this Agreement
pursuant to Clause 16 of this Agreement. 2.3 The Advanced Pool Stock shall be provided to Company by
Repairer for the duration of the Term provided Company has met each of the Conditions Precedent set
out in Clause 17 of the Agreement to the satisfaction of the Repairer before the Start Date. 2.4 The
Advanced Pool Stock total value, under economic conditions 2010, shall be:

[*****]

For the sake of clarity, the total Stock value of Exhibit 16 ("Advanced Pool Stock") list shall be:
[*****].

In the event the Repairer delivers Used Serviceable Items to the Company, the value of each such
Used Serviceable Items shall be quoted at [*****] of the brand new value indicated in Exhibit 16
("Advanced Pool Stock") and the total value of the Advanced Pool Stock shall be adjusted
accordingly.

3. Delivery

3.1 The items of the Advanced Pool Stock will be delivered by Repairer to Company, with the relevant
airworthiness documents (certificate of conformity, ANAC SEGVOO 003, EASA Form 1 or FAA Form
8130-3), [*****] ATR stores located at the address set forth in Clause 6.1 of this Agreement, or
such other location as Repairer may from time to time notify to Company. 3.2 Delivery of the
Advanced Pool Stock shall take place gradually. Repairer shall use its reasonable efforts to deliver
[*****] of the items of the Advanced Pool Stock (in quantity) at the Start Date. Delivery of the
Advanced Pool Stock shall be subject to the Stock delivery. [*****] Confidential material redacted
and filed separately with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master
Agreement DS/CS-3957/14/Issue 7 Page 102/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 104 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED 3.3 Notwithstanding the fact that the Repairer is
the owner of the Advanced Pool Stock, all risks whatsoever and howsoever relating to or arising in
connection with the Advanced Pool Stock and any item of the Advanced Pool Stock, shall be
transferred to, vested in and borne by the Company as from the delivery of each item of the Advanced
Pool Stock by Repairer to Company. 3.4 Company shall be responsible for and proceed to custom
clearance of any item of the Advanced Pool Stock. Within a maximum [*****] lead time from the date
any item of the Advanced Pool Stock is delivered, Company shall provide Repairer with evidence that
any fees, customs duties, and customs declarations has been paid and made, failing which Repairer
may consider such failure as a Company Default pursuant Clause 16 of this Agreement.

4. Management and Handling Procedures

4.1 Location

i. Company shall keep the Advanced Pool Stock in secured warehouse facilities at the Storage
Location, the use of which is reserved for storing and protecting the Advanced Pool Stock owned by
Repairer. These facilities shall be separated from any areas used to store any other equipment and
the Storage Location shall be clearly marked with the inscription "ATR PROPERTY". All the items of
the Advanced Pool Stock will be stored with their corresponding documentation.

ii. Company agrees to maintain the Advanced Pool Stock by applying the best standard methods for
storage and maintenance as requiredby applicable EASA regulations at its own maintenance and storage
costs, particularly for parts subject to limited shelf life or cure date.

iii. Company shall promptly notify the Repairer any loss or damage to the Advanced Pool Stock whilst
under its management.

iv. Prior to the Delivery Date and upon each renewal of any policy, the Company shall supply the
Repairer with certificates of insurancecompliant with the terms and conditions set out in Clause 8
of this Agreement.

v. If at any time during the term, the Storage Location is not owned by the Company and is leased
from a third party, the Company shall advise the Repairer of the name and address of the owner or
landlord of such facilities or if any change of the owner or landlord occurs. It shall be the
responsibility of the Company to notify said owner or landlord of the Repairer's right of ownership
in and to the Advanced Pool Stock and copy the Repairer of such notification.

vi. The Company agrees to assume liability for and to indemnify and keep harmless Repairer against
any loss, cost, expense (including the fees of professional advisers and out of pocket expense),
financial liability, taxes, damage or monetary loss of any kind which Repairer may suffer or incur
as a consequence of the loss or damage to any item of the Advanced Pool Stock.

4.2 Use

The Company shall be entitled to, provided no Company Default has occurred and is continuing,
withdraw and use any of the items of the Advanced Pool Stock pursuant standard [*****] Confidential
material redacted and filed separately with the Securities and Exchange Commission. AZUL-ATR Global
Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 103/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 105 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED exchange service conditions defined in Exhibit 9
and in accordance with its operational needs, solely for the remedy of parts associated defects on
the Aircraft covered under this Agreement.

4.3 Inventory

The Repairer or its agent shall have the right to inspect the Advanced Pool Stock and to audit any
records relating thereto at any reasonable time upon giving prior written notice to the Company. The
Company shall provide full access to enable the Repairer to conduct periodic inventory inspection of
the Advanced Pool Stock.

Should any part of the Advanced Pool Stock be missing, partially or totally damaged, or has not its
appropriate airworthiness documentation at the time the Repairer or its agent carries out its
inspection/audit, and if the Company cannot justify the part being under repair, the Company shall
have a period of [*****] to remedy the situation to the satisfaction of the Repairer, failing which,
the Repairer shall invoice the Company the price for any such lost or damaged item at the ATR spare
parts catalogue price applicable at the date of such invoice.

5. Purchase Option

[*****]

6. Modifying the Composition of the Advanced Pool Stock

Upon either party's request, the parties agree to review the content of the Advanced Pool Stock at
the first anniversary date of the Start Date. Shall the parties agree to modify the content of the
Advanced Pool Stock, the following conditions shall apply:

i. item returned by the Company that has never been used by the Company since the Start Date, is
received by the Repairer in serviceablecondition, in its original packaging and with all appropriate
airworthiness documents;

ii. the item shall be returned in accordance with the provisions of Clause 6.2 of this Agreement;
and

iii. if an item is returned to the Repairer from the Advanced Pool Stock, the value of the Advanced
Pool Stock shall be modified bysubtraction of the initial value of the concerned item; and

iv. if an item is added to the Advanced Pool Stock, the value of the Advanced Pool Stock shall be
increased pursuant to the ATR SparesCatalogue price for the added item at the economical condition
of the moment the Advanced Pool Stock is modified.

The Company shall be responsible for and pay any costs incurred by the return to Repairer and/or
replacement of such items of the Advanced Pool Stock, including but not limited to transportation
costs, customs duties, formalities and commissions, re-certification fees if documents are missing
or damages are found.

7. Purchase or Return of the Advanced Pool Stock

7.1 Promptly on the Expiry Date, and subject to Clause 5 of this Exhibit 15, the Company shall
[*****] Confidential material redacted and filed separately with the Securities and Exchange
Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 104/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 106 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED have the option to:

i. [*****]

ii. re-deliver the items of the Advanced Pool Stock to the Repairer in accordance with Clause 6.2 of
this Agreement or to any other addressindicated from time to time by Repairer to the Company, in
accordance with the following terms and conditions. 7.2 In the event that any items are delivered
back to the Repairer without the appropriate airworthiness documentation, or whenever the parts are
returned without the original documents supplied by the Repairer, or if the Repairer has to test, to
replace or to repair such returned item(s) of the Advanced Pool Stock due to damage or deterioration
as a result of incorrect storage, inappropriate packaging and/or transport, or for any other reason
whatsoever, the Company is liable for any associated re-certification, repair, overhaul, or
replacement costs for such items at the ATR catalogue prices applicable on the date of delivery of
such item to the Company. 7.3 If the Company fails to deliver the Advanced Pool Stock or any part(s)
of the Advanced Pool Stock within [*****] of the Expire Date, the Company shall pay late return fees
equal to [*****] of the value of the non returned part(s), per Day since the Expire Date, until: a)
the missing part(s) are duly received by the Repairer, or b) a maximum [*****] from the Expire Date.
The Repairer will be entitled to withdraw such late return fees from the Security Deposit pursuant
to Clause 13. 7.4 The Company acknowledges and agrees that in the event any item of the Advanced
Pool Stock, or the entire Advanced Pool Stock, is not re- delivered to the Repairer within [*****]
of the Expire Date, this item or the Advanced Pool Stock shall be deemed lost, and the Repairer will
invoice this item of the Advanced Pool Stock to the Company at the ATR spare parts Catalogue price
in force at the date of delivery of any such item of the Advanced Pool Stock. Should the Company
fail to pay such invoice, Repairer will be entitled, at its sole discretion, to withdraw the
corresponding amount(s) from the Security Deposit.

8. Payment and Transfer of the Title to Property

8.1 Save as otherwise set out in this Agreement, the purchase price for any item of the Advanced
Pool Stock shall be paid in accordance with the provisions of Clause 12. 8.2 Notwithstanding the
provisions of Clause 6 of Exhibit 9, title to the Advanced Pool Stock or any item thereof shall
remain with the Repairer at all times until such Advanced Pool Stock or part thereof has been
purchased by the Company and provided that the amount of the corresponding invoice has been fully
received by the Repairer in accordance with Clauses 10 and 12 of this Agreement. The Company
specifically agrees that it shall not acquire any interest, equity or share of the Advanced Pool
Stock, or pledge or create any lien of any sort whatsoever prior to the transfer of title to the
Advanced Pool Stock to the Company in accordance with this Agreement. It is hereby acknowledged and
agreed that the Company is appointed as the custodian of the Advanced Pool Stock, which appointment
the Company hereby accepts until such time as the Repairer has received the Company's payment in
full for the Advanced Pool Stock or any item if the Advanced Pool Stock in case such Advanced Pool
Stock or item is either missing, damaged, without airworthiness documentation, purchased by the
Company or not returned by the Company to the Repairer in accordance with the provisions of this
Agreement.

8.3 The Company may not, under any circumstances, perform or permit any action to be taken that
[*****] Confidential material redacted and filed separately with the Securities and Exchange
Commission. AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 105/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 107 -->
Execution version may be detrimental to the Repairer's title to and property in the Advanced Pool
Stock, including without limitation:

i. the Company must not transfer, sell, charge, pawn, mortgage, negotiate, dispose of, or intend to
negotiate or dispose of the AdvancedPool Stock or any item of the Advanced Pool Stock ; and

ii. the Company shall take the necessary measures in order to prevent the Advanced Pool Stock or
part of the Advanced Pool Stock from being seized or taken away, or to check the Advanced Pool Stock
in the event of a seizure by distress or any other similar legal process. However, if the Advanced
Pool Stock or part of the Advanced Pool Stock is seized or taken away, the Company must immediately
inform the Repairer in writing and indemnify the Repairer for any losses, costs or expenses incurred
by the Repairer as a result of the above-mentioned events, and shall mitigate any such Losses, costs
or expenses by using its best efforts to re-possess the Advanced Pool Stock or to re-acquire the
Advanced Pool Stock or any item of the Advanced Pool Stock. AZUL-ATR Global Maintenance Master
Agreement DS/CS-3957/14/Issue 7 Page 106/110

Source: AZUL SA, F-1/A, 3/3/2017

Execution version CONFIDENTIAL TREATMENT REQUESTED EXHIBIT 16 - ADVANCED POOL STOCK
<!-- page 108 -->
The following Exhibit is composed of two (2) pages, into which are listed [*****] part numbers.

First List for [*****] specific fleet contains [*****] part numbers [*****] DESCRIPTION [*****]
[*****] CONDENSER [*****] [*****] COOLING UNIT [*****] [*****] VALVE-TURBINE INLET CONTROL [*****]
[*****] AUDIO CONTROL PANEL [*****] [*****] CONTROL UNIT-HF [*****] [*****] REMOTE CONTROL AUDIO
UNIT [*****] [*****] CONTROL UNIT-BUS POWER,DC [*****] [*****] CONTROL UNIT-GENERATOR,AC [*****]
[*****] STARTER GENERATOR-DC [*****] [*****] PROBE-CCAS ALPHA [*****] [*****] PROBE-PITOT [*****]
[*****] VALVE-HP AIR BLEED [*****] [*****] EXCITER - IGNITION I.C. [*****] [*****] SERVO VALVE
[*****] [*****] FUEL PUMP [*****] TOTAL

Second List for [*****] specific fleet contains [*****] part numbers [*****] DESCRIPTION [*****]
[*****] REMOTE CONTROL AUDIO UNIT [*****] [*****] REMOTE CONTROL AUDIO UNIT [*****] [*****] CONTROL
UNIT-BUS POWER,DC [*****] [*****] FCU-HYDRO MECHANICAL [*****] [*****] FCU-HYDRO MECHANICAL [*****]
[*****] AUDIO CONTROL PANEL [*****] [*****] EXCITER - IGNITION I.C. [*****] [*****] EXCITER -
IGNITION I.C. [*****] [*****] PROBE-CCAS ALPHA [*****] [*****] PROBE-CCAS ALPHA [*****] [*****]
Confidential material redacted and filed separately with the Securities and Exchange Commission.
AZUL-ATR Global Maintenance Master Agreement DS/CS-3957/14/Issue 7 Page 107/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 109 -->
Execution version CONFIDENTIAL TREATMENT REQUESTED [*****] DESCRIPTION [*****] [*****] CONTROL
UNIT-GENERATOR,DC [*****] [*****] SERVO VALVE [*****] [*****] CONTROL UNIT-VHF [*****] [*****]
CONDITIONER,TORQUE SIGNAL [*****] [*****] ALTIMETER-STANDBY,MILLIBARS [*****] [*****] CONTROL
UNIT-VHF [*****] [*****] ELECTRONIC SYSTEM UNIT [*****] [*****] INDICATOR-STANDBY HORIZON [*****]
[*****] CONTROL,AUTOFEATHER [*****] [*****] CONTROL,AUTOFEATHER [*****] [*****] GOVERNOR-PROPELLER
OVSP [*****] [*****] PUMP-PROPELLER FEATHERING [*****] [*****] PUMP-PROPELLER FEATHERING [*****]
[*****] SWITCH-PROXIMITY [*****] TOTAL [*****] [*****] [*****] DESCRIPTION [*****] [*****] PROBE
PITOT [*****]

ALL ITEMS, PARTS, COMPONENTS, SERVICES, WARRANTIES AND GUARANTEES PROVIDED HEREUNDER ARE PROVIDED
SUBJECT TO CLAUSE 14 OF THE AGREEMENT. [*****] Confidential material redacted and filed separately
with the Securities and Exchange Commission. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 108/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 110 -->
Execution version EXHIBIT 17 - INSURANCE CERTIFICATES

ALL ITEMS, PARTS, COMPONENTS, SERVICES, WARRANTIES AND GUARANTEES PROVIDED HEREUNDER ARE PROVIDED
SUBJECT TO CLAUSE 14 OF THE AGREEMENT. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 109/110

Source: AZUL SA, F-1/A, 3/3/2017
<!-- page 111 -->
Execution version EXHIBIT 18 - NOTA FISCAL REPORTING

Reporting 1:

Dedicated to the pool import + 1st standard exchange loop

Shall be submitted once (after all serviceable parts from the pool sent to Azul)

Part number Serial number

Nota Fiscal CFOP 5949 number Flow Azul -> Helibras

Nota Fiscal CFOP 5949 number Flow Helibras -> Azul Fiscal value Table with XXX lines (XXX = number
of parts to be imported) ...

Reporting 2:

Dedicated to subsequent standard exchanges

Shall be submitted on a monthly basis

Part number Serial number

Nota Fiscal CFOP 5949 number Flow Azul -> Helibras

Nota Fiscal CFOP 5949 number Flow Helibras -> Azul Fiscal value ...

ALL ITEMS, PARTS, COMPONENTS, SERVICES, WARRANTIES AND GUARANTEES PROVIDED HEREUNDER ARE PROVIDED
SUBJECT TO CLAUSE 14 OF THE AGREEMENT. AZUL-ATR Global Maintenance Master Agreement
DS/CS-3957/14/Issue 7 Page 110/110

Source: AZUL SA, F-1/A, 3/3/2017
