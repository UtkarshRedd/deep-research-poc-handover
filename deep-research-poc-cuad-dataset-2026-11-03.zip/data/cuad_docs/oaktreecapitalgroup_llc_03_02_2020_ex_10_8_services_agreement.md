<!-- page 1 -->
# SERVICES AGREEMENT
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2018-09-25 |
| Parties | Oaktree Capital Management. L.P. ("Oaktree US"); Oaktree Capital Management (International) Limited ("Sub-Advisor") |
| Source | CUAD v1 / OAKTREECAPITALGROUP,LLC_03_02_2020-EX-10.8-Services Agreement |

Exhibit 10.8

Services Agreement

Oaktree Capital Management, L.P.

and

Oaktree Capital Management (International) Limited

September 2018

1
<!-- page 2 -->
THIS SERVICES AGREEMENT (this "Agreement") is made on 25 September 2018

BETWEEN:

(1) Oaktree Capital Management, L.P. a Delaware limited partnership of 333 South Grand Avenue, 28th
Floor, Los Angeles, CA 90071 ("Oaktree US"); and

(2) Oaktree Capital Management (International) Limited, a private limited company (registered number
11311066) registered in England and Wales of Verde, 10 Bressenden Place, London, SW1E 5DH (the
"Sub-Advisor").

RECITALS

(A) Oaktree US is general partner and/or investment manager of the funds and separate accounts
referred to in Schedule 2 (the "Funds").

(B) The Funds were established under the applicable limited partnership or other governing
agreements (the "Fund Agreements").

(C) The Sub-Advisor has been constituted for the purposes of carrying on the business of a fund
manager and advisor in the United Kingdom. The Sub- Advisor is authorised and regulated by the
United Kingdom's Financial Conduct Authority (the "FCA") under Part IV of the Financial Services and
Markets Act 2000 ("FSMA") (with registration number 814006).

(D) The Sub-Advisor currently provides certain unregulated services to Oaktree US under a services
agreement dated 11 June 2018, which shall be terminated on the date of this Agreement (the
"Terminated Agreement").

(E) Oaktree US may in the future appoint the Sub-Advisor as a sub-advisor or sub-manager in
connection with such collective investment schemes, mutual funds, separate accounts or companies as
may be agreed from time to time (together, the "New Fund(s)"), upon the terms and conditions set
forth in this Agreement.

THE PARTIES AGREE AS FOLLOWS:

1. APPOINTMENT AND SCOPE OF AUTHORITY

1.1 The parties hereby agree that the Terminated Agreement shall terminate and cease to have effect
for all purposes, and shall simultaneously be replaced by this Agreement, with effect from 25
September 2018 (the "Effective Date"). For the avoidance of doubt, the appointment of the
Sub-Advisor to provide services to Oaktree US shall be continuous before, on and after the Effective
Date, but shall have effect from and after the Effective Date solely subject to the terms and
conditions of this Agreement.

1.2 Oaktree US hereby confirms the appointment of the Sub-Advisor as sub-investment manager and
sub-advisor to the Funds and to provide the services set out in Clause 2, and the Sub-Advisor
accepts such appointments, on the terms and conditions set forth in this Agreement.

1.3 Oaktree US furthermore hereby appoints the Sub-Advisor to provide certain marketing and
promotion services in relation to the Funds as set out in Clause 2, on the terms and conditions set
forth in this Agreement and the Sub-Advisor accepts such appointment.

1.4 The Sub-Advisor acknowledges that it is a relying adviser under the U.S. Investment Advisers Act
of 1940 (as amended) (the "Advisers Act") and the rules and regulations promulgated thereunder. If
and to the extent the assets of any Discretionary Fund or Restricted Fund managed by Oaktree US are
treated as "plan assets" as determined pursuant to 29 C.F.R. 2501.3-101 (or any successor thereto),
the Sub-Advisor acknowledges that it will be a fiduciary for purposes of the U.S. Employee
Retirement Income Security Act of 1974 ("ERISA") with respect to each employee benefit plan subject
to section 406 of ERISA or section 4975 of the Internal Revenue Code of 1986 whose assets are deemed
to be held by the applicable Fund to the extent required under ERISA to continue to manage or
sub-advise the applicable Funds.

1.5 The appointment of the Sub-Advisor pursuant to this Agreement shall be subject always to:

2
<!-- page 3 -->
(a) the terms and conditions in the relevant Fund Agreements governing the Funds, and the
Sub-Advisor hereby agrees to observe the terms and conditions in such Fund Agreements;

(b) any restrictions, limitations or conditions on, or any amendments made to, the Sub-Advisor's
authority which may be imposed by Oaktree US as general partner and/or investment manager of the
Funds from time to time; and

(c) Oaktree US's power and authority to act at all times in respect of any of the Funds as general
partner and/or investment manager of the Funds (as applicable)

1.6 Without limiting the discretion of Oaktree US pursuant to Clause 1.5(b), Oaktree US may limit
the scope of the Sub-Advisor's appointment in respect of any of the Funds by means of:

(a) limiting the appointment to sub-advisory services in respect of a section of the relevant Fund's
portfolio of investments;

(b) limiting the appointment to sub-advisory services in respect of a particular investment or
investments;

(c) limiting the Sub-Advisor's responsibility in respect of the monitoring and/or realisation of an
investment or investments; or

(d) retaining discretion to decide upon the acquisition, disposal, conversion or underwriting of
investments.

1.7 Without limiting the discretion of Oaktree US pursuant to Clause 1.5(b), Oaktree US reserves the
right as general partner and/or investment manager, in the interests of the Funds, to undertake the
management of the Funds' investments and assets to the exclusion of the Sub-Advisor during any
period in which the Sub-Advisor is unable to perform its duties under this Agreement due to the
permanent or temporary absence of the investment professional(s) employed for the time being by the
Sub-Advisor (whether due to holiday, sickness or otherwise).

1.8 The provisions in Clauses 1.5 to 1.7 shall have overriding effect against all other provisions
of this Agreement.

1.9 The Sub-Advisor shall act honestly, with due skill, care and diligence and fairly and in the
best interest of the Partnership in carrying out its obligations under this Agreement and shall use
all reasonable endeavours to perform its obligations under this Agreement in accordance with FSMA,
the FCA Rules and any other laws, regulations, guidelines and guidance as may be in force from time
to time and applicable to the Funds and their business or to the Sub-Advisor ("Applicable Law").

2. SERVICES

2.1 Without limiting the discretion of Oaktree US pursuant to Clause 1.5(b), and without prejudice
to Clauses 1.6 and 1.7, the Sub-Advisor shall be appointed to assist Oaktree US with the management
of the investments and assets of the Funds.

2.2 In connection with the appointment pursuant to Clause 2.1 but subject at all times to Clause 1:

(a) Oaktree US hereby delegates to the Sub-Advisor all such powers, authorities and discretions as
shall be necessary to enable the Sub-Advisor to perform its duties as sub-manager under this
Agreement; and

(b) the Sub-Advisor shall have full power and authority hereunder to decide whether the Funds should
acquire or dispose of an investment and Oaktree US grants the Sub-Advisor discretion, without
consultation to Oaktree US, to:

(i) make investment decisions with respect to invested assets of the Funds; and

(ii) enter into such investment documents and effect such transactions (including, if applicable,
instructing the Custodian (as defined in Clause 5.1 below) of the Funds in respect of transfers,
withdrawals or receipts of money) as may be necessary or proper in connection with the performance
by the Sub-Advisor of its duties hereunder.

3
<!-- page 4 -->
2.3 Without limiting the discretion of Oaktree US pursuant to Clause 1.5(b), and without prejudice
to Clauses 1.6 and 1.7, the marketing and promotion services to be provided by the Sub-Advisor in
respect of the Funds will be:

(a) assisting Oaktree US to promote any Fund to potential investors in Europe and the Middle East to
facilitate subscriptions from such investors;

(b) advising Oaktree US concerning all actions which it appears to the Sub-Advisor that Oaktree US
should consider taking to achieve effective promotion of investor interest in such Funds;

(c) attending, if so requested by Oaktree US, meetings held with such investors;

(d) if required by Oaktree US, arranging the administration of and receiving and collating
application forms from such investors and passing the completed applications to Oaktree US for
processing; and

(e) the provision of any other marketing service as Oaktree US may require from time to time in
Europe and the Middle East.

3. FEES

3.1 In consideration of the provision of services under this Agreement, Oaktree US will pay the
Sub-Advisor such fees as may be agreed between the parties from time to time (the "Service Fee").

3.2 At Oaktree US' discretion, the Service Fee shall be reduced by any management fees received
directly by the Sub-Advisor for investment management services provided to any party pursuant to
this Agreement. The Service Fee shall also be reduced by any amounts earned on cash and
cash-equivalents held by the Sub-Advisor pursuant to this Agreement.

3.3 The Service Fee shall be reviewed by Oaktree US and the Sub-Advisor once annually (or as the
parties agree) for continued appropriateness and in particular, to account for any changes in the
Sub-Advisor's business.

4. ADMINISTRATIVE FUNCTIONS

Oaktree US and its affiliates will provide all fund and investor accounting, fund investor
reporting, custodial services and similar administrative functions required in respect of the Funds.
Oaktree US will provide such services in a manner and quality consistent with past practices in
connection with the management of the Funds.

5. CUSTODY

5.1 All documents of or evidencing title to the Funds' investments shall be held in safe custody
facilities by a custodian to be selected by Oaktree US (the "Custodian") subject to the terms of a
custody agreement made between Oaktree US and the Custodian and subject to such other arrangements
and procedures as may be agreed between Oaktree US and the Custodian from time to time. The
Sub-Advisor shall at no time have custody or physical control of the invested assets of the Funds
nor shall it be liable for any act or omission of the Custodian.

5.2 Oaktree US shall take such additional steps (in addition to the authorities and powers hereby
conferred) as are necessary to procure that the Sub- Advisor is able, on behalf of Oaktree US, to
operate the bank accounts of the Funds so far as necessary for the Sub-Advisor to exercise all of
its powers and discretions and perform all of its duties under this Agreement.

6. RECORDS AND REPORTS

6.1 The Sub-Advisor shall maintain proper and complete records relating to the services to be
provided under this Agreement for such period of time as may be required under Applicable Law,
including (as applicable, in respect of the relevant Discretionary Funds) records with respect to
the acquisition, holding and disposal of securities on behalf of the Funds, details of all brokers
used and the aggregate dollar amount of brokerage commission paid in that regard to each broker.

4
<!-- page 5 -->
6.2 Except as expressly authorised in this Agreement or as required by Applicable Law, regulation or
court order, or as directed by Oaktree US in writing, the Sub-Advisor shall keep confidential the
records and other information pertaining to Oaktree US and the Funds or the investment assets the
subject of this Agreement (save for any records or information pertaining to the Sub-Advisor's own
employees and affiliates, which shall be excluded from the obligations contained in this clause).
Upon termination of this Agreement, the Sub-Advisor shall promptly, upon demand, return to Oaktree
US all such records, except that the Sub-Advisor may retain copies for its records as may be
required by Applicable Law, regulation or court order, and provided that the Sub-Advisor's
confidentiality obligations shall continue in full force and effect with respect to such retained
records not within the public domain.

6.3 The Sub-Advisor shall provide to Oaktree US promptly upon request any information available in
the records maintained by the Sub-Advisor relating to the Funds in such form as Oaktree US shall
request.

7. LIABILITY AND INDEMNIFICATION

7.1 In providing its services under this Agreement, the Sub-Advisor will discharge its duties in
accordance with the same standard of care established for Oaktree US in the relevant Fund
Agreements, and will be indemnified by each of the Funds as an agent of Oaktree US in accordance
with such Fund Agreements. To the extent Oaktree US and its affiliates, directors, officers,
employees, shareholders, assigns, representatives or agents (apart from the Sub-Advisor)
(collectively, "Oaktree US Indemnities") suffer any liability, loss (including amounts paid in
settlement), damages or expenses (including reasonable attorneys' fees) (collectively "Losses") in
connection with the Funds, and:-

(a) Oaktree US Indemnities are not indemnified by the Funds for such Losses under the
indemnification provisions of the applicable Fund Agreements;

(b) such Losses were suffered by virtue of the Sub-Advisor's or its employees' acts or omissions, or
alleged acts or omissions under this Agreement; and

(c) the Sub-Advisor (including its employees) is guilty of negligence or wilful misconduct,

then the Sub-Advisor will hold Oaktree US Indemnities harmless and indemnify it for such Losses;
provided that the Sub-Advisor shall not be liable for actions or omissions to act ordered by Oaktree
US to which the Sub-Advisor objected in writing at the time of such order.

7.2 The provisions of this Clause 7 shall survive the termination of this Agreement.

8. REPRESENTATIONS, WARRANTIES AND UNDERTAKINGS

8.1 Each of Oaktree US and the Sub-Advisor represents and warrants to each other that it is duly
organised, validly existing and in good standing under the laws of its jurisdiction of
incorporation, and is duly authorised by all necessary corporate action to enter into this Agreement
and perform its duties as described in this Agreement.

8.2 The Sub-Advisor hereby undertakes to Oaktree US that it will take all reasonable steps within
its power to remain an authorised person for the purposes of FSMA in respect of the services to be
provided by it hereunder, with a scope of permission which will permit it to carry out its
obligations and exercise its powers under this Agreement, and that it will comply with those FCA
Rules which apply to the services to be provided hereunder.

9. COMPLIANCE WITH FCA RULES

9.1 Oaktree US will be the Sub-Advisor's client for the purposes of the FCA Rules. Accordingly, in
conformity with the FCA Rules, a number of additional statements and provisions are required to be
included in this Agreement. Such additional statements and provisions are set out in Schedule 1
hereof ("Additional FCA Provisions"), which is hereby incorporated into and will form part of this
Agreement and will apply to the services to be provided pursuant to this Agreement with effect from
the Effective Date.

9.2 Nothing in this Agreement shall require or entitle the Sub-Advisor to act as the alternative
investment fund manager (as defined in the FCA Rules with effect from 22 July 2013) of any Fund or
New Fund which is an alternative investment fund. The alternative investment fund manager of each
Fund and New Fund which is an alternative investment fund shall be Oaktree US, unless otherwise
agreed.

5
<!-- page 6 -->
10. TERM

10.1 Basic Term

In relation to each Fund, this Agreement shall terminate on the earlier of (a) the expiration of the
term of such Fund or (b) the date, if any, on which Oaktree US (or any affiliate it has substituted
in its stead in accordance with such Fund's Fund Agreement) is removed as general partner of such
Fund or (c) the Sub-Advisor ceasing to be authorised and regulated by the FCA.

10.2 Early Termination

This Agreement may be terminated, either in respect of a Fund or in its entirety, by either Oaktree
US or the Sub-Advisor for any reason upon 30 days' written notice to the other.

11. TERMINATION CONSEQUENCES

11.1 Upon the termination of this Agreement, the Sub-Advisor shall co-operate with Oaktree US and
take all reasonable steps requested by Oaktree US in making an orderly transition to allow for
continuity of management and to ensure that such termination shall not prejudice the completion of
transactions already initiated.

11.2 The Sub-Advisor shall forthwith upon termination deliver to Oaktree US a full account including
a statement of all investments then under management, the income derived therefrom since the last
report to Oaktree US, and the value at which they were acquired. The Sub-Advisor shall also ensure
that any documents relating to Oaktree US assets over which it has control are released as soon as
practicable to Oaktree US or (if so instructed by Oaktree US) to any other party as may be specified
by Oaktree US.

11.3 Notwithstanding the termination of this Agreement, Oaktree US shall complete, or shall procure
that any successor manager of the Funds shall complete, all investment transactions entered into by
Oaktree US hereunder prior to the termination date.

12. COMPLAINTS PROCEDURE

If Oaktree US has any complaint about the performance of the Sub-Advisor it must notify the
Sub-Advisor Compliance Officer in writing at the address notified in accordance with Clause 13.2 of
this Agreement.

13. MISCELLANEOUS

13.1 Governing Law

This Agreement is governed by the laws of England and Wales.

13.2 Notices

Any notices provided for in this Agreement shall be sent to the following addresses or such other
address as a party may designate in writing:

6
<!-- page 7 -->
To Oaktree US: Oaktree Capital Management, LP 333 South Grand Avenue 28th Floor Los Angeles
California 90071

Attention: Todd Molz, General Counsel Facsimile: +1 (213) 830-8545

To the Sub-Advisor: Oaktree Capital Management (International) Limited Verde, 10 Bressenden Place,
London SW1E 5DH United Kingdom

Attention: Dominic Keenan, Europe Regional Counsel Facsimile: +44 (0) 207 201 4601

All notices delivered by facsimile or hand shall be deemed given on the day received. All notices
mailed shall be deemed to have been given two business days after they have been deposited as
certified mail, return receipt requested, postage paid and properly addressed.

13.3 Assignment

The Sub-Advisor may not assign (within the meaning of the Advisers Act) its rights and obligations
under this Agreement without the prior written consent of Oaktree US.

13.4 Entire Agreement

(a) This Agreement contains the entire agreement between Oaktree US and the Sub-Advisor relating to
the subject matter hereof and supersedes in its entirety all other prior agreements and all
amendments thereto between Oaktree US and the Sub-Advisor relating to the subject matter hereof,
including those agreements referred to in Clause 13.4(b).

(b) For the avoidance of doubt, it is agreed and acknowledged that the Terminated Agreements are
terminated with effect from the Effective Date and all of the parties' obligations and liabilities
will cease with effect from the Effective Date.

13.5 Counterparts

This Agreement may be executed in any number of counterparts and this has the same effect as if the
signatures on the counterparts were on a single copy of this Agreement.

13.6 Third Party Rights

13.7 Indemnified Parties which are not parties to this Agreement shall be entitled to enforce their
respective rights under Clause 7, subject as therein stated. Save to this extent, any rights which
would otherwise arise under the Contracts (Rights of Third Parties) Act 1999 are hereby expressly
excluded.

IN WITNESS whereof the parties have executed and delivered this Agreement as a deed as of the date
appearing on the first page.

7
<!-- page 8 -->
Executed as a deed by Oaktree Capital Management, L.P. ) ) ) )

Authorised Signatory /s/ Todd Molz

Authorised Signatory /s/ Richard Ting

IN WITNESS whereof this deed has been executed and delivered on the date first above written:

Executed as a deed by

Oaktree Capital Management (International) Limited, acting by two directors:

) ) ) ) )

Director

Director

/s/Thomas Ware

/s/Dominic Keenan

8
