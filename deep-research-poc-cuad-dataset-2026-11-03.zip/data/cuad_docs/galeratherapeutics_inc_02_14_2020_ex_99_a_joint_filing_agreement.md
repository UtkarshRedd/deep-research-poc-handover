<!-- page 1 -->
# JOINT FILING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture Agreement |
| Agreement Date | 2020-02-14 |
| Parties | CLARUS IV-A, L.P.; CLARUS IV-B, L.P.; CLARUS IV-C, L.P.; CLARUS IV-D, L.P.; CLARUS IV GP, L.P.; BLACKSTONE CLARUS GP L.P.; BLACKSTONE CLARUS GP L.L.C.; BLACKSTONE HOLDINGS I/II GP L.L.C.; THE BLACKSTONE GROUP INC.; BLACKSTONE GROUP MANAGEMENT L.L.C. |
| Source | CUAD v1 / GALERATHERAPEUTICS,INC_02_14_2020-EX-99.A-JOINT FILING AGREEMENT |

Exhibit A

JOINT FILING AGREEMENT

Pursuant to and in accordance with the Securities Exchange Act of 1934, as amended, and the rules
and regulations thereunder (the "Exchange Act") the undersigned hereby agree to the joint filing of
Clarus IV-A, L.P., Clarus IV-B, L.P., Clarus IV-C, L.P., Clarus IV-D, L.P., Clarus IV GP, L.P.,
Blackstone Clarus GP L.P., Blackstone Clarus GP L.L.C., Blackstone Holdings II L.P., Blackstone
Holdings I/II GP L.L.C., The Blackstone Group Inc., Blackstone Group Management L.L.C. and Stephen
A. Schwarzman, on behalf of each of them of any filing required by such party under Section 13 of
the Exchange Act or any rule or regulation thereunder (including any amendment, restatement,
supplement, and/or exhibit thereto) with respect to securities of Galera Therapeutics, Inc., a
Delaware corporation, and further agree to the filing, furnishing, and/or incorporation by reference
of this Agreement as an exhibit thereto. Each of them is responsible for the timely filing of such
filings and any amendments thereto, and for the completeness and accuracy of the information
concerning such person contained therein; but none of them is responsible for the completeness or
accuracy of the information concerning the other persons making the filing, unless such person knows
or has reason to believe that such information is inaccurate. This Agreement shall remain in full
force and effect until revoked by any party hereto in a signed writing provided to each other party
hereto, and then only with respect to such revoking party. This Agreement may be executed in any
number of counterparts all of which taken together shall constitute one and the same instrument.

IN WITNESS WHEREOF, the undersigned hereby execute this Agreement this 14t h day of February 2020.
CLARUS IV-A, L.P. By: Clarus IV GP, L.P., its general partner By: Blackstone Clarus GP L.P., its
general partner By: Blackstone Clarus GP L.L.C., its general partner

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

CLARUS IV-B, L.P. By: Clarus IV GP, L.P., its general partner By: Blackstone Clarus GP L.P., its
general partner By: Blackstone Clarus GP L.L.C., its general partner

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

CLARUS IV-C, L.P. By: Clarus IV GP, L.P., its general partner By: Blackstone Clarus GP L.P., its
general partner By: Blackstone Clarus GP L.L.C., its general partner

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

[Galera Therapeutics, Inc. - Joint Filing Agreement]
<!-- page 2 -->
CLARUS IV-D, L.P. By: Clarus IV GP, L.P., its general partner By: Blackstone Clarus GP L.P., its
general partner By: Blackstone Clarus GP L.L.C., its general partner

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

CLARUS IV GP, L.P. By: Blackstone Clarus GP L.P., its general partner By: Blackstone Clarus GP
L.L.C., its general partner

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

BLACKSTONE CLARUS GP L.P. By: Blackstone Clarus GP L.L.C., its general partner

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

BLACKSTONE CLARUS GP L.L.C.

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

BLACKSTONE HOLDINGS II L.P. By: Blackstone Holdings I/II GP L.L.C., its general partner

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

BLACKSTONE HOLDINGS I/II GP L.L.C.

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

THE BLACKSTONE GROUP INC.

By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

[Galera Therapeutics, Inc. - Joint Filing Agreement]

BLACKSTONE GROUP MANAGEMENT L.L.C.
<!-- page 3 -->
By: /s/ John G. Finley Name: John G. Finley Title: Chief Legal Officer

/s/ Stephen A. Schwarzman Stephen A. Schwarzman

[Galera Therapeutics, Inc. - Joint Filing Agreement]
