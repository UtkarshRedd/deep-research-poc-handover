# Is our approach the best way? Architecture check against late-2026 evidence — research report (2026-11-02)

**Question.** Is the training-free harness we built (materialized per-query workspace; grep/read agent; ephemeral
1,000-deep BM25 list with paging; clue-decomposition first move; router-gated fan-out for breadth; evidence bank;
outline-first fact-bound writer; tier-1 n-gram alignment + provenance gate + tier-2 grouped review) the
best-evidenced architecture as of late 2026 for deep research over a fixed, pre-filtered set of 500–1,000 contracts
with small open models? What would improve it inside the constraints (no graphs, no persistent index, no training,
no embedding endpoint, 5 minutes), what is worth relaxing a constraint for, what is new in verification, and what
would be novel?

**Method.** Automated deep-research workflow: 5 angles → 25 sources → 124 claims → top 25 adversarially verified by
a 3-vote panel (2 of 3 refutations kill) → 17 confirmed, 8 refuted → 10 findings. Votes and synthesis on Claude Opus
5.5. Companion report: `Retrieval for paraphrased and reasoning-intensive clauses (Nov 2026).md`. Almost every
confirmed claim is a single, author-reported 2025–2026 preprint on closed frontier models over a web corpus; see
Caveats before acting on any number.

## Summary

The design matches the best-evidenced pattern for agentic search over a fixed corpus as of late 2026: a bounded,
materialized workspace, a grep/read agent, a 1,000-deep BM25 list, and a first move that splits the question into
clues. Each part has a 2026 BrowseComp-Plus result behind it: same-model DCI 80.0 % vs 69.0 % for a dense-retrieval
agent; RISE matches DCI at 78 % for about a quarter of the cost; Pi-Serini 83.1 % with BM25 alone; Question's Gambit's
first move lifts that to 90.5 %.

The newest result, **IndexAct (Oct 2026)**, points to the highest-value change inside our constraints: search calls
should stop returning passage text and instead give the agent **persistent result sets with counts** plus
INTERSECT / UNION / DIFFERENCE. On one nano model IndexAct scores 73.5 % vs 67.2 % (DR-DCI) and 62.7 % (Pi-Serini) with
~14K tokens of live context; its ablations credit set composition and counts with ~12 points each. This targets our
enumeration failures without the 4× token cost of fan-out.

For paraphrased clauses, the strongest in-constraint evidence is **query rewriting by an LLM** (gpt-oss-120b): in
legal statutory retrieval it raises BM25 Recall@100 from 0.36 to 0.60 in one round and 0.67 over several. Classical
TF-IDF pseudo-relevance feedback adds only +0.01, so expansion from corpus statistics alone is unpromising unless
seeded by something other than BM25's own top results. Relaxing the no-embedding rule buys the most (dense recall
0.68–0.77 vs 0.36; RARG++ 84 % vs 78 % when an embedder decides which documents grep scans first), but those gains are
single-paper and on closed models. **No verified evidence survived for verification and trust (angle 4), and most
novelty ideas could not be assessed.**

## Verified findings

### 1. Verdict: this architecture family is the best-evidenced one (high; 3–0 on RISE, Pi-Serini, IndexAct; 2–1 on DCI)
- DCI (May 2026): same Claude Sonnet 4.6 backbone, grep/read filesystem agent 80.0 % on all 830 BrowseComp-Plus
  questions vs 69.0 % with a Qwen3-Embedding-8B retriever ($1,016 vs $1,440). Strongest retrieval baseline GPT-5 +
  Qwen3-Embed-8B 71.7 %.
- Pi-Serini: BM25-only agent (k1 = 25, b = 1, 1,000-deep cached ranking paged by offset, line-paged reads, time
  budget) 83.13 % accuracy, 94.70 % surfaced evidence recall with GPT-5.5; best dense agent 73.01 %; on the same model
  (GPT-5) the margin is only 74.58 vs 73.01.
- RISE (June 2026): BM25-bounded workspace matches unbounded DCI at 78 % with gpt-5.4-mini, $0.28 vs $1.10 per query.
- IndexAct (Oct 2026), one GPT-5.4-nano backbone: plain BM25 retrieval-tool agent 30.5 %; dense retrieval-tool agent
  48.2 %; interface-centric agents 53.0–73.5 %. With the backbone fixed, the interface moves accuracy more than the
  retriever.
- Caveats: closed frontier backbones; web corpus; the DCI comparison also changes the harness; DCI is a NeurIPS 2026
  poster (the "Spotlight" label circulating is probably wrong); author-reported.

### 2. The most important correction: result *sets* with counts, not passage text (medium; 3–0 main table, 2–1 ablations)
IndexAct main table (accuracy / evidence coverage / live-context tokens, GPT-5.4 nano high effort): IndexAct
73.5 / 60.7 / 13,960 · RARG 69.4 / 57.2 / 27,896 · DR-DCI 67.2 / 46.6 / 22,435 · DCI-Agent-Lite 63.0 / 43.6 / 30,161 ·
Pi-Serini 62.7 / 55.4 / 10,835 · Sieve 53.0 / 40.8 · BM25 retrieval agent 30.5 / 36.5 / 31,243. Ablations (100 questions;
full 74.0 / 63.9): no set composition 62.0 / 53.1 (and more calls, 54.9 vs 42.9); binary hit feedback instead of counts
62.0 / 55.9; no state reuse 66.0 / 58.4; **auto-preview of text in search results 70.0 / 52.5**; no positional ops
70.0 / 59.1. Mechanism: state-producing operations return a reference, a count and metadata; COUNT_DOCS returns only
a count. Our invariant 8 ("counts, not booleans") is supported. Caveats: four-week-old preprint, single run, authors
ran all baselines; 4-point ablation gaps are noise, only the 8–12-point ones are moderately convincing; the backend is
a standing Lucene index — an ephemeral per-query equivalent over our BM25/grep hit sets is plausible but untested.

### 3. The materialize step is the right shape (medium; 3–0, 3–0, 2–1)
RISE at 100k docs (100 queries, gpt-5.4-mini): RISE 78 % at $0.28 vs DCI 78 % at $1.10 (5 no-answers from caps);
RISE-BM25 without TOCs 77 %. At 1M docs RISE-BM25 holds or improves (mini 77 → 81 %) while DCI on nano falls 71 → 60 %.
A snippet-exposure agent (top-5, 512-token snippets) scores 68 % vs 78 % at similar gold recall (77.5 vs 78.5): the
limitation is "exposing enough of them to the agent", which fits our candidate-recall-1.0-but-answer-missed pattern.
Caveats: n = 100, single judge; the snippet agent also had a full-document tool; at 100k on nano DCI beat RISE.

### 4. A small tool set captures most of the gain (medium; 3–0)
DCI tool-set comparison (100 questions, GPT-5.4 nano): read + grep 61 % at 19 calls / $0.036; Qwen3-Embedding-8B
retrieval agent 45 %; open bash 73 % at 35 calls / $0.102. Bash usage: `rg|head` 56 %, `rg|rg` 21 %, `wc` 8 %, `cat`
0.1 % — chained filters work as an informal set intersection. Implication: a pipeable filter primitive (grep within a
prior hit set) or the IndexAct set-op tool is the missing capability, not open bash. Caveats: the 12-point bash gain is
~1.8 standard errors; no ablation of list_docs or outline exists.

### 5. Approach 1 (deep list + first move) has strong support, with hidden costs (medium; 3–0)
Question's Gambit over Pi-Serini on BrowseComp-Plus (900 s budget): gpt-5.5 83.1 → 90.5; gpt-5.4-mini 68.1 → 79.0;
DeepSeek-v4-pro 71.4 → 76.9. Overhead: median first-move latency 28.5 s (29 % of a 98 s trajectory), ~$0.05 of $0.55;
uncounted: 1 decomposition call, 9.6 GPT-4.1 expansion calls, 9.6 BM25 retrievals at depth 1,000, pointwise reranking
of 2,500 documents with hosted Cohere Rerank 4 Pro; dev-subset median latency 59 → 88 s. Caveats: frontier models, a
budget 3× ours, the reranker must be replaced under our constraints, so the gain is unproven for our stack.

### 6. The paraphrase gap is real (~2× in recall) and LLM rewriting closes most of it (medium; 3–0)
GreekBarRetrieval (NLLP 2026; 283 everyday-language questions vs 6,308 statutory articles), Recall@100: BM25 0.36;
Gemini-001 dense 0.77; best local dense (Euler-Legal-V1) 0.68; Qwen3-8B 0.67. **One-shot rewriting with gpt-oss-120b
lifts BM25 to 0.60**; a ReAct-BM25 loop reaches 0.45 / 0.52 / 0.55 / 0.62 / 0.67 at rounds 1 / 2 / 3 / 5 / 10 (round 10
has the best nDCG@10 but costs ~618k tokens, 20 calls, ~1,598 s — outside a 5-minute budget); one-shot rewriting +
dense costs ~2.9k tokens and 5.1 s. **BM25 + TF-IDF PRF (30 terms from the top 10): 0.36 → 0.37**; dense Rocchio PRF
−0.01; rewriting beat PRF, sparse-dense fusion and translation. Caveats: Greek morphology inflates the lexical gap;
single runs; non-exhaustive gold; the ranking lead partly comes from an LLM observer filtering results; only one PRF
heuristic tested.

### 7. Two more rewriting results with open models of our size (medium; 3–0)
(a) HyDE + Rocchio with gpt-oss-20b (Nov 2025): Recall@20 39.1 on the 9-set low-resource BEIR average vs BM25 34.7,
naive concatenation 33.7, MuGI 36.9, Query2Doc 36.7, BM25 + RM3 36.6 — the real margin is ~+2 over the best
concatenation baseline; here RM3 does help over plain BM25. (b) Structured multi-field rewriting (BoatSE 2026,
Qwen3-Coder-30B): bug-report retrieval MAP@1 0.158 → 0.230, Hit@10 0.713 → 0.813; small effects, possible contamination.
Implication for clue expansion: have the planner emit structured clue fields (defined terms, typical operative
phrasing, party roles, synonyms), weight terms Rocchio-style, keep only terms that occur in the corpus. Two related
claims (large MuGI/Q2D gains with GPT-4.1; "prose-only expansion does not help") were refuted.

### 8. Relaxing the no-embedding rule: embedder as a prior, not a replacement (low; 2–1 RARG, 3–0 GreekBar, 3–0 CeQe)
RARG++ (Jul 2026, BrowseComp-Plus 100k, gpt-5.4-mini): 84 % with 23.9 tool calls vs RISE 78 % (28.7) and DCI 78 %
(99.1) — Qwen3-Embedding-4B ranks document paths, grep scans them in that order, up to 500 matches reranked to 30; at
1M docs 79 % vs 69 %. **Swapping the embedder naively into RISE's search tool scored 69 %, below BM25's 78 %.**
Reranker latency (CeQe, A100, 128 passages): MiniLM 43.5 ms; bge-reranker-v2-m3 409.6 ms. Expected value for us:
probably +5–10 points on paraphrase-heavy retrieval, extrapolated from off-domain closed-model results. Not answered:
whether a cached per-document embedding store counts as a persistent index; ColBERT / learned-sparse costs;
Librarian-style curation.

### 9. Novelty against the verified evidence (low; synthesis)
Already done in close form: set-algebra/count tools (IndexAct, on a persistent Lucene index — a per-query ephemeral
version with small open models, a verbatim evidence bank and contract enumeration is publishable as a
transfer-plus-extension study); clue decomposition with per-clue BM25 (Question's Gambit — open: under 300 s with
small open models and no hosted reranker); per-query dense re-scoring of lexical candidates (close to RARG and CeQe;
only the strictly ephemeral, CPU-cost framing is new). Close negative result: expansion from IDF / co-occurrence
(GreekBar TF-IDF PRF +0.01; CeQe argues seeding from BM25's own top results self-reinforces drift). **The most
defensible novel contribution: expansion from corpus-attested terms seeded by a signal other than BM25's top-k —
verbatim spans already in the evidence bank, or structured clue fields — filtered by attestation and IDF.** Could not
be assessed (no prior art found either way): grid-extract + single-agent hybrids for enumeration; deadline-aware
self-correction driven by deterministic verifier defects (Pi-Serini's time budget steers toward answering but is not
defect-driven); provenance-aware corroboration for amended contracts; evidence-sufficiency stopping.

### 10. Recommended changes, ranked by expected gain per unit of cost (low; synthesis, untested on our stack)
1. **Add a set-state tool and drop text previews from search results** (in-constraint). Fold INTERSECT / UNION /
   DIFFERENCE / COUNT into one flat-schema `set_op` tool to stay at six tools; search returns a handle, a count and
   per-doc counts.
2. **Replace grep + BM25 pseudo-relevance feedback in the first move with one structured planner rewrite per clue,
   weighted Rocchio-style** (in-constraint).
3. **Allow 2–3 bounded rewriting rounds inside the deadline** (in-constraint).
4. **BM25 k1/b for long contracts** (in-constraint, cheap) — but the Pi-Serini claim that tuning gave +18 % was
   refuted 0–3, so treat as an experiment on a held-out split, not a result.
5. **First-move reranker: planner / Nemotron pointwise scoring (reasoning off) or none**; a local cross-encoder
   relaxes the no-embedding constraint.
6. **Local embedder as a grep scan-order prior** (relaxes no-embedding, and no-persistent-index if cached).
7. **Keep fan-out router-gated and re-measure it once set tools exist.**

Experiments in priority order (≥ 3 seeds each; the source papers' n = 100 gaps are within noise):
E1 CUAD paraphrase slice — Recall@100 and latency for current PRF vs one-shot structured rewrite vs Rocchio-weighted
rewrite vs 3-round rewrite · E2 set/count tools + no previews vs the fan-out on enumeration questions — item recall,
tokens, live context · E3 BM25 k1/b sweep on long contracts (held-out) · E4 first-move rerank: none vs pointwise vs local
cross-encoder · E5 local embedder as scan-order prior over ~15k chunks — wall-clock against the 300 s budget.

## Caveats
- Every confirmed claim is a single paper, mostly author-reported 2025–2026 preprints; IndexAct was four weeks old.
  Many comparisons use 100-question subsets without confidence intervals; RARG's RISE and DCI rows are cited, not
  re-run; IndexAct's ablation baseline is never reconciled with its main table.
- All BrowseComp-Plus results use closed backbones (GPT-5.x, Claude Sonnet 4.6, mimo, DeepSeek-v4) on a web corpus;
  transfer to GPT-OSS / Nemotron / Gemma and to contracts is untested. GreekBar is Greek statutory text.
- Question's Gambit depends on a hosted Cohere reranker and GPT-4.1 expansion with a 900 s budget; RARG++ needs a 4B
  embedder.
- **Nothing survived for angle 4** (verification beyond EvidenT / DeepFact / Sauron / CiteAudit, amendment reasoning,
  abstention, audit requirements) nor for production systems (Harvey, Hebbia, Bloomberg), FinanceHarness, learned
  sparse models, contextual prefixes, IterResearch-style context rebuilding, advisor patterns, long-context routing,
  embedding cost at ~15k chunks, or the cache-as-index question. "Not found" means "not assessed".
- Several verifiers ran out of web-search budget, so no contradicting evidence was sought for some claims.
- The BrowseComp-Plus leaderboard moves monthly; dense entries above 73 % may exist (one listing: GPT-5 +
  MixedbreadSearch 78.41 %).

## Open questions
1. Do the interface gains (IndexAct sets, RISE workspace, Question's Gambit first move) carry over to our models under
   300 s on CUAD-style contracts, and how much of the first move's gain survives without Cohere Rerank 4 Pro?
2. Can expansion be seeded from evidence-bank spans or structured clue fields and filtered by corpus attestation, and
   how large is the lexical-vs-dense gap on *English* contracts?
3. What is the current state of verification and trust for regulated deep research beyond the four systems we built on?
4. What do per-query local embedding (~15k chunks) and cross-encoder reranking cost in wall-clock on available
   hardware, and is a cached per-document embedding store acceptable under "no persistent index"?

## Claims that did NOT survive verification (do not cite these)
| Claim | Vote | Source |
|---|---|---|
| Dense embedder works best only as an execution prior for grep (scan order, entry points, match reranking) | 1–2 | arXiv 2607.24223 |
| DCI trades gold-document coverage (28.0 vs 56.7) for localization, explaining enumeration failures | 0–3 | arXiv 2605.05242 |
| **Pi-Serini ablation: BM25 tuning +18 % accuracy, depth +25.3 % surfaced recall** | **0–3** | ricky42613.github.io/piserini |
| Harness alone lifts GPT-5 + BM25 from 58.31 % to 74.58 % and cuts cost 3.3–10× | 0–3 | ricky42613.github.io/piserini |
| MuGI / Q2D / CSQE pseudo-documents give large BM25 gains (0.421 → 0.526 nDCG@10 on BEIR) | 1–2 | arXiv 2604.27421 |
| BM25 + LLM expansion reaches dense-retriever effectiveness (0.526 vs 0.528) | 0–3 | arXiv 2604.27421 |
| Cross-encoder query expansion raises BM25 Recall@100 on NQ 0.32 → 0.47 without re-indexing | 0–3 | arXiv 2608.00452 |
| Prose-only paraphrase expansion does not help BM25 (LCA MAP@1 0.154 vs 0.158) | 0–3 | arXiv 2512.07022 |

## Sources fetched (25)
arXiv 2610.07960 (IndexAct) · 2606.06880 (RISE) · 2607.24223 (RARG++) · 2605.05242 (DCI) · ricky42613.github.io/piserini
and arXiv 2605.10848 (Pi-Serini) · 2609.14412 (Question's Gambit) · 2608.18752 (GreekBarRetrieval) · 2604.27421 (LLM
pseudo-document expansion) · github.com/saundaryaverma/Clausewise · 2608.00452 (CeQe) · 2512.07022 (BoatSE) ·
2511.19349 (HyDE + Rocchio) · 2508.06600 (BrowseComp-Plus) · anthropic.com contextual retrieval · 2610.22273 (Librarian
Agents) · aclanthology 2026.emnlp-main.509 (evidence laundering) · 2605.28044 · 2608.08512 (TIDE) · 2609.37469 ·
2606.09748 · 2607.17641 · 2608.02009 · 2602.18425 · 2511.07327 (IterResearch).

Run statistics: 5 angles, 25 sources, 124 claims, 25 verified, 17 confirmed, 8 refuted, 10 findings, 107 agent calls.
Workflow run id `wf_d286ae27-4c4`; per-agent returns in that run's `journal.jsonl`.
