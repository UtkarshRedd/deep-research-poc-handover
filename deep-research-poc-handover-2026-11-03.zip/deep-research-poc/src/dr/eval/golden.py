"""Golden set schema + loader. data/golden/questions.jsonl, one object per line.

Gold documents are referenced by `<file-stem>` placeholders (doc_ids are content hashes computed at
load time, so a checked-in question cannot name them). `resolve_gold_docs` maps the placeholders to
real ids via each `DocRecord.source_path` stem; `load_golden(path, docs=...)` does it on load.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

from ..models import DocRecord

QType = Literal["single", "multihop", "identifier", "coverage", "not_in_corpus", "temporal"]

_PLACEHOLDER_RE = re.compile(r"^<([^<>]+)>$")


class GoldDoc(BaseModel):
    doc_id: str = Field(description="real doc_id, or '<file-stem>' placeholder before resolution")
    pages: list[int] = Field(default_factory=list)


class GoldenQuestion(BaseModel):
    qid: str
    type: QType
    question: str
    gold_docs: list[GoldDoc] = Field(default_factory=list)
    gold_answer: str | None = None
    gold_items: list[str] = Field(default_factory=list, description="for coverage questions")
    rubric: list[str] = Field(default_factory=list)
    notes: str = ""
    absent_terms: list[str] = Field(
        default_factory=list,
        description="for not_in_corpus questions: strings whose absence from the corpus makes abstention correct",
    )


def placeholder_stem(doc_id: str) -> str | None:
    """'<acme_credit_agreement>' -> 'acme_credit_agreement'; None if `doc_id` is not a placeholder."""
    m = _PLACEHOLDER_RE.match(doc_id.strip())
    return m.group(1) if m else None


def resolve_gold_docs(questions: list[GoldenQuestion], docs: list[DocRecord]) -> list[GoldenQuestion]:
    """Return copies of `questions` with every '<file-stem>' placeholder replaced by the doc_id of the
    DocRecord whose source_path has that stem. Already-real ids pass through. Raises ValueError on a
    placeholder with no (or more than one) matching document."""
    by_stem: dict[str, list[str]] = {}
    for d in docs:
        if d.source_path:
            by_stem.setdefault(Path(d.source_path).stem, []).append(d.doc_id)
    out: list[GoldenQuestion] = []
    problems: list[str] = []
    for q in questions:
        q2 = q.model_copy(deep=True)
        for gd in q2.gold_docs:
            stem = placeholder_stem(gd.doc_id)
            if stem is None:
                continue
            ids = by_stem.get(stem, [])
            if len(ids) != 1:
                problems.append(f"{q.qid}: <{stem}> matches {len(ids)} documents")
                continue
            gd.doc_id = ids[0]
        out.append(q2)
    if problems:
        raise ValueError("unresolvable gold_docs placeholders: " + "; ".join(problems))
    return out


def load_golden(path: Path, docs: list[DocRecord] | None = None) -> list[GoldenQuestion]:
    out = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.strip():
            out.append(GoldenQuestion(**json.loads(line)))
    types = {q.type for q in out}
    if "not_in_corpus" not in types:
        raise ValueError("golden set must include not_in_corpus questions (>= 10%)")
    if docs is not None:
        out = resolve_gold_docs(out, docs)
    return out
