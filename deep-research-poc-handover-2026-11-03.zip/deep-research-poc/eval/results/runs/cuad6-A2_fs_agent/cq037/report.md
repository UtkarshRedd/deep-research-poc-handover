# When does the Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONA...

*Question:* When does the Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONAL TEST SYSTEMS, INC. (filed 2000-07-26) expire, according to its term clause?

## Locate the Distributor Agreement

The Distributor Agreement between COMWARE TECHNICAL SERVICES ("COMWARE") and INTERNATIONAL TEST SYSTEMS, INC. [uncited] ("ITS") was filed on 2000-07-26. [ce581d56506a6a52 p.1] The agreement includes a renewal period provision stating that COMWARE must purchase a minimum of $45,420.00 worth of Products. [ce581d56506a6a52 p.1]

[GAP] The term clause specifying the expiration date of the agreement is not present in the provided evidence.

## Find the term clause

The term clause defines the Initial Distribution Period as April 15, 2000 through October 15, 2000. [ce581d56506a6a52 p.1] The agreement states this period covers six months from the Effective Date. [ce581d56506a6a52 p.1] The Effective Date is the earlier of the date Comware orders and pays for a minimum of $22,710 worth of Products or April 15, 2000. [ce581d56506a6a52 p.1] Since the Effective Date is April 15, 2000 or earlier, it is before the filing date of 2000-07-26. [ce581d56506a6a52 p.1]

[GAP] The evidence does not state whether the agreement expires after the Initial Distribution Period or if it renews.

## Not established by the evidence

[GAP] No evidence was found for: Extract the exact expiration date stated in the term clause

## Verification appendix

Claims: 10 · supported: 6 · partially: 0 · dropped: 0 · gaps: 4 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Determine expiration date

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  | no evidence cited |
| s1.2 | s1 | keep | 1.00 | e1→[ce581d56506a6a52 p.1] |  |
| s1.3 | s1 | keep | 1.00 | e3→[ce581d56506a6a52 p.1] |  |
| s1.4 | s1 | gap |  |  |  |
| s2.1 | s2 | keep | 1.00 | e2→[ce581d56506a6a52 p.1] |  |
| s2.2 | s2 | keep | 1.00 | e2→[ce581d56506a6a52 p.1] |  |
| s2.3 | s2 | keep | 1.00 | e2→[ce581d56506a6a52 p.1] |  |
| s2.4 | s2 | keep | 1.00 | e2→[ce581d56506a6a52 p.1] |  |
| s2.5 | s2 | gap |  |  |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [ce581d56506a6a52 p.1 L6-7] keep (1.0): "| SEC Filing Date | 2000-07-26 |
| Parties | COMWARE TECHNICAL SERVICES ("COMWARE"); INTERNATIONAL TEST SYSTEMS, INC. ("ITS") |"
- e2 [ce581d56506a6a52 p.1 L23-36] keep (1.0): "2. DEFINITIONS:

INITIAL DISTRIBUTION PERIOD: April 15, 2000 through October 15, 2000 (6 Months from the Effective Date)

PRODUCTS: The CircuiTest 2000S In-Circuit Test System

The CircuiTest 2100 Scanner Expansion

EXCLUSIVE TERRITORIES: T…"
- e3 [ce581d56506a6a52 p.1 L78-78] keep (1.0): "4. RENEWAL PERIOD: Provided that COMWARE purchases a minimum of $45,420.00 worth of Products, in any"
