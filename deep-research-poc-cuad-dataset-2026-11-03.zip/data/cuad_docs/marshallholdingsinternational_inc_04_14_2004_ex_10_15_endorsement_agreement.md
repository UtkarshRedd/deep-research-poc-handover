<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 2003-11-01 |
| Parties | Bruce Jenner ("CELEBRITY"); The Right Solution ("COMPANY") |
| Source | CUAD v1 / MARSHALLHOLDINGSINTERNATIONAL,INC_04_14_2004-EX-10.15-ENDORSEMENT AGREEMENT |

EXHIBIT 10.15

ENDORSEMENT AGREEMENT

This ENDORSEMENT AGREEMENT (the "Agreement") is made this 1st day of --- November, 2003 by and
between Bruce Jenner, Individual ("CELEBRITY"), with his offices located in California; and The
Right Solution, a Nevada Corporation (the COMPANY), with its offices located at 3035 East Patrick
Lane, Suite 14, Las Vegas, Nevada 89120.

WHEREAS, CELEBRITY has experience in public speaking and marketing and

WHEREAS, the COMPANY desires to do business with the CELEBRITY and

NOW, THEREFORE, in consideration of the mutual promises, covenants and agreements contained herein,
and for other good and valuable consideration, the receipt and sufficiency of which is hereby
acknowledged, the COMPANY and CELEBRITY agree as follows:

1. ENGAGEMENT The COMPANY agrees to a one year engagement to contract the CELEBRITY to speak at the
company meetings and seminars along with endorsement of the Company products.

2. The CELEBRITY will be limited to six speaking engagements for the year and five conference calls
per month at the company's discretion.

3. The CELEBRITY will assist in getting a distributorship started through his contacts and fan mail.
The CELEBRITY can designate the party placed in the distributorship direct to the Company. This
distributorship will be independent of the endorsement terms of the agreement and will remain on
going as long as the CELEBRITY maintains the annual membership fee.

4. TERMS FOR THE COMPANY

(i) The COMPANY will flag the CELEBRITY center at level six for a six month period. COMPANY will
provide the necessary time to work with the business on products, strategies and opportunity. Jack
Zufelt will coordinate all efforts and work direct with the CELEBRITY and or the designee.

(ii) The COMPANY will provide products at no cost for use by the CELEBRITY for personal use
throughout the duration of this agreement. COMPANY will pay $10,000 upfront to begin representation
and support of the CELEBRITY.

(iii) CELEBRITY will receive $6,000 per month for entire duration of the agreement. The COMPANY will
give stock to the CELEBRITY which will be restricted for one year from issuance and will be as
follows:

Monthly Sales Volume Stock Options -------------------- ------------- $ 300,000 300,000 shares
600,000 600,000 shares 1,000,000 1,000,000 shares These stock options will remain in place until
certificates are issued once volumes are met as long as the CELEBRITY maintains the distributorship
by paying the annual dues of $15.00.

(iv) The terms of this agreement will remain confidential between CELEBRITY and the COMPANY unless
written permission is granted for release by both parties.

(v) Travel arrangements and accommodations will be provided by the COMPANY. This will be first class
accommodations when available.

TERMS FOR THE CELEBRITY

Work with Jack Zufelt to develop a business strategy that can be implemented within 30 days of the
signing of this agreement. (i) Identify marketing platform to recruit new distributors (ii) Develop
a recruiting packet for new recruits that are duplicable with most tools coming from the corporate
website and / or inventory. (iii) CELEBRITY will be available for phone conferences and meeting
participating at any level deemed necessary by the COMPANY. (iv) CELEBRITY will be available for
conference calls not to exceed five per month and at the discretion of his schedule. (v) The terms
of this agreement will remain confidential between CELEBRITY and the COMPANY unless written
permission is granted for release by both parties.

INDEPENDENT CONTRACTOR CELEBRITY and CELEBRITY Personnel will act as an independent contractor in
the performance of its duties under this Agreement. Accordingly, CELEBRITY will be responsible for
payment of all federal, state, and local taxes on compensation paid under this Agreement, including
income and social security taxes, unemployment insurance, and any other taxes due relative to
Distributor's Personnel and any and all business license fees as may be required. This Agreement
neither expressly nor impliedly creates a --- relationship of principal and agent, or employee and
employer, between Distributor's Personnel and the COMPANY. Neither CELEBRITY nor CELEBRITY Personnel
are authorized to enter into any agreements on behalf of the
<!-- page 2 -->
COMPANY. The COMPANY expressly retains the right to approve, in its sole discretion, each Asset
Opportunity or Business Opportunity introduced by CELEBRITY, and to make all final decisions with
respect to effecting a transaction on any Business Opportunity.

6. TERMINATION

The COMPANY and CELEBRITY may terminate this Agreement under the following conditions:

(A) By the COMPANY. --------------

(i) If during the Term of this Agreement the CELEBRITY is unable to provide the Services as set
forth herein for thirty (30) consecutive business days because of illness, accident, or other
incapacity of CELEBRITY Personnel; or,

(ii) If CELEBRITY willfully breaches or neglects the duties required to be performed hereunder; or,

(B) By CELEBRITY ------------

(i) If the COMPANY fails to make any payments or provide information required hereunder; or,

(ii) If the COMPANY ceases business or, other than in an Initial Merger, sells a controlling
interest to a third party, or agrees to a consolidation or merger of itself with or into another
corporation, or enters into such a transaction outside

of the scope of this Agreement, or sells substantially all of its assets to another corporation,
entity or individual outside of the scope of this Agreement; or,

(iii) If the COMPANY subsequent to the execution hereof has a receiver appointed for its business or
assets, or otherwise becomes insolvent or unable to timely satisfy its obligations in the ordinary
course of, including but not limited to the obligation to pay the Initial Fee, the Transaction fee,
or the CELEBRITY Fee; or,

7. INDEMNIFICATION

Subject to the provisions herein, the COMPANY and CELEBRITY agree to indemnify, defend and hold each
other harmless from and against all demands, claims, actions, losses, damages, liabilities, costs
and expenses, including without limitation, interest, penalties and attorneys' fees and expenses
asserted against or imposed or incurred by either party by reason of or resulting from any action or
a breach of any representation, warranty, covenant, condition, or agreement of the other party to
this Agreement. The CELEBRITY will have full release of liability in regards to product performance
and/or law suites resulting from use of the product. This liability will remain the responsibility
of the COMPANY and manufacturers.

8. MISCELLANEOUS

(i) Subsequent Events. CELEBRITY and the COMPANY each agree to notify the ----------------- other
party if, subsequent to the date of this Agreement, either party incurs obligations which could
compromise its efforts and obligations under this Agreement.

(ii) Amendment. This Agreement may be amended or modified at any time and --------- in any manner
only by an instrument in writing executed by the parties hereto.

(iii) Further Actions and Assurances. At any time and from time to time,
------------------------------ each party agrees, at its or their expense, to take actions and to
execute and deliver documents as may be reasonably necessary to effectuate the purposes of this
Agreement.

(iv) Waiver. The party to whom such compliance is owed may waive any ------ failure of any party to
this Agreement to comply with any of its obligations, agreements, or conditions hereunder in
writing. The failure of any party to this Agreement to enforce at any time any of the provisions of
this Agreement shall in no way be construed to be a waiver of any such provision or a waiver of the
right of such party thereafter to enforce each and every such provision. No waiver of any breach of
or noncompliance with this Agreement shall be held to be a waiver of any other or subsequent breach
or noncompliance.

(v) Assignment. Neither this Agreement nor any right created by it shall ---------- be assignable by
either party without the prior written consent of the other or as stated herein.
<!-- page 3 -->
(vi) Notices. Any notice or other communication required or permitted by ------- this Agreement must
be in writing and shall be deemed to be properly given when delivered in person to an officer of the
other party, when deposited in the United States mails for transmittal by certified or registered
mail, postage prepaid, or when deposited with a public telegraph COMPANY for transmittal, or when
sent by facsimile transmission charges prepared, provided that the communication is addressed:

(A) In the case of the COMPANY: The Right Solution 3095 East Patrick Lane, Suite 14 Las Vegas,
Nevada 89120

(B) In the case of the CELEBRITY: Bruce Jenner 2345 Elbury Court Lake Sherwood, CA 91361

or to such other person or address designated in writing by the COMPANY or CELEBRITY to receive
notice.

9. Governing Law. This Agreement was negotiated and is being contracted ------------- for in Nevada,
and shall be governed by the laws of the State of Nevada, and the United States of America,
notwithstanding any conflict-of-law provision to the contrary.

10. Binding Effect. This Agreement shall be binding upon the parties -------------- hereto

11. Entire Agreement. This Agreement contains the entire agreement ---------------- between the
parties hereto and supersedes any and all prior agreements, arrangements, or understandings between
the parties relating to the subject matter of this Agreement. No oral understandings, statements,
promises, or inducements contrary to the terms of this Agreement exist. No representations,
warranties, covenants, or conditions express or implied, other than as set forth herein, have been
made by any party.

12. Severability. If any part of this Agreement is deemed to be ------------ unenforceable the
balance of the Agreement shall remain in full force and effect.

13. Counterparts. A facsimile, telecopy, or other reproduction of this ------------ Agreement may be
executed simultaneously in two or more counterparts, each of which shall be deemed an original, but
all of which together shall constitute one and the same instrument, by one or more parties hereto
and such executed copy may be delivered by facsimile or similar instantaneous electronic
transmission device pursuant to which the signature of or on behalf of such party can be seen. In
this event, such execution and delivery shall be considered valid, binding and effective for all
purposes. At the request of any party hereto, all parties agree to execute an original of this
Agreement as well as any facsimile, telecopy or other reproduction hereof.

IN WITNESS WHEREOF, the parties have executed this Agreement on the date above written.

The COMPANY CELEBRITY The Right Solution Bruce Jenner A Nevada Corporation Independent
Contractor/COMPANY

By ____________________________ By _________________________________ Rick Bailey President / CEO
