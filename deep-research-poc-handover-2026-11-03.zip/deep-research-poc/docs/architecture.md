# Architecture — one page

Agentic deep research over a pre-filtered set of 500–1,000+ documents, producing a page-cited
report in ≤ 5 minutes. No knowledge graph, no persistent index, no training. Three retrieval
approaches share one pipeline; the `variant` selects the research branch.

Rendered diagrams (2026-11-03): `docs/diagrams/architecture_overview.html` (three SVGs, light and dark) and the
PNGs `architecture_pipeline.png`, `architecture_research_loop.png`, `architecture_writer_verify.png` in the same
folder. Regenerate the PNGs by screenshotting that page with a headless browser after editing the SVGs.

```mermaid
flowchart LR
    IN[Input docs<br/>markdown + metadata<br/>page markers] --> MAT[Materialize<br/>workspace: docs/&lt;id&gt;.md,<br/>manifest, line→page map]
    MAT -->|A2| RES
    MAT -->|A1, A3| FM[First move<br/>planner → clues<br/>grep + BM25 in the harness<br/>opening observation + deep ranking]
    FM --> RT{Route<br/>single · breadth · long_context<br/>code guards}
    RT -->|single| RES[Research: ReAct loop<br/>A2: grep · read · outline · list_docs<br/>A1: search · page_results · grep · read<br/>+ add_evidence · submit]
    RT -->|breadth, Phase 5| FAN[Fan-out researchers<br/>+ extract grid]
    RES --> EB[(Evidence bank<br/>verbatim quotes<br/>doc · page · lines)]
    FAN --> EB
    EB --> WR[Write<br/>outline from question<br/>revise + assign evidence<br/>sections → claims with CITE ids]
    WR --> V1[Verify tier 1<br/>5-gram alignment<br/>keep · truncate · drop]
    V1 --> V2[Verify tier 2 + provenance<br/>grouped agentic check<br/>near-duplicate gate, Phase 7]
    V2 --> OUT[Report<br/>cited markdown + appendix<br/>trace.jsonl · evidence.jsonl · verify.json]
    DL[Deadline 300 s<br/>stage budgets, forced synthesis] -.-> RES
    DL -.-> WR
    EV[Eval harness<br/>golden sets: synthetic 31 docs, CUAD 510<br/>recall · support rate · cost per correct] -.-> OUT
```

## Stages

| Stage | Who runs it | What it does | Code |
|---|---|---|---|
| Materialize | harness | Writes each document as line-addressable markdown, builds the manifest and the line→page map; opens the evidence bank and trace | `dr/workspace.py`, `dr/evidence.py` |
| First move (A1, A3) | planner model + harness | One model call decomposes the question into clues; the harness runs grep and BM25 per clue in parallel, ranks candidate documents, and writes the opening observation; the question's deep ranking is cached for paging | `dr/agents/first_move.py`, `dr/tools/bm25.py` |
| Route | router model + guards | Proposes single / breadth / long_context; code refuses long_context above the token estimate and builds doc batches for breadth | `dr/agents/router.py` |
| Research | researcher model | Single ReAct loop with ≤ 6 tools, per-turn width message (wide → narrow), call budget and floor, repeat short-circuit, offload, compaction, forced submit at the deadline | `dr/agents/researcher.py`, `dr/tools/*` |
| Evidence bank | harness | The only state the writer reads: verbatim quotes with doc id, page and line range; quotes are checked against the window when saved | `dr/evidence.py` |
| Write | writer model | Outline from the question alone → one revision pass that assigns evidence → section drafts bound to their evidence → sentence-level claims; markdown is rendered from claims | `dr/agents/writer.py` |
| Verify | harness (+ verifier model later) | Tier 1 aligns every cited quote to its page; dropped claims are replaced by a marker, never silently kept; appendix lists every claim | `dr/verify/tier1.py`, `dr/verify/report.py` |
| Graph + deadline | harness | LangGraph pipeline; research gets what is left after reserving write + verify + reserve; writer skips revision when short; every model call is capped by its stage deadline | `dr/graph.py`, `dr/config.py` |
| Eval | harness + judge model | Golden sets with placeholder doc ids resolved at load; candidate and opened-or-cited recall, tier-1 support rate, hallucination gate, cost per correct answer | `dr/eval/*`, `data/golden/*` |

## Models (roles, not names)

| Role | Used for | Intended model | Free-tier stand-in (NVIDIA Build) |
|---|---|---|---|
| planner / router / researcher | tool calling and reasoning | GPT-OSS 120B | Nemotron 3.5 Super |
| extractor / verifier | many cheap parallel calls | Nemotron Nano | Nemotron 3.5 Lightning |
| writer / judge | prose and grading, no tools | Gemma | Nemotron 3.5 Super (Gemma ids time out) |

Only `dr/llm.py` knows endpoints and model ids; `.env` holds the current mapping.

## Status (2026-11-01)

Done and live-tested: materialize, research loop (A2), writer, tier-1 verification, graph with
deadline, first move with clue expansion + router + A1 variant, synthetic golden set (31 docs,
42 questions), the CUAD real-document corpus (510 contracts, 112 questions, 12-question smoke set),
fan-out + extract grid (Phase 5), the three-way eval runner (Phase 6), and tier 2 + the provenance
gate (Phase 7: grouped claim review, near-duplicate clustering, seeded check 10/10). Not started:
hardening (Phase 8) and the long-context router branch. Running log: `docs/findings.md`.
