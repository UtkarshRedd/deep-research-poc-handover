<!-- page 1 -->
# CONTENT LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2005-11-03 |
| Parties | PACIFICAP ENTERTAINMENT ("Licensor"); THE HENRY FILM AND ENTERTAINMENT CORPORATION ("Licensee") |
| Source | CUAD v1 / PacificapEntertainmentHoldingsInc_20051115_8-KA_EX-1.01_4300894_EX-1.01_Content License Agreement |

PACIFICAP ENTERTAINMENT Agreement with THE HENRY FILM AND ENTERTAINMENT CORPORATION

CONFIDENTIAL

Page 1 of 6

CONTENT LICENSE AGREEMENT

This Content License Agreement is between THE HENRY FILM AND ENTERTAINMENT CORPORATION, located at
2809 Unicornio, Carlsbad, CA, 92009 and PACIFICAP ENTERTAINMENT' located at 12868 Via Latina, Del
Mar, CA 92014

Licensor: PACIFICAP ENTERTAINMENT Licensee THE HENRY FILM AND ENTERTAINMENT CORPORATION

THIS CONTENT LICENSE AGREEMENT (the "Agreement".) is made as of this 3rd day of November, 2005 In
consideration of the mutual, promises contained herein, the parties agree as follows:

GRANT OF LICENSE

Subject to the terms and conditions of this Agreement, PACIFICAP ENTERTAINMENT hereby grants to THE
HENRY FILM AND ENTERTAINMENT CORPORATION, under PACIFICAP ENTERTAINMENT'S full ownership and or
fully authorized licensing Rights of Content

(a) A 10 year exclusive, worldwide license to use, modify, reproduce, distribute, display and
transmit any and all PACIFICAP ENTERTAINMENT nostalgic television show library Content. The
Pacificap Entertainment Content shall be used to create a number of television shows, DVD Magazines,
Internet Streaming Video Television Shows, Television Shorts, Radio Shows, Radio Shorts, Cell Phone
Video Clips. Caller ID Video Clips, Promotional Commercials, Websites, Streaming Video Commercials,
Streaming Video Highlight Shows, 24 Hour Nostalgia Sports Network, DVD Program Package, Television
Show Series, stock footage library, and print promotional posters

PACIFICAP ENTERTAINMENT AGREES that all television shows, DVD Magazines, Internet Streaming Video
Television Shows, Television Shorts, Radio Shows, Radio Shorts, Cell Phone Video Clips, Caller ID
Video Clips, Promotional Commercials, Websites, Streaming Video Commercials, Streaming Video
Highlight Shows, 24 Hour Nostalgia Sports Network, DVD Program Package, Television Show Series,
stock footage library, and print promotional posters, created and or produced with any content
provided by PACIFICAP ENTERTAINMENT are wholly owned by THE HENRY FILM AND ENTERTAINMENT
CORPORATION.

PACIFICAP ENTERTAINMENT agrees to also allow THE HENRY FILM AND ENTERTAINMENT CORPORATION the right
to redistribute, reproduce, retransmit, disseminate, sell, publish, broadcast or circulate the
information contained in such PACIFICAP ENTERTAINMENT Content. THE HENRY FILM AND ENTERTAINMENT
CORPORATION agrees to use its best efforts to restrict the uses of PACIFICAP ENTERTAINMENT Content
by visitors to its Web Pages to personal use of such Content and not for further commercial
redistribution.

NOTICES: PACIFICAP ENTERTAINMENT will not alter or impair any acknowledgment of copyright or other
Intellectual Property Rights of THE HENRY FILM AND ENTERTAINMENT CORPORATION, that may appear in the
PACIFICAP ENTERTAINMENT website and the PACIFICAP ENTERTAINMENT Brand Features, including all
copyright, trademark and similar notices that THE HENRY FILM AND ENTERTAINMENT CORPORATION may
reasonably request.

Initialed THE HENRY FILM AND ENTERTAINMENT CORPORATION:_______

Initialed PACIFICAP ENTERTAINMENT:______ Page 1 of 6

Source: PACIFICAP ENTERTAINMENT HOLDINGS INC, 8-K/A, 11/15/2005

PACIFICAP ENTERTAINMENT Agreement with THE HENRY FILM AND ENTERTAINMENT CORPORATION...
<!-- page 2 -->
CONFIDENTIAL

Page 2of 6

All notices, requests, demands, reports or other communications under this Agreement shall be in
writing and may be sent by mail, facsimile, or authorized electronic address to the offices
specified below. Notices hereunder shall be directed to: For PACIFICAP ENTERTAINMENT: Attention Ed
Litwak, Pacificap, Entertainment Inc., 12868 Via Latina, Del Mar, CA 92014 Email Address
COSM@sbcglobal.net. For THE HENRY FILM AND ENTERTAINMENT CORPORATION, notices shall be sent to the
attention of Michael Henry, Executive Producer, 2809 Unicornio, Carlsbad, CA 92009 Email Address
3impact@adelphia.net.

DELIVERY OF PACIFICAP ENTERTAINMENT CONTENT AND SHARED REVENUE

PACIFICAP ENTERTAINMENT'S RESPONSIBILITIES. PACIFICAP ENTERTAINMENT will be responsible for the
delivery of all requested content less shipping and handling. Content will be delivered in the
digital media form of DVCAM or other requested digital format. PACIFICAP ENTERTAINMENT will provide
on-going assistance to THE HENRY FILM AND ENTERTAINMENT CORPORATION, with regard to technical,
administrative and service-oriented issues relating to the utilization, transmission and maintenance
of the PACIFICAP ENTERTAINMENT Content, as THE HENRY FILM AND ENTERTAINMENT CORPORATION may
reasonably request. PACIFICAP ENTERTAINMENT will use its reasonable best efforts to ensure that the
PACIFICAP ENTERTAINMENT Content is available at the request of THE HENRY FILM AND ENTERTAINMENT
CORPORATION.

SHARED REVENUE: In lieu of PACIFICAP ENTERTAINMENT granting a 10 year Exclusive Content License to
THE HENRY FILM AND ENTERTAINMENT CORPORATION, THE HENRY FILM ANDENTERTAINMENT CORPORATION agrees to
share 10% of the net revenue from any and all advertising sales, Syndication Fees and Licensing fees
generated from all television shows, DVD Magazines, Internet Streaming Video Television Shows,
Television Shorts, Radio Shows, Radio Shorts, Cell Phone Video Clips, Caller ID Video Clips,
Promotional Commercials, Websites, Streaming Video Commercials, Streaming Video Highlight Shows, 24
Hour Nostalgia Sports Network, DVD Program Package, Television Show Series, stock footage library,
and print promotional posters, created and or produced with any content provided by PACIFICAP
ENTERTAINMENT.

Revenue is described as all revenue generated from all content including broadcast and disk media,
print and online properties. Net Revenue is the portion of revenue left after all costs associated
with production, advertising, promotion and commissions which constitute the costs of sale.

Within 30 days of the end of each quarter during the term of this agreement, PACIFICAP ENTERTAINMENT
shall receive from THE HENRY FILM AND ENTERTAINMENT CORPORATION, a detailed accounting statement
showing Net Due and Paid Shared Revenues for that quarter and shall remit to PACIFICAP ENTERTAINMENT
its share of such revenues.

PERFORMANCE: In lieu of PACIFICAP ENTERTAINMENT granting a 10 year Exclusive Content License to THE
HENRY FILM AND ENTERTAINMENT CORPORATION, THE HENRY FILM AND ENTERTAINMENT CORPORATION agrees to
share a minimum of $50,000.00 annually for each year of this Agreement. In the event of THE HENRY
FILM AND ENTERTAINMENT CORPORATION, not fulfilling this minimum PERFORMANCE, PACIFICAP ENTERTAINMENT
may cancel this Agreement

Initialed THE HENRY FILM AND ENTERTAINMENT CORPORATION:______

Initialed PACIFICAP ENTERTAINMENT:______

Page 2 of 6

Source: PACIFICAP ENTERTAINMENT HOLDINGS INC, 8-K/A, 11/15/2005

PACIFICAP ENTERTAINMENT Agreement with THE HENRY FILM AND ENTERTAINMENT CORPORATION
<!-- page 3 -->
CONFIDENTIAL

Page 3 of 6

INDEMNIFICATION

PACIFICAP ENTERTAINMENT, at its own expense, will indemnify, defend and hold harmless Michael Henry,
THE HENRY FILM AND ENTERTAINMENT CORPORATION, its Affiliates and their employees, representatives,
agents and agent affiliates, against any claim, suit, action, or other proceeding brought against
THE HENRY FILM AND ENTERTAINMENT CORPORATION, or an Affiliate based on or arising from any claim
that PACIFICAP ENTERTAINMENT Content as delivered to THE HENRY FILM AND ENTERTAINMENT CORPORATION or
any PACIFICAP ENTERTAINMENT Brand Feature infringes in any manner any third party Ownership Rights
or Ownership Issues, Intellectual Property Right of any third party or contains any material or
information that is defamatory, libelous, slanderous, that violates any person's right of publicity,
privacy or personality, or has otherwise resulted in any injury, damage or harm to any person;
provided, however, that in any such case: (x) THE HENRY FILM AND ENTERTAINMENT CORPORATION provides
PACIFICAP ENTERTAINMENT with prompt notice of any such claim; (y) PACIFICAP ENTERTAINMENT permits
THE HENRY FILM AND ENTERTAINMENT CORPORATION. . to assume and control the defense of such action,
with counsel chosen by PACIFICAP ENTERTAINMENT (who shall be reasonably acceptable to THE HENRY FILM
AND ENTERTAINMENT CORPORATION. .); and (z) THE HENRY FILM AND ENTERTAINMENT CORPORATION does not
enter into any settlement or compromise of any such claim without PACIFICAP ENTERTAINMENT'S prior
written consent. PACIFICAP ENTERTAINMENT will pay any and all costs, damages, and expenses,
including, but not limited to, reasonable attorneys' fees and costs awarded against or otherwise
incurred by Michael Henry, Melba Henry, THE HENRY FILM AND ENTERTAINMENT CORPORATION or any
employees, representatives, agents and agent affiliates in connection with or arising from any such
claim, suit, action or proceeding.

TERM AND TERMINATION

INITIAL TERM AND RENEWALS: This Agreement will become effective as of the last date of signature
(Effective Date) and shall, unless sooner terminated as provided below or as otherwise agreed,
remain effective for an initial term of 10 Years following the first date of public availability of
the PACIFICAP ENTERTAINMENT Content within a THE HENRY FILM AND ENTERTAINMENT CORPORATION Property
(the "Initial Term"). After the Initial Term, this Agreement will be automatically renewed for
successive additional 3~year periods ("Extension Terms"), unless otherwise terminated by either
party by giving notice to the other party not less than sixty (60) days prior to the end of a Term.
As used herein, the "Term" means the Initial Term and any Extension Term(s).

TERMINATION FOR CAUSE: Notwithstanding the foregoing, this Agreement may be terminated by either
party immediately upon notice if the other party: (w) becomes insolvent; (x) files a petition in
bankruptcy; (y) makes an assignment for the benefit of its creditors; or (z) breach any of its
obligations under this Agreement in any material respect, which breach is not remedied within thirty
(30) days following written notice to such party.

EFFECT OF TERMINATION: Any termination shall be without any liability or obligation of the
terminating party, other than with respect to any breach of this Agreement prior to termination. The
provisions relating to property rights and confidentiality shall survive any termination or
expiration of this Agreement. All revenue sharing ceases with the termination of this Agreement.

Initialed THE HENRY FILM AND ENTERTAINMENT CORPORATION:______

Initialed PACIFICAP ENTERTAINMENT:______

Page 3 of 6

Source: PACIFICAP ENTERTAINMENT HOLDINGS INC, 8-K/A, 11/15/2005

PACIFICAP ENTERTAINMENT Agreement with THE HENRY FILM AND ENTERTAINMENT CORPORATION..
<!-- page 4 -->
CONFIDENTIAL Page 4 of 6

PACIFICAP ENTERTAINMENT and THE HENRY FILM AND ENTERTAINMENT CORPORATION hereby acknowledge that
each of them may have access to confidential and proprietary information, which relates to the other
party's business (the "Confidential Information"). Such information shall be identified as
confidential at the time of disclosure. Each party agrees to preserve and protect the
confidentiality of the Confidential Information and not to disclose or use any applicable
Confidential Information without the prior written consent of the other party; provided, however,
that any party hereto may disclose to any other party or use any information which is: (i) already
publicly known; (ii) discovered or created independently of any involvement with such party; (iii)
otherwise learned through legitimate means other than from such party; or (iv) independently created
by the receiving party without reference to the other party's confidential information. Moreover,
any party hereto may disclose any Confidential Information hereunder to such party's agents,
attorneys and other representatives or any court or competent jurisdiction or any other party
empowered hereunder as reasonably required to resolve any dispute between the parties hereto. Both
parties agree all aspects of this contract are confidential and shall not be disclosed to any third
party.

BOTH THE HENRY FILM AND ENTERTAINMENT CORPORATION and PACIFICAP ENTERTAINMENT acknowledges and
agrees that: (i) as between PACIFICAP ENTERTAINMENT on the one hand, and THE HENRY FILM AND
ENTERTAINMENT CORPORATION and its Affiliates on the other, THE HENRY FILM AND ENTERTAINMENT
CORPORATION owns all right, title and interest in any THE HENRY FILM AND ENTERTAINMENT CORPORATION
Property and THE HENRY FILM AND ENTERTAINMENT CORPORATION Brand Features; (ii) nothing in this
Agreement shall confer in PACIFICAP ENTERTAINMENT any license or right of ownership in THE HENRY
FILM AND ENTERTAINMENT CORPORATION Brand Features; and (iii) PACIFICAP ENTERTAINMENT shall not now
or in the future contest the validity of THE HENRY FILM AND ENTERTAINMENT CORPORATION. Brand
Features.

PUBLIC ANNOUNCEMENTS The parties will cooperate to create any and all appropriate public
announcements relating to the relationship set forth in this Agreement. Neither party shall make any
public announcement regarding the existence or Content of this Agreement without the other party's
prior written approval and consent.

THE HENRY FILM AND ENTERTAINMENT CORPORATION will, when appropriate, mention PACIFICAP ENTERTAINMENT
as "Content Provided By" in relevant credits and advertising including but not limited to print,
television, radio and online; promotion and public relations. THE HENRY FILM AND ENTERTAINMENT
CORPORATION will mention PACIFICAP ENTERTAINMENT Content when other third party providers of data to
THE HENRY FILM AND ENTERTAINMENT CORPORATION are mentioned in relevant advertising, promotion and
public relations.

FUTURE COOPERATION: THE HENRY FILM AND ENTERTAINMENT CORPORATION and PACIFICAP ENTERTAINMENT will
keep each other apprised of productions and other developments that may enhance the relationship
between THE HENRY FILM AND ENTERTAINMENT CORPORATION and PACIFICAP ENTERTAINMENT; including but not
limited to new productions development by THE HENRY FILM AND ENTERTAINMENT CORPORATION that may be
valuable to PACIFICAP ENTERTAINMENT. PACIFICAP ENTERTAINMENT and THE HENRY FILM AND ENTERTAINMENT
CORPORATION agree that future cooperation may be valuable to both parties, and that the parties will
discuss s h future cooperation each quarter or as warranted.

Initialed THE HENRY FILM AND ENTERTAINMENT CORPORATION:___

Initialed PACIFICAP ENTERTAINMENT:_____ Page 4of 6

Source: PACIFICAP ENTERTAINMENT HOLDINGS INC, 8-K/A, 11/15/2005

PACIFICAP ENTERTAINMENT Agreement with THE HENRY FILM AND ENTERTAINMENT CORPORATION…
<!-- page 5 -->
CONFIDENTIAL Page 5 of 6

ALL DISPUTES ARISING OUT OF THIS AGREEMENT SHALL BE SETTLED VIA BINDING ARBITRATION ACCORDING TO THE
RULES AND REGULATIONS SET FORTH BY THE AMERICAN ARBITRATION ASSOCIATION IN SAN DIEGO COUNTY , THE
STATE OF CALIFORNIA.

IN WITNESS WHEREOF, the parties have caused this Agreement to be executed by their duly authorized
representatives as of the Effective Date first written above.

PACIFICAP ENTERTAINMENT INC. (Licensor)

Signed________________________________________________________________ Name: Ed Litwak Title:
Chairman

Date:_______________________

And

THE HENRY FILM AND ENTERTAINMENT CORPORATION (Licensee)

Signed______________________________________ Name: Michae1 Henry Title: Chairman

Date:____________________________

Initialed THE HENRY FILM AND ENTERTAINMENT CORPORATION:____

Initialed PACIFICAP ENTERTAINMENT:______

PACIFICAP ENTERTAINMENT Agreement with THE HENRY FILM AND ENTERTAINMENT CORPORATION… CONFIDENTIAL
Page 5 of 6

Witnessed By

Signed ._______________________________________________________ William R. Sickert 7052 Partridge
Place Carlsbad, CA 92009

PACIFICAP ENTERTAINMENT Agreement with THE HENRY FILM AND ENTERTAINMENT CORPORATION

CONFIDENTIAL Page 6 of 6

EXHIBIT A

TO: PACIFICAP ENTERTAINMENT INC. CONTENT LICENSE AGREEMENT

PACIFICAP ENTERTAINMENT INC. MARK USAGE GUIDELINES

Source: PACIFICAP ENTERTAINMENT HOLDINGS INC, 8-K/A, 11/15/2005
<!-- page 6 -->
DEFINITIONS

"Advertising Rights" shall mean the advertising and promotional rights sold or licensed with respect
to Content included properties.

"Affiliates" shall mean any company or any other entity worldwide, including, without limitation,
corporations, partnerships, joint ventures, and Limited Liability Companies, in which THE HENRY FILM
AND ENTERTAINMENT CORPORATION owns at least a five percent ownership, equity, or financial interest.

"THE HENRY FILM AND ENTERTAINMENT CORPORATION Brand Features" shall mean all trademarks, service
marks, logos and other distinctive brand features of THE HENRY FILM AND ENTERTAINMENT CORPORATION
that are used in or relate to a THE HENRY FILM AND ENTERTAINMENT CORPORATION Property or Content,
including, without limitation, the trademarks, service marks and logos described.

"PACIFICAP ENTERTAINMENT Content" shall mean, collectively, all materials, data, and similar
information collected and owned by PACIFICAP ENTERTAINMENT, which is a collection of television
shows, clips, movies, recordings and photos.

"THE HENRY FILM AND ENTERTAINMENT CORPORATION Properties" shall mean any of THE HENRY FILM AND
ENTERTAINMENT CORPORATION produced, created, branded or co branded media properties.

"Content Shows/Programming" shall mean those productions in any THE HENRY FILM AND ENTERTAINMENT
CORPORATION Property that contain PACIFICAP ENTERTAINMENT Content.

"Intellectual Property Rights" shall mean all rights in and to trade secrets, patents, copyrights,
trademarks, know- how, as well as moral rights and similar rights of any type under the laws of any
governmental authority, domestic or foreign.

"Internet" shall mean the collection of computer networks commonly known as the Internet, and shall
include, without limitation, the World Wide Web.

PACIFICAP ENTERTAINMENT Agreement with THE HENRY FILM AND ENTERTAINMENT CORPORATION CONFIDENTIAL
Page 6 of 6

Initialed THE HENRY FILM AND ENTERTAINMENT CORPORATION:____

Initialed PACIFICAP ENTERTAINMENT:____

Source: PACIFICAP ENTERTAINMENT HOLDINGS INC, 8-K/A, 11/15/2005
