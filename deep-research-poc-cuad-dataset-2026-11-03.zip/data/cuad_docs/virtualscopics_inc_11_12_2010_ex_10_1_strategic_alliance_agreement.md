<!-- page 1 -->
# STRATEGIC ALLIANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2010-10-22 |
| Parties | PPD Development, LP ("PPD"); VirtualScopics, Inc ("VS") |
| Source | CUAD v1 / VIRTUALSCOPICS,INC_11_12_2010-EX-10.1-STRATEGIC ALLIANCE AGREEMENT |

Exhibit 10.1

Confidential treatment has been requested for portions of this Exhibit. The copy filed herewith
omits the information subject to the confidentiality request. Omissions are marked by brackets with
asterisks, such as [***]. A complete version of this Exhibit has been filed separately with the
Securities and Exchange Commission.

STRATEGIC ALLIANCE AGREEMENT THIS STRATEGIC ALLIANCE AGREEMENT ("Agreement"), entered into as of
October 22, 2010 (the "Effective Date") by and between PPD Development, LP, a Texas limited
partnership, with its principal executive offices located at 929 North Front Street, Wilmington,
North Carolina 28401 ("PPD") and VirtualScopics, Inc., with an address of 500 Linden Oaks, Second
Floor, Rochester, New York 14625 ("VS"). WHEREAS, PPD is a clinical research organization engaged in
the business of managing clinical research programs and providing services regarding the development
of pharmaceuticals, chemicals, biotechnology and other products through clinical testing; WHEREAS,
VS is in the business of providing imaging services to the medical, pharmaceutical and related
industries; WHEREAS, PPD and VS desire to enter into a mutually beneficial relationship with a
mission to deliver a comprehensive set of clinical and medical imaging services that will enable
biopharmaceutical companies to make faster, more confident decisions on the development of their
compounds, creating time and cost efficiencies; and WHEREAS, the parties desire to develop, market,
sell, and deliver those joint service offerings pursuant to the terms and conditions set forth
herein. NOW, THEREFORE, in consideration of the promises and mutual covenants contained herein and
other good and valuable consideration, the receipt and sufficiency of which are hereby acknowledged,
the parties agree as follows: 1. Term. The term of this Agreement shall begin on the Effective Date
and shall continue for a period of two (2) years ("Initial Term") unless terminated earlier in
accordance with Section 11 of this Agreement. Upon expiration of the Initial Term, unless written
notice to the contrary is provided by one party to the other party at least 30 days prior to the
expiration of the then-current term, this Agreement shall be renewed for additional, successive
periods of one (1) year each (each a "Renewal" and together with the Initial Term, collectively, the
"Term"). In connection with any Renewal, the parties shall mutually agree upon and set forth in a
written amendment signed by the parties (i) any changes to the Services constituting Preferred
Services and (ii) any changes to the [***], VS Preferred Pricing, percentage Discount (defined in
Section 4 below) or Bookings thresholds for all such Preferred Services. Upon any expiration or
termination of this Agreement, all active Work Orders issued prior to such expiration or termination
shall remain subject to the terms and conditions contained herein so long as such Work Order remains
active. 2. Services. PPD or any of its subsidiaries or affiliates may engage VS to perform imaging
services (the "Services") for a specific sponsor's clinical research study ("Sponsor") or for a
particular project. The Services may be amended, supplemented, or replaced from time to time upon
mutual agreement of VS and PPD.

[***] Represents material which has been redacted and filed separately with the Commission pursuant
to a request for confidential treatment pursuant to Rule 24b-2 under the Securities Exchange Act of
1934, as amended.

1
<!-- page 2 -->
3. Services Commitment. "Preferred Services" shall be defined as those imaging services included
within the service offerings of VS at the time of final execution of this Agreement which are
specifically provided by VS in the therapeutic areas of hematology and oncology ("Designated
Therapeutic Areas") to the extent such imaging services are subject to the commitments of VS set
forth in this Section 3 (the "Commitments"). "PPD Services" shall be defined as clinical research
organization services regarding the management of clinical trials for the development of
pharmaceuticals, chemicals, biotechnology and other products through clinical testing. Preferred
Services and PPD Services shall be subject to all of the rights and obligations otherwise set forth
in this Agreement. Nothing contained herein shall be construed to limit the provision of
non-Preferred Services hereunder, however, such non-Preferred Services shall not be subject to the
Commitments set forth in this Section 3. a. Joint Commitments (i) The parties acknowledge and agree
that it is their intent and commitment to expand the Joint Solution (as defined below) to
therapeutic areas beyond the Designated Therapeutic Areas. Upon mutual agreement regarding such
expansion, it is the parties' further intent to make such additional Joint Solution services subject
to substantially the same commitments as those set forth herein. (ii) The parties acknowledge and
agree that each party has in place, or will develop, processes and procedures applicable to their
performance hereunder as specified on Exhibit A ("Integration Services"). The Integration Services
shall be reviewed and assessed by the parties from time to time and may be amended or updated from
time to time. Exhibit A shall be used as a guide for developing integrated service offerings to meet
the needs of each party's clients, as applicable (in each instance, a "Joint Solution" or
collectively, the "Joint Solution"). (iii) Where either party determines that an opportunity exists
and is appropriate for the offering of the Joint Solution to that party's customer or client, it is
the parties' mutual intent and commitment to collaborate, as needed, to propose the Joint Solution
to that customer or client. Each party agrees to make a good faith effort to promote a Joint
Solution for a Sponsor seeking services that could reasonably be addressed by the Joint Solution. In
connection with PPD's response to a request for proposal (an "RFP") in which a Joint Solution is
proposed, PPD shall be responsible for the preparation and submission of such RFP response;
provided, however, that PPD shall provide VS an opportunity to review and provide approval on the
Joint Solution framework, including, the scope of the Preferred Services and the pricing thereof. VS
shall provide such review within two (2) business days following receipt by VS of such RFP response
from PPD. Where reasonably appropriate for the proper defense of an RFP, PPD will use its reasonable
efforts to provide VS an opportunity to participate in a call or bid defense meeting to the extent
related to the Joint Solution. In the event PPD is awarded a clinical research study and such award
includes selection by Sponsor of the Joint Solution, the parties shall mutually agree upon an
applicable Work Order in accordance with Section 4 below.

2
<!-- page 3 -->
A. However, nothing contained herein shall be construed to impose upon PPD an obligation to offer
the Joint Solution or to use VS for Preferred Services where: (1) Sponsor is not in agreement, (2)
VS's pricing is not competitive, or (3) there have been advances in technology not offered by VS. B.
Further, nothing contained herein shall enable either party to utilize the Joint Solution where the
client has rejected the involvement of either party. For the avoidance of doubt, the Joint Solution
shall only be utilized where both parties' services in furtherance of the Joint Solution have been
retained by the client. Nonetheless, a client's selection or rejection of either party for services
outside the Joint Solution shall in no way impact or impede a party from performing such services,
regardless of the other party's selection or rejection by the client. C. In the event either party
discovers, directly or indirectly, technology not currently in use by the other party but which
could improve the Preferred Services, PPD Services or the Joint Solution, the discovering party may
elect to share such technology with the other party with the intent of integration by the other
party. However, to the extent such other party elects not to integrate or otherwise use such
technology, the discovering party shall not be prohibited from using that technology without the
other party's involvement. (iv) During the Term, VS acknowledges and agrees that, to the extent it
is aware of an opportunity for clinical research services, it will refer such opportunity to PPD as
soon as possible. VS shall not refer that opportunity to any other third party provider unless PPD
declines to bid on such opportunity or does not offer the service in question. During the Term, PPD
acknowledges and agrees that, to the extent it is aware of an opportunity for imaging services
outside of the Joint Solution, it will refer such opportunity to VS as soon as possible. Unless
otherwise required by a particular Sponsor, PPD shall not refer that opportunity to any other third
party provider unless VS declines to bid on such opportunity or does not offer the service in
question.

3
<!-- page 4 -->
(v) During the Term of this Agreement, except as otherwise permitted by this Section 3(a)(v), VS
agrees that it shall not enter into the same or substantially similar Commitments with any other
company or entity which performs clinical research services the same or similar to those provided by
PPD or any PPD affiliate (collectively, "PPD Competitor"), nor shall VS provide preferred pricing to
a PPD Competitor which is better than that provided by VS hereunder to PPD. Further, during the Term
of this Agreement, PPD agrees that it shall not enter into commitments which are the same or
substantially similar to the PPD commitments set forth in Section 3 with any other imaging vendor
for the performance of Preferred Services. In the event that, during the Term of this Agreement, VS
desires to enter into the same or substantially similar Commitments with a PPD Competitor for
imaging services outside of the Designated Therapeutic Areas (defined herein or in any amendment
hereto), VS shall first notify PPD regarding the same and PPD shall have a right, for a period of 45
days following receipt of such notice (the "Election Period"), to elect to include such imaging
services as "Preferred Services" hereunder (the "Right of First Refusal"). In the event PPD either
(i) fails to respond within the Election Period or (ii) declines to include such imaging services as
"Preferred Services" prior to termination of the Election Period, then in either such event, VS
shall be permitted to pursue such relationship without being considered in violation of the
Commitments or this Agreement. Additionally, in the event that PPD enters into a relationship with a
VS competitor which provides for commitments which are the same or substantially similar to the
Commitments in a therapeutic area outside the Designated Therapeutic Areas (defined herein or in any
amendment hereto), VS shall have the right, without violating the Commitments or this Agreement
(including the Right of First Refusal), to enter into a relationship with a PPD Competitor which
provides for commitments which are the same or substantially similar to the Commitments outside the
Designated Therapeutic Areas (defined herein or in any amendment hereto). (vi) The parties shall
form a Steering Committee comprised of high level personnel from each party which shall meet
quarterly during the Term of this Agreement to oversee the implementation of this preferred
relationship and the obligations set forth herein. The Steering Committee shall be comprised of an
equal number of representatives from each party. PPD's Steering Committee representatives shall be
comprised of: Director, Finance; Therapeutic Head; Relationship Manager; Executive Director,
Business Development; Executive Director, Information Technology; Medical Director, Global Drug
Development. VS's Steering Committee representatives shall be comprised of: Chief Financial Officer;
Chief Executive Officer/President; Director of Operations and Director of Project Management. Each
party shall provide prior written notice to the other party of any desired change in Steering
Committee representatives. Each party's Steering Committee representatives shall hold a position of
sufficient level within its respective company to be able to obtain timely resolution of disputes
submitted to the Steering Committee.

4
<!-- page 5 -->
In the event a Sponsor shall raise concerns or issues with respect to any Preferred Services
performed by VS in conjunction with Sponsor's selection of the Joint Solution, which Preferred
Services are agreed upon by the parties in an executed Work Order, VS and PPD shall mutually
evaluate such concerns or issues prior to any communication with Sponsor and shall mutually agree
upon an appropriate response to Sponsor related to such concerns or issues. The resolution of any
such matters shall be submitted first to the parties' respective Project Manager for the study, and
in the event such persons are unable to agree upon resolution, then to each parties' Relationship
Manager/Senior Director and finally to the Therapeutic Head or equivalent position. The foregoing
paragraph shall not be deemed to restrict a PPD project manager from ordinary course discussions
with a Sponsor in order to collect information related to the nature of any such concerns or issues
raised by Sponsor. b. VS Commitment. VS agrees to continue to make investments in and improvements
to those processes, technologies, techniques, software, hardware and methods which are integral or
beneficial to the Services provided by VS, specifically but without limitation, to the Preferred
Services. c. PPD Commitment. Where PPD is in a position to make a recommendation to Sponsor with
regard to imaging services, and VS is able to provide such imaging services in accordance with
Sponsor's specifications, PPD agrees to recommend VS to Sponsor. PPD also agrees to maintain, when
present, VS's name and logo on all VS generated deliverables to the Sponsor. 4. Compensation. a.
Each time VS is requested to perform Services, PPD shall provide VS with a work order or other
similar written document mutually agreed upon by VS and PPD which shall set forth the specific
services being requested, the compensation therefore and such other terms, conditions and
specifications as VS and PPD may mutually agree (referred to herein as a "Work Order"). The parties
acknowledge that no services shall be conducted by VS and no compensation shall be due and payable
to VS without a Work Order. In the event PPD receives a change order from a Sponsor which includes
changes to VS's Services as set forth in an executed Work Order or may otherwise impact the
provision by VS of Services to PPD hereunder, PPD shall promptly notify VS. Thereafter, the parties
shall negotiate, in good faith, for an amendment to the applicable Work Order, as appropriate, as a
result of such Sponsor change order. b. VS shall be compensated for the Services in accordance with
the Work Order. All pricing and rates used to establish the budget for Services set forth in each
Work Order shall be in accordance with the pricing structures agreed upon by the parties herein and
set forth in Exhibit B attached hereto and incorporated herein by reference. PPD acknowledges that
VS customarily receives an advance payment in connection with the provision of imaging services to
its clients. PPD agrees that, where appropriate and permitted by the Sponsor, PPD will provide for
an advance payment mutually determined by PPD and VS (and acceptable to Sponsor) in connection with
the provision of Preferred Services to such Sponsor. 5
<!-- page 6 -->
c. Exhibit B sets forth the pricing and rates for Preferred Services [***]. The prices and rates set
forth in Exhibit B and the Discount and Booking thresholds set forth in Exhibit C shall remain in
effect, without adjustment, during the Initial Term of this Agreement and may thereafter be updated
to reflect changes in connection with any Renewal of this Agreement, as specified in Section 1
herein. [*** 2.5 paragraphs omitted] Upon the termination of this Agreement for any reason, VS shall
no longer have any obligation to provide PPD with any Discount with respect to Preferred Services
nor shall VS be required to offer VS Preferred Pricing [***]. The parties acknowledge and agree that
the VS Preferred Pricing [***] shall apply to, and remain in effect for, all active Work Orders
issued hereunder, regardless of the expiration or termination of this Agreement, as well as for any
timeline extensions to an active Work Order, provided that in the case of a timeline extension, the
parties may mutually agree to apply an inflation rate for the extension period. In the event a Work
Order shall be amended in any respect (including with respect to the scope of the Preferred
Services, the timing for the delivery thereof, or otherwise), the VS Preferred Pricing [***]
applicable to any Preferred Services included in such amendment and the Discount shall be the VS
Preferred Pricing [***] and the Discount in effect on the date of the original Work Order. The
parties further acknowledge and agree that VS Preferred Pricing [***] shall be applicable to any
agreed upon expansion of the Preferred Services. With respect to any Services provided to PPD
hereunder, PPD shall charge each Sponsor the actual invoiced amounts charged by VS to PPD for such
Services without any mark-up or administrative or other fee, unless VS has agreed otherwise in
writing in the applicable Work Order. d. Additionally, PPD shall reimburse VS for all reasonable
expenses incurred in the course of performing the Services which are set forth in the Work Order. VS
shall maintain a complete accounting of all expenses incurred and shall include such accounting with
VS's invoice submitted to PPD. Expenses incurred must be invoiced separately and must include an
expense report along with original receipts for such expenses. e. VS shall submit monthly invoices
to PPD detailing its activities and fees in accordance with Section 5 of this Agreement.
Notwithstanding the foregoing, invoices must be submitted to PPD within thirty (30) days of
performing the Service or incurring the expense. PPD shall have no obligation to issue payment to VS
for Services performed or expenses incurred which were not invoiced to PPD in accordance with this
Agreement. f. VS acknowledges and agrees that where VS's Services relate to a specific Sponsor's
clinical research study, all payments under a Work Order are pass through payments from Sponsor and
PPD shall not have any payment obligations until such payments are received from Sponsor. PPD shall
use all reasonable diligence to obtain timely payment from Sponsor in order to make payment to VS
within 45 days following the date of invoice receipt. In furtherance thereof, PPD shall ensure that
Sponsor is invoiced no later than ten (10) days following PPD's receipt of VS's invoice, assuming
such invoice was provided to PPD by VS in accordance herewith and provided that Sponsor's invoice
requirements do not preclude the same. PPD shall ensure that VS is aware of any such Sponsor
restrictions as soon as possible. Further, PPD shall ensure that payment is made to VS either by
wire transfer or PPD check in accordance with PPD's applicable payment processes no later than ten
(10) days following PPD's receipt of applicable funds from Sponsor; provided, however, that in the
event such payment occurs more than 45 days following the date of PPD's receipt of VS' invoice, such
payment shall be made by wire transfer. Notwithstanding the foregoing, where a Sponsor fails to
issue payment to PPD, affecting PPD's ability to pay VS, the parties shall communicate with the
other to jointly pursue communication with the Sponsor to address the non­payment.

[***] Represents material which has been redacted and filed separately with the Commission pursuant
to a request for confidential treatment pursuant to Rule 24b-2 under the Securities Exchange Act of
1934, as amended.

6
<!-- page 7 -->
g. Where PPD and Sponsor have agreed upon and captured in a fully executed contract any
bonus/penalty or other similar, milestone based incentive provisions, and PPD's ability to meet the
terms of such provisions will be impacted by VS's Services, PPD and VS may mutually agree, case by
case, to flow through to the applicable Work Order all or agreed upon portions of such bonuses,
penalties or incentives. 5. Invoices and Billing Account Number. PPD shall assign a billing account
number ("Purchase Order Number") to VS for the Services in each Work Order. All VS invoices must
reference the Purchase Order Number, Service fees, any PPD pre-approved expenses incurred by VS, the
remittance address, and the total amount of compensation owed to VS. These invoices must be sent to
the following address: PPD, 929 North Front Street, Wilmington, NC 28401, Attention: Accounts
Payable. 6. Independent Contractor. VS shall perform all Services under this Agreement as an
independent contractor and not as an employee, partner or agent of PPD. As such, VS shall be solely
responsible for the payment of all taxes, payroll deductions and similar items associated with
compensation for its services under this Agreement as may be required by applicable law. VS
acknowledges that as an independent contractor it will not be entitled to insurance or other
benefits made available to employees of PPD. 7. Additional Personnel. VS shall have the authority to
utilize a third party vendor as may be required to perform the Services ("Subcontractors");
provided, however, that: a. Subcontractors must be approved in advance by PPD, such approval not to
be unreasonably withheld, conditioned or delayed. b . VS shall be responsible for all taxes, payroll
deductions and similar items which may result from the retention of such Subcontractors to assist in
the performance of VS's obligations under this Agreement. c. Compensation for the services of said
Subcontractor shall be paid to VS by PPD on a pass-through basis and at no profit to VS. d. Any such
Subcontractor and its employees or other personnel shall be bound by the terms and conditions of
this Agreement with respect to representations and warranties, privacy, confidential information,
intellectual property, indemnification, debarment, record keeping and audit (see Sections 8, 9, 10,
12, 14 and 15), which provisions shall be incorporated into a written agreement between VS and such
Subcontractor. e. Notwithstanding the foregoing, VS shall remain responsible for the actions of all
of the Subcontractors retained by VS.

7
<!-- page 8 -->
8. Representation and Warranties. VS represents and warrants that it shall utilize independent
discretion and judgment in discharging its responsibilities in a timely, professional and
workmanlike manner in accordance with internationally accepted standards, and shall, at all times:
(i) use individuals of suitable training and skill to perform its duties and responsibilities under
this Agreement, if applicable; (ii) be in possession of all the necessary facilities, resources and
personnel required to perform its duties and responsibilities under this Agreement; and (iii) comply
with all applicable laws, rules, regulations and guidelines. Further, VS represents and warrants
that it has all of the necessary licenses, permits and/or registrations to perform the Services in
accordance with the terms and conditions of this Agreement and that during the Term of this
Agreement, all such licenses, permits and/or registrations are and shall remain current and in good
standing. [*** 1 paragraph omitted] 9. Confidential Information. It is understood and agreed that
any and all information which may be made available to, learned by or generated by either party
during the Term of this Agreement, including without limitation, information relating to the other
party's businesses, its affiliates or the Sponsor, Sponsor's protocol, and this Agreement
(collectively, "Confidential Information"), is to be treated as strictly confidential (the party
disclosing such Confidential Information, the "Disclosing Party" and the party receiving such
Confidential Information, the "Receiving Party", with the understanding that either term may
include, as applicable, an affiliate of either party). Confidential Information shall be used solely
in connection with performance hereunder or as otherwise may be necessary for a party to fulfill its
obligations to a customer or client and shall not to be published or disclosed to any third parties
other than the Receiving Party's employees on a strict need­to­know basis and provided that such
employee is under a similar written and enforceable obligation to keep such information strictly
confidential. Further, nothing contained herein shall prevent PPD from disclosing VS Confidential
Information to PPD's customers and clients solely to the extent directly related to the provision of
Services to such customer or client. The nondisclosure obligations set forth in this Section 9 shall
not apply to any portion of Confidential Information (i) which is, or subsequently may, become
within the knowledge of the general public other than as a result of a breach of this Agreement by
the Receiving Party; (ii) which is known to the Receiving Party on a non-confidential basis at the
time of receipt thereof from the Disclosing Party; (iii) which may subsequently be rightfully
obtained from a third party not bound by an obligation of confidentiality to the Disclosing Party,
or (iv) which is required by any law, rule, regulation, order, decision, decree, subpoena or other
judicial, administrative or legal process to be disclosed, provided that the Disclosing Party
receives prior written notice of such disclosure and that the Receiving Party takes all reasonable
and lawful actions to obtain confidential treatment for such disclosure and, if possible, to
minimize the extent of such disclosure. Receiving Party shall take reasonable care of all
Confidential Information entrusted to it by or on behalf of the Disclosing Party or Sponsor, and
shall return such materials to the Disclosing Party or Sponsor (as the case may be) immediately upon
expiration or termination of this Agreement. Both parties agree to handle all information containing
personal data in accordance with all applicable privacy laws, rules, and regulations.

[***] Represents material which has been redacted and filed separately with the Commission pursuant
to a request for confidential treatment pursuant to Rule 24b-2 under the Securities Exchange Act of
1934, as amended.

8
<!-- page 9 -->
10. Intellectual Property. Nothing contained herein, nor the delivery of any information to either
party hereunder, shall be deemed to grant the other party a right or license under any patent or
patent application or to any know-how, technology, invention or other intellectual property of the
other party or of the Sponsor. All inventions, patents, know-how, trademarks, copyrights,
information, data, software, methodologies, writings and other property in any form whatsoever,
which are provided to either party and which were owned or controlled by the providing party
("Originator") shall remain the sole property of the Originator. The parties' ownership rights in
any inventions, patents, trademarks, copyrights, software, methodologies, writings and other
property in any form whatsoever that results out of the development of a Joint Solution shall be
addressed by the parties by separate written agreement which may include, an applicable Work Order
and/or an amendment to this Agreement ("Intellectual Property Amendment") . Unless otherwise
addressed in an Intellectual Property Amendment, VS hereby assigns to PPD (or Sponsor as the case
may be) all rights that VS may have in any invention, technology, know-how or other intellectual
property which is developed with use of Confidential Information provided to VS by PPD.
Additionally, VS shall assist PPD (or Sponsor), at PPD's (or Sponsor's) sole cost and expense, in
obtaining or extending protection therefor. Unless otherwise addressed in an Intellectual Property
Amendment, PPD hereby assigns to VS all rights that PPD may have in any invention, technology,
know-how or other intellectual property which is developed with use of Confidential Information
provided to PPD by VS. Additionally, PPD shall assist VS, at the sole cost and expense of VS, in
obtaining or extending protection therefor. 11. Termination. Either party may terminate this
Agreement, without cause, upon ninety (90) days prior written notice to the other party, provided,
however, that all outstanding Work Orders shall continue to be governed by the terms and conditions
hereof. Either party may terminate this Agreement, or a relevant Work Order, immediately, upon the
occurrence of any of the following for cause events: (a) either party's material breach of the
commitments set forth in Section 3; (b) either party commences a voluntary proceeding under any
bankruptcy, insolvency or other similar law or an involuntary case or proceeding is commenced
against a party under any bankruptcy, insolvency or other similar law; (c) significant audit
findings are identified by the other party, a Sponsor, or an applicable regulatory authority; or (d)
significant operational deficiencies that are not resolved in accordance with the Steering Committee
determinations following escalation. PPD shall further be permitted to terminate this Agreement or a
relevant Work Order, immediately, for cause, upon the occurrence of any of the following: (a) VS's
failure to meet the agreed upon timelines, provided that such failure is due to circumstances within
VS's reasonable control; (b) VS's failure to provide pricing which is reasonably competitive; (c) a
change of ownership equal to fifty percent (50%) or more in the outstanding voting securities of VS;
(d) the acquisition of a number of VS's outstanding voting securities by a PPD Competitor that would
require disclosure by such PPD Competitor pursuant to Rule 13d-1 of the Securities Exchange Act of
1934 (a "Significant Ownership Position"); (e) a change in any VS Key Leadership Position. In the
event Sponsor, with or without cause, terminates, or requests that PPD terminate, VS's involvement
in a project, PPD shall have the right to immediately terminate the Work Order to which such project
relates. Additionally, in the event the services requested of PPD by Sponsor are cancelled or put on
hold or the services agreement between PPD and Sponsor is terminated, PPD may terminate any relevant
Work Order immediately upon notice to VS. In the event any Work Order is terminated, PPD shall pay
VS for all Services performed in accordance with the Work Order through the date of termination plus
any agreed upon costs necessary to close-out the Work Order (which costs shall be documented in a
Work Order amendment if not included in the Work Order) and any non-cancelable expenses incurred
prior to the termination of such Work Order, provided VS makes all reasonable attempts to mitigate
such non-cancelable expenses.

9
<!-- page 10 -->
12. Indemnification. VS shall indemnify, defend and hold harmless PPD, its affiliates, directors,
officers and employees thereof for any and all damages, costs, expenses and other liabilities,
including reasonable attorney's fees and court costs, incurred by any such party as a result of any
claim, action or proceeding by a third party (a "Third Party Claim") arising from VS's negligence,
intentional misconduct, or breach of this Agreement. PPD shall indemnify, defend and hold harmless
VS, its directors, officers and employees thereof for any and all damages, costs, expenses and other
liabilities, including reasonable attorney's fees and court costs, incurred by any such party as a
result of any Third Party Claim arising from PPD's negligence, intentional misconduct, or breach of
this Agreement. Either indemnified party shall give the indemnifying party prompt notice of any
Third Party Claim for which indemnification is sought hereunder. The indemnifying party shall have
the right to control the defense and settlement of such Third Party Claim, provided the indemnifying
party shall act reasonably and in good faith with respect to all matters relating to the settlement
or disposition of the claim, and the indemnified party shall reasonably cooperate in the
investigation, defense and settlement of such claim. The indemnified party shall have the right to
participate in, but not control, the defense and settlement of a claim and to employ separate legal
counsel of its own choice; provided, however, that such employment shall be at the indemnified
party's own expense, unless (i) the employment thereof has been specifically authorized by the
indemnifying party, or (ii) the indemnifying party has failed to assume the defense and employ
counsel (in which case the indemnified party shall control the defense and settlement of such
claim). 13. Limitation of Liability. EXCEPT WITH REGARD TO A PARTY'S BREACH OF SECTION 9, GROSS
NEGLIGENCE, WILLFUL MISCONDUCT AND INDEMNIFICATION OBLIGATIONS RELATED TO THIRD PARTY CLAIMS
PURSUANT TO SECTION 12, EACH PARTY'S ENTIRE LIABILITY UNDER THIS AGREEMENT WILL IN NO EVENT EXCEED
THREE TIMES (3X) THE TOTAL VALUE OF THE WORK ORDER UNDER WHICH THE CLAIM AROSE. NOTWITHSTANDING
ANYTHING TO THE CONTRARY CONTAINED IN THIS AGREEMENT, NEITHER PARTY SHALL BE LIABLE TO THE OTHER
PARTY FOR INCIDENTAL, INDIRECT, CONSEQUENTIAL OR SPECIAL DAMAGES OR FOR ANY DAMAGES ARISING OUT OF
OR IN CONNECTION WITH ANY LOSS OF PROFIT, INTERRUPTION OF SERVICE OR LOSS OF BUSINESS OR
ANTICIPATORY PROFITS, EVEN IF A PARTY OR ITS AFFILIATES HAVE BEEN APPRISED OF THE LIKELIHOOD OF SUCH
DAMAGES OCCURRING, IN EACH CASE ARISING IN CONNECTION WITH ANY DEFAULT OR BREACH OF OBLIGATIONS
UNDER THIS AGREEMENT OR ANY ATTACHMENTS HERETO. IN THE EVENT OF A BREACH OR DEFAULT BY VS UNDER THIS
AGREEMENT OR ANY WORK ORDER, VS AGREES, AT PPD'S OPTION, TO EITHER REPEAT THE SERVICES AT ISSUE OR
REFUND THE PORTION OF THE CONSIDERATION ATTRIBUTABLE THERETO.

10
<!-- page 11 -->
THE WARRANTIES PROVIDED IN SECTION 8 AND ANY WORK ORDER ARE IN LIEU OF ALL OTHER CONDITIONS OR
WARRANTIES, EXPRESS OR IMPLIED, WHETHER ARISING BY STATUTE, COURSE OF DEALING OR PERFORMANCE,
CUSTOM, USAGE IN THE TRADE OR PROFESSION OR OTHERWISE, INCLUDING BUT NOT LIMITED TO,
MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, AND ARE IN LIEU OF ALL OTHER OBLIGATIONS
RELATING TO THE QUALITY OR ADEQUACY OF THE SERVICES IMPOSED BY LAW, ALL OF WHICH ARE EXPRESSLY
DISCLAIMED TO THE EXTENT PERMITTED BY APPLICABLE LAW.

14. Debarment. VS hereby certifies that it has not been debarred, and has not been convicted of a
crime which could lead to debarment, under the Generic Drug Enforcement Act of 1992. If VS or any of
its employees or agents who perform Services hereunder is debarred or receives notice of an action
or threat of action of debarment, VS shall immediately notify PPD. 15. Record Keeping and Audit.
During the Term of this Agreement, VS shall maintain all materials and all other data obtained or
generated by VS in the course of providing the Services hereunder, including all computerized
records and files. VS shall cooperate with any internal reviews or audits by PPD or Sponsor (or its
and their representatives) and shall make available for examination and duplication, during normal
business hours and at mutually agreeable times, all documentation, data and information relating to
this Agreement or any Work Order. Further, VS shall inform PPD within one (1) business day of being
notified of an audit by any regulatory authority or by any Sponsor to the extent such audit relates
to the Preferred Services, the Joint Solution or a Work Order hereunder. PPD or its representatives
shall be permitted to be present at and directly communicate with such regulatory authority or
Sponsor representatives (as the case may be) concerning any matters related to the Preferred
Services, the Joint Solution or a Work Order hereunder arising in connection with such audit. To the
extent permitted by the auditing entity, VS shall ensure that PPD is provided with copies of any
written communications, reports and findings resulting from any inspection of VS by that regulatory
authority or Sponsor to the extent related to the Preferred Services, the Joint Solution or a Work
Order. To the extent any such communications, reports or findings require action by VS, VS shall
include with such copies its remedial plan of action, including timelines for completion of the
same. To the extent such remedial plan of action impacts the Preferred Services or Joint Solution,
and, where applicable, to the extent permitted by the relevant regulatory authority, VS shall
collaborate with PPD prior to developing or implementing any changes to the Preferred Services or
Joint Solution as a result of the audit findings. 16. Insurance. VS represents and warrants that it
has and will maintain during the Term of this Agreement and, additionally, where applicable, during
the term of any active Work Order, and for a period of two (2) years following expiration or
termination of either, insurance in the types and limits generally accepted in the industry. Upon
request, VS shall provide PPD with a copy of its certificate of insurance. 17. Governing Law. This
Agreement shall be construed in accordance with the laws of the State of Delaware without regard to
its conflict of laws provisions. 18. Assignment. This Agreement shall be binding upon and inure to
the benefit of the parties hereto and their successors and assigns. Neither party shall have the
right to assign this Agreement or any Work Order or to assign any rights thereunder without the
prior written consent of the other party. Notwithstanding the foregoing, PPD may assign a Work Order
to an affiliate or to Sponsor upon written notice to VS. In the event PPD assigns a Work Order to a
Sponsor, VS agrees to release and forever discharge PPD from any and all claims that may arise out
of the relevant Work Order after the effective date of such assignment. Unless otherwise agreed in
writing by VS, PPD shall not be released from any liability or obligation under this Agreement upon
assignment of any Work Order to an affiliate of PPD. VS may subcontract all or a portion of the
Services to be provided hereunder in accordance with Section 7 above. Any unauthorized attempt to
assign or delegate any portion of this Agreement or any Work Order shall be void.

11
<!-- page 12 -->
19. Publicity. Except as otherwise specifically set forth herein, neither party shall use the name,
insignia, symbol, trademark, trade name, logo, logotype, or any abbreviation or adaptation thereof,
of the other party or any affiliate of the other party, in any publication, press release,
promotional material or other form of publicity, nor will either party use the same as verbal
endorsement of its services, without the prior written approval of the other party in each instance.
Further, VS shall be similarly restricted as it pertains to Sponsor and any Sponsor affiliate. The
restrictions imposed by this Section shall not prohibit the parties from making any disclosure
identifying the other party that is required by any applicable law, rule or regulation.
Additionally, following final execution of this Agreement, the parties acknowledge and agree that a
joint press release statement regarding the parties' preferred relationship and its impact on the
parties' ability to provide Services hereunder shall be prepared and mutually agreed upon prior to
its release or use by either party. 20. Force Majeure. The parties shall be excused from performing
their obligations under this Agreement if its performance is delayed or prevented by any event
beyond such party's reasonable control, including, but not limited to, acts of God, fire, explosion,
weather, disease, war, insurrection, civil strife, riots, government action, or power failure,
provided that such performance shall be excused only to the extent of and during such disability.
21. Covenant Not to Interfere. Neither party will solicit for employment any employee of the other
party during the active term of this Agreement and further, where applicable, the term of any active
Work Order. As used in this section "solicit" means the initiation by a party or its agent or
representative of a contact with any of the other party's then current employees who are performing
services under this Agreement for the purpose of offering employment to such employees, but shall
not include the circumstance where any such employee initiates a contact with the other party for
the purpose of obtaining employment whether in response to a general advertisement of employment or
where such contact is initiated by a third party who was not instructed to contact such employee by
the hiring party. 22. Miscellaneous. a. By agreeing to the terms and conditions of this Agreement
and performing the Services for PPD, VS is representing that it is not in violation of any terms and
conditions of any agreement with any other individual or entity. b. This Agreement constitutes the
entire agreement between the parties and supersedes all prior agreements, whether written or oral.
This Agreement shall be construed according to its fair meaning and not strictly for or against any
party. c. This Agreement may be modified only by a writing signed by the parties hereto. d. If any
provision of this Agreement conflicts with the law under which this Agreement is to be construed or
if any such provision is held invalid by a court, such provision shall be deemed to be restated to
reflect as nearly as possible the original intentions of the parties in accordance with applicable
law and the remainder of this Agreement shall remain in full force and effect.

12
<!-- page 13 -->
e. Waiver or forbearance by either party with respect to a breach of any provision of this Agreement
or any applicable law shall not be deemed to constitute a waiver with respect to any subsequent
breach of any provision hereof. f. Any notice required or permitted to be given hereunder by either
party hereto shall be in writing and shall be deemed given on the date received if delivered
personally, by recognized overnight courier, by facsimile or by electronic delivery, or five (5)
days after the date postmarked if sent by registered or certified U.S. mail, return receipt
requested postage prepaid, to the following address: If to PPD: PPD Development, LP 929 North Front
Street Wilmington, NC 28401 Telephone: (910) 251-0081 Facsimile: (910) 343-5920 Attn.: Chief
Executive Officer With a Copy to: General Counsel

If to VS: VirtualScopics, Inc. 500 Linden Oaks, Second Floor Rochester, New York 14625 Telephone:
(585) 249-6231 Facsimile: (585) 218-7350 Attn: Molly Henderson

Either party may change its notice address and contact person by giving notice of same in the manner
herein provided. g. This Agreement may be executed in one or more counterparts, each of which for
all purposes shall be deemed to be an original, and all of which when taken together shall
constitute but one and the same instrument. This Agreement and any amendments hereto, to the extent
signed and delivered by means of a facsimile machine or by electronic mail, shall be considered to
have the same binding legal effect as if it were the original signed version thereof delivered in
person. 23. Survival. The obligations of the parties contained in Sections 4 (provided that any
payments due upon termination shall be governed in accordance with Section 11), 5, 9, 10, 12, 13,
15, 19 and 23 hereof and herein shall survive termination of this Agreement or any Work Order. 24.
Conflict. Any and all Services provided during the Term of this Agreement, including all Services
provided pursuant to a Work Order, shall be subject to the terms and conditions contained herein. To
the extent any terms contained in this Agreement conflict with a Work Order, the terms of this
Agreement shall govern and control unless the Work Order specifically states otherwise. To the
extent any terms contained in this Agreement or a Work Order conflict with a Purchase Order, the
terms of this Agreement shall govern and control first, followed by the terms of the applicable Work
Order.

13
<!-- page 14 -->
[signatures appear on following page]

14
<!-- page 15 -->
IN WITNESS WHEREOF, the parties have caused their duly authorized representatives to execute this
Agreement as of the Effective Date.

VirtualScopics, Inc. By: Name: Molly J. Henderson Title: Chief Business and Financial Officer, Sr.
Vice President PPD Development, LP By: PPD GP, LLC Its General Partner By: Name: Title:

[Signature Page to Strategic Alliance Agreement]

Exhibit A
<!-- page 16 -->
Integration Services

[*** 2 pages omitted]

[***] Represents material which has been redacted and filed separately with the Commission pursuant
to a request for confidential treatment pursuant to Rule 24b-2 under the Securities Exchange Act of
1934, as amended.
<!-- page 17 -->
Exhibit B

[***] Pricing

[*** 3 pages omitted]

[***] Represents material which has been redacted and filed separately with the Commission pursuant
to a request for confidential treatment pursuant to Rule 24b-2 under the Securities Exchange Act of
1934, as amended.
<!-- page 18 -->
Exhibit C

Discounts and Bookings Thresholds

The percentage Discount applicable to Bookings in any given Measurement Period shall be determined
in accordance with the discount structure set forth in the table below:

[*** .5 pages omitted]

[***] Represents material which has been redacted and filed separately with the Commission pursuant
to a request for confidential treatment pursuant to Rule 24b-2 under the Securities Exchange Act of
1934, as amended.
