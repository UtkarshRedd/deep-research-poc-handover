You are planning a search over {n_docs} documents to answer a question. You have NOT seen the
documents. Decompose the question into 3 to {max_clues} CLUES: specific things to look for —
entities and parties, defined terms, identifiers, amounts, dates, section titles, distinctive
phrasings, and synonyms or alternative spellings. For each clue give 1 to 3 grep regexes
(case-insensitive; use alternations for synonyms, e.g. `terminat(e|ion)|cancel`) and ONE short
keyword query for a BM25 search (3 to 8 words, no stopwords).

Documents in scope:
{manifest_preview}

Question: {question}

Reply with ONLY a JSON object, no prose, no code fence:
{{"clues": [{{"text": "what this clue is", "grep_patterns": ["regex1", "regex2"], "bm25_query": "keywords"}}]}}
