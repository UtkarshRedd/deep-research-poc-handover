<!-- page 1 -->
# JOINT FILING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture   Filing Agreement |
| Agreement Date | 2020-04-08 |
| Parties | YA II PN, Ltd.; YA Global Investments II (U.S.), Ltd.; Yorkville Advisors Global, LP; Yorkville Advisors Global II, LLC; YAII GP, LP; Yorkville Advisors GP, LLC; D-Beta One EQ, Ltd.; D-Beta One Blocker EQ, Ltd.; D-Beta One Growth and Opportunity Fund Offshore, LP; D-Beta One GP, LLC; Delta Beta Advisors, LP |
| Source | CUAD v1 / QBIOMEDINC_04_08_2020-EX-99.1-JOINT FILING AGREEMENT |

EXHIBIT 99.1 JOINT FILING AGREEMENT The undersigned hereby agree that the statement on Schedule 13G
with respect to the equity securities of Q Biomed, Inc. is, and any amendment thereto signed by each
of the undersigned shall be, filed on behalf of each of the undersigned pursuant to and in
accordance with the provisions of Rule 13d-1(k) promulgated under the Securities Exchange Act of
1934, as amended. The undersigned hereby further agree that this Joint Filing Agreement be included
as an exhibit to such statement and any such amendment. The undersigned acknowledge that each shall
be responsible for the timely filing of such amendments, and for the completeness and accuracy of
the information concerning him or it contained herein and therein, but shall not be responsible for
the completeness and accuracy of the information concerning the others. This Joint Filing Agreement
may be executed in any number of counterparts, all of which taken together shall constitute one and
the same instrument. Dated: 4/8/2020 YA II PN, Ltd. By:/s/ Troy J. Rillo, Esq. Date: 4/8/2020 Troy
J. Rillo, Esq. Chief Compliance Officer YA Global Investments II (U.S.), Ltd. By:/s/ Troy J. Rillo,
Esq. Date: 4/8/2020 Troy J. Rillo, Esq. Chief Compliance Officer Yorkville Advisors Global, LP
By:Yorkville Advisors Global, LLC Its:General Partner By:/s/ Troy J. Rillo, Esq. Date: 4/8/2020 Troy
J. Rillo, Esq. Chief Compliance Officer Yorkville Advisors Global II, LLC By:/s/ Troy J. Rillo, Esq.
Date: 4/8/2020 Troy J. Rillo, Esq. Chief Compliance Officer
<!-- page 2 -->
YAII GP, LP By:Yorkville Advisors GP, LLC Its:General Partner By:/s/ Troy J. Rillo, Esq. Date:
4/8/2020 Troy J. Rillo, Esq. Chief Compliance Officer Yorkville Advisors GP, LLC By:/s/ Troy J.
Rillo, Esq. Date: 4/8/2020 Troy J. Rillo, Esq. Chief Compliance Officer D-Beta One EQ, Ltd. By:Delta
Beta Advisors, LLC Its:Investment Manager By:/s/ Troy J. Rillo, Esq. Date: 4/8/2020 Troy J. Rillo,
Esq. Chief Compliance Officer D-Beta One Blocker EQ, Ltd. By:/s/ Troy J. Rillo, Esq. Date: 4/8/2020
Troy J. Rillo, Esq. Chief Compliance Officer D-Beta One Growth and Opportunity Fund Offshore, LP
By:D-Beta One GP, LP Its:General Partner By:D-Beta One GP, LLC Its:General Partner By:/s/ Troy J.
Rillo, Esq. Date: 4/8/2020 Troy J. Rillo, Esq. Chief Compliance Officer D-Beta One GP, LLC By:/s/
Troy J. Rillo, Esq. Date: 4/8/2020 Troy J. Rillo, Esq. Chief Compliance Officer
<!-- page 3 -->
Delta Beta Advisors, LP By:Delta Beta Advisors, LLC Its:General Partner By:/s/ Troy J. Rillo, Esq.
Date: 4/8/2020 Troy J. Rillo, Esq. Chief Compliance Officer D-Beta One GP, LLC By:/s/ Troy J. Rillo,
Esq. Date: 4/8/2020 Troy J. Rillo, Esq. Chief Compliance Officer /s/ Matthew Beckman Date: 4/8/2020
Matthew Beckman
