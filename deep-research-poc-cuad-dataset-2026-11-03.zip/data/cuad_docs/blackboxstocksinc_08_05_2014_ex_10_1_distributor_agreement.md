<!-- page 1 -->
# DISTRIBUTOR AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| Agreement Date | 2013-08-01 |
| Parties | Snotarator LLC ("Company"); SMSA Ballinger Acquisition Corp., ("Distributor") |
| Source | CUAD v1 / BLACKBOXSTOCKSINC_08_05_2014-EX-10.1-DISTRIBUTOR AGREEMENT |

Exhibit 10.1 DISTRIBUTOR AGREEMENT

THIS AGREEMENT is made this 1st day of August, 2013, (the "Effective Date"), by and between
Snotarator LLC, a Texas limited liability company, with its principal place of business located at
2591 Dallas Parkway, Suite 102, Frisco, Texas 75034 (the "Company") and SMSA Ballinger Acquisition
Corp., a Nevada corporation, with offices at 12890 Hilltop Road, Argyle, Texas 76226 (the
"Distributor").

NOW, THEREFORE, in consideration of the promises hereinafter made by the parties hereto, it is
agreed as follows: ARTICLE I APPOINTMENT OF DISTRIBUTORSHIP

1.01. Distribution Right. The Company hereby appoints and grants Distributor the exclusive right to
sell the products of the Company, including the Snotarator™ Nasal Aspirator, ("Products") listed in
the current "Price List" (Exhibit "A" attached hereto). The distribution right shall be limited to
all countries and all of their territories and possessions within the continent known as South
America ("Territory") (Exhibit "B" attached hereto). Distributor agrees that the Products, including
the name Snotarator ™ Nasal Aspirator (the "Brand") are the sole property of the Company and
Distributor has no interest whatsoever in such Brand and Products, and Distributor shall use the
Brand and Products only for so long as the rights granted hereby remains in full force and effect.
Distributor shall not take any actions, or aid or assist any other party to take any actions that
would infringe upon, harm or contest the proprietary rights of Company in and to the Brand and
Products. Distributor shall not assign the rights granted in this Section 1.01 without the prior
written consent of the Company.

1.02 Prices. All prices stated are in United States dollars and FOB the Company's offices in Frisco,
Texas. Prices do not include transportation costs which shall be borne by Distributor.

1.03. Terms. Terms are net cash upon delivery.

1.04. Competitive Products. Distributor agrees not to represent or sell other products which are
deemed to be competitive with the Company's Products unless agreed to by the Company by written
notice.

ARTICLE II MARKETING AND SUPPORT

2.01. Sales. Distributor shall use commercially reasonable efforts to market, distribute and promote
the Brand and Products in the Territory at its own cost.

ARTICLE III DELIVERY

3.01. Purchase Orders. Distributor shall order Products by written notice to Company. Each order
shall specify the number of units to be shipped, the type of units to be shipped (as identified by
Company model number designations indicated in the Price List) including all optional features, the
desired method of shipment. Company shall indicate its acceptance of such purchase order by
returning a signed copy to Distributor. Company agrees to ship units to Distributor as close as
possible to the delivery schedule set forth in each order as accepted by Company, unless Company
otherwise indicates in writing

3.02. Shipment. All shipments of Products shall be made FOB Company's office and liability for loss
or damage in transit, or thereafter, shall pass to Distributor upon Company's delivery of Products
to a common carrier for shipment. Shipping dates are approximate and are based, to a great extent,
on prompt receipt by Company of all necessary ordering information from Distributor. Distributor
shall bear all costs of transportation and insurance and will promptly reimburse Company if Company
prepays or otherwise pays for such expenses. Company shall not be in default by reason of any
failure in its performance under this Agreement if such failure results from, whether directly or
indirectly, fire, explosion, strike, freight embargo, Act of God or of the public enemy, war, civil
disturbance, act of any government, de jure or de facto, or agency or official thereof, material or
labor shortage, transportation contingencies, unusually severe weather, default of any other
manufacturer or a supplier or subcontractor, quarantine, restriction, epidemic, or catastrophe, lack
of timely instructions or essential information from Distributor, or otherwise arisen out of causes
beyond the control of the Company. Nor shall the Company at any time be liable for any incidental,
special or consequential damages.
<!-- page 2 -->
3.03. Cancellation. Distributor may, at any time prior to the scheduled date of shipment, cancel any
or all Products on order upon giving timely written notice.

ARTICLE IV PATENT AND TRADEMARK INFRINGEMENT

4.01 Patent Infringement. Company agrees, at its own expense, to indemnify, defend and hold harmless
each Distributor and its customers from and against every expense, damage, cost and loss (including
attorneys' fees incurred) and to satisfy all judgments and decrees resulting from a claim, suit or
proceeding insofar as it is based upon an allegation that any Product or any part thereof furnished
by Company or any process which is practiced in the customary use of the Product is or has been
infringing upon any patent, copyright or proprietary right, if Company is notified promptly of such
claim in writing and given authority, and full and proper information and assistance (at Company's
expense) for the defense of same. In case any Product, or any part thereof, if such suit is held to
constitute an infringement and the use of said Product or part is enjoined, Company shall, in its
sole discretion and at its own expense, either procure for the indemnitee the right to continue
using said Product or provide or procure for the Distributor a similar product.

4.02 Trademark Infringement. The Company has registered the mark Snotarator ™ in the United States.
Distributor agrees it will not at any time, either during the term of this Agreement or thereafter,
use the Brand, Products or Snotarator™ mark in any manner that might infringe upon the Company's
ownership rights to same directly or indirectly. Distributor shall indemnify and hold the Company
and its affiliates harmless from and against any and all claims, judgments, costs, awards, expenses
(including reasonable attorney fees) and liabilities of every kind arising from Distributor's fault
or negligence in its use of the Snotarator ™ mark and in the marketing and distribution of the
Products within the Territory.

ARTICLE V WARRANTY

5.01. Products Warranty. Company warrants that Distributor shall acquire Products purchased
hereunder free and clear of all liens and encumbrances except for Company's purchase money security
interest defined in Section 1.03, above. Company further warrants all Products to be free from
defects in material or workmanship under normal use and service for a period of ninety (90) days
from the date of delivery. Any defects must be replaced by the Company within sixty (60) days within
this scope of the warranty and all charges for labor and material, will be borne by Company. If it
is determined that either no fault exists in Company, or the damage was caused by negligence of
Distributor, its agents, employees or customers, Distributor agrees to pay all charges associated
with each such replacement. THIS CONSTITUTES THE SOLE WARRANTY MADE BY COMPANY EITHER EXPRESSED OR
IMPLIED. THERE ARE NO OTHER WARRANTIES EXPRESSED OR IMPLIED WHICH EXTEND BEYOND THE FACE HEREOF,
HEREIN, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. IN
NO EVENT SHALL COMPANY BE LIABLE FOR ANY INCIDENTAL OR CONSEQUENTIAL DAMAGES AND DISTRIBUTOR'S
REMEDIES SHALL BE LIMITED TO REPAIR OR REPLACEMENT OF NONCONFORMING UNITS OR PARTS. 2
<!-- page 3 -->
ARTICLE VI DURATION OF AGREEMENT

6.01. Term. The term of this Agreement shall terminate on May 31, 2015, unless sooner terminated.
Termination shall not relieve either party of obligations incurred prior thereto. The term of this
Agreement may be extended for an additional two year period with the written consent of both
parties.

6.02. Termination. This Agreement may be terminated only:

(a) By either party for substantial breach of any material provision of this Agreement by the other,
provided due notice has been given to the other of the alleged breach and such other party has not
cured the breach within (30) days] thereof; or

(b) By the Company if: there is an unacceptable change in the control or management of the
Distributor; if the Distributor makes an assignment for the benefit of creditors; if a petition in
bankruptcy is filed by or against the Distributor, resulting in an adjudication of bankruptcy; or,
if the Distributor fails to pay its debts as they become due and provided due notice has been given
by the Company to the Distributor and the Distributor has not cured such breach within thirty (30)
days thereof; or (c) By the written consent of both parties;

(d) Upon termination of this Agreement all further rights and obligations of the parties shall
cease, except that Distributor shall not be relieved of (i) its obligation to pay any monies due, or
to become due, as of or after the date of termination, and (ii) any other obligation set forth in
this Agreement which is to take effect after the date of termination.

ARTICLE VII NOTICES

7.01. Notice or Communication. Any notice or communication required or permitted hereunder shall be
in writing and shall be sent by international courier or registered mail, return receipt requested,
postage prepaid and addressed to the addresses set forth below or to such changed address as any
party entitled to notice shall have communicated in writing to the other party. Purchase orders and
other administrative notices may be sent by facsimile transmission or regular mail. Notices and
communications to Company shall be sent to:

Snotarator LLC 2591 Dallas Parkway Suite 102 Frisco, Texas 75034

Notices and communications to Distributor shall be sent to address shown on first page of this
Agreement. Any notices or communications to either party hereunder shall be deemed to have been
given when deposited in the mail, addressed to the then current address of such party.

7.02 . Date of Effectiveness. Any such notice or communication so mailed shall be deemed delivered
and effective seventy-two (72) hours after mailing thereof in the United States.

ARTICLE VIII CONFIDENTIALITY 3
<!-- page 4 -->
8.01 . Confidentiality. Each party agrees to maintain in confidence and not to use except for the
purpose of this Agreement any information of a confidential nature such as technical information and
data, commercial information and know-how, price structures, administrative and operational costs,
or other information relating to each other's business operations or in the case of Distributor to
the Brand and Products whether disclosed prior to the Effective Date or thereafter. Each party's
obligation of confidentiality and limitation upon use shall not apply to any information to the
extent that the receiving party can show that such information:

a) is or became generally available to the public otherwise than by reason of breach by the
receiving party of the provisions of this Agreement;

b) was known to the receiving party prior to the date of the Agreement provided that documentary
evidence of such knowledge is provided to the disclosing party on request;

c) was subsequently disclosed to the receiving party without obligation of confidentiality by a
third party owing no such obligations to the disclosing party in respect of such information;

d) is required by laws to be disclosed but then only when, to the extent reasonably practicable,
prompt notice of this requirement has been given to the original disclosing party so that it may
seek appropriate relief to prevent or limit such disclosure.

Except as required by applicable laws or court order or as otherwise permitted under this Agreement,
all publicity, press releases and public announcements, in each case relating to the Brand and
Products in the Territory and/or the transactions contemplated hereby shall be reviewed in advance
by, and shall be subject to the written approval (such approval not to be unreasonably withhold) of
both the Company and Distributor. The parties hereto may disclose the existence of this Agreement
and the terms and conditions hereof, without the prior written consent of the other parties, as may
be required by applicable laws, in which case the party seeking to disclose the information shall
give the other parties reasonable advanced notice and review of any such disclosure and shall seek
confidential treatment of such information to the extent possible under applicable law.

ARTICLE IX GENERAL PROVISIONS

9.01. Relationship of Parties. The relationship between the parties established by this Agreement
shall be solely that of vendor and vendee and all rights and powers not expressly granted to the
Distributor are expressly reserved to the Company. The Distributor shall have no right, power or
authority in any way to bind the Company to the fulfillment of any condition not herein contained,
or to any contract or obligation, expressed or implied.

9.02. Independence of Parties. Nothing contained in this Agreement shall be construed to make the
Distributor the agent for the Company for any purpose, and neither party hereto shall have any right
whatsoever to incur any liabilities or obligations on behalf or binding upon the other party. The
Distributor specifically agrees that it shall have no power or authority to represent the Company in
any manner; that it will solicit orders for Products as an independent contractor in accordance with
the terms of this Agreement; and that it will not at any time represent the Company in any manner;
that it will solicit orders for Products as an independent contractor in accordance with the terms
of this Agreement; and that it will not at any time represent orally or in writing to any person or
corporation or other business entity that it has any right, power or authority not expressly granted
by this Agreement.

9.03. Indemnity. The Distributor agrees to hold the Company free and harmless from any and all
claims, damages, and expenses of every kind or nature whatsoever (a) arising from acts of the
Distributor; (b) as a direct or indirect consequence of termination of this Agreement in accordance
with its terms; or (c) arising from acts of third parties in relation to Products sold to the
Distributor under this Agreement, including, but not limited to execution of liens and security
interests by third parties with respect to any such Products. 4
<!-- page 5 -->
9.04. Entire Agreement. The entire Agreement between the Company and the Distributor covering the
Products is set forth herein and any amendment or modification shall be in writing and shall be
executed by duly authorized representatives in the same manner as this Agreement. The provisions of
this Agreement are severable, and if any one or more such provisions are determined to be illegal or
otherwise unenforceable, in whole or in part, under the laws of any jurisdiction, the remaining
provisions or portions hereof shall, nevertheless, be binding on and enforceable by and between the
parties hereto. Any provisions, terms or conditions of Distributor's purchaseoOrders which are, in
any way contradicting of this Agreement, except those additional provisions specifying quantity and
shipping instructions, shall not be binding upon Company and shall have no applicability to the sale
of goods by Company to Distributor.

9.05. Applicable Law. This Agreement shall be governed by the laws of the State of Texas. All
payments hereunder shall be made at Company's offices at Frisco, Texas. Company's rights granted
hereby are cumulative and in addition to any rights it may have at law or equity.

9.06. Separate Provisions. If any provision of this Agreement shall be held to be invalid, illegal
or unenforceable, the validity, legality and enforceability of the remaining provisions shall in no
way be affected or impaired thereby.

9.07. Successors and Assigns. This Agreement shall be binding upon and inure to the benefit of the
parties and their successors and assigns. Distributor shall not assign this Agreement or any rights
or obligations hereunder without the prior written consent of the Company.

IN WITNESS WHEREOF, the parties have caused this Agreement to be executed by their duly authorized
officers as of the date and year indicated above.

SNOTARATOR LLC

By:/s/ Orsolya Peresztegi Orsolya Peresztegi Title: President and Manager

DISTRIBUTOR SMSA Ballinger Acquisition Corp.

By:/s/ Timothy P. Halter Timothy P. Halter Title: President and Sole Director 5
<!-- page 6 -->
EXHIBIT A

SNOTARATOR PRICE LIST AS OF AUGUST 1, 2013

Description of Product

Snotarator® Nasal Aspirator

Price per Unit 1,000 to 5,000 Units* - $4.50 per unit 5,000 to 10,000 Units - $4.15 per unit Over
10,000 Units - $3.95 per unit

____________________________________ *Minimum order of 1,000 Units
<!-- page 7 -->
EXHIBIT B DESCRIPTION OF THE TERRITORY
<!-- page 8 -->
The Territory which is subject to Section 1.01 of this Agreement includes all countries and all of
their territories and possessions within the continent known as South America.
