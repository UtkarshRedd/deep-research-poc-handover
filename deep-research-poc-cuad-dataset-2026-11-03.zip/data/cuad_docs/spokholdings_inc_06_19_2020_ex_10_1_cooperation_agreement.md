<!-- page 1 -->
# Cooperation Agreement
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2020-06-18 |
| Parties | Spôk Holdings, Inc. ("Company"); White Hat Strategic Partners LP; White Hat SP GP LLC; White Hat Capital Partners LP; White Hat Capital Partners GP LLC; (collectively the "White Hat Parties"); each of the Company and White Hat Parties a "Party"' collectively "Parties" |
| Source | CUAD v1 / SPOKHOLDINGS,INC_06_19_2020-EX-10.1-COOPERATION AGREEMENT |

Exhibit 10.1

COOPERATION AGREEMENT

This Cooperation Agreement ("Agreement") is entered into as of June 18, 2020, by and between Spôk
Holdings, Inc., a Delaware corporation (the "Company"), and White Hat Strategic Partners LP, a
Delaware limited partnership, White Hat SP GP LLC, a Delaware limited liability company, White Hat
Capital Partners LP, a Delaware limited partnership, and White Hat Capital Partners GP LLC, a
Delaware limited liability company (collectively, the "White Hat Parties") (each of the Company and
the White Hat Parties, a "Party" to this Agreement, and collectively, the "Parties").

RECITALS

WHEREAS, the White Hat Parties have voting power or sole dispositive power or otherwise have
beneficial ownership of 319,708 shares (the "Current Position") of the common stock, par value
$0.0001 per share, of the Company (the "Common Stock") as of the date of this Agreement; and

WHEREAS, as of the date of this Agreement, the Company and the White Hat Parties have determined to
come to an agreement with respect to certain matters set forth below; and

NOW, THEREFORE, in consideration of the foregoing premises and the mutual covenants and agreements
contained herein, and for other good and valuable consideration, the receipt and sufficiency of
which are acknowledged, the Parties to this Agreement, intending to be legally bound, agree as
follows:

1. Board Nominations; Certain Information.

(a) Brett Shockley (the "New Director") has provided the Company with responses to a Director and
Officer Questionnaire customarily used for NASDAQ-listed companies and certain biographical
information in compliance with Item 401 of Regulation S-K as promulgated by the Securities and
Exchange Commission (the "SEC") (collectively, the "Information"), has executed all documents
required to be executed by directors of the Company, and has cooperated with a background check. (b)
Based on the Information, the Nominating and Governance Committee (the "Nominating Committee") of
the Board of Directors (the "Board") of the Company and the Board have determined that the New
Director may serve as an "independent" director of the Company in accordance with the rules and
listing standards of the NASDAQ National Market and applicable rules and regulations of the
Securities Exchange Commission (the "SEC"). (c) Concurrently with the execution of this Agreement,
the Board shall increase the size of the Board by one and appoint the New Director to the Board to
fill the resulting vacancy. Concurrently with the execution of this Agreement, the Board shall also
appoint the New Director to the Nominating Committee. (d) Concurrently with the execution of this
Agreement, the White Hat Parties shall send a letter to the Corporate Secretary and Treasurer of the
Company irrevocably withdrawing (i) the nomination letter they previously sent to the Company on May
26, 2020, and, accordingly, (ii) their nomination (the "Nominations") of three directors for
election to the Board at the Company's 2020 Annual Meeting of Stockholders (including any
adjournments or postponements thereof, the "2020 Annual Meeting"). (e) The Nominating Committee and
the Board shall take all necessary action to nominate Brett Shockley for election to the Board at
the 2020 Annual Meeting, and to recommend his election and to support and solicit proxies in the
same manner as the other candidates nominated by the Board in the Company's proxy statements for the
2020 Annual Meeting. (f) Nothing in this Agreement shall be deemed to abridge or limit the fiduciary
duties of any member of the Board under Delaware law. 2. Representations of the White Hat Parties.
The White Hat Parties represent and warrant to the Company as of the date hereof as follows: (a) The
White Hat Parties are the beneficial owners of 319,708 shares of Common Stock, such shares of Common
Stock constitute all of the Common Stock beneficially owned by the White Hat Parties and the White
Hat Parties have no agreements, understandings or undertakings with any third party to share or
delegate disposition or voting control over such shares of Common Stock, or to transfer, hypothecate
or lend such shares Common Stock. (b) Each of the White Hat Parties has the power and authority to
execute and deliver this Agreement. This Agreement (i) has been duly and validly authorized by each
of the White Hat Parties, and constitutes a legal, valid and binding obligation of each of the White
Hat Parties, enforceable against each of the White Hat Parties in accordance with its terms except
as may be limited by bankruptcy, insolvency or similar laws affecting creditors' rights and general
equitable principles, (ii) does not require the approval of any investor in or member of the White
Hat Parties and (iii) does not violate any law, order of any court or any governmental agency or
regulation or the charter or any organizational document
<!-- page 2 -->
Exhibit 10.1

of the White Hat Parties, or conflict with, result in a breach of or constitute a default under any
agreement or instrument by which the White Hat Parties or any of their respective assets is bound.
3. Representations of the Company. The Company represents and warrants to the White Hat Parties as
of the date hereof that it has the corporate power and authority to execute and deliver this
Agreement. This Agreement (i) has been duly and validly authorized by the Company and constitutes a
legal, valid and binding obligations of the Company, enforceable against the Company in accordance
with its terms except as may be limited by bankruptcy, insolvency or similar laws affecting
creditors' rights and general equitable principles and (ii) does not violate any law, order of any
court or any agency or regulation or the Company's Certificate of Incorporation or the Bylaws, or
conflict with, result in a breach of or constitute a default under any agreement or instrument by
which the Company or any of its assets or the assets of its subsidiaries are bound. 4. Voting
Commitments. The White Hat Parties shall appear in person or by proxy for quorum purposes at the
2020 Annual Meeting, including any adjournment or postponement thereof, to vote all of the shares of
Common Stock beneficially owned by the White Hat Parties on the record date (if the 2020 Annual
Meeting is within thirty (30) days of the anniversary of the Company's 2019 Annual Meeting of
Stockholders, such number of shares shall be no less than 90% of the Current Position) for such
meeting (i) in favor of all persons nominated by the Board to serve as directors of the Company and
against any stockholder nominated candidate not endorsed by the Board, (ii) against the stockholder
proposal made pursuant to Rule 14a-8 under the Exchange Act as disclosed to the White Hat Parties
prior to the execution of this Agreement, (iii) to ratify the appointment of the Company's
independent registered public accounting firm, and (iv) in accordance with the Board's
recommendation with respect to the Company's "say-on-pay" proposal and new equity compensation plan
(collectively, the "2020 Proposals"), provided, that with respect to the proposals described in
clauses (ii) through (iv) of this Section 4, the White Hat Parties may vote in accordance with the
recommendation of Institutional Shareholders Services to the extent such recommendation differs from
the voting commitments set forth herein and provided that the White Hat Parties do not publicly
disclose their vote on such proposals if it differs from the Board's recommendation; and provided,
further, that White Hat Parties shall have the right to vote the shares of Common Stock beneficially
owned by the White Hat Parties in their sole discretion with respect to all other proposals brought
before the 2020 Annual Meeting. The White Hat Parties shall provide written evidence of the votes
made in accordance with the foregoing sentence to the Company no later than ten business days before
the 2020 Annual Meeting. 5. Support Period Covenants. Except as otherwise contemplated in this
Agreement, at all times during the period commencing on the date hereof and ending on the date that
is thirty (30) days prior to expiration of the advance notice period for the submission by
stockholders of director nominations for consideration at the 2021 Annual Meeting as set forth in
the Bylaws, the White Hat Parties shall not, and shall cause the White Hat Representatives not to,
directly or indirectly, in any manner, alone or in concert with others: (a) attempt to call a
special meeting of stockholders of the Company; or (b) make a request for any stockholder list or
other Company books and records, whether pursuant to Section 220 of the Delaware General Corporation
Law or otherwise. 6. Press Release. The Parties agree that the Company shall issue a press release
and file a Current Report on Form 8-K in substantially the forms agreed to between the Parties
promptly following the execution and delivery of this Agreement by the Parties and shall not make
any other public disclosure relating to this Agreement or the transactions contemplated herein
without the prior review and good faith consideration of any comments made by the White Hat Parties.
The White Hat Parties agree that they shall not issue a press release regarding the subject matter
of this Agreement for a period of three (3) months after the date of this Agreement. 7.
Miscellaneous. (a) Specific Enforcement; Special Remedy. Each of the Parties agrees that the other
Party would be irreparably injured in the event that any provision of the Agreement is breached or
not performed. Accordingly, it is agreed that each Party shall be entitled to temporary and
permanent injunctive relief with respect to each and any breach or purported repudiation of this
Agreement by the other and to specifically enforce strict adherence to this Agreement and the terms
and provisions hereof against the other in any action instituted in a court of competent
jurisdiction, in addition to any other remedy which such aggrieved Party may be entitled to obtain.
Moreover, in the event of the breach of any of the provisions of this Agreement, timeliness in
obtaining relief is of the essence. (b) Amendments; Waiver. Neither this Agreement nor any term
hereof may be changed, waived, discharged or terminated orally or in writing without a writing
signed by the Parties. No delay on the part of either Party in exercising any right, power or
privilege hereunder shall operate as a waiver thereof, nor shall any waiver on the part of either
Party of any right, power or privilege hereunder operate as a waiver of any other right, power or
privilege hereunder, nor shall any single or partial exercise of any right, power or privilege
hereunder, preclude any other or further exercise thereof or the exercise of any other right, power
or privilege hereunder. (c) Successors and Assigns. This Agreement shall inure to the benefit of and
be binding upon the successors and assigns of each of the parties. This Agreement may not be
assigned without the prior written consent of the other Party hereto. (d) No Third Party
Beneficiaries. Nothing expressed or mentioned in this Agreement is intended or shall be construed to
give any person or entity, other than the Parties and their respective successors and assigns, any
legal or equitable right, remedy or claim under or in respect of this Agreement and any conditions
and provisions hereof being intended to be and being for the
<!-- page 3 -->
Exhibit 10.1

sole and exclusive benefit of the parties hereto and their respective successors and assigns, and
for the benefit of no other person or entity. (e) Counterparts. This Agreement may be executed in
any number of counterparts and by the Parties in separate counterparts, each of which when so
executed shall be deemed to be an original and all of which taken together shall constitute one and
the same agreement. (f) Headings. The headings in this Agreement are for convenience of reference
only and shall not limit or otherwise affect the meaning hereof. (g) Governing Law; Choice of Venue.
(i) This Agreement shall be governed by and construed in accordance with the internal laws of the
State of Delaware applicable to agreements made and to be performed within that state. (ii) Each
Party (A) consents to submit itself to the personal jurisdiction of the Court of Chancery or other
federal or state courts of the State of Delaware in the event any dispute arises out of this
Agreement or the transactions contemplated by this Agreement, (B) agrees that it shall not attempt
to deny or defeat such personal jurisdiction by motion or other request for leave from any such
court, (C) agrees that it shall not bring any action relating to this Agreement or the transactions
contemplated by this Agreement in any court other than the Court of Chancery or other federal or
state courts of the State of Delaware, and each Party irrevocably waives the right to trial by jury
and (D) each Party irrevocably consents to service of process by a reputable overnight mail delivery
service, signature requested, to the address of such Party's principal place of business or as
otherwise provided by applicable law. (h) Reimbursement. The Company shall reimburse the White Hat
Parties for their out-of-pocket expenses, including the fees and expenses of counsel, incurred in
connection with their engagement with the Company, the Nominations and the negotiation of, and all
matters arising under this Agreement; provided, however, that such reimbursement shall not exceed
$55,000. (i) Severability. If at any time subsequent to the date hereof, any provision of this
Agreement shall be held by any court of competent jurisdiction to be illegal, void or unenforceable,
such provision shall be of no force and effect, but the illegality or unenforceability of such
provision shall have no effect upon the legality or enforceability of any other provision in this
Agreement. (j) Interpretation and Construction. Each of the Parties acknowledges that it has been
represented by counsel of its choice throughout all negotiations that have preceded the execution of
this Agreement, and that it has executed the same with the advice of said independent counsel. Each
Party and its counsel cooperated and participated in the drafting and preparation of this Agreement
and the documents referred to herein, and any and all drafts relating thereto exchanged among the
parties shall be deemed the work product of all of the parties and may not be construed against any
Party by reason of its drafting or preparation. Accordingly, any rule of law or any legal decision
that would require interpretation of any ambiguities in this Agreement against any Party that
drafted or prepared it is of no application and is hereby expressly waived by each Party, and any
controversy over interpretations of this Agreement shall be decided without regards to events of
drafting or preparation. (k) Entire Agreement. This Agreement contains the entire understanding of
the Parties with respect to the subject matter hereof. (l) Notices. Any notices, consents,
determinations, waivers or other communications required or permitted to be given under the terms of
this Agreement must be in writing and will be deemed to have been delivered: (i) upon receipt, when
delivered personally; (ii) upon receipt, when sent by e-mail to the e-mail address for a Party set
forth below; and (iii) one (1) business day after deposit with a nationally recognized overnight
delivery service, in each case properly addressed to the Party to receive the same. The addresses
for such communications shall be:
<!-- page 4 -->
Exhibit 10.1

If to the Company or the Board:

Spôk Holdings, Inc. 6850 Versar Center, Suite 420 Springfield, Virginia 22151-4148 Attention: Vince
Kelly Email: vince.kelly@spok.com

with a copy (which shall not constitute notice) to:

Latham & Watkins LLP 555 Eleventh Street, NW Suite 1000 Washington, D.C. 20004 Attention: William
O'Neill and Christopher Drewry E-mail: William.O'Neill@retiredpartner.lw.com and
Christopher.Drewry@lw.com

If to the White Hat Parties:

White Hat Capital Partners LP 150 East 52nd Street 21st Floor New York, NY 10022 Attention: David
Chanley and Mark Quinlan Email: DChanley@whitehatcp.com and MQuinlan@whitehatcp.com

with a copy (which shall not constitute notice) to:

Olshan Frome Wolosky LLP 1325 Avenue of the Americas New York, NY 10019 Attention: Elizabeth
Gonzalez-Sussman E-mail: egonzalez@olshanlaw.com

(m) Termination. Unless earlier terminated as provided in this Agreement, upon the expiration of the
Support Period in accordance with Section 4, this Agreement shall immediately and automatically
terminate in its entirety and no Party shall have any further rights or obligations under this
Agreement; provided, however, no Party shall be released from any breach of this Agreement that
occurred prior to the termination of this Agreement.
<!-- page 5 -->
Exhibit 10.1

IN WITNESS WHEREOF, each of the parties hereto has executed this Agreement, or caused the same to be
executed by its duly authorized representative as of the date first above written.

Spōk Holdings, Inc. By: /s/ Vincent D. Kelly Name: Vincent D. Kelly Title: President and Chief
Executive Officer
<!-- page 6 -->
Exhibit 10.1

White Hat Strategic Partners LP

By: White Hat SP GP LLC, its General Partner

By: /s/ Mark Quinlan Name: Mark Quinlan Title: Managing Member

White Hat SP GP LLC

By: /s/ Mark Quinlan Name: Mark Quinlan Title: Managing Member

White Hat Capital Partners LP

By: /s/ Mark Quinlan Name: Mark Quinlan Title: Managing Partner

White Hat Capital Partners LP

By: /s/ Mark Quinlan Name: Mark Quinlan Title: Managing Member
