<!-- page 1 -->
# COLLABORATION AGREEMENT ("A
| Field | Value |
|---|---|
| Document Type | Collaboration Agreement |
| Agreement Date | 2005-06-01 |
| Parties | FibroGen, Inc. ("FG", "FibroGen"); Astellas Pharma Inc. ("Astellas") |
| Source | CUAD v1 / FIBROGENINC_10_01_2014-EX-10.11-COLLABORATION AGREEMENT |

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended. Exhibit 10.11 COLLABORATION AGREEMENT

BY AND BETWEEN

ASTELLAS PHARMA INC.

AND

FIBROGEN, INC. June 1, 2005
<!-- page 2 -->
CONFIDENTIAL EXECUTION COPY TABLE OF CONTENTS ARTICLE 1 DEFINITIONS 1

1.1 "Actions" 1 1.2 "Affiliate" 1 1.3 "Astellas Indemnitees" 1 1.4 "Astellas Territory" 1 1.5
"Authorized Designee" 1 1.6 "Bridging Strategy" 1 1.7 "Bulk Product" 2 1.8 "Commercialize" 2 1.9
"Completion" 2 1.10 "Confidential Information" 2 1.11 "Control" or "Controlled" 2 1.12 "Controlling
Party" 2 1.13 "Data" 2 1.14 "Delivery" or "Delivered" 2 1.15 "Development Plan" 2 1.16 "Development
Program" 2 1.17 "Enforcement Action" 2 1.18 "Event" 2 1.19 "Expanded Field" 2 1.20 "Expenses" 2 1.21
"FDA" 2 1.22 "FG Acquired Patents" 3 1.23 "FG Development Program" 3 1.24 "FG Indemnitees" 3 1.25
"FG Technology" 3 1.26 "FG Patents" 3 1.27 "FG Technical Information" 3 1.28 "FG Territory" 3 1.29
"Field" 4 1.30 "First Commercial Sale" 4 1.31 "Force Majeure Event" 4 1.32 "Fully Burdened Costs" 4
1.33 "Future Third Party Intellectual Property" 4 1.34 "GMP Guidelines" 4 1.35 "[ * ]" 4 1.36 "[ * ]
Percentage" 5 1.37 "HIF" 5 -i-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 3 -->
TABLE OF CONTENTS (continued) Page 1.38 "IND" 5 1.39 "Indemnitee" 5 1.40 "Indemnitor" 5 1.41
"Indications" 5 1.42 "Initial Development Plan" 5 1.43 "Initiate" or Initiation" 5 1.44 "Inspected
Party" and "Inspecting Party" 5 1.45 "Joint Development Committee" or "JDC" 5 1.46 "Lead Compound" 5
1.47 "Listed Price" 5 1.48 "Litigation Agreement" 5 1.49 "Major Indication" 6 1.50 "Marketing
Approval" 6 1.51 "Marketing Approval Application" or "MAA" 6 1.52 "Net Sales" 6 1.53 "Phase I" 6
1.54 "Phase II" 6 1.55 "Phase III" 6 1.56 "Product Specification" 7 1.57 "Preexisting Third Party
Intellectual Property" 7 1.58 "Proof of Concept" 7 1.59 "Prosecution and Interference Activities" 7
1.60 "Protected Field" 7 1.61 "Reference Materials" 7 1.62 "Relevant Standards" 7 1.63 "Sales Price"
7 1.64 "Standard Materials" 7 1.65 "Sublicensee" 8 1.66 "Technical Product Failure" 8 1.67 "Third
Party Agreements" 8 1.68 "Third Party Licensor" 8

ARTICLE 2 JOINT DEVELOPMENT COMMITTEE 8

2.1 Joint Development Committee 8 2.2 Membership 8 2.3 JDC Meetings 8 2.4 Decisions 9

ARTICLE 3 DEVELOPMENT PLANS 9

3.1 General 9 3.2 Annual Review 9 3.3 Periodic Reviews 9

ARTICLE 4 DEVELOPMENT PROGRAM 10

4.1 Development Program for the Astellas Territory 10 -ii-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 4 -->
TABLE OF CONTENTS (continued) Page 4.2 Global Harmonization 10 4.3 Selection of Lead Compounds 10
4.4 Regulatory Matters 11

ARTICLE 5 RECORDKEEPING; PUBLICATION 13

5.1 Reports and Records 13 5.2 Review of Publications 14

ARTICLE 6 DEVELOPMENT PROGRAM FUNDING 15

6.1 Payments for Reimbursement; Net Payments 15

ARTICLE 7 USE OF PRECLINICAL AND CLINICAL DATA 17

7.1 Exchange 17 7.2 Disclosure 18 7.3 Regulatory Requirements 18 7.4 Review of Protocols 18

ARTICLE 8 MARKETING RIGHTS 19

8.1 Astellas 19 8.2 FibroGen 19 8.3 Covenants 19

ARTICLE 9 TRANSFER PRICING 20

9.1 Transfer for Non-Commercial Purpose 20 9.2 Transfer for Commercial Purpose 21 9.3 Payment 22 9.4
Reference Materials; Standard Materials 22

ARTICLE 10 ADDITIONAL PAYMENTS; BOOKS AND RECORDS 22

10.1 Quarterly Reports 22 10.2 Payment Method 22 10.3 Currency Conversion 23 10.4 Taxes 23 10.5
Records; Inspections 24

ARTICLE 11 DUE DILIGENCE 24

11.1 Astellas' Due Diligence 24 11.2 FG's Due Diligence 24 11.3 Development Diligence 25

ARTICLE 12 MANUFACTURING RIGHTS 26

12.1 Procedures 26 12.2 FG Right 27 12.3 Manufacture and Supply 27 12.4 Product Specifications 27
12.5 Orders Forecast 27 -iii-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 5 -->
TABLE OF CONTENTS (continued) Page 12.6 Shipment 28 12.7 Inspection of Shipment/Right to Reject 28
12.8 Inspection of Facilities 28 12.9 Recall 29 12.10 Warranty 29 12.11 Interruption in Supply 29
12.12 Reference and Standard Materials 29

ARTICLE 13 LICENSE GRANTS 29

13.1 Grant to Astellas 29 13.2 Sublicenses 29 13.3 No Rights Beyond Lead Compounds 30 13.4 Expanded
Field Negotiation 30

ARTICLE 14 INTELLECTUAL PROPERTY 30

14.1 Ownership of Inventions 30 14.2 Patent Prosecution 31 14.3 Defense of Third Party Infringement
Claims 31 14.4 Enforcement 32 14.5 Third Party Agreements 33

ARTICLE 15 REPRESENTATIONS AND WARRANTIES 34

15.1 FG Warranties 34 15.2 Astellas Warranties 34 15.3 Disclaimer of Warranties 34

ARTICLE 16 CONFIDENTIALITY 35

16.1 Confidential Information 35 16.2 Permitted Disclosures 35 16.3 Clinical Data 36 16.4 Press
Releases 36

ARTICLE 17 INSURANCE; INDEMNIFICATION 36

17.1 Insurance 36 17.2 Indemnification of FG 36 17.3 Indemnification of Astellas 37 17.4 Procedure
37

ARTICLE 18 TERM AND TERMINATION 37

18.1 Term 37 18.2 Termination for Cause or Technical Product Failure 37 18.3 Termination in case of
Generic Competition 38 18.4 Negative Advice from Authorities 39 18.5 Admission of Invalidity or
Unenforceability of FG Patent 39 18.6 Termination upon Notice 39 -iv-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 6 -->
TABLE OF CONTENTS (continued) Page 18.7 Effect of Termination 39

ARTICLE 19 DISPUTE RESOLUTION 40

19.1 Disputes 40 19.2 Full Arbitration 40

ARTICLE 20 MISCELLANEOUS 41

20.1 Confidential Terms 41 20.2 Governing Law 41 20.3 Force Majeure 41 20.4 No Implied Waivers;
Rights Cumulative 42 20.5 Independent Contractors 42 20.6 Notices 42 20.7 Assignment 43 20.8
Modification 43 20.9 Severability 43 20.10 Counterparts 43 20.11 Headings 43 20.12 Export Laws 43
20.13 Language 43 20.14 Entire Agreement 43

EXHIBIT A LIST OF PATENTS 45

EXHIBIT B INDICATIONS 46

EXHIBIT C INITIAL DEVELOPMENT PLAN 47 -v-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 7 -->
CONFIDENTIAL EXECUTION COPY COLLABORATION AGREEMENT

This COLLABORATION AGREEMENT ("Agreement"), effective as of June 1, 2005 (the "Effective Date"), is
made by and between FibroGen, Inc., a Delaware corporation having offices at 225 Gateway Boulevard,
South San Francisco, California 94080 ("FG" or "FibroGen"), and Astellas Pharma Inc., a Japanese
corporation having offices at 3-11 Nihonbashi-Honcho, 2-Chome, Chuo-ku, Tokyo, 103-8411 Japan
("Astellas").

BACKGROUND

A. FG has a research and development program focused on the development of small molecule prolyl
hydroxylase inhibitors which stabilize hypoxia inducible factor ("HIF"), for the treatment of
anemia.

B. Astellas desires to collaborate with FG on the development and commercialization of, and license
the rights to use as therapeutics, certain small molecule prolyl hydroxylase inhibitors on the terms
and conditions set forth below for use in the Astellas Territory (as defined below).

NOW THEREFORE, for and in consideration of the covenants, conditions, and undertakings hereinafter
set forth, it is agreed by and between the parties as follows:

ARTICLE 1 DEFINITIONS

1.1 "Actions" shall have the meaning as set forth in Section 14.3 below.

1.2 "Affiliate" shall mean any entity which controls, is controlled by or is under common control
with Astellas or FG. For purposes of this definition only, "control" shall mean beneficial ownership
(direct or indirect) of at least fifty percent (50%) of the shares of the subject entity entitled to
vote in the election of directors (or, in the case of an entity that is not a corporation, for the
election of the corresponding managing authority).

1.3 "Astellas Indemnitees" shall have the meaning as set forth in Section 17.3 below.

1.4 "Astellas Territory" shall mean the country of Japan.

1.5 "Authorized Designee" shall mean an officer of FG or Astellas, as the case may be, designated by
the Chief Executive Officer of the respective corporation, that has been granted full authority to
resolve a dispute arising between FG and Astellas as required under Section 2.4 or Section 19.1
hereof.

1.6 "Bridging Strategy" shall mean the decision by Astellas to file an MAA in the Astellas Territory
by submitting the data from the Phase III clinical trial of FG or its Affiliate or Sublicensee. -1-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 8 -->
CONFIDENTIAL EXECUTION COPY 1.7 "Bulk Product" shall mean a Lead Compound supplied by FG to Astellas
as a bulk formulated drug (such as in a form, including, but not limited, to a capsule, tablet or
caplet formulation) without packaging.

1.8 "Commercialize" shall mean directly or indirectly develop, manufacture, sell, market or
distribute.

1.9 "Completion" shall be deemed to occur, with respect to a particular clinical trial for a Lead
Compound, upon clinical database lock for such trial.

1.10 "Confidential Information" shall have the meaning as set forth in Section 16.1 below.

1.11 "Control" or "Controlled" shall mean possession of the ability to grant a license or sublicense
as provided for herein without violating the terms of an agreement with a third party.

1.12 "Controlling Party" shall have the meaning as set forth in Section 14.3 below.

1.13 "Data" shall have the meaning as set forth in Section 7.1 below.

1.14 "Delivery" or "Delivered" shall mean when Lead Compound is made available by FG to Astellas at
the Ex Works location.

1.15 "Development Plan" shall mean the plan for the Development Program in effect from time to time,
as established in accordance with Article 3 below.

1.16 "Development Program" shall mean all Astellas activities with respect to the development and
commercialization of Lead Compounds for applications within the Field in the Astellas Territory, in
accordance with the Development Plan in effect at that time.

1.17 "Enforcement Action" shall have the meaning as set forth in Section 14.4 below.

1.18 "Event" shall have the meaning as set forth in Article 6 below.

1.19 "Expanded Field" shall mean the treatment of any indications in which therapeutic utility is
derived from [ * ], including, without limitation, [ * ]. The Expanded Field shall not include the
Field.

1.20 "Expenses" shall have the meaning as set forth in Section 14.3 below.

1.21 "FDA" shall mean the U.S. Food and Drug Administration, or any successor agency. -2-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 9 -->
CONFIDENTIAL EXECUTION COPY 1.22 "FG Acquired Patents" shall mean those FG Patents that are
in-licensed or otherwise acquired by FG.

1.23 "FG Development Program" shall mean those activities by or on behalf of FG directly related to
the development and commercialization of Lead Compounds for applications within the Field in the FG
Territory that are directly useful or necessary for Commercialization in the Astellas Territory.

1.24 "FG Indemnitees" shall have the meaning as set forth in Section 17.2 below.

1.25 "FG Technology" shall mean FG Patents and FG Technical Information.

1.26 "FG Patents" shall mean all patents including all reissues, renewals, re-examinations and
extensions thereof, and any patent applications therefor, including all divisionals or
continuations, in whole or in part, thereof, which claim or otherwise cover the composition,
manufacture, sale or use of a Lead Compound and that are Controlled by FG or its Affiliates during
the term of this Agreement, subject to Section 14.5.1. For purposes of this definition, a patent or
patent application shall be deemed to "cover" a Lead Compound if the manufacture, use or sale of
such Lead Compound would, but for the license granted herein, infringe, contributorily infringe or
constitute inducement to infringement of such patent or patent application, if issued or granted as
pending. All patents and patent applications listed on Exhibit A, as revised from time to time to
remove patents and/or patent applications by mutual agreement or to add patents and/or patent
applications by FG, shall be within the scope of definition of the FG Patents, provided, however,
that in the event FG designates any additional Lead Compounds, FG shall add to the list on Exhibit A
patents and patent applications which claim or otherwise cover the composition, or manufacture, sale
or use of the additional Lead Compounds within the Field and the Astellas Territory, and upon the
cessation of the designation as any compound as Lead Compound and Astellas' cessation of development
of such Lead Compound, FG shall remove at its sole discretion the related patent or patent
application from Exhibit A.

1.27 "FG Technical Information" shall mean confidential information, tangible and intangible, and
materials, including, but not limited to: trade secrets and know how, pharmaceutical, chemical,
biological and biochemical compositions; and technical and non-technical data and information,
and/or the results of tests, assays, methods and processes; and plans, specifications and/or other
documents containing said information and data; in each case that is possessed by FG as of the
Effective Date or discovered, developed or Controlled by FG or its Affiliates during the term of
this Agreement, to the extent such relates to the development, manufacture, sale or use of a Lead
Compound subject to Section 14.5.1, and such information related to a candidate for use as a Lead
Compound provided by FG to Astellas in connection with the Lead Compound selection decision
consultation process described in Section 4.3.

1.28 "FG Territory" shall mean all areas of the world outside of the Astellas Territory. -3-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 10 -->
CONFIDENTIAL EXECUTION COPY 1.29 "Field" shall mean the treatment of anemia solely in the
Indications, by means of the stabilization of HIF causing the stimulation of erythropoiesis
(including an increase in endogenous erythropoietin production) and/or a subsequent increase in
hematocrit through modulation of prolyl hydroxylase and/or asparaginyl hydroxylase. For purposes of
clarity, FG and Astellas agree and acknowledge that the Field and the Indications exclude [ * ].

1.30 "First Commercial Sale" shall mean, with respect to each Lead Compound, the first bona fide
commercial sale of such Lead Compound to a non-Affiliate third party by or under authority of
Astellas or FG, or their Affiliates or Sublicensees, as the case may be, in the FG Territory or the
Astellas Territory, respectively.

1.31 "Force Majeure Event" shall mean the occurrence of any event causing a failure to perform where
failure to perform is beyond the reasonable control of the non-performing party, as described in
Section 20.3.

1.32 "Fully Burdened Costs" with respect to a Lead Compound shall mean all costs to produce, package
and distribute the product to Astellas or its carrier at the Ex Works location (in compliance with
Section 12.6) and any royalties or other consideration (not reimbursed by Astellas) paid to third
parties related to the acquisition or sale of product, with costs to produce and package the product
to include the direct material, labor and indirect costs that are incurred by FG or its Affiliate(s)
associated with the manufacture, filling, packaging, labeling, preparation of product for shipment
and/or other preparation of such Lead Compound, as applicable, including, but not limited to taxes,
fees, and customs incurred, as applicable. Costs will be determined in accordance with U.S.
Generally Accepted Accounting Principles (U.S. GAAP) and will include but not be limited to the
costs of facilities, labor, purchasing, depreciation of equipment, materials, payments to third
parties for any necessary contract work related to the manufacture or testing of the product, the
validation studies, quality assurance, quality control and other testing, storage, shipping (if
requested by Astellas), costs related to distribution and a reasonable allocation of general and
administrative overhead. Costs related to distribution include the labor, materials and overhead
necessary to prepare and package the final product for shipment to the Ex Works location.

1.33 "Future Third Party Intellectual Property" shall mean any intellectual property rights,
including without limitation all patents, trademarks, or copyrights, and any applications therefor,
including any applications for registration, issuance, or grant thereof, owned or Controlled by a
third party that are necessary for the practice of the license granted hereunder that were not owned
or Controlled by FG as of the Effective Date and that do not qualify as Pre-existing Third Party
Intellectual Property under Section 1.56.

1.34 "GMP Guidelines" shall mean then-current applicable Good Manufacturing Practices guidelines and
regulations of the FDA.

1.35 "[ * ]" shall have the meaning as set forth in Section 1.36 below. -4-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 11 -->
CONFIDENTIAL EXECUTION COPY 1.36 "[ * ] Percentage" shall be determined, for any Lead Compound, (i)
by dividing (a) the [ * ], which shall be defined as the difference between (x) the [ * ], and (y)
the [ * ], by (b) the [ * ]; and (ii) multiplying the result of (i) above by 100.

1.37 "HIF" shall mean hypoxia inducible factor.

1.38 "IND" shall mean an Investigational New Drug application, as defined in the U.S. Federal Food,
Drug and Cosmetic Act and the regulations promulgated thereunder, or comparable filing in a foreign
jurisdiction, in each case with respect to a Lead Compound for use within the Field.

1.39 "Indemnitee" shall have the meaning as set forth in Section 17.4 below.

1.40 "Indemnitor" shall have the meaning as set forth in Section 17.4 below.

1.41 "Indications" shall mean those indications listed on Exhibit B and any other indications to be
agreed upon hereafter between FG and Astellas, each of which shall be referred to as an Indication.

1.42 "Initial Development Plan" shall mean the Initial Development Plan as described in Section
3.2.1 hereof.

1.43 "Initiate" or Initiation" shall mean with respect to a particular clinical trial for a Lead
Compound, the initial dosing of the first patient in such trial in accordance with the protocol
therefor.

1.44 "Inspected Party" and "Inspecting Party" shall have the meanings as set forth in Section 10.5
below.

1.45 "Joint Development Committee" or "JDC" shall have the meaning as set forth in Section 2.1
below.

1.46 "Lead Compound" shall mean any compound Controlled by FG that is designated by FG as a lead
compound for clinical development in an Indication in accordance with Section 4.3 for the duration
of such designation. Any Lead Compound which receives a Marketing Approval in the Astellas Territory
shall remain a Lead Compound for the duration of such Marketing Approval. As of the Effective Date,
FG-2216 shall be deemed to be a Lead Compound.

1.47 "Listed Price" shall have the meaning as set forth in Section 9.2.

1.48 "Litigation Agreement" shall have the meaning as set forth in Section 14.4 below. -5-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 12 -->
CONFIDENTIAL EXECUTION COPY 1.49 "Major Indication" shall have the meaning set forth in Section
11.3.1 below.

1.50 "Marketing Approval" shall mean, with respect to each Lead Compound, approval in the Astellas
Territory by the Japanese Ministry of Health, Labour and Welfare, or in the FG Territory by U.S. or
European regulatory authorities, as the case may be, to market such Lead Compound for an indication
within the Field. It is understood that pricing or reimbursement approval shall constitute a part of
the Marketing Approval. In any event, Marketing Approval shall be deemed to have occurred with
respect to a Lead Compound no later than the date of the First Commercial Sale of such Lead Compound
in the FG Territory or the Astellas Territory as the case may be, by or under authority of FG or
Astellas respectively, or their Affiliate or Sublicensee, as the case may be, whether or not formal
approval by the relevant health regulatory authority is required for the First Commercial Sale of
such Lead Compound.

1.51 "Marketing Approval Application" or "MAA" shall mean, within the FG Territory, a New Drug
Application or similar application as required under the U.S. Federal Food, Drug and Cosmetics Act
and the regulations promulgated thereunder, or such similar filing in Europe, or a comparable filing
for Marketing Approval in the Astellas Territory, in each case with respect to a Lead Compound for
use within the Field.

1.52 "Net Sales" shall mean the gross amount billed or invoiced by Astellas, its Affiliates and its
Sublicensees to unaffiliated third parties for the Lead Compound(s) in bona fide arm's length
transaction, less the following deductions:

i) credits or allowances, if any, given or made on account of rejection or return of the Lead
Compound(s);

ii) trade and quantity discounts actually allowed and taken in such amounts as are customary in the
trade;

iii) duties, sales taxes, excise taxes, insurance and transportation charges actually paid; and

iv) charge back payments or rebates actually paid to wholesalers.

1.53 "Phase I" shall mean human clinical trials, the principal purpose of which is preliminary
determination of safety in healthy individuals or patients as required in 21 C.F.R. §312.21, or
similar clinical study in a country other than the United States, and for which there are no primary
endpoints relating to efficacy included in the protocol.

1.54 "Phase II" shall mean human clinical trials, for which the primary endpoints include a
determination of dose ranges and/or a preliminary determination of efficacy in patients with the
Indication being studied as required in 21 C.F.R. §312.21, or similar clinical study in a country
other than the United States.

1.55 "Phase III" shall mean human clinical trials, the principal purpose of which is to establish
safety and efficacy of one or more particular doses in patients with the Indication being studied as
required in 21 C.F.R. §312.21, or similar clinical study in a country -6-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 13 -->
CONFIDENTIAL EXECUTION COPY other than the United States. For purposes of this Section 1.55, and
Sections 1.53 and 1.54 above, a particular trial that (i) is intended to overlap two phases of
trials, (ii) combines the elements of two phases of trials, or (iii) is treated by the FDA or
comparable foreign agency as two phases of trials, such as a Phase I/II trial or a Phase II/III
trial, shall be deemed a trial of the later, as well as the earlier, phase (i.e., a Phase II and a
Phase III, respectively).

1.56 "Product Specification" shall mean, with respect to a Bulk Product, the written document
describing, the testing procedures and results required to determine compliance with release
specifications, including, and quality control testing procedures to be determined, and be amended
from time to time, by mutual agreement of both parties. The release specifications of such Product
Specifications shall be determined taking into account and shall be designed to meet the shelf life
requirements of the Japanese Ministry of Health, Labor and Welfare for the Lead Compound, provided,
that the Product Specifications shall not require compliance with such shelf life requirements.

1.57 "Preexisting Third Party Intellectual Property" shall mean any intellectual property rights,
including without limitation all patents, trademarks, copyrights, and any applications therefor,
including any applications for registration, issuance, or grant thereof, owned or Controlled by a
third party that are necessary for the practice of the license granted hereunder and that the
existence of which was discoverable or otherwise could have been known on or prior to the Effective
Date and were not owned or Controlled by FG as of the Effective Date.

1.58 "Proof of Concept" shall mean for any Indication, a demonstration of correction of anemia in
relevant patients in a human clinical study.

1.59 "Prosecution and Interference Activities" shall mean the preparation, filing, prosecution and
maintenance of patent applications and patents and any continuing applications thereof, and any
re-examinations, reissues, renewals and requests for patent term extensions therefor, and any U.S.,
international or foreign counterparts of any of the foregoing, together with the conduct of any
interference, opposition or other similar proceeding pertaining to patent applications or patents.

1.60 "Protected Field" shall have the meaning as set forth in Section 14.1.

1.61 "Reference Materials" shall have the meaning as set forth in Section 12.12 below.

1.62 "Relevant Standards" shall have the meaning as set forth in Section 12.8 below.

1.63 "Sales Price" shall mean the price per unit obtained by dividing the Net Sales during the
relevant calendar quarter by the number of units sold during the same period.

1.64 "Standard Materials" shall have the meaning as set forth in Section 12.12 below. -7-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 14 -->
CONFIDENTIAL EXECUTION COPY 1.65 "Sublicensee" shall mean a third party to whom FG or Astellas has
directly or indirectly granted the right in its respective territory to make, use and sell a Lead
Compound or a third party to whom FG or Astellas has directly or indirectly granted the right to
distribute a Lead Compound supplied by FG or Astellas (respectively). For purposes of this
Agreement, FG and Astellas shall not be deemed Sublicensees of the other.

1.66 "Technical Product Failure" shall mean as a [ * ], which is not attributed to Astellas' failure
to fulfill its obligations hereunder.

1.67 "Third Party Agreements" shall mean collectively those agreements between FG and a third party
existing as of the Effective Date, pursuant to which FG obtained rights applicable to the
development, manufacture, sale or use of Lead Compounds hereunder (but excluding options or similar
agreements to acquire such rights). If, after the Effective Date, FG enters into an agreement to
license or acquire rights from a third party with respect to subject matter to be utilized in
connection with Lead Compounds in accordance with Section 14.5 below, such agreements shall also be
deemed Third Party Agreements for purposes of this Agreement.

1.68 "Third Party Licensor" shall have the meaning as set forth in Section 14.5.1 below.

ARTICLE 2 JOINT DEVELOPMENT COMMITTEE

2.1 Joint Development Committee. Astellas and FG shall establish a joint development committee to
oversee, review and coordinate the research and development of Lead Compounds for applications
within the Field pursuant to the Development Program ("Joint Development Committee" or "JDC"). From
time to time, the JDC may establish subcommittees or project teams to oversee particular projects or
activities, and such subcommittees or project teams will be constituted as the JDC agrees (e.g., for
oversight of the development or other day-to-day matters).

2.2 Membership. The JDC shall be comprised of an equal number of representatives from each of
Astellas and FG, selected by such party. The exact number of such representatives shall be [ * ] for
each of Astellas and FG, or such other number as the parties may agree. Subject to the foregoing
provisions of this Section 2.2, FG and Astellas may replace its respective JDC representatives at
any time, upon prior written notice to the other party.

2.3 JDC Meetings. The JDC shall meet no fewer than [ * ] times each calendar year, or as otherwise
agreed by the parties, with the understanding that [ * ] meetings are to be held at mutually agreed
locations alternating among Japan, California, Hawaii, or at such other locations as the parties
agree, and the other [ * ] meetings are to be held by means of telecommunication, videoconference or
correspondence as deemed appropriate. The parties shall conduct team meetings at the same time and
location as the JDC meetings. At its meetings, the JDC will, as applicable, (i) formulate and review
the Development Program objectives, including approval of all proposed pre-clinical and clinical
studies to be performed, (ii) monitor the progress of the Development Program toward those
objectives, (iii) review and approve the -8-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 15 -->
CONFIDENTIAL EXECUTION COPY Development Plan, pursuant to Section 3.3 of this Agreement, including
review, approve and monitor the progress of the clinical and regulatory plans, (iv) resolve issues
surrounding the marketing of the Lead Compounds, (v) discuss the selection of Lead Compounds, (vi)
coordinate manufacturing issues, including the development of standards, scheduling of batch
production, and qualification with regulatory requirements for the Astellas Territory, (vii) resolve
issues arising out of the Development Program or this Agreement, and (viii) undertake and/or approve
such other matters as are specifically provided for the JDC under this Agreement. One meeting each
year will be focused specifically on setting Development Program goals and strategy. Other
representatives of FG or Astellas may attend JDC or subcommittee meetings as non-voting observers.
Astellas' lead representative shall chair the meetings and shall be responsible for preparing the
agenda and minutes for such meetings, and shall provide such minutes to FG in English. Such minutes
as approved by the JDC shall constitute the official record of the actions of the JDC. The JDC may
also convene or be polled or consulted from time to time by means of telecommunications,
videoconferences or correspondence, as deemed necessary or appropriate. Each party shall bear its
own personnel, travel and lodging expenses relating to JDC meetings.

2.4 Decisions. Decisions of the JDC shall be made by unanimous agreement of the members present in
person or by other means (e.g., teleconference) at any meeting; provided that at least two (2)
representatives of each party is present at such meeting. In the event that the JDC is unable to
reach unanimous agreement on an issue, the issue shall be referred for resolution in accordance with
Article 19 hereof.

ARTICLE 3 DEVELOPMENT PLANS

3.1 General. Subject to Section 3.2 below, Astellas shall prepare and propose to the JDC a detailed
Development Plan pursuant to which the Development Program will be performed. The Development Plan
shall specify the objectives and work plan activities by Astellas with respect to the Development
Program.

3.2 Annual Review

3.2.1 Initial Development Plan. The initial Development Plan is attached hereto as Exhibit C (the
"Initial Development Plan"), and shall be fixed for the period from the Effective Date through March
31, 2006, unless otherwise agreed by the JDC.

3.2.2 Other. Beginning upon the date of signing of this Agreement and by December 31 of each year
thereafter until expiration or termination of this Agreement, Astellas shall submit to the JDC the
proposed plan required under Section 3.1 above for the following fiscal year, including for
regulatory activities within the Astellas Territory. The JDC shall review such proposals as soon as
possible and shall approve the Development Plan for such following fiscal year, with such changes as
the JDC may agree to the plan proposed by Astellas, no later than March 15 of the current fiscal
year.

3.3 Periodic Reviews. The JDC shall review the Development Plan on an ongoing basis and may make
changes thereto including variances to the Development Plan in effect. -9-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 16 -->
CONFIDENTIAL EXECUTION COPY ARTICLE 4 DEVELOPMENT PROGRAM

4.1 Development Program for the Astellas Territory. Astellas shall follow FG's development
activities for the Lead Compounds, (i.e., Astellas shall develop, and shall have the right and
obligation to develop, only those compounds that FG has designated as Lead Compounds, for the
duration of such designation and for which FG or its Sublicensee is pursuing clinical development in
the FG Territory), for those Indications being developed by FG or its sublicensee, and such Astellas
development shall comply with, without limitation the procedures set forth in Section 11.3.1. In
fulfillment thereof, Astellas shall conduct, directly or through third parties, the Development
Program for the Astellas Territory, all in accordance with the Development Plan then in effect, and
shall be responsible for all costs related to the Astellas Territory. Astellas agrees to keep the
JDC informed as to the progress of its activities under the Development Program for Lead Compounds
hereunder. FG shall, subject to Section 4.2.2, provide reasonable assistance to Astellas regarding
Astellas' performance of its development activities within the scope of the Development Program
hereunder and provide updates to Astellas as to the FG Development Program. It is understood and
agreed that the Development Program for the Astellas Territory shall include all clinical trials and
other development activities necessary to obtain Marketing Approvals for Lead Compounds for the
Astellas Territory.

4.2 Global Harmonization

4.2.1 Reporting; Redundant Activities. FG shall provide to Astellas regular reports with respect to
the FG Development Program with respect to the Lead Compounds. Such reports may be provided at the
JDC meetings provided for in Section 2.3. Recognizing that the Lead Compounds may be developed on a
global basis and that regulatory and budget efficiencies can be achieved through the worldwide use
of appropriate data and files, the parties will seek to design pre-clinical and clinical development
activities included in the Development Plan in a manner to maximize global clinical and regulatory
harmonization.

4.2.2 Additional Activities. Without limiting the obligations set forth in 4.2.1, the costs of any
non-clinical or clinical developmental work, whether performed by Astellas or FG, to support needs
specific to the Astellas Territory and not required to be performed for the FG Territory, or at the
request of Astellas, shall be borne by Astellas.

4.3 Selection of Lead Compounds. FG shall consult with Astellas with respect to Lead Compound
selection, and shall provide to Astellas information as reasonably necessary to evaluate Lead
Compound candidates in connection with the Lead Compound selection process, including without
limitation the information relating to patent situations in the Astellas Territory. For the
avoidance of doubt, such Lead Compound candidates shall potentially include any and all compounds
Controlled by FG during the term hereof for use in the Field. Notwithstanding anything contained in
this Agreement, FG shall designate, at its sole discretion but in line with the basic policy that
the same Lead Compound shall be Commercialized both in Astellas Territory and FG Territory for the
same Indication(s), Lead Compound(s) in accordance with the terms of this Section 4.3, and shall
notify the JDC of such designations. At any one time, FG may designate up to two (2) Lead Compounds
for Commercialization in any Indication; provided, that in the event that FG designates two (2) Lead
-10-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 17 -->
CONFIDENTIAL EXECUTION COPY Compounds for Commercialization in an Indication, it shall designate one
(1) as the primary Lead Compound and one (1) as the secondary Lead Compound. In the event FG
determines to cease development of a primary Lead Compound in an Indication, FG may designate the
secondary Lead Compound as the primary Lead Compound for such Indication. In the event, prior to
Marketing Approval in the Astellas Territory, FG determines to stop development of a Lead Compound,
FG shall notify the JDC, and upon such notification, such compound shall no longer be considered a
Lead Compound; provided, however, that Astellas may complete those development activities on-going
at the time of such notification for such Lead Compound for a reasonable period of time, unless such
notification is based on safety concerns. In the event FG determines to [ * ], FG shall [ * ] within
[ * ] days of such [ * ]. In the event that FG [ * ], Astellas may, subject to the [ * ], [ * ],
provided, however, that the [ * ] shall apply upon the [ * ] set forth in such Sections, rather than
the [ * ].

4.4 Regulatory Matters

4.4.1 Regulatory Filing. FG shall be responsible, directly or through third parties, for the
preparation, filing and maintenance of all regulatory documents in the FG Territory with respect to
the Lead Compound(s), which shall be filed in the name of FG or its designee. Astellas shall be
responsible for all preparation, filing and maintenance of all regulatory documents in the Astellas
Territory with respect to the Lead Compound(s), which shall be filed in the name of Astellas.
Astellas shall select and own the trademark(s) to be used to identify any Lead Compound in the
Astellas Territory.

4.4.2 Reporting Adverse Experiences

(a) With respect to adverse drug experiences relating to any Lead Compound, the parties shall
promptly report such experiences to the appropriate regulatory authorities in the countries in which
such Lead Compound is being developed or commercialized, in accordance with the appropriate laws and
regulations of the relevant countries and authorities, and each party shall ensure that its
Affiliates and Sublicensees comply with such reporting obligations. In addition, in order that each
party may be fully informed of these experiences, each party shall report to the other party all
"adverse events" involving such Lead Compound. "Serious adverse events" for all fatal and
life-threatening adverse events shall be reported to the designated safety contact person of the
other party by e-mail within five (5) calendar days of a party's and/or its agent's becoming aware
of such an event (a "reporting party"), and all other serious adverse events shall be forwarded to
the other party within seven (7) calendar days of the reporting party's and/or its agent's becoming
aware of such an event. To the extent legally possible, FG and Astellas shall report to the other
all serious adverse events with respect to a Lead Compound in the Field at least twenty-four (24)
hours prior to reporting the same to a regulatory authority, and shall report adverse events which
may constitute a dose limiting toxicity in a reasonably prompt time after the occurrence of such
event. The reporting party shall report all non-serious adverse events on a monthly basis; provided
that, non- serious adverse event data arising from a clinical trial will be included in the clinical
trial report which -11-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 18 -->
CONFIDENTIAL EXECUTION COPY shall be prepared and sent to the other party as soon as practicable
following completion of the final clinical report.

(b) An "adverse event" is any negative symptom experienced at the time of or after the taking of a
medicinal (investigational) product, whether or not considered a medicinal (investigational) product
related, including any side effects, injury, toxicity or sensitivity reaction, or significant
failure of expected pharmacological action. Also included are instances of symptomatic overdose,
abuse or withdrawal reactions.

(c) A "serious adverse event" includes any of the following outcomes: death, a life-threatening
event; that is, an adverse event that puts the patient at risk of dying, requires hospitalization,
prolongs existing hospitalization or results in persistent or significant incapacity or disability,
congenital anomaly/birth defect. Other important medical events that may otherwise jeopardize a
patient or may require intervention to prevent one of the statuses of patients listed in the
preceding sentence shall also be considered serious.

(d) The parties also agree to develop and implement such other procedures as may be necessary or
appropriate to ensure that each party remains in compliance with all reporting requirements imposed
by any regulatory authority in the Astellas Territory, and in the FG Territory. Upon the Initiation
of Phase III, FG shall implement and be responsible for the maintenance of a complete global safety
database. FG will be responsible for preparing, with Astellas' cooperation set forth below in this
Section 4.4.2(d), Periodic Safety Reports for clinical studies requested by European and U.S.
authorities, and Periodic Safety Update Reports (PSURs). FG shall send a draft PSUR for review to
Astellas in the beginning of week 5 after database lock point. Astellas has one week for review. FG
shall provide copies of the final PSURs to Astellas in the same timing as they are submitted to the
authorities. Astellas will provide FG with the data needed for making the PSURs. Maintenance of
Company Core Safety Information (CCSI) is under the responsibility of FG who will communicate all
revisions to Astellas. FG shall prepare the periodic safety reports for clinical studies requested
by European and U.S. authorities and provide Astellas with the copy of such reports at the time of
submission to the regulatory authorities in the FG Territory. Astellas will provide FG with the data
needed for making such periodic safety reports.

(e) Each party shall immediately inform the other party of measures taken in order not to jeopardize
public health or hygiene including but not limited to, discontinuation of manufacture, import and
marketing, clinical trial suspension, recall and disposal of the Lead Compound or the product or the
prescription product, irrespective of whether it is due to regulatory actions or voluntary actions.
-12-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 19 -->
CONFIDENTIAL EXECUTION COPY (f) Both parties hereby nominate the safety contact persons as follows:

Medical Affairs Department FibroGen, Inc. 225 Gateway Boulevard San Francisco, California 94080
Attn: Vice President, Medical Affairs Tel: 1-650-866-7875 Fax: 1-650-866-7360
E-mail:dyeowell@fibrogen.com

With a copy to: Chief Executive Officer FibroGen, Inc. 225 Gateway Boulevard San Francisco,
California 94080 Tel: 1-650-866-7200 Fax: 1-650-866-7201 E-mail:tneff@fibrogen.com Pharmacovigilance
Department, QA, RA, and Pharmacovigilance Division Astellas Pharma Inc. [ * ]

The safety contact persons for each party hereto may be updated from time to time as necessary upon
notice to the other party.

ARTICLE 5 RECORDKEEPING; PUBLICATION

5.1 Reports and Records. Each of Astellas and FG shall use best efforts to maintain (or cause such
records to be maintained) records of the Development Program and FG Development Program,
respectively, in sufficient detail and in good scientific manner as will properly reflect all work
done and results achieved in the performance of the Development Program or FG Development Program,
as the case may be. Upon [ * ] days advance notice or such shorter time period as may be required in
order to meet any regulatory requirements, each party shall allow the other party to have access to
all records, materials and data generated by or on behalf of such party with respect to each Lead
Compound for applications within the Field at reasonable times, in a reasonable manner and, upon
request, to the extent required under Article 7 hereof. -13-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 20 -->
CONFIDENTIAL EXECUTION COPY 5.1.1 Retention. Each of Astellas and FG shall retain its records for
the minimum period of time required by applicable law in all cases, and for not less than [ * ]
following the expiration or termination of this Agreement.

5.1.2 Reports. Not less than [ * ] prior to each JDC meeting under Section 2.3 above, each of
Astellas and FG shall provide the JDC with a written report in English; Astellas' report summarizing
the progress of the Development Program, including the developmental, clinical and other activities
performed by Astellas, its Affiliates and/or Sublicensees with respect to each Lead Compound during
the preceding period; and FG's report summarizing the progress of the FG Development Program.

5.1.3 Activities Outside the Field. The parties understand and acknowledge that FG is engaged in
other research and development activities directed to prolyl hydroxylase inhibition and/or the
stabilization of HIF, and that the focus of this collaboration and the Development Program is
directed to the Field. Accordingly, it is understood that, notwithstanding any other provision of
this Agreement, the obligations of FG specified herein to make available and disclose to Astellas
data, technical information, scientific results and findings and other subject matter is limited in
each case to subject matter directed to Lead Compounds within the Field.

5.2 Review of Publications. As soon as is practicable prior to the oral public disclosure, and prior
to the submission to any outside person for publication of scientific data resulting from the
Development Program, in each case to the extent the contents of the oral disclosure or publication
have not been previously disclosed pursuant to this Section 5.2 before such proposed disclosure, FG
or Astellas, as the case may be, shall provide to the other party a copy of the publication, or a
written summary of any oral disclosure, to be made or submitted, and shall allow the other party at
least [ * ], to determine whether such disclosure or publication contains subject matter for which
patent protection should be sought prior to publication or which either party believes should be
modified to avoid disclosure of Confidential Information or regulatory or other issues. With respect
to publications by investigators or other third parties of scientific data resulting from the
Development Program, such disclosures and publications shall also be subject to review by the
reviewing party under this Section 5.2.

5.2.1 Publication Rights. Subject to the provisions of Articles 7 and 16, after the expiration of [
* ] from the date of receipt of such disclosure or publication, unless the authoring party has
received the written notice specified below, the authoring party shall be free to submit such
publication or to orally disclose or publish the disclosed research results in any manner consistent
with academic standards.

5.2.2 Disapproval of Publication. Prior to the expiration of the [ * ] period specified in Section
5.2.1 above, the reviewing party may notify in writing the submitting party of its determination
that such oral presentation or publication contains Confidential Information of the reviewing party
or objectionable material or material that consists of patentable subject matter of the reviewing
party for which patent protection should be sought. In such event, and unless otherwise mutually
agreed, the submitting party shall withhold publication of its disclosure. -14-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 21 -->
CONFIDENTIAL EXECUTION COPY ARTICLE 6 DEVELOPMENT PROGRAM FUNDING

6.1 Payments for Reimbursement; Net Payments. FG hereby acknowledges receipt of U.S. $[ * ] on
February 13, 2004, U.S. $[ * ] on January 28, 2005, and U.S. $[ * ] on March 22, 2005 as initial
payments for reimbursement of historical research and development expenditures for the Lead
Compounds. Astellas agrees to pay to FG the amounts set forth in Section 6.1.1 below. The parties
hereto acknowledge that the Development Program hereunder involves a high degree of risk and
uncertainty; accordingly, both parties hereto expressly disclaim any implied warranty as to the
results of the Development Program.

6.1.1 Reimbursement Payments. As reimbursement and payment for FG's historical research and
development expenditures with respect to pre-clinical and clinical development of Lead Compounds,
Astellas agrees to make the following non-refundable, non-creditable (except as set forth in Section
14.3 below) reimbursement payments to FG upon the first occurrence of each event specified below
(each, an "Event"): EVENT AMOUNT 1. Upon [ * ], provided, that U.S. $[ * ] million of such amount
shall be paid no later than [ * ] irrespective of whether the [ * ] has occurred. U.S. $[ * ]

2. Upon each of [ * ], for a total of U.S. $[ * ] U.S. $[ * ]

3. Upon [ * ] or in the event that Astellas chooses to utilize the Bridging Strategy, the payment
shall be made concurrent with the payment required in paragraph 4 of this Section 6.1.1 below. U.S.
$[ * ]

4. Upon the first [ * ]. U.S. $[ * ]

6.1.2 Product Approval Payments. As reimbursement and payment for FG's historical and ongoing
research and development expenditures with respect to pre-clinical and clinical development of Lead
Compounds and as payment for the successful marketing and sales of Lead Compound(s), Astellas agrees
to make the following non-refundable, non-creditable (except as set forth in Section 14.3 below)
reimbursement payments to FG upon the first occurrence of each Event (other than paragraph 5 of this
Section 6.1.2 below) specified below. Notwithstanding the foregoing, in the event that Astellas
decides not to pursue Commercialization in [ * ] set forth in paragraph 3 or 4 of this Section
6.1.2, the milestone payment associated with the [ * ] set forth in paragraph 3 -15-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 22 -->
CONFIDENTIAL EXECUTION COPY shall be due and payable upon the first [ * ] of either [ * ], and the
milestone payment associated with the [ * ] set forth in paragraph 4 shall be due and payable upon
the second [ * ] for a [ * ]; and in the event Astellas decides to pursue only [ * ] set forth in
paragraph 3 or 4 of this Section 6.1.2, and pursues Commercialization of either of the [ * ], the
milestone payment for associated with the [ * ] for the [ * ] shall be due and payable upon the
first [ * ] for a [ * ]; and in the event that Astellas decides to pursue [ * ] set forth in
paragraphs 3 and 4 of this Section 6.1.2 and also does not pursue [ * ], the parties shall a [ * ]
for which the milestone payments associated with the [ * ] set forth in paragraph(s) 3 and/or 4 of
this Section 6.1.2, as the case may be, shall be due, as negotiated in good faith by the parties
hereto. EVENT AMOUNT 1. Upon the first [ * ] for the [ * ]; provided, that in the event Astellas
chooses the Bridging Strategy, such payment shall be increased by an additional U.S. $[ * ] for a
total of U.S. $[ * ] U.S. $[ * ]

2. Upon the first [ * ] in the Astellas Territory for the [ * ]; provided, that in the event
Astellas chooses the Bridging Strategy, such payment shall be increased by an additional U.S. $[ * ]
for a total of U.S. $[ * ]. U.S. $[ * ]

3. Upon the first [ * ] in the Astellas Territory for the [ * ]; provided, that in the event
Astellas chooses the Bridging Strategy, such payment shall be increased by an additional U.S. $[ * ]
for a total of U.S. $[ * ]. U.S. $[ * ]

4.

Upon the first [ * ] in the Astellas Territory for the first indication within [ * ] (see Exhibit
B); provided, that in the event Astellas chooses the Bridging Strategy, such payment shall be
increased by an additional U.S. $[ * ] for a total of U.S. $[ * ].

U.S. $[ * ]

-16-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 23 -->
CONFIDENTIAL EXECUTION COPY

5. Upon [ * ] in the Astellas Territory for each of up to [ * ] indications listed on Exhibit B,
including separate indications within [ * ] up to a total of U.S. $[ * ]. U.S. $[ * ]

6.1.3 Sales Success Payments. As reimbursement and payment for FG's historical and ongoing research
and development expenditures with respect to pre-clinical and clinical development of Lead Compounds
and as payment for the successful marketing and sales of the Lead Compound(s), Astellas agrees to
make the following non-refundable, non-creditable (except as set forth in Section 14.3 below)
reimbursement payments to FG upon the first occurrence of the Event specified below. EVENT AMOUNT
Upon receipt of [ * ] aggregate annual Net Sales achieved for the first time in the Astellas
Territory for all indications and Lead Compounds by Astellas and its Affiliates and Sublicensees.
U.S. [ * ]

If at the occurrence of an Event (except for Event 2) as set forth in Section 6.1.1 above with
respect to a particular Lead Compound the payment corresponding to the occurrence of any preceding
Event (except for Event 2) (i.e., "previous" as contemplated by the Event number sequence specified
above) has not been made, then the corresponding payment(s) for such preceding Event (except for
Event 2) shall then be due.

The payments set forth in Sections 6.1.1, 6.1.2 and 6.1.3 hereof shall each be due and payable
within [ * ] after occurrence of the corresponding Event. Astellas agrees to promptly notify FG in
writing of its achievement of any Event under Sections 6.1.1, 6.1.2 and 6.1.3.

ARTICLE 7 USE OF PRECLINICAL AND CLINICAL DATA

7.1 Exchange. Subject to the provisions of this Article 7 and Article 16 below, the parties shall
have access to the underlying preclinical and clinical data (including raw data thereof), analysis,
reports, protocols and correspondence (collectively with such filings, "Data"), at reasonable times,
upon fifteen (15) days advance notice or such shorter notice as may be required in order to meet any
regulatory requirements and (upon request) in English, (it being understood and agreed that Astellas
shall provide in English without cost to FG summaries of all final reports and all documents
necessary to comply with regulatory and legal requirements, and -17-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 24 -->
CONFIDENTIAL EXECUTION COPY shall provide all other documents in English with reasonable costs
shared equally between the parties) of the other party in accordance with the following:

(a) FG shall have access to and the right to use for any purpose, any Data developed by or on behalf
of Astellas or its Affiliates or Sublicensees in the course of the Development Program with respect
to indications within the Field for Lead Compounds. Astellas shall obtain from such Sublicensees
access to all Data prepared by or for such Sublicensee with respect to a Lead Compound, with the
right to provide such Data and/or access to FG and its Sublicensees, and any sublicense failing to
provide such obligation on the part of the Sublicensee shall be voidable at the option of FG.

(b) Astellas shall have access to and the right to use solely for the purpose of this Agreement, any
Data developed by or on behalf of FG or its Affiliates or Sublicensees with respect to Lead
Compounds in connection with the Field (i) to the extent necessary to support the application to the
regulatory authority in the Astellas Territory or to fulfill other Japanese Ministry of Health,
Labor and Welfare regulatory requirements, or (ii) if not necessary to support such application or
to fulfill such Japanese Ministry of Health, Labor and Welfare regulatory requirements, to the
extent FG is permitted subject to FG's third party obligations; provided that FG shall [ * ]
negotiate the availability of such Data to Astellas from such Sublicensee, and provided, further,
that Astellas agrees not to use or disclose to third parties any such data for purposes outside the
Field except as authorized under this Agreement.

7.2 Disclosure. Subject to the provisions of this Section 7.2, FG and Astellas may each provide
copies or summaries of Data to its Affiliates and/or its permitted Sublicensees to the extent
reasonably necessary for the development and commercialization of Lead Compounds in accordance with
this Agreement, or in the case of FG of products other than Lead Compounds. It is understood that
the foregoing shall include the right to disclose Data to third parties with whom Astellas or FG are
discussing entering into agreements for such permitted purposes, subject to reasonable conditions of
confidentiality, provided, that Astellas may not disclose any Data to any third party competitor of
FG within the Field worldwide without the prior written consent of FG.

7.3 Regulatory Requirements. Notwithstanding the provisions of Section 7.2, in all agreements with
third parties or Affiliates involving the development of Data, FG and Astellas, respectively, shall
require that such third parties and Affiliates provide the other party with all such Data, to the
extent such Data is required in order for each party to meet its obligations to the other party
under Section 4.4.2 above.

7.4 Review of Protocols. Astellas agrees that all final protocol summaries for all clinical trials
and GLP toxicology studies to be conducted by or under authority of Astellas will be subject to the
review and approval of the JDC, in accordance with the following procedures set forth in this
Section 7.4. Astellas shall submit to FG and the JDC the original draft protocol summary in English
for any clinical trial or GLP toxicology study it proposes to conduct, and such protocol summary
shall be reviewed and approved by the JDC. The protocol summary shall contain all information as may
be requested by the JDC. Upon Astellas' completion of the final protocol for the proposed clinical
trial or GLP toxicology study, in the -18-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 25 -->
CONFIDENTIAL EXECUTION COPY event that such protocol deviates from the original protocol summary,
Astellas shall resubmit to FG and the JDC for review and approval a revised, final protocol summary
that indicates all changes from the original protocol summary. Notwithstanding the foregoing, FG
reserves the right to request and Astellas shall provide any portion of full text of the protocols
in English for review by the JDC, which portion is at issue. In the event FG requests such a full
text protocol, it shall review and provide comments to the JDC as soon as practicable, and within
five (5) business days of receipt.

ARTICLE 8 MARKETING RIGHTS

8.1 Astellas. Astellas shall have the exclusive right to market, sell and distribute the Lead
Compounds supplied by FG for use in the Astellas Territory within the Field under the license
granted in Article 13. Astellas may exercise its rights under this Section 8.1 through one or more
Sublicensees; provided, that any such Sublicensee agrees to terms identical in all material respects
to those contained in this Agreement, and, provided, further, that any arrangement between Astellas
and an Astellas Sublicensee with respect to a Lead Compound shall be subject to the requirements of
Section 13.2.

8.2 FibroGen. FG shall have the exclusive right, including the right to authorize others, to market,
sell and distribute the Lead Compounds for any use in the FG Territory. Subject to the restrictions
contained in Section 8.3.4 hereof, FG retains the exclusive right, including the right to authorize
others, to market, sell and distribute worldwide the Lead Compounds for use outside the Field.

8.3 Covenants

8.3.1 General. It is understood that, with respect to any particular Lead Compound, whether or not
the use and sale of such Lead Compound by FG and/or Astellas in any country requires a license under
intellectual property rights of the other, neither FG nor Astellas shall market, sell or distribute
a Lead Compound anywhere in the world except in accordance with this Agreement, including this
Article 8.

8.3.2 Independent Activities by Astellas. During the term of this Agreement, in the event Astellas
seeks to Commercialize any molecules for the Field or the Expanded Field, except for actions taken
within the Field in the course of the exercise of the license granted under Section 13.1 hereof and
expressly authorized under this Agreement, Astellas shall notify FG immediately upon the
commencement of any such activities, and provided that [ * ] such activities are and will be in the
future conducted completely independently of any of FG Technology and/or any other FG materials,
confidential information, intellectual property or other related information provided by or on
behalf of FG to Astellas under this Agreement or any other agreement between FG and Astellas
relating to the subject matter hereof, Astellas may proceed with such Commercialization, subject at
all times to the obligations contained in this Agreement with respect to any intellectual property
in connection with or related to such activities and FG's right to terminate this Agreement pursuant
to Section 18.2.1 hereof. -19-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 26 -->
CONFIDENTIAL EXECUTION COPY 8.3.3 Use of FG Technology by Astellas. Astellas shall use the FG
Technology only to exercise the rights granted under Section 13.1 of this Agreement and as expressly
authorized under the Development Program, and shall not under any circumstances use or apply any FG
Technology, including without limitation any FG know-how and/or any other FG materials, confidential
information, intellectual property or other related information provided by FG to Astellas under
this Agreement or any other agreement between FG and Astellas relating to the subject matter hereof,
for any use outside the Field at any time or within the Field after the expiration or termination of
this Agreement.

8.3.4 Activities Outside Field by Astellas. Without limiting the foregoing, Astellas agrees that
during the term of this Agreement it will not (and will not authorize any third party, including,
without limitation, any Affiliates or Sublicensees, to) (i) Commercialize any Lead Compound within
the Field in the Astellas Territory, except a Lead Compound that has been designated a Lead Compound
by the JDC and that has received Marketing Approval in the Astellas Territory for use in the Field,
(ii) Commercialize any Lead Compound for use outside the Field or outside the Astellas Territory,
(iii) provide any supplies of any Lead Compound to any third party, including, without limitation,
any Affiliates or Sublicensees, which Astellas knows or has reason to know is being marketed, sold
or distributed for use outside the Field or outside the Astellas Territory, (iv) conduct or sponsor,
or provide any supplies of any Lead Compound for use in, any clinical trial designed to demonstrate
that a Lead Compound can be used outside the Field, or (v) seek regulatory approval of, or use
labeling for a Lead Compound stating that such Lead Compound is for use outside the Field.

8.3.5 Activities in Astellas Territory by FG During the term of this Agreement, FG shall not
Commercialize by itself or through its Sublicensee any Lead Compound or other compound, whether or
not designated as a Lead Compound, within the Field in the Astellas Territory, or any Lead Compound
outside the Field in the Astellas Territory, provided, however, that FG may develop a Lead Compound
or other compound in the Astellas Territory in those Indications for which Astellas has determined
not to pursue Commercialization or for which Astellas has lost the right to pursue Commercialization
due to failure to meet diligence obligations hereunder; and provided, further, that FG may
Commercialize compounds other than Lead Compounds outside the Field in the Astellas Territory,
irrespective of whether such compound has the effect of stabilizing HIF causing the stimulation of
erythropoiesis (including an increase in endogenous erythropoietin production) and/or a subsequent
increase in hematocrit through modulation of prolyl hydroxylase and/or asparaginyl hydroxylase.

ARTICLE 9 TRANSFER PRICING

9.1 Transfer for Non-Commercial Purpose. In exchange for the transfer of any Lead Compound to
Astellas for a non-commercial purpose, Astellas shall pay FG the total amount of the Fully Burdened
Costs for such Lead Compound as reasonably determined by FG. Lead Compound transferred to Astellas
for a non-commercial purpose shall not be used for a commercial purpose. -20-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 27 -->
CONFIDENTIAL EXECUTION COPY 9.2 Transfer for Commercial Purpose. For any Lead Compound transferred
to Astellas to be used for any commercial purpose, in exchange for the transfer of such Lead
Compound to Astellas, Astellas shall pay FG the amounts set forth in this Section 9.2. All transfers
of Lead Compound for use following Marketing Approval shall be deemed transfers for a commercial
purpose, except transfers under Section 9.2(c), and transfers for the purpose of conducting clinical
trials, which shall be considered transfers for a non-commercial purpose.

(a) For any quantities of Lead Compound shipped by FG to Astellas prior to the issuance of the
national health insurance price as determined by the Japanese Ministry of Health, Labour and Welfare
(the "Listed Price"), Astellas shall pay for such quantities at a price equal to [ * ] of the
estimate of the Listed Price as determined in good faith by FG and Astellas, subject to adjustment
upon the issuance of the actual Listed Price. Upon the issuance of such Listed Price by the Japanese
Ministry of Health, Labour and Welfare, Astellas shall pay to FG, or FG shall reimburse Astellas, as
the case may be, the amount of any difference between the payment made for such Lead Compound at the
estimated Listed Price and the payment required based upon the actual Listed Price.

(b) For all other transfers of Lead Compound, except as set forth in subparagraphs (c) or (d) below,
Astellas shall pay for such quantities at a price equal to [ * ] of the Listed Price. In the event
that a new Listed Price has been notified to Astellas by the Japanese Ministry of Health, Labour and
Welfare before implementation of the new Listed Price, then such new Listed Price shall be used for
calculation of the price of Lead Compound to be shipped on and after the later to occur of (i) [ * ]
before implementation of the new Listed Price, and (ii) the date upon which Astellas has amended the
price of Lead Compound to wholesalers in response to such notification by the Japanese Ministry of
Health, Labour and Welfare, even before implementation of the new Listed Price.

(c) With respect to Lead Compound to be distributed as samples to medical providers and for which
Astellas shall not receive any payment or other consideration, Astellas shall pay to FG the sum of
its Fully Burdened Costs for amounts of Lead Compound shipped to Astellas; provided, however, that
the parties shall mutually agree upon the amount of such samples for distribution without
consideration in the Astellas Territory.

(d) Upon the later of (i) the initial retail sale of a generic equivalent (as defined by the
Japanese Ministry of Health, Labour and Welfare) of such Lead Compound in the Territory, and (ii)
and the expiration of the last to expire of the FG Patents with respect to such Lead Compound
effectively precluding third parties from selling said generic equivalent, for any quantities
shipped by FG to Astellas, Astellas shall pay FG for such quantities [ * ] of the Sales Price;
provided, however, that in the event that the payment of the [ * ] of the Sales Price would result
in FG's [ * ] Percentage falling below [ * ], FG shall have the option to initiate a renegotiation
of the transfer price upon notice to Astellas, in which case the parties shall use best efforts in
good faith to renegotiate reasonable terms for the transfer price; provided, further, that in the
event the transfer price is not renegotiated to FG's satisfaction or FG elects not to initiate a
renegotiation, FG may elect to terminate its manufacturing obligations by written notice to
Astellas, and FG and Astellas shall negotiate reasonable terms for transfer of manufacturing. During
such period of renegotiation, FG shall transfer the Lead Compound to Astellas at a price -21-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 28 -->
CONFIDENTIAL EXECUTION COPY equal to the greater of [ * ] of the Sales Price and the price resulting
if FG's [ * ] Percentage for such Lead Compound is equal to [ * ].

9.3 Payment. Any payments to be made with respect to the transfer of any Lead Compound in accordance
with Section 9.1 or 9.2 above shall be immediately due to FG upon shipment, which shall be paid by
Astellas to FG no later than [ * ] of the date of invoice, which invoice FG shall deliver to
Astellas upon Delivery of Lead Compound to Astellas pursuant to Section 9.2(a), (b) or (c), and
shall be made in U.S. dollars. For transfer of any Lead Compound in accordance with Section 9.1 or
9.2(c) above, FG shall deliver to Astellas, within ten (10) days of receipt of a firm commitment
order from Astellas, an invoice for the estimated Fully Burdened Costs of the Lead Compound to be
transferred to Astellas. Within [ * ] after the transfer of the Lead Compound to Astellas, FG shall
provide a revised final invoice to Astellas that shall indicate the actual Fully Burdened Costs of
the Lead Compound. If the actual Fully Burdened Costs are less than the estimated Fully Burdened
Costs, FG shall include a reimbursement payment to Astellas for the difference between the initial
estimated Fully Burdened Costs and the actual Fully Burdened Costs. If the actual Fully Burdened
Costs are greater than the estimated Fully Burdened Costs, Astellas shall pay such difference within
[ * ] of receipt of an invoice from FG for such amounts. For payments for the transfer of Lead
Compound under Section 9.2(d) hereof, FG's invoice to Astellas shall be calculated based on the
current Listed Price as set by the Japanese Ministry of Health, Labour and Welfare. Upon calculation
of the Sales Price, Astellas shall submit, for any amounts actually sold, the Sales Price to FG, and
FG shall credit Astellas for the difference between the invoice cost, cost calculated based on the
Listed Price and the cost calculated based on the Sales Price.

9.4 Reference Materials; Standard Materials. In exchange for the transfer by FG of any Reference
Materials or Standard Materials for the purposes of conducting analytical, release, stability and
other studies authorized under the Development Program, Astellas shall pay to FG, FG's Fully
Burdened Costs of such materials as reasonably determined by FG.

ARTICLE 10 ADDITIONAL PAYMENTS; BOOKS AND RECORDS

10.1 Quarterly Reports. Astellas shall make quarterly reports to FG within sixty (60) days after the
end of each calendar quarter (April 1 though June 30, July 1 through September 30, October 1 though
December 31, January 1 through March 31), which reports shall include, (a) the Net Sales, unit
shipments and other distributions, including samples, by Astellas, and its Affiliates and
Sublicensees, in such calendar quarter and (b) such other information as may be reasonably requested
by FG to ensure either proper payment by Astellas of amounts required under this Agreement or to
calculate payments with respect to FG's Third Party Agreements. Concurrently with making such
report, Astellas shall remit payment to FG for any payments due under this Agreement.

10.2 Payment Method. All payments under this Agreement shall be made by bank wire transfer in
immediately available funds to an account designated by the payee. All -22-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 29 -->
CONFIDENTIAL EXECUTION COPY such payments made by or on behalf of Astellas hereunder shall be made
by a Japanese entity. All dollar amounts specified in this Agreement, and, except as specifically
authorized under Section 10.3 hereof, all payments made hereunder, are and shall be made in U.S.
dollars. Any payments due under this Agreement which are not paid by the date such payments are due
under this Agreement shall bear interest to the extent permitted by applicable law at the U.S. prime
rate per annum quoted in the "Money Rates" column of The Wall Street Journal (U.S., Western Edition)
on the first business day after such payment is due, plus an additional [ * ], calculated on the
number of days such payment is delinquent. This Section 10.2 shall in no way limit any other
remedies available to either party.

10.3 Currency Conversion. In the event that the amount of an Astellas payment obligation in U.S.
dollars must be determined by the calculation of an underlying amount received by Astellas in
Japanese Yen utilizing the U.S. dollar-Japanese Yen exchange rate (i.e., a transfer payment under
Section 9.2(a), (b) or (d) hereof), currency conversion from Japanese Yen to U.S. dollars shall be
made using the closing exchange rate reported in the Wall Street Journal (U.S. Western Edition) for
the date on which the Lead Compound is Delivered to Astellas. If any such payment is not made by the
due date, the exchange rate utilized for determination of such payment obligation shall be the
exchange rate [ * ] reported in the Wall Street Journal (U.S. Western Edition) during the period
from the date of invoice through the due date, not including any additional amounts owed under
Section 10.2 hereof.

10.4 Taxes

10.4.1 Generally. Each party shall bear and, except as otherwise expressly provided in this Section
10.4, pay any and all taxes, duties, levies, and other similar charges (and any related interest and
penalties), however designated, imposed on that party as a result of the existence or operation of
this Agreement. If laws or regulations require that taxes be withheld, the paying party will (i)
timely pay the taxes to the proper taxing authority, and (ii) send proof of payment to the other
party within [ * ] following that payment.

10.4.2 Certain Payments. Notwithstanding Section 10.4.1, all payments by Astellas required under
this Agreement above, including under Section 6.1.1 are expressed as net amounts and shall be made
free and clear of, and without reduction for, any withholding taxes, provided, however, that in the
event that any withholding taxes are due on the payments Astellas shall make to FG under Sections
6.1.2 and 6.1.3, Astellas shall make such payments directly to the Japanese Tax Authority and shall
be entitled to reduce the amount paid to FG by [ * ] of the amount of the withholding taxes paid to
Japanese Tax Authority in respect of such payment, unless the amount of such withholding taxes is
reduced by a decision of the Japanese tax authority, or is subsequently adjusted downward as result
of appeal, in which event the next payment due hereunder, including, without limitation, a transfer
payment or a payment upon termination, shall be increased by such amount. Any such taxes which are
otherwise imposed on payments to FG shall be the sole responsibility of Astellas. Astellas shall
provide FG with official receipts issued by the appropriate taxing authority or such other evidence
as is reasonably requested by FG to establish that such taxes have been paid. Astellas and FG shall
cooperate to minimize the withholding taxes due on the amounts payable by Astellas to FG hereunder
to the extent permissible under law, including, but not limited to, -23-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 30 -->
CONFIDENTIAL EXECUTION COPY making appropriate application(s) to the tax authorities within the
Astellas Territory. If possible, FG shall use its reasonable efforts to apply for the tax refund
from U.S. tax authorities for the withholding taxes paid to the Japanese Tax Authority on the
payment U.S. $[ * ] payment made by Astellas to FG on January 13, 2004 as set forth in Section 6.1
when such application for the tax refund becomes possible, and if FG has received any such tax
refund, FG shall reimburse to Astellas for the amounts corresponding to the withholding taxes paid
in Astellas' accounts as set forth above.

10.5 Records; Inspections. Astellas shall keep, and require its Affiliates and Sublicensees to keep,
complete, true and accurate books of accounts and records for the purpose of determining payments
due pursuant to this Agreement. Such books and records shall be kept for at least [ * ] following
the end of the calendar quarter to which they pertain. FG shall keep, and require its Sublicensee(s)
to keep, complete, true and accurate books of accounts and records for the purpose of verifying the
accuracy of the [ * ] Percentage and Fully Burdened Costs. Such records will be open for inspection
at the principal place of business of each party (the "Inspected Party") during such [ * ] period by
an independent auditor chosen by the other party (the "Inspecting Party") and reasonably acceptable
to the Inspected Party for the purpose of verifying the amounts payable by Astellas to FG hereunder
or the accuracy of the [ * ] Percentage and/or Fully Burdened Costs. Such inspections may be made no
more than once each calendar year, at reasonable times and on reasonable notice. Any books of
accounts or records shall not be inspected more than once. The independent auditor retained by the
Inspecting Party shall be obligated to execute a reasonable confidentiality agreement with the
Inspected Party prior to commencing any such inspection, which, among other customary clauses,
contains the provisions to the effect that such auditor shall not disclose to the Inspecting Party
any information other than as necessary to accomplish the purpose of the inspection. Inspections
conducted under this Section 10.5 shall be at the expense of the Inspecting Party. Any underpaid or
overcharged amounts that are discovered will be paid by the Inspected Party, and with interest on
such underpaid or overcharged amounts at the rate set forth in Section 10.2 above. The parties will
endeavor to minimize disruption of the Inspected Party's normal business activities to the extent
reasonably practicable.

ARTICLE 11 DUE DILIGENCE

11.1 Astellas' Due Diligence. Astellas shall use its commercially reasonable efforts (i) to conduct
any development work undertaken under the Development Program, and any and all clinical trials
(including without limitation Phase III) required to obtain, and thereafter to take such other
actions as are necessary to obtain, Marketing Approvals for any Lead Compound in the Astellas
Territory as soon as practicable, and (ii) to launch each such Lead Compound in the Astellas
Territory as soon as practicable after receiving Marketing Approval in the Astellas Territory for
such Lead Compound.

11.2 FG's Due Diligence. FG shall use its commercially reasonable efforts to conduct, and to the
extent possible taking into account safety and other applicable issues, complete a Phase II clinical
trial with FG-2216 or another Lead Compound in the FG Territory. -24-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 31 -->
CONFIDENTIAL EXECUTION COPY 11.3 Development Diligence

11.3.1 Astellas shall pursue development of Indications according to the following terms: (i)
Astellas shall pursue Commercialization in "Treatment of anemia in patients with chronic kidney
disease undergoing dialysis" and "Treatment of anemia in patients with chronic kidney disease not
undergoing dialysis"; (ii) Astellas shall notify FG within six (6) months of the execution of this
Agreement whether it shall pursue Commercialization in [ * ]; (iii) Astellas shall notify FG within
six (6) months of the date FG notifies Astellas that it has demonstrated Proof of Concept whether it
will pursue Commercialization in [ * ]; (iv) Astellas shall notify FG within six (6) months of the
date FG notifies Astellas that it has demonstrated Proof of Concept whether it will pursue
Commercialization in [ * ]; and (v) Astellas shall notify FG, upon Marketing Approval for any Lead
Compound in each of the following Indications, whether it will pursue Commercialization of such
Indication: [ * ], and any other indications to be added hereafter to the definition of the
Indication by mutual agreement; and (vi) if FG is pursuing Commercialization of [ * ], Astellas
shall notify FG after Marketing Approval whether it shall pursue Commercialization of such
Indication. Should Astellas inform FG that it does not wish to pursue Commercialization of any
Indication, or should Astellas fail to meet the due diligence obligations under Section 11.3.2 for
any Indication as set forth in Section 11.3.1(iv) or under Section 11.3.3 for any Indication as set
forth in Section 11.3.1(v), such Indication shall no longer be considered an Indication for the
purposes of this Agreement, and Astellas shall have no right or shall lose any right with respect to
such Indication under this Agreement including, without limitation, the licenses granted under
Sections 8.1 and 13.1 hereof. Each Indication for which Astellas is obligated to pursue
Commercialization under Section 11.3.1(i) or for which it decides to pursue Commercialization under
Sections 11.3.1(ii), (iii) or (iv) shall be a "Major Indication".

11.3.2 In addition to the obligations set forth in Section 11.1 and 11.3, for each Major Indication,
until such time as Astellas obtains Marketing Approval in the Astellas Territory for such Major
Indication, with respect to each Lead Compound for each Major Indication, Astellas shall:

(a) If required for development of a Lead Compound in an Indication, Initiate Phase I clinical
trials within [ * ] after the later of (i) the Effective Date, for Indications for which FG has
commenced clinical trials prior to the execution of this Agreement, and (ii) FG's or its
Sublicensees Initiation of a Phase I clinical trial for other such Indications. -25-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 32 -->
CONFIDENTIAL EXECUTION COPY (b) Initiate Phase II clinical trials within the later of (i) [ * ]
after FG's, or its Sublicensee's, Initiation of Phase II, (ii) [ * ] after Astellas' Completion of
its Phase I clinical trial(s), (iii) if Astellas' obligations under this Subsection 11.3.2(b) are
triggered upon FG's notification of demonstration of Proof of Concept in an Indication, [ * ] after
the date Astellas notifies FG that it will pursue Commercialization in such Indication, and (iv) in
the event Astellas' obligations under this Section 11.3.2(b) are triggered by the designation of a
secondary Lead Compound as a primary Lead Compound, [ * ] after such designation.

(c) Either notify FG of its intent to employ the Bridging Strategy, if applicable, or Initiate Phase
III clinical trials within [ * ] of the later of (i) FG's, or its Sublicensee's Initiation of a
Phase III clinical trial and (ii) Astellas' Completion of its Phase II clinical trial(s).

11.3.3 For each of the Indications set forth in Section 11.3.1(v), Astellas shall Initiate Phase II
clinical studies within [ * ] of its notification to FG that it will pursue Commercialization in
such Indication.

11.3.4 Astellas' diligence obligations set forth in Section 11.3.2 shall apply to all Lead Compounds
designated by FG, provided, that for each Indication for which such diligence obligations apply, the
diligence obligations shall only apply to the primary Lead Compound designated by FG, and for the
secondary Lead Compound, Astellas' diligence obligations shall be limited to those set forth in
Section 11.3.2(a) until the designation of the secondary Lead Compound as the primary Lead Compound,
provided, further, upon such designation, that such diligence obligation shall be expanded to
include the requirement that Astellas complete the Phase I clinical studies required to Initiate
Phase II clinical studies in the Indication with such secondary Lead Compound.

ARTICLE 12 MANUFACTURING RIGHTS

12.1 Procedures. FG shall have the exclusive right to determine the methods and procedures for the
manufacture of all Lead Compounds. If FG intends to make any change in the methods or procedures,
including, without limitation, manufacturing process, analyzing process and/or site change for
manufacture of the Lead Compounds, FG shall notify Astellas in writing of such intended change;
provided, that if in Astellas' reasonable opinion, such change may lead to any amendment to the
relevant Marketing Approval or Marketing Approval Application, Astellas shall use best efforts to
(i) as soon as possible petition the Japanese Ministry of Health, Labor and Welfare to make the
change without an amendment to the Marketing Approval or MAA and shall concurrently prepare an
application for amendment to the Marketing Approval or MAA, and (ii) if the Japanese Ministry of
Health, Labor and Welfare determines such an amendment is required, shall notify FG and submit the
application for amendment immediately following notice of such requirement, and FG shall not make
the intended change without a prior written consent from Astellas, such consent not to be
unreasonably withheld or delayed, provided, further, that consent shall be deemed granted upon
notice that an amendment is not required or approval of an amendment from the Japanese -26-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 33 -->
CONFIDENTIAL EXECUTION COPY Ministry of Health, Labor and Welfare. FG shall provide Astellas with
all the data and information necessary for Astellas to amend the Marketing Approval or MAA in
Astellas Territory and shall continue to supply Astellas with the Lead Compound as manufactured with
the manufacturing methods and procedures or at the manufacturing site described in Astellas' (or its
Affiliate's or Sublicensee's) then current Marketing Approval or MAA until Astellas will have
finished the necessary amendment to the relevant Marketing Approval or MAA or received notice that
an amendment is not required.

12.2 FG Right. FG shall have the worldwide exclusive right (itself or through third party vendors)
to manufacture (or have manufactured) Lead Compounds. Astellas and its Affiliates and Sublicensees
shall not directly or indirectly make, produce or manufacture any Lead Compounds.

12.3 Manufacture and Supply. FG shall have the exclusive right and obligation to supply the Lead
Compounds to Astellas and its Affiliates and Sublicensees for all development and commercial
purposes, and Astellas and its Affiliates and Sublicensees shall purchase such Lead Compounds
exclusively from FG. It is understood that FG may engage subcontractors with respect to the
manufacture of such Lead Compounds to fulfill its supply obligations to Astellas hereunder. In all
cases, supply by FG of Lead Compounds hereunder shall be Ex Works (Incoterms 2000) the manufacturing
facility. Subject to Section 8.3.5 hereof, nothing herein is intended to preclude FG from granting
rights to supply or supplying (a) any Lead Compound outside of the Astellas Territory to any third
party for use within or outside the Field, or (b) any compound Controlled by FG within the Astellas
Territory except for a Lead Compound for the duration of its designation in compliance with the
terms and conditions of this Agreement.

12.4 Product Specifications. The Lead Compounds to be supplied by FG hereunder shall meet the
Product Specifications. In addition to, but not in limitation of, the foregoing, FG and Astellas
agree that upon Marketing Approval for any Lead Compound, FG's obligation to supply Astellas with
Lead Compound shall be limited to, and all payment obligations set forth in Section 9.2 shall be
based on, the supply of Bulk Product, unless otherwise agreed by the parties. The packaging for the
Lead Compound to be distributed commercially by Astellas shall contain a clearly visible
acknowledgment that the Lead Compound was manufactured by FG, and shall contain a registered
trademark of the FG logo or other trademark approved by FG.

12.5 Orders Forecast

12.5.1 Orders for Non-Commercial Use. In connection with the supply of any Lead Compound for
non-commercial use in the Territory, Astellas shall provide FG with a firm purchase order as early
as possible prior to its requirements, and in no event less than [ * ] prior to the shipment or
other release date(s) requested by Astellas for such Lead Compound. FG shall provide such Lead
Compound to Astellas as soon as practicable within such time period, subject, prior to Marketing
Approval, to the reasonable lead time requirements of third party contract manufacturers. All
forecasts shall be prepared in good faith in order to facilitate FG's manufacture and shipment of
the Lead Compound in compliance with this Agreement. -27-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 34 -->
CONFIDENTIAL EXECUTION COPY 12.5.2 Forecast and Order for Commercial Use. In connection with the
supply of any Lead Compound for commercial use in the Astellas Territory upon FG's request, Astellas
and FG shall negotiate in good faith appropriate forecasting and firm purchase order lead times,
taking into consideration the reasonable notice requirements of FG and its third party
manufacturers. All forecasts shall be prepared in good faith in order to facilitate FG's manufacture
and shipment of the Lead Compound in compliance with this Agreement.

12.6 Shipment. Astellas, or FG at Astellas' request if specified in a purchase order by Astellas,
shall arrange for shipment of the Lead Compound as specified in each purchase order by Astellas, Ex
Works (Incoterms 2000) the manufacturing facility. For purposes of this Agreement, and
notwithstanding anything to the contrary contained within the term "Ex Works", it is hereby
acknowledged and agreed that title and risk of loss shall transfer to Astellas from receipt by
Astellas at the manufacturing facility. Astellas shall bear the costs of such carrier, including the
costs of insurance of the shipment, and all customs, duties, sales taxes and other governmental
charges related to the importation and sales of the Lead Compound.

12.7 Inspection of Shipment/Right to Reject. Each shipment of Lead Compound from FG to Astellas
shall contain such laboratory and quality control certificate as are necessary to show that the Lead
Compound is in conformity with the Product Specifications. Astellas shall promptly inspect each
shipment. In the event that any portion of the shipment fails to conform to the Product
Specifications, Astellas shall notify FG within [ * ] of Astellas' receipt of such shipment. Such
notice shall specify the manner in which the Lead Compound fails to meet the Product Specifications.
In the absence of such notification, Astellas shall be deemed to have accepted the shipment. FG and
Astellas agree to consult with each other to resolve any discrepancy between each other's
determinations regarding any possible nonconformity of the Lead Compound. If such consultation does
not resolve the discrepancy, the parties agree to nominate a reputable independent laboratory or
other independent third party, in each case acceptable to both parties, to carry out tests on
representative samples taken from such shipment, and the results of such tests shall be binding on
both parties. If the results of such tests demonstrate that the Lead Compound does not meet the
Product Specifications, then FG shall pay the costs of such tests; otherwise, Astellas shall pay for
the costs of such tests. FG shall, at its expense, promptly replace any Lead Compound to the extent
that, in accordance with this Section 12.7, it is determined that it does not conform to the Product
Specifications. Unless otherwise instructed by FG, all non-conforming Lead Compound shall be
returned to FG at the place of manufacture at FG's direction and at FG's expense. If Astellas
detects at any time any defect in the Lead Compound which has not been found through Astellas'
inspection, it shall notify FG to that effect within [ * ] of the discovery of such defect, and the
procedures set forth above in this Section 12.7 shall be applied to such defective Lead Compound,
provided, that FG shall only be responsible to pay for costs of defects that are the result of FG's
gross negligence or willful misconduct.

12.8 Inspection of Facilities. Astellas shall have the right, upon reasonable advance notice and
during regular business hours, to inspect and audit, either by itself or through its Affiliates or
consultants, the facilities (including any facilities of sub-contractors) being used by FG for
production of the Lead Compound to assure compliance with applicable laws, rules and regulations,
including, without limitation, Japanese regulatory standards and FG quality control procedures
("Relevant Standards"). FG shall also reasonably comply with inspection -28-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 35 -->
CONFIDENTIAL EXECUTION COPY requests of the Japanese Ministry of Health, Labor & Welfare. Such
inspection and audit shall be conducted at Astellas' sole cost and expense in a manner so as to
minimize disruption of FG's, or its subcontractor's or Sublicensee's, business operations. FG shall,
within [ * ] after FG's receipt of written notice from Astellas detailing any deficiencies which may
be noted in any such audit which relate to the Relevant Standards use good faith efforts to remedy
such deficiencies, and submit a plan to the Astellas outlining steps proposed to be taken.

12.9 Recall. In the event that Astellas deems it necessary to recall any Lead Compound from the
market, it may do so in its sole discretion, after notification to the FG. The costs and expenses
for such recall shall be borne by Astellas unless caused by a failure for which FG is required to
indemnify Astellas pursuant to Section 17.3, or by FG's gross negligence or willful misconduct, in
which event it shall be borne by FG.

12.10 Warranty. FG represents and warrants that the Lead Compounds to be supplied to Astellas under
this Agreement shall conform to the Product Specifications and shall, as appropriate, be
manufactured in compliance with GMP Guidelines. Subject to Sections 12.9 and 17.3 hereof, FG's sole
obligation and Astellas' sole remedy with respect to Lead Compound which does not meet the warranty
contained herein is limited to replacement of such Lead Compound and reimbursement of Astellas' out
of pocket expenses for shipping to FG at the address designated by FG.

12.11 Interruption in Supply. For any particular Lead Compound, in order to minimize any
interruptions in supply hereunder, FG and Astellas agree that within [ * ], FG shall maintain two
separate, validated manufacturing sites (which may either be its own manufacturing facilities or
facilities of a contract manufacturer) for such Lead Compound.

12.12 Reference and Standard Materials. For any Lead Compound provided to Astellas hereunder, upon
Astellas' request and pursuant to Section 9.4 hereof, FG shall provide to Astellas reasonable
quantities of reference materials, including analogs, metabolites, impurities, degradates and
radio-labeled compounds ("Reference Materials") and standard materials, i.e. defined, highly
purified Lead Compound ("Standard Materials") for such Lead Compound for the purposes of conducting
analytical, release, stability and other studies as may be authorized by the JDC under the
Development Program.

ARTICLE 13 LICENSE GRANTS

13.1 Grant to Astellas. Subject to the terms and conditions of this Agreement including Article 12
above, FG hereby grants to Astellas an exclusive license under the FG Technology to: use, package,
sell, have sold, import, market and otherwise distribute the Lead Compounds for use solely in the
Field in the Astellas Territory

13.2 Sublicenses. The licenses granted under Section 13.1 above include the right to grant and
authorize sublicenses, subject to the requirements of this Agreement and Section 7.2.
Notwithstanding the foregoing, Astellas shall not have the right to authorize a Sublicensee to
market, sell or distribute Lead Compounds without FG's prior written consent -29-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 36 -->
CONFIDENTIAL EXECUTION COPY (which consent shall not be unreasonably withheld). For the purposes of
the foregoing, and without limitation, it shall be deemed reasonable for FG to withhold consent for
competitive concerns.

13.3 No Rights Beyond Lead Compounds. Except as expressly provided herein, nothing in this Agreement
shall be deemed to grant to Astellas rights in FG Technology other than the rights granted hereunder
to the Lead Compounds, or for applications outside the Field or outside the Astellas Territory, or
to manufacture Lead Compounds; nor shall any provision of this Agreement be deemed to restrict FG's
right to exploit any FG Technology and/or the Lead Compounds outside the Astellas Territory.

13.4 Expanded Field Negotiation. Following the signing of this Agreement, FG agrees to negotiate in
good faith with Astellas for a license to develop compounds for the Expanded Field in the Astellas
Territory, exclusively for a period of [ * ] following such date, and non- exclusively thereafter
until the execution of a license agreement with a third party to develop compounds for the Expanded
Field. FG and Astellas hereby agree that FG's obligation to negotiate non-exclusively for the
Expanded Field shall not constitute a right of first offer, right of first refusal, right of first
negotiation or any obligation to enter into any agreement with Astellas at any time, and the failure
of such negotiations to result in an agreement between FG and Astellas with respect to the Expanded
Field shall not constitute a breach of this Agreement.

ARTICLE 14 INTELLECTUAL PROPERTY

14.1 Ownership of Inventions. Subject to Section 14.1.1, title to all inventions and other
intellectual property made related to (i) the Development Program, (ii) the Lead Compounds, (iii) FG
Technology or FG Confidential Information, (iv) the Field, or (v) the Expanded Field (subsections
14.1(i)-(v), collectively, the "Protected Field") shall be owned by or is hereby assigned to FG;
provided, however that Astellas shall own inventions of general applicability relating solely to
drug delivery systems created exclusively by Astellas under subsection 14.1(i), excluding inventions
related to or based on subsections 14.1(ii), (iii), (iv), or (v), and provided, further, that
Astellas hereby grants to FG a worldwide, fully paid non-exclusive license with the right to
sublicense to practice such inventions with respect to the FG Technology. Astellas agrees to execute
any and all assignments and other documents necessary to effectuate the foregoing.

14.1.1 Notwithstanding Section 14.1, in the event that Astellas develops, completely independently
from any FG Technology and/or any other FG materials, confidential information, intellectual
property or other related information provided by or on behalf of FG to Astellas under this
Agreement or any other agreement between FG and Astellas relating to the subject matter hereof, any
inventions or intellectual property rights related to the Field or the Expanded Field, [ * ],
Astellas shall own such intellectual property and hereby grants to FG and its Sublicensees a
non-exclusive, royalty-free, irrevocable license to such intellectual property for the FG Territory.
Astellas agrees to execute any and all assignments and other documents necessary to effectuate the
foregoing. -30-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 37 -->
CONFIDENTIAL EXECUTION COPY 14.2 Patent Prosecution

14.2.1 FG Inventions. FG shall control all Prosecution and Interference Activities pertaining to FG
Patents and patent applications and patents related to its, its Affiliate's or its Sublicensee's
inventions in the Protected Field worldwide using counsel of its choice and shall bear the costs of
such Prosecution and Interference Activities, provided, however, that; and Astellas shall reimburse
to FG, within [ * ] of receipt by Astellas of invoice therefor, any such costs to the extent
incurred in connection with or reasonably allocable to the FG Patents registered and/or to be
registered in the Astellas Territory and related to the Field and the Lead Compounds, provided,
further, that, with respect to patents or patent applications excluding those covering composition
of matter claims and all patents listed on Exhibit A hereto as of the Effective Date, Astellas may
postpone such reimbursement until the respective FG Patent will have been registered in the Astellas
Territory if [ * ], on condition that once the respective FG Patent has been registered in the
Astellas Territory, Astellas shall pay to FG such costs, plus interest to the extent permitted by
applicable law at the U.S. prime rate per annum quoted in the "Money Rates" column of The Wall
Street Journal (U.S., Western Edition), calculated in each case from the date such costs were
incurred, plus an additional [ * ] thereof.

14.2.2 Astellas Inventions. Astellas shall not file for or otherwise seek to obtain (directly or
indirectly) patent or other intellectual property protection for inventions that are related to the
Protected Field, without the prior written consent of FG, which may be withheld at FG's sole
discretion, subject to Section 14.1.1, and provided also that Astellas may file for or otherwise
seek to obtain patent protection for inventions related to drug delivery systems as described in
Section 14.1. To the extent that FG consents to the filing of any patent application or other
intellectual property protection related to the foregoing, such patent application or other
intellectual property protection shall be subject to Section 14.1, unless otherwise agreed in
writing.

14.2.3 Cooperation. Astellas shall cooperate with and assist FG in connection with Prosecution and
Interference Activities and shall use best efforts to consult with FG regarding the prosecution and
maintenance of the FG Patents for the FG Territory and the Astellas Territory for those FG Patents
for which Astellas or its Affiliates, Sublicensees or investigators are inventors, except solely for
inventions (i) of general applicability relating solely to drug delivery systems created by Astellas
under subsection 14.1(i), or (ii) created in compliance with Section 14.1.1 as determined solely by
FG in good faith.

14.3 Defense of Third Party Infringement Claims. If the development, manufacture, sale or use of any
Lead Compound pursuant to this Agreement results in a claim, suit or proceeding (collectively,
"Actions") alleging patent infringement against FG or Astellas (or their respective Affiliates or
Sublicensees), such party shall promptly notify the other party hereto in writing. The party subject
to such Action (for purposes of this Section 14.3, the "Controlling Party") shall have the exclusive
right to defend and control the defense of any such Action using counsel of its own choice;
provided, however, that if such Action is directed to the subject matter of a patent of the other
party (i.e., for Astellas, a FG Patent), such other party may participate in the defense and/or
settlement thereof at its own expense with counsel of its choice. -31-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 38 -->
CONFIDENTIAL EXECUTION COPY Except as agreed in writing by Astellas and FG, Astellas shall not enter
into any settlement relating to a Lead Compound, if such settlement admits the invalidity or
unenforceability, or limits any claim, of any patent within the FG Technology. The Controlling Party
agrees to keep the other party hereto reasonably informed of all material developments in connection
with any such Action. Any cost, liability or expense associated with such action (including amounts
paid in settlement) (together, "Expenses") shall be borne by the Controlling Party; provided, that
if Astellas is the Controlling Party, and the Action is related to Future Third Party Intellectual
Property, with respect to Expenses related solely to such Future Third Party Intellectual Property,
it shall be entitled to deduct up to [ * ] of the Expenses incurred on an annual basis from [ * ] in
such year under this Agreement, provided, however, that (i) the total amount deducted shall not
exceed [ * ] thereunder, and (ii) notwithstanding (i) above, Astellas' right to deduct Expenses
incurred shall be further limited such that in no event shall the sum of (a) the Expenses deducted
by Astellas under this Section 14.3, and (b) the consideration FG contributes for the acquisition of
intellectual property from Third Party Licensors for the Astellas Territory as set forth in Section
14.5, exceed [ * ] hereunder, and, provided further, that if FG is the Controlling Party, it shall
be entitled to reimbursement by Astellas of [ * ] of such Expenses, as incurred. Notwithstanding the
foregoing, Astellas shall be solely responsible (without right of deduction) for all Expenses
related to any Action relating to Preexisting Third Party Intellectual Property.

14.4 Enforcement. Subject to the provisions of this Section 14.4, in the event that FG or Astellas
reasonably believes that any FG Technology necessary for the development, manufacture, use or sale
of a Lead Compound is infringed or misappropriated by a third party or is subject to a declaratory
judgment action arising from such infringement, in each case with respect to the development,
manufacture, sale or use of a product within the Field and within the Astellas Territory, Astellas
or FG (respectively) shall promptly notify the other party hereto. Promptly after such notice the
parties shall meet to discuss the course of action to be taken with respect to an Enforcement Action
(as defined below) with respect to such infringement or misappropriation, including the control
thereof and sharing of costs and expenses related thereto, for the purposes of entering into a
litigation agreement setting forth the same ("Litigation Agreement"). If the parties do not enter
such Litigation Agreement, FG shall have the initial right (but not the obligation) to enforce the
intellectual property rights with respect to the FG Technology, or defend any declaratory judgment
action with respect thereto (such action, for purposes of this Section 14.4, an "Enforcement
Action").

14.4.1 Information. Absent a Litigation Agreement, the party initiating or defending any such
Enforcement Action within the Field shall keep the other party hereto reasonably informed of the
progress of any such Enforcement Action, and such other party shall have the right to participate
with counsel of its own choice at its own expense.

14.4.2 Enforcement Costs; Recoveries. Absent a Litigation Agreement, FG shall have the initial right
to initiate such an Enforcement Action, and shall notify Astellas within a reasonable time whether
it elects to exercise such right. In the event that FG elects to initiate or defend such Enforcement
Action, FG shall be responsible for [ * ] of the costs and expenses while Astellas shall be
responsible for [ * ] of the costs and expenses, and all amounts recovered shall first be applied to
reimbursement of each -32-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 39 -->
CONFIDENTIAL EXECUTION COPY party's costs and expenses with the remainder to be allocated to FG and
Astellas at the ratio of [ * ] and [ * ]. In the event that FG elects not to initiate or defend such
Enforcement Action, Astellas shall have the right to initiate or defend such Enforcement Action in
its own name, and to the extent permitted under Third Party Agreements, in the name of FG or in the
names of both FG and Astellas, in which case, Astellas shall be responsible for [ * ] of the costs
and expenses while FG shall be responsible for [ * ] of the costs and expenses, and all amounts
recovered shall first be applied to reimbursement of each party's costs and expenses with the
remainder to be allocated to Astellas and FG at the ratio of [ * ] and [ * ].

14.4.3 Cooperation in Enforcement Action. Absent a Litigation Agreement, at the request of the party
which has the right to initiate or defend an Enforcement Action, the other party shall reasonably
cooperate in the Enforcement Action, such cooperation to include, without limitation, furnishing
records, information and testimony, and attending conferences, discovery proceedings, hearings,
trials and appeals; provided, that the requesting party shall reimburse to the cooperating party for
the out-of-pocket expenses incurred for such cooperation pursuant to the reimbursement regime set
forth in Section 14.4.2.

14.5 Third Party Agreements

14.5.1 Future Agreements. It is understood that FG may find it necessary to utilize in connection
with a Lead Compound intellectual property that is controlled by a non-Affiliate third party (such
party, a "Third Party Licensor"), in addition to or in lieu of the FG Technology existing as of the
Effective Date. FG shall have the right to obtain (by purchase, license, or otherwise) rights to
such intellectual property with the right to sublicense to Astellas. In the event that FG determines
that it must obtain such rights, it shall provide notice and submit a description of such rights to
Astellas, and shall discuss with Astellas the need to obtain such rights. Astellas shall inform FG
within [ * ] of receipt of such notice whether it believes it is necessary to obtain such rights for
the Astellas Territory and wishes to obtain such rights. In the event Astellas determines to obtain
such rights, FG shall obtain a worldwide license for the rights under such terms and conditions as
are [ * ], and such intellectual property of the Third Party Licensor shall be deemed to be the part
of FG Technology, provided, however, that, notwithstanding anything contained in this Agreement (i)
for Preexisting Third Party Intellectual Property, [ * ] shall pay [ * ] of all consideration due in
connection with the acquisition of such rights for the Astellas Territory, and (ii) for Future Third
Party Intellectual Property, [ * ] shall [ * ] pay [ * ] of all consideration due in connection with
the acquisition of such rights for the Astellas Territory, provided, however, notwithstanding FG's
obligation to contribute to the consideration due for Future Third Party Intellectual Property under
(ii) above, FG's obligation to contribute shall be limited such that in no event shall the sum of
(a) the consideration FG contributes for the acquisition of intellectual property from Third Party
Licensors for the Astellas Territory, and (b) the Expenses for which Astellas has the right to
deduct under Section 14.3 exceed [ * ] hereunder, and Astellas shall be responsible for all
consideration related to the acquisition of rights from Third Party Licensors in excess of such
amount. In the event Astellas determines not to obtain such rights for the Astellas Territory, FG
shall obtain a license for the FG Territory but not the Astellas Territory, and Astellas shall be
solely responsible for the defense of any infringement -33-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 40 -->
CONFIDENTIAL EXECUTION COPY Action, for all Expenses related to any such Action, and any right of
Astellas to deduct Expenses under this Agreement against payments required to be made to FG
hereunder shall not apply to any action brought with respect to such rights.

14.5.2 Payment; Reports. If FG is obligated to pay amounts to a Third Party Licensor, FG shall
notify Astellas [ * ] in advance of the due date of such payment obligation (or such later date as
FG may determine), and Astellas shall reimburse its share of such payments within [ * ] after
receipt of notice therefor.

14.5.3 Limitation. To the extent that FG Patents includes any intellectual property licensed under
FG's License Agreement with Imigen, Inc. relating to HIF stabilization technology dated as of
October 30, 2003, and amended as from time to time of which a redacted copy shall have been provided
to Astellas prior to the Effective Date, Astellas shall be considered a sublicensee and be subject
to the applicable requirements thereunder.

14.5.4 Compliance with Third Party Agreements. Notwithstanding anything to the contrary contained
herein, Astellas agrees to comply with the requirements (upon sublicensees or otherwise) of FG's
License Agreement with Imigen, Inc. relating to HIF stabilization technology dated as of October 30,
2003. In addition, Astellas agrees to comply with the requirements (upon sublicensees or otherwise)
of any future Third Party Agreements for which Astellas obtains rights through an FG license
pursuant to Section 14.5.1 hereof.

ARTICLE 15 REPRESENTATIONS AND WARRANTIES

15.1 FG Warranties. FG warrants and represents to Astellas, as of the execution of this Agreement,
that (i) it is a corporation duly organized, validly existing and in good standing under the laws of
the State of Delaware; (ii) the execution, delivery and performance of this Agreement have been duly
authorized by all necessary corporate action on the part of FG; (iii) there is no pending litigation
which alleges or any communication alleging that Commercialization of any Lead Compound or any
compound Controlled by FG for use in the Field has infringed or misappropriated the intellectual
property rights of any Third Party or has been obtained by misappropriating any Third Party's
intellectual property right; and (iv) subject to the terms and conditions of the agreements for the
FG Acquired Patents, FG has complete title to and ownership of the FG Patents, free and clear from
any mortgages, pledges, liens, security interests, conditional and installment sale agreements,
encumbrances, charges or claims of any kind.

15.2 Astellas Warranties. Astellas warrants and represents to FG, as of the execution of this
Agreement, that (i) it is a corporation duly organized, validly existing and in good standing under
the laws of Japan; and (ii) the execution, delivery and performance of this Agreement have been duly
authorized by all necessary corporate action on the part of Astellas.

15.3 Disclaimer of Warranties. EXCEPT AS OTHERWISE SET FORTH HEREIN, FG AND ASTELLAS EXPRESSLY
DISCLAIM ANY WARRANTIES OR CONDITIONS, EXPRESS, IMPLIED, STATUTORY OR OTHERWISE, WITH RESPECT TO
-34-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 41 -->
CONFIDENTIAL EXECUTION COPY THE DEVELOPMENT PROGRAM, OR THE FG TECHNOLOGY OR LEAD COMPOUNDS,
INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE,
VALIDITY OF FG TECHNOLOGY, PATENTED OR UNPATENTED, AND NONINFRINGEMENT OF THE INTELLECTUAL PROPERTY
RIGHTS OF THIRD PARTIES.

ARTICLE 16 CONFIDENTIALITY

16.1 Confidential Information. Except as expressly provided herein, the parties agree that the
receiving party shall not publish or otherwise disclose and shall not use for any purpose other than
this Agreement any information furnished to it by the other party hereto pursuant to this Agreement
which if disclosed in tangible form is marked "Confidential" or with other similar designation to
indicate its confidential or proprietary nature or if disclosed orally is indicated orally to be
confidential or proprietary by the party disclosing such information at the time of such disclosure
and is confirmed in writing as confidential or proprietary by the disclosing party within a
reasonable time after such disclosure (collectively, "Confidential Information"). Notwithstanding
the foregoing, Confidential Information shall not include information that, in each case is
demonstrated by written documentation:

(a) was already known to the receiving party, other than under an obligation of confidentiality
directly or indirectly to the disclosing party at the time of disclosure hereunder;

(b) was generally available to the public or otherwise part of the public domain at the time of its
disclosure to the receiving party hereunder;

(c) became generally available to the public or otherwise part of the public domain after its
disclosure and other than through any act or omission of the receiving party in breach of this
Agreement; or

(d) was subsequently lawfully disclosed to the receiving party by any third party without any
confidentiality obligation directly or indirectly to the disclosing party or developed by the
receiving party without reference to any information or materials disclosed by the disclosing party.

It is agreed and understood that all matters discussed and presented at the meetings of the JDC
shall be considered Confidential Information hereunder, subject to the terms and conditions of this
Agreement.

16.2 Permitted Disclosures. Notwithstanding the provisions of Section 16.1 above, each party hereto
may disclose the other party's Confidential Information to the extent such disclosure is reasonably
necessary to exercise the rights granted to it, or reserved by it, under this Agreement (including,
without limitation, entering into and/or performing business or scientific relationships with
respect to products outside the Field as permitted hereunder), in filing or prosecuting patent
applications, prosecuting or defending litigation, complying with applicable governmental
regulations, submitting information to tax or other governmental -35-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 42 -->
CONFIDENTIAL EXECUTION COPY authorities (including regulatory authorities), or conducting clinical
trials hereunder with respect to Lead Compounds, provided that if a party is required by law to make
any such disclosure of the other party's Confidential Information, to the extent it may legally do
so, it will give reasonable advance notice to the latter party of such disclosure and, save to the
extent inappropriate in the case of patent applications or otherwise, will use its reasonable
efforts to secure confidential treatment of such Confidential Information prior to its disclosure
(whether through protective orders or otherwise).

16.3 Clinical Data. Except as expressly permitted under Sections 7.2 and 16.2, and for publications
or disclosures in accordance with Section 5.2, neither party shall disclose to third parties
pre-clinical data, clinical data or regulatory filings, comprising Confidential Information of the
other party.

16.4 Press Releases. Except as may already be, or is agreed to be, publicly disclosed, in the event
that either party proposes to release a press release with respect to this Agreement or the
Development Program, such party shall obtain the prior written consent of the other party, which
shall not be unreasonably withheld.

ARTICLE 17 INSURANCE; INDEMNIFICATION

17.1 Insurance. Each party shall secure and maintain in effect during the term of this Agreement and
for a period of five (5) years thereafter insurance policy(ies) underwritten by a reputable
insurance company and in a form and having limits standard and customary for entities in the
biopharmaceutical industry for exposures related to the Lead Compounds. Such insurance shall include
general liability, clinical trial liability and products liability coverage with respect to such
party's performance of the Development Program and commercialization of Lead Compounds hereunder.
Upon request by the other party hereto, certificates of insurance evidencing the coverage required
above shall be provided to the other party.

17.2 Indemnification of FG. Astellas shall indemnify each of FG and its Affiliates and the
directors, officers, and employees of FG and such Affiliates and the successors and assigns of any
of the foregoing (the "FG Indemnitees"), and hold each FG Indemnitee harmless from and against any
and all liabilities, damages, settlements, claims, actions, suits, penalties, fines, costs or
expenses (including, without limitation, reasonable attorneys' fees and other expenses of
litigation) incurred by any FG Indemnitee to the extent not otherwise covered by insurance, arising
from or occurring as a result of any claim, action, suit, or other proceeding brought by third
parties against a FG Indemnitee arising from or occurring as a result of any development, testing,
manufacture, importation, use, offer for sale, sale or other distribution of any Lead Compound by or
for the benefit of Astellas or its Affiliates or Sublicensees, distributors or agents (including,
without limitation, product liability and infringement claims) except to the extent caused by
failure of the Lead Compound supplied by FG to meet the Product Specifications in effect at the time
of manufacture, or material deviation by FG or its sub-contractor from GMP Guidelines in
manufacturing the Lead Compound, or FG's breach of this Agreement or willful misconduct. -36-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 43 -->
CONFIDENTIAL EXECUTION COPY 17.3 Indemnification of Astellas. FG shall indemnify each of Astellas
and its Affiliates and the directors, officers, and employees of Astellas and such Affiliates and
the successors and assigns of any of the foregoing (the "Astellas Indemnitees"), and hold each
Astellas Indemnitee harmless from and against any and all liabilities, damages, settlements, claims,
actions, suits, penalties, fines, costs or expenses (including, without limitation, reasonable
attorneys' fees and other expenses of litigation) incurred by any Astellas Indemnitee to the extent
not otherwise covered by insurance, arising from or occurring as a result of any claim, action,
suit, or other proceeding brought by third parties against an Astellas Indemnitee to the extent
caused by failure of the Lead Compound supplied by FG to meet the Product Specifications in effect
at the time of manufacture, or material deviation by FG or its sub-contractor from GMP Guidelines in
manufacturing the Lead Compound, except in each case in this Section 17.3 to the extent caused by
Astellas' breach of this Agreement or willful misconduct.

17.4 Procedure. A party (for purposes of this Section 17.4, the "Indemnitee") that intends to claim
indemnification under any provision of this Agreement shall promptly notify the indemnifying party
(the "Indemnitor") in writing of any claim, action, suit, or other proceeding brought by third
parties in respect of which the Indemnitee or any of its Affiliates, or their directors, officers,
employees, successors or assigns intend to claim such indemnification hereunder. As between the
parties hereto the Indemnitor shall have the right to control the defense and settlement of such
claim, action, suit, or other proceeding; provided, that the Indemnitee shall have the right to
participate in such defense or settlement with counsel of its own choosing at its expense. The
Indemnitee shall not make any settlement of any loss, claim, damage, liability or action without the
consent of the Indemnitor, to the extent such consent is not withheld unreasonably or delayed. The
failure to deliver written notice to the Indemnitor within a reasonable time after the commencement
of any such action, if prejudicial to its ability to defend such action, shall relieve such
Indemnitor of any liability to the Indemnitee under this Article 17 but the omission so to deliver
written notice to the Indemnitor shall not relieve the Indemnitor of any liability that it may have
to any Indemnitee otherwise than under this Article 17. Without limiting the foregoing, the
Indemnitee shall keep the Indemnitor fully informed of the progress of any claim, action, suit, or
other proceeding for which it intends to claim indemnification under this Article 17.

ARTICLE 18 TERM AND TERMINATION

18.1 Term. This Agreement shall become effective as of the Effective Date and, shall continue in
full force and effect until terminated pursuant to this Article 18.

18.2 Termination for Cause or Technical Product Failure

18.2.1 Material Breaches. FG may forthwith terminate this Agreement in the event Astellas fails to
make any payment due under Articles 6, 9 or 14, within [ * ] following receipt of written notice of
such default, or materially breaches its obligations under Articles 8 or 14, and fails to cure such
breach within [ * ] following receipt of written notice of such default. Astellas may forthwith
terminate this Agreement in the -37-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 44 -->
CONFIDENTIAL EXECUTION COPY event FG materially breaches its obligations under Article 7 or Article
12, and fails to cure such breach within [ * ] following receipt of written notice of such default.
Any termination shall become effective at the end of such [ * ] or [ * ] period unless the
defaulting or breaching party (or any other party on its behalf) has cured any such default prior to
the expiration of the [ * ] or [ * ] period, as the case may be.

18.2.2 Independent Activities. Notwithstanding anything contained in Section 8.3.2 or Section
14.1.1, in the event that Astellas Commercializes any molecules for the Field or the Expanded Field,
except for actions taken within the Field in the course of the exercise of the licenses granted
under Sections 8.1 and 13.1 hereof and expressly authorized under this Agreement, even if FG
determines that Astellas' activities are completely independent of any FG Technology and/or any
other FG materials, confidential information, intellectual property or other related information
provided by FG to Astellas under this Agreement or any other agreement between FG and Astellas
relating to the subject matter hereof, FG shall have the right at its sole discretion to terminate
this Agreement upon [ * ] notice to Astellas.

18.2.3 Technical Product Failure. Astellas may terminate this Agreement upon [ * ] notice to FG upon
Technical Product Failure.

18.2.4 Development Diligence Failure. FG may terminate this Agreement upon thirty (30) days notice
to Astellas in the event Astellas fails to meet any of its development diligence requirements as set
forth in Article 11 hereof, provided, however, that with respect to the development diligence
obligations set forth in Section 11.3.2, such termination right on behalf of FG shall be triggered
only upon Astellas' failure to meet such development diligence obligations for a Major Indication
(except those Major Indications set forth in Section 11.3.1(iv)), and Astellas may terminate this
Agreement upon thirty (30) days notice to FG in the event FG fails to meet the development diligence
requirement as set forth in Section 11.2 hereof.

18.2.5 Other Material Non-Performance/Misrepresentation. Other than a breach giving rise to a
termination right as set forth in Sections 18.2.1 or 18.2.4, or a termination pursuant to a
Technical Product Failure as set forth in Section 18.2.3 in the event of (i) a party's breach or
default in any other material respect in the performance or observance of any other material term,
covenant or provision of this Agreement, or (ii) if any representation by a party contained in this
Agreement shall prove to have been incorrect in any material respect when made, resulting in
material adverse consequences for the other party, (any such default or material incorrect
representation a "Material Non-Performance"), such Material Non-Performance shall be remedied only
as provided in Section 18.7.4 below.

18.3 Termination in case of Generic Competition. In the event generic equivalents has captured the [
* ] of the quantity of Lead Compound sold by Astellas during the [ * ] preceding such termination
calculated on a annual basis; or in the event, after the entry into the market of generic
equivalents, that Astellas' annual sales fall below $[ * ] for all Lead Compounds, Astellas may
terminate this Agreement upon [ * ] written notice to FG; provided, that Astellas does not
Commercialize any Lead Compound after such termination until the expiration of the last to expire FG
Patents applicable to such Lead Compound. -38-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 45 -->
CONFIDENTIAL EXECUTION COPY 18.4 Negative Advice from Authorities. Astellas may terminate this
Agreement upon [ * ] notice to FG in the event Astellas has commenced Phase III clinical studies in
those of the following Indications that FG is developing: "Treatment of anemia in patients with
chronic kidney disease undergoing dialysis", "Treatment of anemia in patients with chronic kidney
disease not undergoing dialysis" and [ * ], and the Japanese Ministry of Health, Labor & Welfare has
provided written notification that it will not approve the Lead Compounds in such Indications or the
JDC determines, after the submission by Astellas of Marketing Approval Applications for such
Indications, and the receipt of a response or request of the Japanese Ministry of Health, Labor &
Welfare that contains development demands that are so onerous that it is not reasonable to continue
with Development of the Lead Compounds in such Indications.

18.5 Admission of Invalidity or Unenforceability of FG Patent. Astellas may terminate this Agreement
upon [ * ] notice to FG in the event that FG enters into a settlement under Section 14.3 that admits
the invalidity or unenforceability of all patents within the FG Technology, including patents
covering Lead Compounds.

18.6 Termination upon Notice. Subject to Section 18.7.2, Astellas may terminate this Agreement upon
six (6) months notice to FG for any reason or no reason.

18.7 Effect of Termination

18.7.1 Accrued Obligations. Termination of this Agreement for any reason shall not release either
party hereto from any liability which, at the time of such termination, has already accrued to the
other party or which is attributable to a period prior to such termination nor preclude either party
from pursuing all rights and remedies it may have hereunder or at law or in equity with respect to
any breach of this Agreement.

18.7.2 Termination. In the event of (a) a termination by Astellas under Section 18.6 during the
period from the execution of this Agreement until the last to expire of the FG Patents, or (b) by FG
under Section 18.2.1, 18.2.2, 18.2.4 or 18.2.5 hereof, Astellas shall, upon the effective date of
such termination, pay to FG (i) a termination fee of $[ * ] U.S. dollars and (ii) any payments to
which FG is otherwise entitled to receive hereunder in the period from the date of such termination
notice until the [ * ].

18.7.3 Survival. Articles 1, 5, 14, 16, 17, 18, 19 and 20, and Sections 8.3.3 and 10.5, shall
survive any termination of this Agreement, along with FG's rights and Astellas' obligations (but not
Astellas' rights or FG's obligations, except to the extent required by the Japanese Ministry of
Health, Labor and Welfare) under Section 5.1.1 and Article 7. In addition, the following provisions
shall survive termination of this Agreement for any reason: Astellas shall assign or cause to be
assigned to FG (or if not so assignable, Astellas shall take all reasonable actions to make
available to FG) all regulatory filings and registrations (including MAAs and Marketing Approvals)
with respect to the Lead Compounds that have been filed or made by or under authority of Astellas,
and the rights in trademark with respect to each Lead Compound as provided for in Section 4.4.1, in
each case such assignment (or availability) -39-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 46 -->
CONFIDENTIAL EXECUTION COPY shall be made within [ * ] after the notice of termination. From and
after the date of a notice of termination, FG shall have no further obligations under this Agreement
beyond those obligations that survive termination in such events as specified in this Section
18.7.3.

18.7.4 Material Non-Performance. In the event of any Material Non-Performance by a party, the other
party shall, without reasonable delay following discovery of such Material Non-Performance notify
the defaulting party in writing, and the parties shall consult with each other in good faith to
endeavor to agree upon the most effective means to cure such Material Non-Performance and, if
necessary, to effect a remedy in favor of the non-defaulting party for the consequences of such
Material Non-Performance by the defaulting party (collectively, the "Resolution"). In the event (i)
the parties are unable to agree upon Resolution, or (ii) the defaulting party, in the exercise of
reasonable diligence shall have been unable to remedy such Material Non-Performance, then in either
such event the remedy of the non-defaulting party with respect to the Material Non-Performance by
the defaulting party shall be determined by arbitration pursuant to Section 19.2 hereof, and the
arbitrators shall be authorized to fashion such remedy, including equitable relief, which may
include termination of this Agreement in whole or in part, as the arbitrators shall determine
appropriate, except that termination of this Agreement in whole shall only be the remedy of last
resort.

18.7.5 License Upon Termination. In the event of a termination of this Agreement, FG shall have an
irrevocable, exclusive, license, with the right to grant and authorize sublicenses, to any
trademarks used by Astellas in association with the Lead Compounds hereunder to make, use, sell,
import and otherwise exploit products within the Field in the Astellas Territory. Such license shall
be royalty-free, provided, however, if such trademark is not a global trademark (i.e. materially
different from the trademark used in the FG Territory) and either (i) if Astellas terminates this
Agreement under Section 18.2.1 or 18.2.4, or (ii) if this Agreement is terminated in accordance with
the procedure as provided for in Section 18.2.5 as a result of FG's Material Non-Performance, in
which event FG and Astellas shall negotiate in good faith a reasonable fee for such license.

ARTICLE 19 DISPUTE RESOLUTION

19.1 Disputes. If the parties are unable to resolve any dispute between them regarding the breach,
interpretation or enforcement of this Agreement, either party may, by written notice to the other,
have such dispute referred to their Authorized Designees, provided that such individuals are not
directly involved in the dispute (i.e., the dispute occurs at the JDC, such individuals shall not be
members of the JDC), for good faith negotiations. If after [ * ] such executives are unable to
resolve the issue, each of Astellas and FG shall have the right to refer the matter to mediation
upon notice to the other party, and the parties shall choose a mediator within [ * ] of the receipt
of such notice, and shall negotiate in good faith to resolve such matter through the mediator within
[ * ] thereafter.

19.2 Full Arbitration. Any dispute, controversy or claim arising out of or relating to the breach,
interpretation or enforcement of this Agreement, including disputes relating to termination of this
Agreement, shall be settled by binding arbitration in the manner -40-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 47 -->
CONFIDENTIAL EXECUTION COPY described in this Section 19.2. The arbitration shall be conducted
pursuant to the rules of Arbitration of the International Chamber of Commerce then in effect.
Notwithstanding those rules, the following provisions shall apply to the arbitration hereunder:

19.2.1 Arbitrators. The arbitration shall be conducted by a panel of three (3) arbitrators, with one
(1) arbitrator chosen by each of FG and Astellas and the third appointed by the other two (2)
arbitrators. If the parties are unable to agree upon a single arbitrator, or the third arbitrator in
case of a panel of three (3), such third arbitrator (as the case may be) shall be appointed in
accordance with the rules of the Arbitration of the International Chamber of Commerce.

19.2.2 Proceedings. Except as otherwise provided herein, the parties shall use their best efforts to
complete the arbitration within [ * ] after the appointment of the Panel under Section 19.2.1 above,
unless a party can demonstrate to the Panel that the complexity of the issues or other reasons
warrant the extension of one or more of the time tables. In such case, the Panel may extend such
time table as reasonably required. The Panel shall, in rendering its decision, apply the substantive
law of the State of California, without regard to its conflicts of laws provisions, except that the
interpretation of and enforcement of this Article 19 shall be governed by the U.S. Federal
Arbitration Act. The proceeding shall be conducted in English and shall take place in the city of
Vancouver, British Columbia, Canada. The judgment of the Panel shall be binding upon the parties and
enforceable in any court of competent jurisdiction.

19.2.3 Interim Relief. Notwithstanding anything in this Article 19 to the contrary, FG and Astellas
shall each have the right to apply to any court of competent jurisdiction for a temporary
restraining order, preliminary injunction, or other similar interim or conservatory relief, as
necessary, pending resolution under the above described arbitration procedures. Nothing in the
preceding sentence shall be interpreted as limiting the powers of the arbitrators with respect to
any dispute subject to arbitration under this Agreement.

ARTICLE 20 MISCELLANEOUS

20.1 Confidential Terms. Except as expressly provided herein, each party agrees not to disclose any
terms of this Agreement to any third party without the consent of the other party, except (i) as
required by securities or other applicable laws or (ii) to prospective and other investors and such
party's accountants, attorneys and other professional advisors, or (iii) to others under reasonable
conditions of confidentiality.

20.2 Governing Law. This Agreement and any dispute arising from the performance or breach hereof
shall be governed by and construed and enforced in accordance with, the laws of the State of
California, without reference to conflicts of laws principles.

20.3 Force Majeure. Nonperformance of any party (except for payment of amounts due hereunder) shall
be excused to the extent that performance is rendered impossible by strike, fire, earthquake, flood,
governmental acts or orders or restrictions, failure of suppliers, or any other reason where failure
to perform is beyond the reasonable control of the non- -41-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 48 -->
CONFIDENTIAL EXECUTION COPY performing party. In such event FG or Astellas, as the case may be,
shall promptly notify the other party of such inability and of the period for which such inability
is anticipated to continue. Without limiting the foregoing, the party subject to such inability
shall use reasonable efforts to minimize the duration of any force majeure event.

20.4 No Implied Waivers; Rights Cumulative. No failure on the part of FG or Astellas to exercise and
no delay in exercising any right under this Agreement, or provided by statute or at law or in equity
or otherwise, shall impair, prejudice or constitute a waiver of any such right, nor shall any
partial exercise of any such right preclude any other or further exercise thereof or the exercise of
any other right.

20.5 Independent Contractors. Nothing contained in this Agreement is intended implicitly, or is to
be construed, to constitute FG or Astellas as partners in the legal sense. No party hereto shall
have any express or implied right or authority to assume or create any obligations on behalf of or
in the name of any other party or to bind any other party to any contract, agreement or undertaking
with any third party.

20.6 Notices. All notices, requests and other communications hereunder shall be in writing and shall
be personally delivered or sent by registered or certified mail, return receipt requested, postage
prepaid; facsimile transmission (receipt verified); or express courier service (signature required),
in each case to the respective address specified below, or such other address or fax number as may
be specified in writing to the other party hereto: Astellas: Astellas Pharma Inc. Attn: Director of
Legal Department [ * ]

with copy to: Astellas Pharma Inc. Attn: Licensing, Corporate Strategy [ * ]

FG: FibroGen, Inc. Attn: Chief Executive Officer 225 Gateway Boulevard San Francisco, California
94080 Fax: 1-650-866-7202

with a copy to: FibroGen, Inc.

Attn: Legal Department 225 Gateway Boulevard San Francisco, California 94080 Fax: 1-650-866-7343
-42-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 49 -->
CONFIDENTIAL EXECUTION COPY 20.7 Assignment. This Agreement shall not be assignable by either party
to any third party without the written consent of the other party hereto; except that either party
may assign this Agreement without the other party's consent to an entity that acquires substantially
all of the business or assets of the assigning party within the Field, in each case whether by
merger, transfer of assets, or otherwise. Upon a permitted assignment of this Agreement, all
references herein to the assigning party shall be deemed references to the party to whom the
Agreement is so assigned.

20.8 Modification. No amendment or modification of any provision of this Agreement shall be
effective unless in writing signed by all parties hereto. No provision of this Agreement shall be
varied, contradicted or explained by any oral agreement, course of dealing or performance or any
other matter not set forth in an agreement in writing and signed by all parties.

20.9 Severability. If any provision hereof should be held invalid, illegal or unenforceable in any
jurisdiction, the parties shall negotiate in good faith a valid, legal and enforceable substitute
provision that most nearly reflects the original intent of the parties and all other provisions
hereof shall remain in full force and effect in such jurisdiction and shall be liberally construed
in order to carry out the intentions of the parties hereto as nearly as may be possible. Such
invalidity, illegality or unenforceability shall not affect the validity, legality or enforceability
of such provision in any other jurisdiction.

20.10 Counterparts. This Agreement may be executed in one or more counterparts, each of which shall
be deemed an original, and all of which together, shall constitute one and the same instrument.

20.11 Headings. Headings used herein are for convenience only and shall not in any way affect the
construction of or be taken into consideration in interpreting this Agreement.

20.12 Export Laws. Notwithstanding anything to the contrary contained herein, all obligations of FG
and Astellas are subject to prior compliance with United States and foreign export regulations and
such other United States and foreign laws and regulations as may be applicable, and to obtaining all
necessary approvals required by the applicable agencies of the governments of the United States and
foreign jurisdictions. FG and Astellas shall cooperate with each other and shall provide assistance
to the other as reasonably necessary to obtain any required approvals.

20.13 Language. This Agreement is in the English language only, which language shall be controlling
in all respects, and all versions hereof in any other language shall not be binding on the parties
hereto. All communications and notices to be made or given pursuant to this Agreement shall be in
the English language.

20.14 Entire Agreement. This Agreement (including the Exhibits hereto) constitutes the entire
agreement, both written or oral, with respect to the subject matter hereof, and supersedes all prior
or contemporaneous understandings or agreements, including the Binding Term Sheet, dated as of
February 9, 2004 by and between FG and Astellas, as amended -43-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 50 -->
CONFIDENTIAL EXECUTION COPY on January 25, 2005, whether written or oral, between FG and Astellas
with respect to such subject matter.

IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be duly executed and delivered
in duplicate originals as of the date first above written. ASTELLAS PHARMA INC. FIBROGEN, INC.

By: /s/ Toichi Takenaka By: /s/ Thomas B. Neff

Toichi Takenaka President and Chief Executive Officer Thomas Neff President and Chief Executive
Officer

Date: 1.September.05 Date: 23 August 05 -44-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 51 -->
CONFIDENTIAL EXECUTION COPY EXHIBIT A LIST OF PATENTS

[ * ] -45-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 52 -->
CONFIDENTIAL EXECUTION COPY EXHIBIT B INDICATIONS

Included indications:

• Treatment of anemia in patients with chronic kidney disease undergoing dialysis

• Treatment of anemia in patients with chronic kidney disease not undergoing dialysis

• [ * ] -46-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
<!-- page 53 -->
CONFIDENTIAL EXECUTION COPY EXHIBIT C INITIAL DEVELOPMENT PLAN

[ * ] -47-

[ * ] = Certain confidential information contained in this document, marked by brackets, has been
omitted and filed separately with the Securities and Exchange Commission pursuant to Rule 406 of the
Securities Act of 1933, as amended.
