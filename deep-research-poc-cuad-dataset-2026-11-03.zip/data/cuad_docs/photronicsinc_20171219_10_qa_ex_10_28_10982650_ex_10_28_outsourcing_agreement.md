<!-- page 1 -->
# OUTSOURCING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Outsourcing Agreement |
| Agreement Date | 2017-05-16 |
| Parties | Photronics, Inc. (“Photronics”); Dai Nippon Printing Co., Ltd. (“DNP”); Photronics DNP Photomask Corporation (“PDMC”); Xiamen American Japan Photronics Mask Co., Ltd. ("Company"); Phototronics and DNP ("Shareholder" and collectively as "Shareholders"); Shareholder and PDMC ("Supplier" and collectively as the Suppliers") |
| Source | CUAD v1 / PhotronicsInc_20171219_10-QA_EX-10.28_10982650_EX-10.28_Outsourcing Agreement |

Exhibit 10.28 Execution Version OUTSOURCING AGREEMENT

This OUTSOURCING AGREEMENT (this "Agreement") is made and entered into as of the 16t h day of May,
2017, by and among

Photronics, Inc., a Connecticut corporation with its principal place of business at 15 Secor Road,
Brookfield, Connecticut, U.S.A ("Photronics"),

Dai Nippon Printing Co., Ltd., a Japanese corporation with its principal place of business at 1-1,
Ichigaya Kagacho 1-chome, Shinjuku-ku, Tokyo, Japan ("DNP"),

Photronics DNP Photomask Corporation, a company limited by shares organized and formed under the
Company Act of the Republic of China with its principal place of business at 4f, #2, Li-Hsin Road,
Science Park, Hsinchu, Taiwan, ROC ("PDMC"), and

Xiamen American Japan Photronics Mask Co., Ltd., a limited liability company organized and formed
under the People's Republic of China with its principal place of business at R203-95, South Building
of Torch Square, No. 56-58 Torch Road, Gaoxin District, Xiamen, Fujian Province, Peoples Republic of
China (the "Company").

Each of Photronics and DNP is hereinafter referred to as a "Shareholder" and collectively as the
"Shareholders", each of the Shareholders and PDMC is hereinafter referred to as a "Supplier" and
collectively as the "Suppliers", and each of the Suppliers and the Company is hereinafter referred
to as a "Party" and collectively as the "Parties."

ARTICLE 1. BACKGROUND Photronics and DNP wish to participate in a joint venture, either directly or
indirectly through their respective Affiliates, as equity interest owners in the Company, and to
carry on the Business through the Company. The Parties are engaged, among other things, in the
design, development, fabrication and sale of advanced photomasks. Photronics and DNP, directly or
indirectly, are the shareholders of and own PDMC, a joint venture of Photronics and DNP in Taiwan.
In connection with the formation of the Company, Photronics and DNP have entered into "Joint Venture
Operating Agreement" (the "China JV Operating Agreement") dated as of the 16t h day of May, 2017. In
connection with the China JV Operating Agreement and in order to support the business objective of
the Company, including but not limited in order to (i) [***]the Company desires to outsource or
[***]of the Company pursuant to the terms and conditions set forth herein.

The Parties hereby agree and confirm the exclusive distribution mechanism set forth in Section 10.1
hereof. All terms and conditions for [***]will be governed by this Agreement. Any and all [***]set
forth in Section 5.15 of the China JV Operating Agreement.

1.1 Defined Terms Unless otherwise defined in this Agreement and Schedule 1 hereof, terms defined in
the China JV Operating Agreement shall have the same meanings when used in this Agreement.

Source: PHOTRONICS INC, 10-Q/A, 12/19/2017
<!-- page 2 -->
1.2 Incorporation by Reference Section 12 (Miscellaneous) of the China JV Operating Agreement shall
be incorporated by reference into and form an integral part of this Agreement, mutatis mutandis.

ARTICLE 2. PURCHASE ORDERS

2.1 Outsource and Issuance of Purchase Orders Subject to the terms and conditions mentioned
hereunder, the Parties agree to the outsource model based on [***]as follows, and the Parties also
agree that they may add additional Products to this Agreement through additional Purchase Orders
[***]

For the avoidance of doubt, the outsource model is purely made based on the [***]

Moreover, it is acknowledged by the Parties that[***] Therefore, subject to the prior notification
to, and the instruction and the express approval of the customers, the Steering Committee could
reasonably decide or change the outsource model at its own discretion in accordance with the China
JV Operating Agreement.

In any case, none of the Parties shall unreasonably [***] of the Products to take advantage of the
outsource relationship or [***]

A. Outsource Transition Period During the Outsource Transition Period, as for the Purchase Orders
received by the Company from: (a) [***] (b) [***] (c) [***]

(d) [***]and

(e) [***]

B. Post Outsource Transition Period (a) During the Post Outsource Transition Period, the following
rules for outsourcing the Purchase Orders to the Suppliers (the "Outsource Stepdown Rules") will
apply: Year 1: [***] Year 2: [***] Year 3: [***] Year 4 and thereafter: [***]

For the sake of clarity and by way of example, as for the above calculation; X: [***] Y: [***] Z:
[***]

2

Source: PHOTRONICS INC, 10-Q/A, 12/19/2017
<!-- page 3 -->
(b) If PDMC and the Company [***] (i) if [***]or (ii) if [***].

C. General (a) The Purchase Orders for the [***][***]in accordance with the .

(b) PDMC and the Company will make best efforts to be [***]The terms and conditions of such [***]

(c) For the avoidance of doubt, the Parties agree and confirm that, during the Outsource Transition
Period and aside from the Outsource Stepdown Rules in [***].

(d) The Parties acknowledge and agree that [***]

2.2 Purchase Orders The Suppliers will make good faith efforts to accept all [***]from the Company
that comply with this Agreement including adhering to all relevant specifications of the Product as
set forth in the [***]entered into between the Company and the Supplier (including the [***] (as
defined below)). The Suppliers shall notify the Company of acceptance or rejection of a [***]within
[***]hours of receipt of a [***]. Failure of the Suppliers to accept or reject a [***]within
[***]hours shall constitute acceptance of such [***]. The lead time for the Products will be as set
forth in the applicable [***]. Each [***]shall include the following: (a) the Company's [***]number;
(b) identification of the quantity and type of the Product ordered by the Company; (c) the price of
each Product ordered per Schedule 2 attached hereto; (d) the requested delivery date (subject to the
applicable Product Lead Time); (e) any shipping instructions, including preferred carrier and
shipping destination; and (f) the specifications for the Product. Notwithstanding anything contained
in this Agreement and the China JV Operating Agreement to the contrary, and for the sake of clarity,
[***]. 2.3 Purchase Order Terms All [***]agreed to between the Company and a Supplier shall be
governed by this Agreement unless otherwise agreed by the Company and the [***]which receives such
[***]in writing; the Parties agree that the [***]submitted by the Company to any of the [***] will
mirror the terms and conditions of the [***]with respect to specification for the Product and the
end customer's requirement submitted to the Company by the Company's [***]. Those terms and
conditions of the [***]may be discussed and agreed between the Company and any of the Suppliers
prior to issuance of such [***]to any of the [***].

2.4 Rescheduling and Cancellation The Company may not [***]any portion of an accepted [***]unless
the Supplier fails to fulfill any material term of such accepted [***]. The Suppliers shall at all
times use prudent material planning practices, including by way of example, [***]. The Company
[***]will be provided on a [***] basis covering a rolling [***]period. The Company will provide the
Suppliers with such [***]which will be updated [***] and [***]which will be updated [***] and will
be used for planning purposes only. If a Supplier's ability to supply any Product is constrained for
any reason, such Supplier shall immediately notify the Company of such supply constraint for the
purpose of resolving the same.

3

Source: PHOTRONICS INC, 10-Q/A, 12/19/2017
<!-- page 4 -->
2.5 End of Life Each of the Suppliers may terminate its obligations to supply a particular Product
under this Agreement by giving written notice of the end of life of such Product to the Company at
least [***]before the effective date of such termination (a "Product EOL Notice"), provided that (a)
the relevant Supplier shall supply, and the Company shall purchase, such Product ordered pursuant to
this Agreement until the effective date of such termination and including any accepted Purchase
Orders outstanding on the effective date of termination, and (b) the relevant Supplier is [***]to
its other [***] with respect to such Product. When the Company becomes aware that any of its
customers will finish purchasing any type of the Products, the Company shall promptly notify the
Supplier(s) thereof. Notwithstanding the above, if the Company has a long term supply agreement with
a customer and the Suppliers (i) has confirmed in writing its intention to [***] hereunder and (ii)
are actually providing Product in support of such supply agreement, neither Supplier can, to the
extent of its confirmation, to supply the Company until such s[***]; provided however that, if a
Shareholder terminates the [***], such Shareholder can immediately terminate [***].

2.6 Certain Claims Notwithstanding any other provisions in this Agreement, either Supplier may
[***]after Suppliers' receipt of a written [***] that is deemed credible by written opinion of the
relevant Supplier's outside counsel, provided that the relevant Supplier also [***] with respect to
such Product; provided further that (i) relevant Supplier shall give the Company at [***]calendar
days prior written notice of its intent to discontinue [***], and (ii) at the Company's request, if
the Company will using the [***], Suppliers will provide the Company with all reasonable information
and assistance necessary, [***]to the relevant [***]in accordance with the terms and conditions to
be agreed by the relevant Supplier and the Company, to enable the Company to manufacture or have the
[***]. Any such granted [***]shall [***] and provided information shall be destroyed or returned in
the event the relevant Supplier resumes[***]. The Company shall defend, indemnify and hold harmless
the relevant Supplier from and against any claims, expenses and costs (including but not limited to
attorney and other professional fees and expenses), settlement of third party claims (if negotiated
and approved by the Company), damages and liability arising from or related to [***]or the violation
of the [***] of any [***]solely with respect to the Company's manufacture, use, sale, offering for
sale, importation or distribution of any [***]during the [***]calendar days period specified in this
Section 2.6 or manufactured by or on behalf of the Company under the license granted in this Section
2.6.

2.7 Priority for New Products [***] for the Company will be reviewed and discussed by the Steering
Committee. The Steering Committee role will be as defined in Section 5.15 of the China JV Operating
Agreement.

ARTICLE 3. PURCHASE ORDER ALLOCATION

Notwithstanding any other provisions in this Agreement, the Parties agree that, [***]hereunder by
the Company to any of the Suppliers shall be at [***] pursuant to the [***]of the Company taking
into account the [***]of the Company's [***]and the [***] for the [***]; provided however that the
Company will attempt to allocate the [***] with each Supplier pursuant to the [***]set forth in
Section 2.1 above. The Parties will review the [***] of orders between Suppliers on a [***]. If at
the end of each [***]the [***]to one of the Suppliers is not consistent with the [***]set forth in
Section 2.1 above, the Company will attempt to [***]to the Suppliers with [***]for the [***]until
such Supplier has received [***]set forth in Section 2.1 above. Notwithstanding the above, each of
the Parties agrees and acknowledges that if a Supplier cannot provide Product to the Company because
of [***]of the Company, then the Company will be [***] to seek the Product from the other Supplier
without [***]of Product orders between the Suppliers.

4

Source: PHOTRONICS INC, 10-Q/A, 12/19/2017
<!-- page 5 -->
ARTICLE 4. PRODUCT PRICES AND PAYMENT

4.1 Prices The purchase price for the Product shall be as set forth in Schedule 2.

4.2 Invoices; Payments The Suppliers shall issue invoices to the Company for any amounts payable to
the Suppliers pursuant to this Agreement upon shipment of the applicable Products to the Company.
Payments for Products delivered in accordance with the Purchase Orders, and any other to be made by
the Company to Suppliers hereunder, shall be made in the Applicable Currency within [***]from the
shipment of the applicable Products delivered.

4.3 Taxes All amounts payable for Product sold by the Suppliers to the Company hereunder are
exclusive of any taxes. The Company shall be responsible for and shall pay any applicable sales,
use, excise or similar taxes, including value added taxes and customs duties due on the importation
of the Products and arising from purchases made by the Company under this Agreement, excluding any
taxes based on the Suppliers' income and any applicable withholding taxes. All such taxes shall be
determined based upon the final shipment designation of the items identified on the invoice. ARTICLE
5. DELIVERY

5.1 Risk of Loss and Title Delivery of all Products shall be made pursuant to the Delivery Term.
Risk of loss for the Products and title to the Products shall pass to the Company in accordance with
the Delivery Term.

5.2 Delivery Suppliers shall deliver the Product to the Company in accordance with the Delivery
Term, shipping instructions in the Purchase Order issued by the Company with regard to the requested
delivery date (subject to the Product Lead Time), ship-to address, and carrier. If the Company does
not provide shipping instructions, the Suppliers will select the carrier on a commercially
reasonable basis. Suppliers shall be responsible for paying freight, handling, shipping and/or
insurance charges to the delivery point in accordance with the Delivery Term.

5

Source: PHOTRONICS INC, 10-Q/A, 12/19/2017
<!-- page 6 -->
ARTICLE 6. LIMITED WARRANTIES

6.1 Suppliers Limited Warranty Each of the Suppliers warrants that the Products shall comply with
the specifications and documentation agreed by the relevant Supplier and the Company in writing that
is applicable to such Products for the Warranty Period. This warranty does not apply to any Product
failures resulting from misuse, storage in or exposure to environmental conditions inconsistent with
those specified in the applicable specifications or documentation, modification of the Product by
anyone other than the relevant Supplier. If a Product fails to comply with the foregoing warranty,
the relevant Supplier shall, at its option, either [***]such Product, or, in the event the foregoing
options are not commercially practicable, [***]to the Company any amounts paid for the applicable
Product. Without limiting the remedies specified in Article 8 and Section 9.2, this Section 6.1
states the exclusive remedy of the Company for failure of a Product to conform to the warranty
provisions set forth in this Section 6.1.

6.2 Disclaimer EXCEPT AS EXPRESSLY SET FORTH IN THIS ARTICLE 6, THE PARTIES MAKE NO WARRANTIES OR
REPRESENTATIONS TO THE OTHER PARTIES AND EACH PARTY HEREBY DISCLAIMS ANY AND ALL OTHER WARRANTIES,
EXPRESS OR IMPLIED, INCLUDING THE WARRANTIES OF MERCHANTABILITY, NON-INFRINGEMENT AND FITNESS FOR A
PARTICULAR PURPOSE.

ARTICLE 7. TERM AND TERMINATION

7.1 Term This Agreement shall become effective as of the Effective Date and shall continue to be in
full force and effect for so long as Photronics and DNP, or any of their Affiliates, each remains a
Shareholder of the Company.

7.2 Termination for Cause A Party shall have the right to terminate its obligations under this
Agreement if the other Party materially breaches this Agreement and fails to cure such breach within
thirty (30) days after its receipt of written notice of the breach specifying such default.

7.3 Survival Article 6 (for the duration of the applicable warranty period), Article 7, Article 8
and Article 9 shall survive any termination or expiration of this Agreement.

ARTICLE 8. INDEMNIFICATION

8.1 Indemnification by the Suppliers Each of the Suppliers shall, with respect to Products supplied
by such Supplier, defend, indemnify and hold harmless the Company from and against any third party
claims, expenses and costs (including but not limited to attorney and other professional fees and
expenses), settlement (if negotiated and approved by the relevant Supplier), damages and liability
to the extent arising from a claim (a) alleging that a Product infringes or misappropriates any
Intellectual Property Rights, or (b) arising under products liability theory from a manufacturing
defect, and shall pay any judgments finally awarded by a court or any amounts contained in a
settlement agreed to by the relevant Supplier arising from such claims. The foregoing indemnity does
not cover claims that solely arise from (i) the modification of the Product by any party other than
the relevant Supplier, (ii) the combination or use of the Product with other products, processes,
methods, materials or devices except as approved by the relevant Supplier, or (iii) the fault of the
Company.

6

Source: PHOTRONICS INC, 10-Q/A, 12/19/2017
<!-- page 7 -->
8.2 Indemnification by the Company Other than claims for which the Suppliers are obligated to
indemnify the Company under Section 8.1, the Company shall defend, indemnify and hold harmless the
Suppliers from and against any third party claims, expenses and costs (including but not limited to
attorney and other professional fees and expenses), settlement (if negotiated and approved by the
Company), damages and liability to the extent arising from a claim (a) alleging that a Product
supplied by such Supplier infringes or misappropriates any Intellectual Property Rights, or (b)
arising under products liability theory from a manufacturing defect, and shall pay any judgments
finally awarded by a court or any amounts contained in a settlement agreed to by the Company arising
from such claims. The foregoing indemnity does not cover claims that solely arise from (i) the
modification of the Product by any party other than the Company, or (ii) the combination or use of
the Product with other products, processes, methods, materials or devices except as approved by the
Company.

8.3 Procedure The Party seeking indemnification hereunder (the "Indemnified Party") agrees to
promptly inform the other Party (the "Indemnifying Party") in writing of such claim and furnish a
copy of each communication, notice or other action relating to the claim and the alleged
infringement. The Indemnified Party shall permit the Indemnifying Party to have sole control over
the defense and negotiations for a settlement or compromise, provided that the Indemnifying Party
may not settle or compromise a claim in a manner that imposes or purports to impose any liability or
obligations on the Indemnified Party without obtaining the Indemnified Party's prior written
consent. The Indemnified Party agrees to give all reasonable authority, information and assistance
necessary to defend or settle such suit or proceeding at the Indemnifying Party's reasonable request
and at the Indemnifying Party's expense.

ARTICLE 9. LIABILITY AND REMEDY

9.1 Limited Liability EXCEPT FOR LIABILITY ARISING FROM BREACHES OF A PARTY'S CONFIDENTIALITY
OBLIGATIONS CONTAINED IN THE NON-DISCLOSURE CLAUSE IN SECTION 12.17 OF THE CHINA JV OPERATING
AGREEMENT, BREACHES OF LICENSE GRANTS CONTAINED HEREIN, AND EXCEPT FOR AMOUNTS PAYABLE TO THIRD
PARTIES TO FULFILL INDEMNITY OBLIGATIONS DESCRIBED IN ARTICLE 8, (A) IN NO EVENT SHALL ANY PARTY
HAVE ANY LIABILITY TO THE OTHERS, OR TO ANY PARTY CLAIMING THROUGH OR UNDER THE OTHER, FOR ANY LOST
PROFITS, ANY INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OF ANY KIND IN ANY WAY ARISING
OUT OF OR RELATED TO THIS AGREEMENT, HOWEVER CAUSED AND UNDER ANY THEORY OF LIABILITY, EVEN IF SUCH
PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES; AND (B) IN NO EVENT SHALL A PARTY'S
CUMULATIVE LIABILITY ARISING OUT OF THIS AGREEMENT EXCEED THE AMOUNTS ACTUALLY PAID, PAYABLE,
RECEIVED OR RECEIVABLE BY SUCH PARTY FOR THE PRODUCTS CONCERNED THEREWITH HEREUNDER PURSUANT TO THIS
AGREEMENT DURING THE TWELVE (12) MONTHS PRIOR TO THE OCCURRENCE OF THE INITIAL EVENT FOR WHICH A
PARTY RECOVERS DAMAGES HEREUNDER. THESE LIMITATIONS SHALL APPLY NOTWITHSTANDING ANY FAILURE OF
ESSENTIAL PURPOSE OF ANY REMEDY. THE PARTIES ACKNOWLEDGE AND AGREE THAT THIS ARTICLE 9 IS AN
ESSENTIAL ELEMENT OF THE BARGAIN AND ABSENT THIS ARTICLE 9 THE ECONOMIC AND OTHER TERMS OF THIS
AGREEMENT WOULD BE SUBSTANTIALLY DIFFERENT.

7

Source: PHOTRONICS INC, 10-Q/A, 12/19/2017
<!-- page 8 -->
9.2 Remedies Notwithstanding anything stated to the contrary in this Agreement, the Parties
acknowledge that any breach of Section 2.5 [***]of this Agreement and/or the non-disclosure clause
in Section 12.17 of the China JV Operating Agreement by a Party would cause irreparable harm to the
other Parties, and that the damages arising from any such breach would be difficult or impossible to
ascertain. As such, the Parties agree that a Party shall be entitled to injunctive relief and other
equitable remedies in the event of any breach or threatened breach of Section 2.5 of this Agreement
and/or the non-disclosure clause in Section 12.17 of the China JV Operating Agreement. Such
injunctive or other equitable relief shall be in addition to, and not in lieu of, any other remedies
that may be available to that Party. The Parties shall be entitled reasonable attorney fees and
costs of enforcement of this Agreement.

ARTICLE 10. OTHER ARRANGEMENT

[***][***].

(Signature Page Follows)

8

Source: PHOTRONICS INC, 10-Q/A, 12/19/2017
<!-- page 9 -->
Execution Version IN WITNESS WHEREOF, the Parties hereto have duly executed this Agreement as of the
day and year first above written.

PHOTRONICS, INC. By: Name: [***] Title: [***] DAI NIPPON PRINTING CO., LTD. By: Name: [***] Title:
[***] Photronics DNP Mask Corporation . By: Name: [***] Title: [***] Photronics DNP Mask Corporation
Xiamen By: Name: [***] Title: [***]

Outsourcing Agreement Signature Page

Source: PHOTRONICS INC, 10-Q/A, 12/19/2017
<!-- page 10 -->
Schedule 1

Definitions

Capitalized words and phrases used and not otherwise defined elsewhere in this Agreement shall have
the following meanings:

1. "Affiliate" of a Person means any other Person which, directly or indirectly, controls, is
controlled by, or is under common control with, such Person. The term "control" (including, with
correlative meaning, the terms "controlled by" and "under common control with"), as used with
respect to any Person, means the possession, directly or indirectly, of the power to direct or cause
the direction of the management and policies of such Person, whether through the ownership of voting
securities, by contract or otherwise. A Person shall be deemed an Affiliate of another Person only
so long as such control relationship exists.

2. "Applicable Currency" means (i) for payments in relation to Photronics, U.S. Dollars, (ii) for
payments in relation to DNP, U.S. Dollars, and (iii) for payments in relation to PDMC, US Dollars.

3. "Delivery Term" means DDP (Incoterms 2010) at delivery point in China. The Delivery Term may be
otherwise determined by the Company and the Supplier in the Purchase Order where delivery point is
other place than China.

4. [***].

5. "Intellectual Property Rights" means all rights in and to (a) U.S. and foreign patents and patent
applications, including all divisions, substitutions, continuations, continuations-in-part, and any
reissues, re-examinations and extensions thereof, (b) copyrights and other rights in works of
authorship, (c) unpatented inventions, trade secrets, data, processes, or materials, (d) mask work
rights, and (e) other intellectual property or proprietary rights of any kind now known or hereafter
recognized in any jurisdiction, but excluding trademarks, service marks, trade names, trade dress,
domain names, logos and similar rights, and the goodwill associated therewith.

6. [***].

7. [***].

8. [***].

9. [***].

10. [***]. 11. "Product" means photolithographic integrated circuit photomasks for [***] and related
services.

12. "Purchase Order" means any of the following (a) a written purchase order issued to the Company
by third party buyers for the purchase of certain Products; (b) a written purchase order issued by
the Company to a Supplier for a quantity of the Product.

13. "Warranty Period" means a period of [***]from the relevant Supplier's shipment of the Product.
*** Confidential treatment has been requested by Photronics, Inc. for redacted portions of this
exhibit. This copy omits the information subject to the confidentiality request. Omissions are
designated as [***]. A complete version of this exhibit has been provided separately to the
Securities and Exchange Commission.

Source: PHOTRONICS INC, 10-Q/A, 12/19/2017
<!-- page 11 -->
Schedule 2

Product Prices

The prices for each Product outsourced to the Suppliers shall be [***].

*** Confidential treatment has been requested by Photronics, Inc. for redacted portions of this
exhibit. This copy omits the information subject to the confidentiality request. Omissions are
designated as [***]. A complete version of this exhibit has been provided separately to the
Securities and Exchange Commission.

Source: PHOTRONICS INC, 10-Q/A, 12/19/2017
