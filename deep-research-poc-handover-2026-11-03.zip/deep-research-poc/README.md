# deep-research-poc

Agentic deep research over a pre-filtered set of 500–1,000+ documents — no index, no knowledge
graph, no model training, ≤ 5 minutes per answer. Three approaches built one by one on a shared
foundation and compared on one golden set.

- **`CLAUDE.md`** — design decisions, invariants, model/endpoint mapping. Read first.
- **`PLAN.md`** — phased implementation plan with acceptance criteria.
- **`TODO.md`** — approaches to explore after the core three are measured (deepagents, harness engineering, …).

## Quick start

```bash
pip install -e ".[dev]"            # core + pytest
pytest -q                          # 116 deterministic tests, no model calls (8 skip until the CUAD corpus is built)

# configure endpoints (OpenAI-compatible; see src/dr/llm.py)
export DR_ENDPOINT_DEFAULT=https://<gateway>/v1  DR_API_KEY_DEFAULT=...
export DR_MODEL_RESEARCHER=gpt-oss-120b DR_MODEL_EXTRACTOR=nemotron-nano DR_MODEL_WRITER=gemma
python scripts/probe_endpoints.py  # writes docs/endpoints.md

# materialize a workspace from parsed markdown and try the tools (no model)
python - <<'EOF'
from pathlib import Path
from dr.ingest.load import load_dir
from dr.workspace import Workspace
from dr.tools import grep, read, outline, manifest
docs = load_dir(Path("data/sample_docs"))
ws = Workspace.materialize(docs, Path(".runs/demo"))
print(manifest.render(*manifest.list_docs(ws)))
print(grep.render(grep.grep(ws, r"Leverage Ratio")))
EOF
```

## Status (2026-11-02)

All three approaches are implemented and run end to end on the 510-contract CUAD corpus; see
`HANDOVER.md` for the full state, `docs/findings.md` for every measurement, `eval/README.md` for tables.

| Component | State |
|---|---|
| Contracts, workspace, grep/read/outline/list_docs, evidence bank, tier-1 alignment | implemented + tested |
| Researcher loop (Approach 2, `A2_fs_agent`) | implemented, live-tested on synthetic and CUAD corpora |
| Writer (outline-first, fact-bound), tier-1 report verification, top-level graph with deadline | implemented, live-tested |
| Approach 1 (`A1_deep_list`): ephemeral BM25, `search`/`page_results`, first move with clue expansion, router | implemented, live-tested; 5/6 on the CUAD slice with thinking off |
| Approach 3 (`A3_fanout`, `A3_grid_only`): sub-question units, extract grid, gap round | implemented; four live iterations on one coverage question, judge not yet passing |
| Tier-2 grouped verification + MinHash provenance gate | implemented; seeded check flags 10/10 planted errors |
| Eval runner, metrics, rubric judge, 7 variants, resume, 429 pacing/backoff | implemented |
| Three-way measurement on CUAD | **pending**: the free endpoint's throttling stopped the full pass and the 12-question smoke set; rerun at concurrency 1 |
| Long-context router branch (`LC_small`), Phase 8 hardening | not started |

## Layout

```
src/dr/            package (see src/dr/__init__.py)
prompts/           21 prompt files (inventory in prompts/README.md)
scripts/           probe_endpoints.py, make_golden_corpus.py, fetch_cuad.py, make_cuad_corpus.py, make_cuad_golden.py
data/sample_docs/  3 synthetic docs; data/golden_docs/ + data/golden/questions.jsonl (31 docs, 42 q);
                   data/cuad_docs/ (built by script) + data/golden/cuad_questions.jsonl (510 contracts, 112 q) + cuad_smoke.jsonl (12 q)
tests/             deterministic tests
notebooks/         thin orchestration notebooks 01-04 (written, not yet executed)
```
