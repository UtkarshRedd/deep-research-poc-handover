<!-- page 1 -->
# Promotion and Distribution Agreement
| Field | Value |
|---|---|
| Document Type | Promotion Agreement |
| Agreement Date | 2011-08-01 |
| Parties | Whitesmoke Inc. ("Distributor"); Google Inc ("Google") |
| Source | CUAD v1 / WHITESMOKE,INC_11_08_2011-EX-10.26-PROMOTION AND DISTRIBUTION AGREEMENT |

Exhibit 10.26 CONFIDENTIAL TREATMENT HAS BEEN REQUESTED AS TO CERTAIN PORTIONS OF THIS DOCUMENT.
EACH SUCH PORTION, WHICH HAS BEEN OMITTED HEREIN AND REPLACED WITH AN ASTERISK [*], HAS BEEN FILED
SEPARATELY WITH THE SECURITIES AND EXCHANGE COMMISSION. PROMOTION AND DISTRIBUTION AGREEMENT This
Promotion and Distribution Agreement including all exhibits (collectively referred to as the
"Agreement"), effective as of 1 August 2011 (the "Effective Date"), is made by and between
Whitesmoke Inc., with registered offices/principle place of business at 501 Silverside Road, Suite
105, Wilmington DE 19809, USA, ("Distributor"), and Google Inc whose principle place of business is
at 1600 Amphitheatre Parkway, Mountain View, CA 94043, USA ("Google").

"Bundle" means the Distribution Products bundled with the Distributor App(s). "Chrome Browser" means
the machine-readable binary code version of the Google Chrome browser provided to Distributor in
connection with this Agreement, and any modifications or updates to it that Google may provide to
Distributor. "Chrome Browser Installer" means: (a) the machine-readable binary code version of the
installer provided to Distributor in connection with this Agreement that installs the Chrome
Browser, and any modifications, updates or upgrades to it that Google may provide to Distributor;
and (b) the Chrome Browser Criteria Checker. "Chrome Use Event" means an event that indicates an [*
] has occurred. "Chrome Server Communication" means a communication that, as determined solely by
Google, is sent for the purpose of indicating that an End User: (a) is [* ] to the [* ]; and (b) has
kept the [* ] open for a minimum of [* ] during a [* ] (whether during the [* ] or a [* ] of the
Chrome Browser). "Criteria Checker" means a set of software routines (and any updates to them)
provided to Distributor by Google, as part of a software library, that check certain criteria (as
determined by Google and modified by Google from time to time) to determine if the Chrome Browser or
Google Toolbar (as applicable) can be installed on an End User's operating system. Accordingly,
"Chrome Browser Criteria Checker" means the Criteria Checker provided by Google in respect of the
Chrome Browser and "Google Toolbar Criteria Checker" means the Criteria Checker provided by Google
in respect of the Google Toolbar. "Distributor App(s)" means the following application (and
successor versions of such software): the trial version of the WhiteSmoke Writer (currently called
WhiteSmoke 2011) available on a worldwide basis, but for the avoidance of doubt shall not mean any
other products of Distributor, including without limitation the full paid version of Whitesmoke
Writer or any version of Whitesmoke "Translator" software, regardless of whether Whitesmoke Writer
incorporates any translation functionality. *Confidential treatment requested Google Confidential

1. DEFINITIONS

1.1 In this Agreement unless expressly stated otherwise:

- 1 -
<!-- page 2 -->
"Distribution Products" means:

"End User" means an end user customer of Distributor who is located in the Territory. "EULA" means
the end user license agreement applicable to a Product, which end user license agreement may be
updated or modified by Google in its sole discretion from time to time. "False" means a "false"
response (or equivalent negative response) given by the Criteria Checker. "Google Program
Guidelines" means the policy and implementation guidelines applicable to the Products as updated by
Google and provided to Distributor from time to time. "Google Toolbar" means the machine-readable
binary code version of the Google toolbar for Internet Explorer provided to Distributor in
connection with this Agreement, and any modifications or updates to it that Google may provide to
Distributor. "Google Toolbar Installer" means: (a) the machine-readable binary code version of the
installer provided to Distributor in connection with this Agreement that installs the Google
Toolbar, and any modifications, updates or upgrades to it that Google may provide to Distributor;
and (b) the Google Toolbar Criteria Checker. "Google Trademarks" means all names, trade names,
trademarks, and logos used by Google in connection with the Products. "Group Company" means in
relation to each of the parties:

"Install Completed" occurs when an End User has completed the install process for a Bundle and the
install completed screen is shown to the End User in accordance with Exhibit B.

(a) as at the Effective Date, the Google Toolbar Installer and the Chrome Browser Installer; and

(b) if Distributor notifies Google at any time after the Effective Date that it wishes to bundle the
full Google Toolbar and Google provides its approval in writing (including email), the Google
Toolbar; and

(c) if Distributor notifies Google at any time after the Effective Date that it wishes to bundle the
full Chrome Browser and Google provides its approval in writing (including email), the Chrome
Browser.

(a) any parent company of that party; and

(b) any corporate body of which that party directly or indirectly has control or which is directly
or indirectly controlled by the same person or group of persons as that party.

- 2 -
<!-- page 3 -->
"Intellectual Property Rights" means all copyright, moral rights, patent rights, trade marks, design
right, rights in or relating to databases, rights in or relating to confidential information, rights
in relation to domain names, and any other intellectual property rights (registered or unregistered)
throughout the world. "IPO" means an initial public offering of all or any of the shares in
Distributor or securities representing those shares for the purposes of being publically traded or
quoted on an investment exchange. "Maximum Distribution Commitment" means [* ] , as may be increased
by Google pursuant to Clause 4.2 (Maximum Distribution Commitment). "[ * ]" means a [ * ] or [ * ]
entered by the [ * ] into the [ * ] located at the [ * ] of the [ * ]. [ * ] do not include the
events listed in Clause 3.9(c)(ii). "Products" means the Google Toolbar, Google Toolbar Installer,
Chrome Browser and Chrome Browser Installer. "[ * ]" means the [ * ] received by a [ * ] that, as
determined solely by [ * ]: (a) is [ * ] by a [ * ] obtained via a [ * ]; (b) is the next [ * ] that
occurs following a [ * ]; and (c) includes the [ * ]. [ * ] only include those [ * ] which meet the
requirements set out in Clause 3.9(c)(iii). "[ * ]" means a [ * ] received by [ * ] that, as
determined solely by [ * ]: (a) is [ * ] by a [ * ] obtained via a [ * ]; (b) is sent for the [ * ]
of indicating that an [ * ]: (i) has opened [ * ] following installation of the [ * ], (ii) is [ * ]
to the [ * ], and (iii) has [ * ] a [ * ] into the [ * ]; and (c) includes the correct [ * ]. [ * ]
only include those [ * ] which meet the requirements set out in Clause 3.9(c)(i). "Term" means the
earlier of: (a) the end of the two year period from the Effective Date to 31 July 2013; or (b) the
last day of the calendar month within which the Maximum Distribution Commitment is reached.
"Territory" means those countries listed in Exhibit A, excluding any territory or state prohibited
under Clause 11.5. "True" means a "true" response (or equivalent positive response) given by the
Criteria Checker.

*Confidential treatment requested Google Confidential

1.2 In this Agreement, the words "include" and "including" will not limit the generality of any
words preceding them.

2. LICENSE GRANTS AND RESTRICTIONS

2.1 Products License Grant. Subject to the terms and conditions of this Agreement, Google grants to
Distributor a [* ] license during the Term to: (a) bundle the Distribution Products, in
machine-readable binary code format only, solely with Distributor App(s); (b) distribute Bundles
directly (or indirectly, subject to Clause 2.2 (Third Party Distribution)) to End Users in the
Territory; (c) when indicated by the applicable Criteria Checker and requested by the End User in
accordance with clause 3.2 (Form of Distribution Offering), install the Chrome Browser or the Google
Toolbar (as applicable) on the End User's system using the Google Installers; and (d) reproduce (or
have reproduced by Third Party Distributors as defined in Clause 2.2 (Third Party Distribution)),
the Distribution Products to the extent necessary to exercise the rights granted in (a), (b) and
(c).

- 3 -
<!-- page 4 -->
*Confidential treatment requested Google Confidential

2.2 Third Party Distribution. Distributor may distribute Bundles to third parties solely for
redistribution of such Bundles by those third parties directly to End Users (such third parties,
"Third Party Distributors"); provided that: (a) in connection with any and all such offers or
distributions, Distributor shall, and shall ensure that each Third Party Distributor shall,
distribute Bundles in a manner that is no less protective of the Products and Google than the terms
of this Agreement, and (b) Google in its sole discretion may direct Distributor to cease
distributing Bundles to any Third Party Distributor that in Google's sole discretion would either:
(i) harm or devalue Google's business, brand or name, or (ii) violate Google's privacy policy, and
Distributor shall cause any such Third Party Distributor to cease distribution of Bundles as soon as
practicable but in no event longer than [ * ] following receipt of such request from Google.
Distributor shall ensure that no Third Party Distributor bundles anything in or with Bundles without
Google's prior written approval, and if Google grants its approval, Distributor shall provide Google
with information about any such bundling arrangements at Google's request.

2.3 License Grant Restrictions. Distributor shall not, and shall not allow any third party to
(except to the extent that such prohibitions are not permitted by law): (a) disassemble, de-compile
or otherwise reverse engineer the Products or otherwise attempt to learn the source code or
algorithms underlying the Products; (b) modify the Products, create derivative works from or based
on the Products; (c) except as expressly set out in this Agreement, provide, sell, license,
distribute, lease, lend, or disclose the Products to any third party; (d) use the Products for
timeshare, service bureau, or other unauthorised purposes; or (e) exceed the scope of any license
granted to Distributor under this Agreement.

2.4 Trademark License and Use. Subject to the terms and conditions of this Agreement, Google grants
to Distributor a limited, [ * ] license during the Term to use the Google Trademarks, in accordance
with Google's trademark usage guidelines, solely to market and promote the Products consistent with
this Agreement, provided that all use of the Google Trademarks shall be subject to Google's prior
review and advance written consent. All uses of the Google Trademarks, and all goodwill associated
therewith, shall inure solely to the benefit of Google.

2.5 Trademark Restrictions. Distributor shall not remove, modify, adapt, or prepare derivative works
of any Google Trademarks or Google copyright notices, or other Google proprietary rights notices.

2.6 Updated Versions of Distribution Products. Google may request that Distributor distribute the
latest version of the Distribution Products. Distributor shall begin such distribution within [ * ]
following Google's request.

3. DISTRIBUTION AND OTHER OBLIGATIONS

3.1 Delivery. Google shall deliver the Distribution Products electronically to Distributor at a [ *
] following the Effective Date and prior to Launch (as defined in Clause 3.4 (Launch)).

- 4 -
<!-- page 5 -->
User to review such EULA via a hyperlink to such EULA: and (c) a button on which each End User may
click indicating agreement to the terms of such EULA. In the event that an End User does not
affirmatively agree to install the Google Toolbar or Chrome Browser, by clicking on the button to
agree to the terms of the applicable EULA, then the Google Toolbar or Chrome Browser (as applicable)
shall not be installed on such End User's computer.

*Confidential treatment requested Google Confidential

3.2 Form of Distribution Offering. Distributor shall ensure that the form of any offering of the
Products by Distributor, including the timing, relative and absolute placement, visual presentation
to End Users, initial launch of the Products (and any modifications to them) and the presentation of
any other applications or products offered with the Products, conforms to the Google Program
Guidelines and to Exhibit B of this Agreement. Except as set out in Clause 2 (Licence Grant and
Restrictions) and except for End Users as expressly set out in this Agreement, Distributor shall not
offer or distribute the Products to any third party. If, during the Term, Exhibit B and the Google
Program Guidelines conflict, Exhibit B will take precedence with respect to the conflicting terms.

3.3 Guidelines for Applications. Distributor shall comply, and shall ensure that each Third Party
Distributor complies, with the Guidelines for Applications set out in Exhibit C.

3.4 Launch. Distributor shall begin distribution of Bundles in accordance with this Agreement
("Launch") within [ * ] days following the Effective Date (the date of such Launch, the "Launch
Date"). Beginning on the Launch Date and continuing throughout the Term, Distributor shall ensure
that [ * ]Distributor App distributed by or on behalf of Distributor is bundled with the
Distribution Products as set out in this Agreement.

3.5 Exclusivity.

(a) [ * ]

(b) [ * ].

3.6 EULA. In connection with Distributor's distribution of the Products under this Agreement, and
before the Google Toolbar or Chrome Browser can be installed by an End User, Distributor shall
provide each End User with: (a) a clear statement inviting the End User to agree to the terms of the
applicable EULA; (b) the opportunity for each End

3.7 Accurate Reproduction. Distributor agrees that in connection with its exercise of the right
granted in Clause 2.1 (Products Licence Grant) it shall accurately reproduce the Distribution
Products and shall not: (a) modify any Product (including modify the Chrome Browser or Google
Toolbar configuration files or registry settings); or (b) insert into the Products any viruses,
worms, date bombs, time bombs, or other code that is specifically designed to cause the Products to
cease operating, or to damage, interrupt, or interfere with any Products or End User data.

3.8 [ * ]. During the Term and for a period of [ * ] following the expiration or termination of this
Agreement, Distributor shall not, and shall not engage any third party to: (a) restrict, modify, or
reconfigure in any manner any of the Products that have been installed by End Users (such End Users,
"Installed Base End Users") in connection with this Agreement; or (b) engage in activities that
encourage Installed Base End Users to modify, uninstall or reconfigure any or the Products.

- 5 -

*Confidential treatment requested Google Confidential
<!-- page 6 -->
3.9 Reporting.

(a) By Distributor. During the Term, Distributor shall, on a [ * ] basis, no later than the [ * ] of
the following [ * ], provide Google with a report identifying, on a country-by-country basis, the
total number of: (i) Bundles distributed; (ii) Installs Completed; (iii) Google Toolbar offers
presented to End Users; and (iv) Chrome Browser offers presented to End Users, in the preceding [ *
].

(b) By Google. During the Term, Google shall on a [ * ] basis, provide Distributor with a report of
the [ * ] of [ * ] and [ * ] in the preceding [ * ] broken down on a [ * ] basis and by the [ * ] in
Exhibit A.

(c) Parameters. Distributor acknowledges, and shall cooperate with Google to [ * ] that:

(i) [ * ]: (A) are determined on a [ * ] (B) are only [ * ]; (C) do not include [ * ] from computers
on which another [ * ] of the [ * ] is [ * ]; and (D) do not include use of the [ * ] in any [ * ]
other than [ * ].

(ii) [ * ] do not include: (A) [ * ] that has been [ * ], (B) [ * ] or [ * ] in any area other than
in the [ * ], or (C) any other [ * ] of the [ * ] designed to artificially [ * ].

(iii) [ * ]: (A) are determined on a [ * ]; (B) are only [ * ]; (C) are not sent in response to [ *
] from computers on which another [ * ] of the [ * ] is [ * ]; and (D) are sent only in response to
[ * ] from computers that meet the [ * ] requirements as determined by the [ * ].

(d) Records and Audit Rights. Distributor will keep and maintain complete and accurate books,
records, and accounts relating to this Agreement. During the Term, and for a period of [ * ]
thereafter, Google may audit Distributor's relevant records to confirm Distributor's compliance with
this Agreement. Google's auditor will only have access to those books and records of Distributor
which are reasonably necessary to confirm such compliance.

4. PAYMENT TERMS

4.1 Payments. Subject to Clause 4.2, during the Term on a [ * ] basis, Google shall pay to
Distributor the applicable payment set out in Exhibit A for each [ * ] and each [ * ] that occurred
during the previous [ * ]. Google shall determine the [ * ] in respect of which each [ * ] and [ * ]
took [ * ] (using the relevant [ * ]). Notwithstanding the foregoing, in no event will the [ * ] of
[ * ] by Google to Distributor for all [ * ] and all [ * ] in respect of [ * ] (as set out in
Exhibit A) exceed [ * ] ([ * ]) of the [ * ] to Distributor for such [ * ].

4.2 [ * ]. Notwithstanding anything to the contrary, in no event shall the [ * ] paid or payable to
Distributor by Google pursuant to Clause 4.1 (Payments) exceed the [ * ]. Google shall have the
right, at its sole option, to increase the [ * ] by providing written notice to Distributor no later
than [ * ] prior to the end of the Term. The foregoing sentence shall not relieve Google of any
payment obligations that have accrued prior to the achievement of the [ * ].

4.3 Payment Terms. All payments under this Agreement shall be made in [ * ] in the [ * ] following
the [ * ] for which the payments are applicable. The party receiving payment will be responsible for
any bank charges assessed by the recipient's bank. In addition to other rights and remedies Google
may have, Google may offset any payment obligations to Distributor that Google may incur under this
Agreement against any product or service fees owed to Google and not yet paid by Distributor under
any agreement between Distributor and Google. Google may also withhold and offset against its
payment obligations under this Agreement, or require Distributor to pay to Google within [ * ] of
any invoice, any amounts Google [ * ] overpaid to Distributor in prior periods.

- 6 -
<!-- page 7 -->
*Confidential treatment requested Google Confidential

4.4 Taxes. All payments under this Agreement are exclusive of taxes imposed by any governmental
entity. Google shall pay any applicable taxes imposed by governmental agencies with respect to the
transactions under this Agreement other than taxes based upon Distributor's income. Google shall
promptly provide to Distributor a copy of an official tax receipt or other appropriate evidence of
any taxes imposed on payments made under this Agreement. When Distributor has the legal obligation
to collect any applicable taxes, the appropriate amount shall be invoiced to and paid by Google
unless Google provides Distributor with a valid tax exemption certificate authorised by the
appropriate taxing authority.

4.5 Interest. Distributor may charge interest at the rate of [ * ] above the base rate of Barclays
Bank PLC from time to time, from the due date until the date of actual payment, whether before or
after judgment, on any payment pursuant to this Clause 4 (Payment Terms) which is overdue.

5. TERM AND TERMINATION

5.1 Term. This Agreement shall commence on the Effective Date and, unless earlier terminated as set
out in this Agreement, shall continue for the Term.

5.2 Termination for breach. A party may suspend performance and/or terminate this Agreement, with
immediate effect, if the other party:

(a) is in material breach of this Agreement where the breach is incapable of remedy; or

(b) is in material breach of this Agreement where the breach is capable of remedy and fails to
remedy that breach within thirty (30) days after receiving written notice of such breach.

5.3 Termination for insolvency. A party may suspend performance and/or terminate this Agreement with
immediate effect, if:

(a) the other party enters into an arrangement or composition with or for the benefit of its
creditors, goes into administration, receivership or administrative receivership, is declared
bankrupt or insolvent or is dissolved or otherwise ceases to carry on business; or

(b) any analogous event happens to the other party in any jurisdiction in which it is incorporated
or resident or in which it carries on business or has assets.

5.4 Change of Control. [ * ] may terminate this Agreement immediately upon written notice if there
is a Change of Control of [ * ]. In this Clause the term "Control" shall mean the possession by any
person(s) directly or indirectly of the power to direct or cause the direction of another person and
"Change of Control" is to be construed accordingly. [ * ] expected to experience, or [ * ] is
experiencing, such Change of Control shall notify [ * ] in writing of this before or within [ * ]
after the Change of Control. If [ * ] has not exercised its right of termination under this Clause
within [ * ] following the later of (i) the receipt of notice of [ * ] Change of Control or (ii) the
Change of Control event, that [ * ]. The parties acknowledge that as at the Effective Date, [ * ]
may [ * ] its [ * ]. [ * ] agrees not to exercise its termination right under this clause 5.4 if [ *
], provided that following [ * ]:

- 7 -
<!-- page 8 -->
For the avoidance of doubt, if following [ * ] there is a transfer of shareholding or interests in
Distributor to any existing or new shareholder(s) which results in any person or persons
subsequently gaining Control of Distributor, then Google may exercise its right to terminate in
accordance with this clause 5.4..

*Confidential treatment requested Google Confidential

5.4.1. no one person Controls [ * ] (other than an[ * ] which is not a [ * ] of [ * ] (as determined
by [ * ]in its sole discretion)); and

5.4.2. no [ * ] of [ * ] (as determined by [ * ] in its sole discretion) holds a [ * ] or [ * ] in [
* ].

5.5 Additional Termination Rights. Google may terminate this Agreement immediately upon written
notice to Distributor if: (a) Distributor breaches Clause 2 (License Grants and Restrictions),
Clause 3.6 (EULA), Clause 3.7 (Accurate Reproduction), or Clause 6 (Confidential Information), (b)
if Google believes, in good faith, that the Distributor has violated or caused Google to violate any
Anti-Bribery Laws (as defined in Clause 8.5) or that such a violation is reasonably likely to occur,
or (c) Distributor is in material breach of this Agreement more than [ * ] notwithstanding any cure
of such breaches. Notwithstanding anything to the contrary, in the event that the government or
controlling body of any country or territory in which Bundles are distributed imposes any law,
restriction or regulation that makes it illegal to distribute the Products, or any portion of them,
into such country or territory, or if any such law, restriction or regulation places a substantial
burden on Google, where substantial is measured with respect to Google's economic benefit under this
Agreement, as determined by Google in its reasonable and good faith judgment (such substantial
burden, a "Substantial Burden") then either party or Google (in the case of a Substantial Burden)
may require the suspension of all distributions of Bundles in such country or territory until such
time as such law, restriction or regulation is repealed, nullified or modified such that it is no
longer illegal or a Substantial Burden (in the case of Google), as applicable, for Bundles to be
distributed in such country or territory ("Special Suspension"); provided, however, that
Distributor's obligations under Clause 3.5 (Exclusivity) shall not apply in respect of the relevant
country or territory during any period of Special Suspension. If a period of Special Suspension
extends for more than [ * ] may then terminate this Agreement (in part) in respect of the affected
country or territory only, such termination to take effect upon written notice[ * ]. [ * ] will use
its reasonable endeavours to provide [ * ] with [ * ] (to the extent it is practicable to do so) of
the [ * ] or [ * ] (which was commenced by [ * ]).

5.6 Effect of Termination. Upon expiration or termination of this Agreement: (a) all rights and
licenses granted under this Agreement shall immediately cease; (b) Distributor shall (and shall
ensure that any Third Party Distributors shall) immediately stop reproducing the Products and
offering or distributing Bundles; (c) Distributor shall return or destroy (and a duly appointed
officer of Distributor shall certify to such destruction) all copies of the Products and any other
Google Confidential Information in its possession; and (d) the fees payable to Distributor shall
immediately cease accruing and Google shall within [ * ] following such expiration or termination
pay to Distributor any undisputed amounts which have accrued from the time of the most recent
payment to Distributor through the date of termination or expiration of this Agreement. Clauses 5.6
(Effect of Termination), 6 (Confidential Information), 7 (Proprietary Rights), 9 (Limitation of
Liability), 10 (Indemnification) and 11 (General) shall survive the termination or expiration of
this Agreement.

- 8 -
<!-- page 9 -->
*Confidential treatment requested Google Confidential

6. CONFIDENTIAL INFORMATION

6.1 In this Agreement, "Confidential Information" means information disclosed by (or on behalf of)
one party to the other party under this Agreement that is marked as confidential or, from its
nature, content or the circumstances in which it is disclosed, might reasonably be supposed to be
confidential, including the terms and conditions (including the Exhibits) of this Agreement. It does
not include information that the recipient already knew, that becomes public through no fault of the
recipient, that was independently developed by the recipient or that was lawfully given to the
recipient by a third party.

6.2 The recipient of any Confidential Information shall not disclose that Confidential Information,
except to Group Companies, employees and/or professional advisors who need to know it and who have
agreed in writing (or in the case of professional advisors are otherwise bound) to keep it
confidential. The recipient shall ensure that those people and entities: (a) use such Confidential
Information only to exercise rights and fulfill obligations under this Agreement, and (b) keep such
Confidential Information confidential. The recipient may also disclose Confidential Information when
required by law, or the regulation or rule of a major US stock exchange or the United States
Securities and Exchange Commission, after giving reasonable notice to the discloser, such notice to
be sufficient to give the discloser: (i) the opportunity to seek confidential treatment, a
protective order or similar remedies or relief prior to disclosure (if applicable) and (ii) (where
any disclosure is necessary) time to consult on and approve the form and content of the relevant
disclosure. The parties shall then promptly discuss and agree in good faith on the form and content
of the disclosure (each acting reasonably).

7. PROPRIETARY RIGHTS

7.1 Distributor acknowledges that Google and/or its licensors own all right, title and interest,
including all Intellectual Property Rights in and to the Products and the Google Trademarks and all
modifications to them. Distributor has, and shall acquire, no rights in the foregoing except those
expressly granted by this Agreement. Google shall not be restricted from selling, licensing,
modifying, or otherwise distributing the Products and/or the Google Trademarks to any third party.

7.2 Google acknowledges that Distributor and/or its licensors own all right, title and interest,
including all Intellectual Property Rights, in and to the Distributor Apps and all [ * ] to [ * ].
Except as expressly set forth in this Agreement, Distributor shall not be [ * ]from [ * ], or
otherwise [ * ]the Distributor App(s) or other products of Distributor to [ * ].

8. WARRANTIES

8.1 Each party warrants to the other that it will use reasonable care and skill in complying with
its obligations under this Agreement. Distributor also represents and warrants that it will
undertake commercially reasonable endeavours in good faith to comply with Google's business partner
due diligence process including providing requested information.

- 9 -
<!-- page 10 -->
*Confidential treatment requested Google Confidential

8.2 Google warrants that the Distribution Products will for a period of [ * ] from the date of their
supply to Distributor be free from any defect which has a materially adverse effect on their use or
operation.

8.3 If any of the warranties in Clause 8.1 or 8.2 is breached by Google, Distributor must tell
Google as soon as possible. Distributor must give Google a reasonable time to fix the problem and
(if necessary) to supply Distributor with a corrected or replacement version of the Distribution
Product or a way to work-around the problem that is not materially detrimental to Distributor, or to
re-perform any relevant services. This will be done without any additional charge to Distributor. If
Google is able to do this within a reasonable time, Google will have no other obligations or
liability in relation to that breach.

8.4 Google will not be liable for breach of any of the warranties or other terms in this Agreement
to the extent that the breach arises from:

(a) use of the Products other than in accordance with normal operating procedures;

(b) any alterations or maintenance to the Products done by anyone other than Google or someone
authorised by Google;

(c) any problem with a computer on which the Products are installed, or with any equipment connected
to that computer or any other software which is installed on that computer;

(d) any abnormal or incorrect operating conditions; or

(e) use of the Products in combination with any other hardware or software, unless this use has been
approved by Google in writing.

8.5 Distributor will comply with all applicable commercial and public anti-bribery laws, including,
without limitation, the UK's Bribery Act 2010 and the U.S. Foreign Corrupt Practices Act of 1977
("Anti-Bribery Laws"), which prohibit (amongst other things) corrupt offers of anything of value,
either directly or indirectly, to a government official to obtain or keep business. ''Government
officials" include any government employee, candidate for public office, and employee of
government-owned or government-controlled companies, public international organisations, and
political parties. Furthermore, Distributor will not make any facilitation payments, which are
payments to induce officials to perform routine functions they are otherwise obligated to perform.

8.6 No conditions, warranties or other terms apply to the Products, [ * ] or to any other goods or
services supplied under this Agreement unless expressly set out in this Agreement. Subject to Clause
9.1, no implied conditions, warranties or other terms apply (including any implied terms as to
satisfactory quality, fitness for purpose or conformance with description).

9. LIMITATION OF LIABILITY

9.1 Nothing in this Agreement shall exclude or limit either party's liability for:

(a) death or personal injury resulting from the negligence of either party or their servants, agents
or employees;

(b) fraud or fraudulent misrepresentation;

- 10 -
<!-- page 11 -->
In this Clause 9.4, "Contract Year" means a period of one year starting on the Effective Date or the
relevant anniversary of the Effective Date (as appropriate). If the amount referred to in (b) above
cannot be calculated accurately at the time the relevant liability is to be assessed (the
"Applicable Time"), it shall be calculated on a pro-rata basis as X/Y x Z. Where: X = the total sum
paid and payable to the Distributor pursuant to Clause 4 in the relevant Contract Year prior to the
Applicable Time; Y = the number of days elapsed in the relevant Contract Year prior to the
Applicable Time; and Z = 365 *Confidential treatment requested Google Confidential

(c) breach of any implied condition as to title or quiet enjoyment; and

(d) misuse of confidential information.

9.2 Nothing in this Agreement shall exclude or limit either party's liability under Clause 10
(Indemnities), or Distributor's liability under Clause 2 (License Grants and Restrictions), Clause
3.5 (Exclusivity), Clause 3.6 (End User License Agreement) and Clause 3.7 (Accurate Reproduction) or
Clause [ * ].

9.3 Subject to Clauses 9.1 and 9.2, neither party shall be liable under this Agreement (whether in
contract, tort or otherwise) for any:

(a) loss of anticipated savings;

(b) loss of business opportunity (which for the avoidance of doubt shall not include loss of
advertising revenue);

(c) loss of or corruption of data;

(d) loss or damage resulting from third party claims; or

(e) indirect or consequential losses;
suffered or incurred by the other party (whether or not such losses were within the contemplation of
the parties at the date of this Agreement).

9.4 Subject to Clauses 9.1 and 9.2, each party's total liability under or in connection with this
Agreement (whether in contract, tort or otherwise) arising in any Contract Year is limited to the
greater of:

(a) [ * ] Euros ([ * ] Euros); and

(b) [ * ]% of the total payment due to the Distributor in the relevant Contract Year pursuant to
Clause 4 (Payment Terms).

- 11 -
<!-- page 12 -->
By Distributor.

User claim arising out of or resulting from such End Users use of any Distributor App(s), including
any actions or claims in product liability, tort, contract or equity. *Confidential treatment
requested Google Confidential

10. INDEMNIFICATION BY GOOGLE.

10.1 Google [ * ] and will indemnify Distributor against all liabilities, costs, damages and
expenses (including settlement costs approved in writing by Google and reasonable legal fees [ * ])
suffered or incurred by Distributor arising from any claim from a third party that any Products or
any Google Trademark infringe(s) any copyright, trade secret or trademark of such third party (an
"IP Claim"), provided that Distributor:

(a) promptly notifies Google;

(b) provides Google with reasonable information, assistance and cooperation in responding to and,
where applicable, defending such IP Claim; and

(c) gives Google full control and sole authority over the defence and settlement of such IP Claim.
Distributor may appoint its own supervising counsel of its choice at its own expense.

10.2 Google will not have any obligations or liability under this Clause 10 in relation to any IP
Claim arising from:

(a) use of the Products or Google Trademarks in a modified form or in combination with materials not
furnished by Google;

(b) use of the Products or Google Trademarks other than in accordance with this Agreement; or

(c) any content, information or data provided to Google by Distributor, End Users or any other third
parties;

10.3 Google may (at its sole discretion) suspend Distributors distribution or use of the Products or
the Google Trademarks which are alleged, or believed by Google, to infringe any third party's
Intellectual Property Rights, or modify such items to make them non-infringing. if any suspension
under this Clause continues for more than 30 days, Distributor may, at any time until use of the
distribution or use of the Products or the Google Trademarks is reinstated, terminate this Agreement
immediately upon written notice. [ * ] will use reasonable endeavours to [ * ] with [ * ] (to the
extent it is practicable to do so) of the [ * ] or [ * ].

10.4 Distributor [ * ] and will indemnify Google against all liabilities, costs, damages and
expenses (including settlement costs approved in writing by Distributor and reasonable legal fees [
* ]) suffered or incurred by Google or any Google Group Company arising from: (a) Distributor's
improper (ie not in accordance with the requirements of this Agreement including the Exhibits) or
unauthorised, replication, packaging, marketing, distribution, or installation of the Products,
including any breach of Clause 8.5 and any claims based on representations, warranties, or
misrepresentations made by Distributor, (b) any claim from a third party that the Distributor App(s)
infringe any third party copyright, trademark, or trade secret, or (c) any End

- 12 -
<!-- page 13 -->
*Confidential treatment requested Google Confidential

10.5 The indemnification obligations set out in Clause 10.4(b) shall exist only if Google: (a)
promptly notifies Distributor of such claim, (b) provides Distributor with reasonable information,
assistance and cooperation in responding to and, where applicable, defending the lawsuit or
proceeding, and (c) gives Distributor full control and sole authority over the defense and
settlement of such claim. Google may join in defense with counsel of its choice at its own expense.

10.6 The foregoing Clauses 10.1 to 10.5 states the parties' entire liability and exclusive remedy
with respect to infringement of a third party's Intellectual Property Rights.

11. GENERAL

11.1 Publicity. Subject to clause 6 (Confidential Information), neither party may make any public
statement regarding the relationship contemplated by this Agreement without the other's prior
written approval.

11.2 Notices. All notices of termination or breach must be in English, in writing, addressed to the
other party's Legal Department and sent to Distributor's address set out at the head of this
Agreement or to [ * ] (as applicable) or such other address as either party has notified the other
in accordance with this Clause. All notices shall be deemed to have been given on receipt as
verified by written or automated receipt or electronic log (as applicable). All other notices must
be in English, in writing, addressed to the other party's primary contact and sent to their then
current postal address or email address.

11.3 Assignment. [ * ] may [ * ]any of its rights or obligations under this Agreement without the
prior written consent of [ * ]. For the avoidance of doubt, a Change of Control shall be deemed an
assignment hereunder unless [ * ] does not exercise its [ * ].

11.4 Force Majeure. Neither party shall be liable for failure to perform or delay in performing any
obligation under this Agreement if the failure or delay is caused by any circumstances beyond its
reasonable control.

11.5 Compliance with Export Laws. Distributor shall comply with all applicable export and re-export
control laws and regulations ("Export Laws"), which the parties agree include: (a) the Export
Administration Regulations maintained by the U.S. Department of Commerce, (b) trade and economic
sanctions maintained by the U.S. Treasury Department's Office of Foreign Assets Control, and (c) the
International Traffic in Arms Regulations maintained by the U.S. Department of State. Unless
Distributor obtains prior authorisation required by applicable Export Laws, Distributor shall not
export any Product to Cuba, Iran, North Korea, Sudan or Syria.

11.6 No Waiver. Failure or delay in exercising any right or remedy under this Agreement shall not
constitute a waiver of such (or any other) right or remedy.

11.7 Severability. The invalidity, illegality or unenforceability of any term (or part of a term) of
this Agreement shall not affect the continuation in force of the remainder of the term (if any) and
this Agreement.

11.8 No Agency. Except as expressly stated otherwise, nothing in this Agreement shall create an
agency, partnership or joint venture of any kind between the parties.

11.9 No Third-Party Beneficiaries. Except as expressly stated otherwise, nothing in this Agreement
shall create or confer any rights or other benefits in favour of any person other than the parties
to this Agreement.

- 13 -
<!-- page 14 -->
Signed by the parties on the dates shown below.

*Confidential treatment requested Google Confidential

11.10 Governing Law. This Agreement is governed by English law and the parties submit to the
exclusive jurisdiction of the English courts in relation to any dispute (contractual or
non-contractual) concerning this Agreement save that either party may apply to any court for an
injunction or other relief to protect its Intellectual Property Rights. If this Agreement is
translated into any other language, if there is conflict the English text will take precedence.

11.11 Counterparts. The parties may execute this agreement in counterparts, which taken together
will constitute one instrument.

11.12 Entire Agreement. Subject to Clause 9.1, this Agreement sets out all terms agreed between the
parties in relation to its subject matter and supersedes all previous agreements between the parties
relating to the same. In entering into this Agreement neither party has relied on any statement,
representation or warranty not expressly set out in this Agreement.

DISTRIBUTOR GOOGLE INC /[ * ] /s/ [ * ] By By [ * ] [ * ] Name Name [ * ] [ * ] Title Title [ * ] [
* ] Date Date

- 14 -
<!-- page 15 -->
EXHIBIT A Payments

*[ * ] ** [ * ]. *Confidential treatment requested Google Confidential
<!-- page 16 -->
[ * ] [ * ] [ * ] [ * ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [
* ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [
* ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [
* ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [ * ] [ * ] $ [ * ] [
* ] [ * ] $ [ * ] [ * ]** [ * ]* $ [ * ]

- 15 -

EXHIBIT B Process Flow

- 16 -
<!-- page 17 -->
Form of Offering 1 - WhiteSmoke Welcome Screen

- 17 -
<!-- page 18 -->
2-Toolbar offer lf [ * ] Criteria Checker has returned "True"

*Confidential treatment requested

- 18 -
<!-- page 19 -->
3-Chrome offer If [ * ] Criteria Checker has not returned 'True" AND [ * ] Criteria Checker has
returned "True"

*Confidential treatment requested

- 19 -
<!-- page 20 -->
4 - Installation Progress

Google Confidential

- 20 -
<!-- page 21 -->
5 - Chrome First Launch If Chrome has been installed

Criteria Checker During the Term, for each End User who installs the Distributor App, Distributor
shall use the [ * ] Criteria Checker to determine if [ * ] can be offered to such End User. If the [
* ] Criteria Checker returns True, Distributor shall offer the End User the opportunity to install
the [ * ] in conjunction with the Distributor App. If the [ * ] Criteria Checker returns False
Distributor shall: a) not offer the End User the opportunity to install the [ * ] and b) use the [ *
] Criteria Checker to determine whether the [ * ] can be offered to such End User. If the [ * ]
Criteria Checker returns True, Distributor shall offer the End User the opportunity to install the [
* ] in conjunction with the Distributor App. If the [ * ] Criteria Checker returns False,
Distributor shall not offer such End User the opportunity to install the [ * ]. Prior to Launch,
Distributor shall obtain Google's approval of the parameters Distributor uses to call the [ * ]
Criteria Checker and [ * ] Criteria Checker Chrome Browser Auto Launch. Distributor shall ensure
that the first launch of the Chrome Browser following installation of the Chrome Browser complies
with each of the following requirements (the "Chrome Launch Requirements"): (a) The Chrome Browser
shall auto-launch immediately prior to the launch of the Distributor App, no earlier and no later.
*Confidential treatment requested

- 21 -
<!-- page 22 -->
(b) No advertisements, offers, or other communications shall appear between launch of a Distributor
App and launch of the Chrome Browser. (c) Upon launch of the Chrome Browser, the Chrome Browser
shall immediately appear on the End User's computer desktop exactly as shown in this Exhibit B.
Without limiting the preceding sentence, each of the following shall appear on the End User's
desktop exactly as shown in this Exhibit B: (i) the location and size of the Chrome Browser window
and the Distributor App window, (ii) the z-order of the Distributor App and the Chrome Browser, and
(iii) the number and content of the tabs in the Chrome Browser (i.e., the Chrome Browser shall
contain exactly two (2) tabs, with the first tab set to google.com, and the second tab set to
http://tools.google.com/chrome/intlfen-US/welcome.html (or such other url as Google may specify). In
no event shall the Chrome Browser window be minimized. Notwithstanding the foregoing, Distributor
may modify the content and design of the Distributor App window provided that Distributor complies
with the other restrictions in this Agreement and obtains Google's prior consent. (d) The tabs in
the Chrome Browser and the Omnibox shall be clearly visible to the End User as shown in this Exhibit
B, regardless of the resolution of the End User's monitor. In no event shall the tabs in the Chrome
Browser or the Omnibox be hidden behind a Distributor App. (e) Distributor shall implement (or, if
implemented by Google, Distributor shall not modify) the six-month flag (i.e., the functionality
that prevents an End User from receiving more than one (1) offer for the Chrome Browser within any
six (6)-month period) unless Google has provided written confirmation (including by email) that the
6-months flag can be turned off. Note that this authorisation may be revoked at any time and
Distributor shall then include the 6 months flag again in future builds.

- 22 -
<!-- page 23 -->
EXHIBIT C Guidelines for Applications Bundled with Google Applications Google has observed a
significant increase in the number of reports of software that is engaging in deceptive, malicious
and other annoying practices that significantly diminish user perception and enjoyment of the
internet. These practices include but are not limited to installing software on computers without
obtaining informed end user consent (the so-called "drive-by download"), inundating end users with
advertisements without adequate attribution or labeling, exposing users to pornographic material
without obtaining informed end user consent, obtaining or transmitting personal information about an
end user without obtaining informed end user consent, and interfering with an end user's ability to
easily uninstall applications the end user does not wish to be on his or her computer. Google does
not wish to be associated with these types of practices. Accordingly, Google has developed the
Guidelines set forth below to prevent its trademark, other intellectual property, and services from
being used in connection with these practices. Google believes that these Guidelines are necessary
to protect Google from any allegation that it has contributed to practices that might be viewed as
unlawful or actionable; to preserve the reputation of Google as a provider of trusted software and
services in a manner that is beneficial and fair to users and other constituents; and to stem the
rising incidence of practices that harm users and diminish the perceived value and reliability of
the internet, which are essential to Google's business. With this objective in mind, Google has
established the following Guidelines to apply to customer Applications that are bundled with any
Google Application. Except to the extent Google has otherwise specifically agreed in writing, Google
does not grant permission to, and you will not, bundle any Application with a Google Application
unless you ensure that any such Application specified in the agreement between you and Google that
incorporated these Guidelines complies with these Guidelines. For the avoidance of doubt, by these
Guidelines Google does not intend to, and does not, impose any restrictions on what you may do with
any Application that is not bundled with a Google Application, bundled with an Application that
accesses Google services, or used to access Google services; you remain free to sell any Application
you wish (whether or not it complies with these Guidelines) so long as it is not bundled with a
Google Application, bundled with an Application that accesses Google services, or used to access
Google services. In these Guidelines: (a) "you" and "your" refer to the legal entity(ies) that has
entered into the contract with Google into which these Guidelines are incorporated, as well as any
person or entity acting on your behalf; and (b) "Application" means any application, plug-in,
helper, component or other executable code that runs on a user's computer, examples of which include
those that provide browser helper objects, instant messaging, chat, email, data, file viewing, media
playing, file sharing, games, internet navigation, search and other services. Google Confidential

- 23 -
<!-- page 24 -->
Google welcomes input about these Guidelines from you and from other interested parties, and is
always willing to consider revisions as appropriate to encourage innovation while protecting against
deceptive, unfair and harmful practices. Accordingly, Google may update these Guidelines, including
the Attachments, from time to time as provided in Section 10 below. If you have any questions about
these Guidelines, please do not hesitate to discuss them with your Google account manager. Google
Confidential

- 24 -
<!-- page 25 -->
1. General. 1.1 Approval and Ongoing Compliance. You may bundle Google Applications with
Applications only to the extent permitted in the signed written agreement into which these
Guidelines have been incorporated. In such instance, you must ensure that your Application both (1)
has been approved by Google for the purpose of being bundled with Google Applications in writing in
advance, and (2) complies at all times with the requirements outlined herein. To obtain Google's
approval for any Applications not expressly approved in your agreement, you must submit a written
request. 1.2 No Google Branding or Attribution. Your Application, and any related collateral
material (including any Web pages promoting your Application or from which your Application is made
available), must not contain any Google branding, trademarks or attribution unless (and then only to
the extent) Google expressly consents otherwise in writing. In addition, queries entered into
Applications may not resolve to a results page that contains any Google branding, trademarks or
attribution unless (and then only to the extent) Google expressly consents otherwise in writing. 2.
Prohibited Content. You may not bundle any Google Application with an Application that: (a) contains
any viruses, worms, trojan horses, or the like; and (b) is distributed primarily for the purpose of
(i) distributing pornographic, obscene, excessively profane, gambling-related, deceptive, fraudulent
or illegal content, or (ii) distributing content related to "hacking" or "cracking." 3. Prohibited
Behavior. You may not bundle any Google Application with an Application that engages in deceptive,
unfair, harassing or otherwise annoying practices. For example, the Application may not:

Google Confidential

(a) use, or permit an unaffiliated person to use, an end user's computer system for any purpose not
understood and affirmatively consented to by the end user (including, without limitation, for
purposes of consuming bandwidth or computer resources, sending email messages, launching denial of
service attacks, accruing toll charges through a dialer or obtaining personal information from an
end user's computer such as login, password, account or other information personal to the end user);

(b) intentionally create or exploit any security vulnerabilities in end user computers;

(c) trigger pop-ups, pop-unders, exit windows, or similar obstructive or intrusive functionality,
that materially interfere with an end user's Web navigation or browsing or the use of his or her
computer;

(d) repeatedly ask an end user to take, or try to deceive an end user into taking, an action that
the end user has previously declined to take (such as repeatedly asking an end user to change his or
her home page or some other setting or configuration);

- 25 -
<!-- page 26 -->
4. Disclosure and Consent. 4.1 Disclosure and Consent before Installation. You may not bundle any
Google Application with any Application unless you (and your distribution and bundling partners, if
applicable under the terms of the agreement between you and Google that incorporates these
Guidelines) design the installation of any such Application in a manner that ensures that it is
installed by end users in a knowing and willful manner - e.g., no "drive-by' downloads or installs.
By "distribution partner" we mean any third party who distributes your Application and by "bundling
partner" we mean any third party who installs your Application in combination with or alongside one
or more other Applications. At a minimum, compliance with this provision requires that, prior to
installing your Application, you and any third party distributing or bundling your Application:

4.2 Disclosure and Consent for Collection and Transmission of Personally Identifiable information.
You may not bundle any Google Application with any Application that (1) collects or transmits to any
entity other than the end user personally identifiable information, or (2) collects or transmits
information related to a user's computer or Internet usage or activity in a manner that could
collect or transmit such user's personally identifiable information (such as through keystroke
logging), unless prior to the first occurrence of any such collection or transmission you:

Google Confidential

(e) redirect browser traffic away from valid DNS entries (except that your Application may direct
unresolved URLs to an alternative URL designated by you, provided that the page to which the end
user resolves adequately informs the end user that you and your Application are the source of that
page);

(f) interfere with the browser default search functionality (except that your Application may permit
an end user to change his or her default search engine with proper disclosure, consent and
attribution as provided below); or

(g) engage in activity that violates any applicable Jaw or regulation.

(a) first, fully, accurately, clearly and conspicuously disclose to end users:

(i) that they are installing an application,

(ii) the name of the Application, identifying you as the entity responsible for it, and

(iii) the principal and significant features and functionality of the Application; and

(b) then, obtain the end user's affirmative consent to install the Application.

(a) first, fully, accurately, clearly and conspicuously disclose:

- 26 -
<!-- page 27 -->
4.3 Disclosure and Consent for Setting Changes. You may not bundle any Google Application with any
Application that makes a change to any operating system or Application data setting which will
impact the user experience of other Applications (e.g., changing the browser default home page or
changing the default application for a file type, such as the default email, browser or media player
application), unless prior to making such change you:

Notwithstanding the foregoing, (i) no disclosure and consent need be made for changes to operating
system or Application data settings that have only a minor impact on user experience, such as adding
a small number of bookmarks to the browser menu or adding an item to a start menu, and (ii) the
disclosure and consent requirements of this Section 4.3 will not apply to those setting changes that
may be made prior to sale to the end user. 4.4 Method of Disclosure and Consent. In order to satisfy
the requirements above, the disclosure of the items specified above (a) must be provided in both (1)
the End User License Agreement (EULA) or privacy policy (to the extent required by law or otherwise
by industry custom) and (2) separately from the EULA and/or privacy policy (e.g. in installation
screens or message boxes, as the case may be), and (b) must be designed so that it will be read by,
adequately inform and evidence the consent of a typical Internet user. See Attachment 1 for sample
disclosure and consent implementations that would satisfy certain of the requirements above. 4.5
EULA and Privacy Policy. You may not bundle any Google Application with any Application unless it
conforms, and is distributed pursuant to a EULA that conforms, with all applicable laws and
regulations. In addition, you and your Application must comply with the agreements and
representations you make with your end users in your EULA and privacy policy. Your privacy policy
must be accessible from your Application in an easily found location. If your Application collects
or transmits any other information related to the user's use of his or her computer, but not
required to be disclosed and consented to pursuant to Section 4.2, then the collection and use of
such other information must be disclosed in your privacy policy. Google Confidential

(i) the type of information collected (described with specificity in the case of personally
identifiable information),

(ii) the method of collection (e.g. by registration, etc.), and

(iii) the location of (i.e., a link to) the privacy policy that governs the collection, use and
disclosure of the information; and

(b) then, obtain the end user's affirmative consent to such collection and/or transmission.

(a) first, fully, accurately, clearly and conspicuously disclose the change in a manner that will
explain the practical effect of such change; and

(b) then, obtain the end user's affirmative consent to make such change.

- 27 -
<!-- page 28 -->
5. Transparency. Neither you nor any of your third party distribution or bundling partners may
mislead end users or create end user confusion with regard to the source or owner of an Application
or any portion of its purpose, functionality or features. For example, all elements of your
Application that are visible to the end user must clearly identify their source through its branding
and attribution, and that identification, whatever form it takes, must correspond to the
identification of your application in the menu that permits end users to remove programs. You must
clearly label advertisements provided by your Application (if any) as such and clearly identify your
Application as the source of those advertisements. In addition, if your Application modifies the
operation or display of other applications or Web sites (other than Web sites that you own), then in
each instance you must clearly and conspicuously attribute the source of that modification to your
Application (as distinct from the application or Web site modified) in a manner that will inform a
typical Internet user; provided that this requirement will not apply to modifications for which you
obtain disclosure and consent pursuant to Section 4.3. See Attachment 1 for examples of
modifications that are clearly and conspicuously disclosed to end users. 6. Deactivation. You may
not bundle any Google Application with any Application that impairs an end user's ability to change
any preferences or settings set by the Application in accordance with the way that such preferences
or settings ordinarily may be changed by the applicable Application. Once disabled by an end user,
your Application may not be re-enabled without an affirmative action by the end user to explicitly
re- enable your application. Accordingly, no use, update, installation or re-enablement of a
separate Application, and no code downloaded as a result of browsing a Web site, may operate to
re-enable your Application. Your Application must permit end users to uninstall it (in the customary
place the applicable operating system has designated for adding or removing programs, e.g.,
Add/Remove Programs control panel in Windows) in a straightforward manner, without undue effort or
skill. In addition, your Application, when running, must provide (in an easily found location) clear
and concise instructions on how it may be uninstalled. Once uninstalled, your Application must not
leave behind any functionality or design elements, and all setting changes made by the application,
but not explicitly agreed to by the end user, should be reversed to the extent practicable. 7.
Bundling of Applications. In addition to the requirements set forth in the agreement between you and
Google that incorporates these Guidelines, in order for you to bundle any Application with a Google
Application must satisfy each of the following requirements:

Google Confidential

(a) the end user is made aware of all of the Applications included in the bundle prior to any
installation;

(b) all such Applications included in the bundle or download comply with the provisions of Section 2
through 6 of these Guidelines;

(c) if Applications in a bundle in which you are participating are supported in part by revenue
generated by advertising displayed in another independent Application included in that bundle and
the continued use of the Application is conditioned on such other independent Application remaining
installed and active on the end user's computer, the end user must be made aware of that
relationship; and

- 28 -
<!-- page 29 -->
8. Information and Assistance. Subject to any confidentiality obligations owed to third parties, you
must provide Google with such information as Google may reasonably request about the distribution of
those of your Applications that are bundled with any Google Application. For example, we may ask you
to share with us: (a) the means by and/or the locations from which your Applications are
distributed; or (b) the identity of any applications included in any of your bundling relationships
(and the entities responsible for such applications). In addition, you must provide such assistance
as Google may reasonably request to investigate and stop potential violations of these Guidelines
that may be connected to your Application, including by way of using such number of identifiers and
other tracking parameters as Google may reasonably request. This would include providing Google with
"golden masters" of any bundle or other distribution that includes your Application, or working with
Google to stop any entities that may be financially benefiting from your Application from engaging
in any of these proscribed practices. You understand, however, that Google has no obligation to
provide support to end users of your Application. For the avoidance of doubt, these information and
assistance rights do not extend to any of your Applications that are not used to access Google
services, bundled with a Google Application, or bundled with an Application that accesses Google
services. 9. Legal. You must maintain ownership and control of your Application at all times to the
extent required to practically and legally enforce the requirements of these guidelines. If you are
seeking to permit a third party Application to be bundled with a Google Application, then you must
also obtain Google's written approval of that third party Application (in addition to the approval
required for your Application). If Google approves the third party Application, you are responsible
for ensuring that such third party Application also complies with these Guidelines. Special
indemnity and other suspension and/or termination provisions may apply. These are addressed in your
agreement with Google. 10. Updates. 10.1 General. As mentioned above, Google may update these
Guidelines, including the Attachments, from time to time; provided, however, that no updates will be
effective until Google provides you with thirty (30) days' written notice thereof. Once you receive
that notice (the date on which you receive such notice, the "Update Notice Date"), you will be
required to bring your Application into compliance within thirty (30) days Google Confidential

(d) either (1) the bundle must provide for a master uninstaller that will enable the end user to
uninstall every Application in the bundle without undue effort or skill, or (2) if no master
uninstaller is provided, the de-installation of any Application may not be dependent or conditioned
upon the de-installation of any other Application included in the bundle.

- 29 -
<!-- page 30 -->
10.2 Extended Compliance Period. If, solely as a result of an updated requirement, one or more of
your Applications no longer complies with these Guidelines, as updated, and you are incapable of
bringing such Application into compliance prior to the scheduled effective date of such update (the
"Update Effective Date"), you agree to provide Google with written notice thereof as soon as
reasonably practicable, but in any event no later than the Update Effective Date, identifying the
Application and the reasons why it may not be brought into compliance prior to the Update Effective
Date, and providing such other detail as Google may reasonably request with respect thereto
(consistent in any event with your confidentiality obligations). Thereafter, the parties will
consult, and you agree to will work, diligently and in good faith to develop and execute a plan to
bring such Application into compliance with these Guidelines, as updated, as soon as reasonably
practicable, but in any event within ninety (90) days of the Update Notice Date (the "Maximum
Compliance Period"). You agree that you will provide Google with such information as Google
reasonably requests during this period to keep Google apprised of your progress in bringing your
Application into compliance. Notwithstanding the foregoing (but subject to the next sentence), in no
event may a new requirement provided for in any update to these Guidelines require you to take any
action which would violate the terms of any agreement between you and any unaffiliated third party
that is in effect on the date that Google delivers notice of the proposed update. In any event, if
you are unable to bring any Application into compliance during the Maximum Compliance Period, Google
may elect, by providing at least thirty (30) days prior written notice, to require you to cease
bundling either the specific non-conforming Application or those versions of the Application which
are, or are distributed, in violation of the Guidelines, as updated; it being understood that, at
such time, you will be entitled to procure services from an alternative source for those
Applications (or versions thereof) with respect to which Google has exercised such election. Google
Confidential

- 30 -
<!-- page 31 -->
Attachment 1 Prohibited Behavior and Content The application may not impact the display of other
applications unless you provide clear disclosure in each instance

Google Confidential

- 31 -

Google Confidential

- 32 -
<!-- page 32 -->
<!-- page 33 -->
Disclosure and Consent Clear and conspicuous disclosure is required prior to download or install:
what it is, what it does, and how it will be displayed to the end user

Disclosure and Consent Describe type, method, and use of personal information, if applicable. Point
user to privacy policy

Google Confidential

- 33 -
<!-- page 34 -->
Google Confidential

- 34 -
<!-- page 35 -->
Branding & Attribution The visible elements of the application should be easily identifiable to the
end user

Google Confidential

- 35 -
<!-- page 36 -->
Implementation, Transparency and Deactivation The Application must permit end users to uninstall it
in the customary place the applicable operating system has designated for adding or removing
programs (e.g., Add/Remove Programs control panel in Windows) in a straightforward manner Google
Confidential

- 36 -

Google Confidential

- 37 -
<!-- page 37 -->
<!-- page 38 -->
Implementation, Transparency and Deactivation The Application must contain (in an easily found
location) clear and concise instructions on how it may be uninstalled

Google Confidential

- 38 -
<!-- page 39 -->
Bundling of Applications When bundling, the end user must be made aware of all the applications
included prior to installation.

Google Confidential

- 39 -
<!-- page 40 -->
Bundling of Applications When bundling, the end user must be made aware of advertising revenue
relationships to other applications, if the continued use of the primary application is conditioned
on the other applications being installed and active on the end user's computer

Google Confidential

- 40 -
