<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 1999-05-31 |
| Parties | FAMOUS FIXINS, INC. ("Company"); PEY DIRT, INC. ("Pey Dirt") |
| Source | CUAD v1 / WARNINGMANAGEMENTSERVICESINC_12_10_1999-EX-10-ENDORSEMENT AGREEMENT |

EXHIBIT 10.14

ENDORSEMENT AGREEMENT

THIS ENDORSEMENT AGREEMENT (this "Agreement"), made and entered into as of May 31, 1999, by and
between FAMOUS FIXINS, INC., 250 West 57th Street, Suite 2501, New York, New York 10107 ("Company")
and PEY DIRT, INC. ("Pey Dirt").

WITNESSETH

WHEREAS, Company desires to obtain the right to use the name, likeness and endorsement of Peyton
Manning (hereinafter called "Manning") in connection with the advertisement, promotion and sale of
Company's "Products" (hereinafter defined); and

WHEREAS, Manning has granted such rights to Pey Dirt together with the right to sublicense such
rights.

NOW, THEREFORE, for and in consideration of the premises and of the mutual promises and conditions
herein contained, the parties do hereby agree as follows:

1. Definitions. As used herein, the following terms shall be defined as set forth below:

(a) "Contract Period" shall mean that period of time commencing as of May 31, 1999 and concluding
May 31, 2000.

(b) "Contract Territory" shall mean the states of Indianapolis and Tennessee and Company's
e-commerce site.

(c) "Contract Year Quarter" shall mean each 3 consecutive month period occurring during any Contract
Year ("Contract Year" meaning any twelve month period herein commencing as of June 1) (so that, by
way of example, the first Contract Year Quarter of the first Contract Year commences as of June 1,
1999, the second commences on September 1, 1999, etc.).

(d) "Endorsed Products" shall mean all Products of Company which have the Manning Identification
(defined below) highlighted as a part thereof (in the Products' name or otherwise) or which are
shipped in containers or packages bearing the Manning Identification.

(e) "Manning Identification" shall mean any words or symbols or photographic or graphic
representations or combinations thereof which identify Manning such as, for example, the name and
likeness of Manning.

(f) "Premium Program" shall mean any traffic builder, third party tie-in program or other program
involving the use of a premium and shall include any program primarily designed to attract the
consumer to purchase a product or service other than Endorsed Products themselves.

(g) "Products" shall mean cold breakfast cereals.

2. Grant of Endorsement Rights. (a) Pey Dirt grants to Company the exclusive right and license to
use Manning Identification within the Contract Territory during the Contract Period in connection
with the advertisement and promotion by Company of Products in television, radio, print and point of
purchase. Pey Dirt also grants to Company, subject to all of the terms and conditions herein, the
non-exclusive right to use the Manning Identification in connection with certain merchandise that
may be featured on the back panel of the Endorsed Products packaging, said merchandise to be subject
to Pey Dirt's sole and exclusive discretion and approval. Notwithstanding anything herein to the
contrary, it is specifically agreed that the Manning Identification cannot be used, in whole or in
part, in connection with (i) Premium Programs and/or (ii) any multi-media use except for Company's
e- commerce site. Pey Dirt expressly agrees that the right to use Manning Identification will not be
granted to anyone other than Company for use within the Contract Territory during the Contract
Period in connection with the advertisement, promotion and sale of Products. Anything herein to the
contrary notwithstanding, Company shall not have the right to distribute photographs of Manning
which are larger than 5" x 7".

(b) Company agrees that during the Contract Period it will use its best efforts actively and
aggressively to (i) promote the sale of all Endorsed Products in the Contract Territory, and (ii)
prevent the sale of any Endorsed Products outside the Contract Territory. Failure of Company to
comply with the provisions of this Section 2(b) shall entitle Pey Dirt to revoke this license
immediately (notwithstanding any other provision in this Agreement to the contrary).

(c) Pey Dirt has the right to terminate this Agreement immediately if Company's Endorsed Products
are not being distributed in the Contract Territory to a significant number of stores by October 1,
1999.

3. Approvals. Company agrees that no use whatsoever of Manning Identification nor any item used in
connection with Manning Identification (including, without limitation, advertising) will be made
hereunder unless
<!-- page 2 -->
and until the same has been approved by Pey Dirt. Pey Dirt agrees that any material, advertising or
otherwise, submitted for approval as provided herein may be deemed by Company to have been approved
hereunder if the same is not disapproved in writing within fourteen (14) days after receipt thereof.
Pey Dirt agrees that any material submitted hereunder will not be unreasonably disapproved and, if
it is disapproved, that Company will be advised of the specific grounds therefor. Company agrees to
protect, indemnify and save harmless Pey Dirt and Manning, or either of them, from and against any
and

-2-

all expenses, damages, claims, suits, actions, judgments and costs whatsoever, arising out of, or in
any way connected with, any advertising material furnished by, or on behalf of, Company.

4. Remuneration. (a) Within thirty (30) days following the conclusion of each Contract Year Quarter,
Company shall deliver to Pey Dirt an itemized statement setting forth the total shipments of
Endorsed Products during said Contract Year Quarter and, at the same time, shall pay to Pey Dirt a
royalty with respect to such shipments as hereinafter provided. Such royalties shall be based upon
the actual invoice price of such shipments, exclusive only of shipping charges and sales taxes, and
shall be at the rate of 8.5% of the total of said invoice prices with a minimum invoice price of
$2.50 per box.

(b) In addition to the royalty payments set forth above, Company agrees to grant Pey Dirt an option
to purchase an aggregate of 50,000 shares of Company's publicly traded and registered stock (the
"Shares") at an exercise price of $0.15 per share (the "Option"), which Option shall vest and become
unrestricted when the SEC declares Company's registration statement effective (anticipated to be no
later than November 30, 1999) and shall be exercisable until June 30, 2004. As further inducement to
Pey Dirt to enter into this Agreement, Company and Pey Dirt will enter into that certain Option
Agreement dated as of the date of this Agreement, which shall govern all aspects of the Option.

(c) Further, Pey Dirt will be entitled to fifty percent (50%) of all gross profits (i.e., gross
revenues less only Company's actual out-of-pocket costs of obtaining the raw merchandise) generated
from merchandise related to the Endorsed Products and/or the Manning Identification, said
merchandise to be advertised exclusively on the back panel of each box of Endorsed Products. Except
for the advertising of merchandise related to the Endorsed Products and/or the Manning
Identification, no other use of the back panel of each box of Endorsed Products is permitted without
Pey Dirt's prior written consent. It is agreed that all such merchandise must be mutually approved
in all respects by the parties hereto, including, without limitation, the style, design and cost
thereof.

(d) In addition to and separate from any other remuneration hereunder, if Company uses any
performance or service of Manning hereunder in any way that is subject to the jurisdiction of any
applicable artists' union, guild or other organization (including, without limitation, SAG and
AFTRA), either during or after the Contract Period, Company shall pay directly to such organization
all minimum payments or fees (for benefit plans or otherwise) required to be made with respect to
Manning's performance or services.

(e) If, at any time during the Contract Period, Company shall enter into any agreement (the terms of
what are significantly the same as the terms hereof) in connection with the production and sale of
Company's products using the name, likeness, photographic representation or signature of any other
National Football League quarterback (active or retired), which agreement provides for the payment
to such individual of remuneration in excess of that set forth herein, then Company agrees it will
immediately so notify Pey Dirt

-3-

and, at the same time, shall, retroactive to the effective date of such other agreement, increase
the rate of remuneration paid to Pey Dirt hereunder up to the highest then-current rate paid by
Company to any such National Football League quarterback (active or retired) for a regional
endorsement deal.

5. Notices and Submissions. Pey Dirt hereby designates International Merchandising Corporation, IMG
Center, Suite 100, 1360 East 9th Street, Cleveland, Ohio 44114, Attn.: Peter Johnson, as Pey Dirt's
authorized agent for all purposes hereunder. All notices, submissions and/or requests for approval
to be made, obtained or delivered by Company to Pey Dirt pursuant to this Agreement shall be
delivered to said address free of all charges such as, for example, shipping charges and customs
charges. In the event that any such charges are paid by Pey Dirt or by Pey Dirt's authorized agent,
Company agrees to make prompt reimbursement.

6. Payments; Books and Records. (a) Pey Dirt may elect to have
<!-- page 3 -->
payments made by check, wire transfer or bank transfer. Unless such election has been made in
writing, all payments shall be made by check drawn to the order of "Pey Dirt, Inc." and delivered to
IMG, Suite 100, 1360 East 9th Street, Cleveland, Ohio 44114, Attn.: Peter Johnson. Past due payments
hereunder shall bear interest at the rate of (i) one and one-half percent (1-1/2%) per month, or
(ii) the maximum interest rate permissible under law, whichever is less.

(b) Company agrees that it will keep accurate and complete records and books of account showing all
Endorsed Products shipped by it and the price thereof. Pey Dirt, or its representatives, shall, upon
two weeks' written notice, have the right at all reasonable times (prior to the expiration of two
(2) years after the termination of the Contract Period) to inspect and make copies of the books and
records of Company insofar as they shall relate to the computation of royalties to be paid to Pey
Dirt hereunder and the shipment of Endorsed Products pursuant to this Agreement. In the event that
any such inspections show an underreporting and underpayment in excess of five percent (5%) for any
twelve (12) month period, then Company shall pay the cost of such examination.

7. Labels/Packaging. (a) It is understood that each of the Endorsed Products shipped by Company or
its container or the packaging therefor shall have affixed thereto a label or other permanent
identification which includes Manning Identification.

(b) It is hereby agreed that the back panel of the Endorsed Products' packaging will feature ad copy
or offers as determined by Pey Dirt and its agent, subject to Company's right to reasonably reject
such materials only if such materials are clearly offensive to a majority of the populace. Any and
all revenues generated by such ad copy or offers shall be disbursed in accordance with Section 4(c)
above. Further, the side panel of the Endorsed Products packaging shall feature a charity or other
entity of Manning's sole choice. All packaging costs shall be Company's sole responsibility.

-4-

8. Trademarks. Should Company, at any time or times during the Contract Period, desire to register a
trademark or trademarks which include Manning Identification, or which relate in any manner to
Manning, and/or to register Company as a user thereof, Pey Dirt shall execute any and all documents
which the parties reasonably believe to be necessary or desirable for registration or protection of
such trademark or trademarks in the name of Manning. All costs related to any such trademarks shall
be borne by Company, and ownership of any such trademarks shall rest solely in the name of Pey Dirt
or its designee. Upon registration of any such trademark, Pey Dirt shall grant to Company a license
for the use of such registered trademark on or in connection with the advertisement, promotion and
sale of Endorsed Products, which license shall be coextensive and coterminous with the rights
granted thereunder with respect to Manning Identification and shall require no increase in the
payments set forth but shall contain such additional provisions as Pey Dirt reasonably believes are
necessary for the protection of such trademark registered in the name of Manning or Pey Dirt.
Company agrees that it will not file, during the Contract Period or thereafter, any application for
trademark registration or otherwise obtain or attempt to obtain ownership of any trademark or trade
name within the Contract Territory or in any other country of the world which consists of Manning
Identification or any mark, design or logo intended to make reference to Manning or to identify
products endorsed by Manning. In the event that, prior to the Contract Period, Company has filed one
or more applications for registration of any such trademark, or otherwise has obtained any rights to
such trademark, Company agrees to cause such applications and/or trademarks to be assigned and
transferred to Pey Dirt forthwith.

9. Products for the Use of Pey Dirt. During the Contract Period, Company shall supply Pey Dirt
and/or its agent with such amounts of Endorsed Products as Pey Dirt and/or its agent may reasonably
request. Company agrees to pay all charges in connection with the delivery of Endorsed Products to
Pey Dirt and/or Pey Dirt's agent, including shipping charges, air freight charges and customs
charges. Company agrees to reimburse Pey Dirt's authorized agent for all such expenses incurred by
it in connection with the transfer of Endorsed Products to Pey Dirt and/or Pey Dirt's agent.

10. Services of Manning. If Company desires to utilize the services of Manning as a model in
connection with photographs or drawings for advertising or for personal appearances, Pey Dirt
agrees, at the reasonable request of Company and upon adequate notice, to provide the services of
Manning at a time and place reasonably convenient to the schedule of Manning. Company agrees that it
will reimburse Pey Dirt for reasonable travel (including first class air fare), lodging, ground
transportation and meal expenses incurred by Manning and one traveling companion designated by
Manning. Company further agrees it will reimburse Pey Dirt's authorized agent for reasonable travel
(including air fare), lodging and meal expenses incurred in providing one representative to
accompany Manning. Company understands that if services are requested hereunder, such services may
be coordinated with similar services for others entitled to the use of Manning Identification in
other connections. Company further understands that such services may be required not more than once
during the Contract Period for up to one (1) hour. In the event that Company elects to use the
services of Manning in connection with television

-5-
<!-- page 4 -->
advertising, Company shall make all required union scale and union pension and welfare payments.
Company further understands that failure to utilize services of Manning pursuant to this section
shall not result in any reduction in payments to Pey Dirt hereunder, nor may the obligation to
provide services be carried past the Contract Period. The obligations of Pey Dirt to provide the
services of Manning hereunder are subject to the condition that payments to Pey Dirt are current and
up to date.

11. Force Majeure. If, at any time during this Agreement, Pey Dirt or Manning is prevented from or
hampered or interrupted or interfered with in any manner whatever in fully performing its/his duties
hereunder, by reason of any present or future statute, law, ordinance, regulation, order, judgment
or decree, whether legislative, executive or judicial (whether or not valid), act of God,
earthquake, fire, flood, epidemic, accident, explosion, casualty, lockout, boycott, strike, labor
controversy (including but not limited to threat of lockout, boycott or strike), riot, civil
disturbance, war or armed conflict (whether or not there has been an official declaration of war or
official statement as to the existence of a state of war), invasion, occupation, intervention of
military forces, act of public enemy, embargo, delay of a common carrier, inability without default
on Company's part to obtain sufficient material, labor, transportation, power or other essential
commodity required in the conduct of its business; or by reason of any cause beyond his reasonable
control; or by reason of any other cause of any similar nature (all of the foregoing being herein
referred to as an "event of force majeure"), then Pey Dirt's/Manning's obligations hereunder shall
be suspended as often as any such event of force majeure occurs and during such periods of time as
such events of force majeure exist and such non-performance shall not be deemed to be a breach of
this Agreement.

12. Default. (a) If either party at any time during the Contract Period shall (i) fail to make any
payment of any sum of money herein specified to be made, or (ii) fail to observe or perform any of
the covenants, agreements or obligations hereunder (other than the payment of money), the
non-defaulting party may terminate this Agreement as follows: as to subparagraph (i) if such payment
is not made within ten (10) days after the defaulting party shall have received written notice of
such failure to make payment, or as to subparagraph (ii) if such default is not cured within thirty
(30) days after the defaulting party shall have received written notice specifying in reasonable
detail the nature of such default. In order to be a sufficient notice hereunder, any such written
notice shall specify in detail each item of default and shall specify the provision of this
Agreement which applies to each item of default, and shall specify in detail the action the
defaulting party must take in order to cure each such item of default. The termination rights set
forth in this section shall not constitute the exclusive remedy of the nondefaulting party
hereunder, however, and if default is made by either party hereunder, the other may resort to such
other remedies as said party would have been entitled to if this section had been omitted from this
Agreement. Termination under the provisions of this section shall be without prejudice to any rights
or claims which the terminating party may otherwise have against the defaulting party.

-6-

(b) Notwithstanding anything herein to the contrary, the cure periods set forth in subparagraphs
(a)(i) and (a)(ii) above only apply to Company's first default under this Agreement. Accordingly,
Pey Dirt may, after Company's first default has occurred under either subparagraph (a)(i) or
subparagraph (a)(ii) above and has been cured, thereafter immediately terminate this Agreement upon
any further defaults by Company hereunder without providing Company an opportunity to cure any
additional defaults.

13. Termination. From and after the termination of the Contract Period all of the rights of Company
to the use of Manning Identification shall cease absolutely and Company shall not thereafter use or
refer to Manning Identification in advertising or promotion in any manner whatsoever, it being
understood by Company that Manning Identification may be used at any time by others in connection
with the advertisement and promotion of Products the shipment of which is completed after the
termination of the Contract Period. It is further agreed that following termination of the Contract
Period, Company shall not advertise, promote, distribute or sell any item whatsoever in connection
with the use of any name, figure, design, logo, trademark or trade name similar to or suggestive of
Manning Identification.

14. Inventory of Endorsed Products on Termination/Expiration. Any Endorsed Products that may have
been manufactured by or for Company prior to the termination or expiration of the Contract Period
may be sold by Company during the ninety (90) day period next following the date of termination or
expiration; provided, however, that Company shall have no such rights unless (a) Company is not in
default of any of its obligations hereunder on the date of termination or expiration, (b) within
fifteen (15) days after the date of termination or expiration, Company shall furnish to Pey Dirt a
written statement of the number and description of Endorsed Products actually in stock on the date
of termination or expiration, (c) the quantity of Endorsed Products in stock on the date of
termination or expiration is not in excess of a reasonable inventory based upon Company's selling
requirements of Endorsed Products during the Contract Period, (d) Company shall continue to pay to
Pey Dirt with respect to such sales a royalty at the rates specified herein, and (e) royalties
payable pursuant to this section shall be paid within thirty (30) days following the end of each
calendar month with respect
<!-- page 5 -->
to shipments made during such month.

15. Collegiate/National Football League Trademarks. Nothing contained herein shall be construed to
convey to Company any rights to use the trademarks, logos or uniform of the University of Tennessee,
the Indianapolis Colts, the National Football League or any other professional or amateur football
association (including any member clubs or teams of such association) in conjunction with the rights
granted hereunder. All rights to the use of such trademarks, logos or team identification must be
acquired from the University of Tennessee, the Indianapolis Colts, the National Football League, or
any other appropriate rights holder.

16. Indemnity. Company agrees to protect, indemnify and save harmless Pey Dirt, Pey Dirt's agent and
Manning, or any of them, from and against any and all expenses, damages, claims, suits, actions,
judgments and costs whatsoever, including reasonable attorneys' fees,

-7-

arising out of, or in any way connected with, this Agreement, Company's default hereunder, the
negligence, actions, errors or omissions of Company or any claim or action for personal injury,
death or otherwise involving alleged defects in Company's Products, provided that Company shall be
given notice of any such action or claim. Company agrees to provide and maintain, at its own
expense, general liability insurance and product liability insurance with limits no less than
$3,000,000 and within thirty (30) days from the date hereof, Company will submit to Pey Dirt a fully
paid policy or certificate of insurance naming Pey Dirt, Pey Dirt's agent and Manning as additional
insured parties, requiring that the insurer shall not terminate or materially modify such without
written notice to Pey Dirt at least twenty (20) days in advance thereof.

17. Waiver. The failure of either party at any time or times to demand strict performance by the
other of any of the terms, covenants or conditions set forth herein shall not be construed as a
continuing waiver or relinquishment thereof and each may at any time demand strict and complete
performance by the other of said terms, covenants and conditions.

18. Bankruptcy. If Company shall become bankrupt or insolvent, or if Company's business shall be
placed in the hands of a Receiver, Assignee or Trustee, whether by voluntary act of Company r
otherwise, the Contract Period shall, at the option of Pey Dirt, immediately terminate.

19. Assignment. This Agreement shall bind and inure to the benefit of Pey Dirt and the successors
and assigns of Pey Dirt. Nothing herein shall prevent Pey Dirt from assigning the monetary benefits
of this Agreement as it may so desire. Further, inasmuch as it is recognized that Pey Dirt is the
representative of Manning, Pey Dirt may at any time assign this Agreement to Manning and, in such
event, Pey Dirt shall have no further obligation or liability in connection herewith and Pey Dirt's
position vis-a-vis Company in connection herewith shall be in all respects the same as if Pey Dirt
had signed this Agreement as agent rather than as principal from the beginning. The rights granted
Company hereunder shall be used only by it and shall not, without the prior written consent of Pey
Dirt, be transferred or assigned to any other. In the event of the merger or consolidation of
Company with any other entity, Pey Dirt shall have the right to terminate the Contract Period by so
notifying Company in writing on or before sixty (60) days after Pey Dirt has received notice of such
merger or consolidation.

20. Arbitration. In the event a dispute arises under this agreement which cannot be resolved, such
dispute shall be submitted to arbitration and resolved by a single arbitrator (who shall be a
lawyer) in accordance with the Commercial Arbitration Rules of the American Arbitration Association
then in effect. All such arbitration shall take place at the office of the American Arbitration
Association located in Nashville, Tennessee. Each party is entitled to depose one (1) fact witness
and any expert witness designated by the other party, and to conduct such other discovery as the
arbitrator deems appropriate. The award or decision rendered by the arbitrator shall be final,
binding and conclusive and judgment may be entered upon such award by any court.

-8-

21. Significance of Headings. Section headings contained herein are solely for the purpose of aiding
in speedy location of subject matter and are not in any sense to be given weight in the construction
of this Agreement. Accordingly, in case of any question with respect to the construction of this
Agreement, it is to be construed as though such section headings had been omitted.

22. Entire Agreement. This writing constitutes the entire agreement between the parties hereto and
may not be changed or modified except by a writing signed by the party or parties to be charged
thereby.

23. Governing Law. This Agreement shall be governed and construed according to the law of Tennessee.

24. Reservation of Rights. All rights not herein specifically
<!-- page 6 -->
granted to Company shall remain the property of Pey Dirt to be used in any manner Pey Dirt deems
appropriate. Company understands that Pey Dirt has reserved to itself the right to authorize others
to use Pey Dirt Identification within the Contract Territory and during the Contract Period in
connection with all tangible and intangible items and services other than Products themselves.

25. No Joint Venture. This Agreement does not constitute and shall not be construed as constituting
a partnership or joint venture between Turn 2 and Company. Neither party shall have any right to
obligate or bind the other party in any manner whatsoever, and nothing herein contained shall give,
or is intended to give, any rights of any kind to any third person.

26. Authorization. The execution, delivery and performance of this Agreement by Company and by Pey
Dirt has been duly authorized and approved by the Board of Directors of Company and by the Board of
Directors of Pey Dirt and constitutes a valid and binding obligation of Company and of Pey Dirt
enforceable in accordance with its terms.

27. Execution and Delivery . This instrument shall not be considered to be an agreement or contract
nor shall it create any obligation whatsoever on the part of Pey Dirt and Company, or either of
them, unless and until it has been personally signed by a representative of Pey Dirt and by a
representative of Company and delivery has been made of a fully signed original. Acceptance of the
offer made herein is expressly limited to the terms of the offer.

28. Liability. In no event (including, but not limited to, Manning's or Pey Dirt's default
hereunder) shall Manning or Pey Dirt be liable to Company (or any entity claiming through Company)
for any amount in excess of the amounts of royalties actually received by Pey Dirt hereunder,
excluding the reimbursement of expenses. Under no circumstances will Manning or Pey Dirt, on the one
hand, or Company, on the other hand, be liable to the other or any other entity for any special,
consequential, indirect, exemplary and/or punitive damages, or for loss of good will or business
profits.

-9-

IN WITNESS WHEREOF, the par-ties hereto have caused this Agreement to be executed as of the date
first above written.

FAMOUS FIXINS, INC. PEY DIRT, INC.

By: /s/ Jason Bauer By: /s/ Peyton Manning --------------------- ------------------------ Jason
Bauer Peyton Manning President President

-10-
