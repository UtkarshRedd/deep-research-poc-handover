<!-- page 1 -->
# WALABOT-HOME RESELLER AGREEMENT
| Field | Value |
|---|---|
| Document Type | Reseller Agreement |
| Agreement Date | 2019-07-31 |
| Parties | Vayyar Imaging Ltd. ("Supplier"); IndeLiving Holdings, Inc. ("Reseller")("Party" and collectively as "Parties") |
| Source | CUAD v1 / HealthcareIntegratedTechnologiesInc_20190812_8-K_EX-10.1_11776966_EX-10.1_Reseller Agreement |

WALABOT-HOME RESELLER AGREEMENT This Walabot-HOME Reseller Agreement ("Agreement") is made and
entered into as of this 31 day of July 2019 ("Effective Date") by and between Vayyar Imaging Ltd.,
having its principal place of business at 3 Avraham Giron St., POB. 325, Yehud 5621717, Israel
("Supplier"), and Inde Living Holdings, Inc., having its principal place of business at 1462 Rudder
Lane, Knoxville, TN 37919 ("Reseller"). Vayyar and Reseller shall be referred to individually as
"Party" and collectively as "Parties". 1. Definitions. The following capitalized terms shall have
the following meanings: "Customer" means a third party who purchases the Products from Reseller
within the Territory, for its internal use only (including for the personal use of its End Users),
such as nursing homes. "End User" means a third party who is a customer of Customer or is otherwise
related to a customer of Customer, and who purchases and/or uses the Products within the Territory,
for its personal use only. "End User Agreement" means Supp l i e r ' s s t andard l i cense ag
reement s , wh ich a re ava i l ab le a t https://walabot.com/walabot-home, which governs each End
User's right to use the Product, as amended by Supplier in its sole discretion from time to time.
"MOQ" means the minimum order quantity of Product units during the Initial Term, as set forth in
Schedule 1. ***. "Order" means a written purchase order for Products to be purchased by the
Reseller. "Products" means the products listed in Schedule 1. "Software" means Supplier's
proprietary software components, included as part of the Products, including all improvements,
corrections, updates, upgrades and any related documentation and derivatives thereof. "Territory"
means the countries and/or territories listed in Schedule 1. Appointment During the Term (defined
below) and subject to the terms and conditions of this Agreement (including, but not limited to
Section 12.4 hereof), Supplier hereby (i) appoints Reseller, and Reseller accepts the appointment,
as a non‐ exclusive reseller of the Products in the Territory. In connection with the foregoing
appointment, Supplier hereby grants Reseller a non-transferable, revocable, limited right to resell,
market, promote, stimulate interest in, and solicit Orders by Customers and/or End Users in the
Territory for the Products and to provide services in connection with those activities. Reseller
shall be solely responsible for all of its costs and expenses related to the resale of the Products.
Notwithstanding anything to the contrary, Supplier reserves any and all rights with respect to the
Products not expressly granted in this Agreement. Without limiting the right of the Reseller to
receive any and all Paid-For Products (including but not limited to under Section 4.2 hereof),
nothing in this Agreement shall entitle the Reseller to any priority of supply in relation to the
Products as against any other distributor or customer of the Supplier. "Paid‐ For Products" means
Products for which Reseller submitted an Order, had that Order accepted by Supplier, and for which
Reseller has remitted payment in full to the Supplier under this Agreement. Subject to the terms of
Section 13, below, it is hereby clarified that Supplier may, in its sole discretion, sell the
Products to any other person or entity, whether within the Territory or otherwise. ***. ***. ***.
Obligations of Reseller By fulfilling its obligations under this Agreement, the Reseller shall: (i)
comply with all applicable laws and regulations; (ii) use materials and branding solely as
determined by the Supplier (subject to the right of the Reseller to make changes to such materials
as are described in Section 2.4); (iii) attend training and sales meetings as required by the
Supplier, so as to be able to describe, demonstrate, and sell the Products adequately; (iv) make
sure that all the End Users are signing the End User Agreement, and in the event that any End User
does not comply with these terms, Reseller shall bear all liability associated with said End User;
and (v) make no representations or warranties with respect to the Products other than those provided
in the Products' documentation; Supplier shall be fully responsible for shipping the Products to the
Reseller at the address of the Reseller specified in each Order (or as otherwise communicated by
Reseller to Supplier under this Agreement) and will obtain and provide for itself and/or on behalf
of Reseller, any and all registrations, licenses, permits, certificates and all other documentation
and information required for the exportation, importation, storage, marketing and otherwise resale
of the Products in the Territory. For such process, Supplier will allocate the additional cost on a
pre-agreed per Product unit additional price basis, which will be subject to an increase (subject to
changes in taxes). Reseller agrees to reimburse Supplier for the reasonable out of pocket costs and
expenses incurred by Supplier in connection with the shipment and delivery of the Products, and of
obtaining the foregoing registrations, licenses, permits, certificated and other documentation,
provided that Supplier submits an invoice therefore in reasonable detail (and unless and solely to
the extent such reimbursements is prohibited by Section 14.9 or prohibited under other applicable
laws). For the avoidance of doubt, in no way will Supplier be subject to any tax (i.e., sales tax)
relating to the sale of the Products to Reseller's Customers and/or End Users.

1. 1.1.

1.2.

1.3.

1.4. 1.5. 1.6. 1.7. 1.8.

1.9. 2. 2.1.

2.2. 2.3. 2.4. 3. 3.1.

3.2.

Source: HEALTHCARE INTEGRATED TECHNOLOGIES INC., 8-K, 8/12/2019
<!-- page 2 -->
Diagnostics, Telemetric Data and Analytics. Supplier will retain access to diagnostics, telemetric
data and analytics generated by the Product. The data shall be uploaded to Supplier's Firebase
server in a timely manner. A server interface will be embedded within the software package provided
by the Supplier. Distributor will maintain Supplier's interface to the server and access to such
data within the Product; provided that the data and analytics to be received by the Supplier shall,
in all cases, not be in violation of any applicable privacy or other law. Orders, Payment and
Delivery ***. If Reseller fails to submit Orders with an aggregate value equal to or greater than
the MOQ, then Reseller shall pay Supplier a sum equal to the shortfall, within 30 days after the end
of the Initial Term. Upon payment of such amount, Seller shall deliver the Products paid for to
Reseller in a commercially reasonable timeframe (and in no event any later than 150 days from the
date such payment is received in full) to be sold by Reseller in accordance with this Agreement as
contemplated by the last sentence of Section 12.4. Reseller shall place its Orders by email, at the
email address set out in Schedule 1. Each Order shall detail the total order quantity of the Product
and the requested date of delivery (taking into consideration up to 4 months lead time). Within 5
business days following the receipt of each Order, Supplier shall acknowledge receipt of such Order.
No Order shall be binding upon Supplier until such written acknowledgment was sent by Supplier to
Reseller; provided that Supplier shall confirm or reject such Orders at its discretion. ***.
Packaging, Samples and Transportation Immediately upon delivery of the Products at the Reseller's
facilities within the Territory ("Arrival Date"), Reseller shall visually inspect the Products and
the appropriate documents, and employ good receiving/delivering procedures, verification of the
Products to confirm origin, identity, quantity, labeled storage conditions, integrity of the
packaging as well as any other inspection, as may be required by applicable laws or regulations.
Reseller shall ensure that the Products are delivered with appropriate information and
documentation, and shall not make any changes to the Products or to the packaging or labeling
thereof, or to the legal documents included in the Products' packages, without Supplier's prior
written consent (subject to the right of the Reseller to make changes to such materials as are
described in Section 2.4). Reseller shall ensure traceability of the delivered Products. Defective
Products; Warranty; Support ***. During the Term Supplier may extend an offer to Reseller for a
Returns Discount Program, whereby the Supplier will rebate a percentage of the cost of goods sold in
lieu of accepting End-User returns. In the event no Returns Discount Program has been entered into
by the Parties, Supplier will not accept Returned Product, except for cases of Defective Products.
***. ***. Intellectual Property Supplier shall retain all its rights and title to and ownership of
all intellectual property rights in the Products including, inter alia, all documentation,
enhancements, improvements or other modifications made thereof (including those modifications made
in connection with Section 3.1 above), and except as expressly provided in this Agreement, Reseller
shall have no right, title, or interest in any intellectual property rights in the Products. Nothing
in this Section shall limit the rights of the Reseller in or to any modifications made to the
Software in accordance with Section 2.3. Reseller shall: (a) not do or omit to do, nor authorize any
third party to do or omit to do, any act or omission that would or might invalidate or be
inconsistent with any of Supplier's intellectual property rights; (b) promptly notify Supplier of
any actual, threatened, or suspected infringement of any of Supplier's intellectual property rights
that comes to Reseller's notice; and (c) at Supplier's request and expense, do all such things as
may be reasonably required to assist Supplier in taking or resisting any proceedings in relation to
any such infringement or claim. Confidential Information. Each Party agrees that it will maintain
the confidentiality of all electronic, oral, and written communications from the other Party which
should reasonably be regarded in the normal commercial view, as constituting confidential
information, trade secrets or proprietary information ("Confidential Information") and use such
Confidential Information only as necessary to exercise a Party's rights or perform a Party's
obligations under this Agreement. Each Party shall: (i) safeguard and keep secret all Confidential
Information, and will not directly or indirectly disclose to any third party the Confidential
Information without written permission of the other; and (ii) in performing its obligations
hereunder, use at least the same degree of care as it does with respect to its own confidential
information of like importance but, in any event, at least reasonable care. Any information related
to the Products shall be considered the Supplier's Confidential Information. If either Party becomes
legally obliged to make disclosure of the other Party's Confidential Information, that Party shall
immediately notify the first Party and reasonably cooperate with the first Party in any efforts to
limit or object to the disclosure.

3.3.

4. 4.1. 4.2.

4.3.

4.4. 5. 5.1.

5.2.

6. 6.1. 6.2.

6.3. 6.4. 7. 7.1.

7.2.

8.

Source: HEALTHCARE INTEGRATED TECHNOLOGIES INC., 8-K, 8/12/2019
<!-- page 3 -->
Disclaimer of Warranties. UNLESS SPECIFIED OTHERWISE HEREIN (INCLUDING BUT NOT LIMITED TO THE BACK
TO BACK WARRANTY SPECIFIED IN SECTION 6.5) AND WITHOUT LIMITATION TO ANY WARRANTY WHICH SUPPLIER
MAY, IN ITS SOLE DISCRETION, MAKE TO ANY CUSTOMER AND/OR END USER, THE PRODUCTS ARE PROVIDED ON AN
"AS IS" AND "AS AVAILABLE" BASIS, AND SUPPLIER DOES NOT MAKE ANY WARRANTIES, EXPRESS OR IMPLIED,
WITH RESPECT TO THE PRODUCTS OR ITS OPERATION THEREOF, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE. Limitation of Liability TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT
SHALL SUPPLIER BE LIABLE UNDER, OR OTHERWISE IN CONNECTION WITH, THIS AGREEMENT FOR: (A) ANY
CONSEQUENTIAL, INDIRECT, SPECIAL, INCIDENTAL, OR PUNITIVE DAMAGES; (B) ANY LOSS OF PROFITS, LOSS OF
BUSINESS, LOSS OF REVENUE, OR LOSS OF ANTICIPATED SAVINGS; (C) ANY LOSS OF, OR DAMAGE TO, DATA,
REPUTATION, OR GOODWILL; AND/OR (D) THE COST OF PROCURING ANY SUBSTITUTE GOODS OR SERVICES. THE
AGGREGATE LIABILITY OF SUPPLIER UNDER, OR IN CONNECTION WITH, THIS AGREEMENT SHALL BE EQUAL TO THE
LESSER OF: (i) ***; AND (ii) ***. THE FOREGOING EXCLUSIONS AND LIMITATIONS SHALL APPLY: (A) EVEN IF
SUPPLIER HAS BEEN ADVISED, OR SHOULD HAVE BEEN AWARE, OF THE POSSIBILITY OF LOSSES OR DAMAGES; (B)
EVEN IF ANY REMEDY IN THIS AGREEMENT FAILS OF ITS ESSENTIAL PURPOSE; AND (C) REGARDLESS OF THE
THEORY OR BASIS OF LIABILITY (INCLUDING, WITHOUT LIMITATION, BREACH OF CONTRACT, TORT, NEGLIGENCE OR
STRICT LIABILITY). Indemnification. Reseller shall defend, indemnify and hold harmless Supplier and
its employees, officers, directors, suppliers, and successors from and against any third-party
claim, suit, proceeding, damages, losses and/or liability arising from or related to (i) Reseller's
breach of any provision of this Agreement; and/or (ii) Reseller's interaction and/or relationship
with any Customer and/or End User or other third party. Term and Termination This Agreement shall
become effective on the Effective Date and shall remain in effect for an initial period of 1 year
("Initial Term"). Thereafter, this Agreement shall automatically be renewed for successive 1-year
terms (each a "Renewal Term", and together with the Initial Term, the "Term"). Following the Initial
Term, either Party may terminate this Agreement without cause upon written notice to the other Party
of at least 3 months. Without derogating from any other remedies that any Party may have under the
terms of this Agreement or at law, each Party shall have the right to terminate this Agreement
forthwith upon the occurrence of any of the following: (i) the other Party is in material breach of
its obligations hereunder and fails to remedy such breach within 30 days after being requested in
writing to do so; or (ii) the other Party's bankruptcy, insolvency, liquidation, whether voluntarily
or otherwise, or if it makes an assignment for the benefit of creditors. Upon any termination of
this Agreement: (i) all rights granted by Supplier to Reseller under the Agreement revert to
Supplier; (ii) Reseller shall transfer to Supplier all data, reports and any other information
generated by Reseller in the course of performance of this Agreement; and (iii) any payment
obligation which had accrued or become payable prior to the date of termination (including the
payment obligation under Section 4.2) shall survive termination of this Agreement. Upon termination
of this Agreement, the provisions in Sections 1, 6.5, 7, 8, 9, 10, 11, 12.3, 12.4, 13 (but solely to
the extent stated in the last sentence of that section), and 14 shall remain in effect as necessary
to carry out the purpose of those Sections after termination. In addition to the foregoing, if, at
the time of termination of this Agreement, Reseller shall have additional Product units in its
inventory and is able to sell them to Customers and/or End Users (including, without limitation, any
Product units for which Reseller has or is obligated to pay the Supplier the purchase price therefor
but which have not yet been delivered to the Reseller by Supplier, which Supplier hereby agrees to
either deliver as otherwise contemplated by this Agreement as if it had not terminated or to refund
the purchase price therefor), then the licenses and appointments described in Section 2 shall remain
in effect with respect to such unsold Product units (and such Section 2 shall not terminate) until
the earlier of (i) the date on which the last Product in Reseller's inventory is sold to a Customer
and/or End User, or (ii) 1 year from the date of the termination of this Agreement. ***. General
Supplier and/or Reseller may assign or novate this Agreement and the rights and obligations under it
to any of its affiliates or upon any merger or acquisition or the sale of all or substantially all
of its assets relating to the Agreement. Any purported assignment of rights in violation of this
subsection is void. The relationship between the Parties is that of supplier and purchaser. Reseller
is an independent contractor and is not the legal representative, agent, joint venture, partner, or
employee of Supplier. Reseller may describe itself as Supplier's 'authorized distributor', but may
not hold itself out as the Supplier's agent. Reseller has no authority to assume or create any
obligations of any kind or to make any representations or warranties, whether express or implied, on
behalf of the Supplier, nor to bind the Supplier in any respect.

9.

10. 10.1.

10.2.

11.

12. 12.1.

12.2.

12.3.

12.4.

13. 14. 14.1.

14.2.

Source: HEALTHCARE INTEGRATED TECHNOLOGIES INC., 8-K, 8/12/2019
<!-- page 4 -->
Except as to the timely payment by Reseller for the Products purchased under this Agreement, no
failure or omission to carry out or observe any provision of this Agreement shall give rise to any
claim by one Party against the other, or be a breach of this Agreement, if the same is caused by or
arises out of circumstances beyond the reasonable control of the other Party, including technical
difficulties beyond such Party's reasonable control that delay or prevent manufacture ("Force
Majeure"). However, the Parties shall endeavor to avoid, remove, or cure all such conditions as soon
as is reasonably feasible. If either Party is prevented or hindered from carrying out its
obligations under this Agreement due to a Force Majeure, this Agreement shall be suspended as long
as the Force Majeure persists. If such period exceeds 1 month, either Party may terminate this
Agreement on giving written notice to the other. No failure or delay on the part of either Party to
exercise any right or remedy under this Agreement shall be construed or operate as a waiver thereof,
nor shall any single or partial exercise of any right or remedy preclude the further exercise of
such right or remedy. If any provision or part of any provision of this Agreement is found to be
invalid or unenforceable for any reason, the other provisions of this Agreement shall remain in full
force and effect as if the Agreement had been executed without that provision or part. All notices
or other communications hereunder shall be in writing and shall be given in person, by courier or by
registered mail (provided that written confirmation of receipt is provided) addressed as set forth
in the heading of this Agreement or such other address as any Party may designate to the other in
accordance with this procedure. All communications delivered in person or by courier service shall
be deemed to have been received upon delivery, shall be deemed to have been received on the business
day following transmission with confirmed answer back, and all notices and other communications sent
by registered mail shall be deemed to have been received within 3 business days after posting. This
Agreement shall be governed by the laws of the State of New York and all disputes and controversies
arising out of or in connection with the Agreement shall be brought exclusively before the competent
courts in New York County, New York; provided however that judgment shall be enforceable in any
country and that nothing in this Section shall prevent or restrict either Party from seeking interim
relief in any competent jurisdiction as it may deem fit. This Agreement constitutes the entire
agreement between the Supplier and the Reseller. All previous or contemporaneous agreements,
proposals, understandings, and communications between the Supplier and the Reseller are replaced in
their entirety by this Agreement. In entering into this Agreement, neither Party has relied on any
warranties, representations, or other matters other than as set out in this Agreement. All
conditions, warranties, or other terms implied by statute or common law are excluded to the fullest
extent permitted by law. This Agreement may be amended only by a written instrument executed by
authorized representatives of the Parties. Each of Reseller and Supplier will, respectively, ensure
that it and its employees, agents or affiliates, or by any independent contractors on its behalf or
for its benefit, shall comply with the United States' Foreign Corrupt Practices Act of 1977, as
amended (15 U.S.C. §§ 78dd-1 et seq.) and any analogous anti-bribery and anti-corruption law, rule,
regulation that may apply to any of the transactions contemplated under this Agreement, including
but not limited to in connection with the sale, resale, import, export, transportation, or shipment
of the Products. Neither party to this Agreement will make any payment, directly or indirectly, of
money or other assets, including but not limited to compensation derived from this Agreement or any
Order placed under it, to government or political party officials, officials of international
organizations, candidates for public office, or representatives of other businesses or persons
acting on behalf of any of the foregoing, that would constitute a violation of any law, rule, or
regulation. IN WITNESS WHEREOF, the Parties have executed this Agreement as of the Effective Date.

Vayyar Imaging Ltd. IndeLiving Holdings, Inc.

By: /s/ Raviv Melamed By: /s/ Robert Forrest Chief Executive Officer Chief Executive Officer

14.3.

14.4.

14.5.

14.6.

14.7.

14.8.

14.9.

Source: HEALTHCARE INTEGRATED TECHNOLOGIES INC., 8-K, 8/12/2019
<!-- page 5 -->
Schedule 1 Territory, Products, Price, Ordering Address, Notices

Territory USA

Products Walabot HOME hardware device

Price $*** per Product unit + $*** for shipment and tax (subject to any tax changes) MOQ *** units

Address to which Orders should be sent Supplier's Ordering Email address: logistics@walabot.com

Address for Notices to the Supplier Vayyar Ltd. 3 Avraham Giron St., POB. 325, Yehud 5621717, Israel
Address for Notices to Reseller Inde Living Holdings, Inc 1462 Rudder Lane Knoxville, TN 37919
Vayyar Wire Transfer Details ***

Payment Terms ***

Source: HEALTHCARE INTEGRATED TECHNOLOGIES INC., 8-K, 8/12/2019
