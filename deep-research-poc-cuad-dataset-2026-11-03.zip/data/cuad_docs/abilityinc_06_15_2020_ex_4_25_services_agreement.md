<!-- page 1 -->
# Services Agreement
| Field | Value |
|---|---|
| Document Type | Service Agreement |
| Agreement Date | 2019-10-01 |
| Parties | [ * * * ] ("Provider"); TELCOSTAR PTE, LTD.; Ability Computer & Software Industries Ltd; TELCOSTAR PTE, LTD. and Ability Computer & Software Industries Ltd (each and both of them "Recipient"); Each of the foregoing parties is referred to herein as a “Party” and together as the “Parties”. |
| Source | CUAD v1 / ABILITYINC_06_15_2020-EX-4.25-SERVICES AGREEMENT |

EXHIBIT 4.25 INFORMATION IN THIS EXHIBIT IDENTIFIED BY [ * * * ] IS CONFIDENTIAL AND HAS BEEN
EXCLUDED BECAUSE IT IS BOTH (I) NOT MATERIAL AND (II) WOULD LIKELY CAUSE COMPETITIVE HARM TO THE
REGISTRANT IF PUBLICLY DISCLOSED. SERVICES AGREEMENT This Services Agreement (this "Agreement") is
entered into on October 1, 2019 and is made effective as of November 1, 2019 (the "Effective Date"),
by and between [ * * * ] (the "Provider"), and TELCOSTAR PTE, LTD., a company organized and existing
under the laws of Singapore and Ability Computer & Software Industries Ltd, a company organized and
existing under the laws of the State of Israel (each and both of them "Recipient"). Each of the
foregoing parties is referred to herein as a "Party" and together as the "Parties". RECITALS A.
Recipient wishes to engage the Provider to provide certain services and resources (the "Services")
and Provider desires to provide Recipient with the Services all in accordance with the terms and
conditions set forth herein. AGREEMENT The Parties hereby agree as follows: 1. Services. 1.1
Provision of Services. (a) Provider agrees to provide the Services set forth on the Exhibit A
attached hereto (as such Exhibit may be amended or supplemented pursuant to the terms of this
Agreement, the "Exhibit") to Recipient for the respective periods and on the other terms and
conditions set forth in this Agreement and in the Exhibit. Notwithstanding the contents of the
Exhibit, Provider agrees to respond in good faith to any reasonable request by Recipient for access
to any additional services and resources that are necessary for the operation of the Recipient and
which are not currently contemplated in the Exhibit, at a price to be agreed upon after good faith
negotiations between the Parties. Any such additional services and resources so provided by Provider
shall constitute Services under this Agreement and be subject in all respect to the provisions of
this Agreement as if fully set forth on the Exhibit as of the date hereof. (b) Recipient may freely
assign its rights under this Agreement to receive the Services to any of its affiliates. 1.2
Standard of Service. (a) Provider represents, warrants and agrees that the Services shall be
provided in good faith, in accordance with applicable law and in a manner generally consistent with
the historical provision of the Services and with the same standard of care as historically
provided. (b) Provider shall maintain complete and accurate records relating to the provision of the
Services under this Agreement, in such form as Recipient shall approve.
<!-- page 2 -->
(c) Provider shall use its best efforts to provide for employees or contractors to perform the
Services, each of whose names, positions, and respective levels of experience and relevant licenses
shall be set out in Exhibit A attached hereto (collectively, the "Provider Representatives").
Provider may not make any change in the Provider Representatives without the prior consent of the
Recipient. Provider Representatives shall be dedicated to solely providing the Services to Recipient
and shall not provide any such services or resources to Provider or any other customer of Provider.
(d) Recipient acknowledges that this Agreement does not create a fiduciary relationship,
partnership, joint venture or relationships of trust or agency between the Parties and that all
Services are provided by Provider as an independent contractor. (e) Notwithstanding anything to the
contrary in this Section 1.2: (a) in the event that Provider uses any subcontractors to perform any
Services, Provider is not released from responsibility for its obligations under this Agreement; (b)
Provider shall remain fully responsible, financially and otherwise, for the Services provided by
each subcontractor to the same extent as if Provider had performed the Services itself (subject to
the limitations set forth in this Agreement) and agrees to pay the fees and expenses of any such
subcontractor; (c) Provider shall remain ultimately responsible for ensuring that the Services are
provided and any such subcontractor performs any such obligations in accordance with the terms of
this Agreement, and (d) the obligations with respect to the nature, quality and standards of care
set forth in Section 1.2 are satisfied with respect to any Service provided by any subcontractor.
(f) Provider shall at all times during the term of this Agreement maintain, or cause to be
maintained, the computer software and computer hardware that is used in connection with the Services
with substantially the same degree of care, skill and diligence with which Provider maintains, or
causes to be maintained, as of the Effective Date, such computer software and computer hardware for
itself, consistent with past practices, as of the Effective Date, including without limitation, with
respect to type, quality and timeliness of such maintenance. 1.3 Additional Services. Nothing in
this Agreement shall be construed to prevent the Recipient from itself performing or from acquiring
services from other providers that are similar to or identical to the Services. 1.4 Intellectual
Property. (a) Recipient shall own, and Provider hereby irrevocably assigns to the Recipient, all
rights, title, and interest in any invention, technique, process, device, discovery, improvement, or
know-how, whether patentable or not and all other proprietary rights, industrial rights and any
other similar rights, in each case on a worldwide basis, and all copies and tangible embodiments
thereof, or any part thereof, in whatever form or medium hereafter made or conceived solely or
jointly by Provider while working for or on behalf of the Recipient, which relate to, is suggested
by, or results from the Services. (b) At Recipient's request, Provider shall disclose any such
invention, technique, process, device, discovery, improvement, or know-how promptly to Recipient.
Provider shall, upon request of Recipient, promptly execute a specific assignment of title to
Recipient, and do anything else reasonably necessary to enable Recipient to secure for itself,
patent, trade secret, or any other proprietary rights.

2
<!-- page 3 -->
(c) All writings or works of authorship, including, without limitation, program codes or
documentation, produced or authored by Provider in the course of performing services for the
Recipient, together with any associated copyrights, are works made for hire and the exclusive
property of the Recipient. To the extent that any writings or works of authorship may not, by
operation of law, be works made for hire, this Agreement shall constitute an irrevocable assignment
by Provider to the Recipient of the ownership of and all rights of copyright in, such items, and the
Recipient shall have the right to obtain and hold in its own name, rights of copyright, copyright
registrations, and similar protections which may be available in the works. Provider shall give the
Recipient or its designees all assistance reasonably required to perfect such rights. 2.
Compensation. 2.1 Responsibility for Wages and Fees. For such time as any employees of Provider are
providing the Services to Recipient under this Agreement, (a) such employees will remain employees
of Provider and shall not be deemed to be employees of Recipient for any purpose, and (b) Provider
shall be solely responsible for the payment and provision of all wages, bonuses and commissions,
employee benefits, including severance and worker's compensation, and the withholding and payment of
applicable taxes relating to such employment. 2.2 Terms of Payment and Related Matters. (a) As
consideration for provision of the Services following the Effective Date, Recipient shall pay
Provider an amount equal to Provider's actual cost of providing the Services plus a 10% service fee.
In addition to such amount, in the event that Provider incurs reasonable and documented
out-of-pocket expenses in the provision of any Service, including, without limitation, license fees
and payments to third-party service providers or subcontractors (such included expenses,
collectively, "Out-of-Pocket Costs"), Recipient shall reimburse Provider for all such Out-of-Pocket
Costs. (b) (i) Provider shall provide Recipient with monthly invoices ("Invoices"), which shall set
forth in reasonable detail, with such supporting documentation as Recipient may reasonably request
with respect to Out-of-Pocket Costs, amounts payable under this Agreement, and (ii) payments
pursuant to this Agreement shall be made within fifteen (15) days after the date of receipt of an
Invoice by Recipient from Provider. (c) Provider shall allow the Recipient to use [ * * * ] at no
cost, until December 31, 2021. 2.3 Invoice Disputes. In the event of an Invoice dispute, Recipient
shall deliver a written statement to Provider prior to the date payment is due on the disputed
Invoice listing all disputed items and providing a reasonably detailed description of each disputed
item. Amounts not so disputed shall be deemed accepted and shall be paid, notwithstanding disputes
on other items. The Parties shall seek to resolve all such disputes expeditiously and in good faith.
Provider shall continue performing the Services in accordance with this Agreement pending resolution
of any dispute.

3
<!-- page 4 -->
2.4 No Right of Setoff. Each of the Parties hereby acknowledges that it shall have no right under
this Agreement to offset any amounts owed (or to become due and owing) to the other Party, whether
under this Agreement, the Purchase Agreement or otherwise, against any other amount owed (or to
become due and owing) to it by the other Party. 3. Termination. 3.1 Termination of Agreement. This
Agreement be deemed effective as of the Effective Date, Agreement and shall terminate on December
31, 2020, unless terminated earlier in accordance with Section 3.2. 3.2 Each of the Recipient and
the Provider may, in their sole discretion, terminate this Agreement in whole or in part, at any
time without cause, and without liability except, in the case of the Recipient, for required payment
for services rendered and reimbursement for authorized expenses incurred, by providing at least 90
(ninety) days' prior written notice to the other party (such date, the "Services Termination Date").
3.3 Breach. Any Party (the "Non-Breaching Party") may terminate this Agreement with respect to any
Service, in whole but not in part, at any time upon prior written notice to the other Party (the
"Breaching Party"), if the Breaching Party has failed (other than pursuant to Section 3.6) to
perform any of its material obligations under this Agreement relating to such Service, and such
failure shall have continued without cure for a period of 30 days after receipt by the Breaching
Party of a written notice of such failure from the Non-Breaching Party seeking to terminate such
service. For the avoidance of doubt, non-payment by Recipient for a Service provided by Provider in
accordance with this Agreement and not the subject of a good-faith dispute shall be deemed a breach
for purposes of this Section 3.3. 3.4 Insolvency. In the event that either Party hereto shall (a)
file a petition in bankruptcy, (b) become or be declared insolvent, or become the subject of any
proceedings (not dismissed within sixty (60) days) related to its liquidation, insolvency or the
appointment of a receiver, (c) make an assignment on behalf of all or substantially all of its
creditors, or (d) take any corporate action for its winding up or dissolution, then the other party
shall have the right to terminate this Agreement by providing written notice in accordance with
Section 6.6. 3.5 Effect of Termination. Upon termination of this Agreement in its entirety pursuant
to Section 3.1, all obligations of the Parties hereto shall terminate, except for the provisions of
Section 2.2, and the entirety of Sections 4, 5 and 6, which shall survive any termination or
expiration of this Agreement. 3.6 Upon expiration or termination of this Agreement for any reason,
Provider shall promptly: (a) Deliver to Recipient all documents, work product, and other materials,
whether or not complete, prepared by or on behalf of Provider in the course of performing the
Services for which Recipient has paid. (b) Return to Recipient all Recipient -owned property,
equipment, or materials in its possession or control.

4
<!-- page 5 -->
(c) Remove any Provider-owned property, equipment, or materials located at Recipient's locations.
(d) Deliver to Recipient, all documents and tangible materials (and any copies) containing,
reflecting, incorporating, or based on Recipient's Confidential Information. (e) On a pro rata
basis, repay all fees and expenses paid in advance for any Services which have not been provided.
(f) Permanently erase all of Recipient's Confidential Information from its computer systems. (g)
Certify in writing to Recipient that it has complied with the requirements of this Section 3.6 3.7
Force Majeure. If Provider is prevented from or delayed in complying, either totally or in part,
with any of the terms or provisions of this Agreement by reason of fire, flood, storm, strike,
lockout or other labor trouble or shortage, delays by unaffiliated suppliers or carriers, shortages
of fuel, power, raw materials or components, any law, order, proclamation, regulation, ordinance,
demand, seizure or requirement of any governmental authority, riot, civil commotion, war, rebellion,
acts of terrorism, nuclear accident or other causes beyond the reasonable control of Provider, or
acts, omissions, or delays in acting by any governmental or military authority or Recipient (each, a
"Force Majeure"), then upon written notice to Recipient, the Services affected by the Force Majeure
(the "Affected Services") and/or other requirements of this Agreement will be suspended during the
period of such Force Majeure and Provider will have no liability to Recipient or any other party in
connection with such Affected Services. If the Force Majeure in question prevails for a continuous
period in excess of three months after the date on which the Force Majeure begins, Provider shall be
entitled to give notice to Recipient to terminate the Affected Services. The notice to terminate
must specify the termination date, which must be not less than ten (10) days after the date on which
the notice to terminate is given. Once a notice to terminate has been validly given, the Affected
Services will terminate on the termination date set out in the notice. Neither Party shall have any
liability to the other in respect of termination of the Affected Services due to Force Majeure, but
rights and liabilities which have accrued prior to termination shall subsist.

5
<!-- page 6 -->
4. Confidentiality. 4.1 Confidentiality. During the term of this Agreement and thereafter, the
Parties hereto shall, and shall instruct their respective representatives to, maintain in confidence
and not disclose the other Party's financial, technical, sales, marketing, development, personnel,
and other information, records, or data, including, without limitation, customer lists, supplier
lists, trade secrets, designs, product formulations, product specifications or any other proprietary
or confidential information, however recorded or preserved, whether written or oral (any such
information, "Confidential Information"). Each Party hereto shall use the same degree of care, but
no less than reasonable care, to protect the other Party's Confidential Information as it uses to
protect its own Confidential Information of like nature. Unless otherwise authorized in any other
agreement between the Parties, any Party receiving any Confidential Information of the other Party
(the "Receiving Party") may use Confidential Information only for the purposes of fulfilling its
obligations under this Agreement (the "Permitted Purpose"). Any Receiving Party may disclose such
Confidential Information only to its representatives who have a need to know such information for
the Permitted Purpose and who have been advised of the terms of this Section 4.1 and the Receiving
Party shall be liable for any breach of these confidentiality provisions by such Persons; provided,
however, that any Receiving Party may disclose such Confidential Information to the extent such
Confidential Information is required to be disclosed by law, in which case the Receiving Party shall
promptly notify, to the extent possible, the disclosing party (the "Disclosing Party"), and take
reasonable steps to assist in contesting such disclosure requirement or in protecting the Disclosing
Party's rights prior to disclosure, and in which case the Receiving Party shall only disclose such
Confidential Information that it is advised by its counsel in writing that it is legally bound to
disclose. Notwithstanding the foregoing, "Confidential Information" shall not include any
information that the Receiving Party can demonstrate: (a) was publicly known at the time of
disclosure to it, or has become publicly known through no act of the Receiving Party or its
representatives in breach of this Section 4.1, (b) was rightfully received from a third party
without a duty of confidentiality, or (c) was developed by it independently without any reliance on
the Confidential Information. 4.2 Return of Confidential Information. Upon demand by the Disclosing
Party at any time, or upon expiration or termination of this Agreement with respect to any Service,
the Receiving Party agrees promptly to return or destroy, at the Disclosing Party's option, all
Confidential Information received in connection with this Agreement. If such Confidential
Information is destroyed, an authorized officer of the Receiving Party shall certify to such
destruction in writing. 5. Indemnification. 5.1 Indemnification. Provider shall indemnify, defend,
and hold harmless Recipient and its officers, directors, employees, agents, affiliates, successors,
and permitted assigns (collectively, "Indemnified Party") against any and all losses, damages,
liabilities, deficiencies, claims, actions, judgments, settlements, interest, awards, penalties,
fines, costs, or expenses of whatever kind, including attorneys' fees, fees and the costs of
enforcing any right to indemnification under this Agreement, and the cost of pursuing any insurance
providers, incurred by Indemnified Party or awarded against Indemnified Party (collectively,
"Losses"), relating to/arising out of or resulting from any claim of a third party or Recipient
arising out of or occurring in connection with Provider's negligence, willful misconduct, or breach
of this Agreement. Provider shall not enter into any settlement without Recipient's or Indemnified
Party's prior written consent. 6. Miscellaneous. 6.1 Entire Agreement. This Agreement, the Purchase
Agreement and the documents referred to herein and therein constitute the entire agreement among the
Parties and supersedes any prior understandings, agreements, or representations by or among the
Parties, written or oral, to the extent they relate in any way to the subject matter hereof.

6
<!-- page 7 -->
6.2 Succession and Assignment. This Agreement shall be binding upon and inure to the benefit of the
Parties named herein and their respective successors and permitted assigns. Provider may not assign,
delegate or otherwise transfer either this Agreement or any of its rights, interests, or obligations
hereunder without the prior written approval of Recipient. 6.3 Counterparts. This Agreement may be
executed in one or more counterparts, each of which shall be deemed an original but all of which
together will constitute one and the same instrument. Counterparts may be delivered via facsimile
and electronic mail (including portable document format (PDF) or any electronic signature complying
with the U.S. federal ESIGN Act of 2000, e.g., www.docusign.com). 6.4 Titles and Headings. Titles
and section headings contained in this Agreement are inserted for convenience only and shall not
affect in any way the meaning or interpretation of this Agreement. 7. Notices. All notices,
requests, consents, claims, demands, waivers and other communications hereunder shall be in writing
and shall be deemed to have been given (a) when delivered by hand (with written confirmation of
receipt); (b) when received by the addressee if sent by a nationally recognized overnight courier
(receipt requested); (c) on the date sent by facsimile or e-mail of a PDF document (with
confirmation of transmission) if sent during normal business hours of the recipient, and on the next
Business Day if sent after normal business hours of the recipient or (d) on the third day after the
date mailed, by certified or registered mail, return receipt requested, postage prepaid. Such
communications must be sent to the respective parties at the following addresses (or at such other
address for a party as shall be specified in a notice given in accordance with this Section 7: If to
Provider: [ * * * ] With a copy to: N/A If to Recipient: TELCOSTAR PTE. LTD 6 Eu Tong Sen Street Tel
Aviv, Israel, 6770007 #10-15 The Central Singapore 059817 Email: avi@ability.co.il Attention: Avi
Levin With a copy to: McDermott Will & Emery LLP 340 Madison Avenue New York, NY 10173-1922
Telephone: (212) 547-5541 Facsimile: (212) 547-5444 EMAIL: GEMMANUEL@MWE.COM Attention: Gary
Emmanuel

7
<!-- page 8 -->
Any Party may change the address to which notices, requests, demands, claims, and other
communications hereunder are to be delivered by giving the other Parties notice in the manner herein
set forth. 7.1 Further Assurances. The Parties agree (a) to furnish upon request to each other such
further information, (b) to execute and deliver to each other such other documents, and (c) to do
such other acts and things, all as the other party may reasonably request for the purpose of
carrying out the intent of this Agreement and the documents referred to in this Agreement. 7.2
Governing Law. This Agreement and any claim, controversy or dispute arising out of or related to
this Agreement, any of the transactions contemplated hereby and/or the interpretation and
enforcement of the rights and duties of the Parties, whether arising in contract, tort, equity or
otherwise, shall be governed by and construed in accordance with the domestic laws of the State of
Israel (including in respect of the statute of limitations or other limitations period applicable to
any such claim, controversy or dispute), without giving effect to any choice or conflict of law
provision or rule (whether of the State of Israel or any other jurisdiction) that would cause the
application of the laws of any jurisdiction other than the State of Israel. 7.3 Consent to
Jurisdiction. The Parties hereby irrevocably submit any disputes under this Agreement to the
exclusive jurisdiction of the courts located in Tel-Aviv, Israel, provided however, that Recipient
shall be entitled to seek an injunction or other appropriate remedy against Provider in the country
in which Provider has acted in breach of the terms hereof. 7.4 Specific Performance. The Parties
hereby agree that, in the event of breach of this Agreement, damages would be difficult, if not
impossible, to ascertain and that irreparable damage would occur in the event that any of the
provisions of this Agreement were not performed in accordance with their specific terms or were
otherwise breached. Accordingly, it is hereby agreed that the Parties shall be entitled to seek an
injunction or other equitable relief in any court of competent jurisdiction to enjoin any such
breach and enforce specifically the terms and provisions hereof, this being in addition to any other
remedy or right to which they are entitled at law or in equity, without any necessity of proving
damages or any requirement for the posting of a bond or other security. 7.5 Amendments and Waivers.
No amendment of any provision of this Agreement shall be valid unless the same shall be in writing
and signed by Recipient and the Provider. No waiver by any Party of any provision of this Agreement
or any default, misrepresentation, or breach of warranty or covenant hereunder, whether intentional
or not, shall be valid unless the same shall be in writing and signed by the Party making such
waiver nor shall such waiver be deemed to extend to any prior or subsequent default,
misrepresentation, or breach of warranty or covenant hereunder or affect in any way any rights
arising by virtue of any prior or subsequent such occurrence.

8
<!-- page 9 -->
7.6 Severability. Any term or provision of this Agreement that is held invalid or unenforceable by a
court of competent jurisdiction or other competent governmental authority in any situation in any
jurisdiction shall not affect the validity or enforceability of the remaining terms and provisions
hereof or the validity or enforceability of the offending term or provision in any other situation
or in any other jurisdiction. Upon such a determination, the Parties shall negotiate in good faith
to replace invalid or unenforceable provisions with valid provisions, the economic effect of which
comes as close as possible to that of the invalid or unenforceable provisions. 7.7 Construction. The
Parties have participated jointly in the negotiation and drafting of this Agreement. In the event an
ambiguity or question of intent or interpretation arises, this Agreement shall be construed as if
drafted jointly by the Parties and no presumption or burden of proof shall arise favoring or
disfavoring any Party by virtue of the authorship of any of the provisions of this Agreement. Any
reference to any law shall be deemed also to refer to all rules and regulations promulgated
thereunder, unless the context requires otherwise. The word "including" shall mean including without
limitation. 7.8 Incorporation of Exhibits and Disclosure Schedule. The Exhibit identified in this
Agreement is incorporated herein by reference and made a part hereof. 7.9 Amendment and Restatement.
This Agreement amends and restates in full the Production Contract. [SIGNATURE PAGE FOLLOWS]

9
<!-- page 10 -->
IN WITNESS WHEREOF, the Parties have executed this Services Agreement as of the date first written
above. PROVIDER: RECIPIENT: [ * * * ] [ * * * ] By: By: Name: Name: Title: Title:

10
<!-- page 11 -->
EXHIBIT A Services [ * * * ] 11
