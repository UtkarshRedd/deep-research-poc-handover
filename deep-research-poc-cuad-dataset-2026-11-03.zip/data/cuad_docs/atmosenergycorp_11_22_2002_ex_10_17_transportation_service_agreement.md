<!-- page 1 -->
# TRANSPORTATION SERVICE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Transportation Agreement |
| Agreement Date | 1992-05-20 |
| Parties | Arkansas Western Pipeline Company ("Transporter"); Associated Natural Gas Company ("Shipper") |
| Source | CUAD v1 / ATMOSENERGYCORP_11_22_2002-EX-10.17-TRANSPORTATION SERVICE AGREEMENT |

EXHIBIT 10.17

TRANSPORTATION SERVICE AGREEMENT UNDER RATE SCHEDULE FTS OR ITS

THIS AGREEMENT ("Agreement"), entered into on May 20, 1992, is between Arkansas Western Pipeline
Company ("Transporter"), an Arkansas corporation, and Associated Natural Gas Company, a division of
Arkansas Western Gas Company, ("Shipper");

WITNESSETH:

WHEREAS, Shipper has requested natural gas for that Transporter transport Shipper; and

WHEREAS, Transporter has agreed to provide such transportation for Shipper subject to the terms and
conditions set forth in this Agreement.

NOW, THEREFORE, in consideration of the promises and the mutual covenants herein contained, the
parties agree as follows:

ARTICLE I

DEFINITIONS

1.1 "Maximum Daily Delivery Obligation (MDDO)" means the maximum daily quantity of natural gas,
expressed in Dekatherms (Dth), that Transporter is obligated to deliver from time to time at the
Point(s) of Delivery specified in Exhibit B to the executed Agreement.

1.2 "Maximum Daily Quantity (MDQ) " means the maximum daily quantity of natural gas, expressed* in
Dth's, that Transporter is obligated under the executed Agreement to transport on behalf of'
Shipper, which shall be 23,000 Dth.

1.3 "Equivalent Quantity" means the quantity, expressed in Dth's, delivered to Shipper by
Transporter at the Point(s) of Delivery. Such quantity is equal to the quantity of gas received from
Shipper at the Point(s) of Receipt less Fuel Usage and Applicable Shrinkage.

1.4 "Fuel Usage and Applicable Shrinkage" means the quantity of natural gas retained by Transporter
for fuel usage, leakage, blow-down, minor line pack fluctuations, and lost and unaccounted for
natural gas.

ARTICLE II

NATURAL GAS TRANSPORTATION SERVICE

2.1 Beginning on the date on which deliveries of natural gas are commenced hereunder, and thereafter
for the remaining term of this Agreement, Shipper agrees to tender gas to Transporter at the
Point(s) of Receipt, and Transporter agrees to transport and redeliver and Shipper agrees to accept
delivery of the Equivalent Quantities of gas at the Point(s) of Delivery, all &bbsp; in accordance
with the terms of this Agreement.

2.2 Transportation service rendered hereunder shall be firm/interruptible service as described in
Section 2 of Transporter's X Rate Schedule FTS _____ Rate Schedule ITS.

ARTICLE III

POINT(S) OF RECEIPT

The Point(s) of Receipt at which Transporter shall receive gas for transportation under this
Agreement shall be specified in Exhibit A to this Agreement.

ARTICLE IV

POINT(S) OF DELIVERY

The Point(s) of Delivery at which Transporter shall redeliver to Shipper or for the account of
Shipper an Equivalent Quantity of gas for transportation under this Agreement shall be specified in
Exhibit B to this Agreement. Notwithstanding the MDDO at each Point of Delivery, Shipper shall not
nominate a total quantity of natural gas at all Points of Delivery that exceeds the MDQ set forth in
this Agreement.

ARTICLE V

TERM OF AGREEMENT

5.1 Subject to the General Terms and Conditions of Transporter's FERC Gas Tariff and Rate Schedule
FTS/ITS, this Agreement shall be effective as of the date of physical completion of and initial
deliveries on Transporter's pipeline and shall continue for a primary term of ten years. Thereafter,
this
<!-- page 2 -->
Agreement shall be effective month to month, until terminated by Transporter or Shipper upon the
following written notice to the other specifying a termination date: sixty (60) days for

interruptible transportation under Rate Schedule ITS and 180 days for firm transportation under Rate
Schedule FTS.

5.2 Any portions of this Agreement necessary to balance receipts and deliveries under this Agreement
as required by the FTS/ITS Rate Schedule, shall survive the other parts of this Agreement until such
time as such balancing has been accomplished.

ARTICLE VI

RATE SCHEDULE AND CHARGES

6.1 Shipper shall pay Transporter for the service hereunder an amount determined in accordance with
Transporter's FTS/ITS Rate Schedule, and the General Terms and Conditions of Transporter's FERC Gas
Tariff, all as may be revised from time to time. Such FTS/ITS Rate Schedule and General Terms and
Conditions are incorporated by reference and made a part hereof.

6.2 Transporter may seek authorization from the FERC and/or other appropriate body to change any
rate(s) and/or term(s) set forth herein or in the FTS or ITS Rate Schedule. Nothing herein shall be
construed to deny Shipper any rights it may have under the Natural Gas Act or the Natural Gas Policy
Act including the right to participate fully in rate proceedings by intervention or otherwise to
contest increased rates in whole or in part.

ARTICLE VII

REDUCTION IN CAPACITY

For firm transportation only, if Transporter's capacity is reduced for any reason and a reduction of
the quantity of gas being transported hereunder is required, Shipper's MDQ shall be reduced pro rata
with the MDQ's of the other firm Shippers during the period of such capacity reduction.

ARTICLE VIII

MISCELLANEOUS

8.1 Amendment. This Agreement shall only be amended, varied or modified by an instrument in writing
executed by Transporter and Shipper. Such amendment will be effective upon compliance with Article
VIII herein.

8.2 Applicable Law. This Agreement and the rights and duties of Transporter and Shipper hereunder
shall be governed by and interpreted in accordance with the laws of the State of Arkansas, without
recourse to the law governing conflict of laws.

8.3 Waiver. No waiver by either Transporter or Shipper of any default by the other in the
performance of any provision, condition or requirement herein shall be deemed a waiver of, or in any
manner a release from, performance of any other provision, condition or requirement herein, nor
deemed to be a waiver of, or in any manner a release from, future performance of the same provision,
condition or requirement; nor shall any delay or omission by Transporter or Shipper to exercise any
right hereunder impair the exercise of any such right or any like right accruing to it thereafter.

8.4 Headings. The headings of each of the various sections in this Agreement are included for
convenience of reference only and shall have no effect on, nor be deemed part of the text of, this
Agreement.

8.5 Further Assurances. Transporter and Shipper shall execute and deliver all instruments and
documents and shall do all acts necessary to effectuate this Agreement.

8.6 Entire Agreement. This Agreement constitutes the entire agreement between Transporter and
Shipper concerning the subject matter hereof and supersedes all prior understandings and written and
oral agreements relative to said matter.

8.7 Cancellation of Prior Agreement(s). This Agreement, upon its effective date, supersedes and
cancels any and all other agreements between Transporter and Shipper relating to the transportation
of gas by Transporter for Shipper.

ARTICLE IX

NOTICES
<!-- page 3 -->
All notices, requests, statements or other communications provided for under this Agreement shall be
in writing and shall be given by personal delivery or by United States mail, postage prepaid, and
addressed as follows:

If to Shipper:

Arkansas Western Gas Company 1001 Sain Street P. 0. Box 1288 Fayetteville, AR 72702-1288

If to Transporter:

Arkansas Western Pipeline Company 1083 Sain Street P. O. Box 1408 Fayetteville, AR 72702-1408 Attn:
Manager of Transportation Services

All written notices, requests, statements or other communications shall be sufficiently given if
mailed postage prepaid by registered, certified, or regular mail and shall be deemed to have been
duly delivered on the third business day following the date on which same was deposited in the
United States mail, addressed in accordance with this Article VIII. Either Shipper or Transporter
may designate a different address to which notices, requests, statements, payments or other
communications shall be sent upon proper notice as set forth in this Article VIII.

IN WITNESS WHEREOF, Transporter and Shipper have caused this Agreement to be duly executed by their
duly authorized officers in two (2) original counterparts as of May 20, 1992.

"TRANSPORTER"

ARKANSAS WESTERN PIPELINE COMPANY an Arkansas Corporation

By /s/ [ILLEGIBLE] --------------------------------------- President

WITNESS: /s/ [ILLEGIBLE] ------------------------

"SHIPPER"

ASSOCIATED NATURAL GAS COMPANY, a division of Arkansas Western Company Gas Company

By /s/ [ILLEGIBLE] ---------------------------------------

WITNESS: ------------------------

EXHIBIT A TO TRANSPORTATION SERVICE AGREEMENT DATED MAY 20, 1992 BETWEEN ASSOCIATED NATURAL GAS
COMPANY AND ARKANSAS WESTERN PIPELINE COMPANY

Pressure Psig Meter MDQ ------------- Receipt Point Number SEC-TWN-RNG County ST Dth/d Max Min
------------- ------- ----------- ------ -- ------ ----- ----- 1. NOARK Pipeline System Pending
31-19N-9E Clay AR 23,000 685 550

SHIPPER: TRANSPORTER: ASSOCIATED NATURAL GAS COMPANY ARKANSAS WESTERN PIPELINE COMPANY

By: /s/ [ILLEGIBLE] By: /s/ [ILLEGIBLE] -------------------------- -----------------------------
<!-- page 4 -->
EXHIBIT B TO TRANSPORTATION SERVICE AGREEMENT DATED MAY 20, 1992 BETWEEN ASSOCIATED NATURAL GAS
COMPANY AND ARKANSAS WESTERN PIPELINE COMPANY

Pressure Psig Meter MDDO ------------- Delivery Point Number SEC-TWN-RNG County ST Dth/d Max Min
-------------- ------- ----------- ------- -- ------ ----- ----- 1. Associated Natural Gas Pending
28-19N-10E Dunklin mo 23,000 500 400

SHIPPER: TRANSPORTER: ASSOCIATED NATURAL GAS COMPANY ARKANSAS WESTERN PIPELINE COMPANY

By: /s/ [ILLEGIBLE] By: /s/ [ILLEGIBLE] -------------------------- -----------------------------
President

SCHEDULE 2

CONTRACTS BIFURCATED OR PARTIALLY ASSIGNED TO ATMOS

Contract Quantity Assigned Expiration -------- ----------------- ---------- Transportation &
Storage: AWP FT dated 5/20/92 13,370 MMBtu/d 07/31/2003 Ozark FT #Z2001 @ AWP 13,370 MMBtu/d
10/31/2002 Ozark FT #Z2001 @ NGPL .2000 MMBtu/d 10/31/2002 TETCO CDS (FT) #800204 9,826 MMBtu/d
10/31/2012 TETCO SSI #400184 11,303 DTH/d W/D 04/30/2012 .3,876 DTH/d Inj. 04/30/2012 Supply: SEECO
Finn Sales dated 10/1/90 15,370 MMBtu/d 09/30/2000

FORM OF NOTICE OF PERMANENT RELEASE OF FIRM CAPACITY AND CONSENT TO PARTIAL ASSIGNMENT

A. Associated Natural Gas Company, a division of Arkansas Western Gas Company ("Releasing Shipper")
is a firm Shipper that is party to an executed and valid Service Agreement with Arkansas Western
Pipeline Company under Rate Schedule FTS ("Transporter"). Releasing Shipper proposes to release
capacity as set forth below, and in accordance with the applicable provisions of Transporter's FERC
Gas Tariff. Upon the satisfaction of all conditions applicable to the proposed release transaction,
including all applicable provisions of Section 14 of the General Terms and Conditions of
Transporter's FERC Gas Tariff, Releasing Shipper will consent to a partial and permanent assignment
of capacity on Transporter's system. Subject to the satisfaction of such conditions by the Releasing
Shipper and the Replacement Shipper, Transporter will consent to this partial and permanent
assignment of capacity on its system, and will waive the requirement under Section 14.7 of the
General Terms and Conditions of Transporter's FERC Gas Tariff, providing that Releasing Shipper
shall remain the guarantor of payment to Transporter of all demand charges arising under its Service
Agreement with Transporter for such assigned capacity.

B. Rate Schedule and contract number pursuant to which capacity is released, Contract Number: FTS -
0 1

C. Quantity of capacity to be released: Max 13,370 Dfli/Day, Min 13,370 DthDay.

D. (i) Minimum transportation rate acceptable to Releasing Shipper (if none, write "none"; includes
commodity component):

Tariff Rate

(ii) Bid Requirements:

(a) _X_ Reservation, __Volumetric

or ___ Volumetric with ___ volume commitment

(b) __ Dollar/Cents or __ Percentage

E. Receipt Points and Delivery Points (designate primary and/or secondary):

Receipt Point: "Ozark/AWP Interconnect" Meter 00010
<!-- page 5 -->
Delivery Point: "AWP/ANG Interconnect" Meter 00020 MDQ @ 13,370 MMBtu/d.

F. Bid Evaluation Methodology: i) highest rate, net revenue or present value

ii). If Releasing Shipper chooses to provide weighting factors in accordance with Section 14.9 of
the General Terms and Conditions of Transporter's FERC Gas Tariff, weighting factors are as follows:
Please provide a range for each factor between 0 - 1,000. The numbers need not add up to 1,000.

_________________ Volume (0 - 1,000)

Max Rate ___________________ -1 Rate (0 - 1,000)

G. i). Designated Replacement Shipper (if none, write "none"):

United Cities Gas Company a, division of Atmos Energy Corporation.

ii). Terms and conditions agreed to between Releasing Shipper and Designated Replacement Shipper:

_________ Demand Rate (MMBtu)

13,370 Volume MMBtu/Day

iii) Releasing Shipper and Designated Replacement Shipper understand Designated Replacement Shipper
may not receive the released capacity if it fails to match any best bid submitted by another
potential Shipper as provided in Transporter's FERC Gas Tariff.

H. Other terms and conditions (if none, write "none"): _________________

This is a maximum tariff rate, permanent assignment of capacity, not subject to bid.

"Date Releasing Shipper: Associated Natural Gas Co. Charles V. Stevens, Sr. Vice President

ANY, a division of Atmos Energy Corporation

UNITED CITIES GAS

BY: /s/ [ILLEGIBLE] ----------------------------------------- Replacement Shipper*

-May 24, 2000

Date

Date Transporter:

ARKANSAS WESTERN PIPELINE COMPANY

To be executed, prior to posting by Transporter, by Replacement Shipper only if Replacement Shipper
has been designated by Releasing Shipper in G(i) above.

BID ON PERMANENTLY RELEASED CAPACITY ON ARKANSAS WESTERN PIPELINE COMPANY

A. United Cities Gas Company a, division of Atmos Energy Corporation ("Bidder") hereby bids on
released capacity ("Capacity") on the system of Arkansas Western Pipeline Company ("Transporter").
This bid will remain open until Transporter selects a winning bidder, or notice of withdrawal is
received by Transporter.

B. The Capacity was released by Associated Natural Gas Company, a division of Arkansas Western Gas
Company.

(FTS - 01) under Transporter's Rate Schedule FTS,

C. The transportation rate bid is Maximum Tariff Rate per Dth, not including commodity charge, fuel,
or other applicable fees.

D. The quantity of Capacity bid for is 13,370 Dth/Day

E. The term of the Capacity bid for is (Permanent Assignment through original contract term)
Months/Years, beginning June 1, 2000 and ending at the expiration date of contract FTS - 01.

F. Receipt and Delivery points (designate primary and/or secondary)

Receipt Point: "Ozark/AWP Interconnect" Meter 000 10

Delivery Point: "AWP/ANG Interconnect" Meter 00020 MDQ @ 13,370 MMBtu/d.
<!-- page 6 -->
G. Other information requested by the Releasing Shipper

This is a maximum tariff rate, permanent assignment of capacity, not subject to bid.

H. Bidder agrees to comply with all terms and conditions of Transporter's FERC Gas Tariff.

I. If selected by Transporter as the winning bidder, Bidder will immediately execute the partial
assignment form set forth below.

i Bidder acknowledges that it has the full authority to make this bid and bind itself and its agents
and/or principals to this bid.

UNITED CITIES GAS COMPANY, a division of May 24, 2000

Atmos Energy Corporation ------------------------
-----------------------------------------------------

Date BIDDER

By: /s/ GORDON J. ROY

Gordon J. Roy Vice President

PARTIAL ASSIGNMENT OF CAPACITY ON ARKANSAS WESTERN PIPELINE COMPANY

A. United Cities Gas Company a, division of Atmos Energy Corporation ("Replacement Shipper") has
submitted the winning bid for firm capacity on the system of Arkansas Western Pipeline Company
("Transporter") for capacity released by Associated Natural Gas Company, a division of Arkansas
Western Gas Company ("Releasing Shipper"), and understands that its bid of (date) June 1, 2000 has
been accepted by Transporter.

B. Replacement Shipper has read and understands the terms and conditions under which the Releasing
Shipper has permanently released such capacity on Transporter and hereby contracts for such
capacity, in accordance with its bid, subject to terms and conditions set forth on Transporter's
FERC Gas Tariff and the Service Agreement between the Releasing Shipper and Transporter (copy of bid
and release notice attached). Replacement Shipper adopts such Service Agreement for the assigned
capacity, and from and after the effective date of the referenced release shall be fully liable to
Transporter for all demand charges, volumetric charges, surcharges, and other charges arising under
the terms of the Service Agreement with Transporter for such assigned capacity from and after that
effective date.

C. Releasing Shipper hereby makes a partial assignment of its rights and obligations under contract
number FTS - 01 in accordance with the attached bid and release notice. This assignment is made in
accordance with Transporter's FERC Gas Tariff.

Releasing Shipper: Associated Natural Gas Co. Charles V. Stevens, Sr. Vice President UNITED GAS a
division of Atmos Energy Corporation

BY: CITIES COMPANY

/s/ GORDON J. ROY ------------------------------------------------- Replacement Shipper Gordon J.
Roy, Vice President

Transporter:

Arkansas Western Pipeline Company
