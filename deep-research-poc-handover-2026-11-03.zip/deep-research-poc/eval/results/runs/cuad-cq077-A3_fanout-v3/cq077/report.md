# Among the following 8 agreements, which contain a non-compete clause? For each, quote t...

*Question:* Among the following 8 agreements, which contain a non-compete clause? For each, quote the clause. Agreements: the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley (dated 2017-11-14); the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. (dated 2011-03-14); the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc (filed 2018-11-09); the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC (dated 2013-05-15); the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies (filed 2005-11-02); the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01); the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. (dated 2010-01-01); the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. (filed 2013-09-26).

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Does the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley da...

The Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley dated 2017-11-14 contains an exclusivity clause restricting endorsements of competing products during the Term. [4cb98e07400203bf p.3] The clause states: "8. [uncited] Exclusivity. [uncited] Talent represents and warrants that during the Term and in the Territories, Talent will not endorse or make any appearances or advertisements on behalf of any other product which is directly competitive to ESSI's products." [4cb98e07400203bf p.3]

## Does the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema...

The Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp dated 2011-03-14 contains a non-compete clause in Section 11.3(a) restricting Network Affiliate from competing with NCM during the Term. [23e65a3b8bc5cc9e p.25] The clause states: "Section 11.3 Non-Competition and Non-Solicitation. [uncited] (a) During the Term, except as otherwise provided in this Agreement, Network Affiliate and its affiliates agree not to engage or participate in any business, hold equity interests, directly or indirectly, in another entity, whether currently existing or hereafter created, or participate in any other joint venture that competes or would compete with any business that NCM is authorized to conduct in the Territory pursuant to this Agreement, whether or not NCM is actually conducting such business in a particular portion of the Territory. [uncited] The foregoing restrictions shall not apply (i) in the event Network Affiliate or its affiliate acquires a competing business as an incidental part of an acquisition of any other business that is not prohibited by the foregoing, if Network Affiliate disposes of the portion of such business that is a competing business as soon as commercially reasonable, (ii) to any direct or indirect ownership or other equity investments by Network Affiliate or its affiliates in such other competing business that represents in the aggregate less than 10% of the voting power of all outstanding equity of such business, o…". [23e65a3b8bc5cc9e p.25]

## Does the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope He...

The document identified as the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc, filed 2018-11-09  contains a non-compete clause. [61c29bdb3ab6960e p.1] [61c29bdb3ab6960e p.2] Section 3 states: "3. [uncited] Restriction on Promotion of Competing Products. [uncited] During the term of this agreement, Distributor shall not market, sell advertise or promote the sale or use of any product or device which is competitive with or substantially similar to the Products, without the prior express written consent of Erchonia, nor shall they assist any third party in doing so. [uncited] Notwithstanding the foregoing, to the extent Distributor or Distributor's customer is a licensed health care professional or licensed health care practitioner, nothing in this paragraph shall prevent or limit Distributor or Distributor's customer from exercising their independent medical judgment with regard to the treatment of any patient." [61c29bdb3ab6960e p.2]

## Does the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC date...

The Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC dated 2013-05-15 does not contain a non-compete clause between the parties. [31cbf0d18f7d763e p.13] Section 7.2(e) titled "Non-Compete" addresses a third-party settlement agreement, not a non-compete between Integra and PcoMed. [31cbf0d18f7d763e p.13] The clause states: "(e) Non-Compete. [uncited] The Settlement Agreement and Mutual Release between *** and *** does not contain a covenant-non-compete applicable to *** and, to the best of PcoMed's current knowledge, *** is not subject to any covenant-non-compete that would prevent is employment with PcoMed."  Section 3.1 provides an exclusivity provision restricting PcoMed from selling or offering for sale products that utilize or embody the PcoMed Surface Modification Technology to any Third Party in the Field in the Territory, but expressly states that PcoMed shall not be subject to any other restriction under the Agreement with regard to that technology. [31cbf0d18f7d763e p.13] [31cbf0d18f7d763e p.7] Section 3.1 further states that the exclusive nature of the Rights shall not limit PcoMed from making, having made, using, selling or offering for sale products and/or services that do not utilize or embody the PcoMed Surface Modification Technology. [31cbf0d18f7d763e p.7]

## Does the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity...

The Cooperation Agreement between e.l.f. [uncited] Beauty, Inc. and Marathon Partners Equity Management, LLC dated 2020-07-01 contains a standstill covenant rather than a non-compete clause. [61c29bdb3ab6960e p.2] Section 5 Standstill Covenants restricts corporate governance actions, not competition. [61c29bdb3ab6960e p.2] The provision states: "5. [uncited] Standstill Covenants. [uncited] (a) Except as otherwise contemplated in Section 4 of this Agreement, at all times during the Support Period, the Marathon Parties shall not, and shall cause their Affiliates and Associates and their and such Affiliates' and Associates' respective equity owners (including members and limited partners), directors, officers, managers and employees not to, and will direct their consultants, agents, representatives, attorneys and advisors (to the extent directly or indirectly acting on behalf of the Marathon Parties) (collectively, the "Marathon Party Representatives") not to, directly or indirectly, in any manner, alone or in concert with others:". [61c29bdb3ab6960e p.2]

[GAP] The evidence does not contain a non-compete clause for this agreement.

## Does the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GA...

The Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. dated 2010-01-01 does not contain a non-compete clause restricting Racing from competing with Sponsor. [ab1fd1dd637746ab p.2] The agreement instead contains a restriction on endorsing competitors, which states: “(v) prohibiting the endorsement by Racing and any members of Racing, including the drivers, of any entities, products or services which are in direct competition or otherwise inconsistent with the Sponsor or it products or services, unless such endorsement activity is approved in writing by Racing and the Sponsor; and (vi) allowing”. [ab1fd1dd637746ab p.2] Section 4 concerns compliance with applicable rules and regulations rather than a non-compete. [ab1fd1dd637746ab p.2]

## Does the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry H...

The Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. filed 2013-09-26 does not contain a non-compete clause. [64e3019755b942aa p.8] The only "compete"-related word in the document appears in the severability clause, which states: "(e) In the event that any one or more provisions of this Agreement shall for any reason be held invalid, illegal or unenforceable in any respect, by any court of competent jurisdiction, such invalidity, illegality or unenforceability shall not affect any other provisions of this Agreement". [64e3019755b942aa p.8]

## Not established by the evidence

[GAP] No evidence was found for: Does the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies filed 2005-11-02 contain a non-compete clause, and if so, quote it?

## Verification appendix

Claims: 31 · supported: 18 · partially: 0 · dropped: 0 · gaps: 13 · tier-1 support rate: 1.00

Notes: outline from 8 fan-out findings (no outline call); 1 empty section(s) collapsed into gaps: Does the Reseller Agreement between Touchstar Software Corporation and Worldwide Strate...

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e7→[4cb98e07400203bf p.3] |  |
| s1.2 | s1 | gap |  |  | no evidence cited |
| s1.3 | s1 | gap |  |  | no evidence cited |
| s1.4 | s1 | keep | 1.00 | e7→[4cb98e07400203bf p.3] |  |
| s2.1 | s2 | keep | 1.00 | e5→[23e65a3b8bc5cc9e p.25] |  |
| s2.2 | s2 | gap |  |  | no evidence cited |
| s2.3 | s2 | gap |  |  | no evidence cited |
| s2.4 | s2 | keep | 1.00 | e5→[23e65a3b8bc5cc9e p.25] |  |
| s3.1 | s3 | keep | 1.00 | e4→[61c29bdb3ab6960e p.1] e1→[61c29bdb3ab6960e p.2] |  |
| s3.2 | s3 | gap |  |  | no evidence cited |
| s3.3 | s3 | gap |  |  | no evidence cited |
| s3.4 | s3 | gap |  |  | no evidence cited |
| s3.5 | s3 | keep | 1.00 | e1→[61c29bdb3ab6960e p.2] |  |
| s4.1 | s4 | keep | 1.00 | e2→[31cbf0d18f7d763e p.13] |  |
| s4.2 | s4 | keep | 1.00 | e2→[31cbf0d18f7d763e p.13] |  |
| s4.3 | s4 | gap |  |  | no evidence cited |
| s4.4 | s4 | keep | 1.00 | e2→[31cbf0d18f7d763e p.13] e3→[31cbf0d18f7d763e p.7] |  |
| s4.5 | s4 | keep | 1.00 | e3→[31cbf0d18f7d763e p.7] |  |
| s5.1 | s5 | gap |  |  | no evidence cited |
| s5.2 | s5 | keep | 1.00 | e1→[61c29bdb3ab6960e p.2] |  |
| s5.3 | s5 | keep | 1.00 | e1→[61c29bdb3ab6960e p.2] |  |
| s5.4 | s5 | gap |  |  | no evidence cited |
| s5.5 | s5 | gap |  |  | no evidence cited |
| s5.6 | s5 | keep | 1.00 | e1→[61c29bdb3ab6960e p.2] |  |
| s5.7 | s5 | gap |  |  |  |
| s6.1 | s6 | keep | 1.00 | e8→[ab1fd1dd637746ab p.2] |  |
| s6.2 | s6 | keep | 1.00 | e8→[ab1fd1dd637746ab p.2] |  |
| s6.3 | s6 | keep | 1.00 | e9→[ab1fd1dd637746ab p.2] |  |
| s7.1 | s7 | keep | 1.00 | e10→[64e3019755b942aa p.8] |  |
| s7.2 | s7 | keep | 1.00 | e10→[64e3019755b942aa p.8] |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [61c29bdb3ab6960e p.2 L98-105] keep (1.0): "3. Restriction on Promotion of Competing Products. During the term of this agreement, Distributor shall not market, sell advertise or promote the sale or use of any product or device which is competitive with or substantially similar to the…"
- e2 [31cbf0d18f7d763e p.13 L640-642] keep (1.0): "(e) Non-Compete. The Settlement Agreement and Mutual Release between *** and *** does not contain a covenant-non-compete applicable to *** and, to the best of PcoMed's current knowledge, *** is not subject to any covenant-non-compete that w…"
- e3 [31cbf0d18f7d763e p.7 L340-347] keep (1.0): "use in the Field in the Territory. Neither PcoMed nor its Affiliates shall sell or offer for sale, or grant rights under the PcoMed Surface Modification Technology to any Third Party in the Field in the Territory for products that utilize o…"
- e4 [61c29bdb3ab6960e p.1 L1-9] keep (1.0): "# EXCLUSIVE DISTRIBUTOR AGREEMENT
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| SEC Filing Date | 2018-11-09 |
| Parties | Erchonia Corporation ("Erchonia"); InnerScope Hearing Technologies Inc ("Distributor") |"
- e5 [23e65a3b8bc5cc9e p.25 L947-963] keep (1.0): "Section 11.3 Non-Competition and Non-Solicitation. (a) During the Term, except as otherwise provided in this Agreement, Network Affiliate and its affiliates agree not to engage or participate in any business, hold equity interests, directly…"
- e7 [4cb98e07400203bf p.3 L105-107] keep (1.0): "8. Exclusivity. Talent represents and warrants that during the Term and in the Territories, Talent will not endorse or make any appearances or advertisements on behalf of any other product which is directly competitive to ESSI's products."
- e8 [ab1fd1dd637746ab p.2 L55-58] keep (1.0): "(v) prohibiting the endorsement by Racing and any members of Racing, including the drivers, of any entities, products or services which are in direct competition or otherwise inconsistent with the Sponsor or it products or services, unless …"
- e9 [ab1fd1dd637746ab p.2 L72-79] keep (1.0): "4. Compliance with Applicable Rules and Regulations. Provision of the Benefits pursuant to this Agreement is subject to rules and requirements of each organization and venue hosting a racing event in which the Racing Team competes during th…"
- e10 [64e3019755b942aa p.8 L370-374] keep (1.0): "(e) In the event that any one or more provisions of this Agreement shall for any reason be held invalid, illegal or unenforceable in any respect, by any court of competent jurisdiction, such invalidity, illegality or unenforceability shall …"
