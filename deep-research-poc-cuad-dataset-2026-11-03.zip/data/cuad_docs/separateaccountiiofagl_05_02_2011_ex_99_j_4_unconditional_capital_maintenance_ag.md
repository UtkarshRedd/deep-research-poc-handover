<!-- page 1 -->
# Unconditional Capital Maintenance Agreement
| Field | Value |
|---|---|
| Document Type | Maintenance Agreement |
| Agreement Date | 2011-03-30 |
| Parties | American International Group, Inc. ("AIG"); American General Life Insurance Company ("Company") |
| Source | CUAD v1 / SEPARATEACCOUNTIIOFAGL_05_02_2011-EX-99.(J)(4)-UNCONDITIONAL CAPITAL MAINTENANCE AGREEMENT |

EXHIBIT (J)(4)

UNCONDITIONAL CAPITAL MAINTENANCE AGREEMENT BETWEEN AMERICAN INTERNATIONAL GROUP, INC. AND AMERICAN
GENERAL LIFE INSURANCE COMPANY OF DELAWARE

This Unconditional Capital Maintenance Agreement (this "Agreement"), is made, entered into and
effective as of March 30, 2011, by and between American International Group, Inc., a corporation
organized under the laws of the State of Delaware ("AIG"), and American General Life Insurance
Company of Delaware, a corporation organized under the laws of the Delaware (the "Company").

WITNESSETH:

WHEREAS, the Company is a life insurer subject to certain capital requirements of the insurance laws
and regulations of Delaware (the "Domiciliary State");

WHEREAS, the Company is an indirect wholly owned subsidiary of AIG; and

WHEREAS, AIG has an interest in unconditionally maintaining and enhancing the Company's financial
condition:

NOW, THEREFORE, in consideration of the mutual promises herein contained, the parties hereto agree
as follows:

1. In the event that the Company's Total Adjusted Capital for each of the Company's first and third
fiscal quarters (as determined based on the Company's first and third fiscal quarterly filed
statutory financial statements, respectively, subject to any adjustments or modifications thereto
required by the Domiciliary State's insurance department or the Company's independent auditors)
falls below the Specified Minimum Percentage of the Company's projected Company Action Level RBC (in
each case as estimated by the Company as of the end of each such first and third fiscal quarters, as
the case may be), AIG shall, within the respective time periods set forth under paragraph 4, in
accordance with paragraph 5 and in compliance with applicable law, provide to the Company cash, cash
equivalents, securities or other instruments that qualify (as admitted assets) for purposes of
calculating the Company's Total Adjusted Capital, as a contribution and not as a loan, in an amount
such that the Company's Total Adjusted Capital as of the end of each of the

Company's second and fourth fiscal quarter, as the case may be, will be projected to be at least
equal to the Specified Minimum Percentage of the Company's Company Action Level RBC. Notwithstanding
the foregoing, AIG may, at any time as it deems necessary in its sole discretion and in compliance
with applicable law, make a contribution to the Company in such amount as is required for the
Company's Total Adjusted Capital to equal a percentage of its Company Action Level RBC determined to
be appropriate by the Company and AIG.

2. In the event that the Company's Total Adjusted Capital (a) for each of the Company's first,
second and third fiscal quarters (as determined based on the Company's first, second and third
fiscal quarterly filed statutory financial statements, respectively, subject to any adjustments or
modifications thereto required by the Domiciliary State's insurance department or the Company's
independent auditors) is in excess of the Specified Minimum Percentage of the Company's projected
Company Action Level RBC (in each case as estimated by the Company as of the end of each such first,
second and third fiscal quarters, as the case may be) or (b) as of each fiscal year end (as shown in
the Company's fiscal year-end filed statutory financial statements, together with any adjustments or
modifications thereto required by the Domiciliary State's insurance department or the Company's
independent auditors) is in excess of the Specified Minimum Percentage of the Company's Company
Action Level RBC (as shown in such fiscal year-end statutory financial statements), the Company
shall, within the respective time periods set forth under paragraph 4, in accordance with paragraph
5 and subject to approval by the Company's board of directors as required by the laws of the
Domiciliary State, declare and pay dividends ratably to its equity holders in an aggregate amount
equal to the lesser of (i) the amount necessary to reduce the Company's projected or actual Total
Adjusted Capital as of each of the end of the Company's fiscal quarter or fiscal year, as the case
may be, to a level equal to or not materially greater than the Specified Minimum Percentage of the
Company's Company Action Level RBC or (ii) the maximum amount permitted by the Domiciliary State's
law to be paid as an ordinary dividend less an amount that the Company and AIG agree is appropriate
to protect the Company from exceeding such maximum amount allowed by such Domiciliary State's law as
a result of potential audit adjustments or adjustments to the projections on which such dividend
amount is based. For the avoidance of doubt, this paragraph shall only require the Company to pay
ordinary dividends; under no circumstances shall the Company be required to pay any dividend which
would trigger the

extraordinary dividend provisions of Section 18 (S) 5005 (B) of the
<!-- page 2 -->
Insurance Law of the Domiciliary State or that is otherwise prohibited by the Domiciliary State.
Notwithstanding the foregoing, this Agreement does not prohibit the payment of extraordinary
dividends to reduce the Company's projected or actual Total Adjusted Capital to a level equal to or
not materially greater than the Specified Minimum Percentage of the Company's Company Action Level
RBC.

3. For the avoidance of doubt, the terms "Total Adjusted Capital", "Company Action Level RBC", and
"Surplus to Policyholders" shall have the meanings ascribed thereto under the insurance laws and
regulations of the Domiciliary State, or, with respect to "Total Adjusted Capital" and "Company
Action Level RBC", if not defined therein, shall have the meanings ascribed thereto in the
risk-based capital ("RBC") instructions promulgated by the National Association of Insurance
Commissioners ("NAIC"). The term "Specified Minimum Percentage" shall be equal to the percentage set
forth on Schedule 1 attached hereto, which shall be agreed to by AIG and the Company at least once
every year beginning upon the date of the filing of the Company's 2010 Annual Statement with the
Domiciliary State's insurance department and following review against the capital adequacy standards
and criteria ("Agency Criteria") of each of Standard & Poor's Corp. ("S&P"), Moody's Investors
Service ("Moody's") and A.M. Best Company ("A.M. Best"). Notwithstanding the obligation of the
Company and AIG to review the Specified Minimum Percentage on an annual basis, the parties hereto
agree to review and revise the Specified Minimum Percentage on a more frequent basis, if the parties
agree it is appropriate, to take into account (a) any material changes after the date hereof to any
Agency Criteria adopted by any of S&P, Moody's or A.M. Best, on the one hand, or to the law of the
Domiciliary State or NAIC RBC rules or instructions, on the other hand, which causes the results
under the Agency Criteria to diverge from that under the law of the Domiciliary State or NAIC RBC
rules or instructions, (b) the Company completes a material transaction that is treated materially
differently by the Agency Criteria, on the one hand, and the NAIC RBC rules or instructions, on the
other hand, or (c) any other material development or circumstance affecting the Company which AIG
and the Company agree merits a reevaluation of the Specified Minimum Percentage then in effect.

4. The Company and AIG agree that any contribution to be made under paragraph 1 will take place
within the following two time periods per year, as applicable: (a) during the time beginning on the
first business day after the filing of the Company's first fiscal

3

quarterly statutory financial statements and ending on the last business day prior to the end of the
Company's second fiscal quarter; and (b) during the time beginning on the first business day after
the filing of the Company's third fiscal quarterly statutory financial statements and ending on the
last business day prior to the end of the Company's fourth fiscal quarter. Notwithstanding the
foregoing, in compliance with applicable law, any capital contribution provided for under paragraph
1 may be made by AIG after the close of any fiscal quarter or fiscal year of the Company but prior
to the filing by the Company of its statutory financial statements for such fiscal quarter or fiscal
year, respectively, and contributions of this nature shall be recognized as capital contributions
receivable as of the balance sheet date of the yet to be filed quarterly or annual financial
statement (as the case may be), pursuant to paragraph 8 of Statement of Statutory Accounting
Principles No. 72, to the extent approved by the Domiciliary State. The Company and AIG further
agree that any dividends to be made under paragraph 2 will take place as soon as practicable after
the filing by the Company of the relevant fiscal quarter-end or fiscal year-end statutory financial
statements or such earlier time as may be agreed by the Company and AIG.

5. At the time that any contribution is due under paragraph 4, AIG agrees that it will either (a)
make such contribution to the Company's direct parent and cause such direct parent to then
contribute such funds, securities or instruments so contributed by AIG to the Company, or (b) make
such contribution directly to the Company without receiving any capital stock or other ownership
interest in exchange therefor, subject in either case to any required regulatory approvals. At any
time any dividends are due under paragraph 4, the Company agrees that it will make such dividend to
the Company's direct parent and will use its best efforts to cause such direct parent to then
dividend or otherwise provide such funds to AIG. All contributions and dividends contemplated under
this Agreement shall be approved, declared and made, as applicable, in compliance with applicable
law, including, without limitation, approval by the board of directors of each applicable entity
(including the Company) and any prior notice requirements specified under applicable rules and
regulations of the Domiciliary State.

6. Subject to the requirements of applicable law and the approval, to the extent required, by any or
all of the Company's senior management, relevant management committees, board of directors, and of
any insurance regulator, the Company hereby acknowledges that, in a manner consistent with past
practice and

any other reasonable requirements of AIG, it will comply with all financial and budgetary planning,
risk mitigation, derisking or pricing, corporate governance, investment, informational and
procedural
<!-- page 3 -->
requirements set forth by AIG.

7. AIG hereby waives any failure or delay on the part of the Company in asserting or enforcing any
of its rights or in making any claims or demands hereunder.

8. Unless earlier terminated in accordance with this paragraph 8, this Agreement shall continue
indefinitely. AIG shall have the absolute right to terminate this Agreement upon thirty (30) days'
prior written notice to the Company, which notice shall state the effective date of termination (the
"Termination Date"); PROVIDED, HOWEVER, that AIG agrees not to terminate this Agreement unless (a)
AIG significantly modifies the corporate structure or ownership of the Company, or (b) AIG sells the
Company to an acquirer (i) having a rating from at least one of S&P, Moody's, A.M. Best or a
substitute agency, which is a nationally recognized statistical rating organization, that is at
least equal to the lower of (x) AIG's then-current rating from such agency or (y) the Company's
then-current rating as supported by this Agreement from such agency; or (ii) such that, immediately
on the effective date of the sale by AIG of the Company, the Company's capitalization is consistent
with the minimum capital adequacy standards and criteria of at least one of S&P, Moody's, A.M. Best
or a substitute agency, which is a nationally recognized statistical rating organization, for a
rating that is equal to or better than the Company's then-current rating on the date immediately
preceding such sale. To the extent not terminated previously by AIG pursuant to the foregoing, this
Agreement will terminate automatically one year after the closing of any sale of the Company by AIG,
and all provisions hereof will be of no further force and effect. For the avoidance of doubt, the
termination of this Agreement pursuant to this paragraph 8 shall not relieve either party of any
obligation it may owe to the other party hereunder that existed prior to, and remains outstanding as
of, the Termination Date.

9. Any policyholder holding a policy issued by the Company prior to the termination of this
Agreement shall have the right to demand that the Company enforce the Company's rights under
paragraphs 1, 4 and 5 of this Agreement, and, if the Company fails or refuses to take timely action
to enforce such rights or the Company defaults in any claim or other payment owed to any such
policyholder when due, such policyholder may proceed directly against AIG to enforce the Company's
rights under paragraphs 1, 4 and 5 of this

5

Agreement; PROVIDED, HOWEVER, that no policyholder of the Company may take any action authorized
under this paragraph 9 unless and until (a) such policyholder has given AIG written notice of its
intent to enforce the terms of this Agreement as provided in this paragraph 9, which notice shall
specify in reasonable detail the nature of and basis for the policyholder's complaint and (b) AIG
has failed to comply with this Agreement within sixty (60) days after such notice is given; and,
PROVIDED, FURTHER, that upon termination of this Agreement in accordance with paragraph 8 hereof,
the rights of any policyholder as provided for under this paragraph 9 shall terminate effective as
of the Termination Date, except with respect to the obligation of AIG (if any) to make capital
contributions to the Company pursuant to paragraphs 1, 4 and 5 of this Agreement solely to the
extent such obligation arose prior to, and remained unsatisfied as of, the Termination Date (it
being understood that upon AIG's satisfaction of all such obligations after the Termination Date, no
such policyholder shall have any rights against the Company or AIG, as the case may be, under this
paragraph 9).

10.This Agreement is not, and nothing herein contained and nothing done pursuant hereto by AIG shall
constitute or be construed or deemed to constitute, an evidence of indebtedness or an obligation or
liability of AIG as guarantor, endorser, surety or otherwise in respect of any obligation,
indebtedness or liability, of any kind whatsoever, of the Company. This Agreement does not provide,
and is not intended to be construed or deemed to provide, any policyholder of the Company with
recourse to or against any of the assets of AIG.

11.Any notice, instruction, request, consent, demand or other communication required or contemplated
by this Agreement shall be in writing, shall be given or made or communicated by United States first
class mail, addressed as follows:

If to AIG:

American International Group, Inc. 180 Maiden Lane New York, New York 10038 Attention: Secretary

If to the Company:

American General Life Insurance Company of Delaware c/o SunAmerica Financial Group, Inc. 2727-A
Allen Parkway

Houston, Texas 77019 Attention: Chief Financial Officer
<!-- page 4 -->
with a copy (which shall not constitute notice) to:

American General Life Insurance Company of Delaware c/o SunAmerica Financial Group, Inc. 1999 Avenue
of the Stars Los Angeles, CA 90067 Attention: General Counsel

12.On April 24, 2011, this Agreement shall supersede and replace that certain letter agreement,
dated December 13, 1991, by and between AIG and the Company regarding capital maintenance without
the need for any action.

13.The covenants, representations, warranties and agreements herein set forth shall be mutually
binding upon and inure to the mutual benefit of AIG and its successors and the Company and its
successors.

14.This Agreement shall be governed by and construed in accordance with the laws of New York,
without giving effect to the principles of conflict of laws.

15.If any provision of this Agreement shall be declared null, void or unenforceable in whole or in
part by any court, arbitrator or governmental agency, said provision shall survive to the extent it
is not so declared and all the other provisions of this Agreement shall remain in full force and
effect unless, in each case, such declaration shall serve to deprive any of the parties hereto of
the fundamental benefits of or rights under this Agreement.

16.This Agreement constitutes the entire agreement between the parties hereto with respect to the
subject matter hereof and supersedes all prior and contemporaneous agreements, understandings,
negotiations and discussion, whether oral or written, of the parties. This Agreement may be amended
at any time by written agreement or instrument signed by the parties hereto.

17.This Agreement may be signed by the parties in one or more counterparts which together shall
constitute one and the same agreement among the parties.

[signature page follows]

7

IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be duly executed by their
respective authorized officers as of the day and year first above written.

AMERICAN INTERNATIONAL GROUP, INC.

By: /S/ BRIAN T. SCHREIBER -------------------------- Name: Brian T. Schreiber Title: Executive Vice
President

By: /S/ ROBERT A. GENDER -------------------------- Name: Robert A. Gender Title: Senior Vice
President and Treasurer

AMERICAN GENERAL LIFE INSURANCE COMPANY OF DELAWARE

By: /S/ DON W. CUMMINGS -------------------------- Name: Don W. Cummings Title: Senior Vice
President and Chief Financial Officer

SCHEDULE 1

The Specified Minimum Percentage shall initially equal 350% of the Company's Company Action Level
RBC.
