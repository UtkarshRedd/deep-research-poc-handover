<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 2012-06-13 |
| Parties | Forty Niners SC Stadium Company LLC ("Forty Niners SC"); Violin Memory, Inc. ("Sponsor"); Forty Niners SC and Sponsor (individually as a “Party” and collectively as the “Parties.") |
| Source | CUAD v1 / VIOLINMEMORYINC_12_12_2012-EX-10.14-SPONSORSHIP AGREEMENT |

Exhibit 10.14

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

SPONSORSHIP AGREEMENT

THIS SPONSORSHIP AGREEMENT (this "Agreement") is made and entered into as of June 13, 2012 the
("Effective Date"), by and between Forty Niners SC Stadium Company LLC, a Delaware limited liability
company ("Forty Niners SC") having its principal place of business at 4949 Centennial Boulevard,
Santa Clara, CA 95054, and Violin Memory, Inc., a Delaware corporation ("Sponsor") having its
principal place of business at 685 Clyde Avenue, Mountain View, CA 94043. For purposes of this
Agreement, Forty Niners SC and Sponsor may each be referred to individually as a "Party" and may be
collectively referred to as the "Parties."

Recitals

WHEREAS, Forty Niners SC is an affiliate of Forty Niners Football Company LLC, (the "Team"), a
Delaware limited liability company that owns the National Football League franchise for the
professional football team known as the San Francisco 49ers.

WHEREAS, the Santa Clara Stadium Authority ("SCSA") is building a new stadium in Santa Clara (the
"Stadium") which it will own and operate.

WHEREAS, Forty Niners SC entered into a lease with SCSA pursuant to which Forty Niners SC will have
the right to sell sponsorships at the Stadium.

WHEREAS, Team entered into a sub-lease with Forty Niners SC and will play substantially all of its
home games at the Stadium.

WHEREAS, Sponsor desires to become a sponsor of Forty Niners SC, and Forty Niners SC desires to
grant Sponsor certain sponsorship rights, under the terms and conditions set forth herein.

NOW, THEREFORE, in consideration of the mutual promises and obligations set forth herein, the
sufficiency of which is hereby acknowledged, the Parties agree as follows:

Agreement

1. Definitions.

(a) "Affiliate" means a person or entity that directly, or indirectly through one or more
intermediaries, controls, or is controlled by, or is under common control with, a Party. The term
'control' means the possession of the power to direct the management and policies of the person or
entity, whether through ownership of voting securities, by contract or otherwise.

(b) "Agreement" has the meaning set forth in the initial paragraph.

(c) "Contract Year" means, for the first year of this Agreement, from March 1 of the year in which
the Stadium is anticipated to open through February 28 of the following year. For all years
thereafter, Contract Year means the period from March 1 through February 28 (or 29).
<!-- page 2 -->
Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

(d) "Deposit" has the meaning set forth in Section 5(b) of this Agreement,

(e) "Effective Date" has the meaning set forth in the initial paragraph.

(f) "Forty Niners SC" has the meaning set forth in the initial paragraph.

(g) "Indemnitee" has the meaning set forth in Section 11(a) of this Agreement.

(h) "Lost Sponsorship Benefits" has the meaning set forth in Section 7(c) of this Agreement.

(i) "Marks" means collectively the Team Marks and the Sponsor Marks.

(j) "No­Signage Event" has the meaning set forth in Section 3(c) of this Agreement.

(k) "Party" has the meaning set forth in the initial paragraph.

(l) "Product and Services Category " means flash data storage and/or video surveillance products.

(m) "Scheduled Opening Date" has the meaning set forth in Section 7(a) of this Agreement.

(n) "SCSA" has the meaning set forth in the Recitals.

(o) "Sponsor" has the meaning set forth in the initial paragraph.

(p) "Sponsor Marks" means those trademarks and services marks set forth in Schedule 3, as may be
updated by Sponsor from time to time, provided that in the event that Sponsor changes its name, the
cost of effectuating the change of such Sponsor Marks shall be borne by Sponsor.

(q) "Sponsorship Fee" has the meaning set forth in Section 5(a) of this Agreement.

(r) "Sponsorship Rights" has the meaning set forth in Section 3(a) of this Agreement.

(s) "Stadium" has the meaning set forth in the Recitals.

(t) "Team" has the meaning set forth in the Recitals.

(u) "Team Companies" shall mean, collectively, Forty Niners SC and the Team.

(v) "Team Marks" means those trademarks and services marks set forth in Schedule 2.

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

*** Confidential material redacted and filed separately with the Commission.
<!-- page 3 -->
2. Term.

(a) This Agreement shall commence on the "Effective Date" and shall continue for ten (10) Contract
Years, unless terminated in accordance with the provisions of Section 6 of this Agreement or
extended by renewal by written agreement of the Parties in accordance with the provisions of Section
13(o) of this Agreement (the "Term").

(b) Provided the Agreement is not earlier terminated in accordance with its terms, *** shall have
***, from ***, to *** for the period ***. During such period, ***. The parties agree and acknowledge
that ***. Nothing herein shall prevent Team from *** at any time, provided Team does not ***.
Nothing herein shall prevent Team from ***, so long as such *** is limited to stating that the ***.

3. Grant of Sponsorship Rights.

(a) From the commencement of the first Contract Year through the end of the Term, Forty Niners SC
will provide (or cause to be provided) to Sponsor those sponsorship rights ("Sponsorship Rights") as
set forth in Schedule 1 to this Agreement.

(b) License to Use Team Marks. From the commencement of the first Contract Year through the end of
the Term, Forty Niners SC grants to Sponsor a limited license during the Term to (a) advertise and
promote the fact that Sponsor is an "official sponsor of the San Francisco 49ers," (b) use,
reproduce and display the Team Marks in connection with advertising and promotion of Sponsor's goods
and services in the Product and Services Category, and (c) promote Sponsor's sponsorship, subject to
the terms and conditions of use set forth herein.

(c) No-Signage Events. Sponsor acknowledges and agrees that SCSA (directly or through its appointed
manager) may determine in its sole discretion that certain events at the Stadium (other than Team
events) from time to time (each referred to herein as a "No-Signage Event"), including, but not
limited to the Olympic Games, World Cup Soccer, NCAA championships, college football bowl games,
college football championship games and other events, may require that signage and advertising be
covered, obscured or temporarily removed during the event or may prohibit signage or advertising for
any party other than a sponsor of the event itself. Sponsor agrees that it shall not be entitled to
Sponsorship Rights, signage or other advertising benefits in or around the Stadium for a reasonable
period before, during and after a No-Signage Event.

(d) Does Not Cover Other Professional Sports Teams. Sponsor acknowledges and agrees that the
Sponsorship Rights granted hereunder do not include any rights or benefits related to or in
connection with any other professional sports team that may, from time to time, play its home games
in the Stadium. SCSA and/or such other team shall have the right to grant Stadium-related rights and
benefits to another sponsor within the Product and Services Category with respect to such other
team's home games played at the Stadium.

(e) Grant of License by Sponsor. In order for Forty Niners SC to fulfill its obligations hereunder,
Sponsor hereby grants to Forty Niners SC a limited license during the

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

*** Confidential material redacted and filed separately with the Commission.
<!-- page 4 -->
Term to use, reproduce and display the Sponsor Marks in connection with advertising and promotion of
Sponsor and its sponsorship.

4. Exclusivity.

(a) Exclusive Sponsor of the Team. Forty Niners SC acknowledges and agrees that, except as otherwise
provided herein, the rights granted to Sponsor herein are exclusive to Sponsor within the Product
and Services Category with respect to Forty Niners SC at the Stadium. Forty Niners SC shall not
enter into a sponsorship agreement with a party with respect to the Product and Services Category,
provided however, that Forty Niners SC shall be permitted to enter into a sponsorship agreement with
any party that enters into a naming rights agreement with SCSA for the Stadium, provided that if
SCSA enters into a naming rights agreement for the Stadium with a party that is in the Products and
Services Category, Sponsor may immediately terminate this Agreement and receive a pro rated refund
of any amounts paid by Sponsor for the unexpired Contract Year in which the termination occurs.

(b) Ability to Seek Other Sponsorships. Sponsor acknowledges and agrees that, notwithstanding the
grant of exclusivity set forth in this Section 4, Team shall have the right to solicit and enter
into sponsorships with other parties that are not known primarily or exclusively as suppliers or
providers of any product or service within the Product and Services Category. Without limiting
Section 4(a) above, the Parties agree that *** are, at the Effective Date, primarily or exclusively
known as suppliers or providers in the Product and Services Category. Accordingly, Forty Niners SC
shall not solicit or enter into sponsorships with such Parties.

5. Sponsorship Fee.

(a) Fee. In exchange for the Sponsorship Rights to be provided to Sponsor during each Contract Year
of this Agreement, Sponsor shall pay an annual fee (the "Sponsorship Fee") during each Contract Year
of the Term. The Sponsorship Fee shall be four­million U.S. Dollars (USD $4,000,000.00) during each
Contract Year.

(b) Deposit. Sponsor shall make a non-refundable deposit upon execution of this Agreement of
five-hundred-thousand U.S. dollars (USD $500,000.00) (the "Deposit"), which shall be applied against
the Sponsorship Fee for the first Contract Year.

(c) Payment Schedule. The Sponsorship Fee shall be payable in two (2) equal semiannual installments
per year on or before March 1 and September 1 of each Contract Year of the Term; with the first
installment due on March 1, 2014, unless Forty Niners SC notifies Sponsor that the Stadium will not
open in 2014.

(d) Taxes. The Sponsor Fee is net of any commissions. Sponsor shall be liable for all applicable
taxes or charges, other than taxes or charges based solely on Forty Niners SC's net income.

(e) Cost of Materials. Unless otherwise agreed in writing, Sponsor shall be solely responsible for
all costs and expenses incurred producing (including, without limitation, design, production and
installation) marketing materials, signage, and/or branding or entitlement, if any

4

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

*** Confidential material redacted and filed separately with the Commission.
<!-- page 5 -->
(e.g., advertising copy, fixed signage, build-out of entitled club space, etc.), used in connection
with the Agreement. In the event Sponsor terminates the Agreement prior to expiration, Sponsor shall
pay for the removal of its signage from the Stadium.

(f) Interest on Late Payments. Any payment required to be made by Sponsor hereunder that is not paid
within fourteen (14) days from the date such payment becomes due and owing shall bear interest at an
annual rate of twelve percent (12%) per annum or, if lower, the maximum allowed by law from the due
date to the date payment is actually made. The right of Forty Niners SC to receive interest under
this Section 5(f) shall be in addition to all other rights it may have as a result of Sponsor's
failure to make payments when due.

(g) Business Back. Over the course of the Term, Forty Niners SC shall purchase, at retail (measured
by the average price sold to other customers), and subject to the terms of such future purchase
agreements, *** of Sponsor's products, services, and support.

6. Termination.

(a) Default. If either Party defaults in the performance of, or compliance with, any term or
condition of this Agreement, the other Party may terminate this Agreement by written notice.
Termination of this Agreement shall be effective thirty (30) days from the date of receipt of such
notice, unless, within thirty (30) days after receipt of such notice, the defaulting Party has
corrected the default or if such default is capable of correction, has taken timely and reasonable
steps to correct and will complete such correction within another thirty (30) days.

(b) Insolvency or Bankruptcy. If either Party files a petition in bankruptcy or is adjudicated a
bankrupt, or if a petition in bankruptcy is filed against a Party, or if a Party becomes insolvent,
makes an assignment for the benefit of its creditors or an arrangement pursuant to any bankruptcy
law, or if a Party discontinues its business or if a receiver is appointed for it or its business,
exclusivity under Section 4 shall terminate automatically and immediately and the other Party shall
have the right to terminate this Agreement effective upon giving of notice to insolvent/bankrupt
Party.

(c) Harmful Behavior. Either Party shall have the right to immediately terminate this Agreement in
the event the other Party, in such Party's reasonable discretion, engages in illegal, indecent,
immoral, harmful or scandalous behavior or activities that may directly or indirectly damage such
Party's reputation or goodwill or violates any rules or regulations of Team or the National Football
League or if this would otherwise violate League policy or directive.

(d) Stadium Naming. Sponsor shall have the right to immediately terminate this Agreement as set
forth in Section 4(b) above.

(e) Discontinuance of Use of Marks. Upon expiration or termination of this Agreement, Sponsor shall
immediately cease any new uses of all Team Marks, as well as any statements of association with
Forty Niners SC, the Team and the Stadium. Sponsor acknowledges that its failure to cease the use of
Team Marks at the termination or expiration of the Agreement will result in immediate and
irreparable harm to Team, Forty Niners SC and the

5
<!-- page 6 -->
Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

SCSA and to the rights of any subsequent sponsor. Sponsor agrees that in the event of such failure
to cease such use, Team, Forty Niners SC, and SCSA shall be entitled to equitable relief by way of
temporary and permanent injunctions and such other and further relief as any court with jurisdiction
may deem just and proper. Upon expiration or termination of this Agreement, Forty Niners SC and the
Team shall immediately cease any new uses of all Sponsor Marks.

(f) Termination Is Without Prejudice to Terminating Party's Rights. Any termination of this
Agreement pursuant to this Section 6 shall be without prejudice to the terminating Party's rights
and remedies available at law or equity.

7. Opening of Stadium.

(a) Scheduled Opening Date. Sponsor acknowledges that the opening of the Stadium is scheduled for
August 31, 2014 (the "Scheduled Opening Date"). During the 2014 NFL season, Team expects to play all
home pre­season games at the existing facility and not in the Stadium. Sponsor further acknowledges
that, due to the complexity of constructing the Stadium, the possibility exists that the opening of
the Stadium could occur after the Scheduled Opening Date. In the event that the opening of the
Stadium occurs after the Scheduled Opening Date, then Sponsor agrees that its sole remedies shall be
as set forth in this Section 7.

(b) Four Regular Season Home Games or Fewer. In the event that the opening of the Stadium causes the
first four or fewer regular 2014 season home games to be played outside of the Stadium, then there
shall be no adjustment to the benefits provided as part of the Team Sponsorship Rights and/or the
Stadium Sponsorship Rights. Team acknowledges and agrees that Sponsor shall still be entitled to
receive all benefits provided under the Team Sponsorship Rights for all such games played outside
the Stadium.

(c) Greater than Four Regular Season Home Games. In the event that the Stadium opens in 2014 but
four or more regular 2014 season games are played outside of the Stadium, then (i) Sponsor shall be
entitled to receive all benefits provided under the Sponsorship Rights for all such games played
outside the Stadium and (ii) Sponsor shall be entitled to receive "make good benefits" for the value
of benefits to be provided as part of the Sponsorship Rights that are not provided (the "Lost
Sponsorship Benefits"). The Parties shall meet to determine make good benefits to be provided to
compensate for Lost Sponsorship Benefits. In the event that the Parties are unable to agree on the
make good benefits to be provided, then the make good benefits shall be determined under the
arbitration process set forth in Section 12.

(d) Stadium Opens for the 2015 or 2016 Season. In the event that the Stadium does not open during
the 2014 season, then, pursuant to Section 2, the first Contract Year will not commence until the
year in which the Stadium is anticipated to open.

(e) Stadium Does Not Open. In the event that the Stadium does not open within two years of the
Scheduled Opening Date, then the Sponsorship Fee shall thereafter be reduced to an amount equal to
the value of the Team Sponsorship Rights only. The Parties shall negotiate in good faith to
determine the value of the Team Sponsorship Rights alone. If they are unable to

6
<!-- page 7 -->
Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

reach an agreement on this issue, then the dispute shall be resolved under the arbitration process
set forth in Section 12.

8. Intellectual Property.

(a) Ownership of Marks. Nothing herein contained shall be construed as an assignment or grant to
Sponsor of any right, title or interest in or to the Team Marks, or in or to any copyright, design
patent or trademark thereto, beyond the grant of the licensing rights on the terms herein specified.
Sponsor hereby agrees that its every use of Team Marks shall inure to the benefit of Team Companies
and that Sponsor shall not at any time acquire any rights in Team Marks by virtue of any use it may
make of such marks. Likewise, nothing herein shall be construed as an assignment or grant to Forty
Niners SC of any right, title or interest in or to the Sponsor Marks, or in or to any copyright,
design patent or trademark thereto, beyond the grant of the licensing rights on the terms herein
specified. Forty Niners SC hereby agrees that its every use of the Sponsor Marks shall inure to the
benefit of Sponsor, and Forty Niners SC shall not at any time acquire any rights in Sponsor Marks by
virtue of any use Team Companies may make of such marks. Sponsor shall have no sub-license or
pass-through rights. Sponsor agrees that it will not create any trademark, logo or other
intellectual property that is derived from or confusingly similar with the Team Marks or that in any
way indicates or implies a connection, affiliation, endorsement, sponsorship or other relationship
between Sponsor, or any product or service of Sponsor, and the Team Companies, without the prior
written approval of Forty Niners SC.

(b) Notification of Infringement. Sponsor shall notify Forty Niners SC of any infringement of the
trademark rights or copyright in the Team Marks, and to assist in any action, legal or otherwise,
necessary to protect such trademark rights or copyright, provided that all costs and expenses
related to such an action shall be the sole responsibility of Forty Niners SC.

(c) Use According to Specifications. Sponsor agrees to use the Team Marks only in accordance with
the Team Companies' specifications and guidelines as may be provided from time to time. Sponsor's
materials shall be of high standard and superior quality and shall in no manner reflect adversely on
Team Companies or the Stadium. The Team Companies agree to use the Sponsor Marks only in accordance
with Sponsor's specifications and guidelines as may be provided from time to time.

(d) Approval of Use of Marks. Sponsor shall submit to the Team Companies all advertising or
promotional materials related to this Agreement and involving Team Marks a minimum of ten (10) days
prior to the production of such materials. Sponsor need not receive specific approval to release
such advertising or promotional materials to the public. However, the Team Companies shall have the
right, at any time during the ten (10) day period, to object to any advertising or promotional
materials. Sponsor will not use the advertising or promotional material if the Team Companies
objects to advertising or promotional materials. The Team Companies shall submit to Sponsor all
materials related to this Agreement and involving Sponsor Marks a minimum of ten (10) days prior to
the production of such materials. The Team Companies need not receive specific approval to release
such advertising or promotional materials to the public. However, Sponsor shall have the right, at
any time during the ten (10)

7
<!-- page 8 -->
Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

day period, to object to any advertising or promotional materials. The Team Companies will not use
the advertising or promotional material if Sponsor objects to advertising or promotional materials.

(e) Players and Coaches. With the exception of certain group player licensing rights made available
to the Sponsor by the Team Companies pursuant to the Team's rights under the NFL Collective
Bargaining Agreement, Sponsor acknowledges that this Agreement does not grant it any rights with
respect to the name, likeness, signature or other attributes of any player, coach, or other employee
of the Team. Sponsor shall be responsible for securing whatever rights may be required for the use
of such names, likenesses, signatures or other attributes and may only do so with the prior written
consent of the Team Companies. Sponsor represents that it will not exercise the rights granted in
this Agreement in any manner that will imply Sponsor has obtained any such rights without separate
written authorization from the, appropriate player, coach or employee.

(f) No Contests Without Approval. Unless otherwise indicated in this Agreement, Sponsor has no right
to run contests, sweepstakes, or promotions in connection with Team Marks or the Agreement or for
the award of invitations, tickets or other benefits acquired by Sponsor under the Agreement. In the
event the Team Companies grant Sponsor the right to run a contest, sweepstakes or promotion, then
Sponsor shall comply with all applicable federal, state and local laws, rules, regulations or orders
applicable to any such activities and hereby indemnifies the Team Companies and SCSA from any
failure to so comply.

9. Confidentiality. The Parties shall each keep confidential all provisions of this Agreement and
(unless required by law or judicial process after making reasonable efforts to resist disclosure,
including without limitation he requirements of any securities exchange), shall not disclose any of
same to any third party (other than the NFL, the Parties' respective lenders or potential lenders,
and the agents, counsel,­ and other representatives of NFL, the Parties, and such lenders) without
first obtaining the prior written consent of the other Party. The provisions of this Section 9 shall
survive the termination or expiration of this Agreement for any reason Warranties and
Representations.

(a) By Forty Niners SC. Forty Niners SC represents and warrants to Sponsor the following:

(i) Forty Niners SC is a limited liability company in good standing under the laws of the State of
Delaware and is duly authorized to transact business in the State of California, with full power and
authority to enter into and fully perform its obligations under this Agreement. The execution and
delivery of this Agreement on behalf of Forty Niners SC has been duly authorized, and no consent or
approval of any other person or entity is required for execution of and performance by Forty Niners
SC of this Agreement.

(ii) Forty Niners SC is not a party to any existing agreement regarding the sponsorship or promotion
of or advertising relating to the Stadium, which other agreement would conflict with the provisions
of this Agreement or otherwise impair any of the rights or other benefits Sponsor is entitled to
receive hereunder.

8
<!-- page 9 -->
Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

(iii) Forty Niners SC has not granted any rights pertaining to the subject matter of this Agreement
to any party in a manner which would cause Forty Niners SC to be in default under any such agreement
or which prevents Forty Niners SC from granting the rights and licenses to Sponsor under this
Agreement.

(iv) The execution, delivery and performance of this Agreement and the transactions contemplated
hereby (a) are within the authority of the Team Companies, and (b) do not conflict with or result in
any breach or contravention of any provision of applicable law or the constitution, bylaws or other
requirements of the NFL.

(v) There are no actions, suits, proceedings or investigations of any kind ending or threatened
against the Team Companies with respect to the transactions contemplated hereby.

(vi) The Team Companies own or otherwise have sufficient rights in and to the Team Marks to grant
the rights and licenses granted herein.

(b) By Sponsor. Sponsor represents and warrants to Forty Niners SC the following:

(i) Sponsor is a corporation in good standing under the laws of the State of Delaware and is duly
authorized to transact business in the State of California with full power and authority to enter
into and fully perform its obligations under this Agreement. The execution and delivery of this
Agreement on behalf of Sponsor has been duly authorized by Sponsor and, no consent or approval of
any other person or entity is required for execution of and performance by Sponsor of this
Agreement.

(ii) Neither this Agreement nor anything required to be done hereunder by Sponsor violates any
corporate charter, contract, or other document to which Sponsor is a party or by which it is
otherwise bound.

(iii) Sponsor has not granted any rights pertaining to the subject matter of this Agreement to any
party in a manner which would cause Sponsor to be in default under any such agreement or which
prevents Sponsor from entering into this Agreement.

(iv) The execution, delivery and performance of this Agreement and the transactions contemplated
hereby (a) are within the authority of Sponsor, and (b) do not conflict with or result in any breach
or contravention of any provision of applicable law.

(v) There are no actions, suits, proceedings or investigations of any kind ending or threatened
against Sponsor with respect to the transactions contemplated hereby.

(vi) Sponsor is the sole owner of all right, title and interest in and to the Sponsor Marks.

10. Indemnification and Insurance.

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

*** Confidential material redacted and filed separately with the Commission.
<!-- page 10 -->
(a) Indemnification. Sponsor hereby agrees to and does (a) waive any and all suits, actions, claims,
losses, demands, damages, liabilities, costs and reasonable expenses of every kind (including
consequential, incidental or punitive damages, or lost profits), including court costs and
reasonable attorneys' fees (collectively, "Claims") Sponsor may have now or in the future against
Forty Niners SC, its Affiliates, the National Football League, SCSA and any of their respective
officers, directors, employees, agents, insurers, and assigns (collectively, the "Indemnitees") for
damage to or destruction of Sponsor's property, excepting only claims caused by the gross negligence
or willful misconduct of an Indemnitee; (b) fully compensate Forty Niners SC, the SCSA and their
respective Affiliates ("Indemnitees") for damage to or destruction of their tangible property caused
by, resulting from, or arising out of Sponsor's negligence or willful misconduct under this
Agreement; (b) defend, indemnify, protect and hold the Indemnitees harmless from and against any and
all claims by Sponsor's officers, directors, employees, insurers, invitees, and agents for any
personal injury or death or any property damage, regardless of how caused, including claims caused
in whole or in part by the act, omission or negligence of an Indemnitee, excepting with respect to
any Indemnitee only claims caused by the negligence or willful misconduct of such Indemnitee, to the
extent of such negligence or willful misconduct, and (c) defend, indemnify, protect and hold
harmless the Indemnitees against any and all claims by third parties, including, without limitation,
all costs, liabilities, judgments, expenses, damages and reasonable attorneys' fees, arising out of
or in connection with (i) any breach by Sponsor of any provision of the Agreement or any
representation or warranty made by it therein; (ii) the use of the Sponsor Marks displayed in any
advertising materials; (iii) any negligence or willful misconduct of Sponsor, its employees,
servants and agents hereunder or in respect hereto; and (iv) any event for which Sponsor is credited
with sponsorship or which is controlled or directed by Sponsor or anyone with whom Sponsor has
contracted to control or direct such activities. ***. Promptly after the receipt by an indemnified
party of notice of any claim, such indemnified party will, if a claim with respect thereto is to be
made against an indemnifying party, give such indemnifying party written notice within a reasonable
period of such asserted liability or commencement of such action or proceeding. The indemnifying
party shall have the right, at its option, to compromise, settle or defend, at its own expense and
with its own counsel, such claim; provided, however, such right shall apply only to claims for
monetary damages and not to claims for injunction or other equitable relief, and provided further
that no Party shall have the right to bind the other Party under the terms of a settlement without
the consent of such Party. If the indemnifying party undertakes to compromise, settle or defend any
such claim, it shall promptly notify the indemnified party. The indemnified party shall cooperate
reasonably with the indemnifying party and its counsel, at the sole expense of the indemnifying
party, in the compromise or settlement of, or defense against, any such claim.

(b) Insurance. During the Term of this Agreement, *** shall, at no cost to the ***, maintain (or
cause to be maintained) the following insurance coverage with insurers having a "Best's" rating of
A­VIII or better: commercial general liability insurance, including coverage for bodily injury,
property damage, personal and advertising injury, products/completed operations and contractual
liability with a minimum amount of ten million US Dollars (USD $10,000,000.00) for each occurrence.
*** shall furnish the other Party with a certificate of insurance evidencing such insurance
coverage, which shall further contain a provision that the

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

*** Confidential material redacted and filed separately with the Commission.
<!-- page 11 -->
policy or policies evidenced thereby shall not be canceled or modified without thirty (30) days
advance written notice.

(c) ***. In no event shall *** be *** or ***, even if apprised of the *** of such ***.

11. Arbitration.

(a) Disputes Subject to Arbitration. Any dispute arising under or relating to this Agreement shall
be resolved exclusively by arbitration under the Commercial Arbitration Rules of the American
Arbitration Association, with the venue of any such arbitration proceeding to be in Santa Clara,
California or such other location as maybe agreed by the Parties.

(b) Arbitrator. The arbitrator for any dispute shall be selected according to the Commercial
Arbitration Rules of the American Arbitration Association.

(c) Arbitration Award. The award rendered by the arbitrator shall be final, shall identify a winning
Party, and judgment may be entered upon the award in accordance with applicable law in any court
having jurisdiction thereof

(d) Expenses; Attorneys' Fees and Costs. The fees and expenses of the arbitrators shall be paid by
the non-winning Party. In addition, the winning Party's reasonable attorneys' fees and costs shall
be paid by the non­winning Party.

12. Miscellaneous Provisions.

(a) Relationship of Parties. Forty Niners SC and Sponsor shall at all times be independent
contractors with respect to each other, and this Agreement shall not constitute either as the agent,
partner, or legal representative of the other for any purpose whatsoever. From time to time during
the Term, each Party will designate an individual to serve as the primary liaison of such Party for
the day-to-day administration of this Agreement.

(b) Third Party Beneficiaries. This Agreement does not and is not intended to confer any rights upon
any person other than the Parties, except that it is expressly agreed that Team and SCSA are
intended third party beneficiaries of Section 8.

(c) Compliance. This Agreement and the rights conferred herein are subject to (i) the Constitution
and Bylaws and all other rules and regulations of the NFL as they presently exist and as they may,
from time to time, be amended; (ii) the terms of any existing or future contracts or agreement
entered into by NFL Properties or a related entity relating to sponsorships, the telecasting or
radio broadcasting of NFL games; (iii) any rule or regulation of the NFL or any agreement to which
the NFL is a party which restricts the visibility of signage within the Stadium during NFL games
which are televised nationally; and (iv) any and all statutes and regulations of the United States,
the State of California, the County of Santa Clara or the City of Santa Clara, as may from time to
time be in force.

(d) Waiver. The failure by either Party to exercise any right, power or option given to it by this
Agreement, or to insist upon strict compliance with the provisions of this Agreement,

11

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

*** Confidential material redacted and filed separately with the Commission.
<!-- page 12 -->
shall not constitute a waiver of the provisions of this Agreement with respect to any other or
subsequent breach thereof, nor a waiver by such Party of its rights at any time thereafter to
require exact and strict compliance with all the provisions hereof. The rights or remedies under
this Agreement are cumulative to any other rights or remedies which may be granted by law.

(e) Notice. All notices, requests, or offers required or permitted to be made under this Agreement
shall be in writing and shall be deemed properly delivered on the earlier of actual receipt or three
days after the date deposited in the U.S. Mail, by certified mail, return receipt requested, or by
recognized overnight delivery service with signature required (e.g., FedEx, UPS) addressed as
follows: If to Forty Niners SC:

San Francisco 49ers Attn: Legal Affairs 4949 Centennial Blvd. Santa Clara, CA 95054

If to Sponsor:

Violin Memory, Inc. Attn: Legal 685 Clyde Ave Mountain View, CA 94043

(f) Severability. Should any provision of this Agreement be determined to be invalid for any reason,
such invalidity shall not affect the validity of any other provisions, which other provisions shall
remain in full force and effect as if this Agreement had been executed with the invalid provision
eliminated, and it is hereby declared the intention of the Parties that they would have executed the
other provisions of this Agreement without including therein any such provisions which may for any
reason be hereafter determined invalid.

(g) Assignment. This Agreement and the rights granted hereunder may not be assigned, sold,
transferred, pledged or exchanged by Sponsor by operation of law or otherwise without the prior
written consent of Forty Niners SC, which consent shall be in Forty Niners SC's sole discretion;
provided, however, that Forty Niners SC shall consent to an assignment to any entity that acquires
Sponsor (or a substantial portion of Sponsor's assets) via merger, acquisition or other similar
transaction so long as (i) such entity's sponsorship would not cause Forty Niners SC to breach any
existing agreement, (ii) Sponsor is not in default under this Agreements, and (iii) such sponsorship
shall not otherwise cause a breach under this Agreement. ***. Sponsor shall have no right to assign
any right granted hereunder to use Team Marks, or any other Sponsorship Rights granted hereunder, to
any third party, except as otherwise explicitly set forth herein. The rights and obligations of
Forty Niners SC under this Agreement may be assigned by Forty Niners SC without the consent of
Sponsor so long as the assignment shall be the assignment of Team's rights and obligations hereunder
(i) as collateral security for financing arrangements, (ii) to any Affiliate or successor entity, or
(iii) to any purchaser of Team's interest in its NFL franchise. The Agreement and all of the terms
and provisions hereof will be binding upon and will inure to the benefit of the Parties hereto and
their respective successors and permitted assigns, upon proper assignment where required.

12
<!-- page 13 -->
Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

(h) Force Majeure. Neither Party shall be liable for failure to comply with any of the terms or
conditions of this Agreement when such failure to comply has been caused by fire, war, insurrection,
labor disturbances, work stoppages, terrorism, government restrictions, natural disasters, weather,
or acts of God beyond the reasonable control of the Parties, provided the Party so affected gives
prompt notice to the other. In the event of a suspension or any obligation by reason of this Section
13(h) which extends beyond one-hundred-and-eighty (180) days, this Agreement shall be tolled.

(i) Unavailable Elements. Due to the nature of this Agreement, the rights granted may become
unavailable or become impossible to provide during the Term (each an "Unavailable Element"). In such
event, the Parties shall mutually and reasonably agree on a different "make good" benefit or right
that has substantially the same value as the Unavailable Element(s).

(j) Media Releases. Any media releases to be issued in connection with this Agreement must be
approved by the Parties, in writing, prior to their release.

(k) Headings. The Paragraph and Section headings in this Agreement are for convenience only and
shall not be used in the interpretation nor considered part of this Agreement.

(l) Survival. The provisions set forth in Sections 9, 11, and 12 shall survive the expiration or
termination of this Agreement.

(m) Entire Agreement and Effect. This Agreement, including all Schedules and Exhibits, constitutes
the entire agreement and understanding between the Parties with respect to the subject matter hereof
and supersedes all prior agreements and understandings. All representations and negotiations
relative to the matters contemplated by this Agreement are merged herein, and there are no
contemporaneous understandings or agreements relating to the matters set forth herein other than
those incorporated herein.

(n) Governing Law. This Agreement shall be governed by and construed in accordance with the laws of
the State of California without regard to its conflict of laws provisions.

(o) Amendments/Modification. This Agreement may not be amended or modified except by written
document signed by both Parties.

(p) Execution In Counterpart. This Agreement may be executed in any number of counterparts, each of
which shall be deemed an original but all of which together shall constitute one and the same
instrument.

[Remainder of page intentionally left blank.]
<!-- page 14 -->
Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

IN WITNESS WHEREOF, the Patties have executed this Agreement, effective as of the Effective Date.
VIOLIN MEMORY

By: /s/ Dixon Doll Jr.

Name: Dixon Doll Jr.

Title: COO/Director

FORTY NINERS SC STADIUM COMPANY LLC

By: /s/ Gideon Yu

Name: Gideon Yu

Title: President

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

*** Confidential material redacted and filed separately with the Commission.
<!-- page 15 -->
SCHEDULE 1

SPONSORSHIP RIGHTS

During each Contract Year:

1. Designation. Sponsor will be permitted to use the designation of "The Official Data Storage and
Video Surveillance Provider of the San Francisco 49ers."

2. Signage. Design, production and installation of all signage or other displays or branding shall
be subject to the mutual agreement of the Parties, and shall be paid for by Sponsor, as set forth in
Section 5(e) of this Agreement.

(a) Branded Areas. Sponsor shall receive exclusive branding and entitlement at the Stadium at (i) a
ticketed entryway for the suite tower guests (currently referred to as "Suite Tower Gate F"); (ii)
an open communal space in front of the suite tower (currently referred to as the "Suite Tower
Plaza"); (iii) first floor welcome lobby of suite tower and individual suite corridors (currently
referred to as the "Suite Tower Atrium"); and (iv) an on­site meeting space (currently referred to
as the "Executive Briefing Center") located adjacent to the suite described below and Forty Niners
SC will provide a *** credit towards buildout of the Executive Briefing Center.

(b) Exterior Stadium Signage. Sponsor shall be permitted to display outside the stadium a
three-dimensional metal lettered sign with a translucent face, internally illuminated by LED (i) in
a *** space on the face of a suite tower (the "West Suite Tower Banner Sign") with the words "Violin
Memory Tower" or another mutually agreed upon name; and (ii) in a *** space over a gate entryway
(the "West Gate Entry Sign") with the words "Violin Memory Plaza" or another mutually agreed upon
name.

(c) Interior Stadium Signage. Sponsor shall be permitted to display in Stadium (i) a prominent
digital rotational sign (one of ten founding partners), as determined by Forty Niners SC, located
above each of the (a) north endzone (the "North Scoreboard Rotator") and (b) south endzone (the
"South Scoreboard Rotator"); and (ii) a bold, channel­cut, high­contrast panel (one of ten founding
partners) located between the 40­yard lines on the Stadium's west side (the "Suite Tower Fixed Bowl
Signage").

(d) Digital Signage. Sponsor shall receive *** thirty-second (:30) advertisements on the Stadium
360-degree LED ribbon in Stadium at each Forty Niners home game in the Stadium. Sponsor shall also
receive (i) advertising in a mutually-determined number of thirty-second (:30) units and (ii) one
(1) mutually-determined co-branded feature, played on a minimum of *** high-definition monitors
located in the Stadium at each Forty Niners home game.

3. Gameday Activation.

(a) Display Booth. Sponsor shall receive booth space for an interactive showcase in an area for
pre-game fan activity (currently referred to as the "Faithful Mile") at each home game.

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

*** Confidential material redacted and filed separately with the Commission.
<!-- page 16 -->
(b) In-Game Fan Promotion. Sponsor and Forty Niners SC shall agree on a presenting sponsorship of a
promotion for each home game each Contract Year (by way of example only, "early fan of the game"
receives a coupon for food and beverage and feature them on the scoreboard).

(c) In-Game Scoreboard Feature. Sponsor and Forty Niners SC shall agree on a presenting sponsorship
of a fan-engagement or football action scoreboard feature (by way of example only, instant replays
or messages to "make noise") for each home game.

(d) Presenting Sponsorship of Regular Season Home Game. Sponsor shall be named the "presenting
sponsor" of a regular season home game, and such home game shall be given a similar theme or be
located in a similar part of the calendar each Contract Year (by way of example only, Veteran's
Day).

4. Media. The following media assets shall he provided, subject to annual review by the Parties,
based on then-existing media and Sponsor needs:

(a) Television.

(i) *** shall be played during all team-controlled television broadcast of Forty Niners preseason
games.

(ii) *** shall be played in each Total Access episode per season, including during playoffs and
re-airs. There shall be a minimum of twenty (20) episodes.

(iii) *** shall be played in each Postgame Live (or similar postgame show) per season, including
during playoffs and re-airs. There shall be a minimum of ***.

(iv) *** shall be played in each "Press Pass" or similar television show episode per season,
including re­airs. There shall be a minimum of ***.

(b) Radio. The following Sponsor commercials shall be played on Team's preseason and regular season
radio programming:

(i) *** on 49ers Insider or similar shoulder programming;

(ii) *** on pre-game radio broadcast;

(iii) *** on game radio broadcast;

(iv) *** on game radio broadcast ;

(v) *** shall be entitled with Sponsor's name (by way of example only, game time and temperature,
scoring summary, etc.);

(vi) *** on local station and affiliate network; and

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

*** Confidential material redacted and filed separately with the Commission.
<!-- page 17 -->
(vii) *** shall be played in each game broadcast on the Team's Spanish radio network.

(c) Print. Sponsor shall receive:

(i) *** in each issue of the Gameday magazine (or similar program), a minimum of ten such programs
per season, including playoffs;

(ii) *** in the annual Forty Niner Yearbook;

(iii) *** in the season ticket holder guide/handbook; and

(iv) Sponsor's logo will appear on the front of the game ticket associated with the aforementioned
presenting sponsorship of one (1) regular season home game.

(d) Online and Social Media. Sponsor and Forty Niners SC shall develop each year a package of
advertising and sponsored content on the Team's website, emails and social media (by way of example,
Twitter, Facebook, and/or YouTube).

5. Hospitality.

(a) Luxury Suite. Subject to execution of the standard executive suite license agreement with Forty
Niners SC ( Suite License Agreement"), Sponsor will receive admission tickets to *** located in the
suite tower on the Stadium's west side with access to "Champions" and "Broadcast" clubs for Forty
Niners preseason and regular season home games played at the Stadium with VIP parking passes and a
*** season-long food and beverage credit. Sponsor shall have the opportunity to purchase the suite
for the postseason at prevailing prices, as available.

(b) 49er Home Games. Sponsor shall receive the following seating package for Forty Niners preseason
and regular season home games played at the Stadium. Sponsor shall have the opportunity to purchase
the same seating package for the postseason at prevailing prices, as available:

(i) *** with access to the "West Legacy Club;"

(ii) *** on the 100 level with access to the "Champions" and "Broadcast" clubs;

(iii) *** on the 200 level with access to the "Loft" club;

(c) Sponsor Trips (Pro Bowl, Road Game). Forty Niners SC shall include *** on a road game trip
(particular game to be mutually agreed upon on an annual basis) or a similar event, as available.

(c) Super Bowl. Forty Niners SC shall include ***. In the event that the Team is a participant in
the Super Bowl, Sponsor shall be allowed to bring ***. Forty Niners SC shall make reasonable efforts
to make available additional Super Bowl tickets for purchase, based on

"

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

*** Confidential material redacted and filed separately with the Commission.
<!-- page 18 -->
availability, solely for the use, enjoyment and entertainment of Sponsor and its guests. Sponsor
agrees not to solicit or accept any direct or indirect payment or income from any person or entity
for the use of the tickets.

(d) Stadium Events. Forty Niners SC shall make commercially reasonable efforts to make tickets
available for purchase as requested to non- NFL events at Stadium.

6. Additional Events and Marketing.

(a) Database Marketing and Business to Business Opportunities. Forty Niners SC shall provide on
annual basis a list of team clients, including season ticket holders, suite holders and fans, and
shall permit Sponsor to direct market to such list(s) ***.

(b) Corporate Stadium Events. Right to host at least *** at the Team's training facility and *** at
the Stadium (by way of example only, conferences, holiday parties, etc.) with a mutually determined
food and beverage credit, staffing credits (for planning, execution and security) and a gift for
guests, with such credits dependent on the number of events held.

(c) Team Marketing Events. Sponsor shall receive VIP invitations to marketing events throughout the
year, including, annual Draft party and training camp. In addition, Sponsor shall receive a foursome
invitation to an annual golf event or equivalent sponsor appreciation event. Further, Sponsor shall
have the opportunity to utilize a display booth at the Draft party, Fan Fest and at one day of
training camp, or equivalent events.

(d) Appearances.

(i) Head Coach Appearance. Forty Niners SC shall schedule *** at a time that is reasonably
convenient for the Head Coach.

(ii) Current Player Appearances. Forty Niners SC shall assist Sponsor in securing ***. Sponsors
shall pay active players directly for such appearances.

(iii) Alumni Player Appearances. Forty Niners SC shall *** alumni player appearances per year for
Sponsor.

(iv) Cheerleader Appearances. Forty Niners SC shall schedule *** Gold Rush cheerleading appearances
upon reasonable, advance request for Sponsor events.

(v) Mascot Appearances. Forty Niners SC shall schedule *** Team mascot appearances upon reasonable,
advance request for Sponsor events.

(vi) Niner Noise Appearances. Forty Niners SC shall schedule *** Niner Noise appearances upon
reasonable, advance request for Sponsor events.

(e) Merchandise Credit. Sponsor shall receive ***, worth, measured at retail price, of San Francisco
49ers merchandise upon request. Sponsor may send requests for any

18

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

*** Confidential material redacted and filed separately with the Commission.
<!-- page 19 -->
merchandise available on shop49ers.com or any successor team-affiliated retailer) to Forty Niners SC
for fulfillment.

(f) Autographed Memorabilia. Sponsor shall receive ***. Such autographs shall be signed by players
who are members of the Team's active roster and Forty Niners SC shall make reasonable efforts to
accommodate Sponsor's requests for specific players.

7. Community Relations. Sponsor will receive a presenting or integrative sponsorship of ***
community program (by way of example only, 49ers Academy, Habitat for Humanity build, etc.); ***
foundation event (by way of example only, Pasta Bowl, Winter Fest), and *** youth football event (by
way of example only, camp, awards).

19
<!-- page 20 -->
Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

SCHEDULE 2

Team MARKS
<!-- page 21 -->
Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

SCHEDULE 3

SPONSOR MARKS

[Please insert logo here.]

Confidential Treatment Requested. Confidential portions of this document have been redacted and have
been separately filed with the Commission.

*** Confidential material redacted and filed separately with the Commission.
<!-- page 22 -->
SCHEDULE 4

RENDERINGS OF SPONSORSHIP RIGHTS

The attached renderings represent the Parties' current expectations of development of Sponsor's
branded areas, as described in detail on Schedule 1. Sponsor acknowledges that all signage is
subject to SCSA approvals and construction/engineering alterations.

***
