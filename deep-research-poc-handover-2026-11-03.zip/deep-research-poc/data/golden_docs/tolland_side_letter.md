<!-- page 1 -->
# Side Letter — Tolland Precision Components
| Field | Value |
|---|---|
| Document Type | Side Letter |
| Effective Date | 2025-06-18 |
| Parties | Tolland Precision Components Corp.; Northgate Capital Bank |
| Facility ID | FAC-2025-0193 |
| Version | Side Letter |

2025-06-18
To: Tolland Precision Components Corp., 2200 Industrial Parkway, Hartford, Connecticut 06103
From: Northgate Capital Bank, as Administrative Agent, on behalf of the Lenders
Re: Credit Agreement dated as of 2025-06-18 (facility FAC-2025-0193) — Reporting Accommodation

This side letter forms part of the Loan Documents and records an accommodation agreed among the parties at closing.
<!-- page 2 -->
## 1. Reporting Accommodation
Notwithstanding Section 6.1(b) of the Credit Agreement, the Borrower may deliver quarterly financial statements within sixty (60) days after the end of each fiscal quarter during the first fiscal year after the Effective Date, and the Minimum Liquidity threshold in Section 7.3 is reduced to $2,000,000 for the same period.
## 2. Notices
Any notice under this side letter must be delivered by electronic mail to the Administrative Agent at agency.services@example.invalid, with a copy by overnight courier, and is effective one (1) Business Day after dispatch.
<!-- page 3 -->
## 3. Confidentiality; Governing Law
This side letter is confidential and may not be disclosed except to the parties' advisors and as required by law.
This side letter shall be governed by the laws of the State of New York.
Northgate Capital Bank, as Administrative Agent — By: /s/ Authorized Signatory
Acknowledged and agreed: Tolland Precision Components Corp. — By: /s/ Authorized Signatory
