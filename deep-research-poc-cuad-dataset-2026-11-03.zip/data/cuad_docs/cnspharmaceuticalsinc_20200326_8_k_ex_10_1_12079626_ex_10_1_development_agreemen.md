<!-- page 1 -->
# Development Agreement
| Field | Value |
|---|---|
| Document Type | Development Agreement |
| Agreement Date | 2020-03-20 |
| Parties | CNS Pharmaceuticals, Inc. ("CNS"); WPD Pharmaceuticals ("WPD")("Party" and collectively as the "Parties") |
| Source | CUAD v1 / CnsPharmaceuticalsInc_20200326_8-K_EX-10.1_12079626_EX-10.1_Development Agreement |

Exhibit 10.1 Development Agreement This Development Agreement (the "Agreement") dated as of March
20, 2020 (the "Effective Date") is entered into by and between CNS Pharmaceuticals, Inc. ("CNS"), a
Nevada corporation, having a business address of 2100 West Loop South, Suite 900, Houston, Texas
77027, and WPD Pharmaceuticals, ("WPD"), a Polish corporation, having a business address of ul.
Żwirki i Wigury 101, 02-089 Warszawa. CNS and WPD are sometimes referred to herein individually as a
"Party" and collectively as the "Parties." RECITALS WHEREAS, WPD is party to a sublicense agreement
dated February 19, 2019 with Moleculin Biotech, Inc. ("MBI") (the "Sublicense Agreement") to
research and develop, manufacture, have manufactured, use, export/import, offer to sell and/or sell
certain products for use in certain territories; WHEREAS, WPD is developing certain anti-viral
indications pursuant to the Sublicense Agreement; and WHEREAS, CNS has agreed to fund a portion of
the development of such indications in exchange for certain economic rights. NOW, THEREFORE, in
consideration of the covenants, conditions and agreements hereinafter set forth, and other valuable
consideration, the receipt and sufficiency of which is hereby acknowledged, WPD and CNS hereby agree
as follows: ARTICLE 1 DEFINITIONS 1.1 "Approval Achievement Date" means the earlier of the: (i) date
on which WPD receives marketing approval for a Development Product in one-half of the countries
included in the Sublicensed Territory, as defined in the Sublicense Agreement; or (ii) the payment
by WPD to CNS of Development Fees hereunder of $1.0 million. 1.2 "Business Day" means any day other
than a day which is a Saturday, a Sunday or any other day on which banks are authorized or required
to be closed in New York City, NY. 1.3 "Calendar Quarter" means the consecutive three month period
ending on one of March 31, June 30, September 30, or December 31. 1.4 "Confidential Information"
includes: (1) all information contained in documents marked "confidential" and disclosed by one
Party (the "disclosing party") to the other Party (the "recipient party") pursuant to this
Agreement; (2) orally disclosed information which is disclosed by the disclosing party to the
recipient party pursuant to this Agreement, summarized in writing, identified as "confidential" and
delivered to the recipient party; and (3) all proprietary technical information, business and
financial information, and all other information which a reasonable person would treat
confidentially that relates to the Development Products and disclosed from the disclosing party to
the recipient party, whether or not the information is marked as "confidential." Notwithstanding
anything to the contrary, CNS shall be permitted to make such disclosures as CNS determines, in its
sole discretion, is required pursuant to the Securities Exchange Act of 1934, as amended, and the
rules and regulations thereof. 1.5 "Development Fee" means 50% of the Net Sales for any Development
Products in the Development Territory. 1.6 "Development Products" means: (i) Sublicensed Products,
as defined in the Sublicense Agreement, in the field of pharmaceutical drug products for the
treatment of any viral infection in humans; and (ii) any other drug or product in the field of
pharmaceutical drug products for the treatment of any viral infection in humans that is licensed
between WPD and MBI after this date. 1.7 "Development Territory" means (i) until the Approval
Achievement Date, the Sublicensed Territory, as defined in the Sublicense Agreement; and (ii) after
the Approval Achievement Date, the Sublicensed Territory, as defined in the Sublicense Agreement,
other than Poland.

1

Source: CNS PHARMACEUTICALS, INC., 8-K, 3/26/2020
<!-- page 2 -->
1.8 "Net Sales" shall be defined in the same way as defined in Sections 6.1 (a)-(f) of the
Sublicense Agreement, as applicable only to the relevant Development Products less any "pass-thru
royalties" or "override royalty percentage" paid by WPD pursuant to the Sublicense Agreement. 1.9
"Phase II Milestone Payment" means the completion by WPD of a Phase II Study in one of the countries
included within the Development Territory, which clinical trial meets all endpoints and is
sufficient to form the basis of an application for approval of a Development Product in one
Development Territory other than Poland. 1.10 "Sale", "Sells", "Sold" means the transfer or
disposition of a Development Product, for value, to a person or entity for end use. ARTICLE 2
DEVELOPMENT AGREEMENT 2.1 Subject to the terms and conditions of this Agreement, WPD hereby agrees
to use its commercially reasonable efforts in good faith to take, or cause to be taken, all actions,
and to do or cause to be done, all things necessary, proper or desirable or advisable under
applicable laws to develop and commercialize the Development Products, with a goal of eventual
approval of Development Products in the Development Territory. In exchange for the payment by WPD of
the Development Fee to CNS, CNS hereby agrees to pay WPD the following payments: (i) within thirty
Business Days from the date of this Agreement, CNS will make an upfront payment of $225,000 to WPD;
and (ii) within thirty days of the verified achievement of the Phase II Milestone, (such
verification shall be conducted by an independent third party mutually acceptable to the parties
hereto), CNS will make a payment of $775,000 to WPD. 2.2 If after three years from the Effective
Date of this Development Agreement, WPD fails to use commercially reasonable efforts as set forth in
section 2.1 above, CNS shall have the right to terminate this Agreement pursuant to the terms
specified in Section 6.2 below, and CNS shall be entitled to the return of any payments made
hereunder. For the purpose of this clause, if WPD has expended the funds provided by CNS pursuant to
section 2.1 above on developing anti-viral indications (including all direct and indirect costs of
such development), it will be deemed to have used commercially reasonable efforts in good faith. 2.3
The first Development Fees payment shall be due forty-five days after the end of the Calendar
Quarter in which the first Sale of a Development Product took place. Thereafter, WPD shall furnish
to CNS Development Fees no later than forty-five days after the end of each Calendar Quarter for the
Sale of Development Products through the end of such Calendar Quarter and shall further furnish CNS
with a written statement setting forth an accounting showing the calculation of the Development
Fees. ARTICLE 3 INFORMATION AND USE 3.1 WPD shall furnish CNS with written reports summarizing the
progress of the research and development conducted under the Sublicense Agreement related to the
Development Products on a quarterly basis. 3.2 The Parties agree to a mutual exchange of any data,
information or know-how resulting from the research and development of the Development Products.
ARTICLE 4 OTHER COMPENSATION 4.1 If MBI exercises its right to terminate the Sublicense Agreement in
whole, or to remove a portion of the sublicensed subject matter that relates to some or all of the
Development Products, by paying to WPD the Buyback Consideration (as defined in the Sublicense
Agreement), WPD agrees that CNS shall receive the greater of (i) 50% of the Buyback Consideration
that is attributable to the field of anti-viral pharmaceutical drug products for humans (such
attribution to be mutually agreed upon by the Parties), and (ii) the amounts actually provided to
WPD pursuant to Section 2.1 of this Agreement.

2

Source: CNS PHARMACEUTICALS, INC., 8-K, 3/26/2020
<!-- page 3 -->
ARTICLE 5 CONFIDENTIALITY 5.1 During the term of this Agreement and for a period of five (5) years
thereafter, the Parties each agree that Confidential Information of the disclosing party, which is
disclosed to the recipient party pursuant to this Agreement: (i) shall be received and held in
strict confidence, (ii) shall be used only for the purposes of this Agreement, and (iii) will not be
disclosed by the recipient party (except as required by law, court order or regulation), its agents
or employees without the prior written consent of the disclosing party, except to the extent that
the recipient party can establish by competent written proof that particular Confidential
Information: (i) was in the public domain at the time of disclosure to the recipient party; or later
became part of the public domain through no act or omission of the recipient party, its employees,
agents, successors or assigns; or (ii) was lawfully disclosed to the recipient party by a third
party having the right to disclose it to the recipient party; or (iii) was already known by the
recipient party at the time of disclosure; or (iv) was independently developed by the recipient
party without use of the disclosing party's Confidential Information; or (iv) is required by law,
court order or regulation to be disclosed, provided that the recipient party so obligated to
disclose the Confidential Information shall promptly notify the disclosing party of such requirement
and provide the disclosing party an opportunity to challenge or limit the disclosure requirement and
to seek confidential treatment or protection order, and that the Confidential Information so
disclosed shall remain otherwise subject to the confidentiality and non-use obligations set forth
above in this section. Particular Confidential Information shall not be deemed to come under any of
the above exceptions merely because it is embraced by more general information that is or becomes
subject to any of the above exceptions. 5.2 Subject to full compliance with Section 5.3 below,
either party may disclose the other party's Confidential Information to its employees, consultants
and affiliates who have a need to know such information in order to satisfy such Parties obligations
under this Agreement. Such employees, consultants and affiliates shall be required to agree to
maintain the confidentiality of such information pursuant to terms no less restrictive that the ones
set forth herein. 5.3 Each Party shall protect the other party's Confidential Information with at
least the same degree of care as it uses to protect its own confidential information, but at no time
less than a reasonable degree of care. This obligation will exist while this Agreement is in force
and for a period of five (5) years thereafter. 5.4 Data Privacy and Security Laws. WPD and its
subsidiaries (if any) will at all times during the Term be in material compliance with all
applicable data privacy and security laws and regulations, and WPD and its subsidiaries (if any)
have taken or will take commercially reasonable actions to comply with the European Union General
Data Protection Regulation ("GDPR") (EU 2016/679) and all other applicable laws and regulations with
respect to Personal Data (defined below) that have been announced as of the date hereof as becoming
effective within 12 months after the date hereof, and for which any non-compliance with same would
be reasonably likely to create a material liability (collectively, the "Privacy Laws"). To WPD's
knowledge, WPD and its subsidiaries (if any) have been and currently are in material compliance with
the GDPR. To ensure material compliance with the Privacy Laws, WPD and its subsidiaries (if any)
have taken, and currently take, commercially reasonable steps reasonably designed to ensure
compliance in all material respects with Privacy Laws relating to data privacy and security and the
collection, storage, use, disclosure, handling, and analysis of Personal Data that WPD has
collected, and collects, or is in WPD's possession or will be in WPD's possession during the Term.
"Personal Data" means "personal data" as defined by GDPR. ARTICLE 6 TERM AND TERMINATION 6.1 The
term of this Agreement will commence on the Effective Date and remain in full force and effect until
the expiration of the Sublicense Agreement, unless earlier termination by pursuant to the terms of
this Agreement ("Term"). 6.2 Subject to any rights herein which survive termination, this Agreement
will earlier terminate in its entirety: (i) upon thirty (30) calendar days written notice from
either party if the other party materially breaches this Agreement, unless before the end of such
thirty (30) calendar day notice period, the breaching party has cured the material default or breach
to the non-breaching party's reasonable satisfaction; or (ii) at any time by mutual written
agreement between the Parties, subject to any terms herein which survive termination.

3

Source: CNS PHARMACEUTICALS, INC., 8-K, 3/26/2020
<!-- page 4 -->
ARTICLE 7 REPRESENTATIONS, WARRANTIES AND COVENANTS 7.1 Each Party represents and warrants that:
7.1.1 it is duly organized and validly existing under the laws of its state or country of
incorporation, and has full corporate power and authority to enter into this Agreement and to carry
out the provisions hereof; 7.1.2 it is duly authorized to execute and deliver this Agreement and to
perform its obligations hereunder, and the person executing this Agreement on its behalf has been
duly authorized to do so by all requisite corporate action; 7.1.3 this Agreement is legally binding
upon it and enforceable in accordance with its terms; that the execution, delivery and performance
of this Agreement by it does not conflict with any Agreement, instrument or understanding, oral or
written, to which it is a party or by which it may be bound, nor violate any material law or
regulation of any governmental entity having jurisdiction over it; and 7.1.4 it has not granted, and
will not grant during the term of the Agreement, any right to any third party that would conflict
with the rights granted to the other Party hereunder; 7.1.5 that it has (or will have at the time
performance is due) maintained, and will maintain, and keep in full force and effect, all
agreements, permits and licenses necessary to perform its obligations hereunder; and in complying
with the terms and conditions of this Agreement and carrying out any obligations hereunder, it will
comply (and it will ensure that its subcontractor's comply) with all applicable laws, regulations,
ordinances, statutes, and decrees or proclamations of all governmental entities having jurisdiction
over such Party. 7.2 U.S. FCPA Compliance. WPD hereby agrees to at all times comply with the U.S.
Foreign Corrupt Practices Act of 1977, as amended (the "FCPA"), and WPD shall establish, institute
and maintain policies and procedures designed to ensure that: 7.2.1 no agent, employee or affiliate
of WPD, or any of its affiliates, takes any action, directly or indirectly, that would result in a
violation by such person of the FCPA or any other anti-bribery or anti-corruption law, rule or
regulation of similar purpose and scope, including, without limitation, making use of the U.S. mails
or any means or instrumentality of interstate commerce in furtherance of an unlawful offer, payment,
promise to pay or authorization of the unlawful payment of any money, or other property, gift,
promise to give, or authorization of the giving of anything of value to any "foreign official" or
any foreign political party or official thereof, of any candidate for any foreign office or any
candidate for foreign political office, in contravention of the FCPA; 7.2.2 WPD, and its affiliates,
shall at all times keep books, records and accounts which, in reasonable detail, accurately and
fairly reflect the transactions and dispositions of their assets and maintain a system of internal
accounting controls sufficient to provide reasonable assurances that transactions are properly
authorized and recorded; 7.2.3 WPD shall, and shall cause its respective affiliates, to permit CNS
and its respective designated representatives, at reasonable times and upon reasonable prior notice
to such parties, to review the books and records of WPD and any of its affiliates and to discuss the
affairs, finances and condition of such party and any of its affiliates with the officers of such
entities and any of their affiliates in relation to their compliance with this section, as
applicable. 7.2.4 WPD understands and agrees that CNS may terminate this Agreement immediately and
without any early termination penalty in the event that WPD, or any of its affiliates, materially
violates the FCPA or any other anti-bribery or anti-corruption law. WPD understands and agrees that,
if WPD, or any of its affiliates, intends to use foreign subcontractors to provide any services
pursuant to this Agreement, such party and each of its affiliates is prohibited from engaging or
using subcontractors for performance of services under this Agreement without prior and express
authorization, in writing, by CNS. If WPD, or any of its affiliates, is authorized to engage or use
subcontractors for such work, such party and each of its affiliates so involved agrees to obtain a
commitment from the subcontractor to comply with the FCPA and any other anti-bribery or
anti-corruption law.

4

Source: CNS PHARMACEUTICALS, INC., 8-K, 3/26/2020
<!-- page 5 -->
ARTICLE 8 INDEMNIFICATION 8.1 WPD hereby agrees to hold harmless and indemnify CNS, its officers,
affiliates, employees, and agents (the "CNS Indemnitees") from and against any and all third party
claims, demands, causes of actions, costs of suit and reasonable and documented attorney's fees
(collectively "Claims") caused by, arising out of, or resulting from WPD's, its employees, agents',
affiliates', licensees', sublicensees' or subcontractors' (i) negligence or willful misconduct; (ii)
breach of any warranty or representations set forth herein; (iii) breach or alleged breach of third
party intellectual property rights; and (iv) use or sale of Development Products. ARTICLE 9
MISCELLANEOUS 9.1 The Parties shall execute and deliver any and all additional papers, documents,
and other instruments and shall do any and all further acts and things reasonably necessary, if any,
in connection with the performance of its obligation hereunder to carry out the intent of this
Agreement. 9.2 This Agreement contains the entire understanding of the Parties, and supersedes all
prior agreements and understandings between the Parties. This Agreement may be amended only by a
written instrument signed by the Parties. 9.3 The waiver by any Party of any terms or condition of
this Agreement, or any part hereof, shall not be deemed a waiver of any other term or condition of
this Termination Agreement, or of any later breach of this Agreement. 9.4 Any notice required by
this Agreement will be given by personal delivery (including delivery by reputable messenger
services such as Federal Express) or by prepaid, first class, certified mail, return receipt
requested, addressed to: If to WPD: If to CNS: WPD Pharmaceuticals sp. z o.o CNS Pharmaceuticals,
Inc. Attention: CEO Attention: CEO ul. Żwirki i Wigury 101 2100 West Loop South, Suite 900 02-089
Warszawa, Poland Houston, TX 77027 9.5 The Article and Section captions in this Agreement have been
inserted as a matter of convenience and are not part of this Termination Agreement. References to $
or "dollars" means United States dollars. 9.6 This Agreement may be executed in counterparts, all of
which together shall constitute a single agreement. 9.7 If any provision of this Agreement or
application thereof to anyone is adjudicated to be invalid or unenforceable, such invalidity or
unenforceability shall not affect any provision or application of this Agreement which can be given
effect without the invalid or unenforceable provision or application, and shall not invalidate or
render unenforceable such provision or application. Further, the judicial or other competent
authority making such determination shall have the power to limit, construe or reduce the duration,
scope, activity and/or area of such provision, and/or delete specific words or phrases as necessary
to render, such provision enforceable. 9.8 This Agreement will be governed by, construed and
enforced in accordance with the laws of the State of Texas. Any dispute between the Parties
regarding or related to this Agreement shall be litigated in the courts located in Houston, Texas,
and WPD agrees not to challenge personal jurisdiction in that forum. IN WITNESS WHEREOF, the Parties
hereto have executed this Agreement by their duly authorized representatives with full right, power
and authority to enter into and perform under this Agreement. CNS Pharmaceuticals, Inc. By____/s/
John Climaco___________________ John Climaco, CEO

WPD Pharmaceuticals SP. z o.o. By__/s/ Mariusz Olejniczak___________ Mariusz Olejniczak, President

5

Source: CNS PHARMACEUTICALS, INC., 8-K, 3/26/2020
