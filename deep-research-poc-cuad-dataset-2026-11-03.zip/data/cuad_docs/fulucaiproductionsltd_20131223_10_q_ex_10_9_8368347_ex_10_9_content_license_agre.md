<!-- page 1 -->
# CONTENT DISTRIBUTION AND LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| Agreement Date | 2012-11-15 |
| Parties | CONVERGTV, INC. (“ConvergTV”); Fulucai Productions Ltd. ("Producer") |
| Source | CUAD v1 / FulucaiProductionsLtd_20131223_10-Q_EX-10.9_8368347_EX-10.9_Content License Agreement |

CONTENT DISTRIBUTION AND LICENSE AGREEMENT Deal Terms Licensed Program/ Film or Video Inevitable
"Licensed Rights" to ConvergTV and ConvergTV Channels and/or Distribution Outlets x All, including
but not limited to: xSimultaneous Internet Streaming x OTT Television x Internet Protocol Television
x Radio, short wave, microwave, fiber optic x Alternative, secondary and specialty distribution x
Stored as VOD, Content Distribution Networks/Company Servers x Full Television Broadcast Rights: x
Free: Terrestrial, Cable, Satellite x Pay: Terrestrial, Cable, Satellite x Direct Satellite IP
Distribution Systems Licensed Territory x Worldwide ¨ Other:
_______________________________________________ License Term Perpetual, unlimited runs x Other: 2
years Commencing: November 15, 2012 Run Dates Within ConvergTV determined parameters. License
Consideration Revenue Share as specified in this CONTENT DISTRIBUTION AND LICENSE AGREEMENT.
Authorized Language Primary: x All ¨ Other (specify): ________________________________________ May
be subtitled or translated by ConvergTV into foreign language(s). Additional Terms Closed Captioned
Version, - NTSC, PAL, SEACAM or standards to be developed, provided by ConvergTV. Producer
Information Producer: Fulucai Productions Ltd. Name of Contact: James Durward Address: 3632-13 St.
SW, Calgary, Alberta, Canada, T2T 3R1 Telephone: 403-689-3901 Email: jimdurward@shaw.ca

1

Source: FULUCAI PRODUCTIONS LTD., 10-Q, 12/23/2013
<!-- page 2 -->
This CONTENT DISTRIBUTION AND LICENSE AGREEMENT (the "Agreement") is entered into as of November 15,
2012 (the "Effective Date") by and between, CONVERGTV, INC., a Delaware Corporation, ("ConvergTV"),
whose principal place of business is located at 3201 Budinger Ave., St. Cloud, FL 34769, P.O. Box
540817, Merritt Island, Florida 32954, and Fulucai Productions Ltd. (the producer, publisher,
content owner, authorized distributor, agent, or assignee of the Program rights, licensor, and
grantor, any and all referred to herein as the "Producer"), whose principal place of business is
located at 3632- 13 St. SW, Calgary, Alberta, Canada, T2T 3R1. The foregoing entities may be
individually referred to as a "Party" or may be jointly referred to as the "Parties". The Parties
agree as follow: 1. Grant of License and Rights. (a) For the License Term and within the Licensed
Territory, Producer hereby grants to ConvergTV a right and license to Distribute the program, file
or video listed on the Deal Terms above (the "Program") consisting of (check one) ¨ episodes
(series) or x one-offs, for unlimited runs for the License Term through ConvergTV channels and/or
other distribution outlets, in accordance with the License Rights. The terms "License Term",
"Licensed Rights", and "Licensed Territory" shall have the meaning specified in the Deal Terms
above, which such Deal Terms are part of this Agreement and are hereby incorporated herein by
reference. As used in this Agreement and this license, the term "Distribute" includes, but is not
limited to, any and all License Rights specified in the Deal Terms, all rights of distribution, the
right to copy and reproduce the Program, the right to create derivative works of the Program for the
purpose of creating branding elements and short form promotional materials ("Promotional Works"),
the right to sell copies, the right to import and export the Program and the Promotional Works, the
right to display the Program and Promotional Works publicity, the right to transmit the Program and
Promotional Works through any transmission or delivery method that exists today, or that is created
in the future, to any number of devices or users, including transmission through simultaneous
delivery or streaming, and the right to sublicense and/or assign some or all of these rights to
others. (b) Producer further grants to ConvergTV the right and license to Distribute the Program on
any ConvergTV channel, and/or other distribution outlets, that exists today or that is created or
developed in the future and this right includes the right to Distribute on any channels of a
ConvergTV affiliate and/or other distribution outlets without limitation. (c) Producer further
grants to ConvergTV the right and license to Distribute and re-Distribute, including relicensing or
sublicensing, the Program at such dates and times as are determined by ConvergTV in its sole
discretion. (d) Producer further grants to ConvergTV the right and license to create (re-edit), at
its sole cost and expense, new and different versions of the Program, create foreign language,
subtitled or translated versions of the Program as well as to create closed captioned versions of
the Program, including NTCS, PAL, SEACAM standards, or other standards, including those yet to be
developed.

2

Source: FULUCAI PRODUCTIONS LTD., 10-Q, 12/23/2013
<!-- page 3 -->
(e) Producer further grants to ConvergTV the right and license to utilize any and all footage from
the Program for promotional and marketing purposes related to the Distribution of the Program and
for promotion of channels or other distribution methods. (f) The grant of rights and license
pursuant to this Section 1 shall include, but not be limited to, the right of ConvergTV to
Distribute and re-Distribute all or any portions of the Program and Promotional Works, including
excerpts therefrom, and any new and different versions of the Program, on simultaneous internet
transmission or streaming, internet protocol television and any television networks and stations,
and/or other distribution outlets, via domestic or foreign television signals, as well as through
CATV and DBS systems, satellite, microwave, fiber optic and/or other modes of Distribution yet to be
developed, but which may be utilized by ConvergTV in the future. ConvergTV shall have the right to
insert commercials within the Program. 2. Delivery. (a) The Program shall be delivered to ConvergTV
utilizing English as the primary language unless otherwise specified or as indicated in the Deal
Terms. (b) The Program will conform to and be delivered in accordance with Exhibit A. (c) The
Program must be saved as executable files (NOT as playable DVD/Blu-Ray movies). (d) The Program
materials delivered to ConvergTV shall be duplicate copies, and ConvergTV disclaims liability for
any damage or loss to any original master delivered by Producer to ConvergTV. 3. Consideration. The
Producer agrees and acknowledges that it will receive no upfront compensation for the rights it has
granted herein and that ConvergTV has no obligation to Producer to exercise any of its rights under
this Agreement. The revenue share for the Program is stated in Exhibit B. The Producer shall have
thirty (30) days from the payment date to dispute the amount of any revenue share payout or any such
claim or dispute is hereby waived by the Producer. 4. Program Exclusivity For The License Term
Within The Licensed Territory . During the License Term (which is identified in the Deal Terms),
Producer agrees that ConvergTV has the exclusive right to exercise the rights granted to it under
this Agreement with respect to the Program, including those in Section 1, within the Licensed
Territory.

3

Source: FULUCAI PRODUCTIONS LTD., 10-Q, 12/23/2013
<!-- page 4 -->
5. Producer's Representations and Warranties. The Producer represents and warrants for the benefit
of ConvergTV that: (a) it: (A) has the right to enter into and perform this Agreement and to grant
ConvergTV all the rights and licenses granted by it herein; and (B) either owns the Program or
controls the exhibition and distribution rights thereto; (b) it has or will obtain, at its sole cost
and expense, all rights necessary to enter into this Agreement and to permit the exercise by
ConvergTV of the rights and licenses herein granted including any and all music synchronization and
mechanical rights and licenses as well as any and all performance rights by the artists and/or other
material susceptible to performing rights contained in the Program and that such rights that
Producer does not have or cannot obtain are within the public domain and are free to exercise by
ConvergTV; (c) neither the Program, nor the production or use of the Program, or any element of the
Program hereunder, will: (A) violate any right of privacy or any other right of any person, firm,
corporation or other entity; (B) be defamatory; or (C) infringe upon or violate any copyright,
trademark, trade name, patent or any proprietary rights of any third parties; (d) there are no
agreements, contracts, commitments or licenses, nor shall Producer enter into any agreements,
contracts, commitments or grant any licenses, which would prevent the fulfillment of this Agreement
or impair or conflict with the rights granted hereunder; (e) it has all required releases for the
Program and to grant the rights and licenses specified in Section 1, including but not limited to
personal appearance, voice, location, sync, mechanical and for any other use requiring authorization
of a person, place or thing; (f) it will not permit its Programs, other than as provided in this
Agreement, to be displayed in full length, or nearly full length, on or through any channel,
distribution or other platforms or services, or by any other means, including but not limited to the
distribution or viewing platforms or services of ConvergTV's competitors; (g) it has not violated
any law, rule, or regulation in connection with the creation or distribution of the Program; and (h)
it shall comply with the Producer Performance Standards set forth in Exhibit C. 6. Insurance. The
Producer has no insurance requirement. 7. Indemnification. Producer shall indemnify, defend and hold
harmless ConvergTV and its parents, subsidiaries, divisions, officers, directors, employees,
attorneys and agents, and their respective successors or assigns, from all costs, expenses and
damages arising from any breach or alleged breach of the warranties made by it in this Agreement.
Producer shall further indemnify, defend and hold harmless ConvergTV and its parents, subsidiaries,
divisions, officers, directors, employees, attorneys and agents, and their respective successors or
assigns, from all costs, expenses and damages arising from any costs, errors, omissions, slander,
losses, liability or for any other cause as a direct or indirect result of the Distribution,
transmission or publication of the Producer's Program or content.

4

Source: FULUCAI PRODUCTIONS LTD., 10-Q, 12/23/2013
<!-- page 5 -->
8. Protection of Copyright. (a) Producer shall take all reasonable steps to protect all copyrights
pertaining to each Program from infringement and will institute such actions and proceedings as may
be reasonable to prevent any unauthorized use, reproduction, exhibition or exploitation by third
parties of the Program or any part thereof, or the material on which the Program is based which may
be in contravention of the rights and license granted to ConvergTV herein. (b) If the Producer does
not fulfill its obligation in Section 8(a) above, ConvergTV shall have the right, but not the
obligation, to take such action as ConvergTV deems reasonable under the circumstances. For this
purpose, Producer hereby appoints ConvergTV its attorney-in-fact to act in its name to prevent any
unauthorized use, reproduction, exhibition, or exploitation of any Program or any part thereof. Any
damages awarded or settlement payments made as a result of any action taken by ConvergTV shall
belong to ConvergTV. 9. Non-Disclosure. The Producer agrees to not disclose, discuss, transcribe,
publish or share: (i) any information contained in this Agreement; or (ii) any non-public,
confidential or proprietary information as it relates to ConvergTV with any third party, including
but not limited to any individual, person, corporation, company, or distributor, except that
Producer may disclose such information or materials, to the extent reasonably necessary, to its
attorneys, auditors, consultants, shareholders, and other fiduciaries who are themselves bound by
confidentiality obligations with regarding any such disclosed information or materials. 10. Security
of Content. For Programs licensed by and/or through ConvergTV and that are resident in the ConvergTV
distribution platform, ConvergTV shall provide reasonable protections for the ConvergTV distribution
platform to prevent the unauthorized distribution, unauthorized licensing, unauthorized
sub-licensing, piracy, theft of content and/or unauthorized monetization of the Programs from the
ConvergTV distribution platform. 11. Monetization of Content. The Producer agrees and authorizes
ConvergTV, its subsidiaries, agents and/or assigns to monetize the Producer's Program and content by
traditional ad (commercial) insertion; product placement; branded programming; overlays; interactive
advertising; merchandise; utilization of brand value; syndication (theatrical, televised, mobile,
OTT, Internet, IPTV); social media television; interactive television; mobile app sales; cable,
satellite, OTT, IPTV, mobile subscriber fees; subscription and premium distribution and any and all
methods of content monetization that may now or in the future exist, by and on any and all known or
future means of content distribution. 12. Force Majeure: If either Party is prevented from
performing its obligations hereunder as a result of a force majeure event, then the non- performing
Party shall not be liable to the other Party for its failure to perform such obligations. As used in
this Agreement, force majeure shall mean any act of God, fire, flood, war, public disaster, other
calamity, strike, or labor difficulties, or any governmental determination, action, regulation, or
order, or any other occurrence beyond the reasonable control of the non-performing Party, which,
despite the non- performing Party's reasonable efforts, prevents the performance of its obligations
hereunder. In the case of a force majeure event, ConvergTV will not be responsible for payment of
any revenue share.

5

Source: FULUCAI PRODUCTIONS LTD., 10-Q, 12/23/2013
<!-- page 6 -->
13. Entire Agreement . This Agreement, which includes the Deal Terms and any and all exhibits,
schedules or attachments to this Agreement, contains the entire agreement of the Parties, and
supersedes any prior written or oral agreements between them concerning the subject matter contained
herein. There are no representations, agreements, arrangements, or understandings, oral or written,
between and among the Parties hereto, relating to the subject matter contained in this Agreement
that are not fully expressed herein. 14.. Notices. All notices, statements or requests for approvals
("Notices") that either Party hereto is required or may desire to give to the other shall be given
in writing by addressing the same to the other at the addresses set forth herein, or at such other
address as may be designated, in writing, by any such Party in a Notice to the other. Notices shall
be made by personal delivery, overnight courier, first class registered mail (postage prepaid and
return receipt requested), facsimile or e-mail. A Notice shall be deemed served and received on the
date executed on a receipt of acceptance or if by personal delivery, upon physical delivery of the
same. 15. Governing Law. All questions with respect to the construction of this Agreement, and the
rights and liabilities of the Parties hereto, shall be governed by the laws of the State of Florida.
The Parties also agree that the venue for this Agreement shall be in the County of Brevard, Florida.
The Parties expressly waive any claim to jurisdiction in any federal or other state forum or venue
in any other county or place. In the event of any controversy, claim or dispute between the Parties
hereto, including, but not limited to, any action at law or in equity, including any action for
declaratory or injunctive relief, arising out of or relating to this Agreement or the breach
thereof, the prevailing Party shall be entitled to recover from the losing Party all of his or her
actual attorney's fees and costs in bringing, prosecuting, or defending said action. 16. Successors
and Assigns. Subject to the restrictions against assignment as herein contained, this Agreement
shall be binding upon and inure to the benefit of the Parties, their predecessors, assigns,
successors in interest, personal representatives, their past and present attorneys, principals,
employees, independent contractors, officers, directors, shareholders, parents, issue, subsidiaries,
agents, servants, estates, heirs, administrators, executors, conservators, trustees, legatees, and
other affiliated entities of each of the Parties hereto. 17. Modification, Severability & Waiver .
This Agreement may not be altered, modified, or changed in any manner except by a writing executed
by the Party against whom it is to be enforced. Waiver of the breach of any of the provisions of
this Agreement shall not be deemed to be a waiver of any other breach of the same or any other
provision of this Agreement. If any term, provision, covenant or condition of this Agreement is held
by a court of competent jurisdiction to be invalid, void or unenforceable, the remainder of the
provisions shall remain in full force and effect and shall in no way be affected, impaired or
invalidated.

6

Source: FULUCAI PRODUCTIONS LTD., 10-Q, 12/23/2013
<!-- page 7 -->
18. Audit. Each of the Parties may, at its own expense, audit the other Party's compliance with this
Agreement, including but not limited to, auditing the other Party's representations and warranties.
19. Counterparts. This Agreement may be executed in any number of counterparts, each of which shall
be deemed an original and all of which together shall be deemed to be one and the same instrument.
All counterparts so executed shall constitute one agreement binding upon all Parties,
notwithstanding that all Parties are signatory to the original or the same counterpart. The Parties
may execute this Agreement by facsimile and/or electronic means and such signatures shall be treated
as original signatures for all purposes. IN WITNESS WHEREOF the Parties hereto have caused this
Agreement as of the Effective Date.

CONVERGTV, INC. by Name: Title: FULUCAI PRODUCTIONS LTD.(PRODUCER) by Name: Title:

7

Source: FULUCAI PRODUCTIONS LTD., 10-Q, 12/23/2013
<!-- page 8 -->
Source: FULUCAI PRODUCTIONS LTD., 10-Q, 12/23/2013
