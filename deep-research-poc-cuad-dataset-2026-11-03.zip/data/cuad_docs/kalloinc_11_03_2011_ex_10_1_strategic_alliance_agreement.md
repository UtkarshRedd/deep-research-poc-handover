<!-- page 1 -->
# STRATEGIC ALLIANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Strategic Alliance Agreement |
| Agreement Date | 2011-10-24 |
| Parties | KALLO Inc. ("KALLO"); Petro data Management Services Limited. ("PDMS"); Gateway Global Fabrication Ltd. ("Gateway") |
| Source | CUAD v1 / KALLOINC_11_03_2011-EX-10.1-STRATEGIC ALLIANCE AGREEMENT |

Exhibit 10.1

KALLO Inc.

STRATEGIC ALLIANCE AGREEMENT

MOBILECARE
<!-- page 2 -->
STRATEGIC ALLIANCE AGREEMENT - MOBILE CARE This Agreement is made by and between: KALLO Inc. With
principal offices at 15 Allstate Parkway, Suite 600, Markham, ON L3R 5B4., Canada ("KALLO") AND
Petro data Management Services Limited., With principal offices at Motorways Center, Block-B, 1
Motorways Avenue Alausa, Ikeja, Lagos, Nigeria ("PDMS") AND Gateway Global Fabrication Ltd., With
principal offices at No-2 Olodu Street, Off Oluobasanjo Road, Portharcourt, Rivers state, Nigeria.
("Gateway") As of the date set forth below. Whereas, Kallo is the developer, owner and licensor of
certain Mobile Care Suite of Products packages designated as the subject matter of this Agreement:
Whereas, PDMS and Gateway (Agent) desires to become a business associate of Kallo for the region of
Nigeria, under the terms and conditions hereof; Now therefore, all the parties agree as follows:

For the purposes of this Agreement, the following definitions will apply: "Business Associate" means
the Kallo Authorized Agent who could be an individual, organization, or company that desires to
represent the Kallo Mobile care suite of products of Kallo Inc., to the end user (customer) market.
The Business Associate as it will be defined in this agreement sells the Kallo Mobile care product
suite only. Kallo will be fully responsible for the training and implementation of the client

KALLO - MOBILECARE

1.DEFINITIONS

Page 2
<!-- page 3 -->
following the sale directly by Kallo Inc., or through it's wholly owned Canadian subsidiary, Kallo
Technologies Inc., "KALLO" means Kallo Inc. and/or its wholly owned subsidiary Kallo Technologies
Inc., "Customer" means the end user of the Kallo Mobile care suite of Products that enters into the
Kallo Mobile care Suite of Products End User License Agreement (EULA). "Schedule A" means the Kallo
supplied executable pricing proposal form which must accompany any EULA for the Kallo Mobile care
suite of Products in order to be accepted by Kallo. "Kallo Mobile care suite of Products" means
Kallo products as specified in Schedule A. "EULA" means the license agreement (headed "End User
License Agreement") between the Customer (end-user) and Kallo that sets forth the terms and
conditions governing the Customer's use of the Kallo Mobile care suite of Products. "Book of
Business" means the sales made by the Agent with the flow of income from those sales paid under this
Agreement, all of which belongs to the Agent in right, title and interest. The Book of Business is
that portion of each sale belonging to the Agent under the commission percentage agreed to at the
time of sale and the continuing flow of income produced so long as the customers pay to use the
Kallo Mobile care suite of products license. "Material Breach" means the violation of the payment
terms herein, copyright or trademarks, an attempt to replace or abet others to replace Kallo Mobile
care suite of products or services at any existing or potential customer with competing products and
any act of malicious conduct by the Agent to disparage Kallo without any justification and malicious
conduct against Agent by Kallo. "Non Material Breach" means serious neglect of Agent's customers by
the Agent in regards to support and services and any other breach of the terms of this agreement for
which the cure of such shall be completed by the Agent within sixty days from written notice of
violation. "Certified Sales Agent" means a Sales Agent who has completed the initial Sales and
Technical Training program and any consecutive

KALLO - MOBILECARE

Page 3
<!-- page 4 -->
training program provided and mandated by Kallo and who abides by the terms and conditions of the
certification program as outlined herein.

KALLO - MOBILECARE

2.KALLO SALES AGENT PROGRAM TERMS AND CONDITIONS

a) Appointment: Kallo hereby conditionally appoints Agent as a Sales Agent, and Agent accepts in
accordance with the provisions of this Agreement the terms of the Kallo Sales Agent Program.

b) Responsibilities: Responsibilities of the Agent (PDMS and Gateway) are defined in Schedule C.
Failure to comply with this will be considered a material breach of this agreement. This also
includes responsibilities for Kallo and the project management entity (BASCIC) appointed jointly by
Kallo and the Agent.

c) Certified Sales Agent: Agent accepts and acknowledges that the Kallo 3 day Sales and 5 day
Technical Training Program is required to be completed by the Agent within 90 days of execution of
this agreement. Agent is required to pay a Training program fee of $10,000.00 for the Kallo Mobile
care suite of Products on or before the date of execution of this agreement for the Authorization of
Agent under this agreement by Kallo. Agent shall pay $1000/- per day for any additional days of
training requested by Agent and all travel expenses plus per diem for the Kallo representative
instructing the program will be due and payable to Kallo on or before execution of this agreement.
Certification is mandatory for Agent to become certified to represent the Kallo Mobile care suite of
products licensed under this agreement and to benefit from commissions allocated to Agent as
outlined in Schedule A of this agreement. Non-compliance of this Section (2), subparagraph (c) on
the part of the Agent will automatically void this agreement.

d)All sales made by the Agent of the Kallo Mobile care suite of products shall create a Book of
Business owned by the Agent, which constitutes all funds due to Agent under this agreement flowing
from each sale for a period not to exceed 36 months from the date of acceptance by Kallo of the
Client EULA or until the EULA terminates under the provision that are outlined therein of the Kallo
Mobile care suite of products.

e)Agent is required bi-monthly to report all prospects, sales activity, activity reported on Kallo
provided leads, and any current client

Page 4
<!-- page 5 -->
accounts relating to the Kallo Mobile care suite of products to the Kallo Sales and Marketing
department in an electronic format following the execution of this agreement. Kallo offers and
enforces lead and current account protection for Sales Agents. Kallo shall not allow another Agent
to solicit the existing Agents book of business unless it is understood by all parties the end user
client desires the transfer. Kallo shall use its best reasonable efforts to protect the Agent from
aggressive solicitation by another Agent taking any part of the Agent's book of Business. The report
MUST include the Business Name, Key Contact name, telephone number, and address.

KALLO - MOBILECARE

f) Exclusivity of territory (Nigeria): Agent's appointment shall be exclusive for the Kallo Mobile
care suite of products and services marked in Schedule A to this Agreement. Such appointment
constitutes a grant of specific territory of Nigeria. Exclusivity is granted for the region of
Nigeria, The Agent is expected to confirm the first purchase order as per Schedule D with the down
payment within thee (3) months of execution of this agreement and in order to retain the exclusivity
of the territory the Agent shall achieve the target commitment in Schedule D.

g)Agent shall be supplied with marketing material at no cost to agent in electronic format only.
Print and mail expense are the responsibility of the Agent. Web design services, press release
services, trade show design services, marketing content services, and listing services are provided
at no cost to Agent as it relates to the Kallo Mobile care suite of products

h) Marketing and Sales Plan: The Agent shall prior to the signing of this agreement submit and have
approved by Kallo a Marketing and Sales Plan for no less than 3 years committing the sale of no less
than 15 Mobile Medical Clinics, 5 Mobile Clinics in twelve month period following the signing of
this agreement as referred to in Schedule D, with minimum growth per annum thereafter of 20%
cumulative. Failure to do this will be considered a material breach of this agreement.

i)Kallo shall not change the marketing and sales plan during this agreement without first discussing
it with Agent and in the event that mutual agreement cannot be reached will provide at least 12
months' notice of any such change. Should agreement not be reached, Agent may maintain its existing
"book of business" and cease making sales under this agreement without prejudice so

Page 5
<!-- page 6 -->
long as Agent meets its support obligations to its clients and financial obligations to Kallo.

KALLO - MOBILECARE

j) Competence: Agent agrees to comply in full with Section (2). Subparagraph (c) of this agreement
and provide and acquire appropriate staffing, training and any other requirements for the marketing,
and sales of the Kallo Mobile care suite of products, and to comply with the Kallo training,
support, shipping and payment terms.

k) Conduct: Agent shall undertake no acts injurious to the business or goodwill of Kallo. Agent
shall use its best efforts to promote Kallo and its products and service and shall promptly report
and follow up all leads provided. Agent may not offer or promote competitive products without the
consent of Kallo.

l) Independent Entities: Notwithstanding the use of the designation "Sales Agent". Agent is an
independent contractor and shall at no time have the power i.to bind Kallo; ii.to alter or change
any terms, conditions, warranties or covenants made by Kallo or iii.to create in favor of any person
any rights, which Kallo has not previously agreed in writing.

m) Form of Relationship: The relationship under this Agreement shall not create any legal
partnership, franchise relationship, agency or other form of legal association between the parties,
which would impose a liability of one party upon the other.

n) Insurance: Agent or its successors shall maintain during the term of this Agreement and while it
is still responsible for its Book of Business: i.All required workers' compensation or similar
insurance; ii.Comprehensive general liability insurance. Agent shall promptly supply Kallo with
proof of such insurance upon request. Kallo shall maintain comprehensive general liability and
errors and omissions insurance for the Kallo Mobile care suite of products. Kallo shall promptly
supply Agent with proof of such insurance upon request.

o) Records: Agent shall supply to Kallo the full business data of each customer as a qualified
prospect and at the time of sale and shall, during this Agreement and while it is still responsible
for its

Page 6
<!-- page 7 -->
Book of Business, and for a period of one year after the termination of this Agreement maintain
records sufficient for Kallo to verify amounts due under this Agreement relating to the contracts,
invoices, accounts, complaints, and other transactions relating to the placement and licensing of
the Kallo Mobile care suite of products. Kallo may directly, or through its Agent at any time during
normal business hours, upon no less than 10 business days' notice, and for any reason inspect such
records and other financial information relevant to Kallo Mobile care suite of products as sold by
Agent to its end users, solely for the purpose of verifying amounts due under this Agreement. Any
such information will be confidential information of Agent subject to the provisions of Section 4.

Warranties:

KALLO - MOBILECARE

p) Sub-Agents: Agent shall not be permitted to establish sub-Agents without the express written
consent of Kallo.

q) Corrupt Practices: Agent represents that it will not make any payment or transfer anything of
value, directly or indirectly, to any government official or employee; to any officer, director,
employee, or representative, or Agent of any actual or potential customer; or to any other person or
entity if such payments would violate applicable laws.

r) Prospects: Agent will provide Kallo with a list of active prospects on a regular basis as
outlined in Section (2) Subparagraph (e) of this agreement. Kallo will use its best efforts to
protect these prospects from being solicited by its other Agents or distributors, and to refrain
from solicitation directly by Kallo, while taking into account prospect's wishes, and in as much as
allowed by applicable laws. Agent in return agrees to respect active prospect lists of Kallo's other
Agents. For the above purposes, the Agent at least once every six (6) weeks and where details of
each such contact are logged with Kallo define an active prospect as a prospect that is contacted.

3.WARRANTY AND LIMITATIONS

a)Kallo represents and warrants to Agent that; i.it has sufficient right, title and interest in and
to the Kallo Mobile care suite of products to enter into this Agreement; and ii.all Kallo Mobile
care suite of products distributed to Agent is free and clear of all liens.

Page 7
<!-- page 8 -->
Limitation of Warranties:

KALLO - MOBILECARE

b)Kallo Mobile care suite of products' Warranties Agent's exclusive warranty regarding the Kallo
Mobile care suite of products is set forth in the applicable EULA provided with the Kallo Mobile
care suite of products.

c)Except as stated above, Kallo makes no other warranties regarding the Kallo mobile care suite of
products and documentation, and any services provided by Kallo including, without limitation,
express or implied warranties, and expressly disclaims the warranties of fitness for a particular
purpose or merchantability, and any other warranty, express or implied.

d)In no event shall Kallo be liable for indirect, consequential, or incidental damages (including
damages for loss of business profits, business interruption, loss of business information, and the
like) arising out of the relationship between Kallo and Agent even if it has been advised of the
possibility of such damages.

e)Kallo's cumulative liability under this agreement, including any cause of action in contract, tort
or strict liability, shall be limited to the license fees paid by agent during the 12 months prior
to such event. Kallo's limitation of liability is cumulative with all Kallo's expenditures to
address liability being aggregated to determine satisfaction of the limit. Agent releases Kallo from
all obligations, liabilities, claims or demands in excess of the limitation. The parties acknowledge
that other parts of this agreement rely upon the inclusion of this section and the resulting
allocation of risks.

f) Agent Actions: Kallo shall have no obligation to any party under any warranty given by Agent, its
Agents or employees. Agent shall not make any representation or warranty with respect to the Kallo
Mobile care suite of products other than those stated by Kallo in its written warranty,
documentation and literature.

g) Agent Indemnification: Agent agrees to indemnify Kallo and to hold it harmless from and against
any loss, damage, claims or demands whatsoever arising out of Agent's activities that are outside
the scope of the EULA provided by Kallo to the end user regarding use of Kallo Mobile care suite of
products. Kallo makes its representations and warrants to the end user and limits

Page 8
<!-- page 9 -->
of liability therein via the EULA.

Each party agrees not to disclose any confidential information received from the other in any form
to any employees who do not have a specific need to use such information or to any outside party
(including contractors) without the other party's prior written consent. All employees or
contractors who receive such confidential information must be bound by written agreement not to
disclose such information to any other party. Each party acknowledges that the unauthorized
disclosure or use of confidential information of the other party would cause irreparable harm and
significant injury to the other party that may be difficult to compensate. Accordingly, each party
agrees that the other party will have the right to seek and obtain temporary and permanent
injunctive relief in addition to any other rights and remedies it may have. The obligations of
confidentiality shall not apply to information which;

KALLO - MOBILECARE

h) Complaints: Agent shall make all reasonable efforts to handle all incidents of customer
complaints or demands regarding the Kallo Mobile care suite of products and shall report promptly to
Kallo all such incidents.

i) Kallo indemnification: Kallo agrees to indemnify Agent and to hold it harmless from and against
any loss, damage, claims or demands whatsoever arising out of: i.Intellectual property infringement
arising from the Kallo Suite of Products; ii.Breach of implied warranty or negligence.
iii.Activities that are outside the scope of the EULA provided by Kallo and issued to the customer
through Agent regarding the use of the Kallo Mobile care suite of products. Kallo further agrees to
indemnify AGENT and to hold it harmless from and against any loss, damage, claims, or demands
whatsoever arising out of Kallo's activities that are outside the scope of this Agreement.

4.CONFIDENTIALITY

i.is in public domain at the time of disclosure, ii.has been released by the other party without
restrictions, iii.has been lawfully obtained by the disclosing party from a third party under no
obligation of confidentiality, or iv.is independently developed by employees of the disclosing party
without access to the confidential information.

Page 9
<!-- page 10 -->
Kallo reserves the right to revoke or limit the use of Trademarks at any time upon reasonable
notice. Non- Compliance with Trademark and Logo Policies shall be considered a material breach of
this Agreement.

If at any time Agent acquires any rights in, or any registration or application for, any of the
Trademarks by operation of law or otherwise, it will immediately, upon request by Kallo and at no
expense to Kallo, assign such rights, registrations, or applications to Kallo, along with any and
all associated goodwill.

KALLO - MOBILECARE

5.TRADEMARKS

a) Definition: "Trademarks" means any and all current or future company names, product names, marks,
logos, designs, trade dress and other designations or brands used by Kallo in connection with its
products and services and all marks similar thereto.

b) License: Kallo grants Agent the right to use the Trademarks solely for the purpose of
distributing and marketing the Kallo Mobile care suite of products provided that Agent: i.uses the
appropriate Trademarks for the corresponding Kallo Mobile care suite of products; ii.Identifies all
Trademarks are registered trademarks of Kallo; iii.take reasonable steps to modify all objectionable
uses of the Trademarks.

c) Ownership: Agent acknowledges that Kallo is the sole owner of the Trademarks and nothing herein
shall grant to Agent any right or interest in the Trademarks. Agent shall not register, or attempt
to register, any Trademarks or any marks confusingly similar thereto in any jurisdiction.

d) Limitations: Except as stated above, Agent is granted no right, title, license or interest in the
Trademarks. Agent acknowledges Kallo's rights in the Trademarks and agrees that any and all use of
Trademarks by Agent shall inure to the sole benefit of Kallo. Agent agrees that it shall take no
action inconsistent with Kallo ownership of the Trademarks and agrees not to challenge Kallo's
rights in or attempt to register any of the Trademarks, or any other name or mark owned or used by
Kallo or any mark confusingly similar thereto.

e) Notification: Agent shall promptly notify Kallo of any use by any third party of Trademarks or
any use by such third parties of

Page 10
<!-- page 11 -->
similar marks which may constitute an infringement or passing off of Trademarks. Kallo reserves the
right, in its sole discretion, to institute any proceedings against such third party infringers and
Agent shall refrain from doing so itself. Agent agrees to cooperate fully with Kallo in any action
taken by Kallo against such third parties, provided that all expenses of such action shall be borne
by Kallo and all damages which may be awarded or agreed upon in settlement of such action shall
accrue to Kallo. Refer to Schedule B for available means of communication to all parties concerned.

KALLO - MOBILECARE

f) Co-Branding: Kallo agrees for co-branding needs with local government and sponsors logo. This is
subject to: i.The submission to and approval by Kallo of the recommended Logo I Product Name. This
is to ensure that the overall look and feel of the Kallo Mobile care product is maintained. ii.The
supply of the Logo I Product Name in suitable high quality format allowing sufficient time as
defined by Kallo to incorporate co-branding logo on the Mobile clinics. iii.Kallo agreeing to this
will, in no way reduce, undermine, alter or limit their rights as outlined in section 5 and 6 of
this agreement.

6.PROPRIETARY RIGHTS

a) Ownership: Agent understands and agrees that Agent takes title only to the media on which the
Kallo Mobile care suite of products is provided. Title in and ownership of all copies of Kallo
products and documentation, Trademarks and all property rights therein, shall remain at all times
vested in Kallo. Agent acknowledges that the Kallo Mobile care suite of products is protected by
domestic and international copyright and other forms of proprietary rights and agrees not to copy or
otherwise reproduce (except as required for distribution to customers), modify, adapt, translate,
reverse engineer, decompile, disassemble or create derivative works based on the Kallo Mobile care
suite of products or the documentation.

b) No Rights Granted: No provision in this Agreement shall be interpreted as an assignment or grant
to Agent of any right, title or interest in the Kallo Mobile care suite of products, documentation
or Trademarks.

c) Protection: Agent agrees to take any reasonable step necessary to protect the proprietary rights
of Kallo and its

Page 11
<!-- page 12 -->
suppliers or licensors, including, but not limited to, the proper display of copyright, trademark,
trade secret and other proprietary notices on any copies of the Kallo Mobile care suite of products.
Agent must reproduce and include any such notices, other legends and logos on any backup copies.

Any printed reference to Kallo products must include the following notice (or such notice as
required by Kallo) with: © Kallo Inc., [YEAR]. All Rights Reserved.

KALLO - MOBILECARE

d) Copyright Notice: Agent agrees not to remove and shall reproduce and include all copyright
notices or confidential or proprietary legends in and on all copies of Kallo Mobile care suite of
products or documentation.

e) Breach: Agent understands and agrees that the protection of Kallo rights in and to the Kallo
Mobile care suite of products, documentation and Trademarks and the prevention of any unauthorized
copying, reproduction, modification, adaptation, translation, reverse engineering, de-compilation,
disassembly and creation of derivative works, is of the essence of this Agreement and that any
failure on its part, however minor, to discharge its obligations shall constitute a material breach
of this Agreement.

7.TERM AND TERMINATION

a) Term: This Agreement shall enter into effect on the date it is signed by both parties as shown
below.

b) Termination: This agreement shall terminate:

i.upon notification of a Material Breach that is not cured within 10 business days thereafter;
ii.Failure to cure a non-material breach within sixty days of written notice; iii.Automatically,
unless otherwise agreed between parties, in the event that Agent is the subject of a proceeding in
bankruptcy which is not dismissed within 60 days, is placed in receivership, or makes an assignment
for the benefit of its creditors; or by iv.Termination for "Cause" by giving 3 months written notice
by the Agent or Kallo. If given by Kallo, "Cause" shall be defined as non-performance on the part of
the Agent by failing to make sufficient efforts to market the Kallo Mobile care suite of products.
Should the parties disagree as to what constitutes "sufficient marketing efforts", the issue will be
submitted to binding arbitration. This course of action is not intended to be a means for

Page 12
<!-- page 13 -->
Kallo, its successors or assigns, to take over the successful operation of Agent's business
generated under this agreement without fair and just compensation.

KALLO - MOBILECARE

c) On Termination: Notwithstanding any terms of this agreement to the contrary, upon termination of
this Agreement for any reason whatsoever, Kallo, unless otherwise agreed, shall set aside the
Agent's Book of Business to be held by Kallo.

i.The revenue stream defined by the Book of Business at the time Kallo becomes the controlling party
will remain constant except in as far as any elected reduction in use by its customers. Any increase
in use will not be to the benefit of the Book of Business. ii.Kallo shall pay over all funds
collected from the Book of Business and due to Agent, less a reasonable administration fee to be
assessed and determined by Kallo, to Agent or its designees or assigns immediately upon receipt and
act as a conduit for Agent funds, except in as far as Kallo or its assignees are required to support
customers in the Book of Business in which case the cost of providing such support, will be
reasonably assessed and appropriate deductions made before passing the balance to Agent. In the
event Agent does not agree with the costs described in this section, the issue will be submitted to
binding arbitration. iii.Kallo shall make an accounting of funds collected to Agent or their assigns
monthly. Kallo shall permit Agent or its designated Agent(s) to inspect Kallo's books upon Agent's
request at Agent's expense during normal business hours of Kallo. iv.Kallo's failure to perform its
duties in the event it becomes the controlling party of the Agent's Book of Business is a
non-material breach of this agreement. v.In any dispute or litigation over the terms of this
agreement, the prevailing party shall have reasonable attorney fees in addition to any settlement or
damages awarded.

d) Rights: Upon termination of this Agreement for any reason and unless otherwise agreed, all rights
granted to Agent shall immediately cease and Agent shall immediately return to Kallo all Kallo
Products and confidential information provided by Kallo except as otherwise provided in this
Agreement.

e) No Compensation: In the event of an agreed termination of this Agreement by both parties, neither
party shall be liable to the

Page 13
<!-- page 14 -->
other for damages, losses, or expenses of any kind or character on account of the termination of
this agreement in accordance with its terms, whether such damage, loss, or expense may arise from
the loss of prospective customers of Agent, or expenses incurred or investments made in connection
with the establishment, development, or maintenance of Agent's business. Termination or expiration
shall not affect any claim, demand, or liability of any party created or arising hereunder prior to
such time.

All Kallo Mobile care suite of products distributed by Agent shall be transferred solely in Kallo
standard packaging and through the terms of the appropriate Kallo Mobile care suite of products EULA
between the customer and Kallo provided by Kallo from time to time. Delivery of copies of the Kallo
Mobile care suite of products to Agent is made solely to enable Agent to exercise this right. Agent
shall not license or transfer any Kallo product for the purpose of retransfer by or to others.

KALLO - MOBILECARE

8.FORCE MAJEURE

a) Definition: "Force Majeure" shall mean any event or condition not reasonably within the control
of either party, which prevents in whole or in material part the performance by one of the parties
of its obligations hereunder or which renders the performance of such obligations as difficult or
costly as to make such performance commercially unreasonable.

b) Notice: Upon giving notice to the other party, a party affected by an event of Force Majeure
shall be released without any liability on its part from the performance of its obligations under
this Agreement, except for the obligation to pay any amounts due and owing hereunder, but only to
the extent and only for the period that its performance of such obligations is prevented by the
event of Force Majeure. The other party may likewise suspend the performance of all or part of its
obligations hereunder to the extent that such suspension is commercially reasonable. Refer to
Schedule B for available means of communication to all parties concerned

9.ADDITIONAL PROVISIONS

a) Rights: Kallo grants to Agent the non-exclusive and non-transferable right to distribute the use
of the Kallo Mobile care suite of products to commercial end user customers. Refer to section (2)
subparagraph (f) for non-exclusive and exclusive status and qualifying requirements.

Page 14
<!-- page 15 -->
This Agreement is not assignable by Agent without prior written consent by Kallo. In the event Agent
changes its legal structure or undergoes a substantial change in ownership of its stock or other
ownership interest, Kallo shall have the option of immediate termination of this Agreement. Kallo
may assign this Agreement and its interest in the Kallo Mobile care suite of products to any party
without the consent of Agent. This Agreement shall inure to the benefit of any successor of Kallo
and shall not be affected by any change in the ownership or control of Kallo. Agent shall re execute
this agreement within 60 days of the effective date of the change in ownership or change in legal
structure or change of name. "Substantial change" in ownership is defined as a change in at least
51% ownership of the Agent.

KALLO - MOBILECARE

b) Limitations: Agent shall distribute only Kallo Mobile care suite of products that Agent has
obtained from Kallo and not from any other seller of the Kallo Mobile care suite of products. For
Tax reasons such distribution is deemed to take place at the Agent's business location identified
above.

c) Pricing: The pricing given in Schedule A is the transfer price from Kallo to the Agent and the
Agent shall, in its discretion establish a reasonable price for each of the Kallo Mobile care suite
of products EULA as per Schedule A. For Maintenance Contract pricing and details refer to Schedule
A, section (9), subparagraph (B). Kallo reserves the right to revise and republish prices as shown
in Schedule A from time to time.

d) Payment terms: For each Kallo Mobile care suite of products license ordered by Agent from Kallo,
Agent shall pay to Kallo the transfer price set forth in Schedule A. 50% of the total amount to be
paid with the signed purchase order, 35% upon shipping of the goods to the carrier at Canadian port
and 15% upon completion of the installation. Upon delivery of the system the Agent is responsible
for getting the signed EULA from the customer before the installation process starts.

e) Taxes: All taxes from the country of origin and destination including customs duty, withholding
taxes, any other levies - international / local and freight and insurance are to the end-user or
customers account. The Agent will work with Kallo to add all applicable taxes to the pricing given
in Schedule A and should be paid to Kallo along with the purchase order and the 50% of the value of
the total system

10.ASSIGNMENT

Page 15
<!-- page 16 -->
KALLO - MOBILECARE

11.MISCELLANEOUS

a) Complete Agreement: This agreement and the provisions of the current sales agent program
guidelines, as amended from time to time, constitute the entire agreement of the parties with
respect to the subject matter hereof and supersede all previous agreements by and between Kallo and
agent as well as all proposals, oral or written and all prior negotiations, conversations or
discussions between the parties related to this agreement. Agent acknowledges that it has not been
induced to enter into this agreement by any representations or statements, oral or written, not
expressly contained herein.

b) Amendment: This Agreement shall not be deemed or construed to be modified, amended, rescinded,
cancelled or waived, in whole or in part, except by written amendment signed by the parties hereto.
Refer to Schedule B for available means of communication to all parties concerned.

c) Unenforceability: If any provision of this Agreement is held to be invalid, illegal or
unenforceable, such provision shall be considered severable from this Agreement and the remaining
provisions shall continue in full force and effect. The parties will replace a severed provision by
a provision, which is closest to the intent of the parties.

d) Notices: Notices permitted or required to be given hereunder shall be deemed sufficient if given
i.by registered or certified mail, postage prepaid, return receipt requested, addressed to the
addresses given in schedule B or such other addresses as the respective parties may designate by
like notice from time to time, or ii.by international courier, telefax to or by email, the details
of which are given in Schedule B. iii.Any notice shall be deemed effective when received by the
receiving party.

e) Governing Law and Jurisdiction: The laws of the province of Ontario, Canada, govern this
AGREEMENT and, in respect of any dispute, which may arise hereunder; Agent consents to the
jurisdiction of the federal and provincial courts of Ontario, Canada.

f) Counterparts: This Agreement shall be executed in two or more counterparts in the English
language and each such counterpart shall be deemed an original hereof.

Page 16
<!-- page 17 -->
KALLO - MOBILECARE

g) Waiver: No failure by either party to take any action or assert any right hereunder shall be
deemed to be a waiver of such right in the event of the continuation or repetition of the
circumstances giving rise to such right.

h) Government: If Agent is acting on behalf of any unit or agency of the United States Government,
the following provisions apply: i.any products Agent acquires under this Agreement for or on behalf
of the United States Government are provided to the United States of America with restricted rights.
Use, duplication, or disclosure by the U.S. Government is subject to restrictions as set forth in
subparagraph (c)(l)(ii) of the Rights in Technical Data and Computer Kallo Mobile care suite of
products clause at DFARS 252.277-7013 and paragraph (d) of the Commercial Computer Kallo Mobile care
suite of products-Restricted Rights clause at FAR 52.227-19; ii.Kallo grants Agent the right to
transfer Kallo Mobile care suite of products to the United States government subject to the
following restrictions. With the exception of the Department of Defense, you will not distribute the
Kallo Mobile care suite of products to the United States of America except: a.on terms at least as
restrictive as those set forth in subparagraph (c)(l)(ii) of the Rights in Technical Data and
Computer Kallo Mobile care suite of products clause at DFARS 252.227-7013 and paragraph (d) of the
Commercial computer Kallo Mobile care suite of products -Restricted Rights clause at FAR 52.227-19,
and b.in compliance with particular department or agency acquisition regulations that provide Kallo
protection at least equivalent to that provided by the above-referenced DFARS and FAR provisions.

i) Export Restrictions: Agent expressly agrees to neither directly or through third parties export
nor transmit any Kallo Mobile care suite of Products to any country to which such export or
transmission is restricted or prohibited by applicable regulations or statutes, or any country other
than the United States of America or Canada.

j) Non-Disparagement: During the term hereof and for a period of two years thereafter, each of Agent
and Kallo agrees that it will refrain from making any representation, statement, comment or any
other form of communication, whether written or oral (hereinafter collectively referred to as a
"Communication"), to any third party, including but not limited to the principals, customers,
suppliers and competitors of the other party, which Communication reflects any opinion, judgment,
observation or

Page 17
<!-- page 18 -->
representation of fact, which has the effect or tendency to, or could have the effect or tendency
to, disparage, denigrate, criticize or otherwise reflect negatively on the other party and/or the
other party's products, services, officers, directors, shareholders, employees or investors (a
"Disparaging Communication"). Each party agrees that it will use all reasonable commercial efforts
to prevent its employees from making any Disparaging Communications regarding the other party and/or
the other party's products, services, officers, directors, shareholders, employees or investors;
provided, however, that nothing in this Section (11), subparagraph (j) shall restrict or impede the
exercise of any rights or remedies of a Party under this Agreement. In Witness Whereof, the Parties
hereto have executed this Agreement as of the date below. And confirm, we have read, understood and
agree to the terms of the strategic alliance agreement - mobile care

KALLO - MOBILECARE

Kallo Inc. JOHN CECIL Signature John Cecil Name Chairman & CEO Title Markham, ON 24 OCT 2011 Place
Date Petro data Management Services Limited Gateway Global Fabrication Ltd., BABAJIDE SOYODE AJAI
KUNNATH Signature Signature Babajide Soyode Ajai Kunnath Name Name Chairman & CEO President & CEO
Title Title Ikeja, Lagos, Nigeria 24 OCT 2011 River State, Nigeria 24 OCT 2011 Place Date Place Date

Page 18
<!-- page 19 -->
SCHEDULE - A Description of Kallo Mobile care suite of products

The Kallo Mobile Medical Clinics are one of a kind in the world having all the diagnostic capability
for basic to mid tier specialty medical care and these units can be used in the following areas to
augment healthcare delivery services. Places where there is no hospitals or clinics and emergency
situations The Mobile Medical Clinics can be taken by road to these areas and patients or
causalities can be taken into the vehicle and treated immediately with effective and real-time
consultation with specialists via satellite. Hospitals where there is no technology available for
diagnosis and treatment The Kallo Mobile Medical Clinics can be driven to, and parked in existing
hospitals and patients can get the latest in technology for diagnosis and treatment, thus many
hospitals in villages and rural areas can be upgraded in their healthcare services with latest
equipment for diagnosis and treatment with the specialist care through remote tele-consultation. The
Kallo Mobile Medical Clinics are designed to take comprehensive health care services (preventive,
promotive and curative) to rural remote villages and will reach out to the most underprivileged but
needy people across the country. The services provided are outpatient services,
Ante-natal/post-natal services, identification of difficult pregnancy and referral for institutional
care, Immunization- Mother & children, Minor surgery, BP examination, X-ray, ECG, First Aid,
Distribution of Iron Folic tablets, Vit-A Prophylaxis, Treatment of mal-nutrient cases, etc.

KALLO - MOBILECARE

1.Mobile Acute Care Clinic

Page 19
<!-- page 20 -->
The Mobile Chemotherapy Clinic serves as an extension to the chemotherapy administration in the
regional Oncology departments of the teaching / general hospitals or dedicated Cancer hospitals.
Blood work is performed the day before and a nurse is then able to contact the patient in advance to
review test results and schedule treatment sessions and advise pre-treatment preparation of the
patient. Chemotherapy drugs and related equipment, all individually packaged for each patient, is
received from the Regional Cancer hospital command center. Chemotherapy chair that includes a
chair-side touch-screen interactive system enabling patients to call a nurse, select a book for
reading from the exhaustive electronic library. Integrative medicine services such as Reiki,
acupressure, and massage therapy can be delivered chair-side by specially trained nurses on staff.
Telemedicine system to enable patients to communicate with their physicians, nurses, and healthcare
professionals from other disciplines and social work.

The mobile dialysis clinic works exactly like a dialysis center. The vehicle has the clinical,
technical and support staff and is well equipped with the necessary machinery required to perform
the standard procedure for dialysis. This includes dialysis machine, recliner, power backup, and a
water tank with water purified through reverse osmosis (RO) system. It has a fully automated and
remote controlled dialysis chair, which works like a dialysis bed and there is a monitor
defibrillator and an artificial respirator. It also carries accessories and equipment required to
tackle emergencies. The machine and accompanying accessories can be moved into homes and patients
can receive the treatment along the bedside.

KALLO - MOBILECARE

2.Mobile Chemotherapy Clinic

3.Mobile Dialysis Clinic

Page 20
<!-- page 21 -->
Our Mobile care is equipped with a dedicated, affordable and accurate CD4+ T-cell and CD4%
enumeration in HIV monitoring and patient follow-up. The CyFlow® Counter is a fully equipped
portable and ultra compact desktop flow cytometer dedicated for routine CD4 and CD4% counting (as
well as total lymphocyte and WBC counting). Equipped with Portable and Battery-Operated Fluorescence
Microscope for Malaria diagnostics and monitoring. The Partec CyScope® is a microscope for
fluorescence light detection employing incident UV light and transmitted light detection. Integrated
with a CCD camera for taking images of the slide for further investigation by image analysis
software.

The Mobile Clinic Command Center is installed in Specialist / Teaching hospitals to provide
real-time support for the Front line Medical officers and staff in the Mobile Clinics for Clinical
care-plan, clinical treatment protocol, clinical diagnostic protocol and procedures to optimize the
Mobile clinic function and to establish seamless continuum of care. Each Command Center, based on
the throughput of patients in the Mobile clinics can manage on an average of 4-5 Mobile clinics.
Note:

KALLO - MOBILECARE

4.Mobile HIV & Malaria Clinic

5.Mobile Clinic Command Center

a)Medications and medical consumables are not provided in the Mobile Medical Clinics and shall be
provided at additional cost. b)Auxiliary equipment for the Mobile Clinics:

i)Stretchers, backboards, collars, drugs, medications and other medical supplies can be provided at
additional cost. ii)All medical supplies to the government shall be on a contract supply based on
demand, negotiated after the principal purchase order is placed for the Mobile Clinic.

Page 21
<!-- page 22 -->
Paramedic staff in Kallo's Mobile Medical Clinics are provided a high level of pre-hospital medical
training involving key skills not performed by technicians, including cannulation, cardiac
monitoring, intubation etc., by Kallo's Internationally accredited doctors.

Specialty training (Focused on providing specialty care in conjunction with Specialists at teaching
hospitals or Specialist care hospitals such as Pediatrics, Cardiology, Nephrology etc.,) for Front
line Medical officers and staff in the Mobile Clinic and the Command center provided at additional
cost based on assessment of resources and training requirements.

Basic training for Front line Medical officers and staff is included in the cost. This training is
for the duration of 1 week and can hold 10 people. Student Material for ACLS for one student is
US$80/- (Includes quick access algorithm cards) Text Book for Basic Trauma and life support for one
student is US$120/- Cost of Training per any additional week of 5 days is US$ 40,000/- (For Doctors
and Clinical/Biomedical Engineers travel stay and charges)

KALLO - MOBILECARE

6.Training:

7.Specialty training:

8.Basic training:

9.Maintenance:

A.Mobile Clinic and Command Center maintenance is included in the Five year Standard Mandatory
Maintenance as per the Program description given in Schedule E

Page 22
<!-- page 23 -->
SCHEDULE - B Communication

KALLO - MOBILECARE

KALLO Inc.,

Attn: Mr. John Cecil Address: 15 Allstate Parkway, Suite #600 Markham, Ontario, L3R 5B4 Canada
Telephone:+1-416-246-9997 Fax: +1-905-415-0332 Email: john@kalloinc.com anna.s@kalloinc.com Petro
data Management Services Limited., Attn: Mr. Babajide A. Soyode Address: Motorways Centre Block 'B',
Ground Floor 1 Motorways Avenue, Alausa, Lagos, Nigeria. Telephone:+234-01-2708786 Fax: + Email:
info@petrodata.net Jide.soyode@gmail.com Gateway Global Fabrication Ltd., Gateway Canada and Gateway
International Inc., Attn: Mr. Ajai Kunnath Address: GATEWAY GLOBAL FABRICATION LTD. No-2 Olodu
Street, Off Oluobasanjo Road, Portharcourt, Rivers state, Nigeria. Address: Gateway Canada. 147
Spring Gate Blvd., Thorn hill, Ontario, L4J 2B2 Tel: +1-647-288-2763 Mobile: +1-647-9385471 Fax: +
Email: ajai.kunnath@gvcal.com

Page 23
<!-- page 24 -->
SCHEDULE - C Roles and Responsibilities defined for Kallo's Mobile Care operations in Nigeria under
this Strategic Alliance Agreement PETRODATA OPERATIONS

ADMINISTRATIVE

KALLO INC

KALLO - MOBILECARE

1.Customs clearance and delivery of Mobile Clinics. 2.Training of Client's Operations 3.Personnel of
various cadres, doctors, nurses, paramedics, drivers, and medical technicians / technologists
4.Maintenance of medical equipment 5.Maintenance of the automobile and the engine of the Mobile
Clinic and diesel generators 6.Procurement of communication channels such as satellite feed and
high-speed internet connectivity for Command Centers 7.Provision of data acquisition and back-up
storage systems 8.Supply of all local manpower, not provided by clients 9.Supply of residential
accommodation, land transport, and general 10.Welfare amenities to all foreign personnel
11.Specialized IT and satellite communication support for Mobile Clinics

1.Letters of invitation to Kallo personnel for visas 2.Procurement of all import permits and
licenses 3.Accommodation, welfare, and security arrangements 4.Arrangements for meetings with
various organizations 5.Local transportation and security 6.Employment of local operational support
staff, as required

1.Supply of Mobile Clinics and all operating equipment and software 2.Supply of all training
personnel and materials for clinical staff (Doctors, Nurses and Front line Medical officers) and
Biomedical Engineers and software Engineers. 3.Sourcing of backup foreign medical consultants, as
required 4.Tele-health consulting for second opinion from medical specialists from US, Canada and UK
5.Procurement of all export permits and licenses 6.Supply of drugs/medications and spare parts
during and after the warranty period.

Page 24
<!-- page 25 -->
GATEWAY

BAS CONSULTANTS INTERNATIONAL CORPORATION (BASCIC)

KALLO - MOBILECARE

1.Purchasing and transportation of Mobile Clinics, operating equipment, spare parts, medical
consumables, drugs/medications to various distribution centers in Nigeria to replenish stocks in the
Mobile Clinic, from Kallo Inc. Canada. 2.Customs clearance and inland transportation 3.Assistance
with local market development and liaison with clients

(Engr. B. A. Soyode)

SCHEDULE - D Mutually accepted Sales Target

1.All Parties in this agreement appoint BASCIC as Project manager without prejudice. 2.Project
development, management and coordination 3.Liaison with Governments and clients and responsible for
payments to Kallo and supply chain management of Medical consumables and medications/drugs from
Kallo.

Mobile Clinics Year Estimated Value Remarks 2 Q4 2011 $14.575 Million To retain Exclusivity for
Nigeria 3 Q1 - Q2 2012 $21.863 Million To retain Exclusivity for Nigeria 2 Q3 - Q4 2012 $14.575
Million To retain Exclusivity for Nigeria 3 Q1 - Q2 2013 $21.863 Million To retain Exclusivity for
Nigeria 2 Q3 - Q4 2013 $14.575 Million To retain Exclusivity for Nigeria 3 Q1 - Q2 2014 $21.863
Million To retain Exclusivity for Nigeria 2 Q3 - Q4 2014 $14.575 Million To retain Exclusivity for
Nigeria 3 Q1 - Q2 2015 $21.863 Million To retain Exclusivity for Nigeria 2 Q3 - Q4 2015 $14.575
Million To retain Exclusivity for Nigeria 3 Q1 - Q2 2016 $21.863 Million To retain Exclusivity for
Nigeria 2 Q3 - Q4 2016 $14.575 Million To retain Exclusivity for Nigeria

Page 25
<!-- page 26 -->
SCHEDULE - E Mandatory Medical Equipment Service Program for Five-year Warranty All equipment
provided in the Mobile Clinic are covered under this program and the service provision is a very
unique model, where Senior Biomedical Engineers trained and certified by the manufacturers are to
perform the following services located at Kallo Headquarters, coordinate with the manufacturers and
the local onsite support Biomedical Technicians and provide the following services:

This program has a set of planned routine maintenance schedule for each device of medical equipment
based on the original equipment manufacturers' recommendations, applicable codes and standards given
in section 7.

This program has scheduled and unscheduled calibration of the medical equipment in the Mobile
Clinic. Each medical device has a scheduled calibration of certain parts critical to the functional
accuracy of the equipment, which is carried out as per the original equipment manufacturers'
guidelines. The unscheduled calibration of the equipment is normally carried out if and when there
is a request from the staff or doctors when they observe certain calibration errors.

Safety of patients, staff, and environment is paramount to the success of the Mobile Care project.
The Joint Commission on the Accreditation of Healthcare Organizations publishes annual lists
detailing "National Patient Safety Goals" to be implemented by healthcare organizations. Goals are
developed by experts

KALLO - MOBILECARE

1.Planned and Corrective Maintenance 2.Calibration of Medical Equipment 3.Patient, Staff and
Environment safety 4.Breakdown Services and Maintenance 5.Application and operation support 6.Risk
Management 7.Codes and Standards adherence for International compliance

1.Planned and Corrective Maintenance

2.Calibration of Medical Equipment

3.Patient, Staff and Environment Safety

Page 26
<!-- page 27 -->
in patient safety, nurses, physicians, pharmacists, risk managers, and other professionals with
patient-safety experience in a variety of settings. Patient safety is among the most important goals
of every healthcare provider, and participation in a variety of committees and processes concerned
with patient safety provides a way for biomedical managers and clinical engineering departments to
gain visibility and positively affect their workplace. Kallo's Patient and Operator Safety Program
uses a comprehensive software where in the actual work process within the Mobile Care Clinic is
monitored by the onsite Biomedical Technicians guided by the Senior Biomedical Engineers at Kallo
Headquarters qualified for managing the patient, staff, and environment safety to international
standards.

The program covers all equipment in the Mobile Clinic. The local onsite Biomedical technicians will
be the first response team to attend to any and all breakdown calls from the Mobile Clinic. The
Biomedical Technicians will then have Kallo Biomedical Engineer support to resolve the issues as
quickly as possible. After the breakdown service is carried out and the equipment is fixed and
recalibrated, the Senior Biomedical Engineers would then advise if a maintenance service has to be
carried out to due to the nature of breakdown.

The program covers all medical equipment in the Mobile Clinic. Kallos' Certified Clinical Engineers
/ Biomedical Engineers and Clinical Application support specialists will be available via
Video/Teleconference/Telehealth systems in the Mobile clinic for all clinical application support in
using technology for diagnostic and therapeutic healthcare services. This is a critical component of
the program offered in order to make it successful in using technology at the front end which is
normally neglected by all medical equipment manufacturers' when the equipment is deployed in remote
areas with medical staff who are not exposed to technology as the case may be in urban areas,
developed cites or countries.

This program helps avoid the likelihood of equipment-related risks, minimize liability of mishaps
and incidents, and stay compliant with regulatory reporting requirements. In addition, user error,
equipment abuse, no problem/fault found occurrences

KALLO - MOBILECARE

4.Breakdown Service and Maintenance

5.Application Support

6.Risk management

Page 27
<!-- page 28 -->
must be tracked to assist risk management personnel in determining whether additional clinical staff
training must be performed. Risk management for IT networks incorporating medical devices will be
covered by the standard ISO/IEC 80001. Its purpose is: "Recognizing that MEDICAL DEVICES are
incorporated into IT-NETWORKS to achieve desirable benefits (for example, INTEROPERABILITY), this
international standard defines the roles, responsibilities and activities that are necessary for
RISK MANAGEMENT of IT-NETWORKS incorporating MEDICAL DEVICES to address the KEY PROPERTIES". Such as
ISO 20000 in the context of medical applications, e.g. configuration, incident, problem, change and
release management, and risk analysis, control and evaluation according to ISO 14971. IEC 80001
"applies to RESPONSIBLE ORGANIZATIONS, MEDICAL DEVICE manufacturers and other providers of
information technologies for the purpose of comprehensive RISK MANAGEMENT". 7. Codes and Standards
adherence for International compliance: 1. JCAHO Comprehensive Accreditation Manual 2. AABB 3. NFPA
99 a. Gas and Vacuum Systems b. Electrical Systems 4. FDA 5. SMDA 6. OSHA

KALLO - MOBILECARE

Page 28
<!-- page 29 -->
SCHEDULE - F Medical Equipment description Blood Chemistry Analyzer

KALLO - MOBILECARE

Advanced i-STAT Cartridge Technology or equivalent system Most Comprehensive Bedside Testing
Platform: i-STAT cartridge technology streamlines traditional lab technology, yet contains many of
the components found in complex lab testing systems. Each test cartridge contains chemically
sensitive biosensors on a silicon chip that are configured to perform specific tests. To perform a
test, 2 to 3 drops of blood are applied to a cartridge, which is then inserted into the i-STAT
handheld. Prior to running a test, each cartridge initiates a series of preset quality control
diagnostics, from monitoring the quality of the sample to validating the reagent. Each i-STAT
single-use cartridge uses advanced biosensor technology that applies microfluidics to process the
most comprehensive range of clinical tests in a single platform, allowing clinicians to access the
time-sensitive diagnostic information they need, when and where they need it. Available tests
include diagnostic indicators related to disease state and clinical practice guidelines.
Test-specific, single-use i-STAT cartridges are available for a range of clinical tests, including
cardiac markers, lactate, coagulation, blood gases, chemistries and electrolytes, and hematology.
Delivers lab-quality test results to the clinician within minutes The portable i-STAT handheld makes
patient-side testing easy:

Patient-side testing is as easy as entering the operator and patient information into the handheld,
inserting one of the several testing cartridges, and then viewing test results:

·requires no special sample preparation or user calibration; maintenance is minimal ·weighs 18
ounces, making it completely portable ·features ergonomically designed soft keys for comfort and
ease of use

·The system prompts users step by step through the testing process ·Operator and patient information
can be entered via barcode scanner ·Operator lockout prevents unauthorized users from performing or
viewing test results

Page 29
<!-- page 30 -->
With over 50,000 handhelds placed in high-acuity settings worldwide-including over 1,800
hospitals-and over 35 million test cartridges produced annually, the i-STAT System is trusted to
provide lab-quality results. i-STAT Integration Into Point-of-Care Data Management and Electronic
Medical Records The i-STAT® System can integrate test results with your Lab Information System (LIS)
and Electronic Medical Records (EMR). This is achieved through flexible connectivity and interfacing
solutions, which serve to ensure your facility gets real-time results in the patient electronic
chart. i-STAT System integration with Laboratory Information Systems (LIS)/Electronic Medical
Records (EMR)

The i-STAT System connects to the Point-of-Care Data Management System of your choice and then
interfaces to the EMR via your LIS. Integration options include:

Addressing Documentation Challenges with STATNotes™ STATNotes is a highly customizable documentation
solution for the i-STAT 1 handheld. This unique feature facilitates timely documentation of complex
and critical data by prompting the user to enter information into the i-STAT 1 during the testing
process. The information is then automatically uploaded to the patient chart with the test results.
Customizing your i-STAT System to prompt data entry:

KALLO - MOBILECARE

·Test results are uploaded automatically when the i-STAT handheld is placed in a downloader

·The Central Data Station System from Abbott Point of Care ·Abbott Diabetes Care PrecisionWeb®
·Medical Automation Systems RALS+™ RALS® Plus ·Telcor Quick-Linc®

Page 30
<!-- page 31 -->
STATNotes can help guide users to be compliant with The Joint Commission National Patient Safety
Goals and hospital policies. For example, many of our customers use STATNotes to capture
comprehensive ventilator setting information, documentation of critical test notification, and "read
back" acknowledgment of critical tests and critical values. Data Management and Laboratory
Regulatory Compliance The i-STAT System gives you control over who can use the device and access
test results. It also offers many features designed to help laboratories maintain regulatory
compliance, such as:

Abbott Point of Care will work with your team to ensure seamless integration with your data
management system. Urine Chemistry Analyzer CLINITEK Status® Analyzer or equivalent system Intended
Use

Table of Results The results shown in shaded areas will be marked as positives, if "mark positive
results" is selected in Instrument Set Up. The results will be marked by asterisks when displayed,
when printed and when the data is transferred to a host computer.

KALLO - MOBILECARE

·streamlines workflow ·helps reduce errors ·allows for increased efficiency ·facilitates compliance

·managing operator certification and device lockout ·reporting on operator performance ·reporting on
both liquid and equivalent quality control ·reporting on reagent usage ·laboratory Information
System interfacing

·The Analyzer is for in vitro use in the semi-quantitative detection of albumin, bilirubin, blood
(occult), creatinine, glucose, ketone (acetoacetic acid), leukocytes, nitrite, pH, protein, specific
gravity and urobilinogen in urine samples, depending on the type of Siemens urinalysis strip used.
·The semi-quantitative calculation of albumin-to-creatinine and protein-to-creatinine ratios in
urine samples, when Clinitek® Microalbumin and Multistix PRO® Reagent Strips for Urinalysis are
used. ·The detection of human Chorionic Gonadotropin (hCG) in urine samples, when Clinitest® hCG
cassettes are used.

Page 31
<!-- page 32 -->
KALLO - MOBILECARE

Page 32
<!-- page 33 -->
<!-- page 34 -->
Urinalysis has become an indispensable tool in healthcare.

In today's busy physician's office environment, interruptions are frequent and can contribute to
timing errors and variability in results when urinalysis strips are read visually. Studies have
shown that when urinalysis is performed with an instrument, sensitivity is increased and positives
are correctly identified and reported.1

1. Tighe P. Improving the quality of urine strip testing: The Clinitek 50 urine chemistry analyser.
Euro Clin Lab, June 1997,16:20.

KALLO - MOBILECARE

·Provides important markers to detect early stages of many disease states, such as diabetes, kidney
disease and urinary tract infections. ·Enhances disease monitoring and patient management.
·Semi-quantitative results have proven to be cost-effective and virtually immediate.

Page 33

KALLO - MOBILECARE

Page 34
<!-- page 35 -->
<!-- page 36 -->
Digital Radiography System RadPRO D2RS Dynamic Digital Remote RF System or equivalent system Digital
Radiography & Fluoroscopy Solutions

Features

KALLO - MOBILECARE

•Canon CXDI-50RF Dynamic/Static Digital Radiography System The RadPRO D2RS Dynamic Digital Remote RF
System is compatible with the Canon CXDI-50RF Dynamic/Static Digital Radiography System that
includes a Cesium Iodide scintillator. Including both dynamic and static capabilities, high
resolution images are produced and may be previewed within 2-4 seconds after exposure in the
radiography mode with the optional monitor. The radiography mode produces up to 15 frames per second
(fps), and up to 30 fps in the fluoroscopy mode, depending on the image capture mode and size. The
detachable cable allows the digital detector to be used in multiple rooms or multiple locations
within the same room. •Dynamic and Static Imaging The Canon CXDI Control Software RF, designed
specifically for the Canon CXDI-50RF Dynamic/Static Digital Radiography System, features a wide
range of fluoroscopic procedures and includes all the standard DICOM functions. Exams include spine,
Osteo-articular, Barium swallow and esophagus, stomach and small intestine, Barium enema and large
bowel, Endoscopy/ERCP, Urography, Cystography, Hysterosalpingography, Myelography, Arthrography,
Venography and more. The software also delivers high-resolution images, generator communication for
preset X-ray parameters, provides actual exposure factors and patient dose information in the DICOM
header. Studies that require full spine and long leg imaging are fully automated. With the automated
stitching capability up to 4 images can be stitched together.

Page 35
<!-- page 37 -->
Digital Retina Scanner CR-2 PLUS or equivalent system Digital Non-Mydriatic Retinal Cameras

Overview The Canon CR-2 PLUS Digital Non-Mydriatic Retinal Camera provides Color and Fundus
Autofluorescence (FAF) imaging within a small compact design. Geographic Atrophy, Macular
Degeneration, Glaucoma, Diabetic Retinopathy and other conditions that can affect vision may also be
identified and monitored using FAF mode. Using invisible infrared alignment light, the digital
non-mydriatic camera may image patients with pupils as small as 3.3 mm (small pupil mode) without
dilation drops. This is especially useful when performing retinal screenings or expediting routine
retinal imaging exams during office visits.

KALLO - MOBILECARE

• High Quality Images High resolution static images can be previewed within 3-5 seconds after
exposure on a monitor (optional). Images may be configured automatically with post-processing and
are ready to be printed or transmitted through the network using industry standard DICOM protocols.
• Full Patient Coverage End-to-end table coverage is available when the motorized tube column
angulation is combined with the motorized tube rotation. The motorized table adjusts the height, and
the low minimum height simplifies access for patients with mobility issues. When patients arrive at
the radiology room on a trolley or in a bed, Smart Access provides clear access to a 47 inch (120
cm) section of the table top to allow for a simplified transfer. The table loading capacity
accommodates patients weighing up to 500 lbs (230 kg). • Auto-Positioning able movements,
collimation and spectral filtration settings, exposure and digital acquisition parameters may be
administered with the single touch, remote-controlled user-interface reducing the preparation time
needed for exams.

Page 36

Features
<!-- page 38 -->
KALLO - MOBILECARE

•Non-Mydriatic Fundus Autofluorescence (FAF) Photography Fundus Autofluorescence (FAF) helps monitor
macular waste (e.g. lipofuscin) which can accumulate in the Retinal Pigment Epithelial (RPE) layer.
The accumulation of macular waste can cause conditions such as Age-Related Macular Degeneration
(AMD) which can lead to reduced vision. The FAF mode may be selected by pressing only one button.
•Digital Filter Processing Red-Free and Cobalt digital filters are included and provide enhanced
screening exams. Red-Free is used for evaluating the Retinal Nerve Fiber Layer (RNFL) and vascular
structure of the retina associated with documenting Glaucoma, Diabetic Retinopathy or Hypertension.
The Cobalt filter is also used for evaluating the RNFL, as well as Optic Disc and Optic Disc Drusen.
Additionally, Green (Vascular view) and Red channel (Choroid view) digital filter views are also
included. •Compact and Lightweight he small design of the CR-2 PLUS facilitates portability when
needed using an optional hard shell transport case sold separately. Canon instrument tables (sold
separately) may comfortably fit both the camera and computer workstation (sold separately). The
space saving design also allows for use in limited office space environments. •Dedicated EOS Camera
Technology Hgh quality diagnostic images are obtained using a dedicated camera for the CR-2 PLUS
which incorporates a large, high-definition CMOS sensor with 18 megapixels. When the camera cover is
removed, the LCD may be adjusted to a variety of titled angles to suit the user's point of view.
•Low Flash Intensity and ISO Sensitivity Th low flash intensity of the CR-2 PLUS minimizes miosis,
thus shortening the time required for taking multiple view exams or stereo images. The reduced
brightness improves patient comfort and reduces the "ghost" image the patient sees after an
exposure. A wide range of low ISO speeds are supported including ISO 200, 400, 800, 1600, 3200 and
6400. •Automatic Exposure Function TheCR-2 PLUS measures the volume of infrared light from the
retina and automatically adjusts the flash intensity for observation and photography. This feature
may be set to ON/OFF and can be adjusted using the operation panel. •Control Panel The implified
design of the control panel can be easily handled by an examiner. The one-handed joystick may be
used to position the camera to acquire the desired image. In darkly lit rooms, the operation panel
illuminates for easier navigation. The short main body of the CR-2 PLUS provides minimal distance
between the patient and the operator allowing easy access to adjust the patient's position or
eyelids. •Retinal Imaging Control Software Usingthe Canon Retinal Imaging Control Software (RICS),
images can be captured, viewed, processed, printed and saved to a permanent storage database. The
Canon RICS complies with the DICOM®* Standard. Images may be stored as DICOM or JPEG files. For more
information, visit Retinal Imaging Control Software.

Page 37
<!-- page 39 -->
Ultrasound Scanner LOGIQ 9 or equivalent system

E-Series transducers Incredible transducer technology makes imaging incredibly easy. E-Series
transducers set an entirely new standard in acquiring extraordinary images. The moment you put the
transducer on the patient, these highly advanced, ergonomically designed transducers work with the
agile architecture to maximize image quality.

Highly advanced transducer technologies for high-quality images:

Acoustic Amplifier Technology built into the new E-Series transducers achieves higher sensitivity by
recycling the acoustic energy that used to pass through the transducer crystal. It redirects this
previously wasted energy back into the piezoelectric crystal, adding significantly to the transducer
sensitivity.

KALLO - MOBILECARE

·Acoustic Amplifier Technology ·Single Crystal Technology ·Matrix Array Technology ·Volume Hybrid
Technology

Page 38
<!-- page 40 -->
Single Crystal Technology increases bandwidth, offering better signal to noise and improved axial
resolution and penetration. Matrix Array Technology helps achieve uniform resolution throughout the
field of view, eliminating the compromise between penetration and image resolution. Volume Hybrid
Technology encompasses a new range of Volume transducers bringing an outstanding spatial and
temporal resolution. LOGIQ E9 knows the next step of a scan and helps you get there like no other
ultrasound system can. It's all part of the technologically advanced Scan Assistant, your
customizable scanning protocol. Scan Assistant does things that an ultrasound system has never done
before, including automatically steering color Doppler and setting up imaging controls and modes for
you. Now you can truly concentrate less on keystrokes and more on patient care. Digital Smartscope

KALLO - MOBILECARE

Optomed Smartscope or equivalent system Optomed Smartscope is a digital camera that provides
general, ophthalmoscope, otoscopic and dermatoscopic imaging with one hand -held device.

Page 39
<!-- page 41 -->
Multi Function Digital Stethoscope CMS VESD Digital Stethoscope or equivalent system

CMS-VESD is a multi-functional visual stethoscope. On the basis of stethoscope function, it is added
with ECG and SpO2 monitoring function. The multi-functional characteristic of the device makes it is
effective on emergency treatment.

Specification

Stethoscope

KALLO - MOBILECARE

·Compact and portable, easy to use ·Suitable for adult, pediatric and neonatal patients. ·Heart,
Lung, Heart and Lung sound models for Stethoscope. ·Large color LCD display of ECG, SpO2 and Pulse
rate ·Adjustable audible and visual alarms ·Real-time monitoring.24 hours storage and review of data
·SD card memory, all data can be transferred to a PC ·Low power consumption.

·Power Supply : Lithium Battery DC3.6~DC4.2V ·Display : 2.4" Color LCD

·Heart：20～230Hz ·Lung：100～800Hz ·H& L：20～800Hz ·Accuracy:± 2 bpm

Page 40
<!-- page 42 -->
Heart Rate

Pulse Rate

SpO2

Patient Weighing Scale for Telehealth UC321 Digital Weighing scale or equivalent system Personal
Scales for Telemonitoring

An accurate and precise scale specifically designed for telemedicine applications. The UC-321 series
provides highly accurate and precise measurements for telemedicine applications. These scales are
one of the thinnest and lightest scales on the market. Measuring less than 1" thick, it is easy to
step on and store.

KALLO - MOBILECARE

·Measurement range: 30bpm～300bpm; ·Accuracy: ± 2 bpm

·Measurement range: 30bpm 250bpm; ·Accuracy: ± 2 bpm or ± 2%

·Measurement range: 35%～100%; ·Accuracy: 70~100% (± 2% ) <70% unspecified.

·Precise measurements ·Displays weight in either pounds or kilograms ·Memory recall with time/date
stamp on select models ·Includes four attachable feet for carpet use ·Motion Tolerance Mode on
select models

Page 41
<!-- page 43 -->
KALLO - MOBILECARE

This sleek and stylish unit offers more precise readings and functionality compared to traditional
scales. Available with wired or wireless communications. Digital Blood Pressure Monitor for
Telehealth AND Digital Blood Pressure Monitor or equivalent system Blood Pressure Monitors for
Telemonitoring

A leading blood pressure monitoring system among telemonitoring service providers. This blood
pressure monitor can send real-time blood pressure measurements to the Access Point. These devices
can also operate in

·Professional accuracy via oscillometric method ·Clinically validated ·One button operation ·Memory
storage ·Provides time and date stamp ·Each monitor has unique serial number ·Meets ANSI/AAMI SP10
standards

a batch-mode to send a number of measurements with time and date in a single request command.
Available with wired or wireless communications. Page 42
<!-- page 44 -->
Telepharmacy Solution Integrates remote or local pharmacist-controlled dispensing system cabinetry
and software, pharmacy software and televideo technology into one system individually designed to
meet all your needs. It brings real-time medication dispensing and pharmacist counseling to the
point of care.

Improves patient care and satisfaction

KALLO - MOBILECARE

·Provides immediate medication access - no more waiting or unnecessary trips. ·Enhances prescription
fulfillment - resulting in greater patient compliance. ·System software/multiple barcode
verifications virtually eliminate dispensing errors.

Page 43
<!-- page 45 -->
SCHEDULE - G Kallo Mobile care suite of products (Price is subject to change based on the
requirement and configuration of various systems in the Mobile Clinic, and is exclusive of taxes,
levies custom duties, freight and insurance.)

KALLO - MOBILECARE

Description Kallo Price Agent Markup End user price Mobile Acute Care Clinic - Base price $2,650,000
$265,000 $2,915,000

NOTE: PRICING INCLUDES TELE PHARMACY SYSTEM COSTING $150,000/ - FOR EACH MOBILE CLINIC.

Standard Mandatory Maintenance Service for 5 years $2,915,000 $1,457,500 $4,372,500 $1,722,500
$7,287,500 Description Kallo Price Agent Markup End user price Mobile Chemotherapy Clinic - Base
price $1,850,000 $185,000 $2,035,000 Standard Mandatory Maintenance Service for 5 years $2,035,000
$1,017,500 $3,052,500 $1,202,500 $5,087,500 Description Kallo Price Agent Markup End user price
Mobile Dialysis Clinic - Base price $1,600,000 $160,000 $1,760,000 Standard Mandatory Maintenance
Service for 5 years $1,760,000 $880,000 $2,640,000 $1,040,000 $4,400,000 Description Kallo Price
Agent Markup End user price Mobile HIV & Malaria Clinic - Base price $1,800,000 $180,000 $1,980,000
Standard Mandatory Maintenance Service for 5 years $1,980,000 $990,000 $2,970,000 $1,170,000
$4,950,000 Description Kallo Price Agent Markup End user price Command Center for Mobile Clinics
$550,000 $55,000 $605,000 Standard Mandatory Maintenance Service for 5 years $605,000 $302,500
$907,500 $357,500 $1,512,500
<!-- page 46 -->
Page 44
