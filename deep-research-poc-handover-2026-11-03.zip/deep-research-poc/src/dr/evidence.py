"""EvidenceBank — harness-owned state. Researchers write verbatim quotes here; the writer
reads ONLY this. Persisted as JSONL inside the workspace so it survives compaction and is
part of the audit trail.
"""
from __future__ import annotations

import json
import threading
from pathlib import Path

from .models import EvidenceItem
from .workspace import Workspace


class EvidenceBank:
    def __init__(self, ws: Workspace):
        self.ws = ws
        self.path: Path = ws.root / "evidence.jsonl"
        self._items: dict[str, EvidenceItem] = {}
        self._n = 0
        self._lock = threading.Lock()   # parallel tool turns and fan-out researchers share one bank
        if self.path.exists():
            for line in self.path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    it = EvidenceItem(**json.loads(line))
                    self._items[it.id] = it
                    self._n = max(self._n, int(it.id[1:]))

    # ------------------------------------------------------------------ write

    def add(
        self,
        doc_id: str,
        start_line: int,
        end_line: int,
        quote: str,
        note: str = "",
        sub_question: str | None = None,
        created_by: str = "researcher",
    ) -> EvidenceItem:
        """Thread-safe `add`; see `_add` for the contract."""
        with self._lock:
            return self._add(doc_id, start_line, end_line, quote, note, sub_question, created_by)

    def _add(
        self,
        doc_id: str,
        start_line: int,
        end_line: int,
        quote: str,
        note: str = "",
        sub_question: str | None = None,
        created_by: str = "researcher",
    ) -> EvidenceItem:
        """Add a quote. Verifies the lines exist and the quote actually appears in that window
        (cheap guard against fabricated quotes before tier-1 runs). Dedupes overlapping windows
        from the same doc with the same note intent by returning the existing item."""
        total = self.ws.line_count(doc_id)
        start_line = max(1, min(start_line, total))
        end_line = max(start_line, min(end_line, total))
        window = "\n".join(self.ws.lines(doc_id)[start_line - 1 : end_line])
        if _norm(quote) not in _norm(window):
            raise ValueError(
                "quote not found verbatim in the cited line range; copy text exactly from the read window"
            )
        for it in self._items.values():
            if it.doc_id == doc_id and _overlap(it.start_line, it.end_line, start_line, end_line) >= 0.8:
                if _norm(quote) in _norm(it.quote) or _norm(it.quote) in _norm(quote):
                    return it
        self._n += 1
        item = EvidenceItem(
            id=f"e{self._n}",
            doc_id=doc_id,
            page=self.ws.page_of(doc_id, start_line),
            start_line=start_line,
            end_line=end_line,
            quote=quote.strip(),
            note=note.strip(),
            sub_question=sub_question,
            created_by=created_by,
        )
        self._items[item.id] = item
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(item.model_dump()) + "\n")
        return item

    def update(self, item: EvidenceItem) -> None:
        with self._lock:
            self._items[item.id] = item
            self._rewrite()

    def _rewrite(self) -> None:
        with self.path.open("w", encoding="utf-8") as f:
            for it in self._items.values():
                f.write(json.dumps(it.model_dump()) + "\n")

    # ------------------------------------------------------------------ read

    def get(self, eid: str) -> EvidenceItem | None:
        return self._items.get(eid)

    def all(self) -> list[EvidenceItem]:
        return list(self._items.values())

    def by_sub_question(self) -> dict[str | None, list[EvidenceItem]]:
        out: dict[str | None, list[EvidenceItem]] = {}
        for it in self._items.values():
            out.setdefault(it.sub_question, []).append(it)
        return out

    def doc_ids(self) -> set[str]:
        return {it.doc_id for it in self._items.values()}

    def __len__(self) -> int:
        return len(self._items)

    def render_for_writer(self, ids: list[str] | None = None, max_quote_chars: int = 600) -> str:
        """Compact rendering the writer sees. Only kept/unchecked items; dropped are excluded."""
        items = [self._items[i] for i in ids if i in self._items] if ids else self.all()
        out = []
        for it in items:
            if it.tier1_status == "drop":
                continue
            pg = f" p.{it.page}" if it.page else ""
            q = it.quote if len(it.quote) <= max_quote_chars else it.quote[:max_quote_chars] + "…"
            out.append(f"[{it.id}] ({it.doc_id}{pg}, L{it.start_line}-{it.end_line}) {it.note}\n    \"{q}\"")
        return "\n".join(out)

    def citation_for(self, eid: str) -> str:
        it = self._items[eid]
        return f"[{it.doc_id} p.{it.page}]" if it.page else f"[{it.doc_id} L{it.start_line}]"


def _norm(s: str) -> str:
    return " ".join(s.split()).lower()


def _overlap(s1: int, e1: int, s2: int, e2: int) -> float:
    inter = max(0, min(e1, e2) - max(s1, s2) + 1)
    return inter / max(1, min(e1 - s1 + 1, e2 - s2 + 1))
