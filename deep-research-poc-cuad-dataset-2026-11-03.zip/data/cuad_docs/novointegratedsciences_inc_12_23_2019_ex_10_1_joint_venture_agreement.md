<!-- page 1 -->
# JOINT VENTURE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Joint Venture Agreement |
| Agreement Date | 2019-12-19 |
| Parties | Novo Integrated Sciences Inc. (“NVOS”); Harvest Gold Farms Inc. (“HGF”); NVOS and HGF (collectively as the “Parties” and separately as a “Party”) |
| Source | CUAD v1 / NOVOINTEGRATEDSCIENCES,INC_12_23_2019-EX-10.1-JOINT VENTURE AGREEMENT |

Exhibit 10.1 JOINT VENTURE AGREEMENT BETWEEN NOVO INTEGRATED SCIENCES INC. ("NVOS") AND HARVEST GOLD
FARMS INC. ("HGF") FOR THE DEVELOPMENT, MANAGEMENT AND OPERATION OF HEMP FARMING AND MEDICINAL CROPS
<!-- page 2 -->
JOINT VENTURE AGREEMENT Dated as of December 19, 2019 This Joint Venture Agreement (the "Agreement")
is entered into between Novo Integrated Sciences Inc., a Nevada Corporation with offices located at
11120 NE 2nd Street, Suite 200, Bellevue, Washington 98004, U.S.A (herein referred to as "NVOS") and
Harvest Gold Farms Inc., a corporation organized under the laws of New Brunswick, Canada with
offices located at 866 E. H. Daigle Blvd, Grand Falls, New Brunswick, E3Z 3E8, Canada (herein
referred to as "HGF"). NVOS and HGF may be referred to herein collectively as the "Parties" and
separately as a "Party." RECEITALS WHEREAS, NVOS is willing to assist in development, assist in
management and purchase biomass resulting from open field farming for health-related cash crops, in
particular medicinal cannabis and industrial hemp; WHEREAS, NVOS is willing to develop and construct
processing facilities as well as finished goods manufacturing and packaging facilities; WHEREAS,
NVOS is willing to provide the Joint Venture access to its distribution pathways established either
directly or indirectly through NVOS or its wholly or partially owned subsidiaries; WHEREAS, NVOS is
willing to establish reasonable commercial cost bases to product processing and packaging ensuring a
profitable and fully transparent Joint Venture; WHEREAS, NVOS is willing to utilize all applicable
HGF tools and offerings for the purposes of developing a fully comprehensive North American business
platform; WHEREAS, HGF is willing to work towards a mutually acceptable Joint Venture; WHEREAS, HGF
is willing to engage to its fullest potential in the licencing, employment harvesting, legal right
consulting, business development within its geographical jurisdiction; WHEREAS, HGF is willing
assist in transport and distribution of raw and finished goods in both domestic and international
jurisdictions; WHEREAS, HGF is willing to provide certified biomass to the JV on pre-determined,
mutually agreed price per acre and participate on a net revenue split of products offered to market
directly or indirectly through NVOS channels; NOW THEREFORE, the Parties agree to sign this
Agreement for the purposes of developing, managing and arranging medicinal farming projects
involving hemp and cannabis cash crops (hereinafter referred to as the "Primary Project") under the
following terms set out in this Agreement for the noted project (herein, referred to as the "Primary
Contract").
<!-- page 3 -->
ARTICLE 1 - DEFINITIONS AND INTERPRETATION 1.1 For the purposes of this Agreement, unless the
context otherwise requires, the following terms shall have the respective meanings set forth below
and grammatical variations of such terms shall have corresponding meanings: (a) "Action" means any
legal action, suit, claim, investigation, hearing or proceeding, including any audit, claim or
assessment for Taxes or otherwise. (b) "Agreement" means this Joint Venture Agreement, dated
December 19, 2019. (c) "Company" means the Joint Venture entity which will be registered and
incorporated in a Canadian jurisdiction with its operating name as Novo Earth Therapeutics Inc. (d)
"Cost" means cost of goods sold as defined in the financials of the Primary Project. (e) "Effective
Date" is the date of the most recent final signature on this Agreement. (f) "EPC" means engineering,
procurement, construction contracts. (g) "HFG" means Harvest Gold Farms Inc. (h) "Joint Venture"
means a business arrangement where NVOS and HGF have agreed to pool their resources for the purpose
of the Primary Project. (i) "Law" means any domestic or foreign, federal, state, provincial,
municipal or local law, statute, ordinance, code, rule, or regulation having the force of law. (j)
"NHL" means Novo Healthnet Limited. (k) "NVOS" means Novo Integrated Sciences Inc. (l) "Parties"
means collectively, Harvest Gold Farms Inc. and Novo Integrated Sciences Inc. (m) "Party"
identifies, separately, either Harvest Gold Farms Inc. or Novo Integrated Sciences Inc. (n) "Primary
Contract" means the terms set out in this agreement for the Primary Project. (o) "Primary Project"
means this agreement that outlines the development, management and arranging of medicinal farming
projects involving hemp and cannabis cash crops. (p) "Tax(es)" means any federal, state, provincial,
local or foreign tax, charge, fee, levy, custom, duty, deficiency, or other assessment of any kind
or nature imposed by any Taxing Authority (including any income (net or gross), gross receipts,
profits, windfall profit, sales, use, goods and services, ad valorem, franchise, license,
withholding, employment, social security, workers compensation, unemployment compensation,
employment, payroll, transfer, excise, import, real property, personal property, intangible
property, occupancy, recording, minimum, alternative minimum, environmental or estimated tax),
including any liability therefor as a transferee (including under Section 6901 of the Code or
similar provision of applicable Law) or successor, as a result of Treasury Regulation Section
1.1502-6 or similar provision of applicable Law or as a result of any Tax sharing, indemnification
or similar agreement, together with any interest, penalty, additions to tax or additional amount
imposed with respect thereto.
<!-- page 4 -->
(q) "Taxing Authority" means the Internal Revenue Service, the Canada Revenue Agency and any other
Authority responsible for the collection, assessment or imposition of any Tax or the administration
of any Law relating to any Tax. (r) "Tax Return" means any return, information return, declaration,
claim for refund or credit, report or any similar statement, and any amendment thereto, including
any attached schedule and supporting information, whether on a separate, consolidated, combined,
unitary or other basis, that is filed or required to be filed with any Taxing Authority in
connection with the determination, assessment, collection or payment of a Tax or the administration
of any Law relating to any Tax. 1.2 Interpretive Provisions. Unless the express context otherwise
requires: (a) the words "hereof," "herein," and "hereunder" and words of similar import, when used
in this Agreement, shall refer to this Agreement as a whole and not to any particular provision of
this Agreement; (b) terms defined in the singular shall have a comparable meaning when used in the
plural, and vice versa; (c) references herein to a specific Section, Subsection, Recital, Schedule
or Exhibit shall refer, respectively, to Sections, Subsections, Recitals, Schedules or Exhibits of
this Agreement; (d) wherever the word "include," "includes," or "including" is used in this
Agreement, it shall be deemed to be followed by the words "without limitation"; (e) references
herein to any gender shall include each other gender; (f) references herein to any contract or
agreement (including this Agreement) mean such contract or agreement as amended, supplemented or
modified from time to time in accordance with the terms thereof; (g) with respect to the
determination of any period of time, the word "from" means "from and including" and the words "to"
and "until" each means "to and including"; (h) references herein to any Law or any license mean such
Law or license as amended, modified, codified, reenacted, supplemented or superseded in whole or in
part, and in effect from time to time; and (i) references herein to any Law shall be deemed also to
refer to all rules and regulations promulgated thereunder.
<!-- page 5 -->
ARTICLE 2 - ENTERPRISE NAME 2.1 The Joint Venture has been registered and incorporated in a Canadian
jurisdiction mutually acceptable to both parties and will be referred to as the "Company", the
Company shall have all the liabilities of the project in relation to finance and operation with HGF
having no liability in relation to the project. ARTICLE 3 - RELATIONSHIP OF PARTIES 3.1 The parties
will work in a Joint Venture relationship with NVOS providing the development and operation of the
project including sales and HGF providing the land, farming expertise, biomass and necessary
approvals for the development of the agricultural project. ARTICLE 4 - OFFICE LOCATION 4.1 The
Company shall have an office in the NVOS head office location as well as an office on the Primary
Project location and if necessary, offices in international jurisdictions for the purpose of sales
and promotion. ARTICLE 5 - START UP CAPITAL AND CONTRIBUTIONS 5.1 Each of the Parties shall
contribute to the start-up as follows: 5.1.1 NVOS ● Complete and finalize a business plan and layout
plans, a detailed procurement project binder and an implementation and roll-out plan. ● Make
arrangements for construction and financing options of any facilities required for the profitable
farming of medicinal crops or related facilities. ● Direct project finance model and selection of
EPC and management service providers. ● Arrange for product purchase contracts. 5.1.2 HGF ● Will
provide the land and approvals for greenhouse (if necessary), open field farming and other
facilities as required. ● Arrange for all required titled land for greenhouses and outdoor
agriculture platforms. ● Arrange for all building permits, environmental approvals and HGF internal
approvals including confirmation of tax-free Company status for the duration of the proposal (if
possible). ● Provide elite farming expertise for the purposes of maximizing potential profits,
inclusive of harvesting techniques and process flow and engineering. ARTICLE 6 - HGF AND NVOS
COMMITMENTS SCHEDULE 6.1 Upon execution of the proposal, HGF will provide necessary documentation
for all land intended for use in the Primary Project including beneficial owners, addresses, and
parcel size.
<!-- page 6 -->
6.2 Upon execution of the proposal, HGF will provide necessary documentation (allocated land)
required for the completion of the construction and management package. 6.3 Harvesting schedule
occurs as dictated by determined cash crop selection. Accompanying cash flow projections will be
completed upon binding buyer contract receipt. ARTICLE 7 - PRINCIPLE AND LINE OF CREDIT RETURNS 7.1
Priority is given to all debt service requirements with principle pay-back schedule adherence based
on cash flow actual conditions. Distribution to Parties as per agreement on a "last to issue" basis.
ARTICLE 8 - TERM OF AGREEMENT 8.1 The initial term of this Agreement shall, unless sooner terminated
by consent of all parties, expires in five (5) years from the date of Effective Date. NVOS and HGF
may renew the Agreement within two (2) years of the expiry of the initial term upon mutual
understanding. 8.2 It is understood that a subsequent renewal of a five (5) year term will be
negotiated in good faith and shall carry terms very close to the original Agreement. 8.3 Both
parties may enter into buyout negotiations with the other Party on terms agreeable to both Parties.
ARTICLE 9 - OBLIGATIONS OF NVOS 9.1 To maintain all financial records of the Company and provide
quarterly and annual reporting to all Company stakeholders. All records are kept under US GAAP
compliance standards. 9.2 Assign and direct operational staff from onset to agreement termination.
9.3 To remunerate HGF on the basis of thirty percent (30%) of net Company income basis on an annual
basis commencing 12 months after the first full 12-month revenue period. 9.4 To purchase product
from the Company at a price of cost plus five percent (5%). 9.5 To issue two (2) million NVOS common
stock upon successful target of twenty-five million dollars ($25M) of net profit achieved by the
Company each fiscal year. NVOS common stock will be delivered to HGF via Novo Healthnet Limited
("NHL") exchangeable preferred shares. All parties understand NVOS is a U.S. reporting publicly
traded corporation and that any NVOS common shares issued, from exchanging the NHL exchangeable
preferred shares, will be provided under the guiding U.S. rules and regulations. Furthermore, all
parties understand these shares will carry the same rights and conditions, with no special terms or
conditions, as all NVOS common shares authorized for issue under the companies' Nevada Articles of
Incorporation. Any NVOS common stock issued to HGF, on or after the date hereof, is subject to
pro-rata adjustment in the event that NVOS shall, prior to the issuance date, approve any forward
stock split, reverse stock split or other capitalization re-structure.
<!-- page 7 -->
ARTICLE 10 - OBLIGATIONS OF HGF 10.1 To assist the Company in any way deemed necessary by the
Company in the marketing and sales of all cash crops associated to the Primary Project both
domestically and internationally. 10.2 To maintain positive relations with agencies (government and
environmental) ensuring continuing land use and development. 10.3 To promote and maintain positive
public relations activities ensuring positive Company public opinion. 10.4 To grow medicinal
agriculture crop at the highest standard, subject to independent third party biomass testing. 10.5
To grow in the most profitable manner while maintaining the standards of excellence required to
maintain elite status. 10.6 To provide a minimum of seven thousand (7000) acres for the Primary
Project to be identified by each individual lot, including size, and its placement in the annual
rotation as per SCHEDULE A. ARTICLE 11 - MANAGEMENT PERSONNEL 11.1 All staffing, including but not
limited to, management, specialized or general labor requirements for farming will be the sole
responsibility of HGF. ARTICLE 12 - DIVIDEND DISTRIBUTIONS 12.1 The distribution will be based on
NVOS audited review and will be made within three months of annual considerations on the basis of a
seventy percent (70%) of net profit to NVOS and thirty percent (30%) of net profit to HGF. 12.2 The
distribution will be based on NVOS audited review and will be made within three months of annual
considerations. ARTICLE 13 - CURRENCY 13.1 Except where otherwise expressly provided, all amounts of
monies referenced are in US dollars. ARTICLE 14 - BANKING AND ACCOUNTING 14.1 The Company will have
a segregated bank account controlled by NVOS for general operating expenses and a segregated
investment account for passive short-term secured investments. ARTICLE 15 - FINANCIAL STATEMENTS
15.1 The Company will prepare quarterly statements for review by the Parties, released on the 15th
day of each subsequent quarter.
<!-- page 8 -->
15.2 The Company's audited annual filing will be prepared in accordance to NVOS requirements for the
purposes of consolidation on a US GAAP accounting basis. 15.3 The Company's fiscal year is September
1 through August 31. ARTICLE 16 - TAXES 16.1 The Company will ensure timely remittance of all tax
liabilities and ensure specific adherence to any specific tax considerations. HGF will ensure
maximum tax reduction and where possible elimination of any tax consideration. ARTICLE 17 -
PRESERVATION OF RECORDS 17.1 All company records will be kept for a minimum of five (5) years unless
otherwise required by federal or provincial law. ARTICLE 18 - ASSIGNMENT BY NVOS 18.1 During the
term of this agreement NVOS shall have the right to assign, transfer or sell all or part of its
interest in the agreement upon the terms and conditions herein, subject only to prior written notice
to HGF. ARTICLE 19 - ASSIGNMENT BY HGF 19.1 During the term of this agreement HGF shall have the
right, upon written approval of NVOS, to assign, transfer or sell all or part of their interest in
this agreement. ARTICLE 20 - BEST EFFORTS 20.1 NVOS and HGF covenant and agree to make their best
efforts to fully develop the Primary Projects as well as all projects associated to this agreement
as per this agreement at all times faithfully, honestly and diligently perform or cause to be
performed their obligations hereunder and to continuously exert best efforts to promote and enhance
the business and in that regards they hereby covenant and agree, so long as this Agreement shall
remain in effect, to operate the business, as to preserve, maintain and enhance the reputation of
NVOS and HGF through the Company. ARTICLE 21 - DISPUTES 21.1 The Parties shall negotiate in good
faith and make every effort to settle any dispute, or claim, that may arise out of, or relate to,
the Agreement. If agreement cannot be reached, an aggrieved Party shall, if he intends to proceed
further in terms of Section 21.2 hereof, advise all other Parties in writing that negotiations have
failed and that he intends to refer the matter to mediation in terms of Section 21.2. 21.2 Not
earlier than ten (10) working days after having advised the other Party, in terms of Section 21.2,
that negotiations in regard to a dispute have failed, an aggrieved Party may require that the
dispute be referred, without legal representation, to mediation by a single mediator. The mediator
shall be selected by agreement between the Parties. The costs of the mediation shall be borne
equally by the Parties.
<!-- page 9 -->
The mediator shall convene a hearing of the Parties and may hold separate discussions with either
Party and shall assist the Parties in reaching a mutually acceptable settlement of their differences
through means of reconciliation, interpretation, clarification, suggestion and advice. The Parties
shall record such agreement in writing and thereafter they shall be bound by such agreement. The
mediator is authorised to end the mediation process whenever in his opinion further efforts at
mediation would not contribute to a resolution of the dispute between the Parties. 21.3 Where a
dispute or claim is not resolved by mediation, it shall be referred to arbitration by a single
arbitrator to be selected by agreement between the Parties. The Party requiring referral to
arbitration shall notify the other Party, in writing, thereof, not later than thirty (30) calendar
days after the mediator has expressed his opinion, failing which the mediator's opinion shall be
deemed to have been accepted by the Parties and shall be put into effect. Arbitration shall be
conducted in accordance with the provisions of the Arbitration Act No. 42 of 1965, as amended, and
in accordance with such procedure as may be agreed by the Parties or, failing such agreement, in
accordance with the rules for the Conduct of Arbitrations published by the Association of
Arbitrators and current at the date that the arbitrator is appointed. The decisions of the
arbitrator shall be final and binding on the Parties, shall be carried into immediate effect and, if
necessary, be made an order of any court of competent jurisdiction. ARTICLE 22 - INDEMNIFICATION
22.1 The Parties agree to mutually defend, indemnify and save one another harmless from and against
any claims, demands, actions, losses, damages, costs, charges, liabilities and any expenses,
including legal fees of whatever kind arising out of or in connection with each parties' activities
conducted pursuant to this Agreement. ARTICLE 23 - CONFORMITY WITH LAWS 23.1 In this Agreement, the
singular includes the plural and the masculine includes the feminine and neuter and vice versa
unless the context otherwise requires. 23.2 If any provision or part of any provision in this
Agreement is void for any reason or found to be unenforceable, it may be severed without affecting
the validity and enforceability of the balance of the Agreement. 23.3 This Agreement binds and
benefits the parties and their respective heirs, executors, administrators, personal
representatives, successors and assigns. 23.4 This Agreement contains the sole and entire agreement
between the parties and supersedes any and all other agreements, both verbal and written, between
them.
<!-- page 10 -->
23.5 The parties agree that neither of them has made any representations with respect to the subject
matter of this Agreement, or any representations inducing the execution and delivery hereof, except
such representations as are specifically set forth herein. ARTICLE 24 - CONFIDENTIALITY 24.1 The
parties shall keep confidential all business terms and conditions of this Agreement and neither
shall release such information to any other party without the express written consent of the other,
in the case of NVOS, it is understood that NVOS will be filing this Agreement with the Security
Exchange Commission of the United States of America in a matter compliant to publicly listed company
rules. ARTICLE 25 - ENTIRE AGREEMENT 25.1 No waiver or modification of this Agreement or of any
covenant, condition or limitation herein contained shall be valid unless in writing and duly
executed by the party to be charged therewith. 25.2 Furthermore, no evidence of any waiver or
modification shall be offered or received in evidence in any proceeding, arbitration, or litigation
between the parties arising out of or affecting this agreement, or the rights or obligations of any
party hereunder, unless such waiver or modification is in writing, duly executed as aforesaid. 25.3
The provisions of this paragraph may not be waived as set forth herein. [Signatures Appear on
Following Page]
<!-- page 11 -->
ARTICLE 26 - AFFIRMATION AND EXECUTION Novo Integrated Sciences Inc. By: /s/ Robert Mattacchione
Name: Robert Mattacchione Title: CEO Date: December 19, 2019 Address for Notices: 119 Westcreek
Drive Unit 1 Woodbridge, Ontario, Canada, L4L 9N6 Email: xxxxxxxxx@xxxxxxx.com Harvest Gold Farms
Inc. By: /s/ Michael Scully Name: Michael Scully, BBA J.D. Title: President Date: December 19, 2019
Address for Notices: 866 E. H. Daigle Blvd. Grand Falls, New Brunswick, Canada, E3Z 3E8 Email:
xxxxxxxxx@gmail.com
<!-- page 12 -->
<!-- page 13 -->
SCHEDULE A Acreage Identification for the Primary Project Disclosed in certificate of Robert
Mattacchione, dated December 18, 2019.
