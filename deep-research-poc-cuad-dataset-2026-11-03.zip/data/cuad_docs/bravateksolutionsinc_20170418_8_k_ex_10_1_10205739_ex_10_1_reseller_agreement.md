<!-- page 1 -->
# RESELLER AGREEMENT
| Field | Value |
|---|---|
| Document Type | Reseller Agreement |
| Agreement Date | 2017-04-07 |
| Parties | i3 Integrative Creative Solutions, LLC ("i3 ICS", "Reseller"); Bravatek Solutions, Inc. ("BVTK", "Company")("party" and collectively "parties") |
| Source | CUAD v1 / BravatekSolutionsInc_20170418_8-K_EX-10.1_10205739_EX-10.1_Reseller Agreement |

EXHIBIT 10.1 RESELLER AGREEMENT THIS RESELLER AGREEMENT (this "Agreement") is made and entered into
effect the 7th day of April, 2017 ("Effective Date"), by and between i3 Integrative Creative
Solutions, LLC ("i3 ICS"), a Virginia limited liability company, having its offices at 6564 Loisdale
Court Suite 1010B, Springfield, VA 22150 ("Reseller") and the company set forth below ("Company")
(each, individually, a "party" and collectively, "parties"): Company: Bravatek Solutions, Inc.
(BVTK) Telephone: 1-866-490-8590

Address:2028 E. Ben White Blvd., Suite 240-2835 Fax: N/A

Austin, Texas 78741 E-mail: tom.cellucci@bravatek.com

Territory: US Federal Government Civilian and Military Agencies/Customers in the U.S. Agreement
Term: 1 Year

Company Products: cybersecurity email software/telecom services Other Terms (not applicable if
blank):

Pricing: Reseller will obtain pricing quote from Company for each opportunity. Contract is renewable
for 1 year extension by amendment to this agreement. Either Party may terminate this agreement for
non-cause with a sixty (60) written notice. The parties agree as follows: 1. Definitions. a.
"Company" shall have the meaning assigned in the preamble. b. "Company Products" shall have the
meaning assigned in the preamble. c. "Effective Date" shall have the meaning assigned in the
preamble. d. "Marks" shall have the meaning assigned in Section 7. e. "Net Revenue" shall mean gross
receipts collected by Company or Reseller from the distribution of Company Products, [less third
party commissions, equipment sales, delivery costs, taxes, refunds, and credits. f. "Proprietary
Information" shall have the meaning assigned in Section 11. g. "Registered Referral" shall mean a
Named Account (i) for which "Reseller" identifies & creates the opportunity, provides Sales
Assistance (as defined below), and (ii) which leads to a direct sale with the "Company". Registered
Referrals may fall into two categories: Sales executed by the "Company", and via a third party's
prime contract. h. "Sales Assistance" shall mean (i) introductions to and scheduling meetings with
key executives at the Named Account (e.g., CxO, Vice President of Infrastructure and Vice President
of Application Development), and (ii) generating and delivering proposals and providing other
marketing and sales support necessary to close the opportunity and obtain an order from the Named
Account. 1

Source: BRAVATEK SOLUTIONS, INC., 8-K, 4/18/2017
<!-- page 2 -->
i. "Registered Opportunity" shall mean a Named Account (i) for which "Reseller" identifies & creates
the opportunity, and (ii) the "Reseller" purchases directly from the "Company" at a discount and
sells to the customer. j. "Fulfillment Transaction" shall mean a sale through the Reseller's
contract vehicle to a Federal Agency entity that is not a Registered Referral or Registered
Opportunity k. "Referral Fee" shall have the meaning assigned in Exhibit B. l. "Reseller" shall have
the meaning assigned in the preamble. m. "Territory" shall have the meaning assigned in the
preamble. 2. General Scope. Company develops or provides Company Products and desires that Reseller
promote and solicit commitments to buy Company Products in the Territory. 3. Reseller Activity.
Reseller shall have the right to solicit orders for Company Products within the Territory. In its
activities under this Agreement, Reseller shall use the then-current names for the Company Products
and any sales or marketing documentation or forms provided by Company. 4. Company Obligations.
Company shall provide Reseller with the support described in Exhibit B. Company shall comply with
good business practices and all applicable laws and regulations. During the term of this Agreement,
Company shall notify reseller of any changes, modifications or the discontinuation of any of the
Company Products within thirty (30) days. Company shall make reasonable accommodations for any
ongoing sales or existing sales. 5. Exclusivity on Registered Referrals and Opportunities. During
the Term hereof and for a period of six (6) months following the termination of this Agreement or
the discontinuation of any of the Company Products, (i) the Reseller shall have the exclusive right
to commission for any Registered Referrals, (ii) the Company shall not market, promote, sell, or
distribute Company Products or solicit or procure orders for the Company Products, or for any
product(s) or service(s) similar to the Company Products, in the Territory other than through the
Reseller and pursuant to this Agreement, except with the prior written consent of the Reseller, and
(iii) without limitation to the foregoing, the Company shall not, directly or through other parties
(whether agents, representatives, intermediaries, resellers or other parties), market, promote,
sell, distribute, solicit or procure orders to any existing or prospective customer of the Reseller.
6. Compensation. In the event that Reseller (i) refers a Registered Referral to Company, through
delivery to Company of the lead form attached hereto as Exhibit A, and (ii) such Registered Referral
executes an agreement to purchase any of such Company Products or services, then Company shall pay
Reseller a Referral Fee, as specified in Exhibit B attached hereto. Referral Fees will be paid
within thirty (30) days of the collection of receivables from the Registered Referral. In the event
an opportunity is requested and the government elects to use a different contract vehicle as
described in 1g, reseller will still receive Referral Fee outlined in exhibit B. 2

Source: BRAVATEK SOLUTIONS, INC., 8-K, 4/18/2017
<!-- page 3 -->
7. Trademarks, Trade Names and Other Designations. Subject to the terms of this Agreement, Company
grants Reseller the right to use and display the Company trademarks, tradenames and other
designations of source, and proprietary notices, slogans, designs and distinct advertising as may
appear on any documentation or other material with respect to Product ("Marks") with prior approval,
that will not be unreasonable withheld. 8. Warranty Disclaimer. RESELLER SHALL MAKE NO
REPRESENTATION, GUARANTEE, OR WARRANTY CONCERNING THE COMPANY PRODUCT EXCEPT AS EXPRESSLY AUTHORIZED
IN ADVANCE BY COMPANY IN WRITING. TO THE EXTENT THE RESELLER HAS COMPLIED WITH THE OBLIGATIONS SET
FORTH IN THIS SECTION, THE COMPANY SHALL INDEMNIFY AND HOLD HARMLESS THE RESELLER FOR ANY AND ALL
LOSSES SUFFERED BY THE RESELLER OR ITS AFFILIATES (WHETHER DIRECTLY OR IN CONNECTION WITH A CLAIM BY
A THIRD PARTY) AS A RESULT OF OR IN CONNECTION WITH THE COMPANY PRODUCTS. ADDITIONALLY, THE RESELLER
SHALL INDEMNIFY AND HOLD HARMLESS THE COMPANY FOR ANY AND ALL LOSSES SUFFERED BY THE COMPANY OR ITS
AFFILIATES (WHETHER DIRECTLY OR IN CONNECTION WITH A CLAIM BY A THIRD PARTY) AS A RESULT OF OR IN
CONNECTION WITH THE RESELLER'S ACTIVITIES. 9. Relationship of Parties. The parties hereto expressly
understand and agree that each party is an independent contractor in the performance of each and
every part of this Agreement. 10. Termination. a. Unless terminated earlier as provided herein, this
Agreement shall have the Term set forth above (which commences on the Effective Date). b. This
Agreement may be terminated by Reseller for cause immediately upon the occurrence of any of the
following events: (i) if the use or sale of Company Products are enjoined due to any claim of
infringement of any U.S. patent or copyright or of any misappropriation of trade secrets; (ii) if
Company ceases to do business, or otherwise terminates its business operations; or (iii) if Company
breaches any provision of this Agreement and fails to fully cure such breach within fifteen (15)
business days of written notice from Reseller describing the breach. c. This Agreement may be
terminated by Company for cause immediately upon the occurrence of any of the following events: (i)
if Reseller ceases to do business, or otherwise terminates its business operations; or (ii) if
Reseller breaches any provision of this Agreement and fails to fully cure such breach within fifteen
(15) business days of written notice from Company describing the breach. d. Neither party shall
incur any liability whatsoever for any damage, loss or expenses of any kind suffered or incurred by
the other party arising from or incident to any termination of this Agreement, which complies with
the terms of the Agreement, whether or not the terminating party is aware of any such damage, loss
or expenses. 3

Source: BRAVATEK SOLUTIONS, INC., 8-K, 4/18/2017
<!-- page 4 -->
e. Upon termination or expiration of this Agreement, other than with respect to customers of the
Reseller existing at any time prior to the termination or expiration and with respect to ongoing
sales or prospective sales, Reseller (i) shall immediately discontinue any use of the name,
logotype, Marks or slogans of Company, (ii) shall immediately discontinue all representations or
statements from which it might be inferred that any relationship exists between the parties, (iii)
will cease to promote, solicit orders for or procure orders for the Product, (iv) will immediately
return to Company all Proprietary Information (as defined below) and any other information or
materials of Company in its possession, custody or control in whatever form held (including copies
or embodiments thereof relating thereto). Notwithstanding the foregoing, the right to payments
accruing prior to the termination or expiration shall survive termination or expiration of this
Agreement. 11. Proprietary Rights. Each party acknowledges that, in the course of performing its
duties under this Agreement, it may obtain from the other party, certain business, technical or
financial information, all of which is confidential and proprietary ("Proprietary Information"). The
parties shall, at all times, both during the term of this Agreement and after its termination, keep
in trust and confidence all such Proprietary Information of the other party, and shall not use such
Proprietary Information other than in the course of its duties as expressly provided in this
Agreement; nor shall a party or its employees disclose any such Proprietary Information of the other
to any person without such other party's prior written consent. Neither party shall be bound by this
Section with respect to information it can document has entered or later enters the public domain as
a result of no act or omission of the receiving party, or is lawfully received by such party from
third parties without restriction and without breach of any duty of nondisclosure by any such third
party. 12. Liability Limitation. EXCEPT FOR IN THE EVENT OF WILLFUL MISCONDUCT OR GROSS NEGLIGENCE,
THE RESELLER AND ITS AFFILIATES SHALL NOT BE LIABLE TO THE COMPANY, AND SHALL HAVE NO OBLIGATION TO
INDEMNIFY OR HOLD HARMLESS THE COMPANY, WITH RESPECT TO OR IN CONNECTION WITH ANY LOSS RESULTING
FROM OR CAUSED BY THE COMPANY PRODUCTS. 13. Indemnification. Company shall indemnify, defend and
hold Reseller and its officers, directors, employees, shareholders, agents, successors and assigns,
harmless from and against any claim, demand lawsuit, cause of action or losses of any nature
whatsoever, including reasonable attorneys' fees, suffered or incurred by Reseller or any of them,
arising out of, (i) any claim that the Company Products infringe any U.S. patent or copyright or
that the Company Products incorporate any misappropriated trade secrets or (ii) any claim for injury
or other loss to any person arising from the use of Company Products. Additionally, Reseller shall
indemnify, defend and hold Company and its officers, directors, employees, shareholders, agents,
successors and assigns, harmless from and against any claim, demand lawsuit, cause of action or
losses of any nature whatsoever, including reasonable attorneys' fees, suffered or incurred by
Company or any of them, arising out of, (i) any claim that the Reseller's Activities infringe any
U.S. Business law or that the Reseller's Activities violate any U.S. government process, procedure
or requirement or (ii) any claim for injury or other loss to any person arising from the use of
Reseller's Activities. 4

Source: BRAVATEK SOLUTIONS, INC., 8-K, 4/18/2017
<!-- page 5 -->
14. Miscellaneous. If any provision of this Agreement is held to be illegal or unenforceable, that
provision shall be limited or eliminated to the minimum extent necessary so that this Agreement
shall otherwise remain in full force and effect and enforceable. Except as otherwise expressly
provided herein, any provision of this Agreement may be amended or waived only with the written
consent of both parties. This Agreement may be executed in separate counterparts, each of which so
executed and delivered (including by emailed PDF) shall constitute an original, but all such
counterparts shall together constitute one and the same instrument. This Agreement shall be governed
by and construed under the laws of the Commonwealth of Virginia without regard to the conflicts of
law provisions thereof. This Agreement supersedes all prior agreements or discussions between the
parties with respect to the subject matter hereof. RESELLER Bravatek Solutions, Inc. I3 ICS, LLC By:
/s/ Philip A. Oakley By: /s/ Thomas A. Cellucci Name:Philip A. Oakley Name:Thomas A. Cellucci Title:
President Title: Chairman & CEO Date: April 17, 2017 Date: April 17, 2017 5

Source: BRAVATEK SOLUTIONS, INC., 8-K, 4/18/2017
<!-- page 6 -->
EXHIBIT A LEAD FORM Customer Info: Date:

Company Products: Purchase Price (in U.S. dollars): Total License Fee:

Term: Evaluation Term: [YES OR NO] 6

Source: BRAVATEK SOLUTIONS, INC., 8-K, 4/18/2017
<!-- page 7 -->
EXHIBIT B RESELLER COMPENSATION Earned Commission: Reseller will be compensated for Registered
Referrals and Registered Opportunities (as defined in Section 1g, 1i.) based on the following
schedule: Registered Referral:

· 25% of Net Revenue (as defined in Section 1e.) with a COMPANY-RESELLER AGREED UPON SALE PRICE in
writing, the case of COMPANY's software products. The Company's Telecom Services will be agreed upon
on a case-by-case basis in writing. Registered Opportunity:

· "Reseller" will purchase directly from the "Company" at a 25% discount off the COMPANY-RESELLER
AGREED UPONsale price.

· If sale is made through SEWP, there will be an additional 4% discount off the sale price to cover
the Prime contractusage fee (typically 7-10%) off the COMPANY-RESELLAR AGREED UPON SALE PRICE.
Fulfillment Transaction Discount (as defined in Section 1j): · "Reseller" will purchase directly
from the "Company" at a 7-10% discount off the sale price. Payment Terms: For a registered referral
where the customer purchases directly from Company or another channel/contract vehicle other than
Reseller, earned commissions are payable within thirty (30)days of when such amounts are collected
by Company. For a Registered Opportunity where the customer purchases from Reseller, payment will be
made by Reseller to Company within 5 days of receipt of payment (paid when paid). Expense
Reimbursement: Reimbursement will be provided ONLY for expenses PRE-APPROVED in writing by Company.
Marketing Expense: As may be agreed to by the parties in writing. 7

Source: BRAVATEK SOLUTIONS, INC., 8-K, 4/18/2017
<!-- page 8 -->
COMPANY SUPPORT OBLIGATIONS Product Training: Training on the Company products as needed. Marketing
Materials: Electronic and print copies of existing marketing material as needed. Company Personnel
Resources: · Access to technical resources for demonstrations and meetings · Access to Company
Customer Support Services 8

Source: BRAVATEK SOLUTIONS, INC., 8-K, 4/18/2017
