<!-- page 1 -->
# RESTATED NET INVESTMENT INCOME MAINTENANCE AGREEMENT
| Field | Value |
|---|---|
| Document Type | Maintenance Agreement |
| Agreement Date | 2012-05-01 |
| Parties | Advantus Capital Management, Inc. ("Investment Adviser”); Securian Financial Services, Inc. (“Underwriter”); Securian Funds Trust (“Trust”); Trust’s Advantus Money Market Fund (“Fund”) |
| Source | CUAD v1 / SECURIANFUNDSTRUST_05_01_2012-EX-99.28.H.9-NET INVESTMENT INCOME MAINTENANCE AGREEMENT |

Exhibit 28(h)(9)

RESTATED NET INVESTMENT INCOME MAINTENANCE AGREEMENT SECURIAN FUNDS TRUST

RESTATED NET INVESTMENT INCOME MAINTENANCE AGREEMENT, effective as of May 1, 2012, by and between
Advantus Capital Management, Inc. (the "Investment Adviser"), Securian Financial Services, Inc. (the
"Underwriter") and Securian Funds Trust (the "Trust"), a Delaware statutory trust, on behalf of the
Trust's Advantus Money Market Fund (the "Fund").

WHEREAS, pursuant to an Agreement and Plan of Reorganization approved by both the Board of Trustees
of the Trust and the Board of Directors of Advantus Series Fund, Inc. (the "Series Fund") on July
28, 2011, and approved by a majority of the shareholders of each Portfolio of the Series Fund on
October 21, 2011, each Portfolio of the Series Fund was reorganized into a separate Fund of the
Trust effective as of May 1, 2012; and

WHEREAS, the Investment Adviser, the Underwriter and the Series Fund have previously entered into a
Net Investment Income Maintenance Agreement, effective as of February 1, 2009 and an Amended and
Restated Net Investment Income Maintenance Agreement effective as of October 29, 2009 (the "Prior
Agreements"); and

WHEREAS, the parties have determined that each desires to restate and adopt the Prior Agreements as
set forth herein; and

WHEREAS, the Trust is registered under the Investment Company Act of 1940, as amended (the "1940
Act"), as an open-end management company of the series type, and the Fund is a series of the Trust;
and

WHEREAS, the Trust and the Investment Adviser have entered into an Investment Advisory Agreement
dated May 1, 2012 (the "Advisory Agreement"), pursuant to which the Investment Adviser will render
investment advisory services to the Fund for compensation based on the value of the average daily
net assets of the Fund; and

WHEREAS, the Trust and the Underwriter have entered into an Underwriting and Distribution Agreement
dated May 1, 2012 (the "Underwriting Agreement") pursuant to which the Underwriter acts the
principal underwriter for the Fund, and receives compensation thereunder pursuant to the Fund's Rule
12b-1 Plan; and

WHEREAS, the Trust and the Investment Adviser have determined that it is appropriate and in the best
interests of the Fund and its shareholders to maintain the Fund's daily "Net Investment Income" (as
defined in paragraph 1.1 below) at or in excess of zero.
<!-- page 2 -->
NOW, THEREFORE, the parties hereto agree as follows:

2

1. Net Investment Income Maintenance.

1.1 Net Investment Income. "Fund Investment Income", as defined in paragraph 1.2 below, minus "Fund
Operating Expenses" as defined in paragraph 1.3 below equals Net Investment Income. If the Fund's
Net Investment Income on any day is below zero, the Investment Adviser shall waive its Advisory Fee
or reimburse the Fund an amount (defined as "Expense Waiver") sufficient to produce a Net Investment
Income of zero.

1.2 Fund Investment Income. Fund Investment Income includes interest and dividends, net of foreign
withholding taxes, plus income from securities lending activities, if applicable. Fund Investment
Income does not include realized and unrealized gains or losses on investments and foreign
currencies.

1.3 Fund Operating Expenses. Fund Operating Expenses are the aggregate expenses of every character
incurred by the Fund, including but not limited to investment advisory fees of the Investment
Adviser (but excluding interest, taxes, brokerage commissions and other expenditures which are
capitalized in accordance with generally accepted accounting principles and other extraordinary
expenses not incurred in the ordinary course of the Fund's business). Fund Operating Expenses do not
include "acquired fund fees and expenses" as defined in SEC Form N-1A, as it may be amended from
time to time.

1.4 Method of Computing Expense Waiver. To determine the Expense Waiver (Investment Adviser's
liability), each day the Fund Operating Expenses shall be subtracted from the Fund Investment Income
to produce the daily Net Investment Income. If the daily Net Investment Income is below zero for any
day, the Investment Adviser shall first waive or reduce its advisory fee for such day by an amount
sufficient to bring the Net Investment Income to zero. If the amount of the waived or reduced
advisory fee for any such day is insufficient to bring the Net Investment Income to zero , the
Investment Adviser shall also pay Fund expenses or reimburse the Fund an amount that, together with
the waived or reduced advisory fee, is sufficient to bring the Net Investment Income to zero.

1.5 Right of Recovery. The Investment Adviser shall have the option to recover the full amount
waived, paid or reimbursed (the Expense Waiver) by the Investment Adviser on any day on which the
Fund's Net Investment Income exceeds zero. In no event, however, shall the Expense Waiver, or any
portion thereof, constitute an obligation of the Fund to the Investment Adviser on any such day
unless the Investment Adviser has expressly exercised its right to recover all or a portion of the
Expense Waiver on that day, in which case such portion of the Expense Waiver elected by the
Investment Adviser for recovery that day shall then be due and payable. If, and to the extent, the
payment by the Fund to the Investment Adviser of the Expense Waiver would cause the Fund's Net
Investment Income to fall below zero, such payment shall be deferred until such date on which the
<!-- page 3 -->
In connection with the obligation of the Investment Adviser to maintain the Fund's Net Investment
Income as set forth in section 1 herein, the Underwriter may waive its Rule 12b-1 fees contemplated
by the Underwriting Agreement, and shall have the same rights to be reimbursed by the Fund as the
Investment Adviser, as set forth in Section 1 herein, to the extent the Investment Adviser has not
already been reimbursed by the Fund for its payment of Rule 12b-1 fees.

This Agreement shall continue in effect for a period of one year from the date of its execution and
from year to year thereafter provided such continuance is specifically approved by a majority of the
trustees of the Trust who (i) are not "interested persons" of the Trust or any other party to this
Agreement, as defined in the 1940 Act, and (ii) have no direct or indirect financial interest in the
operation of this Agreement ("Non- Interested Trustees"). This Agreement will terminate upon the
termination of the Advisory Agreement except the Investment Adviser's Right of Recovery set forth in
section 1.5 herein.

3

payment would not cause the Fund to have a Net Investment Income of less than zero, provided that
the right of the Investment Adviser to receive such payment shall expire three years after the day
it effected such waiver, or made such payment or reimbursement. For purposes of this paragraph 1.5
(and for purposes of paragraph 2), the Expense Waiver that may be recovered from the Fund shall
include the amount of any unrecovered Expense Waiver under the Prior Agreements, provided that the
Investment Adviser's right to receive such payment shall also expire three years after the day it
effected such waiver, or made such payment or reimbursement.

1.6 Payment. If the Investment Adviser is required to reimburse the Fund, the Investment Adviser
shall make such payment within 30 days after each month-end in the amount due the Fund as of each
month. If the Fund is required to pay the Investment Adviser the Expense Waiver, the Fund shall make
such payment within 30 days after each month-end. Reimbursements to the Fund or the Expense Waiver
shall not include any additional charges or fees whatsoever, including, e.g., interest accruable on
such reimbursements or the Expense Waiver.

1.7 Operating Expense Limit. Any Expense Waiver recovery payment by the Fund to the Investment
Adviser shall not cause the Operating Expense for the Fund's full year of operations to exceed 1.25%
of the Fund's average daily net assets.

2. The Underwriter.

3. Term and Termination of Agreement.

4. Miscellaneous.

4.1 Captions. The captions in this Agreement are included for convenience of reference only and in
no other way define or delineate any of the provisions hereof or otherwise affect their construction
or effect.
<!-- page 4 -->
IN WITNESS WHEREOF, the parties hereto have caused this Agreement to be duly executed as of the day
and year first above written.

4

4.2 Interpretation. Nothing herein contained shall be deemed to require any party hereto to take any
action contrary to its Articles of Incorporation or Agreement and Declaration of Trust or By-Laws,
or any applicable statutory or regulatory (including self-regulatory) requirement to which it is
subject or by which it is bound.

4.3 Definitions. Any question of interpretation of any term or provision of this Agreement,
including, but not limited to the investment advisory or Rule 12b-1 fee, the computations of net
asset values, and the allocation of expenses, having a counterpart in or otherwise derived from the
terms and provisions of the Advisory Agreement, the Underwriting Agreement, or the 1940 Act, shall
have the same meaning as and be resolved by reference to such Advisory Agreement, the Underwriting
Agreement, or the 1940 Act.

SECURIAN FUNDS TRUST

By: /s/ David M. Kuplic Name: David M. Kuplic Title: President

ADVANTUS CAPITAL MANAGEMENT, INC.

By: /s/ Robert L. Senkler Name: Robert L. Senkler Title: President

SECURIAN FINANCIAL SERVICES, INC.

By: /s/ George I. Connolly Name: George I. Connolly Title: President and CEO
