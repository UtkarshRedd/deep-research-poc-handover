# What maximum Leverage Ratio applies to Halvorsen Marine Holdings as of 2025-05-01

*Question:* What maximum Leverage Ratio applies to Halvorsen Marine Holdings as of 2025-05-01?

## Regulatory Framework — Maximum Permitted Leverage Ratio

The Credit Agreement dated 2025-02-14 originally set the maximum Leverage Ratio at 4.00 to 1.00, as stated in Section 7.1. [uncited] However, the First Amendment, effective 2025-07-31, increased this limit to 4.50 to 1.00. [uncited] Since 2025-05-01 falls before the First Amendment Effective Date, the original limit of 4.00 to 1.00 applies. [8b969cb203b8817e p.3] [8b969cb203b8817e p.9] [5734789b958179bc p.2]

## Current Ratio Determination — Actual Leverage Ratio as of 2025-05-01

The actual Leverage Ratio of Halvorsen Marine Holdings as of 2025-05-01 cannot be determined from the provided evidence, as no financial data or ratio calculations are included. [uncited] The First Amendment effective date of 2025-07-31  is after the date in question, indicating that the pre-amendment covenant terms govern as of 2025-05-01, but the maximum Leverage Ratio applicable under those terms is not stated in the evidence. [5734789b958179bc p.1]

[GAP]

## Verification appendix

Claims: 6 · supported: 2 · partially: 0 · dropped: 0 · gaps: 4 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  | no evidence cited |
| s1.2 | s1 | gap |  |  | no evidence cited |
| s1.3 | s1 | keep | 1.00 | e1→[8b969cb203b8817e p.3] e2→[8b969cb203b8817e p.9] e4→[5734789b958179bc p.2] |  |
| s2.1 | s2 | gap |  |  | no evidence cited |
| s2.2 | s2 | keep | 1.00 | e3→[5734789b958179bc p.1] |  |
| s2.3 | s2 | gap |  |  |  |

### Evidence

- e1 [8b969cb203b8817e p.3 L33-33] keep (1.0): ""Leverage Ratio" means, as of the last day of any fiscal quarter, the ratio of Consolidated Total Debt as of such day to Consolidated EBITDA for the period of four consecutive fiscal quarters then ended."
- e2 [8b969cb203b8817e p.9 L75-75] keep (1.0): "Section 7.1 Maximum Leverage Ratio. The Borrower shall not permit the Leverage Ratio as of the last day of any fiscal quarter to exceed 4.00 to 1.00."
- e3 [5734789b958179bc p.1 L6-7] keep (1.0): "| Effective Date | 2025-07-31 |
| Parties | Halvorsen Marine Holdings, Inc.; Meridian Trust Bank, N.A. |"
- e4 [5734789b958179bc p.2 L19-20] keep (1.0): "Effective as of the First Amendment Effective Date, the Credit Agreement is amended as follows: 1.1 Section 7.1 is amended by replacing "4.00 to 1.00" with "4.50 to 1.00", so that the Borrower shall not permit the Leverage Ratio as of the l…"
