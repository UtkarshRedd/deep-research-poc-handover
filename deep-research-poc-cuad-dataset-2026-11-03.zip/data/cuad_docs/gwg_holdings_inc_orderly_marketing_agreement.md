<!-- page 1 -->
# ORDERLY MARKETING AGREEMENT
| Field | Value |
|---|---|
| Document Type | Marketing Agreement |
| Agreement Date | 2018-12-27 |
| Parties | GWG Holdings, Inc. ("GWG"); Trust Advisors to the Seller Trusts ("Trust Advisors"); GWG and Trust Advisors (each a “Party” and collectively as the “Parties”) |
| Source | CUAD v1 / GWG HOLDINGS, INC. - ORDERLY MARKETING AGREEMENT |

Exhibit 10.3 Execution Version GWG HOLDINGS, INC., AND THE TRUST ADVISORS TO THE SELLER TRUSTS
LISTED ON SCHEDULE A HERETO ORDERLY MARKETING AGREEMENT December 27, 2018
<!-- page 2 -->
ORDERLY MARKETING AGREEMENT THIS ORDERLY MARKETING AGREEMENT (the "OMA") is entered into on December
27, 2018 (the "Effective Date") by and among GWG Holdings, Inc., a Delaware corporation ("GWG"), and
the Trust Advisors to the Seller Trusts listed on Schedule A hereto (the "Trust Advisors"), and any
other person or entity that becomes a party to this Agreement by executing and delivering a joinder
hereto in the form attached as Exhibit A. Each of GWG and the Trust Advisors may be referred to
herein as a "Party" and collectively as the "Parties." WHEREAS, on January 18, 2018, GWG, the Trust
Advisors and certain other entities entered into that certain Amended and Restated Master Exchange
Agreement, with effect from January 12, 2018, as amended from time to time (the "Master Agreement");
and WHEREAS, the Trust Advisors are at all times acting hereunder as the representatives of and for
the benefit of each Seller Trust named in the Master Agreement; WHEREAS, pursuant to Section 8.6 of
the Master Agreement, GWG and the Trust Advisors agree to negotiate in good faith the terms of an
agreement with one or more nationally recognized bulge bracket investment banks for the orderly
marketing and resale of certain shares (the "Shares") of common stock, par value $0.001 per share
(the "Stock") of GWG issued in reliance upon available exemptions from the Securities Act of 1933,
as amended (the "Act"), under the terms of the Master Agreement to such Seller Trusts for the
purpose of facilitating the establishment of a broader shareholder base and creating on-going
liquidity in Stock; WHEREAS, contemporaneous with the execution of this OMA, the Trust Advisors and
certain other entities are entering into a registration rights agreement (the "Registration Rights
Agreement") pursuant to which GWG is agreeing to file a registration statement on Form S-1 or other
appropriate form (the "Registration Statement") with the Securities and Exchange Commission ("SEC")
for the public offering of the Shares; WHEREAS, the entry into this OMA is a condition to the
obligation of each of GWG and the Seller Trusts to consummate the various transactions contemplated
by the Master Agreement; NOW, THEREFORE, FOR GOOD AND VALUABLE CONSIDERATION, the receipt and
sufficiency of which is hereby acknowledged, the Parties agree as follows: Section 1. Orderly
Marketing. 1.1 The shares of Stock held by each Seller Trust and subject to this OMA shall be as set
out on Schedule A hereto, which Schedule may be amended from time to time in writing by the Parties
in accordance with Section 4.1 below. 1.2 It is the goal of the Seller Trusts to have all of the
Shares sold, on a pro-rata basis, in three or more tranches (each a "Tranche") commencing not
earlier than six (6) months after the Effective Date with the resale of all of the shares of Stock
completed as soon as practicable after the Effective Date.

- 2 -
<!-- page 3 -->
1.3 [Reserved]. 1.4 The Seller Trusts and GWG intend to retain one or more nationally recognized
bulge bracket investment banks (the "Bank") for the orderly marketing and resale of Shares pursuant
to a separate engagement letter (the "Engagement Letter") to advise them in connection with the sale
of the Tranches (together, the "Offerings"). Such Engagement Letter shall include customary
representations, warranties, covenants and indemnification provisions. The services to be performed
by the Bank shall be set forth in such Engagement Letter and are expected to include, among others:
(a) assisting in the drafting and preparation of one or more prospectus supplements describing GWG,
the Shares and the terms of the Offerings; (b) advising the Seller Trusts on a marketing and
distribution strategy for each Tranche of Shares, including whether a particular Tranche should be
sold through a block trade, overnight bookbuild, or similar transaction; (c) assisting GWG in
preparing marketing materials and conducting one or more "roadshows" and meetings with potential
purchasers of the Shares; (d) advising the Seller Trusts as to the timing, structure and pricing of
the Offerings; (e) providing other advisory services as are customary for similar transactions. The
Engagement Letter shall include a requirement that, prior to any distribution of Stock by the Bank
as contemplated by this Agreement, the Bank shall consult with each of GWG and the Trust Advisors as
to the strategy for the marketing, sale and distribution of the respective Tranche. 1.5 After the
Parties have agreed on the strategy for the marketing, sale and distribution of a Tranche, the
Seller Trusts shall offer the Bank the right to serve as the lead left joint-book-running manager in
connection with a best efforts distribution. GWG shall be entitled to appoint, in its discretion, an
additional bank as joint book-running manager to participate in the distribution. The Seller Trusts
further agree that in the event the Bank accepts such role it will be paid customary fees for the
performance of its services in connection with such transactions and that such engagement will
involve the execution of a standard form agreement with respect to the distribution of each Tranche,
which may be in the form of a placement agency agreement, underwriting agreement or other
appropriate agreement (each, a "Distribution Agreement"); provided, however, that nothing contained
in this OMA or Engagement Letter shall require the Bank to underwrite or purchase all or any portion
of a Tranche of Stock for its own account. Notwithstanding the foregoing, it is understood and
agreed that the Bank or its affiliates may, solely at its discretion and without any obligation to
do so, purchase Stock in any Tranche as principal.

- 3 -
<!-- page 4 -->
1.6 Each such Distribution Agreement shall set out the customary terms and conditions for the sale
and distribution of the respective Tranche, including customary representations, warranties,
covenants and indemnification provisions. For the avoidance of doubt, each Distribution Agreement
shall include provisions to the following effect: (i) GWG shall have no responsibility for the
payment of fees or commissions payable to the Bank, which fees and commissions shall be the
responsibility of certain affiliates of the Seller Trusts as set forth in the applicable
Distribution Agreement; and (ii) each of GWG and the Seller Trusts shall agree to provide a
customary indemnity in favor of the Bank and its affiliates. 1.7 If, in connection with the
marketing, sale and distribution of a Tranche, the Bank determines that the number of Shares of
Stock proposed to be included in the Tranche exceeds the number that can reasonably be sold, then
the number of Shares of Stock shall be reduced accordingly on a pro-rata basis with respect to each
of the Seller Trusts. 1.8 Prior to the offering of each Tranche, GWG shall provide the placement
agents or underwriters in such Offering a list of the top 100 institutional holders of the Common
Stock. In connection with any Offering, the Seller Trusts shall instruct the placement agents or
underwriters to use their reasonable best efforts to (i) effect as wide a distribution of the Shares
as is reasonably practicable without adversely affecting the pricing thereof and (ii) not sell any
Shares to any person or Group (as such terms is used in Section 13(d)(3) of the Securities Exchange
Act of 1934, as amended (the "Exchange Act")) who, upon completion of the Offering, would have
Beneficial Ownership (as defined in Rule 13d-3 under the Exchange Act) of shares of Common Stock
representing in the aggregate 5.0% or more the total number of outstanding shares of Common Stock
(or in the case of a person of the type described in Rule 13d-1(b)(1)(i) under the Exchange Act, 10%
or more of the Total Voting Power). Section 2. Compensation. The Engagement Letter shall provide
that the Bank shall not be entitled to any compensation for its advice hereunder or reimbursement of
its expenses in connection with this OMA and shall only be entitled to compensation in connection
with an Offering as provided in the Engagement Letter and related Distribution Agreement with
respect to such Offering. Section 3. [Reserved] Section 4. General Provisions. 4.1 Term;
Termination; Withdrawal of Bank. (a) This OMA shall expire upon the earlier of (i) the first
anniversary of the Effective Date and (ii) the date that all Shares of Stock of the Seller Trusts as
set forth on Schedule A hereto have been sold (the "Term"). Notwithstanding the foregoing, this OMA
may be terminated with or without cause at any time after the Effective Date and without liability
or continuing obligation by any of the Parties hereto (i) by mutual written agreement of all of the
Parties; and (ii) in writing by the Trust Advisors in their sole discretion.

- 4 -
<!-- page 5 -->
(b) The Engagement Letter shall provide that the Bank may terminate its engagement at any time upon
not less than 45 days' prior written notice to the other Parties. In the event the Bank provides
such notice at any time prior to the sale of greater than 50% of the Shares and within 12 months of
the Effective Date, then GWG and the Trust Advisors may elect (A) to terminate this OMA or (B) to
continue this OMA and to seek to appoint a substitute investment bank, in which case GWG, after
consultation with the Trust Advisors, shall be entitled to appoint a substitute investment bank to
serve as the lead joint-book-running manager for the sale of the Shares. In the event the Bank
terminates the Engagement Letter at any time following the sale of greater than 50% of the Shares
and within 12 months of the Effective Date, the termination thereof shall constitute a concurrent
Termination of this OMA. 4.2 Amendments and Waivers. This OMA may be amended or modified in whole or
in part, only by duly authorized agreement in writing executed by each of the Parties. 4.3 Notices.
All notices and other communications among the Parties shall be in writing and shall be deemed to
have been duly given (i) when delivered in person, (ii) when delivered after posting in the United
States mail having been sent registered or certified mail return receipt requested, postage prepaid,
(iii) when delivered by FedEx or other nationally recognized overnight delivery service or (iv) when
received by facsimile or email (provided that a copy is subsequently delivered by one of the other
methods permitted in (i) through (iii) of this Section 4.3), addressed as follows: If to GWG: 220 S.
Sixth Street, Suite 1200 Minneapolis, MN 55402 Attention: Jon R. Sabes, CEO Email:
jsabes@gwglife.com If to the Trust Advisors on behalf of the Seller Trusts: Jeffrey S. Hinkle Murray
T. Holland As Trust Advisors to Each of the Seller Trusts set forth on Schedule A hereto c/o The
Beneficient Company Group, L.P. 325 N. St. Paul Street, Suite 4850 Dallas, Texas 75201 Email:
jhinkle@beneficient.com; mholland@mhtpartners.com

- 5 -
<!-- page 6 -->
4.4 Assignments and Transfers by Seller Trusts. The provisions of this OMA shall be binding upon and
inure to the benefit of the Seller Trusts and their respective successors and assigns. A Seller
Trust may transfer or assign, in whole or from time to time in part, to one or more liquidating
trusts its rights hereunder in connection with the transfer or resale of Stock held by such Seller
Trust, provided that such Seller Trust complies with all laws applicable thereto and provides
written notice of assignment to GWG promptly after such assignment is effected, and provided further
that such liquidating trust and each beneficiary thereof executes a joinder to this OMA effective as
of the date of such assignment or transfer. 4.5 Counterparts. This OMA may be executed in two or
more counterparts, each of which shall be deemed an original, but all of which together shall
constitute one and the same instrument. 4.6 Severability. Any provision of this OMA that is
prohibited or unenforceable in any jurisdiction shall, as to such jurisdiction, be ineffective to
the extent of such prohibition or unenforceability without invalidating the remaining provisions
hereof but shall be interpreted as if it were written so as to be enforceable to the maximum extent
permitted by applicable law, and any such prohibition or unenforceability in any jurisdiction shall
not invalidate or render unenforceable such provision in any other jurisdiction. To the extent
permitted by applicable law, the Parties hereby waive any provision of law which renders any
provisions hereof prohibited or unenforceable in any respect. 4.7 Further Assurances. The Parties
shall execute and deliver all such further instruments and documents and take all such other actions
as may reasonably be required to carry out the transactions contemplated hereby and to evidence the
fulfillment of the agreements herein contained. 4.8 Entire Agreement. This OMA is intended by the
Parties as a final expression of their agreement and intended to be a complete and exclusive
statement of the agreement and understanding of the Parties hereto in respect of the subject matter
contained herein. This OMA supersedes all prior agreements and understandings between the Parties
with respect to such subject matter. 4.9 Governing Law; Consent to Jurisdiction; Waiver of Jury
Trial. This OMA, and all claims or causes of action (whether in contract or tort) that may be based
upon, arise out of or relate to this OMA or the negotiation, execution or performance of this OMA
(including any claim or cause of action based upon, arising out of or related to any representation
or warranty made in or in connection with this OMA), will be construed in accordance with and
governed by the law of the State of New York without regard to principles of conflicts of laws that
would result in the application of the law of any other jurisdiction. Any action against any Party
relating to the foregoing shall be brought in any federal or state court of competent jurisdiction
located within the State of New York, and the Parties hereto hereby irrevocably submit to the
non-exclusive jurisdiction of any federal or state court located within the State of New York over
any such action. The Parties hereby irrevocably waive, to the fullest extent permitted by applicable
law, any objection which they may now or hereafter have to the laying of venue of any such dispute
brought in such court or any defense of inconvenient forum for the maintenance of such dispute. Each
of the Parties hereto agrees that a judgment in any such dispute may be enforced in other
jurisdictions by suit on the judgment or in any other manner provided by law.

- 6 -
<!-- page 7 -->
EACH PARTY TO THIS AGREEMENT HEREBY WAIVES, AND AGREES TO CAUSE ITS AFFILIATES TO WAIVE, TO THE
FULLEST EXTENT PERMITTED BY LAW, ANY RIGHT TO TRIAL BY JURY OF ANY CLAIM, DEMAND, ACTION OR CAUSE OF
ACTION (A) ARISING UNDER THIS AGREEMENT OR (B) IN ANY WAY CONNECTED WITH OR RELATED OR INCIDENTAL TO
THE DEALINGS OF THE PARTIES HERETO IN RESPECT OF THIS AGREEMENT OR ANY OF THE TRANSACTIONS RELATED
HERETO, IN EACH CASE WHETHER NOW EXISTING OR HEREAFTER ARISING, AND WHETHER IN CONTRACT, TORT,
EQUITY OR OTHERWISE. EACH PARTY TO THIS AGREEMENT HEREBY AGREES AND CONSENTS THAT ANY SUCH CLAIM,
DEMAND, ACTION OR CAUSE OF ACTION SHALL BE DECIDED BY COURT TRIAL WITHOUT A JURY AND THAT THE
PARTIES TO THIS AGREEMENT MAY FILE AN ORIGINAL COUNTERPART OF A COPY OF THIS AGREEMENT WITH ANY
COURT AS WRITTEN EVIDENCE OF THE CONSENT OF THE PARTIES HERETO TO THE WAIVER OF THEIR RIGHT TO TRIAL
BY JURY. 4.10 Certain Representations of the Parties. Each of the Parties hereto represents, several
and not jointly, that it has taken all action required of it to duly authorize this OMA and that no
further action or approval is required on its behalf and, when executed and delivered, this OMA
constitutes a valid and binding obligation of such Party, enforceable in accordance with its terms.
4.11 Further Assurances. Each Party agrees to take such further action that may be reasonably
required of it, and to execute such documents or instruments, in order to effectuate the
transactions contemplated by this OMA. 4.12 Seller Trusts and Trust Advisors. It is expressly
understood and agreed that (a) this document is executed and delivered by Delaware Trust Company,
not individually or personally, but solely as Trustee, pursuant to direction from the Trust Advisors
and in the exercise of the powers and authority conferred and vested in Delaware Trust Company as
Trustee pursuant to the Trust Agreements of the Seller Trusts (the "Trust Agreements") and the
Trustee is governed by and subject to the Trust Agreements and entitled to the protections, rights
and benefits contained therein, (b) each of the representations, undertakings and agreements herein
made on the part of the Seller Trusts and Trust Advisors is made and intended not as personal
representations, undertakings and agreements by Delaware Trust Company but is made and intended for
the purpose for binding only the Seller Trusts and respective trust estates (the "Seller Trust
Assets"), (c) nothing herein contained shall be construed as creating any liability on Delaware
Trust Company, individually or personally, to perform any covenant either expressed or implied
contained herein, all such liability, if any, being expressly waived by the parties hereto and by
any person claiming by, through or under the parties hereto, (d) under no circumstances shall
Delaware Trust Company be personally liable for the payment of any indebtedness or expenses of the
Seller Trusts or Trust Advisors or be liable for the breach or failure of any obligation,
representation, warranty or covenant made or undertaken by the Seller Trusts or Trust Advisors under
this Agreement or any other related documents, and (e) under no circumstances shall the Trust
Advisors be personally liable for the payment of any indebtedness or expenses or be liable for the
breach or failure of any obligation, representation, warranty or covenant made or undertaken under
this Agreement, all such recourse being strictly to the Seller Trust Assets. [Remainder of Page
Intentionally Left Blank; Next Page is Signature Page]

- 7 -
<!-- page 8 -->
IN WITNESS WHEREOF, the Parties hereto have executed this OMA as of the date first set forth above.
GWG HOLDINGS, INC. By: /s/ Jon R. Sabes Name: Jon R. Sabes, CEO THE LT-1 EXCHANGE TRUST, By:
DELAWARE TRUST COMPANY, not in its individual capacity but solely as Trustee By: /s/ Alan R. Halpern
Name: Alan R. Halpern Title: Vice President THE LT-2 EXCHANGE TRUST, By: DELAWARE TRUST COMPANY, not
in its individual capacity but solely as Trustee By: /s/ Alan R. Halpern Name: Alan R. Halpern
Title: Vice President

- 8 -
<!-- page 9 -->
THE LT-3 EXCHANGE TRUST, By: DELAWARE TRUST COMPANY, not in its individual capacity but solely as
Trustee By: /s/ Alan R. Halpern Name: Alan R. Halpern Title: Vice President THE LT-4 EXCHANGE TRUST,
By: DELAWARE TRUST COMPANY, not in its individual capacity but solely as Trustee By: /s/ Alan R.
Halpern Name: Alan R. Halpern Title: Vice President THE LT-5 EXCHANGE TRUST, By: DELAWARE TRUST
COMPANY, not in its individual capacity but solely as Trustee By: /s/ Alan R. Halpern Name: Alan R.
Halpern Title: Vice President THE LT-6 EXCHANGE TRUST, By: DELAWARE TRUST COMPANY, not in its
individual capacity but solely as Trustee By: /s/ Alan R. Halpern Name: Alan R. Halpern Title: Vice
President

- 9 -
<!-- page 10 -->
THE LT-7 EXCHANGE TRUST, By: DELAWARE TRUST COMPANY, not in its individual capacity but solely as
Trustee By: /s/ Alan R. Halpern Name: Alan R. Halpern Title: Vice President THE LT-8 EXCHANGE TRUST,
By: DELAWARE TRUST COMPANY, not in its individual capacity but solely as Trustee By: /s/ Alan R.
Halpern Name: Alan R. Halpern Title: Vice President THE LT-9 EXCHANGE TRUST, By: DELAWARE TRUST
COMPANY, not in its individual capacity but solely as Trustee By: /s/ Alan R. Halpern Name: Alan R.
Halpern Title: Vice President THE LT-12 EXCHANGE TRUST, By: DELAWARE TRUST COMPANY, not in its
individual capacity but solely as Trustee By: /s/ Alan R. Halpern Name: Alan R. Halpern Title: Vice
President

- 10 -
<!-- page 11 -->
THE LT-13 EXCHANGE TRUST, By: DELAWARE TRUST COMPANY, not in its individual capacity but solely as
Trustee By: /s/ Alan R. Halpern Name: Alan R. Halpern Title: Vice President THE LT-14 EXCHANGE
TRUST, By: DELAWARE TRUST COMPANY, not in its individual capacity but solely as Trustee By: /s/ Alan
R. Halpern Name: Alan R. Halpern Title: Vice President THE LT-15 EXCHANGE TRUST, By: DELAWARE TRUST
COMPANY, not in its individual capacity but solely as Trustee By: /s/ Alan R. Halpern Name: Alan R.
Halpern Title: Vice President THE LT-16 EXCHANGE TRUST, By: DELAWARE TRUST COMPANY, not in its
individual capacity but solely as Trustee By: /s/ Alan R. Halpern Name: Alan R. Halpern Title: Vice
President

- 11 -
<!-- page 12 -->
THE LT-17 EXCHANGE TRUST, By: DELAWARE TRUST COMPANY, not in its individual capacity but solely as
Trustee By: /s/ Alan R. Halpern Name: Alan R. Halpern Title: Vice President THE LT-18 EXCHANGE
TRUST, By: DELAWARE TRUST COMPANY, not in its individual capacity but solely as Trustee By: /s/ Alan
R. Halpern Name: Alan R. Halpern Title: Vice President THE LT-19 EXCHANGE TRUST, By: DELAWARE TRUST
COMPANY, not in its individual capacity but solely as Trustee By: /s/ Alan R. Halpern Name: Alan R.
Halpern Title: Vice President THE LT-20 EXCHANGE TRUST, By: DELAWARE TRUST COMPANY, not in its
individual capacity but solely as Trustee By: /s/ Alan R. Halpern Name: Alan R. Halpern Title: Vice
President

- 12 -
<!-- page 13 -->
THE LT-21 EXCHANGE TRUST, By: DELAWARE TRUST COMPANY, not in its individual capacity but solely as
Trustee By: /s/ Alan R. Halpern Name: Alan R. Halpern Title: Vice President THE LT-22 EXCHANGE
TRUST, By: DELAWARE TRUST COMPANY, not in its individual capacity but solely as Trustee By: /s/ Alan
R. Halpern Name: Alan R. Halpern Title: Vice President THE LT-23 EXCHANGE TRUST, By: DELAWARE TRUST
COMPANY, not in its individual capacity but solely as Trustee By: /s/ Alan R. Halpern Name: Alan R.
Halpern Title: Vice President THE LT-24 EXCHANGE TRUST, By: DELAWARE TRUST COMPANY, not in its
individual capacity but solely as Trustee By: /s/ Alan R. Halpern Name: Alan R. Halpern Title: Vice
President

- 13 -
<!-- page 14 -->
THE LT-25 EXCHANGE TRUST, By: DELAWARE TRUST COMPANY, not in its individual capacity but solely as
Trustee By: /s/ Alan R. Halpern Name: Alan R. Halpern Title: Vice President THE LT-26 EXCHANGE
TRUST, By: DELAWARE TRUST COMPANY, not in its individual capacity but solely as Trustee By: /s/ Alan
R. Halpern Name: Alan R. Halpern Title: Vice President MURRAY T. HOLLAND, as Trust Advisor /s/
MURRAY T. HOLLAND JEFFREY S. HINKLE, as Trust Advisor /s/ JEFFREY S. HINKLE

- 14 -
<!-- page 15 -->
SCHEDULE A List of Seller Trusts and Shares of Stock

Name of Record Holder Number of Shares The LT-1 Exchange Trust 1,397,705 The LT-2 Exchange Trust
1,396,863 The LT-3 Exchange Trust 2,563,777 The LT-4 Exchange Trust 2,537,152 The LT-5 Exchange
Trust 2,516,313 The LT-6 Exchange Trust 2,535,832 The LT-7 Exchange Trust 2,526,515 The LT-8
Exchange Trust 2,536,840 The LT-9 Exchange Trust 404,110 The LT-12 Exchange Trust 80,402 The LT-13
Exchange Trust - The LT-14 Exchange Trust 204,064 The LT-15 Exchange Trust 63,834 The LT-16 Exchange
Trust 920,349 The LT-17 Exchange Trust 39,347 The LT-18 Exchange Trust 81,860 The LT-19 Exchange
Trust 224,917 The LT-20 Exchange Trust 4,601 The LT-21 Exchange Trust 555,751 The LT-22 Exchange
Trust 555,750 The LT-23 Exchange Trust 1,466,884 The LT-24 Exchange Trust 1,466,883 The LT-25
Exchange Trust 1,466,884 The LT-26 Exchange Trust 1,466,883

- 15 -
<!-- page 16 -->
EXHIBIT A FORM OF JOINDER The undersigned is executing and delivering this Joinder Agreement
pursuant to that certain Orderly Marketing Agreement, dated as of December [___], 2018 (as amended,
restated, supplemented or otherwise modified in accordance with the terms thereof, the "OMA"), by
and among GWG Holdings, Inc., the Trust Advisors to the Seller Trusts listed on Schedule A thereto,
and the Priority Holders listed on Schedule B thereto, and any other person or entity that becomes a
party to the OMA in accordance with the terms thereof. Capitalized terms used but not defined in
this Joinder Agreement shall have the respective meanings ascribed to such terms in the OMA. By
executing and delivering this Joinder Agreement to the OMA, the undersigned hereby agrees, effective
commencing on the date hereof, to become a party to, and to be bound by and comply with the
provisions of, the OMA applicable to it as a holder of Shares, in the same manner as if the
undersigned were an original signatory to the OMA. The undersigned acknowledges and agrees that
Section 4.1 through Section 4.11 of the OMA are incorporated herein by reference, mutatis mutandis.
[Remainder of page intentionally left blank; signature appears on next page]

- 16 -
<!-- page 17 -->
Accordingly, the undersigned have executed and delivered this Joinder Agreement as of the ____ day
of ________________, _____. Name: [HOLDER/TRANSFEREE] By: Name: Title: Notice Information Address:
Telephone: Facsimile: Email: AGREED AND ACCEPTED as of the day of , . GWG HOLDINGS, INC. By: Name:
Title: [TRANSFEROR (if applicable)] By: Name: Title:

- 17 -
