# Among the following 8 agreements, which contain a non-compete clause? For each, quote t...

*Question:* Among the following 8 agreements, which contain a non-compete clause? For each, quote the clause. Agreements: the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley (dated 2017-11-14); the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. (dated 2011-03-14); the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc (filed 2018-11-09); the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC (dated 2013-05-15); the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies (filed 2005-11-02); the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01); the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. (dated 2010-01-01); the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. (filed 2013-09-26).

## Identify agreements containing non-compete clauses

The Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc contains a binding non-compete clause in Section 3 restricting the Distributor from marketing, selling, advertising, or promoting any product competitive with or substantially similar to the Products during the term. [61c29bdb3ab6960e p.2] The Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. contains a binding non-compete clause in Section 11.3(a) restricting the Network Affiliate and its affiliates from engaging in any business that competes with NCM's authorized business in the Territory during the Term. [23e65a3b8bc5cc9e p.25] The Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley contains an exclusivity clause in Section 8 restricting the Talent from endorsing any directly competitive product during the Term and in the Territories. [4cb98e07400203bf p.3]

[GAP] Evidence is missing for the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC, the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies, the Cooperation Agreement between e.l.f.

Beauty, Inc. and Marathon Partners Equity Management, LLC, the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC., and the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. [uncited]

## Exclude provisions that are not non-compete clauses

Section 7.2(e) of the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC states that the referenced Settlement Agreement does not contain a covenant-non-compete applicable to PcoMed and that PcoMed is not subject to any covenant-non-compete that would prevent employment with PcoMed. [31cbf0d18f7d763e p.13] Section 11.3(b) of the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. contains a non-solicitation provision restricting solicitation of employees and clients rather than a non-compete clause. [23e65a3b8bc5cc9e p.26] Section 28 of the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley establishes confidentiality and non-disclosure obligations regarding the Company's financial condition and non-public information. [4cb98e07400203bf p.6] Section 3.1 of the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC grants Integra a sole and exclusive worldwide right to sell and commercialize Integra Products treated by PcoMed while explicitly stating PcoMed remains free to make and sell products that do not use the PcoMed Surface Modification Technology. [31cbf0d18f7d763e p.7] Section 5(v) of the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. prohibits endorsement of entities, products or services in direct competition with the Sponsor unless approved in writing, which is an anti-endorsement clause rather than a non-compete clause. [ab1fd1dd637746ab p.2] Section 6 of the Cooperation Agreement between e.l.f. [uncited] Beauty, Inc. and Marathon Partners Equity Management, LLC contains mutual non-disparagement obligations. [e42a4ef8cda58762 p.7]

[GAP] No evidence is provided for the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc, the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies, or the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp.

## Not established by the evidence

[GAP] No evidence was found for: Quote the exact non-compete clause text from each agreement identified as containing one

## Verification appendix

Claims: 14 · supported: 9 · partially: 0 · dropped: 0 · gaps: 5 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Extract non-compete clauses

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[61c29bdb3ab6960e p.2] |  |
| s1.2 | s1 | keep | 1.00 | e3→[23e65a3b8bc5cc9e p.25] |  |
| s1.3 | s1 | keep | 1.00 | e5→[4cb98e07400203bf p.3] |  |
| s1.4 | s1 | gap |  |  |  |
| s1.5 | s1 | gap |  |  | no evidence cited |
| s3.1 | s3 | keep | 1.00 | e2→[31cbf0d18f7d763e p.13] |  |
| s3.2 | s3 | keep | 1.00 | e4→[23e65a3b8bc5cc9e p.26] |  |
| s3.3 | s3 | keep | 1.00 | e6→[4cb98e07400203bf p.6] |  |
| s3.4 | s3 | keep | 1.00 | e7→[31cbf0d18f7d763e p.7] |  |
| s3.5 | s3 | keep | 1.00 | e9→[ab1fd1dd637746ab p.2] |  |
| s3.6 | s3 | gap |  |  | no evidence cited |
| s3.7 | s3 | keep | 1.00 | e11→[e42a4ef8cda58762 p.7] |  |
| s3.8 | s3 | gap |  |  |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [61c29bdb3ab6960e p.2 L98-105] keep (1.0): "3. Restriction on Promotion of Competing Products. During the term of this agreement, Distributor shall not market, sell advertise or promote the sale or use of any product or device which is competitive with or substantially similar to the…"
- e2 [31cbf0d18f7d763e p.13 L640-642] keep (1.0): "(e) Non-Compete. The Settlement Agreement and Mutual Release between *** and *** does not contain a covenant-non-compete applicable to *** and, to the best of PcoMed's current knowledge, *** is not subject to any covenant-non-compete that w…"
- e3 [23e65a3b8bc5cc9e p.25 L947-963] keep (1.0): "Section 11.3 Non-Competition and Non-Solicitation. (a) During the Term, except as otherwise provided in this Agreement, Network Affiliate and its affiliates agree not to engage or participate in any business, hold equity interests, directly…"
- e4 [23e65a3b8bc5cc9e p.26 L969-978] keep (1.0): "(b) During the Term and for a period of twelve (12) months thereafter Network Affiliate will not, without NCM's prior written consent, either alone or in concert with others directly or indirectly solicit, entice, induce, or encourage: (i) …"
- e5 [4cb98e07400203bf p.3 L105-107] keep (1.0): "8. Exclusivity. Talent represents and warrants that during the Term and in the Territories, Talent will not endorse or make any appearances or advertisements on behalf of any other product which is directly competitive to ESSI's products."
- e6 [4cb98e07400203bf p.6 L275-288] keep (1.0): "28. Confidentiality and Non-Disclosure

A. Talent's endorsement and position of spokesperson of ESSI is for the sole purpose of the endorsement of the Company's products, and to offer information, based upon Talent's use and knowledge of ES…"
- e7 [31cbf0d18f7d763e p.7 L333-347] keep (1.0): "3.1. Grant of Exclusive Rights. Subject to the terms and conditions of this Agreement, PcoMed hereby grants to Integra and its Affiliates a sole and exclusive worldwide right to sell and commercialize Integra Products treated by PcoMed, wit…"
- e9 [ab1fd1dd637746ab p.2 L55-58] keep (1.0): "(v) prohibiting the endorsement by Racing and any members of Racing, including the drivers, of any entities, products or services which are in direct competition or otherwise inconsistent with the Sponsor or it products or services, unless …"
- e11 [e42a4ef8cda58762 p.7 L413-428] keep (1.0): "6. Mutual Non-Disparagement; No Public Statements.

(a) Subject to applicable law, the Company, on the one hand, and each of the Marathon Parties on the other hand, covenants and agrees that, during the Support Period or if earlier, until s…"
