<!-- page 1 -->
# Master Equipment Lease — Tolland Precision Components Corp. (Lessee)
| Field | Value |
|---|---|
| Document Type | Equipment Lease |
| Effective Date | 2025-03-10 |
| Parties | Northgate Equipment Finance LLC; Tolland Precision Components Corp. |

THIS MASTER EQUIPMENT LEASE is made as of 2025-03-10 between Northgate Equipment Finance LLC ("Lessor") and Tolland Precision Components Corp. ("Lessee").
Lessor is an affiliate of Northgate Capital Bank. This Lease is not a Loan Document under any credit agreement.
<!-- page 2 -->
## 1. Equipment; Schedules
Lessor leases to Lessee the CNC machining centers described in each Equipment Schedule executed hereunder, with an aggregate original equipment cost not to exceed $6,000,000.
## 2. Rent
Rent for each Schedule is payable monthly in advance as set forth in such Schedule. Late payments bear a late charge of 1.5% per month.
<!-- page 3 -->
## 3. Maintenance; Return
Lessee shall maintain the Equipment in good working order and return it at the end of the term to Lessor's facility in Hartford, Connecticut at Lessee's expense.
## 4. Governing Law
This Lease is governed by the laws of the State of Connecticut.
