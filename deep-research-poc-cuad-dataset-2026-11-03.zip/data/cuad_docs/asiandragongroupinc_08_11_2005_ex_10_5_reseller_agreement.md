<!-- page 1 -->
# Reseller Agreement
| Field | Value |
|---|---|
| Document Type | Reseller Agreement |
| Agreement Date | 2004-06-01 |
| Parties | 695014 B.C. Ltd. dba Galaxy Telecom ("Galaxy"); Galaxy Telnet SRL ("Telnet") |
| Source | CUAD v1 / ASIANDRAGONGROUPINC_08_11_2005-EX-10.5-Reseller Agreement |

Exhibit 10.5

Reseller Agreement

This Agreement is made and entered into by and between 695014 B.C. Ltd. dba Galaxy Telecom, having a
principal office at 200 - 375 Water Street, Vancouver, British Columbia V6B 5C6 Canada ("Galaxy")
and Galaxy Telnet SRL, having a principal office at Aleea Malinului, Nr. 11, Bl. D, Scara C, Apt.
43, Constanta, Judetul Constanta, Romania ("Telnet") as of the 1s t day of June, 2004.

WHEREAS: Galaxy is a wholesale provider of Voice over Internet Protocol ("VoIP") telephony and
related services and products. Telnet is a provider of VoIP telephony and related services and
products to Subscribers, as defined hereafter. Galaxy wishes to provide to Telnet and Telnet wishes
to acquire from Galaxy VOIP related services and products from time to time for the purpose of
providing them to Telnet's existing and future clients. NOW THEREFORE, for good and valuable
consideration, the receipt and sufficiency of which is hereby acknowledged by the Parties, the
Parties covenant and agree with each other as follows: 1. DEFINITIONS AND INTERPRETATION 1.1
Definitions In this agreement unless the context otherwise requires: "Agreement" means this
agreement; "Confidential Information" means all information which one of the Parties will have
access to or come into possession of which is confidential and proprietary to the other Party and
which is either declared to be confidential or which the receiving Party should know, acting
reasonably, is confidential or proprietary in nature and includes, but is not limited to, the terms
and pricing for the Products and Services, all information contained on or accessible through the
Partner Portal, as defined hereafter, any information disclosed by any third party which the third
party is obligated to treat as confidential or proprietary to one of the Parties hereto, trade
secrets, know-how, processes, standards, product specifications, marketing plans and techniques,
cost and financial pricing figures, all client or customer information (including without limitation
their names, financial information, address or telephone number), all systems software applications,
all software/systems source and object code, data, documentation, program files, flow charts, and
all operational procedures. "Effective Date" means the date first written above; "Force Majeure"
shall include but not be limited to an Act of God, strike, lockout, labour dispute, act of a public
enemy, war whether declared or undeclared, blockade, revolution, riot, insurrection, civil
commotion, lightning, fire storms, flood, or other natural calamities, explosion, governmental
restraint or restrictions, laws, regulations, orders, proclamations of any governmental entities,
judgement or orders of any court of law, embargoes, unavailability of equipment and any other cause
(other than a shortage or unavailability of funds) which is not reasonably within the control of the
Party whose performance under this Agreement is affected by the cause; "Partner Portal" means
Galaxy's web-based VoIP subscriber, management and business administration system; "Party" means
either Galaxy or Telnet as is appropriate in context and "Parties" means both or either of Galaxy
and Telnet as is appropriate in context; "Product" means one of and "Products" means some or all of
the VoIP related devices offered for sale by Galaxy; "Service" means one of and "Services" means
some or all of the VoIP services as listed in Schedule "A" attached hereto; "Subscriber" means a
client of Telnet who is a consumer of the Products or Services as provided by Galaxy and sold by
Telnet. 1.2 Currency All references to currency, unless otherwise specified, are to lawful money of
the United States. 1.3 Headings The division of this Agreement into articles, sections, and/or
subsections and the provision of headings for all or any of them are for convenience of reference
only and shall not affect the interpretation of this Agreement. 1.4 Schedules The following
schedules are attached to and form part of this Agreement: Schedule "A" Services and Products and
Pricing Schedule "B" Tier 1 Subscriber Support
<!-- page 2 -->
Schedule "C" Subscriber Contract Clauses Whenever any provision of any schedule to this Agreement
conflicts with any provision in the body of this Agreement, the provision in the body of this
Agreement shall prevail. References herein to a schedule shall mean a schedule of this Agreement.
Reference in any schedule of this Agreement to an agreement shall mean this Agreement. 1.5 Usage In
this Agreement, unless there is something in the subject matter or context inconsistent therewith:
words importing the singular shall include the plural and vice versa; and words importing gender
shall include masculine, feminine and neuter genders. 1.6 Governing Law This Agreement shall be
governed by and construed in accordance with the laws of the Province of British Columbia and the
federal laws of Canada applicable therein, excluding its conflict-of-laws rules. The parties
expressly disclaim the application of the United Nations' Uniform Convention for the Sale of Goods
convention, to this Agreement.

2. RELATIONSHIP OF THE PARTIES 2.1 Non-Exclusive Reseller Subject to the terms and conditions of
this Agreement, Galaxy hereby appoints Telnet as a non-exclusive authorized reseller of the Products
and Services and Telnet hereby accepts the appointment. 2.2 Not a Partnership This Agreement does
not and shall not be construed to create a partnership, joint venture, agency or any other business
relationship which would authorize either Party to act on behalf of the other or to have any
authority to create any liability or obligations on behalf of or in the name of the other. Each of
the Parties is and will remain completely independent of the other. Telnet may indicate to the
public that it is an authorized seller of Galaxy Services and it may advertise Products and Services
under Galaxy trademarks, logos, and symbols as provided for in this Agreement, but under no
circumstances shall it represent itself to be an associate, franchisee, representative, servant or
agent of Galaxy.

3. TELNET OBLIGATIONS 3.1 Marketing and Sales Telnet shall be responsible for promoting, marketing
and selling those Products and Services it offers for sale or distribution and it shall use its
reasonable best efforts to do so; Telnet may market and sell the Services as being Telnet services
or as Galaxy services being provided by Telnet. 3.2 Business Expenses Telnet shall be responsible
for all expenses it incurs from its business activities associated with the marketing, promotion,
sale and support of the Products and Services, including, but not limited to, those expenses related
to the installation and activation of Products and Services. 3.3 Pricing Structure & Levels Telnet
shall, in its sole discretion, set the prices it charges for the Products and Services it sells or
distributes and the manner, if any, in which it bundles or combines them. 3.4 Qualified Sales and
Marketing Representatives Telnet covenants that all of its employees, agents and representatives who
promote, market and sell the Products and Services will be fully qualified in and knowledgeable of
the Products and Services. 3.5 Terms of Service Telnet shall include those terms set out in Schedule
"C" as a term in each Subscriber agreement for Services. 3.6 Subscriber Support Telnet shall
maintain a first line of response, known within the telephony industry as a "Tier 1 Subscriber
help-desk and support function", as further defined in Schedule "B", as is required to maintain
Subscriber satisfaction at or above industry standards. 3.7 Government Authorizations Telnet shall
obtain and maintain in good standing all licenses, permits and other governmental approvals and
authorizations required in connection with implementation of this Agreement and the sale of Products
and Services, including without limitation, business licenses, import licenses and foreign exchange
permits. Telnet shall keep Galaxy apprised of any change in the status of the licenses, permits and
approvals and authorizations as are referred to in subsection 3.7(a) which may materially affect the
implementation of this Agreement. 3.8 Notification of Infringement Telnet shall notify Galaxy
immediately of any actual, suspected or alleged infringement of Galaxy trademarks, or copyrights
that it
<!-- page 3 -->
becomes aware of.

4. TELNET RECORDS 4.1 Maintain Records Telnet shall maintain complete and, to the best of its
ability, accurate records on the Partner Portal (the "Records") of all Subscribers, including: (a)
Name, location, contact information and date of activation; (b) Products purchased, including model
and serial number and date of activation; (c) Services subscribed; including date of activation; and
All service calls relating to Products or Services, showing Subscriber information, date and nature
of call, Telnet response, service work performed and such other information as Galaxy may reasonably
request. 4.2 Ownership and Privacy of Records Galaxy shall own the Records, but it shall use the
information contained therein only as allowed by the terms and conditions and intent of this
Agreement. Galaxy shall treat the Records as Confidential Information and it shall not provide to or
allow access by any third party except as required or allowed by this Agreement. 4.3 911 Call
Response Service Galaxy shall have the right to disclose Records to any third party providing
emergency call response service to Subscribers as are required by such third party in order to
provide the service.

5. GALAXY RESPONSIBILITIES Services and Products Subject to the terms and conditions of this
Agreement, Galaxy shall provide the Products and Services to Telnet. 5.2 Network Galaxy shall
establish a Telnet account within the Partner Portal and, subject to the terms and conditions of
this Agreement, it shall provide Telnet with access thereto. 5.3 Materials Galaxy shall provide
Telnet with access to electronic copies of sales and technical materials, user manuals, installation
manuals and brochures and catalogues relating to the Products and Services which Galaxy has
electronic versions of and which it, in its absolute discretion, is of the opinion are relevant. 5.4
Supporting Information Galaxy shall make available to Telnet such technical and commercial
information which Galaxy has or which comes into Galaxy's possession and which, in Galaxy's opinion,
may be of assistance to Telnet in selling and supporting the Products and Services. 5.5 Tier 2
Support Galaxy shall provide "Tier 2" technical support to Telnet which would include assistance
with any technical issues related to the Services and Products that could not be resolved by
Telnet's Tier 1 Subscriber support personnel.

6. PRODUCTS 6.1 Approved Products Galaxy shall, at its sole discretion, determine the technical
specifications and the brand and model of those devices which it will support in providing the
Services and chooses to offer as Products; Telnet shall purchase from Galaxy all devices or Products
used or to be used by it to enable the provisioning of the Services pursuant to this Agreement and
Galaxy shall be required to support only those devices actually purchased from Galaxy by Telnet;
Notwithstanding section 6.1(b), Telnet may request from Galaxy that it enable and support devices
other than Products acquired by Telnet from Galaxy, and Galaxy shall not unreasonably refuse such
request; and Galaxy shall have the right, at its sole discretion, to change the Products by
discontinuing or adding new devices to the Products offered and by changing manufacturers, brands,
models or technical or software specifications of any of them. 6.2 Pricing Prices for Products shall
be as quoted at the time of order by Telnet and are subject to change at any time; Prices quoted
shall be for the Products only and shall not include applicable taxes and shipping, insurance,
expedition, import/export, brokerage and other fees, which shall be in addition to the quoted
Product prices. 6.3 Ordering All Telnet orders of Products are subject to acceptance by Galaxy (upon
acceptance, the "Order"). Galaxy shall have the right to not accept an order of Products from
Telnet, in whole or in part, if Telnet is in breach of any term or condition of this Agreement;
<!-- page 4 -->
Unless specifically agreed otherwise and stated in writing, the terms of this Agreement shall
supersede the terms of any Order; 6.4 Payment Telnet shall pay (the "Product Payment" ) for an
Order, using a payment method acceptable to Galaxy, prior to shipment of the Order by Galaxy; If
Telnet falls into arrears on its account for Services, Galaxy shall have the right to apply any
Product Payment, in whole or in part, to Telnet's account for Services and any Product Payment so
transferred shall be deemed to be a payment for Services, not Products, and Galaxy shall have no
further obligation to deliver the Products which such funds were originally payment for. 6.5
Delivery Galaxy shall, subject to availability, use all reasonable effort to deliver the Order
within a reasonable time from the date of the Order; Galaxy shall have the right to suspend or stop
delivery of an Order, in whole or in part, if Telnet is in breach of any of the terms and conditions
of this Agreement, and, if Galaxy elects to stop delivery pursuant to this section, it shall deem
such Order to be an inventory return subject to section 6.7. 6.6 Order Substitution Subject to
obtaining Telnet's approval for any price changes, Galaxy shall have the right to deliver a
different Product of equal or greater technical capability in place of the Order. 6.7 Inventory
Returns Galaxy may, at its sole discretion, accept the return, in whole or in part, of an Order and,
if it elects to do so, Telnet shall pay a restocking fee of 25% of the original purchase price of
the returned Product or Products. 6.8 Warranty Unless specifically stated otherwise, Galaxy makes no
warranty or guarantee, express or implied, including any implied warranty of merchantability or
fitness for a particular purpose, with regard to the Products. All warranties with regard to the
Products shall be those of the original equipment manufacturer only.

7. SERVICES 7.1 Available Services Listed in Schedule "A" is a list of the Services which are
available to Telnet as of the Effective Date. 7.2 Change to Services Galaxy reserves the right to,
at its sole discretion, to add, delete or change any of the Services from time to time. 7.3
Provision of Service Upon Telnet's activation of a Subscriber account, Galaxy shall, subject to the
terms and conditions of this Agreement, provide the requested Services to Subscriber on behalf of
Telnet; Subject to section 13.2, if Telnet is in breach of any of the terms and conditions of this
Agreement, Galaxy shall have the right to suspend or terminate delivery of the Services, in whole or
in part, to Telnet and the Subscribers. 7.4 Communication of Termination Galaxy may, at its sole and
absolute discretion, provide long distance termination through one or more termination partners.
Galaxy shall have the right, at its sole discretion, to reroute the communication traffic
originating from Telnet or Subscribers between Galaxy's different termination partners. 7.5 411 and
911 Service Galaxy shall arrange with third parties for the provision of: 411 directory assistance
service; and 911 emergency call response service, which services will be provided through Galaxy as
part of the Services. 7.6 Prices The prices charged by Galaxy to Telnet for each of the Services
(the "Service Prices") shall be as listed in Schedule "A"; Galaxy shall have the right, but not the
obligation, to: during the term of this Agreement, adjust any of the Service Prices by an amount
that is proportionate with any changes to Galaxy's direct third party costs in providing the related
Services; at the time of any renewal of this Agreement, adjust the Service Prices as it, in its
absolute discretion, determines provided it has given written notice to Telnet of such price changes
a minimum of 60 days in advance of the renewal. Prices for long distance termination shall be as
posted on the Partner Portal and Telnet understands and agrees that, other than for those
destinations noted in Schedule A as being fixed in price for the term of this Agreement, such prices
are variable and subject
<!-- page 5 -->
to change without notice. 7.7 Billing For Services Galaxy shall invoice Telnet once per month for
the Services delivered, termination fees, 411 directory assistance and 911 emergency call service
fees and any other fees or billings chargeable to Telnet; Galaxy shall deliver each invoice to
Telnet's account in the Partner Portal; and Telnet shall give notice to Galaxy of all errors and
inaccuracies in an invoice within 15 days of receipt by Telnet of the invoice at issue. Thereafter,
Telnet will be deemed to have agreed with the accuracy of the invoice. 7.8 Payment of Services
Invoice Telnet hereby covenants to pay all invoices rendered to its account by Galaxy within 15 days
of the date of invoice; Interest shall accrue on overdue accounts at the rate of 1.5% per month
calculated and payable from the date of invoice until the date of payment in full of the overdue
amount. 7.9 Warranty Galaxy does not guarantee the integrity of data transmitted using the Products
and Services or that the Products and Services will operate uninterrupted or error-free, including,
without limitation, the degradation of voice transmission quality and the failure of an incoming or
outgoing call, including emergency calls (911 or equivalent), to be connected or completed.

8. LIMITATION OF REMEDIES AND LIABILITY 8.1 Telnet's Exclusive Remedies Telnet's sole and exclusive
remedies concerning Galaxy's performance or non-performance in any matter related to this Agreement
or the provisioning of the Services or Products are limited to those expressly stated in this
Agreement. 8.2 Limitation of Galaxy Liability Galaxy shall have no liability to Telnet, whether in
contract, tort (including negligence), strict liability or otherwise, for any special, indirect or
consequential damages or for lost profits, in any matter related to this Agreement, including but
not limited to any delay or failure by Galaxy to furnish, deliver or provide Products or Services;
Galaxy's liability in any matter related to Product shall be limited to the purchase price paid by
Telnet for the Product with respect to which such liability relates; Galaxy's liability in any
matter related to Services shall be limited to the fee paid by Telnet for the Service with respect
to which the liability relates in the month or months in which the event giving rise to the
liability occurred. 8.3 Liability Upon Termination of Agreement Neither Party shall be liable to the
other for any damages or compensation in connection with termination of this Agreement including,
without limitation, for loss of profits, loss of investment or expenditures made in reliance on this
Agreement or loss of goodwill. 8.4 Force Majeure Neither party will be liable to the other for any
delay or failure to perform if that delay or failure results from a cause beyond its reasonable
control. 8.5 Telnet's Indemnity Telnet agrees to indemnify Galaxy (and any business entity
controlled by it, controlling it or under common control with it) and save them harmless from any
claim made against any of them, directly or indirectly, by a Subscriber or resulting from: (i) any
promise or commitment that Telnet may have made purportedly on Galaxy's behalf in violation of this
Agreement; or (ii) from any breach by Telnet or Telnet's employees with respect to Telnet's
obligations under this Agreement. 8.6 Limitation of Privacy The Products and Services utilize, in
whole or in part, the public Internet and third party networks to transmit voice and other
communications. Galaxy shall not be liable to Telnet for any loss or damages caused by or related to
a lack of privacy which may be experienced as a result of use of the Products and Services.

9. USE OF NAME, LOGOS, TRADEMARKS AND LICENSED MATERIALS 9.1 News Releases Neither Party will use
the name of the other in any news release, public announcement, advertisement or other form of
publicity, without the prior written consent of the other Party. 9.2 Ownership and Use of Galaxy
Trade Marks Telnet acknowledges Galaxy's exclusive ownership of the Galaxy name and logo as well as
certain other trademarks and trade names which Galaxy uses in connection with the Products and
Services (the "Trademarked Material") and agrees that Telnet will not acquire any interest in any of
the Trademarked Material by virtue of this Agreement or anything done pursuant to it; While this
Agreement is in effect, Telnet may indicate to the public its status of being an authorized seller
of the Galaxy Products
<!-- page 6 -->
and Services; Except with the prior written consent of Galaxy, Telnet will not adopt or use any of
the Trademarked Material, in whole or in part, or any confusingly similar word or symbol, as part of
Telnet's name or, to the extent Telnet has knowledge of such use and the power to prevent such use,
allow others to use the Trademarked Material; Nothing in this Agreement contains any transfer or
license to Telnet of any Trademarked Material or other proprietary rights. 9.3 Review and Approval
of Uses Galaxy shall have the right to review any use by Telnet of the Trademarked Material and to
approve or disapprove, in its absolute discretion, Telnet's use of it and if Galaxy disapproves of
Telnet's use of Trademarked Material, Telnet shall not use the Trademarked Material for such use.
Telnet shall, at Galaxy's request, provide to Galaxy a copy of anything which Telnet is using or may
use and which contains the Trademarked Material; Telnet must adhere to Galaxy's standards of use in
respect to any of the Trademarked Material. Among other things, Telnet will be required to indicate
explicitly Galaxy's ownership of the name or mark. 9.4 No Removal of Logos, Trademarks & Notices
Unless Telnet first obtains express written consent from Galaxy, Telnet will not remove or alter any
patent numbers, trade names, trademarks, copyright or other proprietary notices, serial numbers,
labels, tags or other identifying marks, symbols or legends affixed to or included with any Product
or portion thereof, whether on packaging, media, presentations or otherwise, or any related
materials provided to Telnet by Galaxy.

10. TERM AND TERMINATION 10.1 Term of the Agreement The initial term of this Agreement will be for
two (2) year(s) commencing on the Effective Date. Thereafter, this agreement will renew
automatically from year to year unless cancelled in writing by either Party giving the other written
notice of such cancellation a minimum of 60 days before the end of the then current term. 10.2
Termination for Default Subject to section 13.2, either Party may terminate this Agreement,
effective immediately, if the other commits a material breach of it, commits any material fraudulent
act in performing any of its obligations or makes any material misrepresentation to the other or
commits an act of malfeasance or misfeasance in the performance of its or his duties or is unable or
unwilling to perform its obligations and duties under this Agreement which circumstances will
include, but not be limited to: If a receiver, trustee in bankruptcy or similar officer is appointed
to take charge of any of its assets; or If it files for relief under any applicable bankruptcy laws.
10.3 Obligations Upon Termination Upon expiration or termination of this Agreement: (a) Telnet shall
immediately: stop representing itself as a seller of the Products and Services and marketing and
selling the Products and Services; discontinue using the Trademarked Materials; and return to Galaxy
all Galaxy sales and technical materials and other Galaxy literature; Galaxy shall deliver pending
Orders per the terms of such Orders; and all amounts due from each party to the other shall become
immediately due and payable. 10.4 Inventory Returns Upon termination of this Agreement, Galaxy may,
at its sole discretion accept inventory returns of Products. If Galaxy accepts inventory returns,
Telnet shall pay a restocking fee of twenty-five percent (25%) of the original billing amount for
the returned inventory. 10.5 Subscribers If this Agreement is terminated pursuant to section 10.2,
Galaxy shall have the right to contact Subscribers directly and solicit such Subscribers to become
subscribers of Galaxy, an affiliate thereof or of another client of Galaxy's.

11. CONFIDENTIALITY 11.1 Confidential Information Each of the Parties acknowledges that in the
course of their relationship pursuant to this Agreement, each (the "Receiving Party") will have
access to or come into possession of Confidential Information of the other Party (the "Disclosing
Party") and that the disclosure of such Confidential Information to third parties or to the general
public would be detrimental to the best interests and business of the Disclosing Party.
<!-- page 7 -->
11.2 Exceptions to Confidential Information Notwithstanding the definition of Confidential
Information and the provisions of section 11.1, "Confidential Information" does not include
information or data, which the Receiving Party can prove, on a balance of probabilities, is or was:
publicly known at the time of disclosure; already known by the Receiving Party at the time it
receives the information; provided to the Receiving Party by a third party that is not under
obligation to keep such information confidential; or independently developed by the Receiving Party
without use of any Confidential Information of the Disclosing Party. 11.3 Limitations on Use The
Receiving Party will not, during the term of this Agreement or at any time thereafter: disclose any
Confidential Information to any person; use or exploit, directly or indirectly, the Confidential
Information for any purpose other than the proper purposes of the Disclosing Party; or disclose for
any purpose, other than those of the Disclosing Party, the private affairs of the Disclosing Party
or any other information which the Receiving Party may acquire during the term of the Agreement with
respect to the business and affairs of the Disclosing Party, whether acquired in the course of
carrying out the Agreement or incidentally. 11.4 Required Disclosure Notwithstanding the foregoing,
the Receiving Party will be entitled to disclose Confidential Information if required by law
provided that the Receiving Party will promptly notify the Disclosing Party, consult with the
Disclosing Party and cooperate with the Disclosing Party in any attempt to enjoin, to resist or
narrow such disclosure or to obtain an order or other assurance that such information will be
accorded confidential treatment. 11.5 Survival of Confidentiality All covenants of confidentiality
herein shall survive the term of this agreement by three (3) additional years counting from the date
of termination of this Agreement.

12. EXCLUSION FROM TERRITORIES 12.1 Right to Exclude Subject to section 12.2 Galaxy reserves the
right to grant to any other person an exclusive territory (the "Territory") for the marketing, sales
and distribution of the Services and, from that date which is 30 days after the date upon which
Galaxy delivers notice in writing to Telnet of such grant of exclusivity over a Territory (the
"Exclusion Date"), Telnet shall not sell, distribute or market the Services within the Territory.
However, Telnet shall be entitled to continue to sell the Services to any Subscriber resident within
the Territory who became a Subscriber prior to the Exclusion Date. 12.2 Territories From Which
Telnet May Not Be Excluded During the term of this Agreement, Telnet may not be excluded pursuant to
section 12.1, from the following areas: (a) Romania.

13. MISCELLANEOUS 13.1 No Waiver The failure by either Party to enforce or take advantage of any of
the provisions of this Agreement shall not constitute nor be construed as a waiver of such
provisions or of the right subsequently to enforce or take advantage of each and every such
provision. 13.2 Default If either of the Parties should be in default (the "Defaulting Party") of
any obligation or requirement under this Agreement, the Party affected may give written notice to
the Defaulting Party specifying the default and will give the Defaulting Party a grace period of 30
days (the "Grace Period") to cure such default or to take such reasonable steps to cure without
undue delay such default prior to seeking any remedy it may have on account of such default. The
Defaulting Party shall lose no rights under this Agreement if it cures the stated default within the
Grace Period. 13.3 Disputes Galaxy and Telnet will attempt to settle any claim or controversy
relating to this Agreement through consultation and negotiation in good faith and a spirit of mutual
cooperation. If those attempts fail, then a mutually acceptable mediator, chosen by Galaxy and
Telnet within forty-five (45) days after written notice from one of the parties to the other,
demanding mediation, will mediate the dispute. Neither party may unreasonably withhold consent to
the selection of a mediator. Galaxy and Telnet will share the costs of the mediation equally and
each shall bear its own costs. Any dispute which the parties cannot resolve between themselves
through negotiation or mediation within ninety (90) days after the date of the initial demand for
mediation may then be submitted to the courts for final resolution. Nothing in this paragraph will
prevent either party from resorting to judicial proceedings if:
<!-- page 8 -->
good faith efforts to resolve the dispute under these procedures have been unsuccessful; or interim
relief from a court is necessary to prevent serious and irreparable injury to one party or to
others. 13.4 Notices Any formal notice between the Parties hereto will be in writing and will be
either personally delivered or sent by facsimile or by registered mail to the appropriate party or
parties at the address noted for that party on the first page of this Agreement, or such other
address as may be designated by a party in a written notice sent to the other parties in accordance
with this paragraph. Any notice or other communication will be effective seven calendar days from
the day that it was sent, or if given by personal delivery or facsimile, the day following its
receipt. 13.5 Assignment Neither party may assign this Agreement without the prior written consent
of the other. However, Telnet agrees that Galaxy may assign this entire Agreement to an affiliate or
sell, transfer or assign any account receivable under it to a financing institution to enforce the
Galaxy's rights to receive payment from Telnet. This Agreement will be binding upon any authorized
assignee or successor of Telnet or Galaxy. 13.6 Compliance with Law Each of the Parties agrees to
comply with all applicable laws, rules and regulations of the jurisdictions in which it operates and
to do nothing to cause the other to violate the law, rules and regulations of those jurisdictions.
If this Agreement or the performance hereof, is determined to be contrary of the laws, rules or
regulations of the Territory or of Canada, this Agreement will automatically terminate subject the
terms of Termination outlined in this Agreement.

14. GENERAL 14.1 Entire Agreement This Agreement and all documents contemplated by or delivered
under or in connection with this Agreement constitute the entire agreement between the Parties with
respect to the subject matter of this Agreement, and supersede all prior agreements, negotiations,
discussions, undertakings, representations, warranties and understandings, whether written or oral,
express or implied, statutory or otherwise. 14.2 Amendment No amendment, supplement, restatement or
termination of any provision of this Agreement is binding upon the Parties hereto unless it is in
writing and signed by an authorized representative of each Party to this Agreement at the time of
the amendment, supplement, restatement or termination. 14.3 Severability If any provision or any
portion of any provision of this Agreement shall be held unlawful or unenforceable, the balance of
such provision and all other provisions hereof shall nonetheless in all respects remain binding and
effective and shall be construed in full force and effect to the extent lawfully permissible. 14.4
Time of Essence Time is of the essence in the performance of the terms and conditions of this
Agreement. 14.5 Enurement This Agreement enures to the benefit of and binds the Parties and their
respective heirs, executors, administrators, successors and permitted assigns. 14.6 Counterpart
Signature and Facsimile Delivery This Agreement may be executed in two or more counterparts and may
be delivered by facsimile, each of which will be deemed to be an original and all of which will
constitute one agreement, effective as of the reference date given above.

IN WITNESS WHEREOF, the parties have caused this Agreement to be executed by their duly authorized
representatives as of the date first written above:

695014 B.C. LTD. GALAXY TELNET SRL

Per: "Peter Wiggans" Per: "Michael Stunden"

Authorized Signatory Authorized Signatory

Peter Wiggans Michael Stunden

(Print name) (Print name)

Title: Chief Operating Officer Title: Chief Financial Officer

SCHEDULE "A"
<!-- page 9 -->
<!-- page 10 -->
SCHEDULE "A" PARTNER PRICING Galaxy Telnet

Table 1

Business Partner Pricing

VoIP Services One-Time Fee Monthly Service Fee

VoIP Connectivity (per port charge)

Includes: Unlimited VoIP calls, VoIP Caller ID, Call waiting, Basic voicemail

$9.95 $5.95

VoIP Connectivity - Commpanion Galaxy Telecom Brand

With i-box subscription

Includes: Unlimited VoIP calls, VoIP Caller ID, Call waiting, Basic voicemail, 3-way Calling, Call
forwarding, Do not disturb, Call hold, Auto answer, Call ignore, Call "go to voicemail", Redial,
Mute

$19.95 $1.95

VoIP Connectivity - i-box Commpanion Galaxy Telecom Brand

Stand alone subscription

Includes: Unlimited VoIP calls, VoIP Caller ID, Call waiting, Basic voicemail, 3-way Calling, Call
forwarding, Do not disturb, Call hold, Auto answer, Call ignore, Call "go to voicemail", Redial,
Mute

$19.95 $5.95

VoIP to VoIP Termination included included

VoIP to PSTN Termination (Long distance) included See Current Published Rates

Basic Voicemail Service included included

i-box CommCenter - Enhanced Voicemail

Includes: Web interface, call forwarding, do not disturb, speed dial, call logs, email message
notify management, time zone control, profile management, greeting management and password control

included $2.00

Services

Partner Portal included included

Partner Portal Back-Office (API) included included

Special Accounts

Demonstration Accounts See note 3 free free
<!-- page 11 -->
Employee only Accounts See note 3 free $1.95

Promotion Accounts

TBD Special Special

Phone Numbers

Direct Inward Dial (DID) - Canada $250 one time fee per order

see note 1

$3.00

Direct Inward Dial (DID) - USA $250 one time fee per order

see note 1

$2.50

Toll Free Dial (1-8XX) - Canada/USA $2.50 $2.50 plus usage ($.05 avg.)

Use existing phone number see note 2 $10.00 $3.00

Bundles & Calling Zones

Monthly 250 North America minute bundle n/a $2.95

Monthly 500 North America minute bundle n/a $5.95

Monthly 750 North America minute bundle n/a $8.95

Monthly 1000 North America minute bundle n/a $11.95

Local Calling Zone

On-net locations only

Includes: 750 minutes inbound and outbound local calls. Requires DID. Subscriber must reside in
Local Calling area.

included $6.95

Virtual Calling Zone

On-net locations only

Includes: 750 minutes inbound calls from virtual calling area. Requires DID Applies to North
America-based subscribers only.

See note 4

included $6.95

Custom Calling Zone

Off-net locations

Custom Quote Custom Quote

Note 1 Not available in all areas, see Table 3, 25 DID number block minimum Note 2 Not available in
all areas see Table 3 Note 3 Quantity to be agreed between parties, Long distance charges apply Note
4 Unlimited calling FROM Virtual Calling Zone only. Long distance charges apply when calling to VCZ.
<!-- page 12 -->
<!-- page 13 -->
Table 2 i-box Commpanion Telecom Branded Version

Licenses i-box CommPanion Additional 500 Licenses $7,000 $14.00 ea 1,350 Licenses $14,000 $10.50 ea
2,500 Licenses $21,000 $8.40 ea 3,650 Licenses $28,000 $7.70 ea 5,000 Licenses $35,000 $7.00 ea
6,700 Licenses $42,000 $6.30 ea 8,750 Licenses $49,000 $5.60 ea 11,500 Licenses $56,000 $4.90 ea
15,000 Licenses $63,000 $4.20 ea 20,000 Licenses $70,000 $3.50 ea

Note 1 Co-Branding one time charge $1,350.00
<!-- page 14 -->
Table 3 Galaxy Telecom On-net locations

Canada Province City Alberta Calgary Edmonton British Columbia Vancouver Victoria Kelowna Whistler
Abbotsford Manitoba Winnipeg Nova Scotia Halifax Ontario Toronto Ottawa Hamilton Windsor Kitchener
London Guelph Kingston Oshawa St. Catherines Waterloo Hespeler Quebec Montreal Quebec City
Saskatchewan Regina

USA State City Alabama Birmingham Arizona Phoenix California Los Angeles San Diego San Francisco
Colorado Denver Florida Gainesville Miami Orlando Tampa Georgia Atlanta Illinois Chicago Indiana
Indianapolis Maryland Baltimore Michigan Detroit Minnesota Minneapolis Missouri Kansas City St Louis
New York New York City North Carolina Charlotte Fayetteville Greensboro Raleigh Ohio Cincinnati
Cleveland Dayton
<!-- page 15 -->
Oregon Portland Pennsylvania Philadelphia Tennessee Nashville Texas Dallas Austin Houston San
Antonio Utah Salt lake City Virginia Culpepper Washington Seattle Washington DC Washington DC

SCHEDULE "B" TIER 1 SUBSCRIBER SUPPORT
<!-- page 16 -->
Under this Agreement the Telnet is required to maintain Tier 1 Subscriber Support (the "Subscriber
Support") functioning as initial response for any direct Subscriber inquiries. Galaxy will provide
Tier 2 technical support for technical inquiries from qualified resellers only. The Criteria for the
Subscriber Support are as follows: Subscriber Satisfaction Telnet will use its best efforts to
ensure that Subscribers achieve the highest levels of satisfaction with the Services delivered by
Telnet. Telnet shall notify Galaxy immediately of any complaints by Subscribers, whether they
involve sales, Service, Performance or other issues. Galaxy shall use Subscriber satisfaction
surveys, field Service reports, and random audits, as it deems necessary to determine if the
appropriate levels of Subscriber satisfaction are achieved. If Galaxy determines that an
inappropriate level of Subscriber dissatisfaction exists, Galaxy and Telnet shall put in place an
action plan as approved by Galaxy to continually improve and maintain Subscriber satisfaction
levels. Staff Subscriber Support shall be staffed by fully qualified and trained personnel as per
the following criteria: 1. Training Telnet shall maintain technically qualified Service personnel
and use its best efforts to service Telnet subscribers in the Territory. 2. Technical Team (a)
Language Capabilities Telnet shall employ at least one lead Service engineer who is fluent in
English who will be responsible for communicating with Galaxy's technical staff and who can
accurately translate all technical documentation from English. Service Staff Upon execution of this
Agreement and annually thereafter, Telnet shall furnish Galaxy with a list of its Service management
and other technical staff qualified to support Galaxy Services. (c) Help Desk Telnet shall ensure
that the personnel staffing the Subscriber help desk, as set out in section 3.6, shall have a
sufficient working knowledge of: networking in a TCP/IP WAN/LAN environment; configuring and
maintaining network equipment; relevant operating systems (Macintosh, Windows, Linux); and both
written and spoken English,. to be able to provide effective help to Subscribers, communicate and
work with Galaxy's Tier 2 help desk to address those Subscriber issues which Telnet's help desk are
unable to resolve and to communicate and work with Galaxy with regard to technical issues.

SCHEDULE "C"

SCHEDULE "C" SUBSCRIBER CONTRACT CLAUSES
<!-- page 17 -->
Telnet shall include as a term of any agreement between itself and a Subscriber with respect to any
of the Services, the relevant clauses of the following: General

The Subscriber will not use the Service for any purpose that is unlawful, abusive, intrusive on
another's privacy, harassing, libellous, defamatory, threatening or hateful, or in any other way
that would violate any applicable governmental law.

Telnet offers the Service internationally. While the Service may be used to make and receive
international calls, we do not represent that the use of the Service is legally appropriate in
locations outside of Canada and the United States. If the Subscriber chooses to use the Service from
or to a location outside of Canada and the United States, the Subscriber is responsible for
compliance with any and all governing foreign and local laws.

The Subscriber may not reverse engineer, distribute, publish, display, modify or in any way exploit
the configuration parameters Telnet provides as a means to access the Service.

The Subscriber acknowledges that any devices and embedded software or firmware ("Products")
furnished by Telnet are exclusively for use with Telnet's Service.

Residential Use of Service

If you have subscribed to Residential Services, the Service is provided to you as a residential
user, for your personal, residential, non-business and non-professional use. This means that you are
not using the service for any commercial or governmental activities, profit-making or non-profit,
including but not limited to business, sales, telecommuting, telemarketing, autodialing, continuous
or extensive call forwarding, fax broadcast, fax blasting or any other activity that would be
inconsistent with normal residential usage patterns. Telnet reserves the right to immediately
terminate or modify the service, if Telnet determines, in its sole discretion, that the subscriber's
service is being used for any of the aforementioned activities.

The Service is offered on a monthly basis to the Subscriber. The monthly Service term begins on the
date that Service is activated for the subscriber. Full monthly terms will renew automatically
unless Telnet is otherwise notified of the intent to cancel the Service. Upon cancellation, the
Subscriber will be responsible for charges for the full term of the then current billing period and
any unbilled charges.

Small Business Use of Service

If you have subscribed to Small Business Services, the Service is provided to you as a small
business user. You agree not to use the Service for auto-dialling, continuous or extensive call
forwarding, telemarketing or fax broadcasting. Telnet reserves the right to immediately terminate or
modify the service, if Telnet determines, in its sole discretion, that the subscriber's service is
being used for any of the aforementioned activities.

The Service is offered on a monthly basis to the Subscriber. The monthly Service term begins on the
date that subscriber requests activation of the Service. Full monthly terms will renew automatically
unless the Telnet and Galaxy is otherwise notified of the intent to cancel the Service. Upon
cancellation, the Subscriber will be responsible for charges for the then current full monthly term
and any unbilled charges

Short Form Emergency Services, E911 and 911

The Service presently does not support 911, E911 or any other type of emergency Services; that calls
to "9-1-1" cannot be connected; and that alternative arrangements need to be made to contact
emergency Services in situations where emergency numbers would have to be dialled.

Theft

The Subscriber is responsible for cancelling the Service if Subscriber believes that the associated
Products have been lost or stolen, or if the Subscriber becomes aware that the Service provided is
being used or misused without Subscribers consent. Subscriber is liable for all charges accruing to
Subscribers account for the Service until Subscriber cancels the Service. Service Termination The
Provider reserves the right to terminate the Service at any time with or without notice and for any
reason. The subscriber agrees that the provider shall not be liable to the subscriber or to any
third party for any modification, suspension or discontinuance of the Service. Privacy Personal data
and certain other information submitted by the subscriber is subject to our Privacy Policy. Voice
over IP
<!-- page 18 -->
communications are transmitted over public networks including the Internet. The subscriber
acknowledges that the provider is not liable for any loss of privacy arising out of use of the
Service.
