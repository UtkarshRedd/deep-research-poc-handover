# What non-compete restriction does the Sponsorship Agreement between Excite, Inc. and Ne...

*Question:* What non-compete restriction does the Sponsorship Agreement between Excite, Inc. and NetGrocer, Inc. (dated 1997-12-15) contain?

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Answer

[GAP] No evidence was found for: Answer the question: What non-compete restriction does the Sponsorship Agreement between Excite, Inc. and NetGrocer, Inc. (dated 1997-12-15) contain?

## Verification appendix

Claims: 1 · supported: 0 · partially: 0 · dropped: 0 · gaps: 1

Notes: no evidence in the bank; every section is a gap; OpenAIRateLimitError: Error code: 429

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | gap |  |  |  |

### Evidence

