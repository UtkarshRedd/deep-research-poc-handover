<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 1997-09-23 |
| Parties | Excite, Inc. ("Excite"); N2K, Inc. ("Sponsor") |
| Source | CUAD v1 / N2KINC_10_16_1997-EX-10.16-SPONSORSHIP AGREEMENT |

1 Exhibit 10.16

CONFIDENTIAL Portions of this Exhibit have been omitted pursuant to a request for confidential
treatment. The omitted portions, marked by [****], have been separately filed with the Commission.

SPONSORSHIP AGREEMENT

This agreement ("Agreement") is entered into as of the 23rd day of September, 1997 ("Effective
Date"), by and between Excite, Inc., a California corporation, located at 555 Broadway, Redwood
City, California 94063 ("Excite"), and N2K Inc., a Pennsylvania corporation, located at 55 Broad
Street, 26th Floor, New York, New York, 10004 ("Sponsor").

RECITALS

A. Excite maintains a site on the Internet at http://www.excite.com (the "Excite Site") and owns
and/or manages related Web Sites worldwide (collectively, the "Excite Network") which, among other
things, allow users to search for and access content and other sites on the Internet.

B. Excite also maintains and/or manages certain Web pages which may be delivered to users via email,
desktop "channels" or Internet "push" technologies (collectively, "Broadcast Pages") which may
incorporate content supplied to Excite by third parties for the purpose of providing value to Excite
users and providing access to the content, products and/or services of such third parties.

C. Sponsor is in the business of distributing certain online retail music merchandise and related
content and maintains a Web site at http://www.musicblvd.com (the "Sponsor Site") and other Web
sites through which it makes this merchandise and this content available to its users.

D. Sponsor wishes to be the exclusive retail store music sponsor of the Excite Site and the Excite
Broadcast Pages, to distribute its music-related content through the Excite Site and the Excite
Broadcast Pages and to promote its online retail music merchandise business to Excite.com users.

Therefore, the parties agree as follows:

1. EXCLUSIVITY, TERM AND RIGHT OF FIRST REFUSAL

a) Sponsor will be the exclusive retail music store sponsor of the Excite Site and the Excite
Broadcast Pages. Excite will not permit the display of advertising banners, promotional buttons,
promotional links or other promotional materials for any retail sale of Music Products on the Excite
Site, except those Music Products offered by Sponsor, nor advertising by any other Retail Music
Store. "Retail Music Store" shall mean any entity which is primarily engaged in the sale of Music
Products at retail to consumers. "Music Products" 2 CONFIDENTIAL

shall mean pre-recorded music hard goods, digitally distributed music (except live and/or cybercast
events), music books (to the extent this Agreement does not conflict with Excite's existing
agreement with Amazon.com), music-related t-shirts and apparel, and music videos (except live and/or
cybercast events).

Notwithstanding the foregoing, Excite may make available opportunities on the Excite Site to
purchase Music Products from parties other than Sponsor if such Music Products are not available
from Sponsor so long as, prior to entering into arrangements to make available opportunities to
purchase Music Products from parties other than Sponsor, Excite notifies Sponsor of its interest in
the Music Products and gives Sponsor thirty (30) days to make the desired Music Products available
through the Sponsor Site. Excite and Sponsor acknowledge that certain market opportunities may arise
in which the desired Music Products must be made available on less than thirty (30) days advance
notice and will work together in good faith to maximize those opportunities. In no event will Excite
enter into arrangements to make available opportunities to purchase Music Products from parties
other than Sponsor that would prevent Sponsor from being the exclusive source of such Music Products
on the Excite Site once the Music Products become available through Sponsor.

b) The term of this Agreement will begin on the Effective Date and will end on the second (2nd)
anniversary of the Commencement Date. The "Commencement Date" means the date on which Excite
commences delivery of Impressions (defined below). The parties anticipate the Commencement Date will
be on or about October 15, 1997.

c) The parties' existing agreements regarding sponsorship of the WebCrawler Web site
(http://webcrawler.com) and all of the existing advertising buys on the Excite Network will be
terminated as of the Commencement Date. Excite will credit Sponsor in an amount equal to [****].
This credit will be
<!-- page 2 -->
applied to reduce the first year exclusivity fee described in Section 7(b) and will be reflected in
a reduction of Sponsor's December 31, 1997 payment to Excite described in Section 7(e).

d) Excite will offer Sponsor the right of first refusal to negotiate with Excite for renewal of this
sponsorship.

2 3 CONFIDENTIAL

i) Excite will not propose, solicit or negotiate offers from entities other than Sponsor for any
retail music store sponsorships of the Excite Site, if at all, until [****] prior to the expiration
of the term of this Agreement.

ii) Commencing not later than [****] prior to the expiration of the term of the Agreement, Excite
will negotiate with Sponsor in good faith with respect to the terms and conditions under which this
Agreement would be renewed. Excite will negotiate exclusively with Sponsor for the next [****] in
good faith effort to negotiate and execute a written sponsorship renewal agreement. If, [****] prior
to the expiration of the term of the Agreement, the parties have not entered into a written
sponsorship renewal agreement. Excite may enter into negotiations with any third party with respect
to retail music store sponsorships of the Excite Site.

iii) In the event that Excite intends to enter into an agreement with a third party with respect to
retail music store sponsorships of the Excite Site before the expiration of the term of the
Agreement, Excite will deliver to Sponsor a written notice describing the relevant opportunity.
Although Excite will not be required to disclose any information in violation of any nondisclosure
agreement between Excite and any third party, the notice will include information sufficient to
permit Sponsor to evaluate the requirements for meeting the competing offer for retail music store
sponsorship of the Excite Site and to formulate a meaningful response. Sponsor will have [****]
after receipt of such written notice to provide notice to Excite that it is prepared to enter into
an agreement with Excite on the same terms and conditions as Excite proposes to accept from such
third party. Excite and Sponsor will then promptly commence good faith negotiations to conclude the
agreement.

iv) If Sponsor rejects said offer or fails to notify Excite of its acceptance within the [****]
period, Excite shall have the right thereafter to enter into the agreement with such third party,
provided the terms and conditions of the agreement (if entered into within the subsequent ninety
(90) days) are not less favorable to Excite than previously offered by Sponsor.

3 4 CONFIDENTIAL

2. IMPRESSIONS

a) "Impression" means any appearance of a link to the Sponsor Site whether graphic, text or any
combination of graphic and text. More than one Impression may appear on a page, except, however, not
more than three (3) Impressions per Channel page will count towards delivery of guaranteed
Impressions and, of these 3 Impressions, at least two (2) will link to pages in the Sponsor Site
offering Music Products; not more than two (2) Impressions per generic search results page will
count towards delivery of guaranteed Impressions and, of these 2 Impressions, at least one (1) will
link to pages in the Sponsor Site offering Music Products; and no more than one (1) Impression per
specific search results page will count towards delivery of guaranteed Impressions. In all events,
Excite will make a good faith effort to avoid duplicate Impressions on a single page, but in no
event will more than one (1) Impression for the same artist on a Music Product page count towards
delivery of guaranteed Impressions. For the purposes of this Agreement, "generic search results
page" is an Excite Search results page displayed in response to a query concerning generic music
topics and a "specific search results page" is an Excite Search results page displayed in response
to a query concerning a specific music artist or specific album title.

b) Excite and Sponsor will work together in good faith to define mutually agreeable Impressions in
the Excite Site designed to provide content of interest (defined below) to Excite users and/or
promote the Sponsor Site, in numbers sufficient to meet the Impression guarantees stated in Section
3.

c) Excite and Sponsor will collaborate on the design, appearance, and placement (the "look and
feel") of all Impressions. Excite
<!-- page 3 -->
will have final approval over the look and feel of the promotional Impressions, which approval will
not be unreasonably withheld.

3. IMPRESSION GUARANTEES

a) During the first year of the sponsorship following the Commencement Date, Excite will deliver not
less than [****] Impressions on the Excite Site.

b) During the second year of the sponsorship following the first anniversary of the Commencement
Date, Excite will deliver not less than [****] Impressions on the Excite Site.

4 5 CONFIDENTIAL

c) Excite will report traffic, Impressions and click-thrus to Sponsor on a monthly basis.

4. CONTENT PROVIDED TO EXCITE

a) Sponsor will provide to Excite the content described in Exhibit A ("Content"), subject to the
terms and conditions hereunder. Excite may incorporate music-related content on the Excite Site from
parties other than Sponsor so long as any links in or associated with such third-party content
relating to opportunities to purchase Music Products will link to pages in the Sponsor Site. Any
Content which appears in the Excite Site will be accompanied by attribution or branding identifying
Sponsor as the source of the Content and linking to the Sponsor Site.

b) Sponsor will ensure that the Content will at all times feature the full array of content and
functionality as made generally available by Sponsor at the Sponsor Site and its related Web sites,
through any other means of distribution of Sponsor's own branded service or through any other
third-party relationship, where Sponsor controls the Content.

c) Sponsor and Excite will determine mutually agreeable methods for the transmission and
incorporation of updates to the Content.

d) Excite will have sole control over the "look and feel" of the Excite Site and the Excite Network.
Excite will have sole control over the content, composition, "look and feel" and distribution of the
Broadcast Pages. Excite will have sole responsibility for providing, hosting and maintaining, at its
expense, the Excite Network and for providing and delivering the Broadcast Pages and for integration
of Content into the Broadcast Pages.

e) Sponsor will have sole responsibility for providing, at its expense, the Content to Excite.

5. THE CO-BRANDED AREA OF THE SPONSOR SITE AND DISTRIBUTION THROUGH THE EXCITE SITE AND THE
BROADCAST PAGES

a) Sponsor will design and create Web pages ("Co-Branded Pages" or, collectively, the "Co-Branded
Area") in the Sponsor Site incorporating music-related content to be mutually determined by the
parties including but not limited to Content described in Exhibit A, subject to the terms and
conditions hereunder. Each Co-Branded Page will display the name and/or brands of Sponsor and
Excite.

5 6 CONFIDENTIAL

Sponsor and Excite will collaborate on the "look and feel" of the Co-Branded Pages including, but
not limited to, the display, appearance and placement of the parties' respective names and/or brands
and of advertising displayed on the Co-Branded Pages. Excite will have final approval over the "look
and feel" of the Co-Branded Pages, which approval will not be unreasonably withheld.

b) The Co-Branded Area will reside completely on the Sponsor Site. Sponsor will have sole
responsibility for providing and maintaining, at its expense, the Sponsor Site, the Co-Branded Area,
the content displayed on the Co-Branded Site and any updates thereto.

c) Each Co-Branded Page will include one or more links to the Excite Site. Excite will supply
Sponsor with the URLs for these links.

d) Excite may, upon fifteen (15) days prior notice to Sponsor, request reasonable revisions to the
Co-Branded Area as needed to reflect changes that will not adversely affect Sponsor, such as changes
to Excite's name and/or brand or changes to the URLs for the links to the Excite Site. Sponsor will
use reasonable efforts to accommodate Excite's requested changes
<!-- page 4 -->
within the fifteen (15) day period.

e) Excite may incorporate reasonable portions of the Content on the Excite Site. Each such display
of the Content will count as an Impression, as defined in Section 2(a). Excite will provide links to
the Co-Branded Area from any pages on the Excite Site on which the Content appears. In its
discretion, Excite may elect to provide additional links to the Co-Branded Area from other locations
on the Excite Network and/or Broadcast Pages.

f) Reasonable excerpts or portions of the Content may be incorporated into Broadcast Pages, at
Excite's discretion. Excite will have sole control over of the content, composition, "look and feel"
and distribution of the Broadcast Pages.

6. PROMOTIONS

a) Excite and Sponsor will work together in good faith to create promotions specifically for
customers of the Co-Branded Area. Such joint promotions, when possible and where Sponsor controls
any applicable rights, will include but not be limited to the following:

6 7 CONFIDENTIAL

- [****]

- [****]

- [****]

- [****]

- [****]

- [****]

- [****]

- [****]

- [****]

- [****]

b) Neither party will make any public statement, press release or other announcement relating to the
terms of or existence of this Agreement without the prior written approval of the other.
Notwithstanding the foregoing, Sponsor hereby grants to Excite the right to issue an initial press
release, the timing and wording of which will be subject to Sponsor's reasonable approval, regarding
the relationship between Excite and Sponsor.

7. SPONSORSHIP FEES AND TRANSACTION COMMISSIONS

a) [****] will be due to Excite on the Effective Date as compensation for Excite's costs of
initiating access to the Excite Site, programming costs, set-up costs and other expenses associated
with Excite's initiation of the links, placements, advertisements and promotions contemplated by the
Agreement.

b) Sponsor will pay Excite [****] per year as compensation for being the exclusive online retail
music store sponsor of the Excite Site.

7 8 CONFIDENTIAL

c) Sponsor will pay Excite [****] in the first year of the term of the Agreement as compensation for
on-going programming, links, placements, advertisements and promotions contemplated by this
Agreement.

d) Sponsor will pay Excite [****] in the second year of the term of the Agreement as compensation
for on-going programming, links, placements, advertisements and promotions contemplated by this
Agreement.

e) Sponsor will make payments to Excite according to the following schedule:

DATE PAYMENT ---- ------- Effective Date [****] Commencement Date [****] 12/31/97 [****]

1/1/98 [****] 4/1/98 [****] 7/1/98 [****] 10/1/98 [****] 1/1/99 [****] 4/1/99 [****] 7/1/98 [****]
<!-- page 5 -->
f) Sponsor will pay Excite a share of all gross margins Sponsor realizes on transactions,
advertising, sponsorship, promotions and any other revenue generated during each year of the term of
the Agreement on the Sponsor Site as a result of users referred from the Excite Site ("Total
Revenue"), subject to the following conditions:

i) "Gross margin" is defined as [****].

ii) Total Revenue will be measured at the end of every three months after the Commencement Date.
This three-month Total Revenue amount will be compared to an amount equal to two (2) times the
corresponding three-month share of the applicable sponsorship fee described in Sections 6(c) and
6(d) (each pro rata share a "Revenue Floor").

8 9 CONFIDENTIAL

iii) If the Total Revenue earned by Sponsor during the three-month period exceeds the total of the
Revenue Floor applicable to the same three-month period, Sponsor will pay Excite [****] of the gross
margin Sponsor realizes on the gross revenue amount equal to the excess of the Total Revenue over
the Revenue Floor during the three-month period. iv) If the Total Revenue earned by Sponsor during
the three-month period does not exceed the Revenue Floor applicable to the same three-month period,
Sponsor will not be obligated to pay Excite any share of the gross revenue realized during the
three-month period.

g) Payments of shared gross margin will be due to Excite within thirty (30) days of the end of each
calendar quarter in which the revenue is recognized by Sponsor.

h) With each payment, Sponsor will provide to Excite documentation reasonably detailing the
calculation of the payment.

i) Sponsor will maintain accurate records with respect to the calculation of all payments due under
this Agreement. Excite may, upon no less than thirty (30) days prior written notice to Sponsor,
cause an independent Certified Public Accountant to inspect the records of Sponsor reasonably
related to the calculation of such payments during Sponsor's normal business hours. The fees charged
by such Certified Public Accountant in connection with the inspection will be paid by Excite unless
the payments made to Excite are determined to have been less than ninety percent (90%) of the
payment owed to Excite, in which case Sponsor will be responsible for the payment of the reasonable
fees for such inspection.

8. USER DATA AND USAGE REPORTS

a) All data concerning users and their behavior relating to the use of the Excite Site will be owned
solely by Excite. Data relating to the use of Sponsor's Site (excluding users referred from the
Excite Site) will be owned solely by Sponsor. Data relating to the use of the Co-Branded Pages will
be jointly owned and shared by both parties.

b) All jointly owned and shared data will be held in confidence and will not be used except in
accordance with reasonable guidelines to be mutually agreed upon by the parties.

9 10 CONFIDENTIAL

c) Sponsor and Excite will each provide the other via email usage reports containing the information
set forth in Exhibit B ("Usage Reports"). Each Usage Report will cover a calendar month and will be
delivered within fifteen (15) days following the end of the applicable month. The parties may, by
mutual written agreement, alter the content of the Usage Reports.

d) SPONSOR AND EXCITE WILL USE REASONABLE EFFORTS TO ENSURE THE ACCURACY OF THE USAGE REPORTS BUT
NEITHER PARTY WARRANTS THAT THE USAGE REPORTS WILL CONFORM TO ANY SPECIFICATIONS AT ANY GIVEN TIME.
NEITHER PARTY WILL BE HELD LIABLE FOR ANY CLAIMS AS THEY RELATE TO SUCH USAGE REPORTS, EXCEPT TO THE
EXTENT THAT SUCH USAGE REPORTS SERVE AS THE BASIS FOR PAYMENTS UNDER THIS AGREEMENT.
<!-- page 6 -->
9. CONTENT OWNERSHIP AND LICENSE

a) Sponsor will retain all right, title and interest in and to the Content worldwide (including, but
not limited to, ownership of all copyrights and other intellectual property rights therein). Subject
to the terms and conditions of this Agreement, Sponsor hereby grants to Excite a royalty-free,
non-exclusive, worldwide license to use, reproduce, distribute, transmit and publicly display the
Content in accordance with this Agreement and to sub-license the Content to Excite's wholly-owned
subsidiaries or to joint ventures in which Excite participates for the sole purpose of using,
reproducing, distributing, transmitting and publicly displaying the Content in accordance with this
Agreement

b) Excite will retain all right, title, and interest in and to the Excite Site and the Excite
Network and the Broadcast Pages worldwide (including, but not limited to, ownership of all
copyrights, look and feel and other intellectual property rights therein).

10. TRADEMARK OWNERSHIP AND LICENSE

a) Sponsor will retain all right, title and interest in and to its trademarks, service marks and
trade names worldwide, subject to the limited license granted to Excite hereunder.

b) Excite will retain all right, title and interest in and to its trademarks, service marks and
trade names worldwide, subject to the limited license granted to Sponsor hereunder.

10 11 CONFIDENTIAL

c) Each party hereby grants to the other a non-exclusive, limited license to use its trademarks,
service marks or trade names only as specifically described in this Agreement. All such use shall be
in accordance with each party's reasonable policies regarding advertising and trademark usage as
established from time to time.

d) Upon the expiration or termination of this Agreement, each party will cease using the trademarks,
service marks and/or trade names of the other except:

i) As the parties may agree in writing; or

ii) To the extent permitted by applicable law.

11. TERMINATION a) If Excite fails to deliver the guaranteed number of Impressions on the Excite
Site during the first year, Excite will use commercially reasonable efforts to "make good" the
shortfall. If Excite fails to "make good" the shortfall within [****] following the first year end,
Sponsor may terminate the Agreement in accordance with Section 11 (b).

b) If Excite fails to deliver the guaranteed number of Impressions on the Excite Site during the
second year, Excite will use commercially reasonable efforts to "make good" the shortfall within
[****] following the second year end. However, the term of this Agreement will continue until Excite
has made good the guaranteed number of Impressions on the Excite Site. Sponsor will not be obligated
to make sponsorship, advertising or exclusivity payments to Excite during the "make good" period
after the second year of the Agreement, but Sponsor will continue to make revenue sharing payments
as described in Section 7(e). For the purposes of the calculation of revenue sharing during this
"make good" period only, the "Revenue Floor" from the last quarter of the second year of the term of
the Agreement will apply. c) Either party may terminate this Agreement if the other party materially
breaches its obligations hereunder and such breach remains uncured for thirty (30) days following
the notice to the breaching party of the breach, with the following exceptions:

i) Excite will promptly notify Sponsor of any errors, failures or outages of the Content. Sponsor
will promptly notify Excite of any errors, failures or outages of the Co-Branded Area.

11 12 CONFIDENTIAL

Sponsor will take all reasonable measures to correct any such errors or outages as soon as
reasonably possible. In the event of three or more errors, failures or outages of the Content or the
Co-Branded Area in any thirty (30) day period, Excite may elect to terminate this Agreement upon
fifteen days written notice to Sponsor, unless Sponsor demonstrates to Excite's reasonable
satisfaction before the
<!-- page 7 -->
expiration of the fifteen (15) day notice period that the cause(s) of the errors, failures or
outages have been corrected; or

ii) Sponsor will ensure that the Content will at all times be at least substantially similar to any
other source of comparable topical content available on the Internet in terms of the following
factors, taken as a whole: (i) breadth and depth of coverage, (ii) timeliness of content updates and
(iii) reputation and ranking based on a cross-section of third party reviewers in terms of features,
functionality, quality and other qualitative factors. In the event that Sponsor fails to meet these
quality criteria, Excite may terminate this agreement on thirty (30) days written notice and enter
into an other arrangements for the acquisition of similar content, unless Sponsor demonstrates to
Excite's reasonable satisfaction before the expiration of the thirty (30) day notice period that the
deficiencies in the Content have been corrected.

d) All payments that have accrued prior to the termination or expiration of this Agreement will be
payable in full within thirty (30) days thereof.

e) The provisions of Section 12 (Confidentiality), Section 13 (Warranty and Indemnity), Section 14
(Limitation of Liability) and Section 15 (Dispute Resolution) will survive any termination or
expiration of this Agreement.

12. CONFIDENTIALITY

12 13 CONFIDENTIAL

a) For the purposes of this Agreement, "Confidential Information" means information about the
disclosing party's (or its suppliers') business or activities that is proprietary and confidential,
which shall include all business, financial, technical and other information of a party marked or
designated by such party as "confidential" or "proprietary"; or information which, by the nature of
the circumstances surrounding the disclosure, ought in good faith to be treated as confidential.

b) Confidential Information will not include information that (i) is in or enters the public domain
without breach of this Agreement, (ii) the receiving party lawfully receives from a third party
without restriction on disclosure and without breach of a nondisclosure obligation or (iii) the
receiving party knew prior to receiving such information from the disclosing party or develops
independently.

c) Each party agrees (i) that it will not disclose to any third party or use any Confidential
Information disclosed to it by the other except as expressly permitted in this Agreement and (ii)
that it will take all reasonable measures to maintain the confidentiality of all Confidential
Information of the other party in its possession or control, which will in no event be less than the
measures it uses to maintain the confidentiality of its own information of similar importance.

d) Notwithstanding the foregoing, each party may disclose Confidential Information (i) to the extent
required by a court of competent jurisdiction or other governmental authority or otherwise as
required by law or (ii) on a "need-to-know" basis under an obligation of confidentiality to its
legal counsel, accountants, banks and other financing sources and their advisors.

e) The information contained in the Usage Reports provided by each party hereunder will be deemed to
be the Confidential Information of the disclosing party.

f) The terms and conditions of this Agreement will be deemed to be the Confidential Information of
each party and will not be disclosed without the written consent of the other party.

13. WARRANTY AND INDEMNITY

13 14 CONFIDENTIAL

a) Sponsor warrants that it owns, or has obtained the right to distribute and make available as
specified in this Agreement, any and all content provided to Excite or made available to third
parties in connection with this Agreement.

b) Sponsor warrants that the Content will comply with the description and technical specifications
contained in Exhibit A.

c) Excite will indemnify, defend and hold harmless Sponsor, its
<!-- page 8 -->
affiliates, officers, directors, employees, consultants and agents from any and all third party
claims, liability, damages and/or costs (including, but not limited to, attorneys fees) arising from
the breach of any warranty, representation or covenant in this Agreement. Sponsor will promptly
notify Excite of any and all such claims and will reasonably cooperate with Excite with the defense
and/or settlement thereof; provided that, if any settlement requires an affirmative obligation of,
results in any ongoing liability to or prejudices or detrimentally impacts Sponsor in any way and
such obligation, liability, prejudice or impact can reasonably be expected to be material, then such
settlement shall require Sponsor's written consent (not to be unreasonably withheld or delayed) and
Sponsor may have its own counsel in attendance at all proceedings and substantive negotiations
relating to such claim.

d) Sponsor will indemnify, defend and hold harmless Excite, its affiliates, officers, directors,
employees, consultants and agents from any and all third party claims, liability, damages and/or
costs (including, but not limited to, attorneys fees) arising from:

i) The breach of any warranty, representation or covenant in this Agreement; or

ii) Any claim that the Content infringes or violates any third party's copyright, patent, trade
secret, trademark, right of publicity or right of privacy or contains any defamatory content.

Excite will promptly notify Sponsor of any and all such claims and will reasonably cooperate with
Sponsor with the defense and/or settlement thereof; provided that, if any settlement requires an
affirmative obligation of, results in any ongoing liability to or prejudices or detrimentally
impacts Excite in any way and such obligation, liability, prejudice or impact can reasonably be
expected to be material, then such settlement shall require Excite's written consent (not to be
unreasonably withheld or

14 15 CONFIDENTIAL

delayed) and Excite may have its own counsel in attendance at all proceedings and substantive
negotiations relating to such claim.

e) EXCEPT AS SPECIFIED IN THIS AGREEMENT, NEITHER PARTY MAKES ANY WARRANTY IN CONNECTION WITH THE
SUBJECT MATTER OF THIS AGREEMENT AND HEREBY DISCLAIMS ANY AND ALL IMPLIED WARRANTIES, INCLUDING ALL
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE REGARDING SUCH SUBJECT
MATTER.

14. LIMITATION OF LIABILITY

EXCEPT UNDER SECTION 13(c) and (d), IN NO EVENT WILL EITHER PARTY BE LIABLE TO THE OTHER FOR ANY
SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES, WHETHER BASED ON BREACH OF CONTRACT, TORT (INCLUDING
NEGLIGENCE) OR OTHERWISE, WHETHER OR NOT THAT PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE. THE LIABILITY OF EXCITE FOR DAMAGES OR ALLEGED DAMAGES HEREUNDER, WHETHER IN CONTRACT, TORT
OR ANY OTHER LEGAL THEORY, IS LIMITED TO, AND WILL NOT EXCEED, THE AMOUNTS ACTUALLY PAID BY SPONSOR
TO EXCITE HEREUNDER.

15. DISPUTE RESOLUTION

a) The parties agree that any breach of either of the parties' obligations regarding trademarks,
service marks or trade names and/or confidentiality would result in irreparable injury for which
there is no adequate remedy at law. Therefore, in the event of any breach or threatened breach of a
party's obligations regarding trademarks, service marks or trade names or confidentiality, the
aggrieved party will be entitled to seek equitable relief in addition to its other available legal
remedies in a court of competent jurisdiction.

b) In the event of disputes between the parties arising from or concerning in any manner the subject
matter of this Agreement, other than disputes arising from or concerning trademarks, service marks
or trade names and/or confidentiality, the parties will first attempt to resolve the dispute(s)
through good faith negotiation. In the event that the dispute(s) cannot be resolved through good
faith negotiation, the parties will refer the dispute(s) to a mutually acceptable mediator.

15 16 CONFIDENTIAL

c) In the event that disputes between the parties arising from or concerning in any manner the
subject matter of this Agreement, other than disputes arising from or concerning trademarks,
<!-- page 9 -->
service marks or trade names and/or confidentiality, cannot be resolved through good faith
negotiation and mediation, the parties will refer the dispute(s) to the American Arbitration
Association for resolution through binding arbitration by a single arbitrator pursuant to the
American Arbitration Association's rules applicable to commercial disputes.

16. GENERAL

a) Assignment. Neither party may assign this Agreement, in whole or in part, without the other
party's written consent (which will not be unreasonably withheld), except that no such consent will
be required in connection with (i) a merger, reorganization or sale of all, or substantially all, of
such party's assets or (ii) either party's assignment and/or delegation of its rights and
responsibilities hereunder to a wholly-owned subsidiary or joint venture in which such party holds a
controlling interest. Any attempt to assign this Agreement other than as permitted above will be
null and void.

b) Governing Law. This Agreement will be governed by and construed in accordance with the laws of
the State of New York

c) Notice. Any notice under this Agreement will be in writing and delivered by personal delivery,
express courier, confirmed facsimile, confirmed email or certified or registered mail, return
receipt requested, and will be deemed given upon personal delivery, one (1) day after deposit with
express courier, upon confirmation of receipt of facsimile or email or five (5) days after deposit
in the mail. Notices will be sent to a party at its address set forth below or such other address as
that party may specify in writing pursuant to this Section.

d) No Agency. The parties are independent contractors and will have no power or authority to assume
or create any obligation or responsibility on behalf of each other. This Agreement will not be
construed to create or imply any partnership, agency or joint venture.

e) Force Majeure. Any delay in or failure of performance by either party under this Agreement will
not be considered a breach of this Agreement and will be excused to the extent caused by any
occurrence beyond the reasonable control of such party including,

16 17 CONFIDENTIAL

but not limited to, acts of God, power outages and governmental restrictions.

f) Severability. In the event that any of the provisions of this Agreement are held by to be
unenforceable by a court or arbitrator, the remaining portions of the Agreement will remain in full
force and effect.

g) Entire Agreement. This Agreement is the complete and exclusive agreement between the parties with
respect to the subject matter hereof, superseding any prior agreements and communications (both
written and oral) regarding such subject matter. This Agreement may only be modified, or any rights
under it waived, by a written document executed by both parties.

N2K Inc. Excite, Inc. By: /s/ Jonathan Diamond By: /s/ George Bell --------------------------
------------------------ Name: Jonathan Diamond Name: George Bell --------------------------
------------------------ Title: Vice Chairman Title: Pres. and CEO --------------------------
------------------------ Date: 9/23/97 Date: 9/23/97 --------------------------
------------------------

55 Broad Street, 26th Floor 555 Broadway New York, New York, 10004 Redwood City, California 94063
415.568.6000 (voice) 415.568.6030 (fax)

17 18 CONFIDENTIAL

EXHIBIT A

CONTENT DESCRIPTION AND TECHNICAL SPECIFICATIONS

FOR THE CONTENT

Sponsor content shall be defined as any or all content and services controlled by N2K available via
the main Music Boulevard site (http://www.musicblvd.com), the Music Store. In addition, Excite
reserves the right to draw upon the editorial content controlled by N2K and available via N2K's
network of music-related sites including, but not limited to the following:
<!-- page 10 -->
Music News AllStar Mag - www.allstarmag.com

Labels N2K record label, N2K Encoded Music - www.n2kencodedmusic.com

Music Genre Sites Classical Insites - www.classicalinsites.com Leonard Bernstein -
www.leonardbernstein.com Rocktropolis - www.rocktropolis.com Jazz Central Station -
www.jazzcentralstation.com

N2K will make good faith efforts to assist Excite in obtaining access to music-related content under
the control of third parties with which N2K has existing relationships.

18 19 CONFIDENTIAL

EXHIBIT B

USAGE REPORTS
