"""Golden set v1: the generated corpus and questions are correct by construction (no model calls).

Loads data/golden_docs through the real ingest path and checks, for every question, that the
placeholders resolve, the cited pages exist, and the gold answer / items are verbatim on a cited
page; not_in_corpus answers and their absent_terms appear nowhere in the corpus.
"""
from __future__ import annotations

import importlib.util
import re
import sys
from pathlib import Path

import pytest

from dr.eval.golden import GoldenQuestion, load_golden, placeholder_stem, resolve_gold_docs
from dr.ingest.load import load_dir
from dr.models import DocRecord

ROOT = Path(__file__).resolve().parents[1]
GOLDEN_DOCS = ROOT / "data" / "golden_docs"
QUESTIONS = ROOT / "data" / "golden" / "questions.jsonl"
GENERATOR = ROOT / "scripts" / "make_golden_corpus.py"

PAGE_RE = re.compile(r"^<!--\s*page\s+(\d+)\s*-->\s*$", re.MULTILINE)

MIN_DOCS, MAX_DOCS = 25, 40
MIN_QUESTIONS, MAX_QUESTIONS = 30, 50
MIN_PAGES, MAX_PAGES = 3, 12
TYPE_MINIMUMS = {"single": 5, "multihop": 4, "identifier": 3, "coverage": 3, "temporal": 4, "not_in_corpus": 3}
NOT_IN_CORPUS_SHARE = 0.10


@pytest.fixture(scope="module")
def docs() -> list[DocRecord]:
    return load_dir(GOLDEN_DOCS)


@pytest.fixture(scope="module")
def questions() -> list[GoldenQuestion]:
    return load_golden(QUESTIONS)


@pytest.fixture(scope="module")
def resolved(questions, docs) -> list[GoldenQuestion]:
    return resolve_gold_docs(questions, docs)


def _pages(text: str) -> dict[int, str]:
    """page number -> page text (the marker line excluded)."""
    out: dict[int, str] = {}
    cur: int | None = None
    buf: list[str] = []
    for ln in text.split("\n"):
        m = PAGE_RE.match(ln)
        if m:
            if cur is not None:
                out[cur] = "\n".join(buf)
            cur, buf = int(m.group(1)), []
        else:
            buf.append(ln)
    if cur is not None:
        out[cur] = "\n".join(buf)
    return out


# --------------------------------------------------------------------------- corpus


def test_corpus_loads_with_markers_and_metadata(docs):
    assert MIN_DOCS <= len(docs) <= MAX_DOCS, len(docs)
    for d in docs:
        pages = _pages(d.text)
        assert pages, f"{d.source_path}: no page markers"
        assert sorted(pages) == list(range(1, len(pages) + 1)), f"{d.source_path}: pages not 1..N"
        assert MIN_PAGES <= len(pages) <= MAX_PAGES, (d.source_path, len(pages))
        for key in ("title", "doc_type", "date", "parties"):
            assert d.metadata.get(key), f"{d.source_path}: metadata missing {key}: {d.metadata}"
        assert re.fullmatch(r"\d{4}-\d{2}-\d{2}", d.metadata["date"]), (d.source_path, d.metadata["date"])


def test_corpus_has_the_designed_mix(docs):
    types = [d.metadata["doc_type"] for d in docs]
    assert types.count("Credit Agreement") >= 5
    assert types.count("Amendment") >= 3
    assert types.count("Guarantee") >= 3
    assert types.count("Security Agreement") >= 2
    assert types.count("Fee Letter") >= 3
    assert types.count("Waiver") + types.count("Consent") >= 2
    assert types.count("Side Letter") >= 1
    assert sum(1 for d in docs if "conformed" in Path(d.source_path).stem) >= 2, "near-duplicate traps missing"
    distractors = [d for d in docs if Path(d.source_path).stem.startswith("distractor_")]
    assert len(distractors) >= 3
    # the conformed copy is a near-duplicate, not an exact one: dedupe must keep it
    stems = {Path(d.source_path).stem for d in docs}
    for stem in list(stems):
        if stem.endswith("_conformed"):
            assert stem.removesuffix("_conformed") in stems


def test_doc_ids_unique_and_stems_unique(docs):
    assert len({d.doc_id for d in docs}) == len(docs)
    assert len({Path(d.source_path).stem for d in docs}) == len(docs)


# --------------------------------------------------------------------------- questions


def test_question_counts_and_type_distribution(questions):
    n = len(questions)
    assert MIN_QUESTIONS <= n <= MAX_QUESTIONS, n
    assert len({q.qid for q in questions}) == n, "duplicate qids"
    counts = {t: sum(1 for q in questions if q.type == t) for t in TYPE_MINIMUMS}
    for t, lo in TYPE_MINIMUMS.items():
        assert counts[t] >= lo, (t, counts)
    assert counts["not_in_corpus"] >= NOT_IN_CORPUS_SHARE * n, counts


def test_every_placeholder_resolves(questions, docs, resolved):
    for q, r in zip(questions, resolved):
        assert len(q.gold_docs) == len(r.gold_docs)
        for before, after in zip(q.gold_docs, r.gold_docs):
            assert placeholder_stem(before.doc_id) is not None, f"{q.qid}: gold doc_id is not a <stem> placeholder"
            assert placeholder_stem(after.doc_id) is None, f"{q.qid}: unresolved {after.doc_id}"
            assert any(d.doc_id == after.doc_id for d in docs)
    # the originals are untouched (resolve returns copies)
    assert all(placeholder_stem(gd.doc_id) for q in questions for gd in q.gold_docs)


def test_unresolvable_placeholder_raises(questions, docs):
    bad = questions[0].model_copy(deep=True)
    bad.gold_docs.append(type(bad.gold_docs[0])(doc_id="<no_such_document>", pages=[1]))
    with pytest.raises(ValueError, match="no_such_document"):
        resolve_gold_docs([bad], docs)


def test_load_golden_resolves_when_docs_given(docs):
    qs = load_golden(QUESTIONS, docs=docs)
    ids = {d.doc_id for d in docs}
    assert all(gd.doc_id in ids for q in qs for gd in q.gold_docs)


def test_gold_pages_exist_and_answers_are_verbatim(resolved, docs):
    by_id = {d.doc_id: d for d in docs}
    for q in resolved:
        if q.type == "not_in_corpus":
            continue
        assert q.gold_docs, f"{q.qid}: no gold docs"
        assert q.gold_answer or q.gold_items, f"{q.qid}: neither gold_answer nor gold_items"
        cited: list[str] = []
        for gd in q.gold_docs:
            pages = _pages(by_id[gd.doc_id].text)
            assert gd.pages, f"{q.qid}: {gd.doc_id} cited without pages"
            for p in gd.pages:
                assert p in pages, f"{q.qid}: page {p} missing in {by_id[gd.doc_id].source_path}"
                cited.append(pages[p])
        joined = "\n".join(cited)
        if q.gold_answer:
            assert q.gold_answer in joined, f"{q.qid}: gold_answer {q.gold_answer!r} not verbatim on a cited page"
        for item in q.gold_items:
            assert item in joined, f"{q.qid}: gold item {item!r} not verbatim on a cited page"
        if q.type == "coverage":
            assert len(q.gold_items) >= 2, f"{q.qid}: coverage question needs gold_items"


def test_not_in_corpus_answers_absent_everywhere(questions, docs):
    corpus = "\n".join(d.text for d in docs)
    for q in questions:
        if q.type != "not_in_corpus":
            continue
        assert not q.gold_docs, f"{q.qid}: not_in_corpus must not cite documents"
        assert q.gold_answer and q.gold_answer not in corpus
        assert q.absent_terms, f"{q.qid}: not_in_corpus question needs absent_terms"
        for term in q.absent_terms:
            assert term not in corpus, f"{q.qid}: {term!r} does occur in the corpus"


def test_rubrics_present(questions):
    for q in questions:
        assert q.rubric, f"{q.qid}: empty rubric"


# --------------------------------------------------------------------------- generator


def test_generator_is_deterministic_and_matches_disk():
    spec = importlib.util.spec_from_file_location("make_golden_corpus", GENERATOR)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    files_a, jsonl_a, _ = mod.generate()
    files_b, jsonl_b, _ = mod.generate()
    assert files_a == files_b and jsonl_a == jsonl_b, "generator is not deterministic"
    on_disk = {p.name: p.read_text(encoding="utf-8") for p in GOLDEN_DOCS.glob("*.md")}
    assert on_disk == files_a, "data/golden_docs is stale: rerun scripts/make_golden_corpus.py"
    assert QUESTIONS.read_text(encoding="utf-8") == jsonl_a, "questions.jsonl is stale: rerun scripts/make_golden_corpus.py"
