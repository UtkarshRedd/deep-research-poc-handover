<!-- page 1 -->
# INTELLECTUAL PROPERTY AGREEMENT
| Field | Value |
|---|---|
| Document Type | IP Agreement |
| Agreement Date | 2007-12-20 |
| Parties | NMS Communications Corp. ("Seller"); Verson Backhaul Solutions, Inc. ("Backhaul") |
| Source | CUAD v1 / VERSOTECHNOLOGIESINC_12_28_2007-EX-99.3-INTELLECTUAL PROPERTY AGREEMENT |

Exhibit 99.3

EXECUTION COPY

INTELLECTUAL PROPERTY AGREEMENT

THIS INTELLECTUAL PROPERTY AGREEMENT (this "Intellectual Property Agreement"), dated as of December
20, 2007, is made by and between NMS COMMUNICATIONS CORP., a Delaware corporation ("Seller"), and
VERSO BACKHAUL SOLUTIONS, INC., a Georgia corporation ("Backhaul").

RECITALS:

WHEREAS, Seller and Verso Technologies, Inc., a Minnesota corporation ("Buyer"), have entered into
that certain Asset Purchase Agreement, dated as of the date hereof (the "Asset Purchase Agreement"),
pursuant to which Buyer has the right to acquire the Purchased Assets of Seller and its
Subsidiaries, as more particularly described in the Asset Purchase Agreement (all capitalized words
and terms used herein and not otherwise defined herein shall have the meanings ascribed to them in
the Asset Purchase Agreement); and

WHEREAS, Buyer has designated Backhaul as a Buyer Designee for purposes of the Asset Purchase
Agreement, and Buyer has assigned to Backhaul the right to receive the Purchased Assets pursuant to
that certain Assignment of Asset Purchase Agreement between Buyer and Backhaul dated as of the date
hereof.

ASSIGNMENT:

NOW, THEREFORE, for good and valuable consideration, the receipt and adequacy of which are hereby
acknowledged, Seller does hereby transfer, sell, assign, convey and deliver to Backhaul all right,
title and interest in, to and under the Assigned Intellectual Property, including, without
limitation, the Trademarks and Patents set forth on Schedules A and B hereof, respectively, and all
goodwill of the Purchased Business associated therewith. Seller hereby covenants and agrees, that
from time to time forthwith upon the reasonable written request of Backhaul or Buyer, that Seller
will, at Backhaul's cost and expense, do, execute, acknowledge and deliver or cause to be done,
executed, acknowledged and delivered, each and all of such further acts, deeds, assignments,
transfers, conveyances and assurances as may reasonably be required by Backhaul or Buyer in order to
transfer, assign, convey and deliver unto and vest in Backhaul title to all right, title and
interest of Seller in, to and under the Assigned Intellectual Property.

This Intellectual Property Agreement is subject in all respects to the terms and conditions of the
Asset Purchase Agreement and is intended only to document the assignment of the Assigned
Intellectual Property. Nothing contained in this Intellectual Property Agreement shall be deemed to
supersede any of the obligations, agreements, representations, covenants or warranties of Seller and
Buyer contained in the Asset Purchase Agreement.

This Intellectual Property Agreement shall be construed and interpreted according to the laws of the
State of Georgia, applicable contracts to be wholly performed within the State of Georgia.
<!-- page 2 -->
This Intellectual Property Agreement may be executed in one or more counterparts, and by the
different parties hereto in separate counterparts, each of which when executed shall be deemed to be
an original, but all of which taken together shall constitute one and the same agreement. Delivery
of an executed counterpart of a signature page to this Intellectual Property Agreement by facsimile
shall be effective as delivery of a manually executed counterpart of this Intellectual Property
Agreement.

[Signature Page to Follow]

2
<!-- page 3 -->
IN WITNESS WHEREOF, the parties hereto have executed and delivered this Intellectual Property
Agreement as of the date first written above.

NMS COMMUNICATIONS CORP. By: /s/ Robert Schechter Name: Robert Schechter Title: CEO/President VERSO
BACKHAUL SOLUTIONS, INC. By: /s/ Martin D. Kidder Name: Martin D. Kidder Title: President
<!-- page 4 -->
STATE OF Massachusetts:

COUNTY OF Middlesex:

On the 20th day of December, 2007, before me personally came Robert Schechter, to me known (or
satisfactorily proven), who being by me duly sworn, did depose and say that he/she is the
CEO/President of NMS Communications Corporation, the corporation described in, and which executed
the foregoing instrument, and that he/she was fully authorized to execute this Intellectual Property
Agreement on behalf of said corporation.

/s/ Jason A. Minio (SEAL) Jason A. Minio Notary Public Commonwealth of Massachusetts My Commission
Expires November 1, 2013

STATE OF Georgia:

COUNTY OF Cobb:

On the 20th day of December, 2007, before me personally came Martin Kidder, to me known (or
satisfactorily proven), who being by me duly sworn, did depose and say that he/she is the CFO of
Verso Technologies, the corporation described in, and which executed the foregoing instrument, and
that he/she was fully authorized to execute this Intellectual Property Agreement on behalf of said
corporation.

/s/ Susanne G. Davis (SEAL) Susanne G. Davis Notary Public, Cobb County, GA My Commission expires
Aug. 10, 2010
<!-- page 5 -->
SCHEDULE A

[INTENTIONALLY OMITTED]
<!-- page 6 -->
SCHEDULE B

[INTENTIONALLY OMITTED]
