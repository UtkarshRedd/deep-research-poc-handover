<!-- page 1 -->
# AMENDMENT TO THE DISTRIBUTOR AGREEMENT BETWEEN INGRAM MICRO AND NETGEAR
| Field | Value |
|---|---|
| Document Type | Distributor Agreement |
| Agreement Date | 1996-10-01 |
| Parties | Ingram Micro ("Distributor"); NETGEAR, Inc. ("NETGEAR") |
| Source | CUAD v1 / NETGEAR,INC_04_21_2003-EX-10.16-AMENDMENT TO THE DISTRIBUTOR AGREEMENT BETWEEN INGRAM MICRO AND NETGEAR |

term under the Agreement will not be effective unless mutually agreed to in writing and signed by
authorized representatives of both parties. Neither party shall be bound by typographical or
clerical errors.

G. Neither party is liable for its failure or delay to perform its obligations under the Agreement
due to strikes, wars, revolutions, acts of terrorism, fires, floods, explosions, earthquakes,
shortages in labor, components or materials, government regulations, or other causes beyond its
control.

H. This Agreement may not be assigned by either party without prior written permission from the
other party, which permission shall not be unreasonably withheld or delayed. Any attempt by either
party to assign any right, or delegate any duty or obligation which arises under the Agreement
without such permission will be voidable.

19. ENTIRE AGREEMENT, GOVERNING LAW

This Agreement, including its attachment and order acknowledgments under the Agreement, constitutes
the entire agreement between Distributor and NETGEAR with respect to the purchase, resale and
distribution of the Products and is governed by the laws of the State of California except that body
of law dealing with conflicts of law.

INGRAM NETGEAR Distributor Agreement 11 083096

* Portions denoted with an asterisk have been omitted and filed separately with the Securities and
Exchange Commission pursuant to a request for confidential treatment.

EXHIBIT 1

DISCOUNT SCHEDULE

The initial Discount offered Distributor for purchase or license of NETGEAR Products included on the
NETGEAR Price List in effect on the Effective Date of this Agreement is [*] off of the then current
NETGEAR list price.

Distributor agrees that the foregoing Discount is only applicable to Products included on the
NETGEAR Price List on the Effective Date of this Agreement. NETGEAR reserves the right to add
Products to the Price List at its sole discretion and any such additional Products shall be offered
to Distributor at discounts to be determined at that time.

INGRAM NETGEAR Distributor Agreement 12 083096

EXHIBIT 2

DISTRIBUTOR'S ROUTING GUIDE

INGRAM NETGEAR Distributor Agreement 13 083096

CONFIDENTIAL TREATMENT REQUEST

* Portions denoted with an asterisk have been omitted and filed separately with the Securities and
Exchange Commission pursuant to a request for confidential treatment.

EXHIBIT 3

CMD NAMED ACCOUNTS [*]

INGRAM NETGEAR Distributor Agreement 14 092696

EXHIBIT 4

MARKETING PLAN

INGRAM NETGEAR Distributor Agreement 15 083096

CONFIDENTIAL TREATMENT REQUEST

* Portions denoted with an asterisk have been omitted and filed separately with the Securities and
Exchange Commission pursuant to a request for confidential treatment.

AMENDMENT TO THE DISTRIBUTOR AGREEMENT BETWEEN INGRAM MICRO AND NETGEAR
<!-- page 2 -->
This Amendment is entered into effective October 1,1996 ("Amendment Date") by and between NETGEAR,
Inc. ("NETGEAR"), a wholly owned subsidiary of Bay Networks, Inc., and Ingram Micro ("Distributor")
acting on behalf of itself and its affiliates.

NETGEAR and Distributor having previously entered into a Distributor Agreement ("Agreement") with an
Effective Date of March 1,1996, now mutually agree to amend that Agreement as follows:

1. Subject to the terms of this Amendment, the Territory listed in Section 2 of the Agreement is
amended to be the United States and [*].

2. During the initial one year period beginning on the Amendment Date, Distributor shall be the only
distributor appointed by NETGEAR in [*], subject to Distributor conducting mutually agreed to
marketing activities as described in the Marketing Plan for [*] to be developed and agreed to by and
between the parties and which shall be attached to and made a part of this Agreement as Exhibit 4a.
For the purposes of this provision, distributor shall mean a company acquiring products directly
from NETGEAR for resale or license to dealers or other second tier resellers which in turn resell or
license the products to end use customers. The foregoing notwithstanding, during the [*] and any
subsequent period, NETGEAR reserves the right to sell or license Products in [*] to customers other
than distributors such as, but not limited to resellers who procure Products at centralized
locations for resale to end-use customers solely through their wholly or majority owned retail
outlets, both store-front and catalog. Following the [*], for any extension or renewal term,
Distributor's appointment as Distributor shall be non-exclusive and NETGEAR may appoint other
distributors in [*] at its sole discretion.

3. The terms and conditions of this Amendment, shall amend and supersede any conflicting terms of
the original Agreement. All other terms of the original Agreement shall remain unchanged.

IN WITNESS WHEREOF, the parties have executed this Amendment to be effective as of the date first
written above.

NETGEAR: DISTRIBUTOR:

NETGEAR, INC. INGRAM MICRO

By: /s/ Lloyd Cainey By: /s/ Michael Terrell --------------- ------------------- Name: /s/ Lloyd
Cainey Name: Michael Terrell Title: Exec VP Enterprise Business Group Title: Vice President
Purchasing Date: 4/30/97 Date: 2/21/97

Ingram Amendment 1 111296

CONFIDENTIAL TREATMENT REQUEST

* Portions denoted with an asterisk have been omitted and filed separately with the Securities and
Exchange Commission pursuant to a request for confidential treatment.

[INGRAM MICRO LOGO]

AMENDMENT #2 TO THE DISTRIBUTION AGREEMENT

THIS AMENDMENT (the "Amendment") is entered into this 15th day of July 1998, by and between INGRAM
MICRO INC. ("Ingram") and NETGEAR, INC. ("Vendor").

The parties have agreed to amend their Distribution Agreement ("Agreement") dated October 1,1996.

1. Section 2, TERRITORY, is amended to be United States, [*].

2. This Amendment shall remain in effect for the current term and any renewal term of the Agreement.

Notwithstanding the foregoing, all other provisions of the Agreement remain unchanged. The
undersigned has read this Amendment, agrees hereto, and is an authorized representative of its
respective party.

INGRAM MICRO INC. NETGEAR, INC. 1600 East St. Andrew Place 4401 Great America Parkway Santa Ana, CA
92705 P.O. Box 58185 Santa Clara, CA 95052-8185

By: /S/ AC Mann By: /s/ PATRICK Lo ---------------- -------------------- Name: AC Mann Name: PATRICK
Lo Title: VP Purchasing Title: V. P.

Netgear, Inc. 1 Confidential Doc Rev 2/97 7/15/98
