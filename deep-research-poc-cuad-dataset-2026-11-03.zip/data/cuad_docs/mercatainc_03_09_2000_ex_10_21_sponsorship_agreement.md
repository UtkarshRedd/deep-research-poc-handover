<!-- page 1 -->
# SPONSORSHIP AGREEMENT
| Field | Value |
|---|---|
| Document Type | Sponsorship Agreement |
| Agreement Date | 1999-07-12 |
| Parties | Football Northwest LLC, ("FNW"); Mercata, Inc., ("Sponsor") |
| Source | CUAD v1 / MERCATAINC_03_09_2000-EX-10.21-SPONSORSHIP AGREEMENT |

EXHIBIT 10.21 SPONSORSHIP AGREEMENT

THIS AGREEMENT, dated for reference purposes as of July 12, 1999 (the "Agreement"), is by and
between FOOTBALL NORTHWEST LLC, a Washington limited liability company ("FNW") and MERCATA, Inc., a
Delaware corporation ("Sponsor").

R E C I T A L S ---------------

A. Pursuant to that certain Consent to Assignment and Amendment of Use Agreement dated January 7,
1997, as amended, between King County, Washington ("King County") and FNW, FNW is granted the
exclusive right to and revenue from all advertising both inside and outside the King County Domed
Stadium (the "Kingdome") and the Kingdome Pavilion, including on adjacent parking lots.

B. The Kingdome is located in Seattle, Washington and currently serves as the home venue for the
National Football League ("NFL") franchise for the Seattle Seahawks.

C. FNW owns and, during the term of this Agreement, FNW or its successor or assign will retain the
exclusive signage and advertising rights for the Kingdome.

D. Sponsor desires to acquire from FNW certain sponsorship rights in the areas described below and
FNW is vested with the authority to grant and desires to grant such rights to Sponsor in accordance
with the terms and provisions of this Agreement.

NOW, THEREFORE, in consideration of the foregoing and for other good and valuable consideration,
receipt of which is hereby acknowledged, the parties hereby agree as follows:

1. Sponsorship Benefits. Sponsor shall during the term of this Agreement --------------------
receive the following sponsorship benefits:

A. Television

1. Three (3) :30 second Sponsor produced commercials ("Concept Ads") to air within each of three (3)
preseason telecasts. 2. Three (3) :30 second Seahawks produced commercials ("Products Ads") to air
within each of three (3) preseason telecasts. Content shall be reviewed and approved by Sponsor.
Shawn Springs will be featured in the commercial. 3. Opening/closing billboards in each of three (3)
Seahawks preseason games including Sponsor logo. 4. Sponsorship of one (1) feature ("Instant
Replay") in three (3) preseason games including billboard and Sponsor logo visual. Total of three
(3) features, billboards and logo identifications. 5. Three (3) Sponsor logo exposures in the Hawk
Box Scoreboards per quarter during three (3) preseason games. 6. Sponsor a minimum of three (3)
"live" power buy announcements ("Live Ads") during the course of three (3) telecasts. Announcement
format to be determined. 7. Production: Seahawks will cover all hard costs to create, direct and
produce one (1) :30 second TV spot to be used in three (3) preseason telecasts. Sponsor

1.

will provide creative direction for the production and shall have the right to use such commercial
where appropriate in its general advertising campaign or within certain promotional material during
the 1999 season. 8. The sequence of TV appearance should always be: . FIRST appearance: Concept Ad
(before last commercial series prior to a break) . SECOND appearance: Products Ad (last commercial
series prior to a break) . THIRD appearance: Live Ad (during the break) One sequence per quarter
from 1st to 3rd quarter.

B. Kingdome Promotion/DiamondVision

1. Two (2) DiamondVision announcements per game for three (3) games. Total of six (6) DiamondVision
announcements. Content will have to be reviewed and approved by Sponsor. 2. Sponsor opportunity to
run :30 second television spot on DiamondVision during pregame warm-ups for three (3) preseason
games. Total of three (3) spots 3. Sponsor (Promotional) road trip for two (2) including airfare,
hotel and game tickets. Must participate in Sponsor/Seahawks Sweepstakes to be eligible for road
trip. Designated road trip: Seattle @ Chicago on September 19, 1999. The value of this package is
less $5,000 and shall be provided by FNW.

C Seahawks.com

1. One (1) rotating banner ad on Seahawks.com for sixty (60) days
<!-- page 2 -->
(August through September 1999) Extension beyond the sixty (60) days to offered to Sponsor at
favorable cpm based rate. 2. Seahawks to promote Sponsor online store from Seahawks.com's front page
by providing a graphic and a text link directing visitors to Mercata.com. Text and graphics to be
provided by Sponsor, and reviewed and approved by Seahawks.com. 3. Sponsor acknowledgement on
Seahawks Television network web page on Seahawks.com 4. Sponsor will feature an online
Seahawks-themed store selling Seahawks merchandising at Mercata.com.

D. VIP Benefits

1. Two (2) season tickets with option to purchase two (2) playoff tickets 2. Twenty (20) tickets to
two (2) preseason home games, August 14 and August 28, 1999. 3. One half-page color ad in Seahawks
Insider for the 1999 season. Deadline for ad July 23, 1999. If Sponsor cannot meet the deadline,
Seahawks will provide similar opportunity to be determined (i.e.: letter to season ticket holders
introducing Mercata). 4. One (1) trip for two (2) to Training Camp. Includes transportation, hotel
and entertainment 5. One "Advertorial" in first pre-season issue of NFL Insider to explain the
Mercata 'story' and groundbreaking partnership with the Seahawks (Mercata to write and provide
advertorial). 6. Mercata's use of Seahawks trademarks for promotional purposes extends throughout
the 1999 season.

2.

2. Term. The term of this Agreement shall commence on July 19, 1999 and shall ---- thereafter
continue until all above described Sponsor benefits are completed, but in no event beyond the end of
the 1999 season (the "Term"). This Agreement is noncancellable by either party except for
termination in accordance with Paragraph 7, below, and may be mutually extended by written agreement
of the parties.

3. Consideration. In consideration of the sponsorship rights and other services ------------- and
products granted and provided to Sponsor by FNW hereunder, Sponsor hereby agrees to pay FNW a
sponsorship fee in the amount of Forty thousand Dollars ($40,000 net) (the "Sponsorship Fee").

3.1. Invoices and Payment. FNW will send Sponsor invoices Sponsorship Fee in --------------------
two (2) monthly installments beginning September 1, 1999. Invoices are payable thirty (30) days
after receipt. A five percent (5%) late fee will be added to all invoices which become past due and
interest at a rate of twelve percent (12%) per annum will be charged on all balances not paid within
thirty (30) days of the date they are due.

4. Sponsor's Content and Design. The content and design of Sponsor's creative
---------------------------- material shall be within the discretion of Sponsor. However, if FNW
objects to any such material when it is provided or thereafter, it shall notify Sponsor as soon as
possible and Sponsor shall take prompt action to address FNW's concerns.

5. Trademarks ----------

5.1. Use of Sponsor's Trademarks. FNW shall not, by this Agreement, obtain
--------------------------- any right, title or interest in the trademarks or other proprietary
property of Sponsor, nor shall this Agreement give FNW the right to use, refer to, or incorporate in
marketing or other materials the name, logos, trademarks, designs, identifications, or copyrights of
Sponsor in any manner except as authorized by Sponsor. Sponsor acknowledges that FNW and parties
conducting events within the Kingdome may televise, videotape, or take still photographs of events
occurring in the Kingdome. Sponsor hereby consents to the commercial exploitation of such television
broadcasts, video tapes and still photographs notwithstanding the fact that the content and design
of Sponsor's images may be visible in such television broadcasts, video tapes and still photographs.

5.2. Use of FNW and Seattle Seahawks Trademarks. Sponsor shall not, by this
------------------------------------------ Agreement, obtain any right, title or interest in the
trade names or trademarks of FNW, the Seattle Seahawks, the NFL, NFL Enterprises, L.P., NFL
Properties, Inc. or any affiliate of such, nor shall any such agreements give Sponsor the right to
use, refer to, or incorporate in marketing or other materials the names, logos, trademarks, designs,
identifications or copyrights of&bbsp;FNW, the Seattle Seahawks, the NFL, NFL Enterprises, L.P., and
NFL Properties, Inc. without the prior written approval of FNW, which approval may be withheld in
FNW's reasonable discretion. Sponsor may use Seahawks trademarks for promotional purposes as
necessary to convey the Sponsor benefits described herein. However, all such rights shall expire at
the end of the 1999 regular season.

6. Indemnification. FNW agrees to defend, indemnify and hold Sponsor harmless --------------- from
and against all claims, suits, liabilities, costs and expenses,
<!-- page 3 -->
including reasonable attorney costs and fees, for injury to, including death of, persons (whether
they be third persons or employees of either of the parties hereto) or any loss of or damage to
property in any manner arising from or relating to the rights

3.

conveyed herein, with the understanding that this obligation shall not apply to, and Sponsor agrees
to defend, indemnify and hold FNW and its officers, directors, employees and agents harmless from
and against, all losses, claims, suits, demands, actions, liabilities, costs and expenses, including
reasonable attorney costs and fees, for injury to, including death of, persons (whether they be
third persons or employees of either of the parties hereto) or any loss of or damage to property in
any manner arising from the content of any advertising copy supplied by Sponsor or the negligence or
intentional misconduct of Sponsor or its officers, employees or agents.

7. Termination. FNW and Sponsor shall each have the right but not the ----------- obligation to
terminate this Agreement upon forty-five (45) days prior written notice, without further liability
except as otherwise provided by this Paragraph 7 if any of the following shall occur:

(a) Damage to or destruction of the Kingdome to the extent that the Kingdome is closed for a period
of greater than thirty (30) days, in which case the refund provisions of this Paragraph 7 shall
apply.

(b) The cancellation or termination of FNW's NFL franchise or the relocation of FNW's NFL franchise
to a location more than 50 miles from Seattle, Washington.

(c) The other party materially defaults in the performance of its material obligations under this
Agreement and such other party fails to correct such breach within thirty (30) days of written
notice.

If this Agreement is so terminated by Sponsor, Sponsor shall be entitled to a pro rata refund of any
payments under this Agreement.

8. Remedies --------

8.1 Generally. In the event that either party fails to fully comply with --------- any of its
obligations under this Agreement, the other party shall be entitled to all remedies set forth in
this Agreement and, except as otherwise provided herein, all remedies otherwise available at law or
in equity.

8.2 Limitation on Damages. In no event shall either party be liable for --------------------- any
special, incidental or consequential damages arising out of or in connection with this Agreement or
the performance thereof. FNW's liability for any breach of this Agreement shall be strictly limited
to refunding to Sponsor that portion of any consideration paid by Sponsor for which Sponsor has not
received the rights granted to it herein.

9. Limitations.&sbsp; This Agreement is subject to the Constitution and Bylaws and ----------- other
rules and regulations of the NFL, the statutes and regulations of the State of Washington, and the
ordinances and rules of King County, Washington and the City of Seattle, Washington as they
presently exist or as they may from time-to-time be amended, including without limitation, any rule
or regulation of the NFL or any agreement to which the NFL is a party which restricts the visibility
of signage within the Kingdome during NFL games which are televised nationally. The obligations of
either party to perform under this Agreement shall be excused if such failure to perform or any
delay is caused by matters such as acts of God, strikes, lockout, work stoppage, picketing, damage
or concerted action by any employee or labor organization, civil commotion, riots, war, acts of
government, or any other cause whether similar or dissimilar to those enumerated which are
reasonably beyond the control of the party obligated to perform. Upon the occurrence of such

4.

event, the duties and obligations of the party shall be suspended for the duration of the event
preventing performance.

10. Entire Agreement. The entire agreement between the parties pertaining to ---------------- the
subject matter of this Agreement is incorporated into this document. This Agreement may not be
modified or amended except by a writing duly executed by the parties hereto. This Agreement
supersedes any and all prior agreements and understandings between the parties.

11. Successor Interests. Neither this Agreement nor any of the rights or -------------------
obligations of either FNW or Sponsor hereunder may be assigned, transferred or conveyed by operation
of law or otherwise by either party, nor shall such agreements or rights inure to the benefit of any
trustee in bankruptcy, receiver, creditor, or trustee of either party's business or its properties
whether by operation of law or otherwise, except with the prior written
<!-- page 4 -->
consent of the other party, which consent shall not be unreasonably withheld, and the delivery of a
written document in which the assignee assumes all of the obligations of the assigning party and the
assigning party acknowledges that it will continue to be bound to such obligations if not performed
by the assignee. For purposes of this Paragraph 11, the transfer of a fifty percent (50%) or greater
ownership interest in a party shall be deemed to be an assignment of this Agreement. Notwithstanding
the foregoing, no assignment or attempted assignment by Sponsor shall be valid except to a party
which intends to continue the business of Sponsor as presently conducted. Sponsor does hereby
consent to any transfer or assignment by FNW of its rights under this Agreement to an affiliate of
FNW without any additional prior consent of Sponsor. Subject to the foregoing, this Agreement shall
be binding upon and shall inure to the benefit of all successors and assigns of the parties.

12. Confidentiality. Each of the parties deems the provisions of this Agreement --------------- to
be confidential and proprietary in nature. FNW and Sponsor each agree that the terms of this
Agreement will be kept confidential and will not be disclosed in any manner whatsoever, in whole or
in part, by either party without the prior written consent of the other party except to the extent
necessary for such party to enforce its rights under this Agreement or as either party may be
advised by its legal counsel that it is obligated to disclose the terms of such agreements.
Moreover, each party agrees to disclose the terms of this Agreement only to its
respective&sbsp;officers, employees, agents and representatives who need to know of such terms and
who agree to be bound by the confidentiality terms of this Paragraph. Each party shall be
responsible for any breach of this Paragraph by its respective officers, employees, agents and
representatives. The terms of this Paragraph shall survive the expiration or termination of this
Agreement for whatever reason for a period of three (3) years after such expiration or termination.
Notwithstanding the foregoing, FNW may disclose the terms of this Agreement to King County,
Washington and to lenders, legal counsel, and financial advisors.

13. Washington Law. This Agreement shall be deemed to have been made in the -------------- state of
Washington and shall be construed in accordance with the laws of the state of Washington. The
exclusive venue for any suits or actions arising out of this Agreement shall be in the Superior
Court for the State of Washington for King County or in the United States District Court for the
Western District of Washington.

14. Notices. All notices under this Agreement shall be in writing and shall be ------- deemed to
have been duly given if personally delivered, sent by telecopier, sent by overnight courier service
or sent by registered or certified mail, postage prepaid, and shall be deemed given upon the earlier
of actual

5.

receipt or one day after it is sent, if sent by overnight courier, or three days after it is sent by
registered or certified mail. All notices or other communications shall be made as follows:

To FNW: 11220 N.E. 53rd Street Kirkland, WA 98033 Attn: Scott Patrick V.P./Corporate Sales

With a Copy to: Richard E. Leigh, Jr. Vice President/General Counsel 110 - 110th Ave. N.E., Suite
550 Bellevue, WA 98004

If to Sponsor. Jerome Pache, Director Business Development Leslie Wallis, General Counsel MERCATA,
Inc. 110 110th Avenue NE Bellevue, WA 98004-5840

15. Arbitration. Any controversy or claim arising out of or relating to this ----------- Agreement,
including, but not limited to a claim based on or arising from an alleged tort will, at the request
of any party be determined by arbitration in accordance with the Federal Arbitration Act (9 U.S.C.
Section 1, et seq.) under the auspices and rules of the American Arbitration Association ("AAA").
The AAA will be instructed by either or both parties to prepare a list of judges who have retired
from the Superior Court of the State of Washington, a higher Washington court or any federal court.
'Within 10 days of receipt of this list, each party may strike one name from the list. The AAA will
then appoint an arbitrator from the name(s) remaining on the list. The arbitration will be conducted
from Seattle, Washington. Any controversy in interpretation or enforcement of this provision or
whether a dispute is arbitrable, will be determined by the arbitrators. Judgment upon the award
rendered by the arbitrator(s) may be entered in any court having jurisdiction. The institution and
maintenance of an action for judicial relief or in pursuit of an ancillary remedy, does not
constitute a waiver of the right of any party, including the plaintiff, to submit the controversy or
claim to arbitration.

16. Attorneys' Fees. In the event any suit or action is brought or an --------------- arbitration or
bankruptcy proceeding is initiated (including, without
<!-- page 5 -->
limitation, appeals of the foregoing) to enforce or interpret any of the provisions of this
Agreement, or which is based thereon, the prevailing party shall be entitled to reasonable attorney
fees in connection therewith. The determination of who is the prevailing party and the amount of
reasonable attorney fees to be paid to the prevailing party shall be decided by the court or courts,
including any appellate court, in which such matter is tried, heard or decided, including the court
which hears any exceptions made to an arbitration award submitted to it for confirmation as a
judgment (with respect to attorneys' fees incurred in such confirmation proceedings), or by the
arbitrator(s) (with respect to attorneys' fees incurred prior to and during the arbitration
proceedings), as the case may be.

17. Relationship of Parties. The parties are acting herein as independent -----------------------
contractors and independent employers. Nothing herein contained shall create or be construed as
creating a partnership, joint venture or agency relationship between the parties and no party shall
have the authority to bind the other in any respect.

6.

18. Agreement Approval. Each party hereby represents and warrants that all ------------------
necessary approvals for this Agreement have been obtained, and the person whose signature appears
below has the authority necessary to execute this Agreement on behalf of the parties indicated.

19. Captions. Paragraph headings herein are for convenience only and shall not -------- affect the
construction or meaning of this Agreement.

7.

IN WITNESS WHEREOF, the parties hereto have executed this Agreement as of the date first above
written:

FOOTBALL NORTHWEST LLC MERCATA, INC.

By: /s/ Scott S. Patrick By: /s/ Tom Van Horn ----------------------------
----------------------------

Name: Scott S. Patrick Name: Tom Van Horn -------------------------- --------------------------
(printed or typed) (printed or typed)

Title: VP/Corporate Sales Title: President & CEO ------------------------- -------------------------

8.
