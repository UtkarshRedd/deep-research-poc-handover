<!-- page 1 -->
# ENDORSEMENT AGREEMENT
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| SEC Filing Date | 1997-09-29 |
| Parties | SPORT-HALEY, INC. ("Company"); __________ ("Professional") |
| Source | CUAD v1 / SPORTHALEYINC_09_29_1997-EX-10.2-10-ENDORSEMENT AGREEMENT |

ENDORSEMENT AGREEMENT

THIS ENDORSEMENT AGREEMENT is made and entered into effective this day of ___________________, 19__,
by and between SPORT-HALEY, INC., a Colorado corporation (the "Company"), and _________________
(hereinafter referred to as the "Professional").

WHEREAS, the Professional is an active, exempt and full-time touring professional on the
Professional Golfer's Association Tour (the "PGA Tour"); and/or (the "Senior PGA Tour") and

WHEREAS, the company is in the business of designing and marketing quality men's and women's golf
and active sportswear under the Haley label and desires to obtain the services of the Professional
in endorsing, promoting and publicizing the Company and Haley apparel;

NOW, THEREFORE, in consideration of the agreements of the parties set forth below, and in
consideration of the Company's agreement to make the payments below described to the Professional
the parties hereto agree as follows:

1. SERVICES OF THE PROFESSIONAL. The Professional agrees to perform the following services during
the term of this Agreement:

a. The Professional agrees that, with respect to men's apparel, he will exclusively endorse and use
exclusively in play, practice, exhibits, clinics and other events open to the media or public, Haley
brand apparel which shall consist of shirts, vests, jackets, sweaters, pants and shorts (if
permitted by applicable rules).

b. The Professional grants to the Company the exclusive worldwide right and license to use his name,
autograph, likeness, photographs, electronic media depiction, signature and any other words, symbols
or depiction's which would identify the Professional to the public in connection with the
advertising, promotion, publicizing, sale and distribution of Haley apparel by the Company.

c. Upon reasonable written request of the Company which shall be tendered at least 30 days prior the
date requested, the Professional shall make himself available for the purpose of posing for print
ads, making commercials and other promotional materials, or attending promotional events organized
by the Company once per calendar year. In the event of such requests by the Company, the company
shall be responsible for the payment of all reasonable travel, lodging and meal expenses incurred in
connection with the Professional rendering services described in this subsection. Should the
services of the Professional be required for longer than one day, the Professional shall be entitled
to his daily appearance fee, plus reasonable expenses, for each day in excess of one day.

d. The Professional shall have the opportunity to select from the Company's semi-annual golf
sportswear collections for the purposes of obtaining a wardrobe of Haley apparel suitable to the
Professional at the Company's expense. The Company shall have the right to place on the left chest
and right sleeve of any jackets, shirts, vests, or sweaters and above the back pocket of any pants
selected by the Professional the Company's logo and name in use by the Company at that time.

2. RIGHTS OF USAGE. As described in Section 1(b) above, the Professional has granted the company an
exclusive worldwide right and license to use his name, autograph, likeness, photographs, electronic
media depiction, signature and any other words, symbols or depiction's (hereinafter the
"Professional's Image") which will identify the Professional to the public in connection with the
advertising, promotion, publicizing, sale and distribution of Haley apparel. The Company shall have
unlimited rights of utilization of the Professional's Image in all advertising, promotion, publicity
and other forms of communication with any part during the term of this Agreement, it being the
intent of the Professional that the Company's utilization of the Professional's Image shall be at
the discretion of the Company. The right of usage described herein shall be subject to the
requirement that the Company shall not place the Professional's Image in an unfavorable light. The
Professional or the Professional's designated agent shall have the right to review any advertising,
promotion or publicity materials utilized by the company which contain the Professional's Image on
reasonable written or oral request to the Company during the term of this Agreement.

3. COMPENSATION OF THE PROFESSIONAL. In consideration of the rights granted to the Company and the
services to be provided by the Professional, the Professional shall receive the following
compensation:

4. PAYMENTS. All payments to be made to the Professional pursuant to the terms of this Agreement
shall be made to the Professional and delivered to
________________________________________________________
_____________________________________________________________________

_____________________________________________________________________
<!-- page 2 -->
or at such other address as shall be designated in writing by Professional.

5. RETENTION OF ENDORSEMENT RIGHTS. Except with respect to endorsement rights granted to the Company
for the apparel described herein, the Professional shall retain all rights in and to the
professional's name and endorsement and the Professional shall not be prevented from using,
permitting or licensing others to use the Professional name or endorsement in connection with the
advertising, promotion or sale of any product other than golf apparel as described in Section 1
hereof. The Professional represents and warrants that no agreement, contract or understanding exists
which would prevent or limit the performance of any of his obligations under this Agreement.

6. TERM. The term of this Agreement shall extend from the date of execution hereof through and until
_______, unless extended by written agreement of the parties. The parties shall use their best
efforts to reach agreement on the terms of any such extension. In the event the Professional should
for any reason become a non-exempt PGA Tour player, the Company shall have the right to terminate
this Agreement at its discretion at any time during the initial term or any extension thereof.
Additionally, if either part shall fail to observe or perform any of the agreements or obligations
undertaken by such party hereunder, and such failure or default shall continue for a period of 30
days following notice from the non-defaulting party to the defaulting party during which such
failure or default shall not have been cured by the defaulting party, then the non-defaulting party
shall have the right to terminate this Agreement following the expiration of such 30-day notice
period. The non-defaulting part hereunder. Following the expiration of 90 days from the termination
or expiration of this Agreement, the Company shall cease usage of all publicity, promotion and
advertising materials which contain the Professional's Image, it being the understanding of the
parties that during such 90-day period the Company shall have the right to use such remaining
publicity, promotion or advertising materials as shall then be available to the Company.

7. NOTICE. All notices and communications required or permitted to be given hereunder shall be in
writing, signed by the sender, and delivered by registered or certified mail to:

If to the Company: Robert G. Tomlinson, Chairman and CEO Sport-Haley, Inc. 4600 East 48th Avenue
Denver, CO 80216

With a copy to: Robert W. Walter, Esq. Berliner Zisser Walter & Gallegos, P. C. Suite 4700 1700
Lincoln Street Denver, CO 80203

If to the Professional:

With a copy to:

or such other address as shall have been furnished in writing by the parties to each other.

8. ENTIRE AND SOLE AGREEMENT. This Agreement constitutes the entire agreement between the parties
and supersedes all statements, promises and understandings, whether oral or written, with respect to
subject matter hereof.

9. SUCCESSORS AND ASSIGNS. This Agreement may not be assigned by the Professional under any
circumstances. The Company shall not be entitled to assign this Agreement to any other party without
the Professional's express prior written consent, except any assignment by the Company as a result
of a stock exchange, merger, consolidation, or sale of substantially all of the assets of the
Company, in which case not such consent shall be required.

10. SEVERABILITY. Should any one or more of the provisions of this Agreement be determined to be
illegal or unenforceable, all other provisions of this Agreement shall be given effect separately
from the provision or provisions determined to be illegal or unenforceable.

11. GOVERNING LAW. This Agreement shall be construed and enforced in accordance with, and governed
by the laws of the State of Colorado without regard to conflicts of laws principles.

12. COUNTERPARTS. This Agreement may be executed simultaneously in two or more counterparts, each of
which shall be an original, but all of which together shall constitute one and the same Agreement.
Facsimile signatures shall be accepted by the parties hereto as original signatures for all
purposes.

13. HEADINGS. The headings in this Agreement are for purposes of convenience and easy reference only
and shall not limit or otherwise
<!-- page 3 -->
affect the meaning hereof.

14. DISPUTES. In the event of any dispute which arises between the parties and which relates to the
subject matter of this Agreement, the parties acknowledge and agree that any such dispute shall be
submitted for binding arbitration in accordance with the arbitration procedures established by the
American arbitration Association in Denver, Colorado. If such association is not then in existence,
an independent association of arbitrators may be utilized which is designated by agreement of the
parties. In the event the parties are unable to agree on an independent association of arbitrators,
either party may apply to a court of competent jurisdiction for appointment of arbitrators.

IN WITNESS WHEREOF, the Company and the Professional have executed this Endorsement Agreement as of
the day and year first above written.

PROFESSIONAL:

----------------------------------------

COMPANY:

SPORT-HALEY, INC.

By: -------------------------------------
