<!-- page 1 -->
# Endorsement Agreement
| Field | Value |
|---|---|
| Document Type | Endorsement Agreement |
| Agreement Date | 1995-08-24 |
| Parties | Kathy Ireland, Inc. ("KI Inc."); Kathy Ireland ("KI"); The Sterling/Winters Co. ("SW"); Diplomat Ambassador Eyewear Group ("Diplomat") |
| Source | CUAD v1 / AMBASSADOREYEWEARGROUPINC_11_17_1997-EX-10.28-ENDORSEMENT AGREEMENT |

Exhibit 10.28

ENDORSEMENT AGREEMENT

This Endorsement Agreement ("Agreement") is made and entered into as of August 24, 1995, by and
among the following parties:

(a) Kathy Ireland, Inc. ("KI Inc."), furnishing the services of Kathy Ireland ("KI"), c/o The
Sterling/Winters Co., 1900 Avenue of the Stars, Suite #1640, Los Angeles, California 90067;

(b) The Sterling/Winters Co. ("SW"), 1900 Avenue of the Stars, Suite #1640, Los Angeles, California
90067; and

(c) Diplomat Ambassador Eyewear Group ("Diplomat"), 1010 Arch Street, 3rd Floor, Philadelphia,
Pennsylvania 19107.

1. Recitals.

(a) Whereas Diplomat has created a new product line to be known as "Kathy Ireland Eyewear" ("KI
Eyewear");

(b) Whereas Diplomat estimates on a non-binding basis that wholesale sales of KI Eyewear will reach
$ during the first License Year, $ during the 2nd License Year, $ during the 3rd License Year, and $
during the 4th License Year (as those License Years are defined in subparagraph 3.(b) of this
Agreement);

(c) Whereas Diplomat desires to obtain the right to use the name, likeness and endorsement of KI in
connection with the advertisement, promotion and sale of KI Eyewear; and

(d) Whereas KI, Inc. has the authority to grant the right to use KI's name, likeness and endorsement
to Diplomat in connection with the advertisement, promotion and sale of KI Eyewear and desires to do
so;

(e) NOW THEREFORE, for and in consideration of the mutual promises and conditions contained in this
Agreement, the parties hereby agree as follows.

2. Grant of License.

(a) Products. Upon the terms and conditions set forth in this Agreement, KI, Inc. hereby grants to
Diplomat and Diplomat hereby accepts the right, license and privilege of utilizing KI's name and
likeness solely upon and in connection with the manufacture, sale and distribution of the following
products:

(1) sunglasses, eyeglasses, readers and ophthalmic frames;

1

(2) optical cases, optical eye chains, eye pins, and lens cleaning kits sold only in optical
retailers; and

(3) such other optical accessories as the parties shall agree.

(b) Territory. The license hereby granted extends worldwide.

(c) Term. The term of the license hereby granted shall commence August 1, 1995 and continue until
January 30, 2000, unless sooner terminated in the manner provided in the immediately succeeding
sentence or as otherwise provided in this Agreement. Notwithstanding the foregoing, if the
management of Kmart stores elects not to carry KI eyewear prior to the end of the first license year
(January 30, 1997), then either party shall have the right to terminate this Agreement as of such
date.

3. Terms of Payment.

(a) Rate. Diplomat agrees to pay KI, Inc. as royalty a sum equal to % of the net wholesale volume of
the products covered by this Agreement by Diplomat and its affiliated, associated, or subsidiary
companies. The term "net wholesale volume" shall mean gross sales to all customers; less returns,
trade discounts and cash discounts; but no deduction shall be made for other discounts or
uncollectible accounts. No costs incurred in the manufacture, sale, distribution, or exploitation of
the products covered by this Agreement shall be deducted from any royalty payable by Diplomat.

(b) Minimum Royalties. Diplomat agrees to pay KI, Inc. the minimum royalties set forth below as a
minimum guarantee against royalties to be paid to KI, Inc. under subparagraph 3.(a), above:

(1) 1st License Year (8/1/95 - 1/30/97): $ (2) 2nd License Year (2/1/97 - 1/30/98): $ (3) 3rd
License Year (2/1/98 - 1/30/99): $ (4) 4th License Year (2/1/99 - 1/30/2000): $
<!-- page 2 -->
The minimum royalty for the 1st License Year shall be paid as follows: $ upon the signing of the
Deal Memo dated August 24, 1995, the balance of $ to be paid in six (6) equal, consecutive, monthly
installments of $ commencing with the month in which this Agreement is signed. No part of the
minimum royalty for the first License Year shall in any event be repayable to Diplomat. The minimum
royalty for the 2nd, 3rd and 4th License Years shall be made in four equal installments payable on
February 1st, May 1st, August 1st and November 1st of each such License Year. Notwithstanding the
foregoing, if royalties paid by Diplomat to KI, Inc. on net

2

wholesale volume for any particular License Year under subparagraph 3(a) of this Agreement should
exceed the minimum royalties remaining to be paid for that same License Year under this subparagraph
3(b), then no further payments of minimum royalties for such License Year shall be required under
this subparagraph 3(b).

(c) Periodic Statements. Within thirty (30) days after the initial shipment of the products covered
by this Agreement, and promptly on the 15th of each calendar month thereafter, Diplomat shall
furnish to KI, Inc. complete and accurate statements certified to be accurate by Diplomat showing
the number, description and gross sales price, itemized deductions from gross sales price, and net
sales price of the products covered by this Agreement distributed and/or sold by Diplomat during the
preceding calendar month, together with any returns made during the preceding calendar month. Such
statements shall be furnished to KI, Inc. whether or not any of the products have been sold during
the preceding calendar month.

(d) Royalty Payments. Royalties in excess of the minimum royalty shall be due on the 25th day of the
month following the calendar month in which they are earned, and payment shall accompany the
statements furnished pursuant to subparagraph (c), above. The receipt or acceptance by KI, Inc. of
any of the statements furnished pursuant to this Agreement, or of any royalties paid hereunder, or
the cashing of any royalty checks paid hereunder, shall not preclude KI, Inc. from questioning the
correctness of such statements or payments, provided all such questions are raised with Diplomat
within two years of the date of KI Inc's receipt of the statement or payment in question. In the
event any inconsistencies or mistakes are discovered in such statements or payments, they shall
immediately be rectified and the appropriate payments made by Diplomat.

4. Exclusivity.

The license hereby granted shall be exclusive as to the products described in subparagraphs 2.(a)(1)
and (2) of this Agreement, but nonexclusive as to all other products covered by this Agreement.
Nothing in this Agreement shall be construed to prevent KI, Inc. from granting any other licenses
for the use of KI's name or likeness, or from utilizing KI's name and likeness in any manner
whatsoever, except that KI, Inc. agrees that except as provided herein it will grant no other
licenses for the territory to which this license extends for the use of KI's name and likeness in
connection with the sale of the products described in subparagraphs 2.(a)(1) and (2) of this
Agreement effective during the term of this Agreement.

5. Personal Endorsement and Appearances.

(a) Endorsement. KI, Inc. agrees that KI shall endorse KI Eyewear and that KI will use her best
efforts to wear KI Eyewear whenever reasonably possible and appropriate, with KI to have sole,
unfettered discretion as to where and when to wear KI Eyewear.

3

(b) USA Appearance. KI will make one (1) personal appearance per License Year during the period of
this Agreement on behalf of Diplomat at the Vision Expo in New York, New York, subject to the terms
of this paragraph. Such appearance shall be for the purpose of signing autographs, shall last for a
period of up to three (3) hours, and shall be subject to KI's schedule and availability. Diplomat,
at its own expense, shall provide KI with a hair and make-up assistant of KI's choosing for each
personal or media appearance required under this Agreement.

(c) Travel. Travel expenses of KI in connection with all scheduled personal appearances under this
Agreement, as well the travel expenses of KI's child, the child's nanny, KI's hair and make-up
assistant of KI's choosing, and two (2) additional traveling companions of KI's choosing
(collectively referred to as KI's "entourage"), shall be provided by Diplomat. KI and the members of
her entourage shall travel via first class air and portal-to-portal limousine ground transportation.
In addition, KI and the members of her entourage shall be lodged in first class hotel accommodations
and all of them shall be reimbursed for all meals and other incidental expenses in connection with
such appearances. All the above travel expenses of KI and the members of her entourage shall be
billed directly to Diplomat. For purposes of this paragraph (c), the term "travel expenses" shall
include

(d) Photo Sessions. KI will participate in up to two (2) photo sessions per License Year during the
period of this Agreement on behalf of Diplomat at a mutually acceptable time and place. The photo
sessions shall be scheduled at KI's convenience upon not less than two (2) weeks prior notice, and
shall be subject to KI's preexisting personal and professional commitments. The photo sessions shall
be up to two (2) consecutive days in duration, each day to consist of no more than eight (8) working
hours. The photo shoots shall be
<!-- page 3 -->
produced by SW, approved in writing by Diplomat (which approval shall not be unreasonably withheld),
and all images produced from the photo sessions shall be the property of SW. The parties agree that
all images from the photo sessions shall be retouched at the expense of Diplomat. In recognition of
SW's expenses in connection with the above photo sessions, Diplomat shall pay SW the sum of $ per
day for each day (or partial day) of such photo sessions. It is understood by the parties that such
sum shall include all expenses required to provide Diplomat with positive film (excluding travel
expenses of KI, as set forth in this Agreement), and that such sum contemplates a typical location
for such photo sessions. If a more elaborate set-up for such photo sessions is required, and such
set-up is mutually agreed to by the parties, then the above sum shall be increased to such amount as
the parties shall agree. The above sum shall not include retouching images.

(e) Videotapes. KI will participate in the production of up to one (1) product information/sales
video per License Year during the period of this Agreement on behalf of Diplomat at a mutually
acceptable time and place. The video production sessions shall be scheduled at KI's convenience upon
not less than two (2) weeks prior notice, and shall be subject to KI's preexisting personal and
professional commitments. The video production sessions shall be up to two (2) consecutive days

4

in duration, each day to consist of no more than eight (8) working hours. The video production
sessions shall be produced by SW, approved in writing by Diplomat (which approval shall not be
unreasonably withheld), and all images produced from the video production sessions shall be the
property of SW. In recognition of SW's expenses in connection with such video production sessions,
Diplomat shall pay SW a sum per day for each day (or partial day) of such sessions, such sum to be
agreed upon by the parties. It is understood by the parties that such sum shall include all expenses
required to provide Diplomat with an acceptable video (excluding travel expenses of KI, as set forth
in this Agreement).

(f) Scope of License. The license granted to Diplomat in subparagraph 2(a) of this Agreement shall
include the right to use the photos and videotapes referred to in subparagraphs 5(d) and 5(e) of
this Agreement in connection with the marketing, distribution and sale of the products described in
subparagraph 2(a) of this Agreement, subject to the prior approval of KI, Inc.

6. Good Will, Etc.

Diplomat recognizes the great value of the good will associated with KI's name and acknowledges that
(a) KI's name, and all rights and good will pertaining to KI's name, belong exclusively to KI, Inc.
and (b) that KI's name has a secondary meaning in the mind of the public.

7. KI, Inc.'s Title and Protection of KI. Inc.'s Rights.

(a) Diplomat agrees that it will not at any time during the term of this Agreement or thereafter
attack (i) KI, Inc.'s title to, or rights in and to, KI's name or (ii) the validity of this license.
KI, Inc. hereby indemnifies Diplomat and undertakes to hold it harmless against only those claims or
suits (i) arising solely out of the authorized use of KI's name by Diplomat in accordance with this
Agreement and (ii) brought by those persons or entities to whom KI, Inc. has licensed the use of
KI's name and likeness. Prompt notice shall be given by Diplomat to KI, Inc. of any such claim or
suit. In addition, KI, Inc. shall have the option to undertake and conduct the defense of any suit
so brought and no settlement of any such claim or suit shall be made without the prior written
consent of KI, Inc.

(b) Diplomat shall notify KI, Inc. in writing of any infringements or imitations by others of KI's
name on products similar to those covered by this Agreement that may come to Diplomat's attention,
and KI, Inc. shall have the sole right to determine whether or not any action shall be taken in
connection with such infringements or imitations. Diplomat shall not institute any suit or take any
action in connection with any such infringements or imitations without first obtaining the written
consent of KI, Inc.

5

8. Indemnification by Licensee and Product Liability Insurance.

Diplomat hereby indemnifies KI, Inc. and KI, undertakes to defend KI, Inc. and KI against, and hold
KI, Inc. and KI harmless from, any claims, suits, loss and damage (including attorneys' fees and
costs) arising out of (a) any allegedly unauthorized use of any patent, process, idea, method, or
device by Diplomat in connection with the products covered by this Agreement, (b) any alleged
defects in the products covered by this Agreement, and (c) any other alleged action by Diplomat.
Diplomat agrees that it will obtain, at its own expense, product liability insurance from a
recognized insurance company which is qualified to do business in the State of California providing
adequate protection (at least in the amount of $ ) for KI, Inc., KI and Diplomat against any claims,
suits, loss or damage arising out of any alleged defects in the products. As proof of such
insurance, a fully paid certificate of insurance naming KI, Inc. and KI as an insured party will be
submitted to KI, Inc. by Diplomat for KI, Inc.'s prior approval before any product is distributed or
sold, and at the latest within thirty (30) days after the date first written above. Any proposed
change in certificates of insurance shall be submitted to KI, Inc. for its prior approval. KI, Inc.
shall be entitled to a copy of the
<!-- page 4 -->
then prevailing certificate of insurance, which shall be furnished KI, Inc. by Diplomat. As used in
the first 2 sentences of this paragraph 6, "KI, Inc." shall also include the officers, directors,
agents, and employees of the KI, Inc., or any of its subsidiaries or affiliates.

9. Quality of Merchandise.

Diplomat agrees that the products covered by this Agreement shall be of such style, appearance and
quality as to be adequate and suited to their exploitation to the best advantage, protection and
enhancement of KI's name and the good will pertaining to such name. Diplomat further agrees that (a)
such products will be manufactured, sold and distributed in accordance with all applicable Federal,
State and local laws, (b) that the policy of sale, distribution, and/or exploitation by Diplomat
shall be to the best advantage of KI, Inc. and KI, and (c) that the latter policy shall in no manner
reflect adversely upon the good name of KI and KI, Inc. To this end, Diplomat shall, before selling
or distributing any of the products, furnish to KI, Inc. for its approval, free of cost, a
reasonable number of samples of each product and the cartons, containers, packing and wrapping
material for such products. The quality and style of such products, as well as of any carton,
container or packing or wrapping material, shall be subject to the approval of KI, Inc., which shall
not be unreasonably withheld or delayed. Failure to reject any product, carton, container, or
packing or wrapping within 15 days of receipt of such item or items by KI, Inc. shall be deemed an
acceptance of the quality and style of such item or items. After samples have been approved pursuant
to this paragraph, Diplomat shall not depart therefrom in any material respect without KI, Inc.'s
prior written consent. From time to time after Diplomat has commenced selling the products, and upon
KI, Inc.'s written request, Diplomat shall furnish without cost to KI, Inc. not more than ten (10)
additional random samples of each product being manufactured and sold by Diplomat under this
Agreement, together with any containers and packing and wrapping material used in connection with
such products.

6

10. Labeling.

(a) Diplomat agrees that it will cause to appear on or within each product sold by it under this
license and on or within all advertising, promotional, or display material bearing KI's name (i) the
notice "Copyright (c) (year) ______" and any other notice desired by KI, Inc and (ii) where such
product, advertising, promotional, or display material bears a trademark or service mark,
appropriate statutory notice of registration or application for registration thereof. In the event
that any product is marketed in a carton, container, packing or wrapping material bearing KI's name,
such notice shall also appear upon the said carton, container, packing or wrapping material. Each
and every tag, label, imprint, or other device containing any such notice and all advertising,
promotional or display material bearing KI's name shall be submitted by Diplomat to KI, Inc. for its
written approval prior to use by Diplomat. Approval by KI, Inc. shall not constitute waiver of KI,
Inc.'s rights or Diplomat's duties under any provision of this Agreement.

(b) Diplomat agrees to cooperate fully and in good faith with KI, Inc., at the expense of KI, Inc.,
for the purpose of securing and preserving KI, Inc.'s (or any grantor of KI, Inc.'s) rights in and
to KI's name. It is agreed that nothing contained in this Agreement shall be construed as an
assignment or grant to Diplomat of any right, title or interest in or to KI's name, it being
understood that all rights relating thereto are reserved by KI, Inc., except for the license
hereunder to Diplomat of the right to use and utilize KI's name only as specifically and expressly
provided in this Agreement. Diplomat hereby agrees that at the termination or expiration of this
Agreement Diplomat will be deemed to have assigned, transferred and conveyed to KI, Inc. any trade
rights, equities, good will, titles or other rights in and to KI's name which may have been obtained
by Diplomat or which may have vested in Diplomat in pursuance of any endeavors covered by this
Agreement, and that Diplomat will execute any instruments requested by KI, Inc. to accomplish or
confirm the foregoing. Any such assignment, transfer, or conveyance shall be without consideration
other than the mutual covenants and considerations of this Agreement.

(c) Diplomat hereby agrees that its every use of KI's name shall inure to the benefit of KI, Inc.
and that Diplomat shall not at any time acquire any rights in KI's name by virtue of any use it may
make of such name.

11. Promotional Material.

(a) In all cases where Diplomat desires artwork to be created involving products that are the
subject of this license, the cost of such artwork and the time for the production thereof shall be
borne by Diplomat. All artwork and designs involving KI's name, or any reproduction thereof, shall,
notwithstanding their invention or use by Diplomat, be and remain the

7

property of SW, and SW shall be entitled to use the same and to license the use of the same by
others.

(b) KI, Inc. shall have the right, but shall not be under any
<!-- page 5 -->
obligation, to use KI's name and/or the name of Diplomat so as to give KI's name, KI, Inc., or KI,
Inc.'s programs full and favorable prominence and publicity. KI, Inc. shall not be under any
obligation whatsoever to use KI's name, or any person, character, symbol, design, likeness, or
visual representation thereof in any radio or television program.

(c) Diplomat agrees not to offer for sale, advertise, or publicize any of the products licensed
hereunder on radio or television without the prior written approval of KI, Inc., which approval KI,
Inc. may grant or withhold in its unfettered discretion.

12. Distribution.

(a) Diplomat agrees that during the term of this license it will diligently and continuously
manufacture, distribute and sell the products covered by this Agreement and that it will make and
maintain adequate arrangements for the distribution of the products.

(b) Diplomat agrees that it will sell and distribute the products covered by this Agreement (i) to
jobbers, wholesalers and distributors for sale and distribution to retail stores and merchants, and
(ii) to retail stores and merchants for sale and distribution direct to the public. Diplomat shall
not, without the prior written consent of KI, Inc., sell or distribute such products to jobbers,
wholesalers, distributors, retail stores, or merchants whose sales or distribution are or will be
made for publicity or promotional tie-in purposes, combination sales, premiums, give-aways, or
similar methods of merchandising. In the event any sale is made at a special price to any of
Diplomat's subsidiaries or to any other person, firm or corporation related in any manner to
Diplomat or its officers, directors or major stockholders, there shall be a royalty paid on such
sales based upon the price generally charged the trade by Diplomat.

(c) Diplomat agrees to sell to KI, Inc. such quantities of the products at as low a rate and on as
good terms as Diplomat sells similar quantities of the products to the general trade.

13. Records.

Diplomat agrees to keep accurate books of account and records covering all transactions relating to
the license hereby granted. KI, Inc. and its duly-authorized representatives shall have the right,
upon reasonable notice and at reasonable hours of the day, to visit the offices of Diplomat one time
each calendar quarter for the purpose of examining said books of account and records, and all other
documents and materials in the possession or under the control of Diplomat, with respect to the

8

subject matter and terms of this Agreement, and shall have free and full access thereto for said
purposes and for the purpose of making extracts therefrom. Upon demand of KI, Inc., Diplomat shall
furnish to KI, Inc. a detailed statement by an independent certified public accountant showing the
number, description, gross sales price, itemized deductions from gross sales price and net sales
price of the products covered by this Agreement distributed and/or sold by Diplomat to the date of
KI, Inc.'s demand. The cost of preparing such statement shall be borne by KI, Inc. However,
notwithstanding the foregoing, if the prepared statement indicates that KI, Inc., received less than
all royalties payable to it under this Agreement, and the differential between the royalties
received and those payable amounts to more than % of the royalties received, then the cost of such
statement shall be borne by Diplomat. In the event books of account and records shall be kept
available for at least two (2) years after the termination of this license.

14. Bankruptcy, Violation, Etc.

(a) If Diplomat shall not have commenced in good faith to manufacture or distribute in commercial
quantities sunglasses and ophthalmic frames using KI's name within three months after the date of
this Agreement, or if at any time thereafter in any six calendar month period Diplomat fails to sell
or distribute sunglasses or ophthalmic frames, or any other product described in subparagraph 2(a)
of this Agreement, KI Inc. may give notice of such failure with respect to any such product which
has not been so manufactured or distributed during the six calendar month period. In the event that
Diplomat does not commence selling such product in commercial quantities within 90 days after such
notice, such notice shall be deemed to be a termination of this License with respect to such
product.

(b) If Diplomat files a petition in bankruptcy, or is adjudicated a bankrupt, or if a petition in
bankruptcy is filed against Diplomat, or if it becomes insolvent, or it makes an assignment for the
benefit of its creditors or an arrangement pursuant to any bankruptcy law, or if Diplomat
discontinues its business, or if a receiver is appointed for it or its business, the license hereby
granted shall automatically terminate forthwith without any notice whatsoever being necessary. In
the event this license is so terminated, Diplomat, its receivers, representatives, trustees, agents,
administrators, successors and/or assigns shall have no right to sell, exploit or in any way deal
with or in any of the products covered by this Agreement, or any carton, container, packing or
wrapping material, advertising, promotional or display material pertaining thereto, except with and
under the special consent and instructions of KI, Inc. in writing, which they shall be obligated to
follow.
<!-- page 6 -->
(c) If Diplomat shall violate any of its other material obligations under the terms of this
Agreement, KI, Inc. shall have the right to terminate the license hereby granted upon twenty (20)
days' notice in writing, and such notice of termination shall become effective unless Diplomat shall

9

completely remedy the violation within the twenty-day period and satisfy KI, Inc. that such
violation has been remedied.

(d) Termination of the license under the provisions of this paragraph 14 shall be without prejudice
to any rights which KI, Inc. may otherwise have against Diplomat. Upon the termination of this
license, notwithstanding anything to the contrary herein, all royalties on sales theretofore made
shall become immediately due and payable and no minimum royalties shall be repayable.

15. Final Statement Upon Termination or Expiration.

Sixty (60) days before the expiration of this license and, in the event of its termination, ten (10)
days after receipt of notice of termination or the happening of the event which terminates this
Agreement where no notice is required, a statement showing the number and description of products
covered by this Agreement on hand or in process shall be furnished by Diplomat to KI, Inc. KI, Inc.
shall have the right to take a physical inventory to ascertain or verify such inventory and
statement and refusal by Diplomat to submit to such physical inventory by KI, Inc. shall forfeit
Diplomat's right to dispose of such inventory, KI, Inc. retaining all other legal and equitable
rights KI, Inc. may have under the circumstances.

16. Disposal of Stock Upon Termination or Expiration.

Upon and after the termination of the license, and except as otherwise provided in this Agreement,
Diplomat may dispose of products covered by this Agreement which are on hand, or in process at the
time notice of termination is received, for a period of one hundred and twenty (120) days after
notice of termination, provided advances and royalties with respect to that period are paid and
statements are furnished for that period in accordance with paragraph 3. Notwithstanding anything to
the contrary herein, Diplomat shall not manufacture, sell or dispose of any products covered by this
license after (a) the expiration of the license, or (b) the termination of the license based on (i)
the failure of Diplomat to affix notice of copyright, trademark or service mark registration or any
other notice to the products, cartons, containers, or packing or wrapping material or advertising,
promotional or display material, or (ii) because of the departure by Diplomat from the quality and
style approved by KI, Inc. pursuant to paragraph 9.

17. Effect of Termination or Expiration.

Upon and after the expiration or termination of this license, all rights granted to Diplomat
hereunder shall forthwith revert to KI, Inc., who shall be free to license others to use KI's name
in connection with the manufacture, sale and distribution of the products covered hereby, and
Diplomat will refrain from further use of KI's name or any further reference to it, direct or
indirect, or anything deemed by KI, Inc. to be similar to the KI's name, in connection with the
manufacture, sale or distribution of Diplomat's products, except as provided in paragraph 17.

10

18. KI, Inc.'s Remedies.

(a) Diplomat acknowledges that (except as otherwise provided herein) its failure to commence in good
faith to manufacture and distribute in commercial quantities any one or more of the products listed
in subparagraph 2(a) within three (3) months of the date of this Agreement and to continue during
the term hereof to diligently and continuously manufacture, distribute and sell the products covered
by this Agreement, or any class or category thereof, will result in immediate damages to KI, Inc.

(b) Diplomat also acknowledges that (except as otherwise provided herein) its failure to cease the
manufacture, sale or distribution of the products covered by this Agreement, or any class or
category thereof, at the termination or expiration of this Agreement will result in immediate and
irremediable damage to KI, Inc. and to the rights of any subsequent licensee. Diplomat acknowledges
and admits that there is no adequate remedy at law for such failure to cease manufacture, sale or
distribution, and Diplomat agrees that in the event of such failure KI, Inc. shall be entitled to
equitable relief by way of temporary and permanent injunctions and such other further relief as any
court with jurisdiction may deem just and proper.

(c) Resort to any remedies herein shall not be construed as a waiver of any other rights and
remedies to which KI, Inc. is entitled under this Agreement or otherwise.

19. Excuse for Nonperformance.

Diplomat shall be released from its obligations hereunder and this license shall terminate in the
event that governmental regulations or other
<!-- page 7 -->
causes arising out of a state of national emergency, war, or causes beyond the control of the
parties render performance impossible and one party so informs the other in writing of such causes
and its desire to be so released. In such events, all royalties on sales theretofore made shall
become immediately due and payable and no minimum royalties shall be repayable.

20. No Joint Venture.

Nothing herein contained shall be construed to place the parties in the relationship of partners or
joint venturers, and Diplomat shall have no power to obligate or bind KI, Inc. in any manner
whatsoever.

21. No Assignment or Sublicense by Diplomat.

This Agreement and all rights and duties hereunder are personal to Diplomat and shall not, without
the written consent of KI, Inc., be assigned, mortgaged, sublicensed or otherwise encumbered by
Diplomat or by operation of law.

11

KI, Inc. may assign its rights hereunder, but shall furnish written notice of such assignment to
Diplomat.

22. No Waiver, Etc.

None of the terms of this Agreement can be waived or modified except by an express Agreement in
writing signed by both parties. There are no representations, promises, warranties, covenants or
undertakings other than those contained in this Agreement, which represents the entire understanding
of the parties. The failure of either party hereto to enforce, or the delay by either party in
enforcing, any of its rights under this Agreement shall not be deemed a continuing waiver or a
modification thereof and either party may, within the time provided by applicable law, commence
appropriate legal proceedings to enforce any or all of such rights. No person, firm, group or
corporation (whether included in KI's name or otherwise) other than Diplomat and KI, Inc. shall be
deemed to have acquired any rights by reason of anything contained in this Agreement, except as
provided in paragraphs 8 and 22.

23. Additional Endorsers. If, during the term of this Agreement, Diplomat should utilize the
services of any other person to endorse its products, and the public image of such person is so
inconsistent with that of KI as to risk damaging the good will of KI's name should KI, Inc. continue
to do business with Diplomat, then KI, Inc. shall have the right to terminate this Agreement,
subject to the remedial and other provisions of paragraph 14 of this Agreement.

24. Miscellaneous Provisions.

(a) Authority. KI, Inc. has the full right, power, legal capacity and authority to enter into this
Agreement on behalf of KI, to carry out its terms, and to grant Diplomat the rights, licenses and
privileges granted in this Agreement.

(b) Merger. This Agreement supersedes any and all prior written or oral agreements between the
parties.

(c) Governing Law. This Agreement shall be governed by and construed in accordance with the laws of
the State of California without regard to conflict of law principles.

(d) Attorneys' Fees. The prevailing party in any proceeding brought to enforce any provision of this
Agreement shall be entitled to recover the reasonable fees and costs of its counsel, plus all other
costs of such proceeding.

(e) Notices. All notices and statements to be given, payments to be made and materials to be
submitted under this Agreement shall be given, made and submitted via certified or registered mail,
postage prepaid, return

12

receipt requested, at the addresses of the parties, as set forth above, unless notification of a
change of address is given in writing, and the date of mailing shall be deemed the date the notice
or statement is given.

IN WITNESS WHEREOF, this Agreement has been executed as of the date first set forth above.

/s/ Kathy Ireland --------------------------------- KATHY IRELAND, Individually KATHY IRELAND, INC.
By /s/ Kathy Ireland --------------------------------- KATHY IRELAND, President
<!-- page 8 -->
THE STERLING/WINTERS CO. By /s/ Jason Winters --------------------------------- JASON WINTERS
DIPLOMAT AMBASSADOR EYEWEAR GROUP By /s/ Barry Budilov --------------------------------- BARRY
BUDILOV, President

13

ADDENDUM TO ENDORSEMENT AGREEMENT

This addendum to the Endorsement Agreement between Kathy Ireland, Inc., Diplomat Ambassador Eyewear
Group, and The Sterling/Winters Company entered into as of August 24, 1995 now includes the
following provision:

Diplomat Ambassador Eyewear Group agrees to comply with the laws and regulations of any state or
territory in which they manufacture or have sub-contracted any Kathy Ireland product, especially
pertaining to labor and safety issues.

Diplomat Ambassador Eyewear Group agrees to comply with any reasonable requests from Kathy Ireland,
Inc. concerning labor and safety resolutions.

DIPLOMAT AMBASSADOR EYEWEAR GROUP 3/4/97 By /s/ Barry Budilov - -------
--------------------------------- Dated BARRY BUDILOV, President

KATHY IRELAND, INC. 3/18/97 By /s/ Kathy M Ireland - ------- --------------------------------- Dated
KATHY IRELAND, President THE STERLING/WINTERS CO. 3/21/97 By /s/ Jason Winters - -------
--------------------------------- Dated JASON WINTERS
