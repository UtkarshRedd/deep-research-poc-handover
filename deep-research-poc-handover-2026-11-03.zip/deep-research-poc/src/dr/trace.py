"""Structured audit events: one JSON line per model call / tool call / stage transition.
This file is the audit trail for a regulated deployment; never log document bodies, only
doc_ids, line ranges, token counts and argument hashes.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any


class Trace:
    def __init__(self, path: Path, run_id: str):
        self.path = path
        self.run_id = run_id
        self.t0 = time.perf_counter()
        self._f = path.open("a", encoding="utf-8")

    def event(self, kind: str, **fields: Any) -> None:
        rec = {"run_id": self.run_id, "t_ms": int((time.perf_counter() - self.t0) * 1000), "kind": kind}
        rec.update(fields)
        self._f.write(json.dumps(rec, default=str) + "\n")
        self._f.flush()

    def tool_call(self, stage: str, name: str, args: dict, result_chars: int, ms: int) -> None:
        self.event("tool", stage=stage, tool=name, args_hash=_h(args), args_preview=_preview(args),
                   result_chars=result_chars, ms=ms)

    def model_call(self, stage: str, role: str, model: str, in_tokens: int | None, out_tokens: int | None, ms: int) -> None:
        self.event("model", stage=stage, role=role, model=model, in_tokens=in_tokens, out_tokens=out_tokens, ms=ms)

    def stage(self, name: str, status: str, **fields: Any) -> None:
        self.event("stage", stage=name, status=status, **fields)

    def close(self) -> None:
        self._f.close()


def _h(obj: Any) -> str:
    return hashlib.sha1(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:12]


def _preview(args: dict, n: int = 120) -> str:
    s = json.dumps(args, default=str)
    return s if len(s) <= n else s[:n] + "…"
