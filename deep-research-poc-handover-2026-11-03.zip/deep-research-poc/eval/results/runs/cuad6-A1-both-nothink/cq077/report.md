# Among the following 8 agreements, which contain a non-compete clause? For each, quote t...

*Question:* Among the following 8 agreements, which contain a non-compete clause? For each, quote the clause. Agreements: the Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley (dated 2017-11-14); the Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. (dated 2011-03-14); the Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc (filed 2018-11-09); the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC (dated 2013-05-15); the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies (filed 2005-11-02); the Cooperation Agreement between e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC (dated 2020-07-01); the Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. (dated 2010-01-01); the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. (filed 2013-09-26).

> **Partial report.** Research or writing ended before completion; see the gaps and the appendix.

## Identify agreements containing non-compete clauses

The Endorsement Agreement between Eco Science Solutions, Inc and Stephen Marley contains a non-compete clause in Paragraph 8 Exclusivity restricting Talent from endorsing competing products. [4cb98e07400203bf p.3] The Network Affiliate Agreement between National CineMedia, LLC and Digital Cinema Destinations Corp. contains a non-compete clause in Section 11.3(a). [23e65a3b8bc5cc9e p.25] The Exclusive Distributor Agreement between Erchonia Corporation and InnerScope Hearing Technologies Inc contains a non-compete clause in Section 3 restricting promotion of competing products. [61c29bdb3ab6960e p.2] The Sponsorship Agreement between Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. contains a non-compete-type restriction in Section 2(v) prohibiting endorsement of competing entities, products or services. [ab1fd1dd637746ab p.2]

[GAP] Evidence for the Supply Agreement between Integra LifeSciences Corporation and PcoMed, LLC, the Reseller Agreement between Touchstar Software Corporation and Worldwide Strategies, the Cooperation Agreement between e.l.f.

Beauty, Inc. and Marathon Partners Equity Management, LLC, and the Strategic Alliance Agreement between Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. [uncited]

## Quote non-compete clauses

[GAP] Exact non-compete clause text for Eco Science Solutions, Inc and Stephen Marley Endorsement Agreement. [GAP] Exact non-compete clause text for National CineMedia, LLC and Digital Cinema Destinations Corp. Network Affiliate Agreement. [GAP] Exact non-compete clause text for Erchonia Corporation and InnerScope Hearing Technologies Inc Exclusive Distributor Agreement. [GAP] Exact non-compete clause text for Touchstar Software Corporation and Worldwide Strategies Reseller Agreement. [GAP] Exact non-compete clause text for e.l.f. Beauty, Inc. and Marathon Partners Equity Management, LLC Cooperation Agreement. [GAP] Exact non-compete clause text for Stallings Capital Group Consultants, Ltd. and GAINSCO, INC. Sponsorship Agreement. [GAP] Exact non-compete clause text for Freedom Mortgage Corporation and Cherry Hill Mortgage Investment Corp. Strategic Alliance Agreement. The Integra LifeSciences Corporation and PcoMed, LLC Supply Agreement does not contain a non-compete clause between the parties.

## Verification appendix

Claims: 7 · supported: 5 · partially: 0 · dropped: 0 · gaps: 2 · tier-1 support rate: 1.00

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e3→[4cb98e07400203bf p.3] |  |
| s1.2 | s1 | keep | 1.00 | e1→[23e65a3b8bc5cc9e p.25] |  |
| s1.3 | s1 | keep | 1.00 | e4→[61c29bdb3ab6960e p.2] |  |
| s1.4 | s1 | keep | 1.00 | e5→[ab1fd1dd637746ab p.2] |  |
| s1.5 | s1 | gap |  |  |  |
| s1.6 | s1 | gap |  |  | no evidence cited |
| s2.1 | s2 | keep | 1.00 | e2→[31cbf0d18f7d763e p.13] |  |

### Evidence

- e1 [23e65a3b8bc5cc9e p.25 L947-963] keep (1.0): "Section 11.3 Non-Competition and Non-Solicitation. (a) During the Term, except as otherwise provided in this Agreement, Network Affiliate and its affiliates agree not to engage or participate in any business, hold equity interests, directly…"
- e2 [31cbf0d18f7d763e p.13 L640-642] keep (1.0): "(e) Non-Compete. The Settlement Agreement and Mutual Release between *** and *** does not contain a covenant-non-compete applicable to *** and, to the best of PcoMed's current knowledge, *** is not subject to any covenant-non-compete that w…"
- e3 [4cb98e07400203bf p.3 L105-107] keep (1.0): "8. Exclusivity. Talent represents and warrants that during the Term and in the Territories, Talent will not endorse or make any appearances or advertisements on behalf of any other product which is directly competitive to ESSI's products."
- e4 [61c29bdb3ab6960e p.2 L98-105] keep (1.0): "3. Restriction on Promotion of Competing Products. During the term of this agreement, Distributor shall not market, sell advertise or promote the sale or use of any product or device which is competitive with or substantially similar to the…"
- e5 [ab1fd1dd637746ab p.2 L55-58] keep (1.0): "(v) prohibiting the endorsement by Racing and any members of Racing, including the drivers, of any entities, products or services which are in direct competition or otherwise inconsistent with the Sponsor or it products or services, unless …"
