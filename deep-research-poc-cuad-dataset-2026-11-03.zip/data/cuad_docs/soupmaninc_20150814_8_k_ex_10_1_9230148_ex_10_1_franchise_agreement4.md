<!-- page 1 -->
# ADDENDUM REQUIRED BY THE DEPARTMENT OF LAW OF THE STATE OF NEW YORK
| Field | Value |
|---|---|
| Document Type | Franchise Agreement |
| SEC Filing Date | 2015-08-14 |
| Parties | KIOSK CONCEPTS, INC.; THE GRILLED CHEESE TRUCK, INC. |
| Source | CUAD v1 / SoupmanInc_20150814_8-K_EX-10.1_9230148_EX-10.1_Franchise Agreement4 |

ADDENDUM REQUIRED BY THE DEPARTMENT OF LAW OF THE STATE OF NEW YORK The following Items are required
to be included within the Disclosure Document and shall be deemed to supersede the language in the
Disclosure Document itself: 3. LITIGATION Neither the Franchisor, its Predecessor nor any person
listed under Item 2 or an affiliate offering franchises under Franchisor's principal trademark: (A)
has an administrative, criminal or civil action pending against that person alleging: a felony; a
violation of a franchise, antitrust or securities law; fraud; embezzlement; fraudulent conversion;
misappropriation of property; unfair or deceptive practices; or comparable civil or misdemeanor
allegations.

(B) has been convicted of a felony or pleaded nolo contendere to a felony charge or, within the ten
year period immediately preceding the application for registration, has been convicted of or pleaded
nolo contendere to a misdemeanor charge or has been the subject of a civil action alleging:
violation of a franchise; anti-fraud or securities law; fraud; embezzlement; fraudulent conversion
or misappropriation of property; unfair or deceptive practices; or comparable allegations.

(C) is subject to a currently effective injunctive or restrictive order or decree relating to the
franchise, or under a Federal, State or Canadian franchise, securities, antitrust, trade regulation
or trade practice law, resulting from a concluded or pending action or proceeding brought by a
public agency; or is subject to any currently effective order of any national securities association
or national securities exchange, as defined in the Securities and Exchange Act of 1934, suspending
or expelling such person from membership in such association or exchange; or is subject to a
currently effective injunctive or restrictive order relating to any other business activity as a
result of an action brought by a public agency or department, including, without limitation, actions
affecting a license as a real estate broker or sales agent. 4. BANKRUPTCY Neither the Franchisor,
its affiliate, its predecessor, officers, or general partner during the ten year period immediately
before the date of the disclosure document: (a) filed as debtor (or had filed against it) a petition
to start an action under the U.S. Bankruptcy Code (or any comparable foreign law); (b) obtained a
discharge of its debts under the bankruptcy code; or (c) was a principal officer of a company or a
general partner in a partnership that either filed as a debtor (or had filed against it) a petition
to start an action under the U.S. Bankruptcy Code or that obtained a discharge of its debts under
the U.S. Bankruptcy Code during or within one year after the officer or general partner of the
Franchisor held this position in the company or partnership. IN WITNESS WHEREOF, the parties hereto
have duly executed, sealed and delivered this Addendum dated this ______ day of ______________,
2015.

2

Source: SOUPMAN, INC., 8-K, 8/14/2015
<!-- page 2 -->
ATTEST KIOSK CONCEPTS, INC.: By: Witness Name: Title: MASTER FRANCHISEE: THE GRILLED CHEESE TRUCK,
INC. By: Name: Title: Witness

3

Source: SOUPMAN, INC., 8-K, 8/14/2015
