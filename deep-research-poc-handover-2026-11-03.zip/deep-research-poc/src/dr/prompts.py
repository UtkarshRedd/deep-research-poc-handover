"""Prompt loader. Prompts live in `prompts/*.md` at the repo root and are loaded by name; no
model-facing instruction lives in code (CLAUDE.md conventions). Tool *results* (REJECTED,
INVALID ARGUMENTS, offload pointers) are rendered by the tools themselves and are not prompts.

    from dr.prompts import load, load_sections
    system = load("researcher", n_docs=3, manifest_preview=..., opening_observation="", min_calls=6)
    hints = load_sections("width_phase_hints")   # {"early": "...", "mid": "...", ...}

Placeholders are `str.format` fields (write literal braces as `{{` / `}}`); a missing field
raises KeyError so prompt/code drift fails loudly. Override the directory with DR_PROMPTS_DIR
(e.g. to A/B a prompt set without touching the repo).
"""
from __future__ import annotations

import os
import re
from functools import lru_cache
from pathlib import Path

_DEFAULT_DIR = Path(__file__).resolve().parents[2] / "prompts"
_SECTION_RE = re.compile(r"^##\s+(\S+)\s*$", re.MULTILINE)


def prompts_dir() -> Path:
    return Path(os.getenv("DR_PROMPTS_DIR") or _DEFAULT_DIR)


@lru_cache(maxsize=64)
def _read(name: str, directory: str) -> str:
    path = Path(directory) / f"{name}.md"
    if not path.exists():
        raise FileNotFoundError(f"prompt {name!r} not found at {path}")
    return path.read_text(encoding="utf-8").strip("\n")


def raw(name: str) -> str:
    """The prompt file's text, unformatted."""
    return _read(name, str(prompts_dir()))


def load(name: str, **fields) -> str:
    """Load `prompts/<name>.md` and fill its placeholders."""
    text = raw(name)
    if not fields:
        return text
    try:
        return text.format(**fields)
    except KeyError as e:
        raise KeyError(f"prompt {name!r} needs field {e.args[0]!r}") from None
    except (IndexError, ValueError) as e:
        raise ValueError(f"prompt {name!r} has a malformed placeholder: {e}") from None


def load_sections(name: str) -> dict[str, str]:
    """Split a prompt file on `## key` headings into {key: body}; bodies are unformatted."""
    parts = _SECTION_RE.split(raw(name))
    # parts = [preamble, key1, body1, key2, body2, ...]
    return {parts[i].strip(): parts[i + 1].strip() for i in range(1, len(parts) - 1, 2)}
