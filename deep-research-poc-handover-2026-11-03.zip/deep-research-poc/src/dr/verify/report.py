"""Tier-1 verification applied to a Report's claims, plus the verification appendix.

Every claim cites evidence ids; each cited EvidenceItem is aligned against its cited page
(dr.verify.tier1). A claim's tier-1 status is the WORST of its citations (keep > truncate >
drop); an unknown id is a drop. Dropped claims are removed from the rendered report and replaced
by an explicit marker (CLAUDE.md: unverifiable claims are dropped or flagged, never silently kept).
Tier 2 (Phase 7) will fill `tier2` on claim groups and can never override a tier-1 drop.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..agents.writer import render_report
from ..config import DEFAULT, Config
from ..evidence import EvidenceBank
from ..models import Report, VerifyResult
from ..trace import Trace
from ..workspace import Workspace
from .provenance import clusters_for, source_clusters
from .tier1 import verify_bank
from .tier2 import verify_tier2

_ORDER = {"keep": 2, "truncate": 1, "drop": 0}


def verify_report(ws: Workspace, bank: EvidenceBank, report: Report, config: Config = DEFAULT) -> list[VerifyResult]:
    cited = sorted({e for c in report.claims for e in c.evidence_ids})
    items = [bank.get(e) for e in cited if bank.get(e) is not None]
    aligns = verify_bank(ws, items, config)
    for it in items:                       # persist tier-1 status in the bank (audit trail)
        bank.update(it)
    clusters = clusters_for(ws, sorted({it.doc_id for it in items}), config)   # provenance gate
    results: list[VerifyResult] = []
    for c in report.claims:
        if not c.evidence_ids:
            results.append(VerifyResult(claim_id=c.claim_id, tier1="gap", tier1_score=None,
                                        note="no evidence cited" if not c.text.startswith("[GAP]") else None))
            continue
        statuses, scores, notes = [], [], []
        for e in c.evidence_ids:
            al = aligns.get(e)
            if al is None:
                statuses.append("drop")
                notes.append(f"{e}: unknown evidence id")
                continue
            statuses.append(al.status)
            scores.append(al.score)
            if al.relocated_doc_id:
                notes.append(f"{e}: text found in {al.relocated_doc_id} (score {al.relocated_score:.2f}), not in the cited document")
        worst = min(statuses, key=lambda s: _ORDER[s])
        cited_docs = [bank.get(e).doc_id for e in c.evidence_ids if bank.get(e) is not None]
        n_clusters = source_clusters(cited_docs, clusters) if cited_docs else None
        if cited_docs and len(set(cited_docs)) > 1 and n_clusters == 1:
            notes.append("cited documents are near-duplicates: they count as one source")
        results.append(VerifyResult(claim_id=c.claim_id, tier1=worst,  # type: ignore[arg-type]
                                    tier1_score=round(min(scores), 3) if scores else None,
                                    source_clusters=n_clusters, note="; ".join(notes) or None))
    return results


def appendix(report: Report, results: list[VerifyResult], bank: EvidenceBank) -> str:
    n = len(results)
    counts = {k: sum(1 for r in results if r.tier1 == k) for k in ("keep", "truncate", "drop", "gap")}
    cited = [r for r in results if r.tier1 != "gap"]
    support = (counts["keep"] + counts["truncate"]) / len(cited) if cited else None
    t2 = {k: sum(1 for r in results if r.tier2 == k) for k in ("supported", "partially", "unsupported")}
    n_t2 = sum(t2.values())
    out = ["## Verification appendix", "",
           f"Claims: {n} · supported: {counts['keep']} · partially: {counts['truncate']} · dropped: {counts['drop']} · gaps: {counts['gap']}"
           + (f" · tier-1 support rate: {support:.2f}" if support is not None else "")
           + (f" · tier 2 checked: {n_t2} (unsupported {t2['unsupported']}, partially {t2['partially']})" if n_t2 else ""), ""]
    if report.notes:
        out += ["Notes: " + "; ".join(report.notes), ""]
    out += ["| claim | section | tier 1 | score | tier 2 | clusters | sources | note |", "|---|---|---|---|---|---|---|---|"]
    by_id = {c.claim_id: c for c in report.claims}
    for r in results:
        c = by_id[r.claim_id]
        srcs = " ".join(f"{e}→{bank.citation_for(e)}" if bank.get(e) else f"{e}→?" for e in c.evidence_ids)
        score = "" if r.tier1_score is None else f"{r.tier1_score:.2f}"
        clusters = "" if r.source_clusters is None else str(r.source_clusters)
        out.append(f"| {r.claim_id} | {c.section_id} | {r.tier1} | {score} | {r.tier2} | {clusters} | {srcs} | {r.note or ''} |")
    out += ["", "### Evidence", ""]
    for eid in sorted({e for c in report.claims for e in c.evidence_ids}, key=lambda x: int(x[1:]) if x[1:].isdigit() else 0):
        it = bank.get(eid)
        if it is None:
            out.append(f"- {eid}: unknown id")
            continue
        q = it.quote if len(it.quote) <= 240 else it.quote[:240] + "…"
        pg = f" p.{it.page}" if it.page else ""
        out.append(f"- {eid} [{it.doc_id}{pg} L{it.start_line}-{it.end_line}] {it.tier1_status}"
                   + (f" ({it.tier1_score})" if it.tier1_score is not None else "") + f': "{q}"')
    return "\n".join(out) + "\n"


def finalize_report(
    ws: Workspace, bank: EvidenceBank, report: Report, config: Config = DEFAULT, out_dir: Path | None = None,
    llm: Any | None = None, trace: Trace | None = None, deadline_ts: float | None = None, tier2: bool = True,
) -> tuple[Report, list[VerifyResult]]:
    """Run tier 1 (+ provenance), then tier 2 when enabled, re-render the report with drops/flags
    applied, append the appendix, and write `report.md` + `verify.json` into `out_dir`
    (default: the workspace root). `llm` is the verifier model (default: role `verifier`)."""
    results = verify_report(ws, bank, report, config)
    if tier2 and config.verify.TIER2_ENABLED:
        verify_tier2(ws, bank, report, results, llm=llm, config=config, trace=trace, deadline_ts=deadline_ts)
    by_id = {r.claim_id: r for r in results}
    report.markdown = render_report(report, bank, by_id) + "\n" + appendix(report, results, bank)
    out_dir = out_dir or ws.root
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "report.md").write_text(report.markdown, encoding="utf-8")
    (out_dir / "verify.json").write_text(json.dumps([r.model_dump() for r in results], indent=1), encoding="utf-8")
    return report, results
