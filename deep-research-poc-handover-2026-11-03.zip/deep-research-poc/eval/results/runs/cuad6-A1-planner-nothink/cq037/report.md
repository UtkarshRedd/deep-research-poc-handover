# When does the Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONA...

*Question:* When does the Distributor Agreement between COMWARE TECHNICAL SERVICES and INTERNATIONAL TEST SYSTEMS, INC. (filed 2000-07-26) expire, according to its term clause?

## Locate the Distributor Agreement

The document filed 2000-07-26 between COMWARE TECHNICAL SERVICES and INTERNATIONAL TEST SYSTEMS, INC. is confirmed as the Distributor Agreement. [ce581d56506a6a52 p.1] The parties to this agreement are COMWARE TECHNICAL SERVICES ("COMWARE") and INTERNATIONAL TEST SYSTEMS, INC. [uncited] ("ITS"). [ce581d56506a6a52 p.1]

[GAP] The term clause and expiration date of the Distributor Agreement are not present in the provided evidence.

## Identify the term clause

The agreement's effective date is conditional, not a fixed calendar date. [ce581d56506a6a52 p.1] The term clause states that the effective date is the earlier of the date Comware orders and pays for a minimum of $22,710 worth of Products, in any combination, or April 15, 2000. [ce581d56506a6a52 p.1] The renewal period clause begins by stating that provided COMWARE purchases a minimum of $45,420.00 worth of Products, in any. [ce581d56506a6a52 p.1]

[GAP] The expiration date of the Distributor Agreement is not established by the provided evidence.

## Not established by the evidence

[GAP] No evidence was found for: Establish the exact expiration date stated in the term clause of the Distributor Agreement.

## Verification appendix

Claims: 9 · supported: 5 · partially: 0 · dropped: 0 · gaps: 4 · tier-1 support rate: 1.00

Notes: 1 empty section(s) collapsed into gaps: Determine the expiration date

| claim | section | tier 1 | score | sources | note |
|---|---|---|---|---|---|
| s1.1 | s1 | keep | 1.00 | e1→[ce581d56506a6a52 p.1] |  |
| s1.2 | s1 | gap |  |  | no evidence cited |
| s1.3 | s1 | keep | 1.00 | e1→[ce581d56506a6a52 p.1] |  |
| s1.4 | s1 | gap |  |  |  |
| s2.1 | s2 | keep | 1.00 | e2→[ce581d56506a6a52 p.1] |  |
| s2.2 | s2 | keep | 1.00 | e2→[ce581d56506a6a52 p.1] |  |
| s2.3 | s2 | keep | 1.00 | e5→[ce581d56506a6a52 p.1] |  |
| s2.4 | s2 | gap |  |  |  |
| gaps.1 | gaps | gap |  |  |  |

### Evidence

- e1 [ce581d56506a6a52 p.1 L5-7] keep (1.0): "| Document Type | Distributor Agreement |
| SEC Filing Date | 2000-07-26 |
| Parties | COMWARE TECHNICAL SERVICES ("COMWARE"); INTERNATIONAL TEST SYSTEMS, INC. ("ITS") |"
- e2 [ce581d56506a6a52 p.1 L34-35] keep (1.0): "EFFECTIVE DATE: The earlier of the date Comware orders and pays for a minimum of $22,710 worth of Products, in any combination, or April 15, 2000."
- e5 [ce581d56506a6a52 p.1 L78-78] keep (1.0): "4. RENEWAL PERIOD: Provided that COMWARE purchases a minimum of $45,420.00 worth of Products, in any"
