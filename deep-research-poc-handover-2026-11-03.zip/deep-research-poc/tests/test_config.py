"""Budgets are explicit and must be internally consistent (CLAUDE.md invariant 10)."""
import pytest

from dr.config import DEFAULT, StageBudgetsS


def test_default_stage_budgets_fit_total():
    s = DEFAULT.stages
    assert s.sequential_total() + s.RESERVE <= s.TOTAL
    assert s.GAP <= s.RESEARCH
    # the reserve is real: the deadline has slack to force a write from the bank
    assert s.RESERVE >= 20


def test_stage_budgets_reject_overflow():
    with pytest.raises(ValueError, match="exceed TOTAL"):
        StageBudgetsS(RESEARCH=250.0)
    with pytest.raises(ValueError, match="GAP"):
        StageBudgetsS(GAP=200.0)
    # shrinking the reserve to make room is allowed, but it must still fit
    StageBudgetsS(RESEARCH=170.0, RESERVE=10.0)
