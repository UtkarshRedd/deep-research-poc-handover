<!-- page 1 -->
# TRADEMARK LICENSE AGREEMENT
| Field | Value |
|---|---|
| Document Type | License Agreement |
| SEC Filing Date | 2020-01-15 |
| Parties | New Mountain Capital, LLC. ("Licensor"); NMF Senior Loan Fund I, Inc. ("Licensee")("party" and collectively as the "parties") |
| Source | CUAD v1 / NmfSlfIInc_20200115_10-12GA_EX-10.5_11946987_EX-10.5_Trademark License Agreement |

Exhibit 10.5 TRADEMARK LICENSE AGREEMENT This TRADEMARK LICENSE AGREEMENT (this "Agreement") is made
and effective as of [·], 2019 (the "Effective Date"), by and among New Mountain Capital, L.L.C., a
Delaware limited liability company (the "Licensor"), and NMF Senior Loan Fund I, Inc., a Maryland
corporation (the "Licensee"). The Licensor and the Licensee are sometimes referred to herein
separately as a "party" and collectively as the "parties." RECITALS WHEREAS, the Licensee is a
closed-end management investment company that intends to elect to be treated as a business
development company under the Investment Company Act of 1940, as amended; WHEREAS, the Licensor,
together with its affiliates, provides investment management, investment consultation and investment
advisory services; WHEREAS, the Licensor, of which New Mountain Finance Advisers, BDC, L.L.C., a
Delaware limited liability company (the "Investment Advisor") is an affiliate, is the owner of all
right, title, and interest in and to the mark "NMF" (the "Licensed Mark") in the United States of
America, Canada and the European Union (the "Territory") in connection with "financial services,
namely, investment advisory and investment management services for pooled investment vehicles,
private investment funds, and investment accounts; investment management services for others;
private equity services, namely, providing expansion and growth capital in the form of private
equity investments; financial services, namely, private equity and public equity capital investment;
private and public equity investment management services; providing private equity fund investments;
investment services, namely, asset acquisition, consultation, development, research and management
services; capital investment services; equity capital investment; financial services, namely, debt
and equity investment services in private companies, namely, investment to support business
expansions, acquisitions, management buyouts and recapitalizations" (the "Licensed Services"), and
Licensor has been and is currently using, either on its own or through its related companies or
licensees (such as, but not limited to, the Investment Advisor) the Licensed Mark; WHEREAS, the
Licensee is entering into an investment advisory and management agreement with the Investment
Advisor (the "Investment Management Agreement"), wherein the Licensee will engage the Investment
Advisor to act as the investment advisor to the Licensee; WHEREAS, it is intended that the
Investment Advisor be a third party beneficiary of this Agreement; and WHEREAS, the Licensee desires
to use the Licensed Mark as part of its company name and in connection with the operation of its
business, and the Licensor is willing to grant the Licensee a license to use the Licensed Mark,
subject to the terms and conditions of this Agreement. NOW, THEREFORE, in consideration of the
foregoing and the mutual covenants and agreements set forth herein, and for other good and valuable
consideration, the receipt and adequacy of which are hereby acknowledged, the parties, intending to
be legally bound, hereby agree as follows: ARTICLE 1 LICENSE GRANT 1.1. License. Subject to the
terms and conditions of this Agreement, the Licensor hereby grants to the Licensee, and the Licensee
hereby accepts from the Licensor, a personal, non-exclusive, royalty-free right and license to use
the Licensed Mark in the Territory solely and exclusively as a component of the Licensee's own
company name and in connection with the Licensed Services and any business provided in conjunction
therewith by such Licensee. During the term of this Agreement, the Licensee shall use the Licensed
Mark only to the extent permitted under this Agreement, and except as provided above, neither the
Licensee nor any of its affiliates, owners, directors, officers, employees or agents shall otherwise
use the Licensed Mark or any derivatives without the prior express written consent of the Licensor
in its sole and absolute discretion. All rights not expressly granted to the Licensee hereunder
shall remain the exclusive property of the Licensor. Upon written notification by the Licensor

Source: NMF SLF I, INC., 10-12G/A, 1/15/2020
<!-- page 2 -->
to the Licensee of noncompliance with the Licensor's quality standards in any material respect, such
Licensee shall take appropriate steps, in a commercially reasonable time frame, not to exceed sixty
(60) days, to cure such noncompliance. 1.2. Licensor's Use. Nothing in this Agreement shall preclude
the Licensor, its affiliates, or any of its successors or assigns from using or permitting other
entities to use the Licensed Mark, whether or not such entity directly or indirectly competes or
conflicts with the Licensee's businesses in any manner. 1.3. Ownership. The Licensee acknowledges
and agrees that the Licensor is the owner of all right, title, and interest in and to the Licensed
Mark, and all such right, title, and interest shall remain with the Licensor. The Licensee shall not
otherwise contest, dispute, or challenge the Licensor's right, title, and interest in and to the
Licensed Mark. The Licensee hereby assigns and agrees to assign any rights it may have as a result
of its licensed use, including common law rights, in the Licensed Mark, to Licensor. 1.4. Goodwill.
All goodwill and reputation generated by the Licensee's use of the Licensed Mark shall inure to the
benefit of Licensor. The Licensee shall not by any act or omission use the Licensed Mark in any
manner that disparages or reflects adversely on Licensor or its business or reputation. ARTICLE 2
COMPLIANCE 2.1. Quality Control. In order to preserve the inherent value of the Licensed Mark, the
Licensee agrees to use reasonable efforts to ensure that it maintains the quality of its business
and the operation thereof equal to the standards prevailing in the operation of the Licensor's and
the Licensee's businesses as of the date of this Agreement. The Licensee further agrees to use the
Licensed Mark in accordance with such quality standards as may be reasonably established by the
Licensor and communicated to the Licensee from time to time in writing, or as may be agreed to by
the Licensor and the Licensee from time to time in writing. The Licensee agrees to allow the
Licensor to conduct reasonable inspection of the quality of the Licensee's services from time to
time. 2.2. Compliance With Laws. The Licensee agrees that the business operated by it in connection
with the Licensed Mark shall comply with all laws, rules, regulations and requirements of any
governmental body in the Territory or elsewhere as may be applicable to the operation, advertising,
and promotion of the business and that it shall notify the Licensor of any action that must be taken
by the Licensee to comply with such law, rules, regulations or requirements. 2.3. Notification of
Infringement. Each party shall immediately notify the other party and provide to the other party all
relevant background facts upon becoming aware of (a) any registrations of, or applications for
registration of, marks in the Territory that do or may conflict with the Licensor's rights in the
Licensed Mark or the rights granted to the Licensee under this Agreement, (b) any infringements or
misuses of the Licensed Mark in the Territory by any third party ("Third Party Infringement") or (c)
any claim that Licensee's use of the Licensed Mark infringes the intellectual property rights of any
third party in the Territory ("Third Party Claim"). The Licensor shall have the exclusive right, but
not the obligation, to prosecute, defend and/or settle in its sole discretion, all actions,
proceedings and claims involving any Third Party Infringement or Third Party Claim, and to take any
other action that it deems necessary or proper for the protection and preservation of its rights in
the Licensed Mark. The Licensee shall cooperate with the Licensor in the prosecution, defense or
settlement of such actions, proceedings or claims. ARTICLE 3 REPRESENTATIONS AND WARRANTIES 3.1.
Disclaimer of Representation and Warranties. The Licensee hereby accepts this license on an "as is"
basis. The Licensee acknowledges that the Licensor makes no explicit or implicit representation or
warranty as to the registrability, validity, enforceability or ownership of the Licensed Mark, or as
to the Licensee's ability to use the Licensed Mark without infringing or otherwise violating the
rights of others, and the Licensor has no obligation 2

Source: NMF SLF I, INC., 10-12G/A, 1/15/2020
<!-- page 3 -->
to indemnify the Licensee with respect to any claims arising from the Licensee's use of the Licensed
Mark, including without limitation any Third Party Claim. 3.2. Mutual Representations. Each party
hereby represents and warrants to the other party as follows: (a) Due Authorization. Such party is a
corporation or limited liability company duly incorporated or organized and in good standing as of
the Effective Date, and the execution, delivery and performance of this Agreement by such party have
been duly authorized by all necessary action on the part of such party. (b) Due Execution. This
Agreement has been duly executed and delivered by such party and, upon due authorization, execution
and delivery of this Agreement by the other party, constitutes a legal, valid and binding obligation
of such party, enforceable against such party in accordance with its terms. (c) No Conflict. Such
party's execution, delivery and performance of this Agreement do not: (i) violate, conflict with or
result in the breach of any provision of the charter or by-laws (or similar organizational
documents) of such party; (ii) conflict with or violate any governmental order applicable to such
party or any of its assets, properties or businesses; or (iii) conflict with, result in any breach
of, constitute a default (or event which with the giving of notice or lapse of time, or both, would
become a default) under, require any consent under, or give to others any rights of termination,
amendment, acceleration, suspension, revocation or cancellation of any contract, agreement, lease,
sublease, license, permit, franchise or other instrument or arrangement to which it is a party.
ARTICLE 4 TERM AND TERMINATION 4.1. Term. The license granted to the Licensee under this Agreement
shall continue perpetually. Notwithstanding the foregoing, this Agreement shall expire if the
Investment Advisor or one of its affiliates ceases to serve as investment adviser to the Licensee.
This Agreement shall be terminable (a) by the Licensor (i) at any time and in its sole discretion in
the event that the Licensor or the Licensee receives notice of any Third Party Claim arising out of
the Licensee's use of the Licensed Mark or (ii) upon sixty (60) days' written notice by the Licensor
to the Licensee or (b) by the Licensee (i) at any time in the event such Licensee assigns or
attempts to assign or sublicense this Agreement or any of the Licensee's rights or duties hereunder
without the prior written consent of the Licensor or (ii) upon sixty (60) days' written notice by
the Licensee to the Licensor. 4.2. Effect of Termination. Upon expiration or termination of this
Agreement, all rights granted to the Licensee under this Agreement with respect to the Licensed Mark
shall cease, and the Licensee shall immediately delete the term "NMF" from its corporate name and
shall discontinue all other use of the Licensed Mark. For twenty-four (24) months following
termination of this Agreement, the Licensee shall specify on all public- facing materials in a
prominent place and in prominent typeface that the Licensee is no longer operating under the
Licensed Mark, is no longer associated with the Licensor, or such other notice as may be deemed
necessary by the Licensor in its sole discretion in its prosecution, defense, and/or settlement of
any Third Party Claim. ARTICLE 5 MISCELLANEOUS 5.1. Third Party Beneficiaries. The parties agree
that the Investment Advisor shall be a third party beneficiary of this Agreement, and shall have the
rights and protections provided to the Licensee under this Agreement. Nothing in this Agreement,
either express or implied, is intended to or shall confer upon any third party other than the
Investment Advisor any legal or equitable right, benefit or remedy of any nature whatsoever under or
by reason of this Agreement. 5.2. Assignment. The Licensee shall not sublicense, assign, pledge or
grant as security or otherwise encumber or transfer to any third party all or any part of its rights
or duties under this Agreement, in whole or in part, without the prior written consent from the
Licensor, which consent the Licensor may grant or withhold in its 3

Source: NMF SLF I, INC., 10-12G/A, 1/15/2020
<!-- page 4 -->
sole and absolute discretion. Any purported transfer or other encumbrance without such consent shall
be void ab initio. 5.3. Independent Contractor. Except as expressly provided or authorized in the
Investment Management Agreement or any other agreement between the parties, no party shall have, or
shall represent that it has, any power, right or authority to bind the other party to any obligation
or liability, or to assume or create any obligation or liability on behalf of the other party. 5.4.
Notices. All notices, requests, claims, demands and other communications hereunder shall be in
writing and shall be given or made (and shall be deemed to have been duly given or made upon
receipt) by delivery in person, by overnight courier service (with signature required), by facsimile
or by registered or certified mail (postage prepaid, return receipt requested) to the respective
parties at the following addresses (or such other address as the parties may provide to each other
by written Notice): If to the Licensor: New Mountain Capital, L.L.C. 787 7 Avenue, 49th Floor New
York, New York 10019 Tel. No.: 212.720.0300 Attn: Chief Executive Officer If to the Licensee: NMF
Senior Loan Fund I, Inc. 787 7 Avenue, 48th Floor New York, New York 10019 Tel. No.: 212.720.0300
Attn: Chief Executive Officer 5.5. Governing Law. This Agreement shall be governed by, and construed
in accordance with, the laws of the State of New York without giving effect to the principles of
conflicts of law rules. The parties unconditionally and irrevocably consent to the exclusive
jurisdiction of the courts located in the State of New York and waive any objection with respect
thereto, for the purpose of any action, suit or proceeding arising out of or relating to this
Agreement or the transactions contemplated hereby. 5.6. Amendment. This Agreement may not be amended
or modified except by a written instrument signed by each party hereto. 5.7. No Waiver. The failure
of any party to enforce at any time for any period the provisions of or any rights deriving from
this Agreement shall not be construed to be a waiver of such provisions or rights or the right of
such party thereafter to enforce such provisions, and no waiver shall be binding unless executed in
writing by all parties hereto. 5.8. Severability. If any term or other provision of this Agreement
is invalid, illegal or incapable of being enforced by any law or public policy, all other terms and
provisions of this Agreement shall nevertheless remain in full force and effect so long as the
economic or legal substance of the transactions contemplated hereby is not affected in any manner
materially adverse to any party. Upon such determination that any term or other provision is
invalid, illegal or incapable of being enforced, the parties hereto shall negotiate in good faith to
modify this Agreement so as to effect the original intent of the parties as closely as possible in
an acceptable manner in order that the transactions contemplated hereby are consummated as
originally contemplated to the greatest extent possible. 5.9. Headings. The descriptive headings
contained in this Agreement are for convenience of reference only and shall not affect in any way
the meaning or interpretation of this Agreement. 4

th

th

Source: NMF SLF I, INC., 10-12G/A, 1/15/2020
<!-- page 5 -->
5.10. Counterparts. This Agreement may be executed in one or more counterparts, each of which when
executed shall be deemed to be an original instrument and all of which taken together shall
constitute one and the same agreement. 5.11. Entire Agreement. This Agreement constitutes the entire
agreement of the parties with respect to the subject matter hereof and supersedes all prior
agreements, understandings and arrangements with respect to such subject matter. 5

Source: NMF SLF I, INC., 10-12G/A, 1/15/2020
<!-- page 6 -->
IN WITNESS WHEREOF, the parties hereto have executed and delivered this Agreement as of the
Effective Date. LICENSOR: NEW MOUNTAIN CAPITAL, L.L.C. By: Name: Title: LICENSEE: NMF SENIOR LOAN
FUND I, INC. By: Name: Title: ACKNOWLEDGED AND AGREED TO AS OF THE EFFECTIVE DATE OF THIS AGREEMENT
NEW MOUNTAIN FINANCE ADVISERS BDC, L.L.C. By: Name: Title: 6

Source: NMF SLF I, INC., 10-12G/A, 1/15/2020
